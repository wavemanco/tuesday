# Interview pack: Live Operations Producer, Saltmarsh Games

Candidate: Femi. Interviewer: Tobias Wrenfield, Head of Live Operations. Round: the single 60-minute interview, assumed to be the hiring-manager session. Saltmarsh's interviewing page calls it the "Outage Hour" and says it is with the hiring manager. You have not said whether Tobias is your future manager, so the pack assumes he is.

## How to use this pack and the type key

Personas describe how a question arrives. Types describe what is being scored.

| Type | What it scores |
|---|---|
| VAL | Whether past behaviour shows the company's published values |
| EXP | Whether your stated experience survives scrutiny, and what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge |
| CASE | A live problem from the real role, reasoned aloud |

Guidance is scaffolding, not a script. Where a cell says "answer slot", it names a probe the interviewer is likely to make. Answer from your own experience in your own words. If the thing did not happen, or was not yours, say so plainly. Both answers are acceptable.

IDs run by persona (A, B, C, D, E, G). Snapshot rows are F1 to F10, so the letter F is not used for a bank.

## Prep triage (interview Friday, about one day)

1. Rehearse C1 and C2 aloud until they are boring. They are the highest-ROI prep in this pack.
2. Run the tabletop, A1 and A2, twice aloud, with a timer. Practise saying what you know and what you do not.
3. Choose your stories for B1 to B3 using the selection criteria. Pick only real ones.
4. Prepare the D1 walk-through of the retention numbers: how they were counted, and which assumption you would defend least.
5. Pick three reverse questions.

Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio" — your message; "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | discovery | Your material shows four years as an associate producer and two years of the weekly calendar. It does not show whether the other two years involved live content. Answer slot: if they did, say what; if not, say so plainly and lead with the two years of the calendar |
| F2 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | none | No gap, but a statement with nothing inspected behind it, so expect a probe. Lead in the quote's own terms: you ran the weekly content-drop calendar for your main title for two years |
| F3 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | transferability | Your quote is one main title and content drops. The JD says events, two titles and mobile, and your material does not show those. Answer slot: if any drop was a timed event, say how it differed; if a second title or a mobile platform was involved, say so; if none of these, say so plainly and stay with the weekly calendar for your main title |
| F4 | "coordinate design, art, engineering and community teams on each update" — JD | none given | none | [grounded] | discovery | Your material says nothing about coordination. Answer slot: if you coordinated with any of these disciplines on a drop, say which and how, in your own words; if not, say so plainly and say who you did work with |
| F5 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | transferability | The quote is presenting monthly numbers. It does not show a review of an event or ownership of the numbers. Answer slot: if you ran any review after a drop, say what it covered and what changed; if the monthly presentation was the nearest thing, say so plainly |
| F6 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses" — your message | medium | [grounded] | none | The quote says you wrote the checklist and QA still uses it. Expect a probe on whether you ran releases through it. Answer slot: if you did, say how; if someone else ran them, say so plainly |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | presentation | Say it at its own scope: you presented the monthly retention numbers to the studio head. Expect the probe in D1 on how they were counted |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses" — your message | medium | [grounded] | transferability | A checklist is writing, but it is adjacent to prose communication. Answer slot: if other writing of yours was read by others, say what; if not, say so plainly and stay with the checklist |
| F9 | Monetization side of a mobile live-events role (not a JD line; the pack's role-family reading) | "never worked on a game with in-app purchases" — your message | none | [generic] | capability | A gap wording cannot close, and you have said so. Words: "I've never worked on a game with in-app purchases." Then say what you would learn first and from whom, as a plan and never as a past |
| F10 | Leading people (the JD asks you to coordinate teams, not manage them) | "Never led a team" — your message | none | [generic] | capability | You have stated this. Words: "I've never led a team." Then move to coordination (F4), as a plan or an answer slot, never as a claim |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has led or managed a team | Negative you stated, F10 | "I've never led a team." No slot |
| Has worked on in-app purchases or owned monetization | Negative you stated, F9 | "I've never worked on a game with in-app purchases." No slot |
| Ran live events across two mobile titles | Inflated form of F3 | The F3 quote at its own scope: "I ran the weekly content-drop calendar for our main title for the last two years." The material says one main title and content drops, not events or two titles |
| Owned the post-event review and the KPIs, or set retention targets | Inflated form of F5 and F7 | "Presented the monthly retention numbers to the studio head." The material says presenting, not owning or defining |
| Managed releases end to end with QA | Inflated form of F6 | "Wrote the release checklist our QA team still uses." The material says writing the checklist, not running releases |

## Reading the interviewer

Tobias Wrenfield is Head of Live Operations at Saltmarsh Games and was previously a QA lead at a console studio. He gave a GDC 2026 talk, "Patch Notes Are a Promise". Its argument is that a live team is judged by how often its patch notes describe what actually shipped. This comes from a search snippet only. I did not read the talk itself.

Practical implications:

- His talk and the company value "Ship the Patch Not the Promise" say the same thing. Any claim in your answers that outruns what you did will be noticed, so keep to what you did.
- With a QA background, the release checklist is likely to be your best-received material. Say it plainly: "I wrote the release checklist our QA team still uses" (F6).
- In the tabletop, separate what is known, what is suspected and what is hoped, out loud.

Mirror opportunity: shared vocabulary only. He has a QA background and you wrote a checklist QA uses. That is not a career jump, so it is not offered as one.

## Persona weights and table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist (A) | The tabletop: a simulated outage during a live event | Highest. The interviewing page documents a live-incident tabletop as half of the hour | Clarify first, then objective, then who you involve, what you tell players, what you record |
| Values / Behavioral (B) | The values conversation after the tabletop | Highest. The page documents a values conversation, and the three values are published | A story per value where your quotes carry one; selection criteria where they do not |
| Skeptic (C) | Probing your gaps: in-app purchases, never led a team, one title versus two | High. You have stated two gaps, and a hiring manager is buying capability and weighing risk | Rehearse C1 until boring. Hold, then concede only what is true |
| Data-Driven Prober (D) | The retention numbers and the KPIs | Medium. KPIs are in the JD; this is not read from his talk | Know how the numbers were counted and say plainly what you do not know |
| Pressure (E) | Time-boxed, challenging follow-ups during the tabletop | Lower. A live incident carries time pressure, but nothing says he interrupts | Pause, restate, hold through two follow-ups |
| Conversational (G) | The opening and closing minutes | Lower, but still scored | A 90-second arc built from your own sentences |

No Peer Evaluator bank: he is the Head of Live Operations and, per the page, the hiring manager.

## Question banks

### A. Case / Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Forty minutes into a weekend event, part of the player base is receiving the wrong rewards. Walk me through your first fifteen minutes." | CASE | [generic] | Start by saying what you need to know: who is affected, whether it is still happening, whether the event can be paused. State the objective: stop the harm, tell players, fix, record. Name who you pull in, using the JD's disciplines: engineering, QA, community, design. Say what you would tell players and when. Say which premise you would test first. The question needs no claim about your past, so this guidance makes none | The tabletop format is documented on Saltmarsh's interviewing page. The scenario itself is invented practice material, hence `[generic]` |
| A2 | "The fix will take hours. Write me the first two sentences of the notice to players." | CASE | [grounded] | Write only what is built or known, not what is hoped. This is Saltmarsh's own value, "Ship the Patch Not the Promise": "we announce what is built, not what is hoped." Say what you are doing and when the next update comes. Do not give a time engineering has not confirmed. Say who signs off | Scores written communication (F8) under the tabletop, and echoes the value. The value text is from the values page |
| A3 | "The event is over. What does the post-event review look like?" | CASE | [grounded] "Presented the monthly retention numbers to the studio head" | Structure it: timeline, what players experienced, which numbers moved, what changes next time, owners. Name the numbers you would pull first and the one you would trust least. Answer slot: if you have held a review after a drop, say what it covered and one thing it changed; if you have not, say so plainly and walk it as a plan | JD line on owning the post-event review (F5). CASE because it is asked as a live problem |
| A4 | "Project Larkspur puts one shared events calendar across more than one title. What would you need to know before planning its first quarter?" | CO | [grounded] | The September 2026 announcement says Larkspur "moves Tidepool Tactics and Lantern Row to a season-pass model with one shared events calendar from February 2027, and retires per-title event teams in favour of a single live-ops group." Bring one point from it to show grounding, then think aloud: what the two player bases share, what the season-pass cadence leaves open, how clashes get resolved, where this role sits in the new group. Ask rather than assert. The JD says two mobile titles and the announcement names two titles, but the sources do not connect them, so do not assume they are the same | Differentiates from reciting the announcement. Source: a search snippet; the page was not fetched |
| A5 | "A planned event date and a problem players are hitting collide. How do you decide?" | CASE | [grounded] | Saltmarsh's value: "when the calendar and the players disagree, the players win." Structure the decision: how bad is the harm, can it be undone, who decides, what slipping costs. Concede what you would not know until you looked. Do not claim you have decided this before; the question needs no claim about your past | Tests the first value as a live decision. Dual-scored with VAL |

### B. Values / Behavioral (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time the calendar and the players disagreed." | VAL | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Selection criteria: pick a time a drop's date and the players' experience pulled apart. It needs a named stake, what you did, and what happened. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, "I ran the weekly content-drop calendar for our main title for the last two years", or how you would handle it | Value 1, "Players Before Plans". The quote does not carry a clash, so this is a scaffold, not a story map |
| B2 | "Tell me about a time something was announced before it was ready." | VAL | [grounded] | Selection criteria: choose a moment when what was said and what was built differed. Say what you did about it, in your own words. If no such time comes to mind, say so plainly, then say how you would handle it | Value 2, "Ship the Patch Not the Promise". Also echoes Tobias's talk. No quote carries this, so a scaffold |
| B3 | "Walk me through the release checklist you wrote for QA." | VAL | [grounded] "Wrote the release checklist our QA team still uses" | Story-mapped on F6: you wrote it and QA still uses it. Tell those in your own words. Answer slot: the value says "every release leaves the codebase and the checklist better than it found them", so expect a probe on whether it changed. If it changed after a release, say what prompted it; if it did not change, or changing it was not yours to do, say so plainly and stay with what the quote carries | Value 3, "Leave the Build Greener". Your strongest value story and the one most likely to land with a QA-trained interviewer |
| B4 | "Tell me about a time you delivered a message the team did not want to hear." | VAL | [generic] "Presented the monthly retention numbers to the studio head" | Selection criteria: a named stake, a moment you did not soften it, a relationship still intact at the end. If none comes to mind, say so plainly, then give the nearest thing your material carries, "Presented the monthly retention numbers to the studio head", at that scope, or how you would handle it | Persona stem for the values interviewer. A scaffold; the quote does not say the numbers were unwelcome |
| B5 | "Which of our three values would be hardest for you?" | VAL | [grounded] | Choose one honestly and say why in your own words. Give the ramp you would use. Do not pick the easy one; the question rewards candour | Invites self-assessment against the published values |

### C. Skeptic (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You have not worked on a game with in-app purchases. How would you get up to speed on that side of live events?" | JD | [grounded] "never worked on a game with in-app purchases"; "Presented the monthly retention numbers to the studio head" | The highest-ROI rehearsal in this pack. Hold-then-concede. Open with the plain acknowledgment: "I've never worked on a game with in-app purchases." Then give a plan, in the future tense: what you would learn first and from whom. Follow-up one, "so you cannot judge an offer yet?": concede what is true. Follow-up two, "why hire you?": return to the sentences you have, "I ran the weekly content-drop calendar for our main title for the last two years", and the checklist. Never claim adjacent monetization work | F9 is a gap you stated, so it is the least surprising probe. This ranking is the pack's inference, not a finding |
| C2 | "You have never led a team, and this role coordinates design, art, engineering and community. How do you get four disciplines to move when none report to you?" | JD | [grounded] "Never led a team"; "I ran the weekly content-drop calendar for our main title for the last two years" | Open with "I've never led a team." Then the answer slot: if you needed other disciplines to hit a date on the weekly calendar, say which and what you did, in your own words; if not, say so plainly and describe how you would earn it. Do not turn coordination into leadership | F10 and F4. The JD's coordination line is the raising source |
| C3 | "Which part of this JD would you be weakest at on day one?" | JD | [generic] | Choose one. Your quotes stop short at: events and two titles (F3), coordination (F4), the post-event review (F5). Say the limit plainly, then the ramp. Naming one gap is more credible than naming none | Persona stem. The candidate's choice, so no claim is made for you |
| C4 | "Your calendar was weekly content drops on one title. Ours is live events across two mobile titles. What carries over and what does not?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Say the quote at its own scope. What carries over is what the quote carries. Answer slot: if any drop was a timed event, or a second title or a mobile platform was involved, say so; if none, say so plainly and stay with the weekly calendar. Name what you would need to learn | F3 and F1. The question's premise is your own sentence plus the JD's |

### D. Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through the monthly retention numbers you presented to the studio head." | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Say what you presented, at that scope. Answer slots, each in your own words: how the figures were counted; what they are sensitive to; the assumption you would defend least; which part was yours. If you also produced them, say so; if someone else did, say so plainly. "I do not know how that was counted" is an honest answer | F7 and F5. Defend-the-number slots only; the pack names no metric for you |
| D2 | "Which retention metric would you watch first during a live event?" | CASE | [generic] | Choose the one you know best from your own work. Say what it cannot tell you and what you would compare it with. Make no claim about having used it | JD line on retention metrics. A hypothetical, so nothing about your past is presupposed |
| D3 | "What happened after you presented the numbers?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Answer slot: if decisions followed, say which and what part was yours; if none did, or you do not know, say so plainly and stay with presenting them | F5. Asks for an outcome without supplying one |

### E. Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who has run live events across multiple titles?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years"; "Wrote the release checklist our QA team still uses" | Hold on the two sentences you have, at their own scope. Concede what is true, in your own words: if events across several titles were not part of your work, say so plainly. Do not fold on the core claim to restore harmony | F3. Tests holding a position without defensiveness |
| E2 | "How much of that calendar was actually you?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Your sentence says you ran it. Answer slot: which parts were yours, and which belonged to design, QA or others, in your own words. If a part was shared, say shared | Attribution probe on F2 |

### G. Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Walk me through the journey: how did you end up in live production?" | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio"; "I ran the weekly content-drop calendar for our main title for the last two years"; "Wrote the release checklist our QA team still uses"; "Presented the monthly retention numbers to the studio head" | A 90-second arc using only those sentences: the four years, the calendar, the checklist, the retention numbers. Answer slot: how you came into the field, in your own words. If there was no clear route, say so | F1. A casual opener that is still scored |
| G2 | "Why Saltmarsh, and why this role now?" | JD | [generic] | Answer slot: your own real reasons. If a published value genuinely matches something you have done, say which; do not borrow one. One factual hook is allowed: you read how Saltmarsh describes its interview and its values | Motivation consistency. No claim about your past is written for you |

## Requirement coverage

| JD requirement | Questions |
|---|---|
| "Plan and run the live-events calendar for two of our mobile titles" | A4, C4, E1 |
| "coordinate design, art, engineering and community teams on each update" | A1, A2, C2 |
| "own the post-event review and the KPIs it reports" | A3, D1, D3 |
| "manage the release checklist with QA" | B3 |
| "3+ years producing live-service games or apps" | G1, C4 |
| "experience running a content calendar" | B1, C4, E2 |
| "comfortable with player-retention metrics" | D1, D2, D3 |
| "clear written communication" | A2, B3 |

## Values cheat sheet

| Value (official name) | Working meaning | Your mapped story |
|---|---|---|
| Players Before Plans | When the calendar and players disagree, players win | No quote carries a clash. Selection scaffold at B1, with its honest branch; nearest is F3, "I ran the weekly content-drop calendar for our main title for the last two years" |
| Ship the Patch Not the Promise | Announce what is built, not what is hoped | No quote carries it. Selection scaffold at B2, with its honest branch |
| Leave the Build Greener | Every release leaves the codebase and the checklist better than it found them | F6, "Wrote the release checklist our QA team still uses", mapped at B3 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "You came to live operations from QA. What from that background do you still use most when an event goes wrong?" | Ties to his public path and turns the interview into a conversation |
| 2 | "Your GDC talk argued a live team is judged by how often its patch notes describe what shipped. How does that show up in how you review an event?" | Shows you looked at his work and connects to the post-event review in the JD |
| 3 | "With Project Larkspur's shared calendar, what will this producer own that per-title event teams used to?" | Strategy-aware, and it asks where the role sits |
| 4 | "How are post-event reviews used here, and who reads them?" | Probes the part of the JD you can least prove |
| 5 | "What do you wish new live-ops producers knew about the monetization side before starting?" | Surfaces your stated gap honestly, as curiosity |
| 6 | "What would make the first event I run a good one?" | Signals ownership and asks for his bar |

## Sources

Provided documents: the JD as pasted, and your own description of your background.

Research tier: L1 — searches 4 of 6, fetches 2 of 2

Queries run:
- "Saltmarsh Games values" returned https://saltmarshgames.com/values
- "Saltmarsh Games interview process live operations producer" returned https://saltmarshgames.com/careers/interviewing
- "Saltmarsh Games strategy news mobile" returned https://saltmarshgames.com/news/project-larkspur (search snippet only; page not fetched)
- "Tobias Wrenfield Saltmarsh Games" returned https://talks.gdconf.example/2026/patch-notes-are-a-promise (search snippet only; page not fetched)

Fetched: the values page and the interviewing page.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | yes | Section 10 and the B bank: the three values by name |
| 2. Interview process | yes | Persona weights; the tabletop in A; the values bank in B |
| 3. Strategy / recent news | yes | A4 and reverse question 3; snippet only |
| 4. Tobias Wrenfield | yes | The interviewer read and reverse questions 1 and 2; snippet only |
| 5. Representative JD | skipped | The JD you supplied fixes the snapshot and the JD-tagged questions |

## Upgrade menu

- Confirmation that Tobias is your future manager, and anything the recruiter said about the tabletop (which systems, which event types) → persona weights recomputed and the A bank tuned
- Deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → a grounding brief; the full Larkspur announcement and Tobias's talk read in full instead of from snippets, so A4 and the interviewer read can be sharper
- Your answers to the slots on coordination, timed events, a second title, a mobile platform and any review you ran → F1, F3, F4 and F5 move from `discovery` or `transferability` to grounded story maps
- The release checklist itself, or a retention deck you presented → F6 and F7 can rise from `medium` toward `high`
- A `tuesday-dossier.md` from an earlier evaluation, if you have one → an evidence-derived top objection and stricter prohibited-claim constraints
