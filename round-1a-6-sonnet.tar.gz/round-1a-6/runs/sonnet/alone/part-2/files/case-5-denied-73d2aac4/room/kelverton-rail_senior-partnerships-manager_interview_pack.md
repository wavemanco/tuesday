# Interview pack: Senior Partnerships Manager, Kelverton Rail

**Round:** second round, 60-minute panel on Tuesday. **Panel:** Deepa (VP Partnerships, your future manager) and Ross (Commercial Director). **Shape:** 15 minutes of your POV, no slides, then Q&A, with Ross pushing on commercials.

**Built on:** your message and the recruiter's email as you quoted it. No JD, no CV text, no text of the market report, and no web research (every search was refused). Company-specific content is therefore labeled `[generic]`, and the upgrade menu says what would change it.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding for a spoken answer, not a script: say it in your own words, and where a cell holds an answer slot, answer it from what you actually did.

| Type | Meaning |
|---|---|
| VAL | Behavioral or values alignment: does past behavior show the company's published values (none were available to me, so no VAL questions here) |
| EXP | Work-experience deep-dive: does the CV claim survive scrutiny, and what was actually yours |
| JD | Role-driven: can you do the listed job, including its gaps |
| CO | Company and strategy knowledge: can you think at the company's altitude |
| CASE | Live problem from the actual role, scored on structure and reasoning |

## Prep triage (about four hours, spread over the weekend)

| Order | Time | Do this | Where |
|---|---|---|---|
| 1 | 90 min | Build and rehearse the 15-minute POV out loud, twice, timed. Stop at 13 minutes so you have a buffer. | Section 5 |
| 2 | 45 min | Rehearse C1 with three levels of follow-up, then D1. C1 is the highest-ROI prep in this pack. | C1, C2, D1 |
| 3 | 45 min | Write in your own words what you know and do not know about how the £4M and the 6-to-40 were counted and what was yours. Then say B1 to B4 aloud. | B1 to B4 |
| 4 | 30 min | Reread the report. Mark one item to restate, one to push back on, and one thing you would say no to. | A3, A4 |
| 5 | 30 min | Your 90-second journey arc (E1) and your reverse questions. | E1, section 11 |

Everything else is insurance.

## 4. Fit snapshot

No JD was supplied, so the requirements below are the recruiter's own words as you quoted them, plus two role-family expectations written as plain prose.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "where you'd take our operator partnerships over the next 18 months" — recruiter's email, quoted in your message | "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." — your message | medium | [grounded] | transferability | Your material says an ISV channel at a payments company, not operator partnerships, with nothing inspected behind it, so the words stay at the sentence's scope: "I ran the ISV channel and took it from 6 partners to 40." Answer slot: the POV is about operator partnerships, so expect a probe on what carries over. If something from the channel carries over, say what, in your own words; if nothing does, or it was not yours, say so plainly and stay with the channel |
| F2 | "Please land on what it means for the operators themselves." — recruiter's email, quoted in your message | "Before that 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." — your message | medium | [grounded] | transferability | The sentence says bus and light rail network planning. It does not say who the work was for or whether it involved train operating companies, and the words stay there: "I spent five years in transport consulting, in bus and light rail network planning." Answer slot: expect a probe on what operators needed in that work. If any of it was with operators, say which kind and what you did; if it was not, say so plainly and stay with the network planning |
| F3 | "Ross will push on commercials." — recruiter's email, quoted in your message | "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." — your message | medium | [grounded] | transferability | The quote says influenced revenue, and the words stay at that: "roughly £4M of influenced revenue". Answer slot: a figure raises four probes. How it was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours. Answer each in your own words; "I don't know how it was counted" is an honest answer |
| F4 | Carrying a commercial number for partner-sourced revenue — role-family expectation, no source supplied | "Never sold into rail specifically and never carried a direct quota, only influenced revenue." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't carried a direct quota." Then how you would work toward one, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F5 | Credibility with train operating companies, Kelverton's customers as you described them — role-family expectation, no source supplied | "Never sold into rail specifically and never carried a direct quota, only influenced revenue." — your message | none | [grounded] | capability | Words: "I haven't sold into rail specifically." Then what you would do to close it, said as a plan. No claim to rail selling, and no claim that bus and light rail work is the same thing |
| F6 | The market report the recruiter attached, the strategy team's internal paper | "She also attached the market report their strategy team circulated internally last quarter, which I've read." — your message | medium | [grounded] | discovery | Your material says you read it, not what you concluded. Words: "I've read the report." Answer slot: expect a probe on what you took from it. Name one item you agree with and one you would push on, in your own words; if there is nothing you would push on, say so plainly and say what you would test |

## 5. Graded deliverable: the 15-minute POV

The recruiter asked for a POV on where you would take operator partnerships over the next 18 months, and to land on what it means for operators. This is graded, so it gets its own build.

**5a. Facts you can build on.** Each is a row of the fit snapshot and a sentence exactly as it stands in that row's evidence cell.

| Row | Sentence | What it can carry in the talk |
|---|---|---|
| F1 | "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | One credibility sentence at its own scope. It is not a thesis and it is not about operators |
| F2 | "Before that 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." | One sentence on why operators matter to you, at the scope of bus and light rail. Do not widen it to train operating companies |
| F4 | "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | One plain clause, said by you before Ross asks, then move on |
| F6 | "She also attached the market report their strategy team circulated internally last quarter, which I've read." | The consensus item you restate to prove grounding |

**5b. Theses.** I have not seen the report, so each thesis has a check you run against it before you use it. A stance is not a claim about Kelverton; the check is what makes it one.

| Thesis (a stance) | Basis | Check in the report first | Mandatory concession | What it means for operators |
|---|---|---|---|---|
| T1. Depth over breadth: concentrate on a few operator relationships that shape the roadmap | [generic] | Does the report show operators differing enough that a few can stand for the rest | It concentrates dependence in a few relationships and gives the rest less attention. Say what the rest get | Name what an operator could decide or influence that it cannot today, in the report's own terms |
| T2. Partner-led delivery: use third-party partners so that operator rollouts need less direct effort from Kelverton | [inferred] from F1, the nearest adjacent work you have | Does the report name delivery or integration effort as an operator pain point | Your channel was ISV on a payments platform, not rail, so operator deployment realities are something you would validate with operators first | Name the operator-side change in the report's own measure, such as effort, time or risk |
| T3. Judge partnerships by an operator outcome, not by partner count | [generic] | Which operator-side measure the report uses | Partner count is what leadership sees, so you need a leading indicator and you would agree it with Ross | The measure is one the operator already tracks, so it can see the change |

**Recommended shape.** Restate the report's top partnership priority as your consensus item (one minute, in its words). Then one divergence, T2 or T1 depending on the check, with its concession said aloud. Then the anti-pick: the one thing you would say no to, which is a stance and says nothing about your past. If you take T3 as the anti-pick, expect Ross to point at your own headline and push on it; B2 is the rehearsal.

**5c. Run of show, 15 minutes.**

| Minutes | Beat | Purpose |
|---|---|---|
| 0 to 1.5 | Say how you are reading "operator partnerships" and invite correction | Clarify before you structure |
| 1.5 to 4 | Consensus item from the report, in its words | Proves grounding |
| 4 to 9 | Your divergence with its concession, then the anti-pick | Judgment |
| 9 to 12.5 | What it means for operators: one operator type, one change, one measure | The requested close |
| 12.5 to 14 | What you do not yet know, stated as a first-90-days plan | Candor, not a claim |

Answer slot for the operator close: name the operator type and measure from the report in your own words; if the report does not give one you can use, say what you would ask operators first.

## 8. Persona table

The loop is one 60-minute panel, from your own words, so no archetype fallback applies.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Case / Strategist | Deepa, as your future manager, after the POV: live problems on the partnership roadmap | High. A hiring-manager relationship tilts to Case and Skeptic, and the POV is itself a case | Clarify, then objective, segmentation, approach, metrics, risks; think aloud; challenge one premise politely |
| B. Data-Driven Prober | Ross on commercials: the £4M, the 6-to-40, how revenue is attributed | High. The recruiter said Ross will push on commercials, and your headline figures are the likeliest probe targets | Know what you can and cannot say about how each figure was counted; name the weakest assumption you know of before he does |
| C. Skeptic | Both, on rail and on no direct quota | High. Your message states both gaps | Rehearse C1 until it is boring: plain acknowledgment, then what your material does carry, then a plan |
| D. Pressure | Ross, time-boxed or interrupting on terms and targets | Medium. Commercial directors often test composure on numbers, but nothing here says Ross does | Pause, restate, hold through two follow-ups, concede only what is true |
| E. Conversational | Deepa, in the opening | Medium. It is likely to be the opening of the Q&A and it is still scored | A 90-second arc built only from your sentences |

## 9. Question banks

Highest-ROI prep: **C1**. It will be asked in some form, and a calm rehearsed answer changes the panel.

### A. Case / Strategist (weight: top, 5 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Sketch how you would set up an operator partnership programme. What do you need to know first?" | CASE | [generic] | Clarify what operators buy and what Kelverton needs from them, state the objective in operator terms, segment operators, choose an approach, name the measure, name the risk. Say the structure aloud before using it. The question needs no claim about your past, so the guidance makes none | A live problem on the role itself, and the POV's twin; CASE because it scores structure |
| A2 | "What do you do in your first 90 days, and what do you decide not to do?" | JD | [generic] | Listen, map, agree measures, pick one pilot; say what you would hold off on and why. A plan, so every verb is future tense | JD content with CASE delivery; F5 is why the plan must include learning rail first |
| A3 | "You can fund one partnership type and stop two. Which, and why?" | CASE | [generic] | Rank by the operator outcome from your POV, name the two you would stop, concede what stopping them costs. Hold your choice through two follow-ups | The anti-pick in live form; CASE because it forces a trade-off |
| A4 | "What in our own market report do you agree with, and what would you push back on?" | CO | [grounded] "She also attached the market report their strategy team circulated internally last quarter, which I've read." | "I've read the report." Answer slot: name one item you agree with and one you would push on, in your own words; if there is nothing you would push on, say so plainly and say what you would test. Do not recite the report; bring one consensus item to prove grounding, then your divergence | F6 is the evidence, and it shows reading, not conclusions; CO because it tests altitude |
| A5 | "An operator asks us to co-develop something three other operators do not want. How do you decide?" | CASE | [generic] | Clarify the ask and what is behind it, who else it affects, what you can offer the others, what you would want from product and from Ross on terms, what you would refuse. Name your weakest assumption aloud | A live problem from the operator side of the role; CASE, with JD content |

### B. Data-Driven Prober (weight: top, 5 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Walk me through how the £4M of influenced revenue was counted." | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | Say "roughly £4M of influenced revenue" in those words. Answer slot: how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours, each in your own words; "I don't know how it was counted" is an honest answer. Name the weakest assumption before he does | F3 is the headline figure and the likeliest first probe; EXP because it tests whether the number survives |
| B2 | "You took the channel from 6 partners to 40. How much of that was you?" | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | Hold: "I ran the ISV channel and took it from 6 partners to 40." Answer slot: if you recruited or onboarded specific partners, say which; if others did, or the channel brought them in another way, say so plainly and return to the sentence. Hold through two follow-ups, concede only what is true | F1 carries the attribution probe; EXP and Pressure delivery |
| B3 | "What commercial model would you propose for operator partnerships, and how would you know it was working?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | Reason from principle: what the operator pays or gets, what Kelverton gets, what measure shows it works. Say it is a hypothesis to test with Ross. Answer slot: if you set or negotiated terms with any partner, say which, in your own words; if not, or it was not yours, say so plainly and stay with influenced revenue | Ross pushes on commercials and F4 is the gap, so the answer must be principled without claiming deal experience; JD with CASE delivery |
| B4 | "You have influenced revenue but never carried a quota. What changes for you here?" | EXP | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | "I haven't carried a direct quota." Then what your material does carry, at its scope: "roughly £4M of influenced revenue". Then the plan, in future tense: what you would agree with Ross about targets in the first 90 days. Never describe past target-carrying | F4 states the negative, so the source for the acknowledgment exists; EXP because it tests candor |
| B5 | "How would you split credit for a deal between our sales team and a partner?" | CASE | [generic] | Clarify what is being counted and why, propose a principle, name the trade-off, say how you would agree it with sales. Concede that a rule everyone accepts beats a perfect one only if that is what you believe. Answer slot: if you used a method for attribution in your channel, say what it was; if there was none, say so plainly | Attribution is where influenced revenue is probed; CASE, with Prober delivery |

### C. Skeptic (weight: high, 4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You have never sold into rail. Why would operators take your calls?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | The deepest rehearsal. Level 1: "I haven't sold into rail specifically." Then what your material carries, at its scope: "I spent five years in transport consulting, in bus and light rail network planning." Level 2, when told bus and light rail are not train operating companies: concede that plainly, since it is true as stated; do not widen. Level 3, "so what is your plan": a plan in future tense, who you would listen to first and what you would verify. Answer slot: if any of the consulting work was with operators, say which kind and what you did; if not, say so plainly. Hold through three levels | F5 is the likeliest objection to land; JD because it scores a stated gap |
| C2 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | Pick one of the two your message states, name it plainly, add the plan. The nearest your material carries is "roughly £4M of influenced revenue" for the quota and the consulting sentence for rail, each at its scope | F4 and F5 are the two candidates; JD because the stem scores self-assessment |
| C3 | "Why leave payments for rail-tech, and why now?" | EXP | [generic] | Give your actual reason in your own words; the material does not say what it is, so the pack supplies none. Keep it forward-looking and consistent with your POV | Motivation consistency is the Skeptic's score; nothing here says what the reason is, so it is a slot |
| C4 | "What from running an ISV channel at a payments company does not transfer to operator partnerships?" | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | Concede first and specifically. Answer slot: say what does not transfer and, if some of it does, what, in your own words; if you do not yet know, say so plainly and say how you would find out | F1 is adjacent work with a stated limit; EXP, with CASE delivery |

### D. Pressure (weight: medium, 3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over a candidate who has already sold into rail?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | Pause, restate, concede: "I haven't sold into rail specifically." Hold on what your material carries at its scope: "I ran the ISV channel and took it from 6 partners to 40." Do not claim the other candidate's strengths are irrelevant | F5 is the objection; JD scored under time pressure |
| D2 | "If we gave you a number to carry in year one, would you take it?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | Answer slot: state your actual position on carrying a number, in your own words, and what you would want agreed first. The pack gives no figure and no position. "I haven't carried a direct quota" is the plain starting point | F4 makes this likely, and it is a term you decide, not a claim to rehearse |
| D3 | "If your three moves had half the budget, which would you cut?" | CASE | [generic] | Rank the moves from your POV in advance. Cut one, say what it costs, hold through two follow-ups | The POV is graded, and Pressure tests whether you can defend its order |

### E. Conversational (weight: low, 2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Walk me through the journey from consulting into partnerships." | EXP | [grounded] "Before that 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." and "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | A 90-second arc with the beats the sentences state: five years of transport consulting in bus and light rail network planning, then nine years in partnerships, the last four running the ISV channel at a payments company. Answer slot: the material does not say what the first five years of partnerships were or why you moved from consulting; say both in your own words | F1 and F2 give the beats; the opening question is scored even when it is friendly |
| E2 | "What drew you to Kelverton?" | CO | [generic] | Answer slot: give your actual reason in your own words, naming one thing from the report and one thing about operators. If no reason comes to mind, say so plainly and say what you want to learn | Interest and homework, asked casually; the pack cannot supply your reason |

### Requirement coverage

| Requirement | Questions |
|---|---|
| "where you'd take our operator partnerships over the next 18 months" | Section 5, A1, A3, A4, D3, E2 |
| "Please land on what it means for the operators themselves." | Section 5c, A1, A5 |
| "Ross will push on commercials." | B1 to B5, D2 |
| Carrying a commercial number | B3, B4, C2, D2 |
| Credibility with train operating companies | C1, C2, C4, D1 |
| The attached report | A4, E2 |
| Motivation and journey | C3, E1 |

## 11. Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Which operator partnership today would you point to as the model, and what made it work?" | It tests how you both define "operator partnerships" and gives you the operator-side picture before you have to build on it |
| R2 | "In the first year, how much of this role is a number I would carry and how much one I would influence?" | It turns a stated gap into a scoping conversation and shows you take Ross's commercial lens seriously |
| R3 | "Where are commercial terms with operators decided today, and where would this role sit?" | It is for Ross, and it shows you are thinking about authority, not just activity |
| R4 | "What would an operator say Kelverton's partnerships changed for them in the last year?" | It continues your close on operators and tells you what the panel counts as an operator outcome |
| R5 | "Which assumption in the strategy team's report do you most want pressure-tested?" | You have read it, so it signals you want to be useful on the hardest part |
| R6 | "What would you want to see from me by day 90 to know the hire is working?" | It is for Deepa, and it gets you the manager's own success measure |

## 13. Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has worked with or sold to train operating companies | Contradicted by F5 | The plain acknowledgment F5 gives: "I haven't sold into rail specifically." No slot |
| Knows how train operators run, from the consulting years | Inflated form of F2 | F2's quote at its own scope: bus and light rail network planning. The limit is the pack's observation: your material does not say who the work was for or that it involved train operating companies. C1's slot stays inside that sentence |
| Carries or has carried a commercial number | Negative the candidate stated, F4 | The plain acknowledgment: "I haven't carried a direct quota." Then "roughly £4M of influenced revenue" at its scope |
| Closed or sold £4M through partners | Inflated form of F3 | F3's quote: influenced revenue. B1's slot asks only how it was counted and which part was yours |
| Personally recruited and onboarded all 40 partners | Inflated form of F1 | F1's quote at its own scope: running the channel and taking it from 6 partners to 40. B2's slot stays inside that sentence |

## 14. Sources

Provided: your message, including the recruiter's email as you quoted it. The market report was attached to that email and you have read it; its text was not provided to me, so nothing in this pack comes from it.

Searches sent, all refused, none returned anything:

- "Kelverton Rail values" — refused
- "Kelverton Rail interview process partnerships manager" — refused
- "Kelverton Rail strategy train operating companies scheduling software news" — refused
- "Deepa VP Partnerships Kelverton Rail" — refused
- "Senior Partnerships Manager rail technology train operating companies job description" — refused

Research tier: L1 — searches 5 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Kelverton Rail values` | unavailable | Every call was refused. It would have fed a values cheat sheet; none is built, and no VAL questions are in the banks |
| 2. `Kelverton Rail interview process` | unavailable | Every call was refused. The loop rests on your own account of one 60-minute panel, which is enough to weight the personas, so nothing changed |
| 3. `Kelverton Rail strategy` and recent news | unavailable | Every call was refused. It would have grounded the CO questions and a grounding brief; CO items are `[generic]` or rest on your own reading of the report |
| 4. `Deepa` and Ross, named with their titles and the company | unavailable | Every call was refused. It would have supplied an interviewer read and a reverse question tied to their paths; both are absent |
| 5. representative `Senior Partnerships Manager` JD | unavailable | Every call was refused. Requirements are the recruiter's quoted words and two role-family expectations in plain prose |

## 15. Upgrade menu

- The JD text → the two role-family rows (F4, F5) become `[grounded]` requirements, and mid-list JD items get their own questions
- Your CV bullets for the payments role and the consulting years → F1, F2 and F3 gain more quotable evidence, and E1's unknown five years can be answered
- The report's headline findings or section headings → a grounding brief, the CO questions and the POV theses (section 5b) become `[grounded]`, and the consensus item is the report's own
- How the £4M and the 6-to-40 were counted, and who the consulting work was for → B1, B2, C1 and F2 upgrade from slots to quoted evidence
- Interviewer profiles, or search access → an interviewer read, persona weights adjusted from their public footprint, and a reverse question tied to each of their paths; with search access, a deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) could also supply the values, the loop and strategy
- A line to the recruiter asking whether Ross's commercial push is about deal terms, targets or pipeline → B3 to B5 and D2 get weighted to the real focus
- `tuesday-dossier.md` → verified evidence and constraints that sharpen the objections and prohibited claims above
