# Stripe — Product Operations Manager — final-round interview pack

Interviewer: not given. Relationship: not given. Round: final round. Built on the assumption that the final round is one conversation or a blend of conversations with an unknown relationship, so persona weights are flat. No job description, CV or research was available, so every row below is a role-family pattern labeled `[generic]`.

## How to use this pack

- Personas describe how a question is asked. Types describe what is being scored.
- Type key: VAL is behavioral or values alignment. EXP is a work-experience deep-dive. JD is role or job-description driven. CO is company and strategy knowledge. CASE is a live problem from the role.
- Guidance is scaffolding, not a script. Where guidance says to pick a story, the story must be one you actually lived, told in your own words. Where nothing comes to mind, the pack gives you the honest branch to say instead.
- Rehearse out loud. Each guidance cell is meant to be speakable in under two minutes.

## Fit snapshot

No job description, recruiter wording or CV was supplied, and the representative-JD search was refused. The requirements below are role-family patterns written without a source, so they are unquoted, labeled `[generic]`, and raise no answer slot. This is the worksheet variant: every evidence cell is empty until you supply material. No requirement here is a hard gate, because nothing supplied states a term such as location, authorization or schedule.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Coordinating launches or changes across several teams (role-family pattern, no JD supplied) | none given | none | [generic] | discovery | Strong evidence would be one launch or change you coordinated, which teams were involved and what you personally decided. Selection scaffold: pick an occasion with at least two teams and a deadline; if no such occasion comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F2 | Designing or running an operating process or cadence such as planning, reviews or intake (role-family pattern, no JD supplied) | none given | none | [generic] | discovery | Strong evidence would be a process that existed or changed because of you, and who used it afterward. Selection scaffold: pick a process you set up or changed; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F3 | Using data to inform product or operational decisions (role-family pattern, no JD supplied) | none given | none | [generic] | discovery | Strong evidence would be a decision the data changed, plus how the figure was counted. Selection scaffold: pick one figure you can explain end to end; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F4 | Influencing peers across product, engineering, go-to-market and support without formal authority (role-family pattern, no JD supplied) | none given | none | [generic] | discovery | Strong evidence would be a disagreement with another team and how it ended. Selection scaffold: pick a disagreement where the other side had a fair point; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F5 | Tooling, systems or automation that make a process run (role-family pattern, no JD supplied) | none given | none | [generic] | discovery | Strong evidence would be a tool you chose, built or configured and what it replaced. Selection scaffold: pick one tool and say what was yours; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F6 | Prioritizing under ambiguity and competing requests (role-family pattern, no JD supplied) | none given | none | [generic] | discovery | Strong evidence would be a call between two asks that could not both be done, and the reason you gave. Selection scaffold: pick a call you would make the same way again, or one you would not; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |

## Persona table

Weights are flat. Your note gives a final round and no relationship, no loop source established Stripe's sessions, and no interviewer was named, so no persona is ranked above another. Banks are ordered by letter, not by weight. Once you tell me who the round is with, the table reweights.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Case and Strategist | Live problems from the role: plan this, diagnose that | Equal (flat): relationship unknown, so priors cannot choose | Clarify first, then objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| B. Skeptic | Quiet probing of gaps and motivation: why this role, why now | Equal (flat): relationship unknown | Rehearse the single most predictable objection until it is boring; say limits plainly; never bluff a competency |
| C. Data-Driven Prober | Asks how a number was counted and what it hides | Equal (flat): a data requirement is typical of the role family, so this is plausible from any interviewer | Know what you can and cannot say about each figure; name the weakest assumption before they do; say plainly when you do not know |
| D. Values and Behavioral | Scenario probes, expects a specific story | Equal (flat): a values round is not established for Stripe, so these themes come from the persona stems, not from Stripe's published values | Choose stories where the hard truth landed; we for context, I for your own contribution |
| E. Peer Evaluator | Seam-splitting and collaboration scenarios | Equal (flat): plausible if the final includes a product or engineering peer | Reciprocity: what you bring their team; propose seam principles rather than pretending to know the seam |
| F. Pressure | Interrupts, time-boxes, plays devil's advocate | Equal (flat): relationship unknown | Pause, restate the question, anchor in what you actually did, hold through two follow-ups before conceding anything real |
| G. Conversational | Friendly, unstructured, still scored | Equal (flat): rapport openers are common at any stage | A 90-second arc for the biography question; treat casual questions on hot JD topics as scored |

## Question banks

Every question is an open prompt or a live problem, so none presupposes anything about your past. Provenance is the label alone because no guidance cell makes a claim about your experience. The highest-ROI prep in this pack is B1, labeled `[generic]` because with no CV the pack cannot see your biggest gap: some form of "where would you be weakest" is the question most likely to arrive, and a calm, specific answer changes the interview. Once you share a CV or JD, B1 is re-aimed at your real gap.

### A. Case and Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A product change touches support, sales and finance, ships in three weeks, and none of those teams has been briefed. What do you do in your first two days?" | CASE | [generic] | Clarify what is changing, for whom and who owns the decision. Then name who must be told, in what order, and what each team needs to do differently. Pick one thing you would check on day two. Say aloud what you would not do yet | A launch-coordination problem, the core of F1; CASE because it scores structure, not recall |
| A2 | "Adoption of a recently shipped feature is 20% below plan. Diagnose it." | CASE | [generic] | State what you would ask first: how plan was set, over what period, which segment is short. Then split into awareness, access, value and measurement problems, and say which you would test first and why. Name one way the measurement itself could be wrong | The standard diagnosis stem; covers F3 |
| A3 | "Design the operating cadence for a product organization with eight teams and no shared rhythm. What do you set up first, and what do you refuse to set up?" | CASE | [generic] | Clarify the pain before the design. Propose the smallest rhythm that fixes it, say how you would know it works and when you would remove it. The refusal half matters: name one ritual you would resist and why | Covers F2; the refusal half tests judgment about process cost |
| A4 | "Two product leads each ask you to prioritize their launch's readiness this quarter, and you can do one. How do you decide?" | CASE | [generic] | Ask what each launch is worth and what slips if it is not supported. State your criteria before applying them, say who you would consult and who decides, and how you would tell the loser | Covers F6 and F4 together |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | Highest-ROI rehearsal. Pick the one of F1 to F6 that your honest self-assessment says is weakest. Say it plainly in one sentence, then give a concrete ramp: what you would learn first and from whom. If you cannot name one, say so plainly and name where you would most want a second opinion. Hold through two follow-ups without adding strengths you have not shown | This question arrives in some form in nearly every final round; JD because it scores the role's own list |
| B2 | "Why product operations, and why now?" | EXP | [generic] | One sentence of motive in your own words, one of what the role is to you, one of what you want from it. Keep all three consistent with the story you told in the biography question | A motivation-consistency probe; EXP because the answer must match the rest of your story |
| B3 | "What would make you fail in this role in the first six months?" | JD | [generic] | Name one real risk and the early signal you would watch for. A risk that is only a strength in disguise reads as evasion | Tests honest self-assessment; JD because failure modes follow the role |
| B4 | "Tell me about the nearest thing you've done to this role, and where it differed." | EXP | [generic] | Pick the closest occasion your material actually carries, describe it at its true scope, then name the real difference. If nothing comes close, say so plainly and describe how you would handle the first month | Invites the bridge story honestly; EXP because it scores attribution |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Pick the number you'd most want us to remember from your last role. How was it counted?" | EXP | [generic] | Choose a figure you can defend. Say how it was counted, what it is sensitive to, which assumption behind it you would defend least, and which part was yours, each in your own words. If you do not know how it was counted, say so plainly | Magnet for probers; weakest-assumption move rehearsed |
| C2 | "Tell me about a time data changed a decision. What did the data not tell you?" | EXP | [generic] | Pick an occasion where the decision actually changed. State the decision, the data, and the one thing it could not show. If none comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | Covers F3 |
| C3 | "What metric would you use to tell whether a product operations function is working, and what would that metric hide?" | CASE | [generic] | Pick one metric, say what it measures, then name what it hides and a second measure that covers the hole. Think aloud, and say what you would need to know first | Covers F3 and F2 at the function level |

### D. Values and Behavioral

Stripe's published values were not researched, so these are generic behavioral themes from the persona stems and are not mapped to Stripe's named principles.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell me about a time you delivered an unpopular truth to a senior stakeholder." | VAL | [generic] | Selection scaffold: pick a time with a named stake, a moment you did not soften it, and a relationship intact afterward. Use I for your contribution. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | Covers F4; the stem is a standard values probe |
| D2 | "When did you put a user's need ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a time the two truly conflicted, say what you gave up, and who objected. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | Tests whether behavior, not slogan, matches a user-first stance |
| D3 | "Tell me about a time you changed your mind after being shown you were wrong." | VAL | [generic] | Selection scaffold: pick something with real cost to being wrong, say what changed your mind, and what you did differently after. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | Tests candor and learning speed |

### E. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Our teams sit side by side. Where is the seam between product operations and product management, and what happens when we disagree?" | JD | [generic] | Offer two or three principles for a seam rather than claiming to know this one: who owns decisions, who owns follow-through, how disagreements escalate. Ask what the seam is today | Covers F4 and F1; peers price what the hire costs their own work |
| E2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Selection scaffold: pick an occasion where credit was contested or shared, say what you did, and how it landed. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | Credit-sharing probe from the persona stems |
| E3 | "What would you need from me in your first month, and what could you do for my team?" | JD | [generic] | Name two needs and two offers, the offers first. Keep both concrete and small enough to be true in month one | Reciprocity framing |

### F. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why you over an internal candidate?" | JD | [generic] | Pause, restate the question, then give one reason that is about the work, not about the other person. Hold through the follow-up, then concede one specific uncertainty without folding on the core | Hold-then-concede rehearsal |
| F2 | "Pick a result you're proud of. How much of it was actually you?" | EXP | [generic] | Choose a result you can attribute precisely. Say what was yours, what was shared and with whom, and what you do not know. Never widen the share when pushed | Attribution probe; precise honesty is the whole answer |
| F3 | "I'm not convinced product operations adds more than it costs. Convince me." | JD | [generic] | Do not defend the function in general. Ask what cost they are seeing, then answer that. Concede where the function can fail, and hold the part you can support | Pressure test on the role's purpose |

### G. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey." | EXP | [generic] | A 90-second arc: where you started, what each move taught you, why this role is next. Build it only from your own history and keep it consistent with B2 | Casual opener that is still scored |
| G2 | "What are you actually playing with in tooling and automation these days?" | JD | [generic] | Name one tool or practice you genuinely use. If you do not use any right now, say so plainly and say what you would learn first | Covers F5, asked casually |
| G3 | "What drew you to Stripe in particular?" | CO | [generic] | Your reasons, in your own words, from what you have read on Stripe's own pages. No Stripe facts are supplied here because none were researched; read the company's own pages first and say only what you read | Homework check; kept generic because research was refused |

### Requirement coverage

| Requirement | Question IDs |
|---|---|
| F1 Coordinating launches or changes | A1, A4, E1, B4 |
| F2 Operating process or cadence | A3, C3, E1 |
| F3 Using data to decide | A2, C1, C2, C3 |
| F4 Influencing without authority | A4, D1, E1, E2, E3 |
| F5 Tooling and automation | G2 |
| F6 Prioritizing under ambiguity | A4, B3, F3 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a strong first ninety days look like in this role, and how will you tell?" | Gets the real success criteria, which the posting rarely states, and shows you are thinking about outcomes |
| R2 | "Where does this role end and product management begin, in practice?" | Surfaces the seam from E1 and shows you want clarity before you start |
| R3 | "What did the last launch this team supported teach you about where the process breaks?" | Invites a real story and shows you think in processes and failure modes |
| R4 | "What is the hardest tradeoff the team is facing right now?" | Moves the conversation from interview to shared problem |
| R5 | "What could a new person do in their first month that would genuinely help your team?" | Reciprocity question; useful if the interviewer is a peer |
| R6 | "What would make you say in a year that this hire was a mistake?" | Gets the interviewer's failure criteria, which is the mirror of B3 |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Any statement of what you did, owned, led or measured | No CV or account of your past was supplied, so nothing in this pack rests on a sentence of yours | Pick the story from your own material and say it at its true scope; where nothing fits, use the honest branch in the guidance |
| Stripe's named values, loop structure or current strategy | Research was refused, so none of it is sourced, and reciting it from memory risks a stale or wrong claim | Read Stripe's own pages and say only what you read |

## Sources

Provided documents: your message (company, role and round). No dossier was supplied.

Searches sent, all refused: "Stripe operating principles values users first move with urgency"; "Stripe interview process Product Operations Manager final round"; "Stripe strategy 2026 annual letter stablecoins agentic commerce tender offer"; "Stripe Product Operations Manager job description responsibilities qualifications". No fetches were sent.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Stripe values | unavailable | All calls refused. Would have supplied official value names for a values cheat sheet and the VAL bank |
| 2. Stripe interview process, product operations | unavailable | All calls refused. Would have supplied the loop structure and persona weights; weights are flat instead |
| 3. Stripe strategy or recent news | unavailable | All calls refused. Would have supplied a strategy-grounded CO or CASE question; G3 stays generic |
| 4. Interviewer name and company | n/a | No name was given, so there was no query to form |
| 5. Representative Product Operations Manager JD | unavailable | All calls refused. Would have replaced the F1 to F6 role-family rows with sourced requirements |

## Upgrade menu

- The job description text → F1 to F6 become quoted requirements, and JD-tagged questions become `[grounded]` or `[inferred]`
- Your CV, or a few sentences about your most relevant projects → the evidence column fills, guidance becomes story-mapped instead of selection scaffolds, B1 is re-aimed at your real biggest gap, and defend-the-number questions are tied to your figures
- Who the final round is with (manager, peer, skip-level, cross-functional) → persona weights reweight and the banks resize
- The interviewer's name → an interviewer read and a reverse question tied to their own path
- Recruiter guidance such as focus areas, a take-home or a presentation → a build section for any pre-declared deliverable
- Search permission, or Stripe's values page and a strategy summary pasted in → a Stripe values cheat sheet, a documented loop, and a grounded CO or CASE question; a deeper research pass would add up to 6 more searches and 2 more fetches, several more minutes
- The schedule, if your final is several sessions → per-session mini-packs
- A `tuesday-dossier.md` from job-underwriter, if you have run one → verified evidence, the objection worth the deepest rehearsal, and absolute limits on what the pack may coach
