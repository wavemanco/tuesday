# Interview prep pack: Member Experience Lead, Ashgrove Credit Union

**Candidate:** Dara. **Loop:** three rounds on 5 December 2026, run as loop mode because the recruiter's email fixes the schedule.

| Round | Who | Length | Relationship |
|---|---|---|---|
| 1 | The recruiter | 30 minutes | Recruiter screen |
| 2 | Head of Member Services | 45 minutes | Your future manager, mostly behavioural |
| 3 | Panel of two branch managers | 60 minutes | Includes a 20-minute complaint-escalation case; also the values round, scored against the four published values |

Interviewers' names are not assigned yet, so only their roles are used. All three rounds fall on one day, so each one needs its own warm-up.

## How to use this pack

- **Personas are how a question arrives; types are what it scores.** Rehearse both.
- **Type key:** VAL = behavioural or values alignment. EXP = work-experience deep-dive. JD = role and requirement driven. CO = company and strategy knowledge. CASE = live problem.
- **Guidance is scaffolding, not a script.** Every claim about your past is one of your own sentences, quoted. An **answer slot** is an instruction for the interview, not a question for you now: answer it from your own experience, or take the honest second branch.
- **Question IDs** read round, persona letter, number: R2-B1 is round 2, Skeptic, first question. Persona letters: A Conversational, B Skeptic, C Values/Behavioral, D Case/Strategist, E Peer Evaluator, F Data-Driven Prober.
- The pack has no interviewer read, no graded-deliverable section and no delivery-coaching section: no names, no declared deliverable and no assessment were provided.

## Prep triage

Sized to the nine days between 26 November and 5 December; hours per day were not given.

1. Rehearse R2-B1 aloud until it is boring. It is the highest-ROI prep in this pack.
2. Answer every answer slot in the fit snapshot in your own words, in writing. Send me the answers and I will regenerate the rows with your words quoted in.
3. For round 3, find a real story for each of the four values or take the honest branch, then run the 20-minute case (R3-D3) twice.
4. Fill the round 1 logistics slots (R1-A3 to R1-A6) with your actual answers.
5. Everything else is insurance.

## Fit snapshot (shared across rounds)

No requirement in the JD is a term such as a licence, location, schedule or pay, so no row is a gate.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor" — your message | medium | [grounded] | presentation | Say it in the sentence's own terms: six years in retail banking, the last three as a branch supervisor. The JD says customer operations and your sentence says retail banking; leave that join to the interviewer and add nothing to the sentence |
| F2 | "Own the member complaints process end to end" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | transferability | Your material says one branch's formal complaints log, not a process across branches, and the words stay there: "I handled the branch's formal complaints log." Answer slot: the JD's end-to-end line makes a probe on what sat around the log likely. If any step before or after the log was yours to set or decide, say which, in your own words; if the log was the whole of your part, say so plainly and stay with the log |
| F3 | "across branches and the contact centre" — JD | "Never worked in a contact centre" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked in a contact centre." Then how you would learn the contact centre's side, said as a plan and never as a past. Never a claim to contact-centre work, and nothing added to make the gap feel smaller |
| F4 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | discovery | Your sentence says a formal log and does not show what governed it. Answer slot: the JD's line makes a probe on how the log was kept likely. If it was kept to rules, time limits or reporting set outside the branch, say which and what each asked of you, in your own words; if it was not, or you do not know, say so plainly and stay with the log you handled |
| F5 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | discovery | Your sentence says a monthly complaints spreadsheet, not what was in it. Answer slot: the JD's volumes and resolution times make a probe on its contents likely. If it showed either, say which, in your own words; if it showed other things, say so plainly and describe what it did show |
| F6 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | presentation | Say the sentence as it stands: you built the monthly complaints spreadsheet your regional manager uses. The JD names Excel and your sentence says spreadsheet; the pack adds no feature, formula or tool to it |
| F7 | "coach branch supervisors on escalations" — JD | "trained new tellers on our escalation script" — your message | medium | [grounded] | transferability | Your sentence is training new tellers on a script, not coaching supervisors, and the words stay there: "I trained new tellers on our escalation script." Answer slot: the JD's coaching line makes a probe on how supervisors differ from tellers likely. If you have helped other supervisors with escalations, say how, in your own words; if you have not, say so plainly and stay with the tellers and the script |
| F8 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't presented to anyone above regional level." Then how you would prepare for it, said as a plan and never as a past. The pack's observation: your sentence does not show what you have presented at or below that level, so the banks ask it as an answer slot, never as a claim |
| F9 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material is silent on this. Answer slot: the JD's line makes a probe on your work with digital teams likely. If you have worked with a digital or technology team on anything members use themselves, say what and which part was yours, in your own words; if you have not, say so plainly and say what you would ask them first |

## Grounding brief

The four points below are the July 2026 strategy brief as you reported them to me; the brief itself was not pasted.

| Brief item | Provenance | Where it touches the JD or the loop |
|---|---|---|
| Move 40% of member service to digital channels by 2028 | [grounded] | JD line "work with digital teams on self-service journeys"; R2-D1 |
| Consolidate eight branches into five hubs over 2027 | [grounded] | Round 3's branch managers; the value "Neighbours, Not Numbers"; R3-D4 |
| Launch a small-business lending product in Q1 2027 | [grounded] | No JD line speaks to it; use only if it comes up |
| Main competitive pressure is app-only banks | [grounded] | R2-D2 |

## Persona table

Weights start from the relationship priors, then move with what the recruiter's email says about each round.

| Round | Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|---|
| 1 | Conversational (A) | Friendly 30-minute chat; logistics and motivation | High (6 questions): a recruiter screen's prior is Conversational plus a light Skeptic, and pay, notice, location and reason for leaving are asked here | Prepare a 90-second arc; treat casual questions as scored |
| 1 | Skeptic (B) | Knockout checks on the JD's headline lines | Light (3 questions): the same prior; F3 and F8 are the lines most likely to be checked | One clean pass of each plain acknowledgment; no defensiveness |
| 2 | Skeptic (B) | Quiet probing of the gaps by the person who would manage you | Highest (4 questions): a hiring manager's prior is Case/Strategist plus Skeptic, and a manager is derisking F2, F3, F8 and F9 | Rehearse R2-B1 until it is boring; hold the plan, concede the experience |
| 2 | Values/Behavioral (C) | Behavioural stories, as the recruiter described the round | Second (3 questions): the recruiter's "mostly behavioural" lifts this above the prior | Quoted story where a sentence carries one; selection scaffold with the honest branch where none does |
| 2 | Case/Strategist (D) | Strategy-linked problems from the brief | Lower than the prior (2 questions): the behavioural framing reduces it | Clarify, objective, segmentation, approach, metrics, risks; think aloud |
| 2 | Data-Driven Prober (F) | A walk through the spreadsheet | Low (1 question): the JD's monthly-reporting and Excel lines | Say plainly what the spreadsheet contained and what you do not know |
| 3 | Values/Behavioral (C) | Scenario probes scored against the four values by name | Dominant (4 questions): the recruiter says the panel is the values round | One story per value, or the honest branch; say answers once, in plain words |
| 3 | Peer Evaluator (E) | Branch managers on the seam between branch and complaints lead | Third (3 questions): their supervisors are the people the role coaches, and a panel blends the top personas of its members | Offer seam principles, not claims about a seam you have not seen; lead with what you bring them |
| 3 | Case/Strategist (D) | The 20-minute complaint-escalation case | Second (2 questions): the recruiter fixes 20 of the 60 minutes | Clarify first, challenge one premise respectfully, structure aloud |
| 3 | Skeptic (B) | One probe on coaching supervisors | Low (1 question): the other personas carry the round | Hold what your sentence says; return to it |

---

# Round 1 mini-pack: recruiter screen (30 minutes)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R1-A1 | "So, walk me through the journey." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "I handled the branch's formal complaints log"; "trained new tellers on our escalation script"; "I built the monthly complaints spreadsheet our regional manager uses" | A 90-second arc with four beats, each a quoted sentence told in your own words: the six years in retail banking and the last three as a branch supervisor; the complaints log you handled; the new tellers you trained on the escalation script; the spreadsheet your regional manager uses. Close on why this role, in your own reason, and stop. Add no figure, title or scope the sentences do not carry | The opener is scored for economy; F1, F2, F7 and F5 are the rows the arc carries. EXP because it tests what was actually yours |
| R1-A2 | "What interests you about Ashgrove?" | CO | [grounded] | Pick one thing you can say in your own words from what Ashgrove has published: the JD's description of a member-owned credit union, one of the four values by its name, or one line of the July 2026 brief. Answer slot: give your own reason for choosing it; the pack does not supply it, and it should not be a reason you would not repeat to the panel | A friendly question about motivation is still scored, and the values and brief are in hand. CO because it tests homework |
| R1-A3 | "What are you looking for on salary?" | JD | [generic] | Pay slot: give your own number, or ask for the role's band first; either is a complete answer. Say it once and stop. If asked what you earn now, you can say "I'd rather focus on the range for this role" | A recruiter screen asks this; the pack supplies no figure because none was given. JD because it concerns the listed job's terms |
| R1-A4 | "What's your notice period?" | JD | [generic] | Notice slot: give your actual notice period in your own words. Do not estimate a date you have not checked | Logistics asked of every candidate; JD because it concerns the job's terms |
| R1-A5 | "Where would you be working from, and is there anything on location or hours we should know about?" | JD | [generic] | Location slot: say where you can work and any limit on location or hours, in your own words; if there is no limit, say that | Logistics; JD because it concerns the job's terms |
| R1-A6 | "What's prompting a move now?" | EXP | [generic] | Reason slot: give your own reason in your own words, in a sentence or two, and keep it about what you are moving toward. The pack supplies no reason because none was given | The reason for leaving is the logistics item recruiters probe for consistency. EXP because it tests your own account |
| R1-B1 | "The role owns complaints across branches and the contact centre. You haven't worked in a contact centre, so how does that sit?" | JD | [grounded] "Never worked in a contact centre" | Hold the plain acknowledgment: "I haven't worked in a contact centre." Then give your plan: what you would learn first about the contact centre's side and from whom, said as a plan, never as a past. Describe no contact-centre work. R2-B1 is the deep version; here one clean pass | F3 is the biggest gap against the JD's headline line, so even a light screen checks it. JD because it scores a stated requirement; Skeptic delivery |
| R1-B2 | "The role asks for confidence presenting to senior leaders. What's your experience of that?" | JD | [grounded] "I've never presented to anyone above regional level" | Hold the plain acknowledgment: "I haven't presented to anyone above regional level." Answer slot: if you have presented at regional level or below, say to whom and what, in your own words; if you have not presented at all, say so plainly. Then your plan for preparing | F8 is a stated limit and a headline requirement. JD because it scores a stated requirement |
| R1-B3 | "The JD asks for four-plus years in financial-services customer operations. Can you confirm where you are on that?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | Give the sentence in its own terms: six years in retail banking, the last three as a branch supervisor. The JD says customer operations and your sentence says retail banking; leave the join to the recruiter, and if asked how your branch work fits that phrase, answer from your own sentences with no scope added | A recruiter confirms the experience line before passing a candidate on (F1). JD because it is a stated requirement |

## Round 1 reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "Can you tell me who will be on the panel and in the Head of Member Services round?" | The names unlock an interviewer read and sharper reverse questions; asking is ordinary at this stage |
| 2 | "Is the Head of Member Services round scored on the same four values, or on something different?" | It tells you where to spend rehearsal time between rounds 2 and 3 |
| 3 | "How is the role expected to divide between branches and the contact centre?" | It shows you are thinking about the F3 limit as a ramp plan, and gets the real split |
| 4 | "Is there anything in my background you would like me to clarify before you pass me on?" | It surfaces an objection while you can still answer it |
| 5 | "What happens after 5 December, and when should I expect to hear?" | A simple process question that closes the call on logistics |

---

# Round 2 mini-pack: Head of Member Services (45 minutes, your future manager)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R2-B1 | "This job owns complaints end to end across the branches and the contact centre. You've told us you haven't worked in a contact centre. Why should I trust you with that side of it?" | JD | [grounded] "Never worked in a contact centre"; "I handled the branch's formal complaints log" | **Highest-ROI prep in this pack.** Level 1: "I haven't worked in a contact centre," then the log at its own scope: "I handled the branch's formal complaints log." Then your plan: what you would learn first and from whom, said as a plan. Level 2, when the interviewer notes that one branch's log is not every branch and a contact centre: concede the scope plainly and return to the plan; add nothing to the sentence. Level 3, when asked what would worry you most in your first three months: name, in your own words, the part you would least know, or say plainly that you do not yet know. Hold the plan through two follow-ups; concede the experience | F2 and F3 together are the widest gap against the JD's opening line, and this interviewer owns that scope, so the probe will arrive in some form. JD because it scores the stated line; Skeptic delivery |
| R2-B2 | "How would you prepare for your first presentation to our leadership team?" | CASE | [inferred] derived from the JD's senior-leaders line and the value "Plain Words" | A live problem that asks about no past. Structure it: ask who the audience is and what decision they need, say what the one thing you want them to take away is, keep the content short and in plain words, rehearse it aloud with someone before the day, and say what you would want to be asked. Make no claim about presentations you have given | F8 is a stated gap and a manager will want to see how you approach it. CASE because it is a live problem; the vocabulary comes from a published value |
| R2-B3 | "Tell me about a time you worked with a digital or technology team." | JD | [grounded] | Selection scaffold: pick a time with a named piece of work, what you did, and what changed for members or staff. If no such time comes to mind, say so plainly, then say how you would approach working with a digital team on self-service journeys and what you would ask them first | F9's JD line has no quote behind it, so this is a scaffold, not a story map. JD because it scores the stated requirement |
| R2-B4 | "Tell me about a time you handled a complaint that had to follow formal rules." | JD | [grounded] "I handled the branch's formal complaints log" | Beat from the sentence: the log you handled, told at that scope. Answer slot: if the log was kept to rules, time limits or reporting set outside the branch, say which and what each asked of you, in your own words; if it was not, or you do not know, say so plainly. Choose one real complaint you remember and say what you did and what happened; if none comes to mind, say so plainly and describe how the log was kept | F4 is the JD's regulated-complaints line, which is a screening line for this role. JD because it scores the requirement; EXP content |
| R2-C1 | "Tell me about a time you trained or coached someone through something difficult." | JD | [grounded] "trained new tellers on our escalation script" | Beats from the sentence: new tellers, the escalation script, trained. Answer slot: the JD's coaching line makes a probe on how supervisors differ from tellers likely. If you have helped other supervisors with escalations, say how, in your own words; if you have not, say so plainly and stay with the tellers and the script | F7 is the nearest evidence for the JD's coaching line. JD because the coaching line is a requirement; behavioural delivery |
| R2-C2 | "Tell me about a time you explained something complicated to someone senior." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Selection scaffold: pick a time with an audience senior to you, a point they had to understand or act on, and what you did to make it plain. If no such time comes to mind, say so plainly, then give the nearest thing your material carries at its own scope, the spreadsheet your regional manager uses, or say how you would handle it | The theme comes from the value "Plain Words" and the JD's senior-leaders line (F8). VAL because it tests plain explanation |
| R2-C3 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time with a named stake, a moment you did not soften the message, and a relationship still intact afterwards. If no such time comes to mind, say so plainly, then say how you would deliver unwelcome complaint figures to a senior leader | A stock behavioural stem that fits a role reporting complaint figures to leaders. VAL because it tests how you handle hard messages |
| R2-D1 | "We aim to move 40% of member service to digital channels by 2028. Which kinds of complaint would you keep out of self-service, and how would you decide?" | CO | [inferred] derived from the brief's digital target and the JD's self-service line | Asks about no past. Clarify first: what counts in the 40%, and which complaint types are in scope. Then the test you would apply, for example whether a member would have to explain twice (Plain Words) and whether a person needs to keep hold of it (Own the Fix). Metrics: the JD's volumes and resolution times by channel. Risk: an upset member pushed into a form. Say these as reasoning, not as experience | The brief's headline target meets the JD's self-service line (F9). CO because it tests strategy fluency; CASE delivery |
| R2-D2 | "Our main competitive pressure is app-only banks. Where does a credit union with branches do better on complaints, and where might it do worse?" | CO | [inferred] derived from the brief's competitive-pressure line | Asks about no past. Give one place Ashgrove could do better and one place it could lose, then say how you would check each. Treat the answer as a judgement you would test, not a boast | The brief names the competitive frame; a manager hears whether you can think at that altitude. CO because it tests the brief |
| R2-F1 | "Walk me through the monthly complaints spreadsheet you built." | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Beats from the sentence: monthly, complaints, you built it, your regional manager uses it. Answer slot: the JD's volumes and resolution times make a probe on its contents likely. If it showed either, say which, in your own words; if it showed other things, say so plainly and describe what it did show. If asked what you do not know about how it was used, say so plainly | F5 and F6 are the rows the JD's monthly-reporting and Excel lines press on. EXP because it tests what was actually yours |

## Round 2 reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "What would you want the first six months to have changed in how members' complaints are handled?" | It asks the future manager for their success measure, which tells you what to prepare |
| 2 | "The brief aims for 40% of member service on digital channels by 2028. Where do you see complaints sitting in that?" | It ties your question to the published target, so it reads as homework |
| 3 | "Who reads the monthly complaints report today, and what decisions does it feed?" | It shows you think about reporting as a tool for decisions |
| 4 | "Which part of this role do you expect a new person to find hardest, and how would you want me to learn it?" | It names the gap openly as a ramp-up plan, in line with R2-B1 |
| 5 | "How would you like to hear about problems: early and rough, or once I have a view?" | It asks how your future manager wants to work with you |

---

# Round 3 mini-pack: panel of two branch managers (60 minutes, values round)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R3-C4 | "Tell me about a time you decided something from the member's side of the counter." | VAL | [grounded] | Selection scaffold for "Members First, Always": pick a time where you made a decision, the member's side of it was clear, and something pulled the other way. If no such time comes to mind, say so plainly, then say how you would decide from the member's side | The first of four published values, scored by name. VAL because the panel scores values |
| R3-C5 | "Tell me about a time you changed how something was explained because people did not follow it first time." | VAL | [grounded] "trained new tellers on our escalation script" | Beats from the sentence: new tellers, the escalation script. Answer slot: the value "Plain Words" makes a probe on the script's wording likely. If a teller needed it explained twice and you changed anything, say what and why, in your own words; if not, or the script was not yours to change, say so plainly and stay with training tellers on it. Say your answer once, in plain words; how you speak in the room is scored too | F7 is the sentence nearest the value. VAL because the value is the scoring frame |
| R3-C6 | "Tell me about a time you thought of a branch as part of its town, not just its figures." | VAL | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | Selection scaffold for "Neighbours, Not Numbers": pick a time tied to a real place or member, what you did, and why it was not in a target. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, your years in branches, at that scope, or say how you would handle it. Expect the panel to notice that this role reports numbers; be ready to say how you would keep both in view | The panel are branch managers, and the brief's consolidation sharpens this value. VAL because it is a published value |
| R3-C7 | "Tell me about a problem you found and kept hold of until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log" | Beat from the sentence: the log you handled, at that scope. Answer slot: the value "Own the Fix" makes a probe on a complaint that stayed with you likely. If one did, say what and what was yours, in your own words; if none did, or it moved to someone else, say so plainly and stay with the log | F2 is the nearest evidence for the value. VAL because it is a published value |
| R3-D3 | "A member comes into a branch angry about a fee. They have been to the branch twice and the contact centre once, and each told them something different. It has landed with you. Take us through it." | CASE | [generic] | The 20-minute case; asks about no past. Clarify first: where the complaint sits, what the member was told and by whom, what they want, and which time limits apply. Objective: one person keeps hold until it is solved (Own the Fix) and the member hears one plain answer (Plain Words). Approach: check branch and contact-centre records, give the member one named contact and a date, agree who does what with the branch supervisor. Metrics: resolved or not, how long, whether it came back. Risks: the member told different things again, each channel assuming the other has it. Challenge one premise aloud, such as why the member was passed between channels at all | The recruiter put a 20-minute escalation case in this round. CASE because it is a live problem set in the role; generic because it is a pattern, not a fact about Ashgrove |
| R3-D4 | "A long-standing member writes in angry that their branch is due to move into a hub next year. How do you handle the complaint?" | CASE | [inferred] derived from the brief's consolidation line and the value "Neighbours, Not Numbers" | Asks about no past. Hear the member out; separate how they were told from the decision itself; say plainly what you can and cannot change; keep hold of the complaint rather than handing it on; log it so the pattern reaches whoever decides; use plain words | The brief's consolidation will reach complaints and the panel are the people living through it. CASE with VAL content |
| R3-E1 | "Our branches sit alongside your team. Where is the seam, and what happens when we disagree?" | CASE | [inferred] derived from the JD's coaching line and the value "Own the Fix" | Offer seam principles, not claims about a seam you have not seen: the branch keeps hold of the member, you keep hold of the process, and you agree who decides before the disagreement arrives. Say what you would bring them before what you would need | A peer-style probe; the JD has the role coaching branch supervisors on escalations. Peer delivery |
| R3-E2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Selection scaffold: pick a time work crossed teams, say plainly which part was yours and which was others', and how credit was shared. If no such time comes to mind, say so plainly, then say how you would handle credit on a shared case | A stock peer stem; VAL because it tests attribution honesty |
| R3-E3 | "The role coaches supervisors on escalations, but one of our values says whoever finds the problem keeps hold of it. How do those fit together?" | VAL | [inferred] derived from the JD's coaching line and the value "Own the Fix" | Asks about no past. Offer a principle, not a claim: escalating is asking for help, not handing the problem over; the person who found it keeps hold and stays the member's contact. Say how you would coach a supervisor to do that. If it is a view you have not tested, say so | The two published lines can look in tension to a branch manager. VAL because it tests whether you can apply the value to the job |
| R3-B5 | "The supervisors you would coach do the job you have been doing. Why would they take coaching from you?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "trained new tellers on our escalation script" | Hold what the sentences say: six years in retail banking, the last three as a branch supervisor, and "I trained new tellers on our escalation script." Answer slot: if you have helped other supervisors with escalations, say how; if you have not, say so plainly and stay with the tellers and the script. Then how you would start with a supervisor, said as a plan | F7 and F1 together. JD because it scores the coaching line; Skeptic delivery |

## Round 3 values cheat sheet

| Value | Working meaning (paraphrased) | Mapped story or scaffold |
|---|---|---|
| Members First, Always | Decisions start from the member's side of the counter | Scaffold, R3-C4; no sentence of yours carries a story here |
| Plain Words | If a member needs something explained twice, the writer got it wrong | F7: "trained new tellers on our escalation script" (R3-C5, slot on the wording) |
| Neighbours, Not Numbers | Each branch belongs to its town | Scaffold, R3-C6; nearest is F1: "6 years in retail banking, the last 3 as a branch supervisor" |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | F2: "I handled the branch's formal complaints log" (R3-C7, slot on a complaint that stayed with you) |

## Round 3 reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "How do escalations from your branch reach the complaints process today, and where do they stall?" | It asks the branch managers about their pain, which is what this role exists to relieve |
| 2 | "What could a new complaints lead do in their first month that would genuinely help your branch?" | The reciprocity question for a peer-style panel |
| 3 | "With eight branches becoming five hubs over 2027, what do you most want kept?" | It ties your question to the brief and to "Neighbours, Not Numbers" |
| 4 | "What is a complaint from your branch that you would have wanted the process to catch sooner?" | It invites a real example, which is the best case-prep material you can get |
| 5 | "How would you want supervisors coached: in the branch, by phone, or in a group?" | It shows you would co-design the coaching rather than impose it |

---

## Requirement coverage

| JD requirement | Questions |
|---|---|
| "4+ years in financial-services customer operations" | R1-B3, R1-A1 |
| "Own the member complaints process end to end" | R2-B1, R3-C7, R3-D3 |
| "across branches and the contact centre" | R1-B1, R2-B1 |
| "experience handling regulated complaints" | R2-B4, R3-D3 |
| "report monthly on complaint volumes and resolution times" | R2-F1, R2-D1 |
| "comfortable with Excel reporting" | R2-F1 |
| "coach branch supervisors on escalations" | R2-C1, R3-B5, R3-E3 |
| "confident presenting to senior leaders" | R1-B2, R2-B2, R2-C2 |
| "work with digital teams on self-service journeys" | R2-B3, R2-D1 |

## Prohibited claims

Built from the fit snapshot before the banks were written.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end | Inflated form of F2 | F2's quote at its own scope. The limit is the pack's observation: your material says the branch's log, not a process across branches. R2-B1's slot stays inside the log |
| Has contact-centre experience | Negative you stated, F3 | The plain acknowledgment: "I haven't worked in a contact centre." No slot |
| Handled regulated complaints | Inflated form of F4 | F4's quote at its own scope: a formal complaints log. R2-B4's slot asks only how the log was kept |
| Reported complaint volumes and resolution times | Inflated form of F5 | F5's quote at its own scope: a monthly complaints spreadsheet. R2-F1's slot asks only what it showed |
| Coached branch supervisors | Inflated form of F7 | F7's quote at its own scope: tellers and the script. The slots stay inside it |
| Has presented to anyone above regional level | Negative you stated, F8 | The plain acknowledgment: "I haven't presented to anyone above regional level." The slot asks only what you have presented at or below that level |

## Sources

Provided documents: the JD; the four published values as you copied them from the values page on 26 November 2026; the recruiter's email on the process; your summary of the July 2026 strategy brief (the brief itself was not pasted); your background as you described it. No dossier was consumed.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | The pasted values text fixes the values cheat sheet and the four VAL questions |
| 2. Ashgrove interview process, member-services roles | skipped | The recruiter's email names the three sessions and who runs each, which fixes the loop and persona weights |
| 3. Ashgrove strategy and recent news | skipped | Your summary of the July 2026 brief supplies current priorities for the CO and CASE questions |
| 4. Interviewer name and Ashgrove | n/a | No names were given, so there was no query to form; the interviewer read is absent |
| 5. Representative Member Experience Lead JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Your CV, or the headings of your monthly spreadsheet and the format of the complaints log → F2, F4, F5 and F6 move from your one-line descriptions toward something inspectable, and the slots in those rows can be filled
- Your answers to the answer slots in F2, F4, F5, F7, F8 and F9 → I regenerate those rows and their bank rows with your own words quoted in
- Your own pay, notice, location and reason for leaving → R1-A3 to R1-A6 become quoted rows
- The interviewers' names, once assigned → an interviewer read, persona weights tuned to their public footprint, and a reverse question tied to each one's path
- A word from the recruiter on whether the 20-minute case is shared in advance → if it is, a graded-deliverable build section for R3-D3
- The strategy brief's own text → the grounding brief and the CO questions draw on the brief's wording rather than your summary
- A deeper research pass, up to 6 more searches and 2 more fetches and several more minutes, offered once → say so and I will add a strategy and recent-organisation-context section
- A tuesday-dossier.md → verified evidence and strategy constraints per weak area, in place of the locally built prohibited list
