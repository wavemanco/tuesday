I'll read the reference files the skill points to before building the pack.
Renaming the Values and Peer question IDs, because V1/V2 and P1/P2 no longer collide with the fit-snapshot rows F1–F9. I'm using Edit for this, since the sed command needed approval.
Your prep pack is saved at `/var/tmp/tuesday-measure/1a6/runs/sonnet/alone/part-2/rooms/case-7-denied-15985b3c/saltmarsh-games_live-operations-producer_interview_pack.md`. I built it assuming Tobias is your hiring manager, since your note didn't say.

Web search was refused in this session, so the pack has nothing on Saltmarsh's values, interview process or strategy, or on Tobias's background. Those research targets are marked unavailable in Sources. The company-specific questions are generic, and there is no interviewer read.

The pack has 22 questions across seven personas, weighted toward Case/Strategist and Skeptic. It also has a fit snapshot against your JD, a requirement-coverage table, six reverse questions and a list of claims it won't coach. The prep I'd put first is B1, the Skeptic question on in-app purchases. It rests on the gap you named yourself, and it's rehearsed in three levels with the exact wording of the concession.

Say the word and I'll play the Skeptic on B1.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Is Tobias the person you'd report to, or is this a skip-level or cross-functional round, and did the recruiter name any focus areas or a deliverable for Friday?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview prep pack: Live Operations Producer, Saltmarsh Games

- **Role:** Live Operations Producer, Saltmarsh Games (mobile game studio, about 350 people, per your message)
- **Interviewer:** Tobias Wrenfield, Head of Live Operations
- **Relationship:** assumed hiring manager, because your message did not say. A different relationship would reweight every bank below
- **Round:** 60 minutes, Friday
- **Built from:** the JD text and the background you gave me. No web research is in this pack (see Sources)

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored.

| Type | What it is really testing |
|---|---|
| VAL | Whether past behavior shows good judgment on values-style questions (no published Saltmarsh values were available to this pack) |
| EXP | Whether your own account of your work survives follow-ups, and what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you did your homework on the company and its games |
| CASE | A live problem from the role: structure and reasoning more than the "right" answer |

Provenance labels: `[grounded]` rests on text you gave me; `[inferred]` is this pack's derivation; `[generic]` is a role-family pattern with no claim about you or Saltmarsh.

Guidance is scaffolding, not a script. An **answer slot** is an instruction for the interview: answer it from your own experience, or say plainly that the practice was not yours or did not exist, then return to what you did say. Neither branch is a failure.

## Fit snapshot

Every quote below is your own sentence from your message. The JD lines are quoted from the JD you pasted.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material says one title and weekly content drops; the JD says two titles and live events. That limit is the pack's observation, not words for you. Words: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: the JD's two-title line makes a probe on scale likely, so stay with the main title. If you decided what went into each weekly drop, say how you decided; if that was set for you, or there was no set process, say so plainly and describe how you ran the calendar |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message; "Never led a team, and never worked on a game with in-app purchases." — your message | low | [inferred] | discovery | You stated you have not led a team, so the plain words are "I haven't led a team." The JD's verb is coordinate, not lead, and your material does not show whether drops ran through design, art, engineering or community. Answer slot: the JD names four disciplines, so expect a probe on working with each. If your drops went through any of them, say which and how the work moved between you, in your own words; if none did, or it was not yours to coordinate, say so plainly and stay with the calendar you ran |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | transferability | Your material says presenting the numbers, not owning a review or setting its KPIs. Words: "I presented the monthly retention numbers to the studio head." Answer slot: the JD's own line makes a probe on the numbers likely. If you prepared any of the numbers you presented, say which and how they were counted; if someone else prepared them, or you do not know how they were counted, say so plainly and stay with presenting them |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | none | The quote already reaches the requirement, but nothing has been inspected behind it, so expect a probe. Lead with the checklist in the quote's own terms: "I wrote the release checklist our QA team still uses." Answer slot: the JD's verb is manage. If any item on the checklist was yours to decide, say which and how you decided; if the list was set for you or built from others' input, say so plainly and describe what you wrote |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio" — your message; "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | presentation | The two quotes reach the requirement in other terms. The pack's observation: your title is associate producer, the posting says producer, and your material does not use the phrase live-service, so say weekly content drops rather than the label. Words: "I spent 4 years as an associate producer at a puzzle-game studio, and for the last two years I ran the weekly content-drop calendar for our main title." |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | No gap in the quote's terms, with nothing inspected behind it. Lead with it as written: "I ran the weekly content-drop calendar for our main title for the last two years." A3 rehearses the follow-ups |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | none | The quote reaches the requirement in role-relevant terms. Words: "I presented the monthly retention numbers to the studio head." Whether you prepared the numbers is not shown, so expect a probe on how they were counted; C1 rehearses it |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | low | [inferred] | discovery | A written checklist is a work product, but your material does not say what made it clear or how it was reviewed. Answer slot: if you can point to the checklist itself or another piece of writing others relied on, say which and what it was for; if the checklist is the only such piece, say so plainly and stay with it |
| F9 | Not in the JD you pasted: experience on a game with in-app purchases (an unquoted role-family expectation, listed because you raised it) | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [grounded] | capability | A gap wording cannot close, and you stated it. Words: "I haven't worked on a game with in-app purchases." Then how you would learn it, said as a plan and never as a past. The JD you pasted names retention and KPIs and does not mention purchases. Nothing is added to make the gap feel smaller |

The JD sets no gate: none of its lines is a credential, licence, location, schedule or pay term, and "3+ years" is graded as experience in F5.

## Persona weights

Relationship prior: hiring manager (assumed) puts Case/Strategist and Skeptic first. No interviewer footprint and no loop source for Saltmarsh were available, so there is no adjustment from either, and the loop falls back to a generic archetype with flat tilt. No values-style round was detected.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Case/Strategist | Live problems from the role: a slipping dependency, a two-title calendar, an event review | High. The hiring-manager prior, and the JD's plan, coordinate and review lines are all things that can be posed as problems | Clarify, then objective, approach, metrics, risks, aloud; challenge one premise respectfully. Make no claim about your past that a quote does not carry |
| B. Skeptic | Quiet probing of F9, F2 and the associate-to-producer step | High. The hiring-manager prior, and F9 and F2 are the rows with the least behind them | Say each gap plainly in your own stated words, then give a ramp plan as a plan. B1 is the highest-ROI prep in this pack |
| C. Data-Driven Prober | Line-by-line probing of the retention numbers and the checklist | Medium. The JD names retention metrics and KPIs, and F3, F4 and F7 are single CV-style lines with nothing inspected behind them | Say how things were counted, or plainly that you do not know; name the assumption you would defend least; say what was yours |
| D. Conversational | The opening "walk me through the journey", casual questions about games | Medium. Any 60-minute conversation tends to open with your story; casual questions are still scored | Pre-script the 90-second arc from your own sentences; treat casual questions as scored |
| E. Pressure | Time-boxed "why you" and "how much was you" | Low. No signal in the material either way | Hold your position through two follow-ups, concede specifically, never fold the core |
| V. Values/Behavioral | Scenario prompts about unwelcome truths and player-first choices | Low. No values-style round was detected and no published values were available | Pick a real instance if one exists; if none, say so plainly and give the nearest thing your material carries |
| P. Peer Evaluator | Seam-splitting with design, art, engineering and community | Low. Tobias is assumed to be your manager, but the JD's four-discipline line makes these questions possible from any member of the loop | Offer seam principles rather than pretending to know the seam; reciprocity framing |

## Question banks

### A. Case/Strategist (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A seasonal event is three weeks out and engineering tells you a feature it depends on will slip by a week. Design and art are done. What do you do?" | CASE | [generic] | Clarify first: which feature slipped, what the event's fixed dates are, what can be cut or reordered. Then objective, options (ship reduced, ship later, swap content), who decides, what you tell design, art and community, and what changes on the release checklist. Think aloud. The question needs no claim about your past, so the guidance makes none | A live problem built from the JD's coordination and release-checklist lines (F2, F4); a pattern for the problem, not a fact about Saltmarsh. CASE because structure is what is scored |
| A2 | "How would you plan the next quarter's live-events calendar across our two titles?" | CASE | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Clarify, objective, segmentation, approach, metrics, risks, aloud: what each title needs, which teams both draw on, how the calendar avoids both titles asking for the same capacity in the same week. Where your own experience enters, it is one title, in your words: "I ran the weekly content-drop calendar for our main title for the last two years." Do not stretch it to two titles; say what you would ask about the second | F1 is the JD's headline line and the place scale is probed. CASE for the delivery, JD for the content |
| A3 | "Walk me through how you ran the weekly content-drop calendar for your main title." | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Story-mapped on F1 and F6: the weekly cadence, the content drops, the main title and the two years are the beats the quote states; tell them in your own words. Answer slot: the JD's plan-and-run line makes a probe on how drops were decided likely. If you decided what went into each drop, say how you decided; if that was set for you, or there was no set process, say so plainly and describe how you ran the calendar | F6 and F1 are the evidence for the JD's calendar lines and the likeliest place to be probed. EXP because it tests what was actually yours |
| A4 | "An event has just ended. What goes in the post-event review, and who sees it?" | CASE | [grounded] "Presented the monthly retention numbers to the studio head." | Structure aloud: what the review is for, which measures it reports and why, what the event is compared against, what decision it feeds, who reads it. Pick the measures you would actually choose, and name the assumption behind them you would defend least. Your own history enters at its own scope: "I presented the monthly retention numbers to the studio head." Answer slot: the JD says own the review. If you prepared any of the numbers you presented, say which and how they were counted; if someone else prepared them, say so plainly and stay with presenting | F3 is the weakest-evidenced of the JD's headline lines. JD content, CASE delivery, so the primary tag is the one that scores structure |
| A5 | "What do you make of how our two titles run events today?" | CO | [generic] | Before Friday, play both titles from a player's side and write down one thing you actually saw in each. Say what you saw and what you would ask the team. Do not characterize Saltmarsh's strategy or audience: this pack could not research either. If you cannot get into both, say so plainly and ask which events matter most | CO coverage is generic because no Saltmarsh research was available; the upgrade menu says what would change that |

### B. Skeptic (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You haven't worked on a game with in-app purchases. How would you close that gap in this role?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." "Presented the monthly retention numbers to the studio head." | The highest-ROI rehearsal in this pack: three levels, hold-then-concede. Level 1: say it plainly: "I haven't worked on a game with in-app purchases." Then, as a plan and never as a past, say what you would learn first and who you would ask in the first weeks. Level 2, if pressed on how it affects the calendar or KPIs: stay with what your sentences carry (the weekly calendar, the checklist, the monthly retention numbers presented) and say plainly where purchase-side numbers would be new to you. Level 3, "then why you?": return to those same three sentences in your own words and stop. Claim no purchase, pricing or revenue knowledge of any kind | F9 is the one row where you stated the absence yourself, so the question's premise is yours. The JD's KPI and retention lines (F3, F7) are where it can surface even if purchases are never named, which is why it gets the deepest rehearsal. JD because it scores a gap against the role |
| B2 | "You haven't led a team, and this role coordinates design, art, engineering and community on each update. How would you get four disciplines moving together?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." "I ran the weekly content-drop calendar for our main title for the last two years." | Plain acknowledgment first: "I haven't led a team." The JD asks for coordination, so say what you would do as a plan: who decides what, how everyone sees the same dates, how you raise a conflict early. Answer slot: if your drops went through design, art, engineering or community, say which and how the work moved between you, in your own words; if none did, or it was not yours to coordinate, say so plainly and stay with the calendar you ran | F2 is a discovery row with a stated negative beside it; the probe will aim at the negative. JD because the coordination line is the requirement |
| B3 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Pick the one you can say truthfully. The pack's own reading is that F9, F2 and F3 have the least behind them. If it is purchases: "I haven't worked on a game with in-app purchases." If it is team coordination: "I haven't led a team." Then the ramp plan, as a plan: what you would read, ask or sit in on first. Never present a weak area as covered | Persona stem for the Skeptic; it scores honest self-assessment. JD because the answer is read against the posting |
| B4 | "You've spent four years as an associate producer, and this is a producer role across two titles. What makes you ready for that scope?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio" "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." | Hold on the sentences you gave and say the title plainly: associate producer. Concede that the scope is wider than one title. Answer slot: if any responsibilities within the associate role went beyond those sentences, name them in your own words; if not, say so plainly and do not claim them | F5 is a presentation row: the quotes reach the requirement, and the title difference is the visible seam. JD because it scores fit against the stated level |
| B5 | "Why this role, and why now?" | EXP | [generic] | Give your own reason in one or two sentences, tied to a line of the JD you would genuinely like to do. Nothing here supplies it. If you do not have a settled answer, say so plainly and say what draws you to a two-title live-events calendar | Motivation consistency is the Skeptic's other target. EXP because it tests whether your account holds together. The pack knows nothing about your reasons, so it supplies none |

### C. Data-Driven Prober (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You presented the monthly retention numbers to the studio head. Walk me through how those numbers were counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Defend-the-number slots, each in your own words. How the numbers were counted: say it if you know it, and if you do not, say so plainly. What they are sensitive to. The assumption you would defend least, named before the interviewer names it. Which part was yours: if you prepared them, say so; if you presented numbers someone else prepared, say so plainly | F3 and F7 rest on one line with nothing inspected behind it, which is exactly what a prober tests. EXP because it tests attribution and counting |
| C2 | "When you look at retention around a live event, what would you watch, and what would make you distrust a spike?" | CASE | [generic] | Name the measures you would pick and why, what you would compare against, and the assumption in that comparison you would defend least. Say plainly where a piece is outside what you have done. The question needs no claim about your past, so the guidance makes none | The JD names retention metrics (F7); this tests judgment on them as a live problem. CASE because it asks for reasoning on a situation |
| C3 | "Walk me through the release checklist you wrote." | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Tell the beats the sentence states: you wrote it, and your QA team still uses it. Answer slot: the JD's verb is manage. If any item was yours to decide, say which and how you decided; if the list was set for you or built from others' input, say so plainly and describe what you wrote | F4 is the JD's release line and a CV-style line, so expect it to be read closely. EXP because it tests what was actually yours |

### D. Conversational/Rapport (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio" "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." "Presented the monthly retention numbers to the studio head." | A 90-second arc built only from those four sentences, in the order that sounds natural to you: the four years, the weekly calendar, the checklist, the retention numbers. Close on why this role, in your own words; the pack does not supply that reason. Say associate producer as it is | F5 is the arc's spine. EXP because it tests whether your account is economical and consistent |
| D2 | "What are you playing right now, and what do you think of its events?" | CO | [generic] | Name a game you actually play and say one specific thing, from a player's side, about how it runs events. If you play none, say so plainly and pick one of Saltmarsh's titles instead. Do not invent a favorite | A casual question on the role's native topic; still scored on genuine interest. Generic because it needs no fact about Saltmarsh |
| D3 | "Tell me about something you wrote that other people relied on." | JD | [grounded] "Wrote the release checklist our QA team still uses." | Story-mapped on F8: you wrote it, and your QA team still uses it, which are the beats the sentence states. Answer slot: if you can say how you decided its structure or who reviewed it, do so in your own words; if not, say so plainly and stay with what you wrote | The JD's clear-writing line (F8) is a discovery row, so this is where it gets a concrete answer. JD because it scores the stated requirement |

### E. Pressure (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you, with no in-app purchase experience?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." "Presented the monthly retention numbers to the studio head." | Pause, restate, then hold only what the sentences carry: the weekly calendar, the checklist, the monthly retention numbers presented. Hold through two follow-ups by returning to them, never by adding. Concede specifically: "I haven't worked on a game with in-app purchases." Never claim you are better than other candidates | B1 under time pressure, so the same limit applies. JD because it scores fit against the posting |
| E2 | "That calendar: how much of it was actually you?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Hold the sentence as written through two follow-ups. Then concede precisely, as an answer slot: if inputs came from design, art, engineering or others, say which and what they set; if some of it was set for you, say so plainly. Say it was entirely yours only if it was | F1 attribution under pressure. EXP because the stem scores honest attribution |

### V. Values/Behavioral (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] "Presented the monthly retention numbers to the studio head." | None of your sentences carries this story, so this is a selection scaffold: choose an instance with a named stake, a moment where the number or the plan said something unwelcome, and an intact relationship at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material carries: "I presented the monthly retention numbers to the studio head." Do not supply an ending | Persona stem. Saltmarsh's published values were not available, so this is the generic form. VAL because it scores behavior rather than a stated requirement |
| V2 | "When did you put the player's experience ahead of an internal deadline?" | VAL | [generic] | A selection scaffold: pick a real instance with a named decision, who disagreed, and what was given up. If no such time comes to mind, say so plainly, then say how you would handle it. Do not describe a decision you did not make | Persona stem adapted to a live-ops setting. Generic because it needs no fact about you or Saltmarsh |

### P. Peer Evaluator (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Design wants to add something to an event the week of release, and engineering says it puts the release at risk. Where is the seam, and what happens when you and design disagree?" | CASE | [generic] | Offer seam principles, not a claim to know Saltmarsh's seam: who decides what, risk stated in dates rather than feelings, what goes on the checklist. Show spine and tact together: say what you would hold, and what you would concede. Ask what the team's seam is rather than assuming it | A cross-functional problem from the JD's four-discipline line (F2). CASE because it is a live problem |
| P2 | "How do you handle credit when an update spans design, art, engineering and community?" | VAL | [generic] | A selection scaffold: pick a time credit was shared across teams, with a named contribution of yours and how it was said aloud. Use "we" for context and "I" for what you did. If no such time comes to mind, say so plainly, then say how you would handle it | Collaboration fit, scored on past behavior. The JD names four disciplines (F2); the scaffold stays generic because no quote carries a credit story |

## Requirement coverage

| JD requirement | Covered by |
|---|---|
| "Plan and run the live-events calendar for two of our mobile titles" | A1, A2, A3, E2 |
| "coordinate design, art, engineering and community teams on each update" | A1, B2, P1, P2 |
| "own the post-event review and the KPIs it reports" | A4, C1, C2 |
| "manage the release checklist with QA" | C3, A1 |
| "3+ years producing live-service games or apps" | B4, D1 |
| "experience running a content calendar" | A2, A3 |
| "comfortable with player-retention metrics" | C1, C2 |
| "clear written communication" | D3 |
| Not in the JD: in-app purchases (you stated the gap) | B1, B3, E1 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a good first 90 days look like for this producer across the two titles?" | Gets Tobias to state his own success measure and shows you are planning for the two-title scope the JD names |
| R2 | "Between the two titles, where does the producer's time go on a typical event week?" | Surfaces the real two-title load (F1) without your having to assume it |
| R3 | "How are the post-event review's KPIs set: who decides what it reports, and who reads it?" | Shows you are thinking about ownership of the review (F3) and invites him to say what is expected |
| R4 | "On release day, how do the producer and QA divide the checklist, and who has the final say?" | Opens the F4 conversation on his terms and signals you care about the QA relationship |
| R5 | "How does the team bring someone new to in-app purchase economies up to speed?" | Names your stated gap (F9) as a plan to close rather than a thing to hide, and lets him describe the ramp |
| R6 | "What tends to make someone struggle in this role in the first quarter?" | Shows you want the honest version of the job, and tells you which of the pack's gaps matters most |

## Prohibited claims

What this pack will not coach, and why.

| Not coached | Basis | Honest form |
|---|---|---|
| Ran live events across two titles | Inflated form of F1 | F1's quote at its own scope: one title, weekly content drops. The limit is the pack's observation, not words for you. A2 and A3 stay inside the main title |
| Owned the post-event review and set its KPIs | Inflated form of F3 | F3's quote at its own scope: "I presented the monthly retention numbers to the studio head." A4 and C1's slots stay inside the numbers you presented |
| Led or managed a team | Negative you stated, F2 | The plain acknowledgment: "I haven't led a team." B2 follows it with a plan, not a past |
| Has worked on a game with in-app purchases, or has purchase, pricing or revenue knowledge | Negative you stated, F9 | The plain acknowledgment: "I haven't worked on a game with in-app purchases." B1, B3 and E1 hold at it |
| Managed each release with QA | Inflated form of F4 | F4's quote at its own scope: "I wrote the release checklist our QA team still uses." The limit is the pack's observation: the material says you wrote it, not that you ran each release from it |

## Sources

Provided documents: the JD text you pasted, and the background you gave me (your message). Tobias's name and title, and the studio's size, are also from your message.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

Every search was refused (web search was not permitted in this session), so nothing from any search is used in this pack.

Queries sent, all refused:

- `Saltmarsh Games mobile game studio values` — refused
- `Saltmarsh Games interview process live operations producer` — refused
- `Saltmarsh Games news strategy mobile titles` — refused
- `Tobias Wrenfield Saltmarsh Games Head of Live Operations` — refused

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | unavailable | Would have fed a values cheat sheet and the VAL bank; V1 and V2 are generic scaffolds instead |
| 2. `Saltmarsh Games interview process live operations producer` | unavailable | Would have set the loop and persona weights; they rest on the hiring-manager prior and a generic archetype instead |
| 3. `Saltmarsh Games news strategy mobile titles` | unavailable | Would have grounded the CO questions (A5, D2); both are generic instead |
| 4. `Tobias Wrenfield Saltmarsh Games Head of Live Operations` | unavailable | Would have fed an interviewer read and a reverse question tied to his path; both are absent |
| 5. representative `Live Operations Producer` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Which two titles Saltmarsh runs → A5 and D2 become questions about those specific games, and A2 can name them
- Web search allowed for this session → Saltmarsh's published values, loop structure and strategy, plus Tobias's public professional footprint: a values cheat sheet if a values round shows up, persona weights from real signals, an interviewer read and a reverse question tied to his path
- The relationship to Tobias (hiring manager, skip-level or cross-functional) → persona weights and every bank reweighted
- The recruiter's prep email, or any stated focus areas or deliverable → coverage of what the loop actually scores
- The release checklist itself, an anonymized weekly content calendar, or the monthly retention deck → F4, F6 and F7 can move from medium toward high, and F8 from low
- Your answers to the slots in F1, F2, F3, F4 and F8 → each answer becomes a quoted row of evidence and the cells that draw on it regenerate
- A `tuesday-dossier.md` from an earlier evidence check on this role → verified evidence, a sourced highest-ROI objection and prohibited-claims constraints in place of the ones inferred here
