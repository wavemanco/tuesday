I'll read the reference files the skill points to before writing anything.
I've read the skill's reference files and I'm now running three targeted searches on Northwind Data's values, its interview process and Dan Kovac's public profile. Then I'll build the pack.
Searches were refused, so I'll build the pack from the material you gave me and mark each research target as unavailable. Writing the pack file now.
The mock-interview pack is saved as `northwind-data_senior-gtm-strategy-lead-emerging-products_interview_pack.md` in the working directory. It has 21 questions across seven personas, plus six reverse questions for Dan.

I built it for a single 60-minute round with Dan as a peer, using your summaries rather than the full JD and CV text. My web searches on Northwind's values, its interview process and Dan's public profile were all refused. So the pack has no values cheat sheet, and the persona weights rest on the peer relationship and what you told me about Dan. The Sources section lists each unsearched target.

The one prep item the pack names as highest-ROI is D1, where Dan raises Priya's missing sales-ops and quota-setting experience. It comes back as G2 under a 60-second clock. The pack coaches a plain acknowledgment, a concession, and a plan instead of a claim. It never stretches her volume-target work to cover quota-setting.

The pack also lists six claims it won't coach, such as describing herself as having designed a partner motion or driven the ~$400M uplift.

Say the word and I'll play the Skeptic on D1, the question the pack names as its highest-ROI prep.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: northwind-data_senior-gtm-strategy-lead-emerging-products_interview_pack.md -----
# Interview pack: Senior GTM Strategy Lead, Emerging Products at Northwind Data

- Candidate: Priya
- Interviewer: Dan Kovac, Director of Sales Strategy, a peer (both report to the same VP)
- Format: one 60-minute conversation
- Built from: the coach's notes (JD highlights, a summary of Priya's background, a description of Dan's profile, a research note on Northwind's priorities)

## How to use this pack

- Personas describe how a question arrives. Types describe what it is scored on. Every question carries one of each.
- Guidance is scaffolding, not a script. Say everything in your own words.
- The quoted sentences in each Provenance cell are the only statements about your past the guidance stands behind. Lines marked "Answer slot" are instructions for the interview: answer either branch truthfully, from your own experience.
- Highest-ROI prep in this pack: D1, the sales-ops and quota-setting objection. It will be asked in some form by a Director of Sales Strategy, and a rehearsed, non-defensive answer changes the conversation. Rehearse it until it is boring, then G2, which asks it again under a clock.

| Type | Name | What it is scoring |
|---|---|---|
| VAL | Behavioral / values alignment | Whether past behavior shows the values being probed |
| EXP | Work-experience deep-dive | Whether claims survive scrutiny; what was actually yours |
| JD | Role / JD-driven | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge | Homework depth and thinking at the company's altitude |
| CASE | Hypothetical / live problem | Structure and reasoning on a problem from the role |

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" — JD highlights, the coach's message | "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" — the coach's notes | low | [inferred] | discovery | The quote names the function and the employer, not a launch or a product line, so no words for a launch are offered. Answer slot: the JD's own-GTM line makes a probe on new-product work likely. If any of your work was bringing a new product or line to market, say what it was and which part was yours, in your own words; if there was none, or it was not yours, say so plainly and stay with the strategy and ops work the quote names |
| F2 | "identify whitespace across land/adopt/expand/renew" — JD highlights, the coach's message | "proposed a store-surface change credited with a ~$400M ARR uplift" — the coach's notes | medium | [inferred] | transferability | Adjacent, not the same: one proposed change credited with an uplift, set beside a search for whitespace across four stages. Words stay at the quote: "I proposed a store-surface change that was credited with a ~$400M ARR uplift." Answer slot: the JD's four stages make a probe on which stage that change touched likely. If it maps to one of them, say which, in your own words; if it does not map to any, say so plainly and stay with the change you proposed |
| F3 | "run independent analysis in SQL and Tableau" — JD highlights, the coach's message | "skilled in SQL/Tableau" — the coach's notes | medium | [inferred] | discovery | The quote names the tools and does not show who ran which analysis. Answer slot: the JD's independent-analysis line makes a probe on one analysis end to end likely. If you ran one yourself, name the question, the data and which steps were yours; if others ran parts, or none was end to end, say so plainly and stay with "skilled in SQL/Tableau" |
| F4 | "partner-motion design experience required" — JD highlights, the coach's message | "built a partner-level revenue model used in carrier negotiations" — the coach's notes | medium | [inferred] | transferability | Adjacent: the quote says a revenue model used in negotiations, and the pack does not close the distance to the JD's line. Words: "I built a partner-level revenue model that was used in carrier negotiations." Answer slot: the JD marks this requirement as required, so expect the probe. If any of your work shaped how the partnership itself was set up, say which decision and what part was yours; if the model informed the negotiations without shaping that, or it was set elsewhere, say so plainly and stay with the model |
| F5 | "strong cross-functional influence" — JD highlights, the coach's message | "set annual volume targets with cross-org consensus" — the coach's notes | medium | [grounded] | presentation | The quote already speaks to agreement across orgs. Say it in its own terms: you set annual volume targets, with consensus across orgs. The JD says cross-functional and the quote says cross-org, so keep the quote's word. Expect a probe on how the consensus was reached; the answer slot is in B2 |
| F6 | "AI experience a plus" — JD highlights, the coach's message | "uses AI tools daily" — the coach's notes | medium | [grounded] | none | The quote reaches the plus at its own scope: you use AI tools daily. It does not say you build or ship AI. Say it as it stands; expect which tools and for what, with the slot in E2 |
| F7 | Sales-ops and quota-setting fluency; not in the JD highlights, added because the interviewer's own function sits there | "No classic sales-ops or quota-setting experience." — the coach's notes | none | [grounded] | capability | A gap wording cannot close, and the coach stated it. Words: "I don't have classic sales-ops or quota-setting experience." Then how you would learn it, said as a plan and never as a past. Never a claim to that work, and nothing added to make the gap feel smaller |

## Reading the interviewer

Built from the coach's description of Dan's profile only. His public talks and writing were not checked (the search was refused; see Sources).

| Signal | Source | What it means for the conversation | Provenance |
|---|---|---|---|
| Self-described "relentlessly data-driven" | The coach's notes on his profile | Expect every number you give to be walked to its assumptions. Know how each figure was counted and say plainly what you do not know. Drives A1 to A3 and G1 | [inferred] |
| Career spine of "pricing and monetization roles" | The coach's notes on his profile | His native ground is packaging, pricing and unit economics, so case questions tilt that way (C2). Use revenue and monetization vocabulary only where your quotes use it; do not import "pricing" into your own history | [inferred] |
| "one early-stage-startup chapter" | The coach's notes on his profile | Expect questions about moving without an established playbook, which fits two new product lines. Describe only what you did. RQ2 asks him about it | [inferred] |
| Peer, "both reporting to the same VP" | The coach's notes | He is pricing what your arrival does to his load and his seam. Lead with what you bring his team, then what you need from him (B1, B4, RQ3) | [inferred] |
| Mirror opportunity: shared vocabulary of revenue and monetization | His spine, paired with F4's evidence: "built a partner-level revenue model used in carrier negotiations" | The one place your vocabulary overlaps his. It is a revenue model, not stated to be pricing work; keep it at that scope. No shared career jump is offered, because no row's evidence carries one | [inferred] |

## Persona table

Weights come from three passes. Relationship prior: a peer round puts the Peer Evaluator and the Data-Driven Prober first. Interviewer signals: "relentlessly data-driven" raises the Prober, the pricing spine tilts the case bank toward packaging, and the startup chapter adds a light scrappiness probe under the Skeptic. The loop: no loop source established it, so the Generic archetype applies, with no loop-based tilt, and no values-style round is detected. The weights rest on a pattern, not on Northwind's documented process.

| Bank | Persona | How it shows up with Dan | Likelihood and reasoning | Counter-strategy | Questions |
|---|---|---|---|---|---|
| A | Data-Driven Prober | Reads your lines one by one; asks for inputs, derivations and who did what | High. Peer prior plus his self-description raise it to the top | Know how each number was counted; say plainly what you do not know; name the assumption you would defend least before he does | 5 |
| B | Peer Evaluator | Seam-splitting, "what do you need from me", credit across teams | High. The relationship prior; he reports to the same VP | Reciprocity first: what you bring his team, then what you need. Propose seam principles instead of pretending to know the seam | 4 |
| C | Case / Strategist | Live problems on whitespace, packaging and the bundling threat | Medium. Pricing spine and a role that owns two new lines | Clarify, then objective, segments, approach, metrics, risks; think aloud; challenge one premise respectfully | 3 |
| D | Skeptic | Quiet probing of the sales-ops gap, the partner-motion line and the move from consumer tech | Medium. A stated gap in his own function plus a required JD line | Rehearse D1 until it is boring; acknowledge the gap plainly, then give a plan, never a past | 3 |
| E | Conversational / Rapport | The biography opener and a casual AI question | Medium-low. A 60-minute conversation usually opens this way, and casual questions are still scored | A 90-second arc built only from your quoted sentences; treat the AI question as scored | 2 |
| G | Pressure / Stress | A time-boxed challenge on attribution and on why you | Low-medium. A peer is less likely to run it, but the gap and the headline figure invite it | Pause, restate, anchor in the quote, hold through two follow-ups, concede only what is true | 2 |
| H | Values / Behavioral | Behavioral prompts in a collegial register | Low. No values-style round is detected and no published values were in hand | Use the selection scaffold; if nothing comes to mind, say so and give the nearest thing your material carries | 2 |

## Question banks

### A. Data-Driven Prober (weight: high, 5 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how the ~$400M ARR uplift was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Defend-the-number, in your own words. The quote states two things: you proposed the change, and it was credited with the uplift. Keep both halves. Answer slot, how it was counted: say how the figure was reached and who credited it; if you do not know how it was counted, say so plainly. Answer slot, sensitivity: say what the figure is most sensitive to, if you know; if you do not, say so. Answer slot, weakest assumption: name the assumption behind it you would defend least, before he asks; if you cannot name one, say so plainly. Answer slot, your part: say which part was yours; if others built or measured it, say so and return to "I proposed it" | F2 holds the one headline figure in the material, and Dan describes himself as data-driven, so it will be walked to its assumptions. EXP because it tests whether the claim survives scrutiny and whether the attribution is exact |
| A2 | "Walk me through the partner-level revenue model you built." | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" | Tell it in the beats the quote states: you built it, it worked at partner level, and it was used in carrier negotiations. Answer slot: the JD's independent-analysis line and Dan's profile make a probe on what went into the model and how you checked it likely. If you checked it, say how; if there was no check, or it was not yours, say so plainly and return to the model you built | F4 is the only evidence for the partner requirement and the thing a data-driven peer will open first. EXP because it tests what was actually yours; the question is premised only on the quote |
| A3 | "How did you get to those annual volume targets, and how did you know they were reasonable?" | EXP | [grounded] "set annual volume targets with cross-org consensus" | Anchor on the quote: you set annual volume targets, with consensus across orgs. Use the quote's term, "volume targets". Answer slot: Dan's profile makes a probe on how the numbers were derived likely. If you derived them, say from what and how you tested them, in your own words; if the numbers came from elsewhere, or nothing tested them, say so plainly and return to the consensus the quote states | F5's quote is a claim about numbers, and numbers get probed to their derivation. EXP because it tests the derivation; the Prober scores whether you know your own inputs |
| A4 | "Tell me about an analysis you ran end to end. What was the question, and where did the data live?" | JD | [grounded] "skilled in SQL/Tableau" | An open prompt: choose one from your own work; the pack supplies none. Selection criteria: one where you built the steps yourself and can name the question, the source and the result. Answer slot: if some steps were run by others, say which were yours and which were not; if no analysis was run end to end by you, say so plainly, then say what you have done in SQL and Tableau at a scale you can stand behind. The quote supports only that you are skilled in both | F3 is the JD's independent-analysis requirement, so JD is the primary tag. The Prober asks for the detail because "independent" is only proven by detail |
| A5 | "Two dashboards give different numbers for the same pipeline metric. How do you decide which one to trust?" | CASE | [generic] | Structure it aloud: clarify the metric definition, filters, time windows and refresh timing; reconcile at row level in SQL; name the cause; decide which source is canonical and document it; say who needs to be told. The question needs no claim about your past, so the guidance makes none | A live problem in the data-driven register that tests the F3 requirement without a past claim. CASE because it is delivered live; [generic] because it is a pattern for the problem, not a fact about Northwind |

### B. Peer Evaluator (weight: high, 4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our teams sit side by side. Where do you think the seam is, and what happens when we disagree?" | JD | [generic] | Propose seam principles instead of pretending to know the seam: ask what each team owns today, agree who decides what, and where a decision is shared, agree how it is settled and when it goes to the VP you both report to. Ask him to describe the seam as he sees it. The answer needs no claim about your past | The persona's own seam stem. JD because it scores the influence requirement in F5; Peer because the probe is about turf and disagreement style with an equal |
| B2 | "Tell me about a time you had to get several organizations to agree on a number." | EXP | [grounded] "set annual volume targets with cross-org consensus" | Story-mapped on the quote's beats only: you set annual volume targets, and the consensus was across orgs. Tell it in your own words. Answer slot: the JD's influence line makes a probe on where the orgs disagreed likely. If they did, say who held what position and what part of the resolution was yours; if consensus came without disagreement, or others brokered it, say so plainly and stay with the quote | F5 is the only evidence for the influence requirement. EXP because it tests attribution; Peer because a peer asks it collegially, as "what did you actually do" |
| B3 | "How do you handle credit when work spans teams?" | JD | [generic] | Say the principle: name contributors specifically, say what each did, and keep your own claim to your own part. If you add an example, take it from your own work and keep its attribution exactly as it was. The answer needs no claim about your past | The persona's credit stem; F2's "credited" wording is where this probe is most likely to bite. JD because it scores cross-functional working |
| B4 | "What would you need from me in your first thirty days, and what would you bring my team?" | JD | [grounded] "No classic sales-ops or quota-setting experience." "built a partner-level revenue model used in carrier negotiations" "set annual volume targets with cross-org consensus" "skilled in SQL/Tableau" | Reciprocity: say what you bring first, then what you would ask of him. What you bring: name only your quoted sentences, each in its own words and at its own scope. What you ask: open the ask with the acknowledgment, "I don't have classic sales-ops or quota-setting experience." Then say what you would want to learn first and from whom; that is your plan, in your own words, not a past | F7's gap returns here in collegial packaging, with F3, F4 and F5 supplying what you bring. JD because it scores partnership fit against the role; Peer because it asks whether the hire reduces or adds to his load |

### C. Case / Strategist (weight: medium, 3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You inherit an installed base and a new product line. Where would you look first for whitespace across land, adopt, expand and renew, and what would you pull?" | CASE | [grounded] | Clarify first: what the product is, what counts as each stage, what data exists. Then objective, segmentation by stage and account type, how you would size and rank gaps, which SQL cuts and Tableau views you would build, the metrics, and the risks. Say your hypothesis early and challenge one premise respectfully. No claim about your past | Built from the JD's whitespace line, the requirement in F2. CASE because it is a live problem; the persona scores structure over the "right" answer |
| C2 | "A much larger platform vendor starts bundling a competing capability, and Compass is launching. How do you think about charging for it, bundling it, or holding it for expansion plays?" | CASE | [grounded] your research note: "bundling by a much larger platform vendor" and "an AI copilot launch ('Compass')" | Clarify first: who buys, what the alternative costs them, what the bundler's offer includes, what Compass costs to serve. Then the options (standalone, included in a tier, held for expansion), the evidence that would pick between them, the risks, and the metric. State a hypothesis and what would change your mind. Pricing is Dan's native ground, so say the trade-off aloud and invite his view. No claim about your past | The research note's competitive threat and launch, framed in packaging terms because of his pricing spine. CASE because it is live; it is also the pack's strategy-grounded item. The note is the coach's and was not checked against a published source |
| C3 | "Northwind's stated priorities are enterprise expansion, the Compass launch and reaching profitability. Which one should GTM for the new lines protect first, and what does that cost the others?" | CO | [grounded] your research note: "enterprise expansion, an AI copilot launch ('Compass'), and reaching profitability" | Take a position and defend it; do not recite the three. Name what you would give up on the other two, and what you would need to know to change your mind. No claim about your past | Tests whether you think at the company's altitude, using the priorities from the research note. CO because it scores strategy fluency; the divergence-with-reasons is what separates it from a recital |

### D. Skeptic (weight: medium, 3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "I don't see classic sales-ops or quota-setting in your background. Where do you think that will show up in this job?" | JD | [grounded] "No classic sales-ops or quota-setting experience." "set annual volume targets with cross-org consensus" | The highest-ROI rehearsal in this pack. Open by acknowledging, without defending: "I don't have classic sales-ops or quota-setting experience." Then the other quote at its own scope: "I set annual volume targets with cross-org consensus." Do not fuse the two. Answer slot, where it shows up: say in your own words where you expect the gap to cost you in this job; if you do not know yet, say so plainly and say what you would ask him. Plan: say what you would learn first, from whom and in what order; the plan is yours to set, and no step is presented as done. Follow-up 1, the interviewer says you would be learning in a peer seat: concede exactly, "Yes, on that piece I would be learning, and here is how I would close it," then the plan. Follow-up 2, he presses on the boundary: return to the acknowledgment, then the quote's own words, and widen nothing. Follow-up 3, he asks what you need from him: hand over to B4. Limit, named before he asks: your material shows no sales-ops or quota-setting work, so do not stretch the volume-target work to cover it, and do not describe the gap as small | F7 is the stated gap and sits in Dan's own function, so it is the single most predictable objection. JD because it probes a competency adjacent to the listed role; Skeptic because the probing is quiet and persistent. It gets the most follow-up levels and the exact concession wording |
| D2 | "The JD calls partner-motion design required. What part of designing a partner motion have you done yourself?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | Hold only what the quote carries: "I built a partner-level revenue model that was used in carrier negotiations." Observation: your material says a revenue model used in negotiations, not the motion. Answer slot: if any of your work shaped how the partnership itself was set up, say which decision and what part was yours; if the model informed the negotiations without shaping that, or it was set elsewhere, say so plainly and stay with the model | F4 is the required line the material is thinnest on. JD because it scores the stated requirement; Skeptic because the question asks you to draw your own limit |
| D3 | "You've spent nine years in consumer tech, and this is enterprise B2B data infrastructure. What makes you think the motion carries over, and why now?" | JD | [grounded] "9 at a large consumer-tech company in product strategy & ops" "built a partner-level revenue model used in carrier negotiations" | Two parts. Carry-over: state the first quote at its own scope. Observation: the carrier-negotiation line is the nearest your material comes to a business counterparty. Answer slot: if any of your work faced business customers or partners rather than consumers, say what, in your own words; if none did, say so plainly and say what you would learn first. Why now: give your own reason. No reason was in the material the pack was given, so it writes none; if you have no settled reason yet, say so and say what draws you to this role | F1 and the background mismatch. JD because it tests fit against the listed role; Skeptic because "why here, why now" is the motivation-consistency probe from the persona's stems |

### E. Conversational / Rapport Builder (weight: medium-low, 2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" "built a partner-level revenue model used in carrier negotiations" "set annual volume targets with cross-org consensus" "proposed a store-surface change credited with a ~$400M ARR uplift" | A 90-second arc in four beats, each a clause the quotes state. Beat 1: "2 years strategy consulting at a top firm". Beat 2: the 9 years in product strategy and ops at a large consumer-tech company. Beat 3: choose one of the three quoted sentences and say it in its own words, at its own scope; the revenue-model sentence is the closest to the JD's partner line, an observation, not a claim. Beat 4: why this role. Answer slot: give your own reason; if you have no settled reason yet, say so plainly | The biography opener in a peer conversation. EXP because it is the CV's spine; Conversational because it feels casual and is scored for economy. Draws on F1 |
| E2 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" | Say it at the quote's scope: you use AI tools daily. Answer slot: the JD's plus makes a probe on which tools and for what likely. Name the tools and what you use them for, from your own use; if your use is general-purpose and not on product work, say so plainly. Do not claim building or shipping AI | F6 is a plus, asked casually. JD because it scores the stated plus; Conversational because the persona's stem is exactly this casual JD-plus probe, and casual questions are still scored |

### G. Pressure / Stress (weight: low-medium, 2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "That ~$400M. How much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Pause, restate the question, and anchor in the quote: "I proposed the change, and it was credited with a ~$400M ARR uplift." Hold that through two follow-ups. If he says you only proposed it, stay with "proposed" and "credited". If he asks who credited it, answer slot: say who credited it and how, if you know; if you do not, say so plainly. Concede specifically and only what is true: say which parts others did, if any, in your own words. Never fold on the core claim to restore harmony, and never widen it | The persona's attribution stem applied to F2. EXP because it tests exact attribution; Pressure because it tests whether you hold a position without getting defensive |
| G2 | "Sixty seconds: why you, rather than someone with a sales-ops background?" | JD | [grounded] "No classic sales-ops or quota-setting experience." "built a partner-level revenue model used in carrier negotiations" "set annual volume targets with cross-org consensus" "skilled in SQL/Tableau" | Pause and restate the question in one line. Concede first: "I don't have classic sales-ops or quota-setting experience." Then say three of your quoted sentences in their own words, and stop; let him draw the inference. If he interrupts, hold through a second follow-up by returning to the quotes, and add nothing | D1 under a clock, built from F7 with F3, F4 and F5 as the content. JD because it scores fit for the listed role; Pressure because of the time box and the "why you over" stem |

### H. Values / Behavioral (weight: low, 2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold, because no quoted sentence carries this story. Pick a time with a named stake, a moment you did not soften the message, and a relationship intact afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The persona's own stem. VAL because it scores behavior; low weight because no values-style round is detected, and no published values were in hand to map it to |
| H2 | "Tell me about a time the data changed your mind about a recommendation you had already formed." | VAL | [generic] | Selection scaffold. Pick a recommendation you held, the data that disagreed, and what you did, whether you changed it or defended it. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Its theme comes from Dan's own self-description as data-driven. VAL because it scores behavior rather than skill; it is the collegial version of a Prober question |

### Requirement coverage

| Requirement | Questions |
|---|---|
| own GTM strategy for two new product lines | C1, C2, C3, D3, E1 |
| identify whitespace across land/adopt/expand/renew | C1, A1 |
| run independent analysis in SQL and Tableau | A4, A5 |
| partner-motion design experience required | A2, D2, B4 |
| strong cross-functional influence | B1, B2, B3, A3 |
| AI experience a plus | E2 |
| Sales-ops and quota-setting fluency (F7, not in the highlights) | D1, B4, G2 |

## Reverse questions

| # | Question to ask Dan | Why it lands |
|---|---|---|
| RQ1 | "Your background runs through pricing and monetization. What from that do you lean on most in sales strategy at Northwind, and how would you want a GTM peer to think alongside it?" | Ties to his own path, so it reads as research on him rather than on the company, and it hands him his native vocabulary |
| RQ2 | "You had an early-stage startup chapter. What from it do you still bring to a company at Northwind's scale?" | A second path-based question that turns the interview into a peer conversation about moving without a playbook, which fits two new lines |
| RQ3 | "What could a new peer do in their first month that would genuinely help your team?" | The reciprocity question for a peer: it shows you are pricing your impact on his load, not just your own onboarding |
| RQ4 | "Where do your team and this role's work most often collide, and how would you two want to settle it?" | Puts the seam on the table on your terms, and surfaces his preferences before a disagreement exists |
| RQ5 | "What is the one number you would want this role to move in its first year, and how would you check it?" | Speaks to a data-driven interviewer in his own register and shows you think in measures |
| RQ6 | "How does the bundling threat show up in the deals you see, and what is working against it so far?" | Draws on the research note's competitive threat and asks for his firsthand view, which is more useful than reciting the threat |

## Prohibited claims

Claims this pack will not coach, built from the fit snapshot and written before the question banks.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned GTM strategy for a new product line, or launched a product | Inflated form of F1 | F1's quote at its own scope: "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops". The limit is the pack's observation, not words for you: the material names the function and the employer, not a launch |
| Designed or led a partner motion, or led the carrier negotiations | Inflated form of F4 | F4's quote at its own scope: "built a partner-level revenue model used in carrier negotiations". The limit is the pack's observation: the material says a model used in negotiations, not the motion or who led them |
| Drove or delivered the ARR uplift | Inflated form of F2 | F2's quote at its own scope: "proposed a store-surface change credited with a ~$400M ARR uplift". The limit is the pack's observation: the quote says proposed and credited |
| Has quota-setting or sales-ops experience | Negative the candidate stated, F7 | The plain acknowledgment F7 gives: "I don't have classic sales-ops or quota-setting experience." No slot |
| The annual volume targets amount to quota-setting | A claim F7's quote contradicts | "No classic sales-ops or quota-setting experience." |
| Has built or shipped AI products | Inflated form of F6 | F6's quote at its own scope: "uses AI tools daily". The limit is the pack's observation: the quote says use, not building |

## Sources

Provided documents: the coach's message, which holds the JD highlights, a summary of Priya's background, a description of Dan's profile, and a research note on Northwind's priorities and competitive threat. None of it was checked against a published source.

Searches sent, each refused by the host and returning nothing:

- "Northwind Data company values principles" — refused
- "Northwind Data interview process strategy role" — refused
- "Dan Kovac Northwind Data Director Sales Strategy" — refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Northwind Data values` | unavailable | Every call was refused. It would have fed a values cheat sheet and mapped stories; neither is in this pack |
| 2. `Northwind Data interview process {role family}` | unavailable | Every call was refused. It would have named Northwind's actual loop; persona weights instead rest on the peer-relationship prior and the Generic archetype |
| 3. `Northwind Data strategy` and recent news | skipped | The research note in hand supplies the three priorities and the bundling threat, which fixes C2, C3 and RQ6 |
| 4. `Dan Kovac Northwind Data` | unavailable | Every call was refused. The interviewer read rests on the coach's description only; his talks and writing were not checked |
| 5. representative `Senior GTM Strategy Lead` JD | skipped | The JD highlights supplied fix the fit snapshot and the JD-tagged questions, though they are highlights, not the full text |

## Upgrade menu

- Full JD text: requirement cells in F1 to F6 become exact JD lines, and any mid-list requirement the highlights left out gets its own row and question
- Priya's actual CV text: the evidence column currently holds the coach's summary lines; her own sentences could upgrade F1, F2, F3 and F4 and make the answer slots in A1 to A4, D2 and D3 more specific
- Her own answers to the answer slots in A1 to A4, D1 and D2, stated outside a drill: each one enters the fit snapshot as quoted material and regenerates the rows it draws on
- An inspectable artifact per claim: the document behind the ARR credit (F2), the revenue model or a negotiation summary (F4) and a dashboard or query she wrote (F3) would each raise a medium band toward high
- Dan's profile text or a link to read, or search access: a sharper interviewer read, with real themes from his talks and writing in place of the coach's summary, and more tailored reverse questions
- Northwind's published values and loop structure, pasted or from a recruiter email: a values cheat sheet if a values-style round is documented, and persona weights keyed to the real loop
- Recruiter guidance on focus areas or any pre-declared deliverable: a build section for each announced deliverable, and coverage that no longer rests on round-type priors
- Prep time available: a prioritized prep triage sized to the days left
- A deeper research pass (L2), once searches are permitted: up to 6 more searches and 2 more fetches, several more minutes, adding a strategy brief, Dan's talks and writing, loop reports for this role and recent org context. Say so and I'll run it
- A tuesday-dossier.md from an earlier evidence check would add verified claims, ranked objections and prohibited claims; this pack stands without it
