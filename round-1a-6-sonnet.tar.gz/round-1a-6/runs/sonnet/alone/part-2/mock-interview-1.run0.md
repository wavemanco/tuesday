I'll read the reference files the skill requires before writing anything.
Both searches were refused, so I'll build from the material you gave me and record that in Sources. I'm writing the pack now.
Your prep pack is saved as `/var/tmp/tuesday-measure/1a6/runs/sonnet/alone/part-2/rooms/case-1-denied-693b826f/northwind-data_senior-gtm-strategy-lead_interview_pack.md`. It has 21 questions across seven personas, weighted for a single 60-minute peer conversation with a data-driven Dan, with the strongest weight on the Data-Driven Prober.

I built it from your summary only. Both of my research searches (Northwind's values and Dan's public footprint) were refused, so the interviewer read rests on your description of him. The pack has no values cheat sheet, and every quote about Priya comes from your notes, not her CV.

Say the word and I'll play Dan as the Skeptic on C1, the pack's highest-ROI question: "I don't see classic sales-ops or quota-setting in your background."
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Did the recruiter give any focus areas or announce a deliverable such as a presentation or take-home? That would reweight the banks and could add a build section.
Can you paste the full JD text and Priya's CV lines word for word? That would turn the evidence cells from your paraphrases into her own sentences.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: northwind-data_senior-gtm-strategy-lead_interview_pack.md -----
# Mock-interview pack: Senior GTM Strategy Lead, Emerging Products at Northwind Data

**Candidate:** Priya
**Interviewer:** Dan Kovac, Director of Sales Strategy at Northwind Data. He would be Priya's peer, both reporting to the same VP.
**Round:** one 60-minute conversation with Dan, per the coach's account.
**Built on:** the coach's summary of the JD highlights, of Priya's background and of Dan's profile, plus the coach's research note. No full JD and no CV text were supplied, so every quote about Priya below comes from the coach's notes. The upgrade menu says what the full documents would change.

## How to use this pack

Personas describe how a question is asked. Types describe what it is scoring. Guidance is scaffolding for a spoken answer, not a script: say it in your own words, and say only what you actually did.

An answer slot is an instruction for the interview. It marks a place where the material says nothing, so the answer has to come from Priya's real experience. It always has two honest branches: what you did and how, or that the step did not exist or was not yours. Either branch is a good answer. Inventing a third is the failure.

| Tag | Name | What it is really testing |
|---|---|---|
| VAL | Behavioral / values alignment | Whether past behavior shows what the company publishes as its values. No published Northwind values were retrieved, so VAL rows here are behavioral only |
| EXP | Work-experience deep-dive | Whether the background survives scrutiny, and what was actually Priya's |
| JD | Role / JD-driven | Whether she can do the listed job, gaps included |
| CO | Company and strategy knowledge | Whether she can think at Northwind's altitude |
| CASE | Hypothetical / live problem | Structure and reasoning on a problem from the actual role |

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" — JD highlights | "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" — the coach's notes; "proposed a store-surface change credited with a ~$400M ARR uplift" — the coach's notes | medium | [grounded] | transferability | The material says product strategy and ops, not go-to-market, and the words stay there: "I spent nine years in product strategy and ops at a large consumer-tech company." The figure keeps its own verbs: she proposed the change, and the uplift was credited to it. Answer slot: the JD's own-GTM line makes a probe on whether any of that work was go-to-market likely. If any of it was, say which and what part was yours, in your own words; if none was, say so plainly and stay with product strategy and ops. The figure also raises four slots: how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. Fill each in your own words, or say you do not know |
| F2 | "identify whitespace across land/adopt/expand/renew" — JD highlights | none given | none | [grounded] | discovery | The material shows nothing here either way. Answer slot: the JD names these four stages, so expect a probe on which of them your analysis has touched. If any of your work looked at how customers or partners moved through stages like these, say what and how, in your own words; if none did, say so plainly, then say how you would start on Northwind's data, as a plan and never as a past |
| F3 | "run independent analysis in SQL and Tableau" — JD highlights | "skilled in SQL/Tableau" — the coach's notes | medium | [grounded] | none | The tools are named in the quote's own terms, but it is one line with nothing inspected behind it, and Dan describes himself as relentlessly data-driven, so expect a probe. Lead with the quote's terms: skilled in SQL and Tableau. Answer slot: the JD says independent. If any analysis was yours from start to finish, say which; if others pulled the data or built the views, say so plainly and stay with the skill |
| F4 | "partner-motion design experience required" — JD highlights | "built a partner-level revenue model used in carrier negotiations" — the coach's notes | medium | [grounded] | transferability | The material says a revenue model, not a partner motion, and the words stay there: "I built a partner-level revenue model that was used in carrier negotiations." Answer slot: the JD marks this requirement as required, so expect a probe on whether you shaped how a partner program works, beyond its economics. If any part of that was yours, say which; if none was, say so plainly and stay with the model |
| F5 | "strong cross-functional influence" — JD highlights | "set annual volume targets with cross-org consensus" — the coach's notes | medium | [grounded] | presentation | The quote already reaches the requirement in other terms, so lead with it as it stands: "I set annual volume targets with cross-org consensus." Add nothing about how the consensus was reached. Answer slot: if asked what you did to get there, say what you did in your own words; if the consensus came without steps of yours, say so plainly |
| F6 | "AI experience a plus" — JD highlights | "uses AI tools daily" — the coach's notes | medium | [grounded] | none | The quote reaches the plus in its own terms: daily use of AI tools. It says use, not building. Answer slot: if asked what you use them for, say which tools and which tasks, in your own words; if your use is for other kinds of work than the interviewer assumes, say so plainly |
| F7 | Fluency in sales-ops and quota-setting, the peer's home territory and not stated in the JD highlights | "No classic sales-ops or quota-setting experience." — the coach's notes | none | [grounded] | capability | A gap the coach stated, so the pack may give the words back: "I haven't had classic sales-ops or quota-setting experience." Then how you would learn it, said as a plan and never as a past. Nothing is added to make the gap feel smaller. F5's quote stays at its own scope: volume targets, not quotas |

## Reading the interviewer

Public footprint research was refused in this run, so this section uses only what the coach reported about Dan.

| What is known | Source | What it means for the conversation |
|---|---|---|
| Self-describes as "relentlessly data-driven" | The coach's description of his profile | Every number and tool claim gets probed to its assumptions. Lead with how things were counted, and say plainly when you do not know |
| "pricing and monetization roles, with one early-stage-startup chapter" | The coach's description of his profile | His native language is packaging, pricing and unit economics, so pricing and packaging angles in case answers land. The startup chapter makes builder stories land and makes pace and scrappiness probes plausible for someone from a large company |
| Director of Sales Strategy, peer, same VP | The coach's account | He is pricing what the hire costs and contributes to his own work. Expect seam questions, credit questions and a check on whether you add to or lighten his load |
| Whether he owns quota-setting at Northwind | Not established by anything supplied | Do not assume it, in either direction. F7 is his likeliest probe either way, because quota-setting sits next to his function |
| Mirror opportunity | His spine is pricing and monetization; F4's quote is a revenue model | This is shared vocabulary around revenue, not a shared career path. Use revenue language where it is accurate to F4's quote, and do not call the work pricing or monetization |

## Persona table

Weights come from three passes: the peer-relationship prior, then Dan's signals, then the loop. The loop is one 60-minute conversation with a peer, per the coach's words. No values-style round is documented, so the values cheat sheet is dropped and the Values bank sits at low weight. Change a weight if you know something the pack does not.

| Persona | Weight | How it shows up with Dan | Reasoning | Counter-strategy (a rehearsal method, not a claim) |
|---|---|---|---|---|
| A. Data-Driven Prober | 5 questions | Line-by-line on the figure, the model, the tools | Peer prior, raised by his self-description as relentlessly data-driven | Know what you can and cannot say about how each number was counted. Name the weakest assumption before he does, and say plainly when you do not know |
| B. Peer Evaluator | 4 questions | Seam between Sales Strategy and Emerging Products, credit, what you need from him | Peer prior; he is a direct colleague in the same reporting line | Reciprocity framing. Propose seam principles instead of pretending to know the seam |
| C. Skeptic | 3 questions | The sales-ops and quota gap, partner-motion design, GTM versus product strategy | The coach named F7; the JD marks partner-motion design as required | Rehearse the single most predictable objection until it is boring. Bridges come only from what you actually said, with the limit named first |
| D. Case / Strategist | 3 questions | Live problems on bundling, lifecycle whitespace, priorities | Raised by his pricing and monetization spine and by the research note's priorities and threat | Clarify, state an objective, segment, approach, metrics, risks. Think aloud and state your hypothesis early |
| E. Conversational | 2 questions | The journey question, then what you are playing with in AI | Every conversation opens this way, and the JD flags AI as a plus | A 90-second arc built from your own sentences. Treat casual questions as scored |
| F. Values / Behavioral | 2 questions | Behavioral prompts without a published-values frame | No values-style round documented, and no published Northwind values in hand | Pick a story where the hard truth actually landed. Where none comes to mind, say so |
| G. Pressure | 2 questions | Time-boxed challenge on why you, and on how much of the headline was yours | Nothing supplied suggests a stress style from a peer. Held low, but both items are the likeliest places composure is tested | Pause, restate, hold through two follow-ups, then concede specifically |

## Question banks

Highest-ROI prep in this pack: C1. It is the likeliest objection, it sits in Dan's own territory, and a rehearsed, non-defensive answer changes the conversation. A1 and A2 are next.

### A. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "That ~$400M ARR uplift: walk me through how it was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Say what the quote says and no more: you proposed the change, and the uplift was credited to it. Answer slot: this is the four-part defend-the-number slot. How was it counted, and what is the figure sensitive to? If you know, say it in your own words; if you do not know how it was counted, say so plainly, which is an honest answer. Never name a method you cannot repeat under a second question | F1 holds the headline metric, and Dan's self-description makes the count the first thing he will test. EXP because it scores whether the claim survives scrutiny |
| A2 | "Which assumption behind that number would you defend least?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | The weakest-assumption move: name, in your own words, the assumption you would defend least, before he asks. Answer slot: if you know of one, name it; if you do not know the assumptions behind the figure, say so plainly and say what you would want to check. The pack names no assumption for you | A credibility gain: naming the weak point first turns a gotcha into candor. F1 is the row; EXP because it scores self-awareness about the claim |
| A3 | "Walk me through the partner-level revenue model you built." | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" | Story-mapped on F4, with the beats the quote states: a revenue model, at partner level, which you built, and which was used in carrier negotiations. Tell them in your own words. Answer slot: expect a probe on what went into the model. If you chose or sourced any of its inputs, say which and how; if the inputs were given to you, or you do not know where they came from, say so plainly and stay with the model you built | F4 is the only quantitative-model evidence for a role that requires partner-motion design, so Dan will open it. EXP because the test is attribution and mechanics, not the requirement itself |
| A4 | "Tell me about an analysis you ran yourself in SQL or Tableau, start to finish." | JD | [grounded] "skilled in SQL/Tableau" | Say the quote at its scope: skilled in SQL and Tableau. Then a selection scaffold: pick one analysis where you posed the question, did the pull and the view yourself, and can say what it showed and what anyone did about it. If no such analysis comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would approach one | The JD lists independent SQL and Tableau analysis, and F3 is a single line, so this is the likeliest place a data-driven peer asks for proof. Open prompt, so it supplies no event |
| A5 | "Tell me about a time the data changed your recommendation." | EXP | [generic] | Selection scaffold: pick a case with a named recommendation, the specific data point that changed it, someone who held the other view, and what happened afterward. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle a case like it | Dan's own words, "relentlessly data-driven", raise this theme. Open prompt with a generic scaffold because nothing quoted carries it. EXP because it scores behavior, not a stated value |

### B. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our teams sit side by side. Where's the seam, and what happens when we disagree?" | JD | [generic] | The question needs no claim about your past, so the guidance makes none. Propose seam principles instead of claiming to know Northwind's: who owns the number, who owns the decision, and where an unresolved disagreement goes, which here is the shared VP. Ask what his team owns today before drawing the line. Offer what you would bring to his team before what you need from it | The core peer question. JD because the role is cross-functional by description, and the JD's cross-functional influence line is the raising source |
| B2 | "How do you handle credit when work spans teams?" | EXP | [grounded] "set annual volume targets with cross-org consensus"; "proposed a store-surface change credited with a ~$400M ARR uplift" | Use the quotes at their own scope. The targets were set with cross-org consensus. The figure was credited to the change you proposed. Keep both word for word. Answer slot: if credit on either was shared or contested, say how it was handled in your own words; if no such question arose, say so plainly. Note that Dan can use this question to reopen A1 and A2 | Persona stem. F5 and F1 are the two rows where credit is already written into the wording. EXP because it tests attribution honesty with an equal |
| B3 | "What would you need from my team in your first 90 days, and what can you bring to it?" | JD | [grounded] "skilled in SQL/Tableau"; "built a partner-level revenue model used in carrier negotiations" | Reciprocity framing, with the bringing half first. What you bring is what the two quotes carry: SQL and Tableau skill, and a partner-level revenue model you built. Say no more about its use than the quote does. What you need is a set of questions, not a claim: which definitions and data his team uses today. Do not claim to know Northwind's | The peer evaluator scores whether the hire lightens or adds to his load. F3 and F4 are the only rows that carry something of use to a sales-strategy team. JD because it tests the role's cross-functional line |
| B4 | "Tell me about a time you disagreed with a peer team over a number. How did it end?" | EXP | [generic] | Selection scaffold: pick a case with a named disagreement, a position you held and a point you conceded, and a working relationship that was intact afterward. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle one. Do not stretch the consensus quote into a disagreement story, because it says consensus and nothing about a dispute | Persona stem: disagreement with spine and tact. EXP because it tests behavior with equals, and generic because no quote carries a dispute |

### C. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "I don't see classic sales-ops or quota-setting in your background. How would you handle that in this role?" | JD | [grounded] "No classic sales-ops or quota-setting experience."; "set annual volume targets with cross-org consensus" | **Highest-ROI rehearsal.** Build it in four steps. Step one, name the limit first and plainly: "I haven't had classic sales-ops or quota-setting experience." Step two, the nearest thing the material carries, at its own scope: "I set annual volume targets with cross-org consensus." Do not call those targets quotas or like quotas. Step three, a plan stated as a plan: how you would learn how quotas work at Northwind, starting with his team. Step four, the follow-ups. If asked how volume targets differ from quotas, say in your own words what your targets were, and say plainly if you do not know how Northwind's quotas work. If pressed twice, hold by returning to steps one and two, and concede specifically: the gap is real, and you would lean on his team's knowledge until it is closed. Never claim sales-ops work | The coach stated F7, and it falls in or beside Dan's function, so he will ask it in some form. JD because it scores whether the stated gap can be handled in the role. The negative is sourced to the coach's notes, which is why it may be said aloud |
| C2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations"; "No classic sales-ops or quota-setting experience." | Choose the real answer from the fit snapshot instead of defending everything. The rows where the material is thinnest are F2, F4 and F7, and F2 shows nothing either way. Name one plainly, at the quote's own scope (F4: a revenue model, not a partner motion), then give your plan as a plan. Answer slot: if your own experience reaches the part you named, say how; if it does not, say so plainly. Never present a gap as a strength | Persona stem. Calibrated candor beats bluffing a competency the interviewer owns. JD because it scores honest self-assessment against the listed requirements |
| C3 | "The JD asks for partner-motion design. What have you designed?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | Hold F4's quote at its own scope: "I built a partner-level revenue model that was used in carrier negotiations." The pack's observation is that the material says a model and not a motion. Answer slot: if any part of how a partner program worked was yours to shape, say which and how you decided; if the model was economics only, or that was not yours, say so plainly and stay with the model | The JD marks this requirement as required, and F4's evidence is adjacent to it. JD because it scores a stated requirement directly |

### D. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Bundling by a much larger platform vendor is our main threat. Plan the GTM for a new line against it: what do you need to know first?" | CASE | [grounded] research note: "bundling by a much larger platform vendor" is Northwind's main competitive threat | The question needs no claim about your past. Clarify first: which line, who buys, how it is packaged and priced today, and what success means given that profitability is a stated priority. Then state a hypothesis early, since Dan is data-driven. Then segment, approach, metrics, risks, and name one data pull you would run in SQL first, as a plan. Challenge one premise respectfully, such as whether bundling affects every segment equally | The research note makes bundling the competitive frame, so this is the differentiator question most candidates cannot touch. CASE because it asks for structure on a problem from the role, with CO content |
| D2 | "How would you find the whitespace across land, adopt, expand and renew for the new lines?" | CASE | [grounded] JD line: "identify whitespace across land/adopt/expand/renew" | The question needs no claim about your past. Segment by lifecycle stage and give each stage its own question and metric: how accounts land, how deeply they adopt, where they expand, where renewal is at risk. Add one pricing-and-packaging lens, since that is his native language. State what you would pull and how you would test it, and say what you would need to know first. The pack names no Northwind data | F2 is the row with no evidence, so this question needs a structured answer, not a story. CASE because it is a live problem taken from the JD's own line |
| D3 | "Enterprise expansion, the Compass copilot launch and profitability are all priorities. If the new lines could fund only two, which two and why?" | CO | [grounded] research note: "enterprise expansion, an AI copilot launch ('Compass'), and reaching profitability" | The question needs no claim about your past. Ask what the new lines' economics look like first. Then trade off: which pairs reinforce each other, and what you give up. Challenge the premise that all three compete, if you can say why. Offer a pricing-and-packaging option for an AI copilot, such as attached versus separate, as an option and not a claim about Northwind. Do not claim to know whether Compass is one of the two lines | The three priorities come from the research note, and a pricing-and-monetization peer will enjoy the tradeoff. CO because it scores whether you can think at Northwind's altitude |

### E. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" | A 90-second arc built from the quote's two stages: two years of strategy consulting at a top firm, then nine at a large consumer-tech company in product strategy and ops. Tell them in your own words. The material does not contain why you want this move. Answer slot: give your actual reason for wanting this role and why now, in your own words. Close on what you want to do next, not on a list of accomplishments | Every conversation opens here, and it is scored for economy. F1 gives the arc; the reason for the move is the one piece the pack cannot supply. EXP because it tests the story's coherence |
| E2 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" | Say the quote at its scope: you use AI tools daily. Answer slot: say which tools and for which tasks, in your own words; if you use them for kinds of work other than the interviewer might assume, say so plainly. Expect a follow-up because Compass is Northwind's copilot launch: be ready for what you would want to understand about how customers adopt a copilot, as a view, not a claim about your past | The JD flags AI as a plus, so a casual AI question is still scored. F6 is use, not building. JD because it scores a stated plus |

### F. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a case with a named stake, a moment you did not soften the message, and a working relationship that was intact afterward, where the hard truth actually landed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle one. Use I for your contribution and we for context | Persona stem. Behavioral only, because no published Northwind values were retrieved. VAL because that persona is scored on behavior against values, and generic because no quote carries a story |
| F2 | "Tell me about a time you had to build a plan with no playbook." | VAL | [generic] | Selection scaffold: pick a case where the situation was new, you set the approach, and you can say how you checked it was working. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle one. A story from a large company is fine; do not dress it as a startup story | The JD's two new product lines raise the theme, and Dan's startup chapter makes it plausible. Generic because no quote carries it. VAL because it scores behavior |

### G. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Sixty seconds: why you, over someone who has run quota-carrying GTM?" | JD | [grounded] "No classic sales-ops or quota-setting experience."; "set annual volume targets with cross-org consensus"; "skilled in SQL/Tableau" | Hold then concede. Pause and restate the question. Hold on what the quotes carry: you set annual volume targets with cross-org consensus, and you are skilled in SQL and Tableau. Concede specifically: "I haven't had classic sales-ops or quota-setting experience." Do not claim you are better than the other candidate, and do not fold on the core claim to restore harmony. Hold through two follow-ups by returning to the quotes, never by adding to them | Time-boxed challenge on F7, the gap most likely to be pressed. JD because it scores fit against the role. Composure is what is actually scored |
| G2 | "That result: how much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Hold on the quote's own verbs: you proposed the change, and the uplift was credited to it. Answer slot: name which parts were yours and which were other teams', in your own words; if you do not know how the credit was assigned, say so plainly. Hold through two follow-ups, then concede specifically what you do not know. Never claim you generated the uplift | Persona stem. F1's figure is the claim most likely to be probed for inflation. EXP because it tests attribution honesty under pressure |

## Requirement coverage

| Requirement | Covered by |
|---|---|
| "own GTM strategy for two new product lines" | C2, D1, D3, E1, F2 |
| "identify whitespace across land/adopt/expand/renew" | C2, D2 |
| "run independent analysis in SQL and Tableau" | A4, B3 |
| "partner-motion design experience required" | A3, C3 |
| "strong cross-functional influence" | B1, B2, B3, B4, F1 |
| "AI experience a plus" | E2, D3 |
| Headline figure on the background | A1, A2, B2, G2 |
| Sales-ops and quota-setting, the coach's flagged gap | C1, C2, G1 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Your path runs through pricing and monetization roles and an early-stage startup before Sales Strategy. What from those years do you use most when you plan how Sales and the new product lines fit together?" | Ties to his own career path. It signals you read him, and it moves the conversation from interrogation to craft |
| R2 | "What could someone new in my seat do in their first month that would genuinely help your team?" | The reciprocity question for a peer. It shows you are asking how to lighten his load, not only what you need |
| R3 | "Where does Sales Strategy's work end and the new lines' GTM begin today, and where does that line tend to blur?" | It converts B1 into his view of the seam, and it invites the disagreement conversation on your terms |
| R4 | "When the data points one way and the field's instinct points the other, how does your team settle it?" | It speaks to his self-described data-driven approach and shows you care how decisions actually get made |
| R5 | "How is bundling by the larger platform vendor showing up in deals today, and is it changing what Sales Strategy needs from the new lines?" | It uses the research note's competitive frame, and it asks for his ground-level view instead of reciting yours |
| R6 | "How do the two new lines relate to Compass?" | It clears up something the pack does not know, and it shows you are thinking about the launch rather than guessing |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Owned or ran the GTM for a product line | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: the material says product strategy and ops, not go-to-market |
| Drove, generated or delivered the ~$400M ARR uplift | Inflated form of F1 | The quote's own verbs: proposed the change, and the uplift was credited to it. The slots in A1, A2 and G2 ask only how it was counted, what it is sensitive to, the weakest assumption and which part was yours |
| Negotiated with carriers, or led carrier negotiations | Inflated form of F4 | F4's quote at its own scope: a revenue model that was used in carrier negotiations |
| Designed a partner motion or partner program | Inflated form of F4 | F4's quote at its own scope. The limit is the pack's observation: the material says a model, not a motion. C3's slot stays inside the model |
| Has pricing or monetization experience | Inflated form of F4 | F4's quote at its own scope: a partner-level revenue model. Dan's spine is pricing, so the temptation is to claim a shared one |
| Has sales-ops or quota-setting experience, or that the volume targets were quotas | Negative the candidate stated, F7 | The plain acknowledgment F7 gives: "I haven't had classic sales-ops or quota-setting experience." No slot |
| Drove or led the cross-org consensus | Inflated form of F5 | F5's quote at its own scope: the targets were set with cross-org consensus. The limit is the pack's observation: the material does not say who built the consensus |
| Ran independent analysis end to end | Inflated form of F3 | F3's quote at its own scope: skilled in SQL and Tableau. A4's slot stays inside that |
| Built or shipped AI products | Inflated form of F6 | F6's quote at its own scope: uses AI tools daily |

## Sources

Provided: the coach's message, which carried the JD highlights, the summary of Priya's background, the description of Dan's profile and the coach's research note. The research note's age is not established, and Northwind's priorities and competitive threat are taken from it as given.

Searches sent, both refused:

- "Northwind Data company values principles data infrastructure": refused
- "Dan Kovac Director of Sales Strategy Northwind Data": refused

Research tier: L1 — searches 2 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Northwind Data values` | unavailable | Both calls were refused. It would have supplied published value names for the Values bank. The Values bank therefore uses behavioral stems only, and no values cheat sheet exists |
| 2. `Northwind Data interview process, GTM strategy role` | skipped | The coach's words already fix the loop as one 60-minute conversation with a peer, which fixes the persona weights |
| 3. `Northwind Data strategy` and recent news | skipped | The coach's research note supplies the three priorities and the competitive threat, which fix the CO and CASE content |
| 4. `Dan Kovac Northwind Data` | unavailable | The call was refused. It would have supplied his public talks and writing for the interviewer read and a tailored reverse question. The read rests on the coach's description alone |
| 5. representative `Senior GTM Strategy Lead` JD | skipped | The JD highlights fix the fit snapshot's requirement column. The full text would add the mid-list items |

## Upgrade menu

- The full JD text → the fit snapshot's requirement column quotes more lines, any mid-list requirement gets its own row and question, and the coverage table gains rows
- Priya's CV, verbatim → every evidence cell currently quotes the coach's notes and would quote her own sentences, and some rows could move off medium once an artifact is inspected
- An inspectable artifact behind the headline figure and the revenue model, such as the write-up or experiment readout behind the uplift and the model workbook or the memo that used it → F1 and F4 could move from medium to high, and A1 to A3 would rest on something checkable
- Priya's own answers to the answer slots, stated outside a drill, such as how the figure was counted, which part was hers, what shaped the partner work, and how the volume targets were set → F1, F2, F4 and F5 regenerate with her real words
- The recruiter's guidance on focus areas, any pre-declared deliverable, and process details → coverage reweights from the round-type prior, and a declared deliverable gets its own build section. Usually one email to the recruiter
- Dan's public footprint, by re-running the search with permission or by pasting his profile, talks or posts → the interviewer read gets a published-themes row, and R1 can reference something he has said
- Northwind's published values and documented interview process, by search or pasted → the Values bank becomes mapped to named values, and a values-style round is detected only if a source documents one
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes), offered once → a company strategy brief that would sharpen D1 to D3 and the grounding for R5
- How much prep time Priya has → a prioritized schedule that does the few things in order
- A `tuesday-dossier.md` from a separate evidence review, if one exists → verified claims, per-gap strategy limits and a named highest-risk objection arrive from it instead of being inferred here
