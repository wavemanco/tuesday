Running three searches on Northwind Data (values, interview process, Dan Kovac's public footprint), then building the pack.
Your prep pack is saved as `/var/tmp/tuesday-measure/1a6/runs/sonnet/alone/part-2/rooms/case-1-denied-d5b2903e/northwind-data_senior-gtm-strategy-lead_interview_pack.md`. It has 19 questions across six personas, with answer guidance and a rationale for each. Dan is a peer, so the pack leans on the Data-Driven Prober and the Peer Evaluator, adjusted for his "relentlessly data-driven" profile and his pricing and monetization background.

- **Research:** all three web searches were refused: Northwind's values, its interview process, and Dan's public footprint. The pack therefore rests only on what you pasted, including your research note on the three priorities and the bundling threat, which I couldn't check against a public source. The Sources section says what each search would have added. The upgrade menu offers a deeper pass if search permission is granted.
- **Highest-ROI prep (D1):** the "nine years in consumer tech and no sales-ops background, so why you for B2B GTM" objection. B3 (collegial) and G2 (time-boxed) are the same objection in other packaging.
- **Quota wording:** Priya's own words are "No classic sales-ops or quota-setting experience". The pack keeps "annual volume targets" as exactly that and never lets it become "set quotas". Section 8 lists that and the other claims it won't coach, each with the honest alternative.
- **Slots to fill:** where your material doesn't show a practice, such as how the ~$400M was counted or what drove the carrier model, the guidance is an answer slot for Priya to fill in her own words, with an honest "that wasn't me" branch. I didn't supply specifics she hasn't given you.
- **Left out:** there's no values cheat sheet, because no values round is documented. There's no prep-time triage, since you didn't give a time budget.

Say the word and I'll play Dan as the Prober on A1, or as the Skeptic on D1, the pack's highest-ROI question. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed. If you'd like the pack as a Word document, I can convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: northwind-data_senior-gtm-strategy-lead_interview_pack.md -----
# Interview pack: Senior GTM Strategy Lead, Emerging Products — Northwind Data

**Candidate:** Priya. **Interviewer:** Dan Kovac, Director of Sales Strategy, a peer who reports to the same VP. **Format:** one 60-minute conversation.
**Built on:** the material you pasted, with no web research (all three searches were refused, see Sources). Persona weights rest on the relationship (peer) and on Dan's profile as you relayed it.

## 1. How to use this pack

Personas describe how a question arrives. Types describe what it scores. Guidance is scaffolding, not a script: say it in your own words, and never say something you cannot defend through a second follow-up.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the company's published values (no values-style round is detected, so this pack has no VAL rows) |
| EXP | Whether CV claims survive scrutiny and who did what |
| JD | Whether you can do the listed job, gaps included |
| CO | Company and strategy fluency |
| CASE | Structure and reasoning on a live problem from the role |

Question IDs run by persona: A Prober, B Peer Evaluator, C Case/Strategist, D Skeptic, E Conversational, G Pressure. There is no F, so fit-snapshot rows (F1 to F8) are never confused with questions.

**Highest-ROI prep in the pack: D1**, the "consumer-tech background, no sales-ops experience, so why you for B2B GTM" objection. It will arrive in some form, and B3 is the same objection in peer packaging. Rehearse D1 until it is boring.

## 2. Fit snapshot

Requirements are the JD highlights as you relayed them, not the JD's own text. Evidence is quoted from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" — JD highlights, your message | "9 at a large consumer-tech company in product strategy & ops" — your message | medium | [grounded] | transferability | Your material says product strategy and ops, not go-to-market ownership, with nothing inspected behind it. Words stay at that scope: "I spent nine years in product strategy and ops at a large consumer-tech company." Answer slot: the JD's GTM line makes a probe on go-to-market work likely. If any of your work covered taking a product to market, say which part was yours, in your own words; if none did, or it was not yours, say so plainly and stay with product strategy and ops |
| F2 | "identify whitespace across land/adopt/expand/renew" — JD highlights, your message | "proposed a store-surface change credited with a ~$400M ARR uplift" — your message | low | [grounded] | discovery | The quote shows a proposal and a credited uplift, and does not show whether any analysis looked across stages of a customer lifecycle. Answer slot: the JD's four-stage line makes a probe likely. If the work looked at stages like these, say what it found and what part was yours; if it did not, say so plainly and say how you would structure the search for whitespace |
| F3 | "run independent analysis in SQL and Tableau" — JD highlights, your message | "skilled in SQL/Tableau" — your message | medium | [grounded] | presentation | The quote names both tools and is the whole evidence, so expect a probe on it. Words: "I'm skilled in SQL and Tableau." Answer slot: if there is an analysis you ran yourself in either tool, say what question it answered and what happened next; if there is none you can point to, say so plainly and stay with the tools |
| F4 | "partner-motion design experience required" — JD highlights, your message | "built a partner-level revenue model used in carrier negotiations" — your message | medium | [grounded] | transferability | Your material says a revenue model used in negotiations, not the design of a partner motion. Words stay at that scope: "I built a partner-level revenue model that was used in carrier negotiations." Answer slot: the JD's partner-motion line makes a probe on motion design likely. If any part of designing how a partner relationship works was yours, say which and how you decided; if not, say so plainly and stay with the model |
| F5 | "strong cross-functional influence" — JD highlights, your message | "set annual volume targets with cross-org consensus" — your message | medium | [grounded] | presentation | The quote already carries the requirement in other terms. Say it as written: "I set annual volume targets with cross-org consensus." The word is volume targets, never quotas (see section 11) |
| F6 | "AI experience a plus" — JD highlights, your message | "uses AI tools daily" — your message | low | [grounded] | discovery | The quote shows daily use and does not show whether any of it touched a product or a customer. Answer slot: say what you use the tools for, in your own words; if it is personal or workflow use only, say so plainly and stay there |
| F7 | sales-ops and quota-setting experience (a role-family expectation for a Sales Strategy peer, not a line from the JD highlights) | "No classic sales-ops or quota-setting experience" — your message | none | [grounded] | capability | A gap wording cannot close, and the candidate has said so. Words: "I don't have classic sales-ops or quota-setting experience." Then how you would learn it, said as a plan and never as a past |
| F8 | "B2B data-infrastructure SaaS" — Northwind description, your message (a company description, not a JD line) | "9 at a large consumer-tech company in product strategy & ops" — your message; "built a partner-level revenue model used in carrier negotiations" — your message | low | [grounded] | transferability | Your material does not show enterprise or B2B selling exposure, and nothing here supplies it. Words stay at the two quotes' own scope. No answer slot, because no JD line raises this, so the interviewer's probe is answered by D1's structure |

## 3. Reading the interviewer

Public footprint here is only what your note relays: web searches were refused, so there are no talks, posts or interviews behind it.

| Signal (as you relayed it) | What it implies for the conversation |
|---|---|
| "relentlessly data-driven" (his profile's self-description) | Every number you offer will be taken to its inputs. Offer the weak spot of a figure before he asks |
| "career spine is pricing and monetization roles" | Pricing, packaging and unit economics are his native language. Cases and metric answers land best framed in those terms |
| "one early-stage-startup chapter" | He has seen scrappy and scaled. Expect a probe on whether you can work without big-company infrastructure; builder stories are welcome |
| Peer, "both reporting to the same VP" | He is pricing what you add to, or take from, his workload. Lead with reciprocity |

Mirror opportunity: his monetization vocabulary meets F2's "proposed a store-surface change credited with a ~$400M ARR uplift", used only at that quote's scope. His startup chapter is not offered as a shared jump, since no row's evidence carries a startup side for you.

## 4. Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy | Bank |
|---|---|---|---|---|
| Data-Driven Prober (top) | Line-by-line probing of your figures and models | Highest. Peer prior puts the Prober first, and "relentlessly data-driven" pushes it up | Say how each figure was counted, or say plainly you do not know; name the weakest assumption first | A, 5 questions |
| Peer Evaluator | Seam, credit and "what do I get from you" questions | High. A peer prices your effect on his team | Reciprocity first; propose seam principles rather than claim to know the seam | B, 4 questions |
| Case/Strategist | Live pricing, bundling and GTM problems | Medium. His pricing spine tilts the cases, and your note names bundling and Compass as live issues | Clarify, structure, think aloud, challenge one premise | C, 3 questions |
| Skeptic | The consumer-to-B2B and no-sales-ops objection, in collegial form | Medium. Peer packaging softens delivery, not content, and F7 gives it a stated gap | Rehearse D1 until boring; hold, then concede the stated gap | D, 3 questions |
| Conversational | Opening journey question, casual AI question | Lower. A 60-minute peer talk will open friendly, but it is still scored | A 90-second arc; treat casual questions about JD topics as scored | E, 2 questions |
| Pressure | Time-boxed "how much was you" challenges | Lower. Nothing in his profile signals stress style | Hold through two follow-ups, concede specifically | G, 2 questions |

Loop: your own words establish one 60-minute session with one peer. No values-style round is detected, so there is no values cheat sheet.

## 5. Question banks

### A. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how the ~$400M ARR figure was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Say it as it stands: you proposed the change, and it was credited with the uplift. Answer slot: the four things a prober asks of a figure are how it was counted, what it is sensitive to, which assumption behind it you would defend least, and which part was yours. Answer each in your own words; where you do not know how it was counted, say so plainly. Name the weakest assumption before he does | The headline metric is the likeliest first target for a self-described data-driven peer (F2). EXP because it tests attribution and method, not the number |
| A2 | "Walk me through the revenue model you built for carrier negotiations." | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" | Beats the quote states: you built a partner-level model, and it was used in negotiations. Answer slot: the JD's partner-motion line makes a probe on what drove the model likely. If you set its key assumptions, say which and why; if someone else did, or you do not know, say so plainly and stay with what you built | F4 is the partner-motion evidence, and a prober will test what is behind "built". JD primary since it scores the partner requirement, EXP delivery |
| A3 | "Tell me about an analysis you ran yourself in SQL or Tableau, from question to decision." | JD | [grounded] "skilled in SQL/Tableau" | An open prompt, and your material carries the tools, not an analysis story. Pick one analysis that was yours alone, with a named question, the data you pulled, and a decision it changed. If no such analysis comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would approach it | F3 is the JD's "independent analysis" line and the one a data-driven interviewer cares about most |
| A4 | "A new product has accounts that landed but have not adopted. How would you find the whitespace?" | CASE | [generic] | Structure it aloud: what you need to know first (which accounts, what counts as adopted, what the data can and cannot split), the segments you would cut, the query or view you would build, the metric that would tell you it worked, and the risk of the data misleading. Needs no claim about your past | F2's lifecycle line, as a live problem so no experience claim is needed. CASE because it tests structure, with the SQL angle for this interviewer |
| A5 | "How did you reach cross-org consensus on the annual volume targets?" | EXP | [grounded] "set annual volume targets with cross-org consensus" | Beats the quote states: you set the targets, and consensus was across orgs. Answer slot: the JD's cross-functional line makes a probe on disagreement likely. If orgs disagreed, say about what and what part was yours in settling it; if they did not, say so plainly and stay with the targets | F5 is the cross-functional evidence. EXP because the probe is who did what in reaching consensus |

### B. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our teams sit side by side. Where is the seam, and what happens when we disagree?" | JD | [generic] | Offer principles, not a claim to know the seam: who owns which decision, what data both sides trust, and how you would take a disagreement to your shared VP only after trying to settle it first. Ask him where he sees the seam today. Makes no claim about your past | Peer stem, central to this relationship. JD because it scores the cross-functional requirement, delivered as a collegial probe |
| B2 | "How do you handle credit when work spans teams?" | VAL | [grounded] "set annual volume targets with cross-org consensus" | A selection scaffold: pick a time work spanned orgs, with named contributors, what you attributed to others, and an intact relationship afterwards. If none comes to mind, say so plainly, then give the nearest thing your material does carry, which is the targets set with cross-org consensus, or how you would handle it | The credit probe is a standard peer item (F5). VAL-style because it tests behavior, kept here since no published values were found |
| B3 | "You haven't done classic sales-ops work. What would you need from my team to get up to speed?" | EXP | [grounded] "No classic sales-ops or quota-setting experience" | The same objection as D1, collegially packaged. Say the plain acknowledgment: "I don't have classic sales-ops or quota-setting experience." Then a plan as a plan: what you would ask him to walk you through first, and what you would bring back. Do not claim quota work | F7 is the stated gap. EXP because it tests honest self-assessment, from a peer who would carry the onboarding load |
| B4 | "What would you bring my team that it does not have?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations"; "set annual volume targets with cross-org consensus" | The reciprocity answer. Use the quotes at their own scope: the partner-level model used in negotiations, and the volume targets set with cross-org consensus. Then ask what his team most needs from emerging-products GTM. Claim no more than the two quotes carry | The reciprocity question a peer weighs most (F4, F5). JD because it scores fit to the stated requirements |

### C. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A much larger platform vendor starts bundling a comparable product into its suite. How does that change your GTM for a new line?" | CO | [grounded] | Clarify first: what the bundled product is, how much of the customer base overlaps, and which stage of the customer lifecycle is most exposed. Then objective, segments, approach, metrics, risks. Challenge one premise respectfully. Uses your note's named threat and makes no claim about your past | Your note names bundling as the main competitive threat. CO because it tests altitude on the company's actual frame, CASE in delivery |
| C2 | "Profitability is a priority and an AI copilot is launching. How would you price and package it?" | CASE | [grounded] | Clarify (who buys it, whether it is an add-on or included, what it costs to serve), then packaging options with the trade-off of each, and the metrics that would tell you which is working. Pricing is his native language, so say your assumptions aloud. Makes no claim about your past | Compass and profitability are two of the three priorities in your note, and his pricing spine makes this his natural case. CASE because it is a live problem |
| C3 | "Design a partner motion for a new data-infrastructure product line. What do you need to know first?" | CASE | [generic] | Clarify (which partners, what they want from the product, how they get paid), then segmentation, motion options, metrics, risks. Name the one premise you would push on. Needs no claim about your past, so do not present the carrier model as a designed motion | F4's JD line as a live problem. CASE so the answer rests on reasoning rather than on a thin transferable quote |

### D. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Nine years in consumer tech and no sales-ops background. Why should I believe you can own GTM for these product lines?" | JD | [grounded] "9 at a large consumer-tech company in product strategy & ops"; "No classic sales-ops or quota-setting experience"; "built a partner-level revenue model used in carrier negotiations"; "set annual volume targets with cross-org consensus" | **Highest-ROI rehearsal.** Hold only what the quotes carry: "I built a partner-level revenue model used in carrier negotiations, and I set annual volume targets with cross-org consensus." Concede specifically: "I don't have classic sales-ops or quota-setting experience." Then a ramp plan, as a plan: what you would ask to be walked through in the first weeks and who you would ask. Follow-up 1, "which part would you be weakest at on day one", is answered by D2. Follow-up 2, "what would you need me to teach you", is answered by B3. Hold through both without adding to the quotes. Answer slot: if anything in your nine years touched selling to businesses, say what and what part was yours; if nothing did, say so plainly and stay with the quotes | F1, F7 and F8 converge here, and this is the question the pack most expects. JD because it scores the headline requirement, with Skeptic delivery |
| D2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations"; "9 at a large consumer-tech company in product strategy & ops" | Name one requirement where your quotes are thinnest (F1 or F4 are where the snapshot is thinnest), say it plainly, say what your material does carry for it at its own scope, and give a first-30-days plan. Calibrated candor beats bluffing a competency he may own | Skeptic stem, aimed at F1 and F4. JD because it scores the stated requirements |
| D3 | "Why leave a large consumer-tech company after nine years, and why here?" | EXP | [grounded] "9 at a large consumer-tech company in product strategy & ops" | Give your own reason for moving and your own reason for this role, in one sentence each. No wording is supplied for either, since your material states neither. Make it consistent with D1 and E1 | Motivation consistency is scored in every Skeptic round (F1, F8). EXP because it tests whether the story survives cross-examination |

### E. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" | A 90-second arc with the quote's beats: two years of strategy consulting at a top firm, then nine at a large consumer-tech company in product strategy and ops. Add your own reason for this role last. No other beats are supplied | The friendly opener is still scored (F1). EXP because it tests an economical, consistent career story |
| E2 | "What are you actually using AI for these days?" | JD | [grounded] "uses AI tools daily" | Say what you use the tools for, in your own words, and what you have learned about where they fail. Answer slot: if any use touched a product or a customer, say what and what part was yours; if it is all your own workflow, say so plainly and stay there | F6's plus-skill stem, asked casually. JD because it scores the stated plus |

### G. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "That ~$400M. How much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Pause, restate, and hold on what the quote says: you proposed the change, and it was credited with the uplift. Answer slot: say which parts, beyond the proposal, were yours, and who credited it; if you do not know how credit was assigned, say so plainly. Hold through two follow-ups, concede only what you cannot back, never fold on the proposal | The attribution probe on the pack's biggest number (F2). EXP because it scores the line between proposing and delivering |
| G2 | "Sixty seconds: why you rather than someone who has carried a quota?" | JD | [grounded] "No classic sales-ops or quota-setting experience"; "set annual volume targets with cross-org consensus" | Open with the concession: "I don't have classic sales-ops or quota-setting experience." Then what the quote does carry: volume targets set with cross-org consensus. Stop inside the minute | The time-boxed form of D1 (F5, F7). JD because it scores fit, with Pressure delivery |

## 6. Requirement coverage

| Requirement | Questions |
|---|---|
| own GTM strategy for two new product lines | C1, C2, D1, D2 |
| identify whitespace across land/adopt/expand/renew | A1, A4 |
| run independent analysis in SQL and Tableau | A3, A4 |
| partner-motion design experience required | A2, B4, C3 |
| strong cross-functional influence | A5, B1, B2, B4 |
| AI experience a plus | C2, E2 |
| sales-ops and quota-setting (not in the JD highlights) | B3, D1, G2 |
| Northwind priorities from your note (enterprise expansion, Compass, profitability, bundling) | C1, C2 (enterprise expansion has no question: no row or quote speaks to it, and it fits better as reverse question R6) |

## 7. Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What from your pricing and monetization work do you lean on most in Sales Strategy here?" | Tied to his path as you relayed it. It lets him talk in his native language and shows you researched him |
| R2 | "How did the early-stage chapter change how you work inside a company of this size?" | Tied to his startup chapter. It invites a peer conversation about builder pace |
| R3 | "What could a new person on emerging-products GTM do in the first month that would genuinely help your team?" | The reciprocity question a peer weighs most: it asks what you can give, not only take |
| R4 | "Where do our teams' priorities most often diverge, and what has worked for settling it with the VP?" | Moves B1's seam from hypothetical to real, and shows you plan to disagree well |
| R5 | "Which metrics does the VP actually use to judge whether a new line is working, and which do you distrust?" | A data-driven interviewer enjoys being asked what he distrusts, and it tells you what you will be measured on |
| R6 | "How is bundling showing up in the deals you see, and how does enterprise expansion change the plan?" | Uses two of the priorities in your note, so it shows homework without reciting it |

## 8. Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Set sales quotas | Contradicted by the stated negative, F7 | The candidate's own quote: "No classic sales-ops or quota-setting experience". Plain acknowledgment: "I don't have classic sales-ops or quota-setting experience." No slot |
| Owned or designed a partner motion | Inflated form of F4 | F4's quote at its own scope. The limit is the pack's observation: the material says a revenue model used in negotiations, not a motion. A2's slot stays inside the model |
| Owned GTM for a product line | Inflated form of F1 | F1's quote at its own scope: product strategy and ops. The limit is the pack's observation: the material says product strategy and ops, not go-to-market ownership |
| Led or delivered the ~$400M uplift | Inflated form of F2 | F2's quote at its own scope: you proposed the change, and it was credited with the uplift. G1's slot asks only what part beyond the proposal was yours |
| Built or shipped AI products | Inflated form of F6 | F6's quote at its own scope: daily use of AI tools. E2's slot stays inside the use |

## 9. Sources

Provided: your message only (JD highlights as relayed, the candidate summary, the interviewer profile summary, and your research note on Northwind's three priorities and the bundling threat). No full JD, CV or dossier was provided. The research note could not be checked against any public source.

Searches sent, all refused (permission not granted):
- "Northwind Data company values principles" — refused
- "Northwind Data interview process strategy operations" — refused
- "Dan Kovac Northwind Data Director Sales Strategy" — refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Northwind Data values` | unavailable | Every call was refused. Would have supplied published value names for VAL questions and a values cheat sheet if a values round exists |
| 2. `Northwind Data interview process` | unavailable | Every call was refused. Would have documented how this loop and this role family are run, which could have moved persona weights |
| 3. `Northwind Data strategy` / recent news | skipped | Your research note's content is in hand and fixes the CO and CASE questions C1 and C2 |
| 4. `Dan Kovac Northwind Data` | unavailable | Every call was refused. Would have added talks and writing to section 3 and sharpened R1 and R2 |
| 5. representative `Senior GTM Strategy Lead` JD | skipped | The JD highlights you supplied fix the fit snapshot and the JD-tagged questions |

## 10. Upgrade menu

- Full JD text → the six JD rows (F1 to F6) have their requirements quoted from the posting itself rather than your relay, and any mid-list requirement gets a question
- The candidate's CV → evidence cells quote the CV verbatim, and rows now at `low` can be re-graded
- The written proposal or readout behind the ~$400M uplift, the revenue model workbook, or a SQL or Tableau work sample → F2, F3 and F4 can move from `medium` or `low` toward `high`, and A1, A2 and A3 become story-mapped
- Search permission granted, then a deeper pass (up to 6 more searches and 2 more fetches, several more minutes) → Northwind's published values and loop structure, Dan's public talks and writing, and a current strategy brief to check your note against
- The recruiter's focus areas for this conversation → coverage reweighted from relationship priors to what was actually flagged
- A tuesday-dossier.md from an earlier evidence-verification pass → verified evidence and prohibited claims arrive pre-graded rather than inferred
