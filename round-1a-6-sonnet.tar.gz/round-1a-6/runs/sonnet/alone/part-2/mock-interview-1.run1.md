I'll read the reference files the skill points to before building the pack.
The pack is written and saved. Here is the summary.

I've saved your prep pack as `/var/tmp/tuesday-measure/1a6/runs/sonnet/alone/part-2/rooms/case-1-denied-c4535837/northwind-data_senior-gtm-strategy-lead_interview_pack.md`. It has 19 questions across six personas, built for a peer round with Dan. All three web searches (values, interview process, Dan's public footprint) were refused. So the company, loop and interviewer facts rest only on your notes, and the Sources section shows each search as refused.

- **Highest-ROI prep:** D1, the "no classic sales-ops or quota-setting" objection. It's inferred from the gap you stated, not from an underwriter's dossier. The guidance has Priya name the limit first, then hold only what her quoted material carries.
- **Likeliest follow-ups:** Dan's self-described data-driven style makes A1 and A2 likely. They probe how the ~$400M ARR figure was counted and which assumption behind it she'd defend least.
- **Answer slots:** where your notes were silent, such as GTM ownership, how the volume targets were derived and the AI work beyond daily tool use, the guidance is an answer slot in her own words, not an invented story.
- **No values bank:** no published values were in hand and no values round is documented, so the pack has none.

Say the word and I'll play Dan on D1 so Priya can rehearse the objection live.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for her to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: northwind-data_senior-gtm-strategy-lead_interview_pack.md -----
# Interview pack: Senior GTM Strategy Lead, Emerging Products — Northwind Data

**Candidate:** Priya. **Interviewer:** Dan Kovac, Director of Sales Strategy, a peer who reports to the same VP. **Format:** one 60-minute conversation. Built for a peer round, from the notes you supplied.

## How to use this pack

Personas describe how a question is asked. Types describe what it scores. Question IDs run A to E by persona, plus P for the Pressure persona. Fit-snapshot rows are F1 to F7, so a bare "F" always means a fit row.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the company's published values. This pack has no VAL bank, because no published values were in hand and no values round is documented in your notes |
| EXP | Whether the CV's claims survive scrutiny, and what was actually yours |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you can think at the company's altitude: strategy, competition, recent moves |
| CASE | Structure and reasoning on a live problem from the role |

Guidance is scaffolding, not a script. Every sentence about your past comes from a sentence in the fit snapshot, quoted. Where the material is silent, the guidance is an answer slot: say what is true in your own words, or say plainly that it was not yours or did not exist. The highest-ROI prep in this pack is **D1**, the no-sales-ops-or-quota-setting objection. It is inferred from your stated gap, not from an underwriter's dossier.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" — JD highlights in your message | "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" — the coach's notes; "proposed a store-surface change credited with a ~$400M ARR uplift" — the coach's notes | medium | [grounded] | transferability | Your material says product strategy & ops and a proposal, not ownership of a go-to-market, with nothing inspected behind it. Words at that scope: "I proposed a store-surface change credited with a ~$400M ARR uplift." Answer slot: the JD's two new product lines make a probe on whether any of your work took something to market likely. If any did, say which part was yours, in your own words; if none did, or it was not yours, say so plainly and stay with the proposal |
| F2 | "identify whitespace across land/adopt/expand/renew" — JD highlights in your message | "proposed a store-surface change credited with a ~$400M ARR uplift" — the coach's notes | low | [inferred] | discovery | The quote touches revenue growth and does not show whether it reached any stage of land, adopt, expand or renew. Answer slot: if any of your analysis split revenue by stage of a relationship, say how, in your own words; if it did not, say so plainly and say how you would start on it |
| F3 | "run independent analysis in SQL and Tableau" — JD highlights in your message | "skilled in SQL/Tableau" — the coach's notes | medium | [grounded] | none | No gap in the words, but a one-line claim with nothing inspected behind it, so expect a probe on a specific analysis. Lead with the tools in the quote's own terms: "I'm skilled in SQL/Tableau." A named query or dashboard beats an adjective |
| F4 | "partner-motion design experience required" — JD highlights in your message | "built a partner-level revenue model used in carrier negotiations" — the coach's notes | medium | [grounded] | transferability | The quote says a revenue model used in negotiations. Your material does not show designing a partner motion. Words at that scope: "I built a partner-level revenue model that was used in carrier negotiations." Answer slot: expect a probe on whether you designed a motion or modelled one. If any part of how partners were engaged was yours to design, say which; if the model fed negotiations others ran, say so plainly and stay with the model |
| F5 | "strong cross-functional influence" — JD highlights in your message | "set annual volume targets with cross-org consensus" — the coach's notes | medium | [grounded] | presentation | The quote already reaches the requirement in other terms. Reword only it: "I set annual volume targets, with consensus across orgs." Answer slot: if there was disagreement to resolve on the way, say what it was and what you did; if consensus came without one, or your part was smaller, say so plainly |
| F6 | "AI experience a plus" — JD highlights in your message | "uses AI tools daily" — the coach's notes | medium | [grounded] | presentation | The quote reaches the requirement as use. Words: "I use AI tools daily." Your material says use, not building or launching. Answer slot: if you have built, tested or shipped anything with AI, say what and your part; if it is use, say so plainly |
| F7 | How a sales organisation sets quota and capacity, which a Director of Sales Strategy peer works with. Role-family expectation, unquoted, [generic] | "No classic sales-ops or quota-setting experience." — the coach's notes | none | [grounded] | capability | A gap wording cannot close, and your notes state it. Words: "I haven't had classic sales-ops or quota-setting experience." Then how you would learn it, said as a plan and never as a past: the first thing you would ask Dan is how targets and capacity are set today. Never a claim to that work, and nothing added to make the gap feel smaller |

## Reading the interviewer

Dan's facts come from the profile summary in your message. I could not check them against public sources, because my searches were refused. Nothing here goes beyond your summary.

| Signal | Source | What it means for you | Provenance |
|---|---|---|---|
| Career spine is pricing and monetization roles | Your profile summary | Cases tilt toward packaging, pricing and unit economics. Expect the bundling and Compass questions (C1, C2) to be pushed there | [grounded] |
| One early-stage-startup chapter | Your profile summary | Builder stories land well. Expect a probe on pace and working without large-company structure (D3) | [grounded] |
| Self-describes as "relentlessly data-driven" | Your profile summary | Every number you give will be taken to its assumptions. Rehearse A1, A2 and A5 first | [grounded] |
| Peer, same VP | Your message | The seam and credit questions (B1, B2) are likely. Answer with what you bring to Dan's work as well as what you need (B4) | [grounded] |
| Mirror opportunity: Dan's pricing and monetization spine beside F4's "built a partner-level revenue model used in carrier negotiations" | Your profile summary and F4 | Offer the quote as it stands and let Dan make the connection. It says revenue model, not pricing, so do not call it pricing work | [inferred] |
| Public talks or writing | Not established | No footprint was checked. Anything Dan has published is an upgrade-menu item | [generic] |

## Persona table

The loop is established for this session by your words: one 60-minute conversation with Dan, a peer. Other rounds, if any, are not covered.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Data-Driven Prober (5 questions) | Takes your figures to their inputs and assumptions | Highest. The peer prior puts Prober near the top, and Dan's self-description raises it further. F1 and F2 carry a figure | Know what you can and cannot say about how the ~$400M was counted, and say plainly when you do not know (A1, A2). Name the weakest assumption before Dan does |
| Peer Evaluator (4) | Seam-splitting, credit, what you would need from Dan | High. Peer prior, and the seam with Sales Strategy is real | Offer seam principles, not claims about Northwind. Bring something to Dan's team as well as asking (B1 to B4) |
| Case / Strategist (3) | Live problems on bundling, Compass and partner motion | Medium. The peer prior ranks Case below Peer and Prober, and Dan's pricing spine moves it up one tier | Clarify, then objective, segmentation, approach, metrics, risks. Say the structure aloud. You come from consulting, so this is expected |
| Skeptic (3) | Probes the missing sales-ops and quota-setting experience, and the large-company background | Medium. F7 is a stated gap, and a startup chapter suggests pace probes | Name the limit before it is asked and hold what your quotes carry (D1). Calibrated candor, no bluffing |
| Conversational (2) | The opening "walk me through the journey" | Medium-low. It will open the hour, and it is still scored | A 90-second arc (E1). Treat the AI question as scored (E2) |
| Pressure (2) | Time-boxed "why you" and "how much was actually you" | Low as a style. Peer conversations carry these probes collegially, but they still arrive | Pause, restate, hold two follow-ups, concede specifically (P1, P2) |
| Values / Behavioral | Not banked | No published values were in hand, and your notes describe no values round | Added when values text is supplied (upgrade menu) |

## Question banks

### A. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how the ~$400M ARR uplift was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Start with what the sentence says: you proposed the change, and it was credited with a ~$400M ARR uplift. Then the four slots a figure raises. How it was counted: if you know, say so in your own words; if you do not know, say so plainly. What it is sensitive to: say what, if you know. Who credited it: say only if you know. Which part was yours: return to the proposal. Never describe a counting method you could not repeat under a second question | F1 and F2 carry the figure, and a figure is the first thing a self-described data-driven interviewer takes apart. EXP because it tests attribution and method. Prober because the ask is the denominator |
| A2 | "Which assumption behind that number would you defend least?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | The weakest-assumption move: name in your own words the assumption you would defend least, before Dan does. The pack does not name it, because no quote does. Answer slot: if you know the assumption, say what it is and what you would check; if you do not know how the figure was built, say so plainly. Then return to what the quote carries: you proposed the change | The same figure, one level down. Conceding a limit first converts a gotcha into credibility. EXP because the score is how well you know your own number. See F1 |
| A3 | "Tell me about an analysis you ran yourself in SQL or Tableau, from the question to the decision." | JD | [grounded] "skilled in SQL/Tableau" | Selection scaffold. Choose an analysis where you wrote the query or built the view yourself, and can name the question, what the data was, how you checked it, and what changed because of it. Use the tools only as the quote does: "I'm skilled in SQL/Tableau." If no such analysis comes to mind, say so plainly, then give the nearest thing your material carries, or how you would run one | The JD lists independent SQL and Tableau analysis, and F3 is a bare claim. A self-described data-driven peer will test it. JD because it scores a stated requirement |
| A4 | "Adoption of a new product is climbing but expansion revenue is flat. How do you diagnose it?" | CASE | [generic] | Clarify first: how adopt and expand are defined, and the time window. Objective, then segmentation (cohort, segment, stage). Then competing hypotheses: adoption not turning into more paid usage, a packaging or pricing issue, a bundled alternative. For each, the cut you would run in SQL and what would change your mind. Name the assumption you are least sure of. The question needs no claim about your past, so the guidance makes none | Covers the JD's whitespace across land, adopt, expand and renew (F2) as a live problem, in the Prober's register. CASE because it is reasoning on a problem from the role. `[generic]` because it is a pattern, not a fact about Northwind |
| A5 | "You set annual volume targets. How did you know the number was right?" | EXP | [grounded] "set annual volume targets with cross-org consensus" | Beats the sentence states: you set annual volume targets, with consensus across orgs. Answer slot: the probe is how the number was derived. If you know, say how in your own words; if the method was someone else's, or you do not know, or "right" was not something you could test, say so plainly and return to the consensus | F5 is the evidence, and this is the likeliest place Dan tests it. It also sits next to the stated quota gap in F7, so rehearse it as a limit, not a bridge |

### B. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our teams sit side by side. Where's the seam between Sales Strategy and GTM for the new product lines, and what happens when we disagree?" | JD | [generic] | Ask Dan how it works today before proposing anything, since you do not know it. Then offer principles, not a map: one owner per decision, shared definitions of the numbers, and an agreed default for who decides when you split. The question needs no claim about your past, so the guidance makes none | The signature peer question, and it scores the JD's cross-functional influence (F5). JD because it tests the role's stated collaboration mandate |
| B2 | "How do you handle credit when work spans teams?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | "We" for context, "I" for contribution. The "I" you can stand behind is the one in the quote: you proposed the change. Answer slot: if other teams shaped or built it after the proposal, say what and who; if you do not know, say so plainly. Never claim the uplift as yours | Credit-sharing is a standard peer probe, and F1 and F2 carry the credited figure. EXP because it tests attribution honesty |
| B3 | "Walk me through how you got consensus across orgs on the annual volume targets." | JD | [grounded] "set annual volume targets with cross-org consensus" | Beats the sentence states: annual volume targets, consensus across orgs. Answer slot: if there was disagreement, say what it was and what you did; if consensus came without one, or your part was smaller than "set", say so plainly. Never supply a stakeholder, a standoff or a concession you did not describe | F5 is the evidence for the JD's cross-functional influence. JD because it scores that requirement, and the premise is your own quote |
| B4 | "What would you need from my team in your first 60 days, and what do you bring to it?" | JD | [grounded] "skilled in SQL/Tableau" | Reciprocity. Needs: ask for things you can name as asks, such as how targets and capacity are set today and where the sales data lives. Bring: "I'm skilled in SQL/Tableau," offered as analysis support at that scope. Promise no outcomes and no capacity you have not discussed | The peer-bank reciprocity question. Your ask about targets is also the ramp plan for F7. JD because it tests cross-functional fit |

### C. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Bundling by a much larger platform vendor is our main competitive threat. How should that shape the GTM for a new product line?" | CO | [grounded] your research note: bundling by a much larger platform vendor is the main competitive threat | Clarify which line, which buyer, and what is being bundled. Segment where a bundle is hardest to beat and where depth or neutrality holds up. Then levers: packaging and pricing (expect Dan to push here), a partner route, proof of value. Metrics and risks. Challenge one premise respectfully, such as whether the threat is equal in every segment. No claim about your past | Your note names bundling as the main threat, and Dan's pricing spine makes this the natural case. CO because it needs the company's own frame. Grounded on the note, not on a fetched source |
| C2 | "Compass, our AI copilot, is launching. What is the GTM across land, adopt, expand and renew, and how does it serve enterprise expansion?" | CASE | [grounded] your research note: priorities are enterprise expansion, the Compass launch and profitability; and "uses AI tools daily" | Clarify who it is for and what success means. For each stage, one hypothesis and one metric. Tie it to enterprise expansion, and say where you would hold spend back given the profitability priority. Name the unknowns. If you mention AI, say "I use AI tools daily" and no more | All three of your note's priorities meet here, and it covers the JD's land, adopt, expand and renew (F2) and AI plus (F6). CASE because it is a live design problem |
| C3 | "Design a partner motion for a new product line: who the partners are, what each side gets, and how you would know it is working." | CASE | [grounded] "built a partner-level revenue model used in carrier negotiations" | Structure it: partner types, what each side gets, how you would run it, how you would measure it. The one piece of partner work your material carries is the quote, at its scope: "I built a partner-level revenue model that was used in carrier negotiations." Answer slot: expect a probe on whether you designed the motion or modelled it. If any part of how partners were engaged was yours to design, say which; if the model fed negotiations others ran, say so plainly and stay with the model | The JD requires partner-motion design, and F4 is a transferability bridge, so this is where it gets tested. CASE because it asks for a design, and JD-driven |

### D. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You haven't done classic sales-ops or quota-setting work. Why should I believe you can design a land, adopt, expand and renew motion a field org will carry?" | JD | [grounded] "No classic sales-ops or quota-setting experience."; "set annual volume targets with cross-org consensus"; "built a partner-level revenue model used in carrier negotiations" | **Highest-ROI prep in the pack.** Level 0, the limit before it is asked: "I haven't had classic sales-ops or quota-setting experience." Level 1, the hold, which is only what your quotes carry: "I set annual volume targets, with consensus across orgs" and "I built a partner-level revenue model that was used in carrier negotiations." Let Dan draw the inference. Follow-up 1, "targets aren't quotas": concede it exactly. Your material says volume targets, not quotas, so do not call them quotas, and describe what they were. Follow-up 2, "what would you get wrong first?": say the first thing you would ask Dan, which is how targets and capacity are set today. That is a plan, never a past. Do not fold on the quotes. Concede only the specific points | F7 is a stated gap against a JD whose job sits next to a Sales Strategy peer, so this arrives in some form. Skeptic because it probes the background mismatch. JD because it scores a stated requirement. Deepest rehearsal by follow-up levels |
| D2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "No classic sales-ops or quota-setting experience."; "built a partner-level revenue model used in carrier negotiations" | Pick the part your evidence is thinnest on. The pack's own reading is that F7 is the one you stated, with F4 and F1 next. Say it plainly, then a ramp plan, said as a plan. If you choose F7: "I haven't had classic sales-ops or quota-setting experience." Do not pick a strength dressed as a weakness | The standard Skeptic stem. JD because it scores self-assessment against the listed job |
| D3 | "Nine years at a large company, and now a company of about 3,000 people with new product lines to build. Why this, and why now?" | EXP | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" | The arc at its own scope: two years in strategy consulting, then nine in product strategy & ops at a large consumer-tech company. Answer slot: why leave, why here, why now are yours to say, and this pack supplies no reason. If Dan probes working with less structure, pick a time from your own material; if none comes to mind, say so plainly and say how you would handle it | Motivation consistency is the Skeptic's score, and Dan's startup chapter makes a pace probe likely (see the interviewer read). EXP because it tests the background story |

### E. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops"; "built a partner-level revenue model used in carrier negotiations"; "set annual volume targets with cross-org consensus"; "proposed a store-surface change credited with a ~$400M ARR uplift" | A 90-second arc. Two years in strategy consulting at a top firm, then nine in product strategy & ops at a large consumer-tech company. Then the three pieces of work in the quotes, one clause each, at their own scope. Close with why this role. Answer slot: that reason is yours to say, and the pack supplies none | A casual opener that sets the frame for the hour. EXP because it presents the CV. F1 to F5 supply its content |
| E2 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" | Say which tools and what for, in your own words: "I use AI tools daily." Answer slot: the JD lists AI experience as a plus, so expect a probe on whether it goes past using tools. If you have built, tested or shipped something with AI, say what and your part; if it is use, say so plainly | A casual question on a JD plus, which is still scored (F6). JD because it checks the stated plus |

### Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Sixty seconds: why you rather than someone who has run a sales-ops function?" | JD | [grounded] "No classic sales-ops or quota-setting experience."; "set annual volume targets with cross-org consensus"; "built a partner-level revenue model used in carrier negotiations" | Pause and restate. Concede first: "I haven't had classic sales-ops or quota-setting experience." Then the hold, in the quotes' own words: "I set annual volume targets, with consensus across orgs" and "I built a partner-level revenue model that was used in carrier negotiations." Tie it to what the JD asks for, which is GTM for new lines, whitespace and a partner motion. Hold through two follow-ups and concede only the specific points | A time-boxed version of D1, so the same limit gets rehearsed under pressure. JD because it scores the stated fit. See F7 |
| P2 | "That ARR number: how much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Hold on the quote: "I proposed a store-surface change credited with a ~$400M ARR uplift." The proposal is yours. Credit for the uplift is not a statement of your share. Answer slot: if you know who decided, built and measured it, say whose part was what; if you do not know, say so plainly. Never raise your share to relieve the pressure | The Pressure form of the attribution probe, targeting F1 and F2. EXP because it tests what was actually yours |

### Requirement coverage

| JD requirement | Questions |
|---|---|
| own GTM strategy for two new product lines | C1, C2, C3, D1, D2 |
| identify whitespace across land/adopt/expand/renew | A4, C2 |
| run independent analysis in SQL and Tableau | A3, A4, B4 |
| partner-motion design experience required | C3, D1 |
| strong cross-functional influence | A5, B1, B3, B4 |
| AI experience a plus | C2, E2 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Your career runs through pricing and monetization, with one early-stage chapter. What from the earlier chapters shapes how you want a new product line priced and packaged here?" | Ties to Dan's own path and moves the conversation onto familiar ground. It shows you read the person, not only the company |
| R2 | "Where should Sales Strategy and GTM for the new lines have a clear line, and where should they overlap on purpose?" | The seam question from your side. It treats Dan as a partner in designing it, not a gatekeeper |
| R3 | "What could someone new on my side do in their first month that would genuinely help your team?" | The peer reciprocity question. It signals you are thinking about Dan's load |
| R4 | "With bundling by a much larger platform vendor named as the main threat, where is it showing up in deals?" | Shows CO homework, from your research note, and gives a data-driven peer something concrete to answer |
| R5 | "Which numbers do you trust most to show whether a new product line is gaining traction, and which least?" | Speaks to Dan's self-described data-driven style, and tells you what you would be measured on |
| R6 | "How are the Compass launch and the enterprise-expansion priority changing how targets and plans are set this year?" | Learns how targets are set today, which is the ramp for F7, and reads as diligence |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has sales-ops or quota-setting experience | Negative you stated, F7 | The plain acknowledgment F7 gives: "I haven't had classic sales-ops or quota-setting experience." No slot |
| Set quotas | Inflated form of F5 | F5's quote at its own scope: "set annual volume targets with cross-org consensus". The limit is the pack's observation: your material says volume targets, not how they were allocated. D1 holds this under follow-up |
| Drove, delivered or generated the ~$400M ARR uplift | Inflated form of F1 and F2 | The quote at its own scope: "proposed a store-surface change credited with a ~$400M ARR uplift". The pack observes that your material says proposed and credited, not who decided, built or measured it |
| Designed or ran a partner motion, or negotiated with carriers | Inflated form of F4 | F4's quote at its own scope: "built a partner-level revenue model used in carrier negotiations". The pack observes that your material says a model, not a motion or the negotiations |
| Built or launched an AI product, or ran an AI GTM | Inflated form of F6 | F6's quote at its own scope: "uses AI tools daily". The pack observes that your material says use |
| Owned a go-to-market | Inflated form of F1 | F1's quote at its own scope: "product strategy & ops". The pack observes that your material does not say go-to-market |
| Has pricing experience | Inflated form of F4 | F4's quote at its own scope. The pack observes that your material says a revenue model, not pricing. The interviewer-read mirror offers the quote and leaves the link to Dan |

## Sources

**Provided documents:** your message: the JD highlights, the candidate notes (quoted in the fit snapshot as "the coach's notes"), the interviewer description, and your research note on Northwind's three priorities and the bundling threat. No dossier was present.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Northwind Data values` | unavailable | The search was refused. It would have fed a values cheat sheet and VAL questions, and settled whether a values round exists |
| 2. `Northwind Data interview process GTM strategy` | unavailable | The search was refused. It would have documented the loop beyond this session. Persona weights rest on your words about this session alone |
| 3. `Northwind Data strategy` / recent news | skipped | Your research note already supplies the three priorities and the competitive threat the CO bank uses |
| 4. `Dan Kovac Northwind Data Director Sales Strategy` | unavailable | The search was refused. It would have checked the profile summary and found public talks or writing for the interviewer read |
| 5. representative `Senior GTM Strategy Lead` JD | skipped | The JD highlights you supplied fix the fit snapshot and the JD-tagged questions |

Searches sent, each refused: "Northwind Data company values principles"; "Northwind Data interview process GTM strategy"; "Dan Kovac Northwind Data Director Sales Strategy".

## Upgrade menu

- Search access → the company's published values (a VAL bank and a values cheat sheet if a values round exists), the documented loop for any later rounds, and a check of Dan's public talks and writing for the interviewer read. A deeper research pass, offered once, would add up to 6 more searches and 2 more fetches and take several more minutes
- The full JD text → the mid-list requirements the highlights omit, and `[grounded]` rows where the pack now relies on your summary of the JD
- Your real CV, plus the artifact behind each claim (the revenue model workbook, the written proposal behind the store-surface change, a Tableau workbook or saved query) → F1 to F6 move from medium toward high, and slots can become story maps
- Your own answers to the slots in F1, F2, F4, F5 and F6 → those rows regenerate with your words in the evidence column
- The recruiter's prep email → coverage and any pre-declared deliverable, which this pack assumes from round-type priors
- The schedule of any other rounds → per-round mini-packs with their own persona weights
- A `tuesday-dossier.md` from an earlier evaluation of this role → the underwriter's own named objection and prohibited claims in place of the ones inferred here
