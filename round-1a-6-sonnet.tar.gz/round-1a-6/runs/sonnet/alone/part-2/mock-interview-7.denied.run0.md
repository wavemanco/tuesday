I'll read the reference files first.
Web search was refused, so I'm building the pack from your message and the JD alone and labeling it that way. I'm writing the pack file now.
I'll make the renames with Edit instead.
Your prep pack is saved as `/var/tmp/tuesday-measure/1a6/runs/sonnet/alone/part-2/rooms/case-7-denied-d5752893/saltmarsh-games_live-operations-producer_interview_pack.md`. It has 22 questions, and I built it for a hiring-manager round with Tobias. Your note gives his title but not whether the role reports to him.

All four web searches were refused, so nothing in it about Saltmarsh or Tobias comes from outside your message and the JD. That means no values map, no company-strategy question and no read on Tobias himself. The Sources section lists what each search would have changed.

The pack names A2 as your highest-ROI prep. It's the question about presenting the monthly retention numbers versus owning the post-event review and KPIs the JD describes. It also holds the plain acknowledgments for no team lead and no in-app purchases, with a plan after each.

Say the word and I'll play the Skeptic on A2, the question the pack names as its highest-ROI prep.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Is Tobias the person this role would report to? Did the recruiter give you any focus areas or ask you to prepare something? Would you like to paste your CV so I can check whether it carries evidence your message didn't?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview pack: Live Operations Producer, Saltmarsh Games

- Candidate: Femi
- Interviewer: Tobias Wrenfield, Head of Live Operations
- Round: one 60-minute interview, Friday. Relationship assumed: hiring manager. Your note gives his title, not whether the role reports to him, so the persona weights below rest on that assumption.

## How to use this pack

Personas describe how a question is asked. Types describe what it scores. Every question carries one of each.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows values, not generic virtue |
| EXP | Whether your own experience claims survive scrutiny and attribution |
| JD | Whether you can do the listed job, gaps included |
| CO | Knowledge of the company's strategy (none in this pack, see Sources) |
| CASE | Structure and reasoning on a live problem from the role |

- Guidance is scaffolding, not a script. Say it in your own words.
- An answer slot is an instruction for the interview, not a question for you now. It names a probe you are likely to get and gives two honest branches. Pick the branch that is true.
- Provenance labels: `[grounded]` traces to your message or the JD, `[inferred]` is this pack's derivation, `[generic]` is a role-family pattern with no claim about you or Saltmarsh.
- Every sentence the pack says about your past is a quote from your message. Nothing else is supplied.

## Prep triage

Friday is tomorrow, so this is the order. Do the first five well. Everything else is insurance.

| Order | Do this | Where |
|---|---|---|
| 1 | Rehearse the highest-ROI question aloud until it is boring | A2 |
| 2 | Say the two plain acknowledgments out loud and follow each with its plan | A3, A4 |
| 3 | Write one sentence per answer slot, in your own words | F1 to F5 |
| 4 | Time your 90-second arc | D1 |
| 5 | Talk through the two live cases without notes | B1, B2 |
| 6 | Choose three reverse questions | Reverse questions |

## Fit snapshot

No row is a gate: nothing in the JD is a term such as location, schedule or pay, and "3+ years" is experience, not a credential bar. Requirement quotes are from the JD as you pasted it. Evidence quotes are your own words.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | transferability | Your material says a weekly content-drop calendar for your main title, not a live-events calendar and not two titles. The words stay at that scope: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: expect a probe on what that calendar held week to week and who agreed it. Say what you set and what was set for you, in your own words. If part of it was not yours, say so plainly and stay with the calendar you ran |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | none given | none | [grounded] | discovery | Your material shows no work with design, art, engineering or community. The one cross-team item is the checklist QA uses (F4). The JD verb is coordinate. Answer slot: if you worked with any of those four on a drop, say which and what your part was, in your own words. If you did not, or it was not yours, say so plainly, then say how you would set up a first conversation with each, as a plan |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head" — your message | low | [inferred] | discovery | Your material shows presenting the numbers, not whether you produced them or wrote a review around them. Answer slot: say which part of those figures was yours, such as how they were counted or what went into the write-up. If someone else produced them and you presented them, say so plainly and stay with: "I presented the monthly retention numbers to the studio head." |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses" — your message | medium | [grounded] | transferability | Your material says you wrote the checklist and that QA still uses it, not how releases ran against it. The words: "I wrote the release checklist our QA team still uses." Answer slot: expect a probe on how the checklist got used and what QA did with it. Answer from what you saw. If you only wrote it and did not see how it was used, say so plainly and stay with the checklist you wrote |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio" — your message | medium | [inferred] | discovery | The quote gives years and role, and does not say whether the title was run as a live service. Answer slot: if asked, say in your own words how the game was run after launch. If it was not run as a live service, say so plainly and stay with the four years and the calendar you ran |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | none | No gap, but a line with nothing inspected behind it, so expect a probe. Lead with it in its own terms: you ran it, weekly, for the main title, for two years. A named record beats an adjective |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | presentation | The quote already speaks to the requirement in other terms. Reword only: "I presented the monthly retention numbers to the studio head." It does not say you produced or analyzed them, so do not add that. Expect a probe on how they were counted (C1) |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses" — your message | medium | [grounded] | presentation | The checklist is the written artifact in your material: "I wrote the release checklist our QA team still uses." If asked for a sample, describe it. Whether you may share it is your employer's call |
| F9 | Not in the JD: whether the role manages people. The posting says coordinate and mentions no reports — pack's reading | "Never led a team, and never worked on a game with in-app purchases" — your message | none | [grounded] | capability | A gap wording cannot close, and you stated it. Words: "I haven't led a team." Then how you would work without authority, said as a plan and never as a past |
| F10 | Familiarity with in-app purchases on mobile titles — role-family expectation, no JD line | "Never led a team, and never worked on a game with in-app purchases" — your message | none | [grounded] | capability | You stated it. Words: "I haven't worked on a game with in-app purchases." Then how you would learn it, said as a plan. This is a role-family expectation, so it raises no answer slot, and your material carries nothing adjacent to it |

## Persona table

Weights start from the relationship prior, then adjust. No public information about Tobias could be read, so nothing here is inferred about him beyond his title.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Skeptic (5 questions) | Quiet, persistent probing of the gaps: one title to two, presenting to owning, no team lead, no in-app purchases | Highest. A hiring manager derisks gaps, and you named two of them yourself. F3, F9 and F10 are where your material is thinnest | Rehearse A2 until it is boring. Use your stated words and a plan, never a stretched claim |
| B. Case / Strategist (5) | Live problems from the role: a slipped build, a metric drop, a calendar clash | Highest, with the Skeptic. A hiring manager buys capability and tends to test it on live problems from the role | Clarify, then objective, approach, metrics, risks. Think aloud. Challenge one premise politely |
| C. Data-Driven Prober (3) | Pulls on the retention numbers and how they were counted | Mid. The JD puts KPIs and retention metrics in the role, and your material names presenting retention numbers | Say what you know about how the figures were counted and say plainly what you do not |
| D. Conversational (3) | Friendly biography and "what do you play" questions | Mid. Casual openers are almost always scored, and they come first | A timed 90-second arc built from your own sentences |
| E. Pressure (2) | Time-boxed "why you" and "how much was you" | Low to mid. No signal that this is his style, but the attribution probe arrives in some form | Hold through two follow-ups, then concede specifically |
| G. Values / Behavioral (2) | Story prompts about pushing back or putting players first | Low. No loop source names a values round, and no published values could be read | Selection scaffolds that end in the honest branch |
| Peer Evaluator | Not built | Not plausible for this round as assumed. If Tobias is a peer, tell me and I will add the bank | n/a |

Loop: your own words establish one 60-minute session with Tobias. No loop source names any other round, so no values-style round is detected and there is no values cheat sheet.

## Question banks

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "This role covers the live-events calendar for two of our titles, and you ran the weekly content-drop calendar for your main title. What would you need to find out in your first two weeks?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Start from the quote at its own scope: "I ran the weekly content-drop calendar for our main title for the last two years." Then give your questions as a plan, not a past: what each title's calendar looks like today, who agrees what goes on it, which dates are fixed from outside. Answer slot: if asked what your calendar held week to week, say what you set and what was set for you; if part of it was not yours, say so plainly and stay with the calendar you ran | F1 is the widest jump between the JD and your material, so this arrives early. JD because it scores the stated calendar requirement, with F6 as the base |
| A2 | "This role owns the post-event review and the KPIs it reports. You presented the monthly retention numbers to the studio head. Who produced those numbers, and what was your part in them?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | This is the highest-ROI prep in the pack. Hold only what the quote carries: "I presented the monthly retention numbers to the studio head." Answer slot: say which part of those figures was yours, such as how they were counted or what went into the write-up, in your own words. If someone else produced them and you presented them, say so plainly and stay with presenting. Hold through two follow-ups by returning to what you presented, never by adding to it. Then give the plan: which numbers you would ask to see first for each title | F3 is the thinnest evidence on a headline responsibility and the JD names it as ownership. Expect this in some form from a hiring manager. EXP because it tests what was actually yours, JD because it presses a stated requirement |
| A3 | "You've never led a team, and this role asks you to coordinate design, art, engineering and community. What happens the first time one of them says no to your date?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases" | Hold-then-concede. Concede first, in your own stated words: "I haven't led a team." Then hold the JD's own verb, "coordinate design, art, engineering and community teams on each update". Then give the plan, not a past: ask what the no is based on, who decides, what you would record, when you would escalate. Answer slot (F2): if you worked with any of those four on a drop, say which and what your part was; if not, say so plainly and stay with the plan | F9 and F2 are the largest gap against the coordination line. Skeptics test the negative you volunteered. JD because it presses a stated requirement |
| A4 | "You haven't worked on a game with in-app purchases. If the numbers you'd report include spend from them, how would you get up to speed?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases" | Say it plainly first: "I haven't worked on a game with in-app purchases." Then a plan: ask for recent post-event reviews and read them, ask which measures the studio reports and why, ask whom to shadow. Stay with what your material carries, which is retention numbers you presented. Never imply adjacent spend experience | F10 is a gap you stated, and a mobile studio interviewer hears it early. JD because it presses the KPI requirement, and the pack could not verify what Saltmarsh reports |
| A5 | "Which part of this JD would you be weakest at on day one?" | JD | [generic] | Selection scaffold. Pick the requirement where your material is thinnest, which the fit snapshot shows is F2 or F3. Name it plainly as your weakest, then say how you would close it, as a plan. If none comes to mind, say so plainly, then name the one you would learn first and why | A standard Skeptic stem. It rewards honest self-assessment, and a prepared answer beats improvising a gap live |

### B. Case / Strategist

All of these are `[generic]` rehearsals: they are patterns for the problem, not facts about Saltmarsh.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Engineering tells you on Wednesday that Friday's event build will slip to Monday. Walk me through the next hour." | CASE | [grounded] "Wrote the release checklist our QA team still uses" | Clarify first: why it slipped, what is already announced to players, what QA has covered. Then options (slip the whole event, ship reduced, hold), who needs to hear what and when (design, art, engineering, community, QA), what you would record. Your material carries one fact here: you wrote the release checklist QA still uses. If asked what is on it, answer from your own memory, since none of its steps are in your material and this pack adds none | R4 and R2 are the JD lines this problem presses. CASE because it asks about no past |
| B2 | "A key retention metric for the last event is 20% below the one before it. Diagnose it." | CASE | [generic] | Clarify: which metric, which cohort, compared how, same length and reward? Then hypotheses (the event itself, something else that shipped, an outside release, a measurement change), what you would check and in what order, who you would ask, what you would tell the studio meanwhile. Challenge one premise politely, for example whether the two events are comparable | The persona's stock metric-drop stem, tied to R7 and R3. Tests clarify-before-structure |
| B3 | "Both of your titles want the same week for a big event. How do you decide?" | CASE | [generic] | State the objective first, then constraints (art, engineering, QA and community capacity), cost of delay for each title, a decision rule you could write down, and who you would take it to if the two sides cannot agree. Think aloud | R1 and R2 pressed together. No claim about your past |
| B4 | "The event ended Sunday night. Walk me through the post-event review you'd run and what the write-up says." | JD | [generic] | Say what questions the review answers, which numbers and compared against what, what the event changed versus what else changed, the decisions and who owns them, and a one-page readout. Present it as how you would run it | R3 as a live problem. JD because the JD names it, CASE in delivery |
| B5 | "Write me the update that goes to the four teams the day before an event ships. What's in it?" | JD | [grounded] "Wrote the release checklist our QA team still uses" | Say what readers need: what ships, when, what is different from last time, who to ask, what to do if it slips. Keep it one screen. The written artifact your material carries is the checklist: "I wrote the release checklist our QA team still uses." Describe it if asked rather than sending company documents | R8, tested by doing it. The checklist is F8's only evidence |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through the retention numbers you presented each month. How were they counted?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Say what you presented and to whom: "I presented the monthly retention numbers to the studio head." Answer slot: if you know how the figures were produced, such as what counted as retained and which players, say it in your own words and name the assumption you would defend least. If you do not know how they were counted, or someone else produced them, say so plainly and stay with presenting | F7's quote is the only retention evidence, so it is where a prober starts. EXP because it tests what was yours |
| C2 | "What retention numbers would you want in front of you the week after an event, and what would make you distrust them?" | JD | [generic] | A plan, not a past. Name the few numbers you would ask for, what each is compared against, and the checks you would run first: sample size, a build or tracking change, overlapping events. Say which assumption you would trust least | R7 asked forward, so it needs no history |
| C3 | "How much can a content calendar be credited for a retention number? Where would you be careful?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years", "Presented the monthly retention numbers to the studio head" | State your two sentences at their own scope. Then the principle: other changes, timing and cohort mix all move a number. Answer slot: if a number you presented was ever linked to a specific drop, say how that link was made; if nobody linked them, or the link was not yours, say so plainly and stay with the principle | Attribution honesty on exactly the two roles your material gives you. JD for R3 and R7, EXP for the delivery |

### D. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio", "I ran the weekly content-drop calendar for our main title for the last two years", "Wrote the release checklist our QA team still uses", "Presented the monthly retention numbers to the studio head" | A 90-second arc with four beats, each a sentence you wrote: four years as an associate producer at a puzzle-game studio; the weekly content-drop calendar for your main title for two years; the release checklist QA still uses; the monthly retention numbers to the studio head. Answer slot (F5): if asked whether the game was a live service, say how it was run after launch; if it was not, say so plainly. Then say in your own words why this role at Saltmarsh now, since your material gives no reason | The biography opener is always scored, and it is the cheapest place to land F5, F6 and F8. EXP because it is your own record |
| D2 | "What are you actually playing these days, and what do you notice about how it runs events?" | JD | [generic] | Answer from what you actually play. Name one live-events mechanic you noticed and what you would ask the team behind it. If you have not played Saltmarsh's two titles, say so and say you will: do not guess at their events | A casual question on the JD's hot topic. Install both titles tonight if you can; you will have something real to say |
| D3 | "Tell me about a content drop that went out with a problem. What happened?" | EXP | [grounded] "Wrote the release checklist our QA team still uses" | Selection scaffold. Pick a release where something was caught or missed before players saw it. It needs what was at stake, what you did, and what changed afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, which is that you wrote the release checklist QA still uses, or how you would handle it | R4 as a behavioral prompt. The checklist is the only release evidence |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why should we trust you with two live titles over someone who has led a live-ops team?" | EXP | [grounded] "Never led a team, and never worked on a game with in-app purchases", "I ran the weekly content-drop calendar for our main title for the last two years" | Pause, restate the question, then hold: "I ran the weekly content-drop calendar for our main title for the last two years." Hold through two follow-ups. Concede specifically in your stated words: "I haven't led a team." Then the plan for the first month. Do not claim the calendar equals a live-ops team lead | Pressure interviewers test hold-then-concede on the gap you stated. EXP because it tests what was yours |
| E2 | "That calendar: how much of it was actually you?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Hold: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: say which decisions were yours and which were set by others, in your own words. If you worked from a plan others made, say so plainly and stay with running the calendar. Concede one specific limit if there is one, then stop talking | The persona's attribution stem, aimed at F1 and F6 |

### G. Values / Behavioral

No published values could be read, so these use the persona's own stems.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "Presented the monthly retention numbers to the studio head" | Selection scaffold. Your material names one setting where you spoke to leadership, the monthly retention presentation. Look first at what you said there, if anything landed badly. It needs a named stake, a moment you did not soften it, and an intact relationship after. If no such time comes to mind, say so plainly, then give the nearest thing your material carries or how you would handle it | A persona stem, not a company value, so it is a rehearsal and not a prediction |
| G2 | "When did you put player experience ahead of a calendar date?" | VAL | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Selection scaffold. Pick a drop where the date and the player experience pulled apart. It needs what you weighed, who you told, and what happened. If no such time comes to mind, say so plainly, then say how you would decide, with a weekly calendar you ran as the setting | A customer-ahead-of-internal-metric stem placed on the calendar your material carries |

## Requirement coverage

| JD requirement | Questions |
|---|---|
| Plan and run the live-events calendar for two titles | A1, B3 |
| Coordinate design, art, engineering and community | A3, B1, B3 |
| Own the post-event review and the KPIs it reports | A2, B2, B4, C2 |
| Manage the release checklist with QA | B1, B5, D3 |
| 3+ years producing live-service games or apps | D1, E1 |
| Experience running a content calendar | A1, E2, G2 |
| Comfortable with player-retention metrics | C1, C2, C3 |
| Clear written communication | B5 |
| Stated gaps: no team lead, no in-app purchases | A3, A4, E1 |
| Company and strategy knowledge | none: the strategy search was refused and the pack will not write it from memory |

## Reverse questions

No interviewer profile could be read, so none is tied to Tobias's own path.

| # | Question to ask | Why it lands |
|---|---|---|
| 1 | "Which KPIs does the post-event review report today for each of the two titles, and which one do you most want this role to move or protect?" | The JD makes KPI ownership core. The answer tells you what to learn first, including where in-app purchases matter |
| 2 | "What would a good first 90 days look like — what do you want me to have learned or changed by then?" | Shows you are planning to land, and gives you the yardstick |
| 3 | "How are the two titles' calendars planned today, one shared calendar or two, and where do they collide?" | Follows your A1 and B3 prep and shows you are thinking about the real constraint |
| 4 | "How do design, art, engineering and community agree an update's scope today, and where does it go wrong most often?" | Follows your F2 prep and invites him to describe the coordination you would join |
| 5 | "What does the release checklist look like at Saltmarsh now, and how does QA work with it?" | It is your strongest artifact (F4), and it turns the conversation to your ground |
| 6 | "What would make the first post-event review I write a good one in your eyes?" | Shows you treat the written review as the product and tells you the bar for it |

## Prohibited claims

What this pack will not coach, and why.

| Not coached | Basis | Honest form |
|---|---|---|
| Has led a team | Negative you stated, F9 | "I haven't led a team." Then a plan, never a past |
| Has worked on a game with in-app purchases | Negative you stated, F10 | "I haven't worked on a game with in-app purchases." Then a plan. Nothing adjacent is claimed |
| Ran live events across two titles | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: your material says a weekly content-drop calendar for your main title, not a live-events calendar and not two titles |
| Owned the post-event review and its KPIs | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation: your material says presenting the numbers, not producing them or writing a review around them |
| Ran each release with QA | Inflated form of F4 | F4's quote at its own scope. The limit is the pack's observation: your material says you wrote the checklist, not how releases ran against it |
| Four years of live-service production | Inflated form of F5 | F5's quote at its own scope. The limit is the pack's observation: your material says associate producer at a puzzle-game studio, and does not say the title was run as a live service |

## Sources

Provided documents: the JD as pasted, and your background in your message. No dossier was present.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

Searches sent, all refused (permission not granted), so nothing came back:

- "Saltmarsh Games mobile studio values" — refused
- "Saltmarsh Games interview process Live Operations Producer" — refused
- "Saltmarsh Games strategy news" — refused
- "Tobias Wrenfield Saltmarsh Games Head of Live Operations" — refused

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | unavailable | Search refused. Would have fed a values cheat sheet and VAL questions on published values. None is built, and G1 and G2 use persona stems |
| 2. `Saltmarsh Games interview process live operations` | unavailable | Search refused. Would have set the loop and persona weights. They rest on your own words and the hiring-manager assumption |
| 3. `Saltmarsh Games strategy` / recent news | unavailable | Search refused. Would have fed CO questions and a grounding brief. Neither exists, and the CASE bank is `[generic]` |
| 4. `Tobias Wrenfield Saltmarsh Games` | unavailable | Search refused. Would have fed the interviewer read and a reverse question tied to his path. Both are absent |
| 5. representative `Live Operations Producer` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Web search permission, so the four refused targets can run → a values map, the real loop and persona weights, a CO question on current strategy, and an interviewer read with a reverse question tied to Tobias's path
- The names and a few minutes of play of the two Saltmarsh titles → D2 and B3 become specific instead of `[generic]`
- The recruiter's prep note (focus areas, or any exercise to prepare) → coverage of anything pre-declared, and a check on the hiring-manager assumption
- Your CV → F2, F3 and F5 may find evidence your message did not carry, turning `discovery` rows into `presentation` or `none`
- One sentence from you for each answer slot (F1 to F5), written in your own words → those rows regenerate with your words as evidence
- A sanitised copy or description of the release checklist or a monthly retention report, if you may share it → F4 and F7 can move from `medium` toward `high`
- A `tuesday-dossier.md` from an earlier evaluation of this role → verified evidence and prohibited claims arrive pre-graded
