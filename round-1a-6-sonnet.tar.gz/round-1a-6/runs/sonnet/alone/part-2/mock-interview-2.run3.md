I'll read the reference files the skill requires before writing anything.
Your prep pack is saved as `/var/tmp/tuesday-measure/1a6/runs/sonnet/alone/part-2/rooms/case-2-denied-8ff90597/atlas-freight_operations-manager_interview_pack.md`. It has 19 questions, a fit snapshot against each line of the JD, reverse questions, and a list of claims the pack won't coach.

- **Persona weights are flat.** I didn't know the round or the interviewer, so they rest on a generic loop pattern.
- **Company research didn't run.** My three web searches (values, interview process, recent news) were refused, so nothing in the pack is a claim about Atlas beyond your JD. The pack's Sources section says which questions this affects.
- **The question to rehearse most is A1.** It's the step from your 3 supervisors to the JD's 12, and the pack gives you the concession wording.
- **Power BI is your clearest gap.** The pack coaches you to say "I've never used Power BI" first and plainly, then give a learning plan.

Say the word and I'll play the interviewer on A1 or any other question and give feedback against the pack's guidance.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

1. Do you know who your next round is with (recruiter, hiring manager, a peer, a panel), and has the recruiter said anything about focus areas or something you must prepare? The answer reweights every question bank.
2. Do you want me to retry the company research? It needs search permission granted, and a deeper pass would be up to 6 more searches and 2 more fetches, taking several more minutes.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: atlas-freight_operations-manager_interview_pack.md -----
# Interview prep pack: Operations Manager, Atlas Freight

- Role: Operations Manager
- Company: Atlas Freight (regional logistics, 800 employees, per the JD you pasted)
- Interviewer and relationship: not known
- Built on this assumption: round type unknown, so persona weights are flat and rest on a generic loop pattern (screen, hiring manager, panel), not on Atlas Freight's own process. Company research did not run (see Sources), so nothing here is a claim about Atlas beyond the JD text.

## How to use this pack

Personas describe how a question is asked. Types describe what it scores. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Tag | Meaning |
|---|---|
| VAL | Behavioral and values: does past behavior show it |
| EXP | Experience deep-dive: does the claim survive scrutiny, and what was actually yours |
| JD | The listed requirement: can you do the job as written, gaps included |
| CO | Company knowledge: how well you know the employer |
| CASE | A live problem set in the role |

Provenance labels: `[grounded]` rests on your message or the JD, `[inferred]` is this pack's derivation from them, `[generic]` is a role-family pattern with no claim about you or Atlas. An answer slot is an instruction for the interview: answer it from your own experience, or say plainly it was not yours or never existed.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" — JD | "7 years in warehouse and distribution ops" — your message | medium | [grounded] | transferability | Your material says warehouse and distribution operations, not terminals and not several sites, and the words stay there: "I have 7 years in warehouse and distribution ops." Answer slot: the JD's four-site line makes a probe on terminal and multi-site work likely. If any of your work was terminal work, or covered more than one site, say which and what part was yours, in your own words; if it was not, say so plainly and stay with warehouse and distribution |
| F2 | "drive on-time performance and cost-per-shipment down" — JD | "cut mis-pick rate 40% by redesigning the pick path" — your message | medium | [grounded] | transferability | The quote is an error rate on a pick path, not on-time performance or cost per shipment, and the bridge stays at that scope: "I cut mis-pick rate 40% by redesigning the pick path." Answer slot: the JD names both measures, so expect a probe on either. If you have tracked or changed either, say which and what you did, in your own words; if you have not, or it was not yours, say so plainly and stay with the pick-path work |
| F3 | "lead a team of 12 supervisors" — JD | "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | The number stays on the noun it counts: three supervisors against the JD's twelve. Words: "I'm currently a senior shift manager over 3 supervisors." Answer slot: if you have ever led more than three supervisors at once, say when and how many; if not, say so plainly and stay with your current three. A plan for twelve is said as a plan, never as a past |
| F4 | "build reporting in Excel/Power BI" — JD | "solid Excel" — your message | low | [inferred] | discovery | A self-rating that does not say reporting, so this is a clarify note and not a story. Answer slot: the JD asks to build reporting, so expect a probe on what you built. If you have built reports in Excel, say what each showed and who used it, in your own words; if your Excel use was something other than reporting, say so plainly and say what it was |
| F5 | "build reporting in Excel/Power BI" — JD | "never used Power BI" — your message | none | [grounded] | capability | A gap wording cannot close, and you said so. Words: "I've never used Power BI." Then how you would learn it and what you would build first, said as a plan and never as a past. The JD's wording pairs the two tools and does not show how the team weighs them, so a reverse question asks |
| F6 | "5+ years operations leadership required" — JD | "7 years in warehouse and distribution ops" — your message; "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | discovery | Your material gives seven years in operations and a current supervisory role, and does not show how many of the seven were spent leading. Answer slot: expect a probe on the count. Give the number of years you led people, in your own terms, and what you led; if it is fewer than five, say so plainly and stay with what your current role covers |
| F7 | "Lean/Six Sigma a plus" — JD | "green belt certified" — your message | medium | [grounded] | none | No gap on the Six Sigma side, but a certification line with nothing inspected behind it, so expect a probe. Lead with it in its own terms: "I'm green belt certified." Lean is not in your material. Answer slot: if any of your work used the green-belt method, say which tools and where, in your own words; if the certification stood apart from your work, say so plainly |

None of the JD's requirements is a gate in the sense of a term you either meet or do not: the five-plus years line is a length-of-experience requirement, graded as F6.

## Persona table

Weights are flat on the loop, because the round and the interviewer are unknown, and adjusted only by what your own material exposes. Depth follows that order.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy | Bank |
|---|---|---|---|---|
| Skeptic | Quiet, persistent probing of scope and gaps | Highest: F1, F3, F5 and F6 are where the material is thinnest against the JD | Rehearse the single most predictable objection (A1) until it is boring; bridge only from what your quotes carry | A |
| Case / Strategist | Live operational problems set in the role | High: the JD is an operating role with on-time and cost measures, and a case needs no claim about your past | Clarify, define the measure, segment, hypothesise, check data, decide, name risks; think aloud | B |
| Data-Driven Prober | Line-by-line on your numbers | Medium: the 40% is a headline figure and probers go to it first | Know how the figure was counted, or say plainly you do not; name the assumption you would defend least | C |
| Conversational / Rapport Builder | Open biography and motivation questions | Medium: appears in screens and openers of most loops, and is still scored | A 90-second arc built only from your own quoted sentences (D1) | D |
| Peer Evaluator | Seam-splitting between sites or teams | Lower: depends on whether a peer is in the loop, which is unknown | Propose seam principles, not a claimed knowledge of their seam; say what you bring them | E |
| Pressure | Interrupts and time-boxes | Lower: probable only in a senior or stress-style round, which is unknown | Pause, restate, hold through two follow-ups, concede one thing specifically | P |
| Values / Behavioral | Scenarios mapped to published values | Lower: no values-style round is detected, since no loop source was read and the generic fallback does not assume one. VAL questions sit in E | Selection scaffolds ending in an honest branch | none |

Highest-ROI prep in this pack: A1, the step from three supervisors to twelve. F3 and F1 meet there, it will be asked in some form, and a rehearsed answer that holds only what your quote carries and concedes the arithmetic is the one thing that changes the interview.

## Question banks

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "This role leads twelve supervisors. Your background shows three. What changes at twelve?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" | The deepest rehearsal here. Hold only what the quote carries: "I'm currently a senior shift manager over 3 supervisors." Concede the arithmetic aloud before they push: twelve is more than the three you lead now. Answer slot: if you have ever led more than three supervisors at once, say when and how many; if not, say so plainly and stay with your current three. Then give your plan for twelve, labelled as a plan: what you would want to know about each supervisor and site before changing anything, and where your own time would go, in your own words. Follow-up 1, "so you haven't done it": restate the concession in one sentence and add no experience. Follow-up 2, "what worries you most?": name one worry about the jump, plainly | F3 is the evidence and the likeliest place to be probed; JD because it scores the stated team size |
| A2 | "You have seven years in warehouse and distribution. This job is terminal operations across four sites. What's different?" | JD | [grounded] "7 years in warehouse and distribution ops" | Hold: "I have 7 years in warehouse and distribution ops." Answer slot: if any of your work was terminal work, or covered more than one site, say which and what part was yours; if it was not, say so plainly and stay with warehouse and distribution. Then, as a plan: what you would want to learn about each terminal first | F1 is the evidence for the terminal and four-site requirement; JD because it scores the listed scope |
| A3 | "The job builds reporting in Excel and Power BI. Where are you on Power BI?" | JD | [grounded] "never used Power BI" | Say it first and plainly: "I've never used Power BI." Do not qualify it. Then a plan, labelled as a plan: how you would learn it and what you would build first. If they say that is a problem, concede it once and repeat the plan; do not add a past you did not state. Close by asking how the team weighs the two tools (reverse question 1) | F5 is a stated negative with a plain acknowledgment as its honest form; JD because Power BI is named in the requirement |
| A4 | "The role asks for five-plus years of operations leadership. How many of your seven were leading people?" | JD | [grounded] "7 years in warehouse and distribution ops", "currently a senior shift manager over 3 supervisors" | Answer slot: give the number of years you led people, in your own terms, and what you led in them. If it is fewer than five, say so plainly and stay with what your current role covers: "I'm currently a senior shift manager over 3 supervisors." Do not round up | F6 is a discovery row, so the count is not in the material and the probe is cheap for the interviewer; JD because it scores the stated years |
| A5 | "The role builds reporting in Excel and Power BI. What have you built in Excel?" | JD | [inferred] "solid Excel" | F4 is low confidence, so this is a clarify note and not a story. Say "solid Excel" at its own scope. Answer slot: if you have built reports, say what each showed and who used it, in your own words; if your use was something other than reporting, say so plainly and say what it was | F4 is where the JD's reporting line meets a self-rating; JD because it scores the tool requirement |

### B. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "On-time performance at one of your four terminals has slipped over three weeks. Walk me through your first day." | CASE | [generic] | The question needs no claim about your past, so the guidance makes none. Clarify first: how on-time is defined and measured, at what point in the shipment. Then segment: shift, lane, customer, inbound versus outbound. State two or three hypotheses, say what data you would pull and what you would do while you wait, then name the risk of acting on a guess | The JD's on-time measure (F2's requirement) asked as a decision; `[generic]` because it is a pattern for the problem, not a fact about Atlas |
| B2 | "Cost per shipment is up six percent across the network and volume is flat. Where do you look?" | CASE | [generic] | No claim about your past. Say what is inside the figure first: the cost pool on top, shipment count below, and who owns each part. Then split the movement: labour hours and overtime, error and rework, damage and claims, equipment, mix of shipments. Say what you would rule out cheaply first | The JD's cost measure (F2's requirement); CASE because the structure is scored, not the answer |
| B3 | "Peak hits and two of your four sites are short of people. How do you allocate?" | CASE | [generic] "ran the site's peak-season surge plan two years running" | Structure it: what you would ask first (which sites, how short, for how long, which shifts), the rule you would decide by, the options and their costs, and what you would watch afterwards. If you reach for your own plan, stay at the quote: "I ran the site's peak-season surge plan two years running." Answer slot: if the plan set how people were allocated, say what the rule was; if allocation was decided elsewhere, or the plan covered other things, say so plainly and tell this as a plan | The surge plan in your material meets the JD's multi-site scope here; CASE with EXP flavour |
| B4 | "You inherit twelve supervisors you have never met. What do you do in your first thirty days?" | CASE | [generic] | A plan, so no claim about your past. Say what you would want to learn before changing anything: each site's on-time and cost picture, what each supervisor is strong at, what is already working. Then how you would set expectations and where your own time would go. Name one thing you would deliberately not change yet | F3's span as a decision rather than a record; CASE because it is a live problem from the JD |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the mis-pick rate was measured." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | State the sentence at its own scope: "I cut mis-pick rate 40% by redesigning the pick path." Then the four slots a figure raises, each in your own words: how the rate was counted, or say plainly you do not know how it was counted; what the 40% is sensitive to; the assumption behind it you would defend least; and which part was yours. Name the weakest assumption before they do | F2 is the headline number, and probers go there first; EXP because it tests whether the claim survives |
| C2 | "You redesigned the pick path. What did you actually do, and what was somebody else's?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Hold the sentence: you cut mis-pick rate 40% by redesigning the pick path. Answer slot: say which part of the redesign was yours and who else took part, in your own words; if it was a team effort, say so plainly. Do not describe a step you did not take | F2's attribution probe, rehearsed before it arrives |
| C3 | "Tell me about the peak-season surge plan you ran, two years running." | EXP | [grounded] "ran the site's peak-season surge plan two years running" | Beats the quote carries: you ran it, it was the site's, and it was two years running; tell them in your own words. Answer slot: the JD asks for on-time and cost results, so expect a probe on how you knew the plan worked. If you tracked results, say which measure and what it showed; if you did not, say so plainly and describe the plan itself | The surge plan is your second headline claim; EXP because it tests what was actually yours |

### D. Conversational / Rapport Builder

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey. How did you get to where you are?" | EXP | [grounded] "7 years in warehouse and distribution ops", "currently a senior shift manager over 3 supervisors", "cut mis-pick rate 40% by redesigning the pick path", "ran the site's peak-season surge plan two years running", "green belt certified" | A 90-second arc, in that order, each beat a clause the quotes state: seven years in warehouse and distribution, a current senior shift manager role over three supervisors, then the pick-path redesign, the surge plan and the certification. Answer slot: why this move is your own reason and is not in the material; give it plainly | Casual openers are still scored; EXP because it is your own story, told short |
| D2 | "What do you know about Atlas Freight, and what draws you to this role?" | CO | [grounded] | Say only what the JD gives you: regional logistics, 800 employees, four sites, twelve supervisors. This pack has no research on Atlas, so anything beyond that should come from what you read yourself before the interview, and say where you read it. Answer slot: your reason for wanting this role is yours to give; do not borrow one | `[grounded]` on the JD text only; CO because it tests homework depth, and the honest cost of no research is a shorter answer |
| D3 | "Lean and Six Sigma are a plus for us. Where does your green belt show up in how you work?" | JD | [grounded] "green belt certified" | Lead in its own terms: "I'm green belt certified." Answer slot: if any of your work used the green-belt method, say which tools and where, in your own words; if the certification stood apart from your work, say so plainly. Lean is not in your material, so do not claim it | F7 is the evidence for the Lean and Six Sigma line; JD because it scores the plus |

### E. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "If two of your sites both needed the same extra people on the same night, how would we settle it between us?" | CASE | [generic] | Propose seam principles and not a claimed knowledge of their seam: a shared priority rule agreed in advance, who decides, when it escalates. Reciprocity: say what you would bring their side, not only what you need | The JD's multi-site scope (F1's requirement) in collegial packaging; CASE because it is a live problem |
| E2 | "How do you handle credit when work spans teams?" | VAL | [generic] | A selection scaffold: pick a time work spanned teams where you can say which part was yours and which was not. It needs named others, a named part, and the relationship intact at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | A standard peer probe; VAL because it scores behaviour, though no published values are in hand |

### P. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Sixty seconds: why you over someone who already leads twelve supervisors?" | JD | [grounded] "7 years in warehouse and distribution ops", "cut mis-pick rate 40% by redesigning the pick path" | Pause and restate the question. Hold only what the quotes carry: seven years in warehouse and distribution ops, and cutting mis-pick rate 40% by redesigning the pick path. Concede one thing specifically: they would have led twelve, and you currently lead three. Hold through two follow-ups; do not fold the core claim and do not add experience | F3's span under time pressure; JD because it scores the stated team size |
| P2 | "That 40%: how much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Hold: you cut mis-pick rate 40% by redesigning the pick path. Answer slot: say which part was yours and who else was involved; if you do not know how the figure was counted, say so plainly. Concede that specifically, then return to the sentence | F2's attribution probe in its pressure form |

### Requirement coverage

| JD requirement | Questions |
|---|---|
| "Own daily terminal operations across 4 sites" | A2, B1, B3, E1 |
| "drive on-time performance and cost-per-shipment down" | B1, B2 |
| "lead a team of 12 supervisors" | A1, B4, P1 |
| "build reporting in Excel/Power BI" | A3, A5 |
| "5+ years operations leadership required" | A4 |
| "Lean/Six Sigma a plus" | D3 |

Your headline figure, the 40%, is covered by C1, C2 and P2.

If your next round turns out to be a recruiter screen, a logistics bank (pay, notice, location, reason for leaving) would be added; your material says nothing on those yet.

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "How do you weigh Excel and Power BI in the reporting this role builds, and what would you want built first?" | Turns A3 from a gap into a forward question, and shows you read the JD's pairing of the two tools |
| 2 | "How is on-time performance measured across the four sites today, and is it measured the same way at each?" | Carries the habit B1 rehearses: define the measure before acting on it |
| 3 | "What does the team of twelve look like today: how is it split across the four sites, and where is it strongest?" | Meets A1 with a question about the real team, so the twelve stops being only your gap |
| 4 | "What would you want to see done by ninety days?" | Asks for the interviewer's own success criteria, and gives you something concrete to rehearse against |
| 5 | "Where does someone coming from warehouse and distribution usually need the most ramp-up for terminal work?" | Takes A2's probe into a conversation, and says you expect a ramp |
| 6 | "What is the operational problem across the terminals you most want this role to start on?" | Moves the conversation to the work itself, and gives B1 and B2 a real case to anchor to |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Owns or ran terminal operations across multiple sites | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation, not words for you: the material says warehouse and distribution operations, not terminals or several sites. A2's slot stays inside that scope |
| Led a team of twelve supervisors | Inflated form of F3 | F3's quote: "I'm currently a senior shift manager over 3 supervisors." A1's slot asks only whether you have led more than three at once |
| Drove on-time performance or cost per shipment down | Inflated form of F2 | F2's quote at its own scope: a mis-pick rate cut by a pick-path redesign. B1 and B2 make no claim about your past |
| Built reporting or dashboards in Excel | Inflated form of F4 | "solid Excel" at its own scope. A5's slot asks only what, if anything, you built |
| Has Power BI experience | Negative you stated, F5 | The plain acknowledgment: "I've never used Power BI." No slot |
| Has five or more years of operations leadership | Inflated form of F6 | F6's quotes at their own scope: seven years in operations and a current supervisory role. A4's slot asks for your own count |
| Led Six Sigma or Lean projects, or has Lean experience | Inflated form of F7 | "I'm green belt certified." The limit is the pack's observation: the material gives a certification, not projects, and does not mention Lean |

## Sources

Provided documents: the JD text and your background summary, both in your message. No dossier was consumed. No CV document was provided; your background was a summary in your message, and every candidate quote above comes from it.

Searches sent (all three refused, so nothing came back and nothing from them is used):

- "Atlas Freight regional logistics company values" — refused
- "Atlas Freight interview process operations manager" — refused
- "Atlas Freight regional logistics terminals news strategy" — refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Atlas Freight values` | unavailable | Every call was refused. It would have fed a values cheat sheet and VAL questions with published value names |
| 2. `Atlas Freight interview process operations manager` | unavailable | Every call was refused. It would have named the loop, so persona weights would rest on the real rounds and not the generic fallback |
| 3. `Atlas Freight strategy` / recent news | unavailable | Every call was refused. It would have grounded a CO or CASE question in current priorities; B1 to B4 and D2 stay generic or JD-only |
| 4. `{interviewer name} Atlas Freight` | n/a | No interviewer name was given, so there was no query to form |
| 5. representative `Operations Manager` JD | skipped | The JD you supplied fixes the fit snapshot and every JD-tagged question |

## Upgrade menu

- Round type and who you are meeting (recruiter, hiring manager, peer, skip-level, panel) → persona weights recomputed and banks resized; a logistics bank added if it is a recruiter screen
- The interviewer's name and title → an interviewer read and a reverse question tied to their own path
- Any note from the recruiter on focus areas or a pre-declared deliverable (a presentation, a case, a take-home) → a graded-deliverable build section
- Search permission for company research → the values, loop structure and recent news rows run, so D2 and the CASE bank can be grounded; a deeper pass (up to 6 more searches and 2 more fetches, several more minutes) would add a strategy brief and role-family loop reports
- Your CV text → the evidence column uses your own CV wording in place of the message summary, and F1, F3 and F6 are re-graded against it
- The certificate and issuing body for your green belt → F7 moves from medium toward high
- A sample report or workbook you built in Excel → F4 moves from low and A5 becomes a story, not a clarify note
- Your answers to the slots in A1, A2, A4, A5, B3, C1 to C3 and D3 → rows F1 to F7 are regenerated from what you say outside a drill
- A `tuesday-dossier.md` from a prior evidence review → verified evidence and its prohibited claims replace the list built here
