"""Re-check the fix round's 1,220 saved runs with a tree's checks, two ways, and compare with recheck3.

usage: python3 recheck_both.py <tree> <out>
(1) direct: output_checks.run_checks as qrule/recheck.py calls it;
(2) check_run: run_fixtures.check_run on a copy of each run's meta and body (the driver's own path).
Writes nothing into the saved sets. No model is called.
"""
import collections
import glob
import json
import os
import shutil
import sys
from pathlib import Path

TREE = os.path.abspath(sys.argv[1])
OUT = Path(sys.argv[2])
R = '/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round'
R3 = '/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/qrule/recheck3'
os.environ.pop("TUESDAY_SCAN_ACCOUNT_EMAIL", None)
sys.path.insert(0, TREE + '/evals')
import run_fixtures as rf, output_checks as oc  # noqa
from fixture_clauses import dated  # noqa
assert os.path.dirname(os.path.dirname(os.path.abspath(rf.__file__))) == TREE
assert os.path.dirname(os.path.dirname(os.path.abspath(oc.__file__))) == TREE
SK = {1: 'job-underwriter', 2: 'mock-interview', 3: 'resume-tailor'}
cases = {s: {c['id']: c for c in rf.cases_for(s, [])} for s in SK.values()}
n = 0
direct_vs_r3 = []
checkrun_vs_direct = []
unit_changes = collections.Counter()
other_fields = []
for m in ['haiku', 'sonnet', 'opus']:
    for a in ['tuesday', 'alone']:
        for p, s in SK.items():
            d = f'{R}/{m}/{a}/part-{p}'
            o = OUT / 'direct' / m / a / f'part-{p}'
            o.mkdir(parents=True, exist_ok=True)
            cr = OUT / 'checkrun' / m / a / f'part-{p}'
            cr.mkdir(parents=True, exist_ok=True)
            line = oc.declared_watch_out((rf.REPO / 'skills' / s / 'SKILL.md').read_text())
            for mf in sorted(glob.glob(d + '/*.meta.json')):
                n += 1
                meta = json.load(open(mf))
                stem = meta['stem']
                case = dated(cases[s][meta['id']], rf.run_date(meta))
                status, reasons = rf.harness_status(meta)
                body = open(f'{d}/{stem}.md').read()
                rec = oc.run_checks(case, meta['mode'], body, meta.get('research_log'), status, reasons,
                                    watch_out=line or '')
                rec = {'skill': s, 'id': case['id'], 'run': meta['run'], 'stem': stem, **rec}
                (o / f'{stem}.checks.json').write_text(json.dumps(rec, indent=1))
                old = json.load(open(f'{R3}/{m}/{a}/part-{p}/{stem}.checks.json'))
                if rec != old:
                    direct_vs_r3.append(f'{m}/{a}/part-{p}/{stem}')
                    key = lambda x: json.dumps(x, sort_keys=True)
                    oldc = {key(c) for c in old.get('checks', [])}
                    newc = {key(c) for c in rec.get('checks', [])}
                    for c in oldc - newc:
                        c = json.loads(c)
                        unit_changes[(m, a, stem, c['check'], c.get('target'), 'removed', c['verdict'])] += 1
                    for c in newc - oldc:
                        c = json.loads(c)
                        unit_changes[(m, a, stem, c['check'], c.get('target'), 'added', c['verdict'])] += 1
                    others = [k for k in set(rec) | set(old) if k != 'checks' and rec.get(k) != old.get(k)]
                    if others:
                        other_fields.append((m, a, stem, others))
                # the driver's own path, on copies
                shutil.copy2(mf, cr / Path(mf).name)
                shutil.copy2(f'{d}/{stem}.md', cr / f'{stem}.md')
                rec2 = rf.check_run(s, cases[s][meta['id']], cr, meta['run'], meta['mode'])
                if rec2 != rec:
                    checkrun_vs_direct.append(f'{m}/{a}/part-{p}/{stem}')
print('runs read:', n)
print('direct differs from recheck3:', len(direct_vs_r3), direct_vs_r3)
print('check_run differs from direct:', len(checkrun_vs_direct), checkrun_vs_direct[:10])
for k, v in sorted(unit_changes.items()):
    print('  ', k, v)
print('non-check fields changed:', other_fields)
