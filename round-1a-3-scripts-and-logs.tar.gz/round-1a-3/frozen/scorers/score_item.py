#!/usr/bin/env python3
"""The carried item's reading for round 1a: the sentence after the fit ledger, iteration 2.

Reads the candidate's saved runs with the tree's own loader and measure (evals/compare_arms.py:
load, text_change_measures, fisher), kept to the fix round's eight job-underwriter rooms, both
installs pooled per model, and decides against the fix round's baseline as scored, which it
recomputes from the saved fix-round sets (all their runs; Haiku's ten per cell) and checks
against the figures the plan freezes.

    python3 -I score_item.py TREE FIXROUND_ROUND_DIR [MODEL=TUESDAY_DIR,ALONE_DIR ...]
    python3 -I score_item.py TREE FIXROUND_ROUND_DIR --self-test

With no candidate folders it prints the baseline alone. Offline; calls no model.
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

tree, rnd = Path(sys.argv[1]), Path(sys.argv[2])
sys.path.insert(0, str(tree / "evals"))
import compare_arms as ca  # noqa: E402

# The fix round's eight job-underwriter rooms, as its runs record them (id, mode).
ROOMS = frozenset({(1, "denied"), (2, "denied"), (3, "denied"), (4, "canned"), (4, "denied"),
                   (5, "canned"), (5, "denied"), (6, "canned")})
H1 = "ledger_sentence: sentences after the ledger above one"
CLAIMS = "ledger_sentence: failed for a set claim (any reason but a second sentence)"
PRESENT = "ledger_present: passing, of job-underwriter's valid runs"
FORM = "ledger_sentence_form: passing, the list form or no sentence (reported)"
# Frozen in docs/roadmap-now-l1-plan.md ("Carried into 1a"): the fix round on 0.2.0, all runs as scored.
FROZEN = {"sonnet": {H1: (0, 79), PRESENT: (79, 80), CLAIMS: (1, 79)},
          "opus": {H1: (11, 79), PRESENT: (79, 80), CLAIMS: (3, 79)},
          "haiku": {H1: (60, 82), PRESENT: (82, 160), CLAIMS: (6, 82)}}
P = 0.01
CLOSE = 0.10          # Opus only; Sonnet is already closed and Haiku is read for worse only


def eight_rooms(folder: Path) -> tuple[list[dict], list[str]]:
    """The folder's job-underwriter runs in the eight rooms, and every job-underwriter room it
    holds outside them (reported, never counted: 1a's new rooms land here)."""
    runs = [r for r in ca.load(folder) if r.get("meta_read") and r["skill"] == "job-underwriter"]
    kept = [r for r in runs if (r["id"], r["mode"]) in ROOMS]
    other = sorted({f"{r['id']}.{r['mode']}" for r in runs if (r["id"], r["mode"]) not in ROOMS})
    return kept, other


def measures(folders: tuple[Path, Path]) -> tuple[dict, list[str]]:
    runs, other = [], []
    for f in folders:
        kept, out = eight_rooms(f)
        runs += kept
        other += out
    return dict(ca.text_change_measures(runs)), sorted(set(other))


def rises(now, base) -> bool:
    return now[1] > 0 and now[0] * base[1] > base[0] * now[1] and ca.fisher(*now, *base) < P


def falls(now, base) -> bool:
    return now[1] > 0 and now[0] * base[1] < base[0] * now[1] and ca.fisher(*now, *base) < P


def decide(model: str, now: dict, base: dict) -> dict:
    """One model's reading: the share, both guards, and the item's outcome for that model."""
    share = now[H1]
    g_present = not falls(now[PRESENT], base[PRESENT])
    g_claims = not rises(now[CLAIMS], base[CLAIMS])
    worse = rises(share, base[H1]) or not g_present or not g_claims
    out = {"share": "%d/%d" % share, "baseline": "%d/%d" % base[H1],
           "p_vs_baseline": ca.fisher(*share, *base[H1]),
           "guard_ledger_present": {"now": "%d/%d" % now[PRESENT], "base": "%d/%d" % base[PRESENT], "holds": g_present},
           "guard_set_claims": {"now": "%d/%d" % now[CLAIMS], "base": "%d/%d" % base[CLAIMS], "holds": g_claims},
           "list_form_reported": "%d/%d" % now[FORM] if FORM in now else None, "worse": worse}
    if model == "opus":
        out["closed"] = bool(share[1]) and share[0] <= CLOSE * share[1] and g_present and g_claims
    return out


def baseline() -> dict:
    base = {}
    for model in FROZEN:
        got, other = measures((rnd / model / "tuesday" / "part-1", rnd / model / "alone" / "part-1"))
        for label, frozen in FROZEN[model].items():
            if got[label] != frozen:
                raise SystemExit(f"{model}: {label} reads {got[label]} from the saved fix-round runs, "
                                 f"not the frozen {frozen}: stop, the baseline does not reproduce")
        if other:
            raise SystemExit(f"{model}: the fix round's sets hold job-underwriter rooms outside the eight: {other}")
        base[model] = got
    return base


def verdict(per_model: dict) -> dict:
    worse = any(v["worse"] for v in per_model.values())
    closed = per_model.get("opus", {}).get("closed", False)
    return {"miss_of_1a": worse,
            "opus": "closed" if closed and not worse else ("worse" if worse else "not closed: iteration 2 spent; "
                                                                                 "to the owner under the two-iteration rule")}


def self_test(base: dict) -> None:
    def check(name, got, want):
        print(("  ok   " if got == want else "  FAIL ") + f"{name}: {got!r}" + ("" if got == want else f", wanted {want!r}"))
        if got != want:
            raise SystemExit(1)
    b = FROZEN
    for share, closed in (((7, 79), True), ((8, 79), False), ((8, 80), True), ((0, 79), True)):
        now = {H1: share, PRESENT: (79, 80), CLAIMS: (3, 79)}
        check(f"opus {share} closes", decide("opus", now, b["opus"])["closed"], closed)
    for share, worse in (((25, 79), False), ((26, 79), True)):
        check(f"opus {share} worse", decide("opus", {H1: share, PRESENT: (79, 80), CLAIMS: (3, 79)}, b["opus"])["worse"], worse)
    for share, worse in (((7, 79), False), ((8, 79), True)):
        check(f"sonnet {share} worse", decide("sonnet", {H1: share, PRESENT: (79, 80), CLAIMS: (1, 79)}, b["sonnet"])["worse"], worse)
    for share, worse in (((38, 41), False), ((39, 41), True)):
        check(f"haiku {share} worse", decide("haiku", {H1: share, PRESENT: (41, 80), CLAIMS: (6, 41)}, b["haiku"])["worse"], worse)
    for present, holds in (((71, 80), True), ((70, 80), False)):
        r = decide("opus", {H1: (5, 79), PRESENT: present, CLAIMS: (3, 79)}, b["opus"])
        check(f"opus ledger_present {present} holds", r["guard_ledger_present"]["holds"], holds)
        check(f"opus ledger_present {present} closes", r["closed"], holds)
    for claims, holds in (((13, 79), True), ((14, 79), False)):
        r = decide("opus", {H1: (5, 79), PRESENT: (79, 80), CLAIMS: claims}, b["opus"])
        check(f"opus set claims {claims} hold", r["guard_set_claims"]["holds"], holds)
    for present, holds in (((27, 80), True), ((26, 80), False)):
        check(f"haiku ledger_present {present} holds",
              decide("haiku", {H1: (30, 41), PRESENT: present, CLAIMS: (3, 41)}, b["haiku"])["guard_ledger_present"]["holds"], holds)
    # The fix round read as its own candidate: nothing moves, so nothing is worse and Opus stays open.
    as_candidate = {m: decide(m, base[m], FROZEN[m]) for m in FROZEN}
    check("fix round as candidate: verdict", verdict(as_candidate),
          {"miss_of_1a": False, "opus": "not closed: iteration 2 spent; to the owner under the two-iteration rule"})
    print("self-test passed")


if __name__ == "__main__":
    base = baseline()
    print("baseline reproduced from the saved fix-round runs:",
          json.dumps({m: {k[:34]: "%d/%d" % v for k, v in base[m].items() if k in (H1, PRESENT, CLAIMS, FORM)}
                      for m in base}))
    if "--self-test" in sys.argv[3:]:
        self_test(base)
        sys.exit(0)
    per_model, rooms_left_out = {}, {}
    for arg in sys.argv[3:]:
        model, dirs = arg.split("=", 1)
        tuesday, alone = (Path(p) for p in dirs.split(","))
        now, other = measures((tuesday, alone))
        rooms_left_out[model] = other
        per_model[model] = decide(model, now, FROZEN[model])
    if per_model:
        print(json.dumps({"per_model": per_model, "rooms_left_out": rooms_left_out, **verdict(per_model)}, indent=2))
