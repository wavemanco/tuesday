#!/bin/bash
# Round 1a-3's chain (owner, 20 November: "Full round, stop if a gate misses"): Sonnet starts only after
# Haiku's step status ends "done"; any other end (stopped, refused, crashed) leaves Sonnet unstarted.
K=/var/tmp/tuesday-measure/1a3/frozen/kit; ST=/var/tmp/tuesday-measure/1a3/logs/status; C=/var/tmp/tuesday-measure/1a3/logs
while :; do
  last=$(tail -1 "$ST/haiku-quality.status" 2>/dev/null)
  case "$last" in
    *" done") break;;
    *stopped*|*STOPPED*|*REFUSED*|*CRASHED*) echo "$(date -u +%FT%TZ) haiku ended '$last'; Sonnet not started"; exit 0;;
  esac
  sleep 60
done
echo "$(date -u +%FT%TZ) haiku done; starting sonnet"
"$K/run_step.sh" sonnet quality > "$C/sonnet-step.console.txt" 2>&1
echo "$(date -u +%FT%TZ) sonnet run_step rc=$?"
