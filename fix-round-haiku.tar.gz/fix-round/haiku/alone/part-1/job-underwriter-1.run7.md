**Yes, apply, on conditions. Status: `conditional_go`.** On the must-haves you're a direct fit, and the main open items are whether the posting is live and how much HIPAA exposure the role carries.

**Fit ledger.**

- `must_have`: direct: R1, R2, R3, R4, R6 · adjacent: R5
- `important`: adjacent: R7 · unclear: R8
- `preferred`: adjacent: R9a · absent: R9b

R5 (`medium`): the candidate has built governed dashboards, but not evidenced owning a metrics layer's definitions. R9a (`medium`): consent and PII work is a real bridge, but it isn't HIPAA. R9b (`medium`): no healthcare data, which the JD marks as a plus.

**Opportunity ledger.** The posting reads well on its own: a defined remit with explicit mentoring and clinician-partnership duties (RR3). What I could not check is that the employer and posting exist as described (RR1), and the regulated-data scope is unstated (RR2).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the live posting is confirmed on Harborlight's own careers page (RR1); (2) RR2 answered: clinical or PHI data access, and who owns HIPAA sign-off; (3) the HIPAA gap is stated plainly, never bridged with the GDPR/CCPA work.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, digital-health scale-up, ~400 people, Series C, care-navigation app | `[grounded]` your JD text; not verified externally |
| Mandate | Own product analytics: metrics layer, A/B design and analysis, self-serve Looker, PM and clinician partnership, mentor two juniors | `[grounded]` JD |
| Scope read | A senior IC-plus-mentor role with a defined analytics remit; the metrics-layer ownership and the clinician work are the broad parts | `[inferred]` from the responsibility count against the stated team |
| Market calibration | Not run: no role-family band was obtained | — |
| Unknowns | Live posting status; salary; contract basis; PHI access; reporting line | — |
| Contradictions | None visible in the text you gave me | `[grounded]` JD text |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | Six years at one consumer-subscription company | `[grounded]` your CV | none |
| R2 | Expert SQL | must_have | direct | medium | none | Daily SQL on Snowflake; "expert" is the JD's word, so the CV should show the work, not the adjective | `[grounded]` your CV | sample query or dashboard (upgrade menu) |
| R3 | Experiment design at scale | must_have | direct | medium | none | 30+ tests a year, including the pricing test behind the 11% retention lift | `[grounded]` your CV | confirm your role in the pricing test's design |
| R4 | Looker or similar BI | must_have | direct | medium | none | Built the instance from scratch; 40+ governed dashboards | `[grounded]` your CV | none |
| R5 | Define and maintain the metrics layer | must_have | adjacent | medium | transferability | Governed dashboards and the monthly metrics memo show definitional work; a shared semantic layer is not claimed | `[inferred]` from R4 and the memo | see G1 |
| R6 | Written communication with non-technical stakeholders | must_have | direct | medium | none | Monthly exec-read memo; monthly presentations to the VP Product | `[grounded]` your CV | none |
| R7 | Partner with PMs and clinicians into roadmap decisions | important | adjacent | medium | transferability | PM partnership is direct; clinicians are absent | `[inferred]` from the PM work described | see G2 |
| R8 | Mentor two junior analysts | important | unclear | low | discovery | Nothing in the CV either way | `[grounded]` CV silence | see Q2 |
| R9a | Privacy-regulated data work | preferred | adjacent | medium | transferability | GDPR/CCPA consumer PII and a consent-state model; a different regime from HIPAA | `[grounded]` your CV | state the regime difference up front |
| R9b | Healthcare data (HIPAA, PHI) | preferred | absent | medium | capability | No healthcare experience | `[grounded]` your CV | closure path: none in the short term; name it plainly |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Metrics-layer ownership (R5) | transferability | Governed dashboards and definitions, no semantic layer named | Owning definitions is the first duty in the JD | Metric-definition docs, a metric-dictionary PR, a canonical revenue or retention definition you set | A sanitized metric spec | `[inferred]` |
| G2 | Clinician partnership (R7) | transferability | PM partnership only | Clinician input is a stated part of the roadmap work | Any work with ops, support, CX, or dietitians | A short example of a non-PM stakeholder decision | `[inferred]` |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer and posting not verified | risk_signal | medium | "digital-health scale-up (~400 people, Series C)" | Web search was denied, so nothing was attributed; this is not a finding that the company is fake | `[generic]` for small-company footprints; search not run | Can you point me at the live posting on your careers site, and who is the hiring manager? | unresolved |
| RR2 | Regulated-data scope unstated | unknown | — | "healthcare data experience (HIPAA) a plus" | The role may touch PHI with HIPAA sign-off owned elsewhere, or it may be analytics on de-identified data | `[inferred]` from the JD's HIPAA line against its silence on PHI access | Will this role query PHI directly, and who owns HIPAA sign-off? | unresolved |
| RR3 | Scope is explicit | positive_signal | — | "define and maintain the metrics layer… mentor two junior analysts" | Defined remit and a mentoring duty; success is easier to measure | `[grounded]` JD | Which metric is this role accountable for in year one? | noted |
| RR4 | Salary not in the text you gave me | unknown | — | (none in the text) | The posting may withhold it, or it sits outside the excerpt | `[grounded]` absence in your paste | What is the budgeted base for this role? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead the CV's first bullet with the experimentation program (30+ tests a year, the 11% pricing result) | Strongest direct evidence for the top of the JD | `[grounded]` your CV | pending your approval |
| E2 | Describe the consent-state model as "designed a consent-state model for the warehouse under GDPR and CCPA" | Accurate scope; avoids implying HIPAA alignment | `[grounded]` your CV | pending your approval |
| P1 | In the interview, name the HIPAA gap before they ask | An honest gap stated early reads better than one found later | `[generic]` interview pattern | pending your approval |
| Q1 | Ask RR1–RR4 verbatim in the first conversation | The register doubles as interview prep | `[grounded]` register | pending your approval |

Each row is a proposal. The CV edits (E1, E2) need your approval before anything is changed.

## Evidence status

Verified: none yet. Every claim above is your own statement from the CV and the JD text. Nothing has been checked against an artifact.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Three searches were sent for the company and posting; web search permission was denied in this session, so no attributable results came back. This leaves RR1 open |
| 2. Role-family sweep | unavailable | Would have set the market band for R1–R4 seniority and the RR4 salary calibration; not run |
| 3. Hiring manager's public footprint | n/a | No name was given |

## Upgrade menu

- Allow web search, and the company and role-family checks run: RR1 and the market band close.
- A redacted sample dashboard or a memo excerpt → R2, R4 and R6 move from `medium` to `high`.
- A metric-definition document → R5 moves to direct.
- The budgeted base salary → RR4 closes against the band.
- The hiring manager's name → the application plan leads with the verified story for that reader.

If you'd like a reusable record of this assessment, I can emit a `tuesday-dossier.md` from it.

**Questions**

- **RR1:** Can you paste the live posting link from Harborlight's careers site?
- **R8:** Have you mentored or managed junior analysts before, and at what scale?
- **R5:** Have you owned metric definitions (a canonical metric spec or dictionary), not just dashboards?

Answer in prose, or skip any of them.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.