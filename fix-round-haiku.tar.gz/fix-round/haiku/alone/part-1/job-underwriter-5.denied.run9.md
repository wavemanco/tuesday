**Yes, it's worth applying, once the posting checks out.** Status: `conditional_go`. Your core stack matches the JD, and the disclosed pay sits in the market band. The open items are whether this posting is real and live, and BigQuery, which you haven't used.

**Fit ledger.**
- `hard_gate` — unclear: R1 (remote-US or Denver location), R2 (pay floor against $148,000–$166,000)
- `must_have` — direct: R3 (5+ years data engineering), R4 (strong SQL and Python), R5 (dbt and a cloud warehouse), R6 (orchestration with Airflow or similar), R7 (data quality testing)
- `important` — adjacent: R8 (BigQuery warehouse); unclear: R9 (ingestion from app and CRM), R10 (data contracts analysts depend on)

R8 is adjacent (Snowflake and dbt carry over, BigQuery doesn't). R9 and R10 are unclear because your intake didn't mention them.

**Opportunity ledger.** The posting is specific and pays inside the market band. Its main weakness is that it can't yet be verified: the employer-not-established entry (RR1) is the one that caps the decision at `conditional_go`. Unknowns on hiring manager, equity and scope are listed in the register.

- **Hard gates:** none failed; unconfirmed: R1 (remote-US or Denver location), R2 (pay floor against $148,000–$166,000); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **Conditions for go:** (1) RR1 clears: the role appears on Pellucid's own careers page or comes from a pellucidlearning.com address; (2) R1 and R2 are checked against your location and pay floor; (3) R9 and R10 are answered as owned work, not adjacent work; (4) you're comfortable being the BigQuery learner, stated as such.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 states; founded 2016, Denver; 264 employees; Series C, $52M, February 2026 | `[grounded]` your pasted About page (not checked online) |
| Mandate | Build and run ingestion (app and CRM), a dbt warehouse in BigQuery, and analyst data contracts for reporting | `[grounded]` JD |
| Scope read | Owns one domain's pipelines end to end, plausibly without direct reports | `[inferred]` from "build and run" against the JD's silence on team size |
| Market calibration | Senior DE at Series B–D: median $151,000, IQR $139,000–$163,500; the posted range's midpoint ($157,000) sits in the upper half of that IQR | `[grounded]` the figures from the recruiter's Datawright report, not independently checked; `[generic]` the reading |
| Working pattern | Remote (US) or Denver office | `[grounded]` JD |
| Unknowns | Hiring manager, equity terms, whether a platform team exists, BigQuery depth expected | — |
| Contradictions | None visible between the JD and the pasted company page | `[grounded]` the two pastes |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver location | hard_gate | unclear | — | hard_gate | Your location isn't in the material | `[grounded]` JD | Q3 |
| R2 | Pay within $148,000–$166,000 | hard_gate | unclear | — | hard_gate | Your floor wasn't given; the range sits around the market median | `[grounded]` JD | Q3 |
| R3 | 5+ years data engineering | must_have | direct | medium | none | Six years at one payroll company; unprobed intake, so medium at most | `[grounded]` your intake | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | Daily use of both | `[grounded]` your intake | none |
| R5 | dbt and a cloud warehouse | must_have | direct | medium | none | dbt project of about 180 models on Snowflake | `[grounded]` your intake | none |
| R6 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow in production | `[grounded]` your intake | none |
| R7 | Data quality testing | must_have | direct | medium | none | Set up the Great Expectations suite | `[grounded]` your intake | none |
| R8 | BigQuery warehouse (in the responsibilities) | important | adjacent | medium | transferability | Warehouse and dbt skills carry over; BigQuery itself is unused, and its tooling is not in your evidence | `[grounded]` your intake; `[generic]` that tooling differs across warehouses | Q2 |
| R9 | Ingestion from app and CRM | important | unclear | low | discovery | Not in your intake; may be inside your pipeline work | `[grounded]` JD silence on your side | Q2 |
| R10 | Data contracts analysts depend on | important | unclear | low | discovery | Quality testing is adjacent; contracts are not mentioned | `[grounded]` JD | Q2 |

Confidence stays at `medium` even for claims that sound specific, because nothing has been inspected or probed yet.

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R8) | transferability | Snowflake and dbt experience; no BigQuery | Named in the JD's core mandate, so an interviewer will probe it | Any warehouse migration, cost tuning, or partitioning work you did on Snowflake | A small dbt project on the BigQuery sandbox (free tier) that you build and can walk through | `[generic]` that BigQuery questions are likely in interviews for this role |
| G2 | Ingestion and data contracts (R9, R10) | discovery | Neither appears in your intake | Two of the five responsibilities | Source-system ingestion, CDC or API pulls, schema-change handling, producer-consumer agreements | Pipeline design doc, a contract or schema spec, an ingestion DAG | `[grounded]` JD |

The question each row implies is in the closing block, tagged with its row ID.

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Build and run the pipelines behind our tutoring platform's reporting" | The posting may be stale or not hosted on the company's own site; the employer itself is probably real | `[generic]` pattern for a company of this size, not a claim about Pellucid | Is this role posted on your careers site, and who would I be interviewing with? | unresolved |
| RR2 | Hiring manager not named | unknown | — | (posting names none) | Ownership and reporting line are unclear | `[grounded]` posting silence | Who would I report to, and what does the team look like? | unresolved |
| RR3 | Equity unstated | unknown | — | "plus equity" | Value cannot be assessed | `[grounded]` JD | What equity is offered, as shares or percent, with what vesting? | unresolved |
| RR4 | Salary disclosed, in band | positive_signal | — | "$148,000–$166,000" | Pay transparency and an in-band range | `[grounded]` JD; band from the recruiter's report | — | noted |
| RR5 | Platform team or solo ownership unclear | unknown | — | "Build and run the pipelines" | The role may own the whole reporting stack alone | `[inferred]` from "build and run" against silence on team size | Is there a data platform team, or do I own the reporting pipeline end to end? | unresolved |

RR1 is what caps the decision. Its verification question is addressed to the employer, not to you.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Confirm the posting is live on pellucidlearning.com, or get the recruiter's email, before spending effort | RR1 | `[generic]` pattern for companies this size | pending your approval |
| P2 | Lead with the 180-model dbt project and its test suite; name Snowflake, don't imply BigQuery | R5, R7, R8 | `[grounded]` your intake | pending your approval |
| P3 | Describe the BigQuery gap as "Snowflake-native, BigQuery not yet used", and do not claim BigQuery experience | R8 | `[grounded]` your intake | pending your approval |
| P4 | Build the BigQuery sandbox project (G1) before the first technical round | R8 | `[generic]` interview pattern | pending your approval |

## Evidence status

Verified: none yet. Your intake claims are unprobed.

Research tier: L1 — searches 3 of 5, fetches 1 of 2; the calls were refused, so no page was read.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | The one fetch of pellucidlearning.com/careers/senior-data-engineer was refused. It would have checked that the company exists as described and the posting is live (RR1) |
| 2. Role-family sweep | unavailable | Three searches were refused. They would have checked the recruiter's pay figures against a second source |
| 3. Hiring manager's public footprint | n/a | No name was given |

Web checks were refused in this session, so nothing about Pellucid or the market was verified online. The company facts and pay band rest on your pasted material.

## Upgrade menu

- A link to the live posting, or the recruiter's email address → RR1 closes or escalates, and the decision can move to `go` or `no_go`.
- A short description of your location and pay floor → R1 and R2 close.
- Any ingestion or data-contract work you owned, described concretely → R9 and R10 move from unclear to adjacent or direct.
- A BigQuery sandbox project you can walk through → R8 moves from adjacent toward direct.
- A pipeline design doc or a redacted schema spec → R3 to R7 move from medium to high.

I can also draft the sandbox project outline or the verification message to the recruiter, pending your approval.

If you want the full dossier file, say so and I'll generate `tuesday-dossier.md`.

1. Ingestion and contracts: have you personally built ingestion from an application database or a CRM, and owned a data contract that analysts relied on? What did you own, and what broke?
2. BigQuery: have you used it in any form, such as a sandbox or a migration? If not, is a sandbox project you can walk through a credible answer for you?
3. Constraints: what are your location and pay floor? The posting is remote-US or Denver, at $148,000–$166,000.

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.