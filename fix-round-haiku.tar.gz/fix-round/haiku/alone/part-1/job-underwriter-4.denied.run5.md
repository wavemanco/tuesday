**Decision: conditional go.** Apply, once you've confirmed the role is live and that it's fully remote from the UK. Your evidence matches the stated requirements closely. The one real gap is pet insurance, and the JD doesn't list it as a requirement.

Research tier: L0. I haven't searched for Brindlemoor, so the employer is unverified and the market and pay points below are not checked.

## Role reality

- **Role:** Senior Pricing Analyst, Brindlemoor (insurtech), pet insurance. Hiring manager: Odile Varga, Director of Pricing.
- **Scope:** Owns pricing analytics: build and monitor rating models, design and read price tests, and turn results into recommendations for underwriting and product.
- **Not stated:** people management (the JD asks for ownership, not managers), salary, team size, company stage, and whether the role is UK-resident only.
- **Market calibration:** [generic] A senior IC pricing analyst at an insurtech usually sits in a small team with broad scope. Pay and team maturity vary a lot, and I haven't checked either for this company.

## Evidence map

Fit comes from your account, which I'm treating as [grounded] and as stated, with no portfolio or code to check.

| # | Priority | Requirement | Fit | Confidence | Gap | Evidence |
|---|---|---|---|---|---|---|
| 1 | must | 4+ years pricing or actuarial analytics | strong | high | none | 5 years at a UK motor insurer, last 2 as senior analyst |
| 2 | must | Strong SQL and Python | strong | high | none | Daily use. No code sample reviewed. |
| 3 | must | GLM experience | strong | high | none | Built and maintained the young-driver GLM. Pet risk structure is untested. |
| 4 | must | Presenting to underwriting or actuarial leads | strong | high | none | Quarterly pricing review to the head of underwriting |
| 5 | must | Build and monitor rating models | partial | medium | presentation | Build and maintenance shown. Monitoring cadence not described. |
| 6 | must | Design and read price tests | strong | high | none | 14 tests run last year with underwriting |
| 7 | must | Recommendations for underwriting and product | partial | medium | presentation | Underwriting recommendations shown. Product-side recommendations not described. |
| 8 | preferred | Insurance experience | strong | high | none | Motor insurance |
| 9 | implied | Pet insurance product knowledge | gap | n/a | discovery | No pet experience. The whole product is pet, so expect a ramp-up. |
| 10 | hard_gate | Fully remote, UK | unknown | n/a | hard_gate | Your location isn't stated. No gate failed on the evidence given. |

Hard-gates line: Remote UK is unconfirmed. Nothing failed on the evidence given.

## Gap recovery queue

- **Row 9, pet insurance.** This is the main gap. It's a domain gap, not a capability gap. Close it with any pet-adjacent work, such as a pet dataset, a vet-claims project, or reading on pet pricing. Your GLM and test work transfers, but pet risk drivers (species, breed, age, cover level, and wellness add-ons) need to be learned.
- **Row 7, product recommendations.** Close it with one example where you took a test or model result to a product decision, even if the decision was made by someone else.

## Opportunity risk register

- **Unverified employer (medium).** I haven't confirmed that Brindlemoor exists as described. Check the live posting and the company's own careers page before you apply.
- **Pay unknown (medium).** The JD gives no salary, so it can't be checked against your floor.
- **Small-team and pet-domain ramp (low to medium).** [generic] Insurtech pricing teams are often small and early. That means more ownership but less infrastructure.

## Application plan

- **Lead with** the GLM you built and maintained, and the 14 price tests run with underwriting. These are your strongest, most verifiable proof, and they match the core of the role.
- **Frame pet as transfer, not experience.** For example: "The GLM and test methods I used on motor transfer to pet. I'd need to learn the pet risk drivers, and I'd start with those."
- **Don't claim** pet experience, management experience, or product ownership. The evidence doesn't support any of them.
- **Before applying:** confirm the posting is live and the company is real, and confirm you're eligible to work remotely from the UK.

## Evidence status

Research tier: L0 — no searches

| Target | Status | Reason |
|---|---|---|
| 1. Company official site and careers page | skipped | L0: no research run |
| 2. Role-family sweep (scope, title, pay) | skipped | L0: no research run |
| 3. Hiring manager's public footprint | skipped | L0: no research run |

## Upgrade menu

- **Live posting link or careers page** — confirms the employer exists and the role is open. Unlocks the failed-attribution check.
- **Salary band** — checks pay against your floor.
- **L1 research (up to 5 searches and 2 fetches)** — checks the company, the role-family pay norms, and the hiring manager's public background.
- **Any pet-related work or reading** — moves row 9 from gap to partial.
- **A product-side recommendation example** — moves row 7 from partial to strong.

Dossier offer: I can write this up as a `tuesday-dossier.md` file if you'd like to keep it or carry it into later interview prep.

Questions:
1. (Row 10) Are you resident in the UK, and does "fully remote (UK)" mean UK residency is required?
2. (Row 9) Have you done any pet-related work, or any claims or pricing work outside motor?
3. (Row 7) Do you have a product-side recommendation you can describe, even briefly?

Response mode: answer each question in a line or two, or skip any you'd rather not answer.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.