## Decision snapshot

**Decision: `conditional_go`.** You're not wasting your time. Apply, but only after you've decided how you'll handle the years requirement, because it is the one line that can screen you out before anyone reads your story.

**Fit ledger** (from the evidence map below)
- **Strong:** technical fluency (must); stakeholder management across engineering and customers (must); launch coordination, in analogue (preferred)
- **Partial:** shipped API or platform products (must); roadmap ownership and partner discovery (must); 3+ years of PM experience (must)
- **Unknown:** agile delivery (must); sales coordination (must); adoption metrics (preferred)

**Hard gates:** None stated in the JD. Your non-negotiables (pay, location, schedule) weren't provided, so those checks are unknown.

**Confidence:** Medium. This rests on your CV and the JD alone. Nothing about Quartzline has been verified.

## Role reality

- This is a first-PM-type scope: one person owning the roadmap for a partner-facing API platform, directing two engineering squads. That is a step up from influencing a roadmap. `[inferred]`
- Market calibration: "3+ years PM" on a role that owns a roadmap with two squads is a standard screen. Recruiters often filter on it before reading further. `[generic]`
- Compensation is not stated. The posting withholds it, which is worth asking about before you invest in the process. `[grounded]`
- The company is unverified. I ran no searches, so I can't confirm it exists at ~150 people or Series B. `[grounded]` from the JD only.

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Evidence |
|---|---|---|---|---|---|---|
| 1 | 3+ years PM experience | Must | Partial | Low, as written | Transferability | No PM title. Adjacent: requirements documents, roadmap-input sessions, coordinating PMs on custom builds `[grounded]` |
| 2 | Shipped API or platform products | Must | Partial | Medium | Transferability | Took 30+ client integrations of the REST APIs to go-live. Did not own the platform's roadmap or release decisions `[grounded]` |
| 3 | Technical fluency, API docs, schemas | Must | Strong | High | None | Postman, SQL, OpenAPI, integration architecture `[grounded]`. Check with a schema-review sample |
| 4 | Stakeholder management: eng, sales, customers | Must | Strong for eng and customers; partial for sales | Medium | Discovery (sales) | Coordinated vendor engineers, client engineers and PMs. Sales work not stated `[grounded]` |
| 5 | Agile delivery | Must | Unknown | Low | Discovery | Not on the CV |
| 6 | Roadmap ownership and partner discovery | Must | Partial | Medium | Transferability | Ran quarterly client input sessions that fed product. Did not set priorities `[grounded]` |
| 7 | Adoption metrics | Preferred | Unknown | Low | Discovery | Not stated. The triage-tool note is unconfirmed, so I did not count it |
| 8 | Launch coordination with sales and support | Preferred | Strong, analogue | Medium | None | UAT and go-lives across 30+ integrations `[grounded]`. Support handoff not stated |

## Gap recovery queue

- **Row 1 (years):** Only real PM time closes this. A reframe doesn't substitute for it.
- **Row 2 (ownership):** One shipped feature or endpoint where you scoped it, chose it, and saw it adopted.
- **Row 5 (agile):** Which process your teams ran and what your role was in it.
- **Row 7 (metrics):** Any usage or adoption number from the triage tool or the playbook.
- **Row 4 (sales):** Whether you took part in deal scoping or pricing conversations.

## Opportunity risk register

- **Years screen (high, class: mismatch):** The must-have may filter you out before a human reads your CV. Apply anyway if you accept that. Otherwise, target roles that don't say "3+ years."
- **Unverified employer (medium, standing):** Resolve it with the live posting link or the company's careers page.
- **Scope step-up (medium):** Owning two squads as a first PM is a large jump from implementation work.
- **Reframing risk (high if mishandled):** "Ran roadmap-input sessions" is accurate. "Drove the roadmap" or "product experience" is not. Don't let any resume line imply PM ownership you didn't have.

## Application plan

- **Lead with:** You've taken 30+ enterprise API integrations to go-live, so you know what partners actually need. The playbook is evidence of discovery work.
- **Don't claim:** a PM title, product ownership, PM years, or adoption metrics you can't document.
- **Proposed resume line** (`resume_edits_pending_approval`; nothing is final until you approve it): "Led 30+ enterprise REST API integrations end to end, from scoping workshops and requirements documents through UAT and go-live; ran quarterly client roadmap-input sessions that fed product planning."
- **Build one PM-shaped proof point in the next few weeks.** Examples: a platform-integration spec with an adoption plan, or the triage tool written up with real numbers if the outcome holds up.
- **Target broadly:** Technical PM, Platform or Integrations PM, Solutions PM, and first-PM roles at API companies. This role is a stretch on years and a fit on the rest.

**Research tier: L0, no searches.**

| Target | Status | Reason |
|---|---|---|
| (1) Company site and careers page | skipped | L0 selected; no research run |
| (2) Role-family sweep | skipped | L0 selected; no research run |
| (3) Hiring-manager footprint | n/a | No hiring manager named |

If you want, I can save this as `tuesday-dossier.md` so a later rehearsal session can pick up the gaps.

## Upgrade menu

- **Live posting link or careers page:** Resolves whether the company is real as described and whether the years line is firm.
- **Triage tool details:** Adoption numbers, your decisions, and who used it. This would move rows 2 and 7.
- **Agile and sales details from your CV:** This would move rows 4 and 5.
- **Pay floor, location, and schedule constraints:** This lets me run the hard-gate checks.
- **L1 research** (up to 5 searches and 2 fetches): Company stage and a role-family pay check.

## Questions

1. **Triage tool:** Did you decide what got built and in what order? Do you have any usage or adoption number from it?
2. **Agile:** Which process did your teams run (sprints, Jira, standups), and what was your role in it?
3. **Sales:** Did you join deal scoping or pricing conversations with account executives, or was that outside your lane?

Answer any of these, or say skip. Skipping counts as an answer.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.