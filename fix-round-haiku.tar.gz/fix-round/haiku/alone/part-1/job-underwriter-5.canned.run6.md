**Yes, worth applying, on conditions: `conditional_go`.** The fit on the stated requirements is strong. The main gap is the BigQuery stack, which is transferable. The employer is only partly verified, and the scope of the seat is unclear.

## Decision snapshot

**Fit ledger.**

- `hard_gate`: unclear: R1 (remote US or Denver location), R2 (salary band $148,000–$166,000 plus equity)
- `must_have`: direct: R3 (5+ years data engineering), R4 (strong SQL and Python), R5 (dbt), R6 (a cloud warehouse), R8 (orchestration with Airflow or similar), R9 (data quality testing)
- `important`: adjacent: R7 (BigQuery-based warehouse); unclear: R10 (ingestion from app and CRM), R11 (data contracts analysts depend on)

R7 (`medium`) is a bridge from Snowflake, with BigQuery never used. R10 and R11 are unclear with `low` confidence, because your background does not mention them.

**Opportunity ledger.** Sound on the posting's own terms: the stated pay sits inside the market interquartile range (RR5), and the posting is live on the company's careers page (RR6). The employer is not yet independently verified (RR1, `severity: medium`), the seat's scope may be broad for one person (RR2, `severity: medium`), and the hiring manager and equity are unstated (RR3, RR4).

- **Hard gates:** none failed; unconfirmed: R1 (remote US or Denver location), R2 (salary band $148,000–$166,000 plus equity); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **What would change this:**
  1. An independent source confirms Pellucid as described (RR1). The posting itself is already verified on the company's own domain.
  2. The seat is confirmed as owning ingestion, warehouse and contracts, or it is confirmed as sitting inside a platform team with clear boundaries (RR2).
  3. Your location and pay floor are confirmed against R1 and R2. A failed gate would move the status to `no_go`.
  4. The BigQuery gap is stated as a limit in every application line, not as experience (R7).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online K-12 tutoring in 31 states, founded 2016, Denver, 264 employees, Series C ($52M, February 2026) | `[grounded]` your about-page text; not independently verified (RR1) |
| Mandate | Build and run ingestion from the app and CRM, a dbt-modelled BigQuery warehouse, and analyst data contracts | `[grounded]` JD |
| Working pattern | Remote (US) or Denver office | `[grounded]` JD |
| Scope read | Three domains for one senior seat; the usual senior scope in the pay report is ownership of one domain's pipelines | `[inferred]` from the JD's three-domain scope; `[generic]` for the one-domain norm |
| Market calibration | Senior Data Engineer at Series B–D: base median $151,000, IQR $139,000–$163,500 (US, n=2,310). The posting's midpoint of $157,000 sits above the median and inside the IQR | `[generic]` Datawright 2026 report you supplied; the comparison is `[inferred]` from the posting's figures |
| Unknowns | Reporting line and team size, equity size and vesting, ownership of ingestion and contracts, your location and pay floor | — |
| Contradictions | None between the JD and the careers page | `[grounded]` careers page fetched |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | Your location is not in the inputs. | `[grounded]` JD; no candidate statement | Confirm location (Q2) |
| R2 | Salary $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | Your pay floor is not in the inputs. The range sits inside the market IQR (RR5). | `[grounded]` JD; `[generic]` band | Confirm floor (Q2) |
| R3 | 5+ years data engineering | must_have | direct | medium | none | Six years at a B2B payroll company. Self-reported, no inspectable artifact yet. | `[grounded]` your background | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | Used daily. Self-reported. | `[grounded]` your background | none |
| R5 | dbt | must_have | direct | medium | none | Built a dbt project of about 180 models on Snowflake. | `[grounded]` your background | Excerpt would raise to high |
| R6 | A cloud warehouse | must_have | direct | medium | none | Snowflake meets the requirement as written. The role's warehouse is BigQuery (R7). | `[grounded]` your background, JD | none |
| R7 | BigQuery-based warehouse | important | adjacent | medium | transferability | Snowflake warehouse work carries over. BigQuery never used. BigQuery-specific cost and table-design patterns not exercised. | `[grounded]` Snowflake claim; `[generic]` that these differ across platforms | G1 |
| R8 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow used for orchestration. | `[grounded]` your background | none |
| R9 | Data quality testing | must_have | direct | medium | none | Set up a Great Expectations suite. | `[grounded]` your background | Suite excerpt would raise to high |
| R10 | Ingestion from app and CRM | important | unclear | low | discovery | JD responsibility. Your background does not name app or CRM sources. | `[grounded]` JD; background silence | G2 |
| R11 | Data contracts analysts depend on | important | unclear | low | discovery | Test-suite work is adjacent. No contract ownership stated. | `[grounded]` JD; background silence | G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery warehouse (R7, important) | transferability | Snowflake dbt and warehouse work; no BigQuery | The stack change is the most visible gap on the posting. A stated limit keeps it from being read as experience. | Any warehouse migration or cross-platform dbt work | A BigQuery sandbox project or course completion | `[inferred]` bridge from the Snowflake work; `[generic]` that BigQuery differs in cost and table design |
| G2 | Ingestion from app and CRM (R10, important) | discovery | Your background mentions a payroll platform, not connectors | A responsibility the role leads with | Connectors or syncs you built or ran into a warehouse | An ingestion design doc or DAG excerpt | `[grounded]` JD and background silence |
| G3 | Data contracts (R11, important) | discovery | Test suite is adjacent; no contract ownership | Named as something analysts depend on | Schema agreements, data-owner sign-offs, breaking-change handling | A contract or schema doc | `[grounded]` JD and background silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from independent sources | risk_signal | medium | "runs live online tutoring for K-12 schools in 31 US states" | Entity may be real but thinly indexed; the posting itself is live on the company's domain | `[generic]` pattern for companies of this size, not a claim about this one | "Which public announcement can I cite for the Series C and the 31-state footprint, and who would I interview with?" | unresolved |
| RR2 | One seat owns ingestion, warehouse and contracts | risk_signal | medium | "Build and run the pipelines behind our tutoring platform's reporting" | Scope may exceed one domain, or the seat may sit inside a larger team | `[inferred]` from the JD's three-domain scope; `[generic]` for the one-domain norm | "Does this seat own all three areas outright, or do you have a platform team sharing them?" | unresolved |
| RR3 | No hiring manager or reporting line named | unknown | — | (posting names no manager) | Reporting line unknown | `[grounded]` posting omits it | "Who would this role report to, and who would I work with day to day?" | unresolved |
| RR4 | Equity unquantified | unknown | — | "plus equity" | Equity size and vesting unknown | `[grounded]` JD | "What equity is attached to the role, and what is the vesting schedule?" | unresolved |
| RR5 | Stated salary within market band | positive_signal | — | "$148,000–$166,000" | Pay at or above the median at the midpoint | `[grounded]` JD figure; `[generic]` band from the pay report | "Is this range set for this level, and how is equity sized?" | noted |
| RR6 | Posting live on company careers page | positive_signal | — | "Accepting applications" | Posting is current | `[grounded]` fetched page | "What is the next step after applying?" | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead your summary with the 180-model dbt project and the Great Expectations suite | Puts your two strongest must-have matches first | `[grounded]` R5, R9 | pending your approval |
| E2 | State the BigQuery bridge as: built on Snowflake, BigQuery not yet used, limit is BigQuery-specific cost and table design | Names the limit in the first sentence, not in an interview | `[grounded]` R7; `[generic]` BigQuery differences | pending your approval |
| A1 | Ask the recruiter for the hiring manager's name and the equity terms before investing in the loop | Closes RR1, RR3, RR4 | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Your background is self-report until you answer a probe.

Research tier: L1 — searches 1 of 5, fetches 1 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Pellucid Learning live online tutoring K-12 Denver" (no results). Fetched pellucidlearning.com/careers/senior-data-engineer: posting live, "Accepting applications", text matches the JD. Moved RR1 (no independent footprint) and RR6 |
| 2. Role-family sweep | skipped | The Datawright 2026 report you supplied already fixes the band for this title, level and stage. Inputs fix the output, so no search was sent |
| 3. Hiring manager's public footprint | n/a | No name given |

## Dossier offer

If you want this kept, I can write it out as a `tuesday-dossier.md` file.

## Upgrade menu

- The hiring manager's name → RR3 closes, and the scope read in RR2 can be checked against a named person's public background.
- An independent source for Pellucid's Series C or its 31-state footprint (a funding announcement, a state contract listing) → RR1 reduces.
- An excerpt of the dbt project or the Great Expectations suite, with names removed → R5 and R9 move from `medium` to `high`.
- Your location and pay floor → R1 and R2 move from unclear to met or failed.
- A deeper research pass on Pellucid (funding and leadership changes, hiring patterns, public employee reports; up to 5 more searches and 2 more fetches). Say the word and it runs.

## Questions

**G2 (R10)** — Have you built ingestion from an app database or a CRM (for example, Salesforce or HubSpot) into a warehouse? Which connectors, who owned them, and how did you know they were complete?

**G3 (R11)** — Did you own a data contract or schema agreement that analysts or product teams depended on? What did it cover, and who enforced it?

**R1 and R2** — Are you based in the US, and is $148,000 at the bottom of the range workable for you?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.