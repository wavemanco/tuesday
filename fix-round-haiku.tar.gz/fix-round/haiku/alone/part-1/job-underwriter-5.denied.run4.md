**Decision snapshot: conditional_go.** Yes, it's worth applying, after two checks. Your stated experience matches most of the posting. The open items are whether the employer and posting are real, and two hard gates I can't assess yet.

**Fit ledger** (Fit is per requirement; Confidence is `medium` for CV-only claims. `high` needs a verifiable artifact.)
- **Must-have, met:** 5+ years data engineering, SQL and Python, dbt with a cloud warehouse, Airflow orchestration, data quality testing.
- **Implied, partial:** BigQuery (named in the description, not in the requirements).
- **Implied, unknown:** ingestion from an app and CRM; data contracts.
- **Hard gates, unknown:** location and work authorization (remote US or Denver); your pay floor.

**Hard-gates line:** Location and US work authorization: unknown. Pay floor: unknown.

**Research tier: L1 — searches 2 of 5, fetches 2 of 2.** The calls were refused with a permission error, so no web research ran. Everything below comes from the documents you pasted.

**Evidence status**

| # | Target | Status | Reason |
|---|---|---|---|
| 1 | Company site and careers page | unavailable | Fetch permission denied |
| 2 | Role-family pay sweep | unavailable | Search permission denied |
| 3 | Hiring manager footprint | n/a | No name in the posting |

**Role reality**
- The posting asks for "dbt and a cloud warehouse." It names BigQuery only in the responsibilities. Read literally, your Snowflake work meets the requirement. The BigQuery reference is an implied gap. `[grounded]`
- Scope (owning one domain's pipelines, no direct reports) matches the typical Senior scope in the pay report. `[generic]`
- The posted band is $148k–$166k, midpoint $157k. `[grounded]` The pay report's Senior median is $151k and its interquartile range is $139k–$163.5k. The posted band sits inside that range, with the top end above it. `[generic]` The report came from your recruiter and I could not check it independently.
- The company facts you pasted (Series C, $52M, 264 employees, 31 states) are consistent with each other, but I could not verify them. `[grounded]` to your paste only.

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Evidence |
|---|---|---|---|---|---|---|
| 1 | 5+ years data engineering | Must | Met | medium | none | 6 years, B2B payroll |
| 2 | Strong SQL and Python | Must | Met | medium | none | Daily use |
| 3 | dbt and a cloud warehouse | Must | Met | medium | none | dbt project, about 180 models, on Snowflake |
| 4 | Airflow or similar orchestration | Must | Met | medium | none | Airflow in production |
| 5 | Data quality testing | Must | Met | medium | none | Set up a Great Expectations suite |
| 6 | BigQuery (from description) | Implied | Partial | low | transferability | None; dbt and SQL transfer, BigQuery specifics don't |
| 7 | App and CRM ingestion (responsibility) | Implied | Unknown | — | discovery | Not in CV |
| 8 | Data contracts for analysts (responsibility) | Implied | Unknown | — | discovery | Not in CV |
| 9 | Pay floor vs $148k–$166k | Hard gate | Unknown | — | hard_gate | No floor stated |
| 10 | Remote US or Denver | Hard gate | Unknown | — | hard_gate | Location and authorization not stated |

**Gap recovery queue**
- **Row 6, BigQuery:** Closes with any BigQuery exposure, such as a sandbox project or a GCP-based dbt job. Without it, say what transfers and leave BigQuery out of your claims.
- **Row 7, ingestion:** Closes with an example of building ingestion from an operational app or CRM, even if the source was a payroll system.
- **Row 8, data contracts:** Closes with an example of a schema or SLA agreement between producers and downstream analysts. If you have not done this, don't claim it.
- **Rows 9 and 10:** Hard gates. Closed by your answers to the questions below.

**Opportunity risk register**
- **Employer and posting unverified (medium).** I could not confirm the employer or the live posting. This is why the decision is conditional. Resolve it with the live posting link or the recruiter's email domain.
- **Pay report provenance (low).** The Senior median came from a report the recruiter sent. Check it against a public source before using it in a negotiation.
- **No hiring manager named (low).** Common, but it means no direct route in.
- **Equity unquantified (low).** Ask for the grant size and vesting terms before weighing the offer.

**Application plan**
- Lead with the dbt, Snowflake, Airflow and Great Expectations work, with the scale stated as you did: "built a dbt project of about 180 models on Snowflake."
- Name BigQuery as adjacent experience, not as a skill, unless you have used it.
- Don't claim data contracts or app and CRM ingestion unless you have done them. If you have, give the specifics in the application.
- Apply only after the employer check passes.

**Dossier offer:** If you want, I can save this assessment as a `tuesday-dossier.md` file that mock-interview can pick up later.

**Upgrade menu**
- **Live posting link or recruiter email domain:** Resolves the employer risk. If confirmed, the decision moves to `go`, pending your answers to the hard-gate questions.
- **Your location and work authorization, and your pay floor:** Closes the two hard gates.
- **Examples of ingestion or data-contract work:** Moves rows 7 and 8 from unknown to met or partial.
- **Research, if you grant the web permission:** Up to 5 searches and 2 fetches, to check the posting, the employer, and the pay band. I can retry it then.

**Questions**
1. Where are you based, and do you have US work authorization? The posting is remote US or Denver.
2. What is your base salary floor?
3. Have you built ingestion from an app database or CRM, or worked with data contracts between producers and analysts?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.