**Decision: `conditional_go`.** Apply, once the posting is confirmed live on Harborlight's own careers site. Your must-haves are direct on what you've described. The gaps are metrics-layer ownership and mentoring, and healthcare data is a preferred item, not a requirement.

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.

**Fit ledger**

- `must_have`: direct: R1, R2, R3, R4, R6 · adjacent: R5 (metrics layer ownership)
- `important`: adjacent: R7 (partnering with clinicians) · unclear: R8 (mentoring two junior analysts)
- `preferred`: adjacent: R9 (healthcare data, HIPAA)

R5 is adjacent because your governed dashboards and metrics memo are close to a metrics layer, but you haven't described owning canonical metric definitions. R9 is adjacent through your GDPR/CCPA consent model, not healthcare work.

**Opportunity ledger.** The mandate is clearly defined on paper: metrics layer, experimentation, Looker, and partnering with PMs and clinicians (RR5). The title bundles hands-on analysis, platform building and mentoring (RR3), and the employer is unverified (RR1). No compensation or location was given (RR2).

**What would change this**
- Verified posting and employer → `go` pending interviews.
- You've owned metric definitions beyond dashboards (G1) → R5 moves to direct.
- Mentoring experience (G2) → R8 moves to direct or adjacent.
- Regulated-data or clinician work (G3) → R9 and R7 move up.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, digital-health scale-up, ~400 people, Series C | `[grounded]` your brief, not verified |
| Mandate | Own analytics for the care-navigation app: metrics layer, A/B tests, self-serve Looker, PM and clinician partnership, mentor two analysts | `[grounded]` JD |
| Scope read | Senior individual-contributor role with light people leadership | `[inferred]` from the mentoring line against the rest of the scope |
| Market calibration | Not run. Research was refused (see Evidence status) | — |
| Unknowns | Compensation, location and remote policy, reporting line, whether "mentor" means managing | — |
| Contradictions | None visible in the JD text you gave | `[grounded]` JD |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | Six years at a consumer-subscription company; self-reported, not inspected | `[grounded]` your background | none |
| R2 | Expert SQL | must_have | direct | medium | none | Daily SQL on Snowflake; self-reported | `[grounded]` your background | none |
| R3 | Experiment design at scale | must_have | direct | medium | none | 30+ tests a year and an 11% retention lift from a pricing test; self-reported | `[grounded]` your background | none |
| R4 | Looker or similar BI | must_have | direct | medium | none | Built the Looker instance from scratch, 40+ governed dashboards | `[grounded]` your background | none |
| R5 | Define and maintain the metrics layer | must_have | adjacent | medium | transferability | Governed dashboards and a monthly metrics memo are close, but you haven't said you owned canonical metric definitions | `[inferred]` from the dashboard work | G1 |
| R6 | Written communication with non-technical stakeholders | must_have | direct | medium | none | Monthly exec metrics memo, presented to the VP Product monthly | `[grounded]` your background | none |
| R7 | Partner with PMs and clinicians on roadmap decisions | important | adjacent | low | discovery | PM partnership is implied by your role; no clinician work described | `[inferred]` | G3 |
| R8 | Mentor two junior analysts | important | unclear | low | discovery | Not mentioned in your background | `[grounded]` absence | G2 |
| R9 | Healthcare data experience (HIPAA) | preferred | adjacent | medium | transferability | Consent-state model and GDPR/CCPA PII handling carry over; no HIPAA or clinical data | `[inferred]` | G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Metrics layer (R5, must_have) | transferability | Governed dashboards and a metrics memo; no statement of owning canonical definitions | Ownership of definitions is a named responsibility; it moves R5 to direct or confirms the gap | Defining metrics once for the whole company; a metric dictionary; resolving two teams' conflicting definitions | A metric dictionary, a metrics spec, or a Looker model excerpt | `[inferred]` the gap is in the evidence, not the JD |
| G2 | Mentoring junior analysts (R8, important) | discovery | Nothing in your background about mentoring | Named responsibility; unclear status is the main people-side question | Code or analysis review for other analysts; onboarding a new hire; running a team's analysis standards | Feedback from a manager or a mentee, a review checklist | `[grounded]` absence |
| G3 | Healthcare data and clinician work (R9, R7) | transferability | Consent and PII governance under GDPR/CCPA; no HIPAA, PHI or clinician-facing work | Preferred on R9 and important on R7; the gap decides how steep the ramp is | Any regulated data work, such as financial or health-adjacent data; analysis for operations or support staff who serve customers | Documentation of the consent model; any compliance review you took part in | `[inferred]` transfer from your consent model; `[generic]` that HIPAA is a learnable ramp, not a barrier |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not verified | unknown | — | "Harborlight Health (digital-health scale-up, ~400 people, Series C)" | Research was refused, so nothing confirms the company or the posting exists as described | `[grounded]` absence of verification | Can you confirm this role on your careers page, and who would I be interviewing with? | unresolved |
| RR2 | Compensation and location not given | unknown | — | Not stated in the posting you pasted | The band may be out of reach, or the role may be remote-only | `[grounded]` absence | What is the base range for this role, and what is the location policy? | unresolved |
| RR3 | Scope bundles IC analysis, platform build, and mentoring | risk_signal | low | "Own product analytics... build self-serve dashboards... mentor two junior analysts" | Time may be split thin across three jobs | `[inferred]` from the JD's scope list | How does the role's time split between analysis, Looker platform work and mentoring, and who is on the analytics team? | unresolved |
| RR4 | Mandate defines success and ownership | positive_signal | — | "define and maintain metrics layer… design and analyze A/B tests" | The role has concrete responsibilities, not an open-ended brief | `[grounded]` JD | What does success look like at 6 and 12 months? | noted |
| RR5 | Healthcare regulatory ramp | risk_signal | low | "healthcare data (HIPAA) a plus" | HIPAA knowledge is expected to be learned on the job by someone without healthcare experience | `[inferred]` from the preferred flag | What regulatory training does the team provide, and how is PHI handled in analytics? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm the posting on Harborlight's careers page before applying | RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Lead the application with R1–R4 and R6: six years, 30+ tests a year, the Looker build, and the monthly exec memo | These are your direct matches | `[grounded]` your background | pending your approval |
| A3 | Describe the consent model as GDPR/CCPA governance work; do not describe it as healthcare or HIPAA experience | Keeps R9 at adjacent, honest in the interview | `[grounded]` your background | pending your approval |
| A4 | Ask RR1, RR2, RR3 and RR5 verbatim in the first recruiter call | The register doubles as interview prep | `[grounded]` register | pending your approval |

Any CV line or outreach text is proposed for your approval before use. Nothing here adds a fact beyond what you stated.

## Evidence status

Verified: none yet. Every claim above is self-reported in this message. The three searches below returned nothing, so no outside claim is verified.

Research tier: L1 — searches 3 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searches for the company and its posting were refused by the permission setting, so the employer is unverified (RR1) |
| 2. Role-family sweep | unavailable | The compensation and scope search was refused, so the market calibration is missing (RR2, role reality) |
| 3. Hiring manager's public footprint | n/a | No name was given, so there is no query to form |

## Upgrade menu

- A live posting link or the careers-page URL → RR1 closes or becomes a standing entry.
- Permission to run the research (L1) again → employer checks and a role-family band for compensation and scope.
- The base-pay range, or a location policy → RR2 closes and the market band can be checked against it.
- A metric dictionary or a Looker model excerpt → R5 moves toward direct.
- The hiring manager's name → role reality's scope read, and which verified story to lead with for that reader.

If you want, I can write this assessment to a `tuesday-dossier.md` for later interview prep.

**Questions** (tagged to the gap queue)

**G1 — Have you owned a metrics layer, meaning canonical metric definitions that others build on, rather than defining metrics inside individual dashboards? Which tool held them?**
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**G2 — Have you mentored or formally reviewed the work of junior analysts? How many, and what did you do?**
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**G3 — Have you worked under a regulated data regime beyond GDPR/CCPA, such as HIPAA, or with clinicians directly?**
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.