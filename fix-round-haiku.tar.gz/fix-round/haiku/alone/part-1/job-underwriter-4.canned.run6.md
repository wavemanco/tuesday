**Decision: `hold_pending_answers`.** On fit, I'd apply. Don't submit until the location question is settled, because the posting says two different things about where the job is.

## Decision snapshot

- **Fit ledger**
  - **Must-have, meets:** 4+ years pricing analytics (5 years, last 2 senior); GLM experience (built and maintained a GLM rating model); strong SQL and Python (daily use); presenting to underwriting leads (quarterly review to the head of underwriting); designing and reading price tests (14 last year). `[grounded]` from your CV, unverified.
  - **Preferred, meets:** insurance experience (UK motor).
  - **Partial:** turning results into product recommendations. Your evidence is strong on underwriting, thin on product.
  - **Gap:** pet-insurance domain. Transferability, not capability.
- **Hard gates**
  - **Working location: unresolved.** The JD says "Fully remote (UK)". The careers page says "Leeds office four days a week." `[grounded]`
  - **Compensation: unknown.** Neither source states it.
- **Confidence:** medium overall. Your strengths are CV-stated, not verified against anything.

## Role reality

- Senior Pricing Analyst, Brindlemoor, pet-insurance product, reports to the Director of Pricing (Odile Varga). `[grounded]`, careers page and JD agree on title, product and reporting line.
- Scope: owns pricing analytics for one product. `[grounded]`
- Market calibration: not run in this pass (see evidence status). `[generic]` comparisons are therefore not available yet.

## Evidence status

Research tier: L1 — searches 3 of 5, fetches 1 of 2

| # | Target | Status | Reason |
|---|---|---|---|
| 1 | Company site and careers page | yes | Searches "Brindlemoor careers Senior Pricing Analyst" and "Brindlemoor insurtech pet insurance"; fetched brindlemoor.co.uk/careers/senior-pricing-analyst. The posting is live and matches the JD on title, product and reporting line, but conflicts on location. The insurtech search returned nothing, so I could not confirm stage, size or funding. |
| 2 | Role-family sweep (market pay and scope) | skipped | Not run in this pass. |
| 3 | Hiring manager's public footprint | yes | Search "Odile Varga Director of Pricing." One result: a conference talk listing (2025 Insurance Pricing Forum, "Small Books, Loud Errors") and prior role as head of pricing analytics at Calloway Re. The profile link points to a `.example` domain, so I am treating the footprint as single-sourced and unverified. |

## Evidence map

| # | Requirement | Priority | Fit | Gap | Confidence |
|---|---|---|---|---|---|
| 1 | 4+ years pricing/actuarial analytics | Must | Meets | none | medium (CV) |
| 2 | Strong SQL and Python | Must | Meets | none | medium (CV) |
| 3 | GLM experience | Must | Meets | none | medium-high (built and maintained) |
| 4 | Presenting to underwriting or actuarial leads | Must | Meets | none | medium (CV) |
| 5 | Design and read price tests | Implied by responsibilities | Meets | none | medium (CV) |
| 6 | Build and monitor rating models | Implied by responsibilities | Partial | "maintained" is not the same as "monitored" | medium |
| 7 | Turn results into recommendations for underwriting and product | Implied | Partial | product side unevidenced | medium |
| 8 | Insurance experience | Preferred | Meets | none | medium (CV) |
| 9 | Pet-insurance domain | Implied by product | Gap | transferability | n/a |
| 10 | Fully remote UK vs Leeds 4 days/week | Hard gate | Unresolved | conflicting sources | n/a |
| 11 | Compensation floor | Hard gate (your constraint) | Unknown | not stated | n/a |

People management is not in the JD, so it is not a gap here. The "Senior" title is consistent with your current level.

## Opportunity risk register

| Class | Severity | Risk |
|---|---|---|
| Hard-gate mismatch | High | Location conflict. If the job really requires Leeds four days a week and you can't do that, this is a no-go regardless of fit. |
| Failed attribution (partial) | Medium | Careers page confirms the role exists. I could not independently confirm the company's stage, funding or size. Verify with the recruiter's email domain or a second source. |
| Compensation unknown | Medium | Neither source states pay. The posting withholding it is itself a question to ask. |
| Domain learning curve | Medium | No pet-insurance evidence on your side. Expect questions about pet claim behaviour and vet-cost trends. `[generic]` |

Positive signals: a clearly defined reporting line to a Director of Pricing; a product that already exists; a hiring manager publicly focused on monitoring rating models, which matches your must-have area.

## Application plan

- **Lead with:** the GLM you built and maintained, the 14 price tests, and the quarterly review to the head of underwriting. These answer the four must-haves directly.
- **On the monitoring theme:** you maintained the model. Don't write "monitored" unless you actually ran monitoring (drift, A/E, segment checks). Claiming more than you did would fail the first technical question.
- **On pet insurance:** don't imply exposure. The honest pitch is that the method transfers (GLM, test design, underwriting communication) and the risk drivers are new to you. Show you've thought about what's different.
- **Before any CV or outreach text goes out:** I'd need your approval on the wording first.

## Upgrade menu

- Recruiter confirmation of the working pattern (remote or Leeds, and how many days) would settle the hard gate.
- Your location and whether you can work from Leeds would settle the same gate from your side.
- A role-family pay sweep would give a `[generic]` band to compare against your floor.
- Any pet, vet or non-motor work, even a side analysis, would move the domain gap from transferability to evidence.
- A deeper company check (funding, leadership changes, recent news) would close the employer-verification gap.

The Dossier offer: I can save this assessment as `tuesday-dossier.md` so it carries into interview prep.

## Questions

1. Where are you based, and could you work from Leeds four days a week? The JD says fully remote, the careers page says Leeds. A one-line answer settles this, and asking the recruiter directly is a quick way to resolve it too.
2. Do you have any pet, vet or non-motor pricing exposure, even a side analysis?
3. What is your compensation floor, or expected range? That lets me check the posting against your constraint once a band is available.

Answer any of these in a line, or skip them. Skipping is an answer too.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.