**Yes, apply, but verify the posting first.** This is `conditional_go`. Your must-haves match your record closely, and the open items are the employer check I couldn't run and the pet-insurance gap.

**Fit ledger.**

- `hard_gate`: unclear: R9 (Fully remote, UK)
- `must_have`: direct: R1, R2, R3, R4, R5 · adjacent: R6 (Recommendations for underwriting and product)
- `important`: adjacent: R7 (Pet-insurance domain)
- `preferred`: direct: R8 (Insurance experience)

**Opportunity ledger.** The scope is clear on paper, but pay, contract basis and decision authority are unstated (RR2, RR4, RR5). The employer is unverified because the check did not run (RR1). Whether the team expects pet-specific expertise on day one is unknown (RR3).

- **Hard gates:** none failed; unconfirmed: R9 (Fully remote, UK); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found in the posting; the employer check did not run
- **Conditions for go:** (1) RR1 clears: the live posting or your recruiter contact confirms Brindlemoor and the role; (2) R9 is checked against your location and contract constraints; (3) you have a credible answer to R7 for interviews.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech, pet-insurance product | `[grounded]` JD |
| Mandate | Own pricing analytics: rating models, price tests, recommendations to underwriting and product | `[grounded]` JD |
| Working pattern | Fully remote, UK | `[grounded]` JD |
| Scope read | Senior title with an analytics mandate; no direct reports stated | `[inferred]` from the JD's silence on reports |
| Market calibration | Not run: no salary or remit band was searched | — |
| Unknowns | Decision authority, direct reports, pay, contract type, pet claims history | — |
| Contradictions | None visible in what was pasted; the careers page was not checked | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | Five years, two as senior analyst; self-reported, not probed | `[grounded]` your message | none |
| R2 | GLM experience | must_have | direct | medium | none | You built and maintain a GLM; it is a motor book, but the technique transfers | `[grounded]` your message | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | Daily use; self-reported | `[grounded]` your message | none |
| R4 | Design and read price tests | must_have | direct | medium | none | Fourteen tests last year | `[grounded]` your message | none |
| R5 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | Quarterly review to the head of underwriting | `[grounded]` your message | none |
| R6 | Recommendations for underwriting and product | must_have | adjacent | medium | transferability | Underwriting recommendations are evidenced; product recommendations are not in your record | `[inferred]` from your message | G1 |
| R7 | Pet-insurance domain | important | adjacent | low | transferability | Motor rating carries over; pet risk drivers, claims and cover design differ | `[generic]` pet and motor pricing differ in risk drivers | G1 |
| R8 | Insurance experience | preferred | direct | medium | none | Five years at a motor insurer | `[grounded]` your message | none |
| R9 | Fully remote, UK | hard_gate | unclear | none | hard_gate | The JD states it; your constraint is not given | `[grounded]` JD | Confirm your constraints |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pet domain and product recommendations (R6, R7) | discovery | No pet or non-motor work in your record | Interviewers will likely probe this, and a credible answer moves R7 | Any non-motor pricing, product review, or model for another line; any pet-claims or vet-cost reading | A product note, a non-motor model summary, or a reading list you have worked through | `[generic]` that pet-domain probing is likely |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer and posting not verified | unknown | — | "Brindlemoor — Senior Pricing Analyst" | The posting may be stale or aggregated; the company may be too new to have a footprint | `[generic]` pattern for early-stage companies, not a claim about Brindlemoor | Can you point me to this role on your own careers page, and who would I interview with? | unresolved |
| RR2 | Decision authority not stated | unknown | — | "Own pricing analytics" | You may own analysis while the pricing decisions sit with a committee | `[inferred]` from the JD's verbs against its silence on sign-off | Which pricing decisions does this role make itself, and which go to committee? | unresolved |
| RR3 | Pet-specific expectation not stated | unknown | — | "our pet-insurance product" | The team may expect pet-claims knowledge from day one | `[inferred]` from the product line against the JD's silence on experience | What pet-specific claims history does the product have, and what do you expect me to know on day one? | unresolved |
| RR4 | Pay and contract type not in the JD | unknown | — | JD silent | The package may sit outside your expectations | `[inferred]` from the JD as pasted | What is the salary band, and is the contract permanent? | unresolved |
| RR5 | Direct reports unclear | unknown | — | "Own pricing analytics" | The role may be individual-contributor, or may carry a team you'd be expected to lead | `[inferred]` from silence on reports | Does this role have direct reports or a team to lead? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm the posting is live and the company is as described, via their careers page or the recruiter's email domain | RR1 | `[grounded]` RR1 | you can do this now |
| A2 | Lead your CV with the GLM rating model and the fourteen price tests, framed as motor evidence, with no pet claim | R2, R4, R7 | `[grounded]` evidence map | pending your approval |
| A3 | Prepare a short answer on how motor risk drivers would map to pet, and what you would check first | G1, R7 | `[generic]` pet and motor pricing differ | pending your approval |

## Evidence status

Verified: none yet. Your background is self-report, and nothing has been probed or documented.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Refused: web search permission was declined. Would have settled RR1 and the contradictions row |
| 2. Role-family sweep | unavailable | Refused. Would have set the market calibration for pay and remit |
| 3. Hiring manager's public footprint | unavailable | Refused. A name was given, so the query could have formed. Would have informed positioning for Odile Varga |

## Upgrade menu

- Grant web search permission and I'll run the three L1 checks (up to 5 searches, 2 fetches): the employer and posting, the pay and remit band, and Odile Varga's public footprint. That would settle RR1 and calibrate RR4.
- The live posting link → settles RR1 and checks the pay and contract figures in the JD.
- Any non-motor or pet-adjacent work sample → raises R7 above `low`.
- Your location and contract non-negotiables → resolves R9.

I can also save this as a `tuesday-dossier.md` to carry into interview prep.

Three questions, each tagged to its row:

- G1: Have you done any pricing or product work outside motor, even a side model or a product review? What did you own, and what did it show?
- RR5: Did the recruiter say whether this role has direct reports?
- R9: What are your non-negotiables on location and contract type?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.