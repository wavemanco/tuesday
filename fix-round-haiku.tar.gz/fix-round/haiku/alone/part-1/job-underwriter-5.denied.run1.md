**Yes, but conditionally: `conditional_go`.** Your five must-haves (R3, R4, R5, R7, R8) read `direct` against your background. The real gap is BigQuery, which the posting names in its role description but not among its requirements. Two hard terms (location, base pay) can't be checked because you haven't given me your side. The employer also isn't verified, because my web checks were refused this session (details below).

Research tier: L1 — searches 3 of 5, fetches 2 of 2

**Decision snapshot**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Remote US or Denver office), R2 (base pay $148,000–$166,000)
- `must_have` — direct: R3, R4, R5, R7, R8
- `important` — adjacent: R6 (BigQuery warehouse); unclear: R9 (app and CRM ingestion), R10 (data contracts analysts depend on)

R6 is the one real gap. R9 and R10 are CV silence rather than a known gap. R1 and R2 turn on your constraints, which you haven't given me yet.

**Opportunity ledger.** Scope reads as ownership of one domain's pipelines with named outcomes (RR3), and the posted base band sits near the provided report's median (RR2). The employer is not established from attributable sources (RR1, `severity: medium`), so the decision is capped at `conditional_go`. The hiring manager is unnamed (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Remote US or Denver office), R2 (base pay $148,000–$166,000); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **Conditions for go:** (1) the employer and live posting verify (RR1); (2) your location fits R1; (3) the base floor you need sits within R2's band; (4) ingestion and data-contract experience holds up when probed (R9, R10); (5) BigQuery is framed as dbt-on-Snowflake, never as BigQuery experience (R6).

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states; founded 2016, Denver; 264 employees; Series C, $52M, Feb 2026 | `[grounded]` the About text you pasted; not checked against the live site |
| Mandate | Build and run the pipelines behind the tutoring platform's reporting; ingestion from app and CRM; a dbt-modelled BigQuery warehouse; data contracts | `[grounded]` JD |
| Scope read | One domain's pipelines, no team or reports stated | `[inferred]` from the JD's single-domain wording |
| Working pattern | Remote (US) or Denver office | `[grounded]` JD |
| Market calibration | Series B–D senior data engineers: base median $151,000, IQR $139,000–$163,500. The posted $148,000–$166,000 sits around that median | `[generic]` from the Datawright report as your recruiter sent it; its publisher could not be checked this session |
| Unknowns | Hiring manager, team, contract type, equity size and vesting, your location, your pay floor | — |
| Contradictions | None between the JD and the About text you pasted | `[grounded]` provided text only |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | Your location isn't given, so the gate isn't settled | `[grounded]` JD | Q1 |
| R2 | Base pay $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | Your floor isn't given; equity is unquantified | `[grounded]` JD | Q2 |
| R3 | 5+ years data engineering | must_have | direct | medium | none | Six years at a B2B payroll company; CV self-report, so the intake ceiling is medium | `[grounded]` your background | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | Both used daily; self-report | `[grounded]` your background | none |
| R5 | dbt and a cloud warehouse | must_have | direct | medium | none | ~180-model dbt project on Snowflake, a cloud warehouse | `[grounded]` your background | none |
| R6 | BigQuery warehouse (in the role description) | important | adjacent | low | transferability | You have never used BigQuery; dbt on Snowflake is the bridge, and the limit is BigQuery itself | `[inferred]` dbt work carries over; `[generic]` that dbt transfers across warehouses | G1 |
| R7 | Airflow or similar orchestration | must_have | direct | medium | none | Airflow orchestration, self-reported | `[grounded]` your background | none |
| R8 | Data quality testing | must_have | direct | medium | none | Set up a Great Expectations test suite | `[grounded]` your background | none |
| R9 | Ingestion from app and CRM | important | unclear | low | discovery | Your CV doesn't say whether you ingested from app or CRM sources | `[grounded]` CV silence | Q3 |
| R10 | Data contracts analysts depend on | important | unclear | low | discovery | Quality testing is adjacent, but no contract ownership is stated | `[inferred]` adjacency from R8 | Q3 |

**Gap recovery queue**

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R6, important) | transferability | dbt and orchestration on Snowflake; no BigQuery use | The posting names it; a credible bridge narrows the objection | A dbt or ETL migration to a new warehouse; any BigQuery cost or partitioning work | A repo, a model file, or a migration note | `[inferred]` bridge from your Snowflake work; `[generic]` that BigQuery is the likeliest objection |
| G2 | Ingestion and contracts (R9, R10, important) | discovery | Pipelines and quality testing; sources and contracts not named | Both are in the role's first-line description, and an interviewer will probe them | Source-system ingestion; a schema or SLA agreement with a downstream team | A pipeline diagram, a contract doc, a test definition | `[grounded]` CV silence; `[generic]` that interviewers probe ingestion |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Pellucid Learning runs live online tutoring for K-12 schools in 31 US states" | The company may exist as described, but I could not check it: the web calls were refused, so the posting's liveness is unconfirmed | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on your own careers site, and who would I interview with? | unresolved |
| RR2 | Base band posted; equity unquantified | unknown | — | "$148,000–$166,000 plus equity" | The base sits near the market median; the equity value is unknown | `[grounded]` JD; `[generic]` band from the provided report | What is the approved base range, and what are the equity size and vesting? | unresolved |
| RR3 | Single-domain scope with named outcomes | positive_signal | — | "Build and run the pipelines behind our tutoring platform's reporting" | Ownership is defined, not diffuse | `[inferred]` from the JD's scope wording | Which pipelines does this role own end to end, and who consumes them? | noted |
| RR4 | Hiring manager not named | unknown | — | Posting names no hiring manager | Team and reporting line are unknown | `[generic]` postings often omit the manager | Who would I report to, and who is on the data team? | unresolved |

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Ask the recruiter for the live posting link and the hiring manager's name before investing in the loop | RR1, RR4 | `[grounded]` RR1, RR4 | pending your approval |
| P2 | Put location and base-pay questions to the recruiter in the first call | R1, R2 | `[grounded]` JD terms | pending your approval |
| P3 | Describe BigQuery as "dbt on Snowflake, no BigQuery production use yet" in any CV or interview language | R6 | `[grounded]` your CV; wording is `resume_edits_pending_approval` | pending your approval |
| P4 | Prepare an ingestion or data-contract example only if it is real and yours | R9, R10 | `[grounded]` CV silence | pending your approval |

**Evidence status**

Verified: none yet. Every claim above is your self-report, the pasted JD or About text, or the provided pay report, none of them inspected.

Research tier line above. Targets:

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches (Pellucid tutoring; Pellucid Series C) and two page fetches (the careers posting and the About page) were all refused, because web search and fetch permission was not granted this session. Would have moved RR1 (employer existence, live posting) and the Organization row |
| 2. Role-family sweep | unavailable | One search (Datawright 2026 pay report) was refused. Would have moved the market calibration and the scope norm |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

I did not retry the refused calls.

**Upgrade menu**

- Granting web search and fetch permission → I run targets 1 and 2 (employer existence, live posting, the pay report's publisher and figures). This would most directly move RR1.
- The live posting URL from Pellucid's careers page, or the recruiter's email domain → RR1 closes or escalates.
- The hiring manager's name → RR4 closes, and the positioning for that reader can be set.
- A BigQuery project or migration note → R6 moves from `adjacent` to `direct`, at `medium` or better.

I can also save this as `tuesday-dossier.md` if you want a file to carry into the next step.

**Questions**

Q1 — R1: Are you based in the US, and would Remote (US) work, or only the Denver office?

Q2 — R2: What base-pay floor do you need?

Q3 — R9, R10: Describe one time you built ingestion from an application or CRM source, or defined a data contract an analyst relied on. What was yours, and what broke?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.