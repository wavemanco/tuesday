**Decision snapshot: conditional_go.** You aren't wasting your time, but this is a stretch on the one must-have, so apply only with a truthful story about product decisions you've owned. Hard gates: none stated in the JD; your location, authorization, and pay floors are unknown, so those are unchecked.

**Why it's not a waste:** Your strongest evidence matches the core of the job: partner-facing API discovery, requirements and specs, and coordinating engineers, customers, and PMs. Quartzline is a 150-person company with two eng squads, so the platform scope looks like a first PM role, which often suits someone with your background.

**Why it's a stretch:** The must-have is "3+ years of product management," and your resume has no PM title. Recruiters often screen on that line before anyone reads the rest. Your resume also shows you feeding product (roadmap-input sessions, playbook, requirements) rather than owning roadmap decisions, and it has no evidence yet for metrics or agile delivery.

**Evidence map** (based only on your resume and the JD; provenance: `[grounded]`)

| Requirement | Priority | Fit | Confidence | Gap type |
|---|---|---|---|---|
| 3+ yrs PM experience | must-have | gap | high | transferability: adjacent work, not PM ownership |
| Shipped API or platform products | must-have | partial | medium | presentation: you shipped integrations built on the platform, not the platform |
| Technical fluency (API docs, schemas) | must-have | strong | high | none (verify depth in interview) |
| Stakeholder management (eng, sales, customers) | must-have | strong | medium | none |
| Partner discovery | core responsibility | strong | medium | none |
| Specs and delivery with eng squads | core responsibility | partial | medium | transferability: requirements docs, not sprint ownership |
| Adoption metrics, defined and tracked | core responsibility | unknown | low | discovery: may exist but isn't on the resume |
| Launch coordination with sales and support | core responsibility | partial | medium | presentation: go-live work is strong; sales/support coordination isn't stated |
| Agile delivery | must-have | unknown | low | discovery |

**Application plan**
1. Answer the questions below before you apply. Your answers decide whether the stretch is worth it.
2. Lead with the integration-to-product story: 30+ integrations as a discovery dataset, the playbook as a product artifact, roadmap-input sessions as a feedback loop.
3. Prepare two or three concrete examples where you changed a product decision and can say what shipped and what moved. Don't claim PM ownership you didn't have. Phrase it as what you drove, and be ready for follow-up questions.
4. Get a referral if you can. It's the best lever around the title screen.
5. Apply selectively. Also consider API-, integration-, or solutions-adjacent PM titles, where your background reads as a direct fit `[generic]`.

**Your triage tool:** The earlier note about an internal request-triage tool is unconfirmed, so don't put it on a resume yet. If you built it and support adoption was measured, it is your best PM-shaped evidence.

**Research:** Research tier: L0 — no searches. I checked only what you gave me. I didn't confirm that Quartzline exists as described, that the posting is live, or what PM pay looks like at this level.

**Evidence status:**

| Target | Status | Reason |
|---|---|---|
| 1. Company site and careers page | skipped | L0 run; no search consented |
| 2. Role-family sweep (scope, title, pay) | skipped | L0 run; no search consented |
| 3. Hiring manager's public footprint | n/a | No name given |

**Dossier offer:** I can save this assessment as a `tuesday-dossier.md` file so you can carry it into later sessions.

**Upgrade menu** (what each input would change)
- A link to the live posting, or the company's careers page: confirms the role is real and current.
- Permission to run company and role-pay research: checks employer existence and PM pay at this seniority, which could move the decision.
- Your location, pay floor, and work-authorization constraints: lets the hard-gate check run.
- Any agile or sprint experience, and any metrics you defined or tracked: would move the two unknown rows.

**Questions**
1. Have you ever owned a product decision end to end, such as choosing what to build, what to cut, or how success was measured? What was it?
2. Did you build the request-triage tool? If so, what did support adopt, and how did you measure it?
3. Where did this posting come from, and what are your location and pay constraints?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.