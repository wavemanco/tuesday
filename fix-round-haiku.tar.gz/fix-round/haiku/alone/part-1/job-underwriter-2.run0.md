**Short answer: applying isn't a waste of time, but expect the "3+ years product management" must-have to be the first thing a screen checks, and you don't have it in titled form.** Your technical and stakeholder evidence is strong. Your product-ownership evidence is adjacent, and you'll need to show it in artifacts.

**Decision snapshot**

**Worth applying to, with conditions. Status: `conditional_go`.**

**Fit ledger.**

- `must_have`: direct: R3, R4 · adjacent: R1a, R2, R5, R6 · unclear: R7, R8 · absent: R1b
- `important`: adjacent: R9

R1b (titled PM years) is the one gap a screen will see first; R1a and R5 are the bridge that answers it.

**Opportunity ledger.** The role is well specified: two named squads, partner discovery, and launch duties (RR3). Compensation, location and the employer's own footprint are unknown (RR1, RR2), and the scope is broad for one PM (RR4).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) your application shows product decisions you drove, with specifics, so R1a and R5 read as ownership rather than facilitation; (2) the recruiter confirms whether adjacent years count against the 3+ year must-have (R1b); (3) the employer is verified and the comp and location come back clean (RR1, RR2).

**Research:** none completed. My three searches were all refused by the permission setting, so the employer, market band and salary range are unverified. I didn't retry.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline, B2B logistics-tech, ~150 people, Series B | `[grounded]` posting as you described it |
| Mandate | Own the partner-facing API platform roadmap; lead discovery; drive two engineering squads; launch with sales and support | `[grounded]` JD |
| Scope read | Broad for one PM: roadmap, partner discovery, two squads and launch duties together | `[inferred]` from the JD's responsibility count against no stated team size |
| Market calibration | Not established: no salary or role-family sweep ran | — |
| Unknowns | Compensation, location, team size, whether adoption metrics already exist | — |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1a | Product management experience, in substance | must_have | adjacent | medium | transferability | Roadmap-input sessions and requirements documents are PM-shaped work; you didn't hold the PM decision rights | `[grounded]` CV; `[inferred]` adjacency | G1 |
| R1b | 3+ years of titled PM experience | must_have | absent | none | transferability | No PM title; the limit is titled years, not skill | `[grounded]` CV | G1 |
| R2 | Shipped API or platform products | must_have | adjacent | medium | transferability | 30+ REST API integrations delivered; you shipped client implementations, not the platform itself | `[grounded]` CV | G2 |
| R3 | Technical fluency with API docs and schemas | must_have | direct | medium | none | Postman, SQL, OpenAPI, integration architecture; CV-only, so medium | `[grounded]` CV | none |
| R4 | Stakeholder management: engineering, sales, customers | must_have | direct | medium | none | Coordinated vendor engineers, client engineers and PMs; sales coordination isn't in the CV | `[grounded]` CV | none |
| R5 | Partner discovery and roadmap ownership | must_have | adjacent | medium | transferability | Quarterly client-feedback sessions and scoping workshops; no roadmap ownership stated | `[grounded]` CV | G1 |
| R6 | Specs and delivery with two engineering squads | must_have | adjacent | medium | transferability | Requirements documents, UAT and go-live; no squad-level delivery ownership stated | `[grounded]` CV | G1 |
| R7 | Agile delivery | must_have | unclear | low | discovery | CV is silent on sprints or agile practice | `[grounded]` CV silence | G3 |
| R8 | Defining and tracking adoption metrics | must_have | unclear | low | discovery | CV is silent; SQL suggests you could pull usage data | `[grounded]` CV silence; `[inferred]` from SQL | G2 |
| R9 | Launch coordination with sales and support | important | adjacent | medium | transferability | Go-live coordination across 30+ clients; sales and support aren't named | `[grounded]` CV | none |

**Gap recovery queue**

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Product ownership (R1a, R1b, R5, R6) | transferability | Strong discovery-adjacent and spec work; no titled PM years, no decision rights stated | This is the must-have a screen checks first | A prioritisation call you made on client requests and what shipped; a roadmap input that changed a product decision | A roadmap or prioritisation doc, a before-and-after backlog | `[inferred]` that screens check titles first; `[generic]` |
| G2 | Shipped product and adoption (R2, R8) | discovery | Integrations shipped to clients; no adoption metric in the CV | Adoption tracking is in the JD and is the clearest proof of product judgment | The internal request-triage tool (unconfirmed), any usage or adoption number you tracked | Tool screenshots, usage numbers, a before-and-after metric | `[grounded]` CV silence |
| G3 | Agile delivery (R7) | discovery | CV silent | Required, and a cheap gap to close if you have it | Sprint planning, backlog grooming or release cadence on integration work | A sprint or release plan | `[grounded]` CV silence |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer and compensation not verified | unknown | — | none (no research ran) | The posting may be fine but cannot be checked here | `[grounded]` research refused | Who owns the partner-API roadmap today, and what would this role decide without sign-off? | unresolved |
| RR2 | Adjacent years may not count | risk_signal | medium | "3+ years product management experience (must-have)" | The screen may reject on titled years before reading the bridge | `[generic]` pattern for must-have titled years | Will adjacent PM experience count against the 3+ year requirement? | unresolved |
| RR3 | Specific, realistic scope | positive_signal | — | "two engineering squads"; "launch with sales and support" | The role is defined enough to prepare for | `[grounded]` JD | Which two squads, and what is each one's current output? | noted |
| RR4 | Scope breadth for one PM | risk_signal | low | "own the roadmap… run discovery… drive delivery with two squads" | One PM may carry more than the role's authority covers | `[inferred]` from the JD's responsibility list | Which decisions does this role own alone, and what team is committed? | unresolved |

**Application plan** (every row needs your approval before anything is written)

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Reframe CV bullets toward decisions you drove (roadmap inputs, scope calls), using only what the evidence holds — no "product manager" or "owned roadmap" wording | Makes R1a and R5 read as ownership | `[grounded]` R1a, R5 rows | pending your approval |
| P2 | Write one case study: a client requirement you turned into a product change, with the outcome | Closest shipped-product evidence (R2) | `[inferred]` from G1 | pending your approval |
| P3 | Ask the recruiter whether adjacent years count toward the 3+ year requirement | Resolves RR2 before you invest in the loop | `[grounded]` RR2 | pending your approval |

**Evidence status**

Verified: R3 and R4 rest on your CV alone; nothing is user-confirmed yet. Unverified lead: the internal request-triage tool, from agent memory only. It is not evidence and I haven't used it in any row.

Rejected inferences: none.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches were refused by permission. It would have verified the employer and the live posting, and would have cleared or raised RR1 |
| 2. Role-family sweep | unavailable | One search was refused by permission. It would have set the compensation band and the scope norm behind RR4 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

**Dossier offer:** I can write this up as a `tuesday-dossier.md` file you can keep and use in later prep.

**Upgrade menu**

- Permission to search: the employer check and the salary band (RR1, RR4), up to 5 searches and 2 fetches.
- One roadmap or prioritisation artifact you can share, sanitized → R1a and R5 to `high`.
- Confirmation of the triage tool (who used it, how you know it worked) → G2 and R8 move.
- The recruiter's answer on adjacent years → RR2 closes.

**Questions**

- G1 — Have you ever made a prioritisation or roadmap call that changed what got built? What did you decide, what did you own, and what happened? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.
- G2 — Did you build the internal request-triage tool? If so, who used it, what changed, and how did you know it worked? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.
- G3 — On integration work, did you run sprint planning or release cadence with engineering, and what was your part? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.