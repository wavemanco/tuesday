**Decision: conditional go.** Your core analytics record matches this role closely. Two things hold it short of a plain go: I could not confirm that Harborlight Health exists as described, and the posting's own requirements leave two gaps open (mentoring and healthcare). Both are checkable.

**Research tier: L1, searches 2 of 5, fetches 0 of 2.** The two searches I sent were denied permission, so no company or market facts were gathered. Everything below rests on your background and the JD.

## Decision snapshot

- **Candidate fit:** strong on the must-haves (analytics tenure, SQL, experimentation, Looker, written communication). Mentoring and healthcare are open.
- **Opportunity:** employer unverified. No compensation stated. Role scope otherwise reads as normal for a Series C digital-health company.
- **Hard gates:** none stated. HIPAA is listed as a plus, not a gate, so it cannot block you on its own.
- **Decision:** `conditional_go`, pending verification of the employer and the posting.

## Role reality

- **Title and scope:** Senior Product Analyst, owning the metrics layer, experiment design and analysis, self-serve Looker dashboards, and mentoring two junior analysts. [grounded]
- **Organization:** ~400 people, Series C, care-navigation app. [grounded, from the JD only; unverified]
- **Market calibration:** not available. The search that would have supplied it was denied. [generic] patterns are not used here, to avoid presenting memory as current market data.
- **Compensation:** not stated. The posting withholds it, which is itself worth asking about before you invest in interviews.
- **Contradictions:** none found within the JD.

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Evidence |
|---|---|---|---|---|---|---|
| 1 | 5+ years product analytics | Must-have | strong | medium | none | 6 years, consumer subscription [grounded, CV] |
| 2 | Expert SQL | Must-have | strong | medium | none | Daily SQL on Snowflake [grounded, CV] |
| 3 | Experiment design at scale | Must-have | strong | medium | none | 30+ A/B tests a year; pricing test with 11% retention lift [grounded, CV] |
| 4 | Looker or similar BI | Must-have | strong | medium | none | Built company Looker instance; 40+ governed dashboards [grounded, CV] |
| 5 | Written communication to non-technical stakeholders | Must-have | strong | medium | presentation | Monthly exec metrics memo; monthly VP Product presentation [grounded, CV] |
| 6 | Define and maintain a metrics layer | Must-have | partial | medium | discovery | Governed dashboards and warehouse consent model show the pattern; a formal metrics layer is not claimed [inferred] |
| 7 | Partner with PMs and clinicians | Must-have | partial | low | transferability | PM partnership is evidenced; clinician partnership is not [inferred] |
| 8 | Mentor two junior analysts | Must-have | unknown | low | discovery | Nothing in the CV; may exist but is unrecorded |
| 9 | Healthcare data / HIPAA | Plus | gap | low | capability | No healthcare work. Transferable: GDPR/CCPA PII handling and consent-state model [grounded, CV] |

Do not describe any of this as healthcare experience or HIPAA experience. Describe the consent and PII work as what it is.

## Opportunity risk register

- **Failed attribution (standing entry):** cannot confirm Harborlight Health exists as described. Resolves with the live posting link, the company's careers page, or the recruiter's email domain. Severity: high until resolved.
- **Compensation withheld:** no band stated and no market band available. Check against your floor before going further. Severity: medium.
- **Healthcare regulatory context:** a clinical product will bring HIPAA obligations that your consumer PII work only partly covers. Expect this to come up in interviews. Severity: medium.

## Application plan

- **Lead with:** the experimentation program and the metrics memo. These are your strongest and most verifiable evidence for this JD.
- **Bridge honestly:** consent-state modeling and PII governance, framed as data-privacy work in a regulated-adjacent setting.
- **Address directly:** mentoring (if you have it) and clinician collaboration. Do not leave them for the interviewer to find.
- **Resume edits:** none drafted. Any wording you approve for external use will be proposed as pending your approval before it goes anywhere.

## Evidence status

| Target | Status | Reason |
|---|---|---|
| L1-1: company site and careers page | unavailable | Search permission denied |
| L1-2: role-family compensation and scope sweep | unavailable | Search permission denied |
| L1-3: hiring manager's public footprint | n/a | No hiring manager named |

## Upgrade menu

- **Live posting link or careers page:** verifies the employer and lifts the failed-attribution entry. Unlocks the decision to `go` or `no_go`.
- **Search permission:** allows the company check and a market compensation band. Unlocks the compensation comparison.
- **Your CV or a work sample for the metrics memo:** raises the medium-confidence rows to high, if the artifact is shareable.

## Questions

1. Do you have the live posting link, or the careers page for Harborlight Health? This is the fastest way to resolve the employer check.
2. Have you mentored or managed junior analysts, formally or informally? Even a partial answer changes row 8.
3. Have you worked on any health-adjacent data, such as clinician-facing tools, patient data or insurance data, even briefly?

Answer in prose, skip any question, or say "skip."

If you want a portable record of this assessment for later sessions, I can write it to `tuesday-dossier.md`.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.