**Snapshot**

Yes, apply, but only once the posting checks out. Renata, on what you've given me, your must-haves read as direct: R2 to R5 cover pricing analytics years, SQL and Python, GLM and presenting to underwriting. The open items are the employer itself, which I could not verify, and your UK base, which the posting makes a hard gate. Status: `conditional_go`.

**Fit ledger**

- `hard_gate` — unclear: R1 (Fully remote (UK))
- `must_have` — direct: R2, R3, R4, R5
- `important` — direct: R6 · adjacent: R7 (Recommendations for underwriting and product), R8 (Pet-insurance product knowledge)
- `preferred` — direct: R9 (Insurance experience)

R2 to R5 hold the must-haves. R8 is where the evidence stops short, and R1 is the one gate still open.

**Opportunity ledger.** The scope is concrete (RR5), but authority over rate changes and reporting lines are unstated (RR1, RR2). The employer is not established from attributable sources (RR3), and the pet data history is unknown (RR4).

- **Hard gates:** none failed (R1 `unclear`); unconfirmed: R1 (Fully remote (UK)); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the posting is live on Brindlemoor's own careers site and the entity is confirmed (RR3); (2) you confirm UK base and right to work (R1); (3) the pet gap is framed as adjacent, never as pet expertise (R8).

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, insurtech, pet-insurance product | `[grounded]` JD as you pasted it; existence not verified (RR3) |
| Mandate | Own pricing analytics: build and monitor rating models, design and read price tests, recommend to underwriting and product | `[grounded]` JD |
| Working pattern | Fully remote, UK | `[grounded]` JD |
| Scope read | A senior IC analyst role with ownership of models and tests; no team or reports are described | `[inferred]` from the responsibility list against its silence on team |
| Hiring manager | Odile Varga, Director of Pricing | `[grounded]` your message; public footprint not researched |
| Market calibration | Not checked. No salary band or role-family norm is stated here | — (search refused, see Evidence status) |
| Unknowns | Rate-change authority, reporting line, pet data history, salary, contract type | — |
| Contradictions | None visible between the JD text and your notes | `[grounded]` the two texts as provided |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote, UK-based (right to work) | hard_gate | unclear | medium | hard_gate | Your UK motor employment points to a UK base, but you have not stated your status, so the gate is not settled | `[inferred]` from your UK employer | Gate question (below) |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | Five years of pricing analytics, the last two as senior analyst | `[grounded]` your intake, self-reported | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | Daily use of both, per your intake | `[grounded]` your intake | none |
| R4 | GLM experience | must_have | direct | medium | none | You built and maintained the young-driver GLM | `[grounded]` your intake | none |
| R5 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | Quarterly pricing review to the head of underwriting | `[grounded]` your intake | none |
| R6 | Design and read price tests | important | direct | medium | none | Ran 14 price tests last year with underwriting | `[grounded]` your intake | none |
| R7 | Turn results into recommendations for underwriting and product | important | adjacent | medium | transferability | Underwriting recommendations are evidenced; product recommendations are not | `[inferred]` from the quarterly review against the product half of the requirement | Gap G2 |
| R8 | Pet-insurance product knowledge | important | adjacent | medium | transferability | Motor pricing transfers; you have never priced pet, and pet drivers are not in your notes | `[grounded]` your statement; `[inferred]` requirement, from "our pet-insurance product" | Gap G1 |
| R9 | Insurance experience | preferred | direct | medium | none | Five years at a UK motor insurer | `[grounded]` your intake | none |

Confidence is `medium` throughout because your intake is self-report, not yet probed or inspected, which is the intake ceiling.

**Gap recovery queue**

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pet-insurance product knowledge (R8, important) | transferability | Motor pricing only; no pet work in your notes | Likeliest interview objection; a named limit beats a claim you cannot defend | Any pet, companion-animal or non-motor pricing you touched, even as a reviewer of someone else's model; data work on claims inputs | A pet data sample, a model review note, a pricing paper | `[inferred]` bridge from your motor work; `[generic]` that pet is the likeliest objection |
| G2 | Product recommendations (R7, important) | transferability | Strong underwriting recommendations; product-side input not evidenced | The JD names product as an audience | Product or commercial input on a pricing change; a proposal that changed a product rule | A product-review slide, a change note | `[inferred]` from the JD's two audiences |
| G3 | UK base and right to work (R1, hard_gate) | hard_gate | UK employment history; status not stated | A gate; wording cannot solve it | — | — | `[grounded]` JD "Fully remote (UK)" |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Rate-change authority unstated | unknown | — | "recommendations for underwriting and product" | The role may recommend while sign-off sits with underwriting or actuarial committees | `[inferred]` from recommendation language against silence on decision rights | Which rate changes does this role approve itself, and which go through underwriting or actuarial sign-off? | unresolved |
| RR2 | Reporting line unstated for a senior title | unknown | — | "Senior Pricing Analyst" | The role may or may not include reports; it matters given you have not managed anyone | `[inferred]` from the title against the absence of any team description | Does this role have direct reports now or planned, and who would I partner with in pricing? | unresolved |
| RR3 | Employer not established from attributable sources | risk_signal | medium | "Brindlemoor (insurtech)" | The posting may be stale, aggregated, or from a company too new for a footprint | `[generic]` pattern for young insurtechs, not a claim about this one | Which page on your careers site lists this role, and which legal entity underwrites the pet policies? | unresolved |
| RR4 | Pet data history unknown | unknown | — | "our pet-insurance product" | A young product may have short claims history, which makes a GLM harder to fit | `[generic]` new product lines often have short histories | How many years of claims and exposure data does the pet rating model use, and when was it last refit? | unresolved |
| RR5 | Concrete outputs named | positive_signal | — | "design and read price tests, and turn the results into recommendations" | The mandate has measurable deliverables | `[inferred]` from the JD's wording | What does a good first year look like in price-test volume or loss-ratio terms? | noted |

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead with the GLM, the 14 price tests and the underwriting review as the proof of R2 to R6 | Those rows are direct and the most defensible | `[grounded]` R2 to R6 | pending your approval |
| A1 | Confirm the posting on Brindlemoor's careers page before you spend effort on it | RR3 | `[generic]` cheapest loss to avoid | pending your approval |
| A2 | Describe pet as adjacent, with the limit named: "I have priced motor, not pet; here is what carries over" | R8 | `[grounded]` R8 row | pending your approval |
| A3 | If reports come up, say plainly that you have not managed people, and name what you have led | RR2 | `[inferred]` from RR2 | pending your approval |
| Q1 | Put the RR1, RR2 and RR4 questions to the hiring manager in the first conversation | Register doubles as interview prep | `[grounded]` register | pending your approval |

**Evidence status**

Verified: none yet. Your claims are self-report from intake and have not been probed or inspected.

Research tier: L1 — searches 3 of 5, fetches 0 of 2; user links read 0

Three searches went out and the host refused each one for lack of permission. Nothing was fetched, and no figure below comes from research.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches for Brindlemoor and its careers page were refused. Employer existence is not established (RR3) |
| 2. Role-family sweep | unavailable | One search for senior pricing analyst pay and scope was refused. The market calibration line is blank |
| 3. Hiring manager's public footprint | unavailable | Not sent; the host declined research. Would have fed the positioning in the application plan |

**Dossier offer:** I can write this up as a `tuesday-dossier.md` file for mock-interview to use later, if you want it.

**Upgrade menu**

- Grant search permission and I'll run the L1 checks: the employer's careers page (RR3) and a role-family pay band (closes the market calibration gap).
- A link to the live posting: verifies RR3 directly and may answer RR2 and the contract type.
- A pet data sample or model note you can share: lifts R8 from medium toward high.
- A product-side review or change note: lifts R7.

**Questions**

R8 — Have you touched any pet-specific pricing inputs, such as breed or species factors, vet-cost inflation, or lifetime versus annual cover, even as an analyst reading the data? What was your part?

R1 — Are you based in the UK with the right to work here?

RR4 — Did your GLM work include a product with thin or new data, such as a short history or low exposure? How did you handle the fit?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.