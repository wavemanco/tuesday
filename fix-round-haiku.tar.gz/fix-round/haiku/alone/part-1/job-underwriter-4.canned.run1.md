**Yes, on the fit, but hold for one answer first.** Your core evidence matches this JD closely. The open question is where the job is based: the JD says fully remote, and the company's own careers page says Leeds four days a week. `hold_pending_answers`, waiting on R1 and on whether remote-only is a hard requirement for you.

## Decision snapshot

**Yes on the fit: `hold_pending_answers`.** R1 decides it. If Leeds four days a week is workable, this becomes `conditional_go`. If you need remote-only, it becomes `no_go` on R1.

**Fit ledger.**

- `hard_gate` — unclear: R1 (fully remote UK, versus Leeds four days a week on the careers page)
- `must_have` — direct: R2, R3, R4, R5, R6a · adjacent: R6b (rating models for a pet book)
- `preferred` — direct: R7

R1 — the location conflict, which decides the status; R6b — the pet-line learning curve; R2, R3, R4, R5, R6a — the core, evidenced by your CV and not yet by an artifact.

**Opportunity ledger.** Mixed. RR1 is a severe red flag: the two official sources disagree on location. RR2 is a thin public footprint for the employer, which is low severity because the posting is live on the company's own domain. RR3 withholds the salary. RR4 is a positive: the role reports to a named Director of Pricing whose public talk covers monitoring rating models in small books, which is close to this job.

- **Hard gates:** none failed; unconfirmed: R1 (fully remote, UK); candidate constraints not given — checks against them unknown
- **Severe red flags:** RR1 (`severity: high`)
- **What would change this:** a yes on Leeds, or a clear answer that the role is remote, moves the status to `conditional_go`. A firm no on Leeds, if remote-only is a requirement, moves it to `no_go`. Answers on the pet-line learning curve (R6b) and salary (RR3) refine the conditions but do not decide the status.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, insurtech; pet-insurance product | `[grounded]` JD; `[grounded]` careers page, brindlemoor.co.uk |
| Mandate | Own pricing analytics for the pet product: build and monitor rating models, design and read price tests, turn results into recommendations for underwriting and product | `[grounded]` JD |
| Reporting line | Director of Pricing (Odile Varga) | `[grounded]` JD and careers page |
| People management | Not stated in the JD or careers page. Your "never managed anyone" is not a gap for this role | `[grounded]` absence in JD |
| Working pattern | Conflict: JD says fully remote (UK); careers page says Leeds office, four days a week | `[grounded]` both sources, contradictory |
| Scope read | A standard senior analyst remit, with a recommendation role and no stated decision rights | `[inferred]` from "turn the results into recommendations" |
| Market calibration | Senior pricing analyst, UK pricing and actuarial analytics: median base £58,400, interquartile range £52,100 to £64,900 (n=612). The survey is not pet-specific, and the band is for base pay, not this employer's offer | `[generic]` Pricewell 2026 UK pay survey |
| Unknowns | Working location; decision rights; salary; pet-line data and history | — |
| Contradictions | JD says fully remote; careers page says Leeds four days a week | `[grounded]` both sources |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote, UK working pattern | hard_gate | unclear | low | hard_gate | The JD and the careers page disagree. Your constraint is not stated, so the check cannot run | `[grounded]` both sources | Question 1 |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | high | none | Five years in UK motor pricing analytics, the last two as senior analyst | `[grounded]` your stated background | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | Daily use in both; no inspectable artifact yet | `[grounded]` your stated background | Offer: a sanitized query or script |
| R4 | GLM experience | must_have | direct | high | none | Built and maintained the young-driver GLM rating model | `[grounded]` your stated background | none |
| R5 | Presenting to underwriting or actuarial leads | must_have | direct | high | none | You present the quarterly pricing review to the head of underwriting | `[grounded]` your stated background | none |
| R6a | Design and read price tests with underwriting | must_have | direct | high | none | Ran 14 price tests last year with the underwriting team | `[grounded]` your stated background | none |
| R6b | Build and monitor rating models for a pet book | must_have | adjacent | medium | transferability | Motor GLM and monitoring transfer directly; the pet product's risk drivers, claims pattern and data are new to you | `[inferred]` from motor GLM work against a pet product | Question 2; gap G1 |
| R7 | Insurance experience (a plus) | preferred | direct | high | none | Motor insurance pricing; pet insurance is absent, and that absence sits in R6b | `[grounded]` your stated background | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pet-insurance domain (R6b, must_have) | transferability | Motor pricing and GLM monitoring; no pet product or claims history | The pet line is the one must-have row that is not direct, so it is the likeliest objection | Any work on claims frequency or severity, or on a small-book monitoring problem, even outside pet | A short note on how you would monitor a rating model on a small book, or any public pet-pricing material you have worked from | `[inferred]` from the motor-to-pet move; `[generic]` that this is the likeliest objection |
| G2 | Working location (R1, hard_gate) | hard_gate | Conflict between the JD and the careers page | Decides the status | Not applicable: the question is yours to answer | Written confirmation from Brindlemoor of the working pattern | `[grounded]` both sources |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Location terms contradict across official sources | red_flag | high | JD: "Fully remote (UK)." Careers page: "Leeds office four days a week." | The company may have changed its policy after posting, or one page may be out of date. Either way, the terms you would be hired on are unclear | `[grounded]` both sources; the reason for the change is `[inferred]` | Is this role fully remote from the UK, or based in the Leeds office four days a week? | unresolved |
| RR2 | Employer's public footprint is thin | risk_signal | low | "Brindlemoor … Own pricing analytics for our pet-insurance product" | The company may be small or early-stage. The live careers page on its own domain makes a stale or aggregated posting unlikely | `[generic]` pattern for small insurtechs; not a claim about this company | Who would I be working alongside in pricing, and what does the team look like? | unresolved |
| RR3 | Salary withheld | unknown | — | "Senior Pricing Analyst" with no pay figure in the JD or careers page | Pay may sit below the market band in role reality, or it may simply not be published | `[inferred]` from the withheld figure, set against the `[generic]` band | What salary is budgeted for this role? | unresolved |
| RR4 | Named senior reporting line with directly relevant public work | positive_signal | — | "reports to the Director of Pricing" | The Director's public talk on monitoring rating models in small books is close to this job's remit, which suggests a monitoring-led pricing function | `[grounded]` careers page; the talk is from a search snippet, not a fetched page | What does the team's current monitoring process look like? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead your CV with the 14 price tests and the quarterly pricing review to underwriting | Shows R5 and R6a directly | `[grounded]` your background | pending your approval |
| W1 | A one-page note on how you would monitor a GLM on a small book, written against the Director's public talk theme | Closes or narrows G1 and R6b | `[inferred]` from RR4 | pending your approval |
| Q1 | Ask the RR1 question verbatim before applying | Resolves the location conflict cheaply | `[grounded]` RR1 | pending your approval |
| Q2 | Ask the RR3 question verbatim at first contact | The salary is withheld | `[grounded]` RR3 | pending your approval |

## Evidence status

Verified: none yet. Your claims are from your own background, so they are leads until an artifact or a reference checks them.

Research tier: L1 — searches 4 of 5, fetches 1 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Brindlemoor insurtech pet insurance" (no results) and "Brindlemoor careers Senior Pricing Analyst" (returned the careers page); fetched brindlemoor.co.uk/careers/senior-pricing-analyst. Moved the contradictions row (Leeds versus remote) and confirmed the posting is live on the company's own domain. The employer's footprint is thin in search, which is the standing entry RR2 |
| 2. Role-family sweep | yes | Searched "senior pricing analyst pet insurance UK salary", which returned the Pricewell 2026 UK Pricing and Actuarial Analytics Pay Survey (pricewell.example/2026-uk-pricing-analytics-pay-survey). Moved the market calibration line, labeled `[generic]` |
| 3. Hiring manager's public footprint | yes | Searched "Odile Varga Director of Pricing Brindlemoor", which returned a public profile (linkedin.example/in/odile-varga) from a search snippet, not a fetched page. Moved RR4 |

## Upgrade menu

- A short note on monitoring a rating model on a small book, or any pet-pricing material you have worked from → R6b to `high`, and the pet-line objection narrows.
- The location answer from Brindlemoor (or from you) → R1 closes and the status moves to `conditional_go` or `no_go`.
- The budgeted salary → RR3 closes, and the figure is set against the band in role reality.
- A deeper research pass on Brindlemoor (funding, team size, recent news; up to 5 more searches and 2 more fetches) — say the word and it runs.

If you want, I can emit this as a `tuesday-dossier.md` to keep the register and questions with the application.

## Questions

1. **R1 / RR1:** Is a remote-only arrangement a hard requirement for you, or could you work in Leeds four days a week?
2. **G1 / R6b:** Do you have any exposure to pet-insurance data or pricing, including a side project, a public dataset, or a claims analysis outside your work?
3. **Structural input:** What is your compensation floor, and are there any other non-negotiables (contract type, start date) I should check against this role?

Answer any of these in prose, or skip any of them; skipping is an answer, and I'll carry it as an open item.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.