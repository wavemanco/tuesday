**Decision: no-go on this posting as written.** Your experience fits well, but the posting rules out both of your hard constraints in its own words. Your sense that something is off is well-founded.

**Hard gates (both fail)**
- **Location and schedule:** The posting requires on-site in Austin 5 days a week, "no exceptions." You are remote-only in Portland. [grounded]
- **Pay:** The posting says $70–85k base. Your floor is $150k, so even the top of the range is $65k short. [grounded]

Both gates come from the posting's own terms, and "no exceptions" makes a change unlikely. Asking the recruiter could confirm that, but it is unlikely to change the answer.

**Fit by requirement**
- **8+ years of growth leadership:** Strong. Nine years, and Head of Growth at two companies. [grounded]
- **Paid acquisition, lifecycle/CRM, experimentation:** Strong. You owned all three, and SQL, GA4 and Braze cover the analytics stack. [grounded]
- **Revenue growth end to end ($8M to $40M ARR):** Strong evidence of the scope, but the posted pay does not match that scope.
- **Team of one to start:** A step down from managing 3–7 people. This is an adjustment in scope, not a gap in capability, and it is not a hard gate.
- **SEO/content, brand, PR, partnerships, sales ops:** Gap. Your summary does not show these. If you have done any of them, that is a discovery item worth checking.
- **Ambiguity, evenings and weekends "when it matters":** Culture signal, not a requirement you can confirm from your background.

**Opportunity risks**
- **Title, scope and pay mismatch:** A Head title, a board dotted line and end-to-end revenue ownership, paid $70–85k with no team. The posted pay is well below what this scope usually earns. [generic]
- **Culture signals:** Evenings and weekends as the default, "we don't need a bench," and a mandatory on-site with no exceptions.
- **Employer not verified:** I did not search, so I cannot confirm Novaline's stage, size or whether this posting is live. [generic]

**Application plan:** I would not apply on these terms. The only useful step is a single question to the recruiter about remote work and the pay band. Do that only if you would consider a different structure.

**Evidence status**

Research tier: L0 — no searches

| # | Target | Status | Reason |
|---|---|---|---|
| 1 | Company site and careers page | skipped | Not consented; L0 used |
| 2 | Role-family pay and scope sweep | skipped | Not consented; L0 used |
| 3 | Hiring manager's public footprint | n/a | No name given |

If you want, I can save this as `tuesday-dossier.md`, so a future prep session starts from it. Research at L1 (up to 5 searches and 2 page fetches) would verify that Novaline exists and is hiring for this role, and would replace the [generic] pay estimate with a sourced band. Your resume or LinkedIn profile would show whether you have SEO, PR or partnerships experience, which would close the gap rows.

Did you apply already, or did a recruiter reach out? That decides whether a decline or a single gate question is the better next step.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.