**Decision snapshot**

Yes, probably worth applying: you clear the experience, Salesforce and SQL bars, and the forecast and billing-data requirements are where you're thin. `conditional_go`, with R0, R5 and R6a deciding it.

- **Fit ledger:**
  - hard_gate: R0 `unclear` (Bristol hybrid, two office days a week)
  - must_have, `direct`: R1a, R2, R3
  - must_have, `adjacent`: R1b, R4, R5
  - must_have, `unclear`: R6b
  - must_have, `absent`: R6a
- **Hard gates:** none failed (no `direct` gate rows); unconfirmed: R0 (Bristol hybrid, two office days a week); candidate constraints not given — checks against them unknown.
- **Opportunity ledger:** Quillfield checks out as a real employer, with positive signals (Series A closed April 2025, 96 staff, explicit ownership of CRM and billing data). Open unknowns are forecast decision rights (RR1), reporting line beside the Head of RevOps (RR2), whether the posting is live on the careers page (RR3) and the pay band (RR4).
- **Severe red flags:** none found.
- **What would change this:** `conditional_go` holds if the forecast answer (G1) shows real forecast-adjacent work and the billing answer (G2) shows any payments-data exposure. If neither answer holds, this moves to `hold_pending_answers`, not `no_go`.

**Role reality**

Revenue Operations Lead, Quillfield, Bristol hybrid (two days in office). £61,500–£67,000 plus share options. Owns CRM and billing data, builds pipeline and renewal reporting, runs the quarterly revenue forecast with the CFO. Hiring manager per the recruiter: Tamsin Achebe, listed publicly as Head of Revenue Operations at Quillfield, previously sales operations manager at Corvane Payments for four years. `[grounded]`

Market calibration: not run. The pay band is `[grounded]` from the posting only, not calibrated against market.

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Evidence | Provenance |
|---|---|---|---|---|---|---|---|
| R0 | Bristol hybrid, two office days a week | hard_gate | unclear | low | hard_gate | Your location not given | `[grounded]` JD text |
| R1a | 4+ years in RevOps, sales ops or analytics | must_have | direct | high | — | 5 years sales ops; last 2 running UK RevOps | `[grounded]` your account |
| R1b | At a B2B software company | must_have | adjacent | medium | transferability | B2B payments company, software-adjacent | Limit: payments, not software `[grounded]` |
| R2 | HubSpot or Salesforce administration | must_have | direct | high | — | Salesforce admin certified; rebuilt pipeline and renewal dashboards | `[grounded]` your account |
| R3 | Strong SQL | must_have | direct | medium | — | SQL weekly | "Strong" not verified `[grounded]` |
| R4 | Strong spreadsheet modelling | must_have | adjacent | medium | transferability | Excel daily; no modelling named | Limit: no forecast or financial model named `[grounded]` |
| R5 | Owning a company revenue forecast | must_have | adjacent | low | transferability | Runs monthly pipeline review with sales director; finance owned the forecast | Limit: no forecast accountability `[grounded]`; pipeline review as forecast-adjacent `[inferred]` |
| R6a | Billing data | must_have | absent | high | discovery | Stated: never worked on billing data | `[grounded]` your statement |
| R6b | Working with finance on billing or revenue data | must_have | unclear | low | discovery | Not stated | Covered by G2 |

**Gap recovery queue** (rows only; questions are in the closing block)

- **G1 (R5, transferability):** Nearest evidence is the pipeline review. No forecast call on record. Would count: commit or best-case calls, renewal forecasting, finance-facing pipeline numbers. Useful evidence: one forecast vs actuals example. `[grounded]` pipeline review; `[inferred]` that this moves the decision.
- **G2 (R6a and R6b, discovery):** Nothing stated on billing or finance revenue data. Would count: payments settlement or reconciliation work, bookings-to-invoice checks, renewal or churn numbers finance used. Useful evidence: reports or dashboards you built. If the answer is empty, R6a becomes a `capability` gap with a closure path to name.

**Opportunity risk register**

- **RR1** — forecast decision rights. Class: unknown. Hypothesis: the role runs the forecast "with the CFO" but the posting is silent on who signs it off. `[inferred]` from JD text. Verification question: "Who makes the final call on the quarterly forecast number, and what does this role own that the CFO does not?"
- **RR2** — reporting line beside the Head of RevOps. Class: unknown, low. Hypothesis: the two titles overlap in scope. `[inferred]` from titles. Verification question: "Who would I report to, and how are decisions split between this role and the Head of Revenue Operations?"
- **RR3** — posting not checked on Quillfield's careers page. Class: risk signal, low. Employer exists `[grounded]` from its about page; the only source for the posting is an aggregator. Verification question: "Is this role live on your careers site, and is it the one I would be interviewing for?"
- **RR4** — pay band uncalibrated. Class: unknown. Hypothesis: £61.5–67k may sit below or within market for this scope; no sweep run. `[generic]`. Verification question: "How was the £61,500–£67,000 range set, and what do the share options represent?"

**Application plan**

- Apply once RR3 clears on the careers page.
- Lead with: five years, two running UK RevOps, Salesforce certified, rebuilt pipeline and renewal dashboards, weekly SQL. Same-sector background is shared with Tamsin Achebe's prior role, but don't imply any connection.
- On forecasting, say it plainly: you run the monthly pipeline review with the sales director, and finance owned the company forecast. Don't describe yourself as having owned or built a forecast.
- On billing, say you haven't worked on billing data unless G2 changes that.
- Resume edits: none drafted; nothing is pending approval.

**Evidence status**

Research tier: L1 — searches 2 of 5, fetches 0 of 2; user links read 1

| # | Target | Status | Reason |
|---|---|---|---|
| 1 | Company official site and careers page | yes | Search "Quillfield invoicing software company Bristol" returned quillfield.co.uk/about (founded 2018, Bristol, 96 employees, Series A £11M April 2025). Careers page not fetched; posting liveness open (RR3). |
| 2 | Role-family sweep | skipped | Not run this pass; pay band uncalibrated (RR4). |
| 3 | Hiring manager public footprint | yes | Search "Tamsin Achebe Quillfield" returned a profile snippet: Head of Revenue Operations at Quillfield; previously sales operations manager at Corvane Payments, four years. |

**Dossier offer:** I can save this as `tuesday-dossier.md` so a later mock-interview session can pick up where this leaves off.

**Upgrade menu**

- **Your CV or a recent role description:** raises R1b, R4 and R5 above their current confidence; right now every fit claim rests on your account here, which caps it at `medium`.
- **Location, right-to-work status, notice period, salary floor:** clears R0 and the pay check.
- **Careers-page check (you or me):** confirms the posting is live and the title and reporting line match (clears RR3).
- **Role-family sweep (one search):** places £61,500–£67,000 against UK B2B software RevOps norms (clears RR4).
- **Deeper company diligence (L2):** funding and leadership churn, public candidate reports; up to 5 more searches and 2 more fetches. Offered once.

**Questions**

1. **R0:** Can you do two office days a week in Bristol, and is £61,500–£67,000 above your salary floor?
2. **G1 (R5):** In your monthly pipeline review, do you give a commit or best-case call, and how did it compare with what actually closed?
3. **G2 (R6a, R6b):** Did any of your payments-company work touch billing or invoiced revenue, such as reconciling bookings to invoices, renewal or churn numbers finance used, or settlement data? What did you own?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.