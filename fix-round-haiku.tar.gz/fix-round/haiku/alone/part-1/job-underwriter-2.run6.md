**Decision snapshot — conditional_go.** It isn't a waste of time, but the must-have title requirement is a real reach. Apply only if you can answer the three questions below with specifics.

**Fit ledger**

- **Must-have**
  - Partial: 3+ years of PM experience (row 1)
  - Partial: shipped API or platform products (row 2)
- **Preferred / implied**
  - Strong: technical fluency with APIs and schemas (row 3)
  - Strong: stakeholder management across engineering, sales and customers (row 4)
  - Partial: spec writing and partner discovery (row 5)
  - Partial: launch coordination with sales and support (row 8)
  - Unverified: adoption metrics (row 6)
  - Unverified: agile delivery (row 7)

**Hard gates:** None in the posting. The 3-year requirement is a must-have, not a gate. Your pay, location and schedule constraints weren't provided, so they are unknown against this role.

**Confidence:** Moderate on substantive fit. Low on whether an initial screen will credit your background as product experience.

## Role reality

- Quartzline is a ~150-person B2B logistics-tech company at Series B. The PM owns the partner-facing API roadmap and drives delivery with two engineering squads. [grounded, JD]
- Scope: likely the main or only PM on the platform, though that is unconfirmed. [inferred from "own the roadmap" plus two squads]
- Market calibration: API and platform PM roles at this stage usually ask for several years of PM work, but they do hire people from integration or solutions backgrounds when those people can show product decisions. [generic — pattern, not research]
- Compensation is not stated. The posting withholding it is worth a question.

## Evidence status

Research tier: L0 — no searches. No company link was provided, so no targets were run.

| Target | Status | Reason |
|---|---|---|
| 1. Company site and careers page | skipped | L0; no link given |
| 2. Role-family sweep | skipped | L0 |
| 3. Hiring manager footprint | n/a | No name given |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Evidence |
|---|---|---|---|---|---|---|
| 1 | 3+ yrs PM experience | Must-have | Partial | Low | Title | No PM title. Roadmap-input sessions and requirements docs are product-adjacent, not ownership. |
| 2 | Shipped API/platform products | Must-have | Partial | Moderate | Ownership | 30+ REST integrations delivered end to end. You delivered them; you did not own the product. |
| 3 | Technical fluency | Preferred | Strong | High | — | Postman, SQL, OpenAPI, integration architecture. Claimed, not yet checked. |
| 4 | Stakeholder management | Preferred | Strong | High | — | Coordinated vendor, client and PM teams on custom builds. |
| 5 | Specs and partner discovery | Implied | Partial | Moderate | Format | Requirements docs and workshops match; the roadmap-owner framing is missing. |
| 6 | Adoption metrics | Implied | Unverified | Low | Evidence | No metrics on the resume. |
| 7 | Agile delivery | Implied | Unverified | Low | Evidence | Not on the resume. |
| 8 | Launch coordination | Implied | Partial | Moderate | Scope | Go-live coordination is there; sales and support launch work is not stated. |

Your memory note about the request-triage tool is a lead, not evidence, and is not in this map. It becomes relevant only if you confirm it.

## Opportunity risk register

- **R1 — Title screen (medium-high):** The must-have is written as years of PM experience, and you have none by title. An automated or recruiter screen may stop the application here.
- **R2 — Employer unverified (medium):** No live posting, careers page or recruiter domain was provided. A `go` needs that check.
- **R3 — Pay unstated (medium):** Can't be calibrated against your floor.
- **R4 — Scope unclear (low-medium):** A solo PM over two squads at Series B may come with little product mentorship. [inferred]

## Gap recovery queue

- **G1 (rows 1–2):** Closed by naming product decisions you drove. Not closed by job-title changes.
- **G2 (row 6):** Closed by any outcome numbers you tracked, even approximate.
- **G3 (row 7):** Closed by a clear account of your role in sprints or backlog work.
- **G4 (triage tool):** Lead only. Would move row 2 toward Strong if confirmed with adoption details.

## Application plan

Position this as a partner-side product lead, not as a PM who has done this before. Proposed positioning, pending your approval (`resume_edits_pending_approval`):

> Seven years running partner-facing API integrations end to end: discovery, requirements, architecture, UAT and go-live. Fed client-driven roadmap inputs to product.

Don't use the words "product manager" or "owned the roadmap" unless your answer to question 1 supports it.

## Questions

1. **(G1, rows 1–2)** Name one product decision you made or drove during the integrations work or the playbook. What did you choose, what did you reject, and what changed for the product or its partners?
2. **(G2, row 6)** Did you track any numbers across integrations, such as time to go-live, partner count, support volume, or feature requests that became shipped work? Approximate figures are fine.
3. **(G3, row 7; G4)** Did you work in sprints or against a backlog with the engineering teams? Did you build the request-triage tool your memory notes mention? If so, who adopted it, and how do you know?

You can answer in any order, and "skip" is a valid answer.

## Upgrade menu

- **Posting link or careers page:** resolves R2 and unlocks the employer check.
- **Pay band or your floor:** unlocks the compensation check for R3.
- **L1 research (up to 5 searches, 2 fetches):** checks the company and role-family norms, replacing the `[generic]` calibration.
- **Portfolio or playbook excerpt, only if you choose to share it:** turns "Wrote the integration playbook" into something checkable.
- **Triage tool details:** would strengthen row 2 if confirmed.

I can save this assessment as `tuesday-dossier.md` so your next prep session starts from it.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.