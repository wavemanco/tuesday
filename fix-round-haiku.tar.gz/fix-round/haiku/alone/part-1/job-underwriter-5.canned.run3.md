**Yes, apply, with one condition: confirm the employer first. Status: `conditional_go`.**

**Fit ledger.**
- `hard_gate`: unclear: R1 (US remote or Denver office), R2 (salary against your floor)
- `must_have`: direct: R3 (5+ years), R4 (SQL and Python), R5 (dbt), R6 (cloud warehouse), R7 (Airflow), R8 (data quality testing)
- `important`: adjacent: R9 (BigQuery warehouse); unclear: R10 (app and CRM ingestion), R11 (data contracts for analysts)

R9 is the BigQuery gap. It is a transferability gap on a stack detail, not a hard gate: the requirement list says "a cloud warehouse," and you meet that on Snowflake. R10 and R11 are the real unknowns, and they are about what you have built, not what you lack.

**Opportunity ledger.** The posted salary sits inside the market band (RR4), and the scope reads as typical for the title (RR3). The employer itself is not yet established (RR1), and equity is unpriced (RR2).

- **Hard gates:** none failed; unconfirmed: R1 (US remote or Denver office location), R2 (salary against your floor); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **Conditions for go:** (1) the employer verifies (RR1); (2) location and salary floor confirmed (R1, R2); (3) BigQuery is presented as transferable experience, never as hands-on BigQuery work (R9).

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Live online K-12 tutoring, 31 states, Denver, 264 staff, Series C ($52M, Feb 2026) | `[grounded]` your copy of the about page; not independently confirmed (search returned nothing) |
| Mandate | Reporting pipelines; app and CRM ingestion; dbt warehouse in BigQuery; data contracts for analysts | `[grounded]` JD, and the live careers page matches it word for word |
| Scope | Ownership of one domain's pipelines, analysts as consumers, no reports stated | `[inferred]` from the JD; `[generic]` typical senior scope per the Datawright report |
| Market calibration | Senior DE at Series B–D: base median $151,000, IQR $139,000–$163,500. Posting $148,000–$166,000 sits from the median to the upper half. Equity is unquantified. | `[generic]` Datawright 2026 (n=2,310, US), which covers B–D, not C; `[grounded]` posting figure |
| Unknowns | Equity terms; hiring manager; team size; whether CRM ingestion already exists | — |
| Contradictions | None between the JD and the live careers page | `[grounded]` fetched page |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | US remote or Denver office | hard_gate | unclear | none | hard_gate | Your location is not in the material | `[grounded]` JD | Q3 |
| R2 | Salary $148k–$166k against your floor | hard_gate | unclear | none | hard_gate | Your floor is not given | `[grounded]` JD | Q3 |
| R3 | 5+ years data engineering | must_have | direct | medium | none | Six years at a payroll company (self-report) | `[grounded]` your background | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | Daily use (self-report) | `[grounded]` your background | none |
| R5 | dbt | must_have | direct | medium | none | About 180 models on Snowflake | `[grounded]` your background | none |
| R6 | Cloud warehouse | must_have | direct | medium | none | Snowflake | `[grounded]` your background | none |
| R7 | Airflow or similar | must_have | direct | medium | none | Airflow for orchestration | `[grounded]` your background | none |
| R8 | Data quality testing | must_have | direct | medium | none | Set up the Great Expectations suite | `[grounded]` your background | none |
| R9 | BigQuery warehouse | important | adjacent | medium | transferability | Snowflake dbt carries over; BigQuery specifics (cost model, partitioning, IAM) unused | `[inferred]` from your Snowflake work; BigQuery never used, per you | G1 |
| R10 | Ingestion from app and CRM | important | unclear | low | discovery | Not in your background | `[grounded]` absence from CV | G2 |
| R11 | Data contracts analysts depend on | important | unclear | low | discovery | Not in your background | `[grounded]` absence from CV | G3 |

Confidence is `medium` at most, because nothing has been inspected yet.

**Gap recovery queue**
- **G1** (R9, transferability): You have dbt and warehouse experience on Snowflake but no BigQuery. The limit is BigQuery-specific cost and partitioning, dataset and IAM setup, and the query dialect. A strengthener would be a short BigQuery project on a public dataset. Provenance: `[inferred]` from your background.
- **G2** (R10, discovery): The posting makes app and CRM ingestion central. Your background does not mention it. Provenance: `[grounded]` absence from CV.
- **G3** (R11, discovery): The posting makes analyst-facing data contracts a responsibility. Your background does not mention them. Provenance: `[grounded]` absence from CV.

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Pellucid Learning runs live online tutoring…" | The only footprint is the company's own site. The search found no independent coverage. The company may be newer or smaller than its about page suggests. | `[generic]` pattern for companies of this size, not a claim about this one | Which legal entity employs this role, and can you point me to the Series C announcement? | unresolved |
| RR2 | Equity unpriced | unknown | — | "plus equity" | Equity value cannot be weighed against the salary | `[inferred]` from the posting's silence on grant terms | What equity grant does this role carry, and what are the vesting and strike terms? | unresolved |
| RR3 | Scope and team unknown | unknown | — | "Build and run the pipelines…" | You may be the sole owner of the reporting domain with analysts as consumers | `[inferred]` from JD responsibilities | Who is the hiring manager, and how many data engineers work alongside this role? | unresolved |
| RR4 | Salary inside the band | positive_signal | — | "$148,000–$166,000" | The posted salary is credible for the title | `[generic]` band; `[grounded]` posting figure | — | noted |

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Check the recruiter's email domain against pellucidlearning.com and look up the Series C announcement yourself | RR1 | `[grounded]` RR1 | proposed |
| A2 | Lead with the stack that matches: dbt at about 180 models, Airflow, Great Expectations, daily SQL and Python | R3–R8 | `[grounded]` your background | pending your approval |
| A3 | Present BigQuery as transferable: "dbt on Snowflake at about 180 models; no production BigQuery yet." Name the limit, and offer a short BigQuery project as the closure path. | R9, G1 | `[inferred]` from your background | pending your approval |
| A4 | Do not claim CRM ingestion or data contracts unless your answer to Q1 or Q2 confirms them | R10, R11 | `[grounded]` absence from CV | proposed |
| A5 | Ask the recruiter for equity terms and the hiring manager's name before the loop | RR2, RR3 | `[grounded]` register | proposed |

Any wording for A2 and A3 is proposed, not finalized. It needs your explicit approval before you send it.

**Evidence status**

Verified: none yet.

Research tier: L1 — searches 1 of 5, fetches 1 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Pellucid Learning live online tutoring K-12 Denver": no results, so the employer is not established from attributable sources. Fetched pellucidlearning.com/careers/senior-data-engineer: the posting is live and matches the JD text. Moved RR1 and the contradictions row. |
| 2. Role-family sweep | skipped | The Datawright report the recruiter sent already fixes the band this target would feed. |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form. |

**Dossier offer:** I can save this as `tuesday-dossier.md` if you want it kept.

**Upgrade menu**
- An answer to Q1 or Q2 (G2, G3) confirms or clears R10 and R11, which moves the decision.
- An answer to Q3 closes R1 and R2.
- A BigQuery project or a dbt-to-BigQuery migration note raises R9's bridge.
- A deeper research pass on Pellucid Learning (funding, leadership changes, reviews; up to 5 more searches and 2 more fetches) would test RR1 further. Say the word and I'll run it.

**Questions**
1. **G2:** Have you built ingestion from an app or a CRM? Describe the closest example: what you pulled, how often, and what broke.
2. **G3:** Have you owned a data contract that analysts depended on? Describe the schema promises, how changes were communicated, and who consumed it.
3. **R1 and R2:** Are US-remote work and a salary floor hard limits for you? If so, what is the floor?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.