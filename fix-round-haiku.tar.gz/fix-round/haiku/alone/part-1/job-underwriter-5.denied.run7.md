I'll read the skill's reference files before building the assessment.
The skill's rules are loaded. Next I'll check the employer and the market with the L1 research budget, starting by loading the search and fetch tools.
**Yes, on the core stack, with conditions. Status: `conditional_go`.** Your dbt, Airflow, Great Expectations, SQL and Python match five of the must-haves, and the 180-model dbt project is the strongest point. BigQuery is the gap you would have to talk through. The posting and employer are unverified because research was refused (see Evidence status).

**Fit ledger.**

- `hard_gate` — unclear: R1 (Remote (US) or Denver office), R2 (Salary $148,000–$166,000)
- `must_have` — direct: R3 (5+ years data engineering), R4 (strong SQL and Python), R5 (dbt and a cloud warehouse), R6 (orchestration with Airflow), R7 (data quality testing)
- `important` — adjacent: R8 (BigQuery warehouse); unclear: R9 (ingestion from our app and CRM), R10 (data contracts analysts depend on)

The fit is adjacent on R8 and unclear on R9 and R10. R1 and R2 are gates you have not yet answered. R3 to R7 are direct on your stated experience at intake, which is the medium ceiling until something inspectable backs them.

**Opportunity ledger.** Pay is at or above the market median (RR5), and the company's stated scale is positive (RR6). Against that, the posting and employer are unverified (RR1), contract basis is silent (RR2), and the three named areas may exceed a typical one-domain remit with no hiring manager named (RR3). Equity is unquantified (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Remote (US) or Denver office), R2 (Salary $148,000–$166,000); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **Conditions for go:** (1) the live posting and employer check out (RR1); (2) your location and pay floor clear R1 and R2; (3) the BigQuery gap is framed as transferable, never as experience (R8).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning, live online tutoring for K-12 schools in 31 US states; founded 2016, Denver; 264 employees; Series C ($52M, February 2026) | `[grounded]` the company's about page as you pasted it; not verified (see Evidence status) |
| Mandate | Build and run ingestion from the app and CRM, a dbt-modelled warehouse in BigQuery, and the data contracts analysts depend on | `[grounded]` JD |
| Location | Remote (US) or Denver office | `[grounded]` JD |
| Pay | $148,000–$166,000 base plus equity; midpoint $157,000 | `[grounded]` JD |
| Market calibration | Base median $151,000; interquartile range $139,000–$163,500 for Senior Data Engineers at Series B–D companies. The posted floor sits inside the range, the midpoint above the median, and the top above the upper quartile | `[generic]` Datawright 2026 report, US, n=2,310, as supplied by your recruiter; not independently checked |
| Seniority | "Senior" typically means 5–8 years; you have 6 | `[generic]` same report; `[grounded]` your background |
| Scope read | Three areas (ingestion, warehouse, contracts) against the report's typical one-domain scope with no direct reports; this posting looks broader than typical | `[inferred]` from the JD's scope against the report's typical scope |
| Contract type | Not stated | `[grounded]` JD silence |
| Hiring manager | Not named | `[grounded]` JD |
| Unknowns | Contract basis; equity size; whether the team already runs BigQuery or plans a migration; who owns ingestion and contracts | — |
| Contradictions | None visible between the JD, the about page and the recruiter's pay figures. The live careers page was not checked | `[grounded]` provided material |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | No candidate location or work status given; the gate cannot be checked | `[grounded]` JD; candidate silent | Answer the question below |
| R2 | Salary $148,000–$166,000 | hard_gate | unclear | none | hard_gate | No pay floor given | `[grounded]` JD; candidate silent | Answer the question below |
| R3 | 5+ years data engineering | must_have | direct | medium | none | Six years, stated specifically; no inspectable artifact yet, so the verification caveat applies | `[grounded]` your background | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | Used daily, stated specifically; no code sample yet | `[grounded]` your background | Offer a sanitized query or pipeline sample if you have one |
| R5 | dbt and a cloud warehouse | must_have | direct | medium | none | dbt on Snowflake, about 180 models; Snowflake counts as a cloud warehouse | `[grounded]` your background | none |
| R6 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow stated; no DAG sample yet | `[grounded]` your background | none |
| R7 | Experience with data quality testing | must_have | direct | medium | none | Set up a Great Expectations suite; the suite itself is not inspected | `[grounded]` your background | Offer a suite excerpt if shareable |
| R8 | Dbt-modelled warehouse in BigQuery | important | adjacent | medium | transferability | dbt and cloud-warehouse work carry over; BigQuery specifics are not exercised, and the transfer case is a claim, not experience | `[inferred]` adjacency from R5 and the JD's scope; `[generic]` that BigQuery differs from Snowflake in dialect, cost model and partitioning | See G1 |
| R9 | Ingestion from our app and CRM | important | unclear | low | discovery | Not in your background; may exist and be unmentioned | `[grounded]` JD; candidate silent | Ask (closing block) |
| R10 | Data contracts analysts depend on | important | unclear | low | discovery | Not in your background; may exist and be unmentioned | `[grounded]` JD; candidate silent | See G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R8, important) | transferability | Snowflake and dbt experience; no BigQuery | The posting names BigQuery in its first sentence, so the interview will test it | A dbt adapter switch, a warehouse migration, cost or partition tuning on Snowflake | A small BigQuery project, or a dated course project labelled as personal | `[inferred]` bridge from R5; `[generic]` that interviewers probe the platform named in the JD |
| G2 | Ingestion from app and CRM (R9, important) | discovery | Your background does not mention source ingestion | Named as the first responsibility | Source connectors, CDC, API pulls from a CRM, event pipelines | Pipeline diagram, DAG excerpt | `[grounded]` JD; candidate silent |
| G3 | Data contracts (R10, important) | discovery | Your background does not mention contracts | Named as the output analysts depend on | Schema agreements with producers, versioned models, breaking-change handling | A contract or schema doc | `[grounded]` JD; candidate silent |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posting and employer not verified | unknown | — | "Senior Data Engineer — Pellucid Learning" | The posting may be stale, or the company facts may be its own claims only | `[generic]` pattern for postings pasted without a live link; company facts `[grounded]` as supplied, unverified | Is this role open on your careers site today, and who would I be interviewing with? | unresolved |
| RR2 | Contract basis unstated | unknown | — | JD silent on contract type | The post could be fixed-term or contract | `[inferred]` from JD silence | Is this position permanent, or fixed-term or contract? | unresolved |
| RR3 | Hiring manager unnamed; scope may exceed one domain | risk_signal | medium | "Build and run the pipelines behind our tutoring platform's reporting" | Three areas in one role may stretch ownership; the split between them is unclear | `[inferred]` from JD scope against `[generic]` report's typical one-domain scope | Which of these three areas would this role own alone, and who would I report to? | unresolved |
| RR4 | Equity unquantified | unknown | — | "plus equity" | The total package is unknown beyond base | `[grounded]` JD silence on size | What is the equity grant size and vesting schedule? | unresolved |
| RR5 | Stated pay at or above market median | positive_signal | — | "$148,000–$166,000" | Pay is likely competitive for the title | `[generic]` report median; `[grounded]` JD | How is the band set, and is there room within it? | noted |
| RR6 | Stated company scale | positive_signal | — | "Series C ($52M, February 2026)" | A funded company of this size usually has a data team; unverified | `[grounded]` about page as supplied; `[generic]` size pattern | How big is the data team today, and is BigQuery already the warehouse or is a migration planned? | noted |

Severity reads `—` on `unknown` and `positive_signal` rows because it applies only to risk signals and red flags.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Check the live posting and employer on their careers site, and confirm the recruiter's email domain, before investing in an application | see RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Frame BigQuery as transferable from Snowflake and dbt, with the limit stated. Claim no BigQuery experience | see R8, G1 | `[grounded]` R8; reframing audit applies to any wording | pending your approval |
| A3 | Lead positioning with the directly matched core: dbt on Snowflake (about 180 models), Airflow, and the Great Expectations suite | see R5, R6, R7 | `[grounded]` your background at medium confidence | pending your approval |
| A4 | Ask the recruiter whether the role is permanent and how the data team is structured | see RR2, RR3 | `[inferred]` from JD silence | pending your approval |

## Evidence status

Verified: none yet. Every claim above is your intake self-report at medium, not yet probed or inspected.

Research tier: L1 — searches 3 of 5, fetches 1 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searches for the company and its posting, and a fetch of the careers page, were all refused. Would have moved RR1 and the contradictions row. Refused permission; not retried |
| 2. Role-family sweep | unavailable | A search for senior data engineer pay was refused. Would have moved the market calibration and RR5 from the supplied report to an independent source |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

## Upgrade menu

- Permission for web search and page fetch → targets 1 and 2 run: confirms or contradicts RR1 and RR6, and tests the recruiter's pay figures against an independent source.
- Your US location and pay floor → R1 and R2 close, and the decision either holds or moves.
- Ingestion or contracts examples, or a sanitized pipeline or DAG sample → R9 and R10 move from unclear toward a confirmed claim.
- A small BigQuery project or course project, dated and labelled personal → G1 can narrow R8's limit. It is a new claim, so it needs its own confirmation.
- The recruiter's answers on contract type and hiring manager → RR2 and RR3 close.

I can write this into a `tuesday-dossier.md` you can keep and reuse.

Questions:

R1 — Are you based in the US, and is remote or the Denver office workable for you?

R2 — What base pay is the floor you would accept, and is $148,000 at or above it?

R9 — Have you built ingestion from an app or a CRM, and who owned it?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.