**Decision: `conditional_go`.** The fit is strong on the core of the role. The posting is unverified, and compensation and location are unknown, so I'd apply once you've confirmed the employer and the basics.

**Fit ledger** (from the evidence map below)
- **must_have, direct:** 5+ years product analytics (R1), expert SQL (R2), experiment design at scale (R3), Looker or similar BI (R4), owning a metrics layer (R8), written communication with non-technical stakeholders (R5)
- **must_have, adjacent:** partnering with PMs and clinicians (R7). PM partnership is direct; clinician partnership is not.
- **important, unclear:** mentoring two junior analysts (R6)
- **preferred, adjacent:** healthcare data and HIPAA (R9)

**Hard gates:** None are stated in the posting. Your own constraints (location, pay floor, authorization, start date) weren't provided, so those checks are unknown.

**Research tier: L1 — searches 3 of 5, fetches 0 of 2; user links read 0**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Three web searches were sent and refused for lack of permission. Employer existence and whether the posting is live are unverified. |
| 2. Role-family sweep | unavailable | Same refusal. No market calibration for title, scope or pay. |
| 3. Hiring manager's public footprint | n/a | No name was given. |

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, described as a digital-health scale-up of about 400 people with a Series C | `[grounded]` JD text only; not verified |
| Mandate | Own product analytics for the care-navigation app: metrics layer, A/B tests, self-serve Looker, PM and clinician partnership, mentoring two analysts | `[grounded]` JD |
| Scope read | Senior individual-contributor analytics ownership plus two direct reports' worth of mentoring. Whether the mentoring is formal management is unknown. | `[inferred]` from the mentoring requirement |
| Market calibration | Not available: the sweep didn't run. I won't supply a pay band from memory. | — |
| Unknowns | Compensation, location and remote policy, reporting line, team size, warehouse stack, whether the role touches protected health information (PHI) | — |
| Contradictions | None between the JD and your description. Nothing else is available to check it against. | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | Six years at a subscription company. Stated, not yet inspectable. | `[grounded]` your CV summary | none |
| R2 | Expert SQL | must_have | direct | medium | none | Daily SQL on Snowflake. Specific, with no artifact yet. | `[grounded]` your CV summary | none |
| R3 | Experiment design at scale | must_have | direct | medium | none | 30+ tests a year and an experimentation program you designed. The 11% retention lift is a specific claim with no write-up yet. | `[grounded]` your CV summary | Offer: a sanitized test write-up would raise this to high |
| R4 | Looker or similar BI | must_have | direct | medium | none | Built the Looker instance from scratch; 40+ governed dashboards. | `[grounded]` your CV summary | none |
| R5 | Written communication with non-technical stakeholders | must_have | direct | medium | presentation | Monthly metrics memo read by the exec team; presents to the VP Product monthly. The memo is strong evidence, but it isn't attached. | `[grounded]` your CV summary | Offer: a scrubbed memo sample would raise this to high |
| R6 | Mentor two junior analysts | important | unclear | low | discovery | Nothing in the inputs about mentoring or managing analysts. | `[grounded]` absence in inputs | Question 1 |
| R7 | Partner with PMs and clinicians on roadmap decisions | must_have | adjacent | medium | transferability | PM partnership is direct: the exec memo and VP Product presentations. Clinicians are not. Limit: no clinical stakeholder work. | `[inferred]` from the memo and presentation work | Gap G2 |
| R8 | Define and maintain a metrics layer | must_have | direct | medium | none | Governed dashboards and a monthly metrics memo imply metric definitions were owned. The word "metrics layer" is not in your inputs. | `[inferred]` from the dashboard and memo work | none |
| R9 | Healthcare data and HIPAA | preferred | adjacent | medium | transferability | GDPR and CCPA consumer-PII handling, and a consent-state model in the warehouse, carry over. Limit: no PHI, no HIPAA rules, no clinical data. | `[grounded]` your CV summary; `[inferred]` transfer | Gap G1 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Healthcare and HIPAA (R9, preferred) | transferability | Consumer-PII and consent work. Nothing on PHI or HIPAA. | Preferred, not must-have. The likely probe is how you'd handle PHI, which the consent work doesn't answer. | Any health or dietary-restriction data in the meal-kit business and how it was governed; consent or retention rules you built that were stricter than GDPR/CCPA | A data-governance doc or a consent-model diagram | `[grounded]` CV; `[inferred]` that PHI questions are the likely probe |
| G2 | Clinician partnership (R7) | transferability | PM partnership and exec communication. No clinical stakeholders. | Clinicians are named in the responsibilities. | Working with operations, fulfillment or customer-care teams who weren't PMs; any stakeholder outside product | A stakeholder map or a case where analysis changed a non-product decision | `[grounded]` JD; `[inferred]` bridge |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer unverified | risk_signal | medium | "digital-health scale-up, ~400 people, Series C" | The company may not be as described, or the posting may be stale. Standing entry: caps the decision at `conditional_go`. | `[generic]` pattern for unverified postings, not a claim about this company | Send the live posting link or the recruiter's email domain | unresolved |
| RR2 | Compensation, location and remote policy unstated | unknown | — | Not in the posting | Could fall outside your floor or your location. Nothing in the inputs settles it. | `[inferred]` from the posting's silence | What is the budgeted range, and is the role remote? | unresolved |
| RR3 | Clinical data scope | risk_signal | medium | "care-navigation app"; "healthcare data (HIPAA) a plus" | A care-navigation product likely handles PHI. That brings access controls and compliance review into analysts' daily work. | `[inferred]` from the product domain | Does the role have direct PHI access, and what is the approval process for data access? | unresolved |
| RR4 | Mentoring may mean formal management | unknown | — | "mentor two junior analysts" | Could be informal coaching or direct reports, which changes the role's scope. | `[inferred]` from the wording | Are the two analysts direct reports? | unresolved |
| RR5 | Defined ownership and mandate | positive_signal | — | "define and maintain the metrics layer"; "design and analyze A/B tests" | Clear scope, with ownership written in the posting. | `[grounded]` JD | — | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead the CV with the experimentation program and the Looker build, then the metrics memo | These are the strongest direct matches (R3, R4, R5). | `[grounded]` CV | pending your approval |
| E2 | Reframe the consent work as: "Designed the consent-state model in our warehouse to govern GDPR/CCPA consumer data use." | Accurate and specific, and it doesn't imply health-data experience. | `[grounded]` CV | pending your approval |
| E3 | Prepare an honest answer on PHI: consumer-PII experience, no PHI work, and how you'd learn the HIPAA rules | Likely probe for R9 and RR3. Don't claim HIPAA familiarity. | `[grounded]` R9; `[inferred]` probe | pending your approval |
| A1 | Ask the recruiter for the live posting and the comp and location range before investing time | Resolves RR1 and RR2 | `[grounded]` RR1, RR2 | pending your approval |

Nothing above is externally visible yet. The CV edits (E1, E2) and any outreach need your explicit approval before anything is sent or changed.

## Evidence status

Confidence is medium on most rows because your claims are CV-only. Your inputs don't include a written memo, a test write-up, or a dashboard.

## Upgrade menu

- **Live posting or recruiter's email domain:** verifies the employer (RR1) and, with the posting, may settle compensation and location (RR2).
- **Permission to run web search:** enables the company check and the role-family sweep, so the market calibration can be grounded.
- **Scrubbed metrics memo or dashboard screenshot:** raises R5 and R4 toward high.
- **Write-up of the 11% pricing test:** raises R3 toward high.
- **Your pay floor, location and work authorization:** lets the hard-gate checks run.

If you'd like, I can also turn this into a `tuesday-dossier.md` file you can reuse later.

**Q1 (R6 / RR4):** Have you directly managed or formally mentored analysts? If so, what did that look like: direct reports, or informal coaching?

**Q2 (R9 / RR3):** Did any of your consent or PII work touch health or dietary-restriction data, such as allergies? If so, how was access controlled?

**Q3 (RR1 / RR2):** Can you send the live posting link or the recruiter's email domain, so I can confirm the employer and find out the pay and location?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.