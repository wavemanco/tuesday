**Decision: conditional_go.** Apply. Your core evidence matches the JD's core requirements, and the main gap is domain, not capability. Three things need resolving before you invest interview time: the scope of "own", the compensation, and whether Brindlemoor is verified as described.

**Hard gates:** None failed on what you've given me. Fully remote UK fits a UK-based background [grounded]. Right to work and location aren't stated, so they're unknown, not passed.

**Fit ledger**
- **Met, high confidence:** 4+ years pricing analytics (5 years, last 2 senior); build and maintain rating models (young-driver GLM); GLM experience; presenting to underwriting leads (quarterly review); insurance experience (UK motor).
- **Met, medium confidence:** Strong SQL and Python. You state daily use, but not depth.
- **Partial:** Turning results into recommendations for product. Your evidence is underwriting-facing only.
- **Gap:** Pet insurance. Not present in your background.
- **Unknown:** People leadership. The JD says "own pricing analytics" but doesn't say whether the role has direct reports.

**Evidence map**

| # | Priority | Fit | Confidence | Gap | Requirement | Evidence |
|---|---|---|---|---|---|---|
| 1 | must | met | high | none | 4+ yrs pricing/actuarial analytics | 5 yrs, last 2 senior [grounded: CV] |
| 2 | must | met | high | none | Build and monitor rating models | Built and maintained young-driver GLM [grounded: CV] |
| 3 | must | met | high | none | GLM experience | Same model; JD names GLM [grounded] |
| 4 | must | met | high | none | Design and read price tests | Ran 14 tests last year with underwriting [grounded: CV] |
| 5 | must | met | medium | none | Strong SQL | Daily use stated; depth not shown [grounded: CV] |
| 6 | must | met | medium | none | Strong Python | Daily use stated; depth not shown [grounded: CV] |
| 7 | must | met | high | none | Presenting to underwriting/actuarial leads | Quarterly review to head of underwriting [grounded: CV] |
| 8 | preferred | met | high | none | Insurance experience | UK motor insurer [grounded: CV] |
| 9 | must | partial | medium | transferability | Recommendations for underwriting and product | Underwriting only; no product-side evidence |
| 10 | implied | gap | high | transferability | Pet-insurance product knowledge | Absent. Motor GLM skills carry over; the drivers differ (breed, age, vet-cost inflation, cover structure) [generic] |
| 11 | unknown | unknown | low | discovery | People leadership | JD silent on direct reports |

**Gap recovery queue**
- **Row 10 (pet domain):** Closes only by naming how your motor rating method would adapt to pet claims, and what you'd test first. It can't be closed by claiming pet experience.
- **Row 9 (product):** Closes with any example where a price-test result changed a product decision, even if it went through underwriting.
- **Row 11 (leadership):** Closes once the role's scope is confirmed (question 1 below).

**Opportunity risk register**
- **Compensation unstated (medium):** The posting withholds it. I have no band to calibrate against, since no research has run.
- **Employer unverified (medium, standing):** I have not confirmed Brindlemoor exists as described or that this posting is live. Resolve with the live posting link, the company careers page, or the recruiter's email domain.
- **Insurtech stage unknown (low to medium):** Product maturity and team size aren't stated. Relevant to how much you'd own.
- **Possible management expectation (medium):** Unresolved until question 1.

**Application plan**
- Lead with the young-driver GLM you built and maintained, the 14 price tests, and the quarterly underwriting presentation. Confirm the figures before you quote them.
- Frame pet as a transferability question with a specific first plan. Don't claim pet experience.
- Don't claim people management or product ownership. "Built and maintained" is accurate; "led" or "owned" needs tenure and scope to back it.
- No resume edits are proposed yet. Any CV wording needs your approval before it's used.

**Evidence status**
Research tier: L0 — no searches

| Target | Status | Reason |
|---|---|---|
| 1. Company site and careers page | skipped | Research not consented; no search run |
| 2. Role-family sweep (scope, title, pay) | skipped | Research not consented; no search run |
| 3. Hiring manager's public footprint | skipped | Research not consented; no search run |

User links read: 0.

I can run the L1 research on your go-ahead. I can also build a tuesday-dossier.md file to keep this assessment and carry it into later sessions, if you'd like one.

**Upgrade menu**
- **Full JD link:** Verifies the requirement wording and the live posting. Closes the employer-unverified risk.
- **Compensation band or your floor:** Calibrates the one unstated term.
- **A redacted GLM or price-test work sample:** Would raise the SQL, Python and price-test rows to high.
- **L1 research:** Adds the employer check, role-family pay, and Odile Varga's public professional footprint. Public footprint only.
- **Location and right-to-work:** Confirms the hard gates.

**Questions**
1. Does this role have direct reports, or does "own" mean individual ownership of the analytics? This decides whether the leadership gap is real.
2. What's your compensation floor, and do you know Brindlemoor's band?
3. Do you want me to run the L1 research on Brindlemoor (up to 5 searches and 2 page fetches)?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.