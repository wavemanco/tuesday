Yes, it's worth applying, as `conditional_go`. Your must-haves line up with the posting. The open items are location, ingestion and data contracts, and BigQuery. The employer itself hasn't been checked independently, because the web searches were denied.

- **Fit ledger:** must-haves R2, R3, R4, R6 and R7 are `direct`. R5 (BigQuery) is `adjacent`. R8 (ingestion from app and CRM), R9 (data contracts) and R10 (owning a domain's pipelines) are `unclear`, because your background doesn't say.
- **Opportunity ledger:** The stated scope is concrete: reporting pipelines, a named stack, and a contracts mandate. The pay range is in-market (see R11 below). Against that, the employer is unverified (RR1), and equity, hiring manager and on-call expectations are unstated (RR2–RR4).
- **Hard gates:** unconfirmed: R1 (remote US or Denver office). Your location and work authorization weren't given, so checks against them are unknown.
- **Severe red flags:** none found.
- **What would change this:** `conditional_go` holds if (a) the posting is confirmed live on their own careers page, (b) you have real ingestion or data-contract experience to speak to, and (c) your location and work authorization fit R1. If (b) is no, the fit drops and I'd re-underwrite. If (c) fails, it's `no_go`.

Research tier: L1 — searches 3 of 5, fetches 0 of 2; user links read 0

### Role reality
- **Role:** Senior Data Engineer, Pellucid Learning. Build and run reporting pipelines for live K-12 tutoring: app and CRM ingestion, a dbt-modelled warehouse in BigQuery, and data contracts for analysts. `[grounded]` from the JD.
- **Organization:** live online tutoring for K-12 schools in 31 states, founded 2016, Denver, 264 employees, Series C ($52M, Feb 2026). `[grounded]` from the About page, self-reported; not externally verified.
- **Scope:** one domain (reporting) with ownership signals. Team size, reporting line and direct reports are not stated.
- **Market calibration:** "Senior" at Series B–D is typically 5–8 years with one-domain ownership and no direct reports. You fit that band on years. `[generic]`, from the Datawright 2026 report you supplied (n=2,310, not independently re-checked).
- **Contradictions:** none found between the JD and the About page.

### Evidence map
| # | Requirement | Priority | Fit | Confidence | Gap | Evidence |
|---|---|---|---|---|---|---|
| R1 | Remote US or Denver office | hard_gate | unclear | — | unknown | Your location and work authorization were not given |
| R2 | 5+ years data engineering | must_have | direct | high | — | 6 years at a B2B payroll company |
| R3 | Strong SQL and Python | must_have | direct | medium | — | Daily use; CV-only claim |
| R4 | dbt and a cloud warehouse | must_have | direct | medium | — | dbt project of ~180 models on Snowflake; CV-only claim |
| R5 | BigQuery warehouse (named in responsibilities) | important | adjacent | medium | tool | Never used BigQuery; Snowflake is transferable |
| R6 | Orchestration (Airflow or similar) | must_have | direct | medium | — | Airflow in production; CV-only claim |
| R7 | Data quality testing | must_have | direct | medium | — | Set up a Great Expectations suite; CV-only claim |
| R8 | Ingestion from app and CRM | important | unclear | — | evidence | Not in your background |
| R9 | Data contracts analysts depend on | important | unclear | — | evidence | Not in your background |
| R10 | Owning a domain's pipelines end to end | important | unclear | — | scope | Implied by your history, not stated |
| R11 | Pay: $148,000–$166,000 plus equity | — | in-market | — | — | Midpoint $157k vs. [generic] median $151k, IQR $139k–$163.5k |

### Gap recovery queue
- **G1 (R5, BigQuery):** not a hard gate. Closes if you can credibly speak to the Snowflake-to-BigQuery mapping, or have any BigQuery exposure at all.
- **G2 (R8, ingestion):** closes with a concrete example of app or CRM sources you have ingested.
- **G3 (R9, data contracts):** closes with a concrete example of contracts or schema agreements you have owned, even if informal.
- **G4 (R10, ownership):** closes with a sentence on whether you owned reporting pipelines end to end.
- **G5 (R1, location):** closes with your location and work authorization against the remote-US or Denver terms.

### Opportunity risk register
- **RR1 — Employer not verified.** `risk_signal`, `severity: medium`. Source: "Pellucid Learning runs live online tutoring…". Provenance `[generic]`: small companies often have thin public footprints, which is not a finding about this one. Verification question: "Which team and reporting line does this role sit in, and who owns the warehouse today?" Status: unresolved. Searches were denied, so this check is open.
- **RR2 — Equity unstated.** `unknown`. Verification question: "What is the equity grant size and vesting schedule for this level?"
- **RR3 — Hiring manager not named.** `unknown`. Verification question: "Who is the hiring manager for this role?"
- **RR4 — "Run" is undefined.** `unknown`. "Build and run" may include on-call duties. Verification question: "What does 'run' mean in practice: on-call rotation, SLAs, or incident ownership?"

### Application plan
- **Apply**, once RR1 is cleared on their own careers page.
- **Lead with:** the dbt project (~180 models), Airflow orchestration and the Great Expectations suite. These map to R4, R6 and R7, and the proof is concrete.
- **Positioning on BigQuery (R5):** say "Snowflake, with the transferable dbt and warehouse patterns." Do not claim BigQuery experience.
- **Don't claim** ingestion or contracts (R8, R9) until you can back them with an example.
- `resume_edits_pending_approval`: any resume or cover-letter wording stays unfinalized until you approve it.

### Evidence status
- **Target 1 — company site and careers page:** `unavailable`. Web search permission was denied.
- **Target 2 — role-family market sweep:** `unavailable`. Web search permission was denied. The pay calibration uses the report you supplied.
- **Target 3 — hiring manager footprint:** `n/a`. No name was given.

### Dossier offer
If you want, I can save this as `tuesday-dossier.md` for the mock-interview handoff.

### Upgrade menu
- **Your location and work authorization:** closes R1, the hard gate.
- **The live posting link from their careers page:** closes RR1. This is the single most useful check.
- **Ingestion and contracts examples:** moves R8 and R9 from `unclear` to `direct` or `adjacent`, which is the largest possible fit gain.
- **Hiring manager name:** allows a public-footprint read for positioning. Skipped unless you provide one.
- **Permission to retry web search:** runs the company-site and market-sweep checks that were denied.

### Questions
1. Have you ingested data from a product app and a CRM, or owned data contracts or schema agreements that analysts depended on? (R8, R9)
2. Where are you based, and are you authorized to work in the US for a remote or Denver role? (R1)
3. If you grant web search permission, I can run the company-site and market-sweep checks that were denied (RR1). Want me to retry?

Answer in your own words. "Skip" is a valid answer to any of these.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.