## Decision snapshot

**Decision: `conditional_go`.** Renata meets every stated must-have on the evidence she gave. The conditions are that Brindlemoor is verified as the employer described and that the team and management scope are confirmed.

**Fit ledger (candidate, per requirement):**

| Priority | Fit | Requirement | Confidence |
|---|---|---|---|
| Must | Met | 4+ years pricing or actuarial analytics (has 5) | High |
| Must | Met | Strong SQL and Python (daily use) | High |
| Must | Met | GLM experience (built and maintained a rating GLM) | High |
| Must | Met | Presenting to underwriting or actuarial leads (quarterly review to head of underwriting) | High |
| Must | Met | Build and monitor rating models | High |
| Must | Met | Design and read price tests (14 last year) | High |
| Preferred | Met | Insurance experience (UK motor) | High |
| Implied | Partial | Pet-insurance product domain | Medium that the skills transfer; none held directly |
| Unstated | Unknown | Line management of others | Not in the JD; depends on the role's scope |

**Hard gates:** Fully remote, UK. Renata's location isn't stated, so this is `unknown` until confirmed. Compensation and notice terms are also unknown, because the JD gives no pay figure.

## Role reality

- **Title and scope (`[grounded]`):** Senior Pricing Analyst, owning pricing analytics for one pet-insurance product. Responsibilities cover rating models, price tests and recommendations to underwriting and product.
- **Reporting line (`[grounded]`):** Hiring manager is Odile Varga, Director of Pricing.
- **Unknowns:** Team size, whether the role owns the function alone or sits in a team, data maturity, and the company's stage. The JD doesn't say.
- **Market calibration:** Not run. This needs research (see Evidence status).

## Evidence map

| # | Priority | Requirement | Fit | Evidence | Gap | Confidence |
|---|---|---|---|---|---|---|
| 1 | Must | 4+ yrs pricing analytics | Met | 5 yrs, UK motor insurer | none | High |
| 2 | Must | SQL and Python | Met | Daily use | none | High |
| 3 | Must | GLM experience | Met | Built and maintained young-driver GLM | none | High |
| 4 | Must | Presenting to UW/actuarial leads | Met | Quarterly review to head of underwriting | none | High |
| 5 | Must | Build and monitor rating models | Met | Built and maintained | none | High |
| 6 | Must | Design and read price tests | Met | 14 tests with underwriting | none | High (confirm her ownership of design vs. execution) |
| 7 | Preferred | Insurance | Met | UK motor | none | High |
| 8 | Implied | Pet-insurance domain | Partial | No pet experience | transferability | Medium |
| 9 | Unstated | Managing people | Unknown | Never managed | depends on scope | Unknown |

## Opportunity risk register

| Class | Severity | Item |
|---|---|---|
| Failed attribution | High | Brindlemoor is not yet verified as an existing employer. Nothing here has been checked against the web, so this constrains the decision to `conditional_go`. |
| Scope | Medium | "Own pricing analytics" for a single product may mean the role is the whole pricing function, with little peer review. |
| Domain | Medium | Pet pricing drivers (breed, species, vet-cost inflation, lifetime versus annual policies) differ from motor. Expect a learning curve. |
| Information | Low | Pay, location terms and team size are not stated. |

## Application plan

- **Lead with:** GLM build and maintenance, the 14 price tests, and presenting to the head of underwriting. These map directly to the must-haves.
- **Frame the pet gap honestly:** "transfers from motor; learning pet drivers" is accurate. Don't claim pet experience.
- **Don't claim people management.** If the interviewer asks, answer from what she actually did.
- **Resume edits:** none proposed yet. Any wording change would be `resume_edits_pending_approval` and goes live only after she approves it.

## Evidence status

Research tier: L0, no searches. I haven't run research on this pass, so no company or market claims are verified.

| # | Target | Status | Reason |
|---|---|---|---|
| 1 | Company site and careers page | skipped | L0 this pass; employer not checked |
| 2 | Role-family sweep (scope, title, pay) | skipped | L0 this pass; market calibration not run |
| 3 | Hiring manager public footprint | skipped | L0 this pass; Odile Varga not looked up |

## Dossier offer

If you want, I can save this assessment as a `tuesday-dossier.md` file for reuse with mock-interview later.

## Upgrade menu

- **Live posting or careers page for Brindlemoor:** verifies the employer and the role's actual scope.
- **Pay band and location terms:** clears the two unknown hard gates.
- **Team size and reporting structure:** resolves the people-management question.
- **Research at L1 (up to 5 searches, 2 fetches):** company checks, role-family pay, and Odile Varga's public background.

## Questions

1. Can you send the live posting link, the company careers page, or the recruiter's email domain so I can confirm Brindlemoor exists as described?
2. Does the role manage anyone, or is it a solo ownership role? How big is the pricing team?
3. Shall I run L1 research (up to 5 searches and 2 page fetches) to check the company and market pay? Reply yes or no. Silence means no.

*Response modes: answer each question in prose, or reply "skip" to any one.*

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.