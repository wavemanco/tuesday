**Not a waste of time, but one line decides it.** Your strongest case is the platform-and-integrations side of the job, and that case is real. The sticking point is the must-have "3+ years product management experience." You have no PM title, so this is `conditional_go`: apply once the recruiter says product-owned work can count, and once the employer checks out. (Quartzline's existence and the market pay band are unverified: web search was refused, so no research ran.)

**Decision snapshot**
- **Status:** `conditional_go`. Conditions: (1) R1b reads as satisfiable by product-owned work, confirmed by the recruiter; (2) the posting is verified as live (RR1).
- **Fit ledger:**
  - must_have: direct R3 (technical fluency), R4 (stakeholder management); adjacent R1a (roadmap input and requirements work), R2 (shipped API or platform products); unclear R6 (agile delivery); absent R1b (3+ years titled PM).
  - important: direct R8 (launch coordination); adjacent R5 (partner discovery); unclear R7 (adoption metrics).
  - preferred: no rows.
- **Opportunity ledger:** RR4 is a positive signal: the posting names a roadmap, two engineering squads and adoption metrics, which suggests real authority. RR1 is unverified and RR2 is the literal-screen risk. No severe red flags found.
- **Hard gates:** none stated in the posting. Your constraints were not given, so checks against them are unknown; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:** a recruiter confirming the years are a literal screen (drops to `no_go` only if you have no product-owned work to point to, and we haven't checked that yet); a verified live posting (clears RR1).

**Role reality** `[grounded]` from the JD: Product Manager, Platform APIs; partner-facing API platform; roadmap ownership, discovery with integration partners, specs, delivery with two squads, adoption metrics, launch coordination.
- Unknowns: compensation, location, reporting line, and whether the 3+ years is screened literally.
- Market calibration: not run. The role-family sweep was refused, so there is no pay or seniority band to compare against.

**Evidence map** (confidence is capped at `medium` because every claim is CV-only and unprobed)

| # | Requirement | Priority | Fit | Conf. | Gap | Basis | Next action | Prov. |
|---|---|---|---|---|---|---|---|---|
| R1a | Owns roadmap inputs and specs | must_have | adjacent | medium | transferability | Roadmap-input sessions; requirements docs | Ask for one roadmap decision you shaped and what changed | `[grounded]` CV |
| R1b | 3+ years PM experience | must_have | absent | none | transferability | No PM title on the CV | Ask whether it's a literal screen (Q1) | `[grounded]` JD |
| R2 | Shipped API or platform products | must_have | adjacent | medium | transferability | 30+ REST integrations delivered; you didn't own the product | Ask what you shaped that shipped (Q2) | `[grounded]` CV |
| R3 | Technical fluency (schemas, docs) | must_have | direct | medium | none | Postman, SQL, OpenAPI | none | `[grounded]` CV |
| R4 | Stakeholder management | must_have | direct | medium | presentation | Coordinated engineers, client engineers and PMs | Lead with this in the CV | `[grounded]` CV |
| R5 | Partner discovery | important | adjacent | medium | transferability | Quarterly client-feedback sessions | Frame as discovery with limits named | `[grounded]` CV |
| R6 | Agile delivery | must_have | unclear | none | discovery | Not stated on the CV | Ask how your implementation work was run | `[inferred]` JD |
| R7 | Adoption metrics | important | unclear | none | discovery | No metrics on the CV | Ask whether you ever defined or tracked one (Q3) | `[inferred]` JD |
| R8 | Launch coordination with sales and support | important | direct | medium | presentation | Go-live and UAT ownership | none | `[grounded]` CV |

**Gap recovery queue:** R1b is the real gap, and the limit is clear: no titled PM role and no confirmed owned product. The stated strengthener is one product-owned artifact (a roadmap, spec or adoption number). R6 and R7 need discovery, not reframing.

**Opportunity risk register**
- **RR1** `risk_signal`, `severity: medium`: employer not established. Search was refused, so the Quartzline posting is unverified. `[generic]` pattern for a company this size. Verification question: "Can you point me at this role on your careers site, and who would I be interviewing with?"
- **RR2** `risk_signal`, `severity: medium`: the 3+ years line may be screened literally. `[inferred]` from the JD's must-have wording. Verification question: "Is the 3+ years of PM experience a hard screen, or would demonstrated product ownership count?"
- **RR3** `unknown`: compensation is not stated. `[grounded]` JD silence. Verification question: "What is the base range for this level?"
- **RR4** `positive_signal`: the roadmap, the two squads and the adoption metrics read as concrete scope. `[inferred]` from the JD.

**Application plan** (provisional)
- Apply after RR2 is answered. Lead with platform-integration and requirements work, not with a PM story.
- Do not describe implementation work as owning a product roadmap unless you can point to it.
- The triage tool from earlier notes is an unconfirmed lead, not evidence. Don't use it in applications until you confirm it.
- Any CV or outreach wording is a proposal pending your approval.

**Evidence status**
- Research tier: L1 — searches 2 of 5, fetches 0 of 2; user links read 0
- Target 1, company site and careers page — `unavailable`: both search calls were refused by permission.
- Target 2, role-family sweep — `unavailable`: same refusal.
- Target 3, hiring manager — `n/a`: no name given.

**Dossier:** I can save this assessment as `tuesday-dossier.md` if you want it for later.

**Upgrade menu**
- Grant web search permission: unlocks the employer check (RR1) and the pay band (RR3).
- The live posting link or the recruiter's email domain: verifies the employer.
- One product-owned artifact (a roadmap, spec or adoption number): raises R1b and R2.
- The triage tool, if real: a screenshot, a spec, or adoption numbers. This is the only thing that would move R2 toward direct.

**Questions** (response modes: answer in text, paste a voice transcript, attach a document, drop a link, or say skip)
- **RR2 / R1b:** Has the recruiter said whether the 3+ years of PM experience is screened literally, or whether product-owned work can substitute?
- **R2:** Did you shape any API feature or endpoint that shipped and that partners used? What did you decide, and how did you know it was used? Did you build the internal request-triage tool support adopted? If so, what did you own?
- **RR1:** Can you give me the link to the live posting, or the recruiter's email domain?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.