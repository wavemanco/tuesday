**Decision: hold pending answers.** This is not a no, but don't put in a full application yet. The role is a reasonable stretch on your core skills. Two things block a go: a stated must-have you haven't done (owning a forecast), and two hard gates I can't check (location and pay floor). The employer also isn't verified yet.

**Hard gates:** Bristol, two days a week in the office; your location and commute tolerance are unknown. Salary £61,500–£67,000 [grounded, from the posting]; your floor is unknown.

**Fit ledger**

- **Strong:** Revenue or sales ops at a B2B company, 4+ years (5 years sales ops, 2 running RevOps) [grounded, from your background]. Salesforce admin, certified [grounded]. Your pipeline and renewal dashboards are direct evidence for the reporting half of the role [grounded].
- **Partial:** SQL and spreadsheet modelling. You use SQL weekly and Excel daily, but the posting asks for modelling, and you haven't said you've built models [inferred]. Let me know if you have.
- **Gap, must-have:** Owning a forecast. You've never owned the company forecast, and the role runs the quarterly revenue forecast with the CFO. Your monthly pipeline review with the sales director is the closest adjacent evidence [grounded]. It's a bridge, not a match.
- **Gap, must-have:** Working with finance on billing or revenue data. You've never worked on billing data [grounded]. The role also owns billing data, so this is a scope gap, not just a checkbox.

**Opportunity ledger**

- **Unverified employer [risk]:** The only source is a job board, and it doesn't mention invoicing or the hiring manager. Your recruiter's claim is unconfirmed. The posting also says "own our CRM and billing data" with a CFO-facing forecast, which is broad scope for one lead.
- **Market calibration: not established.** I didn't run searches, so I can't say whether £61.5–67k is normal for this title or seniority in Bristol [generic, unverified].
- **Not checked:** Hiring manager Tamsin Achebe's public background, and the company's stage and leadership.

**Research tier: L0, no searches; user links read 1.**

| Target | Status | Reason |
|---|---|---|
| 1. Company site and careers page | skipped | L0 selected: no searches |
| 2. Role-family sweep (scope, title, pay) | skipped | L0 selected: no searches |
| 3. Hiring manager public footprint | skipped | L0 selected: no searches |

**Application plan (if you proceed)**

1. Verify the role exists on Quillfield's own careers page, or confirm the recruiter's email domain matches the company. Do this before anything else.
2. Answer the location and pay questions below. If both pass, move to conditional go.
3. If you apply, lead with pipeline and renewal reporting and the monthly review. Don't claim forecast ownership or billing-data experience. Describe your pipeline-to-forecast work exactly as it was. The reframing check applies to every line you send.

**Evidence status:** Your CV and the posting are the only sources. Everything about Quillfield's stage, leadership, and pay band is unverified.

**Gap recovery questions:** I can rerun this with research if you want the company and pay checks. That needs your consent.

**Upgrade menu:** Confirm the employer; a company-page or market-pay check (up to 5 searches and 2 fetches); any forecast or model work, even partial; any finance-facing revenue reporting.

**Questions** (response modes: answer in prose, or say "skip"):
1. Can you commit to Bristol two days a week, and is £61.5–67k above your floor?
2. Have you contributed to any forecast, such as pipeline-weighted numbers, commit or best-case calls finance used, or a forecast you reviewed, even without owning the final number?
3. Have you ever given finance revenue or renewal figures for reporting, such as bookings reconciliation or ARR?

If you want to keep the assessment in a file, I can write a `tuesday-dossier.md` with this analysis and your answers.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.