**Worth applying to, with conditions. Status: `conditional_go`.** The fit is strong on the must-haves. The gaps are pet-insurance product knowledge and missing role detail, and I could not verify the employer.

**Fit ledger**
- `hard_gate`: unclear: R1 (UK-based and able to work fully remote; your location isn't stated)
- `must_have`: direct: R2, R3, R4, R5, R6, R7
- `important`: adjacent: R8 (recommendations to product), R10 (pet-insurance product knowledge)
- `preferred`: direct: R9 (insurance experience)

R2 to R7 are direct on CV evidence alone, so they rate `medium` confidence. Nothing has been checked against an artifact yet.

**Hard gates:** none failed; unconfirmed: R1 (candidate location not given, so remote-UK eligibility is unknown).

**Opportunity ledger:** Sound on the JD's own terms, but under-specified. The salary is not stated (RR2), the contract basis is not stated (RR3), and I could not verify that Brindlemoor exists as described (RR1). The JD itself raises no severe red flags.

**Conditions for go**
1. Confirm the employer and the live posting (RR1).
2. Confirm the role's decision rights and whether it line-manages anyone (RR3).
3. Present the pet gap as transferable motor-pricing method, never as pet experience.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech with a pet-insurance product | `[grounded]` JD header only; not verified |
| Mandate | Own pricing analytics for the pet product: build and monitor rating models, design and read price tests, recommend to underwriting and product | `[grounded]` JD |
| Stated outcomes | None stated | — |
| Working pattern | Fully remote, UK | `[grounded]` JD |
| Scope read | Individual-contributor analytics ownership is likely; the JD does not mention reports | `[inferred]` from the responsibility list, which has no people component |
| Market calibration | Not established: no search ran, and I won't offer a salary band from memory | — |
| Unknowns | Salary, contract basis, decision rights, line management, whether the product is live or early-stage | — |
| Contradictions | None found in the JD; no second source to compare | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | UK-based, remote-compatible | hard_gate | unclear | low | hard_gate | Your location is not in the input. Likely fine, but unconfirmed | — | Confirm your location |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | Five years in UK motor pricing analytics, two as senior analyst | `[grounded]` CV | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | Used daily | `[grounded]` CV | none |
| R4 | GLM experience | must_have | direct | medium | none | Built and maintained the young-driver GLM rating model | `[grounded]` CV | none |
| R5 | Designing and reading price tests | must_have | direct | medium | none | Ran 14 price tests last year with underwriting | `[grounded]` CV | none |
| R6 | Building and monitoring rating models | must_have | direct | medium | none | Motor rating model, built and maintained | `[grounded]` CV | none |
| R7 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | Presents the quarterly pricing review to the head of underwriting. Actuarial audience not evidenced | `[grounded]` CV | none |
| R8 | Recommendations for underwriting and product | important | adjacent | medium | transferability | Underwriting recommendations are direct. Product-facing recommendations are not evidenced | `[inferred]` from the CV's underwriting-only audience | see gap G1 |
| R9 | Insurance experience (a plus) | preferred | direct | medium | none | Motor insurer, UK | `[grounded]` CV | none |
| R10 | Pet-insurance product knowledge (implied, not stated) | important | adjacent | low | transferability | Pricing method transfers from motor. Pet-specific drivers do not, and I have no pet experience | `[inferred]` from the JD's product focus; `[generic]` that pet pricing has different drivers (e.g., cover type, vet-cost inflation) | see gap G1 |

## Gap recovery queue

| # | Gap (req) | Type | What I see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pet product knowledge and product-facing recommendations (R8, R10) | transferability | No pet or product-facing work on the CV | Likely the first probe in interview | Any work on new-product pricing, customer-value analysis, or a motor product change taken to product owners | A short note on how you'd approach pet drivers | `[inferred]` from the CV |

The queue holds no questions. The question for G1 goes in the closing block.

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer existence and live posting unverified | unknown | — | "Brindlemoor (insurtech)" | The posting may be real, but I could not check. This constrains `go` to `conditional_go` | `[grounded]` no search ran | Can you send the live posting link or the company careers page? | unresolved |
| RR2 | Salary not stated | unknown | — | JD silent on pay | The band may be below what you expect, or the company simply doesn't publish it | `[grounded]` JD | What is the budgeted salary for this role? | unresolved |
| RR3 | Contract basis, decision rights and line management unstated | unknown | — | "Own pricing analytics" | "Own" may mean accountable for rating models without sign-off authority, or a team may sit under this role | `[inferred]` from the JD's silence | Does this role approve rating changes alone or with actuarial sign-off? Does it line-manage anyone? Is the contract permanent? | unresolved |
| RR4 | No pet-insurance experience | risk_signal | medium | "our pet-insurance product" | Interviewers will probe pet-specific pricing drivers; a motor-only answer will read as a gap | `[inferred]` from the CV; `[generic]` on how pet pricing differs | What do you know about pet pricing drivers already? | unresolved |
| RR5 | JD's must-haves match your record closely | positive_signal | — | GLM, price tests, underwriting presentation | The role was written around work you have done | `[grounded]` JD against CV | — | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Ask the recruiter for the live posting link and the contract basis before investing in the loop | RR1, RR3 | `[grounded]` | pending your approval |
| A2 | Lead the CV with the 14 price tests and the quarterly underwriting review, as evidence for R5 and R7 | Strongest direct evidence | `[grounded]` CV | pending your approval |
| A3 | Frame pet as a transfer of motor pricing method. Don't claim pet experience | RR4, G1 | `[inferred]` | pending your approval |
| A4 | Prepare a plain answer on people management: you have never managed anyone, and the JD doesn't require it. Don't imply otherwise | RR3 | `[grounded]` CV and JD | pending your approval |

Nothing above goes externally until you approve it.

## Evidence status

Verified: none yet. The CV claims are leads until they are backed by a source.

Research tier: L1 — searches 4 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Four web searches (Brindlemoor pet insurance; Brindlemoor careers Senior Pricing Analyst; senior pricing analyst pet insurance UK salary; Odile Varga Director of Pricing insurance) were refused: web search permission was not granted in this session. Would have checked that the employer exists as described and the posting is live (RR1) |
| 2. Role-family sweep | unavailable | The salary-and-scope search was refused in the same way. Would have set the market calibration and the RR2 band |
| 3. Hiring manager's public footprint | unavailable | The name search was refused in the same way. Would have shown Odile Varga's public role and what they tend to probe for |

I did not retry the refused searches.

**Dossier offer:** If you'd like, I can write this assessment to a `tuesday-dossier.md` file you can carry into interview prep.

**Upgrade menu**
- Grant web search permission, and I'll rerun targets 1 to 3. That settles RR1, sets a salary band (RR2), and may show the hiring manager's focus.
- The live posting link → RR1 closes, and the employer is verified or not.
- The budgeted salary → RR2 closes.
- A sanitized note on a past product-facing pricing decision → R8 and G1 move toward direct.

**Questions**
1. (RR3) Does this role approve rating changes alone, or do actuarial leads sign off? Does it line-manage anyone? Is the contract permanent?
2. (RR1) Can you send the live posting link or the company careers page?
3. (RR4) What do you already know about pet pricing drivers, such as cover type or vet-cost inflation?

Answer any of these, or say skip for one. Skipped questions are carried as open risks.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.