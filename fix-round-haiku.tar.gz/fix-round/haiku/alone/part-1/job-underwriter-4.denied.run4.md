**Yes, apply, on conditions: `conditional_go`.** On the evidence you gave, you meet the four must-haves (R2 to R5 are the `must_have` rows, all `direct`). The open items are that the posting is unverified, pay is withheld, and it's unclear whether the role manages people.

Web search was refused in this session, so nothing about Brindlemoor, Odile Varga or pay is checked. Every external statement below is either from the JD or labeled.

**Decision snapshot**

- **Status:** `conditional_go`. Apply once the posting is verified and the three checks below come back clean.
- **Fit ledger.**
  - `hard_gate`: unclear: R1 (fully remote, UK-based)
  - `must_have`: direct: R2 (4+ years pricing analytics), R3 (SQL and Python), R4 (GLM experience), R5 (presenting to underwriting leads)
  - `important`: direct: R6 (building and monitoring rating models), R7 (designing and reading price tests); adjacent: R8 (recommendations for product, not only underwriting)
  - `preferred`: adjacent: R9 (insurance experience, motor not pet)
  - Pet-insurance product knowledge (R10, inferred from the JD's "our pet-insurance product") is adjacent: the methods carry over, the pet-specific drivers don't appear in your record.
- **Opportunity ledger.** RR4 is a positive signal: the outputs are concrete. RR1 (employer unverified), RR2 (people management unstated) and RR3 (pay withheld) are unknowns. RR5 is a low risk on ramp-up.
- **Hard gates:** none failed; unconfirmed: R1 (fully remote, UK-based); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) RR1, the employer and posting verify from a link on Brindlemoor's own site or a recruiter on a company domain; (2) R1 confirmed; (3) RR2 answered. If the role has direct reports, that is a stretch you haven't done yet, and the decision needs a second look.

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, insurtech, pet insurance | `[grounded]` JD only; existence not checked |
| Mandate | Own pricing analytics for the pet product: rating models, price tests, recommendations to underwriting and product | `[grounded]` JD |
| Working pattern | Fully remote, UK | `[grounded]` JD |
| Hiring manager | Odile Varga, Director of Pricing | `[grounded]` name you gave; footprint not checked |
| Scope read | A senior analytical role with three defined outputs; no stated reporting line | `[inferred]` from the JD's responsibilities |
| Market calibration | Not run; no pay band is available from this session | — |
| Unknowns | Employer verification, pay, people management, pet-product ownership | — |
| Contradictions | None visible within the JD; not checked against a careers page | `[grounded]` JD |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote, UK-based | hard_gate | unclear | low | hard_gate | Your location and right to work aren't in your background | `[grounded]` JD; silent on you | Q1 below |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | 5 years, last 2 senior; self-report, not yet inspectable | `[grounded]` your background | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | Daily use stated | `[grounded]` your background | none |
| R4 | GLM experience | must_have | direct | medium | none | Built and maintained the young-driver GLM (motor) | `[grounded]` your background | E1 |
| R5 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | Quarterly review to head of underwriting | `[grounded]` your background | none |
| R6 | Build and monitor rating models | important | direct | medium | none | The GLM work above, motor book | `[inferred]` from R4 | E1 |
| R7 | Design and read price tests | important | direct | medium | none | 14 tests last year with underwriting | `[grounded]` your background | E1 |
| R8 | Turn results into recommendations for underwriting and product | important | adjacent | medium | transferability | Underwriting recommendations evidenced; product not | `[grounded]` background; `[inferred]` on the product gap | G1 |
| R9 | Insurance experience (preferred) | preferred | adjacent | medium | transferability | UK motor insurer; not pet | `[grounded]` background | G2 |
| R10 | Pet-insurance product knowledge | important | adjacent | low | transferability | Methods transfer; pet drivers absent from your record | `[inferred]` from "our pet-insurance product" | G2 |

Confidence is `medium` as the ceiling for self-reported intake, not yet verified.

**Gap recovery queue**

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Product-side recommendations (R8) | transferability | Underwriting recommendations are evidenced; product decisions aren't | Would move R8 from adjacent | Price-test decisions that changed a product rule or a quote journey | A test readout or a one-page product recommendation | `[inferred]` from the CV-equivalent background |
| G2 | Pet-insurance domain (R9, R10) | transferability | Motor only | Interviews will probe pet-specific drivers | Any work on non-motor lines, or on rating factors that behaved differently by customer type | A pet-data or pet-line analysis you can describe | `[generic]` that pet pricing uses different drivers from motor |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer and posting unverified | unknown | — | "our pet-insurance product" | The posting may be stale or aggregated, or the employer may be too new to have a footprint | `[generic]` pattern for small insurtechs | Can you point me to the role on your careers site, and who would I interview with? | unresolved |
| RR2 | People management unstated against "Senior" | unknown | — | "Senior Pricing Analyst" | The role may expect line management, which you haven't done | `[inferred]` from the title against the JD's silence | Does this role have direct reports, and if so, how many? | unresolved |
| RR3 | Pay withheld | unknown | — | (no pay stated) | The figure may sit low, or it may simply be unpublished | `[inferred]` from the posting's silence | What is the budgeted band for this post? | unresolved |
| RR4 | Outputs concrete | positive_signal | — | "build and monitor rating models; design and read price tests" | Scope is defined and matches your record | `[grounded]` JD | — | noted |
| RR5 | Pet ramp-up | risk_signal | low | "our pet-insurance product" | Pet pricing drivers differ from motor, so ramp-up could be longer | `[generic]` | What would my first 90 days on pet pricing look like, and what data would I own? | unresolved |

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Get the live posting link, or the recruiter's email, before investing in the application | RR1 | `[grounded]` RR1 | awaiting you |
| E1 | Prepare one sanitized, inspectable artifact: a GLM documentation page or a price-test readout | Raises R4 and R7 from medium to high | `[generic]` that inspectable proof raises confidence | pending your approval |
| E2 | Frame the motor work as transferable method, not pet expertise | Honest adjacency; avoids the R10 objection | `[inferred]` from R9 and R10 | pending your approval |
| A2 | Ask the recruiter RR2 and RR3 before the first interview | Settles the two unknowns early | `[grounded]` RR2, RR3 | awaiting you |

**Evidence status**

Verified: none yet. Your background is self-report at intake.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches sent for Brindlemoor's company and careers page; both were refused because web-search permission was not granted. This would have verified RR1 and the contradictions row. |
| 2. Role-family sweep | unavailable | One search sent for UK pet-insurance pricing pay and scope; refused for the same reason. This would have set the market calibration, which is now missing. |
| 3. Hiring manager's public footprint | unavailable | A name was given, so a query could be formed; no call was sent before the permission refusal. This would have informed positioning for Odile Varga. |

**Dossier offer:** I can write this up as a `tuesday-dossier.md` for your interview prep if you want to keep it.

**Upgrade menu**

- Granting web-search permission lets me run the remaining L1 budget (up to 2 more searches and 2 fetches): Brindlemoor's own pages, the role-family pay band, and the hiring manager's public professional footprint, roles only.
- The live posting link or the recruiter's email domain verifies RR1.
- One inspectable artifact (E1) raises R4 and R7 to high.
- Your location and right-to-work status settle R1.

**Questions**

1. (R1) Are you UK-based with the right to work, and does fully remote fit your constraints? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.
2. (RR1) Do you have the live posting link, or the recruiter's email domain? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.
3. (RR2, RR3) Do you know whether the role has direct reports, and is there a pay floor you'd need to clear? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.