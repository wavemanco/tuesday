I'll load the job-underwriter skill for this, and try to fetch the posting at the same time.
The posting is readable. Before I write the assessment, I'll read the output and risk-decision specs and load the search tool for the default L1 research pass.
**Decision: conditional_go.** Apply, but treat two must-haves as open. The core RevOps, Salesforce and SQL profile matches well. Forecast ownership and billing/finance data are real gaps, and the location question is unresolved.

Research tier: L1, searches 2 of 5, fetches 1 of 2; user links read 1

## Decision snapshot

- **Fit ledger:**
  - Meets: 4+ years RevOps/sales ops at B2B; Salesforce admin; SQL.
  - Partial: spreadsheet modelling.
  - Gap (must-have): owning a forecast; billing/revenue data with finance.
  - Unknown: hybrid location, salary floor.
- **Hard gates:** Bristol, two days a week in office. Your location is not in your background, so this is **unknown**, not failed.
- **Confidence:** medium overall. The fit side rests on your CV. The employer side rests on one About page and one pay guide.

## Role reality

- **Organization [grounded]:** Quillfield, invoicing and payments software for UK builders' merchants, founded 2018 in Bristol, 96 employees, £11M Series A in April 2025 (quillfield.co.uk/about). Stage fits a first dedicated RevOps lead.
- **Role [grounded, from posting]:** Owns CRM and billing data; builds pipeline and renewal reporting for sales and finance; runs the quarterly revenue forecast with the CFO.
- **Scope read [inferred]:** This is a step up from running reporting to owning the forecast number and the billing data behind it. The posting puts the CFO in the forecast, so you would be the operational owner, not the sign-off.
- **Pay [grounded]:** £61,500–£67,000 plus share options.
- **Market calibration [generic]:** Ledgerline 2026 UK pay guide puts this role at a median base of £64,200 (IQR £57,800–£70,400, n=438). The posted range sits around the median. Ledgerline is a single pay guide, so treat it as a pattern.
- **Contradictions:** None found between posting and About page. The posting's host, tallyboard.example, is a job board. The company's careers page returned nothing, so the posting is not confirmed on Quillfield's own site.

## Evidence map

| # | Priority | Requirement | Fit | Confidence | Gap | Evidence |
|---|---|---|---|---|---|---|
| 1 | Must | 4+ yrs RevOps / sales ops / analytics at B2B software | Meets | Medium | Presentation | 5 yrs sales ops at a B2B payments company; 2 yrs running UK RevOps. Payments is B2B but not software; say so plainly. |
| 2 | Must | HubSpot or Salesforce admin | Meets | High | — | Salesforce admin certified; rebuilt pipeline and renewal dashboards. |
| 3 | Must | Strong SQL and spreadsheet modelling | Meets (SQL) / Partial (modelling) | Medium | Presentation | SQL weekly, Excel daily. Modelling is not stated; daily Excel use does not prove forecast-style modelling. |
| 4 | Must | Experience owning a forecast | Gap | High | Transferability | Finance owned the company forecast. You run the monthly pipeline review with the sales director, which is an input to a forecast, not ownership of one. |
| 5 | Must | Experience working with finance on billing or revenue data | Gap | High | Discovery | Never worked on billing data. Unknown whether renewal dashboards used revenue figures that finance reviewed. |
| 6 | Scope | Owns billing data | Gap | High | Capability | No billing exposure. Scope item, not a stated requirement, but central to the role. |

## Gap recovery queue

- **Row 4 (forecast ownership):** Closes with evidence that you contributed forecast inputs or calls, even if finance owned the number. Would also need an honest account of how your pipeline review fed finance's view.
- **Row 5 (billing/revenue data with finance):** Closes if your renewal or pipeline work used revenue or ARR figures finance signed off. If it did not, this stays a real gap and you should say so.
- **Row 6 (billing data):** Discovery only; no evidence in your background.
- **Row 3 (modelling):** Closes with one example of a model you built in Excel (scenario, cohort, or renewal-rate projection).

## Opportunity risk register

- **Hard-gate unknown (location):** Bristol, two days a week in office. Severity: high until answered.
- **Failed attribution, partial (verification):** Entity confirmed; posting not confirmed on the company's own site. Would resolve with the live posting link from quillfield.co.uk or the recruiter's email domain. This is why the decision is conditional.
- **Comp (mismatch check):** Posted range is within market band [generic]. No mismatch unless your floor sits above £67k, which is unknown.
- **Role-stretch risk:** Two must-haves are gaps, so expect a forecast question in screening. Severity: medium.
- **Positive signals [grounded]:** Series A funded; the role is new-ish for a 96-person company, so there is room to shape it.

## Application plan

- **Lead with:** Salesforce admin, renewal and pipeline dashboards, SQL/Excel reporting, pipeline review with a sales director.
- **Positioning, pending your approval:** Describe the pipeline review as input to forecasting, not forecast ownership. Do not write "forecasting experience" or "billing data" on the CV.
- **Interview prep:** Be ready for "have you owned a forecast?" The honest answer is no, followed by what you did contribute.
- **Outreach:** Nothing drafted; no CV edits without your approval (`resume_edits_pending_approval`).

## Evidence status

| # | Target | Status | Reason |
|---|---|---|---|
| 1 | Company site and careers page | yes | About page confirms the entity (quillfield.co.uk/about). Careers page at quillfield.co.uk/careers returned no page; posting origin not confirmed. |
| 2 | Role-family sweep | yes | Query: "Revenue Operations Lead salary UK B2B software". Source: Ledgerline 2026 UK Revenue Operations Pay Guide. |
| 3 | Hiring manager footprint | skipped | Name given (Tamsin Achebe). Not searched in this pass; available if you want it. |

**Plain points:** The posting cites Salesforce and a Bristol base; both match you on paper. The company is real and funded. The decision would move to `go` if the posting is confirmed on Quillfield's own site and the location works. It would move to `hold` if you cannot do Bristol two days a week or if you can't point to any revenue-data or forecast-input work.

**Dossier offer:** If you want, I can save this assessment as `tuesday-dossier.md` for later interview prep.

**Upgrade menu:**
- A redacted renewal or pipeline dashboard, to check whether revenue figures appear (row 5).
- A sample Excel model, to close row 3.
- The Quillfield careers link or recruiter email domain, to confirm the posting (risk register).
- Your salary floor, to settle the comp check.
- A targeted search on Tamsin Achebe's public footprint (L1 target 3), if you consent.

**Questions:**
1. **Row hard-gate (location):** Are you based in or within reach of Bristol, and could you do two days a week in the office? Answer in text, or say skip.
2. **Row 5 (billing/revenue data):** Did your renewal or pipeline dashboards use revenue or ARR figures that finance reviewed or signed off? Answer in text, or say skip.
3. **Row 4 (forecast ownership):** Did you ever contribute forecast inputs or calls (for example, commit or best-case calls) even though finance owned the number? Answer in text, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.