**Worth applying to, on three conditions. Status: `conditional_go`.** Your analytical core matches the JD closely. The gap is pet-insurance domain knowledge, and two things about the employer are still unverified.

**Fit ledger.**

- `hard_gate` — unclear: H1 (fully remote UK; your location and right to work aren't stated)
- `must_have` — direct: R2 (4+ years), R3 (SQL and Python), R4 (GLM and rating models), R5 (presenting to underwriting leads)
- `important` — direct: R6 (price tests); adjacent: R1 (pet-product pricing), R7 (turning results into product recommendations)
- `preferred` — direct: R8 (insurance experience)

**Opportunity ledger.** The role is concrete: rating models, price tests, and recommendations to underwriting and product. Pay is withheld. The employer could not be checked, because web search was refused, so it is unverified rather than shown to be missing.

- **Hard gates:** none failed; unconfirmed: H1 (remote-UK eligibility, not yet stated by you).
- **Severe red flags:** none in the JD text.
- **Conditions for go:** (1) check the live posting and the employer before investing in the loop (RR1); (2) confirm UK right to work, pay range, and whether the role has direct reports (H1, RR2, RR3); (3) present the pet gap as adjacent, with its limit named, never as pet experience (G1).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, described as an insurtech | `[grounded]` JD header; existence not verified (search refused) |
| Mandate | Own pricing analytics for the pet-insurance product: build and monitor rating models, design and read price tests, turn results into recommendations for underwriting and product | `[grounded]` JD |
| Working pattern | Fully remote, UK | `[grounded]` JD |
| Hiring manager | Odile Varga, Director of Pricing | `[grounded]` your message; no public footprint checked |
| Compensation | Not stated. No market band is established: the salary search was refused, and I won't supply a figure from memory | `[grounded]` absence in JD |
| Scope read | Senior individual-analyst scope with ownership. "Own" is stated, but no reports are mentioned | `[inferred]` from the JD's wording |
| Unknowns | Employer stage and funding, product maturity, pay, reporting line, whether the post manages people | — |
| Contradictions | None found; only one source was available | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance |
|---|---|---|---|---|---|---|---|
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | high | none | Five years at a UK motor insurer, the last two as senior analyst | `[grounded]` your background |
| R3 | Strong SQL and Python | must_have | direct | high | none | Daily use | `[grounded]` your background |
| R4 | GLM experience; build and monitor rating models | must_have | direct | high | none | Built and maintained the GLM rating model for the young-driver book. The technique transfers directly; the pet-specific drivers do not (see R1) | `[grounded]` your background |
| R5 | Presenting to underwriting or actuarial leads | must_have | direct | high | none | Presents the quarterly pricing review to the head of underwriting | `[grounded]` your background |
| R6 | Design and read price tests | important | direct | high | none | Ran 14 price tests last year with the underwriting team | `[grounded]` your background |
| R7 | Turn results into recommendations for underwriting and product | important | adjacent | medium | presentation | Underwriting recommendations are evidenced. Product recommendations are not | `[inferred]` from the quarterly review you described |
| R1 | Pricing analytics for a pet-insurance product (implied by the mandate; not a listed requirement) | important | adjacent | medium | transferability | Motor pricing carries over; pet-specific drivers and claim behaviour are new to you | `[inferred]` from the JD mandate against your background |
| R8 | Insurance experience (a plus) | preferred | direct | high | none | Motor insurance | `[grounded]` your background |
| H1 | Fully remote, UK (hard gate) | hard_gate | unclear | low | hard_gate | The JD states UK remote. Your location and right to work are not in your background | `[grounded]` JD; your status not given |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pet-product pricing (R1, important) | transferability | Motor pricing and GLM work, with no pet, non-motor, or pet-specific drivers | This is the objection most likely to come up. Narrowing it moves R1 toward direct | Any non-motor pricing or benchmarking; any analysis of claim frequency or severity drivers you didn't own; a consulting brief outside motor | A benchmark note, an analysis summary, or a brief | `[inferred]` bridge from your motor work; `[generic]` that pet drivers differ (breed, species, vet-cost inflation, lifetime vs annual cover) |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer unverified | unknown | — | "Brindlemoor (insurtech)" | The employer could be early-stage, which would affect stability and scope. Not established | `[generic]` insurtech pattern; no search result | What is the live posting link, or the recruiter's email domain? | unresolved |
| RR2 | Pay withheld | unknown | — | (no pay stated) | Pay may sit below your expectation. No band is established | `[inferred]` from the silence against the JD's seniority | What is the budgeted salary? | unresolved |
| RR3 | Management scope unstated | unknown | — | "Own pricing analytics" | The role may include people leadership, which you have not done | `[inferred]` from "own" and "senior" with no reporting line stated | Does this role have direct reports? | unresolved |
| RR4 | Pet ramp-up | risk_signal | medium | "our pet-insurance product" | Ramp-up on pet drivers may take longer than the "own" wording implies | `[inferred]` from R1's gap | Covered by G1 | unresolved |
| RR5 | Requirements match your daily work | positive_signal | — | "build and monitor rating models… design and read price tests" | The core of the role is what you already do | `[grounded]` JD against your background | — | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Lead the CV with the GLM build and maintenance, the 14 price tests, and the quarterly review to underwriting | These match the must-haves most directly | `[grounded]` your background | pending your approval |
| A2 | Describe the pet work as a bridge, never as experience: "motor GLM and test design carry over; I'd need to learn pet drivers" | Stating the limit is what keeps the claim defensible in the interview | `[grounded]` G1 | pending your approval |
| A3 | Check the live posting and the reporting line before applying | RR1 and RR3 | `[grounded]` register | pending your approval |
| A4 | Get the pay range and remote-UK terms from the recruiter before the loop | RR2 and H1 | `[grounded]` register | pending your approval |
| A5 | Prepare a one-page pet-drivers note: what you'd check first in pet data | Gives Odile Varga something concrete on R1 | `[generic]` domain pattern | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searches for Brindlemoor and its careers page were refused. Would have moved the employer's existence and stage (RR1), and whether the posting is live |
| 2. Role-family sweep | unavailable | The salary and scope search was refused. Would have set a market band for pay (RR2) and the scope norm |
| 3. Hiring manager's public footprint | unavailable | The search for Odile Varga was refused. Would have informed the positioning of the application |

These rows read `unavailable` because the search permission was refused, not because a search was judged unnecessary.

## Dossier offer

If you'd like, I can write this up as a `tuesday-dossier.md` for later use with interview prep.

## Upgrade menu

- A link to the live posting, or the recruiter's email domain → RR1 can be checked.
- Pay range from the recruiter → RR2 closes, and the offer can be compared against a band.
- Confirmed reporting line → RR3 closes; if the role has reports, the management gap becomes a must-have-level risk.
- Any non-motor or pet-related analysis → G1 narrows; R1 could move toward direct.
- Re-running research once search permission is granted → employer verification, a role-family pay band, and Odile Varga's public footprint.

## Questions

**G1** — Have you priced, analysed, or benchmarked any non-motor or pet-related product, even a side analysis or a benchmark? If not, what is the closest case where you had to learn new drivers fast?

**H1, RR2** — Are you based in the UK with the right to work here, and what is your pay floor for a fully remote role?

**RR1, RR3** — Can you paste the live posting link (or the recruiter's email domain)? And does the role have direct reports?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.