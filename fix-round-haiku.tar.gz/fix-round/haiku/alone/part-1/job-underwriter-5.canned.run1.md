**Yes, worth applying, on two conditions. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (remote US or Denver), R2 (pay floor)
- `must_have`: direct: R3 (5+ years data engineering), R4 (strong SQL and Python), R5 (dbt and a cloud warehouse), R7 (Airflow or similar), R8 (data quality testing)
- `important`: adjacent: R6 (BigQuery warehouse); unclear: R9 (ingestion from app and CRM)
- `preferred`: unclear: R10 (data contracts analysts depend on)

Every must-have (R3, R4, R5, R7, R8) reads `direct` on your background. R6 is the one real stack gap: you have cloud warehouse and dbt experience, but not BigQuery. R1, R2 and R9 are open because your inputs don't settle them.

**Opportunity ledger.** Sound posting with one verification gap. RR1 (employer not established from independent sources) and RR2 (no hiring manager or team named) are open; RR3 (equity unquantified) is unknown; RR4 (posted base sits inside the market band) is a positive signal.

- **Hard gates:** none failed; unconfirmed: R1 (remote US or Denver), R2 (pay floor); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) your location and pay floor clear R1 and R2; (2) the posting is confirmed through a channel other than Pellucid's own site, RR1.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 states; founded 2016, Denver; 264 employees; Series C $52M, Feb 2026 | `[grounded]` pellucidlearning.com/about, fetched |
| Posting status | Live: "Accepting applications"; text matches what you pasted | `[grounded]` pellucidlearning.com/careers/senior-data-engineer, fetched |
| Mandate | Ingestion from app and CRM; dbt-modelled warehouse in BigQuery; data contracts for analysts | `[grounded]` JD |
| Scope read | Ownership of reporting pipelines in one domain, no direct reports stated | `[inferred]` from the JD's listed work against its silence on reports |
| Market calibration | Posted base $148k–$166k sits inside the IQR ($139k–$163.5k), midpoint $157k above the $151k median. Band is base salary for Senior Data Engineers at Series B–D companies; "Senior" typically means 5–8 years | `[generic]` Datawright 2026 Data Engineering Pay Report (datawright.example), n=2,310; `[grounded]` posted range |
| Pay structure | Base range stated; equity unquantified | `[grounded]` JD |
| Working pattern | Remote (US) or Denver office | `[grounded]` JD |
| Hiring manager | Not named | `[grounded]` JD silence |
| Unknowns | Team size, reporting line, equity terms, which CRM and app sources, contract type | — |
| Contradictions | None between the pasted JD and the careers page | `[grounded]` fetch |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Location: remote (US) or Denver office | hard_gate | unclear | none | hard_gate | No location in your background, so the gate is unsettled | `[grounded]` JD | Q1 below |
| R2 | Pay: $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | Your pay floor isn't given; the posted range is in the market band (RR4) | `[grounded]` JD; `[generic]` band | Q2 below |
| R3 | 5+ years data engineering | must_have | direct | medium | none | Six years at a B2B payroll company; self-reported, no artifact inspected | `[grounded]` your background | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | Used daily; self-reported | `[grounded]` your background | none |
| R5 | dbt and a cloud warehouse | must_have | direct | medium | none | dbt project of about 180 models on Snowflake, a cloud warehouse | `[grounded]` your background | none |
| R6 | BigQuery warehouse (in the posting's description) | important | adjacent | medium | transferability | Cloud warehouse and dbt at this scale carry over; BigQuery itself never used, which is the limit | `[inferred]` from R5 against the JD's BigQuery mention | G1 |
| R7 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow for orchestration; self-reported | `[grounded]` your background | none |
| R8 | Data quality testing | must_have | direct | medium | none | Set up a Great Expectations suite; self-reported | `[grounded]` your background | none |
| R9 | Ingestion from app and CRM | important | unclear | low | discovery | Your background doesn't say whether you've ingested app or CRM sources | `[inferred]` from the JD's listing against that silence | G2 |
| R10 | Data contracts analysts depend on | preferred | unclear | low | discovery | Not in your background; dbt model work may be the nearest thread | `[inferred]` from the same silence | G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery warehouse (R6, important) | transferability | Cloud warehouse and dbt experience on Snowflake; no BigQuery | Narrowing this removes the most likely technical objection | A dbt project on BigQuery, a sandbox where you ran dbt, BigQuery cost or partitioning work | A repo, a dbt project tree, or a short write-up of a platform migration | `[inferred]` bridge from R5; `[generic]` that this is the likeliest objection |
| G2 | App and CRM ingestion (R9, important) | discovery | No ingestion from application databases or CRM sources is in the background | Ingestion is the first item in the JD's list | Syncs from an app database, CRM extracts, change-data-capture, API pulls you built or owned | A pipeline diagram, a DAG, or a sanitized source list | `[inferred]` from the JD's listing |
| G3 | Data contracts (R10, preferred) | discovery | No mention of contracts, schema agreements or SLAs with analysts | The JD names data contracts as something analysts depend on | Model contracts in dbt, schema enforcement, agreed SLAs with downstream users | A contract file, a schema-change process, or an analyst-facing SLA | `[inferred]` from the JD's language |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from independent sources | risk_signal | medium | "runs live online tutoring for K-12 schools in 31 US states" | Searches returned only Pellucid's own pages. The entity may be small or simply lack press coverage, and the posting may be stale | `[generic]` pattern for companies of this size, not a claim about this one | Who led the Series C, and who would I be interviewing with? | unresolved |
| RR2 | No hiring manager, team or reporting line named | unknown | — | "Build and run the pipelines behind our tutoring platform's reporting" | Authority and team size are unknown | `[inferred]` from the posting's silence | Who would I report to, and how many engineers own this warehouse? | unresolved |
| RR3 | Equity unquantified | unknown | — | "plus equity" | Total compensation may differ materially from base | `[inferred]` from the posting | What is the grant size, and what is the vesting schedule? | unresolved |
| RR4 | Posted base sits inside the market band | positive_signal | — | "$148,000–$166,000" | The posted range is in line with the Datawright band | `[grounded]` posting; `[generic]` Datawright 2026 band | Is the $148k–$166k base range fixed for this level? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Settle location and pay (Q1, Q2) before investing in an application | see R1, R2 | `[grounded]` the gates | awaiting your answers |
| A2 | Confirm the posting through the recruiter's email domain, or the Series C coverage | see RR1 | `[generic]` standing pattern | pending your approval |
| A3 | Present Snowflake and dbt work as direct experience; name BigQuery as adjacent and never as experience | see R5, R6 | `[grounded]` background; `[inferred]` adjacency | pending your approval |
| A4 | Ask RR2 and RR3 in the first recruiter call | see RR2, RR3 | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Your background is intake-level self-report, the medium ceiling, so R3–R8 are candidate claims at `medium` until probed.

Research tier: L1 — searches 3 of 5, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Fetched pellucidlearning.com/careers/senior-data-engineer (live; matches your paste) and pellucidlearning.com/about (matches). Searched "Pellucid Learning live online tutoring K-12 Denver" (no results) and "\"Pellucid Learning\" Series C funding" (only the company's own about page). No independent footprint found, so RR1 stands |
| 2. Role-family sweep | yes | Searched "senior data engineer salary Series B-D dbt Airflow 2026 pay report"; returned the Datawright 2026 Data Engineering Pay Report (datawright.example/2026-data-engineering-pay-report). Market calibration and RR4 |
| 3. Hiring manager's public footprint | n/a | No name was given |

Deeper diligence (L2) has not run. I can run it on your go-ahead.

## Upgrade menu

- Your location and pay floor → R1 and R2 leave `unclear`, and the status moves to `go` or `no_go`.
- A pipeline diagram or sanitized source list for app or CRM ingestion → R9 moves toward direct.
- A BigQuery sandbox project or dbt-on-BigQuery repo → R6 moves toward direct.
- The recruiter's email domain, or independent coverage of the Series C → RR1 is reduced.
- Deeper research on Pellucid: leadership and funding changes, reviews, hiring patterns; up to 5 more searches and 2 more fetches. Say the word and it runs.

I can save this as `tuesday-dossier.md`, a report plus a machine-readable envelope, so the next session starts from the same evidence.

## Questions

R1 — Are you based in the US, and would remote (US) or the Denver office work for you?

R2 — What is your base pay floor, and does $148,000 clear it?

R9 — Have you built ingestion from an application database or a CRM? If so, which source, and what did you own?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.