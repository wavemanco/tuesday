**Decision: `no_go`.** Don't pursue this one. Your instinct is right, and the reason is concrete: the posting fails both of your hard constraints on its own terms.

**Hard gates (failed)**
- **Compensation:** The posting states $70–85k base. Your floor is $150k, so even the top of the band is $65k short. The equity language ("meaningful upside") doesn't change the base gap. [grounded]
- **Location and schedule:** The role is on-site in Austin five days a week, "no exceptions." You are remote-only from Portland. The posting rules out the one arrangement you need. [grounded]

Neither gate can be solved by wording or by showing strong fit elsewhere.

**Fit (strong on experience)**
Your background matches the stated requirements well: 9 years of growth work, Head of Growth experience, paid, lifecycle and experimentation ownership, team management, a verified $8M→$40M ARR scale-up, and SQL, GA4 and Braze. This is a real match on paper, which is why the mismatch is worth noticing. [grounded]

**Opportunity risks (why it feels off beyond the gates)**
- **Scope against pay:** One person is asked to own paid, SEO, lifecycle, brand, PR, partnerships and sales ops, as "a team of one to start," at a senior title with an 8+ year bar. The posting also says it doesn't want a team, which is the reverse of the team-building work you've done. [grounded]
- **Pay against title:** A Head of Growth role at this scope is usually paid well above $85k base at a Series A. This comes from general market patterns, not a sourced figure, so treat it as [generic]. The decision doesn't depend on it. The posting's own numbers already fail your floor.
- **Hours language:** "Evenings and weekends when it matters is just who we are" sets an expectation that isn't tied to a defined on-call or pay arrangement. [grounded]
- **Vague success measures:** "Metrics will evolve as we learn" plus "must thrive on ambiguity" means accountability is undefined. [inferred]

**Application plan:** None. Don't apply unless Novaline changes both the base and the on-site requirement.

**Evidence status:** I didn't verify that Novaline exists as described, and I didn't check the live posting. That doesn't change the decision, because the gates fail on the posting's own terms.

Research tier: L0 — no searches

**Dossier offer:** If you want, I can save this assessment as a `tuesday-dossier.md` file for later comparison with other roles.

**Upgrade menu:** The decision would change only if Novaline confirmed a remote arrangement and a base of at least $150k. A company check would add whether the employer and posting are verifiable (up to 5 searches and 2 page fetches, only with your consent).

**Question:** Would you like me to run the company check anyway, or is "no" enough for this one?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.