**Decision: no_go as posted.** Two hard gates fail, and both are terms the posting states outright: base pay and on-site location. Your fit on the role itself is strong. The gates are the problem, and they don't depend on how well you match the job.

**Hard gates (failed)**
- **Base pay:** the posting offers $70–85k against your $150k floor, which is $65–80k below it (43–53% under your floor). The band is `[grounded]` in the posting. The posting also says nothing about equity value, so "meaningful equity" can't offset it on paper.
- **Location:** on-site in Austin five days a week, "no exceptions," against your remote-only requirement from Portland.

**Fit by requirement (opportunity-independent, candidate-side)**
- **Strong:** 8+ years of growth leadership (9 years, two Head-of-Growth-level roles); paid acquisition, lifecycle/CRM and experimentation (`[grounded]` in your background); SQL, GA4, Braze; scaling to $40M ARR with a budget you controlled.
- **Partial:** "team of one to start" versus your history of building and managing teams of 3–7. You'd be the one doing the work, not leading people.
- **Unevidenced:** PR, brand, partnerships, sales ops and SEO/content. The posting asks for all of them. Nothing in your stated background covers them, so each is a capability gap until you show otherwise.
- **Transferability:** B2C subscription to e-commerce enablement at Series A is a different customer and motion. `[inferred]` from the two company descriptions; not checked against Novaline's actual model.

**Opportunity ledger (on its own merits)**
- **Mismatch:** a "Head of Growth" title with an $70–85k base and a seven-function remit. Whether that band is low for the role in your market is `[generic]` and not established, since no market research has run.
- **Culture signal:** "evenings and weekends when it matters is just who we are," plus "success metrics will evolve." Both are soft, but together with a team-of-one scope they point to an under-resourced role.
- **Positive:** the company is described as profitable since day one. That is the posting's claim, not verified.

**Opportunity risk register**
- Employer existence and posting currency: not established. I haven't checked the live posting or Novaline's site.
- Comp mismatch versus floor: confirmed by the posting itself.
- Location mismatch versus constraint: confirmed by the posting itself.

**Application plan:** none. A gate that fails in the posting's own terms isn't closed by a cover letter. Only a changed posting would reopen it.

**Evidence status**
Research tier: L0 — no searches. Nothing was checked outside your text and the posting you pasted.

**Dossier offer:** If you want, I can save this assessment as `tuesday-dossier.md` so it carries into interview prep later.

**Upgrade menu**
- **Live posting link or Novaline careers page** would confirm the terms are current and the employer exists as described. It costs no research budget if you paste it.
- **L1 research** (up to 5 searches, 2 fetches) would check whether $70–85k is low for this title and seniority in your market, and whether Novaline's stage and size match the posting. That moves the pay read from `[grounded]` posting terms to a market comparison.

**Questions**
1. Do you have a link to the live posting or Novaline's careers page? Answer with the link, or say skip.
2. Has the recruiter or anyone at Novaline said anything about remote work or pay flexibility that isn't in the posting? That would change the gate read only if they confirm it in writing. Answer, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.