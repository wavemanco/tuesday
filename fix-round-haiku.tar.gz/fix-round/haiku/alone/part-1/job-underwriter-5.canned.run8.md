**Worth applying, on conditions. Status: `conditional_go`.** On the listed requirements your evidence is strong (R2, R3, R4, R6, R7 are `direct`). The open items are about the role: who you'd work with and what you'd own (RR1), contract type and equity (RR2), and whether you can take a remote-US or Denver location (R1). BigQuery is the one real skill gap (R5), and it isn't on the requirements list.

**Fit ledger.**

- `hard_gate`: unclear: R1 (remote US or Denver office)
- `must_have`: direct: R2 (strong SQL and Python), R3 (5+ years data engineering), R4 (dbt and a cloud warehouse), R6 (Airflow or similar), R7 (data quality testing)
- `important`: adjacent: R5 (BigQuery in the warehouse); unclear: R8 (app and CRM ingestion), R9 (data contracts analysts depend on)

R5 is the one to be honest about: Snowflake work transfers, BigQuery experience doesn't exist yet. R9 is a responsibility the posting stresses, and nothing in your background covers it.

**Opportunity ledger.** Sound on paper: the posting is live and matches the JD, the requirements are concrete, and the base range sits inside the market band (RR3, RR4). Team size, ownership, contract type and equity terms are unstated (RR1, RR2).

- **Hard gates:** none failed; unconfirmed: R1 (location: remote US or Denver); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) the team and your ownership of ingestion and contracts are confirmed (RR1); (2) the post is permanent and the location works (R1, RR2); (3) BigQuery is presented as transferable Snowflake experience, never as BigQuery experience (R5).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning, live online tutoring for K-12 schools in 31 states; founded 2016, Denver; 264 employees; Series C ($52M, Feb 2026) | `[grounded]` company's about page (search snippet, not fetched in full) |
| Mandate | Build and run ingestion (app, CRM), the dbt warehouse in BigQuery, and analyst-facing data contracts | `[grounded]` careers page, matches JD |
| Scope read | Spans two ingestion sources, the warehouse and the contracts layer. For a 264-person company that can mean a one-person data function | `[inferred]` from the scope list against the silence on team |
| Pay | Base $148k–$166k plus equity; the posted range sits inside the market IQR and near the median | `[grounded]` posting; `[generic]` band from Datawright 2026 pay report: median $151k, IQR $139k–$163.5k, Senior at Series B–D |
| Working pattern | Remote (US) or Denver office | `[grounded]` JD |
| Unknowns | Team, reporting line, hiring manager (none named), contract type, equity terms | — |
| Contradictions | None between the JD and the careers page | `[grounded]` careers page fetched |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Location: remote US or Denver office | hard_gate | unclear | none | hard_gate | Your location and work-authorization status weren't in the inputs | `[grounded]` JD | Confirm |
| R2 | Strong SQL and Python | must_have | direct | medium | none | Daily use for six years; self-reported, no artifact | `[grounded]` CV | none |
| R3 | 5+ years data engineering | must_have | direct | medium | none | Six years at one employer; self-reported | `[grounded]` CV | none |
| R4 | dbt and a cloud warehouse | must_have | direct | medium | none | dbt project on Snowflake, about 180 models | `[grounded]` CV | none |
| R5 | BigQuery warehouse (in the role description) | important | adjacent | medium | transferability | Snowflake and dbt concepts carry over. Limit: no BigQuery-specific work (cost, partitioning, slots). Strengthener: a short BigQuery project | `[inferred]` from Snowflake to BigQuery | see G1 |
| R6 | Airflow or similar orchestration | must_have | direct | medium | none | Airflow orchestration in production | `[grounded]` CV | none |
| R7 | Experience with data quality testing | must_have | direct | medium | none | Set up the Great Expectations suite | `[grounded]` CV | none |
| R8 | Ingestion from app and CRM | important | unclear | low | discovery | CV silent on CRM ingestion specifically | `[grounded]` CV silence | Ask (closing block) |
| R9 | Data contracts analysts depend on | important | unclear | none | discovery | Not in the CV | `[grounded]` CV silence | Ask (closing block) |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R5) | transferability | Snowflake warehouse and dbt work; no BigQuery | The JD names BigQuery; this is the most visible tool gap | Any cloud-warehouse migration, cost tuning, or partitioning work | A small BigQuery project, or a written Snowflake-to-BigQuery comparison | `[inferred]` from the JD and CV |
| G2 | Data contracts (R9) | discovery | Not in the CV | The JD names it as an analyst dependency | Schema agreements with producers, breaking-change handling, data SLAs | A contract spec or a schema-change process doc | `[grounded]` JD and CV |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Team and ownership not stated | risk_signal | low | "Build and run the pipelines behind our tutoring platform's reporting" | The role may be a one-person data function with no team to lean on | `[inferred]` from the scope list against the silence on team | Is this the only data engineer on the team, who would I report to, and who owns ingestion and contracts day to day? | unresolved |
| RR2 | Contract type and equity terms unstated | unknown | — | "$148,000–$166,000 plus equity" | Permanence and equity terms aren't in the posting | `[grounded]` posting silence | Is this role permanent, and what are the equity grant, vesting, and strike terms? | unresolved |
| RR3 | Concrete requirements and a live, consistent posting | positive_signal | — | "Requirements: 5+ years data engineering; strong SQL and Python; …" | The requirements are specific and the posting is current | `[grounded]` careers page fetched | Who is the hiring manager for this role? | noted |
| RR4 | Base range sits inside the market band | positive_signal | — | "Salary $148,000–$166,000" | Pay is in line with the market for this seniority; equity is extra | `[generic]` Datawright pay report; `[grounded]` posting | Is the range the full base, with equity on top? | noted |
| RR5 | Employer footprint is thin outside its own site | risk_signal | low | "Series C ($52M, February 2026)" | The company's funding and size are established only by its own pages; a 264-person company may simply have little press | `[generic]` pattern for companies of this size, not a claim about this one | Can you confirm the Series C and the team size, and point me to the team's engineering blog or docs? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Ask the recruiter for team, reporting line, contract type and equity terms before a full application | RR1, RR2 | `[grounded]` register | pending your approval |
| A2 | Describe Snowflake work as cloud-warehouse dbt experience; don't claim BigQuery | R5 | `[grounded]` CV | pending your approval |
| A3 | Prepare one honest answer on data contracts from your existing schema work, or say so plainly if there isn't one | R9 | `[grounded]` gap | pending your approval |

Nothing above adds a claim to your CV. A2 is a framing rule, and it needs your approval before any CV or cover-letter text is written.

## Evidence status

Verified: none yet. Every claim above rests on your CV or your statement in this conversation, so each is a lead until you confirm it.

Research tier: L1 — searches 2 of 5, fetches 1 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Pellucid Learning live online tutoring K-12 Denver" (no results). Fetched pellucidlearning.com/careers/senior-data-engineer: live, text matches the JD. The about page (pellucidlearning.com/about) came up in a second search, and its snippet matches your quote. Role reality: the contradictions row is clear; RR5 is the thin-footprint entry |
| 2. Role-family sweep | yes | Searched "senior data engineer salary Series B-D base median 2026 US dbt Airflow". Returned the Datawright 2026 Data Engineering Pay Report (datawright.example/2026-data-engineering-pay-report), whose figures match your quote. Market calibration is `[generic]` and sets RR4 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form. The upgrade menu names what a name would unlock |

## Upgrade menu

- A BigQuery project or a Snowflake-to-BigQuery comparison → R5 moves toward `direct`.
- An example of a data contract or schema-change process → R9 closes, and the decision may simplify to `go`.
- The hiring manager's name or the team roster → RR1 and RR3 close, and the scope read is confirmed or revised.
- Your location and work-authorization status → R1 is confirmed or ruled out, which may move the status.
- A deeper pass on Pellucid (funding confirmation, leadership changes, staff reports; up to 5 more searches and 2 more fetches) → RR5 closes. Say the word and it runs.

If you want, I can write a `tuesday-dossier.md` for this role, so the verification questions carry into interview prep later.

Three questions, each tagged to its row:

1. **RR1** — Is this the only data engineer on the team, who would you report to, and who owns the CRM and app ingestion day to day?
2. **R1 / RR2** — Can you work remote in the US or from Denver, and is a permanent contract a requirement for you? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.
3. **R9** — Have you defined or enforced data contracts between producers and analysts? If yes, what did the contract cover, and who signed off? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.