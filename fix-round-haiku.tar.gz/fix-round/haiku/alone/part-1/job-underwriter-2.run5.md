**Not a waste of time, but the titled-years requirement is a real screen. Status: `conditional_go`.** You can apply, provided the posting checks out and you can show product ownership that a recruiter can see without a PM title.

## Decision snapshot

**Fit ledger.**

- `must_have`: direct: R3, R6 · adjacent: R2 (shipped API or platform products), R4 (partner discovery), R5 (specs and delivery with two squads) · unclear: R8 (agile delivery) · absent: R1 (3+ years PM experience)
- `important`: adjacent: R9 (launch coordination with sales and support) · unclear: R7 (adoption metrics)

R1 — the one must-have with no direct or adjacent path; R3 and R6 — your strongest matches, both self-reported; R8 and R7 — nothing on your resume either way.

**Opportunity ledger.** The JD is well scoped: it names its squads, its metrics and its launch duties (RR4). The unknowns are decision rights against two engineering squads and the pay (RR3, RR5), and the employer itself is not yet verified (RR1). The titled-years wording may be screened literally, so your resume could fail before anyone reads the evidence (RR2).

- **Hard gates:** none stated (the JD names no gates); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) Quartzline and this posting verify as live (RR1); (2) you can point to a product decision you owned, such as a scope, prioritization or go/no-go call, that a recruiter reads as ownership (R1, RR2); (3) PM-shaped work is described as what it was, implementation and discovery, not as product management held under a PM title (R2, R5).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline, B2B logistics-tech, ~150 people, Series B | `[grounded]` JD header; not verified, since the search was refused |
| Mandate | Own the partner-facing API platform roadmap; run partner discovery; write specs; drive delivery with two engineering squads; define and track adoption metrics; coordinate launches | `[grounded]` JD |
| First-year outcomes | None stated | `[grounded]` JD is silent |
| Working pattern | Not stated | — |
| Scope read | A platform role with its own squads and a metrics mandate; substantial, and specific about what it owns | `[inferred]` from the JD's responsibilities |
| Market calibration | Not established: the role-family sweep was refused. A 3+ year PM requirement for a mid-level platform role is typical | `[generic]` pattern, unchecked |
| Unknowns | Decision rights against the squads; pay; location; whether titled years are screened literally | — |
| Contradictions | None visible in the text you provided | `[grounded]` |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 3+ years product management experience | must_have | absent | high | capability | You hold no PM title, and the resume shows no PM years. The PM-shaped work (requirements, roadmap input, playbook) sits beside the requirement, not inside it | `[grounded]` CV | G1 |
| R2 | Shipped API or platform products | must_have | adjacent | medium | transferability | 30+ REST API integrations taken end to end, with go-live. You implemented and delivered them; the resume does not show you owning a product's roadmap | `[grounded]` CV | G2 |
| R3 | API docs and schema fluency | must_have | direct | medium | none | Postman, SQL, OpenAPI. Self-reported, so medium until shown in a work sample | `[grounded]` CV, self-reported | none |
| R4 | Discovery with integration partners | must_have | adjacent | medium | transferability | Scoping workshops and quarterly client roadmap-input sessions are discovery in form. Not framed as product discovery | `[grounded]` CV; `[inferred]` on the discovery framing | G2 |
| R5 | Specs and delivery with two engineering squads | must_have | adjacent | medium | transferability | Requirements documents and coordinating engineers across vendor and client on custom builds. No backlog ownership shown | `[grounded]` CV | G2 |
| R6 | Stakeholder management: engineering, sales, customers | must_have | direct | medium | none | Coordinated vendor engineers, client engineers and PMs; client-facing throughout. Self-reported | `[grounded]` CV | none |
| R7 | Defining and tracking adoption metrics | important | unclear | low | capability | No adoption metric on the resume. SQL is a lead, not evidence | `[grounded]` CV silence | G3 |
| R8 | Agile delivery | must_have | unclear | low | discovery | Not named on the resume | `[grounded]` CV silence | G3 |
| R9 | Launch coordination with sales and support | important | adjacent | medium | none | Go-live and UAT are launch work; sales and support coordination is not named | `[grounded]` CV; `[inferred]` adjacency | none |

The `Reasoning` column holds the qualifiers. Fit and gap type are separate calls: R1 and R7 are the two rows where the gap is the capability itself.

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Titled PM years (R1) | transferability | No PM title; PM-shaped work of seven years | The must-have is literal in wording and the first thing a screen checks | Any decision where you chose what the integration did or did not include, and why | A decision memo or scoping document you authored, with the outcome | `[inferred]` the screen risk; `[generic]` that literal title screens are common |
| G2 | Product ownership (R2, R4, R5) | transferability | Strong delivery and discovery; no backlog or roadmap ownership shown | These three are must-haves at adjacent, so ownership is the objection most likely to be raised | A roadmap input you turned into a shipped change; a partner adoption outcome you drove | A sanitized requirements document with its outcome, or the roadmap-input summary | `[inferred]` from the CV's verbs |
| G3 | Metrics and agile (R7, R8) | capability / discovery | Neither appears on the resume | Both are must-haves or important items the JD names directly | Go-live timing, first-call success or time-to-integrate measures; any sprint or release cadence you worked in | A dashboard or query you ran in SQL on integration status | `[grounded]` CV silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not verified | unknown | — | "Quartzline (B2B logistics-tech, ~150 people, Series B)" | The posting may be live and real, or stale; the search that would have checked it was refused | `[grounded]` the search was refused; `[generic]` that companies this size are usually real but thinly indexed | Is this posting live on your careers page, and who is the hiring manager? | unresolved |
| RR2 | Literal titled-years screen | risk_signal | medium | "3+ years product management experience (must-have)" | A screen may reject on the title before reading any evidence | `[inferred]` from the must-have wording | How do you weigh product ownership that was held without a PM title? | unresolved |
| RR3 | Decision rights against two squads | unknown | — | "Own the roadmap ... drive delivery with two engineering squads" | The role may own priorities while squad leads hold the technical call | `[inferred]` from the scope against the JD's silence on disputes | Which roadmap decisions does this role make alone, and which need the engineering leads' agreement? | unresolved |
| RR4 | Scope and metrics explicit | positive_signal | — | "define and track adoption metrics" | The role's success is defined, which makes the interview easier to prepare for | `[grounded]` JD | Which adoption metrics are defined today, and who owns the data? | noted |
| RR5 | Pay not stated | unknown | — | none; the JD states no pay | The withholding is common in postings of this kind; it is worth one question, not a judgement | `[generic]` pattern, unchecked | What is the budgeted base range for this role? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Verify the posting: ask the recruiter for the live link and hiring manager before investing in the application | RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Reframe the 30+ integrations as discovery and requirements work, with the outcome per integration; no PM title or roadmap ownership implied | R2, R4, R5 | `[grounded]` CV | pending your approval |
| A3 | Write one case study of a single integration, centred on your scoping decisions and what the client adopted | G1, G2 | `[inferred]` | pending your approval |
| A4 | Ask the recruiter how the 3+ year requirement is screened | RR2 | `[generic]` pattern | pending your approval |
| A5 | Prepare one adoption-metric story from integration go-live timing, using SQL where you can show it | R7 | `[inferred]` | pending your approval |

Nothing here is final until you approve it. Every CV line is a proposal, not a claim already made.

## Evidence status

Verified: none yet. Every claim above is self-reported on your CV, so it is a lead until you confirm it in this engagement.

**Unverified memory lead.** A prior conversation's note says you built an internal request-triage tool that support agents adopted. It is unconfirmed, so it is not evidence and no output relies on it. Q2 below asks you about it.

Research tier: L1 — searches 2 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Quartzline logistics technology company Series B"; the call was refused for lack of permission, so no result came back. Would have confirmed the employer and that the posting is live (RR1) |
| 2. Role-family sweep | unavailable | Searched "product manager platform APIs partner integrations salary range B2B SaaS"; refused the same way. Would have set the market calibration and the norm for titled years |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

## Dossier offer

If you want, I can write this up as `tuesday-dossier.md`, so the register and the questions travel with the application.

## Upgrade menu

- A live posting link or the recruiter's email domain → RR1 closes; the decision may move to `go`.
- Permission to run the two refused searches → the employer check and a PM pay and scope band (RR5 closes, R1 calibrates).
- One work sample: a spec or decision memo with the call you made and its outcome → R1 and R5 move toward direct.
- Your constraints (location, pay floor, authorization, schedule) → the hard-gate checks run; right now they are unknown.
- The hiring manager's name → the scope read and which story to lead with for that reader.

## Questions

1. **R1, RR2:** Have you ever owned a backlog or made a go/no-go product call, even informally? Name one, and what happened.
2. **Memory lead:** Did you build an internal request-triage tool that support agents adopted? If so, what did it do, and how did you know they used it?
3. **R7, R8:** Have you worked in sprints, or tracked any adoption measure such as time to first successful API call or partner activation? Give one example.

Response modes: answer in text, paste a document, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.