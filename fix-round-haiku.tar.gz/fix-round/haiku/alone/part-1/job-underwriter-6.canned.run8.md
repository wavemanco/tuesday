**Decision: `conditional_go`.** Apply, but verify the employer first and go in ready to talk about forecasting and billing data, the two requirements you don't yet have.

**Research tier: L0, no searches; user links read 1.** I read the posting only. Nothing about Quillfield, its funding, or Tamsin Achebe has been checked, so anything beyond the posting is `[generic]`.

**Decision snapshot**
- **Fit, strong:** RevOps/sales-ops years, Salesforce certification, SQL weekly and Excel daily, pipeline and renewal reporting. `[grounded]` against your background.
- **Fit, gaps:** owning a forecast, and working with finance on billing or revenue data. Both are named requirements, and the posting puts the quarterly forecast with the CFO and billing data in your scope. `[grounded]`
- **Hard gates:** Bristol, hybrid two days a week, and £61,500–£67,000 plus options. Your location and pay floor aren't on record, so these are unchecked.
- **Opportunity:** the posting itself has no red flags. The employer is unverified because the link is an aggregator (tallyboard.example), not Quillfield's own careers page.

**Role reality** `[grounded]`
- Revenue Operations Lead at Quillfield, an invoicing software company. Bristol, hybrid, two office days a week.
- Owns CRM and billing data. Builds pipeline and renewal reporting for sales and finance. Runs the quarterly revenue forecast with the CFO.
- Requirements: 4+ years in RevOps, sales ops or a similar analytics role at a B2B software company; HubSpot or Salesforce admin; strong SQL and spreadsheet modelling; forecast ownership; work with finance on billing or revenue data.
- The forecast and billing-data parts go beyond your current scope. The rest matches it closely.
- Market calibration `[generic]`: not checked, since no research ran.

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Evidence |
|---|---|---|---|---|---|---|
| 1 | 4+ yrs RevOps / sales ops / analytics | Must | Met | High | None | 5 yrs sales ops, last 2 running UK RevOps |
| 2 | B2B software company | Preferred | Partly met | Medium | Transferability | B2B payments; Quillfield's product is invoicing software |
| 3 | HubSpot or Salesforce admin | Must | Met | High | None | Salesforce admin certified; rebuilt pipeline and renewal dashboards |
| 4 | Strong SQL and spreadsheet modelling | Must | Met | High | None | SQL weekly, Excel daily |
| 5 | Owned a forecast | Must | Unmet | Medium | Capability | Never owned the company forecast; finance did it. Runs monthly pipeline review with sales director (adjacent) |
| 6 | Worked with finance on billing or revenue data | Must | Unmet | Low | Discovery | Never worked on billing data. Finance-facing work not stated |

Confidence reflects what you've told me, not verified evidence. Rows 5 and 6 are the gaps that matter. Row 5 is closest to adjacent experience. Row 6 may be recoverable, depending on what you did with finance outside billing.

**Opportunity risk register**
- **Standing, unverified employer.** Link is an aggregator. Verify via Quillfield's careers page or the recruiter's email domain. This is why the decision is conditional.
- **Scope jump.** Forecast ownership plus billing data is a bigger step than the title suggests. Ask whether the CFO co-owns the forecast in practice.
- **Pay and location unchecked.** £61.5–67k plus options against your floor, and Bristol twice a week against your commute, are both unknown.

**Application plan**
- Lead with the pipeline-to-revenue work: the monthly pipeline review and the renewal dashboards, framed as the inputs to a forecast, not as forecast ownership. Don't call it forecast ownership unless you've done it.
- Address the billing gap directly in the first conversation rather than hoping it goes unnoticed. If you've worked with finance on any revenue numbers, say so specifically.
- Any CV wording or outreach text is a proposal until you approve it.

**Gap recovery queue**
- Gap 5 (forecast): closes with a concrete example of contributing to forecast inputs or reconciling pipeline against finance's numbers.
- Gap 6 (billing data): closes with any finance-facing revenue, invoicing, or ARR data work, even as a consumer of the numbers.

**Dossier offer:** I can save this assessment as `tuesday-dossier.md` to carry into interview prep.

**Upgrade menu**
- Run L1 research (up to 5 searches and 2 fetches): Quillfield's own site and careers page to verify the employer, a role-family pay and scope check, and Tamsin Achebe's public professional footprint.
- Pasting your CV would firm up the Evidence map confidence levels.

**Questions**
1. Can you commute to Bristol two days a week, and does £61,500–£67,000 meet your floor? (Rows: hard gates)
2. Have you contributed to forecast numbers at all, such as pipeline-weighted inputs or reconciling pipeline with finance? (Row 5)
3. Have you worked with finance on any revenue, invoicing or ARR data, even only as a user of the numbers? (Row 6)

Response modes: answer each question as you like, or skip any. Skipping counts as an answer.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.