**Decision: `conditional_go`. Apply, once the posting checks out and you've settled how you'll answer the forecast and billing questions.**

**Fit, by requirement** (as I read your background; I didn't run the role-family sweep, so there's no market band)

| Requirement (from the posting) | Fit | Why |
|---|---|---|
| 4+ years in RevOps / sales ops / analytics at a B2B software company | direct on years, adjacent on "software" | Five years in sales ops and two running UK RevOps. A payments company is close to B2B software, but expect the question. |
| HubSpot or Salesforce administration | direct | Salesforce admin certified, rebuilt pipeline and renewal dashboards. |
| Strong SQL and spreadsheet modelling | direct | SQL weekly, Excel daily. "Modelling" is the part to back with a concrete example. |
| Owning a forecast (and the quarterly forecast with the CFO) | adjacent at best | You run the monthly pipeline review but finance owned the company forecast. This is the biggest gap. |
| Working with finance on billing or revenue data | adjacent or absent | You've worked on revenue data, never billing data, and the role owns billing data. |

**Opportunity side:** the scope is clear (own CRM and billing data, build pipeline and renewal reporting, run the quarterly forecast with the CFO). The posted salary is £61.5–67k plus options, so it's stated. Two things to check: the role takes on forecast ownership that finance holds today, and the posting doesn't say where authority over the forecast or billing data sits. Quillfield itself looks real: a Bristol company founded in 2018 with 96 staff and a Series A in 2025. But I couldn't find the role on its own careers site (the search returned nothing), so the posting is unverified.

**Conditions for going ahead**
1. Confirm the role is live on Quillfield's own careers page, or get the recruiter to confirm it from a company email address.
2. Find out what the forecast ownership means in practice: does this role build the model and sign it off, or own the inputs while finance owns the number? If it's the second, your pipeline work is a credible bridge.
3. Pitch the gap honestly. Describe what you've done (pipeline inputs, renewal forecasting, monthly reviews with a sales director) and don't claim forecast ownership you didn't have.

**Not checked:** your non-negotiables (location, contract type, minimum pay). I don't have them, and Bristol hybrid with two office days needs your confirmation. I also didn't look up Tamsin Achebe's public background, since that needs your go-ahead.

**Questions** (one per open item)
- Are you able to work in Bristol two days a week, and does £61.5k meet your minimum?
- What does "owning the forecast" mean in this posting? Did the recruiter say whether finance keeps the final number?
- Would you like me to look into Tamsin Achebe's public background and run a salary check for this role?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.