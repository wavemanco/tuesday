**Yes, it's worth applying, on conditions. Status: `conditional_go`.** Your fit is strong: six of the seven must-have rows are direct (R1, R2, R3, R4, R6, R7), and the one gap is BigQuery (R5, adjacent). Separately, the employer is only partly verified (RR1), and your location and pay floor are unknown, so the checks against them can't run yet.

## Decision snapshot

**Fit ledger.**

- `hard_gate`: unclear: R11 (Remote (US) or Denver office), R12 (Salary $148,000–$166,000 plus equity)
- `must_have`: direct: R1, R2, R3, R4, R6, R7 · adjacent: R5 (dbt-modelled warehouse in BigQuery)
- `important`: unclear: R8 (ingestion from our app and CRM), R9 (data contracts our analysts depend on)
- `preferred`: absent: R10 (K-12 or tutoring domain)

Reading the ledger: R1, R2, R3, R4, R6 and R7 rest on your own account, with no artifact yet; R5 is Snowflake work, and BigQuery itself is unused; R8 and R9 are unanswered, so they are discovery questions; R10 is a minor preferred gap; R11 and R12 are open because your constraints weren't given.

**Opportunity ledger.** Sound but under-specified: the employer has no attributable footprint beyond its own site (RR1), the hiring manager, authority and equity are unstated (RR2, RR4), and the scope spans four pipeline areas (RR3). One entry runs the other way: the posting publishes its salary and location options (RR5).

- **Hard gates:** none failed (no gate row fails: R11 and R12 are unconfirmed, below); unconfirmed: R11 (Remote (US) or Denver office), R12 (Salary $148,000–$166,000 plus equity); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **Conditions for go:** (1) RR1 clears, via a source beyond the company's own site; (2) R11 and R12 check out against your location and pay floor; (3) R5 is framed honestly as "Snowflake and dbt, BigQuery not yet used," never as BigQuery experience; (4) RR3 settles which of the four areas you would own.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 states, Denver, 264 employees, Series C ($52M, Feb 2026) | `[grounded]` company About page, self-published; no third-party confirmation found |
| Mandate | Build and run the reporting pipelines: ingestion from app and CRM, a dbt-modelled warehouse in BigQuery, and data contracts | `[grounded]` JD and careers page (fetched, text matches) |
| Stated outcomes | None beyond the scope itself | `[grounded]` JD |
| Working pattern | Remote (US) or Denver office | `[grounded]` JD |
| Scope read | Four pipeline areas in one senior role, wider than the usual single-domain scope | `[inferred]` from the JD, against the typical scope in the pay report |
| Market calibration | Posted $148,000–$166,000 brackets the $151,000 median and sits inside the $139,000–$163,500 interquartile range; that is what to expect, not this employer's offer | `[generic]` Datawright 2026 report via your recruiter (n=2,310, not independently checked); `[grounded]` posted range |
| Unknowns | Hiring manager, team ownership, equity value, your location and pay floor | — |
| Contradictions | None between the JD and the careers page | `[grounded]` careers page fetched |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years data engineering | must_have | direct | medium | none | Six years at a B2B payroll company; self-reported, no artifact | `[grounded]` your background | none |
| R2 | Strong SQL and Python | must_have | direct | medium | none | Used daily; self-reported, no artifact | `[grounded]` your background | none |
| R3 | dbt | must_have | direct | medium | none | Built a ~180-model dbt project | `[grounded]` your background | none |
| R4 | A cloud warehouse | must_have | direct | medium | none | Snowflake satisfies the generic term | `[grounded]` background; `[inferred]` that Snowflake meets the generic term | none |
| R5 | dbt-modelled warehouse in BigQuery | must_have | adjacent | medium | transferability | Snowflake dbt work carries over; BigQuery is unused, so its dialect, cost model and adapter are unexercised. Medium grades the Snowflake claim | `[inferred]` bridge from the Snowflake work; `[generic]` that BigQuery is learnable | G1 |
| R6 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow used for orchestration | `[grounded]` your background | none |
| R7 | Data quality testing | must_have | direct | medium | none | Set up the Great Expectations suite | `[grounded]` your background | none |
| R8 | Ingestion from our app and CRM | important | unclear | low | discovery | Not stated in your background | `[inferred]` from silence | Q3 below |
| R9 | Data contracts our analysts depend on | important | unclear | low | discovery | Test suite is related; contracts not stated | `[inferred]` from silence | Q3 below |
| R10 | K-12 or tutoring domain | preferred | absent | none | capability | No education or edtech work in background | `[grounded]` your background | minor risk; none |
| R11 | Remote (US) or Denver office | hard_gate | unclear | low | hard_gate | Your location isn't given, so neither outcome is established | `[grounded]` JD; constraint not given | Q1 below |
| R12 | Salary $148,000–$166,000 plus equity | hard_gate | unclear | low | hard_gate | Your floor isn't given; the posted band brackets the market median | `[grounded]` JD; `[generic]` band | Q2 below |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Useful evidence | Provenance |
|---|---|---|---|---|---|---|
| G1 | BigQuery (R5) | transferability | Snowflake dbt experience; no BigQuery | The JD names BigQuery; the gap is narrow but real | A small BigQuery dbt project, or its README | `[inferred]` bridge; `[generic]` learnability |
| G2 | Ingestion (R8) | discovery | Not stated | Named in the scope; unknown whether it's yours | Example pipeline from app or CRM | `[inferred]` from silence |
| G3 | Data contracts (R9) | discovery | Not stated | Named in the scope; a distinct skill from tests | Example contract or schema agreement with consumers | `[inferred]` from silence |
| G4 | Domain (R10) | capability | No education work | Preferred only; minor | — | `[grounded]` background |
| G5 | Location and pay (R11, R12) | hard_gate | Not given | Can't be resolved by wording; only your answer settles it | — | `[grounded]` JD |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established beyond its own site | risk_signal | medium | "Pellucid Learning runs live online tutoring for K-12 schools in 31 US states … Series C ($52M, February 2026)" | The company may be real but thinly documented, or its funding and scale claims may be unverified; the live posting narrows this | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me to the Series C announcement or an investor or press page, and who would I interview with? | unresolved |
| RR2 | Hiring manager unnamed | unknown | — | Posting names no hiring manager | Reporting line and team owner aren't visible | `[inferred]` from the posting's silence | Who would I report to, and which team owns the reporting pipelines? | unresolved |
| RR3 | Scope bundles four pipeline areas | risk_signal | low | "ingestion from our app and CRM, a dbt-modelled warehouse in BigQuery, and the data contracts" | One senior engineer may own ingestion, warehouse and contracts together, wider than the typical single-domain scope | `[inferred]` from the JD, against the `[generic]` norm in the recruiter's report | Which of these four areas would I own alone, and which sit with the analytics team? | unresolved |
| RR4 | Equity unquantified | unknown | — | "plus equity" | Equity value unknown | `[inferred]` from the posting | What is the equity grant size and vesting schedule? | unresolved |
| RR5 | Salary and location options published | positive_signal | — | "Salary $148,000–$166,000 plus equity. Remote (US) or our Denver office." | Transparent on pay and place | `[grounded]` posting, fetched | What does the post-Series C plan put on this team's roadmap? | noted |

Severe red flags: none found.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Ask your recruiter for the hiring manager's name and the Series C source | RR1, RR2 | `[grounded]` register | pending your approval |
| A2 | Lead with dbt at ~180 models, Airflow and Great Expectations, as you described them | R3, R6, R7 | `[grounded]` your background | pending your approval (CV wording) |
| A3 | Describe BigQuery as not yet used, with the Snowflake transfer named; don't claim it | R5 | `[inferred]` bridge | pending your approval |
| A4 | Before the loop, build or read a small BigQuery dbt project | R5 | `[generic]` ramp pattern | proposed |
| A5 | Ask the four scope questions from RR3 in interviews | RR3 | `[grounded]` register | proposed |

## Evidence status

Verified: none yet. Your background is self-report at intake ceiling (`medium`), and no claim has been confirmed in a probe. Unverified leads: none. Rejected inferences: none.

Research tier: L1 — searches 2 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Pellucid Learning live online tutoring K-12 Denver" (no results) and "Pellucid Learning Series C funding 2026" (returned only pellucidlearning.com/about, the company's own page). Fetched pellucidlearning.com/careers/senior-data-engineer: posting live, text matches the JD you pasted. Moved RR1 (no third-party attribution) and the contradictions row (none) |
| 2. Role-family sweep | skipped | Your recruiter's Datawright figures are in hand and fix the market calibration line and the RR3 scope norm; no search needed |
| 3. Hiring manager's public footprint | n/a | No name was given, so there is no query to form |

## Upgrade menu

- A dbt or Great Expectations artifact (model lineage, a test-suite file, sanitized) → R3, R6 and R7 move from `medium` toward `high`.
- Any BigQuery work, even a personal project → R5 moves from adjacent toward direct.
- Your recruiter's answer on the hiring manager and the Series C source → RR1 and RR2 close.
- Your location and pay floor → R11 and R12 close, and the decision may move to `go`.
- Deeper company diligence (funding and leadership checks, reviews, news; up to 5 more searches and 2 more fetches) — say the word and it runs.

If you want, I can save this as a `tuesday-dossier.md` you can carry into a later mock-interview.

**Questions** (tagged to rows):

- **R11:** Are you based in the US and able to work remotely, or would you relocate to the Denver office?
- **R12:** What base floor would you accept, and what are you earning now?
- **R8, R9:** Have you built ingestion from a CRM or app source, or defined data contracts with analyst consumers? Describe one, what you owned, and who relied on it.

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.