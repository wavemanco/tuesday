**Decision: no_go on the posting as written.** Both hard gates fail on the posting's own terms, and wording can't close either one.

**Decision snapshot**
- **Opportunity:** no_go. Its pay and location terms are incompatible with your stated constraints. Its scope is also a poor match for the title.
- **Candidate fit:** strong on paper. Your 9 years, the $8M→$40M ARR run, and teams of 3–7 clear the "8+ years" line and the core channels.
- **Hard gates:** **Pay fails.** Posted base is $70–85k against your $150k floor, a gap of $65–80k, or 47–53% below it. **Location fails.** Austin on-site 5 days, "no exceptions," against remote-only from Portland.

**Opportunity ledger (on its own merits)**
- **Pay vs. floor** `[grounded]`: $70–85k base is the posting's own figure. Equity is unquantified and can't close a base gap you need to live on.
- **Location** `[grounded]`: "no exceptions" is the posting's own language, so I'd treat it as the real policy unless the recruiter says otherwise.
- **Scope mismatch** `[grounded]`: "team of one to start," with seven owned channels (paid, SEO, lifecycle, brand, PR, partnerships, sales ops) and "no bench." You've run teams of 3–7, so this is a step down in the leverage you're used to.
- **Risk signals** `[grounded]`: evenings and weekends as "just who we are," and "success metrics will evolve." Both shift risk onto the hire.
- **Positive signals:** Series A, profitable since day one, real growth mandate, CEO reporting line with a board dotted line.
- **Market calibration:** I haven't run a market check, so I can't say whether $70–85k is low for a Head-of role at this stage. Any figure I gave would be from memory, which isn't a source for market values.

**Why it feels off:** The posting pairs a Head-of title, an 8+ year requirement, and a Series A org with a base salary that looks more like a senior IC or a first marketing hire. It also demands on-site presence and extra hours while promising a team of one. That mismatch is the thing to trust, even though the posting is internally consistent on its own terms.

**Application plan:** None. Pursuing this would only make sense if the two gates change, and I'd rather not write outreach around a role that fails both.

**Evidence status**
Research tier: L0 — no searches. I didn't run research because the decision rests on the posting's own stated pay and location terms. The one check research would add is whether Novaline exists as described and whether this posting is live.

**Dossier offer:** If you want, I can save this assessment as a `tuesday-dossier.md` file for later reference or for mock-interview prep.

**Upgrade menu** (what would change the verdict):
- A confirmed base of at least $150k, or a written statement that the $70–85k figure is wrong. This would move the verdict toward conditional_go, pending the other gate.
- Written confirmation of remote or hybrid eligibility. Without it, location alone keeps this at no_go.
- The live posting link or Novaline's careers page, to confirm the role exists as described. This needs L1 research.
- A recent news check on funding and stage, which needs L2 research.

**Questions:**
1. Would you like me to run L1 research on Novaline (existence, stage, and whether this posting is live)? It's up to 5 searches and 2 page fetches.
2. Have you talked to anyone at Novaline, or is everything here from the posting alone?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.