**Research tier: L1 — searches 3 of 5, fetches 0 of 2; user links read 1**

## Decision: conditional go

Apply, but only after two things are settled: whether Bristol two days a week works for you, and whether the forecast ownership is really this role's job or shared with the Head of RevOps and the CFO. Your tooling and reporting background matches the role well. The two real gaps are both things the posting lists as requirements.

**Hard gates:** Location (Bristol, two days a week in office) and pay (£61,500–£67,000) are both unknown against your constraints. Neither has failed.

**Fit ledger**
- **Meets:** 4+ years in RevOps/sales ops; Salesforce admin.
- **Partial:** Strong SQL and spreadsheet modelling.
- **Gap:** Owning a forecast; experience with finance on billing or revenue data.

## Role reality

- **Role:** Revenue Operations Lead, Quillfield. Bristol, hybrid. Owns CRM and billing data, builds pipeline and renewal reporting, runs the quarterly revenue forecast with the CFO. [grounded, JD]
- **Company:** Invoicing and payments software for UK builders' merchants. Founded 2018 in Bristol, 96 employees, £11M Series A in April 2025. [grounded, company About page via search snippet]
- **Reporting line:** Tamsin Achebe is listed publicly as Head of Revenue Operations at Quillfield, previously a sales operations manager at a payments company for four years. [grounded, public profile snippet; footprint only] This suggests the Lead sits under an existing RevOps head, so the forecast split is worth asking about.
- **Market calibration:** A 2026 UK survey of RevOps leads at B2B software firms (n=438) gives a median base of £64,200 and an interquartile range of £57,800–£70,400. The posted range sits inside that band, near the median. [generic]
- **Scope read:** Combining pipeline and renewal reporting, billing data, and forecasting in one role is a broad remit, possibly more than one person at this stage. [inferred]

## Evidence map

| # | Priority | Requirement | Your evidence | Fit | Confidence | Gap |
|---|---|---|---|---|---|---|
| 1 | must-have | 4+ yrs RevOps/sales ops/analytics at B2B software | 5 yrs sales ops, last 2 leading UK RevOps, at a B2B payments company | meets | high on years; medium on "software" | none if payments counts |
| 2 | must-have | HubSpot or Salesforce admin | Salesforce admin certified; rebuilt pipeline and renewal dashboards | meets | high | none |
| 3 | must-have | Strong SQL and spreadsheet modelling | SQL weekly, Excel daily | partial | medium | "modelling" is not shown; confirm forecasting or financial models |
| 4 | must-have | Experience owning a forecast | Runs monthly pipeline review; never owned company forecast (finance did) | gap | low | capability/transferability |
| 5 | must-have | Finance work on billing or revenue data | Pipeline and renewal data with sales; no billing data | gap | low–medium | discovery, possibly partial |
| 6 | hard gate | Bristol, two days a week in office | Your location not stated | unknown | — | hard_gate |
| 7 | hard gate | Pay £61.5k–£67k | Your floor not stated | unknown | — | hard_gate |

## Gap recovery queue

- **Row 4 (forecast):** Closable only with evidence that you fed pipeline or renewal numbers into finance's forecast cycle, even if you didn't own the model. Presenting the monthly pipeline review as forecast experience would overclaim. Don't use that framing.
- **Row 5 (billing):** Closable with any reconciliation of CRM or renewal data against invoices or billing exports, even ad hoc.
- **Row 3 (modelling):** Closable with a sample of a pipeline or renewal model you built.

## Risk register

- **Scope (medium):** Forecast, billing data, and reporting in one Lead role. Check whether the forecast is shared with the Head of RevOps or finance.
- **Compensation (low):** Posted range sits inside the market band. Your floor is unknown, so this is unresolved rather than a mismatch.
- **Employer verification (low):** The About page confirms the company's basic facts, but I did not fetch the careers page or the live posting. Check the posting on Quillfield's own careers page before you apply.

## Application plan

- Apply. Lead with the pipeline and renewal dashboards, SQL use, and the Salesforce certification.
- In the cover note, name the forecast and billing gaps directly and say what you did near them. Don't claim more than that.
- Prepare a short, honest answer on how you'd get up to speed on billing data quickly.
- No CV wording is proposed yet. Any wording needs your approval before it goes into an application.

## Evidence status

| Target | Status | Reason |
|---|---|---|
| 1. Company site and careers page | yes | Query "Quillfield invoicing software company Bristol"; About page (quillfield.co.uk/about) via search snippet. Careers page not fetched. |
| 2. Role-family sweep (pay and scope) | yes | Query "Revenue Operations Lead salary Bristol UK"; Ledgerline 2026 UK RevOps Pay Guide via snippet. |
| 3. Hiring manager's public footprint | yes | Query "Tamsin Achebe Quillfield"; public professional profile via snippet. Footprint only. |

Your background is what the skill can't verify, so every candidate-side claim above is from what you told me.

## Dossier offer

If you want, I can save this as a `tuesday-dossier.md` so a later mock-interview session can pick it up.

## Upgrade menu

- **Your location and pay floor:** Settles the two hard gates. Without them, the decision stays conditional.
- **Forecast or billing examples:** Any spreadsheet, model, or reconciliation you touched would raise rows 4 and 5 more than anything else.
- **A sample of a model you built:** Raises row 3 from medium.
- **Careers page or live posting link:** Confirms the employer and posting directly.
- **L2 research (optional, offered once):** Up to 5 more searches and 2 more fetches on funding history, hiring patterns, and recent news. I'd run it only if you want it.

## Questions

1. **(Hard gate, row 6–7)** Where do you live relative to Bristol, and what's your base salary floor?
2. **(Row 4)** Did you ever feed pipeline or renewal numbers into the company forecast, even though finance owned the model? What did they use, and how often did they ask you to check it?
3. **(Row 5)** Have you ever reconciled CRM or renewal data against invoices or billing exports, even ad hoc?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.