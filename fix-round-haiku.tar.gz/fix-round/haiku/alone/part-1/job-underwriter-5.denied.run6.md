**Yes, worth applying to, on conditions: `conditional_go`.** Your six years and core stack match the must-haves. Two hard gates are unchecked, the pay floor is unknown, and the employer is unverified because web research was refused this session.

## Decision snapshot

**Fit ledger.**

- `hard_gate`: unclear: R1, R2
- `must_have`: direct: R3, R4, R5, R6, R7, R11
- `important`: adjacent: R8, R10 · unclear: R9

What matters: R3, R4, R5, R6, R7, R11 are the must-haves, met on your stated experience; R8 is BigQuery, a transferable gap with its limit named; R9 is ingestion, unknown until you say what you built; R1 and R2 are the gates you have not checked.

**Opportunity ledger.** The posting is concrete on stack, scope and salary: the salary band sits near the market median (RR5, RR6). Team size, equity and student-data obligations are unknown (RR2, RR3, RR4), and the employer is unverified (RR1, standing entry).

**Hard gates:** none failed; unconfirmed: R1 (Remote US or Denver office), R2 (base pay $148,000–$166,000); candidate constraints not given — checks against them unknown

**Severe red flags:** none found.

**What would change this:** the decision holds at `conditional_go` on three conditions: R1 checks out (you can work from the US or Denver), R2 meets your floor, and RR1 clears (the posting is live and the employer is as described). If R1 fails, this becomes `no_go` on that gate alone.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 states; founded 2016; 264 employees; Series C $52M, Feb 2026 | `[grounded]` the about page you supplied; not independently checked |
| Mandate | Build and run pipelines behind tutoring reporting; ingestion from app and CRM; dbt-modelled BigQuery warehouse; data contracts | `[grounded]` JD |
| Scope read | Senior individual contributor owning pipelines, no reports | `[inferred]` from the JD; matches the report's typical scope for the title |
| Market calibration (pay) | Posted $148,000–$166,000. The report's senior median is $151,000 (IQR $139,000–$163,500); the posted midpoint of $157,000 sits in the upper half of the IQR | `[grounded]` the pay report you supplied; `[inferred]` the comparison; `[generic]` that a survey is a pattern, not this employer's offer |
| Market calibration (years) | Your six years sit in the report's 5–8 year "senior" band | `[generic]` |
| Working pattern | Remote (US) or Denver office | `[grounded]` JD |
| First-year outcomes | Not stated | — |
| Unknowns | Team size and reporting line; equity terms; hiring manager; whether student data carries privacy obligations | — |
| Contradictions | None found between the JD and the about page | `[grounded]` both as you supplied them |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver location and work authorization | hard_gate | unclear | none | hard_gate | No location or authorization status given; the gate cannot be checked from the inputs | `[grounded]` JD; your status not given | Question Q1 |
| R2 | Base pay $148,000–$166,000 against your floor | hard_gate | unclear | none | hard_gate | Your floor is not given; the band sits near the market median | `[grounded]` JD; `[inferred]` comparison | Question Q2 |
| R3 | 5+ years data engineering | must_have | direct | medium | none | Six years at a B2B payroll company; stated by you, not inspected | `[grounded]` your background; expect a probe on dates | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | Both used daily for six years; no code sample inspected | `[grounded]` your background | none |
| R5 | dbt and a cloud warehouse | must_have | direct | medium | none | dbt project of about 180 models on Snowflake, a cloud warehouse | `[grounded]` your background | none |
| R6 | Airflow or similar orchestration | must_have | direct | medium | none | Airflow orchestration, stated by you | `[grounded]` your background | none |
| R7 | Data quality testing | must_have | direct | medium | none | You set up the Great Expectations suite | `[grounded]` your background | none |
| R8 | dbt-modelled warehouse in BigQuery | important | adjacent | low | transferability | dbt and SQL carry over; you have never used BigQuery, so its specifics are unexercised | `[grounded]` JD environment line; `[generic]` that BigQuery's cost model and partitioning differ from Snowflake's | G1 |
| R9 | Ingestion from application and CRM | important | unclear | low | discovery | Your background mentions pipelines, not which sources you ingested | `[grounded]` absence in your background | G2; Question Q3 |
| R10 | Data contracts analysts depend on | important | adjacent | low | transferability | Test suite shows validation discipline; schema ownership and change notice with consumers not evidenced | `[inferred]` from the GE work | G3 |
| R11 | Build and run pipelines behind tutoring reporting | must_have | direct | medium | none | Pipeline ownership is the same job; the tutoring reporting domain is new to you | `[grounded]` your background and JD | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery warehouse (R8, important) | transferability | Snowflake dbt at about 180 models; no BigQuery | Named as the role's environment; the one stack gap | dbt modelling and tests on Snowflake; query tuning there | A small dbt project on a BigQuery sandbox with tests, and a note on what differed. Limit to state: no BigQuery production use | `[grounded]` your background; `[generic]` on platform differences |
| G2 | Ingestion from app and CRM (R9, important) | discovery | Pipelines in your background; sources not named | A named responsibility; would move R9 from unclear | Any database or API extraction you owned end to end | A sanitized pipeline diagram or repo excerpt | `[grounded]` absence in your background |
| G3 | Data contracts (R10, important) | transferability | GE validation, not contracts with consumers | A named responsibility | Schema change notices; interfaces you owned with downstream teams | A sanitized contract or schema-change process note | `[inferred]` from the GE work |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources (standing entry) | risk_signal | medium | "Build and run the pipelines behind our tutoring platform's reporting" | Research was refused, so nothing has checked the employer or the posting; the about page is the only attribution. Nothing contradicts it | `[generic]` pattern for companies of this size, not a claim about this one | Is this role open now, and who would I be interviewing with? | unresolved |
| RR2 | Team size and reporting line unknown | unknown | — | "Build and run the pipelines" | May be a sole-owner role or one of several | `[inferred]` from the JD's silence on team | How many data engineers are on the team today, and who would this role work with most closely? | unresolved |
| RR3 | Equity unquantified | unknown | — | "plus equity" | Equity may be a meaningful share of pay or may be minor | `[inferred]` from the unstated terms | What is the equity grant: type, size, vesting, and strike basis? | unresolved |
| RR4 | Student data obligations unstated | risk_signal | low | "live online tutoring for K-12 schools" | Pipelines may carry minors' data with privacy duties that shape the contracts in R10 | `[inferred]` from the K-12 customer base | How is student data handled in these pipelines, and which privacy obligations shape the data contracts? | unresolved |
| RR5 | Stack and scope stated concretely | positive_signal | — | "dbt-modelled warehouse"; "data contracts analysts depend on" | Scope is defined; less guesswork in the first weeks | `[grounded]` JD | Which of these pipelines exist today, and which would this role build? | noted |
| RR6 | Pay published, near market median | positive_signal | — | "$148,000–$166,000" | Employer publishes a band close to the Series B–D median | `[grounded]` JD; `[generic]` band | How is the band set for this level, and does it differ between Denver and remote? | noted |

Severity high: none found.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Check location and work authorization against Remote (US) or Denver before any other effort | R1 | `[grounded]` R1 | proposed |
| A2 | Open the live posting and confirm it with the recruiter, including the email domain | RR1 | `[generic]` | proposed |
| A3 | Raise the base floor and the equity terms before the loop | R2, RR3 | `[grounded]` | proposed |
| A4 | Before the first interview, build a small dbt project with tests on a BigQuery sandbox; keep a one-page note of what differed | G1 | `[inferred]` from the R8 limit | proposed |
| A5 | Interview wording for BigQuery, stating the limit: "I've run dbt on Snowflake at about 180 models; I haven't run BigQuery in production, and here is how I'd approach the differences" | G1 | `[grounded]` Snowflake and model count; limit stated | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches ("Pellucid Learning live online tutoring Denver"; "Pellucid Learning Series C $52M 2026") were refused at the permission prompt, so nothing came back. The careers-page fetch was not completed. Would have moved whether the posting is live and whether the entity matches the about page; RR1 stays open |
| 2. Role-family sweep | unavailable | Not sent once searches were refused. Would have added a second pay source; the report you supplied already gives the band |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

## Upgrade menu

If you want this kept as a file, I can write it to `tuesday-dossier.md`.

- Your location and work-authorization status → R1 moves from unclear to direct or failed, and the decision may simplify.
- Your base floor → R2 closes.
- The live posting link and the recruiter's email domain → you can check RR1 yourself in minutes.
- A small BigQuery project → R8's confidence rises from low, and the bridge has an artifact behind it.
- A sanitized pipeline note or repo excerpt covering ingestion and contracts → R9 and R10 move toward direct.
- The hiring manager's name → the scope read and which verified story to lead with for that reader.
- Team size and equity terms → RR2 and RR3 close.

## Questions

Q1 — R1: Are you authorized to work in the US, and can you work fully remote or from the Denver office?

Q2 — R2: Does a $148,000–$166,000 base, plus equity, meet your floor?

Q3 — R9: Which data sources have you built ingestion for (a product database, a CRM, event streams), and what did you own end to end?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.