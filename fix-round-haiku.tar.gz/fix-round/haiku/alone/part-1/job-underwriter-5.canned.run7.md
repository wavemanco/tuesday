**Yes, it's worth applying to, on three checks.** Decision: `conditional_go`.

- **Hard gates:** none failed; unconfirmed: R1 (Remote US or Denver office), R2 (salary $148,000–$166,000); candidate constraints not given — checks against them unknown
- **Fit ledger:**
  - `hard_gate` — unclear: R1 (Remote US or Denver office), R2 (salary $148,000–$166,000)
  - `must_have` — direct: R3 (5+ years data engineering), R4 (strong SQL and Python), R5 (dbt and a cloud warehouse), R6 (Airflow or similar), R7 (data quality testing)
  - `important` — adjacent: R9 (BigQuery-modelled warehouse) · unclear: R8 (ingestion from app and CRM), R10 (data contracts analysts depend on)
- **Opportunity ledger:** The role reads sound. Scope is one domain's reporting pipelines (RR2), and the posted pay sits around the role-family median and upper quartile (RR5). Open items are the unnamed hiring manager (RR1), unquantified equity (RR4), and the employer's public footprint, which search did not corroborate (RR3).
- **Severe red flags:** none found.
- **Conditions for go:** (1) R1 and R2 confirmed against your own location and pay floor; (2) RR3 corroborated, by the Series C announcement or the company's press page; (3) R9 framed as adjacent, never as BigQuery experience.

The main gap is R9. The JD names BigQuery in its responsibilities, not its requirements, and you have built the same kind of dbt project on Snowflake. The dbt skill carries over. The BigQuery-specific work does not yet.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning, live online tutoring for K-12 in 31 states; founded 2016, Denver; 264 employees; Series C ($52M, Feb 2026) | `[grounded]` your paste of the About page; not corroborated by search (RR3) |
| Scope | One domain's pipelines (ingestion, warehouse, contracts) with no stated direct reports | `[inferred]` from the JD; matches the typical senior scope in the pay report |
| Seniority | 5+ years; you have 6 | `[generic]` Datawright: "senior" typically means 5–8 years |
| Market calibration | Posted $148,000–$166,000 against a base median of $151,000 and IQR of $139,000–$163,500. This is the market band, not this employer's offer (RR5) | `[generic]` Datawright 2026 report, as you supplied it; `[grounded]` the posted range |
| Unknowns | Hiring manager; equity terms; Denver in-office expectations; team size; ownership of analyst contracts | — |
| Contradictions | None between the JD and the live careers page | `[grounded]` careers page fetched |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | Your location and eligibility were not given, so nothing settles it | `[grounded]` JD | Q1 below |
| R2 | Salary $148,000–$166,000 | hard_gate | unclear | none | hard_gate | Your pay floor was not given | `[grounded]` JD | Q2 below |
| R3 | 5+ years data engineering | must_have | direct | medium | none | Six years at a B2B payroll company, self-reported; the years are graded on fit, not treated as a gate | `[grounded]` your background | Verify by probe in interview |
| R4 | Strong SQL and Python | must_have | direct | medium | none | Daily use, self-reported | `[grounded]` your background | Verify by probe in interview |
| R5 | dbt and a cloud warehouse | must_have | direct | medium | none | About 180 models in dbt on Snowflake; Snowflake is a cloud warehouse | `[grounded]` your background; `[inferred]` that Snowflake meets "cloud warehouse" | Verify by probe in interview |
| R6 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow, self-reported | `[grounded]` your background | Verify by probe in interview |
| R7 | Data quality testing | must_have | direct | medium | none | You set up the Great Expectations suite | `[grounded]` your background | Verify by probe in interview |
| R8 | Ingestion from app and CRM | important | unclear | low | discovery | Pipelines are named; these sources are not | `[grounded]` silence in your background | Q3 below |
| R9 | BigQuery-modelled warehouse | important | adjacent | medium | transferability | dbt and Snowflake carry over; no BigQuery use, so its specifics are untested | `[grounded]` your statement "never used BigQuery"; `[inferred]` that dbt skill transfers | G1 |
| R10 | Data contracts analysts rely on | important | unclear | low | discovery | Your test suite is the nearest thread; contracts are not mentioned | `[grounded]` silence in your background | G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R9, important) | transferability | Snowflake and dbt at about 180 models; no BigQuery | It is the most visible stack mismatch in the posting | Warehouse cost, partitioning or access-control work on Snowflake; any dbt migration between platforms | A BigQuery sandbox project with one dbt model, or a course noted as such | `[grounded]` your statement; `[inferred]` dbt skill carries over; `[generic]` that interviewers probe warehouse-specific cost and access |
| G2 | Ingestion from app and CRM (R8, important) | discovery | Pipelines are named; the sources are not | It is one of four responsibilities | Pulls from a production database, CDC, a CRM API, or webhooks | An ingestion design note or DAG | `[grounded]` silence in your background |
| G3 | Data contracts (R10, important) | discovery | Test suite confirmed; analyst contracts not mentioned | The posting names contracts as what analysts depend on | Schema or freshness agreements with analysts; change-breaking process | A contract document or schema-change process | `[grounded]` silence; `[inferred]` that the test suite is the nearest thread |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | No hiring manager named | unknown | — | (no name in the posting) | The reporting line and team size are unknown | `[grounded]` JD silence | Who would I report to, and how many engineers are on the data team? | unresolved |
| RR2 | Scope is one domain | positive_signal | — | "Build and run the pipelines behind our tutoring platform's reporting" | Ownership is bounded and matches the typical senior scope | `[grounded]` JD; `[generic]` Datawright scope norm | Which pipelines would I own end to end, and which would I share with analytics? | noted |
| RR3 | Employer not established from attributable sources | risk_signal | low | "Pellucid Learning runs live online tutoring for K-12 schools in 31 US states" | `[generic]` pattern for companies of this size, not a claim about this one. The live posting is on the company's own domain; the Series C and headcount rest on the About page alone | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me to the Series C announcement or the company's press page? | unresolved |
| RR4 | Equity unquantified | unknown | — | "plus equity" | Equity value cannot be assessed from the posting | `[grounded]` JD | What is the grant size, vesting schedule, and valuation basis? | unresolved |
| RR5 | Salary disclosed and in band | positive_signal | — | "Salary $148,000–$166,000" | The range sits around the role-family median and upper quartile | `[grounded]` posted range; `[generic]` band | Is $148,000 the opening offer or a floor? | noted |

Severity is `low` on RR3 because the posting is live on the company's domain. Most small companies are simply small.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Check your own US eligibility and pay floor before applying | R1, R2 are unconfirmed | `[grounded]` R1, R2 | pending your approval |
| A2 | Apply through the live careers posting | RR3 | `[grounded]` careers page | pending your approval |
| A3 | Lead with the dbt-on-Snowflake and Airflow work in your own words; name BigQuery as not used, with a sandbox project as your closure path | R9 needs its limit stated | `[grounded]` your background; `[generic]` that a closure path helps | pending your approval |
| A4 | Ask the RR1, RR4 and RR5 verification questions in the first conversation | Register doubles as interview prep | `[grounded]` register | pending your approval |

No CV was supplied, so there are no resume-edit proposals yet.

## Evidence status

Verified: none yet. Your background is self-report at intake, so it stays at `medium` until probed.

Research tier: L1 — searches 1 of 5, fetches 1 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Pellucid Learning live online tutoring K-12 Denver" (no results, so the employer is not established from search). Fetched pellucidlearning.com/careers/senior-data-engineer: live, and the text matches your paste. The About page was not fetched, so its figures are as you pasted them. Moved: the contradictions row (none) and RR3 |
| 2. Role-family sweep | skipped | Your Datawright 2026 figures (median $151,000, IQR $139,000–$163,500, senior = 5–8 years, one-domain scope) are in hand and fix the market-calibration line |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

I can write this up as a `tuesday-dossier.md` file you keep, if you want the analysis in one place.

## Upgrade menu

- Your location and pay floor → R1 and R2 move from unclear to direct or hard_gate_fail, which could move the decision to `go` or `no_go`.
- Your CV → checks whether R3–R7 can rise from `medium` to `high` and whether any presentation gaps exist.
- A concrete description of your ingestion and contract work → R8 and R10 leave discovery.
- A BigQuery sandbox project or other artifact → R9 moves toward direct.
- The hiring manager's name → RR1 closes, and it shapes how the application is positioned.
- The Series C announcement or press page → RR3 closes.
- A deeper company pass (funding, leadership, news; up to 5 more searches and 2 more fetches). This is offered once; say the word and it runs.

**Questions**

R1 — Are you eligible to work and live in the US, and does remote-US or the Denver office work for you?

R2 — What is your base-salary floor?

R8 — Have you built ingestion from an application database and a CRM into a warehouse? What did you own, and did it run in production?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.