**Yes, apply, but hold until the recruiter answers one question about location.** Renata's fit on the stated requirements is strong. The posting contradicts itself on whether the role is fully remote, and that is a hard gate for you.

**Decision snapshot**

**Apply once the location answer is in. Status: `hold_pending_answers`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Fully remote UK, against Leeds four days a week)
- `must_have` — direct: R2, R3, R4, R5
- `important` — direct: R6 · adjacent: R7 (Pet-insurance product knowledge)
- `preferred` — direct: R9 (Insurance experience)

R7 is the one real gap, and it is a bridge from motor, not a match. R1 is unresolved, not failed.

**Opportunity ledger.** The scope is well defined: RR5 is a positive signal, and the reporting line to the Director of Pricing is stated on the careers page. The location conflict (RR1) and the withheld salary (RR2) are open, and whether the role manages people is unknown (RR3).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote UK, against Leeds four days a week); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:** If the role is fully remote, the status moves to `conditional_go`, with the salary and team-shape answers as conditions. If it is Leeds four days a week and that doesn't work for you, it is `no_go` unless the employer flexes. Your own location and salary limits are needed to decide which.

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech with a pet-insurance product | `[grounded]` JD and careers page |
| Mandate | Own pricing analytics for the pet-insurance product; build and monitor rating models; design and read price tests; turn results into recommendations for underwriting and product | `[grounded]` JD |
| Reporting line | Director of Pricing (Odile Varga) | `[grounded]` careers page |
| Working pattern | JD says fully remote (UK); careers page says Leeds office four days a week | `[grounded]` both sources, in conflict |
| Scope read | Ordinary senior IC scope: ownership of analytics and recommendations, with no stated budget or headcount | `[inferred]` from the JD's verbs against its silence on team |
| Market calibration | Senior pricing analysts at UK insurers and insurtechs: median base £58,400, interquartile range £52,100 to £64,900 (n=612). This is the band to expect, not this employer's offer | `[generic]` Pricewell 2026 pay survey |
| Compensation | Not stated in the material provided | `[grounded]` absence in JD |
| Unknowns | Salary; whether the role line-manages or leads analysts; the contract basis; the live working pattern | — |
| Contradictions | Working pattern (JD vs careers page) | `[grounded]` |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Working location: fully remote UK | hard_gate | unclear | low | hard_gate | Two sources conflict. Renata's own limit is not given | `[grounded]` JD vs careers page | Answer before applying (RR1) |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | high | none | 5 years at a UK motor insurer, the last 2 senior | `[grounded]` user-stated background | none |
| R3 | Build and monitor rating models (GLM) | must_have | direct | high | none | Built and maintained the young-driver GLM | `[grounded]` user-stated, specific ownership | none |
| R4 | Design and read price tests; recommendations to underwriting and product | must_have | direct | high | none | Ran 14 price tests with the underwriting team last year | `[grounded]` user-stated | none |
| R5 | Strong SQL and Python | must_have | direct | medium | discovery | Daily use, self-reported; no artifact yet | `[grounded]` user-stated | G3 |
| R6 | Presenting to underwriting or actuarial leads | important | direct | high | none | Presents the quarterly pricing review to the head of underwriting | `[grounded]` user-stated | none |
| R7 | Pet-insurance product knowledge (implied by the mandate) | important | adjacent | medium | transferability | Motor rating transfers. Pet drivers (breed, age, vet cost inflation, lifetime versus annual cover) are new | `[inferred]` from motor work against the product named in the JD | G2 |
| R9 | Insurance experience | preferred | direct | high | none | UK motor insurer | `[grounded]` user-stated | none |

**Gap recovery queue**

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Working location (R1, hard_gate) | hard_gate | Conflicting sources; your own limit not known | It can end the application on its own | Nothing to add from the CV; this is about your limits and the recruiter's answer | The recruiter's written working pattern | `[grounded]` both sources |
| G2 | Pet-insurance product knowledge (R7, important) | transferability | Motor rating only | Pet is the named product; the objection is likely | Pricing of a product with a rating structure, price tests, and a fast-moving book | A short write-up of how a motor rating change was tested and read | `[inferred]` bridge; `[generic]` that this is the likeliest objection |
| G3 | SQL and Python (R5, must_have) | discovery | Strong self-report, no artifact | A sample would turn a claim into evidence | Any anonymised query or model code | A sanitised SQL extract or model notebook | `[grounded]` user-stated |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Working location conflicts across sources | risk_signal | medium | JD: "Fully remote (UK)"; careers page: "Leeds office four days a week" | The careers page may be stale, or the role may have shifted to hybrid. Medium, not high, because the conflict is between two of the employer's own sources and may be a stale page | `[grounded]` both sources | Is this role fully remote from the UK, or is it based in Leeds four days a week? | unresolved |
| RR2 | Salary withheld | unknown | — | Not stated in the JD | The posting may not publish pay, or may sit below the band | `[inferred]` from the withheld figure, against the `[generic]` band | What base salary is budgeted for this role? | unresolved |
| RR3 | Team shape and line management unknown | unknown | — | "Own pricing analytics" | The role may have no reports, or may expect you to lead analysts. You have not managed people, so this matters | `[inferred]` from the JD's silence on team | Will this role line-manage anyone, or lead other analysts, and who else does the Director of Pricing manage? | unresolved |
| RR4 | Employer footprint thin in search | risk_signal | low | "Brindlemoor" | A young or small insurtech may simply have little press. The careers page is on the company's own domain, which confirms the posting, but the broader footprint did not appear in search | `[generic]` pattern for insurtechs of this size | Which legal entity would employ me, and how long has the pet product been live? | unresolved |
| RR5 | Scope and reporting line stated | positive_signal | — | "reports to the Director of Pricing" | The role is defined enough to assess | `[grounded]` JD and careers page | — | noted |

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Ask the recruiter in writing whether the role is fully remote or Leeds four days a week before you apply | RR1, R1 | `[grounded]` RR1 | pending your approval |
| A2 | Ask the salary band early, and whether the role has reports | RR2, RR3 | `[grounded]` the withheld figure | pending your approval |
| A3 | Lead with the strongest verified stories: the young-driver GLM you built and the 14 price tests you ran with underwriting. Describe motor pricing as transferable to pet, never as pet experience | R3, R4, R7 | `[grounded]` user-stated; `[inferred]` bridge | pending your approval |
| A4 | Do not describe any people leadership. Describe what you owned instead | RR3 | `[grounded]` background | pending your approval |

**Evidence status**

Verified: none yet. The background claims are user-stated and remain unverified until a sample or interview backs them.

Research tier: L1 — searches 3 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Brindlemoor insurtech pet insurance" (no results) and "Brindlemoor Senior Pricing Analyst pet insurance job" (returned the careers page). Fetched "Senior Pricing Analyst — Brindlemoor careers" (brindlemoor.co.uk/careers/senior-pricing-analyst). Moved the working-pattern contradiction (RR1) and the thin-footprint entry (RR4) |
| 2. Role-family sweep | yes | Searched "senior pricing analyst insurance UK salary pricing manager GLM", which returned "Pricewell 2026 UK Pricing and Actuarial Analytics Pay Survey" (pricewell.example/2026-uk-pricing-analytics-pay-survey). Moved the market calibration line |
| 3. Hiring manager's public footprint | skipped | Odile Varga was named, but no search was run in this pass. The upgrade menu offers it |

**Dossier offer:** I can write this up as a `tuesday-dossier.md` you can keep and reuse, if that is useful.

**Upgrade menu**

- Your own location and working-pattern limits, and a salary floor → R1 and RR2 close, and the status moves to `go` or `no_go`.
- The recruiter's written answer on location → R1 and RR1 close.
- A sanitised SQL extract or model notebook → R5 moves from `medium` to `high`.
- A short write-up of a motor price test → G2 narrows the pet-product objection.
- Odile Varga's public footprint → the research target 3 runs, and the positioning in A3 is checked for her as a reader.
- A deeper pass on Brindlemoor (funding, pet product launch date, leadership; up to 5 more searches and 2 more fetches). Say the word and it runs.

**Questions**

1. (R1, RR1) What are your location and working-pattern limits? Could you do Leeds four days a week?
2. (RR2) What base salary are you targeting, and is there a floor?
3. (RR3) Have you ever led people informally, such as mentoring analysts, owning a review, or supervising a piece of work, even without a title?

Answer in text, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.