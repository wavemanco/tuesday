## Decision snapshot

Yes, probably worth applying, but only after three things are checked. Your fit on the stack is strong. The open questions are your own location and pay floor (which I don't have), whether the role is really a build-from-scratch scope, and the BigQuery gap. **Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Remote (US) or Denver office), R2 (Salary $148,000–$166,000 plus equity)
- `must_have` — direct: R3 (5+ years data engineering), R4 (Strong SQL and Python), R5 (dbt and a cloud warehouse), R6 (Orchestration with Airflow or similar), R7 (Experience with data quality testing)
- `important` — adjacent: R8 (BigQuery warehouse); unclear: R9 (Ingestion from application and CRM sources), R10 (Data contracts analysts depend on)

Items that matter: R1 and R2, the two gates, unknown until your constraints are checked; R8, the one stack gap, and it is a transfer case, not a match; R9 and R10, responsibilities your background doesn't yet speak to.

**Opportunity ledger.** Sound on the stated facts, with more unknowns than red flags. The posted pay sits inside the generic band (RR6), and the requirements match your stack (RR7). Unknowns are scope and team (RR1, RR4, RR5), equity (RR3), and contract basis (RR2). Company facts are unverified because the research calls were refused (RR8).

- **Hard gates:** none failed; unconfirmed: R1 (Remote (US) or Denver office), R2 (Salary $148,000–$166,000 plus equity); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found

**What would change this.** Conditions for `conditional_go`: (1) your location and pay floor clear R1 and R2; (2) R8 is framed as an honest bridge, with its limit named; (3) RR2 and RR3 resolve clean (contract basis and equity terms). If R1 or R2 fails against your own constraints, this becomes `no_go` with that gate as the reason.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning, live online tutoring for K-12 schools in 31 US states; founded 2016, Denver; 264 employees; Series C ($52M, February 2026) | `[grounded]` the company's about page as you pasted it; not independently checked (RR8) |
| Mandate | Build and run pipelines behind the tutoring platform's reporting: ingestion from app and CRM, a dbt-modelled warehouse in BigQuery, data contracts for analysts | `[grounded]` JD |
| Scope read | Broader than one domain's pipelines: three areas (ingestion, warehouse, contracts) in one post | `[inferred]` from the JD's three responsibilities against the pay report's "one domain" norm |
| Market calibration | Posted $148k–$166k (midpoint $157k) sits inside the IQR of $139k–$163.5k and above the $151k median | `[generic]` band from the Datawright report you forwarded (Series B–D, n=2,310); the report's figures are `[grounded]`, its application to this employer is not |
| Unknowns | Whether the warehouse is built or being built; team size; contract basis; equity terms; hiring manager | — |
| Contradictions | None between the JD and the pasted about page | `[grounded]` both pasted; no live check ran |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | Your location constraints weren't given, so the check can't run. No statement from you means no band | `[grounded]` JD | Q1 |
| R2 | Salary $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | Your pay floor wasn't given. Equity is posted without terms | `[grounded]` JD | Q1; RR3 |
| R3 | 5+ years data engineering | must_have | direct | medium | none | Six years stated, at one employer. Self-reported; no artifact yet | `[grounded]` your background | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | Daily use stated | `[grounded]` your background | none |
| R5 | dbt and a cloud warehouse | must_have | direct | medium | none | dbt project of about 180 models on Snowflake; the requirement is met by dbt and any cloud warehouse | `[grounded]` your background | A sanitized model graph or repo excerpt would raise to high |
| R6 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow in daily use | `[grounded]` your background | none |
| R7 | Experience with data quality testing | must_have | direct | medium | none | You set up the Great Expectations suite. Whether you ran it in production after that isn't stated | `[grounded]` your background | Q2 covers ongoing ownership |
| R8 | BigQuery warehouse (role text, not a listed requirement) | important | adjacent | medium | transferability | Snowflake and dbt carry over. BigQuery specifics (SQL dialect, partitioning and clustering, cost model) are not exercised; limit named here | `[grounded]` JD names BigQuery; `[inferred]` adjacency from Snowflake and dbt | G1 |
| R9 | Ingestion from application and CRM sources | important | unclear | none | discovery | Your background doesn't say whether you built source ingestion from app or CRM systems | `[inferred]` from the JD responsibility | Q2 |
| R10 | Data contracts analysts depend on | important | unclear | none | discovery | Not mentioned in your background | `[inferred]` from the JD responsibility | Q2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R8, important) | transferability | Snowflake-based dbt work; no BigQuery use stated | The posting names BigQuery as the warehouse, so an interviewer will probe it | Any Snowflake-to-another-warehouse move; cost or performance tuning on Snowflake (the same discipline carries over); any GCP work, including a sandbox | A sanitized dbt project or a short note on what you'd check first on BigQuery | `[grounded]` JD; `[inferred]` the bridge from Snowflake experience |
| G2 | Ingestion and data contracts (R9, R10, important) | discovery | Not in your background | Two of the role's three named responsibilities; your answer decides whether the scope read holds | Source connectors you built or ran; schema-change handling; producer-consumer agreements with analysts | An ingestion design doc, a contract or schema-spec example | `[inferred]` from JD responsibilities |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Build versus run of the warehouse is unstated | unknown | — | "Build and run the pipelines" | The role may be building the BigQuery warehouse from near scratch, or inheriting one in production | `[inferred]` from the JD's wording against its silence on current state | Is the BigQuery warehouse and its dbt project in production today, or is this role building it? | unresolved |
| RR2 | Contract basis unstated | unknown | — | Not stated in the posting | The role may be permanent or fixed-term; the posting doesn't say | `[inferred]` from silence on contract type | Is this a permanent position, and if fixed-term, what is the term? | unresolved |
| RR3 | Equity posted without terms | unknown | — | "plus equity" | The equity could be material or nominal; the posting gives no grant size or vesting | `[inferred]` from the JD's wording | What equity is offered: grant size, vesting schedule, and how it is valued? | unresolved |
| RR4 | Scope spans three areas for one senior role | risk_signal | low | "ingestion from our app and CRM, a dbt-modelled warehouse … and the data contracts" | One person may own a de-facto data platform with no team named; severity low because the posting doesn't say so | `[generic]` pattern for Series B–D companies building a first data function; not a claim about this employer | Who else is on the data team, and who owns each of the three areas day to day? | unresolved |
| RR5 | No hiring manager or team named | unknown | — | Not named in the posting | Common in postings; not a warning sign on its own | `[generic]` common posting pattern | Who is the hiring manager, and who would I work with on ingestion and contracts? | unresolved |
| RR6 | Posted pay sits inside the role-family band | positive_signal | — | "$148,000–$166,000 plus equity" | Pay is in the normal range for this title and stage | `[grounded]` posted figure and the report's figures; `[generic]` applicability to this employer | Is the range set for this level, and how does it weigh against the equity? | noted |
| RR7 | Stated requirements match your stack | positive_signal | — | "dbt and a cloud warehouse; orchestration with Airflow or similar; data quality testing" | Most requirements are already met on your existing stack | `[grounded]` your background against the JD | What would the first six months need from me on BigQuery? | noted |
| RR8 | Company facts not independently checked | unknown | — | "Series C ($52M, February 2026)" | Facts rest only on the page you pasted; the live check was refused | `[grounded]` source is your pasted page only | What does the data team's roadmap look like after the Series C? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Ask the recruiter four things before investing in the loop: contract basis, equity terms, whether the warehouse is built or being built, and the hiring manager | Closes RR1, RR2, RR3, RR5 | `[grounded]` register rows | pending your approval |
| A2 | Lead your CV with the dbt, Airflow and Great Expectations bullets. State Snowflake plainly. Present BigQuery as a bridge, with its limit named, and claim no BigQuery experience | Matches R5–R8 without adding claims | `[grounded]` rows R5–R8; reframing audit applies to any new wording | pending your approval |
| A3 | Prepare one honest answer each for ingestion and data contracts, once Q2 is answered | R9 and R10 are the likeliest probes | `[inferred]` from the JD responsibilities | pending your approval |

## Evidence status

Verified: none yet. Your background is self-report at intake, so every row above sits at `medium` or lower until something is inspected.

Research tier: L1 — searches 1 of 5, fetches 2 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Fetches of the careers page and the about page, and one search on the Series C, were all refused: permission not granted in this session. Would have moved: whether the posting is live and matches the JD text; whether the about-page facts hold; whether the standing failed-attribution entry applies |
| 2. Role-family sweep | skipped | The Datawright report you forwarded fixes the band and the scope norm already, so no search was sent |
| 3. Hiring manager's public footprint | n/a | No name was given |

## Upgrade menu

- Your location and pay constraints, and whether you'd need sponsorship: R1 and R2 close, and the status can move to `go` or `no_go`.
- Any BigQuery exposure, including a sandbox or a cost-tuning exercise: R8 can move from a bridge to a stated, inspectable claim.
- An ingestion design doc or a data-contract example, sanitized: R9 and R10 move from unclear to a verifiable fit.
- Company checks: if you grant web access for this session, a rerun at L1 can check the live posting and the Series C claim (RR8).
- A `tuesday-dossier.md` of this assessment, if you want to keep it: I can emit it on request.

**Questions**

Q1 (R1, R2) — What are your location and base-pay floors, and would you need visa sponsorship to take this role?

Q2 (R7, R9, R10) — Have you built ingestion from application or CRM sources, or defined data contracts with analyst consumers, and with which tools? Did you keep the Great Expectations suite running in production after setting it up?

Q3 (R8) — Have you used BigQuery at all, even in a sandbox or on a cost-tuning job?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.