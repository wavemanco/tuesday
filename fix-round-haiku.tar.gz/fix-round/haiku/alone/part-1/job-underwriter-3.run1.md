**Decision snapshot: `no_go`**

- **Fit ledger (you):** Strong on the stated requirements. You have 9 years in growth, B2C subscription leadership, team management at 3–7 people, an $8M→$40M ARR scale-up with budget ownership, and SQL, GA4, and Braze. [grounded: your background]. Five posting functions (SEO/content, PR, brand, partnerships, sales ops) are not in your background, so they are unknown, not disproven.
- **Hard gates: 2 failed.**
  1. **Base pay.** The posting says $70–85k. Your floor is $150k. Even the top of the range is $65k short, about 43% under your floor. [grounded]
  2. **Location.** Austin on-site 5 days a week, "no exceptions." You are remote-only. [grounded]
- **Opportunity ledger:** Negative on its own terms, separate from your fit. See the risk register below.

Either failed gate is enough for `no_go`. Nothing in the rest of the posting can offset them.

**Why it feels off:** The strong fit is real, but the posting is describing a different job than the one your résumé qualifies you for. It asks for a senior leader's track record, a solo operator's workload, and a pay band and location policy that don't match either. The two things that feel off are the two hard gates. The rest of the posting reads the same way.

**Role reality**
- **Scope:** One person owning seven functions with "a team of one to start" and "we believe in players who don't need a bench." [grounded]
- **Hours:** "Evenings and weekends when it matters is just who we are." This describes a normal overtime expectation. [grounded]
- **Success criteria:** "Metrics will evolve as we learn." Your targets would be set after you start. [grounded]
- **Market calibration:** Head-level growth roles at funded companies are usually priced well above $85k base. [generic] This is a pattern, not a checked figure for Novaline. I did not run research.
- **Positive signals:** Series A and "profitable since day one." Both come from the posting itself and are unverified. [grounded]

**Evidence map** (fit from the CV you gave; the posting's wording is the source for requirements)

| # | Requirement | Priority | Fit | Confidence | Gap | Evidence |
|---|---|---|---|---|---|---|
| 1 | 8+ years growth leadership | must | strong | high | none | 9 years; growth lead → Head of Growth |
| 2 | Paid acquisition | must | strong | high | none | Owned paid at both companies |
| 3 | Lifecycle/CRM | must | strong | high | none | Owned lifecycle; deep in Braze |
| 4 | Experimentation and analytics | implied | strong | high | none | Owned experimentation; SQL, GA4 |
| 5 | Team leadership | implied | strong | high | none | Managed teams of 3–7 |
| 6 | Budget ownership at scale | preferred | strong | high | none | $8M→$40M ARR with a budget you controlled |
| 7 | SEO/content | must | unknown | low | capability | Not in your background |
| 8 | PR | must | unknown | low | capability | Not in your background |
| 9 | Brand | must | unknown | low | capability | Not in your background |
| 10 | Partnerships | must | unknown | low | capability | Not in your background |
| 11 | Sales ops | must | unknown | low | transferability | Adjacent to revenue work, not shown |
| 12 | Base ≥ $150k | hard gate | fail | high | hard_gate | Posting: $70–85k [grounded] |
| 13 | Remote-only | hard gate | fail | high | hard_gate | Posting: Austin 5 days, "no exceptions" [grounded] |

**Gap recovery queue:** Gaps 7–11 would close only with evidence of work in those areas. Gaps 12 and 13 cannot be closed by rewording. Only the employer changing the terms would close them.

**Opportunity risk register**

| # | Risk | Severity | Class | Basis |
|---|---|---|---|---|
| R1 | Base $70–85k vs your $150k floor | high | mismatch | [grounded] |
| R2 | Austin on-site, "no exceptions," vs remote-only | high | mismatch | [grounded] |
| R3 | Seven functions, team of one, "no bench" | high | scope | [grounded] |
| R4 | Evenings and weekends as the norm | medium | culture | [grounded] |
| R5 | Success metrics undefined, to be set later | medium | clarity | [grounded] |
| R6 | Employer not verified (no research run) | medium | verification | Standing entry |

**Application plan:** Don't apply. If you want to test whether the posting is flexible, send the recruiter one message asking directly about base and Austin. If both answers are no, close it out. Nothing here calls for CV changes.

**Evidence status**

| Target | Status | Reason |
|---|---|---|
| 1. Novaline's official site and careers page | skipped | Research not consented; run at L0 |
| 2. Role-family pay and scope sweep | skipped | Research not consented |
| 3. Hiring manager's public footprint | n/a | No name given |

Research tier: L0 — no searches. The decision doesn't depend on research, because both failed gates come from the posting's own text.

**Upgrade menu:** Research at L1 (up to 5 searches and 2 page fetches) would confirm Novaline exists as described and check the pay band against live data. It would not change the gate results. A recruiter's answers would change R2 only if they say Austin is negotiable. A link to the live posting would confirm the wording.

If you want this saved for later use with mock-interview, I can write it to a `tuesday-dossier.md` file.

**Questions**
1. Has anyone at Novaline, or the recruiter, said anything about base or remote work beyond what's in the posting?
2. Do you want me to run the L1 research (up to 5 searches, 2 fetches) to verify the company and the pay band?
3. Would you like a short message to the recruiter asking about base and Austin, for you to review before anything is sent?

Reply with an answer, "skip," or "no" to any of these.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.