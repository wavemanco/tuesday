**Yes, it's worth applying, on three conditions. Status: `conditional_go`.** Your core stack matches the posting. The open questions are BigQuery, ingestion and data contracts, plus whether the employer and posting check out. Those checks failed in this run (details under Evidence status).

**Fit ledger.**

- `hard_gate` — unclear: R8 (Location: remote US or Denver office), R9 (Pay: $148,000–$166,000)
- `must_have` — direct: R1, R2, R3a, R4, R5 · adjacent: R3b (BigQuery specifics)
- `important` — unclear: R6 (ingestion from app and CRM), R7 (data contracts)

Reading: R1, R2, R3a, R4, R5 — the core stack is in hand; R3b — BigQuery transfers only as far as the dbt and warehouse layer; R6, R7 — ingestion and contracts are unstated in your background.

**Opportunity ledger.** Sound on pay and scope (RR3, RR4 are positive); the employer and live posting are unverified in this run (RR1), and the BigQuery stack and contract ownership are unstated in the posting (RR2, RR5).

- **Hard gates:** none failed; unconfirmed: R8 (Location: remote US or Denver office), R9 (Pay: $148,000–$166,000); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **What would change this (conditions for go):** (1) the posting is confirmed live and the employer checks out (RR1); (2) your location, work authorization and a $148,000 base all fit the role (R8, R9); (3) BigQuery is framed as not yet used, and ingestion and contract ownership are answered (R3b, R6, R7).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 states; founded 2016, Denver; 264 employees; Series C, $52M, February 2026 | `[grounded]` your pasted about page; self-reported, not verified this run |
| Mandate | Build and run the pipelines behind the tutoring platform's reporting: ingestion from app and CRM, a dbt-modelled BigQuery warehouse, data contracts for analysts | `[grounded]` JD |
| Scope read | One reporting domain, no direct reports stated; consistent with the report's typical scope for the title | `[generic]` Datawright report; `[grounded]` JD |
| Market calibration | Senior Data Engineer at Series B–D: base median $151,000, IQR $139,000–$163,500; "senior" usually 5–8 years. You have 6 | `[generic]` Datawright 2026 report from your recruiter, not searched |
| Compensation | Posted $148,000–$166,000 plus equity. The midpoint (about $157,000) sits above the median and inside the IQR. Equity is unquantified | `[grounded]` JD; band `[generic]` |
| Working pattern | Remote (US) or Denver office | `[grounded]` JD |
| Unknowns | Equity terms; BigQuery expectation at hire; who owns ingestion and contracts; hiring manager (not named); your location, work authorization and pay floor | — |
| Contradictions | None between the JD and the about page as pasted; the live site was not checked | `[grounded]` both pasted texts |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years data engineering | must_have | direct | medium | none | Six years at a B2B payroll company. Years are a fit row, not a gate | `[grounded]` your background, no artifact | none |
| R2 | Strong SQL and Python | must_have | direct | medium | none | Both used daily; no code shared | `[grounded]` your background | a repo or code sample would raise to high |
| R3a | dbt and a cloud warehouse (as written) | must_have | direct | medium | none | About 180 dbt models on Snowflake, a cloud warehouse. Met as written | `[grounded]` your background | none |
| R3b | BigQuery specifically (the JD's stack) | must_have | adjacent | medium | transferability | dbt modelling and warehouse work carry over. Limit: no BigQuery use, and BigQuery's own features and cost model were not exercised | `[grounded]` you have not used it; `[inferred]` transfer from the shared dbt layer | G1 |
| R4 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow for orchestration | `[grounded]` your background | none |
| R5 | Data quality testing | must_have | direct | medium | none | You set up the Great Expectations suite | `[grounded]` your background | a suite excerpt would raise to high |
| R6 | Ingestion from app and CRM | important | unclear | none | discovery | The JD's first responsibility; your background doesn't mention ingestion | `[inferred]` from JD scope | G2 |
| R7 | Data contracts analysts depend on | important | unclear | low | discovery | The GE suite is the nearest adjacent work; whether it enforced consumer agreements is not stated | `[inferred]` adjacency from R5 | G3 |
| R8 | Location: US remote or Denver office | hard_gate | unclear | none | hard_gate | Your location and work authorization were not given | `[grounded]` JD | Q1 |
| R9 | Pay: $148,000–$166,000 base plus equity | hard_gate | unclear | none | hard_gate | Your pay floor was not given | `[grounded]` JD | Q1 |

No CV was provided, so this map runs on your prose background and cites no document.

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R3b, must_have) | transferability | Snowflake and dbt, no BigQuery | BigQuery is named in the posting's first sentence; an honest bridge narrows the objection | Any BigQuery or GCP work, however small, would count. None is claimed | Sandbox or side-project notes | `[inferred]` bridge; `[generic]` that this is the likeliest objection |
| G2 | Ingestion from app and CRM (R6, important) | discovery | Not in your background | Listed first among the responsibilities | Pipelines pulling from a production app database, an API, or a CRM | A pipeline diagram or DAG list | `[inferred]` from JD scope |
| G3 | Data contracts (R7, important) | discovery | Great Expectations suite; no mention of consumer agreements | Analysts depend on these, and the posting names them | Schema or freshness agreements with downstream teams; a breaking-change process | A contract document or alert config | `[inferred]` from JD scope |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer and live posting unverified in this run | risk_signal | medium | "Pellucid Learning runs live online tutoring for K-12 schools in 31 US states." | The posting may not be live, or the about page may differ from the live site. The check was refused, so this is unverified, not shown to be missing | `[generic]` pattern for unverified postings; the check was refused, so no finding about this employer | Is this role open on your careers site now, and who would the hiring team be? | unresolved |
| RR2 | BigQuery named as the stack | unknown | — | "a dbt-modelled warehouse in BigQuery" | The role may expect BigQuery fluency on day one, or may plan a ramp | `[grounded]` JD | How much BigQuery depth do you expect this role to bring on day one? | unresolved |
| RR3 | Pay range posted; equity unquantified | positive_signal | — | "$148,000–$166,000 plus equity" | Base sits around the report median; equity value unknown | `[generic]` band from the report; `[grounded]` posted range | What equity is offered, and on what vesting terms? | noted |
| RR4 | Scope bounded to one reporting domain | positive_signal | — | "Build and run the pipelines behind our tutoring platform's reporting" | Ownership appears bounded and matches the typical scope for the title | `[generic]` scope norm from the report; `[grounded]` JD | Which pipelines would this role own end to end, and who else changes them? | noted |
| RR5 | Contract and ingestion ownership unstated | unknown | — | "the data contracts our analysts depend on" | The role may enforce contracts, or may only consume analysts' requirements | `[inferred]` from JD silence | Who defines and enforces the data contracts, and who owns ingestion from the app and CRM? | unresolved |
| RR6 | No hiring manager named | unknown | — | (the posting names no hiring manager) | Common in recruiter-led postings; not a signal on its own | `[generic]` pattern | Who would I report to, and does this role have direct reports? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm the posting is live and get the recruiter's email domain before you invest in the application | see RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Describe BigQuery as not yet used, and name the transferable Snowflake and dbt work. Claim no BigQuery depth | see R3b, G1 | `[grounded]` R3b | pending your approval |
| A3 | Ask RR2 and RR5 verbatim in the first screen | the register doubles as interview prep | `[grounded]` register | pending your approval |
| A4 | Propose resume edits once you share a CV, surfacing the 180-model dbt project and the GE suite as outcomes | see R1, R5 | `[grounded]` background | blocked: no CV provided |

## Evidence status

Verified: none yet. Your background is user-stated, and no artifact has been inspected.

Research tier: L1 — searches 1 of 5, fetches 1 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Pellucid Learning live online tutoring K-12 Denver" and fetched pellucidlearning.com/careers/senior-data-engineer. Both were refused: web search and fetch permission was not granted. Would have moved RR1 |
| 2. Role-family sweep | skipped | The Datawright 2026 report, provided in this conversation, already fixes the band, title norm and scope norm. No search sent |
| 3. Hiring manager's public footprint | n/a | No name given; the posting names no hiring manager |

## Upgrade menu

- A link to the live posting, or the recruiter's email domain → RR1 closes, and the employer check can run.
- Your CV → the evidence map cites the document, and any presentation gaps get proposed edits.
- A code sample, a repo, or a Great Expectations suite excerpt → R2 and R5 move to `high`.
- Any BigQuery or GCP work, however small → the limit in R3b narrows.
- Equity terms → RR3 closes.
- Permission for web search and fetch in this session → target 1 runs, with the 4 remaining searches and 1 remaining fetch in the L1 budget.

If you want to keep this analysis, I can write it up as a `tuesday-dossier.md` file that the mock-interview skill can read later.

Three questions:

1. G2 — At your payroll company, did you build or run ingestion from a production app or a CRM? If so, which source, and what broke?
2. G3 — Did any downstream team depend on a schema or freshness agreement you enforced, or was the Great Expectations suite internal to your team?
3. Q1 (R8, R9) — Where are you based, do you have US work authorization for a remote role, and does the posted range clear your pay floor?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.