**Decision: `no_go`.** Don't pursue this one as posted. Two hard gates fail, and neither can be fixed by how you word your application.

**Decision snapshot**
- **Hard gates:** 2 of 2 fail.
  - Compensation: the posting's $70–85k base is $65–80k under your $150k floor, at 47–57% of it [grounded].
  - Location: "on-site in our Austin office 5 days a week — no exceptions" conflicts with remote-only [grounded].
- **Fit ledger:** Strong on the core growth work (paid, lifecycle, experimentation, SQL/GA4/Braze, team leadership, the $8M→$40M scale story) and on the 8+ year requirement. Gaps on SEO/content, PR, brand, partnerships and sales ops, none of which your inputs evidence.
- **Opportunity ledger:** Several red flags beyond the two gates (see the risk register). Your "something feels off" is picking up real signals.
- **Confidence:** The opportunity read rests on the posting alone. No research was run, so the company's existence and the pay band are unverified.

**Role reality**
- Title and scope: Head of Growth owning seven functions, starting as a team of one, reporting to the CEO with a dotted line to the board [grounded].
- Pay: $70–85k base plus unquantified equity [grounded]. A Head-level base at Series A is typically well above this [generic, not researched].
- Hours: "evenings and weekends when it matters is just who we are" [grounded].

**Evidence map (condensed)**

| # | Requirement | Priority | Fit | Confidence | Gap | Evidence |
|---|---|---|---|---|---|---|
| 1 | 8+ yrs growth leadership | must | strong | medium | none | Your 9 years, stated in your background |
| 2 | Paid acquisition | must | strong | medium | none | Owned paid at two B2C subscription companies |
| 3 | Lifecycle/CRM | must | strong | medium | none | Owned lifecycle; deep in Braze |
| 4 | Experimentation | implied | strong | medium | none | Owned experimentation |
| 5 | SQL / analytics | implied | strong | medium | none | Deep in SQL and GA4 |
| 6 | Revenue scale, budget ownership | implied | strong | medium | none | $8M→$40M ARR with a budget you controlled |
| 7 | Build teams from scratch | implied | transferable | medium | scope | Managed teams of 3–7; posting wants a solo start |
| 8 | SEO / content | must | gap | none | discovery | Not in your inputs |
| 9 | Brand | must | gap | none | discovery | Not in your inputs |
| 10 | PR | must | gap | none | discovery | Not in your inputs |
| 11 | Partnerships | must | gap | none | discovery | Not in your inputs |
| 12 | Sales ops | must | gap | none | discovery | Not in your inputs |
| 13 | On-site Austin, 5 days | hard gate | fails | high | hard-gate | Posting, "no exceptions" |
| 14 | $150k base | hard gate | fails | high | hard-gate | Your floor vs. $70–85k posted |

**Opportunity risk register**

| Class | Severity | Signal |
|---|---|---|
| Compensation | high | $70–85k base is 47–57% of your floor [grounded] |
| Location | high | Austin on-site, "no exceptions" [grounded] |
| Seniority/pay | medium | "Head of" title at this base, equity unquantified [inferred] |
| Hours | medium | Evenings and weekends framed as culture [grounded] |
| Scope | medium | Seven functions, team of one, "won't need a bench" [grounded] |
| Ambiguity | medium | "Success metrics will evolve," dotted line to board [grounded] |
| Unverified employer | medium | "Series A, profitable since day one" not checked; standing entry [generic] |

**Application plan:** None recommended. The only path back to a `conditional_go` is written confirmation of both a remote arrangement and a base near $150k. Neither is likely from this posting. I wouldn't propose resume edits for this role.

**Evidence status**
Research tier: L0 — no searches

| Target | Status | Reason |
|---|---|---|
| L1-1: Novaline's official site and careers page | skipped | Research not consented |
| L1-2: Role-family sweep for title and pay | skipped | Research not consented |
| L1-3: Hiring manager's public footprint | n/a | No name given |

**Dossier offer:** I can save this assessment as `tuesday-dossier.md` so a later interview-prep run can pick it up.

**Upgrade menu**
- A recruiter's remote confirmation or base range would re-run the two hard gates. This is the only input that could change the decision.
- L1 research (up to 5 searches, 2 fetches) would verify that Novaline exists as described and replace the generic pay band with a sourced one.
- A list of any hands-on SEO, PR, brand, partnership or sales-ops work would upgrade rows 8–12 from gap to evidenced.

**Questions**
1. Did the recruiter say anything about remote work or a base above $85k? Is there a link to the live posting?
2. Have you done SEO/content, PR, brand, partnerships or sales ops hands-on? If so, how much?
3. Should I run L1 research now to verify the company and the pay band?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.