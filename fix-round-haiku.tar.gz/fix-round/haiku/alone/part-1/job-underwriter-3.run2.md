**Not worth pursuing. Status: `no_go`.** Two of your hard constraints fail on the posting's own terms: on-site in Austin five days a week with "no exceptions" (R1), and a $70–85k base against your $150k floor (R2). The sense that something is off is pointing at real problems, mostly these two gates.

**Fit ledger**

- `hard_gate`: failed: R1, R2
- `must_have`: direct: R3, R4, R5 · unclear: R6
- `important`: adjacent: R7, R8 · unclear: R9

Your core growth record matches the posting: R3, R4 and R5 are direct. The gaps are the scope outside paid, lifecycle and experimentation (R6), building from zero with no team (R7), and the e-commerce enablement domain (R9).

**Opportunity ledger.** The posting lists seven functions for one person (RR2) and attaches evening and weekend expectations (RR1). It also leaves success undefined while promising to change the metrics (RR3). Nothing in it is a positive signal except the CEO and board reporting line (RR7), and the "profitable since day one" claim is unverified.

- **Hard gates:** failed: R1 (on-site Austin five days, "no exceptions"), R2 (base $70–85k); met: none; your constraints were given, so both checks ran.
- **Severe red flags:** RR2 and RR6 are `severity: high`.
- **What would change this:** both gates would have to move. R1 would need the employer to say in writing that remote is possible, and R2 would need a base of at least $150k. The posting states both outright, so I would not spend application effort unless a recruiter confirms both in writing.

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Novaline, e-commerce enablement, Series A, "profitable since day one" | `[grounded]` posting; profitability is the company's claim, unverified |
| Mandate | All revenue growth: paid, SEO/content, lifecycle, brand, PR, partnerships, sales ops | `[grounded]` posting |
| Reporting | CEO, dotted line to board | `[grounded]` posting |
| Team | One person to start | `[grounded]` posting |
| Market calibration | Not run. Search permission was denied, so I can't say whether $70–85k is low for this seniority. I'm not giving a band from memory. | — |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance |
|---|---|---|---|---|---|---|---|
| R1 | On-site Austin, five days | hard_gate | hard_gate_fail | high | hard_gate | Posting says "no exceptions"; you are remote-only in Portland | `[grounded]` posting and your constraint |
| R2 | Base at least $150k | hard_gate | hard_gate_fail | high | hard_gate | Top of posted range is $65k under your floor | `[grounded]` posting and your constraint |
| R3 | 8+ years growth leadership | must_have | direct | high | none | Nine years, two Head/lead roles | `[grounded]` your background |
| R4 | Paid acquisition ownership | must_have | direct | high | none | Owned paid at both companies | `[grounded]` your background |
| R5 | Lifecycle and CRM | must_have | direct | high | none | Owned lifecycle; deep in Braze | `[grounded]` your background |
| R6 | SEO/content, brand, PR, partnerships, sales ops | must_have | unclear | low | discovery | Nothing in what you shared covers these | `[grounded]` absence in your materials |
| R7 | Building from zero as a team of one | important | adjacent | medium | transferability | You built and managed teams of 3–7; you have not started with no team | `[inferred]` from your team history |
| R8 | Ambiguity, evolving metrics | important | adjacent | medium | transferability | Experimentation ownership is relevant; the posting gives no success definition to test against | `[inferred]` |
| R9 | E-commerce enablement vs your B2C subscription background | important | unclear | low | discovery | Posting does not say whether the buyer is B2B or B2C | `[grounded]` posting; `[inferred]` on fit |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Always-on expectation | risk_signal | medium | "evenings and weekends when it matters is just who we are" | Off-hours work may be routine, not occasional | `[grounded]` quote; pattern `[generic]` | How often in a typical month does this role work evenings or weekends outside launches? | unresolved |
| RR2 | Seven functions, one person | risk_signal | high | "team of one to start … we believe in players who don't need a bench" | Accountability may exceed what one person can cover | `[inferred]` from scope against headcount | Which of these areas will I own in the first 90 days, and which will be handed off or hired? | unresolved |
| RR3 | Success undefined | risk_signal | medium | "success metrics will evolve as we learn" | Accountability may be set without a fixed target | `[grounded]` quote | What revenue number defines success at 6 and 12 months? | unresolved |
| RR4 | Equity unquantified | unknown | — | "meaningful equity upside" | Equity may be small or undefined | `[grounded]` quote | What is the grant size, vesting schedule and strike price? | unresolved |
| RR5 | Employer not established | risk_signal | medium | "Novaline (e-commerce enablement startup, Series A …)" | The posting may be stale or aggregated; I could not check | `[generic]` for companies this size; verification not run | Can you point me to the live role on Novaline's own careers page? | unresolved |
| RR6 | Pay against your floor | red_flag | high | "$70–85k base plus meaningful equity upside" | Fails your $150k constraint by $65k–$80k | `[grounded]` posting and your constraint | Is $70–85k the approved base for this role? | unresolved |
| RR7 | CEO and board reporting | positive_signal | — | "Report to the CEO with a dotted line to the board" | Some access to decision-makers | `[grounded]` posting | What is current revenue and runway? | noted |

**Application plan.** None, because the status is `no_go`. The only step worth taking is one message to a recruiter asking whether on-site and base salary are negotiable, and asking for the answer in writing before you spend any time on the loop.

**Evidence status**

Verified: R3, R4, R5 (your background, as you described it). Unverified: everything about Novaline itself.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches for Novaline were refused because search permission was not granted. RR5 stays open. |
| 2. Role-family sweep | unavailable | One search for Head of Growth pay was refused. The market calibration line stays empty. |
| 3. Hiring manager's public footprint | n/a | No name was given. |

If you want to be able to verify the company and the pay band, you can grant search permission and I'll run both checks. Or send me the careers-page link and I'll verify it from the page text. Upgrade menu: a live posting link or the company's careers page (RR5); written pay and location terms from a recruiter (R1, R2, RR6); a list of your SEO, PR, partnership or sales-ops work, if any (R6).

Would you like me to draft the recruiter message, or prepare a full dossier file for this posting?

1. Has anyone at Novaline, or a recruiter, said that on-site or the $70–85k base is negotiable? That is the only fact that could move this from `no_go`.
2. Can you send the live posting link from Novaline's careers page, or the recruiter's email domain? (RR5)
3. Does your background include any SEO, PR, partnership or sales-ops work I haven't seen? (R6, R9)

You can answer in text, paste a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.