**Decision: `conditional_go`.** Apply, but only once two things are settled: your location eligibility against "Remote (US) or Denver", and a concrete plan for BigQuery. The rest of the posting matches your background closely.

**Fit ledger**
- `hard_gate`: unclear: R10 (Remote US or Denver office)
- `must_have`: direct: R1, R2, R3, R4, R6, R7 · adjacent: R5 (BigQuery-specific warehouse)
- `important`: unclear: R8 (ingestion from app and CRM), R9 (data contracts for analysts)

R5 is the only must-have below direct. R8 and R9 are the important rows your CV doesn't address.

**Opportunity ledger.** Sound and specific. The posting is live and matches its own company page, and the pay sits inside the market band (RR1). The main unknowns are how much of the stack this role owns (RR2) and whether the company's self-reported footprint holds up (RR3). No severe red flags.

- **Hard gates:** none failed; unconfirmed: R10 (Remote US or Denver office); candidate constraints not given, so checks against your location and pay floor are unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) R5 has a credible ramp story (below), never framed as BigQuery experience; (2) you confirm location eligibility and your pay floor; (3) RR3 checks out in the first screen.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning, live online K-12 tutoring in 31 states, Denver, 264 employees, Series C ($52M, Feb 2026) | `[grounded]` company About page, via search |
| Posting | Live: "Accepting applications" on the careers page | `[grounded]` fetched careers page |
| Scope | Ingestion, a BigQuery warehouse and analyst data contracts for the reporting stack | `[grounded]` JD |
| Scope read | Ownership of a full reporting pipeline is at or a little above the typical one-domain senior scope | `[inferred]` JD against the market norm |
| Market calibration | Senior at Series B–D: median $151,000, IQR $139,000–$163,500; posted $148,000–$166,000 sits inside it, midpoint near the median | `[generic]` Datawright 2026, n=2,310; `[grounded]` JD |
| Unknowns | Hiring manager, team size, equity amount, whether BigQuery is already in production | — |
| Contradictions | None between the JD and the careers page | `[grounded]` |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance |
|---|---|---|---|---|---|---|---|
| R1 | 5+ years data engineering | must_have | direct | high | none | Six years at a B2B payroll company | `[grounded]` CV |
| R2 | Strong SQL and Python | must_have | direct | high | none | Both daily | `[grounded]` CV |
| R3 | dbt | must_have | direct | high | none | Built the project, about 180 models | `[grounded]` CV |
| R4 | Cloud warehouse | must_have | direct | high | none | Snowflake in production | `[grounded]` CV |
| R5 | BigQuery specifically | must_have | adjacent | medium | transferability | SQL, dbt and warehouse modelling carry over. Not exercised: BigQuery's cost and partitioning model, the dbt-bigquery adapter | `[inferred]` from R3 and R4 against the JD's named warehouse |
| R6 | Airflow or similar | must_have | direct | high | none | Orchestration on Airflow | `[grounded]` CV |
| R7 | Data quality testing | must_have | direct | high | none | Set up the Great Expectations suite | `[grounded]` CV |
| R8 | Ingestion from app and CRM | important | unclear | low | discovery | CV silent on CRM sources | `[grounded]` CV silence |
| R9 | Data contracts for analysts | important | unclear | low | discovery | CV silent on contracts | `[grounded]` CV silence |
| R10 | Remote US or Denver office | hard_gate | unclear | low | hard_gate | Your location wasn't given | `[grounded]` JD; candidate location unknown |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R5, must_have) | transferability | Snowflake and dbt at scale; no BigQuery | Adjacent must-have, the most likely interview objection | Any BigQuery use at all: a sandbox, a course, a side project, a dbt-bigquery test | A short BigQuery project repo: partitioned and clustered tables, a dbt model, a cost note | `[inferred]` bridge from R3 and R4; `[generic]` that partitioning and bytes-scanned cost are BigQuery's main differences |
| G2 | CRM ingestion (R8) | discovery | Nothing on CRM sources | Named in the first sentence of the JD | Any API or CDC ingestion from a CRM or SaaS source | Pipeline diagram or repo | `[grounded]` CV silence |

**Bridge case for G1.** Adjacent evidence: dbt modelling and SQL at 180-model scale on Snowflake. Limit: no BigQuery cost model, partitioning or adapter work. Strengthener: a small BigQuery build you can show.

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay inside market band | positive_signal | — | "$148,000–$166,000 plus equity" | Pay is in line for the title and stage | `[generic]` band; `[grounded]` posted figure | What is the pay band based on, and how is it set against experience? | noted |
| RR2 | Scope may exceed one domain | risk_signal | low | "Build and run the pipelines behind our tutoring platform's reporting" | The role may own ingestion, warehouse and contracts with no team behind it | `[inferred]` from the scope against the `[generic]` norm | Which of these pipelines does this role own end to end, and which does the existing team own? | unresolved |
| RR3 | Employer footprint self-reported | risk_signal | low | "Series C ($52M, February 2026)" | The funding and headcount figures come from the company's own page; my general search found no independent coverage | `[generic]` pattern for venture-backed companies this size | Who is on the data team today, and is this role new or a backfill? | reduced (live posting and About page agree) |
| RR4 | Hiring manager not named | unknown | — | (posting silent) | — | `[grounded]` posting | Who would I report to, and who would I work with most? | unresolved |
| RR5 | Equity unquantified | unknown | — | "plus equity" | — | `[grounded]` posting | What is the grant size, vesting schedule and valuation basis? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Build a small BigQuery project and put it in your application | Closes the G1 objection with evidence | `[grounded]` G1 | pending your approval |
| A2 | Confirm location eligibility with the recruiter before applying | R10 is unconfirmed | `[grounded]` R10 | pending your approval |
| A3 | Ask RR2, RR3, RR4 and RR5 verbatim in the first screen | The register doubles as interview prep | `[grounded]` register | pending your approval |
| A4 | Lead with the 180-model dbt project and the Great Expectations suite | Your strongest direct matches to the must-haves | `[grounded]` R3, R7 | pending your approval |

Wording rule for the application: say "dbt on Snowflake at 180-model scale; ramping on BigQuery" with a link to the BigQuery project. Don't write "BigQuery experience". `resume_edits_pending_approval` applies to any CV or cover-letter text.

## Evidence status

Stated, not yet inspected: all candidate claims above come from your background as you described it. Nothing is verified against an artifact yet.

Research tier: L1 — searches 3 of 5, fetches 1 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Pellucid Learning live online tutoring K-12 Denver" (no results) and "pellucidlearning.com senior data engineer careers" (returned the posting and the About page); fetched "Senior Data Engineer — Pellucid Learning careers" (pellucidlearning.com/careers/senior-data-engineer). Moved the Role reality organization and contradictions rows, and cleared the standing "employer not established" entry down to RR3 |
| 2. Role-family sweep | yes | Searched "Senior Data Engineer salary Series B-D US 2026 pay report", which returned "Datawright 2026 Data Engineering Pay Report" (datawright.example/2026-data-engineering-pay-report). Set the market calibration line and RR1 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

## Upgrade menu

- A BigQuery project or a dbt-bigquery test → R5 moves to direct and G1 closes.
- A CRM or SaaS ingestion example → R8 moves from unclear to direct.
- Your location and pay floor → R10 resolves, and the decision firms up to `go` or `no_go`.
- The recruiter's answer on the hiring manager and equity → RR4 and RR5 close.
- A deeper pass on Pellucid (funding coverage, leadership changes, past hiring): up to 5 more searches and 2 more fetches. Say the word and it runs.

**Questions for you** (G1, G2 and the hard gate):

- G1: Have you used BigQuery in any form (sandbox, course, side project)? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.
- G2: Have you built ingestion from a CRM or SaaS source, such as Salesforce or HubSpot? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.
- R10: Where are you based, and do you need the role to be in a specific state or time zone? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.