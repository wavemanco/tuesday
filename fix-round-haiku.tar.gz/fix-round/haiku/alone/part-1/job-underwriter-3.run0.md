**Decision: no_go.** Don't apply to this posting as written. Two of your stated hard constraints fail outright, and the posting says both are non-negotiable.

## Decision snapshot

- **Candidate fit:** Strong on the core: paid acquisition, lifecycle, experimentation, SQL/GA4/Braze, and $8M to $40M ARR [grounded, from your background]. Your provided background shows no SEO/content, PR, partnerships, sales ops, or brand work [grounded as absence, not as a claim you lack them]. The role is built for one person with no team, and you have managed 3 to 7 [grounded]. That is a mismatch in direction, not a gate.
- **Hard gates: 2 failed.**
  - **Compensation:** $70–85k base against your $150k floor [grounded, from the posting].
  - **Location:** Austin on-site five days a week, "no exceptions," against your remote-only requirement [grounded].
- **Schedule:** "Evenings and weekends when it matters" is an expectation, not a stated gate. It is flagged in the risk register.

## Role reality

Head of Growth covering seven functions (paid, SEO/content, lifecycle, brand, PR, partnerships, sales ops), held by one person, reporting to the CEO with a dotted line to the board. The scope reads like a 2–4 person team's remit. Success metrics are explicitly undefined: "will evolve as we learn."

**Market calibration** [generic]: Head-level growth roles at a Series A usually carry a base well above $85k. This is a pattern to check, not a verified figure, because research has not run.

## Opportunity risk register

| Class | Severity | Signal | Basis |
|---|---|---|---|
| Compensation mismatch | hard gate, failed | $70–85k base vs. $150k floor | [grounded] posting vs. your floor |
| Location mismatch | hard gate, failed | Austin 5 days, "no exceptions" | [grounded] posting |
| Scope-to-pay | high | Head title, seven functions, one person, $70–85k base | [grounded] posting; [generic] calibration |
| Undefined success criteria | medium | "Success metrics will evolve" | [grounded] posting |
| Unbounded hours | medium | "Evenings and weekends... is just who we are" | [grounded] posting |
| Equity unquantified | medium | "Meaningful equity upside," no figures, low base | [grounded] posting |
| Employer unverified (standing) | medium | "Profitable since day one" and Series A are unchecked | Research not run; existence not established |
| Board-level pressure on a solo role | low | Dotted line to the board for one function | [inferred] |

**On "something feels off":** Each signal can be legitimate on its own. Together (a senior title, a broad remit, a below-market base, a "no exceptions" location rule, and an open-ended hours norm) they usually mean the role is priced for a cheaper hire than the posting describes [inferred]. That is a pattern, not evidence of bad faith.

**Rationale:** The no_go comes from the hard gates, not from the role's overall quality. For someone without your constraints, the opportunity could be reasonable: e-commerce is adjacent to your experience, and the company is at a growth stage.

## Application plan

None recommended. If you want a cheap test, send one written question to the recruiter: "Is remote work possible, and is base negotiable toward $150k?" A no to either closes it. Reopen only if both change in writing, since the posting rules out the location exception.

**Research tier: L0, no searches run.** No declared targets were run, so there is no evidence-status table yet.

## Upgrade menu

- **L1 research** (up to 5 searches, 2 page fetches) would check whether Novaline exists as described and is hiring for this role, and give a market band for head-level growth at this stage. Until it runs, the employer is not established.
- **A link to the live posting**, or the company's careers page, would confirm the role is current.
- **Where you found it** (recruiter, careers page, job board) matters for verifying the employer.

**Dossier offer:** I can write `tuesday-dossier.md` with this assessment so it carries forward if you later rehearse for a similar role.

## Questions

1. **(G1)** Should I run L1 research to verify Novaline and whether the posting is live? It is capped at 5 searches and 2 page fetches.
2. **(G2)** Where did you find this posting, and do you have a link or recruiter contact?
3. **(G3)** Is anything pulling you toward this beyond the role itself, such as the e-commerce focus or the equity? If not, I'll treat no_go as final.

Reply with a number to answer; "skip" is also an answer.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.