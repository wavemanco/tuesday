## Decision: conditional go. Apply, but expect a screen on the 3-year line.

Not a waste of time, but on paper you're behind the one must-have that a recruiter will check first. Your evidence is strong on discovery, stakeholder work, and API fluency. It is thin on owning a roadmap and on measuring adoption. Apply if you can truthfully show one owned outcome. If you can't, the implementation-to-platform-PM path still works, but this posting is a harder first target than similar roles that treat implementation experience as the bar.

**Fit:** strong on discovery, stakeholder coordination, and technical fluency. Partial on shipping API products as the owner. Gap on PM tenure and adoption metrics.
**Hard gates:** none stated in the JD. Your non-negotiables (location, pay floor, authorization, timeline) weren't provided, so they're unknown.
**Opportunity:** unverified. I ran no searches. A Series B platform role may be the company's first dedicated PM, so ownership could be unclear `[inferred]`.

Research tier: L0, no searches.

## Evidence map

| # | Priority | Requirement | Fit | Confidence | Gap type | Evidence |
|---|---|---|---|---|---|---|
| 1 | Must-have | 3+ years PM experience | Gap | High | Transferability | No PM title. Closest is roadmap input (quarterly sessions) and requirements docs. |
| 2 | Must-have | Shipped API or platform products | Partial | Medium | Transferability | 30+ client integrations of a REST API, shipped end to end. You delivered integrations, not a product you owned. |
| 3 | Must-have | Technical fluency with API docs and schemas | Met | High | None | Postman, SQL, OpenAPI, integration architecture `[grounded]` from your resume. |
| 4 | Must-have | Stakeholder management: eng, sales, customers | Met | High | None | Coordinated vendor engineers, client engineers, and PMs across custom builds. |
| 5 | Must-have | Agile delivery | Unknown | Low | Discovery | Your resume doesn't name a process or your role in it. |
| 6 | Core | Discovery with integration partners | Met | High | None | Scoping workshops and quarterly client feedback sessions. |
| 7 | Core | Specs and driving delivery with eng squads | Partial | Medium | Transferability | You wrote requirements documents and coordinated engineers, but didn't own a backlog. |
| 8 | Core | Define and track adoption metrics | Gap | Medium | Capability | No metrics in the resume. Possible exception: the triage tool (below). |
| 9 | Core | Launch coordination with sales and support | Met | High | None | Owned UAT and go-live, and wrote the integration playbook. |

## Opportunity risk register

- **Screen risk (high):** the 3-year line is likely to filter you out before a human reads the rest. Counter it with the owned-outcome evidence in the questions below, not with title language.
- **Ownership ambiguity (medium) `[inferred]`:** "own the roadmap" plus "two engineering squads" at ~150 people could mean the role is the company's first PM for this platform. That's a plus for scope and a risk for support.
- **Unverified employer (medium):** I didn't confirm that Quartzline exists as described or that this posting is live. Get the posting link and check it before you spend effort.

## Application plan

- **Lead with** your discovery and stakeholder record. Example, drawn from your resume: "Led 30+ enterprise REST API integrations end to end, from scoping workshops through go-live."
- **Don't** convert "fed client feedback into roadmap inputs" into "owned the roadmap." That's the reframing trap, and an interviewer will test it.
- **Resume edits are pending your approval.** I'll draft them only after you say which of the questions below you can answer truthfully.

## Upgrade menu

- **Triage tool details:** what it did, who adopted it, and any before/after numbers. This is the single biggest lever. Right now it's an unconfirmed memory, not evidence.
- **Live posting link** and the company's careers page, so I can check the posting and the employer.
- **Non-negotiables:** location, pay floor, authorization, and start timeline.
- **Research (L1, consent needed):** up to 5 searches and 2 page fetches. It would verify Quartzline's stage, size, and product, check the posting is live, and look at a role-family pay band.

Offer: I can save this assessment as `tuesday-dossier.md` so a later interview-prep session can pick it up.

## Questions

1. **(row 8, 2)** Did you ever own a backlog, decide priorities, or ship a tool or feature from start to finish, including the triage tool? If so, what changed afterward, and was it measured?
2. **(row 5)** What delivery process did your squads run, such as Scrum or Kanban, and did you run planning or acceptance?
3. **(non-negotiables)** What are your location, pay floor, and start-date constraints?

Answer any of these, or skip any. Silence counts as a skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.