**Yes, it's worth applying, with three conditions.** The role matches your core stack and seniority, the pay sits in the middle of the market band, and the scope is concrete. Two things are open: you have never used BigQuery, and I could not verify the employer because web search and page fetch were denied.

**Status: `conditional_go`**

- **Fit ledger:**
  - `hard_gate`: unclear: R10, R11
  - `must_have`: direct: R1, R2, R3, R5, R6, R9
  - `important`: adjacent: R4, R8 · unclear: R7
- **Opportunity ledger:** Specific and mostly transparent: the stack is named, the salary is posted, and the scope is defined (RR5 positive). Ingestion scope, data-contract ownership, team shape and equity are unstated (RR2–RR4). Employer existence is unverified (RR1).
- **Hard gates:** none failed; unconfirmed: R10 (Remote US or Denver office), R11 (base $148,000–$166,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) location and salary floor confirmed against R10 and R11; (2) the posting and employer confirmed live (RR1); (3) BigQuery presented as adjacent and learnable, never as experience you have.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 states, founded 2016, Denver, 264 employees, Series C $52M (Feb 2026) | `[grounded]` company page as you pasted it; not checked against an outside source |
| Mandate | Build and run ingestion (app and CRM), the dbt-modelled BigQuery warehouse, and analyst data contracts | `[grounded]` JD |
| Scope read | Owns one domain's pipelines end to end, which matches the title | `[inferred]` from the JD's responsibilities |
| Market calibration | Posted range midpoint $157,000 sits above the survey median of $151,000 and inside the IQR of $139,000–$163,500 | `[generic]` survey figures as you summarized them; `[grounded]` posted range |
| Unknowns | Team size and reporting line; ingestion and contract ownership; equity value; location requirement for your situation | — |
| Contradictions | None within the material provided. The JD names BigQuery; your background is Snowflake, which is a gap, not a contradiction | `[grounded]` JD and CV |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years data engineering | must_have | direct | medium | none | Six years at a B2B payroll company | `[grounded]` CV as described | none |
| R2 | Strong SQL and Python | must_have | direct | medium | none | Daily use of both | `[grounded]` CV as described | none |
| R3 | dbt and a cloud warehouse | must_have | direct | medium | none | dbt project of about 180 models on Snowflake | `[grounded]` CV as described | none |
| R4 | BigQuery specifically (named in the duties) | important | adjacent | low | capability | Snowflake production experience transfers; BigQuery itself is unused | `[inferred]` from CV against JD | see G1 |
| R5 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow used for orchestration | `[grounded]` CV as described | none |
| R6 | Data quality testing | must_have | direct | medium | none | Set up a Great Expectations suite | `[grounded]` CV as described | none |
| R7 | Ingestion from app and CRM (duty) | important | unclear | low | discovery | Not in the CV; B2B payroll ingestion may overlap, but the CV does not say | `[grounded]` CV silence | see G2 |
| R8 | Data contracts analysts depend on (duty) | important | adjacent | medium | transferability | dbt models and tests are the mechanics; contracts as analyst agreements are not claimed | `[inferred]` from CV against JD | see G2 |
| R9 | Senior scope: one domain's pipelines | must_have | direct | medium | none | Owned a large dbt project and its orchestration | `[grounded]` CV as described | none |
| R10 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | Your location was not given | `[grounded]` JD; candidate constraint not given | see Q1 |
| R11 | Base $148,000–$166,000 | hard_gate | unclear | none | hard_gate | Your salary floor was not given; the range is posted | `[grounded]` JD; candidate constraint not given | see Q2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R4) | capability | Snowflake only | The JD names BigQuery in the duties, so it is the most visible gap | Any BigQuery use, including sandbox work, a migration, or query-only access | A sanitized query or a migration note | `[inferred]` from CV against JD |
| G2 | Ingestion and contracts (R7, R8) | discovery | The CV describes dbt and tests, not source ingestion or analyst-facing contracts | Both are named duties; the CV neither confirms nor denies them | Any app or CRM ingestion, or any agreements with analysts | A sanitized pipeline diagram or contract doc | `[inferred]` from CV against JD |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer and posting not verified | unknown | — | "Senior Data Engineer — Pellucid Learning" | The posting may be stale, or the employer may be smaller or different than described | `[generic]` pattern for unverified postings; no outside check run | Can you confirm this role is live on your careers page, and who the hiring manager is? | unresolved |
| RR2 | Ingestion and contract ownership unstated | unknown | — | "ingestion from our app and CRM … the data contracts our analysts depend on" | The role may own only part of these duties, or they may sit with another team | `[inferred]` from the JD's silence on ownership | Which of these sources and contracts does this role own end to end? | unresolved |
| RR3 | Team and reporting line unstated | unknown | — | "Build and run the pipelines" | Ownership may be solo or shared; the posting does not say | `[inferred]` from the JD's silence on team | Who else works on these pipelines, and who would I report to? | unresolved |
| RR4 | Equity terms unstated | unknown | — | "plus equity" | Equity value and vesting are unknown and may not be worth weighing | `[inferred]` from the JD's silence | What is the equity grant, vesting schedule, and current valuation basis? | unresolved |
| RR5 | Salary posted within the market band | positive_signal | — | "$148,000–$166,000" | Transparent pay in a sound range | `[grounded]` JD; `[generic]` band | — | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm the posting is live and ask the RR1 question in your first contact | Verifies the employer before you invest effort | `[grounded]` RR1 | pending your approval |
| A2 | Lead the CV with dbt scale, orchestration, and data-quality ownership | Those are your direct matches (R3, R5, R6, R9) | `[grounded]` evidence map | pending your approval |
| A3 | State BigQuery as a gap with a concrete ramp plan, not as experience | R4 is adjacent; claiming it would be unsupported | `[inferred]` R4 | pending your approval |
| A4 | Ask RR2 and RR3 in the first screen | Ingestion and team ownership decide how much of the role is yours | `[grounded]` register | pending your approval |

Nothing here is final until you approve it. A3 is the one most likely to be tempting to soften, so keep it exact.

## Evidence status

Verified: none yet. The web search and page fetch were denied by the permission prompt, so no outside facts were checked. Everything about the employer, the Series C, and the pay survey is as you provided it.

Research tier: L1 — searches 2 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Search and fetch both refused by the permission prompt. Would have confirmed the posting is live and that the employer exists as described (RR1) |
| 2. Role-family sweep | unavailable | Search refused. Would have checked the survey figures you pasted against a public source |
| 3. Hiring manager's public footprint | n/a | No name given, so there was no query to form |

Your pasted JD and company text were read as inputs, not as fetched links.

**Dossier offer:** I can save this assessment as `tuesday-dossier.md` if you want it kept.

## Upgrade menu

- Allow web search and page fetch → runs the L1 pass (up to 3 more searches and 1 more fetch; refused calls count toward the cap). Would verify RR1 and the survey figures.
- The live posting link, or the recruiter's email domain → verifies RR1 without any search.
- Any BigQuery exposure (sandbox, migration, query-only access) → R4 from `low` toward `medium`.
- A sanitized ingestion diagram or contract doc → R7 and R8 from `unclear`/`adjacent` toward `direct`.
- A sanitized dbt model or Great Expectations suite excerpt → R1–R3 and R6 from `medium` toward `high`.
- Your location and salary floor → R10 and R11 resolve from unconfirmed to met or failed.

## Questions

1. **(R10)** Where are you based, and can you work remotely in the US or from Denver?
2. **(R11)** What is your base-salary floor, and does equity change your decision at all?
3. **(R4)** Have you touched BigQuery at all, such as a sandbox, a migration, or query-only access?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.