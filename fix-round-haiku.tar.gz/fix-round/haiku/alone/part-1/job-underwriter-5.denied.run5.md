**Yes, it's worth applying, with three things to check first.** Your core stack matches the posting, and the stated pay sits at the market band. The main unknowns are BigQuery, two responsibilities your background doesn't cover on paper, and whether the employer and posting are real and live. `conditional_go`

**Fit ledger**

- `hard_gate`: unclear: R1 (Remote US or Denver office), R2 (base $148,000–$166,000 plus equity)
- `must_have`: direct: R3 (5+ years data engineering), R4 (strong SQL and Python), R5a (dbt and a cloud warehouse), R6 (orchestration with Airflow or similar), R7 (data quality testing)
- `important`: adjacent: R5b (BigQuery in the dbt warehouse), R10 (owning a domain's pipelines); unclear: R8 (ingestion from app and CRM), R9 (data contracts analysts depend on)

Your candidate constraints weren't given, so every gate check is unknown rather than passed. This ledger rests on your own account and has no artifacts behind it yet.

**Opportunity ledger.** The pay is stated and sits inside the market band, and the company describes itself as a Series C with 264 staff, though that's its own claim and I couldn't check it. The scope is unclear on team size, reporting line, and whether the BigQuery warehouse already exists (RR2, RR3). Equity is unquantified (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Remote US or Denver office), R2 (base $148,000–$166,000 plus equity); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the employer and live posting are confirmed (RR-E); (2) location and pay floor fit R1 and R2; (3) you can show a credible BigQuery path for R5b, stated as transferable from Snowflake, not as existing experience.

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning, live online tutoring for K-12 schools in 31 states; founded 2016; Series C, $52M, Feb 2026 | `[grounded]` company About page, as you pasted it |
| Mandate | Build and run tutoring-platform reporting pipelines, a dbt warehouse on BigQuery, and analyst data contracts | `[grounded]` JD |
| Working pattern | Remote (US) or Denver office | `[grounded]` JD |
| Scope read | Senior IC owning a domain's pipelines; no reports named, which is normal for this title | `[generic]` Datawright pay report definition, plus `[inferred]` from the JD's wording |
| Market calibration | Senior at Series B–D: base median $151,000, IQR $139,000–$163,500. The posting's $148,000–$166,000 sits around the median-to-upper range, about $157,000 at midpoint | `[generic]` Datawright 2026 (n=2,310), one report you got from your recruiter, so the sample is not independent |
| Unknowns | Team size, reporting line, warehouse state, ingestion and contract ownership, equity value, hiring manager | — |
| Contradictions | None found between JD and About page as provided; I couldn't check the live careers page | `[grounded]` provided text only |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance |
|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | low | discovery | Your location wasn't given | `[grounded]` JD |
| R2 | Base pay $148,000–$166,000 | hard_gate | unclear | low | discovery | Your floor wasn't given; the band is calibrated above | `[grounded]` JD |
| R3 | 5+ years data engineering | must_have | direct | medium | none | Six years at a B2B payroll company; self-reported | `[grounded]` your account |
| R4 | Strong SQL and Python | must_have | direct | medium | none | Daily use; self-reported | `[grounded]` your account |
| R5a | dbt and a cloud warehouse | must_have | direct | medium | none | dbt project of about 180 models on Snowflake | `[grounded]` your account |
| R5b | BigQuery warehouse (responsibility) | important | adjacent | medium | transferability | No BigQuery use; Snowflake and dbt transfer directly | `[inferred]` |
| R6 | Airflow or similar orchestration | must_have | direct | medium | none | Airflow used for orchestration | `[grounded]` your account |
| R7 | Data quality testing | must_have | direct | medium | none | Set up a Great Expectations suite | `[grounded]` your account |
| R8 | Ingestion from app and CRM | important | unclear | low | discovery | Not mentioned in your account | — |
| R9 | Data contracts analysts depend on | important | unclear | low | discovery | Not mentioned in your account | — |
| R10 | Owns a domain's pipelines end to end | important | adjacent | medium | transferability | Built and tested the dbt project; ownership isn't stated | `[inferred]` |

**Gap recovery queue** (questions are in the closing block)

- G1 (R5b, transferability): BigQuery. Closes with a BigQuery project, course, or any sample warehouse work. Without one, present it as transferable.
- G2 (R8, discovery): ingestion from an app and CRM. Closes with an example from your payroll work.
- G3 (R9, discovery): data contracts. Closes with an example of a contract with analysts.

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR-E | Employer not established from independent sources | risk_signal | low | "Pellucid Learning runs live online tutoring…" | The posting may be stale or may not be a live hiring channel | `[generic]` pattern; research unavailable (see below) | "Can you point me to this role on your careers site, and who would I interview with?" | unresolved |
| RR1 | Team size, reporting line, and decision rights unstated | unknown | — | "Build and run the pipelines behind our…" | The role may carry ownership without authority over contracts | `[inferred]` from JD silence | "Which pipelines and data contracts would I own end to end, and who approves changes?" | unresolved |
| RR2 | Warehouse state unclear | unknown | — | "a dbt-modelled warehouse in BigQuery" | The warehouse may be greenfield, which changes the scope | `[inferred]` from JD wording | "Is the BigQuery warehouse live today, or are we building it?" | unresolved |
| RR3 | Stated pay within market band | positive_signal | — | "$148,000–$166,000 plus equity" | Compensation is transparent and at market | `[generic]` band, `[grounded]` JD | "Is this band final for the level?" | noted |
| RR4 | Equity unquantified | unknown | — | "plus equity" | Equity could be material or token | `[inferred]` from JD silence | "What is the equity grant size and vesting schedule?" | unresolved |

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm the posting is live and who the hiring manager is before applying | RR-E | `[generic]` | pending your approval |
| A2 | Lead with the Snowflake dbt, Airflow, and Great Expectations work; describe BigQuery as transferable | R5b, G1 | `[inferred]` | pending your approval |
| A3 | Ask RR1–RR4 verbatim in the first recruiter call | Register doubles as interview prep | `[grounded]` register | pending your approval |

**Evidence status**

Verified: none yet. Your background is self-reported, and the company and market facts are from the text you pasted.

Research tier: L1 — searches 2 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Search for the company was refused by the session's permissions. Would confirm the company exists and the posting is live (RR-E) |
| 2. Role-family sweep | unavailable | Search for an independent salary source was refused. Would confirm or adjust the market band |
| 3. Hiring manager's public footprint | n/a | No name was given |

**Upgrade menu**

- Allowing web search would let me check the employer and posting (RR-E) and pull a second salary source for the market band.
- A BigQuery project or course → R5b moves from `adjacent` toward `direct`.
- Your location and pay floor → R1 and R2 get checked.
- Your ingestion and contract examples → R8 and R9 move out of unclear.

If you want this saved as `tuesday-dossier.md` for mock-interview prep later, say so.

**Questions**

1. (R1, R2) Where are you based, and what base-pay floor would you accept?
2. (R8, R9) Did your payroll work involve building ingestion from an app or CRM, or owning data contracts with analysts?
3. (R5b) Have you used BigQuery at all, even in a course, side project, or sample dataset?

You can answer in prose, skip any question, or say "skip."

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.