## Decision snapshot

**Yes on the core analytics requirements, not yet on healthcare or mentoring. Status: `conditional_go`. Apply once you've confirmed the posting is live.**

**Fit ledger.**

- `must_have`: direct: R1, R2, R3, R4, R6, R9 · adjacent: R5 (metrics layer), R7 (clinician partnership)
- `important`: unclear: R8 (mentor two junior analysts)
- `preferred`: adjacent: R10 (healthcare data)

- R1, R2, R3, R4, R9: CV-stated and confirmed at intake, `medium` until an artifact is inspected
- R6: exec-facing evidence; PM-level partnership isn't stated
- R5, R7: transferable, not direct
- R8: no mentoring stated
- R10: privacy and consent work, not PHI or HIPAA

**Opportunity ledger.** RR1 is the cap: the employer is unverified because the searches were refused, so this is not a finding that it's fake. RR2 is the healthcare question that matters most, and RR4 is a gap in the pasted JD, not a risk.

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) RR1: the posting is confirmed live on the employer's own site; (2) R8: mentoring is confirmed in your answer to Q1 before you claim it; (3) R10: healthcare is framed as adjacent, never as experience.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, digital-health scale-up, ~400 people, Series C, care-navigation app | `[grounded]` the JD as pasted; not verified externally |
| Mandate | Own product analytics: metrics layer, A/B tests, self-serve Looker dashboards, PM and clinician partnership, mentoring two junior analysts | `[grounded]` JD |
| Scope read | Broad for one senior post: five responsibilities plus managing two juniors | `[inferred]` from the responsibility list |
| Market calibration | Not run; the role-family sweep was refused, so there is no salary or scope band | — |
| Unknowns | Compensation, location, contract type, team shape, who owns HIPAA for analytics, first-year outcomes | — |
| Contradictions | None visible in the pasted JD; only one source, so nothing to check against | `[grounded]` |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | Six years at a ~2M-subscriber consumer company; intake statement, not yet inspected | `[grounded]` your intake statement | Confirm titles and dates on the CV |
| R2 | Expert SQL | must_have | direct | medium | none | Daily SQL on Snowflake for six years; "expert" is your characterization, not shown | `[grounded]` your intake statement | A sanitized query or schema raises to high |
| R3 | Experiment design at scale | must_have | direct | medium | none | Designed and ran 30+ tests a year, including the pricing test behind an 11% retention lift | `[grounded]` your intake statement | A sanitized test design or readout raises to high |
| R4 | Looker or similar BI; self-serve dashboards | must_have | direct | medium | none | Built the Looker instance from scratch; 40+ governed dashboards | `[grounded]` your intake statement | A sanitized dashboard screenshot raises to high |
| R5 | Define and maintain the metrics layer | must_have | adjacent | medium | transferability | Governed dashboards and the metrics memo imply metric definitions; ownership of definitions is not claimed | `[inferred]` from dashboards and memo | Q2 |
| R6 | Partner with PMs to turn analysis into roadmap decisions | must_have | direct | medium | none | Presents monthly to the VP Product and writes the exec metrics memo; PM-level partnership isn't stated | `[grounded]` intake; `[inferred]` roadmap link | Describe one roadmap decision your analysis changed |
| R7 | Partner with clinicians | must_have | adjacent | medium | transferability | Works with non-technical executive audiences; no clinician or clinical-workflow partnership. Limit: clinical vocabulary and workflow not exercised | `[grounded]` intake; `[generic]` that clinician and executive partnership differ | Name any clinical-adjacent work |
| R8 | Mentor two junior analysts | important | unclear | none | discovery | Nothing stated either way | `[grounded]` absence in intake | Q1 |
| R9 | Strong written communication with non-technical stakeholders | must_have | direct | medium | none | Monthly metrics memo read by the exec team; presentations to the VP Product | `[grounded]` your intake statement | A sanitized memo excerpt raises to high |
| R10 | Healthcare data experience (HIPAA) | preferred | adjacent | medium | transferability | Consumer PII under GDPR/CCPA and a consent-state model. Limit: no PHI and no HIPAA-regulated data | `[grounded]` intake; `[generic]` that HIPAA and GDPR/CCPA differ in scope | Q3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Healthcare data (R10, preferred) | transferability | Consent-state and PII work under GDPR/CCPA; no health data | The most likely objection; a stronger bridge narrows it without claiming healthcare | Any warehouse field touching health, diet or allergy; access controls on identifiable member data; consent rules applied to sensitive fields | A data-access policy excerpt, or the consent-state model's schema | `[inferred]` bridge from your consent work; `[generic]` that this is the likely objection |
| G2 | Mentor two junior analysts (R8, important) | discovery | Nothing stated | A stated duty of the role with no evidence either way | Reviewing a junior's SQL or experiment design; hiring or onboarding analysts; scoping a junior's project | A review example, or a hiring-loop note | `[grounded]` absence in intake |
| G3 | Metrics layer (R5, must_have) | transferability | Governed dashboards and memo; ownership of definitions unclear | A must-have that could move from adjacent to direct | Owning metric definitions, a metric dictionary, or sign-off on metric changes | A metric dictionary page or change-log entry | `[inferred]` from dashboards and memo |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not verified (searches refused) | risk_signal | medium | "Harborlight Health" (the posting's own name) | The entity or the posting may be stale or aggregated, or the employer may be too small for a public footprint | `[generic]` pattern for unverified postings; not a claim about this employer | Can you point me to this role on your own careers site, and who would I interview with? | unresolved |
| RR2 | Data access and HIPAA ownership unknown | unknown | — | "healthcare data experience (HIPAA) a plus" | Analysts may or may not query identifiable health data, and HIPAA ownership sits elsewhere | `[inferred]` from the HIPAA mention against silence on data access | Who owns HIPAA compliance for analytics data, and do analysts query identifiable member data directly? | unresolved |
| RR3 | Broad scope for one senior post | risk_signal | low | "Own product analytics … define and maintain the metrics layer … mentor two junior analysts" | The role may be bundled: one senior analyst covering the work of several | `[inferred]` from the responsibility list | What does the analytics team look like today, and who else owns experimentation or the metrics layer? | unresolved |
| RR4 | Compensation, location, contract type not in the pasted JD | unknown | — | (none quoted) | Terms missing from the input, so checks against your constraints can't run | `[grounded]` absence in the pasted JD | What are the base salary range, location policy and contract type for this role? | unresolved |
| RR5 | Concrete responsibilities and a named mentoring duty | positive_signal | — | "mentor two junior analysts" | The scope is stated, not vague | `[grounded]` the JD's own list | Who owns success metrics for this role in year one? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Verify the posting is live on the employer's site before spending application effort | RR1 | `[generic]` | proposed; your action |
| P2 | Lead the CV with your figures: 30+ tests a year, the pricing test behind an 11% retention lift, 40+ governed Looker dashboards, the memo to the exec team | R2, R3, R4, R9 | `[grounded]` your intake statements | pending your approval |
| P3 | Describe the consent-state model and GDPR/CCPA work as privacy engineering adjacent to health data, with the limit stated: no PHI, no HIPAA-regulated data | R10 | `[grounded]` intake; `[generic]` | pending your approval |
| P4 | Claim mentoring only if it happened, and describe it specifically | R8 | `[grounded]` absence in intake | proposed |
| P5 | Get one inspectable artifact: a sanitized experiment readout or dashboard screenshot | R1, R2, R3, R4 | `[grounded]` the rows' next actions | proposed |
| P6 | Never describe clinical partnership or healthcare experience; in interviews, offer executive and PM partnership as the transferable piece | R7, R10 | `[generic]` | pending your approval |

## Evidence status

Verified: none yet. Your intake statements are CV-equivalent, so every row sits at `medium` at most until you confirm specifics or share an artifact. Unverified leads: none. Rejected inferences: none.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | All three searches were refused (search permission was not granted), so the employer's existence, stage and live posting are unchecked. Would have moved role reality's organization row and RR1 |
| 2. Role-family sweep | unavailable | Refused. Would have moved the market calibration for this title and seniority |
| 3. Hiring manager's public footprint | n/a | No name given, so no query can be formed |

## Upgrade menu

- A link to the live posting or the careers-page listing → RR1 closes.
- Search permission granted → targets 1 and 2 run; a salary band and the employer's footprint land in role reality.
- One inspectable artifact (sanitized experiment readout, dashboard screenshot, or the consent-state model's schema) → R2, R3 and R4 move from `medium` to `high`.
- A sanitized memo excerpt → R9 moves to `high`.
- Base salary, location and contract type → RR4 closes, and your constraints can be checked.
- Deeper research on the company (funding, leadership changes, HIPAA program signals; up to 5 more searches and 2 more fetches) once search is granted; say the word and it runs.

I can also save this assessment as a `tuesday-dossier.md` you can keep and reuse.

Q1 (R8): Have you mentored, reviewed or hired junior analysts? Who, over what period, and what did you own: reviews, scoping, hiring, or career development?

Q2 (R5): For the metrics layer, did you own metric definitions (a dictionary or semantic layer), or share them? Who signed off on changes?

Q3 (R10): Did the warehouse hold any health-related fields, such as dietary restrictions or allergies? What access rules applied to identifiable customer data?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.