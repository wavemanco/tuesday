**No. Don't pursue this one.** The posting fails both of your hard constraints, and it says outright that neither one flexes: `no_go`. The on-site rule is stated as "no exceptions," and the base range is $70–85k against your $150k floor. Your fit on paper is strong, but the role is built around the two things you've ruled out.

## Decision snapshot

**No, not worth pursuing: R1 and R2 are both hard gates and both fail. Status: `no_go`.**

**Fit ledger.**

- `hard_gate` — hard_gate_fail: R1 (on-site in Austin), R2 (base pay)
- `must_have` — direct: R3 (growth leadership), R4a (paid and lifecycle); unclear: R4b (SEO, brand, PR, partnerships, sales ops)
- `important` — adjacent: R5 (team of one); unclear: R6 (thrive on ambiguity)

R1 and R2 are the reasons for the status. R4b is scope you haven't claimed. R5 is the solo model against a record of building teams of 3–7.

**Opportunity ledger.** Two red flags are severe: the base is far below your floor (RR4), and the on-site rule is absolute (RR5). The solo mandate, the always-on language and the undefined success metrics add medium risk (RR1–RR3). Employer status is unchecked (RR6). The one positive signal is the company's own profitability claim (RR7).

- **Hard gates:** failed: R1 (on-site in Austin five days a week), R2 (base pay, $70–85k)
- **Severe red flags:** RR4 (`severity: high`), RR5 (`severity: high`)
- **What would change this:** only a written change from the employer to both the Austin requirement and the base range. The posting makes that unlikely, so I'd treat this as closed unless they reply.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Novaline, e-commerce enablement, Series A, "profitable since day one" | `[grounded]` posting; not verified (see RR6) |
| Mandate | All revenue growth end to end: paid, SEO/content, lifecycle/CRM, brand, PR, partnerships, sales ops | `[grounded]` posting |
| Structure | Team of one to start; reports to the CEO, dotted line to the board | `[grounded]` posting |
| Working pattern | On-site in Austin, five days a week, no exceptions; evenings and weekends | `[grounded]` posting |
| Scope read | Seven channels plus sales ops with no team is a bundled, over-scoped role | `[inferred]` from the channel count against the team-of-one statement |
| Market calibration | Not checked. I'm not stating a band from memory. Against your floor, the posted base is $65k–$80k short | `[grounded]` posting against your stated floor |
| Unknowns | Equity terms, success metrics, actual team budget, real headcount | — |
| Contradictions | None within the posting text | `[grounded]` posting |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | On-site in Austin five days a week | hard_gate | hard_gate_fail | high | hard_gate | Posting says "no exceptions." You are remote-only in Portland and not relocating | `[grounded]` posting; your stated constraint | None: no path to resolve |
| R2 | Base of at least $150k | hard_gate | hard_gate_fail | high | hard_gate | Posted base is $70–85k. Equity is offered in addition, not in place of base | `[grounded]` posting; your stated floor | None: no path to resolve |
| R3 | 8+ years growth leadership | must_have | direct | medium | none | Nine years, growth lead then Head of Growth at two companies | Your account; not documented | none |
| R4a | Paid acquisition and lifecycle/CRM ownership | must_have | direct | medium | none | You owned both, plus experimentation, at a subscription company | Your account; not documented | none |
| R4b | SEO/content, brand, PR, partnerships, sales ops | must_have | unclear | low | discovery | Not in your account. You didn't claim these | `[grounded]` absence from your account | Ask (Q3) |
| R5 | Operate as a team of one without a bench | important | adjacent | low | transferability | You scaled $8M→$40M with a budget you controlled and teams of 3–7, but not solo | Your account; `[inferred]` adjacency | none |
| R6 | Thrive on ambiguity; metrics that evolve | important | unclear | low | discovery | No evidence in your account either way | `[grounded]` absence | none |

## Gap recovery queue

No gaps here are worth closing for this role. R4b is the only one that would matter if the role changed. Its question is in the closing block.

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Responsibility without team or budget | risk_signal | medium | "team of one to start — we believe in players who don't need a bench" | You'd own seven channels with no team and no stated budget | `[inferred]` from the channel list against the team-of-one line | Which budget and people come with this role at launch, and when? | unresolved |
| RR2 | Always-on expectation | risk_signal | medium | "evenings and weekends when it matters is just who we are" | Evenings and weekends are the default, not the exception | `[inferred]` from the wording | How often did the team work evenings or weekends last quarter? | unresolved |
| RR3 | Success metrics undefined | risk_signal | medium | "success metrics will evolve as we learn" | You could be accountable for numbers that change after you start | `[inferred]` from the wording | What two or three metrics would I be measured on at six and twelve months, and who sets them? | unresolved |
| RR4 | Base below your floor | red_flag | high | "$70–85k base plus meaningful equity upside" | Equity is offered where base should be; it does not meet your floor | `[grounded]` posting against your floor | Is the base range firm, and what are the equity grant, strike price and vesting terms? | unresolved |
| RR5 | On-site five days, no exceptions | red_flag | high | "On-site in our Austin office 5 days a week — no exceptions" | Remote or hybrid isn't available at any level | `[grounded]` posting | Is there any remote or hybrid option for this role, and does "no exceptions" apply to every candidate? | unresolved |
| RR6 | Employer not verified | unknown | — | "Novaline (e-commerce enablement startup, Series A…)" | The company may be too new to have a footprint, or the posting may be stale | `[generic]` pattern for early-stage companies; not checked at L0 | Can you point me at this role on Novaline's own careers page, and who would I interview with? | unresolved |
| RR7 | Profitability claim | positive_signal | — | "profitable since day one" | The company may be financially stable | `[grounded]` the company's own claim; unverified | What is the current runway and headcount? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Don't apply | R1 and R2 fail, and the posting says neither flexes | `[grounded]` R1, R2 | proposed |
| P2 | If you want a clean close, send one written question to the recruiter: whether the Austin requirement and base range are negotiable | This is the only route that could move the status, though the posting makes it unlikely | `[grounded]` RR4, RR5 | pending your approval |

## Evidence status

Verified: none yet. Every background claim (nine years, $8M→$40M ARR, team sizes, tools) is your own account in this conversation. No document was provided, so these are leads, not verified evidence.

Research tier: L0 — no searches

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | skipped | Not run at L0. The posting's own text settles both gates. A check would confirm the employer exists and the role is live (RR6) |
| 2. Role-family sweep | skipped | Not run at L0. Would have given a market band for this title and stage. No band is stated |
| 3. Hiring manager's public footprint | n/a | No name given |

## Upgrade menu

- A research pass at L1 (up to 5 searches and 2 fetches): confirms Novaline exists and is hiring for this role (RR6), and gives a market band for the base. It won't reverse the `no_go`, because both gates are in the posting itself.
- The live posting link or Novaline's careers page: confirms whether the Austin requirement appears there too.
- Your CV: would ground the R3 and R4a claims if you ever pursue a role like this one.

If you want, I can write this up as a `tuesday-dossier.md` to keep for later comparison.

1. Is the $150k floor firm for every role, or would you consider a lower base with equity in this case? (R2, RR4)
2. Should I run the L1 research pass to verify Novaline exists and check the base band? (RR6)
3. What is your experience with SEO/content, brand, PR, partnerships and sales ops? Your summary covers paid, lifecycle and experimentation only. (R4b)

Answer each, or say "skip."

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.