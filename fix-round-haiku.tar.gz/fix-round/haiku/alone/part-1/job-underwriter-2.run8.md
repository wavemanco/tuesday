**Decision: conditional_go.** Applying isn't a waste of time, but the 3+ years of PM experience is a real gap. Your integration background matches most of the role, and the application only makes sense if you can show ownership of product decisions, even informal ones. Three answers below would settle whether it's worth it.

**Research tier: L0** (provided documents only). I haven't checked that Quartzline exists as described or that the posting is live. That check is in the upgrade menu.

**Decision snapshot**
- **Fit ledger:** One must-have is unmet (PM experience). Technical fluency and stakeholder work are strong. Shipped API/platform work is partial. Agile delivery and adoption metrics are unknown. Roadmap ownership is a gap.
- **Hard gates:** None stated in the JD. Your non-negotiables (location, pay, schedule) weren't provided, so those checks are unknown.
- **Opportunity ledger:** The scope is clear and matches your domain: a partner-facing API platform, discovery with partners, two engineering squads. Compensation and location aren't stated.

**Role reality**
- The role owns the roadmap and metrics for a partner API platform. That is more than the integration lead job you've held, so you'd be moving from delivering to deciding. [inferred]
- A must-have of 3+ years of PM work is common for roles like this. [generic]

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Evidence |
|---|---|---|---|---|---|---|
| R1 | 3+ years PM experience | must | gap | high | transferability | No PM title. Adjacent: requirements documents, roadmap-input sessions. [grounded] |
| R2 | Shipped API or platform products | must | partial | medium | presentation | Led 30+ REST API integrations end to end. [grounded] No evidence you shipped platform features. |
| R3 | Technical fluency (docs, schemas) | must | strong | high | none | OpenAPI, Postman, SQL, integration architecture. [grounded] |
| R4 | Stakeholder management: eng, sales, customers | must | strong / partial | medium-high | discovery | Coordinated vendor engineers, client engineers, PMs. [grounded] Sales work not described. |
| R5 | Agile delivery | must | unknown | low | discovery | Not mentioned. |
| R6 | Discovery with integration partners | responsibility | strong | medium-high | none | Scoping workshops, quarterly client feedback sessions. [grounded] |
| R7 | Specs and driving delivery with two squads | responsibility | partial | medium | presentation | Requirements documents. [grounded] No squad-level delivery described. |
| R8 | Define and track adoption metrics | responsibility | unknown | low | discovery | No metrics on record. SQL is relevant. A triage tool is a memory lead only, not evidence. |
| R9 | Launch coordination with sales and support | responsibility | partial–strong | medium | none | Go-live and UAT work; you wrote the playbook the team uses. [grounded] |
| R10 | Own the roadmap | responsibility | gap | high | transferability | You supplied input to product; you did not own it. [grounded] |

**Gap recovery queue** (what closes each gap, not questions)
- **R1:** Ownership of any decision, however informal. Not closable with the current evidence.
- **R2:** Anything you shaped in the API itself (versioning, deprecations, requested features) and what happened to it.
- **R8:** Numbers from your integrations, such as go-live time or integration counts.
- **R5:** Whether you've worked in sprints or with a backlog.

**Risk register**
- The must-have R1 will likely be the first screen. Address it in your cover note; don't hope it's skipped.
- Compensation isn't stated. Unknown until you see the posting or ask.
- Employer and posting unverified (L0). [grounded]

**Application plan**
1. Pitch the honest version: seven years turning partner needs into product input, now moving to own the roadmap. Don't say you were a product manager, that you owned the roadmap, or that you shipped features unless the answers below confirm it.
2. Lead with R3, R6 and R9, which are your strongest evidence.
3. Answer the three questions below before applying. If all three come back "no," treat this as a stretch. Look at roles with a lower PM bar or PM-adjacent titles (e.g., technical PM for integrations, product operations). [generic]
4. If you build a work sample (e.g., a spec or adoption view drawn from your integration work), I'll draft it for your approval before you send it anywhere.

Dossier offer: I can save this assessment as `tuesday-dossier.md` so a later mock-interview session can pick it up.

**Upgrade menu**
- Company and posting check (L1: up to 5 searches, 2 page fetches). Confirms Quartzline exists as described and the posting is live. Unlocks employer verification and market calibration.
- Link to the live posting. Lets me check whether the 3+ years requirement is worded the same way everywhere.
- Compensation and location. Unlocks the hard-gate check.
- Triage tool details. Would move R8 from memory lead to evidence, if confirmed.

**Questions**
1. (R2, R10) Before the integrations, did you ever make a call on what the API should or shouldn't do, such as a versioning decision, a deprecation, or a feature you pushed that engineering built? What happened?
2. (R8) Did your integrations track any numbers, such as time to go-live, number of integrations, or where clients dropped off? Do you still have them?
3. (R8) Did you build an internal triage tool that support adopted? If so, roughly how many agents used it, and for how long? This comes from an earlier conversation and I haven't confirmed it.

Answer any of these, skip any, or say "skip."

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.