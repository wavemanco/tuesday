## Decision snapshot

**Decision: `conditional_go`.** Apply. Your fit on the core requirements is strong and checkable. Three things stand between you and a clean `go`: the healthcare gap, unstated compensation and location, and an employer that I have not yet verified.

**Fit ledger**

- **Strong, evidenced:** 5+ years of product analytics (6 years); experiment design at scale (30+ A/B tests a year, one with an 11% retention lift); Looker (built the instance, 40+ governed dashboards); written communication with non-technical stakeholders (monthly exec metrics memo, monthly VP Product presentation).
- **Strong, to confirm:** expert SQL (daily SQL on Snowflake, but "expert" is a claim the interview or a work sample will test).
- **Partial:** defining and maintaining a metrics layer (governed dashboards are close; a formal semantic layer is not stated).
- **Not evidenced:** mentoring junior analysts; clinician and care-domain partnership.
- **Gap, not a hard gate:** HIPAA / healthcare data (the JD lists it as a plus).

**Hard gates:** none stated in the JD. Your non-negotiables (pay floor, location, work authorization) were not provided, so every hard-gate check against you is **unknown**.

**Research tier: L0 — no searches.** Nothing about the company, market pay, or the posting has been checked yet. L1 is offered below.

## Role reality

- **Title and scope:** Senior Product Analyst. Owns the metrics layer, A/B testing, Looker self-serve, and stakeholder decisions for a care-navigation app. Also mentors two analysts. Scope reads as a senior IC with a light lead component `[inferred]` from the mentoring line.
- **Organization:** digital-health scale-up, ~400 people, Series C `[grounded]` from the JD. Whether that is accurate is not verified.
- **Compensation:** not stated. The posting withholds it, which is worth asking about. No market band yet `[generic]` would need research.
- **Location, schedule, work authorization:** not stated.
- **Market calibration:** not run. Senior product-analytics roles at this scope are commonly filled by candidates with 5+ years in consumer or fintech analytics `[generic]`. This is a pattern, not a claim about this employer.

## Evidence map

| # | Priority | Requirement | Fit | Confidence | Gap | Evidence |
|---|---|---|---|---|---|---|
| 1 | must-have | 5+ years product analytics | strong | high | none | 6 years at a ~2M-subscriber consumer subscription company `[grounded]` |
| 2 | must-have | Expert SQL | strong | medium | capability-to-verify | Daily SQL on Snowflake `[grounded]`; "expert" not yet demonstrated |
| 3 | must-have | Experiment design at scale | strong | high | none | 30+ A/B tests a year; pricing test with 11% retention lift `[grounded]` |
| 4 | must-have | Looker or similar BI | strong | high | none | Built the Looker instance from scratch; 40+ governed dashboards `[grounded]` |
| 5 | must-have | Written communication with non-technical stakeholders | strong | high | none | Monthly exec metrics memo; monthly VP Product presentation `[grounded]` |
| 6 | must-have | Define and maintain the metrics layer | partial | medium | discovery | Governed dashboards and warehouse consent model `[grounded]`; no stated semantic-layer ownership |
| 7 | must-have | Mentor two junior analysts | unknown | low | discovery | Not in CV; may exist informally |
| 8 | must-have | Partner with clinicians to drive roadmap | partial | low | transferability | Partners with PMs and execs; no clinical stakeholders |
| 9 | plus | Healthcare data / HIPAA | gap | high | transferability | Consumer PII under GDPR/CCPA; consent-state model built `[grounded]`; no PHI or HIPAA experience |

## Gap recovery queue

- **G-9 (HIPAA):** Consumer privacy work (GDPR/CCPA, consent-state model) transfers to the governance side of PHI, but not the regulatory specifics (minimum necessary, BAAs, PHI de-identification). Closes with: a concrete example of a data-access or privacy decision you made, or any HIPAA training or exposure.
- **G-8 (clinician partnership):** Closes with an example where analysis changed a decision with a non-PM audience, or any work with clinical, care-ops, or customer-support stakeholders.
- **G-7 (mentoring):** Closes with a count and description of any analysts or colleagues you have coached or reviewed.
- **G-6 (metrics layer):** Closes with a description of how you defined and governed metrics in Looker or the warehouse.
- **G-2 (SQL):** Closes with a work sample or a complex query you wrote, if you can share one.

## Opportunity ledger and risk register

| Class | Severity | Risk | Note |
|---|---|---|---|
| Failed attribution | high (until checked) | Employer existence and posting not verified | No link, no research. Verify with the live posting or the company careers page. |
| Compensation | medium | Pay withheld | Band and your floor are both unknown. |
| Domain | medium | Clinical and regulatory context (HIPAA, care navigation) | Real stakes for data errors. Ask how they handle PHI in analytics. |
| Stage | low `[inferred]` | Series C scale-up | Stage alone does not indicate runway or churn. |

Positive signal: the JD asks for experimentation at scale and self-serve Looker, which are your two strongest areas.

## Application plan

- **Lead with:** experiment program (30+ tests a year, the 11% lift) and the Looker build, since those map to the two most specific requirements.
- **Frame healthcare honestly:** privacy and consent work is real. Say it as adjacent, not as healthcare experience. Do not describe PII work as HIPAA work.
- **Prepare a SQL work sample** before any technical screen to back up "expert."
- **Resume edits:** none proposed yet. Any wording change for CV or outreach needs your approval before it is used.

## Evidence status

Research tier: L0 — no searches

| Target | Status | Reason |
|---|---|---|
| L1-1 Company site and careers page | skipped | No research run; needs your consent |
| L1-2 Role-family sweep (scope, title, pay) | skipped | No research run; needs your consent |
| L1-3 Hiring manager public footprint | n/a | No hiring manager named |

## Dossier offer

If you want, I can save this assessment as `tuesday-dossier.md` so a later interview-prep session can pick it up.

## Upgrade menu

- **Research at L1 (up to 5 searches, 2 fetches):** confirms the company exists as described, checks the live posting, and gives a market pay band for this seniority. Closes the failed-attribution risk.
- **Live posting link or the recruiter's email domain:** the cheapest way to verify the employer.
- **Work sample or SQL example:** raises the SQL row from medium to high confidence.
- **Your non-negotiables (pay floor, location, work authorization):** completes the hard-gate checks.

## Questions

1. What are your non-negotiables: pay floor, location or remote requirement, and work authorization?
2. Have you mentored or formally reviewed the work of other analysts? If so, how many and for how long?
3. Do you have a link to the live posting? If not, may I run L1 research (company site, careers page, and a pay band check)?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.