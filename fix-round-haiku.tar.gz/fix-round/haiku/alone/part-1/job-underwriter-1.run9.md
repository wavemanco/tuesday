**Yes, apply, once the posting checks out.** `conditional_go`: on the core requirements your evidence reads as a direct fit, but I could not verify that Harborlight Health or this posting exists as described, so that comes first.

**Fit ledger.**

- `must_have`: direct: R1, R2, R3, R4, R5 · adjacent: R6 (metrics layer definition)
- `important`: adjacent: R7 (clinician partnership) · unclear: R8 (mentoring junior analysts)
- `preferred`: adjacent: R9 (healthcare data, HIPAA)

R6 (metrics-layer ownership), R7 (clinician work), R8 (mentoring) and R9 (HIPAA depth) are where the objections will land. R1–R5 are fit on your own statements, which are medium at intake and not yet verified.

**Opportunity ledger.** Unverified rather than bad: the employer is unconfirmed (RR1), the split between mentoring and individual analysis is unstated (RR2), the HIPAA depth is unknown (RR3), and pay is absent from the posting (RR4). One entry runs the other way: the posting names its tooling and scope concretely (RR5).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the posting is confirmed live on Harborlight's own careers site (RR1); (2) the mentoring and individual-contributor split is concrete (RR2); (3) HIPAA is learnable on the job rather than required on day one (RR3).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, a digital-health scale-up, ~400 people, Series C | `[grounded]` your JD text; not verified externally |
| Mandate | Own product analytics for the care-navigation app: metrics layer, A/B tests, self-serve Looker dashboards, PM and clinician partnership | `[grounded]` JD |
| Scope read | Senior individual-contributor mandate with two direct reports' worth of mentoring | `[inferred]` from the mentoring clause against the ownership clauses |
| Market calibration | Not calibrated: the role-family search was refused, so there is no band | — |
| Unknowns | Pay, reporting line, how much PHI the role touches, whether clinicians are day-to-day partners | — |
| Contradictions | None visible in the JD as pasted | `[grounded]` JD text |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | Six years at a subscription company is the claim; intake self-report, not yet probed | `[grounded]` your statement | Confirm in interview framing |
| R2 | Expert SQL | must_have | direct | medium | none | Daily SQL on Snowflake for six years. The claim is daily production use, not a self-rated level of "expert" | `[grounded]` your statement | None |
| R3 | Experiment design at scale | must_have | direct | medium | none | 30+ tests a year, including the pricing test behind an 11% retention lift. The lift needs its design and readout to verify | `[grounded]` your statement | Offer a sanitized readout (see upgrade menu) |
| R4 | Looker or similar BI | must_have | direct | medium | none | Built the company's Looker instance and its 40+ governed dashboards | `[grounded]` your statement | Offer a dashboard screenshot |
| R5 | Written communication to non-technical stakeholders | must_have | direct | medium | none | Writes the monthly exec metrics memo and presents monthly to the VP Product | `[grounded]` your statement | None |
| R6 | Define and maintain the metrics layer | must_have | adjacent | medium | transferability | Governed dashboards and metric definitions carry over. Limit: no evidence you owned a canonical metrics layer across teams | `[inferred]` from R4 | Question G3 |
| R7 | Partner with PMs and clinicians on roadmap decisions | important | adjacent | low | transferability | PM and VP partnership carries over. Clinician partnership is absent from the material | `[inferred]` from R5 | Question G3 |
| R8 | Mentor two junior analysts | important | unclear | low | discovery | Nothing in the material | — | Question G2 |
| R9 | Healthcare data, HIPAA (a plus) | preferred | adjacent | medium | transferability | GDPR/CCPA PII handling and your consent-state model carry over. Limit: no PHI, no HIPAA-covered entity, no BAA | `[inferred]` from your consent-model work | Question G1 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | HIPAA and PHI (R9, preferred) | transferability | Consent and PII work under GDPR/CCPA; no PHI | A preferred row, but the RR3 question turns on it | Access controls on sensitive fields; consent logic that gated which data could be used | A short description of the consent-state model's rules | `[inferred]` bridge from your consent work; `[generic]` that clinical-data roles probe the PHI line |
| G2 | Mentoring (R8, important) | discovery | Nothing in the material | Decides whether RR2's split is a real concern | Onboarding or reviewing a junior analyst's SQL; running a team's experiment review | A review checklist, a onboarding plan | `[grounded]` absence in the material |
| G3 | Metrics layer and clinician partnership (R6, R7) | transferability | Governed dashboards and PM partnership, not canonical metric ownership or clinician work | Both are must-have or important responsibilities the CV does not reach | Writing or arbitrating metric definitions others consumed; joint work with a non-PM stakeholder group | A metric-definition doc, a stakeholder brief | `[inferred]` from R6 and R7 |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not verified (standing) | risk_signal | medium | "Harborlight Health (digital-health scale-up, ~400 people, Series C)" | The employer could not be checked: web search was refused in this run. That is unknown, not a finding of absence | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on Harborlight's own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Mentoring combined with an individual-contributor mandate | unknown | — | "Mentor two junior analysts" | The role may carry people management alongside analysis; the split is unstated | `[inferred]` from the JD's scope | How much time goes to mentoring versus your own analysis, and do the two analysts report to this role? | unresolved |
| RR3 | HIPAA framed as a plus while the app is clinical | unknown | — | "healthcare data experience (HIPAA) a plus" | PHI may be in daily use from the start, so HIPAA knowledge could be needed in practice | `[inferred]` from the care-navigation scope against the "a plus" wording | What PHI does this role query day to day, and what access or HIPAA training is required before the first analysis? | unresolved |
| RR4 | Pay absent from the posting | unknown | — | (no pay stated in the JD as pasted) | The band may sit below your expectation, or the posting may withhold it | `[grounded]` the JD as pasted | What is the budgeted base for this level? | unresolved |
| RR5 | Tooling and scope named concretely | positive_signal | — | "owning product analytics for the care-navigation app" | The mandate is specific and measurable | `[grounded]` JD | Which metrics-layer and experimentation tools does the team use today? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Verify the live posting on Harborlight's careers site and the recruiter's email domain before any application effort | see RR1 | `[grounded]` RR1 | proposed |
| A2 | Lead with the pricing test and the Looker build, each with a sanitized design or readout | Raises R3 and R4 once an artifact exists | `[inferred]` that artifacts raise confidence | pending your approval |
| A3 | Describe HIPAA exposure as "consent and PII handling under GDPR/CCPA; no PHI under HIPAA yet" | Keeps R9 truthful | `[inferred]` from R9 | pending your approval |
| A4 | Prepare a mentoring example only if your answer to G2 supports one | see R8 | `[grounded]` G2 | proposed |

## Evidence status

Verified: none yet. Your statements are intake self-report at medium at most, and nothing is user-confirmed under a probe.

Research tier: L1 — searches 3 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches ("Harborlight Health care navigation digital health company", "Harborlight Health Senior Product Analyst careers") were refused: web search permission was not granted. Would have checked the employer exists as described and the posting is live (RR1) |
| 2. Role-family sweep | unavailable | One search ("senior product analyst digital health salary product analytics experimentation") was refused. Would have calibrated title, seniority and pay as `[generic]` |
| 3. Hiring manager's public footprint | n/a | No hiring manager was named |

Rejected inferences: none.

**Dossier offer:** If you want this saved as a `tuesday-dossier.md` to carry into interview prep, say so and I'll write it.

## Upgrade menu

- Granting web search, or pasting the live posting or careers-page text → RR1 resolves either way, the role-family band for RR4 becomes available, and the company's stage and size get checked.
- A sanitized readout of the pricing test, or a Looker dashboard screenshot → R3 and R4 move toward `high`.
- A named hiring manager → the scope read in role reality and which story to lead with.
- A deeper company pass (funding, leadership changes, public employee reports; up to 5 more searches and 2 more fetches) → say the word and it runs, once web search is granted.

## Questions

G1 — Have you worked with protected health information, under a BAA, or in a HIPAA-covered environment, even read-only? If not, what in your consent-state model had to be right, and would that transfer?

G2 — Have you mentored or managed junior analysts? What did you own, and what did they go on to do?

RR1 — Can you share the link to the live posting on Harborlight's careers site, or the recruiter's email domain?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.