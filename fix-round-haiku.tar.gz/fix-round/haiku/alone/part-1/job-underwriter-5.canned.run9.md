**Yes, worth applying, with three things to confirm first.** Status: `conditional_go`. Your core fit is strong. The open items are two hard gates I can't check without your constraints, and an employer I could only verify through its own site.

## Decision snapshot

**Worth applying — `conditional_go`.** Your background matches the requirements list almost line for line. The posting's scope is broader than the typical title, and the BigQuery gap is real but small.

**Fit ledger.**
- `hard_gate` — unclear: R1 (Remote (US) or Denver office), R2 (Compensation $148,000–$166,000)
- `must_have` — direct: R3 (5+ years data engineering), R4 (Strong SQL and Python), R5 (dbt and a cloud warehouse), R6 (Orchestration with Airflow or similar), R7 (Experience with data quality testing)
- `important` — adjacent: R8 (dbt-modelled warehouse in BigQuery); unclear: R9 (Ingestion from our app and CRM), R10 (Data contracts our analysts depend on)

The must-haves read at `medium` confidence because they rest on your own statement, not an artifact. R8 is `adjacent`: the dbt work carries over, the BigQuery work doesn't yet exist.

**Opportunity ledger.** The pay is in market (RR5). The scope reads broader than a typical senior role (RR1). Equity is unquantified (RR4). No hiring manager is named (RR3). The employer rests on its own site alone (RR2).

- **Hard gates:** none failed; unconfirmed: R1 (Remote (US) or Denver office), R2 (Compensation $148,000–$166,000); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **What would change this:** conditions for go are (1) confirm US work authorization and that remote-US or Denver works (R1); (2) confirm your base floor sits at or below what the posting offers (R2); (3) verify the employer through a source other than its own site (RR2); (4) confirm the team and scope in the first call (RR1). A failed gate in (1) or (2) makes this `no_go`.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 states; founded 2016, Denver; 264 employees; Series C ($52M, February 2026) | `[grounded]` the About text you provided; no independent source found (RR2) |
| Mandate | Build and run ingestion from the app and CRM, a dbt warehouse in BigQuery, and data contracts for analysts | `[grounded]` posting |
| Scope read | Three domains (ingestion, warehouse, contracts) under one role | `[inferred]` from the posting's three-domain list |
| Market calibration | Posting range $148k–$166k against the Datawright 2026 senior band: base median $151k, IQR $139k–$163.5k. The range sits inside the band, with its floor below the median and its ceiling above the IQR top | `[generic]` Datawright 2026 Data Engineering Pay Report (US, n=2,310, Series B–D senior roles); `[grounded]` posting range |
| Seniority | "5+ years" sits inside Datawright's 5–8 year "Senior" norm | `[generic]` Datawright |
| Contradictions | None: the careers page matches the JD you pasted | `[grounded]` careers page fetched |
| Unknowns | Hiring manager, team size, equity terms, contract type | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | No candidate location or authorization given, so the gate can't be checked. Not a failure | `[grounded]` posting | Q1 |
| R2 | Compensation $148,000–$166,000 | hard_gate | unclear | none | hard_gate | No pay floor given. The range sits inside the market band | `[grounded]` posting; `[generic]` band | Q2 |
| R3 | 5+ years data engineering | must_have | direct | medium | none | Six years at one payroll company; self-reported, no artifact yet | `[grounded]` your background | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | Daily use, per your background | `[grounded]` your background | none |
| R5 | dbt and a cloud warehouse | must_have | direct | medium | none | dbt on Snowflake, about 180 models. "A cloud warehouse" is met by Snowflake | `[grounded]` your background | none |
| R6 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow in production, per your background | `[grounded]` your background | none |
| R7 | Experience with data quality testing | must_have | direct | medium | none | You set up the Great Expectations suite. "Set up" is your word, so the ownership depth needs checking | `[grounded]` your background | none |
| R8 | Dbt-modelled warehouse in BigQuery | important | adjacent | medium | transferability | Snowflake warehouse and dbt carry over. BigQuery never used, so this is not production experience | `[grounded]` your statement; `[generic]` that dbt is adapter-based and transfers across warehouses | G2 |
| R9 | Ingestion from our app and CRM | important | unclear | low | discovery | Your background doesn't mention app-database or CRM ingestion | `[grounded]` absence in your background | G1 |
| R10 | Data contracts analysts depend on | important | unclear | low | discovery | Your background doesn't mention contracts with consumers | `[grounded]` absence in your background | G1 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Ingestion and data contracts (R9, R10) | discovery | Your background is silent on app-database or CRM ingestion, and on written contracts with analysts | Both lead the posting's description of the role | Pipelines from a product database or a CRM into a warehouse; schema agreements or SLAs with downstream users | A pipeline README, a contract document, a DAG diagram | `[grounded]` posting names both; `[inferred]` that they lead the role's work by their order |
| G2 | BigQuery (R8) | transferability | Snowflake in production, BigQuery never used | Named in the posting's description | Snowflake-to-BigQuery equivalents: dbt adapter, partitioning and clustering, cost controls | A small BigQuery project with one tested dbt model | `[grounded]` your statement; `[generic]` on what transfers |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Scope spans three domains under one title | risk_signal | medium | "Build and run the pipelines behind our tutoring platform's reporting" | The role may own the whole data stack with no team, which is broader than typical | `[generic]` Datawright: typical scope is one domain, no direct reports; `[inferred]` from the three-domain list | Who else is on the data team today, and which parts of the stack would I own versus inherit? | unresolved |
| RR2 | Employer not established from an independent source | risk_signal | medium | "Pellucid Learning runs live online tutoring for K-12 schools in 31 US states" | Company facts rest only on its own site. The careers page is live and matches the JD, which lowers the risk. Search returned no independent footprint | `[generic]` pattern for companies of this size, not a claim about this one | Can you share the Series C announcement and name the lead investor? | unresolved |
| RR3 | No hiring manager or team size named | unknown | — | (absent from posting) | Common for recruiter-run postings, and not a red flag by itself | `[generic]` | Who would I report to, and how large is the team? | unresolved |
| RR4 | Equity unquantified | unknown | — | "plus equity" | The equity could be material or nominal | `[inferred]` from the posting's silence on grant size | What is the grant size, vesting schedule, and latest strike price? | unresolved |
| RR5 | Pay stated within market | positive_signal | — | "$148,000–$166,000" | Pay is at market and not withheld | `[grounded]` posting; `[generic]` band | Is the top of the range the target or the cap? | noted |

Severe red flags: none found.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Lead the resume with the Snowflake dbt project (about 180 models) and the Great Expectations suite, stated at your actual scope | Direct fit on R3–R7 | `[grounded]` your background | pending your approval |
| P2 | For BigQuery, say "not used in production; dbt and warehouse work carry over." Don't claim BigQuery experience | R8 limit | `[grounded]` your statement; reframing audit applied | pending your approval |
| P3 | Check R1 and R2 yourself first, then ask the recruiter about authorization, location, equity, and contract type | Gates and open unknowns | `[grounded]` posting silence | pending your approval |
| P4 | Optional: build a small BigQuery project with one tested dbt model, to narrow G2 | A work sample narrows a transferability limit | `[generic]` | pending your approval |
| P5 | Ask the recruiter for the Series C source and the hiring team | RR2, RR3 | `[grounded]` RR2, RR3 | pending your approval |

## Evidence status

Verified: none yet. Your background is self-report until it's backed by an artifact.

Research tier: L1 — searches 2 of 5, fetches 1 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Pellucid Learning live online tutoring K-12 Denver", which returned no results. Fetched "Senior Data Engineer — Pellucid Learning careers" (pellucidlearning.com/careers/senior-data-engineer): the live posting matches the JD you pasted. The About page you provided was not fetched. Moved: contradictions row, and RR2 |
| 2. Role-family sweep | yes | Searched "Senior Data Engineer salary median 2026 United States report", which returned "Datawright 2026 Data Engineering Pay Report" (datawright.example/2026-data-engineering-pay-report), from the snippet. Moved: market calibration and RR1 |
| 3. Hiring manager's public footprint | n/a | No name given, so there was no query to form. The upgrade menu names what a name would unlock |

## Upgrade menu

- Your location, US work authorization, and base floor → R1 and R2 close; the decision likely becomes `go` or `no_go`
- The Series C announcement or investor name → RR2 closes
- The team roster, or the recruiter's answer on team size → RR1 and RR3 narrow
- A small BigQuery project or sanitized dbt model → R8 moves toward `direct`
- An inspectable artifact for R3–R7, such as a sanitized dbt repo or a pipeline diagram → those rows move from `medium` to `high`
- A deeper research pass on Pellucid (funding, leadership changes, public employee reports; up to 5 more searches and 2 more fetches) — say the word and it runs

Want me to save this as `tuesday-dossier.md`?

1. What's your work authorization in the US, and would remote-US or the Denver office work for you?
2. What base salary is your floor?
3. Have you built ingestion from a product database or a CRM into a warehouse, or owned data contracts with analysts? (G1)

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.