**Short answer: yes, it's worth applying for, but I'd hold until you've answered three questions.** The main unknowns are your Bristol and pay constraints, and how much of the forecast this role actually owns.

**Decision snapshot**

Status: `hold_pending_answers`. Your background covers most of the posting's core. The forecast and billing requirements are the two places you'd be stretching, and two constraints (location and pay) are unconfirmed.

**Fit ledger**
- `hard_gate`: unclear: R8 (Bristol, two office days a week), R9 (£61,500–£67,000 against your floor)
- `must_have`: direct: R1a, R2, R3; adjacent: R1b (B2B software sector), R4 (owning a forecast); unclear: R5 (finance work on billing or revenue data)
- `important`: direct: R7; absent: R6 (billing data ownership)

R1a, R2 and R3 carry the case for you. R4 and R5 are the case against you, and R6 is the gap you'd have to state honestly.

- **Hard gates:** none failed; unconfirmed: R8 (Bristol, two office days a week), R9 (£61,500–£67,000 against your floor); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Opportunity ledger:** Positive signals RR5 (Series A, 96 staff) and RR6 (pay sits inside the market band) hold up. Open questions are RR2 (forecast authority), RR3 (billing boundary) and RR4 (reporting line). RR1 is a medium-severity verification gap on the posting itself.
- **What would change this:** Answers to Q1 and Q2 below. If Bristol and the pay floor work and the role genuinely owns the forecast, this moves to `conditional_go`. If the forecast is mostly the CFO's, R4 weakens, and the case for applying gets thinner.

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quillfield, Bristol, invoicing and payments software for UK builders' merchants; 96 staff; Series A (£11M) closed April 2025 | `[grounded]` company About page (self-reported) |
| Mandate | Own CRM and billing data; build pipeline and renewal reporting; run the quarterly revenue forecast with the CFO | `[grounded]` posting |
| First-year outcomes | None stated | — |
| Working pattern | Hybrid, two days a week in the Bristol office | `[grounded]` posting |
| Scope read | Broad: spans sales, finance and billing with no stated split of authority | `[inferred]` from the three responsibilities against the silence on sign-off |
| Market calibration | UK revenue operations lead in B2B software: median £64,200, interquartile range £57,800–£70,400 (n=438). The stated range sits inside that band | `[generic]` Ledgerline 2026 pay guide; `[grounded]` posting for the stated range |
| Unknowns | Forecast authority; billing ownership versus finance; reporting line; first-year outcomes | — |
| Contradictions | The posting is on Tallyboard, and a search for Quillfield's careers page returned no match for the role. The hiring manager's public title, Head of Revenue Operations, matches this role's title | `[grounded]` search results |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1a | 4+ years in revenue, sales operations or analytics | must_have | direct | high | none | Five years in sales operations; two running UK revenue operations | `[grounded]` CV | none |
| R1b | B2B software company (not payments) | must_have | adjacent | medium | transferability | B2B payments, with invoicing and payments overlap with Quillfield's product | `[inferred]` from sector names | name the overlap |
| R2 | HubSpot or Salesforce administration | must_have | direct | high | none | Salesforce admin certified; rebuilt pipeline and renewal dashboards | `[grounded]` CV | none |
| R3 | Strong SQL and spreadsheet modelling | must_have | direct | medium | none | SQL weekly, Excel daily; "modelling" is not separately evidenced | `[grounded]` CV | show a model sample if asked |
| R4 | Experience owning a forecast | must_have | adjacent | low | capability | Runs the monthly pipeline review with the sales director; has never owned the company forecast (finance did) | `[grounded]` CV; `[inferred]` bridge | Q2 |
| R5 | Working with finance on billing or revenue data | must_have | unclear | low | discovery | No billing work; finance collaboration not described | — | Q2 |
| R6 | Billing data ownership | important | absent | high | capability | Never worked on billing data | `[grounded]` your statement | state it plainly |
| R7 | Pipeline and renewal reporting | important | direct | high | none | Rebuilt pipeline and renewal dashboards | `[grounded]` CV | none |
| R8 | Bristol hybrid, two office days a week | hard_gate | unclear | low | hard_gate | Your location and willingness not given | — | Q1 |
| R9 | £61,500–£67,000 against your floor | hard_gate | unclear | low | hard_gate | Your floor not given; the stated range sits inside the market band | `[grounded]` posting | Q1 |

**Gap recovery queue**

| # | Gap (req) | Type | What I see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Forecast ownership (R4) | capability | Pipeline review, not the forecast itself | Must-have, and the one you'd most likely be probed on | Any forecast inputs you've built or checked, even without owning the output | A sanitised pipeline or forecast pack | `[inferred]` |
| G2 | Billing data (R5, R6) | discovery | No billing work stated | Must-have, and the posting says you'd own billing data | Any reconciliation or revenue-data work with finance | Finance-side reconciliation examples | `[grounded]` CV silence |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posting not found on Quillfield's own careers site | risk_signal | medium | Search for "Quillfield careers Revenue Operations Lead" returned nothing | The posting may be aggregated or stale | `[generic]` pattern for aggregator-only postings; `[grounded]` search | Can you point me to this role on Quillfield's careers page? | unresolved |
| RR2 | Forecast authority shared with the CFO | unknown | — | "run the quarterly revenue forecast with the CFO" | The role may build the forecast with the CFO signing off, or may only supply inputs | `[inferred]` from "with the CFO" against silence on sign-off | Which parts of the quarterly forecast does this role own alone, and what does the CFO sign off? | unresolved |
| RR3 | Billing boundary with finance | unknown | — | "you will own our CRM and billing data" | Billing ownership may be shared with finance | `[inferred]` from the posting against the silence on finance's role | Who owns billing data quality and reconciliation today, and where does this role's ownership stop? | unresolved |
| RR4 | Reporting line unclear | unknown | — | Hiring manager's public title is Head of Revenue Operations | The role may report to the hiring manager or sit alongside her | `[grounded]` public profile in search result | Does this role report to Tamsin Achebe, and which revenue operations responsibilities does she keep? | unresolved |
| RR5 | Funded, established company | positive_signal | — | "Series A (£11M) closed in April 2025"; 96 employees | Funding gives room to fund the role | `[grounded]` company About page, self-reported | What runway and hiring plan sits behind this role? | noted |
| RR6 | Stated pay sits inside the market band | positive_signal | — | £61,500–£67,000 | The offer sits in the middle of the band | `[generic]` Ledgerline band; `[grounded]` posting | Is this band set for this level, or is there room within it? | noted |

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Check the role on Quillfield's careers page, or ask the recruiter to confirm it, before applying | Resolves RR1 | `[grounded]` RR1 | pending your approval |
| P2 | Describe forecasting as the next step from the monthly pipeline review you run; don't claim you've owned a forecast | Keeps R4 honest | `[grounded]` CV; `[generic]` that interviewers probe this | pending your approval |
| P3 | Name the invoicing and payments overlap as your bridge into B2B software (R1b) | Turns the adjacency into an argument | `[inferred]` | pending your approval |

**Evidence status**

Verified: none yet. Everything above rests on your own account, which is a lead rather than proof until we check it.

Research tier: L1 — searches 4 of 5, fetches 0 of 2; user links read 1

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Quillfield invoicing software company Bristol" (returned quillfield.co.uk/about) and "Quillfield careers Revenue Operations Lead" (no results). The company exists as described; the role isn't on its careers page. Moved RR1 and the employer row in role reality |
| 2. Role-family sweep | yes | Searched "revenue operations lead salary UK B2B software 2026", which returned the Ledgerline 2026 UK Revenue Operations Pay Guide. Moved the market calibration line and RR6 |
| 3. Hiring manager's public footprint | yes | Searched "Tamsin Achebe Quillfield", which returned a public profile listing her as Head of Revenue Operations at Quillfield. Moved RR4 |

**Dossier offer:** I can write this assessment to a `tuesday-dossier.md` you can carry into later sessions, if that's useful.

**Upgrade menu**
- Bristol and pay answers: R8 and R9 close, and the status moves to `conditional_go` or `no_go`.
- A sanitised pipeline or forecast pack you've produced: R4 moves toward `direct`, with confidence up.
- The role description from Quillfield's careers page: RR1, RR2 and RR3 can be checked against the employer's own words.
- Any finance-side billing or reconciliation work: R5 and R6 can be reassessed.

**Questions**

1. (R8, R9) Can you work from Bristol two days a week, and is £61,500 your floor or somewhere you could flex?
2. (R4, R5) Have you had any part in the forecast, or in billing or reconciliation with finance, even informally? What did you do?
3. (RR4) Do you know whether this role reports to Tamsin Achebe, or sits alongside her?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.