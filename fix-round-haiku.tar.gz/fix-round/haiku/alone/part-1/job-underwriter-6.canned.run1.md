**Research tier: L0, no searches; user links read 1.**

**Decision: conditional_go.** Apply, but only after you can answer whether the forecast actually sits with RevOps or with finance. Your pipeline and renewal reporting and your CRM work match the posting well. The forecast and billing-data requirements are where you're thin, and they are two of the role's three named mandates.

**Decision snapshot**
- **Fit ledger:**
  - Met: 4+ years in sales ops (5 years, B2B payments) [grounded]; Salesforce admin (certified) [grounded]; pipeline and renewal reporting (rebuilt dashboards) [grounded].
  - Partial: B2B *software* (you're in payments, which is B2B but adjacent); SQL and spreadsheet *modelling* (you use both daily, but modelling depth isn't shown).
  - Gap: owning a forecast; working with finance on billing or revenue data.
- **Hard gates:**
  - Location: Bristol, hybrid two days a week. Your location and commute aren't in what you gave me, so this is **unknown**.
  - Pay: £61,500–£67,000 plus share options. Your floor isn't stated, so this is **unknown**.

**Evidence map**

| # | Priority | Requirement | Fit | Evidence | Gap | Confidence |
|---|---|---|---|---|---|---|
| 1 | must | 4+ yrs RevOps/sales ops at B2B software co. | Partial | 5 yrs sales ops, B2B payments [grounded] | Software vs payments | High on years, medium on "software" |
| 2 | must | HubSpot or Salesforce admin | Met | Salesforce admin certified [grounded] | None | High |
| 3 | must | Strong SQL and spreadsheet modelling | Partial | SQL weekly, Excel daily [grounded] | Modelling not evidenced | Medium |
| 4 | must | Owned a forecast | Gap | You run the monthly pipeline review; finance owned the forecast [grounded] | Never owned it | Low on any forecast-adjacent reframing |
| 5 | must | Worked with finance on billing/revenue data | Partial | Renewal and revenue-adjacent reporting [grounded] | Never worked on billing data | Medium |
| 6 | responsibility | Own CRM and billing data | Partial | CRM yes | Billing data no | Medium |
| 7 | responsibility | Build pipeline and renewal reporting | Met | Rebuilt both [grounded] | None | High |
| 8 | responsibility | Run quarterly forecast with the CFO | Gap | Same as row 4 | Same as row 4 | Low |

**Opportunity risks**
- **Unverified employer (standing entry).** The only source is an aggregator posting. I haven't checked Quillfield's own careers page, and the hiring manager, Tamsin Achebe, is known only through the recruiter. This keeps the decision at conditional_go. It resolves with Quillfield's careers page or the recruiter's email domain.
- **Scope (inferred).** One role combines RevOps, billing-data ownership, forecasting and CFO partnership. That may be a finance-ops hybrid in practice, which would make it harder than the title suggests.
- **Pay (unverified).** The band is stated, but I haven't calibrated it against the market because research didn't run. Nothing here says whether it's good or bad.

**Application plan (as far as evidence allows)**
- Lead with pipeline and renewal reporting, Salesforce, and SQL, which are verified.
- Don't describe the monthly pipeline review as forecasting. It's pipeline inspection, and the reader will test that claim.
- Only claim forecast or billing work you can name concretely. If you've fed commit or best-case calls, or tracked forecast against actuals, that's the honest bridge. Say what you did, not "forecasting experience."

**Dossier offer:** I can save this assessment as `tuesday-dossier.md` so it carries into interview prep later.

**Upgrade menu** (what each missing input unlocks)
- **Your location and pay floor** → settles the two hard gates in the snapshot.
- **Quillfield's careers page or the recruiter's email domain** → verifies the employer and clears the standing risk.
- **Research at L1** (up to 5 searches, 2 page fetches; say go to run it) → company stage and size, a market check on the pay band, and the hiring manager's public professional background.
- **Your CV** → checks the fit ratings against the document rather than your summary.

**Questions**
1. In practice, who builds the quarterly forecast: RevOps, finance, or the CFO directly? If finance, the forecast gap shrinks to inputs you may already touch.
2. Have you fed forecast inputs, such as commit or best-case calls, or compared forecast against actuals?
3. Did you work with any billing, invoicing or settlement data at the payments company, even indirectly?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.