**Yes, apply, and you are a strong fit on the must-haves.** Your evidence supports the five core requirements. The open items are a healthcare gap, two scope questions the posting leaves blank, and an employer I could not check. `conditional_go`

Research note: web search was refused this session, so I could not check the company or pay market. That leaves the employer unverified (RR1) and the pay band uncalibrated (RR2).

## Decision snapshot

- **Fit ledger.**
  - `must_have`: direct: R1, R2, R3, R4, R5, R7a; adjacent: R6 (metrics layer, governed dashboards rather than a named layer)
  - `important`: absent: R7b (clinician partnership); unclear: R8 (mentoring two junior analysts)
  - `preferred`: absent: R9a (HIPAA / PHI); adjacent: R9b (consumer privacy governance, your GDPR/CCPA consent model)
- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Opportunity ledger.** Scope is concrete, with a metrics layer, self-serve Looker, and two direct reports (RR5, positive). Pay is withheld (RR2), the employer is unverified (RR1), and clinician access is unknown (RR3).
- **Severe red flags:** none found.
- **What would change this:** the live posting verifies the employer (RR1); the pay range is workable (RR2); the clinician and mentoring scope is confirmed (R7b, R8).

## Role reality

- **Role:** Senior Product Analyst, product analytics for the care-navigation app at Harborlight Health (~400 people, Series C, per the JD).
- **Must-have:** 5+ years product analytics, expert SQL, experiment design at scale, Looker or similar BI, written communication with non-technical stakeholders.
- **Preferred:** healthcare data, HIPAA.
- **Implied:** the metrics layer and self-serve Looker are standard-setting work for the function (`[inferred]` from the scope list).
- **Scope read:** the mentoring duty suggests a team already exists (`[inferred]`).
- **Unknowns:** pay, location and remote terms, employment type, clinician access, the regulatory regime for the data, and reporting line.
- **Contradictions:** none visible in the JD.
- **Market calibration:** unavailable. No role-family sweep ran, so I give no pay or scope band and draw on no memory of market figures.

## Evidence map

| # | Priority | Requirement | Fit | Gap | Evidence | Confidence | Provenance |
|---|---|---|---|---|---|---|---|
| R1 | must_have | 5+ yrs product analytics | direct | none | 6 yrs, meal-kit subscription company | medium | `[grounded]` brief, self-report |
| R2 | must_have | Expert SQL | direct | none | Daily SQL on Snowflake | medium | `[grounded]` brief, self-report; "expert" is your call to claim |
| R3 | must_have | Experiment design at scale | direct | none | 30+ A/B tests a year; designed the program; pricing test, 11% retention lift | medium | `[grounded]` brief, self-report |
| R4 | must_have | Looker or similar BI | direct | none | Built the Looker instance from scratch; 40+ governed dashboards | medium | `[grounded]` brief, self-report |
| R5 | must_have | Written comms with non-technical stakeholders | direct | none | Monthly metrics memo read by exec team; monthly VP Product presentation | medium | `[grounded]` brief, self-report |
| R6 | must_have | Define and maintain metrics layer | adjacent | transferability | Governed dashboards imply metric definitions; no explicit semantic layer named | low | `[inferred]` from brief |
| R7a | must_have | Partner with PMs to drive roadmap decisions | direct | none | Monthly VP Product presentations; pricing test informed decisions | medium | `[grounded]` brief, self-report |
| R7b | important | Partner with clinicians | absent | discovery | No evidence in brief | n/a | `[grounded]` brief silence |
| R8 | important | Mentor two junior analysts | unclear | discovery | Not in brief | low | `[grounded]` brief silence |
| R9a | preferred | Healthcare data / HIPAA | absent | discovery | Never worked in healthcare | n/a | `[grounded]` brief |
| R9b | preferred | Regulated personal-data handling | adjacent | transferability | GDPR/CCPA consumer PII; built warehouse consent-state model | low | `[grounded]` brief, self-report |

## Gap recovery queue

- **G1 (R8, discovery):** No mentoring or hiring in the brief. Closing this would confirm or rule out the `important` requirement that the JD's "mentor two junior analysts" names. Useful evidence: examples of onboarding, reviewing, or managing an analyst.
- **G2 (R7b, discovery):** No clinician or non-product partnership in the brief. Closing it would show whether you have worked with non-product stakeholders on a decision. Useful evidence: a decision you shaped with operations, care or clinical staff.
- **G3 (R9a, discovery):** No healthcare or PHI work. This is `preferred` and cannot be closed with experience you lack. The honest path is the bridge in the application plan.

## Opportunity risk register

| ID | Class | Severity | Signal | Provenance | Verification question |
|---|---|---|---|---|---|
| RR1 | risk_signal | medium | Employer unverified; web checks refused | `[generic]` pattern for companies this size | "Can you confirm this posting is live on your careers page, and who the hiring manager is?" |
| RR2 | unknown | low | Pay withheld in the JD | `[inferred]` from the posting's silence | "What is the base salary range for this level?" |
| RR3 | unknown | low | Clinician partnership scope not stated | `[inferred]` from the JD's wording | "How much of this role involves working directly with clinicians, and how is that time split?" |
| RR4 | unknown | low | Authority over metrics definitions and tooling not stated | `[inferred]` from the scope language | "Who signs off on metric definitions, and which tools and budget does this role control?" |
| RR5 | positive_signal | — | Concrete deliverables and two direct reports | `[grounded]` from the JD | "What are the first-year deliverables, and who are the two analysts?" |

## Evidence status

Research tier: L1 — searches 2 of 5, fetches 0 of 2; user links read 0

| Target | Status | Reason |
|---|---|---|
| 1. Company site and careers page | unavailable | Both web-search calls were refused; no page was read |
| 2. Role-family sweep | unavailable | Same refusal; no pay or scope band |
| 3. Hiring manager footprint | n/a | No name given |

## Application plan

- **Lead with** the experimentation program (30+ tests a year, the 11% retention result) and the Looker build (40+ governed dashboards). Put the monthly exec memo under R5.
- **Don't claim** clinician work, mentoring, or healthcare experience until you have them. Describe SQL by what you did rather than as "expert" unless you are comfortable defending that word.
- **Bridge for the healthcare requirement:** consent and PII governance transfers. Its limit is that you have no PHI, HIPAA controls, or clinical data work. A sanitized write-up of the consent model would narrow that limit. Do not list HIPAA training you have not completed.
- **Proposed resume line, `resume_edits_pending_approval`:** "Designed the consent-state model for the company warehouse, governing consumer PII under GDPR and CCPA." It adds no fact beyond your brief. Approve or change it before it is used anywhere.
- **Interview framing:** prepare one metrics-memo example and one experiment readout you can narrate in two minutes. Expect a question on how you would handle PHI.

**Dossier offer:** I can save this as a `tuesday-dossier.md` to carry into interview prep; `mock-interview` is the sibling skill for rehearsing it.

## Upgrade menu

- **Live posting link** → verifies the employer and clears RR1.
- **Pay range, if you have one** → calibrates RR2 against a market band.
- **Approve retrying research** → company and role-family checks within the L1 caps (3 searches and 2 fetches still available).
- **Sanitized experiment readout or dashboard screenshot** → could raise R3 and R4 from medium toward high.
- **Redacted metrics memo excerpt** → could raise R5 from medium toward high.
- **Consent-model write-up, no proprietary data** → strengthens the R9b bridge.
- **Deeper diligence, offered once:** funding, leadership churn, and public candidate reports, up to 5 more searches and 2 more fetches, only if you consent.

## Questions

G1 — Have you hired, trained, or formally mentored junior analysts? If so, how many, what was your role, and what did they produce on their own?

G2 — Have you shaped a decision with people outside product, such as operations, customer care, or clinical staff? What did you own, and what happened?

RR2 — Can you paste the live posting link and any pay range you have been given?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.