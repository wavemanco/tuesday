## Decision snapshot

**Worth applying to, on conditions. Status: `conditional_go`.** On the evidence you've given, your must-have fit is strong: six of seven must-haves are direct. The conditions are right-to-work and location, the pet-insurance gap, and three things the posting doesn't say (salary, decision rights, whether the role manages people). Nothing has been checked against the outside world yet, so the company itself is unverified.

**Fit ledger.**

- `hard_gate`: unclear: R1
- `must_have`: direct: R2, R3, R4, R5, R6, R7 · adjacent: R8
- `important`: adjacent: R10
- `preferred`: direct: R9

**Hard gates.** R1 (UK eligibility and UK base) is unconfirmed on your side. Nothing in your background says either way.

**Opportunity ledger.** Scope is specific: build, monitor, test and recommend are all named (RR5, positive). Authority, people management, salary and the company's standing are unknown (RR1–RR4).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech; pet-insurance product | `[grounded]` JD header |
| Mandate | Own pricing analytics: build and monitor rating models, design and read price tests, recommend to underwriting and product | `[grounded]` JD |
| Reporting line | Hiring manager is Odile Varga, Director of Pricing | `[grounded]` your input |
| Working pattern | Fully remote, UK | `[grounded]` JD |
| Scope read | Individual-contributor ownership is implied. Direct reports are not mentioned in the JD text you gave | `[inferred]` from the JD's verbs and silence on people |
| Market calibration | Not run. No search has been done, so there is no salary band or role-family norm | — |
| Unknowns | Decision rights over rating changes, salary, people management, company stage and funding | — |
| Contradictions | None found between the JD and your background | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | UK work eligibility and UK base | hard_gate | unclear | low | discovery | Fully remote UK is a hard term. Your background implies UK work, but eligibility and base are not stated | `[grounded]` JD; your input silent | Q1 |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | Five years, last two as senior analyst. Stated, not yet inspected | `[grounded]` your input | Confirm with CV |
| R3 | Strong SQL and Python | must_have | direct | medium | none | Daily use. Stated, no artifact yet | `[grounded]` your input | Offer: a sanitized query |
| R4 | GLM experience | must_have | direct | medium | none | Built and maintained the GLM rating model for the young-driver book. Motor only | `[grounded]` your input | Offer: model-validation summary |
| R5 | Build and monitor rating models | must_have | direct | medium | none | "Built and maintained" covers build and monitoring. Stated | `[grounded]` your input | Confirm monitoring cadence |
| R6 | Design and read price tests | must_have | direct | medium | none | Ran 14 tests last year with the underwriting team | `[grounded]` your input | Offer: a test readout |
| R7 | Present to underwriting or actuarial leads | must_have | direct | medium | none | Presents the quarterly pricing review to the head of underwriting. Actuarial leads not stated | `[grounded]` your input | None |
| R8 | Turn results into recommendations for underwriting and product | must_have | adjacent | medium | transferability | Underwriting recommendations are direct, through the quarterly review. Product recommendations are not evidenced | `[grounded]` your input; `[inferred]` on the product side | G2 |
| R9 | Insurance experience | preferred | direct | medium | none | Five years at a UK motor insurer | `[grounded]` your input | None |
| R10 | Pet-insurance product knowledge | important | adjacent | medium | capability | No pet pricing experience. Motor pricing skills transfer, but pet-specific drivers do not | `[grounded]` your input; `[generic]` pet drivers | G1 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pet-insurance knowledge (R10) | capability | Motor pricing only | The JD names the pet product. A reviewer will look for pet-specific pricing judgment | Any work on claims-cost drivers, rating-factor selection or GLM validation that transfers across lines | A one-page note on how you'd adapt a motor GLM for pet risk | `[grounded]` JD, your input |
| G2 | Product recommendations (R8) | transferability | Underwriting recommendations are evidenced. Product is not | The JD says "underwriting and product" | Any test readout or recommendation that went to a product owner | One test summary framed for product | `[grounded]` your input |
| G3 | Location and eligibility (R1) | discovery | Not stated | A hard term. Unresolved, it ends the application | — | Confirmation of right-to-work and base | `[grounded]` JD |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Decision rights unstated | unknown | — | "Own pricing analytics" | The role may recommend, with rating-change approval sitting with pricing leadership or underwriting | `[inferred]` from the verbs "recommendations" and "own analytics" | Who approves a rate change this role recommends? | unresolved |
| RR2 | People management not stated | risk_signal | medium | (JD silent) | The Director may expect the role to lead analysts later. You have not managed anyone, so this matters if it appears | `[inferred]` from the Director title and the silence | Does this role have direct reports now or planned? | unresolved |
| RR3 | Salary not in the JD text | unknown | — | (JD silent) | Compensation may be published separately, or withheld | `[grounded]` JD text you gave | What is the budgeted salary band? | unresolved |
| RR4 | Company not checked | unknown | — | "Brindlemoor (insurtech)" | Stage, funding and product maturity are unknown. A pet product may be early | `[inferred]` no research run | Is the live posting link available? | unresolved |
| RR5 | Specific scope | positive_signal | — | "build and monitor… design and read price tests" | The role is well defined and measurable | `[grounded]` JD | — | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead your CV with the GLM build-and-maintain work and the 14 price tests | Strongest direct evidence against the must-haves | `[grounded]` R4, R6 | pending your approval |
| E2 | Add one line on motor-to-pet transfer, stated as transferable skill, not pet experience | Addresses R10 without overclaiming | `[generic]` R10 | pending your approval |
| E3 | Use the register's questions in the recruiter screen | Covers decision rights, salary and people | `[grounded]` RR1–RR3 | pending your approval |
| E4 | Ask for the live posting link before applying | Checks the JD text against the source | `[grounded]` RR4 | pending your approval |

Nothing here is externally visible yet. The CV and outreach changes wait for your approval.

## Evidence status

Verified: none yet. Your statements are the only source for R2–R7, R9.

Research tier: L0 — no searches; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | skipped | Would check that Brindlemoor exists as described and that the posting is live (RR4) |
| 2. Role-family sweep | skipped | Would set a salary band and the norm for a pet pricing remit (RR3, market calibration) |
| 3. Hiring manager's public footprint | skipped | Would show Odile Varga's public background for positioning (name given) |

I held the search tier for your go-ahead, because research consent is asked with the questions below.

If you want, I can save this as `tuesday-dossier.md` at the end of the engagement.

## Upgrade menu

- Research at L1 (up to 5 searches, 2 fetches): confirms Brindlemoor exists and is hiring, sets a salary band, and gives Odile Varga's public background → R8 and RR3–RR4 move from unknown to grounded.
- A live posting link → checks the JD text against the source.
- A sanitized price-test readout, or a GLM validation summary → R4 and R6 move from medium to high.
- A one-page pet-adaptation note → R10 moves toward direct.

**Questions**

1. (R1) Is your right to work in the UK unrestricted, and are you based in the UK?
2. (RR3) What is your salary floor for this role?
3. (Research) Do you want the L1 check on Brindlemoor and the salary band? You can answer yes, no, or go with the questions in any combination.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.