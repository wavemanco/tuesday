## Decision snapshot

Yes, apply, but as a `conditional_go`. Your must-have evidence is strong on every must-have row. Two things need checking before you invest in the loop: the employer and the UK remote terms.

**Fit ledger.**

- `hard_gate` — unclear: R1 (Fully remote, UK-based)
- `must_have` — direct: R2, R3, R4, R5, R6, R7
- `important` — adjacent: R9 (Pet-insurance product); unclear: R8 (Product-side recommendations)
- `preferred` — direct: R10

R9 (`medium`) is a credible bridge from motor to pet, with its limit named. R1 is `medium` because your location and right to work are inferred from your UK motor history, not stated.

**Opportunity ledger.** The role is sound on its face: the scope is clear and the hiring manager's public work matches the job. The employer could not be found in public search (RR1), no salary is stated (RR2), and the post's decision rights and people scope are unstated (RR3). RR4 runs the other way: the hiring manager has published on monitoring rating models in small books, which is the same problem this JD describes.

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote, UK-based); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) the posting is verified on the company's own careers page (RR1); (2) you confirm UK-based, fully remote eligibility (R1); (3) you describe the pet-insurance bridge as adjacent, not as pet experience (R9).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech; pet-insurance product | `[grounded]` JD header |
| Mandate | Own pricing analytics: build and monitor rating models, design and read price tests, turn results into underwriting and product recommendations | `[grounded]` JD |
| Working pattern | Fully remote, UK | `[grounded]` JD |
| Market calibration | Pricing and actuarial analytics, senior level, UK: median base £58,400, interquartile range £52,100 to £64,900 (n=612, insurers and insurtechs, 2026) | `[generic]` Pricewell 2026 UK pay survey; not this employer's offer |
| Unknowns | Salary; contract basis; direct reports; which pricing decisions sit with this role | — |
| Contradictions | None between the JD and the public trace found. The employer itself did not resolve (RR1) | `[grounded]` search results |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote, UK-based | hard_gate | unclear | medium | hard_gate | Your UK motor employment implies UK location; right to work and remote terms not stated | `[inferred]` from employment history | Confirm (Q2) |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | high | none | Five years in pricing analytics, last two as senior analyst | `[grounded]` your statement | none |
| R3 | Strong SQL and Python | must_have | direct | high | none | Both used daily | `[grounded]` your statement | none |
| R4 | GLM experience | must_have | direct | high | none | Built and maintained the young-driver GLM rating model | `[grounded]` your statement | none |
| R5 | Presenting to underwriting or actuarial leads | must_have | direct | high | none | Quarterly pricing review to the head of underwriting | `[grounded]` your statement | none |
| R6 | Design and read price tests | must_have | direct | high | none | Ran 14 price tests last year with the underwriting team | `[grounded]` your statement | none |
| R7 | Build and monitor rating models | must_have | direct | high | none | Built and maintained one; monitoring implied by the same work | `[grounded]` your statement | none |
| R8 | Turn results into product recommendations | important | unclear | low | discovery | Underwriting-side recommendations are evidenced; product-side not | `[grounded]` CV silence on product | Q1 closes via G2 |
| R9 | Pet-insurance product experience | important | adjacent | medium | transferability | Motor pricing and GLM work carry over; pet claims behaviour and renewal dynamics do not | `[inferred]` bridge from motor work | G1 |
| R10 | Insurance experience | preferred | direct | high | none | Five years in UK motor insurance | `[grounded]` your statement | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pet-insurance product (R9, important) | transferability | Motor work only; no pet claims or pet-product work | This is the most likely objection; a stated limit makes the bridge credible | Frequency and severity modelling, GLM rating for a new book, price tests on a product you did not design | A one-page note mapping motor-to-pet, with the limit stated | `[inferred]` bridge; `[generic]` that pet objections are likely |
| G2 | Product recommendations (R8, important) | discovery | Underwriting recommendations are evidenced; product-side ones are not | The JD names product as a recipient of your recommendations | Price-test results that changed a product feature, cover limit or excess | A product brief, or a test readout sent to product | `[grounded]` CV silence on product |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Brindlemoor (insurtech)" | The company may be new or small, the posting stale, or it may not be a live hiring employer. The hiring manager's name is public, but no company page or posting was found | `[generic]` pattern for small companies, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Salary not stated | unknown | — | (no salary in the JD as pasted) | The budget may sit below the band, or the employer may not publish salaries | `[inferred]` from the paste against the `[generic]` band | What base salary is budgeted for this role? | unresolved |
| RR3 | Direct reports and decision rights unstated | unknown | — | "Own pricing analytics" | The role may include leading people, which you have not done | `[inferred]` from JD silence against your background | Does this role have direct reports, and which pricing decisions does it make on its own? | unresolved |
| RR4 | Hiring manager's public work matches the mandate | positive_signal | — | "monitor rating models" | The hiring manager's published talk and background point to the same monitoring problem | `[grounded]` search snippets (see evidence status) | What does a good first year look like for rating-model monitoring? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Find the posting on the company's own careers page before applying | see RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Ask about salary, contract basis and remote terms in the first call | see RR2, R1 | `[grounded]` RR2 | pending your approval |
| A3 | Write a one-page motor-to-pet bridge note with its limit stated | see R9, G1 | `[inferred]` R9 | pending your approval |
| A4 | Lead with rating-model monitoring when you speak to the hiring manager, since that is their published subject | see RR4 | `[grounded]` RR4 | pending your approval |
| A5 | Do not claim people management; if asked, state the limit plainly | see RR3 | `[grounded]` your statement | pending your approval |

## Evidence status

Verified: none yet. Every CV claim rests on your statement in this conversation, so it is a lead until an artifact backs it.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Brindlemoor insurtech pet insurance": no results. The employer is not established from attributable sources (RR1) |
| 2. Role-family sweep | yes | Searched "Senior Pricing Analyst pet insurance UK salary", which returned the Pricewell 2026 UK Pricing and Actuarial Analytics Pay Survey. Market calibration `[generic]` |
| 3. Hiring manager's public footprint | yes | Searched "Odile Varga Director of Pricing Brindlemoor", which returned a public profile (search snippet, not fetched) and a 2025 Insurance Pricing Forum talk, "Small Books, Loud Errors", on monitoring rating models. Moved RR4 and the positioning in A4 |

## Upgrade menu

- Posting link or careers page → RR1 closes, and the decision can move to `go` if the employer verifies cleanly.
- Budgeted salary, or the recruiter's answer → RR2 closes, and the figure is set against the band above.
- Written confirmation of UK location and remote terms → R1 moves to direct.
- A motor-to-pet bridge note, or a sanitized price-test write-up → R9 moves toward high confidence.
- A product brief or test readout you sent to product → R8 moves from `unclear` toward direct.
- Deeper research on Brindlemoor (funding, leadership changes, reviews; up to 5 more searches and 2 more fetches). Say the word and it runs. Offered once.

If you want this kept for later interview prep, I can save it as `tuesday-dossier.md`.

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip, after each question below.

1. RR1 — Can you point me at the role on your own careers site, and who would I be interviewing with?
2. R1 — Are you based in the UK, eligible to work for a UK employer without sponsorship, and looking for fully remote only?
3. RR3 — Does this role have direct reports, and which pricing decisions does it make on its own?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.