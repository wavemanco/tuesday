**Decision snapshot**

- **Decision: `conditional_go`.** Apply, once two things are checked: the posting is live and the company is real, and the pay and location fit your constraints.
- **Fit ledger** (candidate can credibly do the role):
  - must_have · direct: R1, R2, R3, R4, R5
  - must_have · unclear: R6
  - important · adjacent: R7
  - important · unclear: R8
  - preferred · adjacent: R9
- **Hard gates:** none are named in the posting. Your own constraints (location, pay floor, authorization) are unknown to me, so those checks have not been run.
- **Opportunity ledger** (role is what it claims to be, and acceptable to you): no red flags in the posting. Pay, location and employer verification are unknown. Details are in the risk register.

The two ledgers are scored separately and not averaged.

**Role reality**

| Item | Reading | Provenance |
|---|---|---|
| Title and org | Senior Product Analyst, Harborlight Health, digital-health scale-up, ~400 people, Series C | `[grounded]` JD text only; not verified |
| Scope | Owns product analytics for one care-navigation app: metrics layer, A/B tests, self-serve dashboards, partnering with PMs and clinicians, mentoring two junior analysts | `[grounded]` JD |
| Scope read | Coherent for one senior role: analytics ownership plus people development. The clinician partnership and compliance load are the parts to check | `[inferred]` from the JD's responsibility list |
| Compensation | Not stated. The posting withholds it, which is worth asking about | `[grounded]` JD (absence) |
| Market calibration | Not run. No research tier was used, so I have no role-family band to compare against | n/a |
| Location and arrangement | Not stated | `[grounded]` JD (absence) |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Provenance |
|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | — | `[grounded]` 6 years in background; dates unverified |
| R2 | Expert SQL | must_have | direct | medium | — | `[grounded]` daily SQL on Snowflake; "expert" level is `[inferred]` from daily use |
| R3 | Experiment design at scale | must_have | direct | medium | — | `[grounded]` 30+ tests a year, pricing test with 11% retention lift; `[inferred]` that the lift was relative and held up, unverified |
| R4 | Looker or similar BI | must_have | direct | medium | — | `[grounded]` built the Looker instance, 40+ governed dashboards |
| R5 | Written communication with non-technical stakeholders | must_have | direct | medium | — | `[grounded]` monthly metrics memo read by the exec team; monthly presentation to VP Product |
| R6 | Define and maintain the metrics layer | must_have | unclear | low | discovery | `[grounded]` governed dashboards; `[inferred]` that this is not the same as owning canonical metric definitions |
| R7 | Partner with PMs and clinicians | important | adjacent | low | transferability | `[grounded]` partnering with PMs and execs; no clinician work stated |
| R8 | Mentor two junior analysts | important | unclear | low | discovery | `[grounded]` absence of any mentoring in the background |
| R9 | Healthcare data (HIPAA) | preferred | adjacent | medium | transferability | `[grounded]` GDPR/CCPA consumer PII and consent-state model; no PHI or HIPAA work |

**Gap recovery queue**

| # | Gap (req) | Type | What I currently see | Why it matters | Closure path | Provenance |
|---|---|---|---|---|---|---|
| G1 | Metrics ownership (R6) | discovery | Governed dashboards are stated; whether you owned canonical definitions is not | A must-have. If you owned definitions, R6 becomes direct | Describe one metric definition you set and who signed off on it | `[inferred]` that this moves R6 |
| G2 | Mentoring (R8) | discovery | No mentoring is in the background | Stated as a responsibility; a gap here weakens the senior fit | Any formal or informal mentoring, even partial | `[grounded]` absence |
| G3 | Healthcare (R9) | transferability | Consent-state and PII work carries over conceptually. Limit: no PHI, no HIPAA controls, no clinical data | Preferred, not required. Present it as adjacent with the limit stated | No question needed; state the limit in any application | `[generic]` that HIPAA work is a separate skill set |

**Opportunity risk register**

| Class | Item | Severity | Provenance |
|---|---|---|---|
| unknown | Compensation not stated | medium | `[grounded]` JD absence |
| unknown | Location and remote policy not stated | medium | `[grounded]` JD absence |
| unknown | Employer existence and live posting not verified (no research run) | high | `[grounded]` JD only |
| unknown | How experiments are governed in a clinical product (patient-facing change limits, clinical outcome metrics, review requirements) | medium | `[inferred]` from the domain |
| risk_signal | Broad scope: analytics ownership, people development, clinician partnership and compliance in one senior title | low | `[inferred]` from the JD |
| positive_signal | Mentoring responsibility implies a team, and the scope is specific | low | `[grounded]` JD |

No red flags were found in the posting text.

**Application plan**

| Step | Move | Provenance |
|---|---|---|
| 1 | Verify the live posting and the company before investing time. Use the posting link or the careers page. | `[generic]` standard check |
| 2 | Confirm pay range and location against your constraints. | `[grounded]` JD absence |
| 3 | Lead with R3 and R4: the experimentation program and the Looker build. Have a shareable writeup or dashboard screenshot ready, if confidentiality allows. | `[grounded]` background |
| 4 | Describe healthcare as adjacent: consumer PII under GDPR/CCPA and the consent-state model. State plainly that you have no HIPAA or PHI experience. | `[grounded]` background |
| 5 | Before interviewing, check the 11% lift: relative or absolute, the significance, and whether it held after rollout. | `[inferred]` interviewers will probe it |
| 6 | Do not describe SQL as "expert" unless you are comfortable with that word. Describe the daily use. | `[inferred]` reframing audit |

No resume edits are proposed. Any CV language would be `resume_edits_pending_approval` and needs your explicit approval before use.

**Evidence status**

Research tier: L0 — no searches

| Target | Status | Reason |
|---|---|---|
| L1-1: company site and careers page | skipped | L0 chosen; no search run |
| L1-2: role-family sweep (scope, title, pay) | skipped | L0 chosen; no search run |
| L1-3: hiring manager's public footprint | n/a | No hiring manager name was given |

User links read: none.

I can save this as a `tuesday-dossier.md` file that mock-interview can pick up later.

**Upgrade menu**

- A link to the live posting or the company's careers page: confirms the employer and posting (unlocks the first check above).
- Pay range and location: runs the hard-gate checks.
- Light research (up to 5 searches and 2 page fetches): checks the company's stage and size, and gives a role-family pay band.
- Deeper research (up to 5 more searches and 2 more fetches): funding, leadership changes, and public employee and candidate reports.
- The 11% test writeup or a dashboard screenshot (anonymized if needed): raises the confidence on R3 and R4 from medium toward high.

**Questions**

G1 — Did you own the canonical definitions for the company's core metrics, or did you build dashboards on definitions someone else set? If you owned them, what was one you set and who signed off?

G2 — Have you mentored or managed junior analysts, formally or informally? Describe one example, even a partial one.

S1 — What compensation floor and location or remote arrangement do you need? The posting doesn't state either.

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.