**Yes, apply, conditionally: `conditional_go`.** On the core analytics requirements you map directly to the posting. Healthcare data is a plus in the posting, not a gate, and your consent-state work is the bridge to it. The conditions are that the employer checks out, the pay range is confirmed, and you don't present consumer-PII work as HIPAA experience.

**Fit ledger.**

- `hard_gate` — none in the posting.
- `must_have` — direct: R1, R2, R3, R4, R6
- `important` — direct: R5 · adjacent: R7 (Partner with PMs and clinicians) · unclear: R8 (Mentor two junior analysts)
- `preferred` — adjacent: R9 (Healthcare data, HIPAA)

Fit reads from your background as you described it, which is self-report, so confidence stays at `medium` at most. R7's clinician side and R8 are the open rows.

**Opportunity ledger.** The mandate is specific and owned (RR5, positive); pay is withheld (RR4, unknown); the scope bundles IC analysis, mentoring and clinician partnership (RR1, unknown); HIPAA handling on health data is a plus that you would learn on the job (RR3, risk signal); and the employer is not verified in this run (RR2, risk signal).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) RR2 clears: the live posting and the company's own careers page confirm the role; (2) RR4 clears: a base range is confirmed; (3) R9 is presented as a learning gap, with consent-state and consumer-PII work as the bridge, never as HIPAA experience.

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, digital-health scale-up, ~400 people, Series C | `[grounded]` JD header; not verified this run |
| Mandate | Own product analytics for the care-navigation app: metrics layer, A/B tests, self-serve Looker, PM and clinician partnership, two junior analysts | `[grounded]` JD |
| Scope read | Analyst IC, plus informal people management and a clinical stakeholder role; broader than a single analytics lead | `[inferred]` from the JD's responsibility list |
| Market calibration | Not run; no role-family band this run | — |
| Unknowns | Pay; whether mentoring is a formal line-management role; who owns metric definitions today; PHI scope of the warehouse | — |
| Contradictions | None found within the JD | `[grounded]` JD |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | Six years at one consumer-subscription company, as you described it; self-report, no artifact | `[grounded]` your background | none |
| R2 | Expert SQL | must_have | direct | medium | none | Daily SQL on Snowflake; no query sample yet | `[grounded]` your background | upgrade menu |
| R3 | Experiment design at scale | must_have | direct | medium | none | 30+ tests a year, incl. the pricing test with an 11% retention lift; specific, but no readout in hand | `[grounded]` your background | upgrade menu |
| R4 | Looker or similar BI | must_have | direct | medium | none | Built the Looker instance from scratch; 40+ governed dashboards | `[grounded]` your background | upgrade menu |
| R5 | Define and maintain the metrics layer | important | adjacent | low | discovery | Governed dashboards and the monthly metrics memo are nearest, but you have not said you owned metric definitions | `[inferred]` from the dashboard and memo work | Q3 |
| R6 | Strong written communication with non-technical stakeholders | must_have | direct | medium | none | Monthly metrics memo read by the exec team; monthly presentations to the VP Product | `[grounded]` your background | none |
| R7 | Partner with PMs and clinicians on roadmap decisions | important | adjacent | low | transferability | VP Product presentations are a partnership signal; no clinician work in your background | `[inferred]` from the presentation cadence | Q2 |
| R8 | Mentor two junior analysts | important | unclear | none | discovery | Not in your background as stated | `[grounded]` absence in your background | Q1 |
| R9 | Healthcare data experience (HIPAA) | preferred | adjacent | medium | transferability | GDPR/CCPA consumer PII and a consent-state model transfer; HIPAA is a separate regime you have not worked under | `[grounded]` your background; `[generic]` that HIPAA is a distinct regime from GDPR/CCPA | Q2 |

**Gap recovery queue**

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Clinician partnership (R7) | transferability | PM-facing presentation work; no clinical stakeholders named | Clinicians are named in the mandate; their absence is the likeliest objection | Working with ops or support teams on care or service decisions; any stakeholder group with a regulatory or safety stake | A stakeholder map or a sanitized memo addressed to a non-analyst audience | `[inferred]` bridge from the presentation cadence; `[generic]` that clinicians are the likeliest objection |
| G2 | Mentoring (R8) | discovery | No people-management or mentoring in your background | Two named junior analysts are part of the role | Onboarding, code review, or growth plans for analysts or new hires | Nothing specific needed; the answer itself decides it | `[grounded]` absence |
| G3 | Metric definitions (R5) | discovery | Governed dashboards and a memo; ownership of definitions unstated | The metrics layer is a core responsibility | Definitions you wrote, changes you approved, disputes you settled | A metrics dictionary entry or a change log | `[inferred]` from the dashboard work |
| G4 | Regulated-data bridge (R9) | transferability | Consent-state model and consumer PII handling | Bridges the one preferred gap; HIPAA handling is not established | Access controls, data minimization, audit of who saw what | Consent model spec or access policy summary | `[grounded]` your background; `[generic]` on HIPAA scope |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Scope bundles IC analysis, mentoring and clinician partnership | unknown | — | "Own product analytics… mentor two junior analysts" | The role may be a lead-analyst-plus-people-manager role under an analytics title | `[inferred]` from the responsibility list | Is this role line-managing the two analysts, or mentoring them alongside analysis work? | unresolved |
| RR2 | Employer not verified this run | risk_signal | medium | "Harborlight Health (digital-health scale-up, ~400 people, Series C)" | Web verification was declined, so the employer and the posting are unconfirmed | `[generic]` pattern for companies of this size, not a claim about this one | Can you send the live posting link and the hiring manager's name for the first call? | unresolved |
| RR3 | HIPAA handled as a plus on health data | risk_signal | low | "healthcare data experience (HIPAA) a plus" | You may be onboarded into a PHI regime with no prior exposure | `[inferred]` from the JD's wording against the product's care-navigation scope | How much of the analytics warehouse holds PHI, and what access controls and training apply to analysts? | unresolved |
| RR4 | Pay withheld | unknown | — | not stated in the JD | Pay could sit below your expectation, or the employer may simply not publish ranges | `[grounded]` the JD omits pay | What is the budgeted base range for this role? | unresolved |
| RR5 | Mandate is specific and owned | positive_signal | — | "Own product analytics for our care-navigation app" | Clear ownership and defined tools make the role easier to scope | `[grounded]` JD | Who owns the metrics layer today? | noted |

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead the resume with the Looker build and the experimentation program, and cite the exec memo as a stakeholder-communication bullet | Matches R3, R4, R6 without inventing new claims | `[grounded]` your background | pending your approval |
| E2 | Describe consent-state and consumer-PII work as the bridge to R9; do not describe it as HIPAA experience | Keeps R9 at `adjacent` and avoids overstating | `[grounded]` your background | pending your approval |
| W1 | Offer a sanitized readout or one-page summary of the 11% pricing test, if your employer permits | Would raise R3 to `high` | `[grounded]` R3 row | pending your approval |
| A1 | Confirm the employer and pay range with the recruiter before investing in the loop | Closes RR2 and RR4 | `[grounded]` register | pending your approval |

**Evidence status**

Verified: none yet. Your background is intake prose, so it stands as a lead until you answer a specific probe.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Three search calls were declined by permission, so no result came back. RR2 stays open |
| 2. Role-family sweep | unavailable | Shared with the refused calls above. No salary or scope band, so RR4 and the market calibration line are unfilled |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

**Upgrade menu**

- The live posting link or the recruiter's email domain → RR2 can close, and the employer check can run.
- The posted base range, or the range the recruiter gave you → RR4 closes, and a band can be set against it.
- If you allow web search in this session, the L1 targets run: employer verification and a role-family salary band.
- A scrubbed SQL sample or dashboard screenshot → R2 and R4 move toward `high`.
- A non-confidential readout of the pricing test, or one memo extract → R3 moves toward `high`.
- A stakeholder map or a memo for a non-analyst audience → G1 and R7 can firm up.
- A deeper research pass on Harborlight Health (leadership changes, funding, public reviews; up to 5 more searches and 2 more fetches): say the word and it runs.

I can write this up as a `tuesday-dossier.md` you can keep and bring to later sessions, if that would help.

1. **R8 (mentoring):** Have you managed or formally mentored analysts? If so, how many, and did you own hiring, reviews or growth plans?
2. **R7 and R9 (partners and regulated data):** Who did you work with beyond product managers, such as clinical, ops, legal or compliance, and did any of that work involve health or PHI data?
3. **R5 (metric definitions):** Did you own the metric definitions in the metrics layer, or consume them? Who signed off changes?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.