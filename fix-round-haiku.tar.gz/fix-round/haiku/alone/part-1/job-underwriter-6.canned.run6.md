## Decision: conditional go

Apply, but treat it as a stretch on two requirements and verify the employer before investing time. Your core profile matches most of the posting. The gaps are forecast ownership and billing data, and both are ones the posting lists as requirements.

**Decision snapshot**
- **Fit:** Strong on the CRM, SQL and pipeline/renewal requirements. Gaps on forecast ownership and finance-facing billing work.
- **Hard gates:** Location (Bristol, hybrid 2 days/week) and pay floor are unknown for you. Neither is a failure yet, but you need to answer both before this becomes a real option.
- **Opportunity:** Employer existence not verified. Scope is broad for one role.

## Role reality

- **Role:** Revenue Operations Lead at Quillfield, Bristol, hybrid two days a week. Salary £61,500–£67,000 plus share options [grounded].
- **Stated scope:** Own the CRM and billing data, build pipeline and renewal reporting for sales and finance, and run the quarterly revenue forecast with the CFO [grounded].
- **Scope read:** Combining CRM ownership, billing-data ownership and forecast ownership in one "Lead" role is broad. The posting doesn't say whether there's a team behind it [inferred].
- **Market calibration:** Not run. Research was not consented to, so I can't say whether the salary band or scope is typical for this seniority [generic].
- **Unverified employer:** I haven't confirmed Quillfield exists as described. The posting is on a job board, so I'd check the company's own careers page or the recruiter's email domain.

## Evidence map

| Requirement | Fit | Basis |
|---|---|---|
| 4+ years RevOps / sales ops / analytics at B2B software | Likely met | 5 years sales ops at a B2B payments company. "Payments" vs "software" is a framing point to be ready for [inferred] |
| HubSpot or Salesforce admin | Met | Salesforce certified admin |
| Strong SQL and spreadsheet modelling | Met for SQL and Excel; modelling partly evidenced | SQL weekly, Excel daily. Forecast-style modelling isn't stated |
| Experience owning a forecast | Gap | Finance owned the company forecast. You run the monthly pipeline review, which is adjacent |
| Experience working with finance on billing or revenue data | Gap | No billing data. Revenue-side work (pipeline, renewals) is adjacent |

Your background is self-described; I haven't seen a CV, so every fit call here is capped at the confidence a self-report supports.

## Risks and red flags

- **Forecast ownership.** This is a stated must-have and the biggest gap. Ownership is hard to claim without owning the number, so the honest version is "I shaped the inputs and challenged the output," if that's true.
- **Billing data.** Ramp-up is real if the role owns billing data from day one [inferred].
- **Employer verification.** Unresolved (see above).
- **Pay and location.** Your floor and your ability to attend Bristol are unknown.

## Gap recovery queue

- **Forecast ownership:** Closes if you contributed inputs or reconciled forecast against actuals, even informally.
- **Billing data:** Closes if your payments company's data touched invoicing, settlement, failed payments or revenue recognition, even at the edges.

## Application plan

Lead with the Salesforce, SQL and pipeline/renewal evidence. Position the forecast and billing gaps honestly as adjacent, not as experience you don't have. I'd hold off on any CV wording about "owning" a forecast or billing data unless you can back it with specifics. Nothing here is ready to send until you approve the wording.

**Research tier: L0 — no searches; user links read 1.** Nothing about Quillfield or the market has been checked beyond the posting.

If you want the full underwriting kept for later, I can save it as a dossier file for interview prep. Adding your CV would firm up the fit calls, and running company research would verify the employer and calibrate the salary.

1. Did you contribute to the sales-to-finance forecast at your payments company, such as supplying pipeline-weighted inputs, reconciling forecast to actuals, or challenging the number? (Closes the forecast gap.)
2. Did any of your work touch billing, invoicing, settlement, failed payments or revenue recognition, even at the edges? (Closes the billing gap.)
3. Can you work in Bristol two days a week, and what is your base-salary floor? (Hard-gate check.)

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.