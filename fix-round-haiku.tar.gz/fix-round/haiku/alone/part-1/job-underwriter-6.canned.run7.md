**Yes, probably: apply, once the posting is confirmed on Quillfield's own careers site.** Status: `conditional_go`.

**Fit ledger** (the candidate-side read; separate from the opportunity read below)

- `hard_gate`: unclear: R1 (Bristol hybrid, two days a week in the office), R2 (£61,500–£67,000 pay)
- `must_have`: direct: R3, R4, R5 · adjacent: R6 (owning a forecast) · unclear: R7 (finance work on billing or revenue data)
- `important`: direct: R8

The must-haves below `direct` are R6 and R7. Your other stated must-haves, R3 to R5, are direct on the evidence you gave me.

- **Hard gates:** none failed; unconfirmed: R1 (Bristol hybrid, two days a week in the office), R2 (£61,500–£67,000 pay); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.

**Opportunity ledger.** The employer exists and states its pay (RR5, RR4, both positive). The posting is not confirmed on Quillfield's own careers site (RR1), forecast sign-off is unstated (RR2), and one lead title carries four responsibility areas (RR3).

- **Conditions for go:** (1) RR1 clears: the listing is live on Quillfield's careers site, or the recruiter confirms it. (2) RR2 clears: the forecast sign-off is named, and you are not the sole owner of the numbers. (3) R6 and R7 are presented as adjacent and as a gap, never as owned forecasting or billing work.
- **What would change this:** a "no" on RR1 (no live listing) moves this toward `hold_pending_answers`. Answers to Q1 and Q2 below move R6 and R7 in either direction.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quillfield: invoicing and payments software for UK builders' merchants, Bristol, 96 employees, Series A (£11M) closed April 2025 | `[grounded]` company About page, via search |
| Mandate | Own CRM and billing data; build pipeline and renewal reporting; run the quarterly revenue forecast with the CFO | `[grounded]` JD |
| Hiring manager | Tamsin Achebe, Head of Revenue Operations (public profile snippet; previously four years in sales operations at Corvane Payments) | `[grounded]` profile snippet |
| Scope read | One title spanning CRM admin, billing data, reporting and forecasting | `[inferred]` from the JD's responsibility list |
| Market calibration | UK B2B-software RevOps lead: median base £64,200, interquartile range £57,800–£70,400 (n=438). The posted range sits inside it, nearer the middle. This is one 2026 pay guide, not Quillfield's offer | `[generic]` Ledgerline 2026 pay guide, searched this session; `[grounded]` JD for the posted range |
| Unknowns | Forecast sign-off; team behind the role; reporting line; whether the share options are final | — |
| Contradictions | None in the JD. Sector difference only: the JD says "B2B software", Quillfield describes itself as invoicing and payments software | `[grounded]` JD and About page |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Bristol hybrid, two days a week in the office | hard_gate | unclear | none | hard_gate | Your location and attendance limits were not given | `[grounded]` JD | Q3 |
| R2 | Pay £61,500–£67,000 plus share options | hard_gate | unclear | none | hard_gate | Your pay floor was not given | `[grounded]` JD | Q3 |
| R3 | 4+ years in RevOps, sales ops or analytics at a B2B software company | must_have | direct | medium | none | Five years in sales operations, two running RevOps. The sector is B2B payments, not software; Quillfield's own description is payments-adjacent, which narrows the gap | `[grounded]` your statement; About page | none |
| R4 | HubSpot or Salesforce administration | must_have | direct | medium | none | Salesforce admin certified (your statement, not yet inspected) | `[grounded]` your statement | Attach the certificate (upgrade menu) |
| R5 | Strong SQL and spreadsheet modelling | must_have | direct | medium | none | SQL weekly, Excel daily. "Modelling" beyond daily use is not evidenced | `[grounded]` your statement | none |
| R6 | Experience owning a forecast | must_have | adjacent | medium | transferability | You run the monthly pipeline review with the sales director, but finance owned the company forecast. Adjacent, with the limit named | `[grounded]` your statement; `[inferred]` adjacency | Q2 |
| R7 | Experience working with finance on billing or revenue data | must_have | unclear | low | discovery | No billing data (your statement). Pipeline and renewal dashboards touch revenue, but no finance collaboration is stated | `[grounded]` your statement | Q1 |
| R8 | Build pipeline and renewal reporting | important | direct | medium | none | You rebuilt the pipeline and renewal dashboards | `[grounded]` your statement | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Owning a forecast (R6, must_have) | transferability | Pipeline review and pipeline dashboards; no forecast ownership | The JD's first forecast duty is the role's core; this is the adjacency the interviewer will test | Any call you made on commit or best-case deals; any comparison of your calls against actual outcomes | Pipeline review notes, a forecast-vs-actual sheet | `[inferred]` adjacency; `[generic]` that forecast ownership is probed hardest |
| G2 | Finance on billing or revenue data (R7, must_have) | discovery | No billing data; no stated finance work | The JD requires finance work by name | Renewal bookings, revenue reconciliations, any figure you took to finance | A renewal report or reconciliation you ran | `[grounded]` your statement |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posting not found on Quillfield's careers site | risk_signal | medium | (search: "Quillfield careers Revenue Operations Lead", no results) | The listing may be stale, aggregated, or already filled | `[generic]` pattern for job-board postings, not a claim about this employer | Is this role live on Quillfield's own careers page, and who would I be interviewing with? | unresolved |
| RR2 | Forecast sign-off unstated | unknown | — | "run the quarterly revenue forecast with the CFO" | The lead may build and present the forecast while the CFO holds the numbers | `[inferred]` from "with the CFO" against silence on sign-off | Who signs off the quarterly revenue forecast, and does this role own the model, the numbers, or both? | unresolved |
| RR3 | Bundled scope | risk_signal | medium | "own our CRM and billing data, build the pipeline and renewal reporting ... and run the quarterly revenue forecast" | One title may cover more than one role, with thin support | `[inferred]` from the JD's list; `[generic]` that bundled RevOps titles are often under-resourced | Which of these responsibilities has dedicated staff, and what team sits behind this role? | unresolved |
| RR4 | Pay stated and in band | positive_signal | — | "£61,500–£67,000 plus share options" | Transparent pay within the sector band | `[grounded]` JD; `[generic]` band from the Ledgerline 2026 guide | Is this range final, and how are the share options structured? | noted |
| RR5 | Employer exists as described | positive_signal | — | About page: invoicing and payments software, Bristol, 96 employees | Real, funded company in the sector the JD describes | `[grounded]` About page, via search | — | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Ask the recruiter for the live listing link on Quillfield's careers site, and whether forecast sign-off sits with you | RR1, RR2 | `[grounded]` register | proposed |
| A2 | Attach the Salesforce certificate and an anonymised pipeline or renewal dashboard | R4, R8 | `[grounded]` your statements | pending your approval |
| A3 | Position on pipeline and renewal reporting and the payments sales-ops background. Describe the monthly pipeline review as forecast input, not forecast ownership | R3, R6 | `[grounded]` rows; no added claim | pending your approval |

## Evidence status

Verified: none yet. Your background is intake prose (medium at most, since nothing is inspected yet).

Research tier: L1 — searches 4 of 5, fetches 0 of 2; user links read 1

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Quillfield invoicing software company Bristol" (quillfield.co.uk/about, "About Quillfield") and "Quillfield careers Revenue Operations Lead" (no results). Moved: employer existence confirmed (RR5); the posting is not found on the careers site (RR1) |
| 2. Role-family sweep | yes | Searched "revenue operations lead salary UK B2B software £60,000", which returned "Ledgerline 2026 UK Revenue Operations Pay Guide" (ledgerline.example/2026-uk-revenue-operations-pay-guide). Moved: market calibration `[generic]` and RR4 |
| 3. Hiring manager's public footprint | yes | Searched "Tamsin Achebe Quillfield", which returned a profile snippet (linkedin.example/in/tamsin-achebe). Moved: the positioning in A3. The name match rests on that snippet's Quillfield link and was not checked further |

## Upgrade menu

- A Salesforce certificate, or an anonymised pipeline or renewal dashboard → R4 and R8 to `high`.
- Pipeline-call history against actual outcomes, from the monthly review → R6 could move from adjacent toward direct.
- Any renewal or revenue work you took to finance, even without billing data → R7 resolves.
- The recruiter's answers on the listing and forecast sign-off → RR1 and RR2 close.
- Your Bristol attendance limit and pay floor → R1 and R2 close.
- Deeper research on Quillfield (funding history, leadership changes, hiring patterns; up to 5 more searches and 2 more fetches). Say the word and it runs. I'm offering it once.

If you want this kept for later, I can write it to a `tuesday-dossier.md` file.

1. Q1 (R7): Have you ever worked with finance on any revenue figure, such as renewal bookings, ARR or a reconciliation, even without billing data? What did you own?
2. Q2 (R6): In the monthly pipeline review, did you make the call on deals (commit or best case), or present other people's? Did anyone track your calls against what actually closed?
3. Q3 (R1, R2): Can you work in Bristol two days a week, and what is your salary floor?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.