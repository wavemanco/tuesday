This is the kind of decision the job-underwriter skill covers, so I'll run it.
**Decision: no_go on this posting as written.** Your gut is right. Two hard gates fail outright, and neither can be fixed by wording or by a strong fit elsewhere.

**Research tier: L0, no searches.** The decision rests on the posting's own terms, so it doesn't need outside research.

**Hard gates (both failed)**

| Gate | Your constraint | Posting | Read |
|---|---|---|---|
| Base pay | At least $150k | $70–85k base [grounded] | About 47–53% below your floor. The posting's range is the whole offer. |
| Location | Remote-only, Portland | On-site Austin, 5 days/week, "no exceptions" [grounded] | Explicit refusal of remote. |

On the pay gap, I'd call the $70–85k band low for a Head-of-level growth role at a funded company, and that is a pattern, not a verified market figure [generic]. The posting also says "meaningful equity" without a number, so it doesn't offset the base gap.

**Red flags in the posting itself**

- **Title, scope, and pay don't match.** Head of Growth, owning seven disciplines plus sales ops, with 8+ years required, at $70–85k [grounded]. You'd be paid well below the level the role asks for.
- **"Team of one… we believe in players who don't need a bench"** [grounded]. You've built and managed teams of 3–7, so this is a step down in the work you're hired to do, not a step up.
- **"Evenings and weekends when it matters is just who we are"** [grounded]. That's a culture signal of routine overwork, stated as a norm.
- **"Must thrive on ambiguity; success metrics will evolve"** [grounded]. Combined with the above, this reads as undefined scope and no fixed targets, which makes you accountable for results without a clear mandate.
- **Dotted line to the board** [grounded]. Unusual at this stage, and it adds reporting ambiguity.
- **"Profitable since day one" at Series A** [grounded, unverified]. It's possible, but it's a claim you'd want to check before relying on it.

**Fit (separate from the decision)**

Your experience fits the stated requirement: 9 years, 8+ required [inferred from your background]. The $8M→$40M ARR scale-up with a budget you controlled, your SQL/GA4/Braze depth, and your team-building all map well to the role's channels. Fit is strong on paper. The hard gates still decide it.

**What would change this:** only a verified change to both pay and location, stated in writing. "No exceptions" on location makes that unlikely. Pursuing it would cost time for a low chance of a yes.

**Recommendation:** Don't apply. If you want, I can help you set search filters for remote Head-of-Growth roles with a stated base at or above $150k and a defined team.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.