**Yes, apply, but only after you've confirmed Brindlemoor is a real employer with a live posting. Status: `conditional_go`.** On the core requirements your experience matches the JD closely. The open items are the employer itself, the withheld salary, and your lack of pet-insurance knowledge.

**Fit ledger.**

- `hard_gate` — unclear: R1 (fully remote UK)
- `must_have` — direct: R2, R3, R4, R5, R6, R7
- `important` — adjacent: R9 (pet-insurance product knowledge)
- `preferred` — direct: R8 (insurance experience)

R9 is adjacent: motor pricing transfers, but pet-specific drivers are untested. R1 is unclear because your location isn't in what you gave me.

**Opportunity ledger.** The role is clearly scoped, but I could not confirm the employer exists as described (RR1), the salary is withheld (RR2), and it's unclear whether the role has direct reports (RR3). The hiring manager's public record is a positive signal (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (fully remote UK); candidate constraints not given — checks against them unknown
- **Severe red flags:** RR1 (`severity: high`), unverified rather than confirmed. Verifying it clears the flag.
- **Conditions for go:** (1) Brindlemoor's live posting, careers page, or recruiter's email domain checks out (RR1); (2) the salary is disclosed and acceptable to you (RR2); (3) you're comfortable with the pet-insurance gap and with the role's reporting line (R9, RR3).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech with a pet-insurance product | `[grounded]` JD header; not independently verified (see RR1) |
| Mandate | Own pricing analytics: build and monitor rating models, design and read price tests, turn results into recommendations for underwriting and product | `[grounded]` JD |
| Outcomes | None stated | — |
| Working pattern | Fully remote, UK | `[grounded]` JD |
| Scope read | A senior analyst remit with ownership of the rating and testing function, not explicitly a team lead | `[inferred]` from "own" against the absence of any reporting-line language |
| Market calibration | Senior pricing analysts at UK insurers and insurtechs: median base £58,400, interquartile range £52,100–£64,900 | `[generic]` Pricewell 2026 UK Pricing and Actuarial Analytics Pay Survey (n=612); a band, not this employer's offer |
| Unknowns | Salary; reporting line and direct reports; whether the employer exists as described | — |
| Contradictions | None within the JD. No careers-page cross-check was possible (see the research table). | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote, UK | hard_gate | unclear | none | hard_gate | Your location and right to work aren't in the inputs | — | Q3 |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | Five years in pricing analytics, last two as senior analyst; self-reported, no artifact | `[grounded]` your statement | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | Daily use of both | `[grounded]` your statement | none |
| R4 | GLM experience | must_have | direct | medium | none | Built and maintained a GLM rating model; the model was for motor's young-driver book | `[grounded]` your statement | none |
| R5 | Design and read price tests | must_have | direct | medium | none | Ran 14 price tests last year with underwriting. Expect a probe on test design and read-out | `[grounded]` your statement | none |
| R6 | Build and monitor rating models | must_have | direct | medium | none | Maintained a live rating model, which covers the monitoring half | `[grounded]` your statement | none |
| R7 | Present to underwriting or actuarial leads | must_have | direct | medium | none | Present the quarterly pricing review to the head of underwriting | `[grounded]` your statement | none |
| R8 | Insurance experience | preferred | direct | medium | none | Five years at a UK motor insurer | `[grounded]` your statement | none |
| R9 | Pet-insurance product knowledge | important | adjacent | medium | transferability | Credible adjacency: the same pricing-and-testing discipline on a different product. Limit: no pet-specific drivers (species, breed, vet-cost trend, lifetime versus annual cover) and no pet claims data. Named wherever this bridge is used | `[inferred]` from the motor work you described | G1 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pet-insurance product knowledge (R9, important) | transferability | Motor pricing and testing, nothing pet-specific | The likeliest objection from a pet-insurance hiring manager. A credible bridge narrows it | Any non-motor pricing, a product with a different claims pattern, or a test where the risk drivers were unfamiliar at first | A short note on how you'd adapt your monitoring approach to pet risk drivers, or a sanitized test read-out | `[inferred]` bridge from your motor work; `[generic]` that this is the likeliest objection |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | high | "Brindlemoor (insurtech)" | The entity may be too new to have a web footprint, the posting may be stale or aggregated, or it may not be a live hiring employer. Severity is high because the salary is also withheld; unconfirmed, not confirmed | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Salary withheld | unknown | — | "Fully remote (UK)" with no pay stated | The figure may sit below the band in role reality, or the employer may simply not publish pay | `[inferred]` from the JD's silence on pay, against the `[generic]` band | What base salary is budgeted for this role? | unresolved |
| RR3 | Reporting line and direct reports unstated | unknown | — | "Own pricing analytics" | The role may be an individual-contributor post with no line management. That fits your history, but it's worth confirming | `[inferred]` from "own" against the absence of reporting-line language | Does this role manage anyone, and who does it report to? | unresolved |
| RR4 | Hiring manager's public work is close to your own | positive_signal | — | Odile Varga, Director of Pricing at Brindlemoor; 2025 Insurance Pricing Forum talk "Small Books, Loud Errors" on monitoring rating models in small books | Your monitoring work on the young-driver book is a direct point of contact with that talk's subject | `[grounded]` public profile and talk title from search results (not fetched); `[inferred]` on the relevance | Which monitoring signals have you found most reliable on a small book? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm the posting on Brindlemoor's own careers page or via the recruiter's email domain before investing in the application | RR1 | `[grounded]` RR1 | proposed |
| A2 | Lead with the monitoring work on the young-driver book, framed as the same discipline the talk describes, not as pet expertise | RR4, R4, R6 | `[inferred]` from the talk title and your CV | pending your approval |
| A3 | Name the pet gap yourself, with your adaptation plan, rather than letting the panel find it | R9, G1 | `[generic]` interview pattern for transferability gaps | pending your approval |

## Evidence status

Verified: none yet. All your claims are self-reported in this message (confidence `medium` at most, no artifact).

Research tier: L1 — searches 3 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Brindlemoor insurtech pet insurance" — no results. Employer not established from attributable sources; RR1 raised to `high` and the decision capped at `conditional_go` |
| 2. Role-family sweep | yes | Searched "Senior Pricing Analyst pet insurance UK salary GLM"; result: Pricewell 2026 UK Pricing and Actuarial Analytics Pay Survey. Supplies the `[generic]` market band in role reality |
| 3. Hiring manager's public footprint | yes | Searched "Odile Varga Director of Pricing"; result: a public profile and a 2025 conference talk. Supplies RR4 and the positioning in A2 |

## Upgrade menu

- Brindlemoor's live posting or careers page → RR1 closes; the decision moves to `go` or `no_go`.
- The budgeted salary → RR2 closes against the band in role reality.
- Any non-motor or pet-related pricing work, or a sanitized test read-out → R9 moves toward direct.
- The reporting line → RR3 closes.
- A deeper pass on Brindlemoor (funding, leadership changes, public candidate reports; up to 5 more searches and 2 more fetches) — say the word and it runs.

If you want this kept as a file, I can emit it as `tuesday-dossier.md` at the end.

1. **G1** — Have you ever worked on a product whose risk drivers were unfamiliar to you at first (non-motor, or a different claims pattern)? What did you own, and what did you learn?
2. **RR1** — Can you paste the live posting link, or the Brindlemoor careers page, or the recruiter's email address? That's the one thing that moves this from conditional to a clear decision.
3. **R1 and RR2** — Are you UK-based with no other constraints, and what's your base salary floor?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.