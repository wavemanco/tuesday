Your prep pack is saved as `kelverton-rail_senior-partnerships-manager_interview_pack.md` and attached above. Web search was refused in this session, so nothing about Kelverton Rail comes from outside your message and the recruiter's email. The pack builds on the strongest thing you have: your ISV channel growth, quoted directly, with your transport-side experience as the bridge to operators.

Three things to start with:
- **The point of view** is a graded deliverable, so it gets the most time. The pack gives three theses, each with a concession, and an operator-side close. These are rehearsal scaffolds, not facts about the rail market.
- **Your highest-risk objection** is "why should an operator trust a partnerships lead who has never sold into rail?" (B1). Practise the plain acknowledgment, then hold through two follow-ups.
- **Commercials:** Ross will likely probe "never carried a direct quota" and the "£4M influenced" figure. Say the plain acknowledgment first, and don't claim you would hit a quota. Know how the £4M was counted, or say you don't.

Offers, one line each, neither pushed:
- I can run a live drill with me as Ross on the commercial questions (C1 to C3), or as Deepa on B1.
- I can save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions.

A Word version of the pack is available if you want one.

Three questions, which would change the pack:
1. Can you paste the job description? If you'd rather not, I'll proceed and the JD-derived rows stay labelled as inferred.
2. Can you paste the headline points from the market report? I need them to know the consensus answer, so the point of view departs from it on purpose.
3. In your transport work, were your clients operators, the transport authority, or suppliers to operators? That decides which side of the table your "from the other side" line stands on.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: kelverton-rail_senior-partnerships-manager_interview_pack.md -----
# Kelverton Rail: Senior Partnerships Manager, second round

**Panel (Tuesday, 60 minutes):** Deepa (VP Partnerships, your future manager) and Ross (Commercial Director).
**Format:** first 15 minutes, a spoken point of view on operator partnerships over the next 18 months (no slides); the rest is Q&A, and Ross will push on commercials.
**Built without research:** the web searches were refused, so nothing about Kelverton Rail below is sourced from the web. Company facts come only from your message and the recruiter's email as you quoted it. The job description and the market report were not supplied.

## How to use + type key

Personas describe how a question arrives. Types describe what is being scored. Guidance is scaffolding, not a script: speak it in your own words.

| Tag | Name | What it scores |
|---|---|---|
| VAL | Values / behavioural | Past behaviour against published values (none detected here) |
| EXP | Experience deep-dive | Whether your claims survive scrutiny and what was actually yours |
| JD | Role-driven | Whether you can do the job as stated, including its gaps |
| CO | Commercial / strategy | Commercial judgement and how you think about revenue |
| CASE | Live problem | Structure and reasoning on an operator problem, live |

## Prep triage (about 4 hours)

1. **POV, about 100 minutes.** Pick one thesis from section 5, draft it, then record two full 15-minute runs on your phone. Check the last three minutes land on what it means for operators.
2. **Highest-ROI hold, about 45 minutes.** B1 and C1, out loud, two follow-ups each. Say the concession sentence until it sounds plain, not rehearsed.
3. **Commercials, about 45 minutes.** C2, C3, D1, D2. For each answer slot, write the honest branch in your own words. Do not invent a number.
4. **Case structure, about 30 minutes.** A2 and A4 only, structured on paper, no full answers.
5. **Journey and reverse questions, about 20 minutes.** E1 timed at 90 seconds; R1 to R3 said aloud.

Everything else is insurance.

## The fit snapshot

Requirements come from the recruiter's words, quoted, since no job description was supplied. Your background comes from your message, quoted.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "where you'd take our operator partnerships over the next 18 months" (recruiter email) | "9 years in partnerships" (your message); "took it from 6 partners to 40, roughly £4M of influenced revenue" (your message) | medium | [grounded] | transferability | Your material shows partnership work through a payments channel, not operator partnerships. The bridge is the channel mechanics in your words: "running the ISV channel," "took it from 6 partners to 40." Limit, as the pack's own observation: the material does not show an operator relationship. Answer slot: if any of that growth was yours to design, say which step and how you decided; if it was not yours, say so and say what you did run. |
| F2 | "what it means for the operators themselves" (recruiter email) | "so I know the operator world from the other side" (your message) | low | [inferred] | discovery | The sentence touches operators but does not show which side of the table you sat on, so any bridge here is this pack's derivation, not an established fact. Answer slot: if your transport work was for operators, say what you saw from their side; if it was for someone else, say that and what it showed you. Never describe operator decisions you did not see. |
| F3 | "Ross will push on commercials." (recruiter email) | "never carried a direct quota, only influenced revenue" (your message) | none | [grounded] | capability | A gap your own words already state: "I've never carried a direct quota." Then the plan, as a plan and never as a past: what you would need to learn in your first 90 days. |
| F4 | Sector knowledge of rail operators (role-family, no quote) | "Never sold into rail specifically" (your message); "bus and light rail network planning" (your message) | medium | [grounded] | transferability | "I haven't sold into rail specifically." The adjacent work is the planning side of bus and light rail, not rail sales. Answer slot: if the planning work put you in front of rail decision-makers, say so; if it did not, say what it did put you in front of. |

Reading the gap types: F1 and F4 are transferable, not capabilities you have, so the bridges say what the work was and stop there. F3 is the one row your own words close as a gap.

## Prohibited claims

Built locally from the fit snapshot, since no dossier was supplied. These are the claims a candidate reaches for under pressure. No answer, hold, bridge or reverse question in this pack asserts any of them.

| Not coached | Basis | Honest form |
|---|---|---|
| Sold into rail, or rail sales experience | Negative you stated: "Never sold into rail specifically" | "I've never sold into rail specifically." No slot. |
| Carried a quota, or owned a revenue target | Negative you stated: "never carried a direct quota" | "I've never carried a direct quota." No slot. |
| Built the ISV channel | Inflated form of "running the ISV channel" and "took it from 6 partners to 40" | The quotes at their own scope. The limit is the pack's observation: the material does not say who designed the channel. A slot asks which steps were yours. |
| Generated £4M | Inflated form of "roughly £4M of influenced revenue" | "roughly £4M of influenced revenue," in those words, with the attribution question as a slot (D1). |
| Knows operators' decisions from the inside | Inflated form of "so I know the operator world from the other side" | The quote at its own scope; which side you sat on, only in your own words (F2). |

## Persona weights

No interviewer profile was researched (the search was refused), so the weights rest on each panellist's stated role and the recruiter's words.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Pressure | Ross, pushing on quota and revenue | High. He is the Commercial Director and the recruiter named commercials as the push. He is the panel's pressure seat. | Hold, then concede specifically. Say the plain acknowledgment first, then hold through two follow-ups. |
| Case / Strategist | Deepa, live operator problem | High. A hiring manager buys capability and wants to see how you structure an operator problem. | Clarify, then structure, then answer. Say the framework aloud once. |
| Skeptic | Deepa, "why you, why now" | High. The rail gap and the quota gap are the two obvious objections; she will likely find them in your background. | Rehearse the single most likely objection until it is plain. Bridge only from what you stated. |
| Data-Driven Prober | Ross, on the £4M figure | Medium-high. "Influenced revenue" invites a question about how it was counted. | Say how it was counted only if you know; otherwise say so, and name the weakest assumption. |
| Conversational | Opening biography | Medium. A panel almost always opens with a journey question, which is scored for economy. | A 90-second arc, in the order of the sentences you already have. |

Weights: Pressure 5, Case 4, Skeptic 4, Prober 3, Conversational 2, for 18 questions.

## Graded deliverable: the 15-minute point of view

The recruiter named this deliverable and asked you to "land on what it means for the operators themselves." Grounded facts to build on:

- F1: "took it from 6 partners to 40, roughly £4M of influenced revenue" (your message)
- F2: "so I know the operator world from the other side" (your message)
- F4: "bus and light rail network planning" (your message)

The theses below are rehearsal scaffolds, not facts about Kelverton Rail or the rail market. Each is `[generic]`. The market report is the consensus answer you need to depart from, and the pack cannot see it. Paste its headline points (upgrade menu) and the differentiation step gets real.

**Thesis 1: operators buy change, not software.** Organise partnerships around the operator's change-approval cycle. Concession: if operators buy per licence rather than per change, the cycle matters much less.

**Thesis 2: delivery capacity is the constraint, not demand.** Invest in partners who can staff rollouts. Concession: if operators' planning teams want to own tooling in-house, partners become the wrong lever.

**Thesis 3: measure the partnership by an operator outcome, not a licence count.** Use a shared measure the operator controls. Concession: operators may refuse to share operating data, which makes the measure theirs to choose.

**Differentiation.** Name one item from the consensus answer to show you read it, then one thesis that departs from it, with your reason. Recommended anti-pick for this role: name one operator or segment you would not pursue yet, and why. Partnerships roles spend much of their time saying no.

**Structure (15 minutes).** About 1 minute framing the operator question; 2 minutes on the operator's problem; 6 minutes on one thesis and its mechanics; 3 minutes on the concession and the bridge from your own work (F1, F4); 3 minutes on what it means for the operators, stated as a test they could check, not a promise.

## Question banks

Every row's provenance comes first. A row that makes no claim about your past carries its label alone.

### Pressure: Ross (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Sixty seconds: why give an operator-partnerships role to someone who has never sold into rail?" | JD | [grounded] "Never sold into rail specifically" (your message); "bus and light rail network planning" (your message); "took it from 6 partners to 40" (your message) | Open with the plain line: "I've never sold into rail specifically." Hold through two follow-ups with the adjacent evidence in your own words: the planning side of bus and light rail, and the channel growth. Do not argue the gap away. On the second follow-up, concede what you would need to learn first, and say it as a plan. | F4 asked as a pressure question. Hold-then-concede is the structure, and the hold rests only on the quoted sentences. |
| C2 | "Your £4M. How much of that was yours?" | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" (your message) | Say the figure with "roughly" and "influenced" kept. Weakest-assumption move: name the assumption behind "influenced" that you would defend least. Answer slot: if you know how the channel counted influence (which deals, what window), say it; if you do not, say so plainly and say which part was yours. | F1 is your one number on this side of the table. Defend the number, not a reconstruction of it. |
| C3 | "You've never carried a direct quota. Why would we believe you'd hit one?" | CO | [grounded] "never carried a direct quota, only influenced revenue" (your message) | Begin with "I've never carried a direct quota." Do not promise to hit one. Hold that the channel growth is your evidence for partner growth, not revenue ownership, then concede specifically: what you would need to learn in the first 90 days, as a plan. | F3, the commercial probe the panel is most likely to make. The plain acknowledgment must be ready before the probe. |
| C4 | "What's the revenue case for an operator partnership: who pays, and when?" | CO | [generic] | Structure it aloud: who pays (the operator, the partner, or a licence through a partner), what triggers payment, and what payback window you would test. Name the two inputs you would need from the business before committing a number. Make no claim about current pricing or contracts. | Ross's commercial push, asked as a structure problem. Generic, because the market report is not in the pack. |
| C5 | "Give me the number you'd hold yourself to in year one, and how you'd defend it." | JD | [generic] | Name the metric, then the assumption you would defend least. Do not invent a target. If the business has not set one, say you would agree it with the commercial team before committing. | The most direct form of Ross's commercial push, and the metric move applied to a forward number. |

### Case / Strategist: Deepa (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Where would you take our operator partnerships over the next 18 months?" | CASE | [grounded] "where you'd take our operator partnerships over the next 18 months" (recruiter email) | This is the graded point of view. Build it in the section above. | The recruiter's own assignment, so it has its own build. |
| A2 | "What do you need to know about an operator before proposing a partnership with them?" | CASE | [generic] | Clarify, then structure: how operators decide what to change, who signs off, what their change cycle is, and what they already run. Say the three you would ask first before answering. | Deepa's likely opener, testing clarify-before-structure. Makes no claim about your past. |
| A3 | "Which operator problem would you solve first, and what does a partner do that we can't?" | CASE | [grounded] "what it means for the operators themselves" (recruiter email) | Start from the operator's problem, not from your product. Name the one problem, the partner's role in solving it, and the test that would show it worked. Use no operator-specific facts. | Tests the operators-first brief in the recruiter's words. The guidance does not adopt a specific problem. |
| A4 | "How would you tell, twelve months in, that an operator partnership is working?" | CASE | [generic] | Name the outcome before the tactic. Give one leading and one lagging measure, and name the one you would defend least. Keep the outcomes on the operator's side first. | A case question that leads into the prober's assumption test. No claim about your past. |

### Skeptic: Deepa (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Why should an operator trust a partnerships lead who has never sold into rail?" | JD | [grounded] "Never sold into rail specifically" (your message); "so I know the operator world from the other side" (your message) | **Highest-ROI prep.** Open: "I haven't sold into rail specifically." Then the bridge in your words: the planning side of bus and light rail, and the channel you grew. Hold through two follow-ups by returning to what you did, not by adding to it. Answer slot: if your transport work was for operators, say what you saw from their side; if it was for someone else, say that and what it showed you. | The objection this candidate most predictably faces, combining F4 and F2. The answer slot's second branch allows that operator work was never yours. |
| B2 | "The ISV channel is a payments partner programme. Operator partnerships are a different buyer. What transfers?" | JD | [grounded] "running the ISV channel" (your message); "took it from 6 partners to 40" (your message) | Name the mechanics you actually did. Answer slot: if you recruited, enabled or tiered partners yourself, say which and how; if others ran those, say what you ran. Never list mechanics you did not run. | F1, where the buyer differs. The mechanics are a practice the material does not state, so they stay a slot. |
| B3 | "Why leave a payments company now?" | JD | [generic] | Give your true reason in one sentence, in your own words. The material does not contain it, so the pack supplies none. | A standard motivation probe. The pack has no reason for you to rehearse and will not supply one. |
| B4 | "Where's the gap between what you know about rail and what this role needs on day one?" | JD | [generic] | Name the gap plainly, then a 30-day plan: which operators you would talk to first and what you would ask them. A plan, not a past. | The day-one gap, answered as a plan. |

### Data-Driven Prober: Ross (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how you counted the £4M." | EXP | [grounded] "roughly £4M of influenced revenue" (your message) | Answer slot: if you know how the influence was counted (which deals, what window, what attribution), say it. If you do not, say so, and keep "roughly" in the answer. | The figure-defence rehearsal. The pack does not supply a counting method. |
| D2 | "Of the 40 partners, how many were active?" | EXP | [grounded] "took it from 6 partners to 40" (your message) | Answer slot: if you know what "partner" meant in that count (signed, live, or active), say it. If the count did not separate them, say that. | The prober's denominator question on the growth figure. |
| D3 | "What would you have to believe for the operator revenue case to hold?" | CO | [generic] | Name two assumptions, then the one you would defend least. Keep to beliefs you could test. | Assumption-naming for a case with no claim about your past. |

### Conversational: panel opener (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So — walk us through the journey." | EXP | [grounded] "9 years in partnerships" (your message); "running the ISV channel" (your message); "5 years in transport consulting" (your message) | Ninety seconds in this order: partnerships, the channel, then transport planning, ending on why operators. Use only these sentences. | Scored for economy. The quotes above are the whole of the story. |
| E2 | "What would you want to be true at the end of your first quarter?" | JD | [generic] | Name two concrete outcomes as a plan, one for operators and one internal. Never a past. | Casual register, but scored. |

### Requirement coverage

| Requirement (recruiter's words) | Question IDs |
|---|---|
| "where you'd take our operator partnerships over the next 18 months" | A1 (graded POV), A4, B2 |
| "what it means for the operators themselves" | A2, A3, B1 |
| "Ross will push on commercials" | C1 to C5, D1 to D3 |
| Job-description requirements | none, and why: no job description was supplied, so mid-list requirements have no rehearsal yet |

## Reverse questions

Each needs one line of why it lands. No interviewer profile was researched, so none is tailored to Deepa's or Ross's career path.

1. **"What would a strong first six months in this role look like to you, Deepa?"** Converts the interview into a manager conversation and tells you what to aim at.
2. **"Ross, when you say commercials, which number do you look at first for operator partnerships?"** Names his push and shows you want to know what he measures.
3. **"Which operator relationship do you most want the new person to understand before anything else?"** Shows operators-first thinking and invites the operator story from them.
4. **"What's the decision this role will have to make that the strategy work doesn't settle yet?"** Shows you read the internal material without quoting it back.
5. **"How do operators buy scheduling software from you today: through your team, through partners, or both?"** Shows you want the process, not only the pitch.

## Upgrade menu

- **The job description** → the fit snapshot's requirement rows become `[grounded]`, and mid-list requirements get JD-tagged questions.
- **The market report's headline points** → section 5's consensus check becomes real, and the differentiation step can name what to depart from.
- **Your transport clients (operators, the authority, or suppliers to operators)** → F2 moves from `discovery` to a stated fact, and B1's bridge gets its real side.
- **How the £4M was counted** → D1, D2 and C2 become answers you can give, not slots.
- **Permission to search** → the refused searches (values, strategy, Deepa's public footprint) can be rerun. That adds the values check, the strategy vocabulary, and a tailored reverse question and persona weights.

## Sources

**Provided:** your message, including the recruiter's email as you quoted it. The market report was not in the files, so it has not been read here.

**Searches sent (all refused, so no results):**
- "Kelverton Rail company values" (target 1)
- "Kelverton Rail scheduling software train operators partnerships" (target 3, strategy and product)
- "Deepa VP Partnerships Kelverton Rail" (target 4, interviewer)

**Research tier: L1, searches 3 of 6, fetches 0 of 2; user links read 0**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Kelverton Rail values | unavailable | Values cheat sheet, section 10. Refused, so no values round can be checked against published values. |
| 2. Interview process, role family | unavailable | Loop structure. Your recruiter's email already fixes the session (60 minutes, panel, POV first), so the loop is established without it; the values-round check is what it would have added. |
| 3. Strategy and recent news | unavailable | Grounding brief and the CO bank's current-strategy questions. Refused; the CO questions are generic as a result. |
| 4. Interviewer footprint (Deepa, Ross) | unavailable | Interviewer read, tailored reverse questions and persona weights. Refused. |
| 5. Representative job description | unavailable | Fit-snapshot requirements. No job description was supplied and no search was sent; the host refused. |

## Sections dropped

- **Grounding brief:** no research ran and no strategy brief was provided.
- **Reading the interviewer:** no public footprint was retrieved.
- **Values cheat sheet:** no values-style round detected. The recruiter's email names no values round, and no published values were read.
- **Delivery coaching:** no working-style assessment was provided.

## Upgrade menu (final)

- The job description, pasted → requirement rows become `[grounded]`, and mid-list requirements get questions.
- The market report's headline points → the point of view's differentiation becomes real.
- Your transport clients (operators, the authority, or suppliers to operators) → F2 and B1 get their real side.
- How the £4M was counted → D1, D2 and C2 become answers you can give.
- Permission to search → the refused targets can be rerun.
