Your prep pack is saved as /tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-alone-part-2-rooms-case-8-canned-1c056e05/a5f392f8-38e2-46e0-910b-ad0bd1a786a8/scratchpad/ashgrove_member-experience-lead_interview_pack.md. I built it as a loop, with a bank and persona weights for each of the three rounds.

Three things to act on before 20 November:

- **Round 2's highest-ROI question is 2.1:** "You've never worked in a contact centre... why should I believe you can run it?" Rehearse holding on the branch complaints log, then conceding the contact-centre queue specifically.
- **Your material is thinnest on three JD lines:** contact centre (F2), presenting to senior leaders (F8), and regulated complaints (F7). The pack uses plain acknowledgments for the first two. For regulated complaints, it asks whether any complaint went outside the branch or ran to a deadline. Answer that in writing before the round.
- **Strategy:** the 40% digital shift and the eight-to-five hub consolidation both change where complaints come from and how they are routed. Section 4 and question 3.2 cover this.

Research did not run. Your values, the recruiter's round structure and your strategy summary already covered every research target. The strategy section is based on your summary of the July brief, not the brief itself. Ashgrove's values are from the page you copied this morning.

Do you want me to run a drill? I can play the Head of Member Services on question 2.1, the highest-ROI prep. I can also save a tuesday-dossier.md recording the gaps this prep exposed, for carrying into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove_member-experience-lead_interview_pack.md -----
# Interview pack: Member Experience Lead, Ashgrove Credit Union

**Mode:** Loop (three rounds, 20 November 2026) · **Prepared:** 11 November 2026 · **Candidate:** Dara

Changed since last version: n/a (first version).

---

## 1. How to use this pack

- **Personas** describe how a question arrives. **Types** describe what it scores.
- **Type key:** VAL = values alignment, scored against Ashgrove's four published values. EXP = your own experience, checked for what was actually yours. JD = a requirement from the job description. CO = company and strategy knowledge. CASE = a live problem from the role.
- **Guidance is scaffolding, not a script.** Answer slots say "if you did this, say how; if there was no such step, or it wasn't yours, say so." Both branches are honest answers. Pick the one that is true.
- **Every claim about your past is quoted from what you gave me.** Each quote names its source: *your message* (your background, JD text, values page, recruiter's email, or the strategy summary you pasted).
- **Question IDs** are by round: 1.x = recruiter screen, 2.x = Head of Member Services, 3.x = panel. Fit-snapshot rows are F1–F8.

---

## 2. Prep triage (9 days to the first round)

Done in this order. Everything else is insurance.

1. **Say the two plain acknowledgments until they're flat.** "I've never worked in a contact centre." and "I've never presented to anyone above regional level." Say each once, then go straight to the closest thing you do have. Covers 1.4, 1.6, 2.1, 2.2.
2. **Time your 90-second background** (1.1) using only the four quoted sentences, in order. Stop at 90 seconds.
3. **Run the complaint case (3.1) aloud twice**, 20 minutes each, out loud, with a timer. Structure: clarify, objective, approach, metrics, risks. Before 20 November, ask the recruiter whether the case comes with any written material.
4. **Write one page: your first 90 days.** Cover learning the contact-centre side, how you'd prepare to present to senior leaders, and how you'd work with a digital team. Write it as a plan, not as history.
5. **Answer your own answer slots in writing**, for regulated complaints (2.3) and Excel (1.5, 3.8). Write what is true, including "no." Those answers decide how the banks read on those two requirements.

---

## 3. Fit snapshot

Requirements are quoted from the JD you pasted. Evidence is quoted from what you told me. Nothing in the evidence column is a summary.

No requirement in the JD is a gate in the sense that the evidence conventions use (no location, schedule, pay, credential or legal term is stated). Hard gates: none.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor" — your message | medium | [grounded] | none | No gap on years. Your words, unchanged: "6 years in retail banking, the last 3 as a branch supervisor." Borrow nothing from the JD: say "retail banking," not "customer operations." Expect a probe on what the years covered. |
| F2 | "Own the member complaints process end to end across branches and the contact centre" — JD | "I handled the branch's formal complaints log" — your message; "Never worked in a contact centre" — your message | low | [grounded] | capability | The branch half is partial evidence. The contact-centre half is a stated absence. Your words: "I handled the branch's formal complaints log." and "I've never worked in a contact centre." Then how you'd learn the contact-centre side, as a plan. Answer slot: if any complaint crossed a handoff to another team, say which and what you did. The material shows a branch log, not an end-to-end process. Don't widen it. |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | presentation | The quote reaches monthly complaint reporting. It doesn't say resolution times. Your words: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: if the sheet recorded how long complaints took to resolve, say how that was counted; if it didn't, say so. Don't describe the sheet as the executive report. |
| F4 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | low | [grounded] | discovery | The sheet may be Excel; your material doesn't say. Answer slot: if it was Excel, name what you did in it and what you'd still need to learn. If it was another tool, say which, then say how comfortable you are with Excel. Don't claim a skill level the material doesn't show. |
| F5 | "coach branch supervisors on escalations" — JD | "I trained new tellers on our escalation script" — your message | low | [grounded] | transferability | Adjacent work: training tellers on an escalation script, not coaching supervisors. Your words: "I trained new tellers on our escalation script." Answer slot: if you coached a supervisor or colleague through a live escalation, say what you did. If training was all the coaching you did, say so. |
| F6 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | The material is silent. It doesn't show digital work on your side, and it doesn't deny any. Answer slot: if you've worked with a digital or systems team on a customer-facing change, say what it was and your part. If you haven't, say so, then say what you'd bring to a first meeting, as a plan. |
| F7 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | discovery | "Formal" suggests a regulated process. The material doesn't show whether any complaint left the branch or ran to a deadline. Answer slot in 2.3: if one did, say which and your part. If none did, say so plainly. |
| F8 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level" — your message | none | [grounded] | capability | Stated absence. Your words: "I've never presented to anyone above regional level." Then how you'd get ready, as a plan, never as a past. Don't add any presentation that isn't in your material. |

**Reading the snapshot.** The three rows that will matter most in the room are F2 (contact centre), F8 (senior leaders) and F7 (regulated complaints). The question banks lean hardest on them, because they are where the JD is strongest and your material is thinnest.

---

## 4. Grounding brief (from the strategy summary you pasted)

**Source:** your summary of the 2026 strategy brief (July 2026). I have not seen the brief itself, only your summary. Quote its wording exactly once you have it.

**Company context, in the brief's own terms:**
- "move 40% of member service to digital channels by 2028"
- "consolidate eight branches into five hubs over 2027"
- "launch a small-business lending product in Q1 2027"
- Main competitive pressure: app-only banks

**What this means for the complaints role (my reasoning, labelled as such):**
- **Consolidation** (`[generic]` reasoning) changes where complaints are raised, routed and tracked. A closing branch's members may still have a complaint, but no local counter. That is the process you'd own.
- **Digital shift** (`[generic]` reasoning) changes the channel mix of complaints. Members who can't or won't use the app may raise problems by phone or in a hub, and the complaint may look different when it arrives. The volume and the routing both move.
- **Small-business lending** (`[generic]` reasoning) can create a new category of complaint, with its own handling rules. Ask about this before you assume it.
- **App-only competitors** (`[generic]` reasoning) raise the service bar on digital journeys, which is the JD's "work with digital teams" line.

**Stale-framing check:** the brief is four months old. Before 20 November, confirm nothing has been published since. Use the brief's language as your reading of the strategy, not as a quotation to correct the interviewer on.

---

## 5. Persona weights by round

Loop mode: each round has its own bank and its own weights. Weights are shown with the reasoning.

| Persona | Round 1: recruiter screen | Round 2: Head of Member Services | Round 3: panel of two branch managers | Why |
|---|---|---|---|---|
| Conversational / Rapport | 4 | 0 | 0 | Relationship prior for a recruiter screen. Casual questions are still scored. |
| Skeptic | 3 | 4 | 0 | Your stated gaps (F2, F8) are the Skeptic's material. The screen will check them early. The Head of Member Services is the hiring manager, and the relationship prior is Skeptic plus Case. The recruiter called the round "mostly behavioural," which lowers Case and raises Skeptic. |
| Values / Behavioral | 1 | 3 | 3 | The recruiter says the panel "scores against the four values." Round 2 is "mostly behavioural." |
| Case / Strategist | 0 | 0 | 3 | The 20-minute complaint-escalation case in round 3. |
| Peer Evaluator | 0 | 0 | 2 | The panel is two branch managers. The seam between branches and the contact centre is their concern too. |
| Data-Driven Prober | 0 | 1 | 2 | The JD's Excel and reporting requirements, and the monthly spreadsheet on your CV. |
| Pressure / Stress | 0 | 1 | 0 | One attribution probe in round 2. |

**Depth:** the top persona in each round gets the most questions. Every plausible persona appears in at least one round, so you never meet a style for the first time live.

**Coverage line.** Every JD requirement has a question, or a reason it does not.

| JD requirement | Covered by |
|---|---|
| Own the complaints process end to end across branches and the contact centre | 1.4, 2.1, 2.8, 3.5 |
| Report monthly on complaint volumes and resolution times | 2.2, 3.7, 3.9 |
| Coach branch supervisors on escalations | 2.6, 3.1 |
| Work with digital teams on self-service journeys | 3.2, 3.6 |
| 4+ years in financial-services customer operations | 1.1 (F1 is closed; no separate question) |
| Experience handling regulated complaints | 2.3, 2.4 |
| Confident presenting to senior leaders | 1.6, 2.2 |
| Comfortable with Excel reporting | 1.5, 3.8 |

No headline metric appears on your material, so no defend-the-number question is needed. Questions 3.8 and 3.9 test method, not a figure.

---

## 6. Question banks

### Round 1: Recruiter screen, 30 minutes

**Weights:** Conversational 4 (1.1, 1.2, 1.3, 1.8) · Skeptic 3 (1.4, 1.5, 1.6) · Values 1 (1.7)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 1.1 | "Walk me through your background in two minutes." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" — your message; "I handled the branch's formal complaints log" — your message; "I trained new tellers on our escalation script" — your message; "I built the monthly complaints spreadsheet our regional manager uses" — your message | A 90-second arc in your own words, in the order those four sentences give: years and the supervisor step, the complaints log, the tellers' script, the spreadsheet. Stop there. No outcomes, team sizes, or contact-centre work. | Casual register, still scored. The first answer sets the record the next two rounds check. Uses F1, F2, F3 and F5 only. |
| 1.2 | "Why Ashgrove, and why now?" | VAL | [grounded] "Members First, Always — we decide from the member's side of the counter" — company values page, copied 11 November 2026 (your message) | Anchor on one value and one line from the brief: "move 40% of member service to digital channels by 2028." Give your reason as your own reading of the strategy. Don't claim knowledge of the branch network from the inside. | Motivation is the screen's core question. The recruiter reads for consistency with the rounds ahead. |
| 1.3 | "Why leave a branch supervisor role for this one?" | JD | [generic] | Give reasons in your own words, about where you want to go: owning the complaints process across branches, reporting it, coaching supervisors. Frame them as direction, not as things already done. No claim about your past is needed. | Motivation probe in a friendly register. Generic, because it tests the reasoning, not a fact. |
| 1.4 | "Have you worked in a contact centre?" | JD | [grounded] "Never worked in a contact centre" — your message; "I handled the branch's formal complaints log" — your message | Plain acknowledgment: "I've never worked in a contact centre." Then the closest thing you have run: "I handled the branch's formal complaints log." Then one line on how you'd learn the contact-centre side, as a plan. | F2. A stated gap the screen can knock out on. The JD's "across branches and the contact centre" makes the question likely. |
| 1.5 | "Are you comfortable with Excel reporting?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" — your message | Answer slot: if the spreadsheet was in Excel, say what you did in it and what you'd still need to learn. If it was another tool, say which, then say how comfortable you are with Excel. Don't claim a skill level you haven't shown. | F4, asked as a knockout. The quote doesn't name the tool, so the slot asks which. |
| 1.6 | "How do you feel about presenting to senior leaders?" | JD | [grounded] "I've never presented to anyone above regional level" — your message | Plain acknowledgment: "I've never presented to anyone above regional level." Then your plan for getting ready, as a plan. Don't add a presentation that isn't in your material. | F8. The JD asks for "confident presenting to senior leaders," and the screen asks it directly. |
| 1.7 | "What does member-ownership ask of a complaint process?" | VAL | [grounded] "Neighbours, Not Numbers — every branch is part of its town" — company values page (your message) | Scaffold, no past claim. One answer, about 60 seconds, on what member ownership asks of how complaints are handled, in your own words. | Values read early. No story is needed here, so the guidance makes no claim. |
| 1.8 | "What would you want to learn in your first 90 days?" | JD | [generic] | Name two things from the JD you'd need to learn: the contact-centre side and executive reporting. Give a plan for each. A plan, not a past. | Casual question about the gaps. Generic, because it asks for a plan. |

### Round 2: Head of Member Services, 45 minutes (hiring manager; mostly behavioural)

**Weights:** Skeptic 4 (2.1, 2.2, 2.3, 2.8) · Values 3 (2.5, 2.6, 2.7) · Prober 1 (2.4) · Pressure 1 (2.9)

**Highest-ROI prep in this pack: 2.1.** The contact-centre gap sits at the centre of the JD's first requirement, so expect this objection in some form. A rehearsed, non-defensive answer changes the interview more than any other single answer.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 2.1 | "You've never worked in a contact centre, and this role owns the complaints process across one. Why should I believe you can run it?" ★ | JD | [grounded] "Never worked in a contact centre" — your message; "I handled the branch's formal complaints log" — your message | **Hold:** the closest thing you have run is the branch's formal complaints log. Say what it carried: the log, the formal complaints. **Concede specifically:** you haven't run a contact-centre queue. Name the part you'd learn first. Hold through two follow-ups by returning to the log; concede the queue. Answer slot: if any complaint in your log came to you from a contact centre or another team, say which and what you did with it. If none did, say so. | F2 and the JD's first line. The most likely probe. The hold-then-concede shape matters more here than any single fact. |
| 2.2 | "You've never presented above regional level. How would you put complaint volumes in front of the executive?" | JD | [grounded] "I've never presented to anyone above regional level" — your message | Plain acknowledgment first: "I've never presented to anyone above regional level." Then the plan: what you'd put on one page, who checks it first, and how you'd rehearse. All as a plan. Never describe an executive presentation. | F8 with the JD's monthly reporting duty. Asked to see whether the plan is concrete. |
| 2.3 | "Have any of the complaints you handled gone to an outside body, or run to a deadline you were held to?" | JD | [grounded] "I handled the branch's formal complaints log" — your message | Answer slot: if a complaint went beyond the branch, or ran to a deadline, say which and what your part was, in your own words. If none did, say so plainly. | F7. The JD asks for "experience handling regulated complaints." Your sentence says "formal," not regulated. This answer sets F7's band. |
| 2.4 | "Walk me through how you handled the branch's formal complaints log." | EXP | [grounded] "I handled the branch's formal complaints log" — your message | Story-mapped on the quote: the log, the formal complaints, your handling. Tell the beats in your own words. Answer slot: if you set the order cases were worked in, or how they closed, say how you decided. If the procedure set them, say so and describe how you worked within it. | Premised on your own sentence alone. Prober, because the next question will be how it was counted. F2 and F7 both draw on this quote. |
| 2.5 | "Tell me about a time you made a decision about a member's complaint from the member's side of the counter, when the process pointed the other way." | VAL | [grounded] "Members First, Always — we decide from the member's side of the counter" — company values page (your message) | Selection scaffold. Pick a complaint where what the member needed and the procedure pulled apart. Say what you chose, what you gave up, and what the member heard. If none comes to mind, say so plainly, then give the nearest thing your material carries: the complaints log you handled. Add no outcome the log doesn't have. | Members First is a published value, and this round is behavioural. The question is open, so the guidance can't supply an event. |
| 2.6 | "Tell me about a time you coached someone through an escalation." | VAL | [grounded] "I trained new tellers on our escalation script" — your message | Story-mapped on the quote: the script and the new tellers, in your words. Answer slot: if you coached a supervisor or colleague through a live escalation, say what you did and how it went. If training was the only coaching you did, say so. | The JD's line on coaching supervisors. Your sentence is training tellers, not coaching supervisors. The slot keeps the difference visible. |
| 2.7 | "Tell me about a problem you found that wasn't yours to fix, and how you saw it through." | VAL | [grounded] "Own the Fix — whoever finds the problem keeps hold of it until it is solved" — company values page (your message) | Selection scaffold. Pick one problem you found and kept hold of. Say what you did at each step, and where you stopped. If you stopped, say so. If none comes to mind, say so plainly, then give the nearest thing your material carries: "I built the monthly complaints spreadsheet our regional manager uses." Say what it showed, if it showed anything, and whether you acted on it. | Own the Fix is hard to fake in a story. The spreadsheet pointer makes no claim that it revealed a problem. |
| 2.8 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "confident presenting to senior leaders" — JD; "Never worked in a contact centre" — your message | Name the part you judge weaker, plainly: the contact-centre side or senior presentation. Then a 30-day ramp plan. A plan, not a past. | Skeptic stem. It asks for honesty about the requirements you lack, which is the behaviour the round scores. |
| 2.9 | "Of the complaints process at your branch, which parts did you set yourself?" | EXP | [grounded] "I handled the branch's formal complaints log" — your message | Answer slot: say which parts you set and which were set for you, in your own words. If you set none of it, say so. Hold a position you can back; don't round your share up to the role's scope. | Pressure on attribution. The question assumes a process; the second branch allows that none of it was yours to set. |

### Round 3: Panel of two branch managers, 60 minutes (includes a 20-minute case; scored against the four values)

**Weights:** Values 3 (3.3, 3.4, 3.10) · Case 3 (3.1, 3.2, 3.7) · Peer 2 (3.5, 3.6) · Prober 2 (3.8, 3.9)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 3.1 | **20-minute case:** "A member has complained three times about the same fee reversal, which hasn't come through. The branch supervisor wants to close the complaint as resolved, because the fee was refunded. The member says it isn't resolved. What do you do?" | CASE | [generic] | Structure, aloud. **Clarify:** what "resolved" means to the member, and what the complaint record says. **Objective:** the member's outcome, and a closure you can defend. **Approach:** check the reversal yourself; don't rely on the supervisor's word. Decide who owns the fix. **Metrics:** how many contacts, how many days open. **Risks:** a refund is not resolution, and three contacts may be a pattern. Coach the supervisor on the escalation, not just on the close. | A constructed case, not an Ashgrove one. It presupposes nothing about your past. It tests Own the Fix and Members First together. |
| 3.2 | "The strategy moves 40% of member service to digital by 2028. What happens to complaints from members who used to come in person?" | CO, CASE | [grounded] "move 40% of member service to digital channels by 2028" — recruiter's brief, as summarised in your message | Structure: which members lose a route they used; where their complaints go instead (the app, the contact centre, a hub); how you'd see the shift early, through channel mix and repeat contacts; one risk to name. The reasoning is generic. The figure is the brief's. | Strategy-grounded, from the provided summary. Connects the complaints process to the brief. |
| 3.3 | "Tell me about a time a member needed something explained more than once." | VAL | [grounded] "Plain Words — if a member needs it explained twice, we wrote it wrong" — company values page (your message) | Selection scaffold. Pick a time a member or new teller needed something said twice. Say what you changed in the wording, and what happened next. If none comes to mind, say so plainly, then say how you'd test a letter's wording with a member before it went out, as a plan. | Plain Words is scored. This asks for the value's own test in a story. |
| 3.4 | "Eight branches become five hubs over 2027. How do you keep each town's view in the complaints process when a branch closes?" | VAL, CO | [grounded] "consolidate eight branches into five hubs over 2027" — recruiter's brief, as summarised in your message; "Neighbours, Not Numbers — every branch is part of its town" — company values page (your message) | Two beats: who in the closing branch's town still has a complaint route, and how their complaints stay visible once they sit in a hub's numbers. Then one risk. Don't claim you've run a closure. | Neighbours, Not Numbers is scored. The question uses the brief's own words, so it is a raising source. |
| 3.5 | "Branches and the contact centre disagree about who owns a complaint. How do you decide?" | JD | [grounded] "Own the member complaints process end to end across branches and the contact centre" — JD | Method and principle: name the rule that decides (the member's outcome, one named owner, a deadline). Then how you'd bring the two managers into it. Plan language; no past claim. | Peer seam probe. The panel are branch managers, so the disagreement touches them too. |
| 3.6 | "How would you work with our digital team on a self-service complaint journey?" | JD | [grounded] "work with digital teams on self-service journeys" — JD | Answer slot: if you have worked with a digital or systems team on a customer-facing change, say what it was and your part. If you haven't, say so, then say what you'd bring to the first meeting, such as complaint data by channel and by reason. As a plan. | F6. The material is silent, so the honest answer may be the first branch. |
| 3.7 | "Build the first monthly complaints report for senior leaders. What's on it, and what's left off?" | JD | [grounded] "report monthly on complaint volumes and resolution times" — JD | Structure: the audience, then the two headline measures from the JD (volumes, resolution times). Definitions first: what counts as a complaint, and when it's resolved. Name the definition you'd defend least. Then what you'd leave off: detail below the headline. Don't describe the spreadsheet you built as this report. | A JD duty as a design problem. Case persona. |
| 3.8 | "Which tool did you build the complaints spreadsheet in, and what could you do in it?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" — your message | Answer slot, as in 1.5: name the tool, the functions you used, and what you'd still need to learn for the role's reporting. | F4, asked by a branch manager. Same slot, harder probe. |
| 3.9 | "How would you calculate resolution time for a complaint?" | JD | [generic] | A method, not a past. Name the start and end points. Say what happens to the clock when a complaint waits on a member or another team. Name the one definition you'd defend least. Reasoning only; no figure. | Prober's method question on the JD's resolution-time measure. Generic, because it asks for reasoning. |
| 3.10 | "Tell me about a time you put a member's need ahead of an internal target." | VAL | [grounded] "Members First, Always — we decide from the member's side of the counter" — company values page (your message) | Selection scaffold. Pick a time a target and a member's need pulled apart. Say what you chose and what the target did. If none comes to mind, say so plainly, then give the nearest thing your material carries, without adding an outcome. | Members First asked as a trade-off, which values panels use. |

---

## 7. Values cheat sheet

Ashgrove's values, from its public page as you copied them on 11 November 2026. Your material carries no sentence that shows a decision made for any of the four values. Each row is therefore a selection scaffold with its honest branch. The nearest quoted sentence is named where one exists.

| Value (official name) | Working meaning (paraphrased) | Your mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter. | Scaffold, questions 2.5 and 3.10: a complaint where the member's need and the procedure pulled apart. If none comes to mind, say so, then give the nearest sentence you have: "I handled the branch's formal complaints log" (F2). Add no outcome. |
| Plain Words | If a member needs it explained twice, we wrote it wrong. | Scaffold, question 3.3. Nearest sentence: "I trained new tellers on our escalation script" (F5), at its own scope. That is training, not wording. If you never rewrote a script, say so. |
| Neighbours, Not Numbers | Every branch is part of its town. | Scaffold, question 3.4. Your material has no sentence about a town or a branch closure. If you have one, say it outright. It becomes new material. |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved. | Scaffold, question 2.7. Nearest sentence: "I built the monthly complaints spreadsheet our regional manager uses" (F3). Say what it showed, if anything, and whether you acted on it. If you didn't act on anything it showed, say so. |

---

## 8. Reverse questions

Each question has a "why it lands."

**Round 1 (recruiter)**
- "What would be most useful for me to bring to the Head of Member Services' round?" — *Shows you read the process and want to prepare for the right thing.*

**Round 2 (Head of Member Services, your future manager)**
- "What does 'end to end' mean on day one? Which complaint decisions sit with this role, and which stay with the branches?" — *Shows you're scoping the JD's first line, not just accepting it.*
- "How are complaint volumes and resolution times reported to the executive today, and what decisions does that report feed?" — *Connects the monthly reporting duty to the decisions it drives.*
- "How will the move from eight branches to five hubs change where complaints are raised and routed in 2027?" — *Uses the brief. Signals you've thought about the strategy at the level of the complaints process.*

**Round 3 (panel of branch managers)**
- "Where does the digital team's self-service plan touch complaints today?" — *Connects your answer on digital work (3.6) to something real. Shows you're thinking of the channel shift as a complaints question.*
- **Reciprocity:** "What could someone in this role do in their first month that would genuinely help your branches?" — *The panel are peers in the sense that matters: what the hire contributes to their work, not just what the candidate needs from them.*

Interviewer-path question: none included. There are no profiles for these interviewers yet, so a question tied to their own career path waits for the names (see the upgrade menu).

---

## 9. Prohibited claims

Built from the fit snapshot, before any bank was written. Nothing in the banks, guidance or reverse questions may assert, soften or imply these.

| Not coached | Basis | Honest form |
|---|---|---|
| "I owned the complaints process end to end." | Inflated form of F2. It widens "I handled the branch's formal complaints log" to the whole process. | The quote at its own scope: "I handled the branch's formal complaints log." Limit, as the pack's observation: your material shows the log, not the end-to-end process. Answer slot 2.9 stays inside the log. |
| "I've worked in a contact centre." | Stated negative, F2: "Never worked in a contact centre." | Plain acknowledgment: "I've never worked in a contact centre." No slot. |
| "I've presented to senior leaders or executives." | Stated negative, F8: "I've never presented to anyone above regional level." | Plain acknowledgment: "I've never presented to anyone above regional level." No slot. |
| "I built the bank's Excel or automated reporting." | Inflated form of F3 and F4. It widens "I built the monthly complaints spreadsheet" to a reporting system. | The quote at its own scope. The tool is asked only in the slot at 1.5 and 3.8. |
| "I coached supervisors on escalations." | Inflated form of F5. It widens "I trained new tellers on our escalation script" to supervisors. | The quote at its own scope: "I trained new tellers on our escalation script." |
| "The spreadsheet cut complaint volumes or resolution times." | An outcome nobody stated. It would be a figure with no quote behind it. Inflated form of F3. | The quote only: you built it, and your regional manager uses it. Nothing more. |

---

## 10. Sources and research accounting

**Provided documents (all from your message):**
- The JD text.
- The values page, as copied on 11 November 2026.
- The recruiter's email on the three rounds.
- Your summary of the July 2026 strategy brief. The brief itself was not in the conversation.
- Your background.

**Searches and fetches:** none sent.

**Research tier:** L1. Searches 0 of 6; fetches 0 of 2. Every target was already fixed by a provided input, so no call was sent.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | Values cheat sheet (§7). The four values are in your message, verbatim, so no search was needed. |
| 2. Interview process | skipped | Loop structure (three rounds, weights in §5). The recruiter's email gives the rounds and the scoring. |
| 3. Strategy / recent news | skipped | Grounding brief (§4). Your summary of the July 2026 brief is in hand. A later update would change it, and none was searched. |
| 4. Interviewer name | n/a | No names for the round 2 or round 3 interviewers. |
| 5. Representative JD | skipped | The JD you pasted fixes the fit snapshot and the JD-tagged questions. |

---

## 11. Upgrade menu

- **Names of the round 2 and round 3 interviewers** → persona weights from their public footprint, and a reverse question tied to their own career path.
- **The 2026 strategy brief itself** → grounding brief quotes checked against its exact wording, not your summary.
- **A complaint from your log that went outside the branch, or ran to a deadline** → resolves the answer slot at 2.3 and moves F7 from discovery to a stated fact.
- **The tool the complaints spreadsheet was built in, and its columns** → resolves the slots at 1.5, 3.8 and 3.9, and moves F4 from discovery to grounded.
- **Any work with a digital or systems team, or any complaint that crossed a handoff to another team** → resolves 3.6 and 2.1, and moves F6 from silence to evidence.
- **Deep research (L2): Ashgrove's current strategy and recent news, plus the interviewers' public talks.** Adds up to six searches and two fetches beyond this run. It adds a wait while it runs, and I'll state the time when it starts. Offered once.
