Web search is not permitted in this session (all four calls were refused), so the pack runs on your brief, the JD highlights and your research note. I'll write it now.
Your prep pack is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-alone-part-2-rooms-case-1-denied-2c352925/1ffd8941-1ac3-48f9-963c-faa08c63505a/scratchpad/northwind_senior-gtm-strategy-lead_interview_pack.md`.

Web search was refused in this session, so the pack rests on your brief, your JD highlights and your research note. The interviewer read is built from your note only, and the company values, loop and strategy are unverified. Those gaps are in the Sources and upgrade-menu sections.

The biggest risk is D1: the likeliest objection is that Priya has not owned a quota or sales motion. Rehearse the hold-then-concede answer until it is routine.

Say the word and I'll play the Skeptic on D1. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, and I can convert the pack to a Word document if you want one.

1. Does any gate apply to this role, such as work authorization, location or schedule? Your material doesn't say, so the pack surfaces it without bridging it.
2. Has Priya set quotas or run sales-ops work? Your note says no. She should confirm it in her own words before she rehearses D1 or E1.
3. Could you paste the full JD text? The fit rows currently quote your highlights, not the posting.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: northwind_senior-gtm-strategy-lead_interview_pack.md -----
# Interview pack: Senior GTM Strategy Lead, Emerging Products, Northwind Data

**Interviewer:** Dan Kovac, Director of Sales Strategy. **Relationship:** peer, same VP. **Format:** one 60-minute conversation.
**Candidate:** Priya.

## How to use this pack

- **Personas** describe how a question is asked. **Types** describe what it scores.
- Type key: **EXP** = your past work, tested for attribution. **JD** = the role's stated requirements. **CO** = company and strategy knowledge. **CASE** = a live problem. **VAL** = values; none is detected for this loop, so there is no values section.
- Question IDs are letter-by-persona: **A** Data-Driven Prober, **B** Peer Evaluator, **C** Case/Strategist, **D** Skeptic, **E** Pressure, **G** Conversational. (F is reserved for fit-snapshot rows.)
- Guidance is scaffolding, not a script. Rehearse what you actually did, in your own words.

## Fit snapshot

Requirements are the JD highlights you gave me, quoted as you supplied them. Evidence is quoted from your brief, which I call "coach's notes" below.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" (JD highlights, your note) | "built a partner-level revenue model used in carrier negotiations" (coach's notes) | medium | [grounded] | transferability | Your material shows a revenue model used in negotiations, not GTM strategy for a product line. Words: "I built a partner-level revenue model used in carrier negotiations." Answer slot: if you set go-to-market choices for any product line, say which and how you decided; if not, say so and describe the model's role. |
| F2 | "identify whitespace across land/adopt/expand/renew" (JD highlights, your note) | "built a partner-level revenue model used in carrier negotiations" (coach's notes) | low | [inferred] | discovery | The quote touches revenue, not the land, adopt, expand and renew stages. Answer slot: if you looked for whitespace across those stages, say which stage and how; if you did not, say so and say how you would find it first. |
| F3 | "run independent analysis in SQL and Tableau" (JD highlights, your note) | "skilled in SQL/Tableau" (coach's notes) | medium | [grounded] | none | The quote reaches the requirement. Words: "I'm skilled in SQL and Tableau." Expect a probe for one piece of analysis you ran end to end. |
| F4 | "partner-motion design experience required" (JD highlights, your note) | "built a partner-level revenue model used in carrier negotiations" (coach's notes) | medium | [grounded] | transferability | Transferable: partner economics in carrier negotiations. Not shown: designing a partner motion. Say the limit plainly: "The partner work I did was the revenue model; I have not designed a partner motion." |
| F5 | "strong cross-functional influence" (JD highlights, your note) | "set annual volume targets with cross-org consensus" (coach's notes) | medium | [grounded] | none | The quote reaches the requirement. Words: "I set annual volume targets with cross-org consensus." Expect a probe on who disagreed and how it was resolved. |
| F6 | "AI experience a plus" (JD highlights, your note) | "uses AI tools daily" (coach's notes) | low | [inferred] | transferability | Usage is not building AI products. Words: "I use AI tools daily." Do not stretch this into product work. |
| F7 | Headline figure on your material (no JD line) | "proposed a store-surface change credited with a ~$400M ARR uplift" (coach's notes) | medium | [grounded] | discovery | The figure is attributed to a proposal, not to you alone. Answer slots: how the uplift was counted, what it was sensitive to, the assumption you would defend least, and which part was yours. Words: "I proposed a store-surface change; it was credited with the uplift." |
| F8 | Location, work authorization, schedule (not in JD highlights) | none given | none | [generic] | hard_gate | Your material does not establish this. Surfaced, not bridged. See question 1 below. |
| F9 | Sales-ops and quota-setting (not a JD highlight; your note says none) | "No classic sales-ops or quota-setting experience" (coach's notes) | none | [grounded] | discovery | Pending your confirmation. Until you confirm it in your own words, the pack will not coach an answer about quotas or sales-ops. See question 2 below. |

**Confidence and gap rules applied:** a coach's-note sentence is treated as user-confirmed, not inspected, so every band is capped at medium. F9 is `none` until you confirm it, because I cannot treat a note as your own statement of absence.

## Prohibited claims

Built locally from the fit snapshot. Nothing below may be coached, implied or softened in any answer.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned GTM strategy for a product line | Inflated form of F1 (JD line widens your revenue-model sentence) | The F1 quote at its own scope. Your material says a revenue model, not GTM strategy. |
| Designed partner motions | Inflated form of F4 | The F4 quote at its own scope: partner economics in carrier negotiations. |
| Drove the ~$400M ARR uplift | Inflated form of F7 ("proposed" and "credited" become "drove") | The F7 quote at its own scope, with the attribution slot. |
| Built AI products or AI features | Inflated form of F6 ("uses" becomes "built") | "I use AI tools daily." |
| Set quotas or ran sales operations | Your note's negative, not yet confirmed by you (F9) | No coaching until you confirm it. Then: the plain acknowledgment in your own words, plus the nearest thing you did. |

## Interviewer read

Source: your note only. I could not verify any public footprint for Dan Kovac, because web search was refused in this session.

- **Career spine:** pricing and monetization roles, with one early-stage startup chapter (your note).
- **Self-described style:** "relentlessly data-driven" (your note).
- **Implications:** every metric you give will be tested for its inputs and denominators. Tilt case questions toward pricing, packaging and unit economics, which is his native language. Your partner-level revenue model is the strongest mirror: it sits in his domain.
- **Mirror opportunity:** a shared professional domain (revenue and monetization), paired with F1's quote. You share no startup chapter, so do not reach for one.

## Persona weights

| Persona | Weight | Depth | Reasoning |
|---|---|---|---|
| Data-Driven Prober | Top | 5 | Peer relationship prior, raised further by "relentlessly data-driven" and his pricing career. |
| Peer Evaluator | High | 4 | Peer prior; the seam between teams and the cross-functional influence requirement. |
| Case/Strategist | Mid | 3 | Pricing and packaging lean; whitespace and partner-motion problems. |
| Skeptic | Mid | 3 | Your two biggest gaps: GTM ownership and partner-motion design. |
| Pressure | Low | 2 | Peer rounds carry less stress-testing, but the $400M attribution will draw one. |
| Conversational | Low | 2 | Casual openers still score, and the reverse-question slot is weighted. |

**Loop:** no loop source establishes the rounds, so these weights rest on the peer relationship prior and your note's interviewer profile, not on a documented process. The fallback archetype is "generic," so no values round is detected.

**Total:** 19 questions, inside the 18 to 26 range.

## Question banks

**Highest-ROI prep:** question D1. Your gap is GTM ownership and quota-level experience, and it will come up in some form. Rehearse D1 until it is boring.

### A. Data-Driven Prober (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how you built the partner-level revenue model." | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" (coach's notes) | Story-mapped on F1: the model, and its use in negotiations, the beats the quote states. Answer slot: what inputs you chose and how you counted them. Name the weakest assumption you know before he does. | F1 is the strongest evidence on the partner and revenue requirements, and the likeliest probe. EXP tests what was yours. |
| A2 | "How was the ~$400M uplift counted, and what was it sensitive to?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (coach's notes) | Four defend-the-number slots, in your own words: how the figure was counted, what it was sensitive to, the assumption you would defend least, and which part was yours. If you do not know how it was counted, say so plainly. Do not invent a method. | F7 is a headline figure; a Prober will test it first. |
| A3 | "Which part of the volume targets was yours to set, and which was consensus?" | EXP | [grounded] "set annual volume targets with cross-org consensus" (coach's notes) | Answer slot: if you set the number, say which and how you decided. If the number was consensus, say so and describe your role in reaching it. Do not claim sole authorship. | F5 is a none-gap, but the probe on who set the number is still likely. |
| A4 | "Tell me about an analysis you ran in SQL and Tableau that changed a decision." | JD | [inferred] open prompt on JD "run independent analysis in SQL and Tableau" (JD highlights) | Selection scaffold: pick one analysis where you wrote the query and built the view yourself, and name the decision it moved. Answer slot: if no such analysis comes to mind, say so plainly, then give the nearest thing your material carries. | F3 is medium; this is where an independent-analysis claim gets tested. The question theme comes from the JD, not from a fact about you. |
| A5 | "How do you use AI tools day to day, and where have they been wrong for you?" | JD | [grounded] "uses AI tools daily" (coach's notes) | Say what you use them for, concretely. Do not describe building AI products (see prohibited list). Name one failure. | F6 is low confidence; the question tests usage honesty, not AI product work. |

### B. Peer Evaluator (4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our teams sit side by side. Where's the seam between revenue analysis and GTM, and what happens when we disagree?" | JD | [inferred] JD "strong cross-functional influence" (JD highlights) | Propose seam principles, not a map you do not know. Disagreement story: an open prompt. Selection scaffold: pick a disagreement you resolved with a peer, with a named stake and an intact relationship at the end. Say so plainly if none comes to mind. | Peer seam probes are the prior's native form. Cross-functional influence is a stated requirement. |
| B2 | "Who on the revenue side would you need to bring in first, and why them?" | JD | [inferred] JD "own GTM strategy for two new product lines" (JD highlights) | Name the roles, not individuals, and give a reason tied to a decision. Do not claim you have owned GTM for a product line (see prohibited list). | F1's requirement; tests whether you understand the coalition before you need it. |
| B3 | "How do you handle credit when GTM work spans our teams?" | JD | [grounded] "set annual volume targets with cross-org consensus" (coach's notes) | Answer with the consensus story in your own words: what you proposed, who shaped it, and how credit was shared. Do not overclaim the number. | Peer evaluators probe credit-sharing. F5 is your strongest collaboration evidence. |
| B4 | "If a partner's incentives pull against a direct land motion, what do you do?" | JD | [inferred] JD "partner-motion design experience required" (JD highlights) | Clarify before answering: which partners, which incentives, which stage. Give a method, not a claim about past partner design. Answer slot: if you have resolved partner-versus-direct conflict before, say how; if not, say so and say how you would frame it. The carrier negotiations are the nearest parallel, in your own words. | F4 is transferable; this tests the limit honestly. |

### C. Case/Strategist (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "An expansion motion stalls after land. Diagnose it. What do you need first?" | CASE | [inferred] JD "identify whitespace across land/adopt/expand/renew" (JD highlights) | Clarify the objective, then segment by stage (land, adopt, expand, renew), then the approach, then metrics and risks. Tilt toward pricing and packaging unit economics for this interviewer. The question is a live problem; it presupposes nothing about your past. | The JD's lifecycle requirement, delivered as a live problem; his native pricing language. |
| C2 | "Size the whitespace for one of two new product lines across land, adopt, expand and renew. What's your method?" | CASE | [inferred] JD "identify whitespace across land/adopt/expand/renew" (JD highlights) | Method first: the data you would need, the segmentation, the sizing approach, the check on it. Do not claim data access you do not have. Say how SQL would produce the inputs, if you would use it. | F2 is discovery; this question is where the whitespace gap gets made visible. |
| C3 | "How would you think about bundling by a much larger platform vendor against your product's pricing?" | CO | [grounded] "bundling by a much larger platform vendor" (your research note; unverified) | Structure the threat: who bundles, what the bundle costs the buyer, which segments it reaches first. Give one defensible response and name its risk. Do not state competitor facts you have not verified. | Your note names bundling as the main threat, and his pricing career makes this a natural probe. Unverified, so it stays generic in detail. |

### D. Skeptic (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "No classic sales-ops or quota-setting experience" (coach's notes, pending confirmation) | **Hold then concede.** Hold through two follow-ups: your nearest evidence is the revenue model and the volume-target consensus, both quoted. Concede specifically: name the sales-ops and quota work you have not done, and your ramp. Answer slot: if you have set quotas or run sales operations, say so; if not, say so plainly, then give your ramp plan. Never fold on the revenue model to restore harmony. | This is the highest-ROI prep. The likeliest objection is that you have not owned a quota or sales motion. A calm, specific concession changes the round. |
| D2 | "I don't see partner-motion design in your background. How would you handle it?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" (coach's notes) | Bridge: the carrier negotiation model at its own scope. Limit said plainly. Then a concrete ramp: what you would read, whom you would ask, what you would test first. | F4's gap. The question names the silence in your material, which the interviewer will raise anyway. |
| D3 | "Your numbers come from a large consumer-tech company. Why would they hold in B2B data infrastructure?" | EXP | [grounded] "9 yrs product strategy & ops at a large consumer-tech company" (coach's notes) | Say what transfers (revenue modeling, partner economics, volume targets) and what does not (enterprise sales cycles, expansion, renewal). Name the difference before he does. | Transferability is the skeptic's cross-examination of the whole CV. |

### E. Pressure (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who has run quota before?" | JD | [grounded] "set annual volume targets with cross-org consensus" (coach's notes) | **Hold then concede.** Hold on the volume-target work and the revenue model. Two follow-ups. Concede the quota experience you lack, specifically. Never claim quota work. | The stress form of D1, time-boxed. |
| E2 | "That $400M. How much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (coach's notes) | **Hold then concede.** Hold the proposal; concede the credit specifically. "I proposed the change; the credit was shared." Do not restore harmony by inflating your share. | F7's attribution probe, in its stress form. |

### G. Conversational (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" (coach's notes) | Casual register, scored. Two concrete uses, in your words. No product claims. | F6, asked casually. |
| G2 | "So, walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm" and "9 yrs product strategy & ops at a large consumer-tech company" (coach's notes) | A 90-second arc: two years of consulting, then nine years of product strategy and operations at a large consumer-tech company, ending on the revenue model. Tell it in your words. | Rapport openers are scored; the arc is the answer to the biography question. |

### Requirement coverage

| JD requirement | Covered by | Notes |
|---|---|---|
| Own GTM strategy for two new product lines | A1, B2, C2, D1 | F1 is transferability, not capability |
| Whitespace across land/adopt/expand/renew | C1, C2 | F2 is discovery |
| Independent analysis in SQL and Tableau | A4, A1 | F3 is none-gap |
| Partner-motion design required | B4, D2 | F4 is transferability |
| Strong cross-functional influence | B1, B3, A3 | F5 is none-gap |
| AI experience a plus | A5, G1 | F6 is low confidence |
| Gates: location, work authorization, schedule | Question 1 | Not in your JD highlights; asked, not bridged |
| Headline figure (no JD line) | A2, E2 | F7 |

**Coverage check:** all six JD highlights have at least one question.

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Your path runs from pricing and monetization into sales strategy. What has been hardest to carry across?" | Ties to his own career path. It turns a probe into a peer conversation. |
| R2 | "Where does the Compass launch put the most pressure on the sales motion?" | Uses your research note's priority. Unverified, so ask it as a question, not as a fact. |
| R3 | "How is the bundling threat showing up in deals today?" | Tests whether the threat is live in pipeline or only in strategy. |
| R4 | "What could a new peer do in the first month that would genuinely help your team?" | Reciprocity: required for a peer round. |
| R5 | "How does Northwind define profitability for the emerging lines, and which metric carries the bar?" | Connects to your note's third priority and shows you read the company's numbers. |

## Prohibited claims (repeat check)

No answer, bridge, reverse question or rationale in this pack asserts any entry above. Confirm F9 before you rehearse D1 or E1 in your own words.

## Sources

**Provided documents:** your brief (coach's notes); your JD highlights (not the full JD text); your research note (company priorities: enterprise expansion, the Compass copilot launch, reaching profitability; main threat: bundling by a much larger platform vendor); your interviewer profile note (Dan Kovac).

**Research tier:** L1 — searches 4 of 6, fetches 0 of 2; user links read 0.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Northwind Data values | unavailable | Values cheat sheet. No values round is detected for this loop, so nothing is lost. |
| 2. Northwind Data interview process, sales strategy | unavailable | Loop structure. Persona weights rest on the relationship prior, not a documented loop. |
| 3. Northwind Data strategy / recent news | unavailable | Grounding brief and CO bank. Questions C3, R2 and R3 rest on your research note, not on a current source. |
| 4. Dan Kovac, Northwind Data | unavailable | Interviewer public footprint. The interviewer read is built from your note only. |
| 5. Representative Senior GTM Strategy Lead JD | skipped | Your JD highlights fix the fit snapshot and the JD-tagged questions. |

**Searches sent, all refused by the host:** "Northwind Data company values"; "Northwind Data interview process sales strategy"; "Northwind Data strategy news"; "Dan Kovac Northwind Data Director of Sales Strategy."

**Dossier:** none consumed.

## Upgrade menu

- The full JD text → turns F1 through F6 from highlight quotes into full requirement quotes, and firms up the JD-tagged questions.
- Your confirmation of F9 in your own words → unlocks a plain acknowledgment for D1 and E1, and the quota-level answer slots.
- Your recruiter's guidance (focus areas, process) → the loop structure, so the persona weights stop resting on the relationship prior alone.
- Dan Kovac's public talks or writing → the interviewer read, the persona weights, and reverse questions tied to his recurring themes.
- A recent strategy brief or a pasted Compass source → C3, R2 and R3 grounded instead of unverified.
- A deeper research pass (L2) → up to 6 more searches and 2 more fetches, several minutes. Offered once; say the word if you want it. Note that web search was refused this session, so it may fail here too.
