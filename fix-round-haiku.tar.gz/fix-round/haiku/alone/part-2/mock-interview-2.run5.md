Your prep pack is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-alone-part-2-rooms-case-2-denied-e82532d5/2a637f40-b896-4a6e-be6e-dcc33806dbde/scratchpad/atlas-freight_operations-manager_interview_pack.md`. I built it as a hiring-manager round, since your note didn't say who you're meeting. The persona weights would change if it's a peer or a panel.

The pack's main finding is that the JD's scope is far above your current scope: one site and three supervisors against four sites and twelve. Start there.

- **Highest-ROI prep, B2:** "You've run a shift over three supervisors. Why would that prepare you for four sites and twelve?" Concede the scale gap plainly, then hold on the pick-path result, and say how you'd learn the four sites as a plan.
- **Power BI:** say "I haven't used Power BI" and move to a learning plan. Don't describe a Power BI project.
- **The 40%:** be ready to say how it was counted and whose part it was. The pack gives you no baseline, so if you don't know how it was counted, say so.
- **Green Belt:** the probe will be how you applied it (C1). Name a project only if you ran one.
- **Five years of leadership (B3):** you need to say how many of your seven years were in a supervisory or leadership role.

The pack has 18 questions across five personas, a fit snapshot, a list of claims not to coach, six reverse questions, and a requirement-coverage table. I did no company research, as you asked, so there's no values section, interview-process detail, or strategy brief.

Would you like me to play the Skeptic on B2 in a live drill? I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

1. Is the person you're meeting your future manager, a peer, or on a panel? Is it a screen or the full loop?
2. Does the role require a fixed site location, a shift pattern, or travel across the four sites? The JD doesn't say, and any of those could be a hard gate.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: atlas-freight_operations-manager_interview_pack.md -----
# Interview prep pack: Operations Manager, Atlas Freight

Interviewer: not known. Round type: not known. Built as a hiring-manager round (Case/Strategist and Skeptic weighted highest), because the JD's team scope points to one. Change this if you know otherwise; the weights move (see the persona table).

## How to use this pack

- **Personas** describe how a question arrives (its delivery). **Types** describe what is being scored.
- Type key: **JD** = stated responsibility or qualification. **EXP** = your past work, tested for attribution. **CASE** = live problem from the role. **CO** = company knowledge (none included: no research ran). **VAL** = values (none included: no published values in hand).
- Guidance is scaffolding, not a script. Rehearse what you actually did, in your own words.

## Fit snapshot

Requirements are quoted from the JD you pasted. Evidence is quoted from your message ("your message"). Nothing else is claimed about you.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" (JD) | "currently a senior shift manager over 3 supervisors" (your message) | medium | [grounded] | transferability | Your material shows one site's shift, not four terminals. Say it at that scope: "I run a shift at one site." Answer slot: if you have run or covered any second site, say how; if not, say so and describe your first 90 days. |
| F2 | "lead a team of 12 supervisors" (JD) | "currently a senior shift manager over 3 supervisors" (your message) | medium | [grounded] | transferability | Three supervisors is the adjacent scope, four times smaller. Do not stretch it. Say the number and what you do with it. Answer slot: if you have led supervisors through a layer above you, or across sites, say how; if not, say so. |
| F3 | "drive on-time performance and cost-per-shipment down" (JD) | "cut mis-pick rate 40% by redesigning the pick path" (your message) | medium | [grounded] | transferability | The result is accuracy, not on-time performance or cost. Say it at its own scope. Its baseline and counting method are not in your material, so expect a probe (see C2). |
| F4 | "5+ years operations leadership required" (JD) | "7 years in warehouse and distribution ops" (your message), "currently a senior shift manager over 3 supervisors" (your message) | low | [grounded] | discovery | Seven years of operations is shown. Leadership years are not. This is not a gate, so it is graded on fit, not treated as a dealbreaker. Answer slot: say how many of your seven years had a supervisory or leadership role, in your own words. |
| F5 | "Lean/Six Sigma a plus" (JD) | "green belt certified" (your message) | medium | [grounded] | none | The certification reaches the requirement. Expect a probe on how you applied it (C1). |
| F6 | "build reporting in Excel/Power BI" (JD), Excel part | "solid Excel" (your message) | low | [grounded] | discovery | Excel skill is stated. Building reporting others use is not. Answer slot: if you have built a report people relied on, name it; if not, say which Excel skills are solid. |
| F7 | "build reporting in Excel/Power BI" (JD), Power BI part | "never used Power BI" (your message) | none | [grounded] | capability | A gap you stated. Words: "I haven't used Power BI." Then how you would learn it, as a plan and never as a past. |
| F8 | Peak and volume planning (not a JD line; from your message) | "ran the site's peak-season surge plan two years running" (your message) | medium | [grounded] | none | Reaches on-time performance under volume. Story beats are the sentence's own: you ran it, two years running. Answer slot on your role in setting the numbers (A4). |

**Gates:** none in the JD text. Possible gates are site location, shift pattern, and travel across the four sites. Your material does not say whether these are fixed. Step 1 asks about it.

## Prohibited claims

Not to be coached in any answer, slot, or bridge. Each is the wording that stretches a sentence you did say.

| Not coached | Basis | Honest form |
|---|---|---|
| Ran operations across four sites | Inflated form of F1 | "I run a shift at one site." Your material says one site's shift. |
| Led twelve supervisors | Inflated form of F2 | "I run three supervisors." |
| Drove on-time performance or cost-per-shipment down | Inflated form of F3 | "I cut mis-pick rate 40% by redesigning the pick path." Stop there. |
| Built Power BI reporting, or built dashboards | Inflated form of F6 and F7 | "I haven't used Power BI." For Excel, only what you have built. |
| Led a Six Sigma or Lean project | Inflated form of F5 | "I'm Green Belt certified." Name a project only if you ran one. |
| A baseline or counting method for the 40% | Not in your material | Your answer to the C2 slot, in your own words. The pack will not supply it. |

## Persona table

| Persona | How it shows up here | Likelihood (reasoning) | Weight | Counter-strategy |
|---|---|---|---|---|
| Case / Strategist | Live ops problems from the JD: four sites, on-time, cost | High: a hiring manager buys capability and tests it live | 5 | Clarify, then structure: objective, segment by site or shift, metric, risk |
| Skeptic | Probes the scope gap (3 to 12, 1 to 4) and the Power BI gap | High: the JD's scope is far above your current scope | 4 | Hold the one objection you know will come. Concede scale specifically. |
| Data-Driven Prober | Counts and assumptions behind the 40% and the Green Belt | High: the 40% is the one number on your material | 4 | Say how it was counted only if you know. Name the weakest assumption first. |
| Pressure | Composure: "why you over someone with twelve?" | Medium: common when the scope gap is visible | 3 | Pause, restate, hold through two follow-ups, then concede the specific gap |
| Conversational | Journey question; casual Excel and Power BI | Medium: opening questions are scored too | 2 | A 90-second arc from your quotes. Treat casual questions as scored. |

Total: 18 questions. Depth follows weight.

## Question banks

**Highest-ROI prep: B2.** It is the objection the JD makes almost certain: your scope is one site and three supervisors, and the role is four sites and twelve. Rehearse it until a non-defensive answer is boring.

### A. Case / Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You take over daily operations across four terminals. What do you look at first, and why?" | CASE | [grounded] "Own daily terminal operations across 4 sites" (JD) | Clarify the scope and baseline. Segment by terminal, then shift. Pick two metrics (on-time, cost per shipment) and a daily rhythm: exception review, then escalation. Name one risk per terminal. No claim about your past. | The JD's headline line is the likeliest case. CASE because it is a live problem, not a record. |
| A2 | "On-time performance dropped at one terminal over three weeks. Diagnose it." | CASE | [grounded] "drive on-time performance and cost-per-shipment down" (JD) | Clarify the window and what changed. Split by lane, dock, shift, and volume. Test labour against volume before anything else. Hypothesis first, then the check that kills it. | A direct test of the JD's first metric. The case is hypothetical, so it presupposes nothing about you. |
| A3 | "Cost per shipment is up 6% quarter over quarter. Where do you look?" | CASE | [grounded] "drive on-time performance and cost-per-shipment down" (JD) | Define the denominator first. Split cost into labour, overtime, space, rework, and volume mix. Say which you would check this week. | Tests the second metric. The 6% is the interviewer's hypothetical, not a fact about the company. |
| A4 | "Peak is six weeks away and volume is forecast up 30%. Walk me through your plan." | CASE, EXP | [grounded] "ran the site's peak-season surge plan two years running" (your message) | Story beats are the sentence's: you ran the plan, two years running. Answer slot: if you set the staffing numbers, say how; if the plan was set above you, say so and describe your part in it. | F8 is your strongest evidence for volume planning. It is also where a probe on your role will land. |
| A5 | "What would you need from HR and finance to hit the cost target across four sites?" | JD | [generic] | Name the three inputs you would ask for and why: headcount approval, cost data, and a decision owner for shift changes. No claim about your past. | Tests scope thinking. Generic because it is a pattern for the role, not a fact about the company. |

### B. Skeptic (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You run a shift over three supervisors. How would you lead twelve across four sites?" | JD | [grounded] "lead a team of 12 supervisors" (JD); "currently a senior shift manager over 3 supervisors" (your message) | Name the scale gap first. Then say what you would do in the first 90 days: meet all twelve, learn each site, agree one shared metric. Answer slot: if you have led supervisors across sites or through a layer above you, say how; if not, say so plainly and stay with the plan. | F1 and F2 are the evidence. The question's premise is your three supervisors, which is quoted, so it is lawful. |
| B2 | "You've run a shift over three supervisors. Why would that prepare you for four sites and twelve?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" (your message); "lead a team of 12 supervisors" (JD) | **Highest-ROI.** Concede the scale specifically: "I haven't run four sites or twelve supervisors." Hold the one thing your material shows: "I redesigned the pick path and cut the mis-pick rate 40%." Hold through two follow-ups by returning to that, never by adding to it. Then the honest bridge: how you would learn the four sites, in your own words. | F1 and F2 are where this objection lands. Deepest rehearsal because it is the most likely question and the one most tempting to inflate. |
| B3 | "Five years of operations leadership is the bar. Where does your leadership time sit?" | JD | [grounded] "5+ years operations leadership required" (JD); "7 years in warehouse and distribution ops" (your message) | Answer slot: say how many of your seven years had a supervisory or leadership role, in your own words. If the number is under five, say so and say which part of your operations record is leadership. | F4 is a discovery gap. Not a gate, so the answer is fit, not a yes or no. |
| B4 | "What part of this role would you be weakest at on day one?" | JD | [grounded] "build reporting in Excel/Power BI" (JD); "never used Power BI" (your message) | Name Power BI plainly: "I haven't used Power BI." Then your learning plan, as a plan. Do not describe a Power BI project. | F7 is a capability gap you stated. The plain acknowledgment is yours. |

### C. Data-Driven Prober (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "What does Green Belt mean to you in an operations role, and where have you applied it?" | JD | [grounded] "green belt certified" (your message); "Lean/Six Sigma a plus" (JD) | Open prompt. Say the certification and what it taught you. Answer slot: if you applied the method on a project, name the tools and your part. If not, say so and name the nearest thing your material carries: the pick-path work, but only if you used a method there. | F5 is met by the certificate. The probe is what you used it for. |
| C2 | "Your mis-pick rate fell 40%. Walk me through how you counted it." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Defend the number. Answer slot: how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. If you do not know how it was counted, say so. | F3 is a figure, so its counting is a probe. The pack supplies no baseline. |
| C3 | "Tell me about a spreadsheet you built that people relied on." | JD | [grounded] "solid Excel" (your message) | Open prompt. If you built one, name it and what it fed. If you have not built reporting others relied on, say so, and say which Excel skills you are solid on. | F6 is discovery: Excel is stated, reporting is not. Gives you the honest version before the probe. |
| C4 | "How would you build an on-time performance dashboard in Power BI?" | CASE | [grounded] "never used Power BI" (your message) | Plain acknowledgment: "I haven't used Power BI." Then describe the approach as a plan: data source, refresh, owner, who reads it. No past claim. | F7. A plan is a strong answer when the gap is stated. |

### D. Pressure (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over someone who has led twelve supervisors?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" (your message); "ran the site's peak-season surge plan two years running" (your message) | Pause. Concede the scale gap in one sentence. Hold the fit with the quotes: you ran the peak plan two years running and cut the mis-pick rate 40%. Stop there. | Tests composure. Hold, then concede. The held position is only what the quotes carry. |
| D2 | "That 40%. How much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Answer slot: if you designed the redesign, say so and say how. If others executed or approved it, name them. Do not claim the crew's work as yours, or the reverse. | A limit probe. Honest answers are the strongest answers here. |
| D3 | "Peak always breaks something. What broke on yours, and who paid for it?" | EXP | [grounded] "ran the site's peak-season surge plan two years running" (your message) | Open prompt. If something went wrong, say what and what you did. If nothing failed, say so; do not invent an incident. | Tests whether you will fabricate a failure to sound credible. The pack will not supply one. |

### E. Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | JD | [grounded] "7 years in warehouse and distribution ops" (your message); "green belt certified" (your message); "cut mis-pick rate 40% by redesigning the pick path" (your message) | Ninety seconds, chronological. Seven years in warehouse and distribution, now a senior shift manager over three supervisors, the pick-path result, the peak plan, the Green Belt. Each beat is one of your sentences. | Scored even in casual register. Pre-scripted arc. |
| E2 | "What are you playing with in reporting these days?" | JD | [grounded] "solid Excel" (your message); "never used Power BI" (your message) | Excel: solid, and say which parts. Power BI: "I haven't used it yet." Then the plan to learn it. | Casual, but scores the Excel and Power BI requirement. Do not oversell. |

### Requirement coverage

| JD requirement | Covered by | Gap |
|---|---|---|
| Own daily terminal operations across 4 sites | A1, B1, B2 | None |
| Drive on-time performance and cost-per-shipment down | A2, A3, E1 | None |
| Lead a team of 12 supervisors | B1, B2, D1 | None |
| Build reporting in Excel/Power BI | C3, C4, B4, E2 | None |
| 5+ years operations leadership required | B3 | None |
| Lean/Six Sigma a plus | C1 | None |

## Reverse questions

Each "why it lands" is a reason to ask it, not a claim about the company.

1. "What does on-time performance look like at your weakest terminal, and what has already been tried?" Why it lands: it shows you are already thinking about the problem.
2. "How are the twelve supervisors set up across the four sites today?" Why it lands: it shows you know the scope is the real job, and asks how it is organised.
3. "Who builds the operations reporting today, and what does the leadership team read each week?" Why it lands: it reveals the Power BI picture and shows you care about it.
4. "What would make this role a success at 90 days?" Why it lands: it turns the interview toward the criteria they will score you on.
5. "What is the biggest operational constraint the company is trying to fix this year?" Why it lands: it shows you are listening for priorities.
6. "How is this role measured against the site leaders?" Why it lands: it tests where the role's authority ends, a question an experienced candidate asks.

## Sources

- Provided documents: the JD text and your background, both in your message. No CV was provided.
- Research tier: L0. No searches and no page fetches. You did not ask for company research, and the company's values, strategy, and interview process were not searched.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Atlas Freight values | unavailable | Values cheat sheet (section omitted: no values in hand, not detected) |
| 2. Atlas Freight interview process, operations | unavailable | Loop structure and persona weights (round type unknown, so weights are a prior) |
| 3. Atlas Freight strategy / recent news | unavailable | A grounding brief for the case questions (A1 to A3 are generic to the JD) |
| 4. Interviewer name and Atlas Freight | n/a | No interviewer name given. Interviewer read omitted. |
| 5. Representative operations manager JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The interviewer's name → a tailored reverse question, the interviewer read, and persona weights from their public footprint
- The round type and who you meet → persona weights rebuilt for that round
- Confirmation of site location, shift pattern, and travel across the four sites → a hard-gate check, if any apply
- Company research at L1 (values, interview process) → a values section if they publish values, and a loop structure
- Your CV → fit rows F1 to F8 graded on the actual document, not your message
- The recruiter's note on focus areas or a pre-declared exercise → coverage of any graded deliverable
