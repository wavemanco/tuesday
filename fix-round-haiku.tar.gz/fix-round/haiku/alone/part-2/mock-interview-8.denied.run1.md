Your prep pack is saved as `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-alone-part-2-rooms-case-8-denied-103350e1/9a364ac9-6d8c-452f-a1db-dd59d2b203a4/scratchpad/ashgrove_member_experience_lead_interview_pack.md`. It's built on the three rounds as the recruiter described them, and on your message as the only source for your background, since I haven't seen a CV.

The two gaps you named, contact centre and senior presentation, are stated absences. So the pack gives you a plain acknowledgment plus a plan for each, not a story. B1 is the highest-return prep: the contact-centre objection. C1 is the 20-minute escalation case, with a timed plan.

Say the word and I'll run a live drill of C1 with the Round 3 panel, with follow-ups that react to what you say. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, to carry into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove_member_experience_lead_interview_pack.md -----
# Member Experience Lead — Ashgrove Credit Union: interview prep pack

**Role:** Member Experience Lead
**Company:** Ashgrove Credit Union (member-owned, about 900 staff)
**Candidate:** Dara (pronouns not given; this pack uses they/them)
**Interviewers:** Round 1, recruiter (30 min). Round 2, Head of Member Services, your future manager (45 min, mostly behavioural). Round 3, panel of two branch managers (60 min, includes a 20-minute complaint escalation case, scored against the four values). All three on 20 November. Names not yet assigned.
**Changelog:** first version.

---

## How to use this pack

Personas describe how a question arrives: the tone, the pressure, who is asking. Types describe what is being scored. Guidance is scaffolding for a spoken answer, not a script. Where the guidance rests on something you said, the quote is shown in the row. Where it does not, the row says so.

| Tag | Name | What it scores |
|---|---|---|
| VAL | Values and behaviour | Whether past behaviour shows the published values |
| EXP | Experience deep-dive | Whether your claims hold up, and what you personally did |
| JD | Role requirement | Whether you can do the listed job, gaps included |
| CO | Company and strategy | Whether you know where Ashgrove is heading |
| CASE | Live problem | Structure and reasoning on a problem from the role |

Provenance labels: **[grounded]** traces to a document you gave me or something you said. **[inferred]** is my derivation, with the basis named. **[generic]** is a pattern for the problem, not a fact about you or Ashgrove.

---

## Fit snapshot

Requirements are quoted from the job description you supplied. Evidence is quoted from what you wrote to me. I have not seen your CV, so every evidence quote comes from your message, and these are the only sentences the pack says about your past.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor" — your message | medium | [grounded] | presentation | Your words give the years in retail banking. Say them in those terms: six years in retail banking, the last three as a branch supervisor. Medium because nothing has been inspected yet. |
| F2 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | transferability | A formal complaints log is adjacent work. Your message does not show it was the regulated part. Words stay with the log: "I handled the branch's formal complaints log." Answer slot: if that log carried regulatory timescales or reporting duties, say which and how you tracked them; if it did not, say so plainly and say what it did do. |
| F3 | "Own the member complaints process end to end across branches" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | transferability | The log is one branch's. Your words stay there: "I handled the branch's formal complaints log." Answer slot: which parts of the route a complaint took were yours to decide, and which were set by others; if none were yours, say so and stay with the log. |
| F4 | "and the contact centre" — JD | "Never worked in a contact centre" — your message | none | [grounded] | capability | A stated absence. Words: "I've never worked in a contact centre." Then a plan, said as a plan: how you would learn the centre's complaint routes first. Never a claim about past work. |
| F5 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | discovery | Volumes are in the quote's terms: a monthly complaints spreadsheet. Resolution times are not in it. Answer slot: if the spreadsheet tracked how long complaints took, say how the clock started and stopped; if it did not, say so. |
| F6 | "coach branch supervisors on escalations" — JD | "trained new tellers on our escalation script" — your message | medium | [grounded] | transferability | Teller training is adjacent to coaching supervisors. Words: "I trained new tellers on our escalation script." Answer slot: if you coached a supervisor or anyone else on an escalation, say what you did; if you did not, say so and say how you would start. |
| F7 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material is silent on this. Answer slot: if you have worked with anyone building a digital or self-service journey, say what your part was; if you have not, say so and say what you would look at first. |
| F8 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level" — your message | none | [grounded] | capability | A stated absence. Words: "I haven't presented to anyone above regional level." Then a plan: how you would prepare for a senior audience, said as a plan. |
| F9 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | presentation | The quote reaches the requirement in other terms: a spreadsheet you built. The word Excel does not appear in your message. Bring the spreadsheet, anonymised, and this row becomes inspectable. |

Gate check: none of the eight requirements is a licence, credential or legal term, so none is a hard gate. Years and skill lines are graded on fit and gap.

---

## Prohibited claims

Built locally from the fit snapshot. Nothing in this pack asserts, softens or implies any entry below.

| Not coached | Basis | Honest form |
|---|---|---|
| "I have worked in a contact centre" | Contradicts your stated absence (F4) | "I've never worked in a contact centre." |
| "I have presented to senior leaders" | Contradicts your stated absence (F8) | "I haven't presented to anyone above regional level." |
| "I owned the member complaints process end to end" | Inflated form of F3 | Your quote at its own scope: "I handled the branch's formal complaints log." Limit, in this pack's analysis: your material says the branch log, not the process. |
| "I led coaching of branch supervisors" | Inflated form of F6 | Your quote at its own scope: "I trained new tellers on our escalation script." |
| "The spreadsheet reached senior leadership" | Inflated form of F5 and F9 | Your quote at its own scope: a spreadsheet your regional manager uses. Limit, in this pack's analysis: your material names the regional manager as its user and nobody wider. |

---

## Persona weights

Relationship priors set the start: a recruiter screen leans conversational, a manager round leans case and skeptic, a values panel leans behavioural. Your interviewer roles adjust them. No interviewer names or public profiles exist yet, so the interviewer read is omitted.

| Persona | How it shows up here | Likelihood | Reasoning | Counter-strategy and questions |
|---|---|---|---|---|
| Values / Behavioral | Round 2 is mostly behavioural. Round 3 scores the four values. | High | The recruiter says the panel scores against the values, and Round 2 is behavioural by design. | Story-map where a quote carries a story; otherwise a selection scaffold ending in the honest branch. A1, A2, A4, A5, A6. Depth 5. |
| Skeptic | The manager tests the gaps: contact centre, senior presentation, regulated complaints. | High | F4 and F8 are stated absences, and the JD names both. This persona will find them. | Rehearse B1 until it is boring. Acknowledge the absence in plain words, then a plan. B1 to B4. Depth 4. |
| Case / Strategist | The Round 3 escalation case, plus strategy questions about digital and branch change. | High | Round 3 includes a 20-minute case. The strategy brief supplies the material. | Clarify first, then structure, then act. Think aloud. C1 to C3. Depth 3. |
| Pressure / Stress | Composure challenges, especially on presenting to senior people and on how much of the spreadsheet was yours. | Medium | Not announced. It is a common prior for senior-facing rounds. | Pause, restate, hold through two follow-ups, then concede specifically. D1 to D3. Depth 3. |
| Data-Driven Prober | How the monthly figures were counted. | Medium | F5 and F9 are your headline reporting claims. Branch managers often read the numbers. | Name how it was counted, what it was sensitive to, and which assumption you would defend least. Say plainly when you do not know. E1 to E3. Depth 3. |
| Conversational | The recruiter round. | Low | Round 1 is a screen. The risk is treating it as unscored. | A 90-second arc. Treat casual questions about the digital role as scored. F1 to F2. Depth 2. |
| Peer Evaluator | The branch managers on the panel are future peers across the branches. The seam between branch and contact centre is the topic. | Low | The panel is branch managers. Their concern is the handoff. | Propose seam principles rather than pretending to know the seam. G1 to G2. Depth 2. |

---

## Question banks

Ordered by weight. Provenance comes first and carries every sentence the guidance rests on.

### A. Values / Behavioral (depth 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Tell me about a complaint you took from start to finish. What did the member need from you?" | VAL | [grounded] "I handled the branch's formal complaints log" — your message | Story-mapped on F3. Tell one case from the log in your own words: what came in, what you did with the entry, what the member received back. Answer slot: if you changed the outcome for the member, say what changed; if the log was a records step and you did not decide the outcome, say so and say what you did decide. | Tests Members First. F3 is the evidence for the end-to-end requirement, so it is where a probe will land. |
| A2 | "Tell me about a time you helped a colleague get better at handling an escalation." | VAL | [grounded] "trained new tellers on our escalation script" — your message | Story-mapped on F6. Name who you trained, how you taught the script, and what you watched for when they used it. Answer slot: if the training changed how someone handled a member, say how you saw it; if you did not see it land, say so. | Covers the coaching requirement through the nearest thing your words carry. Plain Words is tested here too. |
| A3 | "Tell me about a problem you noticed that nobody had asked you to fix, and how you kept hold of it." | VAL | [generic] | Scaffold: pick a problem you found, a stake it carried, a moment you did not let it drop, and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. Your message carries no sentence for this, so do not borrow one. | Tests Own the Fix. An open prompt: the theme comes from the published value, and the instance is yours to choose. |
| A4 | "If a member needs something explained twice, what do you do differently the third time?" | VAL | [grounded] "if a member needs it explained twice, we wrote it wrong" — published values, pasted | Scaffold: name a time a member came back for the same explanation and what you changed in how you explained it. Honest branch: if no such time comes to mind, say so, then say how you would handle it. The published line is the company's; it is not your claim. | Tests Plain Words in the panel's own language. |
| A5 | "Tell me about a complaint where the branch's place in its town mattered to how you handled it." | VAL | [grounded] "every branch is part of its town" — published values, pasted | Scaffold: pick a complaint where something local, such as a known family, a closure, or a community concern, changed the handling. If no such time comes to mind, say so plainly, then say how you would weigh a local concern against a number. | Neighbours, Not Numbers is the value a spreadsheet-builder is most likely to be tested on. |

### B. Skeptic (depth 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The complaints process runs through the contact centre as well as the branches, and you've never worked in one. What makes you credible running it?" **Highest-ROI prep in this pack.** | JD | [grounded] "Never worked in a contact centre" — your message; [grounded] "and the contact centre" — JD | Hold, then concede. Acknowledge first: "I've never worked in a contact centre." Then the nearest thing your material carries: the complaints log you handled in a branch, and what that taught you about how a complaint reaches a person. Hold through two follow-ups by returning to the log. Concede specifically: "I don't yet know the centre's routing or its volumes." Then a plan: how you would learn the routes in your first month. Do not offer any contact-centre experience. | This is the single most predictable objection. F4 is a stated absence, so the honest answer is the acknowledgment and the plan, not a story. |
| B2 | "What did 'formal complaint' mean in your branch's log, and what rules governed how it was handled?" | JD | [grounded] "I handled the branch's formal complaints log" — your message; [grounded] "experience handling regulated complaints" — JD | Story-mapped on F2 and the log. Say what counted as formal and who set the handling rules. Answer slot: if the log carried regulatory timescales or reporting duties, say which and how you tracked them; if it did not, say so plainly and say what the log did do. | Regulated complaints is the JD's exact phrase. The answer must stay at the scope of the log. |
| B3 | "You haven't presented above regional level. This panel is senior. How do you hold a room you haven't held before?" | JD | [grounded] "I've never presented to anyone above regional level" — your message; [grounded] "confident presenting to senior leaders" — JD | Plain acknowledgment: "I haven't presented to anyone above regional level." Then a plan: how you would prepare, what you would show, who you would rehearse with. Answer slot: if you walked your regional manager through the spreadsheet, say what they did with it; if you did not present it, say so. | F8 is a stated absence. The plan is the answer, and the rehearsal is the preparation. |
| B4 | "Why this role, and why now, given the contact-centre and senior-presentation parts are new to you?" | JD | [grounded] "Never worked in a contact centre" — your message; [grounded] "I've never presented to anyone above regional level" — your message | Your reasons, in your words. Name what draws you to the complaints work itself, not to the title. Do not pad the reasons with experience you do not have. | Tests motivation consistency. The skeptic is checking whether the reasons survive the gaps. |

### C. Case / Strategist (depth 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A member complained at a branch about a charge. The branch resolved it. The member then phoned the contact centre to say the branch had given the wrong reason, and now says they will take it to the regulator. Walk us through how you'd handle it, and what you'd fix afterwards." | CASE | [generic] | **Escalation case drill, 20 minutes.** This is a rehearsal scenario, not the panel's actual case. Use it with a timer. Minutes 0 to 3: clarify. What does the member want? What does the branch record say? What does the contact-centre note say? Could a regulatory clock have started? Minutes 3 to 6: structure. Two problems: the member's fix, and the seam that gave the wrong reason. Name one owner for each. Minutes 6 to 14: act. One named owner who keeps hold until it is solved (Own the Fix). One call back to the member, in plain words (Plain Words). Check the branch record against the contact-centre note. Take the regulatory question to whoever owns compliance; say you would check, not what the rule says. Minutes 14 to 18: the supervisor. Coach on what was said and why. Name the routing problem. Minutes 18 to 20: the fix. Say what you would count in the monthly report, such as wrong-reason complaints, and how you would count them. Do not claim contact-centre or regulator experience. Say you would learn the centre's routes. | Round 3 is scored on the values, and this case tests the seam the JD names. It is generic because nothing you wrote describes an escalation of this shape. |
| C2 | "Ashgrove plans to move 40% of member service to digital channels by 2028 and consolidate eight branches into five hubs over 2027. What happens to complaints during that change?" | CO | [grounded] "move 40% of member service to digital channels by 2028" — strategy brief, as supplied; [grounded] "consolidate eight branches into five hubs over 2027" — strategy brief, as supplied | Think aloud at the company's altitude. Name where complaints volume is likely to move during the change. Name the risk of a member losing their route in. Name one measure you would watch. Do not say which branches are on any list, and do not characterise the plan as good or bad. If you have not seen the plan, say so and say you would want to see it. | The strategy is published. Branch managers on the panel may run branches in scope, so this is the most sensitive question in the pack. |
| C3 | "Our main competitive pressure is app-only banks. How would you judge whether a self-service journey is working for a member who has a complaint?" | CO | [grounded] "the main competitive pressure is app-only banks" — strategy brief, as supplied; [grounded] "work with digital teams on self-service journeys" — JD | Answer slot tied to F7: if you have worked on a digital or self-service journey, say what your part was; if not, say so, and then say what you would measure first: whether a member got the answer without a call, and whether they came back. | F7 is silent in your material. The honest answer is the plan. |

### D. Pressure / Stress (depth 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you, over someone who has already worked in a contact centre?" | JD | [grounded] "Never worked in a contact centre" — your message | Pause. Restate. Anchor in what you did: "I handled the branch's formal complaints log." Hold through two follow-ups. Concede specifically: someone with centre experience is ahead on the centre side, and say how you would close that gap. Do not offer a centre claim to win the argument. | F4 again, under time pressure. Hold-then-concede is the structure. |
| D2 | "That spreadsheet your regional manager uses. How much of it was actually yours?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" — your message | Attribution in your words. Say what you built and what has changed since. Answer slot: if anyone else designed or changed its structure, say who and what they changed; if no one did, say so. | The probe is aimed at the headline claim. Precise attribution beats a flourish. |
| D3 | "Lots of people train tellers on a script. What did you do that was different?" | EXP | [grounded] "trained new tellers on our escalation script" — your message | Hold the position that the training was yours and say what you taught. Concede specifically where you are unsure whether it changed behaviour. Do not add an outcome you did not see. | Tests whether the training claim holds under a challenge that sounds reasonable. |

### E. Data-Driven Prober (depth 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Walk me through how the monthly count was made. What counted as a complaint?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" — your message | Answer slot on F5 and F9: how a complaint was counted, what the count was sensitive to, the assumption you would defend least, and which part was yours. If you do not know how a figure was counted, say so. | A headline reporting claim is the magnet for this probe. |
| E2 | "Did your monthly report include how long complaints took to resolve? If so, how did you start and stop the clock?" | JD | [grounded] "report monthly on complaint volumes and resolution times" — JD; [grounded] "I built the monthly complaints spreadsheet our regional manager uses" — your message | Answer slot on F5: if the report carried resolution times, say how the clock was set. If it carried only volumes, say so plainly. That is the honest answer. | F5 is discovery in your material. The question is the JD's own line. |
| E3 | "Show me how you'd set up a monthly complaints report for an area bigger than one branch." | JD | [grounded] "comfortable with Excel reporting" — JD | Scaffold: one row per complaint, a date for each step, one count per month. Honest branch: if you have the spreadsheet, walk through its columns; if you do not, say which parts you would build first. Make no claim about a bigger area you have not reported on. | Covers the Excel requirement with a design question rather than a claim. |

### F. Conversational (depth 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through your journey to here." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" — your message | A 90-second arc: six years in retail banking, the last three as a branch supervisor, the complaints log, the training, the spreadsheet, then why this role. Use your own words. Add nothing. | The biography question is scored casually. |
| F2 | "What are you actually playing with in self-service at the moment?" | JD | [grounded] "work with digital teams on self-service journeys" — JD | Answer slot tied to F7: if you have used a self-service product as a customer, say what you noticed; if you have not looked at this, say so. Do not invent a project. | A casual question about a JD topic is still scored. |

### G. Peer Evaluator (depth 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Our teams sit side by side. Where's the seam between a branch and the contact centre, and what happens when we disagree?" | JD | [grounded] "across branches and the contact centre" — JD | Propose seam principles, not facts about a seam you have not seen. Say that you have not worked in the centre, and that you would learn its routes before proposing changes. | Branch managers see the handoff every day. Pretending to know the seam would fail here. |
| G2 | "What would you need from my team in your first month?" | JD | [grounded] "Own the member complaints process end to end across branches and the contact centre" — JD | Reciprocity: name what you would need, and what you would bring to their branch. Keep to the role, not the title. | Peers price what a hire adds to their own load. |

---

## Requirement coverage

| JD requirement | Questions |
|---|---|
| 4+ years in financial-services customer operations | F1 |
| Experience handling regulated complaints | B2 |
| Own the complaints process end to end across branches | A1, C1 |
| Own the complaints process across the contact centre | B1, D1, C1, G1 |
| Report monthly on complaint volumes and resolution times | E1, E2 |
| Coach branch supervisors on escalations | A2 |
| Work with digital teams on self-service journeys | C3, F2, G1 |
| Confident presenting to senior leaders | B3, D1 |
| Comfortable with Excel reporting | E3, D2 |

Values coverage: Members First (A1), Plain Words (A4), Neighbours, Not Numbers (A5), Own the Fix (A3).

---

## Grounding brief

Source: the July 2026 strategy brief, as you summarised it for me. I have not seen the full brief. There are no stale framings in what you supplied to flag.

- **Digital.** Ashgrove plans to "move 40% of member service to digital channels by 2028." This is the main reason the self-service requirement exists.
- **Branch footprint.** Ashgrove plans to "consolidate eight branches into five hubs over 2027." Complaint handling is the thing that gets harder in a consolidation, which is why C2 exists.
- **Lending.** Ashgrove plans to "launch a small-business lending product in Q1 2027." Not a complaints topic, but the panel may mention it.
- **Competition.** "the main competitive pressure is app-only banks." C3 uses this.

Sensitivity: the two branch managers on the Round 3 panel may run branches in scope for the consolidation. The pack does not know which, and you should not guess. Do not characterise the plan. Name the risk to members, then say you would want to see the plan.

---

## Values cheat sheet

| Value (official name) | Working meaning | Your mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter. | Scaffold, no quote carries it. Pick a complaint where you decided from the member's side. Honest branch: if no such time comes to mind, say so, then give the nearest thing your log work carries (F3). |
| Plain Words | If a member needs it explained twice, the wording was wrong. | F6: "trained new tellers on our escalation script" carries the training. Story: the script you taught, and what you changed when it did not land. Honest branch: if you did not see it land, say so. |
| Neighbours, Not Numbers | Every branch is part of its town. | Scaffold, no quote carries it. Pick a time a local fact changed a decision. Honest branch: if none comes to mind, say how you would weigh a local concern against a count. |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved. | F3: "I handled the branch's formal complaints log" carries the log. Story: one case you kept hold of. Honest branch: if you did not keep hold of a case to its end, say so, then say how you would. |

---

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What complaint from the last quarter do you wish had reached you sooner?" | Shows you care about the work, not just the report. |
| R2 | "How does a complaint move between a branch and the contact centre today, and where does it stall?" | Asks for the seam, which is the gap you named. |
| R3 | "How will complaint handling be protected while the branch changes are planned and carried out?" | Names a real risk the panel lives with, and asks to see the plan without presuming it. |
| R4 | "What could a new Member Experience Lead do in their first month that would genuinely help your branch?" | Reciprocity for the branch-manager panel. Peers price what a hire adds. |
| R5 | "How will you judge whether this role is working at six months?" | For the Head of Member Services. Shows you want the measure, not the title. |
| R6 | "Which of the four values is hardest to live by on a bad day?" | Invites a candid answer, and shows you have read the values. |

---

## Sources

- **Provided documents.** The job description (your message). The four published values, as you copied them on 11 November 2026 from ashgrovecu.org/about/values. The recruiter's process email (your message). The July 2026 strategy brief, as you summarised it in your message. I did not see the full brief.
- **Your background.** Your message only. No CV was supplied.
- **Research.** No searches or fetches were run. Every target below was fixed by the inputs.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | The values you pasted fix section 10 |
| 2. Ashgrove interview process | skipped | The recruiter's email fixes the three rounds and their persona weights |
| 3. Ashgrove strategy and news | skipped | The strategy brief you summarised fixes the grounding brief. A search would add only recent news, not required here |
| 4. Interviewer name and profile | n/a | No names yet, so there was no query to form. The interviewer read is absent |
| 5. Representative JD for the title | skipped | The JD you supplied fixes the fit snapshot and the JD questions |

---

## Upgrade menu

- An anonymised copy of the monthly complaints spreadsheet → F5 and F9 move from medium to high, and E1 to E3 can be rehearsed on the real columns.
- Your CV, as text → the evidence quotes can come from your own document, and the rows that rest on your message can be checked against it.
- The complaint-handling rules you worked under, such as the regulator or timescales → F2 and B2 can name the actual regime.
- Names and public profiles of the Head of Member Services and the two branch managers → personas weighted per person, and a reverse question tied to each career path.
- The Round 3 case brief, if Ashgrove sent one → replaces the generic case in C1 with the real one.
- The full strategy brief → C2 and C3 can quote the exact wording.
- How much prep time you have before 20 November → a ranked schedule with the question IDs in order.
