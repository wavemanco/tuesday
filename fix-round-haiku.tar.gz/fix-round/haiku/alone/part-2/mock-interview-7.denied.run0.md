Your prep pack is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-alone-part-2-rooms-case-7-denied-4a0bed3e/a8fe9e19-a8fd-466a-b478-5f34e3dfd2d9/scratchpad/saltmarsh_live_operations_producer_interview_pack.md`. I built it on the assumption that Tobias is your hiring manager. Web search was refused in this session, so the company and interviewer research is missing. The pack is built from your JD and your background only.

# Interview pack: Live Operations Producer, Saltmarsh Games

**Role:** Live Operations Producer. **Company:** Saltmarsh Games (mobile, about 350 people). **Interviewer:** Tobias Wrenfield, Head of Live Operations. Relationship assumed to be hiring manager; not yet confirmed. **Format:** 60 minutes, Friday.

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored.
- Type key: **VAL** behavioral and values, **EXP** your experience in depth, **JD** the job's own requirements, **CO** company knowledge, **CASE** a live problem.
- Guidance is scaffolding, not a script. Say it in your own words. If a line makes you sound bigger than you were, cut it.

## Fit snapshot

Requirements are quoted from the job description you pasted. Evidence is quoted from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years producing live-service games or apps" (JD) | "4 years as an associate producer at a puzzle-game studio" (your message) | medium | [grounded] | transferability | Your material shows four years at a puzzle studio, with the title associate producer. It does not say the games were live-service. Answer slot: if the game was run as a live service, say how it ran, in your own words; if it was not, say so plainly and say what carries over. |
| F2 | "experience running a content calendar" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | high | [grounded] | none | The quote already reaches the requirement. Lead with it in its own words. |
| F3 | "comfortable with player-retention metrics" (JD) | "Presented the monthly retention numbers to the studio head" (your message) | medium | [grounded] | presentation | The quote reaches the requirement in other terms. Your material shows you presenting retention numbers, not defining them. Say it that way. Add no definition you did not own. |
| F4 | "clear written communication" (JD) | "Wrote the release checklist our QA team still uses" (your message) | medium | [grounded] | none | The checklist is a written artifact that is still in use. One example, not a body of writing. Offer to walk through it. |
| F5 | "Plan and run the live-events calendar for two of our mobile titles" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | medium | [grounded] | transferability | Your material shows one title. Two titles is adjacent work. Say what you ran; for the second title, say how you would plan it, as a plan. |
| F6 | "coordinate design, art, engineering and community teams on each update" (JD) | none given | none | [grounded] | discovery | Your material does not show this coordination. Answer slot: if you coordinated across any of those teams on an update, say which and what you did; if you did not, say so and say how you would set that up. |
| F7 | "own the post-event review and the KPIs it reports" (JD) | "live-ops ownership of a full post-event review cycle is implied rather than stated" (your message) | low | [grounded] | discovery | Your material does not show this. Answer slot: if you ran a post-event review, say what it covered and which KPIs it reported; if you did not own one, say so plainly and say what you would measure first. |
| F8 | "manage the release checklist with QA" (JD) | "Wrote the release checklist our QA team still uses" (your message) | high | [grounded] | none | The quote reaches the requirement directly. |

Notes:
- **Team leadership** is not a line in the JD. It is a gap you named: "Never led a team" (your message). It appears in the prohibited list and in question C5.
- **In-app purchases** are not a line in the JD either. You named the gap: "Never worked on a game with in-app purchases" (your message). It appears in question S3.

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Ran the live-events calendar for two titles | Inflated form of F5 | Your quote at its own scope: "I ran the weekly content-drop calendar for our main title for the last two years." Your material shows one title. |
| Owned the post-event review and its KPIs | Inflated form of F7 | Your material does not show ownership. The answer is the slot in F7. |
| Defined the retention metrics | Inflated form of F3 | Your quote at its own scope: "Presented the monthly retention numbers to the studio head." |
| Led a team | Negative you stated | Plain acknowledgment: "I haven't led a team." |
| Monetization or in-app purchase experience | Negative you stated | Plain acknowledgment: "I haven't worked on a game with in-app purchases." |

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | Live problems from the role: plan this, resolve that | **Top weight.** The hiring-manager prior is case-led, and the JD reads as a list of live duties. | Clarify, then structure, then answer. Name one assumption aloud. |
| Skeptic | Quiet probing of the gaps: two titles, coordination, post-event ownership, no IAP, no team lead | **Top weight, deepest rehearsal.** Your material is thinnest exactly where this JD asks for ownership. | Name the gap plainly. Bridge only with what you have stated. Give a concrete ramp plan. |
| Data-Driven Prober | Asks how the retention number was counted | **Mid weight.** The JD asks for retention comfort; your retention line says "presented", not "defined". | Say what you know about the count. Name the weakest assumption before they do. |
| Pressure / Stress | Time-boxed challenge: why you, how much was you | **Lower weight.** Common in closing segments of hiring-manager rounds. | Pause. Hold a position through two follow-ups. Concede specifically. |
| Conversational / Rapport | Casual opener, "walk me through the journey" | **Lower weight.** Casual questions still count. | A 90-second arc from your quotes. |

## Question banks

Provenance lists the candidate's own sentences the guidance rests on, quoted exactly.

### Case / Strategist (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Retention on day 7 dips after your last content drop. What do you check first?" | CASE | [generic] | Clarify before diagnosing: did the drop ship on schedule, which cohort moved, did anything else change that week. Then name the one metric you would check first and why. Make no claim about your past. | A live problem from the role. Presupposes nothing about you. |
| C2 | "You are planning the live-events calendar for two titles next quarter. What do you need to know before you lock dates?" | JD / CASE | [grounded] "Plan and run the live-events calendar for two of our mobile titles" (JD) | Name inputs: QA capacity, art and engineering lead times, the other title's calendar, fixed dates. Say what you would lock and what you would hold. This is a plan, not a record. | Covers F5 and R5 as a live problem. |
| C3 | "A design lead, an engineer and the community manager disagree on whether a new event ships this sprint. How do you decide?" | CASE | [grounded] "coordinate design, art, engineering and community teams on each update" (JD) | Structure: what each side protects, what slipping costs, what QA needs to sign off. Name one decision owner and how you would record the call. Make no claim about your past. | Covers F6 as a decision. The question is the JD's, not your history. |
| C4 | "What goes into a post-event review, and who owns the KPIs it reports?" | JD | [grounded] "own the post-event review and the KPIs it reports" (JD) | Describe the structure you would use: plan against actual, the metric and how it was counted, what changes next time. Answer slot from F7: if you ran a review, say what it covered and which KPIs it reported; if you did not own one, say so and say what you would measure first. | Covers F7, the JD's own line. |
| C5 | "You have not led a team. How would you coordinate four teams on an update without authority over them?" | CASE | [grounded] "Never led a team" (your message) | Start with the plain acknowledgment: "I haven't led a team." Then the plan: a shared calendar, a named decision owner, a checkpoint each team signs. Do not describe coordination you did not do. | Premise is your own stated negative. Keeps the answer to a plan. |

### Skeptic (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| S1 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "coordinate design, art, engineering and community teams on each update" (JD); [grounded] "Never led a team" (your message) | Name coordination and post-event ownership as the honest weak spots. Use "I haven't led a team" if it fits. Then give the first 30 days as a plan. | The Skeptic's opening. It sets the tone for the rest. |
| S2 | "The job runs the calendar for two titles. You ran one. What is the difference, and what would you need to learn?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | **Highest-ROI prep in this pack.** Hold: "I ran the calendar for our main title for two years." For the second title, give a plan. Answer slot: if you set priorities across two products, say how; if not, say so. Hold through two follow-ups by returning to the one title and conceding what you do not know. | This will be asked in some form. The quote is the only thing you can defend. |
| S3 | "Your background does not include a game with in-app purchases. How would you close that gap?" | JD | [grounded] "Never worked on a game with in-app purchases" (your message) | Acknowledge: "I haven't worked on a game with in-app purchases." Then name how you would learn the economics: the store data you would read, the people you would ask, the first question you would take to the monetization owner. No claim about IAP work. | Premise is your own negative. The answer is a plan. |
| S4 | "How did you define the retention numbers you presented?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" (your message) | Answer slot: if you defined the metric, say how in your own words; if the definition came from elsewhere, say so plainly. Name the assumption you would defend least. | Presenting is not defining. Expect this from anyone who reads the quote closely. |
| S5 | "Why this role, from a puzzle studio, now?" | EXP | [generic] | Motivation in two sentences: what you have done, what you want next, why this company. Stay within the CV line; do not claim live-service history you do not have. | The motivation probe. |

### Data-Driven Prober (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Walk me through how that retention number was counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head" (your message) | Say what you know about the count, in your own words. Answer slot: if you know the method, describe it as you know it; if not, say so plainly. Never invent a denominator. | The first probe on the figure. "I don't know the method" is a valid answer. |
| P2 | "Which assumption behind that retention figure would you defend least?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" (your message) | Name the assumption before they do. If you cannot name one, say that plainly. | Weakest-assumption move on the one figure you have. |
| P3 | "Walk me through the release checklist you wrote. How do you know it catches what it needs to?" | JD | [grounded] "Wrote the release checklist our QA team still uses" (your message) | Describe what the checklist covers and how QA uses it. Answer slot: if you tracked issues that got past it, say what; if not, say so. Offer to show it. | Covers R8 and R4 through the artifact. |

### Pressure / Stress (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| PR1 | "Sixty seconds: why you, given the gaps in this job description?" | JD | [generic] | Pause. Name one gap plainly. Give one thing your material does show, in its own words. Hold through one follow-up, then concede the specific gap. | A pressure stem tied to the JD's gaps. |
| PR2 | "That calendar you ran: how much of it was actually you?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | Hold: "I ran it." Name which parts you set and which the team set. Answer slot: if you set priorities, say which; if not, say so. | Hold-then-concede. Do not inflate the share. |

### Conversational / Rapport (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| CV1 | "So, walk me through the journey from the puzzle studio to here." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio" (your message) | A 90-second arc: the studio, the associate role, the calendar, the checklist, where you want to go. Stop there. | The opener. Casual, and still scored. |
| CV2 | "What are you playing in mobile live ops these days?" | CO | [generic] | Be honest about what you actually play and follow. Do not name games you have not played. | Casual, JD-adjacent. Scored. |

### Requirement coverage

| JD requirement | Question IDs |
|---|---|
| 3+ years producing live-service games or apps | CV1, S2 |
| Experience running a content calendar | C2, S2, F2 |
| Comfortable with player-retention metrics | P1, P2, P3 |
| Clear written communication | P3 (the checklist artifact) |
| Plan and run the live-events calendar for two titles | C2, S2 |
| Coordinate design, art, engineering and community teams | C3, S1 |
| Own the post-event review and the KPIs it reports | C4 |
| Manage the release checklist with QA | P3 |

## Reverse questions

1. "How many updates a month does the calendar carry across the two titles?" Shows you are planning, not only listening.
2. "Which of the two titles needs the most help right now, and why?" Asks for current priority, which only an insider can give.
3. "How is the post-event review decided? Who reads it, and what changes because of it?" Probes whether the review is a ritual or a decision tool.
4. "Where does the release checklist usually slip, and how does QA sign off before a drop?" Shows you already know the checklist matters.
5. "How does the team decide on in-app purchase changes when a live event is planned?" Names the monetization gap as a question, not a claim.
6. "What would the first 90 days need to deliver for you to call this hire a good one?" Asks for the scorecard.

## Sources

- **Provided documents:** the job description text and your background message.
- **Searches:** two were attempted and refused, because WebSearch permission was not granted in this session. No results came back.

**Research tier:** L1 requested, effective L0.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | unavailable | Refused. Would have moved the values cheat sheet, which is absent without it. |
| 2. Saltmarsh Games interview process, live operations | unavailable | No call sent; permission not granted. Would have set the loop structure and persona weights. |
| 3. Saltmarsh Games strategy and recent news | unavailable | No call sent; permission not granted. Would have moved the company-knowledge bank. |
| 4. Tobias Wrenfield, Saltmarsh Games | unavailable | Refused. Would have moved the interviewer read and one reverse question. |
| 5. Representative Live Operations Producer JD | skipped | Your JD fixes the fit snapshot and the JD-tagged questions. |

## Upgrade menu

- Confirming Tobias is your hiring manager, or a peer → persona weights recomputed.
- The company's published values, pasted or linked → a values cheat sheet mapped to your stories.
- Search permission granted for this session → the unavailable rows can be run, and an interviewer read added.
- One post-event review you ran, described in your own words → F7 moves toward a stated quote.
- Any detail on the second title in the live calendar → F5 moves toward grounded.
- A deeper research pass (L2) → a grounding brief on strategy and loop reports. Offered once, with its caps and time cost stated.

---

If you want to rehearse, I can play the Skeptic on S2, the question the pack names as the highest-return prep. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, to carry into later sessions.

Two questions that would change the pack:

1. Is Tobias your future manager, or a peer on the team? That reweights the personas.
2. Has the recruiter mentioned a take-home, a presentation, or any focus areas for the 60 minutes? If so, I'll add a section for it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh_live_operations_producer_interview_pack.md -----
# Interview pack: Live Operations Producer, Saltmarsh Games

**Role:** Live Operations Producer. **Company:** Saltmarsh Games (mobile, about 350 people). **Interviewer:** Tobias Wrenfield, Head of Live Operations. Relationship assumed to be hiring manager; not yet confirmed. **Format:** 60 minutes, Friday.

*First version. No changes yet.*

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored.
- Type key: **VAL** behavioral and values, **EXP** your experience in depth, **JD** the job's own requirements, **CO** company knowledge, **CASE** a live problem.
- Guidance is scaffolding, not a script. Say it in your own words. If a line makes you sound bigger than you were, cut it.

## Fit snapshot

Requirements are quoted from the job description you pasted. Evidence is quoted from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years producing live-service games or apps" (JD) | "4 years as an associate producer at a puzzle-game studio" (your message) | medium | [grounded] | transferability | Your material shows four years at a puzzle studio, with the title associate producer. It does not say the games were live-service. Answer slot: if the game was run as a live service, say how it ran, in your own words; if it was not, say so plainly and say what carries over. |
| F2 | "experience running a content calendar" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | high | [grounded] | none | The quote already reaches the requirement. Lead with it in its own words. |
| F3 | "comfortable with player-retention metrics" (JD) | "Presented the monthly retention numbers to the studio head" (your message) | medium | [grounded] | presentation | The quote reaches the requirement in other terms. Your material shows you presenting retention numbers, not defining them. Say it that way: "I presented the monthly retention numbers to the studio head." Add no definition you did not own. |
| F4 | "clear written communication" (JD) | "Wrote the release checklist our QA team still uses" (your message) | medium | [grounded] | none | The checklist is a written artifact that is still in use. One example, not a body of writing. Offer to walk through it. |
| F5 | "Plan and run the live-events calendar for two of our mobile titles" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | medium | [grounded] | transferability | Your material shows one title. Two titles is adjacent work. Say what you ran; for the second title, say how you would plan it, as a plan. |
| F6 | "coordinate design, art, engineering and community teams on each update" (JD) | none given | none | [grounded] | discovery | Your material does not show this coordination. Answer slot: if you coordinated across any of those teams on an update, say which teams and what you did; if you did not, say so and say how you would set that coordination up. |
| F7 | "own the post-event review and the KPIs it reports" (JD) | "live-ops ownership of a full post-event review cycle is implied rather than stated" (your message) | low | [grounded] | discovery | Your material does not show this. Answer slot: if you ran a post-event review, say what it covered and which KPIs it reported; if you did not own one, say so plainly and say what you would measure first. |
| F8 | "manage the release checklist with QA" (JD) | "Wrote the release checklist our QA team still uses" (your message) | high | [grounded] | none | The quote reaches the requirement directly. |

Notes:

- **Team leadership** is not a line in the job description. It is a gap you named: "Never led a team" (your message). It appears in the prohibited list and in question C5.
- **In-app purchases** are not a line in the job description either. You named the gap: "Never worked on a game with in-app purchases" (your message). It appears in question S3.

## Prohibited claims

What this pack will not coach, and why.

| Not coached | Basis | Honest form |
|---|---|---|
| Ran the live-events calendar for two titles | Inflated form of F5 | Your quote at its own scope: "I ran the weekly content-drop calendar for our main title for the last two years." The limit is this pack's observation: your material shows one title. |
| Owned the post-event review and its KPIs | Inflated form of F7 | The pack's observation: your material does not show ownership. The answer is the slot in F7. |
| Defined the retention metrics | Inflated form of F3 | Your quote at its own scope: "Presented the monthly retention numbers to the studio head." |
| Led a team | Negative you stated, "Never led a team" | Plain acknowledgment: "I haven't led a team." |
| Monetization or in-app purchase experience | Negative you stated, "Never worked on a game with in-app purchases" | Plain acknowledgment: "I haven't worked on a game with in-app purchases." |

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | Live problems from the actual role: plan this, resolve that | **Top weight.** The hiring-manager prior is case-led. The JD is written as a list of live duties. | Clarify, then structure, then answer. Name one assumption aloud. |
| Skeptic | Quiet probing of the gaps: two titles, coordination, post-event ownership, no IAP, no team lead | **Top weight, deepest rehearsal.** Your material is thinnest exactly where this JD asks for ownership. | Name the gap plainly. Bridge only with what you have stated. Give a concrete ramp plan. |
| Data-Driven Prober | Asks how the retention number was counted | **Mid weight.** The JD asks for retention comfort, and your retention line is "presented", not "defined". | Say what you know about how the number was counted. Name the weakest assumption before they do. |
| Pressure / Stress | Time-boxed challenge: why you, how much was you | **Lower weight.** Common in closing segments of hiring-manager rounds. | Pause. Hold a position through two follow-ups. Concede specifically. |
| Conversational / Rapport | Casual opener, "walk me through the journey" | **Lower weight.** Casual questions still count. | A 90-second arc from your quotes. Treat casual questions about the JD's topics as scored. |

## Question banks

Sorted by weight. Provenance lists the candidate's own sentences the guidance rests on, quoted exactly.

### Case / Strategist (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Retention on day 7 dips after your last content drop. What do you check first?" | CASE | [generic] | Clarify before diagnosing: did the drop ship on schedule, which cohort moved, did anything else change that week. Then name the one metric you would check first and why. Make no claim about your past. | A live problem from the role's own job. Presupposes nothing about you. |
| C2 | "You are planning the live-events calendar for two titles next quarter. What do you need to know before you lock dates?" | JD / CASE | [grounded] "Plan and run the live-events calendar for two of our mobile titles" (JD) | Name inputs: QA capacity, art and engineering lead times, the other title's calendar, any fixed dates. Say what you would lock and what you would hold. This is a plan, not a record of past work. | Covers F5 and R5 as a live problem. |
| C3 | "A design lead, an engineer and the community manager disagree on whether a new event ships this sprint. How do you decide?" | CASE | [grounded] "coordinate design, art, engineering and community teams on each update" (JD) | Structure: what each side is protecting, what slipping costs, what QA needs to sign off. Name a single decision owner and say how you would record the call. Make no claim about your past. | Covers F6 as a decision. The question is the JD's, not your history. |
| C4 | "What goes into a post-event review, and who owns the KPIs it reports?" | JD | [grounded] "own the post-event review and the KPIs it reports" (JD) | Describe the structure you would use: plan against actual, the metric and how it was counted, what changes next time. Answer slot from F7: if you ran a review, say what it covered and which KPIs it reported; if you did not own one, say so and say what you would measure first. | Covers F7, the JD's own line. |
| C5 | "You have not led a team. How would you coordinate four teams on an update without authority over them?" | CASE | [grounded] "Never led a team" (your message) | Start with the plain acknowledgment: "I haven't led a team." Then give the plan: a shared calendar, a named decision owner, a checkpoint each team signs. Do not describe coordination you did not do. | Premise is your own stated negative. Keeps the answer to a plan. |

### Skeptic (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| S1 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "coordinate design, art, engineering and community teams on each update" (JD); [grounded] "Never led a team" (your message) | Name the coordination and the post-event ownership as the honest weak spots. Use "I haven't led a team" if it fits. Then give the first 30 days as a plan. | The Skeptic's opening. Answering it first sets the tone for the rest. |
| S2 | "The job runs the calendar for two titles. You ran one. What is the difference, and what would you need to learn?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | **Highest-ROI prep in this pack.** Hold: "I ran the calendar for our main title for two years." For the second title, give a plan. Answer slot: if you set priorities across two products, say how; if you did not, say so. Hold through two follow-ups by returning to the one title and conceding what you do not know. | This will be asked in some form. The quote is the only thing you can defend. Expect the probe on priorities across titles. |
| S3 | "Your background does not include a game with in-app purchases. How would you close that gap?" | JD | [grounded] "Never worked on a game with in-app purchases" (your message) | Acknowledge: "I haven't worked on a game with in-app purchases." Then name how you would learn the economics: the store data you would read, the people you would ask, the first question you would take to the monetization owner. Make no claim about IAP work. | Premise is your own negative. The answer is a plan, not experience. |
| S4 | "How did you define the retention numbers you presented?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" (your message) | Answer slot: if you defined the metric, say how in your own words; if the definition came from elsewhere, say so plainly. Name the assumption you would defend least. | Presenting is not defining. Expect this follow-up from anyone who reads the quote closely. |
| S5 | "Why this role, from a puzzle studio, now?" | EXP | [generic] | Motivation in two sentences: what you have done, what you want to do next, why this company. Keep it to the quote's scope and avoid claiming a live-service history you do not have. | The motivation probe. No claim about your past beyond the CV line. |

### Data-Driven Prober (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Walk me through how that retention number was counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head" (your message) | Say what you know about the count, in your own words. Answer slot: if you know the method, describe it as you know it; if you do not, say so plainly. Never invent a denominator. | The first probe on the figure. Honest "I don't know the method" is a valid answer. |
| P2 | "Which assumption behind that retention figure would you defend least?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" (your message) | Name the assumption before they do. If you cannot name one, say that plainly. | Weakest-assumption move, applied to the one figure you have. |
| P3 | "Walk me through the release checklist you wrote. How do you know it catches what it needs to?" | JD | [grounded] "Wrote the release checklist our QA team still uses" (your message) | Describe what the checklist covers and how QA uses it. Answer slot: if you tracked issues that got past it, say what; if not, say so. Offer to show it. | Covers R8 and R4 through the artifact. |

### Pressure / Stress (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| PR1 | "Sixty seconds: why you, given the gaps in this job description?" | JD | [generic] | Pause. Name one gap plainly. Give one thing your material does show, in its own words. Hold the position through one follow-up, then concede the specific gap. | A pressure stem tied to the JD's gaps. |
| PR2 | "That calendar you ran: how much of it was actually you?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | Hold: "I ran it." Name which parts you set and which the team set. Answer slot: if you set priorities, say which; if not, say so. | Hold-then-concede. Do not inflate the share. |

### Conversational / Rapport (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| CV1 | "So, walk me through the journey from the puzzle studio to here." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio" (your message) | A 90-second arc: the studio, the associate role, the calendar, the checklist, where you want to go. Stop there. | The opener. Casual, and still scored. |
| CV2 | "What are you playing in mobile live ops these days?" | CO | [generic] | Be honest about what you actually play and follow. Do not name games you have not played. | Casual, JD-adjacent. Scored. |

### Requirement coverage

| JD requirement | Question IDs |
|---|---|
| 3+ years producing live-service games or apps | CV1, S2 |
| Experience running a content calendar | C2, S2, F2 |
| Comfortable with player-retention metrics | P1, P2, P3 |
| Clear written communication | P3 (the checklist artifact) |
| Plan and run the live-events calendar for two titles | C2, S2 |
| Coordinate design, art, engineering and community teams | C3, S1 |
| Own the post-event review and the KPIs it reports | C4 |
| Manage the release checklist with QA | P3 |

## Reverse questions

Each one has a reason it lands.

1. "How many updates a month does the calendar carry across the two titles?" Lands because it shows you are planning, not only listening.
2. "Which of the two titles needs the most help right now, and why?" Lands because it asks for the current priority, which only an insider can give.
3. "How is the post-event review decided? Who reads it, and what changes because of it?" Lands because it probes whether the review is a ritual or a decision tool.
4. "Where does the release checklist usually slip, and how does QA sign off before a drop?" Lands because it shows you already know the checklist matters.
5. "How does the team decide on in-app purchase changes when a live event is planned?" Lands because it names the monetization gap as a question, not a claim.
6. "What would the first 90 days need to deliver for you to call this hire a good one?" Lands because it asks for the scorecard, which hiring managers remember.

## Sources

- **Provided documents:** the job description text and your background message.
- **Searches:** two were attempted and refused, because permission to use WebSearch was not granted in this session. No results came back.

**Research tier:** L1 requested, effective L0. No search or fetch returned a result.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | unavailable | Refused. Would have moved the values cheat sheet, which is absent without it. |
| 2. Saltmarsh Games interview process, live operations | unavailable | No call sent; search permission not granted. Would have set the loop structure and the persona weights. |
| 3. Saltmarsh Games strategy and recent news | unavailable | No call sent; search permission not granted. Would have moved the company-knowledge (CO) bank. |
| 4. Tobias Wrenfield, Saltmarsh Games | unavailable | Refused. Would have moved the interviewer read and one reverse question. |
| 5. Representative Live Operations Producer JD | skipped | The job description you supplied fixes the fit snapshot and the JD-tagged questions. |

## Upgrade menu

- Confirming Tobias is your hiring manager, or a peer → persona weights recomputed, with the Skeptic and Case banks reweighted.
- The company's published values, pasted or linked → a values cheat sheet, with each value mapped to a story from your quotes or a selection scaffold.
- Search permission granted for this session → the target rows above become `yes`, and the interviewer read and the strategy brief can be added.
- One post-event review you ran, described in your own words → F7 moves from discovery toward a stated quote.
- Any detail on the second title in the live calendar → F5 moves from transferability toward grounded.
- A deeper research pass at L2 → a grounding brief on strategy, plus role-family loop reports. Offered once, with its caps and time cost stated.
