Your prep pack is saved as `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-alone-part-2-rooms-case-7-canned-f548321b/2b6b545b-2f87-4459-951c-bbf69a87af29/scratchpad/saltmarsh_games_live_ops_producer_interview_pack.md`.

I treated Tobias as the hiring manager. Saltmarsh's careers page says the 60-minute round is the "Outage Hour": a live-incident tabletop, then a values conversation. The pack's highest-ROI prep is B2, the question about running two titles with monetization you haven't owned. Your answers to the answer slots in B2, C1, C2 and A5 would sharpen the pack most, so draft those in your own words.

I can run a drill on B2 with Tobias's persona, or save a `tuesday-dossier.md` recording the gaps this prep exposed. I can also convert the pack to a Word document if you'd like one.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh_games_live_ops_producer_interview_pack.md -----
# Live Operations Producer, Saltmarsh Games: interview pack for Femi

**Role:** Live Operations Producer. **Company:** Saltmarsh Games (mobile, about 350 people). **Interviewer:** Tobias Wrenfield, Head of Live Operations, taken as the hiring manager. **Format:** 60 minutes, the "Outage Hour" on the company's careers page: a live-incident tabletop on a simulated outage during a live event, then a values conversation. No take-home.

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored: VAL (values), EXP (your own experience), JD (the role's stated requirements), CO (company knowledge), CASE (a live problem).
- The guidance is scaffolding for a spoken answer, not a script. Rehearse the shape, then say it in your own words.
- Anything in *italics* after "Answer slot" is an instruction for the interview, not a question. Answer it from what you actually did.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" (JD) | "ran the weekly content-drop calendar for our main title for the last two years" (your message) | medium | [grounded] | transferability | Your material says one title's weekly content drops, for two years. Say that. The two-title scope and live events are what it does not show. Answer slot: if you planned events or covered more than one title, say which and how; if not, say so and say how you would run two. |
| F2 | "coordinate design, art, engineering and community teams on each update" (JD) | "Wrote the release checklist our QA team still uses" (your message) | low | [inferred] | discovery | The material shows one cross-team artifact, shared with QA. It does not show coordinating design, art, engineering or community. Answer slot: name the teams you worked with on a drop and what each needed from you. If you did not coordinate them directly, say so and say how you would set that up. |
| F3 | "own the post-event review and the KPIs it reports" (JD) | "Presented the monthly retention numbers to the studio head" (your message) | medium | [grounded] | transferability | Your material says you presented monthly retention numbers. It does not say you owned a post-event review. Bridge: "I presented the monthly retention numbers to the studio head." Answer slot: if you ran a review after any event or drop, say what it covered; if none, say so and say what you would review first. |
| F4 | "manage the release checklist with QA" (JD) | "Wrote the release checklist our QA team still uses" (your message) | high | [grounded] | none | The quote reaches the requirement. Lead with it in those words: "I wrote the release checklist our QA team still uses." Expect a probe on how it is kept current; if you updated it, say how. |
| F5 | "3+ years producing live-service games or apps" (JD) | "4 years as an associate producer at a puzzle-game studio" (your message) | medium | [grounded] | transferability | Four years and a puzzle studio meet the years. The material does not say whether that title was live-service. Bridge: "I was an associate producer at a puzzle-game studio for four years." Answer slot: if the title ran on updates and events, say how often; if it shipped once, say so. |
| F6 | "experience running a content calendar" (JD) | "ran the weekly content-drop calendar for our main title for the last two years" (your message) | high | [grounded] | none | The quote reaches the requirement: "I ran the weekly content-drop calendar for our main title for the last two years." |
| F7 | "comfortable with player-retention metrics" (JD) | "Presented the monthly retention numbers to the studio head" (your message) | medium | [grounded] | presentation | The quote reaches the requirement in other terms: presenting, not defining. Bridge rewords only: "I presented the monthly retention numbers to the studio head." Metric probes are in banks C1 and C2. |
| F8 | "clear written communication" (JD) | "Wrote the release checklist our QA team still uses" (your message) | low | [inferred] | discovery | One checklist is evidence of writing for a working team; the JD asks for more than that. No writing sample was supplied. Answer slot: if you have a written artifact you can describe (a post-event write-up, an update note, a KPI summary), name it and its audience. If not, say so. |
| F9 | Lead people: not in the JD; implied by its coordination line | "Never led a team" (your message) | none | [grounded] | capability | A gap you stated. Words: "I've never led a team." Then how you would get work done across teams without line authority, said as a plan, never as a past. |
| F10 | In-app purchase and monetization experience: not in the JD; a likely probe for a monetized mobile title | "never worked on a game with in-app purchases" (your message) | none | [grounded] | capability | A gap you stated. Words: "I haven't worked on a game with in-app purchases." Then how you would learn the monetization side, said as a plan. |

Gap types are chosen from the evidence cell, per the routing rule in the skill's output template: the quote either reaches the requirement, reaches it in other terms, carries adjacent work, or is silent. Silence is `discovery`; only a negative you stated is `capability`.

## Prohibited list

Claims this pack will not coach, and why. Each has its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the live-events calendar for two titles | Inflated form of F1 | "I ran the weekly content-drop calendar for our main title for the last two years." Limit, in the pack's own analysis: your material shows one title's content drops, not two titles' live events. |
| Owned the post-event review and its KPIs | Inflated form of F3 | "I presented the monthly retention numbers to the studio head." Limit: your material shows monthly reporting, not a post-event review. |
| Coordinated design, art, engineering and community on each update | Inflated form of F2 | "I wrote the release checklist our QA team still uses." Limit: your material shows a QA artifact. |
| Led a team | Negative you stated, F9 | "I've never led a team." |
| Ran monetization or in-app purchase work | Negative you stated, F10 | "I haven't worked on a game with in-app purchases." |

## Persona weights

Relationship prior: hiring manager, so Case/Strategist and Skeptic lead (the skeleton's prior). The careers page adds a values conversation to this round, and the JD's KPI and retention lines pull in the Prober. The Conversational opener is a 60-minute slot's usual warm-up.

| Persona | How it shows up | Likelihood, with reasoning | Weight | Counter-strategy |
|---|---|---|---|---|
| Case/Strategist | Outage tabletop on a live event; "what do you do first" | High: the careers page names a live-incident tabletop as the core of this slot | 5 | Clarify, then stop the bleed, then tell players, then review. Think aloud. |
| Skeptic | "Which part of this would you be weakest at?" and the monetization and people gaps | High: a hiring manager derisks gaps first; F9 and F10 are the visible ones | 4 | Rehearse B2 until it is plain. Concede the gap in one sentence, then the plan. |
| Data-Driven Prober | Defend the retention number; "how was it counted" | Medium-high: a retention KPI is named in the JD, and F7 is a presentation line | 4 | Say what you know about how the figure was counted, and say plainly when you don't. Name the weakest assumption first. |
| Values/Behavioral | The three published values, asked as a conversation | Medium-high: the careers page names a values conversation | 3 | Map each value to a story only where your material carries one; otherwise a selection scaffold with its honest branch. |
| Pressure | Interruptions and time limits | Low-medium: no signal from the company; the tabletop itself is timed | 2 | Hold a position through two follow-ups before conceding anything real. |
| Conversational | Warm-up and "walk me through the journey" | Low-medium: short slot, but casual openers are scored | 2 | A 90-second arc, prepared. |

## Reading the interviewer

Public footprint only: a GDC 2026 talk titled "Patch Notes Are a Promise", by Tobias Wrenfield, described on its listing as the Head of Live Operations at Saltmarsh Games and previously a QA lead at a console studio. The listing's argument: a live team is judged by how often its patch notes describe what actually shipped. (Taken from the search listing; I did not read the full talk.)

- **Career pattern:** QA lead at a console studio, then Head of Live Operations here. He came to live ops from QA.
- **Practical implications:** he will test accuracy. Say only what shipped, and say what you did not see shipped. Expect probes from the QA side of a release.
- **Shared jump:** his path from QA into live operations runs alongside your own, since you wrote a release checklist QA still uses: "I wrote the release checklist our QA team still uses." Use this in your reverse questions, not as a claim about your career.

## Question banks

Provenance comes first in each row. Provenance quotes are your own sentences. Where the guidance says anything about what you did, it rests on those quotes. Anything beyond them is an answer slot.

### A. Case/Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how you would plan the first month of live events across two titles. What do you need to know first?" | CASE | [generic] | Clarify before structuring: which two titles, their retention trend, current event cadence, team sizes. Then structure: calendar horizon, event types, what to measure in event one. Say aloud what you would not decide without the data. | The JD's first line raises this directly; the answer is a method, so no claim about your past. |
| A2 | "A live event went out this morning and a reward grant is failing for part of the player base. Walk us through the first hour." | CASE | [generic] | Confirm scope and symptoms. Decide whether to pause the event, hotfix, or compensate. Name who you pull in: engineering on the fix, QA on the check, community on the message. Tell players what is built, not what is hoped. The scenario is illustrative; the real one will differ. | The careers page names the live-incident tabletop as this round's core. |
| A3 | "Your release checklist is in use. A release goes out Thursday and QA reports a blocker on the day before. What do you do?" | JD | [grounded] "I wrote the release checklist our QA team still uses." | Keep the checklist as the gate. Decide go or no-go with QA and the engineering owner; decide what gets cut; say what you announce. Answer slot: if you owned a go or no-go call, say how you made it; if you did not, say so and say how the checklist would drive the decision. | F4 is the evidence; the question's premise is only that you wrote it. |
| A4 | "Our post-event review sets the KPIs for the next calendar. What would you put in one?" | JD | [grounded] "I presented the monthly retention numbers to the studio head." | Structure: the target the event was built for against the actual result; the retention effect by cohort; player feedback; what changes next. Name the assumption you would defend least. Answer slot: if you have run a review, describe it in your words; if not, say so and describe the one you would run. | F3 and F7; the review is the JD's requirement, so the guidance describes its method, not your history. |
| A5 | "Tell me about a drop that missed its target. What changed in the next one?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Pick one drop from two years of weekly drops. Name the target, the miss, and the change. Answer slot: if no drop missed its target, say so and give the nearest one you have. | An open prompt with its theme from the JD's review requirement; the candidate chooses the instance. |

### B. Skeptic (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "I haven't worked on a game with in-app purchases." "Never led a team" | Name the gap in one sentence: "I haven't worked on a game with in-app purchases." Then the first 30 days: who you learn the monetization side from, and what you ask them first. | F10 and F9 are where this question lands. |
| B2 (highest-ROI) | "You've run one puzzle title's weekly calendar. Why should we trust you with two titles' live events, including monetization you haven't owned?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." [grounded] "I haven't worked on a game with in-app purchases." | Hold: "I ran the weekly content-drop calendar for our main title for the last two years." Say what transfers: the cadence, the checklist, the retention reading. Concede: "I haven't worked on a game with in-app purchases." Plan: how you would learn the monetization side in your first month, with the economy owner. Hold through two follow-ups by returning to the calendar. Never claim the second title. Answer slot: if any of your events involved paid items, say what they were; if none did, say so. | This is the objection the material most supports: F1's scope and F10's gap together are the likeliest reason to pass. Rehearse it until the concession is plain. |
| B3 | "You've never led a team. How would you coordinate design, art, engineering and community without authority over any of them?" | JD | [grounded] "Never led a team" [grounded] "I wrote the release checklist our QA team still uses." | Concede first: "I've never led a team." Then the plan: coordination runs on the calendar and the checklist, the artifacts each team plans against. Answer slot: if you have gotten a team to act without line authority, describe it; if not, say so and describe how you would set the cadence. | F9 and F2; the question assumes the coordination the JD asks for, and the answer does not claim it. |
| B4 | "Why leave a studio where you're established, for a company our size, now?" | VAL | [generic] | Keep it short and forward-looking. Do not criticize your current studio. Say what you want from live ops that the puzzle studio's calendar did not give you. | The Skeptic's motive probe; the question presupposes nothing about your history. |

### C. Data-Driven Prober (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "The monthly retention numbers you presented: how was retention counted?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Defend-the-number, in your words: how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. Answer slot: if you did not define it, say whose definition it was. The pack supplies no method. | F7 is the quote; a retention figure raises the defend-the-number slots and nothing else. |
| C2 | "Which assumption behind that retention figure would you defend least?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Name the weakest assumption before they do. If you do not know it, say so plainly and say what you would check. | The weakest-assumption move, in its own form. |
| C3 | "A live event ran, and retention moved. How would you tell whether the event caused it?" | JD | [generic] | Name the metric the event targeted; a comparison group or a before-and-after window; the other drops or sales in the same weeks as confounds. Say what you would not claim from one number. | The JD's retention requirement, asked as a method. |
| C4 | "You ran a weekly calendar for two years. What did the drop-by-drop data tell you that a monthly number did not?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Answer slot: if you looked at individual drops, say what you saw; if the monthly figure was the only read you had, say so. | F6 and F3: the difference between a weekly calendar and a monthly read is the probe. |

### D. Values/Behavioral (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell me about a time you put the player ahead of the plan." | VAL | [generic] | Selection scaffold: pick a moment when the planned drop and what players needed disagreed; say what you chose and what changed. If no such moment comes to mind, say so plainly, then give the nearest one you have. | Players Before Plans, from the company's published values. No quote in your material carries this story. |
| D2 | "When have you announced something only after it was built?" | VAL | [grounded] "I wrote the release checklist our QA team still uses." | Answer slot: if the checklist was what gated announcements, say so and give a case; if it did not, say so. | Ship the Patch Not the Promise. The checklist is the only artifact your material shows that could carry this story. |
| D3 | "What have you left better than you found it?" | VAL | [grounded] "I wrote the release checklist our QA team still uses." | Say what you wrote and that QA still uses it, in those words. Do not claim you improved it unless you did; if you did, say how. | Leave the Build Greener. |

### E. Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | JD | [grounded] "4 years as an associate producer at a puzzle-game studio" "I ran the weekly content-drop calendar for our main title for the last two years." | A prepared 90-second arc: the puzzle studio, the calendar, the checklist, the retention reporting, and why live ops now. Use your own words. | Casual openers are scored; this one sets up the rest of the hour. |
| E2 | "What game are you playing right now, and what would you change about its event calendar?" | JD | [generic] | Name a live game you play and what its calendar does well. Give one change that would matter for retention, and say why. | A casual question on a JD topic; no claim about your history. |

## Values cheat sheet

Published values, from the company's values page. The mapped story is a quote from your material where one exists, and otherwise a selection scaffold ending in its honest branch.

| Value | Working meaning | Mapped story |
|---|---|---|
| Players Before Plans | When the calendar and the players disagree, the players win. | None in your material. Selection scaffold: a moment when a planned drop and what players needed disagreed. If none comes to mind, say so and give the nearest. (D1) |
| Ship the Patch Not the Promise | Announce what is built, not what is hoped. | F4: "Wrote the release checklist our QA team still uses." Answer slot: if the checklist gated announcements, say how. (D2) |
| Leave the Build Greener | Every release leaves the codebase and the checklist better than it found them. | F4: "Wrote the release checklist our QA team still uses." Say what you wrote and that it is still in use. Claim no improvement you did not make. (D3) |

## Requirement coverage

| JD requirement | Covered by | Note |
|---|---|---|
| Plan and run the live-events calendar for two of our mobile titles | A1, B2 | |
| Coordinate design, art, engineering and community teams on each update | B3, A2 | |
| Own the post-event review and the KPIs it reports | A4, C3 | |
| Manage the release checklist with QA | A3, D3 | |
| 3+ years producing live-service games or apps | Fit snapshot F5 | No question; the answer is in F5's slot. |
| Experience running a content calendar | A5, E1 | |
| Comfortable with player-retention metrics | C1, C2, C4 | |
| Clear written communication | Fit snapshot F8 | No question; upgrade-menu item. |

## Reverse questions

Each has why it lands. Two tie to the interviewer's own path.

1. **"Your talk argues patch notes are a promise. What is the hardest patch note your team has had to write?"** Why it lands: it draws on the talk's argument, which you saw in a search listing, so ask about it lightly. It turns the tabletop into a conversation about his team.
2. **"You came up through QA. Which parts of the release checklist would you want rewritten first?"** Why it lands: it ties to his path from QA into live ops, and to the checklist you wrote.
3. **"How is monetization organized alongside the calendar? Who owns the economy?"** Why it lands: it turns your biggest gap into a question about how the team works, and shows you know the gap exists.
4. **"Which of the two titles is most at risk on the calendar right now?"** Why it lands: it shows you are already thinking about the work, not the job title.
5. **"What would the first 90 days need to deliver for you to call the hire right?"** Why it lands: it asks for the scoring sheet directly, and gives you a target to plan against.

## Interview run-of-show

Your request, for the 60 minutes. This is an addition to the skeleton: the plan follows from the personas above.

| Minutes | Segment | Question IDs |
|---|---|---|
| 0 to 5 | Opener and your arc | E1 |
| 5 to 20 | Outage tabletop | A2, then A1 if time allows |
| 20 to 35 | Calendar, checklist and reporting | A3, A4, C1, C2 |
| 35 to 45 | Values | D1, D2, D3 |
| 45 to 55 | Skeptic: gaps and the monetization question | B1, B2, B3 |
| 55 to 60 | Your questions | Reverse questions 1 to 5, choose two |

## Sources

Provided documents: your message (background and gaps); the job description you pasted.

| Query or fetch | Result |
|---|---|
| Search: "Saltmarsh Games mobile studio values" | Returned saltmarshgames.com/values |
| Search: "Tobias Wrenfield Head of Live Operations Saltmarsh Games" | Returned a GDC 2026 talk listing (search snippet only, not fetched) |
| Search: "Saltmarsh Games live operations producer interview process" | Returned saltmarshgames.com/careers/interviewing |
| Fetch: saltmarshgames.com/careers/interviewing | Read: the Outage Hour format, no take-home |
| Fetch: saltmarshgames.com/values | Read: three values by name |

Research tier: L1, searches 3 of 6, fetches 2 of 2.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | yes | Values cheat sheet: three values by name |
| 2. Saltmarsh Games interview process, live operations | yes | Round type (Outage Hour); persona weights |
| 3. Saltmarsh strategy and recent news | unavailable | Not searched: the budget went to targets 1, 2 and 4 first. Would have moved one CO question; the pack has none, so there is a gap in CO coverage. |
| 4. Tobias Wrenfield, Saltmarsh Games | yes | Reading the interviewer; reverse questions 1 and 2 |
| 5. Representative live operations producer JD | skipped | The JD you supplied fixes the fit snapshot |

## Upgrade menu

- Your answers to the answer slots in B2, C1, C2 and A5, in your own words, outside a drill → sharper defend-the-number and concession lines, from your actual numbers
- A written sample (a checklist or a KPI summary you wrote) → F8 moves from discovery to grounded evidence
- The names and sizes of the two titles → A1 and B2 get real scope in place of "two titles"
- A recent strategy search (research target 3) → a CO question on Saltmarsh's current priorities
- A tuesday-dossier.md from the job-underwriter → a verified evidence map and a named highest-risk objection to check the pack against
