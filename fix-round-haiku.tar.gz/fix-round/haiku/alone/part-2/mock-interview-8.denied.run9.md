Your prep pack is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-alone-part-2-rooms-case-8-denied-0f81cb06/712ea3d6-d621-4545-99c9-94debba3578f/scratchpad/Ashgrove_Credit_Union_member-experience-lead_interview_pack.md`. It covers the fit snapshot, the prohibited claims, persona weights for all three rounds, 20 questions with guidance, values cheat sheet, the escalation case, strategy grounding, reverse questions and an upgrade menu.

The main thing to rehearse is C1: "You've run a branch, not a contact centre, and you've never presented above regional level. Why should we give you the whole complaints process?" Your answer has to hold on the complaints log you handled, then concede the two gaps plainly, then give a plan for each. The pack does not give you any contact-centre or senior-presentation experience to lean on.

I didn't run any web research. Your pasted values and strategy summary already covered what the research would have fetched, so the strategy section reflects only the July brief you supplied.

I can also draft the answer slots' wording for B1–B4 once you tell me a complaint you took through to closure, in your own words.

Would you like a Word version of the pack?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Ashgrove_Credit_Union_member-experience-lead_interview_pack.md -----
# Interview pack: Member Experience Lead, Ashgrove Credit Union

Prepared 11 November 2026 for Dara. Interviews: 20 November 2026, three rounds.

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored.
- Type key: **VAL** behavioural/values, **EXP** your own experience (probed), **JD** the job's stated requirements, **CO** company and strategy, **CASE** a live problem.
- Guidance is scaffolding, not a script. Speak it in your own words.
- Every claim about your past is either a sentence you wrote (quoted in the fit snapshot), a plain acknowledgment of a gap, or an answer slot. Where the material does not show something, the pack says so and does not fill the gap.

## Fit snapshot

Requirements come from the JD you sent. Evidence is quoted exactly from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches and the contact centre" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | transferability | Your material says the branch's formal complaints log, not the process end to end. Say it in those words. Answer slot: if you set how complaints moved from intake to close, say which steps and how you decided; if you did not, say so plainly and stay with the log. |
| F2 | "across branches and the contact centre" (JD) | "Never worked in a contact centre" (your message) | none | [grounded] | capability | You stated this absence. Words: "I've never worked in a contact centre." Then how you would learn it, as a plan and never as a past. |
| F3 | "report monthly on complaint volumes and resolution times" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | medium | [grounded] | discovery | The spreadsheet is a monthly complaints report. Your material does not show whether it carried volumes or resolution times. Answer slot: if it carried either, say which and how each was counted; if it did not, say so and say what you would add first. |
| F4 | "comfortable with Excel reporting" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | medium | [grounded] | presentation | Your material says a spreadsheet, not Excel. Say "spreadsheet" in those words. Answer slot: name the tool, and say which parts you built yourself; if you did not build formulas or summaries, say so. |
| F5 | "4+ years in financial-services customer operations" (JD) | "6 years in retail banking, the last 3 as a branch supervisor" (your message) | medium | [grounded] | none | This meets the requirement in role-relevant terms. Say the six years and the three as supervisor, in those words. |
| F6 | "experience handling regulated complaints" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | discovery | Your material does not show whether the log was governed by rules or timescales. Answer slot: say which rules or timescales applied to the log, if any; if none applied to you, say so plainly. |
| F7 | "confident presenting to senior leaders" (JD) | "I've never presented to anyone above regional level" (your message) | none | [grounded] | capability | You stated this absence. Words: "I've never presented to anyone above regional level." Then your plan for building it, as a plan. |
| F8 | "coach branch supervisors on escalations" (JD) | "trained new tellers on our escalation script" (your message) | medium | [grounded] | transferability | Your material shows training tellers, not coaching supervisors. Say the teller training in those words. Do not stretch it to supervisors. |
| F9 | "work with digital teams on self-service journeys" (JD) | none given | none | [grounded] | discovery | Your material says nothing about digital teams or self-service. Answer slot: if you worked with anyone on a digital or self-service journey, say what, in your own words; if you did not, say so plainly and say how you would start. |

**Gaps in plain terms:** F2 and F7 are absences you stated. F9 is silence in your material. F1, F3, F4, F6 and F8 are real experience that falls short of what the JD asks. F5 is a clean match.

## Prohibited claims

Claims this pack will not coach, and why. No answer, hold, bridge or reverse question asserts any of them.

| Not coached | Basis | Honest form |
|---|---|---|
| You owned the complaints process end to end across branches | Inflated form of F1 | "I handled the branch's formal complaints log." Your material says the log, not the process. |
| You have worked in or run a contact centre | Negative you stated (F2) | "Never worked in a contact centre." Then a plan. |
| You have presented to senior leaders | Negative you stated (F7) | "I've never presented to anyone above regional level." Then a plan. |
| You measured or reported resolution times | Inflated form of F3 | "I built the monthly complaints spreadsheet our regional manager uses." Whether it held resolution times is an answer slot. |
| You coached or trained branch supervisors | Inflated form of F8 | "Trained new tellers on our escalation script." |
| You are proficient in Excel | Inflated form of F4 | "A spreadsheet." Naming the tool is an answer slot. |

Silence is not listed. F9 is an answer slot, because your material does not say you lack digital experience.

## Grounding brief: Ashgrove now

Source: the 2026 strategy brief summary you supplied, July 2026. I have not checked it against anything newer, and I have not searched for news.

- **Digital:** "move 40% of member service to digital channels by 2028." This is the largest change the role is likely to sit inside.
- **Branches:** "consolidate eight branches into five hubs over 2027." Complaints from closing branches are a live operational question.
- **Lending:** "launch a small-business lending product in Q1 2027." Expect new complaint types.
- **Competition:** the main pressure is app-only banks. Expect self-service and speed of resolution to come up.

Vocabulary to use: member service, digital channels, hubs, self-service journeys. Use the brief's words in your answers. Do not correct the interviewers' framing.

## Persona table

Persona weights reflect the three rounds and the recruiter's notes. No interviewer profiles were provided, so there is no interviewer read.

| Round | Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|---|
| 1, recruiter (30 min) | Conversational, light Skeptic | Friendly opener; "why this role, why now"; a check on the JD's must-haves | High for Conversational. The recruiter screens motivation and knockouts, and the risk is treating it as unscored | Speak the 90-second arc. Treat casual questions about the JD as scored |
| 2, Head of Member Services (45 min, behavioural, your future manager) | Values/Behavioral (lead), Skeptic (second), Pressure (light) | STAR-style prompts; probes of your experience; "why not someone who has run a contact centre" | Values lead because the recruiter says "mostly behavioural." Skeptic second because F1, F2 and F7 are the gaps a manager will test. Pressure light because it is a manager round | Hold-then-concede on F2 and F7. Stories built only from F1, F8 and F3 |
| 3, panel of two branch managers (60 min, values-scored, 20-min case) | Values/Behavioral (lead), Case/Strategist (second), Data-Driven Prober, Peer Evaluator | Scored value questions; a live escalation case; numbers probes on the spreadsheet | Values is the panel's stated scoring frame. Case is the 20-minute block. Prober follows the spreadsheet on your CV. Peer is likely if they see your role as a seam with theirs | Map a story to each value where the material carries one; choose scaffolds where it does not. Structure the case aloud |

The panel's members are not yet named. If they are branch managers at a level above your supervisor role, expect them to weight the case and the values more heavily than their peers would.

## Question banks

Question IDs are letter-by-persona so the drill and the upgrade menu can reference them.

### A. Conversational (round 1, weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, walk me through the journey to here." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | Six years in retail banking, the last three as a branch supervisor, in that order. Then one sentence on the complaints work: "I handled the branch's formal complaints log." Keep it to 90 seconds | F5 is the clean match; F1 is what you will be probed on, so name it early and in your words |
| A2 | "What did you read about Ashgrove before today?" | CO | [generic] | Name two things you read: the strategy brief and the values page. Say one question each raised for you. Do not claim to have worked with any Ashgrove team | A recruiter screens whether you prepared. It makes no claim about your past |

### B. Values / Behavioral (rounds 2 and 3, weight 4 to 5)

Each published value gets one question. Where your material carries a story, the guidance maps it. Where it does not, it gives a selection scaffold and ends in the honest branch.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time you decided something from the member's side of the counter when the process pointed the other way." (Members First, Always) | VAL | [grounded] "I handled the branch's formal complaints log" | Pick a complaint from the log where the procedure and the member's interest pulled apart. Say what the member needed, what you did, and what changed. If none comes to mind, say so plainly, then give the nearest case the log carries | F1 is the only quote; the guidance is a scaffold because no sentence carries a member-side decision |
| B2 | "Tell me about a time you had to explain something to a customer more than once, and what you changed." (Plain Words) | VAL | [grounded] "trained new tellers on our escalation script" | If you changed the wording of a script or a letter, say what and why. If you did not, say so and give the nearest time you rewrote an explanation for a teller or member | F8 is the nearest sentence; no sentence carries a wording change, so this is a scaffold with an honest branch |
| B3 | "Tell me about a complaint where the figures and the customer pointed in different directions." (Neighbours, Not Numbers) | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Name a case where you looked past the figure to the customer or the town. If your work with the figures never met a case like this, say so, then say what you would do when they conflict | This value is the one your material most easily sounds like the opposite of. Rehearse the honest branch first |
| B4 | "Tell me about a complaint you kept hold of until it was solved." (Own the Fix) | VAL | [grounded] "I handled the branch's formal complaints log" | Pick a complaint you took through to closure. If the log recorded it and you did not see it through, say so, and give the nearest complaint you did follow to the end. Do not describe a fix you did not own | F1's limit applies: "handled" is the verb, not "owned end to end" |

### C. Skeptic (round 2, weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You've run a branch, not a contact centre, and you've never presented above regional level. Why should we give you the whole complaints process?" | JD | [grounded] "I handled the branch's formal complaints log" · "Never worked in a contact centre" · "I've never presented to anyone above regional level" | **Highest-ROI prep in this pack.** Open with what you did own: the log. Then concede the two gaps in plain words: "I haven't worked in a contact centre" and "I've never presented to anyone above regional level." Then a plan for each, as a plan. Hold the position through two follow-ups by returning to the log. Concede a specific limit when pressed, never a general one. Never claim contact-centre experience | F1, F2 and F7 together make this the objection most likely to arrive in some form. The JD names the contact centre directly, so the premise is raised by a source |
| C2 | "A branch supervisor's escalations keep coming back to you unresolved. What do you do?" | CASE | [generic] | Structure it: what you would ask the supervisor first, what you would check on the case today, who owns the next step, and what you would record. Coaching is a plan the supervisor follows, with a check-in date | A live problem from the JD's supervisor-coaching line. It presupposes nothing about your past |
| C3 | "Walk me through how you'd present the complaints picture to the senior leadership team." | JD | [generic] | Structure: the audience's question first, then the three numbers that answer it, then the one decision you need from them. Say what you would not put on the slide | The JD says "confident presenting to senior leaders"; this is the live version. Answer as a plan; your material does not show a past presentation above regional level |

### D. Pressure (round 2, weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over someone who has run a contact centre?" | JD | [grounded] "Never worked in a contact centre" | Do not fold. Say plainly: "I haven't worked in a contact centre." Then what you bring that the material supports: the complaints log, the escalation training for tellers, the monthly spreadsheet. Hold through the first follow-up. Concede once, specifically | F2 under time pressure. The hold is on what you did, not on what you have not done |
| D2 | "That spreadsheet: how much of it was actually you?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Say what you built, and which parts someone else built or set. If you did not design the layout, say so; if you did, say which parts. Concede the part that was not yours without apology | F3 and F4 are the attribution probe. The honest answer is the one you can defend in the next question |

### E. Data-Driven Prober (round 3, weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Walk me through what the spreadsheet counted, and how each figure was counted." | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Answer slot: if it counted complaint volumes or resolution times, say which, and how each was counted, in your own words. If it did not count one of them, say so plainly and say what you would add first. Name the assumption you would defend least, only if you know one; if you do not know, say that | The JD asks for both measures. F3 is discovery, so the answer is a slot, not a narrative |
| E2 | "What would you measure first to report resolution times?" | JD | [generic] | A plan, not a claim about your past: the definition of "resolved", the clock's start and stop, and how you would check a sample by hand before trusting the figure | Takes the JD's own requirement as the raising source. Makes no claim about your history |
| E3 | "What did you build the spreadsheet in, and what would someone else need to check it?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Name the tool. Say which parts you built, and whether you used formulas or summaries. If you did not, say so plainly. Do not say "Excel" unless that is the tool | F4. "Comfortable with Excel" is the JD's words, not yours |
| E4 | "Which rules or timescales, if any, governed the formal complaints log?" | JD | [grounded] "I handled the branch's formal complaints log" | Answer slot: say which rules or timescales the log had to meet, in your own words. If none applied to you, or you did not work to them, say so plainly | F6. The JD raises regulated complaints; the material does not show what governed the log |

### F. Case / Strategist (round 3, weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | **Escalation case (20 minutes, scenario below).** "A member has been passed between a branch and the contact centre for three weeks over a disputed fee. Their regional manager asks you what happens next. Talk us through it." | CASE | [generic] | Structure aloud, in this order. (1) Clarify: what was promised, what is on file, and the deadline. (2) Objective: the member resolved, and the procedure's clock met. (3) Ownership: one named owner today. This is the Own the Fix value. (4) Actions today: call the member in plain words; check the branch record; check the contact-centre record; fix the single version of the facts. (5) Coaching: brief the branch supervisor on the next step and check in. (6) Record for the monthly report and say what it changes. (7) Risks: the clock, data handling, and the member's trust. Say the risk you would watch hardest | The panel's case. It presupposes nothing about your past. If you have a real case like this, name it; if not, reason through the steps |
| F2 | "Ashgrove plans to move 40% of member service to digital channels by 2028. What would you want to know before designing a self-service journey for complaints?" | CO | [grounded] "move 40% of member service to digital channels by 2028" (strategy brief) | Ask first which complaints can safely move to self-service and which must stay with a person. Then what members who cannot use the app will do, and how a complaint is handed over without the member repeating themselves. Do not claim digital experience; F9 is a slot | The brief is the company's stated direction. This is the question the digital requirement is really asking |
| F3 | "The brief talks about consolidating eight branches into five hubs over 2027. What happens to complaints from the branches that close?" | CO | [grounded] "consolidate eight branches into five hubs over 2027" (strategy brief) | Open cases first: which are on the clock, and who holds each one. Then the member's side: where they will go, and whether they will know it. Then the town: what a closing branch means to the people who used it. Say the one thing you would not let slip in the change | Links the strategy to the monthly report. Neighbours, Not Numbers applies directly |

### H. Peer Evaluator (round 3, weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Our branches own the customer and the contact centre owns the call. Where's the seam for complaints, and what happens when we disagree?" | VAL | [generic] | Propose principles, not a map you do not have. For example: the member is told one owner; the owner has the authority to fix; disagreements are settled on the member's facts, not on whose team it is. Do not claim to know their seam | The panel may include peers in the branch network. Seam questions are collegial. Your answer should show a principle, not a turf claim |
| H2 | "How do you handle credit when a complaint fix needs both a branch and the contact centre?" | VAL | [generic] | Name the member as the credit's recipient, then the people who did the work, then the owner who kept hold of it. Say how you would make that visible in the monthly report | Credit-sharing is the peer probe. Answer from principle; your material does not show a past joint fix |

## Requirement coverage

| JD requirement | Covered by |
|---|---|
| Own the complaints process end to end across branches and the contact centre | C1, F1, B4 |
| Report monthly on complaint volumes and resolution times | E1, E2, F3 |
| Coach branch supervisors on escalations | C2, F1 |
| Work with digital teams on self-service journeys | F2 (F9 is an answer slot; your material does not show it) |
| 4+ years in financial-services customer operations | A1, F5 in the snapshot |
| Experience handling regulated complaints | E4 |
| Confident presenting to senior leaders | C3, D1 (F7 is a stated gap; the answer is a plan) |
| Comfortable with Excel reporting | E3 |

## Values and principles cheat sheet

Source: the four values you copied from ashgrovecu.org/about/values on 11 November 2026. The panel scores against these four.

| Value | Working meaning | Mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | No sentence in your material carries a member-side decision. Scaffold: B1. Honest branch: say so and give the nearest case |
| Plain Words | If a member needs it explained twice, the wording was wrong | "trained new tellers on our escalation script" (F8). This carries teaching, not a wording change. Scaffold: B2. Honest branch: say so |
| Neighbours, Not Numbers | Every branch is part of its town | "I built the monthly complaints spreadsheet our regional manager uses" (F3). This is the numbers side of the value. Scaffold: B3. Your honest answer may be that you did not see the town in the figures; prepare that answer |
| Own the Fix | Whoever finds the problem keeps hold of it until solved | "I handled the branch's formal complaints log" (F1). "Handled" is not "owned to the end." Scaffold: B4 and F1 (the case). Honest branch: name the nearest complaint you followed to closure, and say which parts were not yours |

## Reverse questions

Each has a note on why it lands.

1. **"Who owns a complaint today when it crosses from a branch into the contact centre?"** Why it lands: it shows you have found the seam the role is about, and it asks for a fact the manager can answer.
2. **"How will complaint reporting change when eight branches become five hubs in 2027?"** Why it lands: it ties the monthly report to the strategy brief, and tests whether the manager sees the role as part of the change.
3. **"Where is the digital self-service work against the 40% target, and where has it stalled?"** Why it lands: a direct question about the strategy's hardest part. It shows you read the brief and are not just repeating it.
4. **"What would success look like for this role at twelve months?"** Why it lands: it sets the measure the manager will hold you to, and it is the question you need answered before accepting.
5. **"What could a new person do in their first month that would genuinely help the branch teams?"** Why it lands: reciprocity for the panel, which may be peers. It turns the end of the interview into a working conversation.

No interviewer profile was provided, so no reverse question is tied to a career path. The upgrade menu says what a name would unlock.

## Sources

- **Provided documents:** the JD text and background in your message; the four values you copied from ashgrovecu.org/about/values on 11 November 2026; the strategy brief summary you supplied (July 2026); the recruiter's round description.
- **Research:** none run. Tier L1, searches 0 of 6, fetches 0 of 2. Every research target below was already fixed by a document you supplied, so no search was needed.

**Target accounting**

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | Values cheat sheet: the four values were pasted, so no search was needed |
| 2. Ashgrove interview process, member services | skipped | Loop structure and persona weights: the recruiter's email fixes the three rounds |
| 3. Ashgrove strategy and recent news | skipped | Grounding brief: the July 2026 brief summary was supplied. Not checked against anything newer |
| 4. Interviewer name | n/a | No interviewers have been named |
| 5. Representative JD | skipped | The JD you supplied fixes the fit snapshot |

## Prep triage

Prep time was not stated, so no schedule is given. Start with C1, then F1, then B1 to B4. Everything else is insurance.

## Upgrade menu

- **Names of the round 2 and round 3 interviewers** → persona weights from their public footprint, and reverse questions tied to their career paths.
- **What the spreadsheet counted and which tool it used** → E1, E3, F4 move from answer slots to story maps, with your own sentences quoted in.
- **One complaint you took through to closure, in your own words** → B1, B4 and the case F1 can be mapped to a quoted sentence, not a scaffold.
- **Any work with a digital team or self-service journey** → F9 and F2 become grounded answers instead of slots.
- **The rules or timescales the formal log had to meet** → E4 and F6 become grounded.
- **Whether the case in round 3 will use a real anonymised complaint or a written scenario** → you can rehearse the actual facts, not the generic scenario F1.
