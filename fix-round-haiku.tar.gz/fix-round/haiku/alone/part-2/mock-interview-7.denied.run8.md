Your prep pack is saved as `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-alone-part-2-rooms-case-7-denied-b266d3ae/3ad68619-4b3f-4ce2-93a1-48dcc5751232/scratchpad/saltmarsh_live_operations_producer_interview_pack.md`. I built it on the hiring-manager prior, since your note didn't say who Tobias is to the role. No company research was run, so nothing about Saltmarsh's titles, values or strategy is in it.

# Interview pack: Live Operations Producer, Saltmarsh Games

**Interviewer:** Tobias Wrenfield, Head of Live Operations. Relationship not stated.
**Research tier:** L0 (your materials only).

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is scored: VAL (values), EXP (your experience), JD (the posting's requirements), CO (company knowledge), CASE (a live problem).
- Guidance is scaffolding, not a script. Rehearse the beats out loud, in your own words.
- Answer slots (sentences starting "Answer slot:") are instructions for the interview. Either honest branch is a fair answer.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | medium | [grounded] | transferability | Your material shows one title's weekly content drops, not two titles' live events. Bridge, reworded from the quote only: "For two years I ran the weekly content-drop calendar for our main title." Answer slot: if you planned anything beyond weekly drops, or for more than one title, say what, in your own words; if not, say so and say how you would split the calendar across two titles. |
| F2 | "coordinate design, art, engineering and community teams on each update" (JD) | none given | none | [grounded] | discovery | Your material does not show coordinating those teams. "I ran the calendar" does not say who else moved on a drop. Answer slot: if you coordinated any of those teams on a drop, name which and how you got them to act, in your own words; if not, say so plainly and say how you would set it up as a plan. |
| F3 | "own the post-event review and the KPIs it reports" (JD) | "Presented the monthly retention numbers to the studio head" (your message) | medium | [grounded] | transferability | Your material shows you presented retention numbers, not that you ran a post-event review. Bridge: "I presented the monthly retention numbers to the studio head." Answer slot: if you ran a review after a drop, say what it measured and what it changed; if not, say so. |
| F4 | "manage the release checklist with QA" (JD) | "Wrote the release checklist our QA team still uses" (your message) | medium | [grounded] | none | No gap, but a single line with nothing inspected behind it, so expect a probe on what it covers. Lead with the quote's own terms: you wrote it, and QA still uses it. |
| F5 | "3+ years producing live-service games or apps" (JD) | "4 years as an associate producer at a puzzle-game studio" (your message) | medium | [grounded] | presentation | The years reach the requirement; your material does not use the words live-service. Bridge, reworded from the quote only: "Four years as an associate producer at a puzzle-game studio." Answer slot: if you would call that title live-service, say why, in your own words. |
| F6 | "experience running a content calendar" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | high | [grounded] | none | Direct match, and your strongest row. Say it in your own words; nothing to add. |
| F7 | "comfortable with player-retention metrics" (JD) | "Presented the monthly retention numbers to the studio head" (your message) | medium | [grounded] | presentation | The quote reaches the requirement in other terms. Bridge, reworded only: "I presented the monthly retention numbers to the studio head." Answer slot: how those figures were counted, which assumption behind them you would defend least, and which part was yours. If you do not know how they were counted, say so. |
| F8 | "clear written communication" (JD) | "Wrote the release checklist our QA team still uses" (your message) | low | [grounded] | presentation | The checklist is a written artifact a team relies on, which reaches the requirement only in part. Bridge, reworded only: "I wrote the release checklist our QA team still uses." Your material does not show written updates to a wider audience. |
| F9 | Lead a team (not in the posting; a gap you raised) | "Never led a team" (your message) | none | [grounded] | capability | A gap you stated: "I haven't led a team." Then the coordination answer slot in S2, not a claim of leadership. |
| F10 | In-app purchases (not in the posting; a gap you raised) | "never worked on a game with in-app purchases" (your message) | none | [grounded] | capability | A gap you stated: "I haven't worked on a game with in-app purchases." Then the planning answer in S3. |

## Prohibited claims

These are not coached, and no guidance here asserts, softens or implies them.

| Not coached | Basis | Honest form |
|---|---|---|
| "I led a team" or "I managed people" | Negative you stated, F9 | "I haven't led a team." Coordination is covered in S2. |
| Experience with in-app purchases, or on a monetized title | Negative you stated, F10 | "I haven't worked on a game with in-app purchases." |
| "I owned the live-events calendar for two titles" | Inflated form of F1 | "For two years I ran the weekly content-drop calendar for our main title." Your material shows one title's drops, not two titles' events. |
| "I ran post-event reviews and owned the KPIs they report" | Inflated form of F3 | "I presented the monthly retention numbers to the studio head." Your material does not show a review. |

## Persona table

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist (weight 5) | Live problems on a two-title quarter, a retention drop, a delayed drop | Highest. A hiring-manager round is mostly about whether you can do the job, and this posting describes the job as live problems. | Clarify, then structure, then name the metric. Think aloud. |
| Skeptic and JD fit (weight 4) | Direct questions on the leadership and in-app purchase gaps; posting-line checks | High. Two gaps you stated sit against the posting, and a Head of Live Ops will test coordination without authority. | Hold the stated negative, then give the answer slot's honest branch. Never fold. |
| Data-Driven Prober (weight 3) | Defend the retention number; name the assumption behind it | Medium. Your strongest CV line is a number, and probers go to numbers first. | Say how it was counted only if you know; name the weakest assumption before they do. |
| Pressure (weight 2) | One stress probe on the leadership gap or on how much was yours | Lower in a hiring-manager round, possible at any point. | Pause, restate, hold through two follow-ups, concede one specific thing. |
| Conversational (weight 2) | Opener, and a casual question about the two titles | Certain to open the round, and still scored. | Keep the arc to quoted facts. |

A peer or skip-level reading would move Skeptic and Prober up and Case down.

## Question banks

### Case / Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You have two titles and one producer's calendar. Walk me through how you would plan the next quarter. What do you need to know first?" | CASE | [generic] | Clarify before structuring: each title's cadence, what each update needs from design, art, engineering and community, and what success means for each. Then outline the calendar, owners and checkpoints. Make no claim about your past. | Tests R1 live. Generic because it is a problem from the role. |
| C2 | "A content drop lands 20% under its day-7 retention target. Diagnose it." | CASE | [generic] | Clarify what the target measured and how the cohort was defined. Split into content, timing, audience and technical causes. Name the one check you would run first, and the assumption you would test before blaming the content. | Pulls R3 and R7 into one live problem. You answer with method, not a record. |
| C3 | "A balance update needs design, art, engineering and community, and QA says the release checklist is not ready on the day. What do you do?" | CASE | [generic] | Decide what ships, what waits, and who you tell first. Name the blocking checklist step and an owner for each team. | Covers R2 and R4 as a live decision. |
| C4 | "How would you structure a post-event review so its KPIs change a decision?" | CASE | [generic] | Name the decision first, then the one or two metrics that bear on it, then the owner who acts. Say what would make you drop a metric. | Covers R3 as a design question. A method, not a record. |
| C5 | "Tell me how you would write one update to QA and community on the same day about a delayed drop." | CASE | [generic] | Lead with the decision and the new date. Then the reason in one line, then what each group must do. Keep the facts the same in both notes. | Covers R8, which no other question tests. |

### Skeptic and JD fit (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| S1 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never led a team" (your message) | Name the gap you can say plainly, in your words. Coordination is the line your material most needs to answer for, so lead there. Hold: "I haven't led a team." Then a ramp plan you can carry out: how you would learn the four teams' cadence in your first month. | The most direct version of the leadership gap. |
| S2 | "You haven't led a team. This role coordinates four teams that don't report to you. How do you get them to act on your plan?" | JD | [grounded] "Never led a team" (your message) | **The highest-ROI prep in this pack.** Hold through two follow-ups with "I haven't led a team." Then the answer slot: if you got a group to act on a plan without authority over it, name the group and the step, in your own words; if not, say so plainly and say how you would set up the coordination: a shared calendar, a named owner per update, a fixed review. Concede one specific thing you do not know yet, such as how the leads will weigh your calendar against their priorities. Never fold the core claim to restore the room. | The objection most likely to come up in some form. It presupposes the coordination line the posting raises; the stated negative is the plain acknowledgment. F9 and F2 both lean on it. |
| S3 | "Your background is a title with no in-app purchases. How would you plan a calendar for a title that sells them?" | CASE | [grounded] "never worked on a game with in-app purchases" (your message) | Hold: "I haven't worked on a game with in-app purchases." Then a plan: which metrics you would watch first, what you would ask the monetization owners, and how you would keep the calendar from disrupting the economy. Answer slot: if you have seen in-app purchases in any work, say where; if not, say so. | F10. The posting does not raise monetization, so this is a probe to expect, not a line the posting contains. |
| S4 | "Why leave a puzzle studio for a 350-person mobile studio now?" | CO | [generic] | Your material carries no reason, so there is no story to map. Say what the next role needs that your current one does not, in your own words. Name one specific thing about this studio's titles you would want to work on. If you cannot, say what you can name. | A standard skeptic probe. |

### Hiring-manager fit checks (JD-tagged, weight 4 with the Skeptic bank)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| J1 | "Walk me through the release checklist you wrote. How does QA use it today?" | JD | [grounded] "Wrote the release checklist our QA team still uses" (your message) | Describe what it covers, who uses it, and how QA relies on it, in your words. If you cannot say what a given line protects, say so. | R4 and R8. The quote says QA still uses it; the guidance goes no further. |
| J2 | "Three years of live-service producing is the bar. What's yours?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio" (your message) | Say the four years, the studio and your role, in those words. Answer slot: if you would call that title live-service, say why; if the term does not fit, say what the work was. | R5. The posting's label is live-service; your quote gives the years, not the label. |
| J3 | "Which post-event reviews have you run, and what did they change?" | JD | [grounded] "Presented the monthly retention numbers to the studio head" (your message) | Answer slot: if you ran a review after a drop, say what it measured and what it changed; if you presented retention numbers without running a review, say that plainly. Do not describe a review you did not run. | R3. The question presupposes a review the quote does not carry, so its guidance is a slot with the honest branch. |
| J4 | "Your calendar covered one title. This role plans two. How would you split your time?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | Say what the one-title calendar took, in your words, then how you would split the week across two titles. Make no claim about the second title's needs until you have asked. | R1 and R6. |

### Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how the retention numbers you presented were counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head" (your message) | Answer slot: say how the figures were counted, what they are sensitive to, and which part was yours, in your own words. If you do not know how they were counted, say so. The pack supplies no method. | F7. The figure's own defend-the-number slot. |
| D2 | "Which assumption behind those retention numbers would you defend least?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" (your message) | Name the weakest assumption you know of before they do. If you do not know one, say you have not checked it. | Weakest-assumption move. The pack names no assumption. |
| D3 | "What did you measure after each content drop, and what did you decide from it?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | Answer slot: if you measured anything after a drop and acted on it, say what and what you did; if you did not measure per drop, say so plainly. The question presupposes a measurement the quote does not carry. | R3 and R6. |

### Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "That calendar ran for two years. How much of what shipped was actually you?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | Hold through two follow-ups on what you ran: the calendar, for two years. Concede specifically what others set. Answer slot: say which parts of the drops you set and which others did, in your own words. | An attribution probe. The hold rests on your quoted sentence and nothing more. |
| P2 | "Sixty seconds: why should we hire you over someone who has led a team?" | JD | [grounded] "Never led a team" (your message) | Pause and restate. Hold: "I haven't led a team." Then the strongest true thing your material carries: the calendar you ran and the checklist QA still uses. Concede the one thing the other candidate would have that you do not. | A pressure stem. The concession has to be specific, not "I'm not perfect". |

### Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio" and "Wrote the release checklist our QA team still uses" (your message) | A 90-second arc from those quotes and the calendar and retention facts in F1 and F3: studio, calendar, checklist, retention numbers. Keep the order, skip the adjectives. | A casual opener is still scored. The arc names only what is quoted. |
| V2 | "What did you make of our two titles when you read the posting?" | CO | [generic] | No research has run, so say what the posting tells you and nothing more. Name one question you would ask about either title. | Casual, but it scores company depth. Honest, because nothing was researched. |

## Requirement coverage

| Requirement (JD) | Covered by |
|---|---|
| Plan and run the live-events calendar for two titles | C1, J4 |
| Coordinate design, art, engineering and community teams | C3, S2 |
| Own the post-event review and the KPIs | C2, C4, J3, D3 |
| Manage the release checklist with QA | C3, J1 |
| 3+ years producing live-service | J2 |
| Experience running a content calendar | J4, D3 |
| Comfortable with player-retention metrics | C2, D1, D2 |
| Clear written communication | C5, J1 |

## Reverse questions

| Question to ask Tobias | Why it lands |
|---|---|
| "Which of the two titles needs the most attention in the first quarter, and why?" | Shows you read the two-title scope and want to start with the real problem. |
| "How are the calendars for the two titles planned today, who owns each, and where do they overlap?" | A seam question. It shows you have already thought about coordination without authority. |
| "Which KPIs go in front of leadership after a post-event review, and which of them change decisions?" | Points at the post-event duty and tests whether the reviews are used. |
| "How is the release checklist owned today, and what most often causes a drop to slip?" | Links to your checklist and asks for the real failure mode. |
| "Which monetization model do the two titles use, and how much of the calendar does it shape?" | Turns the in-app purchase gap into a question you are curious about. |
| "What would make you say the hire was a success at six months?" | Standard and useful. It shows what the role is scored on. |

No reverse question is tied to Tobias's own career path, because no public profile was researched.

## Sources

- **Provided:** the job description and your background, both in your message.
- **Searches and fetches:** none. You have not consented to research, so this is an L0 pack.

**Research tier:** L0, searches 0 of 0, fetches 0 of 0.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | unavailable | Values cheat sheet, built only if a values-style round is named. |
| 2. `Saltmarsh Games interview process live operations` | unavailable | Loop structure and the persona weights that follow it. |
| 3. `Saltmarsh Games strategy` and recent news | unavailable | Current titles and recent moves, which would make C2 and V2 company-specific. |
| 4. `Tobias Wrenfield Saltmarsh Games` | unavailable | Interviewer read and a tailored reverse question. The name is enough to search; no search was consented to. |
| 5. Representative live operations producer JD | skipped | Your supplied posting already fixes the fit snapshot and the JD-tagged questions. |

## Upgrade menu

- Tobias's public profile → persona weights read from his footprint, and a reverse question tied to his own path.
- Whether Tobias is your future manager, a skip-level or a peer → reweights every bank (asked below).
- The recruiter's note on the round's format and any take-home → coverage of any deliverable.
- Company research at L1 (three searches, one fetch) → a values cheat sheet if a values round is named, and company-specific C2 and C4.
- Anything you have seen of in-app purchases in your work, including talks or reading → an answer for S3 that rests on your own words rather than a slot.
- A `tuesday-dossier.md` from job-underwriter → verified evidence in place of the `[grounded]` quotes above, and a check on F9 and F10.

---

**Offers, not pushed:**
- Say the word and I'll play the Skeptic on S2, the question this pack names as its highest-ROI prep.
- I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
- If you'd like the pack as a Word document, say so and I'll convert it.

**One question:** Is Tobias your future manager, a skip-level, or a peer on the team? The answer reweights every bank.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh_live_operations_producer_interview_pack.md -----
# Interview pack: Live Operations Producer, Saltmarsh Games

**Interviewer:** Tobias Wrenfield, Head of Live Operations. Relationship not stated; built on the hiring-manager prior.
**Research tier:** L0 (your materials only). No company research was run, so nothing here about Saltmarsh's titles, values or strategy comes from outside your message.

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored: VAL (values), EXP (your experience), JD (the posting's requirements), CO (company knowledge), CASE (a live problem).
- Guidance is scaffolding, not a script. Rehearse the beats out loud, in your own words.
- Answer slots (sentences starting "Answer slot:") are instructions for the interview. Either branch is a fair answer.

## Fit snapshot

Requirements are quoted from the posting. Your evidence is quoted from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | medium | [grounded] | transferability | Your material shows one title's weekly content drops, not two titles' live events. Bridge, reworded from the quote only: "For two years I ran the weekly content-drop calendar for our main title." Answer slot: if you planned anything beyond weekly drops, or for more than one title, say what, in your own words; if not, say so and say how you would split the calendar across two titles. |
| F2 | "coordinate design, art, engineering and community teams on each update" (JD) | none given | none | [grounded] | discovery | Your material does not show coordinating those teams. "I ran the calendar" does not say who else moved on a drop. Answer slot: if you coordinated any of those teams on a drop, name which and how you got them to act, in your own words; if you did not, say so plainly and say how you would set it up as a plan. |
| F3 | "own the post-event review and the KPIs it reports" (JD) | "Presented the monthly retention numbers to the studio head" (your message) | medium | [grounded] | transferability | Your material shows you presented retention numbers, not that you ran a post-event review. Bridge: "I presented the monthly retention numbers to the studio head." Answer slot: if you ran a review after a drop, say what it measured and what it changed; if you did not, say so. |
| F4 | "manage the release checklist with QA" (JD) | "Wrote the release checklist our QA team still uses" (your message) | medium | [grounded] | none | No gap, but a single line with nothing inspected behind it, so expect a probe on what it covers. Lead with the quote's own terms: you wrote it, and QA still uses it. |
| F5 | "3+ years producing live-service games or apps" (JD) | "4 years as an associate producer at a puzzle-game studio" (your message) | medium | [grounded] | presentation | The years reach the requirement; your material does not use the words live-service. Bridge, reworded from the quote only: "Four years as an associate producer at a puzzle-game studio." Answer slot: if you would call that title live-service, say why, in your own words. |
| F6 | "experience running a content calendar" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | high | [grounded] | none | Direct match, and your strongest row. Say it in your own words; nothing to add. |
| F7 | "comfortable with player-retention metrics" (JD) | "Presented the monthly retention numbers to the studio head" (your message) | medium | [grounded] | presentation | The quote reaches the requirement in other terms. Bridge, reworded only: "I presented the monthly retention numbers to the studio head." Answer slot: how those figures were counted, which assumption behind them you would defend least, and which part was yours. If you do not know how they were counted, say so. |
| F8 | "clear written communication" (JD) | "Wrote the release checklist our QA team still uses" (your message) | low | [grounded] | presentation | The checklist is a written artifact a team relies on, which reaches the requirement only in part. Bridge, reworded only: "I wrote the release checklist our QA team still uses." Your material does not show written updates to a wider audience. |
| F9 | Lead a team (not in the posting; a gap you raised) | "Never led a team" (your message) | none | [grounded] | capability | A gap you stated, so the words are yours: "I haven't led a team." Then the coordination answer slot in S2, not a claim of leadership. |
| F10 | In-app purchases (not in the posting; a gap you raised) | "never worked on a game with in-app purchases" (your message) | none | [grounded] | capability | A gap you stated: "I haven't worked on a game with in-app purchases." Then the planning answer in S3. |

## Prohibited claims

These are not coached, and no guidance in this pack asserts, softens or implies them.

| Not coached | Basis | Honest form |
|---|---|---|
| "I led a team" or "I managed people" | Negative you stated, F9 | "I haven't led a team." Coordination is covered in S2. |
| Experience with in-app purchases, or on a monetized title | Negative you stated, F10 | "I haven't worked on a game with in-app purchases." |
| "I owned the live-events calendar for two titles" | Inflated form of F1, which is one title's weekly drops | "For two years I ran the weekly content-drop calendar for our main title." Your material says one title's drops, not two titles' events. |
| "I ran post-event reviews and owned the KPIs they report" | Inflated form of F3, which is presenting retention numbers | "I presented the monthly retention numbers to the studio head." Your material does not show a review. |

## Persona table

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist (weight 5) | Live problems on a two-title quarter, a retention drop, a delayed drop | Highest. A hiring-manager round is mostly about whether you can do the job, and the posting lists the job as live problems. | Clarify, then structure, then name the metric. Think aloud. |
| Skeptic and JD fit (weight 4) | Direct questions on the leadership and in-app purchase gaps; posting-line checks | High. Two gaps you stated sit against the posting, and a Head of Live Ops will test coordination without authority. | Hold the stated negative, then give the answer slot's honest branch. Never fold. |
| Data-Driven Prober (weight 3) | Defend the retention number; name the assumption behind it | Medium. Your strongest CV line is a number, and probers go to numbers first. | Say how it was counted only if you know; name the weakest assumption before they do. |
| Pressure (weight 2) | One stress probe on the leadership gap or on how much was yours | Lower in a hiring-manager round, possible at any point. | Pause, restate, hold through two follow-ups, concede one specific thing. |
| Conversational (weight 2) | Opener, and a casual question about the two titles | Certain to open the round, and still scored. | Keep the arc to quoted facts. |

Weights are the hiring-manager prior. A peer or skip-level reading would move Skeptic and Prober up, and Case down.

## Question banks

### Case / Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You have two titles and one producer's calendar. Walk me through how you would plan the next quarter. What do you need to know first?" | CASE | [generic] | Clarify before structuring: each title's current cadence, what each update needs from design, art, engineering and community, and what success means for each. Then outline the calendar, the owners and the checkpoints. Make no claim about your past. | Tests R1 live. Generic because it is a problem from the role, not a fact about you. |
| C2 | "A content drop lands 20% under its day-7 retention target. Diagnose it." | CASE | [generic] | Clarify what the target measured and how the cohort was defined. Split into content, timing, audience and technical causes. Name the one check you would run first, and the assumption you would test before blaming the content. | Pulls R3 and R7 into one live problem. You answer with method, not with a record. |
| C3 | "A balance update needs design, art, engineering and community, and QA says the release checklist is not ready on the day. What do you do?" | CASE | [generic] | Decide what ships, what waits, and who you tell first. Name the checklist step that is blocking, and an owner for each team. | Covers R2 and R4 as a live decision. |
| C4 | "How would you structure a post-event review so its KPIs change a decision?" | CASE | [generic] | Name the decision first, then the one or two metrics that bear on it, then the owner who acts on them. Say what would make you drop a metric. | Covers R3 as a design question. A method, not a record of what you ran. |
| C5 | "Tell me how you would write one update to QA and community on the same day about a delayed drop." | CASE | [generic] | Lead with the decision and the new date. Then the reason in one line, then what each group must do. Keep the facts the same in both notes. | Covers R8, which no other question tests. |

### Skeptic and JD fit (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| S1 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never led a team" (your message) | Name the gap you can say plainly, in your words. Coordination is the line your material most needs to answer for, so lead there. Hold: "I haven't led a team." Then a ramp plan you can carry out: how you would learn the four teams' cadence in your first month. | The most direct version of the leadership gap. |
| S2 | "You haven't led a team. This role coordinates four teams that don't report to you. How do you get them to act on your plan?" | JD | [grounded] "Never led a team" (your message) | **The highest-ROI prep in this pack.** Hold through two follow-ups with "I haven't led a team." Then the answer slot: if you got a group to act on a plan without authority over it, name the group and the step, in your own words; if you did not, say so plainly and say how you would set up the coordination: a shared calendar, a named owner per update, a fixed review. Concede one specific thing you do not know yet, such as how the leads will weigh your calendar against their own priorities. Never fold the core claim to restore the room. | The objection most likely to come up in some form. It presupposes the coordination line the posting raises, and the stated negative is the plain acknowledgment. F9 and F2 both lean on it. |
| S3 | "Your background is a title with no in-app purchases. How would you plan a calendar for a title that sells them?" | CASE | [grounded] "never worked on a game with in-app purchases" (your message) | Hold: "I haven't worked on a game with in-app purchases." Then a plan: which metrics you would watch first, what you would ask the monetization owners, and how you would keep the calendar from disrupting the economy. Answer slot: if you have seen in-app purchases in any work, say where; if not, say so. | F10. The posting does not raise monetization, so the question is the probe you should expect, not a line the posting contains. |
| S4 | "Why leave a puzzle studio for a 350-person mobile studio now?" | CO | [generic] | Your material carries no reason, so there is no story to map. Say what the next role needs that your current one does not, in your own words. Name one specific thing about this studio's titles you would want to work on. If you cannot name one, say what you can name. | A standard skeptic probe. |

### Hiring-manager fit checks (JD-tagged, weight 4 with the Skeptic bank)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| J1 | "Walk me through the release checklist you wrote. How does QA use it today?" | JD | [grounded] "Wrote the release checklist our QA team still uses" (your message) | Describe what it covers, who uses it, and how QA relies on it, in your words. If you cannot say what a given line protects, say so. Keep the description to what you know of it. | R4 and R8. The quote says QA still uses it, and the guidance does not go past that. |
| J2 | "Three years of live-service producing is the bar. What's yours?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio" (your message) | Say the four years, the studio and your role, in those words. Answer slot: if you would call that title live-service, say why, in your own words; if the term does not fit, say what the work was. | R5. The posting's label is live-service; your quote gives the years, not the label. |
| J3 | "Which post-event reviews have you run, and what did they change?" | JD | [grounded] "Presented the monthly retention numbers to the studio head" (your message) | Answer slot: if you ran a review after a drop, say what it measured and what it changed; if you presented retention numbers without running a review, say that plainly. Do not describe a review you did not run. | R3. The question presupposes a review the quote does not carry, so its guidance is a slot with the honest branch. |
| J4 | "Your calendar covered one title. This role plans two. How would you split your time?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | Say what the one-title calendar took, in your words, then how you would split the week across two titles. Make no claim about the second title's needs until you have asked about them. | R1 and R6. |

### Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how the retention numbers you presented were counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head" (your message) | Answer slot: say how the figures were counted, what they are sensitive to, and which part was yours, in your own words. If you do not know how they were counted, say so. The pack supplies no method. | F7. The figure's own defend-the-number slot. |
| D2 | "Which assumption behind those retention numbers would you defend least?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" (your message) | Name the weakest assumption you know of before they do. If you do not know one, say you have not checked it. | Weakest-assumption move. The pack names no assumption. |
| D3 | "What did you measure after each content drop, and what did you decide from it?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | Answer slot: if you measured anything after a drop and acted on it, say what and what you did; if you did not measure per drop, say so plainly. The question presupposes a measurement the quote does not carry. | R3 and R6. |

### Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "That calendar ran for two years. How much of what shipped was actually you?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | Hold through two follow-ups on what you ran: the calendar, for two years. Concede specifically what others set. Answer slot: say which parts of the drops you set and which others did, in your own words. | An attribution probe. The hold is on your quoted sentence and nothing more. |
| P2 | "Sixty seconds: why should we hire you over someone who has led a team?" | JD | [grounded] "Never led a team" (your message) | Pause and restate. Hold: "I haven't led a team." Then the strongest true thing your material carries: the calendar you ran and the checklist QA still uses. Concede the one thing the other candidate would have that you do not. | A pressure stem. The concession has to be specific, not "I'm not perfect". |

### Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio" and "Wrote the release checklist our QA team still uses" (your message) | A 90-second arc from those quotes and the calendar and retention facts in F1 and F3: studio, calendar, checklist, retention numbers. Keep the order, skip the adjectives. | A casual opener is still scored. The arc names only what is quoted. |
| V2 | "What did you make of our two titles when you read the posting?" | CO | [generic] | No research has run, so say what the posting tells you and nothing more. Name one question you would ask about either title. | Casual, but it scores company depth. Honest because nothing was researched. |

## Requirement coverage

| Requirement (JD) | Covered by |
|---|---|
| Plan and run the live-events calendar for two titles | C1, J4 |
| Coordinate design, art, engineering and community teams | C3, S2 |
| Own the post-event review and the KPIs | C2, C4, J3, D3 |
| Manage the release checklist with QA | C3, J1 |
| 3+ years producing live-service | J2 |
| Experience running a content calendar | J4, D3 |
| Comfortable with player-retention metrics | C2, D1, D2 |
| Clear written communication | C5, J1 |

## Reverse questions

| Question to ask Tobias | Why it lands |
|---|---|
| "Which of the two titles needs the most attention in the first quarter, and why?" | Shows you read the two-title scope and want to start with the real problem. |
| "How are the calendars for the two titles planned today, who owns each, and where do they overlap?" | A seam question. It shows you have already thought about coordination without authority. |
| "Which KPIs go in front of leadership after a post-event review, and which of them change decisions?" | Points straight at the post-event duty, and tests whether the reviews are used. |
| "How is the release checklist owned today, and what most often causes a drop to slip?" | Links to your checklist and asks for the real failure mode. |
| "Which monetization model do the two titles use, and how much of the calendar does it shape?" | Turns the in-app purchase gap into a question you are curious about. |
| "What would make you say the hire was a success at six months?" | Standard and useful. It shows what the role is scored on. |

No reverse question is tied to Tobias's own career path, because no public profile was researched. The upgrade menu says what one would add.

## Sources

- **Provided:** the job description and your background, both in your message.
- **Searches and fetches:** none. You have not consented to research, so this is an L0 pack.

**Research tier:** L0, searches 0 of 0, fetches 0 of 0.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | unavailable | Values cheat sheet, which would be built only if a values-style round is named. |
| 2. `Saltmarsh Games interview process live operations` | unavailable | Loop structure, and the persona weights that would follow it. |
| 3. `Saltmarsh Games strategy` and recent news | unavailable | Current titles and recent moves, which would make C2 and V2 specific to the company. |
| 4. `Tobias Wrenfield Saltmarsh Games` | unavailable | Interviewer read and a tailored reverse question. The name is enough to search, but no search was consented to. |
| 5. Representative live operations producer JD | skipped | Your supplied posting fixes the fit snapshot and the JD-tagged questions. |

## Upgrade menu

- Tobias's public profile → persona weights read from his footprint, and a reverse question tied to his own path.
- Whether Tobias is your future manager, a skip-level or a peer → reweights every bank (asked below).
- The recruiter's note on the round's format and any take-home → coverage of any deliverable.
- Company research at L1 (three searches, one fetch) → values cheat sheet if a values round is named, and a company-specific C2 and C4.
- Anything you have seen of in-app purchases in your work, including talks or reading → an answer for S3 that rests on your own words rather than a slot.
- A `tuesday-dossier.md` from job-underwriter → verified evidence in place of the `[grounded]` quotes above, and a check on F9 and F10.
