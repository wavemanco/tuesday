I couldn't run the web research: the search permission was declined, so the pack relies on your JD and your background only. I'll write the pack to a file and then present it in full.
Your prep pack is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-alone-part-2-rooms-case-2-denied-e458f344/0d8779e2-68ba-42fd-b949-e1c88df0b3f9/scratchpad/atlas_freight_operations_manager_interview_pack.md`. I built it for a hiring-manager round, since your note didn't say who you're meeting. Web search was declined, so it uses only your JD and background.

# Interview prep: Operations Manager, Atlas Freight

**Round:** not stated. Built as a hiring-manager round, since your note didn't say who you're meeting.
**Interviewer:** not named.
**Requirements:** the JD in your message. **Background:** your message (no CV file).

## How to use this pack

Personas are how a question is asked. Types are what it scores:

- **VAL**: behavioral and values alignment
- **EXP**: deep-dive on your own work
- **JD**: the role's stated requirements
- **CO**: company and strategy knowledge
- **CASE**: a live problem

Guidance is scaffolding, not a script. Lines marked *Answer slot* tell you what to say when a question lands on a gap: give the true branch in your own words.

Left out because the inputs don't support them: prep triage (no time given), values cheat sheet (no round detected), grounding brief and interviewer read (no research, no interviewer), graded deliverables (none declared), delivery coaching (no assessment).

## 1. Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" — JD | "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | Your material describes one site's shift leadership, not terminal operations across four. Bridge: "Right now I'm a senior shift manager over three supervisors." Answer slot: if you have run operations across more than one site, say which and what you were responsible for; if you haven't, say so, and say how you would run four. |
| F2 | "drive on-time performance and cost-per-shipment down" — JD | "cut mis-pick rate 40% by redesigning the pick path" — your message | medium | [grounded] | transferability | Mis-pick accuracy is adjacent to on-time performance and cost per shipment, not the same measure, and your material shows neither of those. Bridge: "The number I can point to is mis-picks: I cut the mis-pick rate 40% by redesigning the pick path." Answer slot: if you have moved on-time performance or cost per shipment, say the figure and how it was counted; if you haven't, say so and name the measure you would look at first. |
| F3 | "lead a team of 12 supervisors" — JD | "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | Three supervisors is adjacent to twelve, and the span is the larger step. Bridge: "I lead three supervisors now." Answer slot: if you have led a larger team or more layers, say the number; if not, say so, and say how you would build the team in the first ninety days. |
| F4 | "build reporting in Excel" (Excel part) — JD | "solid Excel" — your message | low | [grounded] | discovery | Your material says Excel is solid, not what you have built in it. No bridge is asserted. Answer slot: name a report you built in Excel, what it tracked and who used it; if you haven't built one, say so and describe the first report you would build. |
| F5 | "build reporting in Excel/Power BI" (Power BI part) — JD | "never used Power BI" — your message | none | [grounded] | capability | Your own words: "I haven't used Power BI." Then how you would learn it, as a plan, never as a past. |
| F6 | "5+ years operations leadership required" — JD | "7 years in warehouse and distribution ops" — your message; "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | discovery | Years in operations are shown; years leading people are not. Answer slot: say how many years you have led people and when that began; if fewer than five, say the number and don't round it up. |
| F7 | "Lean/Six Sigma a plus" — JD | "green belt certified" — your message | medium | [grounded] | none | No gap: the quote reaches the requirement. Bridge: "I'm Green Belt certified." Confidence is medium because no certificate has been inspected. |

The JD states no gate (authorization, licence, location, schedule), so no row is `hard_gate`. "5+ years" is a years requirement, graded on the evidence above.

## 2. Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| "Owned terminal operations across four sites" | Inflated form of F1 | "currently a senior shift manager over 3 supervisors," at its own scope. The limit is this pack's observation: your material describes one site. |
| "Led twelve supervisors" or "led a team of 12" | Inflated form of F3 | "currently a senior shift manager over 3 supervisors," at its own scope. The span gap is this pack's observation. |
| "Improved on-time performance or cost per shipment" | Inflated form of F2 | "cut mis-pick rate 40% by redesigning the pick path," at its own scope. Your material shows a mis-pick rate. |
| "Built reporting in Excel" or "built Power BI reports" | Inflated form of F4 (Excel); stated negative (Power BI) | Excel: "solid Excel," at its own scope. Power BI: "I haven't used Power BI," the plain acknowledgment of your stated "never used Power BI." |
| "Five years of operations leadership" | Inflated form of F6 | "7 years in warehouse and distribution ops," at its own scope. Leadership years are an answer slot. |

## 3. Persona weights

Built for a hiring-manager round, which is an assumption from your note, not a fact. The relationship prior puts Skeptic and Case/Strategist first, and your fit snapshot adds Pressure and Data-Driven Prober.

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | "You manage three supervisors. Why twelve?" | 5 (top). The span gap (F3) and the Power BI gap (F5) are the two most visible misses against the JD. | Restate the span, hold it, then concede specifically. |
| Case/Strategist | Live diagnosis of on-time performance or cost | 4. Hiring managers test capability live, and the JD's first two responsibilities are operational. | Clarify, segment, rank hypotheses, name one risk. |
| Data-Driven Prober | "How was the 40% counted?" and reporting questions | 3. One headline figure (F2) and an Excel-only base (F4) invite probing. | Name the counting method only if you know it; otherwise say so. |
| Pressure | "How much of that was actually you?" | 3. The 40% and the three-supervisor span are where composure is tested. | Hold the part you did; concede what you can't attribute. |
| Conversational | "Walk me through the journey." | 2. Casual openers are still scored. | A 90-second arc in your own sentences. |
| Values/Behavioral | "A time you delivered bad news upward." | 2. No published values detected, so these are behavioral stories with no VAL tag. | Selection scaffold; say so if no story fits. |
| Peer | "Where's the seam between our teams?" | 2. Depends on the round, which is unknown. | Propose seam principles, not a map you haven't seen. |

## 4. Question banks

Depth follows weight: the top persona gets 4, mid-weight personas 3, low-weight personas 2.

### A. Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You manage three supervisors today. What makes you ready to lead twelve across four sites?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" — your message | Say the current span in your words: three supervisors. Then name any part of a wider team or footprint your current work has actually exercised, and only what you did. Answer slot: if you have led more supervisors or layers than three, say the number; if not, say so plainly and say how you would build the team in the first ninety days. Hold through two follow-ups by returning to the three. | F3 is the largest span gap in the snapshot and the objection a hiring manager is most likely to press. JD because it scores the twelve-supervisor requirement. This is the highest-ROI rehearsal in the pack. |
| A2 | "How many years have you led people in operations, as opposed to working in them?" | JD | [grounded] "7 years in warehouse and distribution ops" — your message; "currently a senior shift manager over 3 supervisors" — your message | Give the leadership number first, then the operations number. Answer slot: say how many years you have led people and when that began; if fewer than five, say the number and don't round it up. Name what your seven years in operations covered that is closest to leading, in your own words. | F6 is a discovery gap. The five-year requirement is a years figure, not a gate, so the answer is judged on evidence. |
| A3 | "You redesigned the pick path. Did you design it, or lead the people who did?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" — your message | Answer in your own words: which parts you designed and which you led others on. Answer slot: if you designed a part, say which and how you decided; if you led the people who did it, say so and say your part in it; if it was not yours, say so plainly and return to the 40%. | F2 carries the 40% figure, and attribution is the probe most likely to follow it. |
| A4 | "This role builds reporting in Excel and Power BI. You haven't used Power BI. Why would you be effective at reporting here within six months?" | JD | [grounded] "never used Power BI" — your message; "solid Excel" — your message | Open with the plain acknowledgment: I haven't used Power BI. Then say how you would learn it and by when, as a plan. Hold the plan. Answer slot: if you have built a report in Excel that others used, name what it tracked and who used it; if you haven't, say so and describe the first report you would build. Don't describe Power BI as something you can do. | F5 is a stated absence; the acknowledgment has its source. F4 covers the Excel half. |

### B. Case/Strategist (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A site's on-time performance has dropped over the last few weeks. What would you do about it?" | JD | [generic] | Clarify what counts as on time, and which sites and lanes. Split the drop by shift, dock and carrier before deciding anything. Rank hypotheses by how quickly each can be checked. Name one risk of changing the process before the cause is known. About 90 seconds. | Drive on-time performance is the JD's first operational responsibility. A generic live problem: it makes no claim about your past. CASE delivery. |
| B2 | "Cost per shipment has risen while volumes stayed flat. Where do you start?" | JD | [generic] | Ask how cost per shipment is defined, then break it into labor hours per shipment, overtime and extra handling, and see which part moved. Name a lever only after that. Name one number you would not trust without checking. | Cost per shipment is a JD requirement. Generic; no claim about your past. CASE delivery. |
| B3 | "Four sites, one operations manager. How do you decide which site gets your time this week?" | JD | [generic] | Give three criteria in order: customer impact, cost impact, and whether the problem is getting worse. Then say how you would keep the other sites moving while you are at one. | The four-site requirement is F1's gap. The question is generic and asks about no past. CASE delivery. |
| B4 | "Peak season is six weeks out and the labor plan is short. Walk me through what you'd do first." | CASE | [generic] | Clarify the demand forecast and what is confirmed. Triage the shortfall by which operations are most time-critical. Name the decision you need this week and who has to sign off on overtime. | A live problem from the role. The live counterpart of your peak-season experience, without claiming it. |

### C. Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "How was the 40% mis-pick reduction counted? What was the baseline and the period?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" — your message | Weakest-assumption move: name the assumption behind the 40% you would defend least, before they do. Then say how the rate was counted, in your own words. Answer slot: if you know the counting method, say it exactly; if you don't, say plainly that you don't know how it was counted, and say what you do know about where the number came from. | F2's figure raises the defend-the-number slots: how it was counted, what it's sensitive to, the weakest assumption, and which part was yours. |
| C3 | "What would you show me to prove the peak-season surge plan worked?" | EXP | [grounded] "ran the site's peak-season surge plan two years running" — your message | Name the figure first, if you have one, and how it was counted. Answer slot: if the plan produced a measure, name it and what it counted; if it didn't, say so plainly and say what you would have measured. Don't reach for an outcome you can't show. | Your peak-season work is a headline story. A prober asks for the evidence, not the story. |
| C4 | "Show me how you'd build a weekly on-time performance report for four sites." | JD | [grounded] "solid Excel" — your message | Describe what the report would hold: the measure, the grain, the audience, the cut-off. Answer slot: if you have built a report that tracked a performance measure, name the measure, the audience and how often it ran; if you haven't, say so and describe the report you would build first. Don't name a tool you haven't used as if you had. | The reporting requirement, asked as a build. F4 is a discovery gap. |

### D. Pressure (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You have three supervisors today. Why should we trust you with twelve?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" — your message; "7 years in warehouse and distribution ops" — your message | Pause and restate: "You're asking whether three is enough preparation for twelve." Answer in about 60 seconds, using your seven years and your three supervisors, each in your words. Hold through two follow-ups. Concede the span specifically: three is not twelve, and the first months would test that. | The Skeptic's objection under time pressure. Hold the seven years and the three supervisors; concede the span, not the core. |
| D2 | "That 40% — how much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" — your message | Hold-then-concede. Hold on the part you did, in the words you used above. Concede specifically on anything you can't attribute to yourself. Answer slot: if you did this, say how; if it was not yours, say so plainly and return to the figure you can defend. | The attribution probe. It overlaps C1 on purpose: the same figure, under pressure. |
| D3 | "You've never used Power BI. Why should we believe you'll pick it up?" | JD | [grounded] "never used Power BI" — your message | Say it plainly: I haven't used Power BI. Then say how you would learn it, with a date and a check, not a claim of speed. Don't argue the premise. | The second pass at the Power BI objection, under pressure. The premise is your own stated negative. |

### E. Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So — walk me through the journey." | EXP | [grounded] "7 years in warehouse and distribution ops" — your message; "currently a senior shift manager over 3 supervisors" — your message; "cut mis-pick rate 40% by redesigning the pick path" — your message | A 90-second arc: the seven years, the senior shift manager role over three supervisors, the pick path work with its 40% figure, then the peak-season plan. One sentence each, in your words. End on what you want next, in one sentence. Add nothing the quotes don't carry. | Casual openers are scored. This arc is the answer to "tell me about yourself." |
| E2 | "What are you actually doing with Lean and Six Sigma these days?" | JD | [grounded] "green belt certified" — your message | Name the belt and what it covered. Answer slot: if you applied the method to a project, name the project and the steps you used; if you did not, say so plainly and say what the certification taught you. | F7 has no gap, but the question is casual and scored. |

### F. Values/Behavioral (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Tell me about a time you delivered an unwelcome result to someone senior." | EXP | [generic] | Selection scaffold: pick a time you had to tell someone senior that a plan would miss. It needs a named stake, a moment you didn't soften the number, and a working relationship intact at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it. | No published values were detected, so this is EXP, not VAL. No candidate sentence carries this story, so it is a scaffold. |
| F2 | "Tell me about a time you changed a process people were attached to. How did you bring them with you?" | EXP | [generic] "cut mis-pick rate 40% by redesigning the pick path" — your message | Selection scaffold: pick a process change you led or helped lead. Name who resisted, what evidence you used, and what you did with the resistance. The pick path redesign may be it, if you were part of it. If no change comes to mind, say so and give the nearest thing your material carries. | The pick path is the only change your material names, so it is offered as a candidate instance, not a claim. |

### G. Peer (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Our teams sit side by side on this site. Where's the seam, and what happens when we disagree?" | EXP | [generic] | Propose seam principles, not a map you haven't seen: who decides a handoff, how an open disagreement gets settled, and what you would ask them first. Give a disagreement you have had with a peer only if your material carries one; otherwise give the principle. | The peer read. Behavioral, with no published values, so not VAL. |
| G2 | "If we hired you, what would you need from my team in the first month?" | JD | [generic] | Name two or three specific needs tied to the four sites: site data, supervisor roles, the reporting baseline. Ask for the one you would need first. | A reciprocity question that shows you're planning the role. |

### Requirement coverage

| JD requirement | Questions |
|---|---|
| Own daily terminal operations across 4 sites | A1, B3 |
| Drive on-time performance and cost-per-shipment down | B1, B2, C1 |
| Lead a team of 12 supervisors | A1, D1 |
| Build reporting in Excel/Power BI | A4, C4, D3 |
| 5+ years operations leadership required | A2 |
| Lean/Six Sigma a plus | E2 |

Session total: 20 questions across seven personas.

## 5. Reverse questions

Each one has a "why it lands."

1. "What does on-time performance look like at each of the four sites right now, and which is furthest from target?" Why it lands: it shows you read the JD and want the real baseline.
2. "How is cost per shipment measured here, and who owns that number?" Why it lands: it tests the reporting culture and shows you care about definitions.
3. "What does reporting look like today, what gets built in Excel, and what would you hope a Power BI setup replaces?" Why it lands: it surfaces the tool gap honestly, in their terms.
4. "What would you need from the person in this role in the first ninety days?" Why it lands: it signals ownership, and the answer tells you the real scope.
5. "How are the twelve supervisors split across the four sites, and who has been in the role longest?" Why it lands: it shows you understand the span.
6. "What does success look like at the end of year one, in numbers?" Why it lands: it signals you expect to be measured.

## 6. Sources

Provided documents: the JD text and the background sentences in your message. No CV file, no interviewer information.

Search calls sent this engagement, refused ones included:

- "Atlas Freight regional logistics company": refused (the host declined search permission).
- "Atlas Freight operations manager interview process": refused (the host declined search permission).

Research tier: L1 — searches 2 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Atlas Freight values` | unavailable | Section 4 values cheat sheet, only if a values round were detected; none was. No call sent; the host declined search permission. |
| 2. `Atlas Freight interview process operations` | unavailable | Persona weights and loop structure. Query refused. |
| 3. `Atlas Freight strategy` / recent news | unavailable | Grounding brief and CO questions. No call sent; the host declined search permission. |
| 4. Interviewer name | n/a | No name given, so there was no query to form. |
| 5. Representative operations manager JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions. |
| Company identity check (un-numbered) | unavailable | Would have confirmed the company's scale and existence before the pack described it. Query refused. |

## 7. Upgrade menu

- Your interviewer's name, title and public background → persona weights from their footprint, and a reverse question tied to their career path.
- Your CV as text → quotes from it replace the background sentences you typed, and your leadership years get checked against it.
- Your Green Belt certificate → F7 confidence moves from medium to high.
- One Excel report you built (even a screenshot) → F4 moves from discovery to medium if it exists, and A4's Excel slot gets a concrete example.
- Web search permission → company values, interview process and recent news. Target rows 1–3 move from unavailable to yes, and the grounding brief can be built. A deep research pass (up to six more searches and two more fetches) also needs that permission.
- The recruiter's prep email → coverage of any deliverable or focus area they name.
- A `tuesday-dossier.md` from an earlier evaluation → verified evidence and a prohibited-claims list from that run.

---

Want a live drill? I can play the Skeptic on A1, the span question you'll most likely face.

I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.

If you'd like the pack as a Word document, say so and I'll convert it.

Who are you meeting: your future manager, a peer, or a panel? The answer reweights every bank.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: atlas_freight_operations_manager_interview_pack.md -----
# Interview prep: Operations Manager, Atlas Freight

**Round:** not stated. Built as a hiring-manager round, since your note didn't say who you're meeting.
**Interviewer:** not named.
**Requirements:** the JD in your message. **Background:** your message (no CV file).

## How to use this pack

Personas are how a question is asked. Types are what it scores:

- **VAL**: behavioral and values alignment
- **EXP**: deep-dive on your own work
- **JD**: the role's stated requirements
- **CO**: company and strategy knowledge
- **CASE**: a live problem

Guidance is scaffolding, not a script. Lines marked *Answer slot* tell you what to say when a question lands on a gap: give the true branch in your own words.

Left out because the inputs don't support them: prep triage (no time given), values cheat sheet (no round detected), grounding brief and interviewer read (no research, no interviewer), graded deliverables (none declared), delivery coaching (no assessment).

## 1. Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" — JD | "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | Your material describes one site's shift leadership, not terminal operations across four. Bridge: "Right now I'm a senior shift manager over three supervisors." Answer slot: if you have run operations across more than one site, say which and what you were responsible for; if you haven't, say so, and say how you would run four. |
| F2 | "drive on-time performance and cost-per-shipment down" — JD | "cut mis-pick rate 40% by redesigning the pick path" — your message | medium | [grounded] | transferability | Mis-pick accuracy is adjacent to on-time performance and cost per shipment, not the same measure, and your material shows neither of those. Bridge: "The number I can point to is mis-picks: I cut the mis-pick rate 40% by redesigning the pick path." Answer slot: if you have moved on-time performance or cost per shipment, say the figure and how it was counted; if you haven't, say so and name the measure you would look at first. |
| F3 | "lead a team of 12 supervisors" — JD | "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | Three supervisors is adjacent to twelve, and the span is the larger step. Bridge: "I lead three supervisors now." Answer slot: if you have led a larger team or more layers, say the number; if not, say so, and say how you would build the team in the first ninety days. |
| F4 | "build reporting in Excel" (Excel part) — JD | "solid Excel" — your message | low | [grounded] | discovery | Your material says Excel is solid, not what you have built in it. No bridge is asserted. Answer slot: name a report you built in Excel, what it tracked and who used it; if you haven't built one, say so and describe the first report you would build. |
| F5 | "build reporting in Excel/Power BI" (Power BI part) — JD | "never used Power BI" — your message | none | [grounded] | capability | Your own words: "I haven't used Power BI." Then how you would learn it, as a plan, never as a past. |
| F6 | "5+ years operations leadership required" — JD | "7 years in warehouse and distribution ops" — your message; "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | discovery | Years in operations are shown; years leading people are not. Answer slot: say how many years you have led people and when that began; if fewer than five, say the number and don't round it up. |
| F7 | "Lean/Six Sigma a plus" — JD | "green belt certified" — your message | medium | [grounded] | none | No gap: the quote reaches the requirement. Bridge: "I'm Green Belt certified." Confidence is medium because no certificate has been inspected. |

The JD states no gate (authorization, licence, location, schedule), so no row is `hard_gate`. "5+ years" is a years requirement, graded on the evidence above.

## 2. Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| "Owned terminal operations across four sites" | Inflated form of F1 | "currently a senior shift manager over 3 supervisors," at its own scope. The limit is this pack's observation: your material describes one site. |
| "Led twelve supervisors" or "led a team of 12" | Inflated form of F3 | "currently a senior shift manager over 3 supervisors," at its own scope. The span gap is this pack's observation. |
| "Improved on-time performance or cost per shipment" | Inflated form of F2 | "cut mis-pick rate 40% by redesigning the pick path," at its own scope. Your material shows a mis-pick rate. |
| "Built reporting in Excel" or "built Power BI reports" | Inflated form of F4 (Excel); stated negative (Power BI) | Excel: "solid Excel," at its own scope. Power BI: "I haven't used Power BI," the plain acknowledgment of your stated "never used Power BI." |
| "Five years of operations leadership" | Inflated form of F6 | "7 years in warehouse and distribution ops," at its own scope. Leadership years are an answer slot. |

## 3. Persona weights

Built for a hiring-manager round, which is an assumption from your note, not a fact. The relationship prior puts Skeptic and Case/Strategist first, and your fit snapshot adds Pressure and Data-Driven Prober.

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | "You manage three supervisors. Why twelve?" | 5 (top). The span gap (F3) and the Power BI gap (F5) are the two most visible misses against the JD. | Restate the span, hold it, then concede specifically. |
| Case/Strategist | Live diagnosis of on-time performance or cost | 4. Hiring managers test capability live, and the JD's first two responsibilities are operational. | Clarify, segment, rank hypotheses, name one risk. |
| Data-Driven Prober | "How was the 40% counted?" and reporting questions | 3. One headline figure (F2) and an Excel-only base (F4) invite probing. | Name the counting method only if you know it; otherwise say so. |
| Pressure | "How much of that was actually you?" | 3. The 40% and the three-supervisor span are where composure is tested. | Hold the part you did; concede what you can't attribute. |
| Conversational | "Walk me through the journey." | 2. Casual openers are still scored. | A 90-second arc in your own sentences. |
| Values/Behavioral | "A time you delivered bad news upward." | 2. No published values detected, so these are behavioral stories with no VAL tag. | Selection scaffold; say so if no story fits. |
| Peer | "Where's the seam between our teams?" | 2. Depends on the round, which is unknown. | Propose seam principles, not a map you haven't seen. |

## 4. Question banks

Depth follows weight: the top persona gets 4, mid-weight personas 3, low-weight personas 2.

### A. Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You manage three supervisors today. What makes you ready to lead twelve across four sites?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" — your message | Say the current span in your words: three supervisors. Then name any part of a wider team or footprint your current work has actually exercised, and only what you did. Answer slot: if you have led more supervisors or layers than three, say the number; if not, say so plainly and say how you would build the team in the first ninety days. Hold through two follow-ups by returning to the three. | F3 is the largest span gap in the snapshot and the objection a hiring manager is most likely to press. JD because it scores the twelve-supervisor requirement. This is the highest-ROI rehearsal in the pack. |
| A2 | "How many years have you led people in operations, as opposed to working in them?" | JD | [grounded] "7 years in warehouse and distribution ops" — your message; "currently a senior shift manager over 3 supervisors" — your message | Give the leadership number first, then the operations number. Answer slot: say how many years you have led people and when that began; if fewer than five, say the number and don't round it up. Name what your seven years in operations covered that is closest to leading, in your own words. | F6 is a discovery gap. The five-year requirement is a years figure, not a gate, so the answer is judged on evidence. |
| A3 | "You redesigned the pick path. Did you design it, or lead the people who did?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" — your message | Answer in your own words: which parts you designed and which you led others on. Answer slot: if you designed a part, say which and how you decided; if you led the people who did it, say so and say your part in it; if it was not yours, say so plainly and return to the 40%. | F2 carries the 40% figure, and attribution is the probe most likely to follow it. |
| A4 | "This role builds reporting in Excel and Power BI. You haven't used Power BI. Why would you be effective at reporting here within six months?" | JD | [grounded] "never used Power BI" — your message; "solid Excel" — your message | Open with the plain acknowledgment: I haven't used Power BI. Then say how you would learn it and by when, as a plan. Hold the plan. Answer slot: if you have built a report in Excel that others used, name what it tracked and who used it; if you haven't, say so and describe the first report you would build. Don't describe Power BI as something you can do. | F5 is a stated absence; the acknowledgment has its source. F4 covers the Excel half. |

### B. Case/Strategist (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A site's on-time performance has dropped over the last few weeks. What would you do about it?" | JD | [generic] | Clarify what counts as on time, and which sites and lanes. Split the drop by shift, dock and carrier before deciding anything. Rank hypotheses by how quickly each can be checked. Name one risk of changing the process before the cause is known. About 90 seconds. | Drive on-time performance is the JD's first operational responsibility. A generic live problem: it makes no claim about your past. CASE delivery. |
| B2 | "Cost per shipment has risen while volumes stayed flat. Where do you start?" | JD | [generic] | Ask how cost per shipment is defined, then break it into labor hours per shipment, overtime and extra handling, and see which part moved. Name a lever only after that. Name one number you would not trust without checking. | Cost per shipment is a JD requirement. Generic; no claim about your past. CASE delivery. |
| B3 | "Four sites, one operations manager. How do you decide which site gets your time this week?" | JD | [generic] | Give three criteria in order: customer impact, cost impact, and whether the problem is getting worse. Then say how you would keep the other sites moving while you are at one. | The four-site requirement is F1's gap. The question is generic and asks about no past. CASE delivery. |
| B4 | "Peak season is six weeks out and the labor plan is short. Walk me through what you'd do first." | CASE | [generic] | Clarify the demand forecast and what is confirmed. Triage the shortfall by which operations are most time-critical. Name the decision you need this week and who has to sign off on overtime. | A live problem from the role. The live counterpart of your peak-season experience, without claiming it. |

### C. Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "How was the 40% mis-pick reduction counted? What was the baseline and the period?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" — your message | Weakest-assumption move: name the assumption behind the 40% you would defend least, before they do. Then say how the rate was counted, in your own words. Answer slot: if you know the counting method, say it exactly; if you don't, say plainly that you don't know how it was counted, and say what you do know about where the number came from. | F2's figure raises the defend-the-number slots: how it was counted, what it's sensitive to, the weakest assumption, and which part was yours. |
| C3 | "What would you show me to prove the peak-season surge plan worked?" | EXP | [grounded] "ran the site's peak-season surge plan two years running" — your message | Name the figure first, if you have one, and how it was counted. Answer slot: if the plan produced a measure, name it and what it counted; if it didn't, say so plainly and say what you would have measured. Don't reach for an outcome you can't show. | Your peak-season work is a headline story. A prober asks for the evidence, not the story. |
| C4 | "Show me how you'd build a weekly on-time performance report for four sites." | JD | [grounded] "solid Excel" — your message | Describe what the report would hold: the measure, the grain, the audience, the cut-off. Answer slot: if you have built a report that tracked a performance measure, name the measure, the audience and how often it ran; if you haven't, say so and describe the report you would build first. Don't name a tool you haven't used as if you had. | The reporting requirement, asked as a build. F4 is a discovery gap. |

### D. Pressure (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You have three supervisors today. Why should we trust you with twelve?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" — your message; "7 years in warehouse and distribution ops" — your message | Pause and restate: "You're asking whether three is enough preparation for twelve." Answer in about 60 seconds, using your seven years and your three supervisors, each in your words. Hold through two follow-ups. Concede the span specifically: three is not twelve, and the first months would test that. | The Skeptic's objection under time pressure. Hold the seven years and the three supervisors; concede the span, not the core. |
| D2 | "That 40% — how much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" — your message | Hold-then-concede. Hold on the part you did, in the words you used above. Concede specifically on anything you can't attribute to yourself. Answer slot: if you did this, say how; if it was not yours, say so plainly and return to the figure you can defend. | The attribution probe. It overlaps C1 on purpose: the same figure, under pressure. |
| D3 | "You've never used Power BI. Why should we believe you'll pick it up?" | JD | [grounded] "never used Power BI" — your message | Say it plainly: I haven't used Power BI. Then say how you would learn it, with a date and a check, not a claim of speed. Don't argue the premise. | The second pass at the Power BI objection, under pressure. The premise is your own stated negative. |

### E. Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So — walk me through the journey." | EXP | [grounded] "7 years in warehouse and distribution ops" — your message; "currently a senior shift manager over 3 supervisors" — your message; "cut mis-pick rate 40% by redesigning the pick path" — your message | A 90-second arc: the seven years, the senior shift manager role over three supervisors, the pick path work with its 40% figure, then the peak-season plan. One sentence each, in your words. End on what you want next, in one sentence. Add nothing the quotes don't carry. | Casual openers are scored. This arc is the answer to "tell me about yourself." |
| E2 | "What are you actually doing with Lean and Six Sigma these days?" | JD | [grounded] "green belt certified" — your message | Name the belt and what it covered. Answer slot: if you applied the method to a project, name the project and the steps you used; if you did not, say so plainly and say what the certification taught you. | F7 has no gap, but the question is casual and scored. |

### F. Values/Behavioral (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Tell me about a time you delivered an unwelcome result to someone senior." | EXP | [generic] | Selection scaffold: pick a time you had to tell someone senior that a plan would miss. It needs a named stake, a moment you didn't soften the number, and a working relationship intact at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it. | No published values were detected, so this is EXP, not VAL. No candidate sentence carries this story, so it is a scaffold. |
| F2 | "Tell me about a time you changed a process people were attached to. How did you bring them with you?" | EXP | [generic] "cut mis-pick rate 40% by redesigning the pick path" — your message | Selection scaffold: pick a process change you led or helped lead. Name who resisted, what evidence you used, and what you did with the resistance. The pick path redesign may be it, if you were part of it. If no change comes to mind, say so and give the nearest thing your material carries. | The pick path is the only change your material names, so it is offered as a candidate instance, not a claim. |

### G. Peer (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Our teams sit side by side on this site. Where's the seam, and what happens when we disagree?" | EXP | [generic] | Propose seam principles, not a map you haven't seen: who decides a handoff, how an open disagreement gets settled, and what you would ask them first. Give a disagreement you have had with a peer only if your material carries one; otherwise give the principle. | The peer read. Behavioral, with no published values, so not VAL. |
| G2 | "If we hired you, what would you need from my team in the first month?" | JD | [generic] | Name two or three specific needs tied to the four sites: site data, supervisor roles, the reporting baseline. Ask for the one you would need first. | A reciprocity question that shows you're planning the role. |

### Requirement coverage

| JD requirement | Questions |
|---|---|
| Own daily terminal operations across 4 sites | A1, B3 |
| Drive on-time performance and cost-per-shipment down | B1, B2, C1 |
| Lead a team of 12 supervisors | A1, D1 |
| Build reporting in Excel/Power BI | A4, C4, D3 |
| 5+ years operations leadership required | A2 |
| Lean/Six Sigma a plus | E2 |

Session total: 20 questions across seven personas.

## 5. Reverse questions

Each one has a "why it lands."

1. "What does on-time performance look like at each of the four sites right now, and which is furthest from target?" Why it lands: it shows you read the JD and want the real baseline.
2. "How is cost per shipment measured here, and who owns that number?" Why it lands: it tests the reporting culture and shows you care about definitions.
3. "What does reporting look like today, what gets built in Excel, and what would you hope a Power BI setup replaces?" Why it lands: it surfaces the tool gap honestly, in their terms.
4. "What would you need from the person in this role in the first ninety days?" Why it lands: it signals ownership, and the answer tells you the real scope.
5. "How are the twelve supervisors split across the four sites, and who has been in the role longest?" Why it lands: it shows you understand the span.
6. "What does success look like at the end of year one, in numbers?" Why it lands: it signals you expect to be measured.

## 6. Sources

Provided documents: the JD text and the background sentences in your message. No CV file, no interviewer information.

Search calls sent this engagement, refused ones included:

- "Atlas Freight regional logistics company": refused (the host declined search permission).
- "Atlas Freight operations manager interview process": refused (the host declined search permission).

Research tier: L1 — searches 2 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Atlas Freight values` | unavailable | Section 4 values cheat sheet, only if a values round were detected; none was. No call sent; the host declined search permission. |
| 2. `Atlas Freight interview process operations` | unavailable | Persona weights and loop structure. Query refused. |
| 3. `Atlas Freight strategy` / recent news | unavailable | Grounding brief and CO questions. No call sent; the host declined search permission. |
| 4. Interviewer name | n/a | No name given, so there was no query to form. |
| 5. Representative operations manager JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions. |
| Company identity check (un-numbered) | unavailable | Would have confirmed the company's scale and existence before the pack described it. Query refused. |

## 7. Upgrade menu

- Your interviewer's name, title and public background → persona weights from their footprint, and a reverse question tied to their career path.
- Your CV as text → quotes from it replace the background sentences you typed, and your leadership years get checked against it.
- Your Green Belt certificate → F7 confidence moves from medium to high.
- One Excel report you built (even a screenshot) → F4 moves from discovery to medium if it exists, and A4's Excel slot gets a concrete example.
- Web search permission → company values, interview process and recent news. Target rows 1–3 move from unavailable to yes, and the grounding brief can be built. A deep research pass (up to six more searches and two more fetches) also needs that permission.
- The recruiter's prep email → coverage of any deliverable or focus area they name.
- A `tuesday-dossier.md` from an earlier evaluation → verified evidence and a prohibited-claims list from that run.
