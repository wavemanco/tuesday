Your prep pack is saved as `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-alone-part-2-rooms-case-5-denied-89256c5c/a40d6c10-95d4-49f0-b48c-a7d0da1f8603/scratchpad/kelverton-rail_senior-partnerships-manager_interview_pack.md` and sent to you here. I built it on the assumption of a panel with a future manager (Deepa) and a commercial director (Ross), since the recruiter's email names both. The pack is built from your message and the recruiter's email only: I had no JD, CV file or market report text, and web search was refused, so it contains no company facts I couldn't source.

The three things I'd put the most time into:
- **B1 is the highest-ROI prep.** Ross will ask how the £4M of influenced revenue was counted. The pack gives you no counting method. It asks you to say how it was counted, what it's sensitive to, and which part was yours, in your own words.
- **The POV is a graded deliverable.** Three theses, each with a concession, and a close on one operator-visible outcome within six months. Every thesis is marked `[generic]` until you check it against the market report.
- **Hold the quota and rail gaps plainly.** You've said you've never carried a direct quota and never sold into rail. The pack rehearses saying so and then giving a plan, and it never lets the channel result stretch into a quota or rail claim.

Would you paste the JD text? It's the one input that would most change the pack. It turns the recruiter-sourced requirements into quoted JD lines, gives the commercial questions a raising source, and lets the POV close be checked against the role's own words.

Would you like me to play Ross on B1 as a drill? Or, if you want, I can save a `tuesday-dossier.md` recording the gaps this prep exposed, to carry into later sessions.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: kelverton-rail_senior-partnerships-manager_interview_pack.md -----
# Kelverton Rail, Senior Partnerships Manager: second-round panel prep pack

Built from your message and the recruiter's email as you quoted it. No JD, CV file or market report text was provided, and web search was refused, so company facts are absent rather than guessed. First version.

## 2. How to use, and the type key

Personas are how a question is asked. Types are what is being scored. Guidance is scaffolding, not a script. Rehearse the shape, then say it in your own words.

- **VAL**: values or behavioural fit. Not scored here: no published values were provided.
- **EXP**: your experience, tested for what was actually yours.
- **JD**: the role's stated requirements.
- **CO**: company and commercial knowledge.
- **CASE**: a live problem from the role, reasoned aloud.

Answer slots are instructions for the interview, not questions to me. Where a question asks about your past, the guidance says either what your quoted sentence carries, or what to say if the answer is no.

## 3. Prep triage (about four hours)

1. **75 min: the POV (section 5).** Pick one thesis, write its concession, and write the operator close in your own words. Say it aloud twice, under 15 minutes each.
2. **60 min: commercials (B1, B2, B3, B7, B8).** Write down what you know about how the £4M was counted, and what you do not know. Say the unknowns aloud, in full sentences.
3. **45 min: case drills (A1, A2, A7).** Use a timer. Clarify first, then structure.
4. **30 min: opener and your questions (C1, reverse questions).**
5. Everything else is insurance.

## 4. Fit snapshot

Requirements come from the recruiter's email, quoted. No JD was supplied, so no role requirement is quoted from a JD. Rows F4 and F6 come from your own stated gaps. No gate row can be named, because no JD or eligibility terms were provided.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "where you'd take our operator partnerships over the next 18 months" (recruiter's email) | "took it from 6 partners to 40, roughly £4M of influenced revenue" (your message), "running the ISV channel" (your message) | medium | [grounded] | transferability | Your material shows channel partnerships at a payments company, not operator partnerships. Say: "For four years I was running the ISV channel, and I took it from 6 partners to 40." The 18-month plan is a plan, said as one. |
| F2 | "what it means for the operators themselves" (recruiter's email) | "so I know the operator world from the other side" (your message) | medium | [grounded] | presentation | The quote already reaches the requirement in other terms. Say: "I know the operator world from the other side," and go on to what that means for an operator. Add no operator decision you made. |
| F3 | "Ross will push on commercials" (recruiter's email) | "roughly £4M of influenced revenue" (your message) | medium | [grounded] | transferability | The figure is influenced, not sourced. Say the figure as it is. Answer slot: if you can say how the £4M was counted, say how in your own words, including what it is sensitive to and which part was yours. If you cannot, say so, and say what you would want to see first. |
| F4 | direct sales quota ownership (role-family, [generic]) | "never carried a direct quota" (your message) | none | [grounded] | capability | A gap you stated, so it can be said plainly: "I've never carried a direct quota." Then how you would learn to be measured on one, said as a plan, never as a past. |
| F5 | rail and operator-side domain knowledge (role-family, [generic]) | "bus and light rail network planning" (your message), "so I know the operator world from the other side" (your message) | medium | [grounded] | transferability | Five years on bus and light rail network planning. Say that, and stop there. Your material does not show rail product or rail sales knowledge. |
| F6 | selling into rail (role-family, [generic]) | "Never sold into rail specifically" (your message) | none | [grounded] | capability | A gap you stated: "I've never sold into rail specifically." Then how you would close it, as a plan. |

Gap types follow the evidence cells. Confidence is set by what can be inspected, so a CV and any deal records would raise F1 and F3 (see the upgrade menu).

## 5. Graded deliverable: the 15-minute POV

Declared by the recruiter: "a short POV on where you'd take our operator partnerships over the next 18 months, no slides needed," landing on "what it means for the operators themselves."

Grounded facts to build on: F1, "took it from 6 partners to 40, roughly £4M of influenced revenue" (your message); F2, "so I know the operator world from the other side" (your message).

Every thesis below is `[generic]` until you check it against the market report, which the pack has not seen. Treat each as a hypothesis you test in the room.

- **T1: judge operator partnerships by operator outcomes, not partner count.** Concession: I don't yet know which operator outcomes they track, so I would test with three operators before committing. Differentiation: the consensus answer is more partners and more integrations. This thesis departs from breadth, and says why.
- **T2: anchor the 18 months to the operators' own change windows, not to a sales calendar.** Concession: this depends on which windows their operators can plan around, which I would confirm first. This is generic, not a claim about their timetable.
- **T3, the anti-pick: do not sell the partnership as a reseller channel.** The operator is the customer, and the outcome belongs to them. Concession: a reseller model may fit some segments, and I would test that rather than rule it out.
- **The close, required by the recruiter:** name one operator-visible outcome they would notice within six months, and what the operator would have to give up to get it.

## 8. Persona table

Weights are a shown judgement. Relationship priors come first, then the panel, then your stated focus areas. No interviewer profile was available, so there is no career-pattern read.

| Persona | Who | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|---|
| Case / Strategist | Deepa (future manager) | live problems on the 18-month plan; "what would you do first" | high: the hiring-manager prior, and the recruiter named her as your future manager | clarify, objective, segment, approach, metrics, risks; say the first two aloud |
| Skeptic | Deepa | "why would operators talk to you," the rail gap, the quota gap | medium: "what it means for the operators" invites a fit probe | hold the channel result, concede the rail and quota gaps plainly, bring a plan |
| Data-Driven Prober | Ross (Commercial Director) | the £4M figure, its counting, its assumptions | high: the recruiter wrote "Ross will push on commercials" | name the weakest assumption before he does; say which part was yours |
| Pressure / Stress | Ross | "you've never carried a quota"; time-boxed challenges | medium: a commercial director's usual register is executive, and the quota gap is visible | hold the channel result, concede the quota gap, do not fold on the partner growth |
| Conversational | either | "walk me through the journey"; a casual question on a JD topic | low weight, but scored | a 90-second arc, and treat casual questions as scored |

Depth: Deepa's Case and Skeptic banks carry the most questions. Ross's Prober bank is the highest-weight bank in the pack.

## 9. Question banks

### Deepa: Case / Strategist and Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Your 18-month plan: where would you start, and what would you need to know first?" | CASE | [generic] | Clarify the objective first (which operators, what outcome), then segment operators by what they buy, then approach, metrics and risks. Say the first two aloud before structuring. | A live problem from the role. [generic] because it is a pattern for the problem, not a claim about the candidate or the company. |
| A2 | "An operator's ops director says the change is too disruptive this year. What do you do?" | CASE | [generic] | Ask what "disruptive" costs them. Propose a smaller first step, with a measure they would accept. No past claim. | A live operator-side problem, and a test of whether you think from their side. |
| A3 | "You've run a channel. What changes when the partner is the operator?" | JD | [grounded] "running the ISV channel" (your message); [grounded] "took it from 6 partners to 40" (your message) | "For four years I was running the ISV channel, and I took it from 6 partners to 40." Then the difference, as your view: the operator's buying cycle, and the outcome it is measured on. Your view, not a past. | F1 is the evidence for the operator-partnership requirement. The question is a fair one, and the answer is a view. |
| A4 | "You haven't sold into rail. Why would operators talk to you?" | JD | [grounded] "Never sold into rail specifically" (your message); [grounded] "so I know the operator world from the other side" (your message) | Hold: "I've never sold into rail specifically." Then the operator side: "so I know the operator world from the other side." Hold through two follow-ups by returning to the planning work. Concede the rail gap plainly, and name how you would close it, as a plan. | F6 and F2 are the Skeptic's obvious probe. Hold-then-concede: the hold is only what your sentences carry. |
| A5 | "Why leave a payments company for rail?" | EXP | [generic] | Open prompt. Say the thing you want from this job, in your own words. If the true answer is not yet clear to you, say what you are testing. | Motivation consistency. [generic] because it asks for a view, not a fact about the company. |
| A6 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "never carried a direct quota" (your message); [grounded] "Never sold into rail specifically" (your message) | Name the quota and the rail gap in one breath, in those words. Then a 90-day plan for each. Do not name a third gap. | F4 and F6 together. The honest answer is the one the Skeptic is looking for. |
| A7 | "Why would an operator choose a partnership over doing this in-house?" | CASE | [generic] | Structure: what in-house costs them, what the partner adds, what they would measure after six months. Make no claim about how operators buy. | A case on the operator's side. |

### Ross: Prober and Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Your £4M of influenced revenue: how was it counted?" | EXP | [grounded] "roughly £4M of influenced revenue" (your message) | Answer slot: say how it was counted, in your own words. Say what it is sensitive to, and the assumption you would defend least, before he asks. Say which part was yours. If you do not know how it was counted, say so plainly. | The highest-ROI prep in this pack. F3 is the commercials push, and the figure is the one number you have. The slot names no counting method. |
| B2 | "You've never carried a quota. Why should I trust a channel number?" | EXP | [grounded] "never carried a direct quota" (your message); [grounded] "took it from 6 partners to 40" (your message) | Hold the channel result at its own scope: "I took it from 6 partners to 40." Concede the quota gap plainly. Hold through two follow-ups. Do not fold on the partner growth. | F4 and F1. Hold-then-concede. The hold is only the sentence you wrote. |
| B3 | "Of that £4M, what would have happened without your partners?" | EXP | [grounded] "roughly £4M of influenced revenue" (your message) | Answer slot: say how you would separate what the partners did from what would have happened anyway. If you did not separate it, say so, and say what you would use to separate it. Keep "influenced" as the word. | F3. Attribution probe on the figure. |
| B4 | "How would you price a partnership for an operator, and what margin would you protect?" | CO | [generic] | Structure: who pays, what they pay for (the operator outcome), price against value, the margin floor, and what you would need to see of their current pricing before proposing. No figures. | A commercial question with no past claim. |
| B5 | "Walk me through how you'd forecast partner-sourced revenue in your first year." | CASE | [generic] | Structure: what has to be true (partners signed, partners active, deals per active partner), which of these you would know after 90 days, and what you would call a miss. | Forecasting is a stated commercial probe. [generic] because it is a method, not a fact about you. |
| B6 | "Operators run tight budgets. Why would a train operator fund this in the next 18 months?" | CO | [generic] | Answer from one point in the market report you have read, in your own words. Name the operator pressure you would lead with and what you would check against the report first. | The report is not in the pack, so this stays `[generic]` until you check it. |
| B7 | "If we paid you only on sourced revenue, what would you do differently?" | CASE | [grounded] "roughly £4M of influenced revenue" (your message) | Answer slot: say what you would change in how you track a partner deal to sourced. Do not say you ever did it. Keep the current measure at its scope: influenced. | F3 and F4. Tests whether you can think at the commercial altitude without claiming it. |
| B8 | "Which assumption behind 'from 6 partners to 40' would you defend least?" | EXP | [grounded] "took it from 6 partners to 40" (your message) | Answer slot: name the assumption you would defend least, in your own words. If you do not know which assumption, say so plainly. | F1 and F3. Defend-the-number, applied to the partner count. |

### Conversational opener

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, walk me through the journey." | CO | [grounded] "9 years in partnerships" (your message); [grounded] "so I know the operator world from the other side" (your message) | A 90-second arc: nine years in partnerships, four of them running the ISV channel, five before that on the operator side of network planning, then why this. Say it in your own words. | Casual, and scored. Opening arcs set the panel's first impression. |
| C2 | "What have you been reading about rail lately?" | CO | [generic] | Name one point from the report you have read, in your own words. If you would rather not, name a source you actually read. | Light, but it tests whether you read the material you were sent. |
| C3 | "Who would you go to first in your first month here?" | CO | [generic] | Name the roles, not the people. Say what you would want from each. | A reciprocity-style probe. No claim about the company's people. |

### Reverse questions

Each of these has a reason it lands. No interviewer profile was available, so none is tied to Deepa's or Ross's career path yet.

1. "Which operator relationship today is the one this role would most want to change, and why?" Lands because it shows you have looked at the existing book.
2. "How is partner-sourced revenue measured here, compared with influenced revenue?" Lands on Ross's commercial test, and lets you ask it as a real question.
3. "What did the last person to hold the operator partnership remit get right, and what did they miss?" Lands because it asks for an honest peer-level answer.
4. "What would make you say the first year was a success, and what would make you say it failed?" Lands because it asks for criteria, and criteria are what a manager is hiring against.
5. "Ross, what does a commercial conversation with an operator look like when it goes well?" Lands because it speaks to the commercial interest the recruiter flagged.

## 13. Prohibited claims

Built locally from the fit snapshot. Each entry names its basis, and the honest form is what you can say.

| Not coached | Basis | Honest form |
|---|---|---|
| "I sold into rail," "rail sales experience" | Inflated form of F5, and the stated negative in F6 | "I've never sold into rail specifically." The plain acknowledgment. Then "bus and light rail network planning," at its own scope. |
| "I carried a quota," "I hit target" | Stated negative in F4 | "I've never carried a direct quota." The plain acknowledgment. No slot. |
| "£4M sourced," "I drove £4M of revenue" | Inflated form of F3 | "roughly £4M of influenced revenue," at its own scope. The limit is this pack's observation: your material says influenced, not sourced. |
| "I built the ISV channel," "I designed the partner programme" | Inflated form of F1 | "took it from 6 partners to 40," at its own scope. Your material does not say who set the programme. |
| "I know how operators make buying decisions," "I was on the operator side of a purchase" | Inflated form of F2 | "so I know the operator world from the other side," at its own scope. Your material shows network planning work, not operator buying. |

## 14. Sources

Provided: the recruiter's email, as you quoted it in your message; your background, as you described it in your message. No CV file, JD text or market report text was provided.

Searches sent: "Kelverton Rail scheduling software train operating companies" (refused, search permission not granted); "Kelverton Rail company leadership partnerships" (refused, search permission not granted). Nothing was fetched.

Research tier: L0, searches 0 of 6, fetches 0 of 2.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Kelverton values | unavailable | No values section in the pack. Would have added a values cheat sheet. No call was sent: search was refused. |
| 2. Interview process, role family | unavailable | Loop structure is inferred from your message only. Would have confirmed the panel format. No call was sent: search was refused. |
| 3. Strategy and recent news | unavailable | The market report was not pasted. It would move B6 and T1 to T3, and the grounding brief. Query refused. |
| 4. Interviewer footprint (Deepa, Ross) | unavailable | No interviewer read, and no tailored reverse question. Query not sent: search was refused. |
| 5. Representative JD | unavailable | No JD supplied, so no requirement could be quoted. Would have turned the `[generic]` requirements into `[inferred]` ones. |

## 15. Upgrade menu

- JD text → F1 to F3 get a quoted requirement from the JD, rather than the recruiter's email, and the commercial and operator banks gain a raising source.
- The market report's three to five main claims, pasted → B6, the T1 to T3 theses and the grounding brief can be checked against it, and their `[generic]` labels can become `[grounded]`.
- Your CV as a file → F1, F3 and F5 get the CV's own sentences, and the EXP questions (A3, A5, B1 to B3, B8) can cite them.
- Web search permission → research at L1: the company, the panel names, and the representative JD. Names are common, so any search would need the company name with them.
- The recruiter's note on what the POV must close on → confirms or changes the section 5 close.
- The interviewer names' public profiles → persona weights per panel member, and a reverse question tied to their own path.

Every upgrade adds evidence. None of them changes what is already in the pack.
