Your prep pack is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-alone-part-2-rooms-case-5-denied-aad581d7/303496d6-7322-4df7-b26d-f7fc97f58972/scratchpad/kelverton-rail_senior-partnerships-manager_interview_pack.md`.

Three things you should know first:

- **Web search was refused in this session**, so the pack has no company research: no values, no interview process, nothing on Deepa or Ross. Its company content is limited to the recruiter's email and your message.
- **I didn't have the market report's text.** You said you'd read it, but it wasn't in what I could open, so the POV isn't yet differentiated from the consensus answer. Pasting its section headings or its operator-priority shortlist would fix that.
- **I built it for a panel round with Deepa as your future manager.** The personas are weighted by role, not by anything I found about them.

The biggest findings for your prep:

- **Highest-ROI prep is B2**, "Which part of this role would you be weakest at on day one?" Name the rail and direct-quota gaps plainly, then give a ramp plan. Rehearse three follow-ups.
- **Ross's commercial bank is the main risk.** The £4M of influenced revenue needs a ready answer on how it was counted, which assumption you'd defend least, and which part was yours. Only say what you can actually back up.
- **The POV's anti-pick:** don't pitch scaling partner count as the operator answer. Lead with operator outcomes, and concede that you haven't sold into rail.

Two questions that would change the pack:

1. Can you paste the job description? Right now the requirement rows come from the recruiter's email only.
2. Is there a location, office-day or right-to-work condition for this role that you need checked? If so, I'll add it as a gate row.

If you'd like, I can play Deepa on B2 as a live drill. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions. And I can convert the pack to Word if you want it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: kelverton-rail_senior-partnerships-manager_interview_pack.md -----
# Interview prep pack: Senior Partnerships Manager, Kelverton Rail

Second round, panel, 60 minutes. Deepa (VP Partnerships, your future manager) and Ross (Commercial Director). Built from the recruiter's email, your background message and the skill's own role-family knowledge. The internal market report was not in the material I could read, and web search was refused in this session, so there is no company research in this pack.

## How to use this pack

Personas describe how a question arrives. Types describe what is being scored: **JD** (role requirement), **EXP** (your own record), **CASE** (live problem), **CO** (company knowledge), **VAL** (values; not used here). Guidance is scaffolding, not a script. Rehearse in your own words, and say the honest branch out loud when the material does not carry the answer.

## Prep triage (about 4 hours)

1. **Build and time the 15-minute POV (section 5), about 90 minutes.** Say it aloud twice, timed. Aim for 10 to 12 minutes so the 15 has room for questions.
2. **Rehearse B2 with its follow-ups, about 45 minutes.** This is the highest-ROI prep in the pack: a skeptical manager asking where you would be weakest on day one.
3. **Drill the commercial bank A1 to A4, about 60 minutes.** Know how the £4M was counted, which assumption you would defend least, and what was yours. If you do not know, say so.
4. **Read the reverse questions and pick three, about 15 minutes.**

Everything else is insurance.

## 1. Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "where you'd take our operator partnerships over the next 18 months" (recruiter email) | "took it from 6 partners to 40, roughly £4M of influenced revenue" (your message) | medium | [grounded] | transferability | Your material says partners in a payments ISV channel, not operator partnerships. Words: "I took it from six partners to forty." Answer slot: if any step with an operator was yours, say which and how; if none was, say so and stay with the partner-management method you ran. |
| F2 | "what it means for the operators themselves" (recruiter email) | "bus and light rail network planning, so I know the operator world from the other side" (your message) | medium | [grounded] | presentation | Words: "I know the operator world from the other side, through network planning work." Adds no practice. Limit: this is planning work at consulting scope, not operator sales. |
| F3 | "what it means for the operators themselves" (recruiter email) | none given | low | [inferred] | discovery | Your material does not show an operator outcome you measured. Answer slot: if you have seen an operator's planning or disruption outcome change because of your work, say what and how you know; if not, say how you would test the operator benefit in the first three operators. |
| F4 | "Ross will push on commercials" (recruiter email) | "roughly £4M of influenced revenue" (your message) | medium | [grounded] | transferability | Your material says influenced revenue, not a direct number. Words: "I was accountable for influenced revenue of roughly £4M." Answer slot: how that figure was counted, and which part was yours. |
| F5 | "commercials" (recruiter email) | "never carried a direct quota, only influenced revenue" (your message) | none | [grounded] | capability | A negative you stated. Words: "I haven't carried a direct quota." Then how you would learn quota ownership, said as a plan and never as a past. |
| F6 | "Ross will push on commercials" (recruiter email) | "Never sold into rail specifically" (your message) | none | [grounded] | capability | A negative you stated. Words: "I haven't sold into rail specifically." Then how you would learn the rail buying path, said as a plan. |

Gap types follow the routing rule in the skill's output template: a stated absence is `capability`, a quote that reaches the requirement in other terms is `presentation`, a quote that reaches the requirement only in adjacent work is `transferability`, and silence is `discovery`.

## 2. Prohibited claims

Built locally from the fit snapshot. These are the claims a candidate reaches for under pressure in this loop, and the pack does not coach them.

| Not coached | Basis | Honest form |
|---|---|---|
| Built or owned the partner channel | Inflated form of F1: "running the ISV channel" | The quote at its own scope. Your material says running the channel, not setting its strategy. |
| Owned a revenue number or quota | Inflated form of F4 and F5 | "Influenced revenue" at its own scope. No direct number, no quota. |
| Operator-side sales or operator customer relationships | Inflated form of F2: "know the operator world from the other side" | Network planning work at consulting scope. |
| A rail sales track record | Negative you stated, F6 | The plain acknowledgment: "I haven't sold into rail specifically." No slot. |

## 3. Persona weights

| Panelist | Relationship prior | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|---|
| Ross (Commercial Director) | Skip-level or executive: Pressure, with Data-Driven Prober | Interrupts on the influenced-revenue line; asks how the £4M was counted; time-boxes answers | High. The recruiter said Ross will push on commercials, and F4 and F5 are the commercial gaps. | Name the weakest assumption before he does; hold the influenced-revenue line through two follow-ups, then concede specifically. |
| Deepa (VP Partnerships, future manager) | Hiring manager: Case/Strategist with Skeptic | Live problem on finding the first operator partnerships; a direct "where are you weakest" | High for the Skeptic line, because a hiring manager is buying derisked capability. Lower for pure case. | Clarify before structuring; name the rail and quota gaps plainly, then a ramp plan. |

No interviewer read is included: no public footprint for either panelist was retrieved, so the personas above use role priors only.

## 4. Question banks

### Ross: commercial pressure (weight 4 to 5, five questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Your £4M of influenced revenue: how was that counted?" | EXP | [grounded] "roughly £4M of influenced revenue" (your message) | Name the weakest assumption you would defend least, in your own words. Answer slot: how the figure was counted, what it is sensitive to, and which part was yours. If you did this, say how; if no attribution method was yours, say so plainly and say what you can show. Keep to 90 to 120 seconds. | F4 is the evidence. A figure raises the defend-the-number slot, and Ross's commercial lens will probe the influenced-versus-direct line first. |
| A2 | "You've never carried a direct quota. Why should we expect you to own a revenue number here?" | JD | [grounded] "never carried a direct quota, only influenced revenue" (your message) | Plain acknowledgment: "I haven't carried a direct quota." Hold through two follow-ups by returning to the influenced-revenue line you did carry. Then concede specifically: name one operator-level metric you would agree with Ross in the first 90 days, as a plan. Do not describe a quota you did not hold. | F5 is the highest-stakes commercial question for this panelist. Hold-then-concede is the structure. |
| A3 | "Your channel grew from six partners to forty. What is different about selling through operators?" | JD | [grounded] "took it from 6 partners to 40" (your message) | Hold: the part that transfers is the partner-management method you ran. Concede: the buyer count and the buying cycle differ, and you would check them first. Do not claim operator experience you do not have. | F1 is the bridge. The question is premised on your quote alone; the contrast it asks for is one you must give from your own judgment. |
| A4 | "You've never sold into rail. What's the first deal you would lose?" | JD | [grounded] "Never sold into rail specifically" (your message) | Plain acknowledgment: "I haven't sold into rail specifically." Then the uncertainty, concretely: say which operator objection you expect first and how you would find out. Do not guess at a rail deal you never ran. | F6 is a stated negative, so the acknowledgment is yours to give. The question asks for the honest version of the gap. |
| A5 | "An operator says a partnership pilot should be free for a year. Respond." | CASE | [generic] | Structure it: what the operator gets in the year, what you learn, what it costs, and what would make you stop. Clarify what success means to the operator before pricing it. | A live commercial problem in the role's shape. It makes no claim about your past, so the guidance makes none. |

### Deepa: manager, Case and Skeptic (weight 3 to 4, five questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Sketch how you'd find our first three operator partnerships. What do you need to know first?" | CASE | [generic] | Clarify, then objective, segmentation, approach, metrics, risks. Speak it in 90 to 120 seconds. Ask one question about the operators before you name any. | The Case/Strategist prior. The POV is the same question at 15-minute scale, so the two should agree. |
| B2 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never sold into rail specifically" (your message); [grounded] "never carried a direct quota, only influenced revenue" (your message); [grounded] "took it from 6 partners to 40" (your message) | **Highest-ROI prep.** Name both negatives plainly: "I haven't sold into rail specifically, and I haven't carried a direct quota." Then the ramp plan, as a plan. Follow-up one, "which part of your method carries?": "The partner onboarding and management I ran, which is what the six-to-forty record shows." Follow-up two, "why would that work with operators?": concede specifically that operators buy differently, and name what you would check first. Do not hold a claim the quotes do not carry. | This question will come in some form. Three follow-ups are the depth it needs, and the concession wording must be exact. |
| B3 | "How do operators' planning decisions differ from what a software vendor sees?" | JD | [grounded] "bus and light rail network planning, so I know the operator world from the other side" (your message) | Story-map from the quote: describe what network planning decisions looked like from the consulting side, at the scope the quote gives. Answer slot: if you saw one operator decision up close, say what it was and what your part was; if you did not, say what you learned from planning work and what you would test. | F2 is the bridge. It is the one question where your real operator-side experience is the answer. |
| B4 | "Why leave a payments company for a rail-tech supplier?" | JD | [grounded] "bus and light rail network planning, so I know the operator world from the other side" (your message) | Say what drew you, in your own words. If the operator side is it, say so and use the planning years as the reason. Do not claim rail sales. Keep the answer to one minute. | Skeptic motivation probe. The motivation is yours to give; the guidance supplies no motive. |
| B5 | "What do you know about our operator customers?" | CO | [generic] | Name two things you know from public material and say what you would want to confirm. Do not guess at a customer list. | Company knowledge is thin here because research did not run. The honest answer is the one to rehearse. |

## 5. Graded deliverable: the 15-minute spoken POV (no slides)

The recruiter asked for it in these words: "a short POV on where you'd take our operator partnerships over the next 18 months — no slides needed." She also asked you to "land on what it means for the operators themselves." Grounded facts to build on: F1, F2 and F3, from section 1.

**Structure (about 10 to 12 minutes):** context and hypothesis (2 minutes); three theses with concessions (4 minutes); what it means for operators (3 minutes); what you would test first (2 minutes).

**Theses, each with its concession:**

- **T1, operator-first.** Plan partnerships around the operator's timetable-change and disruption cycle, not the partner's sales cycle. Basis: [generic] pattern for B2B buyers with long planning cycles; not a claim about Kelverton's market. Concession: you have not sold into rail, so you would test this with operators rather than assume it.
- **T2, outcomes over partner count.** Measure partner value in operator outcomes, such as planning time or disruption recovery, rather than in partner numbers. Concession: your record is partner count and influenced revenue (F1, F4); outcome measurement is not something your material shows you have done.
- **T3, planners first.** Start the partner channel with network-planning consultancies and operator planners, because that is where the operator side is credible. Concession: the operator-side credibility comes from network planning work (F2), and you do not know the procurement path.

**Differentiation against the consensus answer:** not yet built. The market report's shortlist is the consensus the panel will expect, and I did not have it. Until it is pasted (see the upgrade menu), differentiate on T2.

**Anti-pick:** do not pitch scaling partner count, your 6-to-40 story, as the operator answer. With a limited number of operator buyers [generic], that is the wrong altitude.

**Close, operator benefit:** what the first three operators would experience in six months, as hypotheses to test, not results you have achieved.

## 6. Reverse questions

1. "What would a strong first 90 days look like for this role?" Why it lands: it turns the Skeptic's question into a plan conversation and shows you are already thinking about the ramp.
2. "Which operator partnerships are furthest along today, and what did those operators need to see before committing?" Why it lands: it asks for the buying path you have not sold into, in the panel's own words.
3. "Where does the pricing decision sit between this role and Ross?" Why it lands: it shows you know commercial ownership is the first thing to settle.
4. "What have you tried with operator partnerships that did not work?" Why it lands: a candid answer shows how the team learns, and it tells you what they will test you on.
5. "How do you measure an operator partnership working, and does that show up in the revenue number?" Why it lands: it is the influenced-versus-direct question, asked from their side.

## 7. Requirement coverage

| Requirement | Covered by |
|---|---|
| Operator partnerships over 18 months | Section 5 (POV); B1, B3 |
| What it means for the operators themselves | Section 5 (POV); B3 |
| Commercial pushback | A1, A2, A5 |
| Influenced versus direct revenue | A1, A2; F4 |
| Quota | A2, B2; F5 |
| Rail experience gap | A4, B2; F6 |
| Motivation | B4 |
| Company knowledge | B5, thin: research did not run |

## 8. Sources

- Provided: the recruiter's email, as quoted in your message; your background message.
- Not in hand: the internal market report. You said you read it, but its text was not in the material I could read, so nothing in this pack draws on it.
- Research tier: L1, with every search refused.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Kelverton Rail values | unavailable | Values cheat sheet, section 10; dropped because values were not detected and no values page was retrieved |
| 2. Kelverton Rail interview process, role family | unavailable | Loop structure and persona weights; the panel format above comes from the recruiter's email |
| 3. Kelverton Rail strategy and recent news | unavailable | Grounding brief; the POV's current framing, and B5 |
| 4. Deepa or Ross, public footprint | unavailable | Interviewer read and tailored reverse questions; the persona weights above use role priors |
| 5. Representative JD for the role title | unavailable | Requirement rows from a fetched JD; requirements here come from the recruiter's email |

Refused calls, each listed as refused: "Kelverton Rail scheduling software train operating companies"; "Kelverton Rail values careers"; "Kelverton Rail Deepa VP Partnerships"; "Great British Railways train operators digital scheduling technology suppliers 2026".

Because nothing was retrieved, the company-specific content here is limited to the recruiter's own words. The POV's operator claims and the market framing are [generic].

## Upgrade menu

- A pasted job description → requirement rows become [grounded] from the JD's own words, and the JD-tagged questions get stronger.
- The market report's section headings or shortlist of operator priorities → the POV can differentiate from the consensus answer, which is the open item in section 5.
- Approval for web search → the L1 research runs: company values, the interview process, and the public footprint of Deepa and Ross, after which I rerun the pack.
- Surnames for Deepa and Ross → an interviewer read and a tailored reverse question, and the persona weights come from public footprint.
- The gate question below, answered → a gate row in the fit snapshot.
