Your prep pack is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-alone-part-2-rooms-case-3-denied-52d75ef3/9ff9d9fb-d8b6-45fc-aa6e-4756477a0081/scratchpad/stripe_product-operations-manager_interview_pack.md`.

I could not research Stripe. Web search permission was not granted, so the company's values, interview process and strategy are not in the pack, and I did not fill them in from memory. The pack has no CV, JD or interviewer name, so the requirements are generic and the question banks use role-family questions with answer scaffolds you fill from your own history. Persona weights are flat because I don't know who you're meeting.

Say the word and I'll play the Skeptic on B1, "Why this role, and why now?" That's the question the pack flags as highest-value prep, since nothing in the material answers it yet.

I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

Who are you meeting in the final, and what's their relationship to the role? Is it one session or several? Did the recruiter mention focus areas or a take-home?

Could you paste the JD and your CV, or their key lines? With those, the generic rows become quoted evidence and the scaffolds become mapped answers.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: stripe_product-operations-manager_interview_pack.md -----
# Interview prep pack: Product Operations Manager, Stripe, final round

Built 2026-11-11. Session mode. Research tier L0 (no web research ran; see Sources). Persona weights are flat because the relationship to your interviewer is unknown. No CV, JD or interviewer name was provided, so every requirement below is role-family prose labeled `[generic]`, and no answer describes your own experience.

## How to use this pack

- **Personas** = how a question is asked. **Types** = what is being scored.
- Type key: **EXP** work-experience deep-dive · **JD** role/requirement · **CO** company and strategy knowledge · **VAL** behavioral/values · **CASE** live problem.
- Guidance is scaffolding, not a script. Say answers in your own words.

## Fit snapshot (worksheet variant)

No CV or JD yet, so the evidence column is empty. Every row is a worksheet entry.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| R1 | Owning cross-functional programs end to end: role-family prose | none given | none | [generic] | discovery | Strong evidence looks like one program you drove from start to finish across teams, with its milestones and who signed off. Selection scaffold: pick a program where you coordinated several teams to one date; if none fits, say so plainly and describe the nearest one you did run |
| R2 | Operating rhythm: planning, cadence, reporting: role-family prose | none given | none | [generic] | discovery | Strong evidence looks like a recurring review you ran and what it changed. Selection scaffold: name a recurring review or planning cycle you took part in and what you did in it; if none, say so and say how you would set one up |
| R3 | Stakeholder management across product, engineering, finance and go-to-market: role-family prose | none given | none | [generic] | discovery | Strong evidence looks like a disagreement between two of those functions and how it resolved. Selection scaffold: pick one such disagreement; if none, say so and describe how you would open it |
| R4 | Process design and change adoption: role-family prose | none given | none | [generic] | discovery | Strong evidence looks like a process you changed and whether people used it. Selection scaffold: name a process change, who had to adopt it, and how you knew it stuck; if none, say so |
| R5 | Metrics and analysis for decisions: role-family prose | none given | none | [generic] | discovery | Strong evidence looks like a number that changed a decision, with its definition. Selection scaffold: name one metric you used to decide something and how it was defined; if you did not use one, say so |
| R6 | Communicating with executives: role-family prose | none given | none | [generic] | discovery | Strong evidence looks like a short written or spoken update that led to a decision. Selection scaffold: pick one update you gave to senior leaders and what they did with it; if none, describe how you would structure one |

Your material does not establish any of these rows yet. That is the pack's observation, not a claim about you.

## Prohibited claims

Nothing is listed. Inflated-form entries are built from sentences you have said, and you have not given me any yet. Once you paste your CV or the JD, this section fills in. Until then the rule holds: no answer in this pack describes your past.

## Persona table

Weights are flat (relationship unknown). A final round can be any of these, so each persona gets three questions.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | A live problem on the team's actual work | High. Product ops roles are scored on how you structure a messy cross-team problem | Clarify, then structure, then state the risk you would watch |
| Skeptic | "Why this role, why now, what's the case against you" | High. Final rounds test whether the story holds up | Name the strongest objection before they do; state what is untested and how you would test it |
| Pressure / Stress | Time-boxed challenge; "give me one specific decision" | Medium. Common in final rounds with senior leaders | Pause, restate, hold a position through two follow-ups, concede only the specific uncertainty |
| Data-Driven Prober | "How was that counted?" | Medium. Ops roles lean on metrics | Name the weakest assumption before they do; say plainly when you do not know |
| Conversational | Friendly opener: "walk me through the journey" | Medium. Casual questions are still scored | A 90-second arc in your own words; treat casual questions about the role as scored |
| Peer Evaluator | "Where's the seam, and what happens when we disagree?" | Medium. Final rounds often include a partner from an adjacent team | Propose seam principles rather than claiming to know the seam; name one real disagreement and how it resolved |

## Question banks

Every provenance cell is `[generic]`. No guidance claims anything about your past. Answers that need your experience are selection scaffolds, and you fill them with your own history.

### A. Case / Strategist (weight: 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A launch you own is three weeks out, and a dependent team says it cannot deliver its part on time. What do you do?" | CASE | [generic] | Clarify what is fixed (date, scope, who decides). Separate the decision from the relationship. Give two or three options with their tradeoffs, then your recommendation. State what you would tell whom, and when. Name one risk you would watch | Live cross-team problem for R1 and R3. Presupposes nothing about your past |
| A2 | "Weekly reporting from the revenue system disagrees with the finance close by a few percent. How would you find out why?" | CASE | [generic] | Define the source and timing of both numbers. Reconcile stage by stage. Check definitions before data. Name who owns the fix | Tests R5 with a structured diagnosis |
| A3 | "What would you want to learn about this team in your first 30 days?" | JD | [generic] | A sequenced plan: three questions, what you would do with each answer, and what would change your approach | Tests R2 and R6 through ordering, not biography |

### B. Skeptic (weight: 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Why this role, and why now?" | EXP | [generic] | Give one reason about the work and one about the role. Keep both specific and free of criticism of your current employer. Follow-up: "what would make you leave this role in a year?" Answer it plainly | Highest-ROI prep in this pack. Motivation is the question every final round tests, and nothing in the material yet answers it |
| B2 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | Name one area where your experience is thinnest, in your own words. Then describe a concrete first-month ramp. Do not bluff a competency | Persona stem; scores calibrated candor |
| B3 | "What is the strongest case against hiring you for this?" | JD | [generic] | State the objection in its strongest form. Say what you have that bears on it. Say what is untested and how you would test it. Do not argue it away | Tests composure under a direct objection |

### C. Pressure / Stress (weight: 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Sixty seconds: why you over an internal candidate?" | EXP | [generic] | One concrete reason tied to the role. If pushed, hold it through two follow-ups. Concede only a specific uncertainty, never the core reason | Time-boxed hold-then-concede; a persona stem |
| C2 | "That answer is generic. Give me one specific decision you made, and what you would change about it." | EXP | [generic] | Pick a real decision. Name the stake, what you chose, and what you would change. If no decision comes to mind, say so plainly and give the nearest one you did make | Open prompt. Asks you to choose an instance; the pack supplies none |
| C3 | "Where would you push back on your manager's priorities?" | EXP | [generic] | Name one real type of disagreement, how you raised it, and how it resolved. Do not invent a conflict | Tests spine with tact, for R6 |

### D. Data-Driven Prober (weight: 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how you would measure whether a process change worked." | JD | [generic] | Baseline first. Then the metric, what would count as noise, and the assumption you would defend least | Tests R4 and R5 in a method, not a story |
| D2 | "Tell me about a metric you have owned. How was it counted?" | EXP | [generic] | Pick a real metric. Say how it was counted, what it is sensitive to, and the weakest assumption behind it. Say which part was yours. If none comes to mind, say so | Open prompt. Probers test whether the number survives scrutiny |
| D3 | "What would a successful process change look like in numbers after 60 days?" | CASE | [generic] | One leading and one lagging indicator, what you would not measure, and what result would make you stop | Tests R5 with a forward-looking answer |

### E. Conversational / Rapport (weight: 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [generic] | A 90-second arc: one sentence per role, then the thread that connects them. Fill it with your own history; do not borrow anyone else's | Casual opener that is still scored for economy |
| E2 | "What have you been reading or thinking about in product operations lately?" | CO | [generic] | Name one thing you read, your view of it, and why it matters for this role. Name nothing you have not read | Tests current interest without invented depth |
| E3 | "What kind of team do you do your best work on?" | VAL | [generic] | Describe one working condition and one example. Keep it to what you have seen. This is not a values round and no company values are assumed | Values-adjacent, not a detected values round |

### F. Peer Evaluator (weight: 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Our teams sit side by side. Where's the seam, and what happens when we disagree?" | JD | [generic] | Propose seam principles, not a claim to know the seam. Name one real disagreement with an equal and how it resolved | Tests R3 in collegial form |
| F2 | "How do you handle credit when work spans teams?" | VAL | [generic] | One principle, then one example. If you have no example, say so and describe the principle you would apply | Partnership fit |
| F3 | "What would you need from my team to be effective in the first month?" | JD | [generic] | Concrete asks, named by function and by the decision they unlock. Do not guess at their internal structure | Reciprocity; tests whether you think about their load |

## Requirement coverage

| Requirement | Covered by |
|---|---|
| R1 cross-functional programs | A1, F1 |
| R2 operating rhythm | A3, D3 |
| R3 stakeholder management | A1, F1, F2 |
| R4 process design and change | D1, C3 |
| R5 metrics and analysis | A2, D1, D2, D3 |
| R6 executive communication | C1, C2, A3 |

Motivation (not a JD requirement) is covered by B1.

## Reverse questions

Each one lands for a reason. No interviewer profile exists, so these are role-generic.

1. "What does a strong first 90 days look like for whoever fills this role?" Why it lands: it sets the bar before you commit to a plan.
2. "Which problem would this role be expected to solve first?" Why it lands: it shows you want to work on the real thing, not an abstract scope.
3. "Where do process decisions get made here, and who has the final say?" Why it lands: it reveals how much authority the role carries.
4. "How does this team judge whether its process work is succeeding?" Why it lands: it tests whether they have a measure, and sets up your metrics answer.
5. "What has separated people who succeeded in this role from those who struggled?" Why it lands: it invites them to describe the job honestly.
6. "What is the biggest tradeoff this team is navigating right now?" Why it lands: it shows you think in tradeoffs and asks for current context.

## Sources

- Provided documents: your message only. No CV, JD, interviewer name or strategy brief.
- Research tier: L0. Web search permission was not granted in this session, so no research call returned a result.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Stripe values` | unavailable | Values cheat sheet (section 10) is absent. The search was refused. No values were taken from memory |
| 2. `Stripe interview process product operations` | unavailable | Loop structure and persona weights are flat. Search was refused |
| 3. `Stripe strategy` / recent news | unavailable | Grounding brief and CO questions are generic. Search was refused |
| 4. interviewer name + Stripe | n/a | No name given, so no query could be formed |
| 5. representative JD for this title | unavailable | Fit snapshot rows would become `[inferred]` if a representative JD were found. No search was sent |

Queries sent: `Stripe values operating principles`, `Stripe interview process Product Operations Manager final round`, `Stripe strategy news 2026`. Each was refused.

## Upgrade menu

- Your CV or its key lines → rows R1 to R6 get quoted evidence, and the story-selection scaffolds become mapped answers
- The JD text → the six `[generic]` rows become `[grounded]`, and the coverage table becomes real
- Who you are meeting and their relationship to the role → persona weights and reverse questions are reweighted
- The interviewer's name → an interviewer read and a tailored reverse question
- The recruiter's note on focus areas or any take-home → a graded deliverable section
- Allowing web search → company values, interview process and strategy at L1, with the `[generic]` labels replaced by sourced ones
- A deeper research pass (L2): up to 6 more searches and 2 more fetches, several more minutes → strategy brief and role-family loop reports
