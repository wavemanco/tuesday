Your prep pack is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-alone-part-2-rooms-case-7-denied-509a14d2/c96b7f2b-131c-4758-b7f6-05b489a451ba/scratchpad/saltmarsh_live_ops_producer_interview_pack.md`. I built it for a hiring-manager round, since your note didn't say who Tobias is to you. Search was refused, so nothing about Saltmarsh's values, strategy or Tobias's background is in it.

# Interview prep pack: Live Operations Producer, Saltmarsh Games

Interviewer: Tobias Wrenfield, Head of Live Operations. Relationship assumed: hiring manager. Format: 60 minutes, Friday.

## How to use this pack

- **Personas** describe how a question is asked. **Types** describe what it scores: **VAL** (values behavior), **EXP** (what you actually did), **JD** (the job's listed needs), **CO** (company knowledge), **CASE** (a live problem).
- Guidance is scaffolding, not a script. Rehearse out loud, in your own words.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | transferability | Your material shows one title's content-drop calendar, not two titles' live events. Bridge: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: the two-title scope makes a probe on running two calendars likely. If you have planned across more than one title or format, say so in your own words; if not, say so plainly and describe how you would split your planning across two titles. |
| F2 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | none | No gap. The quote reaches the requirement directly. Lead with the calendar in the quote's own terms. Expect a probe on it. |
| F3 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses" — your message | medium | [grounded] | presentation | Bridge, rewording only that quote: "I wrote the release checklist our QA team still uses." Add no practice or figure. |
| F4 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | transferability | Presenting retention numbers is adjacent to owning a post-event review, which your material does not show. Bridge: "I presented the monthly retention numbers to the studio head." Answer slot: if you ran a review after a live event and it set the KPIs, say how, in your own words; if not, say so plainly and say what you would build first. |
| F5 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | presentation | Bridge, rewording only that quote: "I presented the monthly retention numbers to the studio head." Add no figure or method. |
| F6 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio" — your message | low | [inferred] | hard_gate | Your material does not establish the live-service producing years: four years are shown, as an associate producer, at a puzzle-game studio. This row asks nothing; see the upgrade menu. |
| F7 | "coordinate design, art, engineering and community teams on each update" — JD | "Never led a team" — your message | none | [grounded] | capability | Words from your stated negative: "I've never led a team." Answer slot: if you coordinated work across teams without managing them, say how; if not, say so plainly and describe how you would run an update across four teams. |
| F8 | Monetized live-ops experience — [generic], not a JD line | "never worked on a game with in-app purchases" — your message | none | [grounded] | capability | Words from your stated negative: "I've never worked on a game with in-app purchases." The JD doesn't raise this, so no answer slot is written against it. Expect it anyway; see B5. |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Ran live events across two titles | Inflated form of F1 | F1's quote at its own scope. Your material says one title's calendar. |
| Owned post-event reviews | Inflated form of F4 | F4's quote. Your material says presenting retention numbers. |
| Produced live-service games | Inflated form of F6 | "4 years as an associate producer at a puzzle-game studio." |
| Built the retention metrics | Inflated form of F5 | You presented the numbers; who defined them is not stated. |
| Led or managed a team | Negative you stated, F7 | "I've never led a team." |
| Worked on in-app purchase monetization | Negative you stated, F8 | "I've never worked on a game with in-app purchases." |

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Probes the gaps: people management, two titles, post-event reviews | High. A hiring manager's prior is Case plus Skeptic, and F4, F6, F7 are visible on the page. Weight: 5 questions. | Rehearse the leadership objection until it is plain. Hold the calendar you actually ran. |
| Case/Strategist | Live problems: plan, diagnose, coordinate | High. The JD's first line is planning. Weight: 4. | Clarify first, then structure: cadence, teams, release risk. |
| Data-Driven Prober | How was retention counted; which assumption would you defend least | Medium-high. Retention is a JD line and a CV line. Weight: 3. | Say what you know about the counting, and say plainly when you don't know. |
| Pressure | Time-boxed challenge on the puzzle-game background or your influence | Medium. A 60-minute format leaves room for it. Weight: 2. | Hold through two follow-ups; concede the specific gap, not the whole case. |
| Conversational | "Walk me through your journey" | Medium. Casual openers are scored. Weight: 2. | A 90-second arc from your own quotes. |
| Peer | Seam and credit questions | Low-medium. Weight: 2. | Name what you bring to their team. |

Interviewer read: none. No public profile for Tobias was searched, so no career pattern is assumed.

## Question banks

### A. Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "I don't see people management in your background. How would you run cross-team updates without it?" | JD | [grounded] "Never led a team" | Start with "I've never led a team." Then the F7 slot: if you coordinated across teams without managing them, say how; if not, say so and describe how you'd get four teams to agree on an update's scope and date. Hold through two follow-ups by returning to the plan. | F7 is the largest gap against the JD's coordination line. Deepest rehearsal. |
| A2 | "The role covers two titles. Your calendar covered one. How would you carry both?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Tell the calendar in your own words: weekly, one title, two years. F1 slot: if you have planned across more than one title or format, say so; if not, say so and describe how you'd split planning across two. | F1 is transferability; the scope is the probe. |
| A3 | "Walk me through your post-event reviews. What changed because of them?" | JD | [grounded] "Presented the monthly retention numbers to the studio head" | F4 slot: if you ran a review after a live event and it changed the KPIs, say what it measured and what changed; if not, say so and say how you'd structure the first one. | The JD's review line is the premise; your material shows presenting, not reviewing. |
| A4 | "Which of the KPIs you reported did you set yourself?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Say which numbers you presented and where they came from. If you chose the metric, say which; if it was set for you, say so plainly. | F5 is presentation, so ownership is the probe. |
| A5 | "You haven't worked on a game with in-app purchases. Where does that cost us most?" | JD | [grounded] "never worked on a game with in-app purchases" | Start with "I've never worked on a game with in-app purchases." Then say what you would learn first, and from whom. | F8. The JD doesn't raise monetization, so this is a probe to expect, not a requirement. |

### B. Case/Strategist (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Sketch the next quarter's live-events calendar for one of our titles. What do you need to know first?" | CASE | [grounded] JD line "Plan and run the live-events calendar for two of our mobile titles" | Clarify first: goals, release cadence, team capacity across design, art, engineering and community, any QA window. Then structure: objective, event types, sequencing, metrics, risks. | The JD's core job. No claim about your past. |
| B2 | "Retention dropped in the week after a live event. How would you diagnose it?" | CASE | [generic] | Segment before concluding: which cohort, which platform, who saw the event. Check release timing and build changes. Name the metric's definition before using it. | Tests the retention comfort in the JD. |
| B3 | "Design, art and engineering each want the same week for an update. How do you decide?" | CASE | [grounded] JD line "coordinate design, art, engineering and community teams on each update" | Propose a decision rule (player impact, release risk, team load), agree it with the leads, name the escalation path. | Coordination without authority; rehearses method, not a past event. |
| B4 | "Two days before a live event, QA finds a blocking bug. What do you do?" | CASE | [grounded] JD line "manage the release checklist with QA" | Decide with QA on severity and the checklist's gates; say who you tell and when; say what you'd delay and what you'd ship. | Tests the checklist requirement live. |
| B5 | "How would you think about monetization inside a live-events calendar?" | CASE | [generic] | Frame it as player value first: what each event asks of players and gives back. Name what you'd check with the monetization owner before planning. | Expected mobile live-ops territory; answered as a live problem, so no past is claimed. |

### C. Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the monthly retention numbers you presented were counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Say what you can and cannot say about the counting. Slot: if you defined the cohort window or retention day, say what it was; if not, say so and say who did. | Counting method is not in your material. |
| C2 | "Which assumption behind those numbers would you defend least?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Name the assumption before they do. If you can't name one, say you don't know how the figure was counted. | Weakest-assumption move for a JD metric. |
| C3 | "How did you tell whether a content drop worked?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Slot: if you measured drops, say which metric and how you read it; if not, say so and say how you'd measure the next one. | Covers the KPI requirement from the calendar side. |

### D. Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why should we take a producer from a puzzle game for a live-service role?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio" | Hold on the four years and the calendar you ran, through two follow-ups. Concede the specific gap if pressed: "I've never worked on a game with in-app purchases." | F6 and F8 together. |
| D2 | "The retention numbers you presented: how much of the movement was actually yours to influence?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Slot: if you influenced the movement, say how; if you only presented the numbers, say so plainly. | Attribution pressure on a figure you presented. |

### E. Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey to here." | VAL | [grounded] "4 years as an associate producer at a puzzle-game studio"; "Wrote the release checklist our QA team still uses" | A 90-second arc: the studio, the calendar, the checklist, the retention presentations. Stop there; let the gap come up in A1. | Casual openers are scored. |
| E2 | "What about the role are you most curious about?" | CO | [grounded] JD line "Plan and run the live-events calendar for two of our mobile titles" | Name one JD line and one specific question about it. | Shows you read the JD. |

### G. Peer (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Our community team and QA sit side by side on every update. Where's the seam, and what happens when you disagree?" | JD | [grounded] JD line "coordinate design, art, engineering and community teams on each update" | Propose seam principles rather than pretending to know the seam. Disagreement story: if none comes to mind, say so, then say how you'd handle it. | Peer seam probe. |
| G2 | "How do you handle credit when a live update succeeds across teams?" | VAL | [generic] | "We" for the team's work, "I" for your part. Slot: name what you did; if credit was shared, say so. | No claim about your past. |

## Requirement coverage

| JD requirement | Question IDs |
|---|---|
| Plan and run the live-events calendar for two of our mobile titles | A2, B1, E2 |
| Coordinate design, art, engineering and community teams on each update | A1, B3, G1 |
| Own the post-event review and the KPIs it reports | A3, A4, C3 |
| Manage the release checklist with QA | B4 |
| 3+ years producing live-service games or apps | D1 (gate, F6) |
| Experience running a content calendar | E1, C3 |
| Comfortable with player-retention metrics | C1, C2, D2, B2 |
| Clear written communication | None, and why: a spoken hour rarely scores writing. Reverse question 5 covers it. |

## Reverse questions

1. "What would you need to see in the first 90 days to call this hire a success?" Why it lands: it turns the interview toward what the job needs.
2. "How is cross-team sign-off for an update decided today, and who owns it?" Why it lands: it shows you read the coordination line.
3. "How do post-event reviews feed into the KPIs the studio reports?" Why it lands: it asks where that line sits in reporting.
4. "Is the release checklist shared across both titles, or does each keep its own?" Why it lands: it shows you know it's a real artifact.
5. "Is there a written element to the role, like a review template or plan document?" Why it lands: it addresses the writing requirement.
6. "What is the biggest live-ops risk on the roadmap this year?" Why it lands: it asks at the strategy level.

No interviewer profile exists, so none of these ties to Tobias's own path.

## Sources

- Provided: the job description, and your message.
- Research tier: L1. Searches 0 of 6 (2 attempted, both refused), fetches 0 of 2.

| Target | Status | What it would have moved |
|---|---|---|
| Saltmarsh Games values | unavailable | Values cheat sheet, not written. Query refused. |
| Saltmarsh Games interview process | unavailable | Loop structure; weights used round-type priors instead. Query refused. |
| Saltmarsh Games strategy / news | unavailable | Company-strategy CO questions, not written. No query sent. |
| Tobias Wrenfield, Saltmarsh Games | unavailable | Interviewer read and a tailored reverse question. No query sent. |
| Representative JD | skipped | Your JD fixes the fit snapshot. |

## Upgrade menu

- Search permission for Saltmarsh Games → values cheat sheet, strategy questions, grounding brief.
- Tobias's public profile, or a link → interviewer read, persona weights, a tailored reverse question.
- The recruiter's note on the round format and any written exercise → written-communication coverage, and a build section if there's a deliverable.
- Whether "3+ years" is a hard floor → settles F6.
- Prep time before Friday → a prioritized schedule.

---

Two things before Friday, both about the pack's assumptions:

1. Is Tobias your future manager, or a peer or skip-level? The answer reweights every bank.
2. Did the recruiter say whether "3+ years producing live-service games or apps" is a hard cut-off? If so, F6 becomes a knockout row to address directly.

Want a live drill? I can play the Skeptic on A1, the question the pack flags as highest-ROI prep, and give feedback against its guidance. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, to carry into later sessions. And I can convert the pack to Word if you'd like.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh_live_ops_producer_interview_pack.md -----
# Interview prep pack: Live Operations Producer, Saltmarsh Games

Interviewer: Tobias Wrenfield, Head of Live Operations. Relationship assumed: hiring manager (not yet confirmed). Format: 60 minutes, Friday.

## How to use this pack

- **Personas** describe how a question is asked. **Types** describe what it scores: **VAL** (behavior matching the company's values), **EXP** (what you actually did, from your own material), **JD** (the job's listed needs), **CO** (company knowledge), **CASE** (a live problem).
- Guidance is scaffolding, not a script. Rehearse out loud, in your own words.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | transferability | Your material shows one title's content-drop calendar, not two titles' live events. Bridge: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: the two-title scope makes a probe on running two calendars likely. If you have planned across more than one title or format, say so in your own words; if not, say so plainly and describe how you would split your planning across two titles. |
| F2 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | none | No gap. The quote reaches the requirement directly. Lead with the calendar in the quote's own terms, because a named calendar carries more weight than an adjective. Expect a probe on it. |
| F3 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses" — your message | medium | [grounded] | presentation | Your material says you wrote the checklist, and that QA still uses it. Bridge, rewording only that quote: "I wrote the release checklist our QA team still uses." Add no practice or figure. |
| F4 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | transferability | Presenting retention numbers is adjacent to owning a post-event review. Your material shows no post-event review. Bridge: "I presented the monthly retention numbers to the studio head." Answer slot: the post-event review line makes a probe likely. If you ran a review after a live event and it set the KPIs, say how, in your own words; if you did not, say so plainly and say what you would build first. |
| F5 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | presentation | The quote reaches the requirement in other terms: you presented retention monthly. Bridge, rewording only that quote: "I presented the monthly retention numbers to the studio head." Add no figure or method. |
| F6 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio" — your message | low | [inferred] | hard_gate | Your material does not establish the live-service producing years: four years are shown, in an associate producer role, at a puzzle-game studio. This row asks nothing; see the upgrade menu. |
| F7 | "coordinate design, art, engineering and community teams on each update" — JD | "Never led a team" — your message | none | [grounded] | capability | Words from your stated negative: "I've never led a team." Answer slot: if you coordinated work across teams without managing them, say how, in your own words; if you did not, say so plainly and describe how you would run an update across four teams. |
| F8 | Monetized live-ops experience — [generic], not a JD line | "never worked on a game with in-app purchases" — your message | none | [grounded] | capability | Words from your stated negative: "I've never worked on a game with in-app purchases." The JD does not raise this, so no answer slot is written against it. Expect it anyway in a mobile live-ops interview; see B5. |

Gap-type notes: F6 is a gate the material does not show met. F7 and F8 rest on your own stated negatives. Confidence describes your evidence; provenance describes this pack's statement.

## Prohibited claims

Not coached in any cell of this pack.

| Not coached | Basis | Honest form |
|---|---|---|
| Ran live events across two titles | Inflated form of F1 | F1's quote at its own scope. Limit, as this pack's observation: your material says one title's calendar, not two titles' events. |
| Owned post-event reviews | Inflated form of F4 | F4's quote at its own scope. Limit, as this pack's observation: your material says presenting retention numbers, not running reviews. |
| Produced live-service games | Inflated form of F6 | "4 years as an associate producer at a puzzle-game studio." Live-service is not stated in your material. |
| Built the retention metrics | Inflated form of F5 | F5's quote: you presented the numbers. Who defined or calculated them is not stated. |
| Led or managed a team | Negative you stated, F7 | "I've never led a team." No slot. |
| Worked on in-app purchase monetization | Negative you stated, F8 | "I've never worked on a game with in-app purchases." No slot. |

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Probes the gaps: no people management, two titles, post-event reviews | High. A hiring manager's prior is Case plus Skeptic; the gaps in F4, F6 and F7 are visible on the page. Weight: 5 questions. | Rehearse the leadership objection until it is plain. Hold the calendar you actually ran; concede the rest in your own words. |
| Case/Strategist | Live problems from the job: plan, diagnose, coordinate | High. The JD's first line is planning, and a hiring manager buys capability. Weight: 4 questions. | Clarify first, then structure. Name the cadence, the teams and the release risk. |
| Data-Driven Prober | Asks how retention was counted and which assumption you would defend least | Medium-high. Retention is a JD line and a CV line. Weight: 3 questions. | Say what you know about how the numbers were counted, and say plainly when you do not know. |
| Pressure | Time-boxed challenge on the puzzle-game background or on your influence | Medium. A 60-minute format leaves room for it. Weight: 2 questions. | Hold through two follow-ups; concede the specific gap, not the whole case. |
| Conversational | Opener: "walk me through your journey" | Medium. Casual openers are scored. Weight: 2 questions. | A 90-second arc from your own quotes. |
| Peer | Seam and credit questions, in collegial form | Low-medium. Weight: 2 questions. | Name what you bring to their team, not just what you need. |

Interviewer read: none. No public profile for Tobias was searched (see Sources), so no career pattern is assumed.

## Question banks

Coverage: 18 questions. Depth follows persona weight. Question IDs are persona letters: A Skeptic, B Case/Strategist, C Prober, D Pressure, E Conversational, G Peer.

### A. Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "I don't see people management in your background. How would you run cross-team updates without it?" | JD | [grounded] "Never led a team" | Start with the plain acknowledgment: "I've never led a team." Then the answer slot from F7: if you coordinated work across teams without managing them, say how, in your own words; if you did not, say so plainly and describe how you would get four teams to agree on an update's scope and date. Hold through two follow-ups by returning to the plan. | F7 is the largest gap in the JD's coordination line. This is the most likely objection; it gets the deepest rehearsal. |
| A2 | "The role covers two titles. Your calendar covered one. How would you carry both?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Tell the calendar in your own words: weekly, one title, two years. Answer slot from F1: if you have planned across more than one title or format, say so; if not, say so plainly and describe how you would split the planning across two titles. | F1 is transferability: the scope is the probe. |
| A3 | "Walk me through your post-event reviews. What changed because of them?" | JD | [grounded] "Presented the monthly retention numbers to the studio head" | Answer slot from F4: if you ran a review after a live event and it changed the KPIs, say what it measured and what changed; if you did not run one, say so plainly and say how you would structure the first one for a title you are handed. | The JD's post-event review line is the premise; your material shows presenting, not reviewing. |
| A4 | "Which of the KPIs you reported did you set yourself?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Say which numbers you presented and where they came from, in your own words. If you chose the metric, say which; if it was set for you, say so plainly. | F5 is presentation, so the ownership question is the probe. Do not claim a metric you did not choose. |
| A5 | "You haven't worked on a game with in-app purchases. Where does that cost us most?" | JD | [grounded] "never worked on a game with in-app purchases" | Start with the plain acknowledgment: "I've never worked on a game with in-app purchases." Then say what you would learn first, and from whom. Do not describe monetization work you have not done. | F8. The JD does not raise monetization, so this is a probe you should expect rather than a requirement. |

### B. Case/Strategist (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Sketch the next quarter's live-events calendar for one of our titles. What do you need to know first?" | CASE | [grounded] JD line "Plan and run the live-events calendar for two of our mobile titles" | Clarify first: the title's goals, the release cadence, team capacity across design, art, engineering and community, and any QA window. Then structure: objective, event types, sequencing, metrics, risks. Think aloud. | The JD's core job. This question contains no claim about your past, so its label stands alone. |
| B2 | "Retention dropped in the week after a live event. How would you diagnose it?" | CASE | [generic] | Segment before you conclude: which cohort, which platform, who saw the event. Check release timing and any build change. Name the metric's definition before using it. | Hypothetical figure-free stimulus; tests the retention comfort in the JD. |
| B3 | "Design, art and engineering each want the same week for an update. How do you decide?" | CASE | [grounded] JD line "coordinate design, art, engineering and community teams on each update" | Propose a decision rule (player impact, release risk, team load), agree it with the leads, then name the escalation path. | Coordination without authority is the F7 gap; this rehearses the method, not a past event. |
| B4 | "Two days before a live event, QA finds a blocking bug. What do you do?" | CASE | [grounded] JD line "manage the release checklist with QA" | Decide with QA on severity and the checklist's own gates; name who you tell, and when; state what you would delay and what you would ship. | Tests the checklist requirement in a live problem. |
| B5 | "How would you think about monetization inside a live-events calendar?" | CASE | [generic] | Frame it as player value first: what each event asks of players and what it gives back. Name what you would check with the monetization owner before you plan an event. No claim about your past. | Expected mobile live-ops territory, not a JD line; answered as a live problem so no past is claimed. |

### C. Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the monthly retention numbers you presented were counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Say what you can and cannot say about the counting. Answer slot: if you defined the cohort window or the retention day, say what it was; if you did not, say so plainly and say who did. | F5 is presentation; the counting method is not in your material, so this is a slot. |
| C2 | "Which assumption behind those numbers would you defend least?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Name the assumption you know of before they do. If you cannot name one, say you do not know how the figure was counted. | Weakest-assumption move for a metric the JD names. |
| C3 | "How did you tell whether a content drop worked?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Answer slot: if you measured drops, say which metric and how you read it; if you did not, say so plainly and say how you would measure the next one. | Covers the KPI requirement from the calendar side; the measuring is not in your material. |

### D. Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why should we take a producer from a puzzle game for a live-service role?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio" | Hold: the four years and the calendar you ran. Hold through two follow-ups. Concede the specific gap if pressed: "I've never worked on a game with in-app purchases." | F6 and F8 together; the hold is the position the material carries. |
| D2 | "The retention numbers you presented: how much of the movement was actually yours to influence?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Answer slot: if you influenced the movement, say how; if you only presented the numbers, say so plainly. | Attribution pressure on a figure you presented, not one you produced. |

### E. Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey to here." | VAL | [grounded] "4 years as an associate producer at a puzzle-game studio"; "Wrote the release checklist our QA team still uses" | A 90-second arc: the puzzle-game studio, the content-drop calendar, the checklist, the retention presentations. Stop there, and let the gap come up in A1. | Casual openers are scored. |
| E2 | "What about the role are you most curious about?" | CO | [grounded] JD line "Plan and run the live-events calendar for two of our mobile titles" | Name one JD line and one specific question about it. | Shows you read the JD; no claim about your past. |

### G. Peer (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Our community team and QA sit side by side on every update. Where's the seam, and what happens when you disagree?" | JD | [grounded] JD line "coordinate design, art, engineering and community teams on each update" | Propose seam principles rather than pretending to know the seam. Disagreement story: if none comes to mind, say so plainly, then say how you would handle it. | Peer seam probe on the coordination line. |
| G2 | "How do you handle credit when a live update succeeds across teams?" | VAL | [generic] | "We" for the team's work, "I" for your own part. Answer slot: name what you did; if credit was shared, say so. | Peer credit probe; no claim about your past in the guidance. |

## Requirement coverage

| JD requirement | Question IDs |
|---|---|
| Plan and run the live-events calendar for two of our mobile titles | A2, B1, E2 |
| Coordinate design, art, engineering and community teams on each update | A1, B3, G1 |
| Own the post-event review and the KPIs it reports | A3, A4, C3 |
| Manage the release checklist with QA | B4 |
| 3+ years producing live-service games or apps | D1 (gate, F6) |
| Experience running a content calendar | E1, C3 |
| Comfortable with player-retention metrics | C1, C2, D2, B2 |
| Clear written communication | None, and why: a spoken hour rarely scores writing. The reverse question on a written element covers it. |

## Reverse questions

1. "What would you need to see in the first 90 days to call this hire a success?" Why it lands: it turns the interview toward what the job actually needs.
2. "How is the cross-team sign-off for an update decided today, and who owns it?" Why it lands: it shows you read the coordination line.
3. "How do post-event reviews feed into the KPIs the studio reports?" Why it lands: it asks where the post-event review line sits in the reporting.
4. "Is the release checklist shared across both titles, or does each keep its own?" Why it lands: it shows you know the checklist is a real artifact.
5. "Is there a written element to the role, such as a review template or a plan document?" Why it lands: it addresses the writing requirement the interview may not test.
6. "What is the biggest live-ops risk on the roadmap this year?" Why it lands: it asks at the level of the strategy, which hiring managers respect.

No interviewer profile exists, so no reverse question ties to Tobias's own path.

## Sources

- Provided: the job description; your message, quoted above as "your message".
- Research tier: L1, searches 0 of 6 (2 refused), fetches 0 of 2.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | unavailable | Values cheat sheet, not written. Query "Saltmarsh Games mobile studio values": refused. |
| 2. Saltmarsh Games interview process, live operations | unavailable | Loop structure; persona weights came from round-type priors instead. Query "Saltmarsh Games live operations producer mobile game": refused. |
| 3. Saltmarsh Games strategy / recent news | unavailable | Company-strategy CO questions, not written. No query was sent; no search permission was granted. |
| 4. Tobias Wrenfield, Saltmarsh Games | unavailable | Interviewer read and a tailored reverse question. No query was sent. |
| 5. Representative live operations producer JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions. |

## Upgrade menu

- Search permission for Saltmarsh Games → a values cheat sheet, strategy questions and a grounding brief.
- Tobias Wrenfield's public profile, or a link to one → an interviewer read, persona weights and a tailored reverse question.
- The recruiter's note on the round format and any written exercise → coverage for written communication, and a build section if there is a deliverable.
- Whether the "3+ years" requirement is a hard floor → turns F6 into a settled gate row.
- How much prep time you have before Friday → a prioritized prep schedule.
