Your prep pack is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-alone-part-2-rooms-case-4-denied-0ff1caf5/9adab3dc-98f4-48fe-80af-afe72e5af099/scratchpad/quartzline_platform-api-pm_interview_pack.md`.

Two things to check before Thursday:

- **The dossier is about three months old** (generated 2026-08-14; today is 2026-11-11). Confirm the role is still open and the posting hasn't changed.
- **Web search was refused**, so the pack rests only on your dossier and this conversation. It has no values or interview-process research.

The pack's highest-return rehearsal is B1, the title objection the underwriter named. It's built on the acknowledge-then-bridge approach: say plainly that you haven't held the PM title or owned a roadmap, then speak to the integration work at its real scope. Hold through two follow-ups, and concede the squad-authority gap specifically.

I left out the prep triage (no prep time given), the values sheet, the interviewer read, and the deliverables section, since none of those inputs were in play.

Would you like me to play the Skeptic on B1 as a drill?

I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.

If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quartzline_platform-api-pm_interview_pack.md -----
# Interview pack: Product Manager, Platform APIs at Quartzline

**Round:** hiring-manager interview, 45 minutes, Thursday
**Interviewer:** name not given
**Built from:** `tuesday-dossier.md` (job-underwriter, generated 2026-08-14, decision `conditional_go`)

**Check before Thursday:** the dossier is about three months old and today is 2026-11-11. Confirm the role is still open and the posting still reads the same. If it has changed, the fit rows and banks need regenerating.

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored.
- Type key: **VAL** behavioral and values, **EXP** deep-dive on your own experience, **JD** the stated role, **CO** company knowledge, **CASE** a live problem.
- Guidance is scaffolding, not a script. Say it in your own words.
- Every claim about your past is one of your quoted sentences, or an answer slot where you say what was yours. Where a quote does not carry a detail, the pack leaves it blank.

## Fit snapshot

Evidence is quoted from the dossier's verified evidence (V1 to V3) and its requirement lines. Requirement sources are the JD text as recorded in the dossier's `role_profile`.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" (JD, must-have) | "Led 30+ end-to-end client integrations of the vendor's REST APIs" (dossier V1); "Ran quarterly roadmap-input sessions feeding client evidence to product" (dossier V3) | low | [inferred] | transferability | Your material does not show the PM title. The bridge is the adjacent work, each sentence at its own scope: you led client integrations, and you ran the input sessions that fed client evidence to product. Name the limit plainly: those were not PM roles. |
| F2 | Owning a roadmap and prioritization authority (JD, responsibility "Own the roadmap for the partner-facing API platform"; underwriter's unresolved area) | none given | none | [grounded] | capability | Gap recorded by the underwriter's `acknowledge_gap` area. Words: "I haven't owned a product roadmap or set prioritization for an engineering squad." No bridge. Follow with a ramp as a plan, never as a past. |
| F3 | "Shipped API or platform products" (JD, must-have) | "Led 30+ end-to-end client integrations of the vendor's REST APIs" (dossier V1) | high | [inferred] | transferability | Not flagged by the underwriter; this is this pack's read. V1 is integration work delivered to clients, not a platform you shipped. Bridge at V1's scope only. Answer slot: if you shipped anything others built on, say what and your part in it; if the integrations were the closest thing, say so. |
| F4 | "Stakeholder management across engineering, sales, customers" (JD, important) | "Led 30+ end-to-end client integrations of the vendor's REST APIs" (dossier V1); "Ran quarterly roadmap-input sessions feeding client evidence to product" (dossier V3) | medium | [grounded] | transferability | Your sentences carry customers and product. Engineering and sales are not named in them. Reword only what is quoted; do not add stakeholders. Caveat: V3 is confirmed with limited inspectable proof, so expect a probe on it. |
| F5 | "Technical fluency: API docs, schemas" (JD, important) | "Wrote the internal integration playbook" (dossier V2) | high | [inferred] | discovery | Your playbook is integration documentation, but the material does not show API reference docs or schemas. This is this pack's read, not an underwriter finding. Answer slot: if you wrote or reviewed reference docs or schemas, say which; if the playbook is the nearest you have done, say that. |
| F6 | "Agile delivery experience" (JD, preferred) | none given | low | [inferred] | discovery | The dossier grades this low. Nothing in the material touches agile delivery. Clarify rather than bridge: see B3. |
| F7 | "Define and track adoption metrics" (JD responsibility) | none given | none | [generic] | discovery | No quote speaks to adoption metrics, and no current baseline is stated. Answer slot: if you defined an adoption metric before, say which and how it was counted; if not, say so and reason from the definition. See C4 and D2. |

**Gates:** none. The dossier's `hard_gates` list is empty.

## Prohibited claims

These are not coached anywhere in this pack, including in answer slots, holds, reverse questions and rationale.

| Not coached | Basis | Honest form |
|---|---|---|
| "Having held a product manager title or role" | Dossier `prohibited_claims` | "I haven't held the product manager title." Then V1 and V3 at their own scope. |
| "Having owned a product roadmap" | Dossier `prohibited_claims` and `acknowledge_gap` | "I haven't owned a product roadmap." |
| "Having set prioritization for an engineering squad" | Dossier `prohibited_claims` | "I haven't set prioritization for an engineering squad." |
| Owned the partner API roadmap | Inflated form of V3, which says the sessions fed client evidence to product | V3 at its own scope. Limit, as this pack's observation: your material says the sessions fed evidence to product, not that you set the roadmap. |
| Led discovery with integration partners | Inflated form of V1, which is client integrations; the JD's "Run discovery with integration partners" is not in your evidence | V1 at its own scope. Limit, as this pack's observation: the material shows integrations, not discovery. |

## Persona table

Weights start from the hiring-manager prior (Case/Strategist and Skeptic dominant). The dossier's named objection moves the Skeptic to the top. No interviewer profile was given, so no further adjustment was made.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (5 questions) | Probes the title gap and the authority gap | High. The underwriter named the title objection as the most likely one. | Acknowledge the gap plainly, hold through two follow-ups, concede the authority gap specifically. |
| Case/Strategist (5) | Live problems on the partner API platform | High. A hiring manager buys capability and tests it on the real roadmap. | Clarify, then structure, then name the decision that is not yours. |
| Data-Driven Prober (3) | Counts behind "30+" and the input sessions | Medium. V1 is a headline figure, so it draws defend-the-number questions. | Say how it was counted, in your own words; name the weakest assumption. |
| Pressure (2) | "Sixty seconds" and "how much was actually you" | Medium. A composure check on the title gap. | Hold the adjacent evidence, concede the title gap specifically. |
| Conversational (2) | Opener and closing questions | Standing. Casual questions are still scored. | A 90-second arc from V1 to V2 to V3, then the role. |

## Question banks

Question count: 17. Five Skeptic, five Case, three Prober, two Pressure, two Conversational. The 45-minute slot does not reward more.

### Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've never held a product manager title or owned a roadmap. Why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs" (V1, high); "Ran quarterly roadmap-input sessions feeding client evidence to product" (V3, medium, caveat visible) | Do not argue the premise. Say: "I haven't held the product manager title or owned a roadmap." Then, at scope: "I led client integrations of the vendor's REST APIs end to end, and I ran the quarterly sessions that fed client evidence to product." Then name what you would learn first: squad prioritization and roadmap ownership. Hold through two follow-ups by returning to the integrations. Concede the authority gap specifically, never the whole claim. | The underwriter named this as the most likely objection, so it is the highest-return rehearsal in the pack. The negatives in the question are sourced by the dossier's `prohibited_claims` and `acknowledge_gap` fields. |
| B2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] dossier `acknowledge_gap` area (F2) | Name roadmap ownership and squad prioritization first, in the words given at F2. Then a ramp as a plan: what you would do in the first month, and what you would ask the squad leads. Make no claim about past ownership. | A Skeptic stem. The answer names the gap, then turns to the ramp. |
| B3 | "What does agile delivery mean to you inside a product org, and what have you run yourself?" | JD | [generic] | Answer slot: if you ran a delivery cadence yourself, say which and how. If you worked inside one that others ran, say that, then say what you would want to confirm about how these squads run theirs. | F6 is `discovery`. The JD's "Agile delivery experience" is the raising source, so the second branch must allow that you never ran one. |
| B4 | "What made you want to move from client integration work into a product role, and why now?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs" (V1, high) | The reason has to be yours. The integrations are the ground you can stand on. Scaffold: say what the integration work showed you that you want to work on at product level, if that is true for you. If the real reason is the role itself, say so, and say what you would bring from the integrations. | A motivation probe: the Skeptic checks "why leave, why here, why now." V1 is the only quote the answer rests on. |
| B5 | "Your roadmap-input sessions. Did product change a decision because of them?" | EXP | [grounded, caveat medium] "Ran quarterly roadmap-input sessions feeding client evidence to product" (V3) | Answer slot: if a decision changed and you had a say in the change, say which and what you did, in your own words. If the sessions fed evidence in and product decided, say exactly that. Volunteer this limit before it is extracted: the sentence carries the feeding, not the deciding. | V3 is medium confidence, and this is the seam the underwriter flagged for a prober. |

### Case/Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A partner's integration keeps failing on the same endpoint across three customers. How would you decide whether to prioritize a fix?" | CASE | [generic] | Clarify first: one endpoint, or a pattern in the docs? Then the objective: which partner outcome you are protecting. Segment: which customers, and how many. Approach: fix now, or document a workaround. Metrics: integration success rate and time to go-live. Risks: squad capacity, and whether the two squads agree. Say you would ask the squad lead for capacity before deciding. | A live problem from the role. It makes no claim about your past, so it carries no provenance. |
| C2 | "Sketch what you would need to know before writing the roadmap for the partner API platform in your first 90 days." | JD | [generic] | Clarify who decides what: the two squad leads, the current adoption baseline, the partner list. Name the two decisions you would want settled before writing anything. | Tests the decision-authority question, which the dossier leaves open. |
| C3 | "Partners say the docs are the problem, not the API. Where do you start?" | JD | [grounded] "Wrote the internal integration playbook" (V2, high) | Start with what partners already do in the integrations you led. Say the playbook is the nearest documentation you have written, and reason from it. Answer slot: if you have written or reviewed reference docs or schemas, say which; if the playbook is the nearest you have done, say that. | R3 is technical fluency. V2 is the nearest artifact, and the slot keeps reference docs claimed only if they were yours. |
| C4 | "How would you measure whether partners are adopting the platform?" | JD | [generic] | Name the adoption event you would count, and the weakest assumption in it. Say you do not know the current baseline, and that you would ask for it first. Answer slot: if you defined an adoption metric before, say which and how it was counted; if not, say so and reason from the definition. | The JD's adoption-metrics responsibility. The dossier names the baseline as unknown, so the honest answer includes asking. |
| C5 | "Two squads, one platform. How would you split the work between them?" | CASE | [generic] | Clarify the split: by API surface, by partner, or by lifecycle. Name the seam, and say what happens when the squads disagree. Name the decision that stays with the squad leads, not with you. | The JD's "two engineering squads" is the raising source. This is the decision-authority question put as a case. |

### Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Of the 30+ integrations you led, how did you count them, and which assumption behind that number would you defend least?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs" (V1, high) | Defend-the-number, in your own words: how you counted, what the count is sensitive to, the assumption you would defend least, and which part of the work was yours. If you did not keep a count, say so and say how you would know. | V1 is a headline figure, so it draws defend-the-number questions. The four slots are the ones a figure raises. |
| D2 | "Who counts as an adopter of this platform, and how would you tell a partner had stopped using it?" | JD | [generic] | Name the adoption event and the churn signal. Say which of the two is the harder to measure, and that you do not yet know the baseline. | The adoption responsibility, with the churn half that the JD implies and the material does not cover. |
| D3 | "Your playbook: was its use measured anywhere?" | EXP | [grounded] "Wrote the internal integration playbook" (V2, high) | Answer slot: if it was used to measure anything, say what and who measured it. If it was not measured, say so. | Premised on V2 only. The second branch allows that no measure existed. |

### Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over a PM who has the job?" | JD | [grounded] V1; V3 (medium, caveat visible) | Hold: the integration work is the ground, and the sessions that fed evidence to product are the adjacent part. Hold through two follow-ups. Concede specifically: "They have the title and the squad authority I haven't held." Do not claim to be the better hire. | Tests composure on the title gap, which the Pressure persona targets. |
| E2 | "That integration count: how much of it was actually you?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs" (V1, high) | Answer slot: say which of the integrations you led end to end and which you supported, in your own words. If the 30+ was a team count, say that. | Premised on V1. The honest branch is the attribution split. |

### Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | JD | [grounded] V1, V2, V3 | A 90-second arc: the integrations (V1), the playbook (V2), the input sessions (V3), then why this role. Add nothing beyond those three. | A rapport opener, scored on economy and clarity. |
| F2 | "What are you most looking forward to in the first year?" | JD | [generic] | Answer with the work: the roadmap-level problems you want to own. Do not answer with the title. | A casual question that is still scored. |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| 3+ years product management experience (R1) | B1, B2, E1, B4 |
| Owning a roadmap and prioritization authority (R1 sub-claim) | B2, C2, C5 |
| Shipped API or platform products (R2) | C5, D1. Partial: the only shipping evidence is V1, and no question asks you to claim a shipped platform beyond that. |
| Technical fluency: API docs, schemas (R3) | C3, F5 |
| Stakeholder management across engineering, sales, customers (R4) | B5, F1 |
| Agile delivery experience (R5) | B3, reverse question 3 |
| Define and track adoption metrics | C4, D2 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" | Resolves the decision-authority question the dossier leaves open. Asking it is diligence, and the answer tells you what you are accepting. |
| 2 | "How is partner API adoption measured today, and what is the current baseline?" | The dossier found no stated baseline. Their answer tells you how much of the adoption work already exists. |
| 3 | "How do you define agile delivery between the PM and the two squads?" | R5 is `discovery`. Their answer shows whether the cadence is set by the PM or the squads. |
| 4 | "What did the last person in this role get right in year one, and what did they get wrong?" | A fit check that does not depend on any claim about you. |
| 5 | "What would make the first six months a success from your side?" | Turns the conversation to outcomes they will measure you against. |

No interviewer profile was provided, so no reverse question is tied to the interviewer's own path.

## Sources

- **Provided documents:** `tuesday-dossier.md`, consumed. Sections used: `handoff_to_mock_interview` (verified evidence, uncertain areas and allowed strategies, likely objection, risks, employer questions, prohibited claims), `role_profile` (requirements and unknowns), `decision` (context only). `evidence_map` and `evidence_state` were not present in the dossier as supplied, so no rejected inferences were carried in.
- **Dossier version:** 1.1, read as the current major version.
- **No CV or JD text** was pasted in this conversation. The dossier's `role_profile` and `verified_candidate_evidence` stand in for both.
- **Searches attempted:**
  - "Quartzline values": refused (search permission not granted).
  - "Quartzline product manager platform APIs interview process": refused (search permission not granted).

**Research tier:** L1 requested. Searches 0 of 6, fetches 0 of 2. Both sends were refused, so the pack is built from the dossier and this conversation only.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quartzline values` | unavailable | Values cheat sheet. Not built: no values-style round is established, and no company values are in hand. Query refused. |
| 2. `Quartzline interview process product manager` | unavailable | Loop structure and persona weights. Weights here rest on the hiring-manager prior alone. Query refused. |
| 3. `Quartzline strategy` / recent news | unavailable | Current strategy for CO questions. No CO questions are in the pack, and no strategy brief was provided. No call sent. |
| 4. `{interviewer name} Quartzline` | n/a | No interviewer name was given. |
| 5. Representative JD for the title | skipped | The dossier's `role_profile` fixes the requirements, so a representative JD would move nothing. |

## Upgrade menu

- Prep time before Thursday → a prioritized schedule keyed to question IDs.
- Your CV, or the work behind V1 to V3 → fit rows F1 to F7 get CV-grounded wording, and the story mapping widens.
- Interviewer's name → an interviewer read, and a reverse question tied to their own path.
- Search access → the values and interview-process research in Sources rows 1 and 2, which may add a values cheat sheet if the round turns out to be values-style.
- Recruiter's prep email → any deliverable they declared.
- Re-running job-underwriter on the current posting → checks whether the August dossier still matches the role.
