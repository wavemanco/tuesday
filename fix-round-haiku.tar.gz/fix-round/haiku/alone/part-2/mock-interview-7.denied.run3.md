Your prep pack is saved as `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-alone-part-2-rooms-case-7-denied-0abec21a/a15549e3-a8c6-4e31-8d2f-176dfb0b75eb/scratchpad/saltmarsh_games_live_operations_producer_interview_pack.md`. I built it assuming Tobias is your hiring manager, and I could not run web research: search permission was refused, so it uses only your JD and your background.

# Saltmarsh Games: Live Operations Producer, interview pack

Candidate: Femi. Interviewer: Tobias Wrenfield, Head of Live Operations. Round: 60 minutes, Friday. Relationship assumed to be hiring manager (not yet confirmed).

## How to use this pack

Personas are how a question is asked; types are what is being scored. Types: **VAL** values and behaviour, **EXP** your own experience, **JD** the job's stated requirements, **CO** company knowledge, **CASE** a live problem. This pack has no CO questions because no company research ran. Guidance is scaffolding, not a script: say the parts in your own words, and leave out any detail you cannot stand behind.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | transferability | Your material says one title and weekly content drops, not two titles of live events. Bridge in your words: "For two years I ran the weekly content-drop calendar for our main title." Answer slot: if you have planned or run a schedule across more than one title, say which and how. If you have not, say so and say how you would plan two titles at once. |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | "Wrote the release checklist our QA team still uses" — your message; none given for the other four teams | low | [grounded] | discovery | Your material shows QA and nothing of design, art, engineering or community. Answer slot: if you coordinated any of these four teams on an update, say which, how, and what you needed from each. If one was not yours to coordinate, say so plainly. |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | transferability | Your material shows you presented retention numbers, not that you owned a post-event review or the KPIs behind it. Bridge: "I presented the monthly retention numbers to the studio head." Answer slot: if you ran or defined any review or KPI, say which and what you did. If the numbers were set by others, say so, and say what you would put in a post-event review first. |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses" — your message | medium | [grounded] | presentation | The sentence reaches the requirement in other terms: wrote, against manage. Bridge: "I wrote the release checklist our QA team still uses." Add no sign-off step and no QA process you did not describe. |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio" — your message | medium | [grounded] | presentation | The years and the role reach the requirement. Whether the title counts as live-service is the JD's framing, not a sentence you wrote. Bridge: "Four years as an associate producer at a puzzle-game studio." Describe the title by what it did: weekly content drops. |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | none | The quote reaches the requirement in role-relevant terms. Limited inspectable proof, so expect a probe: have an example calendar ready, if you are allowed to share one. |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | presentation | The quote reaches the requirement in other terms: presenting numbers, not defining or analysing them. Bridge: "I presented the monthly retention numbers to the studio head." Claim no analysis you did not describe. |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses" — your message | medium | [grounded] | presentation | The quote reaches the requirement in other terms: a checklist another team uses. Bridge: "I wrote the release checklist our QA team still uses." Do not call your writing clear; let the checklist stand. |
| F9 | Your own gap: team leadership (not a JD line; the JD asks you to coordinate teams) | "Never led a team" — your message | none | [grounded] | capability | You stated the absence. Words: "I haven't led a team." Then how you would coordinate without line authority, said as a plan. The coordination answer slot is F2's. |
| F10 | Your own gap: in-app purchase titles (not a JD line) | "never worked on a game with in-app purchases" — your message | none | [grounded] | capability | You stated the absence. Words: "I haven't worked on a game with in-app purchases." Then a ramp plan, said as a plan and never as a past. |

## Persona table

No public interviewer profile was available, so the weights come from the relationship prior for a hiring manager: they are buying capability and checking the gaps. No loop is known.

| Persona | How it shows up here | Weight and reasoning | Questions | Counter-strategy |
|---|---|---|---|---|
| Case / Strategist | Live problems on the calendar and a metric drop | Top. A head of live ops buys the ability to plan two titles, so expect a live plan | 4 (A1 to A4) | Clarify, then structure, then name one risk |
| Skeptic | The gaps: team leadership, monetization, KPIs | Top. The fit snapshot's gaps (F2, F3, F9, F10) are where they will press | 5 (B1 to B5) | Rehearse the most likely objection until it is plain; hold what you did, concede what you did not |
| Data-Driven Prober | The retention numbers you presented | Mid. The JD asks for KPIs and retention, and F7 is the only figure in your material | 3 (C1 to C3) | Say how the figure was counted only if you know; name the weakest assumption before they do |
| Pressure / Stress | Time-boxed challenges and sharp follow-ups | Mid. Tests whether you hold the true position on the calendar | 3 (D1 to D3) | Pause, restate, hold through two follow-ups, then concede specifically |
| Values / Behavioral | Scored stories | Low. No published values are in hand | 2 (V1, V2) | Selection scaffolds with their honest branch |
| Conversational / Rapport | A warm opener and a biography question | Low. A 60-minute round often starts casual | 2 (E1, E2) | A 90-second arc; treat the casual question as scored |
| Peer Evaluator | Seams with QA and design | Low. They are not your peer, but cross-team coordination is peer-like | 2 (P1, P2) | Propose seam principles, not facts about their teams |

## Question banks

### Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how you'd plan the live-events calendar for two titles over the next quarter." | CASE | [generic] | Clarify first: what each title has committed, which teams have capacity, and what QA needs before any date is fixed. Then set a cadence for each title, with buffer before the QA freeze. Then say how you would decide which update takes which slot when two titles compete for the same engineers. Name one thing you would confirm with Tobias before committing to the plan. | A live problem from the JD's calendar line. CASE because it scores structure on the role's own work. [generic] because it makes no claim about your past. |
| A2 | "Your calendar has covered one title. What changes when you run two?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Start from what the calendar taught you, in your words, and only what you saw on it. Then name the differences you would plan for: shared QA capacity, overlapping community load, and the decisions you would make per title. Answer slot: if you have scheduled across more than one title, say which and how. If you have not, say so plainly and move to how you would plan two. | F1 is the thinnest bridge for the calendar requirement. The premise, two titles, is the JD's line rather than your quote, so the second branch lets it be false. F6 is the calendar evidence. |
| A3 | "Tell me about a time you coordinated an update across more than one team." | JD | [grounded] "Wrote the release checklist our QA team still uses" | Open prompt: you choose the instance. The nearest thing your material carries is the release checklist that QA still uses. Describe your role in it, in your words. If you coordinated design, art, engineering or community on an update, say which, how, and what you needed from each. If you did not, say so, and say how you would set that coordination up. | F2 is a discovery gap: the material shows QA and nothing of the other four teams. The open prompt lets you pick an instance, so the guidance supplies none. |
| A4 | "A player metric dropped after an update. Diagnose it." | CASE | [generic] | Clarify the metric and the window first. Then split the drop by segment, platform, cohort and update exposure. Then list the checks: what else shipped that week, whether events overlapped, and whether the drop is real or a tracking change. Say what you would look at first and what would change your mind. | The Case stem. Retention is the JD's headline metric and the one you presented. [generic] because the diagnosis is a method, not a fact about you. |

### Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've never led a team. Why would you coordinate four of them?" | JD | [grounded] "Never led a team" — your message | Open with the plain acknowledgment: "I haven't led a team." Then the nearest thing your material carries, in your own words: the release checklist QA still uses. Then a plan, said as a plan and not as a past: how you would coordinate four teams with no line authority in your first 30 days. Do not argue that leadership is unnecessary. | F9 is a stated capability gap, so the acknowledgment is yours to give. F2 is why this is the likeliest probe on the coordination line. |
| B2 | "You presented the monthly retention numbers. Which of them did you define, and which were set for you?" | JD | [grounded] "Presented the monthly retention numbers to the studio head" — your message | **Highest-ROI rehearsal in this pack.** Hold on the sentence: "I presented the monthly retention numbers to the studio head." Answer slot: if you defined or chose any retention measure, say which and how you decided. If the numbers were set for you, say so plainly and describe what you did with them: you presented them. Hold through two follow-ups by returning to what you presented. Never add a metric you did not present. | F3 and F7 both rest on this one sentence. The JD's post-event review and KPI line is the most pointed requirement, and this is where the material is thinnest. Expect it in some form. |
| B3 | "You haven't worked on a game with in-app purchases. How would you think about monetization in a live event?" | JD | [grounded] "never worked on a game with in-app purchases" — your message | Plain acknowledgment: "I haven't worked on a game with in-app purchases." Then a plan, said as a plan: which event metrics you would watch on the monetization side, who owns that data, and what you would ask the business side in your first weeks. Do not describe a purchase event you have run. | F10. The question is the probe your stated gap invites. The monetization plan is [generic] method, not a claim about you. |
| B4 | "Your background is a puzzle game with content drops. Why is that the same job?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio"; "I ran the weekly content-drop calendar for our main title for the last two years" | Do not argue that it is the same job. Say what carries over, each in the words you used: the content-drop calendar, the release checklist, the retention presentation. Then say what is new: a second title, and a purchase model you have not worked with. If there is a difference in the work that I have not raised, name it. | F5 and F6. The live-service framing is the JD's. Your quotes say content drops, and the pack keeps your words. |
| B5 | "Which part of this JD would you be weakest at on day one?" | JD | [generic] | Name the weakest part honestly: the purchase side, or coordinating without a reporting line. Then say how you would close it by day thirty. Do not pick a strength dressed as a weakness. | A Skeptic stem. Naming the gap yourself is cheaper than having it found. |

### Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the retention numbers you presented were counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head" — your message | If you know how the figure was counted, say it in your words. If you do not, say so plainly: "I presented them; I don't know how the counting was set up." Do not reconstruct a method you did not see. Answer slot: if you did any of the counting yourself, say which part and how. | F7 is the figure you gave, and a figure raises the probe on how it was counted. |
| C2 | "Which assumption behind those retention numbers would you defend least?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" — your message | Weakest-assumption move: if you can name one, say it before they do. If you cannot, say you cannot name the weakest assumption without knowing how the figures were built. That is a complete answer. | Prober stem. No quote names an assumption, so the pack does not supply one. |
| C3 | "The role owns the KPIs a post-event review reports. Which KPI would you put first for a live event, and what would it mislead you about?" | JD | [generic] | Pick one KPI, say why it leads, and name the way it can mislead. Keep it to 90 seconds. This is a decision, not a record, so you claim nothing about your past. | F3. The material does not show you defining a post-event KPI, so the bridge is a decision question. |

### Pressure / Stress

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why should we hire you over someone who has run live events for two titles?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Pause, then restate the question in your own words. Hold the calendar you ran, and concede the gap plainly: you have not run two titles. Then your plan for the first quarter. Do not claim parity. | F1. A timed challenge tests whether you hold the true position without folding into a claim you cannot stand behind. |
| D2 | "That's a list of things you wrote, presented and ran. How much of the calendar was actually you?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years"; "Wrote the release checklist our QA team still uses" | Hold: you ran the calendar, and you wrote the checklist. Concede specifically if part of it was set above you. Answer slot: if some of the calendar was decided above you, say which part and what you decided within it. If all of it was yours to decide, say so, and say which decisions those were. | Hold-then-concede. The quotes carry "ran" and "wrote", not "decided", so the guidance does not claim decisions. |
| D3 | "Presenting numbers isn't owning them. Why should we trust you to own the KPIs?" | JD | [grounded] "Presented the monthly retention numbers to the studio head" — your message | Hold the fact: you presented the monthly retention numbers to the studio head. Do not add an owned review. Concede: "I haven't owned a post-event review. Here is how I would start," then the start, as a plan. | F3's owned-review gap, asked as the pressure version. |

### Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V1 | "Tell me about a time you delivered an unpopular truth to someone senior." | VAL | [generic] | Selection scaffold: pick a time you told someone senior something they did not want to hear. It needs a named stake, a moment you did not fold, and a working relationship at the end. If none comes to mind, say so plainly, then give the nearest thing your material carries: presenting the monthly retention numbers to the studio head, in those words only, without adding how it landed. | The Values stem. No company values are in hand, so this is a selection scaffold with its honest branch. |
| V2 | "When did you put a player ahead of an internal metric?" | VAL | [generic] | Selection scaffold again: a time a player-facing choice cost a number you were tracking, what you decided, and what happened. If you have no such time, say so, and say how you would decide it now. | Player-first is a likely value at a mobile studio, but it stays an assumption until a values page confirms it. |

### Conversational / Rapport

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio"; "I ran the weekly content-drop calendar for our main title for the last two years" | A 90-second arc: the studio and the role, then the content-drop calendar, then the release checklist, then the retention presentation. Each beat in the words quoted here. End on why live events for two titles. | The biography question is scored even when it is casual. |
| E2 | "What's the part of live ops you enjoy most?" | EXP | [generic] | Answer with something you did: the calendar's rhythm, or the checklist. Not a general claim about enjoying live ops. | Casual, but it tests whether you have a specific story. |

### Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Our QA and design teams sit side by side. Where's the seam, and what happens when you disagree?" | JD | [generic] | Propose a seam principle rather than a fact about their teams: for example, that a checklist item is agreed before the date, not after. Then say how you would resolve a disagreement with a peer, as a plan. Do not claim to know their seam. | A peer seam stem. Low weight, because the relationship is not peer. |
| P2 | "How do you handle credit when work spans teams?" | VAL | [grounded] "Wrote the release checklist our QA team still uses" — your message | Name the checklist as your piece, and QA's use of it as theirs. Do not claim a shared sign-off you did not run. | Credit probes test attribution. The checklist sentence has its own scope. |

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| Plan and run the live-events calendar for two titles | A1, A2, D1 |
| Coordinate design, art, engineering and community teams | A3, B1 |
| Own the post-event review and the KPIs it reports | B2, C3, D3 |
| Manage the release checklist with QA | A3, B1, P2 |
| 3+ years producing live-service games or apps | B4, E1 |
| Experience running a content calendar | A2, E1 |
| Comfortable with player-retention metrics | C1, C2, A4 |
| Clear written communication | none, and why: no interview question asks for a written sample, so the pack cannot test it. A written follow-up after the round is where it shows. |
| Not a JD line, your gap: in-app purchases | B3 |
| Not a JD line, your gap: team leadership | B1 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a good post-event review look like here, and who writes it?" | Tests whether the producer owns the review, which is the JD's line. Shows you think in KPIs. |
| R2 | "Which two titles are on the calendar this year, and where do they differ most in cadence?" | Turns the two-title requirement into a planning problem you can talk about. |
| R3 | "How do production and QA split ownership of the release checklist today?" | Shows you know the seam you will work across. Tests the checklist requirement from the other side. |
| R4 | "Where do the producer's decision rights stop, and which calls go to design or engineering?" | Surfaces the coordination-without-authority problem you have a gap in, and asks it as a question. |
| R5 | "What would a strong first 90 days look like for this role?" | Gets the bar in their words, so you can aim at it. |
| R6 | "Which KPIs does the studio head ask about first?" | Connects to the retention presentation in F7 and shows you know the audience for the numbers. |

No reverse question is tied to Tobias's career path, because no public profile was available. A reciprocity question isn't needed, since the relationship is not peer.

## Prohibited claims

Built from the fit snapshot. These are the claims a candidate reaches for under pressure. None of the banks above asserts them.

| Not coached | Basis | Honest form |
|---|---|---|
| Led a team, or managed people | Negative you stated: "Never led a team" | "I haven't led a team." No slot about leadership responsibilities. |
| Experience with in-app purchase or monetization titles | Negative you stated: "never worked on a game with in-app purchases" | "I haven't worked on a game with in-app purchases." |
| Owned the live-events calendar for two titles | Inflated form of F1 | "I ran the weekly content-drop calendar for our main title." The limit is the pack's observation: your material says one title. |
| Owned the post-event review or the KPIs | Inflated form of F3 | "I presented the monthly retention numbers to the studio head." The material shows presenting, not owning. |
| Ran release sign-off or the QA process | Inflated form of F4 | "I wrote the release checklist our QA team still uses." |
| Four years of live-service production | Inflated form of F5 | "Four years as an associate producer at a puzzle-game studio." |

## Sources

- Provided documents: your JD text and your background message. No CV was supplied.
- Searches sent: "Saltmarsh Games mobile studio values" (refused); "Tobias Wrenfield Head of Live Operations Saltmarsh Games" (refused); "Saltmarsh Games live operations news" (refused). No results came back.
- No fetches were attempted.

Research tier: L1, searches 0 of 6 completed (3 refused), fetches 0 of 2.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | unavailable | Refused. Would have moved the values cheat sheet, which is dropped; V1 and V2 stay scaffolds. |
| 2. Interview process, role family | unavailable | No call sent, since search was refused in this session. Would have set the loop structure and persona weights. |
| 3. Company strategy / recent news | unavailable | Refused. Would have moved a grounding brief and a CO question. |
| 4. Interviewer name and company | unavailable | Refused. Would have moved the interviewer read and a tailored reverse question. |
| 5. Representative Live Ops Producer JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions. |

## Upgrade menu

- Search permission for this session → the values cheat sheet, the interviewer read, and the grounding brief, from public sources
- Saltmarsh's values page, pasted → the values section, and V1 and V2 get mapped stories or stay scaffolds
- Your CV → fit rows gain a document; F1, F3 and F6 can move
- A sanitized calendar example, or the release checklist if you may share it → F4 and F6 gain an inspectable artifact, so their confidence can rise
- Your answers to the answer slots in A2, B2 and F2, said here → those rows gain a quote and the pack regenerates them
- Whether the 60 minutes is one of several rounds → loop mode, with per-round weighting

---

Say the word and I'll play the Skeptic on B2, the question the pack names as its highest-ROI prep.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Two questions that would reshape the pack:
1. Is Tobias the person you'd report to, or is this one of several interviews on Friday?
2. Does the posting or process have any location, work-authorization, or schedule requirement that I don't know about?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh_games_live_operations_producer_interview_pack.md -----
# Saltmarsh Games: Live Operations Producer, interview pack

Candidate: Femi. Interviewer: Tobias Wrenfield, Head of Live Operations. Round: 60 minutes, Friday. Relationship assumed to be hiring manager (not yet confirmed). Built from your JD and your background message only, since web search was refused in this session.

## How to use this pack

Personas are how a question is asked; types are what is being scored. Types: **VAL** values and behaviour, **EXP** your own experience, **JD** the job's stated requirements, **CO** company knowledge, **CASE** a live problem. This pack has no CO questions because no company research ran. Guidance is scaffolding, not a script: say the parts in your own words, and leave out any detail you cannot stand behind.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | transferability | Your material says one title and weekly content drops, not two titles of live events. Bridge in your words: "For two years I ran the weekly content-drop calendar for our main title." Answer slot: if you have planned or run a schedule across more than one title, say which and how. If you have not, say so and say how you would plan two titles at once. |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | "Wrote the release checklist our QA team still uses" — your message; none given for the other four teams | low | [grounded] | discovery | Your material shows QA and nothing of design, art, engineering or community. Answer slot: if you coordinated any of these four teams on an update, say which, how, and what you needed from each. If one was not yours to coordinate, say so plainly. |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | transferability | Your material shows you presented retention numbers, not that you owned a post-event review or the KPIs behind it. Bridge: "I presented the monthly retention numbers to the studio head." Answer slot: if you ran or defined any review or KPI, say which and what you did. If the numbers were set by others, say so, and say what you would put in a post-event review first. |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses" — your message | medium | [grounded] | presentation | The sentence reaches the requirement in other terms: wrote, against manage. Bridge: "I wrote the release checklist our QA team still uses." Add no sign-off step and no QA process you did not describe. |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio" — your message | medium | [grounded] | presentation | The years and the role reach the requirement. Whether the title counts as live-service is the JD's framing, not a sentence you wrote. Bridge: "Four years as an associate producer at a puzzle-game studio." Describe the title by what it did: weekly content drops. |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | none | The quote reaches the requirement in role-relevant terms. Limited inspectable proof, so expect a probe: have an example calendar ready, if you are allowed to share one. |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | presentation | The quote reaches the requirement in other terms: presenting numbers, not defining or analysing them. Bridge: "I presented the monthly retention numbers to the studio head." Claim no analysis you did not describe. |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses" — your message | medium | [grounded] | presentation | The quote reaches the requirement in other terms: a checklist another team uses. Bridge: "I wrote the release checklist our QA team still uses." Do not call your writing clear; let the checklist stand. |
| F9 | Your own gap: team leadership (not a JD line; the JD asks you to coordinate teams) | "Never led a team" — your message | none | [grounded] | capability | You stated the absence. Words: "I haven't led a team." Then how you would coordinate without line authority, said as a plan. The coordination answer slot is F2's. |
| F10 | Your own gap: in-app purchase titles (not a JD line) | "never worked on a game with in-app purchases" — your message | none | [grounded] | capability | You stated the absence. Words: "I haven't worked on a game with in-app purchases." Then a ramp plan, said as a plan and never as a past. |

## Persona table

No public interviewer profile was available, so the weights come from the relationship prior for a hiring manager: they are buying capability and checking the gaps. No loop is known.

| Persona | How it shows up here | Weight and reasoning | Questions | Counter-strategy |
|---|---|---|---|---|
| Case / Strategist | Live problems on the calendar and a metric drop | Top. A head of live ops buys the ability to plan two titles, so expect a live plan | 4 (A1 to A4) | Clarify, then structure, then name one risk |
| Skeptic | The gaps: team leadership, monetization, KPIs | Top. The fit snapshot's gaps (F2, F3, F9, F10) are where they will press | 5 (B1 to B5) | Rehearse the most likely objection until it is plain; hold what you did, concede what you did not |
| Data-Driven Prober | The retention numbers you presented | Mid. The JD asks for KPIs and retention, and F7 is the only figure in your material | 3 (C1 to C3) | Say how the figure was counted only if you know; name the weakest assumption before they do |
| Pressure / Stress | Time-boxed challenges and sharp follow-ups | Mid. Tests whether you hold the true position on the calendar | 3 (D1 to D3) | Pause, restate, hold through two follow-ups, then concede specifically |
| Values / Behavioral | Scored stories | Low. No published values are in hand | 2 (V1, V2) | Selection scaffolds with their honest branch |
| Conversational / Rapport | A warm opener and a biography question | Low. A 60-minute round often starts casual | 2 (E1, E2) | A 90-second arc; treat the casual question as scored |
| Peer Evaluator | Seams with QA and design | Low. They are not your peer, but cross-team coordination is peer-like | 2 (P1, P2) | Propose seam principles, not facts about their teams |

## Question banks

### Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how you'd plan the live-events calendar for two titles over the next quarter." | CASE | [generic] | Clarify first: what each title has committed, which teams have capacity, and what QA needs before any date is fixed. Then set a cadence for each title, with buffer before the QA freeze. Then say how you would decide which update takes which slot when two titles compete for the same engineers. Name one thing you would confirm with Tobias before committing to the plan. | A live problem from the JD's calendar line. CASE because it scores structure on the role's own work. [generic] because it makes no claim about your past. |
| A2 | "Your calendar has covered one title. What changes when you run two?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Start from what the calendar taught you, in your words, and only what you saw on it. Then name the differences you would plan for: shared QA capacity, overlapping community load, and the decisions you would make per title. Answer slot: if you have scheduled across more than one title, say which and how. If you have not, say so plainly and move to how you would plan two. | F1 is the thinnest bridge for the calendar requirement. The premise, two titles, is the JD's line rather than your quote, so the second branch lets it be false. F6 is the calendar evidence. |
| A3 | "Tell me about a time you coordinated an update across more than one team." | JD | [grounded] "Wrote the release checklist our QA team still uses" | Open prompt: you choose the instance. The nearest thing your material carries is the release checklist that QA still uses. Describe your role in it, in your words. If you coordinated design, art, engineering or community on an update, say which, how, and what you needed from each. If you did not, say so, and say how you would set that coordination up. | F2 is a discovery gap: the material shows QA and nothing of the other four teams. The open prompt lets you pick an instance, so the guidance supplies none. |
| A4 | "A player metric dropped after an update. Diagnose it." | CASE | [generic] | Clarify the metric and the window first. Then split the drop by segment, platform, cohort and update exposure. Then list the checks: what else shipped that week, whether events overlapped, and whether the drop is real or a tracking change. Say what you would look at first and what would change your mind. | The Case stem. Retention is the JD's headline metric and the one you presented. [generic] because the diagnosis is a method, not a fact about you. |

### Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've never led a team. Why would you coordinate four of them?" | JD | [grounded] "Never led a team" — your message | Open with the plain acknowledgment: "I haven't led a team." Then the nearest thing your material carries, in your own words: the release checklist QA still uses. Then a plan, said as a plan and not as a past: how you would coordinate four teams with no line authority in your first 30 days. Do not argue that leadership is unnecessary. | F9 is a stated capability gap, so the acknowledgment is yours to give. F2 is why this is the likeliest probe on the coordination line. |
| B2 | "You presented the monthly retention numbers. Which of them did you define, and which were set for you?" | JD | [grounded] "Presented the monthly retention numbers to the studio head" — your message | Highest-ROI rehearsal in this pack. Hold on the sentence: "I presented the monthly retention numbers to the studio head." Answer slot: if you defined or chose any retention measure, say which and how you decided. If the numbers were set for you, say so plainly and describe what you did with them: you presented them. Hold through two follow-ups by returning to what you presented. Never add a metric you did not present. | F3 and F7 both rest on this one sentence. The JD's post-event review and KPI line is the most pointed requirement, and this is where the material is thinnest. Expect it in some form. |
| B3 | "You haven't worked on a game with in-app purchases. How would you think about monetization in a live event?" | JD | [grounded] "never worked on a game with in-app purchases" — your message | Plain acknowledgment: "I haven't worked on a game with in-app purchases." Then a plan, said as a plan: which event metrics you would watch on the monetization side, who owns that data, and what you would ask the business side in your first weeks. Do not describe a purchase event you have run. | F10. The question is the probe your stated gap invites. The monetization plan is [generic] method, not a claim about you. |
| B4 | "Your background is a puzzle game with content drops. Why is that the same job?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio"; "I ran the weekly content-drop calendar for our main title for the last two years" | Do not argue that it is the same job. Say what carries over, each in the words you used: the content-drop calendar, the release checklist, the retention presentation. Then say what is new: a second title, and a purchase model you have not worked with. If there is a difference in the work that I have not raised, name it. | F5 and F6. The live-service framing is the JD's. Your quotes say content drops, and the pack keeps your words. |
| B5 | "Which part of this JD would you be weakest at on day one?" | JD | [generic] | Name the weakest part honestly: the purchase side, or coordinating without a reporting line. Then say how you would close it by day thirty. Do not pick a strength dressed as a weakness. | A Skeptic stem. Naming the gap yourself is cheaper than having it found. |

### Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the retention numbers you presented were counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head" — your message | If you know how the figure was counted, say it in your words. If you do not, say so plainly: "I presented them; I don't know how the counting was set up." Do not reconstruct a method you did not see. Answer slot: if you did any of the counting yourself, say which part and how. | F7 is the figure you gave, and a figure raises the probe on how it was counted. |
| C2 | "Which assumption behind those retention numbers would you defend least?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" — your message | Weakest-assumption move: if you can name one, say it before they do. If you cannot, say you cannot name the weakest assumption without knowing how the figures were built. That is a complete answer. | Prober stem. No quote names an assumption, so the pack does not supply one. |
| C3 | "The role owns the KPIs a post-event review reports. Which KPI would you put first for a live event, and what would it mislead you about?" | JD | [generic] | Pick one KPI, say why it leads, and name the way it can mislead. Keep it to 90 seconds. This is a decision, not a record, so you claim nothing about your past. | F3. The material does not show you defining a post-event KPI, so the bridge is a decision question. |

### Pressure / Stress

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why should we hire you over someone who has run live events for two titles?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Pause, then restate the question in your own words. Hold the calendar you ran, and concede the gap plainly: you have not run two titles. Then your plan for the first quarter. Do not claim parity. | F1. A timed challenge tests whether you hold the true position without folding into a claim you cannot stand behind. |
| D2 | "That's a list of things you wrote, presented and ran. How much of the calendar was actually you?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years"; "Wrote the release checklist our QA team still uses" | Hold: you ran the calendar, and you wrote the checklist. Concede specifically if part of it was set above you. Answer slot: if some of the calendar was decided above you, say which part and what you decided within it. If all of it was yours to decide, say so, and say which decisions those were. | Hold-then-concede. The quotes carry "ran" and "wrote", not "decided", so the guidance does not claim decisions. |
| D3 | "Presenting numbers isn't owning them. Why should we trust you to own the KPIs?" | JD | [grounded] "Presented the monthly retention numbers to the studio head" — your message | Hold the fact: you presented the monthly retention numbers to the studio head. Do not add an owned review. Concede: "I haven't owned a post-event review. Here is how I would start," then the start, as a plan. | F3's owned-review gap, asked as the pressure version. |

### Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V1 | "Tell me about a time you delivered an unpopular truth to someone senior." | VAL | [generic] | Selection scaffold: pick a time you told someone senior something they did not want to hear. It needs a named stake, a moment you did not fold, and a working relationship at the end. If none comes to mind, say so plainly, then give the nearest thing your material carries: presenting the monthly retention numbers to the studio head, in those words only, without adding how it landed. | The Values stem. No company values are in hand, so this is a selection scaffold with its honest branch. |
| V2 | "When did you put a player ahead of an internal metric?" | VAL | [generic] | Selection scaffold again: a time a player-facing choice cost a number you were tracking, what you decided, and what happened. If you have no such time, say so, and say how you would decide it now. | Player-first is a likely value at a mobile studio, but it stays an assumption until a values page confirms it. |

### Conversational / Rapport

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio"; "I ran the weekly content-drop calendar for our main title for the last two years" | A 90-second arc: the studio and the role, then the content-drop calendar, then the release checklist, then the retention presentation. Each beat in the words quoted here. End on why live events for two titles. | The biography question is scored even when it is casual. |
| E2 | "What's the part of live ops you enjoy most?" | EXP | [generic] | Answer with something you did: the calendar's rhythm, or the checklist. Not a general claim about enjoying live ops. | Casual, but it tests whether you have a specific story. |

### Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Our QA and design teams sit side by side. Where's the seam, and what happens when you disagree?" | JD | [generic] | Propose a seam principle rather than a fact about their teams: for example, that a checklist item is agreed before the date, not after. Then say how you would resolve a disagreement with a peer, as a plan. Do not claim to know their seam. | A peer seam stem. Low weight, because the relationship is not peer. |
| P2 | "How do you handle credit when work spans teams?" | VAL | [grounded] "Wrote the release checklist our QA team still uses" — your message | Name the checklist as your piece, and QA's use of it as theirs. Do not claim a shared sign-off you did not run. | Credit probes test attribution. The checklist sentence has its own scope. |

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| Plan and run the live-events calendar for two titles | A1, A2, D1 |
| Coordinate design, art, engineering and community teams | A3, B1 |
| Own the post-event review and the KPIs it reports | B2, C3, D3 |
| Manage the release checklist with QA | A3, B1, P2 |
| 3+ years producing live-service games or apps | B4, E1 |
| Experience running a content calendar | A2, E1 |
| Comfortable with player-retention metrics | C1, C2, A4 |
| Clear written communication | none, and why: no question in an interview asks for a written sample. The pack cannot test it. Any written follow-up after the round is where it shows. |
| Not a JD line, your gap: in-app purchases | B3 |
| Not a JD line, your gap: team leadership | B1 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a good post-event review look like here, and who writes it?" | Tests whether the producer owns the review, which is the JD's line. Shows you think in KPIs. |
| R2 | "Which two titles are on the calendar this year, and where do they differ most in cadence?" | Turns the two-title requirement into a planning problem you can talk about. |
| R3 | "How do production and QA split ownership of the release checklist today?" | Shows you know the seam you will work across. Tests the checklist requirement from the other side. |
| R4 | "Where do the producer's decision rights stop, and which calls go to design or engineering?" | Surfaces the coordination-without-authority problem you have a gap in, and asks it as a question. |
| R5 | "What would a strong first 90 days look like for this role?" | Gets the bar in their words, so you can aim at it. |
| R6 | "Which KPIs does the studio head ask about first?" | Connects to the retention presentation in F7 and shows you know the audience for the numbers. |

No reverse question is tied to Tobias's own career path, because no public profile was available. The reciprocity question is not needed: the relationship is not peer.

## Prohibited claims

Built locally from the fit snapshot. These are the claims a candidate reaches for under pressure. None of the banks above asserts them.

| Not coached | Basis | Honest form |
|---|---|---|
| Led a team, or managed people | Negative you stated: "Never led a team" | "I haven't led a team." No slot about leadership responsibilities. |
| Experience with in-app purchase or monetization titles | Negative you stated: "never worked on a game with in-app purchases" | "I haven't worked on a game with in-app purchases." |
| Owned the live-events calendar for two titles | Inflated form of F1 | "I ran the weekly content-drop calendar for our main title." The limit is the pack's observation: your material says one title. |
| Owned the post-event review or the KPIs | Inflated form of F3 | "I presented the monthly retention numbers to the studio head." The material shows presenting, not owning. |
| Ran release sign-off or the QA process | Inflated form of F4 | "I wrote the release checklist our QA team still uses." |
| Four years of live-service production | Inflated form of F5 | "Four years as an associate producer at a puzzle-game studio." |

## Sources

- Provided documents: your JD text and your background message, both in this conversation. No CV was supplied.
- Searches sent: "Saltmarsh Games mobile studio values" (refused); "Tobias Wrenfield Head of Live Operations Saltmarsh Games" (refused); "Saltmarsh Games live operations news" (refused). Web search permission was not granted in this session, so no results came back.
- No fetches were attempted.

Research tier: L1 — searches 0 of 6 completed (3 refused), fetches 0 of 2.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | unavailable | Refused. Would have moved the values cheat sheet; section dropped, V1 and V2 stay scaffolds. |
| 2. Interview process, role family | unavailable | No call sent: search was refused in this session. Would have set the loop structure and the persona weights. |
| 3. Company strategy / recent news | unavailable | Refused. Would have moved a grounding brief and a CO question. |
| 4. Interviewer name and company | unavailable | Refused. Would have moved the interviewer read and a tailored reverse question. |
| 5. Representative Live Ops Producer JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions. |

## Upgrade menu

- Search permission for this session → the values cheat sheet, the interviewer read, and the grounding brief, all from public sources
- Saltmarsh's values page, pasted → the values section, and V1 and V2 get mapped stories or stay scaffolds
- Your CV → fit rows gain a document; F1, F3 and F6 can move
- A sanitized calendar example, or the release checklist if you may share it → F4 and F6 gain an inspectable artifact, so their confidence can rise
- Your answers to the answer slots in A2, B2 and F2, said here → those rows gain a quote and the pack regenerates them
- Whether the 60 minutes is one of several rounds → loop mode, with a per-round weighting
