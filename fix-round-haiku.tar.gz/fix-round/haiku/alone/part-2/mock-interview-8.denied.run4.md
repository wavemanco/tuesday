Your prep pack is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-alone-part-2-rooms-case-8-denied-a784b85e/04ec8171-bec7-4d96-90d6-706a1140bcc5/scratchpad/Ashgrove_member_experience_lead_interview_pack.md` (also sent to you above). I built it from the JD, the recruiter's email, the values and strategy points you pasted, and your background. I ran no web searches, because those inputs already cover what research would have found.

The pack centres on two gaps the panel is likely to press:

- **Contact centre (F8):** you have never worked in one, and the JD puts it in scope. Question A1 is the highest-ROI rehearsal. Practise the plain acknowledgment, the branch log, and the plan for learning the contact-centre flow until they're routine.
- **Presenting to senior leaders (F7):** you've never presented above regional level. Question A3 covers this, and P1 tests whether you can hold your position without overclaiming.

The strategy points matter most for complaint routing. Question C4 asks what happens to an open complaint when a branch closes in the 2027 hub consolidation. The pack suggests a rule that the complaint owner keeps the case until it closes, tied to "Own the Fix".

Two judgement calls to check:
- **Round 3 persona weighting:** I treated the two branch managers as a panel with no named profiles, so the weights rest on round type. Their names would sharpen this.
- **Strategy source:** you gave me four summary points, not the full brief. Check any figure against the full brief before you quote it.

Would you like a drill? I can play the Skeptic on A1 and push on the contact-centre gap. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Ashgrove_member_experience_lead_interview_pack.md -----
# Ashgrove Credit Union: Member Experience Lead, interview prep pack

**Candidate:** Dara (they/them)
**Role:** Member Experience Lead, Ashgrove Credit Union (member-owned, about 900 staff)
**Rounds:** 20 November 2026
- Round 1: 30 min with the recruiter (screen)
- Round 2: 45 min with the Head of Member Services, your future manager, mostly behavioural
- Round 3: 60 min panel of two branch managers, including a 20-minute complaint escalation case; the panel scores against the four published values

Interviewers for rounds 2 and 3 are not yet named, so the persona weights below rest on round type, not on individual profiles.

---

## How to use this pack

- **Personas** describe how a question is asked. **Types** describe what is being scored.
- Type key: **VAL** behavioural/values alignment · **EXP** your own past work, tested for attribution · **JD** the role's listed requirements · **CO** company and strategy knowledge · **CASE** a live problem from the role.
- Guidance is scaffolding, not a script. Rehearse what you actually did, in your own words.
- Answer slots (rows marked "Answer slot") are instructions for the interview, not questions to answer here. They ask you to say either what you did, or that the step was not yours or did not happen.

---

## 4. Fit snapshot

Requirements are quoted from the JD (or the recruiter email, for the panel). Your evidence is quoted from your background message. Nothing else is treated as evidence about you.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" (JD) | "6 years in retail banking, the last 3 as a branch supervisor." (your message) | medium | [grounded] | none | No gap on years. Say it as written. Expect a probe on whether branch work counts as customer operations; answer from what you did at the counter and in the log. Confidence is medium because nothing has been inspected yet. |
| F2 | "Own the member complaints process end to end across branches and the contact centre" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | transferability | Your material says one branch's formal log. It does not show end-to-end ownership, across branches, or the contact centre. Bridge with the log at its own scope: "I handled the branch's formal complaints log." Answer slot: if you owned any step beyond logging, say which and how you decided; if the log was the whole of your part, say so and stay with the branch. |
| F3 | "coach branch supervisors on escalations" (JD) | "trained new tellers on our escalation script" (your message) | medium | [grounded] | transferability | Teaching new tellers a script is adjacent to coaching supervisors on escalation decisions, and the two should not be merged. Say what you taught and to whom. Your supervisor years are a real basis for the coaching role, but they are not coaching experience in the sense the JD means. |
| F4 | "report monthly on complaint volumes and resolution times" (JD) | "I built the monthly complaints spreadsheet our regional manager uses." (your message) | medium | [grounded] | presentation | The spreadsheet reaches the monthly reporting requirement in other terms. Reword only that sentence. Resolution times are not stated. Answer slot: if the spreadsheet tracked resolution times, say how; if not, say so and say how you would add them. Confidence rises to high if you can show a sanitised copy of the spreadsheet. |
| F5 | "comfortable with Excel reporting" (JD) | "I built the monthly complaints spreadsheet our regional manager uses." (your message) | medium | [grounded] | presentation | Your material says spreadsheet, not Excel. Do not add Excel as a fact. Answer slot: if you used Excel for it, name the features you used in your own words; if you used another tool, say which. |
| F6 | "experience handling regulated complaints" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | transferability | "Formal" is not the same as "regulated". Your material does not show which rules applied to the log. Bridge: the formal log, at its own scope, and no claim of regulatory work. Answer slot: if any of those complaints were subject to timescales, written-response rules or escalation rules set outside the branch, say which and how you applied them; if none were, or you did not work to those rules, say so and describe how the log was kept. |
| F7 | "confident presenting to senior leaders" (JD) | "I've never presented to anyone above regional level." (your message) | none | [grounded] | capability | A capability you stated as absent. The words are your own: "I've never presented to anyone above regional level." Then how you would prepare, said as a plan and never as a past event. Do not claim senior presentations you have not made. |
| F8 | "the contact centre" (JD, scope of "across branches and the contact centre") | "Never worked in a contact centre" (your message) | none | [grounded] | capability | A capability you stated as absent. The words are your own: "I've never worked in a contact centre." Then a plan for learning the contact-centre flow. Do not describe contact-centre work you have not done. |
| F9 | "work with digital teams on self-service journeys" (JD) | none given | none | [grounded] | discovery | Your material is silent on digital or self-service work, so this is discovery, not a known absence. Answer slot: if you have worked on a customer journey change, say which and what you handled; if you have not, say so and say how you would learn the journey. |

Gap-type routing: F1 and F5 are rows with a quote that reaches the requirement. F2, F3, F6 are transferability (adjacent work only). F4 and F5 are presentation (the quote reaches the requirement in other terms). F7 and F8 are capability because you stated the absence. F9 is discovery because the material is silent.

---

## Prohibited claims

Built from the fit snapshot. None of the guidance below asserts, softens or implies these.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned complaints end to end across branches and the contact centre | Inflated form of F2 | "I handled the branch's formal complaints log." The pack's own observation, not words for you: your material says one branch's log, not end-to-end ownership. |
| Has worked in a contact centre | Negative you stated (F8) | "I've never worked in a contact centre." No answer slot here. |
| Has presented to senior leaders | Negative you stated (F7) | "I've never presented to anyone above regional level." No answer slot here. |
| Has run complaints to a regulatory standard | Inflated form of F6 | "I handled the branch's formal complaints log." The pack's observation: your material does not say the log was regulated. |
| Has coached branch supervisors | Inflated form of F3 | "I trained new tellers on our escalation script." |

---

## 6. Grounding brief

Source: the four strategy points the recruiter sent, as you have summarised them. You did not paste the full brief. Check every number against the full brief before you quote it in the room.

- **Digital shift:** move 40% of member service to digital channels by 2028.
- **Branch footprint:** consolidate eight branches into five hubs over 2027.
- **New product:** launch a small-business lending product in Q1 2027.
- **Competitive pressure:** app-only banks.

The strategy brief is dated July 2026, so it is under six months old. It is current enough to use.

---

## 8. Persona table

Weights are relationship priors (round type), with the reasoning shown. Depth follows weight.

| Persona | Where it shows up | Likelihood | Why | Counter-strategy |
|---|---|---|---|---|
| Values / Behavioral (B) | Round 2 (mostly behavioural); Round 3 (scored against values) | High, top weight | Round 2 is "mostly behavioral" per the recruiter, and Round 3 scores the four values. Depth 5. | Map a story to each value where your material carries one; where it does not, use a selection scaffold and say plainly if none comes to mind. |
| Skeptic (A) | Round 2 (your future manager, de-risking gaps); light in Round 1 | High | A manager's job is to find what the gaps will cost. F2, F6, F7, F8 are the likely probes. Depth 4. | Rehearse the predictable objection until it is calm. Hold the bridge at its own scope. |
| Case / Strategist (C) | Round 3, the 20-minute escalation case; strategy questions | High in Round 3 | The recruiter named a 20-minute case. CO questions use the strategy brief. Depth 4 to 5. | Clarify, then structure: which complaint, which timescale, who owns it, what the member hears. Speak it aloud in 90 to 120 seconds. |
| Conversational / Rapport (D) | Round 1 (recruiter) | High for Round 1 | Round 1 is a screen. Casual questions are still scored, and the JD's topics come up as small talk. Depth 3. | Keep a 90-second arc ready. Treat casual Excel and journey questions as scored. |
| Peer Evaluator (E) | Round 3, branch managers who sit beside the role | Medium | Two branch managers price what the hire does to their own workload, and the seam between branches and the contact centre is theirs too. Depth 2. | Offer seam principles, not claimed seams. Credit the fix, not the owner. |
| Pressure (P) | Round 2 and Round 3, if they test composure | Medium | A manager or panel may time-box an answer or push a gap. Depth 2. | Hold the log and the plan through two follow-ups. Concede the gap explicitly and specifically. Do not fold on what you did. |

---

## 9. Question banks

Ordered by weight: Values/Behavioral, Skeptic, Case/Strategist, Conversational, Peer Evaluator, Pressure.

**Highest-ROI prep in this pack: A1.** The contact-centre gap (F8) is the most predictable objection. The JD names the contact centre in the role's scope, and you have stated you have never worked in one. Rehearse the plain acknowledgment, the log, and the plan until they are boring.

### B. Values / Behavioral (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a complaint you kept hold of until it was actually solved." | VAL | [grounded] "I handled the branch's formal complaints log" (your message) | Selection scaffold for Own the Fix: pick a complaint that stayed with you after it left the first desk. It needs a named problem, your follow-through, and how you knew it was solved. If none comes to mind, say so plainly, then give the nearest thing your log carries, described at the log's own scope. | Own the Fix is the value this log most nearly speaks to, but the quote does not carry the follow-through, so the story is a scaffold. |
| B2 | "Tell me about teaching someone a procedure they had to get right under pressure." | VAL | [grounded] "trained new tellers on our escalation script" (your message) | Story map from the quote: the escalation script, the new tellers, the training. Answer slot: if you did anything to make the script clear to a new teller, say what; if you taught it only as written, say that. Do not claim the teller got it right unless you saw it. | F3's adjacent work, rehearsed for the values round. Plain Words lives in how you taught a procedure. |
| B3 | "Describe a time you put a member's position ahead of a procedure." | VAL | [generic] (no candidate sentence carries this) | Selection scaffold for Members First: pick a time you explained or adjusted a procedure for a member. It needs the procedure, the member's stake, and what you decided. If you have no such time, say so plainly, then describe how you would decide it. | No sentence of yours carries this value. A scaffold is the honest form. |
| B4 | "Ashgrove says every branch is part of its town. A branch in one of those towns is closing. How would you make sure its members' complaints still get dealt with?" | VAL | [grounded] "Neighbours, Not Numbers — every branch is part of its town" (company values, pasted) | Reason from the value: which members lose local access, where a complaint goes if the branch door closes, who keeps ownership until it closes. The reasoning is generic. It makes no claim about your past. | Raised by the published value and by the 2027 hub plan. Ties VAL to CO, and it is the tension the panel may test. |
| B5 | "When have you had to explain something to a member a second time?" | VAL | [grounded] "Plain Words — if a member needs it explained twice, we wrote it wrong" (company values, pasted) | Open prompt. Selection scaffold: pick a time a member needed a second explanation. Name the first explanation, what you changed, and whether the member understood. If none comes to mind, say so, then say how you would check whether a letter is plain. | Plain Words is a published value; a specific decision demonstrates it. |

### A. Skeptic (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You haven't worked in a contact centre, and this role runs across one. What makes you the right person to own complaints that come through it?" | JD | [grounded] "Never worked in a contact centre" (your message); [grounded] "I handled the branch's formal complaints log" (your message) | The plain acknowledgment: "I've never worked in a contact centre." Then the nearest thing your material carries: the branch's formal log, at its own scope. Then the plan, said as a plan: how you would learn the contact-centre flow in the first month, starting with how its complaints are logged. Hold through two follow-ups by returning to the log and the plan. Concede specifically: "I don't yet know how contact-centre complaints are recorded; I would want to see the system first." | F8 and F2 are the largest gaps. This is the highest-ROI rehearsal in the pack. |
| A2 | "What did you handle that you would call a regulated complaint?" | JD | [grounded] "I handled the branch's formal complaints log" (your message) | Answer slot: if any of those complaints were subject to timescales, written-response rules or escalation rules set outside the branch, say which and how you applied them. If none were, or you did not work to those rules, say so plainly and describe how the log was kept. The second branch is a true answer, not a failure. | F6 is transferability. The JD raises regulated complaints, and your quote carries only "formal". |
| A3 | "The role reports to senior leaders every month. Tell me how you would present complaint trends to someone two levels above you." | JD | [grounded] "I've never presented to anyone above regional level." (your message) | The plain acknowledgment: "I've never presented to anyone above regional level." Then the plan: one trend, one decision you need from them, one ask. Say it as a plan, not as a past event. Hold through a follow-up by staying with the plan. | F7 is a stated capability gap. Rehearse the honest answer before the probe. |
| A4 | "What did the monthly complaints spreadsheet track, and did it track resolution times?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." (your message) | Name what it tracked in your own words. Answer slot: if it tracked resolution times, say how they were measured and which part of that you would defend least. If it did not, say so plainly and say how you would add them. Do not describe a measure you did not track. | F4 and F5. The question tests attribution, not the spreadsheet's quality. |

### C. Case / Strategist (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A member has waited three weeks on a fee complaint. The branch says it is with the contact centre. Walk us through your first hour." | CASE | [generic] (live problem, no claim about your past) | Clarify first: which complaint type, what the timescale is, who currently owns the file. Then structure: is it overdue, one named owner, contact the member today, get the contact centre's status, root cause, feedback to the branch. Speak it in 90 to 120 seconds. | The 20-minute case is a complaint escalation. This is the kind of case the panel will set. |
| C2 | "A complaint has been escalated to you. The supervisor says the teller followed the script. The member disagrees. What do you do?" | CASE | [generic] | Separate the script question from the member's experience. Check the record, speak to the supervisor and then the teller, and decide what gets fixed. Coach, do not blame. Name what you would tell the member and when. | Covers the JD line to coach supervisors on escalations. No past claim is needed. |
| C3 | "Ashgrove plans to move 40% of member service to digital channels by 2028. Where do complaints sit in that plan?" | CO | [grounded] "move 40% of member service to digital channels by 2028" (strategy brief, as summarised by the recruiter) | Give a view, without claiming knowledge of the digital plan. Complaints that arrive digitally need the same tracking, and the risk is complaints disappearing into self-service. Propose tracking complaints by channel and checking that self-service has a route to a person. Concession: "I don't know the digital team's current plan." | F9 is discovery, so do not claim self-service experience. The answer is judgment at the company's altitude. |
| C4 | "Eight branches become five hubs in 2027. What happens to a complaint that is open at a branch that closes?" | CO | [grounded] "consolidate eight branches into five hubs over 2027" (strategy brief, as summarised by the recruiter) | Name the risks: open deadlines, the member's local contact, which hub takes the file. Propose a rule that the complaint owner keeps the case until it closes, and link it to Own the Fix. Hold the rule, and concede that you would want to see the hub plan before you commit to a routing design. | This is the complaint-routing implication of the strategy. Expect it. |
| C5 | "A small-business lending product launches in Q1 2027. What complaints would you expect, and how would you keep them separate?" | CO | [grounded] "launch a small-business lending product in Q1 2027" (strategy brief, as summarised by the recruiter) | Reason generically: a new product brings new complaint categories and possibly different rules. Propose agreeing the categories before launch, so they are not mixed into the retail log. No claim about your past. | Tests altitude on the company's 2027 plan. |

### D. Conversational / Rapport (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey. How did you end up in complaints?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." (your message) | A 90-second arc: the years in retail banking, the branch supervisor role, the formal log, the spreadsheet. Use only what is quoted. Do not add a promotion, a team size or a result. | F1 is the arc's spine. The question is casual, and it is scored. |
| D2 | "What are you actually doing with Excel these days?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." (your message) | Describe the spreadsheet and what it does. Offer to walk through it. Answer slot: name any functions you used, in your own words; if you used none in particular, say what you did use. | F5. Casual phrasing of a JD requirement. |
| D3 | "Why this role, and why now?" | JD | [generic] (motivation; no candidate sentence carries it) | Selection scaffold: pick the part of the role you most want to change, such as monthly reporting or the escalation path. Say why it matters to you in your own words. If you have no clear reason, say so, then say what you would want to learn first. | Motivation is yours to supply. The scaffold makes it specific without supplying it. |

### E. Peer Evaluator (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "We run the branches. Where is the seam between your job and ours, and what happens when we disagree about a complaint?" | VAL | [generic] | Propose seam principles: who owns the member after a handover, and who decides when branch and contact centre disagree. For disagreement, pick a time you disagreed with another manager about a complaint. Name the disagreement and how you resolved it. If you have no such time, say so plainly. | The panel are branch managers and will feel the seam in their own workload. |
| E2 | "A branch manager says a complaint is the contact centre's fault. How do you handle the credit when work spans teams?" | VAL | [generic] | Credit the fix, not the owner. Say that whoever finds the problem keeps hold of it until it is solved, which is the published value. Do not claim a credit-sharing story you do not have. | Peer-style credit probe tied to Own the Fix. |

### P. Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Sixty seconds: why should we hire someone who has never worked in a contact centre?" | JD | [grounded] "Never worked in a contact centre" (your message) | Hold: the log, the supervisor years, and the plan to learn the contact-centre flow. Concede explicitly: "I haven't worked in one, and I would not pretend otherwise." Do not fold on what you did. | The time-boxed form of A1. Practise the hold-then-concede structure. |
| P2 | "That spreadsheet. How much of it was actually you?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." (your message) | Hold: "I built it." If the regional manager changed it, concede specifically what they changed, and say you built the first version and the monthly format. Do not fold on "built". | Attribution under pressure. Hold through two follow-ups. |

### Requirement coverage

| JD requirement | Question IDs | Fit row |
|---|---|---|
| Own the member complaints process end to end across branches and the contact centre | A1, C1, C2, P1 | F2, F8 |
| Report monthly on complaint volumes and resolution times | A4, D2, P2 | F4 |
| Coach branch supervisors on escalations | B2, C2 | F3 |
| Work with digital teams on self-service journeys | C3 | F9 (discovery) |
| 4+ years in financial-services customer operations | D1 | F1 |
| Experience handling regulated complaints | A2 | F6 |
| Confident presenting to senior leaders | A3, P1 | F7 |
| Comfortable with Excel reporting | D2 | F5 |
| The four published values | B1 to B5, E1, E2 | Values sheet below |
| Strategy: digital shift, hub consolidation, small-business lending | C3, C4, C5 | Grounding brief |

---

## 10. Values cheat sheet

Each value, what it means in working terms, and the story it maps to. Values are the company's published wording, copied on 11 November 2026.

| Value | Working meaning | Mapped story |
|---|---|---|
| Members First, Always: "we decide from the member's side of the counter." | Decide from the member's position, and say so out loud | No quoted sentence carries it. Selection scaffold, B3. If none comes to mind, say so and describe how you would decide. |
| Plain Words: "if a member needs it explained twice, we wrote it wrong." | A procedure or letter should land the first time | "trained new tellers on our escalation script" (your message), B2 and B5. Answer slot: what you did to make it clear. |
| Neighbours, Not Numbers: "every branch is part of its town." | A closure or merger is a change to a place, not only a line on a plan | No quoted sentence carries it. Reason from the value, B4, and say what you would protect. |
| Own the Fix: "whoever finds the problem keeps hold of it until it is solved." | Keep ownership until closure | "I handled the branch's formal complaints log" (your message), B1. Scaffold for the follow-through. |

---

## 11. Reverse questions

Each one has a reason it lands. Ask two or three in the room.

1. **"Which complaints would move into the five hubs in 2027, and who would own one that crosses a hub boundary?"** Why it lands: it shows you read the consolidation as a complaint-routing problem, which is the implication the strategy brief does not spell out.
2. **"How will the 40% digital target be measured, and will complaints raised through self-service count toward it?"** Why it lands: it links your role to the strategy's own metric and asks what the number includes.
3. **"How does the panel score the four values, and is the scoring written against each one?"** Why it lands: it signals you want the standard, and it lets you prepare for the panel's own scale.
4. **"What would a good first 90 days look like for the monthly reporting?"** Why it lands: it turns the JD's reporting line into a shared success measure.
5. **"Which complaint standards are set by regulation, and which does Ashgrove set itself?"** Why it lands: it names the regulated-complaints requirement directly and asks where the line sits, without assuming an answer.
6. **"Will the 20-minute case be a real escalation from the last quarter, or a written brief sent in advance?"** Why it lands: it shows you are preparing for the case format, and it may change how C1 and C2 are rehearsed.

---

## 12. Sources

Provided documents:
- Job description, pasted.
- Recruiter email on the process, pasted.
- Ashgrove values, copied from ashgrovecu.org/about/values on 11 November 2026, pasted.
- Strategy points from the 2026 strategy brief (July 2026), as summarised by the recruiter and pasted.
- Candidate background, in your message.

No searches or fetches were sent. The pasted inputs cover every target that research would have addressed.

**Research tier: L1, searches 0 of 6, fetches 0 of 2**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | Fixed by the pasted values page. Values sheet, section 10. |
| 2. Ashgrove interview process | skipped | The recruiter's email is a loop source. It names three sessions and who runs each. The panel's values scoring is also named there. |
| 3. Ashgrove strategy | skipped | The pasted strategy points, dated July 2026, are under six months old. They feed C3 to C5 and the grounding brief. |
| 4. Interviewer name | n/a | No names have been given for rounds 2 or 3. |
| 5. Representative JD | skipped | The JD you supplied fixes the fit snapshot and the requirement coverage. |

---

## Upgrade menu

- **Names of the Head of Member Services and the two branch managers** → an interviewer read, persona weights for each panel member, and reverse questions tied to their paths.
- **The full strategy brief** (you have four points) → C3 to C5 can cite exact segments and figures, and the grounding brief can be fuller.
- **Which timescales or written-response rules applied to the formal log** → F6 moves from transferability to a stated fact, and A2's answer slot can be answered with specifics.
- **A sanitised copy of the monthly spreadsheet** (no member data) → F4 and F5 confidence moves from medium to high.
- **Whether the 20-minute case is a live escalation or a written brief in advance** → C1 and C2 can be made specific to the case.
- **Whether the panel scores against a written rubric** → the values questions can be tuned to the rubric's wording.
- **A deeper research pass, if you want it:** up to 6 more searches and 2 more fetches, several minutes. It would cover the full strategy brief, recent organisational context, and loop reports for this role family.
