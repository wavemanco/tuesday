Your prep pack is saved at `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/haiku/alone/part-2/rooms/case-4-denied-ca44a943/quartzline_platform-apis-pm_interview_pack.md`. I built it from the dossier you pasted, since no `tuesday-dossier.md` is in the working folder.

Research didn't run. Web search was refused for this session, so the company values, interview process and strategy are not in the pack. Those sections are missing rather than guessed, and the Sources section records both refused searches.

The pack's centre is the objection the underwriter flagged: "why hire you into a roadmap role instead of a PM with three years of the job?" (A1). It opens with the plain acknowledgment that you haven't held the PM title or owned a roadmap. Then it moves to the integrations bridge, with its limit named, and a ramp plan. Rehearse that answer until it's boring.

The other things to rehearse:
- **Day-one gap (A2):** name roadmap ownership first, then agile delivery in a product org.
- **Roadmap-input sessions (A3):** expect "what did product actually do with what you brought?" Say what you brought, and that the decision was product's, if it was.
- **The 30+ figure (C1):** be ready to explain how you counted, what the count is sensitive to, and which integrations you led end to end. If you don't know how it was counted, say so.
- **Squad authority (B3):** don't claim authority over squad priorities. Describe how you'd get to a decision.

I wrote 16 questions, below the 18 floor I'd normally aim for. The dossier gives one round and no further material, so more questions would repeat the same evidence. A drill can cover the rest.

The pack lists six claims you must not make, including the three the dossier prohibits. Its date is 14 August, so if the posting has changed since then, send me the current one and I'll rebuild the fit snapshot.

Would you like a drill? I can play the Skeptic on A1, the highest-value question. I can also save a `tuesday-dossier.md` recording what this prep exposed, and convert the pack to Word if you want it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quartzline_platform-apis-pm_interview_pack.md -----
# Interview pack: Product Manager, Platform APIs at Quartzline

**Round:** hiring-manager conversation, 45 minutes, Thursday. Interviewer name not given, so no interviewer read.
**Built from:** the pasted underwriting dossier (dossier_version 1.1, generated 2026-08-14, decision conditional_go). Research did not run (see Sources).

## How to use this pack

- **Personas** are how a question arrives (friendly, skeptical, numbers-first, live problem). **Types** are what is being scored: JD (the stated requirement), EXP (what you actually did), CASE (a live problem), VAL (values; none detected here), CO (company knowledge; none researched).
- Guidance is scaffolding for a spoken answer, not a script. Say only what your quoted sentences say, in your own words.
- Answer slots (written as instructions) are honest branches: answer from your experience, or say plainly the thing was not yours.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" (dossier role_profile, R1, must_have) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier verified_candidate_evidence) | low | [inferred] | transferability | Your material shows client integration work, not product management time. Bridge, with its limit: "I led thirty-plus end-to-end client integrations of the vendor's REST APIs." Do not say you have product management years. |
| F2 | "Owning a roadmap and prioritization authority" (dossier role_profile, R1 sub-claim) | none given | none | [grounded] | capability | Plain acknowledgment, sourced to the dossier's acknowledge_gap area for this sub-claim: "I haven't owned a product roadmap or set prioritization for an engineering squad." Then a ramp plan, said as a plan and never as a past. |
| F3 | "Shipped API or platform products" (dossier role_profile, R2, must_have) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier verified_candidate_evidence) | high | [grounded] | transferability | The integrations went live for clients on the vendor's APIs; say that. The dossier does not grade R2, so this grading is the pack's derivation. Do not say you built or shipped a platform product. |
| F4 | "Technical fluency: API docs, schemas" (dossier role_profile, R3, important) | "Wrote the internal integration playbook her team uses" (dossier verified_candidate_evidence) | high | [grounded] | discovery | The playbook touches documentation but does not show whether it covered API docs or schemas. Answer slot: if you wrote or reviewed API docs or schemas for those integrations, say which; if the playbook covered only process, say so. |
| F5 | "Stakeholder management across engineering, sales, customers" (dossier role_profile, R4, important) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier verified_candidate_evidence) | medium | [grounded] | discovery | The quote reaches customers through UAT and go-live, and says nothing about engineering or sales. Confirmed, with limited inspectable proof, so expect a probe. Answer slot: name who you held a line with on one integration, and what each side wanted; if none of those groups were involved, say so. |
| F6 | "Agile delivery experience" (dossier role_profile, R5, preferred) | none given | low | [inferred] | discovery | Clarify, not bridge. Answer slot: if you have worked in sprints with an engineering team, say how; if your delivery model was different, say what you would want to confirm about theirs. |
| F7 | "Own the roadmap for the partner-facing API platform" (dossier role_profile, responsibility) | "Ran quarterly roadmap-input sessions feeding client evidence to product" (dossier verified_candidate_evidence, medium) | medium | [grounded] | transferability | Say that you ran sessions that brought client evidence to product. The limit: you supplied input; you did not own the roadmap. Expect a probe on what product did with it. |

Gap-type routing: no requirement here is a gate (no authorization, location, credential, or schedule term appears in the dossier), so no hard_gate row. Gap types for F3 to F6 are the pack's derivation from the quotes; the dossier grades only R1, R3 (through its uncertain-areas list) and R5, and R1's sub-claim.

## Prohibited claims

The pack will not coach any of these, in any answer, slot, reverse question, or drill feedback.

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | Dossier prohibited_claims | Plain acknowledgment: "I haven't held the product manager title." |
| Having owned a product roadmap | Dossier prohibited_claims | Plain acknowledgment: "I haven't owned a product roadmap." |
| Having set prioritization for an engineering squad | Dossier prohibited_claims | Plain acknowledgment: "I haven't set prioritization for an engineering squad." |
| Ran sessions, so product decisions were yours | Inflated form of F7, built locally | F7's quote at its own scope. The limit is the pack's observation, not words for you: your material says you ran sessions that brought evidence to product, not that product decided on your input. |
| Built or shipped a platform product | Inflated form of F3, built locally | F3's quote at its own scope: client integrations of the vendor's REST APIs. |
| Set the integration standard for the team | Inflated form of F4, built locally | F4's quote at its own scope: you wrote the playbook. The pack does not say it became the standard. |

## Persona weights

Relationship prior for a hiring manager: Case/Strategist and Skeptic. The dossier's named objection is a Skeptic item, so Skeptic leads. Data-Driven Prober rises because the 30+ figure and the adoption-metric gap are both numbers the interviewer can test. Conversational appears as the opener. No loop source established the loop, so the pack falls back to the generic archetype (flat weights, said plainly). No values round is detected.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (A) | The "why you, not a PM with three years" objection, and the day-one gap. Top weight | High. The dossier names this objection, and it targets the R1 gap | Plain acknowledgment, then the bridge with its limit named, then a ramp plan. Hold through two follow-ups |
| Case/Strategist (B) | Live problems on the actual role: adoption, partner discovery, squad disagreement | High. The JD's responsibilities are a case list, and the adoption baseline is unknown | Clarify, then objective, segmentation, approach, metrics, risks. Name the baseline you would need |
| Data-Driven Prober (C) | Denominators on the 30+ figure, usage of the playbook, timelines | Medium. The figure is headline, and the playbook's use is unmeasured | Name the figure's basis only if you know it; name the weakest assumption before they do; say so when you do not know |
| Conversational (D) | Journey question, a casual question about API docs, why now | Medium-low. A rapport opener is still scored | A pre-scripted 90-second arc. Treat the casual docs question as scored |

## Question banks

Question type is one token per row. Dual-tag rationale appears in the rationale cell.

### A. Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have never held the PM title or owned a roadmap. Why should we hire you into that role instead of a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; [grounded] dossier acknowledge_gap area for the R1 sub-claim | Open with the plain acknowledgment: "I haven't held the product manager title or owned a roadmap." Then the bridge, limit named: "I led thirty-plus end-to-end client integrations of the vendor's REST APIs, from scoping through go-live." Then a ramp plan, said as a plan: which roadmap decisions you would learn first and from whom. Hold through two follow-ups by returning to the integrations, never by adding to them. Do not argue that the title does not matter. | Highest-ROI prep, named by the underwriter. F1 and F2 are the rows it draws on. JD type because it scores R1. The premise (no PM title, no roadmap) comes from the dossier's prohibited list, and the three years come from the JD's R1 line |
| A2 | "What would you be weakest at on day one in this role?" | JD | [grounded] dossier acknowledge_gap area for the R1 sub-claim; [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Name roadmap ownership and prioritization authority first, with the plain acknowledgment from A1. Second, agile delivery inside a product org: answer slot. If you have worked in sprints with an engineering team, say how; if your delivery model was different, say what you would want to confirm about theirs. Keep it to two items | F2 and F6. Covers R5 under clarify. Shows calibrated candor, which this interviewer is scoring |
| A3 | "You ran roadmap-input sessions. What did product do with the evidence you brought?" | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Story-mapped on F7: you ran quarterly sessions and brought client evidence to product. Answer slot: if product changed a decision because of your input, say which and what you did; if product decided on its own terms, say so plainly and describe what you brought. Confirmed at medium confidence, so this is the probe to expect | F7 is the adjacent bridge to the roadmap responsibility. It is medium-confidence, so the caveat is volunteered before it is extracted |
| A4 | "Have you shipped an API or platform product? What did you ship?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Answer from F3 only. Say that the integrations went live for clients on the vendor's APIs. If the question means a product you built and owned, say you have not; do not stretch the integrations into a platform | F3 is a transferability gap on R2. Asked as a plain question, so the answer can be a plain no |
| A5 | "Tell me about a time a client, sales, and engineering wanted different things from one integration." | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Open prompt, so pick one integration you can describe end to end. Story-mapped on F5: the scoping, requirements, and UAT beats are the quote's own. Answer slot: name what each group wanted and how the conflict ended, in your own words. If engineering or sales were not involved, say so and stay with the client's side | F5 is medium confidence on R4, and the JD's stakeholder line is the raising source. An open prompt cannot supply the event, so the slot is the honest form |

### B. Case/Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Partner API adoption dropped after the second version. Walk me through how you would diagnose it." | CASE | [generic] | Clarify first: which partners, which endpoints, what counts as adoption. Then objective, segmentation (by partner size and integration age), approach, metrics you would need, and risks. Say the baseline is the first thing you would check, since you do not have one | A live problem from the adoption-metrics responsibility. Scores structure, so think aloud. No claim about your past |
| B2 | "What adoption target would you set for year one, given no baseline yet?" | CASE | [generic] | Say you would not set a number before a baseline. Propose how you would build one in the first month, then a target range with a stated assumption. Do not name a figure | Probes the unknown the dossier flagged: no current baseline. Answering "I would measure first" is the honest answer |
| B3 | "Two squad leads disagree on the sequence of the next release. Who decides, and what do you do?" | JD | [grounded] "Write specs and drive delivery with two engineering squads" (dossier role_profile responsibility) | Clarify who owns the decision and what escalation looks like. Propose a process: bring the trade-off to both leads with the partner evidence, and name what you would escalate. Do not claim the decision was yours; you have not held that authority | The squad-authority question is the employer's unknown. This is where the pack must not imply authority over squad priorities |
| B4 | "A partner wants a breaking change to an endpoint. How do you decide between a versioning break and a deprecation window?" | CASE | [generic] | Structure: who is affected, what the cost is for each partner group, what the window needs to be, and what you would need to know first. Name one trade-off you would defend and one you would concede | A platform-specific live problem. Generic, so it carries no claim about your history |
| B5 | "A partner asks for an endpoint three other partners don't need. How do you run discovery on it?" | JD | [grounded] "Run discovery with integration partners" (dossier role_profile responsibility) | Story-mapped on F7 only if you ran discovery with partners; otherwise say how you would run it: what you would ask, who you would talk to, and what would change your mind. Answer slot: if you ran partner discovery with client evidence, say what you asked and what it changed; if you did not, say so and give your approach | Covers the discovery responsibility, which no quote carries directly. The answer slot keeps the claim at F7's scope |

### C. Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "How did you arrive at thirty-plus integrations? Walk me through how you counted them." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Answer slot: say how you counted them, in your own words, and what the count is sensitive to. Name the assumption behind it you would defend least, before they ask. Say which of the integrations were yours to lead end to end. If you do not know how it was counted, say so plainly | Every headline figure gets a defend-the-number probe. The four slots are the coverage rule's: basis, sensitivity, weakest assumption, which part was yours. No basis is in the dossier, so none is supplied here |
| C2 | "How do you know your team still uses the playbook you wrote?" | EXP | [grounded] "Wrote the internal integration playbook her team uses" | Answer slot: if you have a way to see use, say what it is; if you do not, say you do not know how often it is used, and that you would measure it first | A probe on whether the playbook's use is measured, which mirrors the adoption-metric unknown. F4 is discovery, so the honest "I don't know" is an answer |
| C3 | "Which integration took longest from scoping to go-live, and where did the time go?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Pick one integration you led end to end and walk the stages. Answer slot: where the time went, if you know; if you do not have that detail, say which stage you would look at first. Do not give a timeline you cannot defend | A timeline probe is the fastest way to find an invented number. The quote's stages are the beats |

### D. Conversational (weight 2 to 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey from integrations to this role." | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; [grounded] "Wrote the internal integration playbook her team uses" | A 90-second arc, in order: the integrations, the playbook, the roadmap-input sessions (as input, F7). Then the acknowledgment and the bridge. Say what you want from this role in your own words | An opener scored on communication economy. The arc is built from quotes only |
| D2 | "What are you actually doing with API docs these days?" | JD | [grounded] "Wrote the internal integration playbook her team uses" | Answer slot: say what you do with API docs now, if anything. If your current work does not touch them, say so and say what you would bring | Casual register on a JD topic (R3). F4 is discovery, so the honest answer is either branch |
| D3 | "Why this role, and why now?" | JD | [generic] | Say what draws you to the platform-API problem, in your own words. The pack does not supply a motivation, because your material does not state one. Keep it to what you would say to a colleague | The motivation probe the Skeptic persona also uses. Generic, so it carries no claim |

## Requirement coverage

| Requirement | Questions |
|---|---|
| R1, 3+ years product management | A1, A2, D1 |
| R1 sub-claim, roadmap and prioritization | A1, A2, A3 |
| R2, shipped API or platform products | A4 |
| R3, API docs and schemas | C2, D2 |
| R4, stakeholder management | A5 |
| R5, agile delivery | A2 |
| Responsibility: own the roadmap | A3, B3 |
| Responsibility: run discovery with partners | B5 |
| Responsibility: adoption metrics | B1, B2, C2 |
| Responsibility: specs and delivery with two squads | B3 |

Session total: 16 questions. This is below the usual 18 floor. The reason is that the dossier gives one round and no further material, so more questions would repeat the same evidence rather than cover new ground. A drill can add the rest.

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R-1 | "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" | It tests the decision-authority risk the JD asserts and the dossier could not evidence. The answer tells you what you are taking on before you accept |
| R-2 | "How is partner API adoption measured today, and what is the current baseline?" | It is the dossier's unresolved adoption-metric risk. A reply of "none yet" is itself the finding |
| R-3 | "What would make this hire a success at six months?" | Asked as diligence, it lets the hiring manager state the scope in their own terms, and tells you what the first review will check |
| R-4 | "What did the last person in this scope learn that the job description does not say?" | It surfaces the hidden parts of the role. Generic, so it carries no claim about this employer |
| R-5 | "How do the two squads plan together, and where does the platform team's work meet partner requests?" | It tests the squad-coordination responsibility from the JD in terms of how work actually flows. Generic |

No peer or interviewer-profile reverse question is included, because neither applies.

## Sources

**Provided documents.** The pasted `tuesday-dossier.md` (dossier_version 1.1, generated 2026-08-14, decision conditional_go). Consumed sections: `role_profile` (requirements R1 to R5, responsibilities, unknowns) and `handoff_to_mock_interview` (verified_candidate_evidence, uncertain_or_weak_areas, likely_interviewer_objections, opportunity_risks_to_validate, questions_for_employer, prohibited_claims). Not present in the dossier: `evidence_map`, `evidence_state`, `risk_register`. The dossier is from 14 August. Its JD and evidence are taken as current unless the posting has changed.

**Searches attempted.**
- "Quartzline company values operating principles": refused (host permission not granted).
- "Quartzline interview process Product Manager Platform APIs": refused (host permission not granted).

**Research tier: L0.** Two L1 searches were attempted and refused; no results were returned and no pages were fetched.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quartzline values | unavailable | The values cheat sheet, section 10. Dropped, since no values source is in hand |
| 2. Quartzline interview process, Product Manager | unavailable | Loop structure and persona weights. Fallback archetype used: generic, flat weights |
| 3. Quartzline strategy or recent news | unavailable | The CO bank. Not written, so no company-specific CO or CASE questions appear |
| 4. Interviewer name and company | n/a | No name was given, so there is no query to form |
| 5. Representative JD | skipped | The dossier's role_profile fixes the JD |

Sections dropped for this run: prep triage (no prep time stated), graded deliverables (none declared), grounding brief (no research), values cheat sheet (no values source and no values round detected), interviewer read (no name), delivery coaching (no assessment).

**Persona weights** rest on the hiring-manager prior and the dossier's named objection, not on this company's documented loop. No loop source was available.

## Upgrade menu

- The recruiter's note on the round format, such as whether there is a pre-read or an exercise → persona weights for any deliverable, and whether a case is coming.
- The interviewer's name → an interviewer read, and a reverse question tied to their own path.
- The current posting, if it has changed since 14 August → the fit snapshot and JD-tagged questions are rebuilt against it.
- Search permission for research → the values, interview-process, and strategy targets, which would add the company values cheat sheet, a loop-based persona weighting, and current-strategy CO questions. Deeper research is an option after that, with its own caps.
- Your playbook, or a list of the thirty-plus integrations with dates → the C1 to C3 slots can be answered from quotes, and F4 and F5 can be upgraded from discovery when the material shows reach.
