I'll load the skill's reference files and run the default research pass in parallel.
Web search was not granted, so I can't pull Stripe's values, loop or strategy. The pack below is built only from your request, and every item is labeled `[generic]`.
Your prep pack is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-alone-part-2-rooms-case-3-denied-febe2ffc/65b9396b-6168-448b-ac17-93fd823690c0/scratchpad/stripe_product-operations-manager_interview_pack.md`. It is built only from your request. Web search wasn't granted, so nothing in it is Stripe-specific yet, and every item is labeled `[generic]`.

# Stripe: Product Operations Manager, final-round prep pack

**Built on:** final round, interviewer and relationship unknown, no job description, no CV, no research. Flat persona weights.

## How to use
- **Personas** describe how a question is asked. **Types** describe what is scored.
- Type tags: **VAL** behavioral/values, **EXP** your past work tested under follow-up, **JD** role requirements, **CO** company knowledge, **CASE** a live problem.
- Guidance is scaffolding, not a script. Answer in your own words and only with what you actually did.

## Fit snapshot (worksheet variant)
No JD, CV or candidate sentence has been supplied, so every evidence cell is `none given`.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Owning a cross-functional process end to end (role-family pattern) | none given | none | [generic] | discovery | Strong evidence is one process you designed or ran that other teams relied on, with what it changed. Selection scaffold: pick one and say which parts were yours. If you have none, say so and give the nearest one. |
| F2 | Using metrics to make decisions (role-family pattern) | none given | none | [generic] | discovery | Strong evidence is one number you used to decide, how it was counted, and the decision it changed. |
| F3 | Working with senior leaders and pushing back on priorities (role-family pattern) | none given | none | [generic] | discovery | Strong evidence is one time you disagreed with someone senior, the stake, what you did, and how it ended. Selection scaffold with an honest branch. |
| F4 | Sequencing work when requests outrun capacity (role-family pattern) | none given | none | [generic] | discovery | Strong evidence is one time you said no or reordered work, and what you gave up. |
| F5 | Working with data tools and dashboards (role-family pattern) | none given | none | [generic] | discovery | Strong evidence is a dashboard or workflow tool you built or changed and the decision it fed. Name the tool only if you have used it. |

Gate rows: none yet. If the posting lists location, work authorization or schedule terms, those become hard-gate rows.

## Prohibited list
No entries yet. The list is built from your own sentences, and none have been given. Standing limit: no metric, scope, title or outcome is coached unless you have said it in your own words.

## Persona table
Flat weights, because the relationship, interviewer and loop are unknown. No source establishes the loop, so no values round is assumed. Three questions per persona, 21 in total.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Data-Driven Prober | Asks how a number was counted, then goes two levels deeper | Flat. Any final may include a metric discussion | Know how each figure was counted; name its weakest assumption first |
| Pressure / Stress | Interrupts, time-boxes, questions your part in results | Flat. Interviewer style unknown | Pause, restate, hold through two follow-ups, concede one specific point |
| Values / Behavioral | Open prompts for specific past decisions | Flat. No values round detected | Pick a real decision, state the stake, say what you did and gave up |
| Case / Strategist | A live problem to diagnose or plan | Flat. Common in product and ops finals | Clarify, structure, segment, propose; think aloud |
| Skeptic | Asks your weakest area and why you're moving | Flat. Common in finals | Name one honest gap and a 30-day ramp; no bluffing |
| Conversational / Rapport | Casual openers that are still scored | Flat | Have a 90-second arc |
| Peer Evaluator | Seams between teams, credit, disagreement | Flat. Relevant if the interviewer sits beside you | Propose seam principles; offer reciprocity |

## Question banks

### Data-Driven Prober (EXP)
| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through a number you've used to make a decision. How was it counted?" | EXP | [generic] | Pick one figure. Say what it counts, where the data came from, and which part was yours to set. Answer slot: if you set how it was counted, say how; if not, say so plainly and say who did. Don't explain a method you can't repeat under a second question. | Prober stem. Probes F2. |
| A2 | "Which assumption behind that number would you defend least?" | EXP | [generic] | Name the weakest assumption before they do, then say what you would check. If you don't know how it was counted, say so. | Weakest-assumption move. Probes F2. |
| A3 | "What did you decide not to measure, and why?" | EXP | [generic] | Pick a metric you dropped and give the reason you could defend if asked again. | Tests judgment. Probes F2 and F4. |

### Pressure / Stress (EXP)
| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Sixty seconds: why should we hire you over a candidate with more direct experience?" | JD | [generic] | Pause, restate, anchor on the one thing you can show. Don't disparage the other candidate. | Stress stem. Likely ground: F1, F3. |
| B2 | "That result. How much of it was actually you?" | EXP | [generic] | **Highest-ROI prep in this pack.** Name the result. Say what you did personally and what the team did, then stop. Hold through two follow-ups by keeping your part and naming the team's. Concede one specific point, never the core claim. | Attribution probe, asked cold to nearly every candidate with a shared result. Build the answer from your own result. |
| B3 | "You've described the team's work. What did you personally decide?" | EXP | [generic] | Follow-up to B2. One decision in the first person, its stake, and what you would do differently. If you made no decision there, say so and describe your contribution. | Second-level follow-up for hold-then-concede. |

### Values / Behavioral (VAL)
| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you put a user's outcome ahead of an internal number someone was tracking." | VAL | [generic] | Selection scaffold: pick a time you chose the user's outcome over a tracked metric. Name the stake and the cost. If none comes to mind, say so plainly, then give the nearest thing you have. | Open prompt. No values read, so the theme comes from the persona stem. |
| C2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time the news was bad. Say what you said, how it landed, what happened next. Honest branch if none. | Tests candor under hierarchy. |
| C3 | "Tell me about a decision you made on incomplete information. How did you handle it once you had more?" | VAL | [generic] | Selection scaffold: pick a decision you'd now make differently. What you knew, what you did when you learned more. Honest branch if none. | Tests judgment and recovery. |

### Case / Strategist (CASE)
| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "A conversion rate on a key funnel dropped 15% week over week. Walk me through how you'd diagnose it." | CASE | [generic] | Clarify the metric and time window. Segment before proposing causes. One metric per hypothesis; test the largest first. Name risks: data lag, seasonality, a recent launch. | Scores structure, not the answer. |
| D2 | "You have to roll out a new review process to 40 teams in a quarter. What do you need to know first?" | CASE | [generic] | Clarify the goal, definition of done, who is affected, current process and constraints before designing. Then phases, stakeholders, metrics, risks. | Tests clarify-before-structure. |
| D3 | "You have three requests and capacity for one. How do you decide, and how do you say no?" | CASE | [generic] | Criteria first (impact, urgency, reversibility, who asks). Say how you'd score them, then what you'd tell the two you declined. | Prioritization and saying no. Probes F4. |

### Skeptic (JD)
| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Which part of this job would you be weakest at on day one?" | JD | [generic] | Name one specific gap and how you'd close it in 30 days. Don't claim there's no gap. Answer slot: if you know a gap, name it; if not, say what you'd learn first. | Most common skeptic probe. Probes F1 to F5. |
| E2 | "Why leave where you are, and why now?" | JD | [generic] | The reason, in the positive, in your words. No criticism of your employer. Connect it to this role's scope. | Motivation check. |
| E3 | "What would make this a bad hire after six months?" | JD | [generic] | Name the failure mode you'd watch for, for example a process nobody adopts, and how you'd prevent it. | Self-awareness. |

### Conversational / Rapport (JD and CO)
| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | JD | [generic] | 90-second arc: start, turning points, now, why this role. Nothing you wouldn't say to a colleague who knows you. | Opener that is still scored. |
| F2 | "What's a process or product you use that you think is well designed?" | CO | [generic] | One you know well, with two specifics for why it works. | Tests product sense without research claims. |
| F3 | "Where does operations work at a company like this most often go wrong?" | CO | [generic] | One or two common failure modes, marked as your view, and how you'd prevent one. | Tests altitude. Generic without research. |

### Peer Evaluator (JD and VAL)
| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Our teams sit side by side. Where's the seam, and what happens when we disagree?" | JD | [generic] | Propose principles for the seam, such as who owns intake and who sets priority. Then how you'd handle disagreement with an equal. | Peer seam probe. |
| G2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Name the credit you'd give other teams and the credit you'd take. How you'd check it with them. | Partnership fit. |
| G3 | "What would you need from my team to do this job well?" | JD | [generic] | Concrete asks: a named owner, data access, a standing review. Then what you'd bring to their team. | Reciprocity. |

## Reverse questions
| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a strong first 90 days look like in this role?" | Shows you plan, and gives you a standard to measure against. |
| R2 | "How is success for this role measured in year one?" | Shows you think in outcomes, not tasks. |
| R3 | "Where does the team's process break down most often today?" | Invites a candid answer; shows you think of operations as a system. |
| R4 | "How do Product Ops and the product and finance teams work together day to day?" | Shows you're looking at the seams. |
| R5 | "What could a new person do in their first month that would genuinely help your team?" | Reciprocity. Best if the interviewer is a peer. |

No interviewer profile exists, so no reverse question is tied to their career path.

## Coverage
No JD was supplied, so no requirement table can be filled yet.

## Sources
- Provided documents: your request only.
- Searches: "Stripe Product Operations Manager role interview process values" (refused). "Stripe company values … interview" (refused). The second query included value names from memory, not from a source; nothing from it is used.
- Fetches: none.

**Research tier: L0.** Searches 0 of 6, fetches 0 of 2.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Stripe values | unavailable | Values cheat sheet, not built. No values round detected |
| 2. Stripe interview process, product operations | unavailable | Loop structure. Persona weights stay flat |
| 3. Stripe strategy / recent news | unavailable | CO bank would have grounded in current priorities |
| 4. Interviewer name + Stripe | n/a | No interviewer name given |
| 5. Representative JD | unavailable | Fit snapshot would have quoted requirements |

## Upgrade menu
- **JD text:** worksheet rows become quoted rows, the coverage table fills, and JD questions become grounded.
- **Your CV, or three examples with the figures you'd defend:** the fit snapshot gets quoted evidence, and B2 and the EXP questions get your actual results.
- **Who you're meeting and their role:** persona weights and reverse questions get tailored.
- **Stripe's values page, pasted:** C1 to C3 and G2 get checked against published values.
- **The recruiter's prep email:** any declared exercise gets a build section, and the loop structure firms up.
- **Permission for web search:** the default pass (up to 6 searches, 2 page fetches) on values, interview process and recent strategy.
- **A deeper pass, once:** strategy brief, interviewer footprint and loop reports; up to 6 more searches and 2 more fetches, several extra minutes. Say if you want it later.

---

Two offers, neither pushed:
- I can run a live drill: I play the Pressure interviewer on B2, the highest-ROI prep here, with follow-ups that react to what you say.
- I can save a `tuesday-dossier.md` recording the gaps this prep exposed, to carry into later sessions.

I can also convert the pack to Word once you've finished iterating on it.

Two questions, which would change the pack the most:
1. Who are you meeting, and what is their role relative to yours: hiring manager, peer, skip-level, or someone from another function? Is the final one session or several back-to-back?
2. Can you paste the job description and your CV? If not, we proceed as is, and the pack stays generic.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: stripe_product-operations-manager_interview_pack.md -----
# Stripe: Product Operations Manager, final-round prep pack

Built on: final round, interviewer and relationship unknown, no job description, no CV, no research (web search not granted). Flat persona weights. Every item is `[generic]`.

## How to use

- **Personas** describe how a question is asked. **Types** describe what is scored.
- Type tags: **VAL** behavioral/values, **EXP** your past work tested under follow-up, **JD** role requirements, **CO** company knowledge, **CASE** a live problem.
- Guidance is scaffolding, not a script. Answer in your own words and only with what you actually did.

## Fit snapshot (worksheet variant)

No JD, CV or candidate sentence has been supplied, so every evidence cell is `none given`. The requirements below are role-family patterns, not quotes.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Owning a cross-functional process end to end (role-family pattern) | none given | none | [generic] | discovery | Strong evidence is one process you designed or ran that other teams relied on, with what it changed. Selection scaffold: pick one such process and say which parts were yours. If you have none, say so and give the nearest one. |
| F2 | Using metrics to make decisions (role-family pattern) | none given | none | [generic] | discovery | Strong evidence is one number you used to decide, how it was counted, and the decision it changed. Selection scaffold: pick one number and be ready to say how it was counted. |
| F3 | Working with senior leaders and pushing back on priorities (role-family pattern) | none given | none | [generic] | discovery | Strong evidence is one time you disagreed with someone senior, the stake, what you did, and how the relationship stood after. Selection scaffold, ending in an honest branch if none comes to mind. |
| F4 | Sequencing work when requests outrun capacity (role-family pattern) | none given | none | [generic] | discovery | Strong evidence is one time you said no or reordered work, and what you gave up. Selection scaffold, ending in an honest branch if none comes to mind. |
| F5 | Working with data tools and dashboards (role-family pattern) | none given | none | [generic] | discovery | Strong evidence is a dashboard or workflow tool you built or changed and what decision it fed. Selection scaffold; name the tool only if you have used it. |

Gate rows: none yet. If the posting lists location, work authorization or schedule terms, those become hard-gate rows and are surfaced, not bridged.

## Prohibited list

No entries. The list is built from your own sentences, and none have been given yet. Standing limit for this pack: no metric, scope, title or outcome is coached unless you have said it in your own words. This section fills in when your CV or examples arrive.

## Persona table

Flat weights, because the relationship, the interviewer and the loop are all unknown. No source establishes the loop, so no values round is assumed. Three questions per persona, 21 in total.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Data-Driven Prober | Asks how a number was counted, then goes two levels deeper | Flat weight. Any final may include a metric discussion | Know how each figure you bring was counted; name its weakest assumption first |
| Pressure / Stress | Interrupts, time-boxes, questions your part in results | Flat weight. Unknown interviewer style | Pause, restate, hold through two follow-ups, concede one specific point |
| Values / Behavioral | Open prompts asking for specific past decisions | Flat weight. No values round detected | Pick a real decision, state the stake, say what you did and what you gave up |
| Case / Strategist | A live problem to diagnose or plan | Flat weight. Common in product and ops finals | Clarify, then structure, then segment, then propose; think aloud |
| Skeptic | Asks for your weakest area and your reason for moving | Flat weight. Common in finals | Name one honest gap and a 30-day ramp; no bluffing |
| Conversational / Rapport | Casual openers that are still scored | Flat weight. Any interviewer may open this way | Have a 90-second arc; treat casual questions as scored |
| Peer Evaluator | Seams between teams, credit, disagreement | Flat weight. Relevant if the interviewer sits beside you | Propose seam principles; offer reciprocity |

## Question banks

### Data-Driven Prober (EXP)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through a number you've used to make a decision. How was it counted?" | EXP | [generic] | Pick one figure you have used. Say what it counts, where the data came from, and which part was yours to set. Answer slot: if you set how it was counted, say how; if you did not, say so plainly and say who did. Do not explain a method you cannot repeat under a second question. | Prober stem. Probes F2. EXP because it tests what was yours. |
| A2 | "Which assumption behind that number would you defend least?" | EXP | [generic] | Name the weakest assumption before they do, in your own words, then say what you would check to test it. If you don't know how it was counted, say so. | Weakest-assumption move for any figure. Probes F2. |
| A3 | "What did you decide not to measure, and why?" | EXP | [generic] | Pick a metric you dropped or deprioritized and give the reason in your own words. Use a reason you can defend if asked again. | Tests judgment, not counting. Probes F2 and F4. |

### Pressure / Stress (EXP)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Sixty seconds: why should we hire you over a candidate with more direct experience?" | JD | [generic] | Pause, restate the question, and anchor on the one thing you can show. Do not disparage the other candidate. | Stress stem. The likely ground is F1 and F3. |
| B2 | "That result. How much of it was actually you?" | EXP | [generic] | **Highest-ROI prep in this pack.** Name the result you will bring. Say what you did personally and what the team did, then stop. Hold through two follow-ups by keeping your part and naming the team's part. Concede one specific point, never the core claim. | Attribution probe, asked cold to almost every candidate with a shared result. Most likely objection here, and the answer has to be built from your own result. |
| B3 | "You've described the team's work. What did you personally decide?" | EXP | [generic] | Follow-up to B2. Answer with one decision in the first person, its stake, and what you would do differently. If you made no decision in that work, say so and describe your contribution. | Second-level follow-up for hold-then-concede. |

### Values / Behavioral (VAL)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you put a user's outcome ahead of an internal number someone was tracking." | VAL | [generic] | Selection scaffold: pick a time you chose the user's outcome over a tracked metric. Name the stake and what you gave up. If no such time comes to mind, say so plainly, then give the nearest thing you have, or how you would handle it. | Open prompt. No published values were read, so the theme comes from the persona stem. |
| C2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time the news was bad. Say what you said, how it landed, and what happened next. If none comes to mind, say so plainly, then give the nearest thing you have. | Open prompt. Tests candor under hierarchy. |
| C3 | "Tell me about a decision you made on incomplete information. How did you handle it once you had more?" | VAL | [generic] | Selection scaffold: pick a decision you would now make differently. Say what you knew then, and what you did when you learned more. If none comes to mind, say so plainly, then give the nearest thing you have. | Open prompt. Tests judgment and recovery. |

### Case / Strategist (CASE)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "A conversion rate on a key funnel dropped 15% week over week. Walk me through how you'd diagnose it." | CASE | [generic] | Clarify the metric definition and the time window. Segment (by channel, device, region, cohort) before proposing causes. Give one metric per hypothesis, test the largest first, and name risks: data lag, seasonality, a recent launch. Think aloud. | Classic live diagnosis. Scores structure, not the answer. |
| D2 | "You have to roll out a new review process to 40 teams in a quarter. What do you need to know first?" | CASE | [generic] | Clarify the goal, the definition of done, who is affected, the current process, and the constraints before designing anything. Then lay out phases, stakeholders, metrics and risks. | Tests whether you clarify before you structure. |
| D3 | "You have three requests and capacity for one. How do you decide, and how do you say no?" | CASE | [generic] | State criteria first (impact, urgency, reversibility, who is asking). Say how you would score them, then what you would tell the two you declined and when. | Tests prioritization and saying no, both central to ops work. Probes F4. |

### Skeptic (JD)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Which part of this job would you be weakest at on day one?" | JD | [generic] | Name one specific gap honestly, and how you would close it in 30 days. Do not claim there is no gap. Answer slot: if you know of a gap, name it; if you don't yet, say what you would learn first. | Most common skeptic probe. Probes F1 to F5. |
| E2 | "Why leave where you are, and why now?" | JD | [generic] | Give the reason in the positive, in your own words. No criticism of your current employer. Connect it to this role's scope. | Motivation check. |
| E3 | "What would make this a bad hire after six months?" | JD | [generic] | Name the failure mode you would most watch for, for example a process built that nobody adopts, and what you would do to prevent it. | Tests self-awareness. |

### Conversational / Rapport (JD and CO)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | JD | [generic] | Have a 90-second arc: where you started, the turning points, what you do now, and why this role. Build it from your own path. Include nothing you would not say to a colleague who knows you. | Opener that is still scored. |
| F2 | "What's a process or product you use that you think is well designed?" | CO | [generic] | Pick one you know well and give two specifics for why it works. This shows you know the work without claiming research about Stripe. | Casual, but tests product sense. |
| F3 | "Where does operations work at a company like this most often go wrong?" | CO | [generic] | Give one or two common failure modes, marked as your view. Name how you would prevent one. | Tests altitude. Without research, the answer stays generic. |

### Peer Evaluator (JD and VAL)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Our teams sit side by side. Where's the seam, and what happens when we disagree?" | JD | [generic] | Propose principles for the seam, such as who owns intake and who sets priority, rather than pretending to know it. Then say how you would handle disagreement with an equal. | Peer seam probe. |
| G2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Name the credit you would give other teams and the credit you would take. Say how you would check it with them. | Tests partnership fit. |
| G3 | "What would you need from my team to do this job well?" | JD | [generic] | Name concrete asks: a named owner, data access, a standing review. Then say what you would bring to their team. | Reciprocity framing. |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a strong first 90 days look like in this role?" | Shows you plan, and gives you a standard to measure against. |
| R2 | "How is success for this role measured in year one?" | Shows you think in outcomes, not tasks. |
| R3 | "Where does the team's process break down most often today?" | Invites a candid answer and shows you think of operations as a system. |
| R4 | "How do Product Ops and the product and finance teams work together day to day?" | Shows you are looking at the seams, not just the job description. |
| R5 | "What could a new person do in their first month that would genuinely help your team?" | Reciprocity. Works best if the interviewer is a peer. |

No interviewer profile exists, so no reverse question is tied to their career path.

## Coverage

No JD was supplied, so no requirement table can be filled. This section fills in when the JD is pasted.

## Sources

- Provided documents: your request only.
- Searches sent: "Stripe Product Operations Manager role interview process values" (refused). "Stripe company values … interview" (refused). The second query included value names from memory, not from a source, and nothing from it is used.
- Fetches: none.

Research tier: L0. Searches 0 of 6 (both sent, both refused). Fetches 0 of 2.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Stripe values` | unavailable | Values cheat sheet, not built. No values round detected |
| 2. `Stripe interview process, product operations` | unavailable | Loop structure. Persona weights stay flat |
| 3. `Stripe strategy / recent news` | unavailable | CO bank would have grounded in current priorities. Currently generic |
| 4. `{interviewer name} Stripe` | n/a | No interviewer name given |
| 5. Representative Product Operations Manager JD | unavailable | Fit snapshot would have quoted requirements. No JD supplied |

## Upgrade menu

- **JD text:** worksheet rows become quoted rows, the coverage table fills in, and the `[generic]` JD questions become grounded.
- **Your CV, or three examples with the figures you would defend:** the fit snapshot gets quoted evidence, EXP questions and B2 get your actual result, and the rehearsal stops being generic.
- **Who you are meeting and their role:** persona weights and reverse questions get tailored.
- **Stripe's values page, pasted:** the values questions (C1 to C3, G2) get checked against published values.
- **The recruiter's prep email:** any declared exercise gets a build section, and the loop structure firms up.
- **Permission for web search:** the default research pass (up to 6 searches, 2 page fetches) on values, interview process and recent strategy.
- **A deeper pass, once:** strategy brief, interviewer footprint and loop reports, up to 6 more searches and 2 more fetches, several extra minutes. Say if you want it later.
