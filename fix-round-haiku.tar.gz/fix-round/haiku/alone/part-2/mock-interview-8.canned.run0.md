Your prep pack is saved at /tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-alone-part-2-rooms-case-8-canned-6227481e/6f0a3f89-9b6d-496b-87ed-14dfe6c69206/scratchpad/ashgrove_member_experience_lead_interview_pack.md, and I've attached it here. I built it as three rounds, since the recruiter's email gave the schedule. It has 21 questions, a fit snapshot of your background against each JD requirement, a values cheat sheet, and a strategy brief to use in the panel round.

Three things to know before you read it:

- **Your highest-value prep is B1.** The Head of Member Services will likely ask what you'd be weakest at on day one. The honest answer names the two gaps you told me about: no contact-centre work, and nothing presented above regional level. The pack gives you the words for each, then a ramp plan you can say as a plan rather than a past.
- **The values round has no ready-made stories.** Your material doesn't carry a specific story for any of the four values, so the cheat sheet gives you selection prompts with an honest "if none comes to mind" branch. Choose your own examples, and say so plainly when you don't have one.
- **Some answers depend on what you tell me.** Your spreadsheet is the strongest thing you have for the reporting requirements. I can't tell from your message whether it tracked volumes, resolution times, or both, so F5 and B3 are open until you say.

Nothing here is verified against the web. I used only what you pasted: the JD, the values text you copied, the recruiter's email, and the strategy brief. I didn't fetch Ashgrove's values page myself.

Two offers, neither pushed:
- Say the word and I'll play the Head of Member Services on B1 and give you feedback against the pack's guidance for it.
- I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.

If you'd like the pack as a Word document, say so and I'll convert it.

What did the monthly complaints spreadsheet track: volumes, resolution times, or both? That one answer moves F5, F6, B3 and C7.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove_member_experience_lead_interview_pack.md -----
# Ashgrove Credit Union: Member Experience Lead interview pack

- **Role:** Member Experience Lead
- **Company:** Ashgrove Credit Union
- **Candidate:** Dara (they/them)
- **Rounds, 20 November 2026 (loop mode):** (1) recruiter, 30 min; (2) Head of Member Services, your future manager, 45 min, mostly behavioural; (3) panel of two branch managers, 60 min, including a 20-minute complaint-escalation case. The panel also scores against the four values.
- **Interviewer names:** not given. The bank is built on roles only.
- **Version:** first version. Nothing to change yet.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored:

- **VAL**: behaviour that shows a published value
- **EXP**: your own experience, checked for precision
- **JD**: a requirement from the listed job
- **CO**: company and strategy knowledge
- **CASE**: a live problem to structure out loud

Guidance is scaffolding, not a script. Say things in your own words. Provenance labels: `[grounded]` means your own sentence or a document you gave me; `[inferred]` means my derivation, named where it appears; `[generic]` means a role pattern with no claim about you or Ashgrove.

## Fit snapshot

Requirements are quoted from the JD you supplied. Evidence is quoted from your message. Nothing is added to either.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" (JD) | "6 years in retail banking, the last 3 as a branch supervisor" (your message) | medium | [grounded] | none | The quote clears the four-year line on its face. Say it in your words: "six years in retail banking, the last three as a branch supervisor." Expect a probe on whether branch work counts as customer operations. Your material does not show a contact-centre operation. |
| F2 | "experience handling regulated complaints" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | presentation | Your material says formal complaints, not regulated ones, and the words stay there: "I handled the branch's formal complaints log." Answer slot: if the log carried regulatory response deadlines or an external referral route, say which and how you tracked them, in your own words. If it did not, say so plainly and describe the log as it was. |
| F3 | "Own the member complaints process end to end across branches and the contact centre" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | transferability | The quote is branch-level. It does not show the process end to end, nor across branches. Bridge: "For the branch's log, I handled the complaints in it." Answer slot: if you owned any step past the log, such as intake, decision or close-out, say which and how. If the log was the whole of it, say so plainly and say where your part ended. |
| F4 | "coach branch supervisors on escalations" (JD) | "trained new tellers on our escalation script" (your message) | medium | [grounded] | transferability | Tellers, not supervisors; a script, not coaching. Bridge: "I trained new tellers on our escalation script." Answer slot: if you coached anyone on escalations beyond that, say who and how. If not, say so plainly. |
| F5 | "report monthly on complaint volumes and resolution times" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | medium | [grounded] | discovery | The spreadsheet touches the monthly report. It does not show whether volumes or resolution times were in it. Answer slot: say what the spreadsheet counted, in your own words. If resolution times were in it, say how they were measured. If they were not, say so plainly. |
| F6 | "comfortable with Excel reporting" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | low | [inferred] | discovery | Your material does not name Excel, nor any function you used. The Excel reading is my derivation. Answer slot: name the tool and the functions you used, in your own words. If the spreadsheet was built in another tool, say so plainly. |
| F7 | "confident presenting to senior leaders" (JD) | "I've never presented to anyone above regional level" (your message) | none | [grounded] | capability | A gap you stated. Words: "I haven't presented above regional level." Then how you would prepare for a senior audience, said as a plan and never as a past. Do not add any presenting you have not done. |
| F8 | "the contact centre" within the complaints remit (JD) | "Never worked in a contact centre" (your message) | none | [grounded] | capability | A gap you stated. Words: "I haven't worked in a contact centre." Then how you would learn it, said as a plan. |
| F9 | "work with digital teams on self-service journeys" (JD) | none given | none | [grounded] | discovery | Your material says nothing about this. Answer slot: if you worked with any team on a customer-facing change, say which and what your part was. If not, say so plainly. |

Your material does not show, and the pack does not assume: work in a contact centre, presenting above regional level, regulated complaint handling by name, resolution times, Excel by name, or work with digital teams.

## Grounding brief: Ashgrove's strategy

This comes from the July 2026 brief you received through the recruiter. Use its terms, because they are the words the panel will use.

- **Digital:** move 40% of member service to digital channels by 2028.
- **Network:** consolidate eight branches into five hubs over 2027.
- **Products:** launch a small-business lending product in Q1 2027.
- **Competition:** the main pressure is app-only banks.

Words to use: "member service", "digital channels", "hubs", "app-only banks". The brief is four months old, so ask the recruiter in round 1 whether anything has moved. I found no stale framings to flag.

## Persona weights and reasoning

| Round | Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|---|
| 1 recruiter | Conversational / Rapport | Friendly biography opener, motivation, a few logistics | High. Recruiter screens are friendly, and the email names motivation checks | Pre-script a 90-second arc. Treat every casual question as scored |
| 1 recruiter | Skeptic (light) | "Why this, why now" with the contact-centre gap in view | Medium. The JD's scope is wide and your material is branch-side | Say the stated gaps plainly, then the plan |
| 2 Head of Member Services | Skeptic | "Which part would you be weakest at on day one?" | High. Your manager is derisking the hire, and the email says mostly behavioural | Name the two stated gaps first. Hold through two follow-ups |
| 2 Head of Member Services | Case / Strategist | Live problems on escalations and reporting | High. A manager tests how you would run the job | Clarify, then structure, then answer |
| 3 panel | Values / Behavioral | "Tell me about a time…" scored against each value | High. The email says the panel scores the values | Map a story to each value where your material carries one. Otherwise use the selection scaffold and its honest branch |
| 3 panel | Peer Evaluator | The seam between branches and the contact centre | High. Two branch managers sit beside your future team | Propose seam principles. Do not pretend to know their seam |
| 3 panel | Data-Driven Prober | "What did that count?" on the complaints report | Medium. The panel may read your spreadsheet line | Say what the spreadsheet counted, and say plainly what you do not know |
| 3 panel | Case | The 20-minute escalation case | Certain. It is in the email | Use the escalation structure in C8 |

## Question banks

Round weights: round 1 is light on depth, round 2 is the Skeptic and Case round, round 3 is the values and case round. Each round has its own bank.

### Round 1: recruiter (30 min)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through your background, starting where you are now." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "I handled the branch's formal complaints log" | A 90-second arc. Six years in retail banking, the last three as a branch supervisor. Then one clause on the complaints work: you handled the branch's formal complaints log. Stop there, and leave the contact-centre gap for round 2. | F1 and F2 are the only sentences the arc can use. Biography questions are scored for brevity |
| A2 | "This role covers the branches and the contact centre. Your background is branch-side. What is your angle on that?" | JD | [grounded] "Never worked in a contact centre"; "6 years in retail banking, the last 3 as a branch supervisor" | Say the gap in one line: "I haven't worked in a contact centre." Then the angle that your branch work does give you, using only the quoted sentence. Then how you would learn the contact-centre side, said as a plan | F8 is the scoped gap. The question's premise is the JD's scope, which the quote confirms |
| A3 | "What drew you to a member-owned credit union rather than another bank?" | CO | [generic] | Give your own reason in plain words. If the reason is member ownership, say so. Do not claim past experience with credit unions. Name one thing from the values page or strategy brief that you would speak to | Motivation, the most common recruiter check. No claim about your past |
| A4 | "Why leave branch supervision after three years, and why this remit?" | JD | [grounded] "the last 3 as a branch supervisor" | One sentence: the reason, in your own words. Then one sentence on why the complaints remit fits it. If the real reason is something other than the remit, say that | A motivation probe on the supervisor role in F1. The answer is yours, and the pack supplies no reason |

Recruiter reverse questions and the rest are in section Reverse questions below.

### Round 2: Head of Member Services (45 min, behavioural)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre"; "I've never presented to anyone above regional level" | The highest-ROI prep in this pack. Name the contact centre first: "I haven't worked in a contact centre." Then presenting: "I haven't presented above regional level." Then your ramp plan, said as a plan: how you would learn the contact-centre work in the first weeks, and how you would prepare for a senior audience. Hold through two follow-ups. Do not promise competence you have not shown | F8 and F7 are the two gaps you stated, and the manager is buying derisked capability. This objection will come in some form |
| B2 | "Tell me about a complaint that stayed open longer than it should. What did you do next?" | VAL | [grounded] "trained new tellers on our escalation script"; "I built the monthly complaints spreadsheet our regional manager uses" | Selection scaffold: pick a complaint that stayed open, name what was blocking it, what you did, and whether it closed. If none comes to mind, say so plainly, then give the nearest thing your material carries: the escalation script you trained tellers on, or the spreadsheet your regional manager reads. Do not invent a stuck complaint | Own the Fix. Your material has no sentence about a stuck complaint, so the answer has to be a selection the candidate makes and states |
| B3 | "What did that spreadsheet count?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Answer slot: say what the spreadsheet counted, in your own words, and how the entries were recorded. Name the assumption you would defend least, if you know it. If you do not know how a figure was counted, say so plainly. Hold through two follow-ups by returning to what it counted | F5 and F6 are the places a probe lands. The question asks about the spreadsheet you built, which the quote carries, and presupposes no figure |
| B4 | "A branch supervisor tells you two escalations have sat unresolved for three weeks. What do you do?" | CASE | [generic] | Structure, out loud: what you would ask the supervisor first; what you would do about the two cases today; who holds each one until it is solved; what the member is told, in plain words; what you would change so it does not happen again. Make no claim about your past | The JD's coaching line, asked as a decision. Generic by design |
| B5 | "Tell me how you would coach a branch supervisor who escalates everything." | JD | [grounded] "trained new tellers on our escalation script" | Start with the nearest thing: you trained new tellers on the escalation script. Say what you would carry over to supervisors, and how you would check the coaching worked. Answer slot: if you have coached anyone beyond tellers, say who and how. If not, say so plainly and describe how you would approach it | F4. The question presupposes coaching, which the material does not show, so the second branch lets that premise be false |
| B6 | "Tell me about a time you worked with a digital or IT team on a customer-facing change." | JD | [generic] | Selection scaffold: pick a change that reached customers, name your part, and say what you learned. If you have no such time, say so plainly, then say how you would start: which digital team, and what you would ask them first | F9. An open prompt raised by the JD's self-service line |
| B7 | "How would you build a monthly report of complaint volumes and resolution times in Excel?" | JD | [generic] | Answer in steps: the data you need, where it comes from, how you would clean it, what you would show, and how often. Name the tool you would use. If you have built this report before, say so, and say what it covered. If you have not, say so plainly | F5 and F6. A live reporting problem from the JD, asked as a method. No claim about your Excel level |

Requirement coverage, for the banks as a whole:

| Requirement | Covered by |
|---|---|
| 4+ years in financial-services customer operations | A1, A4 |
| Experience handling regulated complaints | B2, B3 |
| Own the complaints process end to end across branches and the contact centre | A2, B1, C6, C8 |
| Report monthly on complaint volumes and resolution times | B3, B7, C7 |
| Coach branch supervisors on escalations | B4, B5 |
| Work with digital teams on self-service journeys | B6 |
| Confident presenting to senior leaders | B1, C5 |
| Comfortable with Excel reporting | B7 |

### Round 3: panel of two branch managers (60 min, values scored, 20-minute case)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you decided something from the member's side of the counter." | VAL | [grounded] "trained new tellers on our escalation script" | Selection scaffold for Members First: pick a decision where the member's view changed what you did. If none comes to mind, say so plainly. Nearest thing your material carries: the escalation script you trained tellers on. Say what it was for, in your words | Values round scored against the published value. Your material has no member-side decision, so the honest branch must be ready |
| C2 | "Tell me about a time a member needed something explained twice." | VAL | [generic] | Selection scaffold for Plain Words: pick a moment the first explanation did not land. Say what you changed and whether it worked. If you have no such time, say so plainly and say how you would check your plain-words test on a member's letter | Plain Words. No quote carries a story, so the answer is selected, not mapped |
| C3 | "How would you keep a complaint process local when eight branches become five hubs?" | CO | [grounded] "consolidate eight branches into five hubs over 2027" | Start from the principle that every branch is part of its town. Say what you would measure at the town level: complaints by place and how long they take. Say what you would keep for members whose branch closes. Do not claim you have done a consolidation | Neighbours, Not Numbers, tied to the brief. The premise is the brief's own line. The approach is a principle, not a past |
| C4 | "Tell me about a problem you found that was not yours to fix. What did you do with it?" | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Selection scaffold for Own the Fix: a problem you found that stayed with you until it was solved. If the spreadsheet surfaced one and you kept hold of it, say what and how long. If not, say so plainly, then describe what you would hold, and for how long | Own the Fix. The spreadsheet is the nearest sentence. The story is yours to choose |
| C5 | "Tell me about a time you told a senior manager something they did not want to hear." | VAL | [generic] | Selection scaffold: pick a time you were right about something uncomfortable and said so. Say what you said, how they reacted, and what changed. If you have no such time, say so plainly, then say how you would raise a hard complaint trend with a senior audience | Hard truth to leadership, the panel's scored test of candour. A presenting question as well, so the honest branch matters |
| C6 | "Our branches and the contact centre see different complaints. Where is the seam, and what happens when you disagree?" | JD | [grounded] "Own the member complaints process end to end across branches and the contact centre" | Propose seam principles: one complaint record, one owner until closed, one closure rule. Do not claim you know their seam. For disagreement, use a time you disagreed and kept the relationship, if you have one; if not, say how you would disagree with a peer | Peer Evaluator. The seam is the JD's own scope |
| C7 | "Monthly complaint volumes fell by a third last quarter. Is that good news?" | JD | [generic] | Name the assumption before they do: the volume may have fallen because of how complaints were recorded, or because members stopped complaining. Say what you would check before you call it good news, and in what order. Hold the assumption until you have checked it | Data-Driven Prober on the JD's reporting line. A hypothetical figure from the panel, not a figure of yours |
| C8 | "A member complained at a branch, was passed to the contact centre, and has been escalated twice. The branch says it is closed. The member says it is not. Take me through what you do." | CASE | [generic] | 20-minute structure, out loud: clarify which complaint, what outcome the member wants, and which response timelines apply under your complaints policy. Set the objective: close it right, not just close it. Name one owner who holds it until it is solved. Get both sides' records. Lay out options. Tell the member in plain words. Find the root cause across branch and contact centre. Record it and report it. Say what you would not do: close it without the member agreeing | The panel's case. Asked as a decision. It claims nothing about your past |
| C9 | "Ashgrove wants 40% of member service through digital channels by 2028. What happens to the complaints that still come in by phone and at the counter?" | CO | [grounded] "move 40% of member service to digital channels by 2028"; "the main competitive pressure is app-only banks" | Say that complaints do not move with the channel. The ones left may get harder. Name the risk that members who complain by phone or at the counter get a slower route. Say you would measure route and time by channel. Be plain about what you do not know | Strategy question from the brief. Competitive pressure is the brief's own line |
| C10 | "Small-business lending launches in Q1 2027. What would you want in the complaints process before it does?" | CO | [grounded] "launch a small-business lending product in Q1 2027" | Principles, not experience: a complaint route defined before launch, one owner, and reporting kept apart from retail complaints. Do not claim business-lending experience you do not have | A forward question on the brief's product. No claim about your past |

## Values and principles cheat sheet

The values are the panel's scoring sheet. Your material does not carry a story for any of the four values, so each row gives the selection scaffold and its honest branch.

| Value (official name) | Working meaning | Your mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | No quoted sentence carries a story. Use C1 with its honest branch. Pick a decision where the member's view changed the outcome |
| Plain Words | If a member needs it explained twice, the writing was wrong | No quoted sentence carries a story. Use C2. Pick a moment a first explanation failed |
| Neighbours, Not Numbers | Every branch is part of its town | Your branch is the nearest local context. Use C3 and say what you would measure by town. No quoted sentence carries the story |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | Your spreadsheet is the nearest sentence. Use C4 and B2. Pick a problem you held until it was solved, or say plainly that you have not |

## Reverse questions

Reverse questions are at least five, each with why it lands. Your three interviewers have no profiles yet, so none is tied to a career path. The panel is peers, so one reciprocity question is included.

| Round | Question | Why it lands |
|---|---|---|
| 1 recruiter | "What does the panel score on each value, and what does a strong answer look like on Own the Fix?" | It shows you have read the values round as scored. It also tells you the bar |
| 1 recruiter | "Has the strategy brief changed since July, especially the hub timing?" | It tests whether your strategy knowledge is current, and it puts the question to the right person |
| 2 Head of Member Services | "What would you expect the first 90 days to deliver, and how would you know it is working?" | Your manager's definition of success is the most useful thing you can hear before the next round |
| 2 Head of Member Services | "Where do complaints most often stall today: in the branches, the contact centre, or the handoff between them?" | It shows you have thought about the seam. The answer is the job |
| 2 Head of Member Services | "How far has the digital self-service plan changed complaints so far?" | It ties your knowledge of the brief to the work the role does |
| 3 panel | "What would a new person do in their first month that would genuinely help your branch managers?" | Reciprocity for peers. It moves the conversation from what you need to what you bring |
| 3 panel | "When two branches disagree about a complaint's outcome, who decides today?" | It tests how the seam really works, and what you would be changing |
| 3 panel | "How are the hub changes being explained to branch teams and to members?" | It shows you care about the town, not just the numbers |

## Prohibited claims

These are the claims this pack will not coach, with the honest form of each. Each is built from the fit snapshot, because no dossier was supplied.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end across branches and the contact centre | Inflated form of F3. Your material says the branch log | "I handled the branch's formal complaints log." The material says the log, not the process |
| Tracked complaint volumes and resolution times | Inflated form of F5. Your material says the spreadsheet | "I built the monthly complaints spreadsheet our regional manager uses." |
| Coached branch supervisors on escalations | Inflated form of F4. Your material says tellers | "I trained new tellers on our escalation script." |
| Advanced Excel skills | Inflated form of F6. Your material does not name a tool or function | "I built the monthly complaints spreadsheet our regional manager uses." No level is claimed |
| Presented to senior leaders | A negative you stated, F7 | "I've never presented to anyone above regional level." No answer slot |
| Contact-centre experience | A negative you stated, F8 | "Never worked in a contact centre." No answer slot |

## Sources

- **Provided, used:** the JD text in your message; the values text you copied on 11 November 2026 from ashgrovecu.org/about/values; the recruiter's email on the rounds; the July 2026 strategy brief as you described it; your background message.
- **Not fetched:** I did not check the values page myself. The values are your copy.

Research tier: L0. No search or fetch was run in this pass, because the material you supplied covers the rounds, values and strategy.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | The values text you pasted fixes the values cheat sheet |
| 2. Ashgrove interview process, member services | skipped | The recruiter's email fixes the three rounds and the persona weights |
| 3. Ashgrove strategy / recent news | skipped | The strategy brief you pasted fixes the grounding brief. Recent news would test whether it has moved |
| 4. Interviewer name and footprint | n/a | No names were given, so there was no query to form |
| 5. Representative Member Experience Lead JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- **Your CV or role history in your own words** → the quotes move from your message to your CV. F1 and F2 can be checked against it.
- **What the complaints spreadsheet counted: volumes, resolution times, or both** → F5 and F6 move from discovery to presentation or none. B3 and C7 get your figures.
- **The Excel functions you used** → F6 becomes specific, and B7 gets a real answer.
- **The names of the Head of Member Services and the two branch managers** → per-member persona weights, an interviewer read, and tailored reverse questions. Public professional footprint only.
- **Whether complaints are held to a regulator's timelines, and which ones** → the B2 and B3 answer slots become specific.
- **Any task or deliverable named in the recruiter's email** → coverage of that deliverable.
- **Deeper research (L2): Ashgrove's recent news, the interviewers' public footprint, loop reports** → offered once. It runs only on your yes, and adds about six searches and two page fetches.
- **A fetch of the values page** → the values section cites the page itself, not your copy.
