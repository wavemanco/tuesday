This matches the interview-prep skill, so I'll load it and build the pack from your details.
The skill is loaded. Its Step 3 and Step 4 need the reference files, so I'll read the ones it names for synthesis and delivery.
I have the rules I need for the pack. The skill's default research tier is L1, so I'll load the search tool and run the company searches before writing.
Web search was refused by the host, so the pack will be built from your message alone. Writing the pack file now.
Your prep pack is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-alone-part-2-rooms-case-6-denied-d05ee1d2/2e9f9abb-dd76-4f7b-b2c3-9ed031690671/scratchpad/larkfield_engineering-manager_interview_pack.md`. It covers all three rounds, with one shared fit snapshot and a mini-pack per round: 8 questions for the Director, 9 for the panel, 8 for the VP.

The biggest things to prep:

- **The hardware roadmap gap (A3, round 1).** You've never owned a hardware-adjacent roadmap, and the pack expects this objection in all three rounds. The answer is to say "I haven't owned one" first, then move to the reliability quarter you did push through, and name the specific thing you'd defer on for the first few weeks.
- **The 60% on-call drop (A7, C1).** Expect "how was it counted, and which part was yours?" The pack does not supply a baseline or a counting method, since your material doesn't give one. Work out the answer in your own words before the first round.
- **Manager-of-managers (A2, B9).** Plain acknowledgment, then a plan for how you'd learn it. Whether the role has leads under you would change this, so the full JD matters.

Things that limit the pack:

- **No company research.** The host refused web search, so I couldn't check Larkfield's values, interview process or strategy. The VP round has no values cheat sheet, and its strategy question is generic.
- **Built from your summary, not a JD.** Requirements are quoted from your role description.
- **No interviewer names.** Personas use typical priors for each round type.

I wrote Yusuf as they/them in the pack; tell me if you'd prefer otherwise.

To sharpen it, I need one thing from you: **can you paste the full job description?** It would let the fit snapshot quote the posting's own lines and check every requirement against the question list.

I can also run a live drill on A3, the highest-ROI question, with the Director's pressure. Say the word. And I can save a `tuesday-dossier.md` recording the gaps this prep exposed, for carrying into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: larkfield_engineering-manager_interview_pack.md -----
# Interview prep pack: Engineering Manager, Larkfield Systems

**Candidate:** Yusuf
**Mode:** Loop (three scheduled rounds, one shared fit snapshot, one mini-pack per round)
**Built from:** your role summary and your background note. No full JD, no interviewer names, no company research (see Sources).

| Round | Interviewer(s) | Length | Mini-pack |
|---|---|---|---|
| 1 (Tuesday) | Director of Engineering, the hiring manager | 45 min | Round 1 |
| 2 (Thursday, following week) | Two staff engineers and a product manager | 60 min | Round 2 |
| 3 (Monday, following week) | VP Engineering | 30 min | Round 3 |

## How to use this pack

- **Personas** describe how a question arrives: its tone, its pace, what the interviewer is listening for.
- **Types** describe what is being scored. Tags: **JD** = a stated requirement; **EXP** = your past work and how you attribute it; **CASE** = a live problem from the role; **CO** = company or market knowledge; **VAL** = values and behavior.
- Guidance is scaffolding for a spoken answer, not a script. Say it in your own words.
- **Provenance** tells you what each piece of guidance rests on. `[grounded]` means it traces to something you said or to the role text you gave me. `[inferred]` means it is my derivation. `[generic]` means it is a pattern for this kind of question, with no claim about you or Larkfield.
- **Answer slots** are written as instructions, not questions. They tell you what to say if the thing was yours, and what to say if it was not.

## Fit snapshot (shared across all three rounds)

Quoted sentences come from your message, marked "your message," or from the role summary, marked "role summary." Gap types follow the routing rule in the skill: `transferability` means adjacent work that does not fully reach the requirement; `presentation` means the quote already reaches it in other terms; `discovery` means the material is silent; `capability` means you stated the absence; `none` means the quote covers it.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" (role summary) | "3 as a team lead of 6" (your message) | medium | [grounded] | transferability | Your material shows one team of six, not two squads. Bridge at its own scope: "For three years I led a team of six." Answer slot: if you have ever had more than one group, or leads reporting to you, say so and how; if not, say so plainly and say how you would split the work. |
| F2 | "own delivery, hiring and growth for 11 engineers" (role summary), delivery | "I pushed a reliability quarter through against roadmap pressure" (your message) | medium | [grounded] | transferability | Delivery at team scope, not eleven engineers. Keep the quote's terms: you pushed a reliability quarter through. Do not add a delivery system or a headcount you did not describe. |
| F3 | "own delivery, hiring and growth for 11 engineers" (role summary), hiring | "I run our hiring loop for backend roles — about 40 interviews last year." (your message) | medium | [grounded] | none | The quote covers hiring in role terms. Limit: it is about 40 interviews, not 40 hires, and it is backend roles. Lead with the loop and the count in those terms. |
| F4 | "own delivery, hiring and growth for 11 engineers" (role summary), growth | none given | none | [grounded] | discovery | No quote touches growth. Answer slot: if you grew people (promoted, coached toward a level), say which, how, and what you did; if you did not, say so plainly and say what you would do first. |
| F5 | "partner with hardware and product on roadmap" (role summary), product | "I pushed a reliability quarter through against roadmap pressure" (your message) | medium | [grounded] | transferability | Your roadmap experience is software and product, not hardware. Bridge at its own scope: the roadmap pressure you pushed through. Do not describe hardware partnership you did not describe. |
| F6 | "partner with hardware and product on roadmap" (role summary), hardware | "I've never managed managers and never owned a hardware-adjacent roadmap." (your message) | none | [grounded] | capability | A stated gap. Words: "I've never owned a hardware-adjacent roadmap." Then how you would learn hardware constraints, said as a plan and never as a past. |
| F7 | "Lead two squads building device-management services" (role summary), device domain | none given | none | [grounded] | discovery | Your material does not show device-management, telemetry or embedded work. Answer slot: if you have worked near device fleets, telemetry or embedded constraints, say which; if not, say so and say how you would learn the domain. |
| F8 | Manager of managers (your note: "no manager-of-managers experience") | "I've never managed managers" (your message) | none | [grounded] | capability | A stated gap. Words: "I haven't managed managers." Then the plan for how you would learn it. Whether the role has leads under you is unknown to me; the full JD would settle it (see upgrade menu). |

## Prohibited claims (not coached in any round)

| Not coached | Basis | Honest form |
|---|---|---|
| Managed managers, or coached leads who managed others | Negative you stated (F8) | "I haven't managed managers." Then the plan. No slot asks for a past here. |
| Owned a hardware-adjacent roadmap | Negative you stated (F6) | "I've never owned a hardware-adjacent roadmap." Then the plan. |
| Led two squads, or led eleven engineers | Inflated form of F1 and F2 | F1's quote at its own scope: "For three years I led a team of six." My observation, not words for you: the material shows one team. |
| Owned the engineering hiring process or set the org's hiring bar | Inflated form of F3 | F3's quote at its own scope: the hiring loop for backend roles. Your material says the loop, not the org's process. |
| The 60% drop was yours alone | Inflated form of the attribution in F2 | The sentence as written: "after I pushed a reliability quarter through." The 60% drop is linked to your quarter by "after," not credited to you alone. |

Growth outcomes (promotions, coaching results) are not on this list. Your material is silent on them, so they are answer slots, not claims to avoid.

---

## Round 1: Director of Engineering (hiring manager), 45 min

### Persona table

| Persona | How it shows up | Likelihood and why | Counter-strategy |
|---|---|---|---|
| Skeptic (top, 4 questions) | "You've never done X" probes on the three gaps F1, F6, F7 | High. A hiring manager is buying capability and derisking gaps (relationship prior). | Acknowledge the gap in your own words, then a plan. Rehearse the most likely objection until it is boring. |
| Case/Strategist (2) | Live problems on the actual roadmap: two squads, hardware dependency | Medium-high. They will test how you think on their roadmap. | Clarify, then structure, then answer. Say the framework aloud. |
| Data-driven Prober (2) | "Walk me through how that number was counted" on the 60% and the 40 interviews | Medium. A numbers-first candidate's claims get counted. | Know what you can and cannot say about each figure. Name the weakest assumption before they do. |

### Questions

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've led one team of six. How would you run two squads and eleven engineers?" | JD | [grounded] "3 as a team lead of 6" (your message); [grounded] "Lead two squads building device-management services" (role summary) | Open with the fact: "I've led one team of six for three years." Then a plan for splitting the work across two squads, in your own words. Answer slot: if you have had more than one group or leads reporting to you, say so and how; if not, say so plainly. | F1 is the scale gap; the question is its most direct form. |
| A2 | "You've never managed managers. What would you do the first time you have to coach a lead?" | JD | [grounded] "I've never managed managers" (your message) | Plain acknowledgment: "I haven't managed managers." Then the plan: what you would ask the lead, how you would check your coaching was landing, and who you would ask for help. Make no claim about a past coaching conversation. | F8 is a stated gap. The question presupposes a lead exists; if the role has none, say so. |
| A3 | "Partner with hardware on the roadmap. You've never owned a hardware-adjacent roadmap. Why should I believe you can run it?" | JD | [grounded] "I've never owned a hardware-adjacent roadmap" (your message); [grounded] "I pushed a reliability quarter through against roadmap pressure" (your message) | **Highest-ROI prep in this pack.** This is the objection the fit snapshot predicts most strongly (F6 with F5 and F7), and it returns in rounds 2 and 3. Plain acknowledgment: "I haven't owned one." Bridge: the closest thing you have is the reliability quarter, which was software, and you pushed it through roadmap pressure. Answer slot: if you have worked with any device, telemetry or hardware-team constraints, say which; if not, say so and say how you would learn them in the first month, with the hardware leads. Hold through two follow-ups by returning to the reliability quarter. Do not argue that you would be good at it. Concede specifically: "I haven't done this, and I'd expect to defer to the hardware leads on device constraints for the first few weeks." | Most predictable objection, aimed at the thinnest material. The hold uses only the quote; the concession names the exact gap. |
| A4 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | Name the hardware domain and manager-of-managers, both from your stated gaps, in your own words. Then one concrete ramp plan: what you would learn first, from whom, by when. | A self-assessment stem. Scores honesty and whether you have a plan, not the gaps themselves. |
| A5 | "Two squads are behind on a device-management release, and the hardware team says firmware will slip a month. What do you do in week one?" | CASE | [generic] | Clarify: what the slip blocks, what the customer has been promised, what the hardware team can commit to. Then segment the options (cut scope, add people, move the date), name the metric for each, and the risk you are accepting. Think aloud. | A live problem from the role's hardware dependency. No claim about your past, so none is made. |
| A6 | "How would you decide between a customer-requested device feature and the reliability backlog for next quarter?" | CASE | [generic]. If you use your reliability quarter as the example: [grounded] "I pushed a reliability quarter through against roadmap pressure" (your message) | Structure: the objective, the cost of each option, what you would need to know, your recommendation with the risk named. If you use the reliability quarter, say what the trade-off was and what you chose, in your own words. | Roadmap ownership with product, the role's core. The story is optional and only as far as the quote goes. |
| A7 | "Walk me through how the on-call burden dropped 60%. How was it counted, and which part was yours?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" (your message) | Defend-the-number slots, in your words: how the figure was counted, over what period and against what starting point, if you can name them. Answer slot: if you cannot say how it was counted, say so plainly. Name the assumption behind the 60% you would defend least before they do. Then say which part was yours: the decision to push the quarter, not the whole team's work, unless it was. | Figures attract probers. The pack does not supply a baseline or a counting method, because your material does not give one. |
| A8 | "Tell me about your hiring loop for backend roles. What did you run, and what would you change?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." (your message) | Say what the loop is, in those words, and what you ran in it. Answer slot: if you calibrated the bar, or changed the loop, say what and how; if not, say so and say how you would calibrate it for an engineering manager hire. Never turn "about 40 interviews" into a number of hires. | F3 is the strongest bridge to hiring for this role, so expect it to be probed. |

### Persona coverage check

Round 1 covers: lead two squads (A1), manager of managers (A2), hardware roadmap (A3), growth (A4 touches it; no separate growth question here), delivery (A7), hiring (A8), roadmap with product and hardware (A5, A6). Growth gets its own question in round 2 (B8) for the staff engineers.

### Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1a | "What would the first 90 days need to look like for both squads to be healthy?" | Turns the interview into a shared planning conversation, and shows you are thinking about two squads, not one team. |
| R1b | "How do you want this role to decide when the roadmap and reliability work collide?" | Points at the trade-off in A6 and shows you expect a real decision rule to exist. |

---

## Round 2: Two staff engineers and a product manager, 60 min

### Persona table

| Persona | How it shows up | Likelihood and why | Counter-strategy |
|---|---|---|---|
| Data-driven Prober (top, 3) | Depth probes from the staff engineers: how you know reliability is real, how you calibrate interviews | High. Staff engineers verify depth (technical specialist prior). | Name your assumptions; say what you did not measure. |
| Peer Evaluator (2) | Seam questions between squads and product; credit when work spans teams | High. Both sides of this panel will be your peers in practice. | Reciprocity: what you bring to their teams, not just what you need. Propose seam principles, not invented ones. |
| Case/Strategist (2) | A roadmap sequencing problem from the PM | High. The PM tests roadmap thinking. | Clarify, structure, metrics, risks. |
| Pressure (2) | A challenge aimed at the hardware gap, from a staff engineer | Medium. A panel may test composure once. | Hold a position through two follow-ups, then concede exactly what you have not done. |

### Questions

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "What's the hardest technical decision your team has made in the last year, and what would you have changed?" | EXP | [grounded] "I pushed a reliability quarter through against roadmap pressure" (your message) | Open prompt. If the reliability quarter is the honest answer, tell it in the quote's terms: the pressure, what you pushed through, what it cost. Answer slot: if the technical decisions inside the quarter were yours, say which; if they were the team's, say so. | Staff engineers ask for decisions, not outcomes. The slot keeps the answer honest about whose decision it was. |
| B2 | "How would you know a reliability improvement was real, and what would fool you?" | CASE | [generic] | Name the signal you would trust (what changed in incident load, what did not), the confounders (traffic, a quiet month, a reclassified alert), and what you would check before claiming a win. | Probes whether the 60% story survives method questions; device-fleet context is unknown, so the answer stays general. |
| B3 | "I'll push on this. A manager who has never owned hardware work will defer to the hardware team on every trade-off. Convince me otherwise, in two minutes." | JD | [grounded] "I've never owned a hardware-adjacent roadmap" (your message) | Pressure stem. Hold: you would own the trade-off decisions with the hardware leads, and say how. Concede specifically: "I haven't owned a hardware roadmap, so for the first few weeks I would defer on device constraints, and say so out loud." Do not argue that you are not a deferrer. | Pressure belongs in the panel because a staff engineer may test it. The concession is the one your material supports. |
| B4 | "Where's the seam between your squads and product, and what happens when we disagree?" | JD | [generic]. Raising source: "partner with hardware and product on roadmap" (role summary) | Reciprocity first: what your squads would give the product team. Then one seam principle you would propose. Disagreement: if you have disagreed with product, say how you handled it, in your words; if not, say how you would. | Peer Evaluator stem. Seam questions are where a PM tests real partnership. |
| B5 | "How do you handle credit when work spans teams?" | VAL | [generic] | Name the people, not the team, in one example if you have one. If you do not have one, say how you would share credit and say so. | Peer Evaluator stem, collegial packaging of the credit objection. |
| B6 | "Sales wants three device features, and the reliability backlog is growing. Walk me through how you'd sequence next quarter." | CASE | [generic] | Clarify the constraints and the objective. Segment the requests (who asks, what it costs, what breaks if deferred). Name one metric per option and the risk you accept. | The PM's core question, the roadmap partnership the role describes. |
| B7 | "What's the real difference between a hardware roadmap and a software roadmap for a device-management service?" | CO | [generic] | Say what you know in plain terms (release cadence, field update risk, hardware lead times), and name what you do not know. Do not claim a device-domain past. | Probes whether the domain gap is real. An honest partial answer scores better than a confident generic one. |
| B8 | "How do you know your interview bar is calibrated, given you run the loop for backend roles?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." (your message) | Answer slot: if you checked calibration (how, and what you found), say how; if you did not, say so and say what you would check first. Do not claim a calibration method you did not run. | F3 probed for quality, not volume. Staff engineers judge the bar. |
| B9 | "Sixty seconds: why would the engineers on these squads trust a manager who has never managed managers to protect their time?" | JD | [grounded] "I've never managed managers" (your message) | Plain acknowledgment: "I haven't managed managers." Then the plan: what you would do in the first month to earn trust, and how you would protect their time. | Pressure on F8 from the people the manager will work with. The stated gap is said once, then the plan. |

### Persona coverage check

Round 2 covers: depth and method (B1, B2, B8), composure (B3, B9), seam and credit (B4, B5), roadmap sequencing (B6), domain (B7). Growth (F4) gets B8's calibration answer and no separate growth question; the reverse questions below ask about growth.

### Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R2a | "What would a new person do in their first month that would genuinely help your team?" | Reciprocity question for a peer panel. Shows you are asking what you can give, not only what you need. |
| R2b | "Where do the staff engineers think the current device-management architecture is weakest?" | Invites the technical conversation the panel can answer, and shows you want their view. |
| R2c | "What does growth look like for engineers here, and what would you want from me on it?" | Puts growth, which the material is silent on (F4), into the conversation, and asks for their view on it. |

---

## Round 3: VP Engineering, values and leadership philosophy, 30 min

**Values note:** Larkfield's published values are not in hand, so this round has no values cheat sheet. The recruiter's description ("values and leadership philosophy") makes this a values round, and the VAL questions below are written against your stories and generic patterns. The upgrade menu says what would turn them into mapped answers.

### Persona table

| Persona | How it shows up | Likelihood and why | Counter-strategy |
|---|---|---|---|
| Values/Behavioral (top, 4) | Scenario probes for the leadership philosophy; STAR-shaped stories | High. The recruiter named the round as values-led. | "We" for context, "I" for what you decided. Land the hard truth where your material shows one. |
| Pressure (2) | Composure on the scope gap, from an executive | Medium-high. A VP tests whether you can hold a position on scale. | Hold, then concede exactly the scope you have not done. |
| Case/Strategist (1) | A question on where the industry is going | Medium. Executive altitude test. | Name one trend, the reason, and what you would verify. |
| Conversational (1) | A friendly opener that is still scored | Medium-high. A 30-minute round often starts loose. | A 90-second arc, prepared once. |

### Questions

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" (your message); the open prompt's theme is from the recruiter's "values and leadership philosophy" | Open prompt. If the reliability quarter is the honest fit, the truth was the roadmap pressure cutting against reliability. "We" for the team, "I" for what you decided to push. The outcome: state the 60% with the counting caveat from A7. Answer slot: if no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it. | The quote is the only story your material carries for this theme. |
| C2 | "What's your leadership philosophy, and where did it come from?" | VAL | [generic] | Three sentences in your own words, each anchored in one thing you did. Do not borrow a philosophy you do not hold. | A values round opener. Scores whether the philosophy connects to your past. |
| C3 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Open prompt. Choose a real instance. If none comes to mind, say so plainly, then give the nearest thing you did. Do not invent a customer story. | Persona stem for the Values/Behavioral prior. Theme is generic, since no published value is in hand. |
| C4 | "You've led a team of six. Why should we trust you with two squads and a 600-person company's device line?" | JD | [grounded] "3 as a team lead of 6" (your message); scope from role summary: "Lead two squads building device-management services" | Hold: "I've led one team of six for three years; I'm confident in the team-level work, and the step to two squads is what I'd need to build." Concede specifically: "I haven't done the two-squad step yet; here is how I'd learn it." Hold through two follow-ups. Do not expand the six into a bigger scope. | The pressure question on F1 from the top of the company. Held position is the one the quote carries. |
| C5 | "What would you do in your first thirty days if the hardware team disagreed with your roadmap?" | CASE | [generic] | Listen first, then state the constraint each side is protecting. Decide with a rule the two teams can both read, and say what you would escalate and what you would not. | A live problem on hardware partnership, no claim about your past. |
| C6 | "Where do you think device management goes in industrial IoT over the next three years?" | CO | [generic] | Name one trend, why you think it is moving, and what you would verify before you bet on it. Do not claim knowledge of Larkfield's strategy, which I have not researched. | Altitude test. Research was not run, so this stays general and says so. |
| C7 | "So, walk me through the journey to here." | VAL | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" (your message) | A 90-second arc: nine years in engineering, three leading a team of six, now at a payments company. Answer slot: the reason you are moving, in your own words. Keep it short; the length is the signal. | A casual opener that is still scored. Prepare it once, verbatim-ish. |
| C8 | "What do you need from your VP to do this job well?" | VAL | [generic] | Name two things you need, with one example of why each matters. Ask for them directly. | Turns the leadership-philosophy round into a working relationship, and shows you have thought about the VP's job. |

### Persona coverage check

Round 3 covers: values and story (C1, C2, C3), composure on scope (C4), hardware partnership (C5), altitude (C6), opener (C7), leadership relationship (C8).

### Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R3a | "What did the best leader you've worked with here do differently in their first year?" | Asks about leadership, which is the round's theme, and gives the VP room to show their philosophy. |
| R3b | "What would make you confident in this hire at the end of the first quarter?" | Shows you want a measurable bar and are not only selling yourself. |

---

## Sources

**Provided documents:** your role summary and your background note in the conversation. No JD text, no interview guide, no values page.

**Searches and fetches:** two standard searches were attempted for targets 1 and 2 below. The host refused both, because web search permission was not granted. No other calls were made.

**Research tier:** L1 requested, but no search ran (refused). Searches 0 of 6, fetches 0 of 2.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Larkfield values | unavailable | Values cheat sheet for round 3. Queries sent: "Larkfield Systems industrial IoT company values" (refused). |
| 2. Larkfield interview process, engineering manager | unavailable | Loop structure and round weights. Queries sent: "Larkfield Systems engineering manager interview process device management" (refused). |
| 3. Larkfield strategy and recent news | unavailable | The CO question C6 would move from generic to grounded. No call sent; host search refused. |
| 4. Interviewer name and public footprint | n/a | No names given. The interviewer read is absent. |
| 5. Representative JD for the title | unavailable | JD-tagged questions would be checked against a representative list. No call sent; host search refused. |

## Upgrade menu

- **Full JD text** → the fit snapshot quotes the JD's own lines instead of your role summary, and the requirement-coverage check runs against it. It may also show whether the role has leads under you (F8) and whether it has any location or travel conditions that the material does not cover.
- **Interviewer names for the three rounds** → personas and reverse questions tuned to each person's public footprint. Without names, the round weights come from relationship priors.
- **Larkfield's published values page, pasted** → a values cheat sheet for round 3, with each value mapped to a story from your material, or a selection scaffold where none fits.
- **Web search permission** → company strategy and interview-process research (L1), which would ground C6 and the round 3 values mapping. A deep-research pass (L2) is available on request, with its caps and time cost stated.
- **For the 60% story: how it was counted, the starting point, and which decisions were yours** → upgrades A7 and C1 from answer slots to rehearsed answers. Anything you tell me here becomes new material and updates the rows that draw on it.
- **Whether the two squads have leads reporting to you** → settles F8 and A2.
- **Any device, telemetry, embedded or hardware-team work, even at a distance** → changes F7 from discovery to a stated adjacent case, with its limits.
- **Your interview schedule with start times** → prep sequencing across the three rounds.
