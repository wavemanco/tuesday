Your prep pack is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-alone-part-2-rooms-case-8-canned-505dce25/21187fcf-8423-4645-8aac-0745c7b40116/scratchpad/ashgrove_member-experience-lead_interview_pack.md`.

I built it for all three rounds, since you gave me the full loop. Everything in it traces to your message, the JD text you pasted, the recruiter's email, the strategy summary you gave me, or the Ashgrove pages I checked. Your values wording matches the official page, and their "How we hire" page confirms the three-round structure and the values-scored panel.

**The biggest gaps, which the pack treats as the priority:**
- **Contact centre.** You've never worked in one, and the role covers it. The pack's hold is your six years and your branch log. The concession is one sentence. Then you give a plan for learning it. Question C1 is the one to rehearse most.
- **Senior presentation.** You've never presented above regional level. Say that plainly, then give a plan. Don't describe a presentation you haven't given (C2).
- **Resolution times.** Your spreadsheet shows volumes. Nothing you gave me shows resolution-time reporting, so the pack leaves that as an answer slot. If you did track it, say how it was counted (D1).
- **Digital teams.** Nothing in your material shows this work, so it's an answer slot (C3).

**For the 20-minute case (round 3):** B1 is a complaint that has come in three times from different branches about one fee. The structure is clarify, one owner, one case record, a plain-words reply to the member, and a root-cause note to branch supervisors. It makes no claim about your past, so you can rehearse it without the risk of overstating.

**Values:** Plain Words and Own the Fix have nearby sentences from your material, though nothing shows a full story. Members First and Neighbours, Not Numbers have no sentence at all, so the pack gives you a selection scaffold and says what to do if no example comes to mind. Don't reach for an example you don't have.

**What I took as the reading:** round 2 is mostly behavioural, so I weighted values questions above case questions. The panel is scored on values and includes the case. I didn't ask any questions, because the round structure and the JD were enough to build the full pack.

**Not included:** the pack has no prep schedule, because you didn't say how much time you have.

Would you like a drill? I can play the Skeptic on C1, the contact-centre objection, and push back on your answer. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, so you can carry them into later sessions. And I can convert the pack to a Word document if you want one.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove_member-experience-lead_interview_pack.md -----
# Member Experience Lead, Ashgrove Credit Union: interview prep pack

**Interviews:** 20 November 2026. Round 1 recruiter (30 min). Round 2 Head of Member Services, your future manager (45 min, mostly behavioural). Round 3 panel of two branch managers (60 min, including a 20-minute complaint-escalation case, scored against the four values). Names for round 2 and round 3 are not yet known.

## 1. How to use this pack

Personas describe **how a question arrives**. Types describe **what is being scored**.

| Type | Meaning |
|---|---|
| VAL | Behavioural and values: does your past behaviour show the published values |
| EXP | Experience deep-dive: do your claims survive questions about what you did |
| JD | Role-driven: can you do the listed job, gaps included |
| CO | Company and strategy: do you know where Ashgrove is heading |
| CASE | Live problem from the role, solved aloud |

The guidance is scaffolding, not a script. Say it in your own words. Where a cell says "answer slot", the answer is yours to give from what actually happened, including "that was not mine".

## 2. Fit snapshot

Requirements are quoted from the JD text you pasted. Evidence is quoted from your message, and nothing else. No requirement here is a hard gate (eligibility, licence or credential); the four-plus years line is graded on fit like any other.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" (JD) | "6 years in retail banking, the last 3 as a branch supervisor" (your message) | medium | [grounded] | none | The quote meets the requirement on its own terms. Say the six years and the three as supervisor exactly as written. Limit: self-reported, with nothing inspectable behind it yet, so expect a probe on what the years covered. |
| F2 | "experience handling regulated complaints" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | presentation | Reword only what the quote says: "I handled the branch's formal complaints log." Do not add rules, timelines or regulators to it. |
| F3 | "Own the member complaints process end to end across branches and the contact centre" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | transferability | Credible adjacent work at one branch. Say the quote at its own scope: "I handled the branch's formal complaints log." Limit, as this pack's observation: your material shows one branch's log, not a process end to end across branches. |
| F4 | "report monthly on complaint volumes" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | medium | [grounded] | presentation | The spreadsheet reaches monthly volume reporting in other terms. Say the quote as written. Add no counts, dates or outcomes to it. |
| F5 | "report monthly on complaint volumes and resolution times" (JD) | none given | none | [grounded] | discovery | Your material does not show resolution-time reporting. Answer slot: if the spreadsheet or any report carried resolution times, say what was counted and how; if none did, say so and say what you would measure first. |
| F6 | "coach branch supervisors on escalations" (JD) | "trained new tellers on our escalation script" (your message) | low | [inferred] | transferability | Coaching note only. Say the quote at its own scope: you trained tellers. Answer slot: if you have coached a supervisor on an escalation, say how; if you have not, say so. |
| F7 | "work with digital teams on self-service journeys" (JD) | none given | none | [grounded] | discovery | Your material does not show digital-team work. Answer slot: if you have worked with a digital team on a customer journey, say which and what you did; if not, say so and say how you would learn the journey work. |
| F8 | "confident presenting to senior leaders" (JD) | "I've never presented to anyone above regional level" (your message) | none | [grounded] | capability | A gap you stated, so the words are yours: "I've never presented to anyone above regional level." Then how you would learn it, said as a plan. Never describe a senior presentation. |
| F9 | "comfortable with Excel reporting" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | medium | [grounded] | presentation | The quote reaches reporting in other terms: a spreadsheet you built and that is used. Say "spreadsheet". Do not name Excel features you have not described. |
| F10 | "Own the member complaints process end to end across branches and the contact centre" (JD) | "Never worked in a contact centre" (your message) | none | [grounded] | capability | A stated absence for the contact-centre half. Words: "I've never worked in a contact centre." Then a plan for learning how a contact centre runs complaints. Never claim contact-centre work. |

## 3. Grounding brief

From the 2026 strategy brief as you supplied it, and from the sources in section 12. Use the current vocabulary; do not coach a correction of anyone's framing.

- Move 40% of member service to digital channels by 2028.
- Consolidate eight branches into five hubs over 2027.
- Small-business lending launches in Q1 2027. This is not in this role's scope, so do not claim it.
- App-only banks are the main competitive pressure.
- Values, as published: Members First, Always; Plain Words; Neighbours, Not Numbers; Own the Fix.
- Process, as published: most roles have three rounds, and the panel scores against the four values.

No stale framing was found in the material provided.

## 4. Persona table

Relationship priors set the starting weights. The loop then adjusts them: round 2 is described as mostly behavioural, so values rise above the hiring-manager default of case and skeptic. The panel is scored against values and includes a case.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral (A) | Round 2 questions about past conduct; the panel's values score | High. Round 2 is mostly behavioural, and the process page says the panel scores against values | Use a story for each value where your material has one. Where it does not, say so and use the nearest sentence you have |
| Case / Strategist (B) | The 20-minute complaint-escalation case in round 3 | High. Named in your recruiter email | Clarify, then one owner, then the root cause, then the member's answer. Say the assumptions aloud |
| Skeptic (C) | Round 2 probing the contact centre, senior presentation, and the step from supervisor to coach | High. F3, F8 and F10 are the largest gaps, and a skeptic finds them first | Rehearse the contact-centre and senior-presentation objections until they are plain. Concede in one sentence, then give a plan |
| Data-Driven Prober (D) | Panel members asking what the spreadsheet counted | Medium. Branch managers read complaint numbers daily, but no panel member is named | Say what you counted, and say plainly when you do not know how a count was defined |
| Pressure (E) | Challenges to how much of the spreadsheet was yours, and to fit against an internal candidate | Medium. Possible in any panel, not specified in the brief | Hold through two follow-ups, then concede one specific point |
| Conversational (G) | Round 1 recruiter: openers, Excel asked casually | High for round 1. Recruiter screens are scored even when they feel light | A 90-second arc. Treat the Excel question as scored |
| Peer Evaluator (H) | Branch managers asking about the seam between complaints and branch operations | Medium. The panel are branch managers, so they will be your future peers | Propose a principle for the seam. Do not claim to know theirs |

Weights: round 1, Conversational 3, Skeptic 2. Round 2, Values 4, Skeptic 3, Pressure 2, Case 2. Round 3, Values 4, Case 3, Prober 3, Peer 2, Pressure 2.

## 5. Question banks

Coverage line. Each JD requirement, mapped to the question IDs that cover it:

| JD requirement | Questions |
|---|---|
| 4+ years in financial-services customer operations | C1, E2, G1 |
| Experience handling regulated complaints | A1, D3 |
| Confident presenting to senior leaders | C2 |
| Own the complaints process end to end across branches | A1, C1 |
| ...and the contact centre | C1, E2 |
| Report monthly on complaint volumes | D1, D2, E1 |
| Report monthly on resolution times | D1 (answer slot only) |
| Coach branch supervisors on escalations | B1, C4 |
| Work with digital teams on self-service journeys | B2, C3 |
| Comfortable with Excel reporting | D1, G2 |

**Highest-ROI prep:** C1. It is the objection most likely to come in some form: one branch's log, against a role that covers branches and the contact centre. The hold is what you did; the concession is the contact centre. Rehearse it until it is plain.

### A. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Tell me about a time a member's complaint was going nowhere and you decided what happened next." | VAL | [grounded] "I handled the branch's formal complaints log" (your message) | Story-mapped on F2. Beats: the complaint, what you did next, how you knew it had closed. Answer slot: if the complaint was closed by someone else, or the log shows it handled but not resolved, say so, and say what you would do differently. Hold on what you did, not on the outcome. | Own the Fix is tested in round 3, and the JD's end-to-end line sits here too. F2 is the only sentence about complaint handling, so the story draws on it. |
| A2 | "Tell me about a time you put the member's side of the counter ahead of what the branch needed." | VAL | [grounded] "I handled the branch's formal complaints log" (your message) | Selection scaffold, with no story given. Pick a complaint where the member's need and a branch process pulled apart, and say what you chose and why. The nearest sentence is the formal log: if a case came through it, say how you handled it from the member's side. If no such time comes to mind, say so plainly, then say how you handle a complaint from the member's side. | Members First is the first value the panel scores. F2 is the nearest sentence, so the scaffold carries the honest branch. |
| A3 | "Tell me about a time you had to explain something to a member more than once." | VAL | [grounded] "trained new tellers on our escalation script" (your message) | Selection scaffold. Pick a time an explanation had to be given again, and say what changed the second time. If none comes to mind, say so plainly, then give the script training in those words. | Plain Words is scored. F6 is the nearest sentence, and it is about tellers, not members, so the scaffold does not stretch it. |
| A4 | "Tell me about a time a local detail, not the policy, changed how you handled a complaint." | VAL | [generic] | Selection scaffold. Pick a case where something about the branch or its town changed the answer, and name what it was. If none comes to mind, say so plainly, then say how you would learn what a branch's town needs in the first month. | Neighbours, Not Numbers has no sentence in your material, so the scaffold and its honest branch carry it. The label is [generic] because the guidance makes no claim about you. |
### B. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A member has complained three times about the same fee, and a different branch logged each one. You have twenty minutes. Walk me through what you do." | CASE | [generic] | Clarify first: how many members, which fee, and whether the fee policy is yours to change. Objective: one answer for the member and one owner for the case. Approach: name one owner; one case record across branches; a plain-words reply to the member; a root-cause note to branch supervisors. Metrics: repeat contacts and days to close. Risk: the fee itself is not yours to change. Say who decides, and escalate it with the member's facts. Hold Own the Fix until the case is closed. | This is the round 3 case. It uses the JD's end-to-end and coaching lines and carries the values into the answer. It makes no claim about you. |
| B2 | "Ashgrove is moving 40% of member service to digital by 2028. Where would a complaints process break first?" | CO | [grounded] "move 40% of member service to digital channels by 2028" (2026 strategy brief, as supplied) | Structure: which complaints move to a self-service channel, which still need a person, and where Own the Fix fails when nobody answers. Name one failure a self-service journey creates for complaints, and one measure you would watch first. | The brief is the differentiator most candidates cannot answer. The question makes no claim about you, so the label stands alone. |
| B3 | "Eight branches become five hubs during 2027. What happens to open complaints on the day a branch closes?" | CO | [grounded] "consolidate eight branches into five hubs over 2027" (2026 strategy brief, as supplied) | Clarify: how many open cases there are, whose supervisors own them, and how members are told. Approach: inventory open cases before the move, give each an owner, tell members in plain words, and track them by hub afterwards. Name one case you would not move until it closed. | The consolidation puts complaints in flight at the centre of the change. No claim about you. |

### C. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "This role runs complaints across branches and the contact centre. Your experience is one branch's formal log. Why would we bet on that?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" (your message); [grounded] "I handled the branch's formal complaints log" (your message); [grounded] "Never worked in a contact centre" (your message) | **Highest-ROI prep.** Hold: "Six years in retail banking, the last three as a branch supervisor, and I handled the branch's formal complaints log." Concede plainly: "I've never worked in a contact centre." Then a plan, stated as a plan: how you would learn a contact-centre queue in your first month. Hold through two follow-ups by returning to the log and the supervisor years. Do not add a contact-centre story. | F3 and F10 are the two largest gaps, and this is the objection the JD and a panel's scope most predictably raise. F1 and F3 are the holds. |
| C2 | "You've never presented above regional level. Why would senior leaders trust your numbers?" | JD | [grounded] "I've never presented to anyone above regional level" (your message); [grounded] "I built the monthly complaints spreadsheet our regional manager uses" (your message) | Plain acknowledgment first: "I've never presented to anyone above regional level." Then the spreadsheet, in its own words, as the numbers you have. Then a plan, stated as a plan: how you would prepare your first senior presentation, and how you would check the figures with a peer before it. Never describe a senior presentation you have not given. | F8 is a capability gap you stated. The presentation requirement is headline, and the spreadsheet is the only numbers evidence you have. |
| C3 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre" (your message) | Answer slot: if you have worked with a digital team on a customer journey, say which and what you did. If you have not, say so, and name the order in which you would learn the journey work. The contact-centre part is the stated absence above; use those words if it comes up. | Skeptic favourite. F7 is silence in your material, so the honest form is the slot, not a claim. |
| C4 | "You've supervised for three years. Why move to a role that coaches supervisors?" | JD | [inferred] "trained new tellers on our escalation script" (your message); "6 years in retail banking, the last 3 as a branch supervisor" (your message) | Answer slot: if you have coached another supervisor on an escalation, say how. If you have not, say so, and say how you would learn to coach supervisors. Build on what you did: you trained tellers on the escalation script, and say that in those words. Do not stretch it to supervisors. | F6 is transferable at best. The label is [inferred] because the bridge is this pack's derivation, not your sentence. |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "What did your monthly complaints spreadsheet count, and how was each count defined?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" (your message) | Defend-the-number slot. No figure is given, so the guidance is an answer slot: say what the spreadsheet counted and how, in your words. Name the assumption you would defend least before they do. If it held resolution times, say how they were counted; if it did not, say so plainly, and say what you would measure first. | F4 and F5 are the monthly reporting requirement. The question asks for the counting method, which your material does not state. The slot stops you giving an explanation you cannot repeat under a second question. |
| D2 | "Who uses your spreadsheet, and what decision did it change?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" (your message) | Say who uses it, in the sentence's own words. Answer slot: if you know what decision it changed, say what; if you do not, say so and say how you would find out. | F4. Outcomes come after volumes, and the honest answer may be that you do not know. |
| D3 | "What rules governed how the formal log was kept, and who set them?" | JD | [grounded] "I handled the branch's formal complaints log" (your message) | Answer slot: if a named source set the rules, say which and how you applied them. If no rules were set, or they were not yours to apply, say so plainly, and say how you kept the log. Stay with the log; do not add detail beyond it. | The JD asks for regulated complaints, and F2 is the only evidence. The second branch allows that no rules were set. |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "That spreadsheet is your regional manager's tool, not a reporting function. How much of it was actually you?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" (your message) | Hold-then-concede. Hold: "I built it, and my regional manager uses it." Hold that through two follow-ups by returning to what you built. Concede where your sentence stops: "I don't know how the region uses it beyond that." Do not fold on what you built. | F4 and F9. Pressure on attribution is the pack's test of honesty. |
| E2 | "Sixty seconds: why should we hire you over an internal candidate with contact-centre experience?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" (your message); [grounded] "Never worked in a contact centre" (your message) | Sixty seconds. Open with the six years and the three as supervisor, then the branch log. Concede in the same breath: "I've never worked in a contact centre." Hold through the first follow-up: the branch log is the closest work you have to this role. Do not fold to the contact-centre argument. | Pressure on fit, with the concession and hold in one answer. |

### G. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey to here." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" (your message) | A 90-second arc: the six years, the three as supervisor, the complaints log and training tellers on the escalation script, and why member services. Keep it to what those sentences say. | Round 1 is scored even though it feels light. This is the biography question. |
| G2 | "What are you actually playing with in Excel these days?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" (your message) | Say what you built and what it does, in those words. Answer slot: if you use lookups or pivot tables, name them and what they do; if you do not, say so and name the spreadsheet functions you do use. | Excel is a JD plus, asked casually. F9. |
| G3 | "Why Ashgrove, and why now?" | VAL | [grounded] "Members First, Always — we decide from the member's side of the counter." (published values page, fetched) | Name one published value and say why it matches how you work, in your own words. Do not claim knowledge of Ashgrove beyond the brief. Mention the 40% digital target only if you can say what it means for complaints. | Motivation is scored on the published values, not on slogans. |

### H. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Our branches sit beside yours. Where's the seam between complaints and branch operations, and what happens when we disagree?" | VAL | [generic] | Propose a principle, not a seam you claim to see: one owner per case; the branch keeps the member conversation; a disagreement goes to the Head of Member Services with the member's facts. Do not claim to know their seam. | Branch managers as future peers. The label is [generic] because the guidance makes no claim about you. |

Answer slots are instructions for the interview, not questions to you. Count: 20 questions across seven personas.

## 6. Values / principles cheat sheet

The panel scores against these four values. The published wording is the one in the official page.

| Value | Working meaning | Mapped story, or scaffold with honest branch |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | No mapped story. Scaffold, A2: pick a complaint where the member's need and a branch process pulled apart. Nearest sentence: "I handled the branch's formal complaints log" (F2). If none comes to mind, say so plainly, then say how you handled one complaint from the member's side. |
| Plain Words | If a member needs it explained twice, we wrote it wrong | Nearest sentence: "trained new tellers on our escalation script" (F6). Scaffold, A3: pick a time an explanation had to be given again. If none comes to mind, say so plainly, then give the script training in those words. |
| Neighbours, Not Numbers | Every branch is part of its town | No mapped sentence. Scaffold, A4: a local detail that changed a decision. If none comes to mind, say so plainly, then say how you would learn a town's needs in the first month. |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | Nearest sentence: "I handled the branch's formal complaints log" (F2). The log shows handling, not a solved case. Scaffold, A1: a complaint you kept hold of until it closed. If the case did not close under you, say handled and say what you would do differently. |

## 7. Reverse questions

Interviewers are not profiled, so none is tied to a career path. Each question below has a reason it lands.

1. "What does a complaint look like when it reaches the Head of Member Services, and what would have had to go wrong at the branch first?" Why it lands: it shows you understand the escalation path the role owns.
2. "How will the move from eight branches to five hubs change where complaints get logged?" Why it lands: the 2027 consolidation puts complaints in flight at the centre of the change, and the question shows you have read the brief.
3. "Which complaint measure does the team look at first each month: volumes, time to resolve, or repeat contacts?" Why it lands: monthly reporting is in the JD, and the question names the measures without assuming which one matters.
4. "How is the digital self-service plan being set against the complaint drivers it is meant to reduce?" Why it lands: the 40% digital target is the strategy's test, and this asks how it is being measured.
5. For a branch manager on the panel: "What would a new Member Experience Lead do in their first month that would genuinely help your branches?" Why it lands: a reciprocity question for a future peer, which turns the panel from scoring into a working conversation.
6. "When Own the Fix and a monthly target pull against each other here, which one wins?" Why it lands: it asks directly how the values operate under pressure, which the panel scores.

## 8. Prohibited claims

What this pack will not coach, and why. Each entry names its basis and its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end across branches | Inflated form of F3 | F3's quote at its own scope: "I handled the branch's formal complaints log." Limit, as this pack's observation: the material shows one branch's log, not a process across branches. |
| Worked in a contact centre, or ran contact-centre complaints | Stated absence, F10 | "I've never worked in a contact centre." |
| Presented to senior leaders | Stated absence, F8 | "I've never presented to anyone above regional level." |
| Reported resolution times | Inflated form of F5 | F4's quote at its own scope. Limit, as this pack's observation: the material shows a volumes spreadsheet and no resolution times. |
| Coached branch supervisors on escalations | Inflated form of F6 | "trained new tellers on our escalation script" |
| Advanced Excel reporting | Inflated form of F9 | "I built the monthly complaints spreadsheet our regional manager uses" |
| Handled regulated complaints under regulatory timelines | Inflated form of F2 | "I handled the branch's formal complaints log." |

## 9. Sources

**Provided documents:** the JD text, your background, the recruiter's email, the 2026 strategy brief as you summarised it, and the values as you copied them on 11 November 2026.

**Searches and fetches, with what came back:**

1. Fetch: https://ashgrovecu.org/about/values. Returned the four values, matching your copied text word for word.
2. Search: "Ashgrove Credit Union values". Returned the values page above.
3. Search: "Ashgrove Credit Union interview process Member Experience Lead". Returned https://ashgrovecu.org/careers/how-we-hire: "Most roles have three rounds: a recruiter call, a conversation with the hiring manager, and a panel that includes a short case and scores against our four values."

**Research tier: L1, searches 2 of 6, fetches 1 of 2**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | yes | Values cheat sheet, section 6. The four names and wording are confirmed against the official page. |
| 2. Interview process, Member Experience Lead | yes | Loop structure and persona weights. The process page corroborates three rounds and a values-scored panel. |
| 3. Strategy and recent news | skipped | The strategy brief you supplied fixes current priorities and recent moves. |
| 4. Interviewer name | n/a | No names were given, so there was no query to form. |
| 5. Representative JD for the title | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions. |

## 10. Upgrade menu

- Your CV, or a fuller account of your work → turns F5 (resolution times) and F7 (digital-team work) from discovery into quoted rows, if the material shows them. Nothing will be added that is not in it.
- Names for the Head of Member Services and the two branch managers → persona weights per interviewer, and a reverse question tied to their public career path, from public professional footprint only.
- The recruiter's guidance for round 1, if it names focus areas → coverage for that round.
- Deep research (L2): the official strategy page, interviewer talks, and recent loop reports for this role family. This is up to six more searches and two more fetches. It is offered once, and runs only if you ask.
- Any real example of a contact-centre or senior-presentation experience, however small → would turn F8 and F10 from stated absences into quoted rows. It would not be invented.
- Your prep time before 20 November → a prioritised prep schedule (section 3 of the template).
