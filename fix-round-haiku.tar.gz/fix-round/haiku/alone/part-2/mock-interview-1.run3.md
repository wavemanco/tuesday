I couldn't run web research: all three search calls were refused for lack of permission. The pack is built from your brief, the JD highlights, your research note and the interviewer profile you described. I'll record that in the Sources section.
Your prep pack is saved as /tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-alone-part-2-rooms-case-1-denied-5a5d7378/6f1ae717-a368-4328-ba06-00229816fcfd/scratchpad/northwind_senior-gtm-strategy-lead-emerging-products_interview_pack.md.

It has 21 questions across six personas, weighted toward the Data-Driven Prober and the Peer Evaluator because Dan is a peer and describes himself as "relentlessly data-driven." Each question carries its type, its provenance quote from Priya's material, answer guidance and a rationale. The biggest rehearsal priority is the sales-ops and quota gap (D1). The $400M figure gets the most probing (A1 and E2).

Two things to know:
- **No web research ran.** All three searches were refused for lack of permission, so the values cheat sheet and the interview-process detail are missing. If you can enable search, I'll re-run them.
- **The fit snapshot uses your highlights, not the full JD.** A full JD and Priya's CV would firm up several rows.

Would you like me to play the Skeptic on D1, the sales-ops and quota gap? I can also save a tuesday-dossier.md recording the gaps this prep exposed, for later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

Can you paste the full JD and Priya's CV?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: northwind_senior-gtm-strategy-lead-emerging-products_interview_pack.md -----
# Interview prep pack: Senior GTM Strategy Lead, Emerging Products, Northwind Data

**Candidate:** Priya. **Interviewer:** Dan Kovac, Director of Sales Strategy. **Relationship:** peer, same VP. **Format:** one 60-minute conversation.
**Built from:** the coach's notes on Priya's background, the JD highlights, your research note on Northwind, and the interviewer profile as you described it. No web research ran (see Sources).

## 1. How to use

- **Personas** describe how a question is asked (tone, pace, follow-up style). **Types** describe what is being scored.
- **Type key:** EXP = work-experience deep-dive, whether claims survive scrutiny. JD = role and JD-driven, can she do the listed job including its gaps. CASE = live problem, structure and reasoning. VAL = behavioral and values fit. CO = company and strategy knowledge.
- Guidance is scaffolding, not a script. Rehearse it until you can say it in your own words. Never memorise a line you could not defend under a second follow-up.
- Answer slots (sentences ending in "say so plainly") are instructions for the interview, not questions. They tell you what to say whichever way the facts go.

## 2. Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" (JD highlights) | "proposed a store-surface change credited with a ~$400M ARR uplift" (the coach's notes) | medium | [grounded] | transferability | Your material says you proposed a change and that it is credited with an outcome. It does not show you owning a go-to-market for a product line. Say the proposal in those terms. Answer slot: if you owned any part of taking that change to market, such as rollout sequencing or which accounts it went to, say which and how you decided, in your own words. If you proposed it and others ran it, say so plainly and describe your part. |
| F2 | "identify whitespace across land/adopt/expand/renew" (JD highlights) | "set annual volume targets with cross-org consensus" (the coach's notes) | medium | [grounded] | transferability | Volume targets are a set-the-number artifact, not whitespace across the lifecycle. Your material does not show segment or lifecycle-stage analysis. Answer slot: if you have located an unserved segment or stage from data, say how; if not, say so and say what you would examine first. |
| F3 | "run independent analysis in SQL and Tableau" (JD highlights) | "skilled in SQL/Tableau" (the coach's notes) | low | [inferred] | discovery | "Skilled in" is a claim with nothing inspected behind it, so do not assert it as a story. Answer slot: name one SQL or Tableau analysis you ran yourself, end to end, and the question it answered. If none comes to mind, say so and describe how you would approach the first question in this role. |
| F4 | "partner-motion design experience required" (JD highlights) | "built a partner-level revenue model used in carrier negotiations" (the coach's notes) | medium | [grounded] | transferability | Carriers are the partners in your material. The model was used in negotiations. Your material does not show designing a partner motion: programme terms, enablement, or partner recruitment. Answer slot: if you shaped partner terms or programme economics beyond the model, say which and how you decided. If the model was your piece only, say so and say what it fed. |
| F5 | "strong cross-functional influence" (JD highlights) | "set annual volume targets with cross-org consensus" (the coach's notes) | medium | [grounded] | presentation | The quote already reaches the requirement in other terms: cross-org consensus. Reword only, adding no practice: "I set annual volume targets with cross-org consensus." |
| F6 | "AI experience a plus" (JD highlights) | "uses AI tools daily" (the coach's notes) | low | [grounded] | transferability | This is usage, not building or launching AI. Say it as usage: "I use AI tools daily." Do not describe anything built with them. |
| F7 | "AI copilot launch ('Compass')" (your research note) | none given | none given | [grounded] | discovery | The material does not show go-to-market work on an AI product. Answer slot: name an AI-enabled product or feature you shaped the go-to-market for. If none, say so, then say how you would approach a copilot launch to existing accounts. |
| F8 | "enterprise expansion" (your research note) | none given | none given | [grounded] | discovery | The material does not show expansion motions on enterprise accounts. Answer slot: if you have designed an expansion or renewal motion for enterprise accounts, say which and what it changed. If not, say so and name the closest quote you have. |
| F9 | "reaching profitability" (your research note) | none given | none given | [grounded] | discovery | The material does not show a decision you took on margin or cost-to-serve. Answer slot: if you have shaped a decision on unit economics, say which and how it was measured. If not, say what you would test first. |
| F10 | "B2B SaaS go-to-market experience" (role-family expectation, not quoted from the JD) | "9 at a large consumer-tech company in product strategy & ops" (the coach's notes) | low | [generic] | transferability | Nine years of consumer-tech product strategy and ops is adjacent. Your material shows no enterprise buyers or B2B selling. Say the consumer-tech experience in its own terms and name what you would learn first. |
| F11 | "sales-ops and quota-setting fluency" (role-family expectation, not quoted from the JD) | none given | none given | [generic] | discovery | The coach's notes record no sales-ops or quota-setting experience. Confirm this with Priya in her own words before the interview. Answer slot: name any target-setting or sales-ops work you did, and say plainly where you have not worked on quotas. |

**Confidence and gap type do not match the JD.** The JD highlights are a sample. A full JD text would turn F2, F3 and F4 into exact quotes, and could add rows.

## 3. Prohibited claims

Built locally from the fit snapshot. These are claims a candidate reaches for under pressure, and this pack will not coach any of them.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the go-to-market for a product line | Inflated form of F1 ("proposed") | F1's quote at its own scope. The limit is the pack's observation: your material says "proposed", not "owned". |
| Designed the partner motion | Inflated form of F4 ("used in carrier negotiations") | F4's quote at its own scope. Your material says the model was used, not that you designed a partner programme. |
| Ran SQL or Tableau analysis independently at scale | Inflated form of F3 ("skilled in") | The pack's observation that your material shows no inspected analysis. Slot F3 asks for one example, not a scale claim. |
| Built or launched AI products | Inflated form of F6 ("uses AI tools daily") | F6's quote at its own scope: usage. |
| Set quotas or ran sales-ops targets | Inflated form of F2 ("set annual volume targets") | F2's quote at its own scope: volume targets, with cross-org consensus. |

## 4. Reading the interviewer

- **Career pattern:** pricing and monetization roles, with one early-stage-startup chapter. This is the spine of his career.
- **Self-described style:** "relentlessly data-driven".
- **Implications:**
  1. Every number you give will be probed for its inputs and denominator. Know the weakest assumption before he names it.
  2. Case questions will tilt toward pricing, packaging and unit economics. Expect the whitespace and bundling problems to be framed as price and value questions.
  3. The startup chapter means builder stories land, and he may test your attitude to big-company pace.
  4. He will likely ask about the $400M figure, because it is the one number that sounds like a P&L.
- **Mirror opportunities:** monetization and ARR vocabulary are shared. You can say "ARR uplift" and "partner revenue model" in his language. No shared career jump appears in the profile, so none is offered.

## 5. Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy | Weight |
|---|---|---|---|---|
| Data-Driven Prober | Reads the revenue model and the $400M figure line by line. Asks for inputs, denominators and validation. Follow-ups go two levels deeper. | High. His self-described "relentlessly data-driven" and his pricing spine both put the Prober first. | Know what you can say about how each number was counted, and say plainly when you do not know. Name the weakest assumption first. | 5 questions |
| Peer Evaluator | Seam-splitting between sales strategy and emerging products. "What would you need from me?" Credit-sharing probes. | High. He is a peer on the same VP, so the relationship prior is peer-led and he is pricing what the hire costs his work. | Propose seam principles rather than pretending to know the seam. Offer reciprocity. | 5 questions |
| Case / Strategist | Live problems on the two product lines, enterprise expansion, the Compass launch and the bundling threat. | Medium. The JD asks for whitespace and GTM strategy, which are case-shaped. | Clarify, then objective, segmentation, approach, metrics, risks. Name the price lens early. | 4 questions |
| Skeptic | Probes the sales-ops and quota gap and the consumer-tech background. | Medium. The gaps in F9, F10 and F11 are where a peer would press. | Rehearse the single most predictable objection until it is calm. Concede plainly. | 3 questions |
| Pressure / Stress | Time-boxed challenge on the $400M figure and on enterprise expansion. | Low. A peer is less likely to interrupt, but the figure is the one thing he could press hard. | Pause. Hold the position through two follow-ups, then concede only what is real. | 2 questions |
| Conversational / Rapport | Opens with the journey and closes with "anything you want to ask?" | Low. Rapport opens and closes peer conversations, and the reverse-question slot counts. | A pre-scripted 90-second arc. Treat casual AI questions as scored. | 2 questions |

## 6. Question banks

**Data-Driven Prober (weight 5)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how the ~$400M ARR figure was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (the coach's notes) | Say what you know about how the figure was counted, in your own words. Name the weakest assumption before he does. Answer slot: if you know how the figure was attributed, say how; if you do not, say so plainly and say who would know. Hold the word "credited" through a follow-up. | Headline number and the Prober's core probe. F1 is the row it draws on. |
| A2 | "Which assumption behind the partner-level revenue model would you defend least?" | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" (the coach's notes) | Name the assumption in your words, and say what the model fed. Answer slot: if you set the model's inputs, say which and how you chose them; if others set them, say so. | F4. Probers test the inputs of a model before the outcome. |
| A3 | "Tell me about an analysis you ran in SQL or Tableau and the question it answered." | EXP | [inferred] "skilled in SQL/Tableau" (the coach's notes) | Open prompt. Pick the most recent analysis you ran yourself: the question, the data source, and what changed. If none comes to mind, say so, then describe how you would approach the first question in this role. | F3 is low confidence, so this is a discovery prompt, not an assertion. The JD's "run independent analysis" is the raising source. |
| A4 | "How would you find under-served land, adopt, expand and renew segments in our data? What denominator would you use?" | JD | [generic] role-family pattern, not a claim about your past | Name the denominator, and name the data field you would distrust most. Do not claim past work. | JD whitespace requirement, asked as a live problem. The denominator question is the Prober's signature. |
| A5 | "How did you arrive at the annual volume targets, and what did you do when the orgs disagreed?" | EXP | [grounded] "set annual volume targets with cross-org consensus" (the coach's notes) | Say what consensus meant in practice, in your words. Answer slot: if the orgs disagreed, say what you did; if the targets were agreed without contest, say so and what you checked. | F2 and F5. The second branch lets the disagreement never have happened. |

**Peer Evaluator (weight 5)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our teams sit side by side. Where's the seam with your work, and what happens when we disagree?" | VAL | [generic] peer persona stem | Propose seam principles, not a map you do not have. Answer slot: if you have disagreed with an equal on a shared decision, say what it was and how you settled it; if not, say so and say how you would settle one. | Peer stem. F5 cross-functional influence is the raising source. |
| B2 | "How do you handle credit when work spans sales strategy and product?" | VAL | [generic] peer persona stem | Name the principle you use, and the one time it was tested only if you can say it plainly. Do not claim a credit dispute you have not described. | Peer stem. Credit is the most common collegial probe. |
| B3 | "Partner terms are pricing. Where would you draw the line between partner-motion design and pricing?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" (the coach's notes) | Say what the model did and where pricing decisions sat. Answer slot: if you set terms, say which; if others set them, say so and what you fed in. | F4 and the JD's partner-motion requirement. The question does not presuppose you designed the motion. |
| B4 | "You've been in consumer tech for nine years. What does a B2B data-infrastructure deal look like that consumer tech does not prepare you for?" | JD | [grounded] "9 at a large consumer-tech company in product strategy & ops" (the coach's notes) | Name what you know and what you would learn first. Do not claim B2B experience. | F10. The honest answer is the limit, given as a plan. |
| B5 | "Who would you need to align with on expansion whitespace, and where would you expect to be pushed?" | JD | [generic] peer persona stem | Name the functions and the trade you would offer each. No past claim. | Your research note's enterprise expansion priority, asked as a seam question. |

**Case / Strategist (weight 4)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "How would you structure go-to-market for an AI copilot launch to existing enterprise accounts?" | CASE | [grounded] "AI copilot launch ('Compass')" (your research note) | Clarify: what the copilot does and for whom. Objective, then segmentation, approach, metrics, risks. Name the pricing choice early, given his pricing spine. | F7 and the research note's Compass priority. Live problem, no claim about your past. |
| C2 | "Enterprise expansion is the priority. Where is the whitespace across land, adopt, expand and renew, and how would you size it?" | CASE | [grounded] "identify whitespace across land/adopt/expand/renew" (JD highlights) | Clarify the product line and the segment first. Segment by tier and usage. Name the denominator, the metric, and the risk. Use packaging and unit economics as the lens. | The JD's core task, asked as a case. The pricing lens matches his career. |
| C3 | "Bundling by a much larger platform vendor is the main threat. What do you do in the next 90 days?" | CO | [grounded] "main competitive threat is bundling by a much larger platform vendor" (your research note) | Restate the threat. Challenge one premise, for example whether bundled buyers are our buyers. Propose a test, and name what would change your mind. Do not recite a shared competitive list. | CO from the research note, since no live research ran. Differentiate, do not recite. |
| C4 | "Profitability is a stated priority. Which of the two product lines would you put on a margin path first, and why?" | CASE | [grounded] "reaching profitability" (your research note) | Pick one, state the metric, and name the assumption you would defend least. Do not claim a P&L you have not owned. | Profitability is a priority, and the choice is a live judgement call. |

**Skeptic (weight 3)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Which parts of sales operations or quota-setting would you need to learn first?" | JD | [grounded] "set annual volume targets with cross-org consensus" (the coach's notes) | Answer slot: name the adjacent target-setting you did, quoted at its own scope. Then say plainly which quota and sales-ops work you have not done. Do not claim quota work. | F11, the biggest gap. The honest answer is the limit plus a learning plan. |
| D2 | "Your nine years are in consumer tech. Why would a B2B team believe the lessons transfer?" | VAL | [grounded] "9 at a large consumer-tech company in product strategy & ops" (the coach's notes) | Make the transfer case from the quoted work and state its limit: no enterprise buyers shown. Answer slot: if you have sold to or worked with enterprise buyers, say how. If not, say so. | F10. The skeptic probes the most predictable objection. |
| D3 | "What would you be weakest at on day one?" | JD | [generic] skeptic persona stem | Name the weakest area honestly: sales operations and quota-setting (F11). Give a closure plan as a plan, not a past. | Skeptic stem, aimed at the gap in F11. |

**Pressure / Stress (weight 2)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who has run enterprise expansion?" | VAL | [generic] pressure persona stem | Hold: anchor in the revenue model and the volume targets. Concede: plainly and specifically, the expansion gap. Answer slot: if you have run an expansion motion, say which. If not, say so, then name the closest quote you have. Hold through two follow-ups before conceding anything real. | F8. Hold-then-concede. |
| E2 | "That $400M, how much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (the coach's notes) | Hold: you proposed the change, and the figure is credited to it. Concede: any share you cannot defend, specifically. Answer slot: say which part of the outcome was yours and which was not, in your words. Do not say the figure is yours alone. | The single sharpest probe on the headline figure. |

**Conversational / Rapport (weight 2)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey." | VAL | [grounded] "2 years strategy consulting at a top firm" and "9 at a large consumer-tech company in product strategy & ops" (the coach's notes) | A 90-second arc: two years of strategy consulting, nine years of product strategy and ops in consumer tech, and why you want this. Use only those words. | Casual openers are scored. The arc is pre-scripted, and it contains no claim you cannot defend. |
| G2 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" (the coach's notes) | Name the tools you use and what you use them for. Do not describe anything built. | F6. AI is a plus in the JD, asked casually. |

## 7. Requirement coverage

| JD or research requirement | Question IDs | Note |
|---|---|---|
| "own GTM strategy for two new product lines" | C4, A1, E2 | F1 |
| "identify whitespace across land/adopt/expand/renew" | C2, A4, B5 | F2 |
| "run independent analysis in SQL and Tableau" | A3 | F3 |
| "partner-motion design experience required" | B3, A2 | F4 |
| "strong cross-functional influence" | B1, A5 | F5 |
| "AI experience a plus" | G2, C1 | F6 |
| "AI copilot launch ('Compass')" | C1 | F7 |
| "enterprise expansion" | E1, B5 | F8 |
| "reaching profitability" | C4 | F9 |
| "B2B SaaS go-to-market experience" | B4, D2 | F10 |
| "sales-ops and quota-setting fluency" | D1, D3 | F11 |
| Bundling threat | C3 | Research note |

## 8. Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Your pricing career sits at the centre of how we think about launches. How did that shape the way you'd want a new line priced at launch?" | Ties to his own path and turns the interview into a peer conversation. |
| R2 | "What from your early-stage chapter do you still apply to a big-company launch?" | Shows you read his profile. Uses his startup chapter as the subject, not as flattery. |
| R3 | "What could a new person do in their first month that would genuinely help your team?" | Reciprocity question for a peer. It shows you are thinking about his load, not only your job. |
| R4 | "Which of the two product lines is most exposed to the bundling threat, in your view?" | Opens a strategy conversation at the company's altitude, without reciting the research. |
| R5 | "Where do sales strategy and emerging products disagree most today?" | Names the seam directly and invites him to show where the friction is. |
| R6 | "How are expansion and renewal targets split between your org and the product side?" | Turns the enterprise expansion priority into a question he can answer from his own remit. |

## 9. Prohibited claims: rules for this pack

- Every claim about your past rests on a quote in the fit snapshot or a question's provenance column.
- The pack will not coach any entry in section 3.
- Where a question asks about a number, a method, or an outcome you have not described, the guidance is an answer slot, not a script.

## 10. Sources

**Provided documents:**
- The coach's notes on Priya's background (two years of strategy consulting at a top firm; nine years in product strategy and ops at a large consumer-tech company; the partner-level revenue model; the volume targets; the store-surface change; SQL/Tableau; AI tools; the absence of sales-ops or quota-setting experience).
- JD highlights.
- Your research note on Northwind (three priorities; bundling threat).
- The interviewer profile, as you described it.

**Searches and fetches:** three searches sent; all three refused, so nothing was returned.
- "Northwind Data company values": refused.
- "Northwind Data Compass AI copilot launch": refused.
- "Northwind Data interview process Senior GTM Strategy Lead Emerging Products": refused.

**Research tier:** L1, searches 0 of 6 (all refused), fetches 0 of 2.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Northwind values | unavailable | Values cheat sheet. Dropped. The searches were refused. |
| 2. Northwind interview process | unavailable | Loop structure and persona weights. Persona weights rest on the relationship and the profile alone. |
| 3. Northwind strategy and recent news | unavailable | Current strategy vocabulary. The research note supplies the three priorities but not recent moves. |
| 4. Interviewer public footprint (Dan Kovac) | unavailable | Interviewer read. The profile you gave stands in. |
| 5. Representative JD | skipped | The JD highlights fix the requirements in the fit snapshot. A full JD is in the upgrade menu. |

## 11. Upgrade menu

- Full JD text → the six highlight rows become exact quotes, and the coverage table gains rows.
- Priya's CV → the evidence cells can quote her own sentences, and some medium or low rows may move.
- One SQL or Tableau artifact she can show → F3 moves from low toward high.
- Her own account of how the $400M figure was counted → answers A1 and E2 in her own words.
- Web search permission → values, interview process, Compass news and Dan's public footprint, which unlock the values cheat sheet and a grounding brief.
- Dan Kovac's public talks or writing → persona weights and reverse questions read from his footprint.
- Recruiter guidance on focus areas or a pre-declared deliverable → coverage of any take-home or presentation.
