Your prep pack is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-alone-part-2-rooms-case-7-canned-ac05654f/abe55d57-7de7-4c0c-833c-a0cf92c9c436/scratchpad/saltmarsh_live-operations-producer_interview_pack.md`. I built it as a hiring-manager round, since Tobias is Head of Live Operations.

The main points:

- **Highest-ROI prep is S1:** "You've run one title's calendar. Two titles is double the surface. Why should we believe you can run two?" Hold on your one-title calendar, concede that you haven't run two at once, and don't add to it under follow-ups.
- **Your real gaps are coordination, post-event review ownership, and in-app purchases.** The pack gives you plain acknowledgments for the things you've never done, and answer slots where your material is silent. It never gives you words for experience you don't have.
- **Tobias came from QA.** He gave a GDC 2026 talk, "Patch Notes Are a Promise," arguing that a live team is judged by how often its patch notes match what shipped. Your release checklist is your strongest link to that, and the pack includes reverse questions built on the talk.
- **Research was thin.** The company searches returned nothing, so there's no values page and no strategy brief. The pack says so in its Sources section.

I'd like you to answer one thing: is Tobias your hiring manager for this role, or is this a different round? If it's a peer or panel, the persona weights change.

If you can also tell me whether you ran any post-event review or coordinated design, art, and engineering on an update, I can turn those answer slots into real stories in the pack.

Want to run a live drill? I can play the Skeptic on S1 and push you through the follow-ups. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions, and convert the pack to Word if you'd like.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh_live-operations-producer_interview_pack.md -----
# Live Operations Producer — Saltmarsh Games
**Interviewer:** Tobias Wrenfield, Head of Live Operations
**Round:** 60 minutes, Friday. I've assumed a hiring-manager round, since your note didn't say otherwise. The persona weights below depend on that assumption.

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored.
- Type key: **JD** = a stated requirement. **EXP** = your own experience, tested closely. **CASE** = a live problem from the role. **CO** = company knowledge. **VAL** = values. No VAL or CO questions appear here: no published values were found, and the company searches returned nothing.
- Guidance is scaffolding, not a script. Each guidance cell should be speakable in 90–120 seconds. Use your own words.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | high | [grounded] | transferability | Your material shows one title, not two. Say it that way: "I ran the calendar for our main title." Answer slot: if you ever planned around a second title's dates or dependencies, say how; if you did not, say so and describe how you would split the work. |
| F2 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | high | [grounded] | none | The quote already says what the JD asks. Lead with its own terms: a weekly calendar, two years, one main title. |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | transferability | Presenting monthly numbers is adjacent to owning a post-event review, and the bridge should not stretch it. Answer slot: if you ran a review after an event, say what it changed; if you did not, say so and say what you would put in one. |
| F4 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | none | The quote reaches the requirement. Expect a probe on how a figure was counted (see P2). |
| F5 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses" — your message | high | [grounded] | presentation | Your quote carries the writing and the adoption. Reword only that: "I wrote the checklist QA still uses." Answer slot: how you run it on each release — say the steps you actually did. |
| F6 | "coordinate design, art, engineering and community teams on each update" — JD | none given | none given | [grounded] | discovery | Your material does not show coordinating four disciplines on an update. Answer slot: if you did, say which teams and how you kept them aligned; if you did not, say so and describe how you would start. |
| F7 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio" — your message | medium | [grounded] | transferability | The years are shown. Whether the title counts as live-service in the JD's sense is not stated; the calendar quote is the nearest evidence. Say the years and the title type plainly. |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses" — your message | medium | [grounded] | presentation | The checklist is written work that others use daily. Rewording only: "I wrote the checklist, and QA still uses it." Answer slot: name a written artifact you wrote that others acted on, if one exists. |

**Gap not in the JD, and raised by you:** you have never led a team. The JD asks you to coordinate, not to manage people. It is a likely probe, handled in the Skeptic bank (S3).

## Prohibited list

| Not coached | Basis | Honest form |
|---|---|---|
| Ran the live-events calendar for two titles | Inflated form of F1 | "I ran the calendar for our main title." The limit is my observation, not words for you: your material says one title. |
| Owned the post-event review | Inflated form of F3 | "I presented the monthly retention numbers to the studio head." No slot on a review you did not run. |
| Led a team | Negative you stated | "I haven't led a team." Plain acknowledgment, no slot. |
| Shipped or ran in-app purchase work | Negative you stated | "I have never worked on a game with in-app purchases." Plain acknowledgment, no slot. |

## Reading the interviewer

- **Career pattern (public):** Tobias Wrenfield is Head of Live Operations at Saltmarsh Games and previously a QA lead at a console studio. His GDC 2026 talk, "Patch Notes Are a Promise," argues that a live team is judged by how often its patch notes describe what actually shipped.
- **Implications:**
  1. Expect QA-rigor probes. Your release checklist is the strongest thing you bring to his world, so know its steps cold.
  2. Accuracy beats volume. Answers about what shipped matter more than answers about how much.
  3. Do not claim QA expertise you did not have. He will know the difference.
- **Mirror opportunity:** his talk's theme sits next to your checklist quote (F5). Use it in the reverse questions, not as a claim about your past.
- **Shared jump:** none offered. Your material does not show a QA-to-live move on your side, so I have not paired your history with his.

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | Live problems from the role: sequencing, diagnosis, coordination | Highest. A hiring manager buys capability on the actual roadmap; the JD is mostly live-problem language | Clarify first, then structure, then metrics. Name one premise you would challenge. |
| Skeptic | Quiet probes on the gaps: one title, no leadership, no IAP | High. The gaps are visible on the page, and the hiring manager owns the risk | Rehearse the single most likely objection until it is plain; hold to the quote; concede the gap cleanly. |
| Data-Driven Prober | Assumptions behind the retention figure, how the calendar was tracked | Medium. JD names retention and KPIs; the CV has one retention quote | Know how each number was counted, or say you do not know. |
| Pressure | Time-boxed challenges to motive and ownership | Lower. A short hiring-manager round may still time-box | Pause, restate, hold through two follow-ups, then concede the specific point. |
| Conversational | Journey opener, casual hot-topic questions | Medium. Openers are scored | A 90-second arc from your quotes. Treat casual questions as scored. |
| Peer | Seams with QA and design | Low for a hiring manager, but the role coordinates four teams | Reciprocity framing; propose a seam principle, not a story. |
| Values | Not weighted | No published values were found, so there is no values round to target | Not built. |

## Question banks

### Case / Strategist (weight: top; 5 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Two titles. A content drop on one is scheduled the same week as an event on the other, and both need the same engineering squad. How do you sequence it?" | CASE | [generic] | Clarify: which squad, which dates are fixed, what the event costs if it slips. Then options: move the drop, split the squad, or cut scope. Name the metric you would check first. Make no claim about your past. | Tests the JD's two-title calendar requirement (F1). Generic because it is a live problem, not a fact about you. |
| C2 | "Day-two participation on a launch event fell 20% against plan. Walk me through your diagnosis." | CASE | [generic] | Check instrumentation first, then segments (new versus returning players), then event mechanics, then release issues. Say what data you would ask for. | Tests the KPI ownership requirement (F3, F4). |
| C3 | "Four disciplines on every update, and none of them report to you. What do your first two weeks look like?" | CASE | [generic] | Structure the two weeks: meet each lead, learn the update cadence, agree one shared checklist. Do not describe past coordination. Answer slot from F6: if you have coordinated four disciplines before, say which and how; if you have not, say so and say how you would start. | Tests the coordination requirement (F6), which your material does not show. |
| C4 | "Write the post-event note for an event that missed its target. What goes in the first paragraph?" | JD | [generic] | A short written exercise: the outcome against target, the likely cause, the one decision needed. Speak it as you would write it. | Tests the clear written communication requirement. |
| C5 | "Suppose an event includes a paid offer. Which metric would you watch that a free event would not need?" | CASE | [grounded] "I have never worked on a game with in-app purchases." (your message) | Plainly: "I haven't worked on a game with in-app purchases." Then reason from the mechanism: conversion on the offer, spend per paying player, and whether the offer shifts the calendar. Do not claim IAP experience. | Monetization is the natural live-ops probe for a mobile studio. The question is hypothetical so it presupposes no paid offer in your past. |

### Skeptic (weight: high; 4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| S1 | "You've run one title's calendar. Two titles is double the surface. Why should we believe you can run two?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | **Highest-ROI prep in this pack.** Hold: "I ran the calendar for our main title for two years." Concede: "I haven't run two at once." Return to what the one-title calendar taught: weekly cadence, and a checklist QA still uses. Answer slot: if you ever planned around a second title's dates, say how; if not, say so and say how you would split the work. Hold through two follow-ups by returning to the cadence, never by adding to it. | F1 is where the JD's two-title mandate presses hardest. This objection will arrive in some form, so it gets the deepest rehearsal. |
| S2 | "Owning the post-event review is a different job from presenting numbers. Did you run a post-event review?" | JD | [grounded] "Presented the monthly retention numbers to the studio head" (your message) | Say what you presented and to whom. Concede plainly: presenting monthly numbers is not owning a review. Answer slot: if you ran a review after an event, say what it changed; if not, say so and say what you would include. | F3 is the adjacent work and the JD's owned requirement. |
| S3 | "You haven't led a team. Why is this your next step?" | JD | [grounded] "Never led a team" (your message) | Plain acknowledgment: "I haven't led a team." Then the JD's own words: the role asks you to coordinate design, art, engineering and community on each update. Answer slot: if you have coordinated across teams without authority, say how; if not, say so and say how you would earn their trust. | The likely motivation probe. The JD raises coordination, not management, so the answer addresses coordination. |
| S4 | "No in-app purchase experience. What do you think you'd get wrong first?" | JD | [grounded] "I have never worked on a game with in-app purchases." (your message) | Plain acknowledgment, then name one plausible first mistake, such as timing a paid offer against the calendar. Do not claim IAP work. | Honest calibration. Naming a plausible first error reads better than a bluff. |

### Data-Driven Prober (weight: medium; 3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "How did you know a content drop went out on schedule?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | Answer slot: if you tracked on-time delivery, say how and what counted as on time; if you did not, say so and say what you would track. | Tests whether your calendar claim survives a question about measurement. The question presupposes tracking only if the quote carries it, so the guidance holds a slot. |
| P2 | "Pick one retention figure you presented. Which assumption behind it would you defend least?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" (your message) | Name the weakest assumption you know of before they do. Answer slot: if you know how the figure was counted, say so; if you do not, say plainly that you do not know. | F4. Defend-the-number slot: you can only defend what you can repeat. |
| P3 | "What number on a live title moves before retention does?" | JD | [generic] | Name a leading indicator, such as session starts or event participation, and say why it leads. Do not claim you tracked it unless you did. | Tests the retention requirement without assuming your history. |

### Pressure (weight: lower; 2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| X1 | "Sixty seconds: why you over a candidate who has run a live title?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | Pause, restate, then anchor in the calendar. Hold the position through two follow-ups. Concede the specific point: you have not run two titles at once. | Tests composure under a time box. |
| X2 | "That checklist. How much of it was actually you?" | EXP | [grounded] "Wrote the release checklist our QA team still uses" (your message) | Hold: "I wrote it." Concede: QA's changes since then are theirs. Answer slot: if you still own parts of it, say which; if not, say so. | F5. Tests whether you can separate your work from the team's. |

### Conversational (weight: lower; 2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V1 | "So, walk me through the journey." | JD | [grounded] "4 years as an associate producer at a puzzle-game studio" (your message); [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | A 90-second arc: four years, a puzzle-game studio, the content-drop calendar, the checklist, presenting retention. Stop there. | Opener, but scored on communication economy and on the JD's live-service and calendar requirements (F7, F2). |
| V2 | "What are you playing right now?" | JD | [generic] | Name a game you have played and why it keeps you engaged, in terms of its live updates if you can. Do not invent an analysis you have not done. | Casual, but tests live-game fluency. |

### Peer (weight: low; 2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "QA signs off the checklist; design wants the date. Where's the seam, and what happens when you disagree?" | JD | [generic] | Propose a principle: the release gate follows QA sign-off, and the calendar moves before the gate does. Name how you would escalate. Make no claim about past disagreements. | Tests the seam between QA and the calendar, which the JD names. |
| E2 | "How do you handle credit when work spans teams?" | JD | [generic] | Credit the people who found problems, such as QA. Keep it general. | Reciprocity framing for the coordination requirement. |

### Requirement coverage

| JD requirement | Questions |
|---|---|
| Plan and run the calendar for two titles | C1, S1, R4 |
| Coordinate design, art, engineering and community | C3, S3, E1, E2 |
| Own the post-event review and KPIs | C2, S2, P1 |
| Manage the release checklist with QA | X2, E1, R4 |
| 3+ years live-service | V1 |
| Experience running a content calendar | P1, V1 |
| Player-retention metrics | P2, P3 |
| Clear written communication | C4 |

## Reverse questions

Ask at least five. Each includes why it lands.

| # | Question | Why it lands |
|---|---|---|
| R1 | "Your GDC 2026 talk argues that patch notes should describe what actually shipped. Where does that break down on a live calendar?" | Ties to his own published path and talk, showing you read him, not only the company. |
| R2 | "You moved from QA lead into live operations. What did the QA years change about how you plan a live calendar?" | A peer conversation about his career path, not an interrogation. |
| R3 | "Who reads the post-event review, and which KPI are they judged on?" | Shows you think the review is a decision tool. |
| R4 | "Who owns the release checklist today: QA, producers, or both?" | Tests the shared-ownership question the JD leaves open. |
| R5 | "What would a strong first 90 days look like across the two titles?" | Makes the interviewer describe success in concrete terms. |

## Sources

- **Provided documents:** your message (background and gaps); the job description as pasted.
- **Searches and fetches:**
  - "Saltmarsh Games mobile studio live operations": no results. Nothing attributable about the company was found.
  - "Tobias Wrenfield Head of Live Operations": one result, the GDC 2026 talk page at talks.gdconf.example/2026/patch-notes-are-a-promise, which describes him as Head of Live Operations at Saltmarsh Games and previously a QA lead at a console studio.
  - No pages were fetched.
- **Research tier:** L1 — searches 2 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | unavailable | Values cheat sheet, if a values page existed. No values page was reachable, and the company query returned nothing. |
| 2. Saltmarsh Games interview process, live operations | yes | The company query returned no results, so the loop structure is not established. Persona weights rest on the round assumption. |
| 3. Saltmarsh Games strategy and recent news | unavailable | Could have moved the CO bank and the grounding brief. Not sent, because the company query returned nothing. |
| 4. Tobias Wrenfield Saltmarsh Games | yes | Reading the interviewer, the reverse questions R1 and R2, and the QA-rigor implication |
| 5. Representative live operations producer JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions. |

## Upgrade menu

- Tobias's confirmed role in the loop → confirms or reweights the persona table
- Your answer on whether you ran a post-event review → upgrades F3 and S2 from an answer slot to a story
- Your answer on coordinating design, art, engineering and community → upgrades F6 and C3
- Your answer on tracking on-time delivery → upgrades P1
- A company values page, pasted → a values cheat sheet and a values round check
- The recruiter's note on process details → confirms the loop structure
- Deep research (L2, offered once) → a strategy brief and recent Saltmarsh context
