Your prep pack is saved as /tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-alone-part-2-rooms-case-2-denied-be26f8b1/5e61f351-541e-4270-853c-61c0d9a18edb/scratchpad/atlas-freight_operations-manager_interview_pack.md. I built it as a hiring-manager round, since your note didn't say who you're meeting.

Web search was refused in this session, so the pack has nothing on Atlas Freight's values, interview process or strategy. Everything about the company comes from the JD you pasted. The Skeptic and Case questions don't need that research, but the company-knowledge questions are missing, and the values-style questions rest on general patterns.

The biggest gap is leadership scope. You manage three supervisors, and the role leads twelve, with a 5+ year leadership requirement. Question A1 is the one to rehearse hardest.

Say the word and I'll play the Skeptic on A1 as a live drill. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

Who are you meeting, and in what round: your future manager, a peer, a skip-level, or a recruiter screen? The answer reweights every bank.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: atlas-freight_operations-manager_interview_pack.md -----
# Interview prep pack: Operations Manager, Atlas Freight

**Interviewer:** not given. **Round:** not given. Built as a hiring-manager round by default (see Persona table).
**Changelog:** first version.

## How to use

- **Personas** describe how a question is asked. **Types** describe what is being scored.
- Type key: **JD** = a requirement from the job description. **EXP** = your past work, with attribution checked. **CASE** = a live problem for the role. **CO** = company knowledge (none here, because company research did not run). **VAL** = behavioral, looking for a specific example.
- Guidance is scaffolding, not a script. Each cell is written to be spoken in 90 to 120 seconds, in your own words.
- Answer slots are instructions for the interview, not questions to answer here. Each one has two honest branches: one where you did it, one where you did not.

## Fit snapshot

Requirements are quoted from the JD you pasted. Evidence is quoted from your message. Nothing in the evidence column is a summary.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "lead a team of 12 supervisors" (JD) | "currently a senior shift manager over 3 supervisors" (your message) | medium | [grounded] | transferability | Your material says over three supervisors, not twelve, and the words stay there: "I'm a senior shift manager over three supervisors." Answer slot: if you have led more people than those supervisors, or a team of teams, say which and how you ran it, in your own words. If you have not, say so plainly, then say how you would lead twelve, as a plan and never as a past. |
| F2 | "5+ years operations leadership required" (JD) | "7 years in warehouse and distribution ops" (your message) | low | [grounded] | discovery | Seven years is operations time. Your material does not show how many of those years were in a leadership role. Answer slot: how many years you have led people, and in what role. If it is fewer than five, say so plainly and give the seven years in the message's own terms. |
| F3 | "drive on-time performance and cost-per-shipment down" (JD) | "cut mis-pick rate 40% by redesigning the pick path" (your message) | medium | [grounded] | transferability | The quote is pick accuracy, not timeliness or cost. Bridge: "I cut the mis-pick rate by 40 percent by redesigning the pick path." Stop there. Linking it to on-time or cost is a step this material does not show. Answer slot: if the redesign moved timeliness or cost per shipment, say what you measured and how. If it did not, say so and stay with pick accuracy. |
| F4 | "Own daily terminal operations across 4 sites" (JD) | "ran the site's peak-season surge plan two years running" (your message) | low | [grounded] | discovery | Your material describes one site. It does not show multi-site work. Answer slot: if you have run operations across more than one site, say which and how. If you have run one site, say so and give that site's scope in your own words. |
| F5 | "build reporting in Excel/Power BI" (JD) | "solid Excel" (your message) | low | [grounded] | discovery | The quote touches Excel without showing any report built. Answer slot: if you have built a report that people used to decide something, name it and what it fed. If you have used Excel without building one others relied on, say so plainly. |
| F6 | "build reporting in Excel/Power BI" (JD) | "never used Power BI" (your message) | none | [grounded] | capability | A stated absence. Words: "I haven't used Power BI." Then how you would learn it, said as a plan. Never a claim to Power BI work. |
| F7 | "Lean/Six Sigma a plus" (JD) | "Green belt certified" (your message) | medium | [grounded] | none | The quote already reaches the requirement, but the certificate has not been inspected. Lead with it in these words: "I'm Green Belt certified." Expect a probe on which project it sits behind. The material does not show that, so do not supply it. |

Gate check: no requirement in the JD is a term or credential bar (authorization, licence, location, schedule, pay, travel). "5+ years" is a length of experience, so it is graded as F2, not as a gate.

## Prohibited claims

Built locally from the fit snapshot. These are the claims a candidate reaches for under pressure. Nothing in the banks below asserts, softens or implies any of them.

| Not coached | Basis | Honest form |
|---|---|---|
| Leads or has led 12 supervisors | Inflated form of F1 | F1's quote at its own scope. The limit is this pack's observation: your material says over three supervisors. A1's slot stays inside the three. |
| Seven years of leadership, or five-plus years leading operations | Inflated form of F2 | F2's quote at its own scope: seven years in ops. The leadership years are the answer slot. |
| Ran operations across four sites | Inflated form of F4 | F4's quote at its own scope: one site's surge plan. The limit is this pack's observation: your material describes one site. |
| Designed the whole pick system, or led the pick redesign alone | Inflated form of F3's quote | The quote at its own scope: "redesigning the pick path." C3's slot asks which part was yours. |
| Moved on-time performance or cost per shipment | Requirement that widens F3's quote | F3's quote at its own scope. A4's slot asks only what you moved. |
| Built reporting in Excel that others relied on | Inflated form of F5 | The quote "solid Excel" at its own scope. C4's slot asks what you built, if anything. |
| Built Power BI reporting, or any Power BI work | Stated negative, F6 | Plain acknowledgment: "I haven't used Power BI." No slot on Power BI work. |
| Delivered Six Sigma projects | Inflated form of F7 | "Green belt certified" at its own scope. No project is claimed. |

## Persona table

No interviewer profile and no documented loop were available, so the loop is not established. The pack uses the generic archetype: flat weights, said plainly. Within that, the relationship prior is a hiring manager, since they are buying operations capability and de-risking the leadership gap.

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet probing of the supervisor count and the leadership years | Top weight, 5 questions. F1 and F2 are the largest gaps against the JD, and a hiring manager's first job is to test them. | Rehearse the one predictable objection until it is plain. Name the limit before they do. Plan, not past, for anything not yet done. |
| Case / Strategist | Live terminal problems: on-time slippage, cost per shipment, peak staffing | 4 questions. The JD names two operational outcomes, and a hiring manager will test how you diagnose them. | Clarify, then define the metric, then segment by site, shift and lane, then approach, then risks. |
| Data-Driven Prober | Asks how the 40 percent was counted and which assumption is weakest | 4 questions. The 40 percent is your headline figure and it will be probed. | Know what you can say about the count. Say plainly what you do not know. Name the weakest assumption first. |
| Pressure / Stress | Time-boxed challenges to the pick-path claim and to your fit | 3 questions. Tests whether you hold a position without folding or getting defensive. | Pause, restate, hold through two follow-ups, then concede one specific thing. |
| Conversational / Rapport | Casual openers: the journey, Power BI | 2 questions. Casual is still scored. | A 90-second arc for the journey. Answer the Power BI question honestly, in one breath. |
| Peer Evaluator | Seams between sites and credit for shared fixes | 2 questions, low weight. Peers at other sites may sit on the panel. | Frame what you bring to their sites. Propose seam principles, not invented seams. |
| Values / Behavioral | Examples of hard truths and customer trade-offs | 2 questions, low weight. No values-style round is established, so this is a fallback. | Choose the example that fits. If none fits, say so plainly and give the nearest thing you can describe in your own words. |

## Question banks

### A. Skeptic (5 questions, top weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You manage over three supervisors today. This role leads twelve. What makes that jump credible?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" (your message) | **Highest-ROI prep in this pack.** Hold the position that the quote carries: "I'm a senior shift manager over three supervisors." Hold through two follow-ups by returning to the three and to the plan, never by adding people. Concede exactly what is true: "I haven't yet led twelve supervisors." Answer slot: if you have led more people than three, or a team of teams, say which and how. If not, say so, then describe how you would structure twelve supervisors across four sites in the first ninety days, as a plan. | F1 is the largest gap and the most likely objection. It is aimed at the leadership requirement, so it gets the deepest rehearsal. |
| A2 | "The role asks for five years of operations leadership. How many years have you held one?" | JD | [grounded] "7 years in warehouse and distribution ops" (your message) | Give the number of years you have led people, in your own words. Answer slot: if it is fewer than five, say so plainly, then give the seven years in the message's own terms: seven years in warehouse and distribution ops. Do not stretch the seven years into leadership years. | F2 is a discovery gap and the interviewer will test the number. The premise is the JD's, and the second branch lets it be false. |
| A3 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "never used Power BI" (your message) | Name the honest weak spot in one breath: "I haven't used Power BI." Then a ramp plan: which part of the reporting you would learn first, and how you would test it on a real report. Say it as a plan. | F6 is the stated capability gap. A plain, specific admission followed by a ramp plan is the strongest answer available. |
| A4 | "The role drives on-time performance and cost-per-shipment down. Which of those have you moved yourself?" | JD | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Answer slot: if you moved on-time performance or cost per shipment, name which one, what you measured and how you know. If you did not, say so plainly, then give the one you did move: pick accuracy, cut 40 percent by redesigning the pick path. Say what it did and did not touch. | F3 widens to a requirement the quote does not carry. The question asks about the requirement; the answer stays inside the quote. |
| A5 | "You're a senior shift manager now. Why this step, and why now?" | JD | [grounded] "currently a senior shift manager" (your message) | Answer with the content of the step, not the title: more sites, more supervisors, a wider remit. Give one true reason for now. If the honest reason is that you want the role, say that. Do not reach for a story you do not have. | Motivation is the skeptic's standard probe for a step up. The answer is only as strong as the reason you can state truthfully. |

### B. Case / Strategist (4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Four terminals, and on-time performance has slipped over the quarter. How would you diagnose it in your first thirty days?" | CASE | [generic] | Clarify first: what counts as on time, and over what period. Then segment by site, shift, lane and carrier. Then pick the two or three likeliest causes, the data you would pull, and the first action. Close on the risk that the fix moves the problem. | A live problem from the JD's on-time requirement across four sites. No claim about your past, so no provenance beyond the pattern. |
| B2 | "Cost per shipment is up while volume is flat. What do you look at first?" | CASE | [generic] | Define the cost per shipment and its inputs: labour, overtime, dwell, rework. Ask for the baseline and the period. Segment by site before you conclude. | Tests metric literacy under the JD's cost requirement. No claim about your past. |
| B3 | "Peak is six weeks away and two of your four sites are short on supervisors. What is your plan?" | CASE | [grounded] "ran the site's peak-season surge plan two years running" (your message) | Structure the answer: staffing gap, cross-site coverage, priorities by volume, what you would stop doing. Answer slot: if you bring in the surge plan you ran, say which steps were yours to set. If none were, say so and reason from first principles. | The JD names multi-site operations and this question tests them as a live plan. The guidance draws only on what the quote says you did. |
| B4 | "What would you put on the wall at each site, and why?" | CASE | [generic] | Name four or five measures and define each, one per line: on-time performance, cost per shipment, pick accuracy, labour productivity, exceptions. Say why each matters and what decision it drives. | Tests whether you can translate the JD's outcomes into a site-level view. No claim about your past. |

### C. Data-Driven Prober (4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the 40 percent mis-pick reduction was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Answer slot, defend-the-number: name the unit you counted, the period, and what the figure is sensitive to, in your own words. If you did not count it yourself, say so plainly and say what you can confirm. No method is supplied here. | The headline figure on your record is the one probers test. A number you cannot explain under a second question is worse than none. |
| C2 | "Which assumption behind that 40 percent would you defend least?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Weakest-assumption move: name the assumption you are least sure of before they name it. If you do not know which one, say you do not know, and say what you would check. | Turns a gotcha into a credibility gain. Same figure as C1, a different slot. |
| C3 | "Of the pick-path redesign, which part was yours and which was the team's?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Answer slot: name the part you did, in the message's terms, and any parts others made. If you did not carry out the redesign, say so plainly and say what you did do. | Attribution is what a prober checks first when a result is quoted. |
| C4 | "You list Excel as solid. What have you built in it that someone used to make a decision?" | EXP | [grounded] "solid Excel" (your message) | Answer slot: if you built a report that people relied on, name it and what it fed. If you used Excel for work but built no report others relied on, say so plainly, then describe the most complex thing you did in it. | F5 is a discovery gap and the JD asks for reporting. The open prompt asks you to choose an instance. |

### D. Pressure / Stress (3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over a candidate who has led twelve supervisors?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" (your message) | Pause, then restate the question. Hold the position on what you bring: the pick-path result and the peak plans you ran, as your message states them. Hold through two follow-ups. Concede one specific thing: "They have led more supervisors than I have." | Pressure tests composure on the same gap as A1. A specific concession beats a defensive hold. |
| D2 | "That mis-pick result. How much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Hold to the sentence: the 40 percent came from redesigning the pick path. Concede the specific part you cannot vouch for, which is usually the counting, not the change. Answer slot: if the redesign was shared, say which parts were yours. | Hold-then-concede on attribution. The held position is the quote; the concession is the part you cannot back. |
| D3 | "Argue against the pick-path change you made. Why was it wrong?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Hold the result. Name one real limit of the change, such as a cost it added or a case it did not fix, if you know one. If you do not know of one, say that plainly rather than inventing a flaw. | Pressure to argue against your own result. Inventing a flaw to look balanced is the trap. |

### E. Conversational / Rapport (2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | JD | [grounded] "7 years in warehouse and distribution ops" (your message); "currently a senior shift manager over 3 supervisors" (your message) | A 90-second arc: where you started, the pick-path result, the peak plans, and the step now. Use only the facts in those two quotes. | Casual openers are scored on economy and clarity. Pre-scripted arcs prevent rambling. |
| E2 | "What's your experience with Power BI?" | JD | [grounded] "never used Power BI" (your message) | Answer: "I haven't used Power BI." Then how you would learn it, and which report you would build first to prove it. Say it as a plan. | The JD names Power BI. Casual wording still scores the honest admission. |

### F. Peer Evaluator (2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Our teams sit side by side on the floor. Where's the seam between yours and mine, and what happens when we disagree?" | JD | [generic] | Propose seam principles, not invented seams: who owns inbound, who owns the dock, how a disagreement goes to the person who owns the number. Offer what you would bring to their site, not just what you need from it. | Peer-level probes about multi-site coverage. No claim about your past. |
| F2 | "When a fix spans two sites, how do you handle credit?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Answer slot: if others were in the redesign, name who did which part, in your words. If you did it alone, say so and say who you consulted. | Credit probes are how peers test for fairness. The honest answer is who did which part. |

### G. Values / Behavioral (2 questions, low weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you had to tell leadership something they did not want to hear." | VAL | [generic] | Selection scaffold: pick a time you told someone senior a hard operational truth. It needs a named stake, the moment you said it, and what happened after. If no such time comes to mind, say so plainly, then give the nearest thing you can describe in your own words. | No values round is established, so this is a fallback for the Values persona. Open prompt, no claim about your past. |
| G2 | "Tell me about a time you put a customer ahead of an internal number." | VAL | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Selection scaffold: pick a time a customer outcome beat an internal metric. If the pick-path change touched customers, say how, in your words. If it did not, say so plainly and give the nearest example you can state truthfully. | The nearest thing the material carries is the pick-path result. Its customer effect is not stated, so do not supply one. |

### Requirement coverage

| JD requirement | Questions |
|---|---|
| Own daily terminal operations across 4 sites | B1, B3, F1 |
| Drive on-time performance and cost-per-shipment down | A4, B1, B2 |
| Lead a team of 12 supervisors | A1, D1 |
| Build reporting in Excel/Power BI | C4, E2, A3 |
| 5+ years operations leadership required | A2 |
| Lean/Six Sigma a plus | none, and why: a plus, and F7's quote already reaches it, so a question would only repeat one sentence |

Session total: 22 questions. Within the 18 to 26 range.

## Reverse questions

No interviewer profile exists, so these are role-generic. Each one is a question you ask at the end.

1. "What does a strong first ninety days look like in this role, and what would tell you I'm on track?" Why it lands: turns the skeptic's test into success criteria you can plan against.
2. "Which of the four sites is hardest to hold on time, and what is the usual cause?" Why it lands: shows you are thinking about the JD's on-time requirement at site level.
3. "How are on-time performance and cost per shipment defined here, and who owns those numbers?" Why it lands: signals metric literacy and checks how the numbers are measured.
4. "What reporting do the supervisors use today, and where does it fall short?" Why it lands: maps directly to the reporting requirement and shows you will look for the gap.
5. "How is the supervisor team laid out across the four sites, and where is coverage thinnest?" Why it lands: shows you are planning for the team you would lead.
6. "What did the last person in this role do that you wish they had done differently?" Why it lands: a candid question that tends to get a candid answer.

## Sources

**Provided documents:** the job description and the background summary, both in your message. No CV was supplied.

**Search and fetch calls, all refused by the permission setting:**
- "Atlas Freight regional logistics company values": refused
- "Atlas Freight interview process operations manager": refused
- "Atlas Freight logistics strategy news terminals": refused

Nothing from the web is used in this pack. Company values, the interview loop and current strategy are not established. Everything about Atlas Freight in this pack comes from the JD you pasted.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Atlas Freight values | unavailable | Calls were refused, so no value names were established. Would have moved a values cheat sheet, if a values-style round were established. |
| 2. Atlas Freight interview process, operations manager | unavailable | Calls were refused, so the loop is not established. Would have moved the persona weights and the round structure. |
| 3. Atlas Freight strategy and recent news | unavailable | Calls were refused, so no strategy brief. Would have moved the CO questions, which are absent here. |
| 4. Interviewer name and company | n/a | No name was given, so there was no query to form. |
| 5. Representative operations manager JD | skipped | The JD you supplied fixes the fit snapshot and the JD questions. |

## Upgrade menu

- Permission to run web search, or paste Atlas's values page, careers or interview-guide page, and any recent news → values, loop structure and strategy become sourced, and the CO questions get written. Without it they stay generic.
- Who you are meeting and in what round → persona weights recomputed, and the reverse questions tuned to that person.
- The interviewer's name → a tailored reverse question and weights read from their public footprint.
- A recruiter note on round format, one email → confirms whether the loop is several sessions, and what each one holds.
- A certificate for the Green Belt, or a before-and-after pick-accuracy report → F3 and F7 move from medium to high confidence, and the 40 percent becomes checkable.
- A deeper research pass, up to 6 more searches and 2 more fetches, several more minutes → strategy brief, interviewer footprint and role-family loop reports. Offered once; say if you want it.
- A tuesday-dossier.md file → would record the gaps this prep exposed, for later sessions. Nothing here depends on it.
