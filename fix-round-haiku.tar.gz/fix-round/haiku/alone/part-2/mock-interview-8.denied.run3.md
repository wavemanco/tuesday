Your prep pack is saved as `Ashgrove-Credit-Union_member-experience-lead_interview_pack.md` and sent to you. I built it as a loop: one shared fit snapshot, then a mini-pack for each of the three rounds.

Two things you should know before you read it:

- **Web search was refused in this session**, so the pack runs only on what you pasted: your background, the JD, the values, the recruiter's email and the strategy brief. The values have not been checked against ashgrovecu.org.
- **The Head of Member Services and the panel members are not named**, so there is no interviewer read and the reverse questions are role-generic.

The pack's main points:

- **Your biggest gap is contact centres and presenting above regional level.** Question B3 (Round 2) is the one to rehearse first. It holds your branch complaints work, concedes the gaps plainly, and does not fold into "I can do it".
- **Your spreadsheet is your strongest artifact and your biggest exposure.** Expect questions on whether it tracked resolution times. The pack gives you an honest answer for both cases, and it does not assume either.
- **"Neighbours, Not Numbers" is the value most likely to catch you out.** Your spreadsheet is about counts. Round 2 (D3) and the panel (D5, D6) both test this.
- **The pack builds no stories you did not tell me.** Where your material has no matching story, the guidance gives you a selection prompt and an honest "if none comes to mind" branch.

I took your message's statements as the candidate's own words and did not ask anything further, since the round types, JD and background were all provided. If you want the pack as a Word document, or a drill with a persona on B3, say so.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Ashgrove-Credit-Union_member-experience-lead_interview_pack.md -----
# Ashgrove Credit Union: Member Experience Lead, interview prep pack

**Company:** Ashgrove Credit Union (member-owned, about 900 staff)
**Role:** Member Experience Lead
**Rounds:** three, on 20 November 2026. Interviewers beyond the roles are not yet named.
**Built:** 11 November 2026, from your message, the JD, the values you pasted, the recruiter's email and the strategy brief the recruiter sent.
**Research tier:** L1 requested; every search was refused (see Sources).

## How to use this pack

- **Personas** describe how a question is asked. **Types** describe what is being scored: VAL (values and behaviour), EXP (your past work, in detail), JD (the job's own requirements), CO (company and strategy), CASE (a live problem).
- Guidance is scaffolding for a spoken answer, not a script. Keep each answer to 90 to 120 seconds.
- **Answer slots** are instructions for the interview: they say what to say when the honest answer is "no" or "not mine". They are not questions to me.
- The highest-return rehearsal in the pack is **B3** (Round 2). Start there.

## Fit snapshot (shared across all three rounds)

Gap rows: none. The JD's requirements are experience and skills, not eligibility conditions, and the JD names no location, schedule or work-rights term. If it does carry one, see the upgrade menu.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" (JD) | "6 years in retail banking, the last 3 as a branch supervisor" (your message) | medium | [grounded] | none | The years line reaches the requirement in role-relevant terms. The material does not say how much of the six years was customer operations, so expect that probe. Give the years and the role as they were. |
| F2 | "experience handling regulated complaints" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | transferability | Formal complaints are adjacent to regulated ones. The material does not say the log carried regulatory rules or deadlines, and the bridge stays at the log's scope. Answer slot: if the log carried regulator timescales or reporting duties, say which and what you did; if it did not, say so plainly and say what "formal" meant in your branch. |
| F3 | "confident presenting to senior leaders" (JD) | "I've never presented to anyone above regional level" (your message) | none | [grounded] | capability | A gap that wording cannot close, and you have stated it. Words: "I haven't presented to anyone above regional level." Then how you would build the skill, said as a plan, never as a past. |
| F4 | "comfortable with Excel reporting" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | medium | [grounded] | none | The spreadsheet reaches the requirement directly. It is an artifact you could show, so expect a probe on how it works. |
| F5 | "Own the member complaints process end to end across branches" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | transferability | One branch's log is adjacent to end-to-end ownership across branches. The bridge stays at the log. Answer slot: if you held a complaint from first contact to close, say which steps were yours; if you did not hold one that far, say so and say where your part stopped. |
| F6 | "and the contact centre" (JD) | "Never worked in a contact centre" (your message) | none | [grounded] | capability | A stated absence. Words: "I haven't worked in a contact centre." Then how you would learn its complaint flows, said as a plan. |
| F7 | "report monthly on complaint volumes and resolution times" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | low | [inferred] | discovery | The spreadsheet touches monthly complaint reporting. The material does not show whether it counted volumes, resolution times, or both. Answer slot: if it tracked resolution times, say how they were measured, in your words; if it did not, say so and say what you would add first. |
| F8 | "coach branch supervisors on escalations" (JD) | "trained new tellers on our escalation script" (your message) | medium | [grounded] | transferability | Training tellers on the script is adjacent to coaching supervisors, and the quote names tellers. Answer slot: if you coached other supervisors on escalations, say how; if you did not, say so and say what you did train tellers on. |
| F9 | "work with digital teams on self-service journeys" (JD) | none given | none | [grounded] | discovery | The material is silent. Answer slot: if you worked with anyone on a digital or self-service change, say what you did; if you did not, say so and say what you would learn first. |

Gap types follow the routing rule in the template. Confidence grades your evidence; Provenance grades what this pack wrote about it.

## Grounding brief (from the strategy brief you pasted)

- **Three moves:** "move 40% of member service to digital channels by 2028"; "consolidate eight branches into five hubs over 2027"; "launch a small-business lending product in Q1 2027".
- **Main competitive pressure:** "the main competitive pressure is app-only banks".
- **Vocabulary to use:** member service, digital channels, hubs, small-business lending. Use the brief's words, not your own paraphrase.
- Nothing here is checked against a live source. The brief is as the recruiter relayed it.

## Prohibited claims

Built locally from the fit snapshot. Each entry names its basis and its honest form. No answer slot, hold or rationale in this pack asserts, softens or implies any of these.

| Not coached | Basis | Honest form |
|---|---|---|
| Ran a contact centre, or managed contact-centre complaints | Inflated form of F5 and F6 | The stated absence: "I haven't worked in a contact centre." The log at its own scope. |
| Presented to senior leaders or to an executive team | Negative you stated, F3 | "I haven't presented to anyone above regional level." No slot. |
| Wrote the escalation script or set the escalation policy | Inflated form of F8 | "I trained new tellers on our escalation script." The word "our" stays. |
| Coached branch supervisors on escalations | Inflated form of F8 | The teller training at its own scope. The E4 slot asks what you actually did. |
| Tracked resolution times, or improved complaint outcomes | Inflated form of F4 and F7 | The spreadsheet at its own scope. The pack's observation: your material says the spreadsheet, not what it tracked. |

## Round 1: recruiter screen, 30 minutes, with the recruiter

**Persona weights.** The recruiter screen prior is Conversational plus a light Skeptic. Depth 4 for Conversational, because the screen checks knockout requirements in a friendly register. Skeptic and Prober at 2 each: the Skeptic reads motivation and the stated gaps; the Prober targets the spreadsheet, the one inspectable claim you made.

| Persona | Weight | Why |
|---|---|---|
| Conversational / Rapport | 4 | Screen register; scored casually, including the JD's knockout items |
| Skeptic | 2 | Motivation and the two stated absences |
| Data-Driven Prober | 2 | The spreadsheet is the only artifact in the material |

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through your six years in retail banking." | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" (your message) | Story-mapped on F1: the six years, then the last three as a branch supervisor, in that order. Say what the branch's work was, in your own words. About 90 seconds. | F1 is the years requirement, the first knockout the screener checks. The open walk-through lets them check it. |
| A2 | "Why this role, and why now?" | VAL | [grounded] "I handled the branch's formal complaints log" (your message); [grounded] "Members First, Always — we decide from the member's side of the counter." (values as pasted) | One honest reason, tied to the complaints work you did, if it is your real reason. Do not quote the values back as a slogan. "Why now" in your own terms. | Motivation is screened here. The values can be cited only as your reason, not as a phrase. |
| A3 | "What have you read about where we are taking member service?" | CO | [grounded] "move 40% of member service to digital channels by 2028"; "consolidate eight branches into five hubs over 2027"; "the main competitive pressure is app-only banks" (recruiter's brief) | Name the three moves and the competitive pressure in the brief's own words. Say what you would want to learn about the hub plan, and say plainly what you have not seen. Claim no knowledge of internal plans. | Casual register, but scored. The brief is the source; no research was run, so this is the depth available. |
| A4 | "The role covers the contact centre as well as the branches. How would you approach that?" | JD | [grounded] "Own the member complaints process end to end across branches and the contact centre" (JD); [grounded] "Never worked in a contact centre" (your message) | Plain acknowledgment, then approach: "I haven't worked in a contact centre." Then learn the complaint flows first, then the people. This is a plan, not a past, so no slot. | F6 is the screener's knockout. The negative is yours, so the acknowledgment is allowed. |
| B1 | "You've been a branch supervisor for three years. Why leave the branch?" | EXP | [grounded] "the last 3 as a branch supervisor" (your message) | Give your reason in your own words. Your material gives none, so this pack supplies none. | Premised on the tenure you quoted. Motivation is the Skeptic's first cut. |
| B2 | "This role handles regulated complaints. What have you handled that carried regulatory rules or deadlines?" | JD | [grounded] "I handled the branch's formal complaints log" (your message) | Answer slot: if the log carried regulator timescales or reporting duties, say which and what you did. If it did not, say so plainly and say what "formal" meant in your branch. Do not borrow the word "regulated" for the log. | F2 is the requirement this question scores. The word "regulated" is the JD's, so the question may use it; it presumes no rules in your history. |
| C1 | "Tell me what the monthly complaints spreadsheet tracks." | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" (your message) | Say what it tracks and how you built it, in your words. Answer slot: if it tracked resolution times, say how they were measured; if it did not, say so and say what you would add first. | F4 and F7. An open walk-through of your one inspectable artifact. The probe will go to resolution times, which the JD names. |
| C2 | "Which part of that spreadsheet's reporting would you defend least?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" (your message) | Name the part you would defend least and the assumption behind it, in your own words, before they ask. If you cannot say how something was counted, say so plainly. | JD for the monthly-reporting and Excel requirements. The weakest-assumption move turns a gotcha into a credibility gain. |

## Round 2: Head of Member Services, 45 minutes, behavioural (your future manager)

**Persona weights.** The hiring-manager prior is Case plus Skeptic. The recruiter says this round is mostly behavioural, so Values/Behavioural moves to the top. The manager will test the two stated absences and the scope of your complaints work.

| Persona | Weight | Why |
|---|---|---|
| Values / Behavioural | 4 | Recruiter: "mostly behavioural" |
| Skeptic | 2 | Your stated absences and the scope of the log |
| Case / Strategist | 2 | Manager will check how you would run the process |

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell me about a time you decided something from the member's side of the counter." | VAL | [grounded] "I handled the branch's formal complaints log" (your message) | Open prompt on Members First, Always. Pick one real instance and tell it as it happened. If none comes to mind, say so plainly, then give the nearest thing the log carries, or how you would handle it. Pick a decision you made or influenced, a member's side named, and an outcome you can state. | The theme is the published value. The quote is the nearest story the material carries. |
| D2 | "Tell me about a time something you wrote or said had to be explained twice." | VAL | [grounded] "trained new tellers on our escalation script" (your message) | Open prompt on Plain Words. Choose a time a member or colleague needed a second explanation, and say what you changed. Honest branch: if none comes to mind, say so, then say how you taught the escalation script to tellers. Do not claim you wrote the script. | The value is scored. The teaching quote is the nearest story, and its word "our" limits the claim. |
| D3 | "When did a branch's local context change how you handled a complaint?" | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" (your message) | Open prompt on Neighbours, Not Numbers. The tension to name: a spreadsheet counts, and the value says each branch is part of its town. Choose a case where local context changed the handling. If none, say so, then say how you read the count alongside a branch's context. | The spreadsheet and the value pull against each other. The honest branch is the answer a manager will test. |
| D4 | "Tell me about a complaint you followed until it was solved, and what you did if it stalled." | VAL | [grounded] "I handled the branch's formal complaints log" (your message) | Open prompt on Own the Fix. Pick one complaint you held to closure. If you did not hold one to closure, say so and say where it passed to someone else. | The value is "whoever finds the problem keeps hold of it until it is solved". The second branch allows that you did not hold it. |
| B3 | "You've never worked in a contact centre and never presented above regional level. Why should we believe you can lead this?" | JD | [grounded] "Never worked in a contact centre" (your message); [grounded] "I've never presented to anyone above regional level" (your message); [grounded] "I handled the branch's formal complaints log" (your message) | **The highest-return rehearsal in this pack.** Hold: the complaints work you did is branch work, and the contact-centre part is what you would learn first. Hold through two follow-ups by returning to the log. Then concede specifically: contact-centre flows and presenting above regional level are not yet yours. Do not fold into "I can do it". Close with the first things you would do, as a plan. | This is the JD's most obvious gap and the question you will almost certainly get in some form. The question names only your own stated absences, so it is sourced. |
| B4 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre" (your message); [grounded] "I've never presented to anyone above regional level" (your message) | Name one gap plainly, then how you would close it. Do not list all of them. Digital and self-service: your material is silent, so answer slot: if you did any digital or self-service work, say so; if not, say what you have not done and what you would learn first. | The manager's version of the Skeptic probe. One honest gap with a plan scores better than a list. |
| E1 | "A member's complaint has been passed between a branch and the contact centre twice. You're asked to own it end to end. What do you do first?" | CASE | [grounded] "Own the member complaints process end to end across branches and the contact centre" (JD) | Clarify before structuring: who holds the complaint now, what the member has been told, and whether a regulatory clock is running. Then one owner, then the member's next contact. Name what you would want to know before you structure the answer. Cite no past cases. | A live problem from the JD's own line. It asks about no past and presumes nothing about you. |
| E2 | "Member service is moving to digital channels. Where do complaints get lost when a member switches channel mid-complaint?" | CASE | [grounded] "move 40% of member service to digital channels by 2028" (recruiter's brief); [grounded] "work with digital teams on self-service journeys" (JD) | Structure it: where the complaint record lives, who owns the handoff, what the member is told at each switch. Ask one question first: whether the 40% target counts complaints. Use the brief's own phrase, and say what you do not know about its design. | Ties the JD's digital requirement (F9) to the brief. It is a case, so it makes no claim about your past. |

## Round 3: panel of two branch managers, 60 minutes, values round and complaint-escalation case

The recruiter's words: "The panel is also the values round — they score against the four values." **The values cheat sheet lives with this round**, per the loop rule.

**Persona weights.** Values-style round prior: Values plus Conversational, with the 20-minute case pulling Case up. Pressure at 2 because branch managers will test attribution. Interviewer names unknown, so this is the round-type blend, not a per-member read.

| Persona | Weight | Why |
|---|---|---|
| Values / Behavioural | 3 | Recruiter: the panel scores against the four values |
| Case / Strategist | 3 | Recruiter: a 20-minute complaint-escalation case |
| Pressure / Stress | 2 | Branch managers testing whether the stories are yours |

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D5 | "Tell me about a time a member's need and a target pulled in different directions." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" (your message) | Open prompt on Members First, Always. Say whether a target was involved and what you chose. If none, say so, then say how the monthly reporting handled the same question. | The panel scores this value. The frame is the value's own; the spreadsheet is the nearest artifact. |
| D6 | "How would you make sure a branch manager in a small town feels the complaints process is hers?" | VAL | [grounded] "Neighbours, Not Numbers — every branch is part of its town" (values as pasted); [grounded] "the last 3 as a branch supervisor" (your message) | Speak from the supervisor side: what you needed from the process as a branch supervisor, in your words. Name one thing you would do first and one you would not do. | Panel values question. The only past claim rests on your tenure as a supervisor, nothing more. |
| D7 | "Tell me about a problem you found that was not yours to fix. What did you do with it?" | VAL | [grounded] "I handled the branch's formal complaints log" (your message) | Open prompt on Own the Fix. Pick one instance and say whether you kept hold, and what you did when it was not yours. If you did not keep hold, say so and say who did. | Own the Fix is scored. The second branch lets you say it was not yours. |
| E3 | "A member's fee complaint has been escalated to you from a branch on Friday afternoon. You have 20 minutes. Structure the first 20 minutes." | CASE | [grounded] "coach branch supervisors on escalations" (JD) | The recruiter's case, as described. Structure it: confirm the facts and the clock, decide who owns the next step, decide what the member hears and in what words, and what you would coach the supervisor on. Think aloud, and name one premise you would challenge. | The scenario is a generic escalation pattern. Its only grounded element is the JD's escalation line. |
| E4 | "Your branch supervisor has escalated a complaint badly. Coach her through the next one, live." | JD | [grounded] "coach branch supervisors on escalations" (JD); [grounded] "trained new tellers on our escalation script" (your message) | Role-play: ask what happened, what she needs to decide, and what the member should hear. Coach to the script and the value. Answer slot: if you have coached supervisors on escalations, say how; if you have not, say so and say how you coached tellers. | Scores the JD's coaching requirement (F8) as a live act. The second branch lets you say you have not coached supervisors. |
| E5 | "The bank is consolidating eight branches into five hubs over 2027. A branch manager asks what that means for her open complaints. What do you say?" | CO | [grounded] "consolidate eight branches into five hubs over 2027" (recruiter's brief) | Say what you would check first: which complaints are open, who will hold them after a move, and what the member is told. Do not speculate about hub staffing or decisions you do not know. | The strategy-grounded differentiator in the coverage rule. It uses only the brief's sentence. |
| F1 | "Sixty seconds: why should we hire you over someone who already runs a contact centre?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" (your message); [grounded] "I handled the branch's formal complaints log" (your message) | Hold on your six years and the log, said at their scope. Concede the contact centre plainly, then the first thing you would do. Claim no contact-centre experience. | Pressure stem. The rival is hypothetical; the question presumes no fact about you. |
| F2 | "That complaints log: what did you decide yourself, and what did the branch or the rules decide for you?" | EXP | [grounded] "I handled the branch's formal complaints log" (your message) | Answer slot: say which decisions were yours and which were set by policy or the rules, in your words. If none in the log was your decision, say so plainly and say what you did do. | Attribution probe on the one artifact you quoted. A decision you claim must be one you made. |

## Values cheat sheet (Round 3)

| Value (official name) | Working meaning (paraphrased) | Mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | F5: "I handled the branch's formal complaints log" (your message). A scaffold, not a finished story. Honest branch: if no member-side decision comes to mind, say so. |
| Plain Words | If a member needs it explained twice, it was written wrong | F8: "trained new tellers on our escalation script" (your message). Scaffold: a time an explanation had to be simplified. Honest branch: if none, say so. |
| Neighbours, Not Numbers | Every branch is part of its town | F4: "I built the monthly complaints spreadsheet our regional manager uses" (your message). The tension is the spreadsheet itself. Honest branch: if local context never changed a decision, say so. |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | F5: "I handled the branch's formal complaints log" (your message). Scaffold: one complaint you held to closure. Honest branch: if you did not hold one, say where it passed. |

## Reverse questions (at least one per round)

- **Round 1.** "What does a strong first 90 days in this role look like to you?" Why it lands: asks their definition of success, which a screener notes as preparation.
- **Round 1.** "Which of the three moves in the strategy does the complaints team hear about first?" Why it lands: ties the question to the brief you were sent, not a generic one.
- **Round 2.** "Which complaint in the queue this month would you want the new person to own first?" Why it lands: tests the Own the Fix value in practice and signals you would take it on.
- **Round 2.** "As branches move into hubs in 2027, where do you expect complaint handling to change most?" Why it lands: uses the brief and invites the manager's own view.
- **Round 3.** "When a branch manager cannot close a complaint alone, what does she do next?" Why it lands: asks the people who run the escalation how it works, which shows you think about the process as theirs.
- **Round 3.** "What would a member-complaints process that is working look like a year from now?" Why it lands: the outcome question. Panels score a candidate who names a standard.

## Coverage: JD requirements to questions

| JD requirement | Covered by |
|---|---|
| 4+ years in financial-services customer operations | A1 |
| Experience handling regulated complaints | B2 |
| Confident presenting to senior leaders | B3, B4 |
| Comfortable with Excel reporting | C1, C2 |
| Own the complaints process end to end across branches and the contact centre | A4, E1 |
| Report monthly on complaint volumes and resolution times | C1, C2 |
| Coach branch supervisors on escalations | E3, E4 |
| Work with digital teams on self-service journeys | B4, E2 |

Values coverage: Members First, Always: D1, D5. Plain Words: D2. Neighbours, Not Numbers: D3, D6. Own the Fix: D4, D7. Strategy-grounded questions: A3, E2, E5.

Question count: 24 across the three rounds (8 each).

## Sources

**Provided documents:**
- Your message: your background, and two stated absences ("Never worked in a contact centre"; "I've never presented to anyone above regional level").
- The JD text, as you pasted it.
- Ashgrove's values, as you pasted them from ashgrovecu.org/about/values on 11 November 2026. The pack did not check the live page.
- The recruiter's email on the three-round process.
- The 2026 strategy brief, as the recruiter relayed it.

**Searches and fetches sent:**
- "Ashgrove Credit Union values member first plain words neighbours not numbers own the fix". Refused (permission not granted).
- "Ashgrove Credit Union 2026 strategy digital hubs small business lending". Refused (permission not granted).

**Research tier: L1, searches 0 of 6, fetches 0 of 2 (every call refused).**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | unavailable | Refused. The values cheat sheet uses your pasted copy; the live page was not checked. |
| 2. Interview process | skipped | The recruiter's email fixes the loop structure. |
| 3. Strategy and recent news | unavailable | Refused. The grounding brief uses the strategy brief you pasted. |
| 4. Interviewer name | n/a | No names given, so no query could be formed. The interviewer read is absent. |
| 5. Representative JD | skipped | The JD you supplied fixes the fit snapshot. |

## Upgrade menu

- Interviewer names for each round → a per-person persona read, persona weights from their public background, and tailored reverse questions.
- Search access (or the live values page, pasted) → checks the four values against the official wording and refreshes the strategy brief. The deep-research tier would add the role's loop reports and recent news, at most six more searches and two more fetches, adding several minutes.
- An anonymised copy of the monthly complaints spreadsheet → F4 can move from medium to high once you have shown it; C1 and C2 get checked against it.
- The complaint rules or timescales the log worked under (anonymised) → F2 from transferability toward presentation, and B2 gets a grounded answer.
- Whether the spreadsheet tracked resolution times → F7 from low; the C1 slot resolves.
- Any digital or self-service work → F9 from discovery; E2 and B4 get a grounded answer.
- Whether you have coached other supervisors → F8, and the E4 slot resolves.
- Any member-side decision you have made, with an outcome → D1, D5 and D7 become mapped stories instead of scaffolds.
- Any location, schedule or work-rights condition in the role → checked against the gate rule; none is in the material now.
- Whether round 3's case is a particular scenario → E3 gets specific.
