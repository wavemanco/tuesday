I'll read the skill's reference files before building anything, starting with the ones it requires for synthesis and delivery.
I have the skill's rules. Next I'll load the web tools so the values and interview-process checks run at the default L1 tier.
Web search and fetch were refused at the permission prompt, so this pack runs at L0 on your inputs alone. I'll write the pack file now.
I'll fix two errors in the file: the question count is wrong, and the gate row sits inside the bank as a question. The gate question belongs in the closing questions.
Your Stripe prep pack is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-alone-part-2-rooms-case-3-denied-5e1cd030/be149f59-3ed9-421f-956f-d60549f763b5/scratchpad/stripe_product_operations_manager_interview_pack.md`.

Web search and fetch were refused, so this is a pack built only from what you've told me. It has no verified Stripe values, no interview-process facts, and no strategy content. Everything about Stripe is left out rather than guessed.

# Stripe, Product Operations Manager: interview prep pack

**Round:** "final round," relationship unknown, so all personas are weighted flat.

**Types:** VAL = values and behavior. EXP = your experience under scrutiny. JD = role-driven. CO = company knowledge (not covered; research didn't run). CASE = live problem.

## Research status

Research tier: L1, searches 2 of 6, fetches 1 of 2. All attempted, all refused.

| # | Target | Status | What it would have moved |
|---|---|---|---|
| 1 | Stripe values | unavailable | Values cheat sheet, not built |
| 2 | Stripe interview process | unavailable | Loop structure; weights stay flat |
| 3 | Stripe strategy and news | unavailable | CO bank absent |
| 4 | Interviewer | n/a | No name given |
| 5 | Representative JD | unavailable | Requirements are generic, not quoted |

## Fit snapshot (worksheet: no CV or JD yet)

| # | Requirement (generic) | Evidence | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Run cross-functional operating processes | none given | none | [generic] | discovery | Answer slot: name one recurring process you ran or set up end to end, and what you personally set up. If you haven't, say so |
| F2 | Build and use metrics for product decisions | none given | none | [generic] | discovery | Answer slot: a metric you tracked, who used it, what changed. If no decision moved on it, say so |
| F3 | Influence senior stakeholders | none given | none | [generic] | discovery | Answer slot: one decision you moved and how. If none, describe the nearest thing and say so |
| F4 | Payments, fintech or high-scale B2B depth | none given | none | [generic] | discovery | Domain preference, not a gate. Answer slot: what you know about how payments businesses run, and what you'd learn first |
| G1 | Work authorization, location, schedule | none given | none | [generic] | hard_gate | Not established by your material. Asked below |

**Prohibited claims:** none yet. Nothing about your past is in the pack, so there's nothing to inflate. This fills once your CV is in.

## Question banks

Every row is generic. Where a question asks about your past, the guidance is a selection scaffold with an honest branch.

| # | Persona | Question | Type | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | Conversational | "Walk me through your background and what brought you to product operations." | EXP | 90 seconds. Two or three moments where you ran or set up process. End on why this role | Opener. Scored even when casual |
| A2 | Prober | "Pick one process you ran. How did you know it was working?" | EXP | Name the metric and its weakest assumption before they do. Say what you can't say about how it was counted | Tests F1 and F2 |
| A3 | Prober | "Which number from that work would you defend least?" | EXP | Answer slot: the figure and the assumption you'd defend least. If you didn't track a number, say so | Raised only by a figure you give |
| B1 | Pressure | "Why should we hire you over someone who has run this at a payments company?" | JD | Restate. Anchor in what you can do. Hold through two follow-ups. Concede a specific gap, not the whole case | Composure under comparison |
| B2 | Pressure, highest ROI | "What would you need to learn about a payments business in your first ninety days?" | JD | Name the domain gap yourself if real. Give adjacent experience only as you stated it. Give a ramp plan. Hold through two follow-ups | F4 is the likeliest objection. Deepest rehearsal |
| C1 | Case | "A launch missed its adoption target by 30 percent. Diagnose it." | CASE | Clarify target and window. Segment users. Form hypotheses with metrics. Challenge one premise | Structure over the right answer |
| C2 | Case | "A team ships every two weeks and has no launch review. What's your first week?" | CASE | Ask what has gone wrong before fixing. Propose a light review. Name what you wouldn't change | Live version of F1 |
| D1 | Skeptic | "What would you be weakest at on day one?" | JD | Name it honestly. Give the ramp. Don't bluff | Calibrated candor |
| D2 | Skeptic | "Why leave where you are, and why now?" | JD | Give the reason in terms of the work, not the grievance | Motivation consistency |
| E1 | Peer | "Tell me about a time you disagreed with a peer about a process change." | VAL | Pick a disagreement where the relationship held. If none, say so and give the nearest | Peer seam |
| E2 | Peer | "Where is the seam between your work and engineering or finance?" | JD | Propose seam principles, not a seam you haven't seen | Partnership fit |
| F1 | Values | "When did you put a customer ahead of an internal metric?" | VAL | Pick a moment where customer outcome cost a metric. If none, say so | No Stripe value named |
| F2 | Values | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | Pick a truth that landed and what followed. If none landed, say so | Scored behavior |

**Coverage:** 13 questions, below the roughly 18 to 26 target. The gap is the CO and JD-tagged banks, which need inputs you haven't given yet.

## Reverse questions

1. "What does a strong first ninety days look like?" Shows you plan the ramp.
2. "Which process here do teams most often say is broken?" Surfaces real pain.
3. "How do product operations and product teams split decision rights?" Tests whether the role has authority or only coordination.
4. "How is this role measured six months in?" Signals you think in outcomes.
5. "What have the last people in this role done well, and where did they struggle?" Shows you want to learn the job.

If the interviewer is a peer, add: "What could a new person do in their first month that would genuinely help your team?"

## Sections dropped

Prep triage (no time given), graded deliverables (none declared), grounding brief (no deep research), interviewer read (no interviewer), values cheat sheet (no values in hand), delivery coaching (no assessment).

## Upgrade menu

- **JD text:** F1 to F4 get quoted requirements. Coverage becomes checkable. JD-tagged questions get added.
- **CV:** evidence cells fill with your own sentences. A1 to A3 become story-mapped. The prohibited list gets built.
- **Round type and relationship, plus any recruiter guidance:** sets persona weights. If the final is several sessions, send the schedule for per-session packs.
- **Interviewer name:** an interviewer read and a tailored reverse question.
- **Web permission:** lets me rerun L1 for values, the interview process and strategy. A deeper pass (L2) is up to 6 more searches and 2 more fetches, several minutes. Want it?

---

**Drill offer:** I can play the Pressure interviewer on B2, the highest-ROI question, with live follow-ups and feedback against its guidance.

**Dossier offer:** I can save a `tuesday-dossier.md` recording the gaps this prep exposed, to carry into later sessions.

**Questions:**
1. Is the final with your future manager, a peer, a skip-level, or a cross-functional partner? Did the recruiter name focus areas or a take-home?
2. Can you paste the job description and/or your CV? If not, I'll proceed as is.
3. Are you authorized to work where this role is based, and are the location and schedule workable?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: stripe_product_operations_manager_interview_pack.md -----
# Stripe, Product Operations Manager: interview prep pack

Role: Product Operations Manager. Company: Stripe. Interviewer: not given. Round: "final round", relationship unknown, so every persona is weighted flat. Built at L0: web research was refused, so nothing about Stripe in this pack is verified, and no Stripe value is named.

## How to use

Personas describe how a question arrives. Types describe what is being scored.

- **VAL**: behavioral and values. Whether past behavior shows the company's published values.
- **EXP**: experience deep-dive. Whether the claims on your CV hold up under scrutiny.
- **JD**: role-driven. Whether you can do the listed job, gaps included.
- **CO**: company and strategy knowledge. Not covered here; research did not run.
- **CASE**: live problem. Structure and reasoning on a problem from the role.

The guidance is scaffolding, not a script.

## Research status

Research tier: L1, searches 2 of 6, fetches 1 of 2 (all attempted; all refused because web permission was not granted)

| # | Target | Status | What it moved, or would have |
|---|---|---|---|
| 1 | Stripe values | unavailable | Values cheat sheet not built. No published values are named in this pack |
| 2 | Stripe interview process, product operations | unavailable | Loop structure unknown. Persona weights stay flat |
| 3 | Stripe strategy and recent news | unavailable | CO questions absent. Would have grounded the CO bank |
| 4 | Interviewer name and Stripe | n/a | No interviewer name given |
| 5 | Representative Product Operations Manager JD | unavailable | No requirement is quoted. Requirements below are role-family patterns, labelled generic |

Sources: "Stripe company values operating principles" (refused). "Stripe Product Operations Manager interview process final round" (refused). Fetch of stripe.com/jobs/culture (refused).

## Fit snapshot (worksheet variant)

No CV and no JD were supplied, so no evidence cell can hold a quote. Every row is a role-family requirement, labelled generic.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Run cross-functional operating processes for product teams, such as planning, launch reviews and metrics (role family) | none given | none | [generic] | discovery | Answer slot: name one recurring process you ran or set up end to end, and what you personally set up. If you have not, say so and describe how you would approach it |
| F2 | Build and use metrics to inform product decisions (role family) | none given | none | [generic] | discovery | Answer slot: name a metric you tracked, who used it, and what it changed. If no decision moved on it, say so |
| F3 | Influence decisions with senior stakeholders (role family) | none given | none | [generic] | discovery | Answer slot: one decision you moved, and what you did to move it. If you did not move one, describe the nearest thing and say so |
| F4 | Domain depth in payments, fintech or high-scale B2B software (role family) | none given | none | [generic] | discovery | Domain preference, not a gate. Answer slot: what you know about how payments businesses run, and what you would learn first |
| G1 | Work authorization, location and schedule for the role | none given | none | [generic] | hard_gate | Your material does not establish this. It is surfaced here and asked once in the closing questions |

## Prohibited claims

None. No claim about your past appears in the pack, so there is nothing to inflate yet. This list fills when your CV is in.

## Persona weights

Round type and relationship are unknown, so all seven personas are weighted flat, at 2 or 3 questions each. Relationship priors from the skill would tilt this as follows once known: a hiring manager leans Case and Skeptic; a peer leans Peer Evaluator and Prober; a skip-level leans Case and Pressure.

## Question banks

Each row is generic. None carries a quote from your background, so no guidance cell says what you did. Where a question asks about your past, the guidance is a selection scaffold that ends in an honest branch.

| # | Persona | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|---|
| A1 | Conversational | "Walk me through your background and what brought you to product operations." | EXP | [generic] | 90 seconds. Pick two or three moments where you ran or set up process for a team. End on why this role. If a moment was not yours to set, say so | Opener in every loop. Scored even when casual |
| A2 | Prober | "Pick one process you ran. How did you know it was working?" | EXP | [generic] | Name the metric. Name its weakest assumption before they do. Say plainly what you cannot say about how it was counted | Tests F1 and F2 together. Probers go two levels deeper |
| A3 | Prober | "Which number from that work would you defend least?" | EXP | [generic] | Answer slot: the figure you used, and the assumption behind it you would defend least. If you did not track a number, say so and say what you would track | Figure-defense slot. Raised only by a figure you give |
| B1 | Pressure | "Why should we hire you over someone who has run this at a payments company?" | JD | [generic] | Restate the question. Anchor in what you can actually do. Hold your position through two follow-ups. Concede a specific gap, not the whole case | Tests composure under a comparison. Hold-then-concede |
| B2 | Pressure, highest-ROI | "What would you need to learn about a payments business in your first ninety days?" | JD | [generic] | Name the domain gap yourself if it is real. Give the adjacent experience only as you stated it. Give a concrete ramp plan. Hold through two follow-ups | F4 is the most likely objection for a payments company. Deepest rehearsal here |
| C1 | Case | "A launch missed its adoption target by 30 percent. Diagnose it." | CASE | [generic] | Clarify the target and the time window. Segment the users. Form two or three hypotheses. Name the metric for each. Challenge one premise | Scores structure, not the right answer |
| C2 | Case | "A team ships every two weeks and has no launch review. What is your first week?" | CASE | [generic] | Ask what has gone wrong before proposing a fix. Propose a lightweight review. Name what you would not change | Tests F1 as a live problem |
| D1 | Skeptic | "What in this role would you be weakest at on day one?" | JD | [generic] | Name the weakest area honestly. Give the ramp. Do not bluff a competency | Calibrated candor, scored |
| D2 | Skeptic | "Why leave where you are, and why now?" | JD | [generic] | Give the reason in terms of the work, not the grievance. Keep it consistent with your CV once you have it | Motivation consistency |
| E1 | Peer | "Tell me about a time you disagreed with a peer about a process change." | VAL | [generic] | Selection scaffold: pick a disagreement where you changed your mind or they did, and where the relationship held. If none comes to mind, say so, then give the nearest one | Open prompt. Peer seam probe |
| E2 | Peer | "Where is the seam between your work and an engineering or finance team?" | JD | [generic] | Propose seam principles, not a seam you have not seen. Say what you would need from them | Partnership fit |
| F1 | Values | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a moment where the customer outcome cost a metric. If none, say so and give the nearest case | Values probe. No published Stripe value is named here |
| F2 | Values | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a truth that landed, and say what happened next. If none landed, say so | Scored behavioral question |

Requirement coverage: no JD requirement was supplied, so there is no requirement-coverage table. Role-family requirements F1 to F4 are covered by A1 to A3, B1, B2, C1, C2 and D1.

Total: 13 questions. This is below the roughly 18 to 26 target. The shortfall is the CO bank and the JD-tagged bank, both of which need inputs not yet in hand.

## Reverse questions

Five minimum, each with a reason.

1. "What does a strong first ninety days look like in this role?" Why it lands: shows you plan the ramp.
2. "Which process here do teams most often say is broken?" Why it lands: surfaces the real pain without asking for a secret.
3. "How do product operations and product teams split decision rights?" Why it lands: tests whether the role has authority or only coordination.
4. "How is this role measured six months in?" Why it lands: signals you think in outcomes.
5. "What have the last people in this role done well, and where did they struggle?" Why it lands: shows you want to learn the job, not only interview for it.

If the interviewer is a peer, add: "What could a new person do in their first month that would genuinely help your team?" Why it lands: reciprocity.

## Prohibited list, sections and drops

Not built. Sections dropped because their condition fails: prep triage (no prep time given), graded deliverables (none declared), grounding brief (no L2 research), reading the interviewer (no interviewer information), values cheat sheet (no values-style round detected and no values in hand), delivery coaching (no assessment provided).

## Upgrade menu

- JD text → fit rows F1 to F4 gain quoted requirements and move from generic to grounded. Requirement coverage becomes checkable. JD-tagged questions are added.
- CV → evidence cells fill with your sentences. A1 to A3 become story-mapped. The prohibited list is built from your claims.
- Round type and relationship to the interviewer, plus any recruiter guidance on focus areas or a take-home → persona weights are set. If your final is several sessions, send the schedule for per-session mini-packs.
- Interviewer name → interviewer read and a tailored reverse question.
- Web permission for research → values cheat sheet, strategy-grounded CO questions, and a representative JD at L1. A deeper pass at L2 (strategy brief, interviewer talks, loop reports) is up to 6 more searches and 2 more fetches, several minutes. Want it?
