This matches the mock-interview prep skill, so I'll load it and build the prep pack from your JD and background.
Web search was refused by the host, so the pack will be built from your JD and background only. I'll write it to the scratchpad now.
Your prep pack is saved as `atlas_freight_operations_manager_interview_pack.md` (sent to you as a file). I built it for a hiring-manager round, since your note didn't say who you're meeting. Web search was refused in this session, so the pack draws only on your JD and your background. Nothing about Atlas Freight's values, interview process or recent news is in it.

**The main thing to prepare:** the pack's highest-ROI item is question A2, "How would you run four sites with twelve?" Your current scope is a senior shift manager over three supervisors. The JD asks for four sites and twelve supervisors. Rehearse a non-defensive answer that names the gap, then describes how you would build the structure, without claiming you've done it.

**The other gaps the pack flags:**
- **Leadership years (A3):** the JD asks for 5+ years of operations leadership. Your material shows seven years in operations, but not how many were in a leadership role. Work out that number from your dates before the interview.
- **Power BI (A4):** say "I haven't used Power BI" in the first sentence, then give a concrete plan. Don't describe any Power BI work.
- **The 40% mis-pick reduction (C1, C2, D2):** expect probes on how it was counted and which part was yours. Be ready to name the assumption you'd defend least, and to say plainly if you don't know how it was measured.

**Two questions for you:**
- Who are you meeting, and is it your future manager or a peer? The answer reweights the question banks.
- Do you want the pack as a Word document?

If you grant web search, I can rerun the company research (values, interview process, recent news) and add it to the pack. I can also run a live drill: I play the Skeptic on A2, and you answer.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: atlas_freight_operations_manager_interview_pack.md -----
# Interview prep pack: Operations Manager, Atlas Freight

Role: Operations Manager (regional logistics, 800 employees, four sites)
Company: Atlas Freight
Interviewer: not given
Round: assumed hiring-manager round, since your note didn't say who you're meeting. Every persona weight below follows from that assumption.
Research: none. Web search was refused in this session, so nothing about Atlas Freight comes from outside your JD and your note.

## How to use this pack

Personas are how a question arrives. Types are what it scores:

- **JD**: tests a stated requirement from the posting.
- **EXP**: tests what you actually did, and how precisely you can say it.
- **CASE**: a live problem from the role. Structure matters more than the answer.
- **CO**: company knowledge. None in this pack, because no research ran.
- **VAL**: values or behavioral. None in this pack, because no values source was found.

The guidance is scaffolding, not a script. Rehearse it in your own words until you can say it in 90 to 120 seconds.

## Fit snapshot

Each row sets one JD requirement against your own words. Evidence is quoted exactly from your message. Gap and bridge language says what you can truthfully say and where the material stops.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" (JD) | "currently a senior shift manager over 3 supervisors" (your message) | medium | [grounded] | transferability | Your material says one shift manager role over three supervisors, not four sites. Keep that scope: "I'm currently a senior shift manager over three supervisors." Answer slot: the JD asks about daily ownership across four sites, so expect a probe on multi-site work. If you have run operations across more than one site, say which and how, in your own words; if not, say so plainly and describe how you run your current shift. |
| F2 | "drive on-time performance and cost-per-shipment down" (JD) | "cut mis-pick rate 40% by redesigning the pick path" (your message) | medium | [grounded] | transferability | Your material shows accuracy, not on-time performance or cost per shipment. Bridge: "I cut the mis-pick rate by 40% by redesigning the pick path." Answer slot: if you tracked on-time performance or cost per shipment, say what you tracked and how; if you did not, say so and say what you would measure first. |
| F3 | "lead a team of 12 supervisors" (JD) | "currently a senior shift manager over 3 supervisors" (your message) | medium | [grounded] | transferability | Three supervisors, not twelve. Bridge: "I lead three supervisors now." Answer slot: if you have led a larger layer of supervisors, say how many and how it was structured; if not, say how you would structure a layer of twelve. |
| F4 | "5+ years operations leadership required" (JD) | "7 years in warehouse and distribution ops" (your message) | low | [grounded] | discovery | Your material shows seven years in operations but does not show how many were in leadership. Length of experience is not a gate, so this is graded on fit. Answer slot: state the number of years you held a leadership role, from dates you can give; if it is fewer than five, say so and say what you led. |
| F5 | "build reporting in Excel/Power BI" (JD) | "solid Excel" (your message) | low | [grounded] | discovery | Your material says Excel but not reporting built in it. Bridge: "I'm solid in Excel." Answer slot: if you have built a report in Excel, name it, who used it and what it changed; if not, say so and say what you have used Excel for. |
| F6 | "build reporting in Excel/Power BI" (JD) | "never used Power BI" (your message) | none | [grounded] | capability | You stated this absence. Words: "I haven't used Power BI." Then how you would learn it, said as a plan, never as a past. Nothing added to make the gap feel smaller. |
| F7 | "Lean/Six Sigma a plus" (JD) | "green belt certified" (your message) | medium | [grounded] | none | The quote reaches the requirement. Bridge: "I'm Green Belt certified." Expect a probe on how you applied it. The certificate is not inspected, so the band stays medium. |

Confidence grades your evidence, not the pack's writing. F6's confidence is none because it is an absence you stated, not a claim you can make.

## Prohibited claims

Claims this pack will not coach, and why. No answer, hold or rationale in the pack asserts these.

| Not coached | Basis | Honest form |
|---|---|---|
| Owns daily terminal operations across four sites | Inflated form of F1 | F1's quote at its own scope. The material says a senior shift manager role over three supervisors, not four sites. |
| Leads twelve supervisors | Inflated form of F3 | F3's quote at its own scope: three supervisors. |
| Drove cost-per-shipment down | Inflated form of F2 | F2's quote at its own scope: the mis-pick rate, cut 40%. |
| Five years of operations leadership | Inflated form of F4 | "7 years in warehouse and distribution ops", with the leadership count left as an answer slot. |
| Has built Power BI reporting, or used Power BI | Negative you stated, F6 | The plain acknowledgment: "I haven't used Power BI." No slot. |

## Persona table

Relationship assumed: hiring manager. Priors and reasoning:

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy | Questions |
|---|---|---|---|---|
| Skeptic | Quiet probing of the gaps: scope, leadership years, Power BI | Highest. Hiring managers buy capability and derisk gaps, and your three gaps (scope, leadership years, Power BI) are visible on paper | Rehearse the scope question until it is boring. Bridge from what you stated. Name the limit plainly | A1 to A5 |
| Case / Strategist | Live problems on on-time performance, cost, peak planning | High. The JD asks for both outcomes, so a live diagnosis is likely | Clarify, define the metric, segment, then approach and risks. Think aloud | B1 to B4 |
| Data-Driven Prober | Asks how the 40% was counted and what part was yours | High. The 40% is your strongest number and the one most likely to be tested | Say the baseline and count in your own words, name the assumption you'd defend least, and say plainly what you don't know | C1 to C4 |
| Pressure | Interrupts, time-boxes, challenges what you did | Medium. Pressure tests composure when the gaps are real | Pause, restate, hold a position through two follow-ups, then concede the specific gap | D1 to D3 |
| Conversational | Friendly opener, casual questions on the JD's tools | Lower, but casual questions here are still scored | Practice a 90-second arc. Answer casual questions with the same discipline | E1 to E2 |

Depth follows weight: Skeptic 5, Case 4, Prober 4, Pressure 3, Conversational 2.

## Question banks

### Skeptic (weight 5)

Highest-ROI prep in this pack: **A2**. The scope gap is the most predictable objection to you, and a rehearsed, non-defensive answer changes the interview.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "currently a senior shift manager over 3 supervisors"; "7 years in warehouse and distribution ops" | Name the scope gap first, in your words: "Today I manage three supervisors as a senior shift manager." Then your first 30 days: what you would learn across the four sites before you change anything. Plan language only. | F1 and F3 are the largest gaps. A skeptic asks this to hear whether you name the gap yourself |
| A2 | "You're currently a senior shift manager over three supervisors. How would you run four sites with twelve?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" | Answer with structure, not experience: layers, cadence, who reports to whom, what you would delegate. Hold through two follow-ups by returning to the three-supervisor scope. Answer slot: if you have led people across more than one site or more than three supervisors, say how, in your own words; if not, say so plainly and give your structure for building it. | F1 and F3 together are the most likely probe. Deepest rehearsal, because it is the objection most likely to be asked in some form |
| A3 | "The posting asks for five years of operations leadership. How many of your seven years were in a leadership role?" | JD | [grounded] "7 years in warehouse and distribution ops" | Give the number you can support with dates. Answer slot: if fewer than five years were in a leadership role, say so, then say what you led and when you started leading. Never round the count up. | F4. The question presupposes a leadership count the quote does not state, so the second branch allows fewer |
| A4 | "The reporting job uses Power BI. Where's your experience with it?" | JD | [grounded] "never used Power BI" | "I haven't used Power BI." Then one concrete first step you would take, as a plan. No slot: the negative is yours to say. | F6. Acknowledge it in the first sentence, then move to the plan. Do not describe any Power BI work |
| A5 | "The posting asks for reporting in Excel. What have you built?" | JD | [grounded] "solid Excel" | Say what you have used Excel for, in the words of your quote. Answer slot: if you built a report, name it, its audience and what it changed; if you did not, say so and do not describe a report. | F5. The question asks for a built report, which the quote does not show. The second branch allows that none was built |

### Case / Strategist (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Your terminal's on-time rate has dropped five points over two weeks. Walk me through how you'd diagnose it." | CASE | [generic] | Clarify what on-time means and over which shipments. Then segment by site, shift, lane, carrier and dock. Then approach and risks. Think aloud and state a hypothesis early. | JD's on-time requirement. Presupposes nothing about you |
| B2 | "Cost per shipment is up eight percent across the four sites. Where do you start?" | CASE | [generic] | Confirm how cost per shipment is defined, then split it into labor, dock, linehaul and overhead, then compare sites. Ask for the baseline before you touch a number. | JD's cost-per-shipment requirement. The clarifying move is what the interviewer scores |
| B3 | "Peak season starts in six weeks and volume is up forty percent. What is your plan?" | CASE | [grounded] "ran the site's peak-season surge plan two years running" | Structure first: capacity, labor, dock, exception handling, and the weekly checkpoint. Answer slot: if you ran peak planning, say what the plan covered and what you would change; if the plan was not yours to set, say so plainly. | Your surge plan is the strongest real evidence for this, and the question asks you to structure a plan, not to tell that story |
| B4 | "Pick one metric for this role and tell me how you'd know a change worked." | CASE | [generic] | Name one metric, a baseline, a control and a check for side effects, such as accuracy falling as speed rises. | Tests whether the metric answer names its assumptions, which Prober questions will press later |

### Data-Driven Prober (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how you counted the 40% mis-pick reduction." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Say the baseline, the period and what was counted, in your own words. Name the assumption behind the 40% that you would defend least, before they ask. Answer slot: if you don't know how it was counted, say so plainly. | F2. Your strongest number is the one most likely to be tested |
| C2 | "Which part of that 40% was yours, and which part came from systems or other teams?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Say which part you redesigned and which changes came from elsewhere. Answer slot: if other people or systems were involved, name them. | Attribution probe on the same figure. A clean split is worth more than a bigger number |
| C3 | "Show me how you'd pull on-time performance by site this week." | JD | [grounded] "solid Excel" | Describe the steps: the source data, the filter by site, the calculation, the check. Answer slot: if you have pulled data like this, describe the steps you used; if not, name the tool you would use and what you would check first. | F5. Tests whether "solid Excel" holds up in a specific task |
| C4 | "Do you track on-time performance or cost per shipment today? Where does the data come from?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Answer slot: if you tracked either, name the source and who checked it; if not, say so and name what you did track. | F2. The question asks whether a practice existed; the second branch allows that it did not |

### Pressure (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why should we hire you over someone who has run four sites?" | EXP | [grounded] "currently a senior shift manager over 3 supervisors"; "cut mis-pick rate 40% by redesigning the pick path" | Hold first: "I haven't run four sites." Then what you do bring, from your quotes only. Hold through two follow-ups. Concede specifically: "I don't have multi-site experience; here is how I'd close that." | F1 and F2 together. Pressure tests whether you fold on the core claim, or concede only the real gap |
| D2 | "That 40% reduction. How much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Hold what you did: you redesigned the pick path. Concede what you did not own, specifically. Answer slot: name the part you designed and the part you didn't, in your words. | F2. Pressure on attribution, the same shape as C2 under time pressure |
| D3 | "Two years of surge planning isn't leadership. What did you actually decide?" | EXP | [grounded] "ran the site's peak-season surge plan two years running" | Name the decisions you made inside the plan. Answer slot: if the decisions were yours, name them; if they were set above you, say so plainly and say what you ran. | Pressure on the surge plan. The challenge is theirs, the answer must stay inside what you ran |

### Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey to here." | EXP | [grounded] "7 years in warehouse and distribution ops" | A 90-second arc: where you started, the pick path, the shift role, why this role. Your own words throughout. | Casual openers are scored on economy. Rehearse the arc once |
| E2 | "What are you playing with in reporting these days?" | JD | [grounded] "solid Excel"; "never used Power BI" | "I use Excel for what I've described. I haven't used Power BI yet, and here is how I'd start." Do not describe any dashboard. | F5 and F6 asked casually. Casual questions on a JD tool are still scored |

### Requirement coverage

| JD requirement | Questions |
|---|---|
| Own daily terminal operations across 4 sites | A1, A2, D1 |
| Drive on-time performance and cost-per-shipment down | B1, B2, C4 |
| Lead a team of 12 supervisors | A2, A1 |
| Build reporting in Excel/Power BI | A4, A5, C3, E2 |
| 5+ years operations leadership required | A3 |
| Lean/Six Sigma a plus | none, and why: the quote in F7 reaches it, and the probe on how you applied it comes through C1 |

## Reverse questions

Ask these when they invite you to ask questions. Each one shows you have thought about the job.

1. "What does on-time performance look like across the four sites today, and which site is furthest from target?" Why it lands: shows you already think in the job's numbers.
2. "How is operations reporting built now, and who reads it each week?" Why it lands: surfaces the Power BI expectation directly and gives you the answer.
3. "What would the first ninety days need to deliver for you to call this a good hire?" Why it lands: turns the gaps into a shared success measure.
4. "How are the twelve supervisors split across the four sites, and what has changed in that structure recently?" Why it lands: tests your scope gap against the real structure.
5. "What is the biggest cost-per-shipment lever you expect the next person to pull?" Why it lands: asks for the real priority, not a generic one.
6. "Which peak-season plan did the team run last year, and what would you change?" Why it lands: connects your surge-plan experience to what they actually did.

## Sources

- Provided documents: the job description and the candidate's background, both in the user's message. No CV, dossier or strategy brief was provided.
- Searches sent, all refused by the host:
  - "Atlas Freight regional logistics company values": refused
  - "Atlas Freight Operations Manager interview process": refused
  - "Atlas Freight logistics news terminals expansion": refused

Research tier: L1, searches 0 of 6, fetches 0 of 2. Every search was refused.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Atlas Freight values | unavailable | Values cheat sheet, section 10. Not produced; no values round detected |
| 2. Atlas Freight interview process, operations | unavailable | Loop structure and persona weights. The hiring-manager assumption stands unconfirmed |
| 3. Atlas Freight strategy and recent news | unavailable | Would have supplied CO questions and a grounding brief. Neither is in this pack |
| 4. Interviewer name and company | n/a | No name given, so no query could be formed |
| 5. Representative operations manager JD | skipped | The supplied JD fixes the fit snapshot and the JD questions |

## Upgrade menu

- Allow web search for this session → values, interview process and recent news for Atlas Freight, each marked [grounded] with sources, and a values cheat sheet if the values are published
- Who you are meeting, and the round type → persona weights and the reverse questions tuned to that person; if it is a peer, the weights shift toward the Peer Evaluator
- The recruiter's prep email → coverage of any pre-declared deliverable, such as a presentation or a take-home
- A CV → fit rows F1 to F5 can quote your own sentences for more detail, instead of your message alone
- Your count of years in a leadership role → row F4 moves from a discovery gap to a grounded answer
