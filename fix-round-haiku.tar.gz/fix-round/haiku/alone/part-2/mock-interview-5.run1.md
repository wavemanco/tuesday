I'll load the mock-interview prep skill, since this is a panel round with a specific format and a commercial grilling.
Your prep pack is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-alone-part-2-rooms-case-5-denied-6ad26a8e/b17cbe08-2f5d-4d95-8030-d826c6257a23/scratchpad/kelverton_rail_senior_partnerships_manager_interview_pack.md`.

I built it on your message and the recruiter's email as you quoted it. I had no JD, no contents of the strategy report, and no web research, so the requirement rows quote the recruiter and the rest is role-family prose.

The pack's core is the 15-minute POV in section 5: two theses, each with a concession, an anti-pick on channel scale, and an operator-first close. Ross's quota and £4M questions (R1 to R3) are the highest-ROI prep. Operator-market facts are not verified; check them against the report before you use them.

I can play Ross's Pressure persona on R3, the quota question, as a live drill. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed. If you'd like the pack as a Word document, say so and I'll convert it.

1. Can you paste the JD, or should I proceed without it?
2. Are quota ownership and rail experience must-haves in it?
3. Can you paste the three or four headline claims from the strategy report? The POV's consensus item depends on them.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: kelverton_rail_senior_partnerships_manager_interview_pack.md -----
# Kelverton Rail: Senior Partnerships Manager, second-round prep pack

**Role:** Senior Partnerships Manager, Kelverton Rail (UK rail-tech, sells scheduling software to train operating companies)
**Round:** Panel, 60 minutes. Deepa (VP Partnerships, your future manager) and Ross (Commercial Director).
**Format:** 15 minutes of spoken POV on operator partnerships over the next 18 months, no slides, landing on what it means for the operators. Then Q&A, with Ross pushing on commercials.
**Built on:** your message and the recruiter's email as quoted in it. No JD, no contents of the strategy report, documents only (no searches). This is the first version.

---

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored.
- Type key: **VAL** behavioural/values, **EXP** work-experience deep-dive, **JD** role-driven, **CO** company and strategy, **CASE** live problem.
- Guidance is scaffolding, not a script. Rehearse the structure, then say it in your own words.
- Answer slots (sentences starting "If you…") are instructions for the interview, not questions to answer here.

---

## Prep triage (4 hours)

1. **0:00 to 0:45. Read the strategy report with one question:** which three claims would an operator planner dispute? Note them. The POV (section 5) and question D6 depend on this.
2. **0:45 to 1:45. Build the POV** from section 5. Write it, then say it aloud twice with a timer. Aim for 13 minutes so you are not cut off at 15.
3. **1:45 to 2:45. Ross's bank (R1 to R3 first).** Say each hold aloud. Work the £4M figure from your own records: how it was counted, and which part was yours.
4. **2:45 to 3:30. Deepa's bank (D3 and D4), then the rail gap.** Practise the plain sentence "I have never sold into rail", then the planning-side bridge.
5. **3:30 to 4:00. One full 60-minute run, recorded.** Then the reverse questions in section 11.

Everything else is insurance.

---

## Fit snapshot

No JD was supplied. Requirement rows quote the recruiter's own words (`[grounded]`). Role-family requirements are plain prose (`[generic]`) and raise no answer slot unless a quote touches them. Every evidence cell holds your own sentences, or `none given`.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "land on what it means for the operators themselves" (recruiter email) | "bus and light rail network planning, so I know the operator world from the other side" (your message) | medium | [grounded] | none | No gap in the requirement; the quote reaches the operator view. Expect the probe "was that work for operators or for authorities?" The material shows network planning. Say which client it was, in your own words. |
| F2 | "Ross will push on commercials" (recruiter email) | "roughly £4M of influenced revenue" (your message) | medium | [grounded] | presentation | The quote already reaches commercials in other terms: influenced, not sourced. Reword only that: "I influenced roughly £4M of revenue." Add no figure. The defend-the-number slots are in R1, R2 and R6. |
| F3 | Build and scale a partner channel (role family) | "took it from 6 partners to 40" (your message) | medium | [generic] | none | The quote carries channel scale in the terms the role asks for. Keep the numbers as stated. |
| F4 | Partnerships with train operating companies (role family) | "running the ISV channel" (your message) | medium | [grounded] | transferability | The quote is a software-vendor channel in payments. It does not reach train operators. Say that scope exactly. Any argument that the operator link carries over is yours to make, as a view. Answer slot: if you have a view on how channel mechanics carry over to operators, give it as a view, marked as untested. |
| F5 | Direct revenue ownership or quota (role family) | "never carried a direct quota, only influenced revenue" (your message) | high | [grounded] | capability | You stated this absence. Words: "I have never carried a direct quota." Then say what you would do to show you can, as a plan and never as a past. Whether quota is a must-have depends on the JD, which is not in hand. |
| F6 | Selling into rail or to train operators (role family) | "Never sold into rail specifically" (your message) | high | [grounded] | capability | You stated this absence. Words: "I have never sold into rail." Then the scoped bridge to F1: "I have worked on the planning side of bus and light rail." Do not extend the bridge to selling. |
| F7 | Pricing or revenue share with partners (role family) | none given | none | [generic] | discovery | Answer slot: if you have negotiated pricing or commercial terms with a partner, say how, in your own words. If you have not, say so and say what you would model first. |
| F8 | Long procurement with several decision-makers (role family) | none given | none | [generic] | discovery | Answer slot: if you have run a sale with more than one decision-maker, describe the sequence. If you have not, say so and say how you would map the buying group. |

---

## Prohibited claims

The pack will not coach these. Each entry says why, and what you may say instead.

| Not coached | Basis | Honest form |
|---|---|---|
| "I have sold into rail" or any operator sales experience | Negated by your own words | "I have never sold into rail." |
| "I carried a quota" or "I owned a revenue target" | Negated by your own words | "I have never carried a direct quota." |
| "I sourced £4M of revenue" | Inflated form of "influenced revenue" | The quote at its scope: "roughly £4M of influenced revenue." The limit is this pack's observation, not a line to say: your material says influenced, not sourced. |
| "I built the ISV channel" | Inflated form of "running the ISV channel" | The quote at its scope: "running the ISV channel," with "took it from 6 partners to 40" as the number. |
| "I know the operator commercial side" | Inflated form of "bus and light rail network planning" | The quote at its scope: planning networks, not operator commercial work. |

---

## 5. Graded deliverable: the 15-minute POV

**Facts you can build on** (your own sentences, quoted exactly): "running the ISV channel" (F4); "took it from 6 partners to 40" (F3); "bus and light rail network planning, so I know the operator world from the other side" (F1).

**Not verified in this pack.** Operator-market facts (who the buyer is for each operator, contract timing, and any change in ownership or structure of the operator base) are not verified. They must come from the strategy report, not from this pack or from memory. Mark each one you use as "per the report."

**Pick two theses. Each has a concession you must say aloud.**

- **Thesis A: operators buy outcomes they can be held to, so partner on performance, not on licences.**
  Concession: outcome-linked deals need operator data access and buy-in from procurement, and I have not checked the report's view on either.
- **Thesis B: the planning team, not only procurement, decides how a scheduling partnership lands. Partner with the people who already model the network.**
  Concession: planning teams often do not hold the budget, so I would need to map the procurement path before relying on this. The evidence is from network planning, not from rail sales.
- **Anti-pick (say no to this): lead with channel scale.** The 6-to-40 playbook is the default you would expect from someone with your background. Say why it is the wrong default for a buyer base that may be small. Check the report for the operator count before you say it.

**Consensus answer and differentiation.** The strategy report is internal, so both panel members have read it. Name its headline priority once, in one sentence: [consensus item, filled in after you read the report]. Then depart from it: Thesis A or B, with the reason. Do not recite the report.

**Requested close: what it means for the operators.** Finish by describing one operator planning team's Monday morning under your plan. Use only what you can defend, and mark any figure as a target you would test, not a result.

**Timing.** Operator problem 2 minutes. Thesis A with concession 4 minutes. Thesis B with concession 4 minutes. Operator close 3 minutes. Buffer 2 minutes.

---

## 8. Persona table

Relationship priors: a panel takes the top two personas of each member's relationship. Deepa is your future manager, so the hiring-manager prior applies. Ross is a commercial executive, so the skip-level prior applies. The panel's own wording ("Ross will push on commercials") adjusts Ross's weight.

| Persona | Who | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|---|
| Case / Strategist (weight 4 to 5) | Deepa | Live problems on operator partnerships, and follow-ups on your POV | High. The recruiter asked for an 18-month view, and a hiring manager buys capability by testing it on her own roadmap. | Clarify before structuring. Say the structure aloud. Name what you do not know. |
| Skeptic (weight 3) | Deepa | Quiet questions on the gaps: no rail, no operator-side sales | High for the rail gap. It is the most visible gap on paper, so a hiring manager will raise it. | Rehearse D3 until it is plain. Bridge only from F1. State the limit where none exists. |
| Data-Driven Prober (weight 4 to 5) | Ross | Asks how the £4M was counted and what assumption sits behind it | High. Ross's own wording points at commercials, and influenced revenue is the number a commercial director questions first. | Name the weakest assumption before Ross does. Say which part was yours. Say plainly what you do not know. |
| Pressure / Stress (weight 3) | Ross | Interrupts on the quota gap; time-boxes the answer | Medium to high. The quota gap is clear from your own sentence, so Ross will test whether you hold a position under it. | Hold the quota position through two follow-ups. Then concede that it is untested, and give the ramp plan. |

---

## 9. Question banks

Ordering: Deepa's bank first (Case weight 4 to 5, Skeptic 3); then Ross's (Prober 4 to 5, Pressure 3).

**Highest-ROI prep in this pack: R3.** The quota question will come in some form. A held, non-defensive answer changes the commercial half of the interview.

### Deepa (Case / Strategist, then Skeptic)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Which operator do you call first, and what do you ask them?" | CASE | [generic] | Clarify what "first" means: the largest operator, or the one most likely to say yes. Choose one, say why, and name the question you would ask. Name what you would need from the report to be sure. | An 18-month plan starts with a first operator; the question tests whether you think operator-first. Presupposes nothing about your past. |
| D2 | "Your first operator says the timetable team already has a tool. What do you do?" | CASE | [generic] | Ask what the tool does and what it does not. Find the person who owns the timetable decision. Say what would make you walk away. | A live objection built from the operator side. No claim about your past. |
| D3 | "Why would an operator take a partnership call from someone who has never sold into rail?" | JD | [grounded] "Never sold into rail specifically" (your message) | Words: "I have never sold into rail." Then the planning-side bridge: "I have worked on the planning side of bus and light rail," with F1's quote as the scope. Hold through two follow-ups by returning to the planning work. Do not go beyond it. | F6 is the clearest gap on paper. The question presupposes the absence you stated, so the plain acknowledgment is the honest answer. |
| D4 | "Your background is payments. What transfers to operators, and what does not?" | JD | [grounded] "running the ISV channel" (your message); [grounded] "took it from 6 partners to 40" (your message) | Name what transfers: partner recruitment, enablement, running a channel. Then name what does not: the buyer, the procurement cycle, the operator's decision-making. Say how you would test the transfer in 90 days. | F4 is transferability. The answer names the limit before it is asked for. |
| D5 | "What would you stop doing in operator partnerships in the first six months?" | CASE | [generic] | Say what you would stop, and why, before you say what you would start. Keep it to one or two items. | Tests judgment, not activity. No claim about your past. |
| D6 | "What in the strategy report do you think is wrong?" | CO | [grounded] "the market report their strategy team circulated internally last quarter" (your message) | Name one place you would depart from the report, and why. Do not recite it. The departure should come from the POV. | The report is shared by both panel members, so reciting it scores as homework. Departing from it scores as judgment. |
| D7 | "Why leave payments for rail, and why now?" | JD | [generic] | Answer with the reason that connects your planning work to operators. Keep it to two sentences, then stop. | A standard motivation probe, asked as an open prompt. The answer draws only on your message. |
| D8 | "What would you need to know in the first two weeks to change your mind about the 18-month plan?" | CASE | [generic] | Name two or three things, specifically: operator contract timing, the buyer map, the report's data. Say what you would do with each. | Shows you hold the plan as a hypothesis. No claim about your past. |

### Ross (Data-Driven Prober, then Pressure)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R1 | "Walk me through how the £4M was counted." | EXP | [grounded] "roughly £4M of influenced revenue" (your message) | Say what you know about how it was counted, in your own words. Name the weakest assumption behind it before Ross does. Say which part was yours. Answer slot: if you know how it was counted, say how. If you do not know, say so plainly, and say where you would look to find out. | F2 is the defend-the-number row. Attribution is the probe; the pack does not supply a method. |
| R2 | "How much of that £4M would have happened without you?" | EXP | [grounded] "roughly £4M of influenced revenue" (your message); [grounded] "running the ISV channel" (your message) | Hold that you ran the channel: the claim your own words carry. Concede that the counterfactual is not known to you, and say what you would need to estimate it. Do not offer a percentage. | Pressure on attribution. Hold-then-concede: the position held is the one your words carry. |
| R3 | "You have never carried a quota. Why should I trust you with one?" | JD | [grounded] "never carried a direct quota, only influenced revenue" (your message) | Words: "I have never carried a direct quota." Hold through two follow-ups with the plan: what you would do in the first 90 days to show you can carry one. Concede that quota is untested for you. Do not claim a past result. | F5 is the highest-stakes gap. The hold is the plan, not a claim. The concession is the only honest close. |
| R4 | "An operator asks for a revenue share on scheduling uplift. What are your first three numbers?" | CASE | [generic] | Structure: what the uplift is measured against, who verifies it, and what would make the share unfair to either side. Name the numbers you would need. Do not supply figures. | Live commercial problem, scored on structure. Presupposes nothing about your past. |
| R5 | "Tell me about a commercial term you lost on, and what you would do differently." | EXP | [generic] | Pick a time you pursued a term and did not get it. If none comes to mind, say so plainly, then give the nearest thing your material carries: the influenced-revenue work, and what you would change about how it was measured. | An open prompt. The honest branch is built in. |
| R6 | "Influenced revenue is a soft number. How do you separate it from sourced?" | EXP | [grounded] "roughly £4M of influenced revenue" (your message) | Say the definition your company used, if you know it. If you did not set it, say so. Do not invent an attribution model. Answer slot: if you have a view on how you would separate the two, give it as a view. | F2 again, on the definition. Ross will push on this if the figure reads as sourced. |
| R7 | "Why would Kelverton hire a partnerships leader who has never owned a quota?" | JD | [grounded] "never carried a direct quota, only influenced revenue" (your message) | Hold the case in two sentences: what you have carried, and what you would bring to a number. Concede that quota is the untested part, and say how you would show it early. | Pressure in its sharpest form. Hold-then-concede; the second follow-up is where a claim you cannot back breaks. |
| R8 | "What is the commercial risk in your POV?" | CO | [generic] | Name the concession you wrote for Thesis A or B in section 5. Say what would have to be true for the risk to matter. | Ross will test whether the POV is commercially sound. The concession is already in the pack. |

**Coverage of stated requirements**

| Requirement | Covered by | Note |
|---|---|---|
| "what it means for the operators themselves" | Section 5, D1, D2, D5, D8 | Operator-first is the POV's whole spine. |
| "over the next 18 months" | Section 5, D8 | The horizon, and what would change it. |
| "Ross will push on commercials" | R1 to R8 | Commercial half of the round. |
| Quota ownership (role family) | R3, R7, F5 | Gap is stated by you. Whether it is a must-have depends on the JD. |
| Rail or operator sales (role family) | D3, F6 | Gap is stated by you. |
| Pricing or revenue share (role family) | R4, F7 | Discovery gap; answer slot. |
| Partner channel (role family) | D4, F3 | Reaches the requirement. |
| Long procurement (role family) | D8, F8 | Discovery gap; answer slot. |
| JD requirements | None, and why: no JD supplied | Add the JD and this table is rebuilt against its own list. |

---

## 11. Reverse questions

Each one carries why it lands.

1. **Deepa: "What would make this hire a clear success at the 90-day mark?"** Lands the scorecard you would be measured on, before you are measured on it.
2. **Deepa: "Which operator relationship would you least want changed in the first six months?"** Signals operator-first thinking and gives you the account you would be careful with.
3. **Deepa: "Where is the strategy report most contested inside the company?"** Shows you read it without reciting it, and tells you where the POV will be tested.
4. **Ross: "How is partner revenue counted in the commercial plan: sourced, influenced, or both?"** Tells you the number Ross will push on before the push, and whether your £4M figure would be read the same way.
5. **Ross: "What does a good first-year number look like for this role, and what would make it a bad one?"** Shows commercial seriousness and asks for the test in writing.
6. **Either: "What did the last person in this role leave unfinished?"** Exposes the real scope and the work that is already waiting for you.

There is no interviewer profile, so no reverse question is tied to a career path. The upgrade menu says what adding the profiles would unlock.

---

## 14. Sources

- **Provided documents:** your message (background and the panel details), and the recruiter's email as quoted in it.
- **Not provided to me:** the strategy report. I have not used its contents, and every report-specific claim in this pack must be checked against it.
- **Searches and fetches:** none.
- **Dossier:** none.

**Research tier: L0 (documents only; no searches sent)**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Kelverton values | unavailable | Values cheat sheet (not included; no values-style round detected). Research not consented at L0. |
| 2. Kelverton interview process, partnerships | unavailable | Loop structure. Persona weights rest on the recruiter's description instead. |
| 3. Kelverton strategy / recent news | unavailable | Depth of the CO bank. D6 and R8 are generic without it. |
| 4. Deepa and Ross, with Kelverton | unavailable | Interviewer read and tailored reverse questions. Both names are known, so this was not n/a. |
| 5. Representative partnerships JD | unavailable | Would have turned the role-family rows from [generic] to [inferred]. |

---

## 15. Upgrade menu

- **The JD text:** the role-family rows become quoted requirements; quota and rail are confirmed as must-haves or not.
- **Three or four headline claims from the strategy report:** the POV's consensus item (section 5) and D6 become specific. Until then, operator-market facts in this pack are unverified.
- **Deepa's and Ross's public profiles:** a real interviewer read, persona weights tuned to each, and a reverse question tied to a career path.
- **Research at L1** (six searches, two fetches, consent needed): checks on the operator-side facts, and a representative JD if you do not have one.
- **The recruiter's note on the POV's format or close, if any:** sharpens the operator close in section 5.
