Your prep pack is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-alone-part-2-rooms-case-1-denied-67b621d7/9f1cf323-5b2a-4871-968c-4a27c432fdff/scratchpad/northwind_senior-gtm-strategy-lead_interview_pack.md`.

It's built for a single 60-minute peer conversation with Dan. The JD was six highlight lines, so the full JD text would sharpen the fit snapshot.

**What's in the file**
- **Fit snapshot:** eight rows. The biggest gap is partner-motion design. Priya's partner-level revenue model is adjacent to it, not the same thing.
- **Persona weights (23 questions):** Peer Evaluator 5, Data-Driven Prober 5, Case/Strategist 4, Skeptic 3, then Values, Pressure and Conversational at 2 each. Each question is tagged by type and carries a provenance label and the candidate's own quoted sentence.
- **Highest-ROI prep:** D1, "What part of a partner motion have you been involved in, if any?" Rehearse it until the honest answer is plain.
- **Prohibited claims:** six inflated versions of her CV lines, including "drove the ~$400M" and "set quotas." Her answers should stay inside what she actually said.
- **Reverse questions:** six, including two tied to Dan's pricing and startup path.
- **60-minute plan:** requested separately from the standard pack. It budgets time per persona and says to keep D1 if the Prober segment runs long.

**Research didn't run.** The three web searches were refused for lack of permission, so the values, interview-loop and Dan's public footprint are unverified. The pack says so in its Sources section. Anything about current strategy comes only from your research note, and its recency is unchecked. If you grant web search, I can rerun those three checks and update the affected rows.

**Quota-setting gap:** the "no quota-setting experience" point comes from your note, not from Priya's own words. If she confirms it, the pack can treat it as a plain acknowledgment she can say.

Offers, one line each:
- **Drill:** I can play Dan as the Skeptic on D1, the highest-ROI question, and push with two follow-ups.
- **Dossier:** I can save a `tuesday-dossier.md` recording the gaps this prep exposed, for her to carry into later sessions.
- **Word:** If you want the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: northwind_senior-gtm-strategy-lead_interview_pack.md -----
# Mock-interview pack: Senior GTM Strategy Lead, Emerging Products, Northwind Data

**Candidate:** Priya. **Interviewer:** Dan Kovac, Director of Sales Strategy. **Relationship:** peer (same VP). **Format:** single 60-minute conversation.
**Research tier:** L1, with web search refused (see Sources). Interviewer footprint not checked.

## How to use this pack

- **Personas** describe how a question is asked. **Types** describe what is scored: VAL behavioral/values, EXP work-experience deep-dive, JD role requirement, CO company and strategy, CASE live problem.
- Guidance is scaffolding, not a script. Each cell is speakable in 90 to 120 seconds.
- An **answer slot** is an instruction for the interview: Priya answers from her own experience, in either branch the slot allows.

## Fit snapshot

The JD was supplied as six highlight lines, not full text. Candidate evidence is your summary, quoted as written.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" (JD highlights) | "9 at a large consumer-tech company in product strategy & ops" (your message) | medium | [grounded] | transferability | Your material shows product strategy and ops, not go-to-market ownership of a new line. Words: "I spent nine years in product strategy and ops at a consumer-tech company." Answer slot: if you made any go-to-market decision for a launch, say which and how you decided; if there was no such decision, or it was not yours, say so plainly and stay with the product strategy work you did. |
| F2 | "identify whitespace across land/adopt/expand/renew" (JD highlights) | "built a partner-level revenue model used in carrier negotiations" (your message) | medium | [grounded] | transferability | A revenue model is adjacent to whitespace work and does not show it. Words: "I built a partner-level revenue model that was used in carrier negotiations." Answer slot: if the model pointed at an unserved segment or lifecycle stage, say what it was; if it did not, say so. |
| F3 | "run independent analysis in SQL and Tableau" (JD highlights) | "skilled in SQL/Tableau" (your message) | low | [inferred] | discovery | "Skilled" is a claim with nothing inspected behind it. Answer slot: name one analysis you ran yourself in SQL or Tableau and what you can show of it; if you have not run one, say which analysis you would run first. |
| F4 | "partner-motion design experience required" (JD highlights) | "built a partner-level revenue model used in carrier negotiations" (your message) | medium | [grounded] | transferability | Partner-level revenue modelling is adjacent to partner-motion design and does not establish it. Answer slot: if you were involved in any part of how partners were engaged, incentivized or rewarded, say which and your role; if none, say so plainly and say what the model gave the carrier talks. |
| F5 | "strong cross-functional influence" (JD highlights) | "set annual volume targets with cross-org consensus" (your message) | medium | [grounded] | none | The quote reaches the requirement in role-relevant terms. Expect a probe on who agreed and what was conceded: lead with the consensus in the quote's own terms. |
| F6 | "AI experience a plus" (JD highlights) | "uses AI tools daily" (your message) | low | [inferred] | transferability | Daily use of AI tools is adjacent to building or launching AI features and does not reach them. Words: "I use AI tools every day." Answer slot: if you have worked on an AI feature's design, evaluation or launch, say which; if not, say so plainly and stay with how you use the tools. |
| F7 | none in the JD highlights (raised by the sales-side function, not by the JD) | "No classic sales-ops or quota-setting experience." (your note) | none | [grounded] | discovery | This absence is stated in your note, not yet in Priya's words, so it is not a plain acknowledgment she can say. Answer slot: if she has done sales planning or target-setting work, say what it was and whose it was; if not, say so plainly. Upgrade: if she confirms the absence herself, this row becomes a plain acknowledgment. |
| F8 | none in the JD highlights (CV headline metric) | "proposed a store-surface change credited with a ~$400M ARR uplift" (your message) | medium | [grounded] | none | The quote carries the headline figure with its attribution. Defend-the-number slots apply (B1, B2, B5). |

## Grounding brief (from your research note)

Your note is the only strategy input in hand. Its recency is unverified because web search was refused.

| Topic | Your note, verbatim | Provenance | Used in |
|---|---|---|---|
| Enterprise expansion | "enterprise expansion" (your research note) | [grounded] | C3 |
| AI copilot launch | "AI copilot launch ('Compass')" (your research note) | [grounded] | C3, R4 |
| Profitability | "reaching profitability" (your research note) | [grounded] | C3 |
| Competitive threat | "bundling by a much larger platform vendor" (your research note) | [grounded] | C2 |

Use these as the company's stated priorities "as I understand them," never as internal knowledge.

## Reading the interviewer

Public footprint was not checked. Everything below comes from your note alone.

- **Career spine:** pricing and monetization (your note).
- **One early-stage-startup chapter** (your note).
- **Self-description:** "relentlessly data-driven" (your note, describing his profile).

**Practical implications**

1. Bring every number with its denominator and its weakest assumption (B1 to B3).
2. Frame case answers in price, packaging and unit economics first; that is his native language (C1, C2).
3. The startup chapter makes builder stories land well, and makes a big-company pace feel suspect. Keep the store-surface story to what Priya did.

**Mirror opportunity:** a shared professional path, pricing and monetization. Priya's side of it is one quoted sentence, "built a partner-level revenue model used in carrier negotiations" (F2). A revenue model is not a pricing career. Use it only as monetization work, in her own words.

## Persona table

Relationship prior for a peer round: Peer Evaluator and Data-Driven Prober. The "relentlessly data-driven" self-description raises the Prober. No loop source is established, so the archetype fallback is generic and the weights rest on the relationship prior, not on a documented process.

| Persona | How it shows up | Weight (questions) | Reasoning | Counter-strategy |
|---|---|---|---|---|
| A. Peer Evaluator | Seam and credit probes; "what would you need from my team" | 5 | Peer prior; he is pricing what the hire adds to his load | Reciprocity; seam principles, not a map of his team |
| B. Data-Driven Prober | Denominators, assumptions, "walk me through how that was counted" | 5 | Peer prior, raised by his self-description | Name the weakest assumption first; say "I don't know" where true |
| C. Case/Strategist | Live GTM problem for the two new lines; bundling scenario | 4 | Role is GTM for new lines; pricing spine tilts cases to packaging | Clarify, objective, segments, approach, metrics, risks; aloud |
| D. Skeptic | Partner-motion gap; the sales-side gap | 3 | Two gaps in the fit snapshot (F4, F7) | Rehearse D1 until plain; concede precisely |
| E. Values/Behavioral | "Unpopular truth" and "customer over metric" stems | 2 | No values-style round is detected, so this is touched, not weighted | Selection scaffold ending in its honest branch |
| F. Pressure | Time-boxed "why you"; attribution challenge | 2 | Low for a peer; can surface in any round | Pause, restate, anchor in a quote; hold through two follow-ups |
| G. Conversational | Journey opener; "what are you playing with in AI" | 2 | Casual questions are still scored | Pre-scripted 90-second arc; treat AI as scored |

Total: 23 questions.

## Question banks

Types: VAL, EXP, JD, CO, CASE. Provenance cells carry each quoted sentence the guidance rests on.

### A. Peer Evaluator (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Our teams sit side by side on new-product plans. Where's the seam between sales strategy and emerging products, and what happens when we disagree?" | JD | [grounded] "strong cross-functional influence" (JD highlights) | Name the seam as principles, not a map of his team: who holds the price decision, who holds the pipeline number, how a launch decision escalates. For disagreement, say what data you would bring and how you would close it. Give one thing your work offers his team. | Peer prior; seam probes test turf awareness and press the JD's influence line. The question is a persona stem and assumes no team fact. |
| A2 | "How do you handle credit when work spans teams?" | JD | [grounded] "set annual volume targets with cross-org consensus" (your message); "built a partner-level revenue model used in carrier negotiations" (your message) | Use "we" for the team outcome and "I" for the decision you made. If you use the volume-target example, say who agreed and what you conceded. Answer slot: if you made a call others did not, say which. | Credit probes are standard peer questions; both quotes are the only cross-team record in the material. F5 covers the influence line. |
| A3 | "Tell me about a time you disagreed with a peer on another team and how it resolved." | JD | [grounded] "strong cross-functional influence" (JD highlights); "set annual volume targets with cross-org consensus" (your message) | Selection scaffold: pick a disagreement with an equal where the outcome can be stated and you held a real position. Say what you conceded and what you held. If none comes to mind, say so plainly, then give the nearest thing your material carries: the volume-target consensus (A2). | The probe this persona tests hardest; the honest branch keeps it from becoming a fabricated story. |
| A4 | "If we were both building the plan for a new line, how would you split the decisions between your team and ours?" | CASE | [generic] | Propose principles: decide by who holds the data and the accountable number, and by who can act fastest. Name one decision you would give his team and one you would keep. Say nothing about either team's current split. | A live design question on the seam. No past claim, so the pattern is labeled generic. |
| A5 | "What would you need from my team in the first month to make this work?" | JD | [generic] | Name one concrete need tied to the role's first deliverable, such as data access or a whitespace read on the new lines, and what you bring back. Do not answer "nothing." | Reciprocity; a peer scores how much the hire adds to his load. |

### B. Data-Driven Prober (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Walk me through how the ~$400M figure was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (your message) | Defend-the-number slots, in your words: how the figure was counted; what it is most sensitive to; the assumption you would defend least; which part was yours. Answer slot: if you did the counting, say how; if it was done by someone else or in a step you did not run, say so plainly and say what you proposed. | F8 is the headline CV metric; every headline metric draws this probe. |
| B2 | "Which assumption behind that number would you defend least?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (your message) | Name the weakest assumption before he does, in your words. If you do not know how the figure was built, say so; "I don't know how it was counted" is an honest branch. Name nothing you cannot repeat under a second question. | The weakest-assumption move converts a gotcha into a credibility gain. |
| B3 | "Walk me through how the partner-level revenue model worked, end to end." | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" (your message) | Describe the model in order: what it took in, what it produced, where it was used. Answer slot: which inputs you chose and which you took from others; what the model's use in the negotiations was. | The strongest model claim, and "end to end" invites the attribution question. The question presupposes only the quoted model. |
| B4 | "Describe an analysis you ran yourself in SQL or Tableau. Where did the data come from?" | JD | [grounded] "run independent analysis in SQL and Tableau" (JD highlights); "skilled in SQL/Tableau" (your message) | Start from one analysis: source table, grain, one check you ran. Answer slot: if you ran one yourself, say so and walk through it; if you have not, say so plainly and name the first analysis you would run. Do not present "skilled" as a story. | The JD line plus the thinnest CV claim (F3, low confidence). The prober checks whether the claim is a skill or a demonstrated analysis. |
| B5 | "Suppose the ARR uplift was half what was credited. What changes in your story?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (your message) | Hold the proposal: it stays. Say which part of the uplift she can defend and on what basis. Do not restate the total. | Attribution stress test; the hypothetical presupposes nothing about the figure beyond the quote. |

### C. Case/Strategist (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Two new product lines, one sales organization. How would you sequence go-to-market over the first two quarters?" | CASE | [grounded] "own GTM strategy for two new product lines" (JD highlights) | Clarify first: which lines, which customers, what the two-quarter objective is. Then objective, segmentation by land/adopt/expand/renew stage, approach, metrics, risks. Think aloud; challenge one premise respectfully. No past claim is needed. | The core JD role as a live problem. CASE because it scores structure. |
| C2 | "Suppose a much larger platform vendor starts bundling a competing capability into its suite. How would you change pricing or packaging for one of the new lines?" | CASE | [grounded] "bundling by a much larger platform vendor" (your research note) | Clarify whether bundled means free or included at a tier. Frame in price, packaging and unit economics. State one trade-off between standalone and bundled, and one metric to watch. | Pricing is his native language. The threat comes from your note, and the conditional avoids presupposing it is current. |
| C3 | "Enterprise expansion, the AI copilot launch and profitability are all live. Which one should constrain a new line's GTM plan, and why?" | CO | [grounded] "enterprise expansion" (your research note); "AI copilot launch ('Compass')" (your research note); "reaching profitability" (your research note) | Choose one constraint and defend it with a trade-off. Use the note's language as the stated priorities, not as current internal knowledge. Say what you would deprioritize and what that costs. | Tests altitude. The note is the only grounded strategy source, and its recency is unverified. |
| C4 | "Where would you look for whitespace across land, adopt, expand and renew, and which stage first?" | CASE | [grounded] "identify whitespace across land/adopt/expand/renew" (JD highlights) | Define each stage with the data you would pull first. Name the stage you would check first and why. Name the risk: stage definitions often differ across teams. | Maps the JD whitespace requirement (F2) as a method question. |

### D. Skeptic (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You've built a partner-level revenue model. What part of a partner motion have you been involved in, if any?" | JD | [grounded] "partner-motion design experience required" (JD highlights); "built a partner-level revenue model used in carrier negotiations" (your message) | **Highest-ROI prep in this pack.** Answer slot: if you were involved in any part of how partners were engaged, incentivized or rewarded, say which and your role; if none, say so plainly and say what the model gave the carrier talks. Hold through two follow-ups by returning to the model's quote. Concede the gap in your own words, not in an adjective. | F4 is the JD's required experience and the largest gap. This objection will come in some form, and a rehearsed, non-defensive answer changes the interview. |
| D2 | "You set annual volume targets with cross-org consensus. How did you decide they were right?" | EXP | [grounded] "set annual volume targets with cross-org consensus" (your message) | Say how the targets were checked and who agreed. Answer slot: if you checked them against a named basis, say which; if they were planning targets and you did not check them, say so plainly. Concede a miss if one occurred. | The one sales-adjacent quote. The question stays within the quote's scope and presupposes nothing about quotas. |
| D3 | "Why would a sales strategy team trust a product strategy person with a partner plan?" | JD | [grounded] "9 at a large consumer-tech company in product strategy & ops" (your message) | Concede exactly what you lack, partner design and sales-side planning, before naming what you bring: the revenue model and the cross-org targets. Hold once; concede specifically on the second follow-up. | A skeptic's version of the role-change question. The answer uses only quoted work. |

### E. Values/Behavioral (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] persona stem; "proposed a store-surface change credited with a ~$400M ARR uplift" (your message) | Selection scaffold: pick a time you told someone senior a finding they did not want; say what you said, what they did, and what you held. If none comes to mind, say so plainly, then give the nearest thing your material carries: the store-surface proposal, at its own scope. | Low weight for a peer round, kept so a drift into behavioral questions is rehearsed. The guidance names no event. |
| E2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] persona stem; "set annual volume targets with cross-org consensus" (your message) | Selection scaffold: pick a time a customer outcome beat an internal number you owned; say what you gave up and what you kept. If none comes to mind, say so plainly, then give the nearest thing your material carries: the volume-target consensus (D2), at its own scope. | Values stem with its honest branch. No published values were in hand. |

### F. Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why you over an internal candidate?" | JD | [generic] persona stem; "built a partner-level revenue model used in carrier negotiations" (your message) | Pause, restate the question, then anchor in one quote. Hold through two follow-ups. Concede the one gap that matters in D1's words. Do not claim advantages over an internal candidate that you cannot state. | Time-boxed pressure. The hold-then-concede structure. |
| F2 | "What would have happened without your proposal?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (your message) | Hold the proposal as the thing you made. Answer the counterfactual in terms of the change, not an invented baseline. Answer slot: if you can say what would have happened without it, say what you know and how; if you cannot, say so plainly. | Pressure on attribution. The question presupposes only the quote, and no baseline may be invented. |

### G. Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm" (your message); "9 at a large consumer-tech company in product strategy & ops" (your message) | A 90-second arc: two years in consulting, nine in product strategy and ops, and the reason you want this role, in your words. Speak to the through-line, not each year. | Scored casually. The arc sets up the seam with sales. |
| G2 | "What are you actually playing with in AI these days?" | JD | [grounded] "AI experience a plus" (JD highlights); "uses AI tools daily" (your message) | Name the tools and one use you would defend. Say where they stopped being useful. Answer slot: if you have worked on an AI feature's design, evaluation or launch, say which; if not, say so plainly and stay with how you use the tools. | "A plus" asked casually is still scored (F6). |

**Requirement coverage**

| JD requirement | Questions |
|---|---|
| own GTM strategy for two new product lines | C1, D3 |
| identify whitespace across land/adopt/expand/renew | C4 |
| run independent analysis in SQL and Tableau | B4 |
| partner-motion design experience required | D1, F1 |
| strong cross-functional influence | A1, A2, A3 |
| AI experience a plus | G2 |

The quota-setting gap (F7) is covered by D2, which is premised on the volume-target quote, not on quota work.

## Reverse questions

| # | Question | Why it lands | Tie |
|---|---|---|---|
| R1 | "Your career has been pricing and monetization. Which part of that work would you most want to carry into a new product line?" | Turns the probing into a peer conversation and shows you researched him. | His career path |
| R2 | "You had an early-stage chapter before this. What did it teach you about launching without a big-company playbook?" | Invites his story and shows you read his path. | His career path |
| R3 | "What could a new person do in their first month that would genuinely help your team?" | Reciprocity; signals you are thinking about his load. | Peer |
| R4 | "Is the AI copilot launch's pricing decided yet, or still open?" | Shows concern for a live decision; ties to your note. | Company priorities |
| R5 | "Where is the seam between your team and emerging products that you would most want fixed?" | Inverts A1 and invites him to name a problem. | Peer |
| R6 | "Which of the two new lines is the harder GTM problem, and why?" | Asks for his judgment, not a fact. | Company priorities |

## Conversation time plan (60 minutes, requested)

This plan sits outside the standard skeleton because you asked for it. Prep time was not stated, so no prep triage is included.

| Minutes | Segment | Questions |
|---|---|---|
| 0 to 5 | Opener and arc | G1, rehearsed to 90 seconds |
| 5 to 20 | Prober | B1, B2, B3, B4 |
| 20 to 35 | Peer and case | A1, A2, C1, C4 |
| 35 to 45 | Skeptic and pressure | D1 (non-negotiable), D3, F1 |
| 45 to 52 | Case and strategy | C2 or C3; D2 if time |
| 52 to 60 | Reverse and close | R3, R1, R5, then close |

If the Prober segment runs long, drop C4 first. Keep D1.

## Prohibited claims

Built locally from the fit snapshot. These are the claims Priya could reach for under pressure, and none may be coached.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned go-to-market for a new product line | Inflated form of F1 | F1's quote at its own scope. The material shows product strategy and ops, not go-to-market ownership. C1 and D3 stay inside that scope. |
| Set quotas or ran sales ops | Inflated form of F5. F7 is your note's statement, not Priya's | F5's quote at its own scope. No first-person negative until Priya says it herself. D2 names no quota. |
| Drove the ~$400M ARR uplift | Inflated form of F8 ("proposed ... credited with") | F8's quote at its own scope. B1, B2 and B5 ask what she can defend. |
| Designed partner programs or partner motions | Inflated form of F4 | F4's quote at its own scope. D1 asks which part, if any, she was involved in. |
| Built AI products | Inflated form of F6 ("uses AI tools daily") | F6's quote. G2 asks which part of AI work, if any. |
| Ran independent SQL or Tableau analysis at scale | Inflated form of F3 ("skilled in") | F3's quote. B4 asks whether she ran one herself. |

## Sources

- **Provided documents:** your message (role summary, candidate summary, six JD highlight lines, research note).
- **Searches sent, all refused** (permission not granted):
  - "Northwind Data company values" (target 1): refused.
  - "Northwind Data interview process sales strategy" (target 2): refused.
  - "Dan Kovac Director of Sales Strategy Northwind Data" (target 4): refused.
- **Fetches:** 0 of 2.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Northwind Data values | unavailable | Values cheat sheet. Omitted: no values-style round is detected (no loop source, generic archetype reads no), and no published values were in hand. |
| 2. Northwind Data interview process | unavailable | Loop structure. No loop source established it, so persona weights rest on the relationship prior, not on this company's documented process. |
| 3. Northwind strategy / recent news | skipped | Your research note fixes the current priorities and the competitive threat, which feed C2 and C3. Its recency is unverified. |
| 4. Dan Kovac, Northwind Data | unavailable | Interviewer read and reverse questions tied to his public path. Only your note's description is used. |
| 5. Representative JD | skipped | The six JD highlights you supplied fix the fit snapshot and the JD-tagged questions. |

## Upgrade menu

- **Full JD text** → the six highlight rows become full requirements, and any location, travel or work-authorization term is checked as a gate.
- **Web search permission** → values cheat sheet if a values round is documented, the loop structure, Dan's public footprint (his interviewer read and path-tied reverse questions), and a freshness check on your research note (C2, C3).
- **Priya's CV as a document** → CV-line evidence for F1 to F4 and F6.
- **Priya's own words on the sales-side gap** → turns F7 into a plain acknowledgment she can say, or an answer slot she can answer.
- **A SQL or Tableau artifact she can show** (a query or dashboard she built) → F3 moves from low confidence, and B4 gets a story to rehearse.
- **Recruiter's process email** → any pre-declared deliverable, the round format, and whether this is a single session.
- **Dossier:** a `tuesday-dossier.md` from job-underwriter would add verified evidence and prohibited claims.
- **Deep research, offered once:** up to 6 more searches and 2 more fetches, several more minutes. Want it?
