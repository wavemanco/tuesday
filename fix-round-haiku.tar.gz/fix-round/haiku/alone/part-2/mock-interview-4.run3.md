Your prep pack is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-alone-part-2-rooms-case-4-denied-08eef14d/e430de19-388d-415e-b168-fb07c2aad721/scratchpad/quartzline_product_manager_platform_apis_interview_pack.md`. It is built for a hiring-manager round, with 18 questions weighted toward the Skeptic.

**Check these before Thursday:**
- **The dossier is 89 days old.** It is dated 2026-08-14. The requirement lines and the objection come from it, so confirm they still match the live posting.
- **Web research didn't run.** All three searches were refused by the permission gate, so the pack has no values, no company strategy and no loop structure. Granting search would fill those gaps.

**The objection to rehearse most:** "You've never held the PM title or owned a roadmap. Why should we hire you into one instead of a PM with three years of the actual job?" The underwriter named it, and it gets the deepest treatment (A1, with a 60-second pressure version at D1).

The shape of the answer is fixed by the dossier's guardrails:
- Open with the plain fact: "I haven't held the title or owned a roadmap."
- Then give the integration work in its own words, at its own scope: leading client integrations on the vendor's REST APIs, from scoping to go-live.
- Then the input sessions, described as sessions feeding client evidence to product, not as roadmap ownership.
- Then concede the specific gap and give a 90-day ramp plan. Don't describe yourself as "effectively" a PM.

**Other things the pack covers:**
- **Adoption metrics.** Nothing in your material shows how adoption is measured. Several case questions (B1, B4) let you reason through it without claiming past experience.
- **Agile delivery.** The dossier marks this as a clarify area, so the pack gives you an honest either-branch answer rather than a bridge.
- **Squad authority.** B2 is built around the open question of who decides between squads. Reverse questions R-Q1 and R-Q2 ask it directly.

**Reverse questions for the end:** "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" and "How is partner API adoption measured today, and what is the current baseline?"

**Offers:**
- Want to run a live drill on the objection (A1) with me playing the Skeptic?
- I can also save a `tuesday-dossier.md` with a `pack_feedback` section recording what this prep exposed, so it carries into later sessions.

Watch-out: Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quartzline_product_manager_platform_apis_interview_pack.md -----
# Interview pack: Product Manager, Platform APIs at Quartzline

**Round:** 45-minute conversation with the hiring manager. **Interviewer:** not named. **Relationship:** hiring manager.
**Built from:** the underwriting dossier dated 2026-08-14 (decision: conditional_go). This is the first pack for this round, so there is no changelog.

## How to use

Personas describe how a question arrives. Types describe what is being scored:

- **JD**: can you do the listed job, including its gaps
- **EXP**: do your claims survive scrutiny, and what did you actually do
- **CASE**: structure and reasoning on a live problem from the role
- **CO**: company and strategy knowledge (none in this pack; research did not run, see Sources)
- **VAL**: behavior against published values (none in this pack; no values were available)

The guidance is scaffolding, not a script. Each answer should be speakable in about 90 to 120 seconds.

## Fit snapshot

Requirement lines are the dossier's `role_profile` text. Evidence quotes are verbatim from the dossier's `verified_candidate_evidence` entries: E1, E2 and E3, in that order. Confidence bands and gap types are the underwriter's, mirrored; the bridge wording is this pack's.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" (dossier role_profile R1) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier E1). No quote reaches product-management years. | low | [inferred] | transferability | Your material shows integration leadership, not product-management years. Say that first, then stay in E1's words. Answer slot: if any product work sat beyond those integrations, say which; if none did, say so and stay with the integrations. |
| F2 | "Own the roadmap for the partner-facing API platform" (dossier role_profile responsibility; dossier R1 sub-claim, roadmap and prioritization authority) | "Ran quarterly roadmap-input sessions feeding client evidence to product" (dossier E3). Medium confidence: confirmed, limited inspectable proof. | none | [grounded] | capability | The dossier records this as a stated gap, so the words come from the dossier: "I haven't owned a product roadmap." Bridge only at E3's scope: you ran the input sessions, and the material does not show that you set what went onto the roadmap. |
| F3 | "Shipped API or platform products" (dossier role_profile R2) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier E1) | high | [grounded] | transferability | The material shows go-lives of client integrations on the vendor's APIs. It does not show a platform product you shipped. Name that limit, then give the go-lives in E1's words. Answer slot: if you shipped anything you owned end to end, say what; if not, say so. |
| F4 | "Technical fluency: API docs, schemas" (dossier role_profile R3) | "Wrote the internal integration playbook her team uses" (dossier E2) | high | [grounded] | presentation | Reword only that quote: "I wrote the internal integration playbook my team uses." The material is silent on schemas, so the schema part is an answer slot: if you worked with schemas, say how; if you did not, say so and say how you would learn them. |
| F5 | "Stakeholder management across engineering, sales, customers" (dossier role_profile R4) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier E1) | high | [grounded] | transferability | The quote carries the client side of the work. It does not show engineering or sales. Bridge stays on the client side. Answer slot: if you worked with engineering or sales on those integrations, say which and how; if not, say so. |
| F6 | "Agile delivery experience" (dossier role_profile R5) | none given. No verified entry speaks to this requirement. | low | [inferred] | discovery | The dossier's strategy here is clarify, so no bridge is written. Answer slot only: if you have worked in an agile delivery cadence, say what it was in your own words; if not, say so and say what you would want to confirm about how this team defines it. |
| F7 | "Define and track adoption metrics" (dossier role_profile responsibility; dossier unknown: how adoption is measured today) | none given. The material does not show adoption measurement either way. | none | [inferred] | discovery | Pack observation: your material does not show adoption measurement. Answer slot: if you measured how any integration you led was adopted, say what you measured; if you did not, say so. This slot rests on a responsibility line, not a requirement line; if the live posting does not carry it, drop the slot. |

## Prohibited claims

Built from the dossier's `prohibited_claims`, the `acknowledge_gap` area, and two local inflated forms. No guidance, bank cell, reverse question or answer slot in this pack asserts, softens or implies any entry below.

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | dossier prohibited_claims | "I haven't held a product manager title." Plain acknowledgment sourced from the dossier field. |
| Having owned a product roadmap | dossier prohibited_claims and acknowledge_gap ("Owning a roadmap and prioritization authority") | "I haven't owned a product roadmap." Plain acknowledgment sourced from the dossier fields. |
| Having set prioritization for an engineering squad | dossier prohibited_claims | "I haven't set prioritization for an engineering squad." Plain acknowledgment sourced from the dossier field. |
| "Ran quarterly roadmap-input sessions" stretched to "ran the roadmap" or "shaped the roadmap" | Inflated form of E3 | E3 at its own scope. The limit is the pack's observation, not a first-person negative: your material says input sessions feeding product, not the roadmap. |
| "Led 30+ end-to-end client integrations" stretched to "owned partner API adoption" | Inflated form of E1 | E1 at its own scope. The material does not show adoption measurement, so no adoption claim is made. |

## Persona table

Relationship prior for a hiring manager is Case/Strategist plus Skeptic. The dossier named the most likely objection, which weights the Skeptic highest. No interviewer profile exists, so there are no interviewer-signal adjustments. This is a single session, and no loop source is known, so there is no loop adjustment.

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy | Questions |
|---|---|---|---|---|
| Skeptic | "You've never held the PM title" as the opening objection | Highest. The dossier names this objection, and a hiring manager is buying capability and derisking gaps | Say the plain fact once, then hold on what the material carries. Concede the specific gap and give a ramp plan | 5 (A1 to A5) |
| Case/Strategist | A live problem on partner API adoption and squad trade-offs | High. A hiring manager tests judgment on the actual roadmap | Clarify, then structure, then metrics, then one named risk. Say the decision owner aloud, since authority is an open question | 4 (B1 to B4) |
| Data-Driven Prober | Pushes on the roadmap-input claim and on adoption measurement | Medium. E3 is medium confidence and the dossier expects a probe on it | Say what you can see at E3's scope. Give a number only when you have one, and say how it was counted | 3 (C1 to C3) |
| Pressure / Stress | A time-boxed "sixty seconds" version of the objection | Medium. A 45-minute slot invites a time-boxed challenge | Restate, hold through two follow-ups, concede specifically | 3 (D1 to D3) |
| Conversational / Rapport | An opener asking for the journey, plus a casual question on API docs | Medium. Casual questions on JD topics are still scored | Pre-scripted 90-second arc built from E1, E2 and E3 | 3 (E1 to E3) |
| Peer Evaluator | Not included | Low. A peer round is not this round | None | 0 |
| Values / Behavioral | Not included | Not detected. No values were in hand and no values round was named | None | 0 |

## Question banks

Provenance comes first in each row. Quotes are verbatim. Rationale refers to the candidate's history only by fit-snapshot row ID.

### A. Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've never held the PM title or owned a roadmap. Why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" "Ran quarterly roadmap-input sessions feeding client evidence to product"; dossier prohibited_claims: "Having held a product manager title or role" | Open with the plain fact: "I haven't held the title or owned a roadmap." Then E1 in its own words, then E3 at its own scope. Then concede specifically: a PM with three years has set priorities and owned a roadmap, and you have not. Close with a first-90-days plan, which is a plan and not a past. Hold through two follow-ups by returning to the integrations. Never describe yourself as "effectively" a PM. About 100 seconds. | The dossier named this as the most likely objection, so it gets the deepest rehearsal. F1 and F2 are the gaps it presses. |
| A2 | "What part of this job would you be weakest at on day one?" | JD | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product"; dossier acknowledge_gap: "Owning a roadmap and prioritization authority" | Name roadmap ownership first, in one sentence: "I haven't owned a product roadmap." Then decision authority: say you would want to know which decisions are yours and which the squad leads hold. Then a 30-day plan built on the squads and on sales. A plan is not a claim about your past. | F2 is the capability gap. The question invites the candidate to name it before the interviewer does. |
| A3 | "Which of those integrations were you accountable for end to end?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Name the five phases in E1's order. If any phase was done by someone else, say which. If you worked with engineering or sales on those integrations, say which and how; if not, say so. | F3 and F5 both draw on E1. The engineering and sales slot is raised by the JD's stakeholder line. |
| A4 | "You've seen partner integrations from the vendor's side. What does that tell you about a platform you didn't build?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Say that the integrations were on the vendor's APIs, using E1's words, and stop there. Answer slot: if you owned any API product end to end, say which; if you did not, say what you saw from the integration side. Do not write a negative about shipping a product. | F3 is transferability. The question presupposes a platform the candidate did not build, which E1 supports only as a vendor's API. |
| A5 | "How do you work with an engineering squad on agile delivery?" | JD | [inferred] F6 | Answer slot: if you have worked in an agile delivery cadence, say what it was in your own words. If you have not, say so and say what you would want to confirm about how this team defines agile delivery. No claim about the past is made here. | F6 is discovery. The dossier's strategy is clarify, so the slot is the honest form. |

### B. Case/Strategist (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Partner API adoption has been flat since launch. How would you find out why?" | CASE | [generic] | Clarify what counts as adoption: first successful call, first live integration, or active partners. Segment partners by size and integration type. Trace the path from sign-up to first call. Pick one metric with its denominator stated, and one risk. Name what you would need from the squads. | F7 and the responsibility to define and track adoption metrics. Tests structure on the role's live problem, with no claim about your past. |
| B2 | "Two partners want different API changes in the same quarter, and one squad has capacity for one. How do you decide?" | CASE | [generic] | Clarify what each change unlocks and for whom. Name the decision owner before the analysis, and say aloud that the decision authority is an open question. Score both on partner value and squad cost. State the call and the one thing that would change it. | Tests reasoning under the squad-authority unknown. R4 (stakeholders across engineering and sales). |
| B3 | "How would you write a spec for a partner-facing API change so a squad can start on Monday?" | CASE | [generic] | Order the spec's parts: the problem and the partner, the contract (endpoints, fields, errors), versioning and deprecation, acceptance criteria, out of scope. Name who signs off. | Tests the responsibility to write specs and drive delivery, and R3 (API docs and schemas), through a live spec. |
| B4 | "Which metric would you put on the partner API dashboard first, and what would make you distrust it?" | CASE | [generic] | Name one adoption metric with its denominator. Name the weakest assumption in your own choice before the interviewer does. Name one alternative metric. | Pairs with B1. Tests the candidate's self-critique on the metric most likely to be probed. |

### C. Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through what happened to client evidence once it reached product." | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Describe the sessions in E3's words. Say what you can see of what product did with the evidence. Answer slot: if you tracked what product took from the sessions, say what; if you did not, say so and say how you would want to learn it. Do not extend "feeding" into "shaping". | E3 is medium confidence and the dossier expects a probe on it. |
| C2 | "How would you know whether any client item from those sessions reached the roadmap?" | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Give no count, because the quote carries none. Answer slot: if you saw one reach the roadmap, say which and how you knew; if you did not see that, say so and say what you would check. | F2. The question probes the same boundary as F2 from the other side. |
| C3 | "Which of the vendor's REST APIs did you spend the most time on, and why?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs" | Name the API family you worked on most, in your words. Do not name endpoint counts or version numbers the material does not carry. If you cannot name one, say so and describe the kind of integration. | R3 (technical fluency). Tests whether E1's scope holds at the level of detail a prober goes to. |

### D. Pressure / Stress (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why should we give this to someone without the PM title over an internal PM?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" "Ran quarterly roadmap-input sessions feeding client evidence to product"; dossier prohibited_claims: "Having owned a product roadmap" | Restate the question in your own words. Hold on the integrations and the input sessions, at their own scope. Concede specifically: an internal PM with years has prioritization you do not yet have. Hold through two follow-ups. Do not fold to "I can do the PM job." State the ramp. About 60 seconds. | Time-boxed version of A1. Tests composure more than content. |
| D2 | "That's running a session, not owning a roadmap. How much of the outcome was actually you?" | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Hold E3's scope: you ran the sessions. Answer slot: if you had any say in what product did with the evidence, say what; if you had none, say so. Concede the limit plainly. | E3 is the attribution probe. The honest answer is the limit, stated early. |
| D3 | "Another candidate has done this job for years. Give me your answer in one minute." | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | State the one thing you would bring, which is E1's partner-facing integration work. Concede the years. Name the first thing you would start on. Do not compare yourself to the other candidate's experience. | A pressure version of the same objection, aimed at the rival. |

### E. Conversational / Rapport (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So — walk me through the journey." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" "Wrote the internal integration playbook her team uses" "Ran quarterly roadmap-input sessions feeding client evidence to product" | A 90-second arc in this order: the integrations (E1), the playbook (E2, reworded to "my team"), the input sessions (E3). Then one sentence on why this role, in your words. Do not add anything the quotes do not carry. | Casual openers are scored. A pre-scripted arc keeps the answer economical. |
| E2 | "What are you playing with in API docs these days?" | JD | [grounded] "Wrote the internal integration playbook her team uses" | Describe the playbook in your words. Answer slot: if you worked with schemas, say which and how; if you did not, say so and say how you would learn them. | F4. R3 (technical fluency) is the JD's own line. |
| E3 | "What got you into integration work?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Give the short true version in your own words. The material holds only the scope in E1, so do not invent a motive story. | Conversational probes often reach motivation. Keeping the answer to the quote avoids a story the candidate cannot back. |

**Coverage.** R1 maps to A1, A2, D1 and D3. R2 maps to A3 and A4. R3 maps to B3, C3 and E2. R4 maps to A3 and B2. R5 maps to A5. The responsibility to own the roadmap maps to A2, C1 and C2. The responsibility to define and track adoption metrics maps to B1 and B4. The responsibility to write specs maps to B3. The responsibility to run discovery with integration partners has no question: the material shows no partner-discovery work, and a question would only probe a gap the bridges do not cover.

## Reverse questions

No interviewer profile exists, so these are role-generic. The first two come from the dossier's `questions_for_employer`.

| # | Question | Why it lands |
|---|---|---|
| R-Q1 | "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" | It answers the decision-authority risk before you accept. It reads as diligence. |
| R-Q2 | "How is partner API adoption measured today, and what is the current baseline?" | The posting names adoption as a responsibility but no baseline. This tests whether the metric is defined yet. |
| R-Q3 | "What did the last person in this role leave unfinished?" | It surfaces the ramp, and reads as a question about the work rather than about the pay. |
| R-Q4 | "How do the squads and this role split discovery with integration partners?" | It tests the responsibility to run partner discovery, which has no question in the banks. |
| R-Q5 | "What would make you say six months from now that this hire was the right call?" | It surfaces success criteria, which the candidate can then hold the first 90 days to. |

## Sources

- **Provided documents:** `tuesday-dossier.md`, pasted into the conversation. Dated 2026-08-14, which is 89 days before today (2026-11-11). Its requirement lines, evidence and objection are used as given. Re-check them against the live posting (see upgrade menu).
- **Dossier consumed:** `role_profile` (requirements R1 to R5, responsibilities, unknowns); `verified_candidate_evidence` (E1, E2, E3, numbered in order); `handoff_to_mock_interview` (`likely_interviewer_objections`, `uncertain_or_weak_areas` with their strategies, `opportunity_risks_to_validate`, `questions_for_employer`, `prohibited_claims`). `decision` was context only.
- **Searches sent, all refused by the host's permission gate:** "Quartzline company values"; "Quartzline interview process product manager platform APIs"; "Quartzline strategy partner API platform news". No results were returned, and none were retried.

**Research tier: L1, searches 0 of 6 (3 refused), fetches 0 of 2.**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quartzline values` | unavailable | Would have produced the values cheat sheet (section 10). Absent, so no values round is cheat-sheeted. |
| 2. `Quartzline interview process` (role family) | unavailable | Would have set loop structure and persona weights. Weights here rest on the relationship prior and the dossier's objection. |
| 3. `Quartzline strategy` / recent news | unavailable | Would have grounded a CO question. No CO question is included. |
| 4. `{interviewer name} Quartzline` | n/a | No interviewer name was given, so there was no query to form. |
| 5. representative JD | skipped | The dossier's `role_profile` fixes the fit snapshot and the JD questions. |

## Upgrade menu

- A fresh copy of the posting → checks the dossier's requirement lines against the live text, and confirms or drops the adoption slot in F7.
- Permission to run web search, or the Quartzline values page pasted → the values cheat sheet, and a strategy-grounded CO question.
- The interviewer's name → a tailored reverse question, and persona weights read from their public footprint.
- Whether this round is one of several → loop-mode mini-packs.
- Any roadmap-input notes you can share → makes E3 inspectable, so C1 and D2 rest on a document rather than a sentence.
- Deep research (L2), offered once: a strategy brief, interviewer talks, and role-family loop reports. It costs up to six more searches and two more fetches. Not run.
