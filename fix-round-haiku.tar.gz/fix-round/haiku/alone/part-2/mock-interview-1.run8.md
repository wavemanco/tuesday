Your prep pack is saved as /tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-alone-part-2-rooms-case-1-denied-c3582aea/46bcde88-da7f-4b48-aadc-72822eca2dc7/scratchpad/northwind-data_senior-gtm-strategy-lead_interview_pack.md. I built it for a single peer round with Dan, using your summaries of the JD and her profile, not full texts. Her evidence quotes are your wording, so swap in her CV sentences to make them verbatim.

Search permission was refused, so the company facts come only from your research note. The pack says so in its Sources section.

The highest-ROI prep is question D2, "You've never set a quota or run sales ops… why should I trust your strategy over my team's?" It's the objection most likely to come up in some form, and the pack rehearses the hold and the concession through two follow-ups.

Want me to play Dan on D2 as a drill? One line on it: I can also save a tuesday-dossier.md recording the gaps this prep exposed, and I can convert the pack to Word if you'd like.

Did the recruiter name a focus area or a pre-declared exercise for this round?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: northwind-data_senior-gtm-strategy-lead_interview_pack.md -----
# Interview pack: Senior GTM Strategy Lead, Emerging Products, Northwind Data

**Candidate:** Priya · **Interviewer:** Dan Kovac, Director of Sales Strategy · **Relationship:** peer, same VP · **Round:** single 60-minute session

Built on your summaries of the JD highlights, her profile and your research note, not full texts. Her evidence quotes are your wording, labelled "your message"; swap in her CV sentences to make them verbatim.

## How to use this pack

Personas describe how a question arrives. Types describe what is being scored.

| Type | Name | Scores |
|---|---|---|
| VAL | Behavioral / values | Past behavior against stated values |
| EXP | Work-experience deep-dive | Whether her claims survive attribution questions |
| JD | Role / JD-driven | Whether she can do the listed job, gaps included |
| CO | Company and strategy | Whether she thinks at Northwind's altitude |
| CASE | Live problem | Structure and reasoning on a role problem |

Guidance is scaffolding, not a script. "Answer slot" means an instruction for the answer in the room, not a question to me.

## Fit snapshot

Your JD highlights contain no gate requirement, so no gate row appears. Requirements quote your highlights; evidence quotes your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" (your JD highlights) | "built a partner-level revenue model used in carrier negotiations" (your message) | medium | [grounded] | transferability | Your material shows a revenue model, not GTM ownership, and the words stay there: "I built a partner-level revenue model used in carrier negotiations." Answer slot: if you made any go-to-market decision for a product, say which and how you decided; if you did not, say so and stay with the model. |
| F2 | "identify whitespace across land/adopt/expand/renew" (your JD highlights) | none given | none | [grounded] | discovery | Your material does not show whitespace work. Answer slot: if you have sized or ranked a segment of the customer lifecycle, say which and how you counted it; if not, say so and say how you would start. |
| F3 | "run independent analysis in SQL and Tableau" (your JD highlights) | "skilled in SQL/Tableau" (your message) | medium | [grounded] | presentation | The quote reaches the tools, not the independence. Say: "I'm skilled in SQL and Tableau." Do not extend it to analysis run alone; the probe on that is A4. |
| F4 | "partner-motion design experience required" (your JD highlights) | "built a partner-level revenue model used in carrier negotiations" (your message) | medium | [grounded] | transferability | Carrier negotiations are partner-facing, but the material shows a model used in them, not a partner motion designed. Say the model at its own scope. Answer slot: if you designed or ran a partner program or channel terms, say how; if your part was the model or its inputs, say so and say what carries over. |
| F5 | "strong cross-functional influence" (your JD highlights) | "set annual volume targets with cross-org consensus" (your message) | medium | [grounded] | presentation | The quote reaches cross-org influence in other terms: consensus on a target. Say it in those words. Answer slot: if a target was disputed, say how it was settled and whose call it was; if it was not yours to settle, say so. |
| F6 | "AI experience a plus" (your JD highlights) | "uses AI tools daily" (your message) | medium | [grounded] | transferability | Daily use of AI tools is adjacent to building AI products and does not reach it. Say: "I use AI tools daily." Limit: your material does not show AI product work. Answer slot: name one tool and one thing it changed; if it changed nothing, say so. |
| F7 | sales-strategy fluency (role-family requirement, not in your JD highlights) [generic] | "No classic sales-ops or quota-setting experience" (your message) | medium | [grounded] | capability | Your note states the absence, so the words are the plain acknowledgment: "I haven't set quotas or run sales ops." Then how you would learn it, said as a plan and never as a past. |

## Prohibited claims

Not coached in any cell, with its basis and honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned GTM strategy for product lines | Inflated form of F1: the material shows a revenue model | F1's quote at its own scope. Pack observation, not words for her: your material shows a revenue model, not GTM ownership. A4 and D2 stay inside that scope |
| Set quotas or ran sales ops | Stated negative in your message (F7) | "I haven't set quotas or run sales ops." No answer slot |
| Designed partner motions | Inflated form of F4: a model used in negotiations | The carrier-model quote at its own scope |
| Built or led AI product features | Inflated form of F6: daily tool use | "I use AI tools daily." |
| Sole credit for the ~$400M uplift | Inflated form of the credited sentence | "proposed a store-surface change credited with a ~$400M ARR uplift," at that scope |
| Independent analysis drove a decision | Inflated form of F3: "skilled in SQL/Tableau" | "I'm skilled in SQL and Tableau." |

## Reading the interviewer

- **Career pattern (your research note):** pricing and monetization roles, with one early-stage startup chapter.
- **Self-described style (public profile):** "relentlessly data-driven."
- **Practical implications:**
  1. Expect every metric probed to its assumptions (A1 to A3).
  2. Cases will lean toward pricing, packaging and unit economics, his native language (C2, C4).
  3. Builder stories from a startup-style context land with him; expect a probe on big-company pace. Describe the consumer-tech years in their own terms and do not apologize for them.
  4. Mirror his vocabulary where it is accurate: "revenue model" maps onto his monetization language.
- **Shared jump:** none offered. Her material shows no startup chapter, so there is no shared professional path to point at.

## Persona table

Relationship prior for a peer round: Peer Evaluator and Data-Driven Prober dominant. Interviewer signals move the Prober up.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy | Weight |
|---|---|---|---|---|
| Data-Driven Prober | Two levels deep on every number and CV line | Very likely: peer prior, plus a self-described data-driven profile | Know what you can say about how each figure was counted; name the weakest assumption first; say plainly when you don't know | 5 |
| Peer Evaluator | Seam questions, disagreement, credit, what the hire adds to his load | Very likely: this is the peer lane | Reciprocity framing; seam principles rather than claimed knowledge; one disagreement story | 5 |
| Case / Strategist | Live GTM and pricing problems on Compass, bundling and whitespace | Likely: the pricing spine tilts cases toward pricing; the bundling threat and Compass are live problems | Clarify, then structure; think aloud; challenge one premise | 4 |
| Skeptic | Probes the stated gap and the transferability rows | Likely: F1, F4, F7 are where a peer would press | Rehearse the single most predictable objection until plain; honest bridges only | 3 |
| Pressure | Time-boxed attribution challenges on the headline figure | Possible: peer rounds rarely pressure, but the $400M figure invites it | Pause; hold a stated position through two follow-ups; concede a specific limit | 3 |
| Conversational | Casual openers and a casual AI question | Possible: casual questions on JD topics are still scored | Ninety-second arc; treat casual AI questions as scored | 2 |
| Values / Behavioral | Scenario prompts from a senior-leader or behavioral angle | Possible but low: no published values, no values-style round detected | Select a story; say plainly where the material shows none | 2 |

Total: 24 questions, within the 18 to 26 band.

## Question banks

### A. Data-Driven Prober (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how the ~$400M uplift was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Say what you proposed, and that the uplift was credited with it. Then, in your own words: how it was counted, what it is most sensitive to, the assumption you would defend least, and which part was yours. Answer slot: if you specified the attribution, say how; if there was no such step, or it was not yours, say so plainly and return to the change you proposed. | The headline figure is the likeliest prober target. EXP because it tests attribution. |
| A2 | "Which assumption behind that uplift would you defend least?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Name the weakest assumption before he does. If you do not know how it was counted, say: "I don't know how the attribution was modeled." Do not name an assumption the material does not carry; the slot in A1 applies. | Weakest-assumption move: it turns a gotcha into a credibility gain. |
| A3 | "Your partner-level revenue model: what inputs did you choose, and what did you leave out?" | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" | Name the inputs you chose and one you left out, only what you can repeat under a second question. Answer slot: if you chose the inputs, say which and why; if others set them, say so and say what your part was. Hold through follow-ups by returning to how the model was used in negotiations. | Premised on F1's model. Tests whether she can explain it under pressure. |
| A4 | "Which analysis have you run yourself in SQL or Tableau, and how did you check it?" | JD | [grounded] "skilled in SQL/Tableau" | Open prompt: choose one analysis you ran alone, with its question, its data and one check you ran. If you have none you ran alone, say so plainly and say how you would validate an analysis. The quote carries a skill, not an analysis; give no analysis. | Open prompt on the JD's independence requirement (F3). This is the probe that exposes an unevidenced "skilled." |
| A5 | "Which AI tool has changed something in your work, and what?" | JD | [grounded] "uses AI tools daily" | Name one tool and what it changed, in your words. Answer slot: if nothing changed, say so and describe how you use the tool day to day. Describe nothing you built. | AI is a plus in the JD; a daily-use claim invites a concrete probe (F6). |

### B. Peer Evaluator (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our teams sit side by side. Where's the seam between your GTM work and sales strategy, and what happens when we disagree on a number?" | VAL | [generic] question; [grounded] "set annual volume targets with cross-org consensus" (your message) | Propose seam principles: who owns the number, who makes the trade-off, how a dispute escalates. Do not claim to know Northwind's seam. For disagreement, use the nearest story the material carries, the consensus on the volume target, in her words; if no disagreement occurred, say so. | Seams and disagreement are the peer's core probe; cross-functional influence is the JD line it draws on. |
| B2 | "Partner motion: what would you design first for the new lines, and what would you need from my team?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | Lead with what you would need from the partner-facing team and one design principle. Hold the model at its own scope: an input to a partner decision, not a partner motion. Answer slot: if you designed a partner program or channel terms, say how; if your part was the model or its inputs, say so and what carries over. | Partner motion is a required JD item (F4). The peer checks what the hire adds to his load. |
| B3 | "Our sales org has run enterprise expansion for years. Why would I want someone who hasn't set a quota making GTM calls on two new lines?" | JD | [grounded] "No classic sales-ops or quota-setting experience" (your message); [grounded] "set annual volume targets with cross-org consensus" (your message) | Plain acknowledgment: "I haven't set quotas or run sales ops." Then what she did carry, quoted as written: the volume targets, set with cross-org consensus. Concede specifically: quota design should lead with his team. Do not argue she is a sales leader. | The peer form of the highest-ROI objection (D2), in collegial packaging. |
| B4 | "How do you handle credit when work spans teams?" | VAL | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (your message) | Separate what you proposed from how the uplift was credited. Name whose work the change depended on and who else was in the decision. Do not claim sole credit. Answer slot: if credit was split, say how; if it was yours alone, say why. | Credit is the collegial version of A1's attribution probe. |
| B5 | "Whitespace across land, adopt, expand and renew: whose number does that move, yours or mine?" | JD | [grounded] "identify whitespace across land/adopt/expand/renew" (your JD highlights) | Name the lifecycle stage you would start from and what it hands to the sales number, as a principle. Do not claim to know who owns that number at Northwind. | Whitespace is a JD headline; the peer checks ownership. |

### C. Case / Strategist (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Compass is launching. How would you sequence GTM for it and the two new lines across land and expand?" | CASE | [grounded] "an AI copilot launch ('Compass')" (your research note) | Clarify first: which line goes first and what the launch must prove. Then objective, segmentation by lifecycle stage, approach, two metrics, one risk. Think aloud and challenge one premise. No claim about her past. | Case built from a stated priority; scored on structure, not the answer. |
| C2 | "Our main threat is bundling by a much larger platform vendor. How would you price against a bundle?" | CO | [grounded] "bundling by a much larger platform vendor" (your research note); [grounded] "built a partner-level revenue model used in carrier negotiations" (your message) | Start with the pricing question: what the bundle is anchored to and what the customer compares. Use the revenue model as an analogy only, at its scope: it modeled partner-level revenue; it does not show what a bundle does. Name the unit-economics trade-off. | Pricing is his native language; the threat is named in your research note. |
| C3 | "Where is the largest whitespace across land, adopt, expand and renew, and how would you size it?" | CASE | [grounded] "identify whitespace across land/adopt/expand/renew" (your JD highlights) | Segment by lifecycle stage; state the sizing inputs; name the one that most moves the answer. Use no figures you were not given. | Expansion is a stated priority; sizing tests the whitespace requirement. |
| C4 | "Reaching profitability is a priority. Which GTM trade-off would you make first to get there?" | CO | [grounded] "reaching profitability" (your research note) | Pick one trade-off, name a counterweight to growth, and say what would prove you wrong within two quarters. | Profitability is one of three stated priorities; an altitude test. |

### D. Skeptic (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "No classic sales-ops or quota-setting experience" (your message) | Plain acknowledgment: "I haven't set quotas or run sales ops." Then a ramp plan, stated as a plan: what you would learn first and from whom. | Stems from the stated gap (F7). |
| D2 | "You've never set a quota or run sales ops, and this role owns GTM for two new lines. Why should I trust your strategy over my team's?" | JD | [grounded] "No classic sales-ops or quota-setting experience" (your message); [grounded] "built a partner-level revenue model used in carrier negotiations" (your message); [grounded] "set annual volume targets with cross-org consensus" (your message) | **Highest-ROI prep in this pack.** Hold: "I built a partner-level revenue model used in carrier negotiations, and I set annual volume targets with cross-org consensus." Concede specifically: "I haven't set quotas or run sales ops, and I'd want your team to lead quota design." Hold through two follow-ups by returning to the model and the targets; add nothing to them. Answer slot: if you held a target decision alone, say which; if the consensus was not yours to set, say so. | Aimed at F1 and F7 together. The probe will come in some form, so the non-defensive answer is rehearsed here, to the second follow-up. |
| D3 | "Where did the model's output change a negotiation, and where did it not?" | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" (your message) | Say what the model was used for and what you did not control. Answer slot: if you were in the negotiations, say your part; if you were not, say so and say how the model was used. | Attribution probe on F1's model; a skeptic tests whether the model's reach is claimed beyond its scope. |

### E. Pressure (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who has run enterprise GTM?" | JD | [grounded] "9 at a large consumer-tech company in product strategy & ops" (your message) | Pause and restate. Then sixty seconds anchored in the product strategy and ops years and the model. Hold the case: the model and the consensus targets, as stated. Concede a specific limit: you have not run enterprise GTM. Do not fold on the case. | Pressure stem; the time box tests composure on the F1 gap. |
| E2 | "That ~$400M figure: how much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (your message) | Hold the sentence: you proposed the change, and the uplift was credited with it. If you cannot split your share from the team's, say that plainly and name what you can split. Do not claim a share you cannot state. | Pressure on attribution; the hold is one the quote carries, and the concession is the honest limit. |
| E3 | "Consensus is a polite word for nobody being in charge. Who signed off your volume target?" | VAL | [grounded] "set annual volume targets with cross-org consensus" (your message) | Name the decision-maker in your words. If you did not hold the final call, say so and say what you did hold. Do not let the consensus be recast as sole ownership. | Pressure on consensus; tests whether the influence claim survives. |

### F. Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | VAL | [grounded] "2 years strategy consulting at a top firm" and "9 at a large consumer-tech company in product strategy & ops" (your message) | Ninety-second arc: the consulting years, the consumer-tech years, then the model and the targets. Keep the scope of the quoted sentences; add no titles or dates. | Casual opener, still scored; the arc is the rehearsal. |
| F2 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" (your message) | Name one or two tools and what you use them for, in your words. Say where you don't trust the output. Describe nothing built with AI. | Casual form of the AI plus, treated as scored. |

### G. Values / Behavioral (weight 2)

No values are published and no values-style round was detected, so no values cheat sheet is included.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] question; nearest story: [grounded] "set annual volume targets with cross-org consensus" (your message) | Select a time you put a number senior people did not want. If none comes to mind, say so plainly, then give the nearest thing the material carries: the consensus on the volume target, in her words, with what she actually said. | Persona stem. The material carries no unpopular-truth story, so the honest branch is the rehearsal. |
| G2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Select a time. If none comes to mind, say so and say how you would handle it. The material carries no customer story; do not invent one. | Persona stem. Largest honest gap in the values bank. |

## Requirement coverage

| JD requirement or company priority | Question IDs |
|---|---|
| Own GTM strategy for two new product lines | C1, D2 |
| Identify whitespace across land/adopt/expand/renew | B5, C3 |
| Run independent analysis in SQL and Tableau | A4 |
| Partner-motion design experience required | B2 |
| Strong cross-functional influence | B1, E3 |
| AI experience a plus | A5, F2 |
| Stated gap: sales-ops and quota-setting (role-family) | B3, D1, D2 |
| Priority: enterprise expansion | C3 |
| Priority: AI copilot launch ("Compass") | C1 |
| Priority: reaching profitability | C4 |
| Threat: bundling by a larger platform vendor | C2 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Your career has run through pricing and monetization. Where do you see pricing decisions get lost between product and sales?" | Ties to his own path; turns an interview into a peer conversation. |
| R2 | "What did the startup chapter teach you about pricing that a large organization tends to hide?" | Uses his public early-stage chapter; shows you researched him, not only the company. |
| R3 | "Which Compass number do you watch first to know whether expansion is moving?" | Data-driven register; ties to the stated launch priority. |
| R4 | "What could a new person do in the first month that would genuinely help your team?" | Peer reciprocity: what she brings his team, not only what she needs. |
| R5 | "How do sales strategy and GTM strategy split ownership of whitespace today?" | Opens the seam conversation the peer will judge. |
| R6 | "How has the push to profitability changed what your team is asked to model?" | Altitude question; shows she reads the stated priorities. |

## Sources

- Provided: your message (JD highlights, candidate profile, round and interviewer details) and your research note (three priorities, bundling threat).
- Research tier: L1, searches 2 of 6, fetches 0 of 2. Search permission was refused by the host; the calls below were sent and refused, and were not retried.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Northwind Data company values | unavailable | Calls refused: "Northwind Data company values" (refused). No values cheat sheet; the round is not values-style, so section 10 does not apply. |
| 2. Northwind Data interview process, peer round | unavailable | No call sent; host search refused. Would have confirmed the loop structure. Persona weights follow the stated peer round. |
| 3. Northwind Data strategy and recent news | unavailable | Calls refused: "Northwind Data Compass AI copilot launch" (refused). Would have replaced the research note's priorities with current sources for C1 to C4. |
| 4. Dan Kovac, Northwind Data | unavailable | No call sent; host search refused. Would have added public talks and writing for the interviewer read. |
| 5. Representative JD for this role | skipped | Your JD highlights fix the fit snapshot and the JD-tagged questions. |

## Upgrade menu

- Full JD text → F1 to F6 move from highlight quotes to verbatim `[grounded]` requirements, and any gate (location, work authorization) would appear as a gate row.
- Her CV sentences → evidence quotes become her own words; the model file or the ~$400M attribution note would move F1, F4 and A1 toward high confidence.
- Recruiter's note on round focus or any pre-declared exercise → reweights the persona table and adds a graded section if one is declared.
- Search permission granted → reruns targets 1 to 4; C1 and C2 get current Compass and bundling sources.
- Dan's public talks or posts → his recurring themes become questions in the peer bank and sharpen C2.
- Her answers to the answer slots, given outside a drill → new quoted material; rows F1, F2, F4 and D2 regenerate.
