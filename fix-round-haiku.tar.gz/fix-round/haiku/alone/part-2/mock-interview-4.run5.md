Your prep pack is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-alone-part-2-rooms-case-4-denied-c0f528f0/0b5c8f0e-f90a-4cc5-9da3-44a64a3151e9/scratchpad/quartzline_product_manager_platform_apis_interview_pack.md`. It is built from your dossier. Two things to know first:

- **Company research didn't run.** Web search was refused in this session, so the pack has nothing on Quartzline's values, strategy or interview process. The company-specific parts are generic.
- **The dossier is about three months old** (generated 2026-08-14). If the posting or the squad structure changed since then, its open questions may have moved.

The pack's highest-ROI prep is A1, the objection the underwriter named: "You've never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" The guidance is to hold on the integration scope, concede the title and roadmap plainly, then give a ramp plan. Ask me to play it as a live drill if you want to rehearse it.

I can also update `tuesday-dossier.md` with a `pack_feedback` section recording what this prep exposed.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quartzline_product_manager_platform_apis_interview_pack.md -----
# Interview pack: Product Manager, Platform APIs at Quartzline

**Round:** 45-minute conversation with the hiring manager. Interviewer name not given, so the pack uses round-type priors only.
**Built from:** `tuesday-dossier.md` (dossier_version 1.1, generated 2026-08-14, decision conditional_go). See Sources for what it supplied and how old it is.

## How to use + type key

Personas describe how a question arrives. Types describe what is being scored. Guidance is scaffolding, not a script. Rehearse the shape and the honest branches, not the sentences.

| Type | Meaning |
|---|---|
| JD | Can you do the listed job, including its gaps |
| EXP | Do your past claims hold up under scrutiny, and what exactly was yours |
| CASE | Structure and reasoning on a live problem from this role |
| VAL | Past behavior against published values (not used: no values round detected) |
| CO | Company and strategy knowledge (not used: no research ran) |

## Fit snapshot

Requirements are quoted from the dossier's `role_profile`. Evidence is quoted from the dossier's `verified_candidate_evidence`. No CV or posting text was provided.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" — dossier role_profile R1 | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier row (verified_candidate_evidence 1) | low | [grounded] | transferability | Adjacent work only. Say the integrations in the quote's words and let the interviewer judge the overlap. The PM title and years are not yours; see the plain acknowledgment in the prohibited list. Do not present the integrations as PM years. |
| F2 | "Shipped API or platform products" — dossier role_profile R2 | "Wrote the internal integration playbook her team uses" — dossier row (verified_candidate_evidence 2) | high | [inferred] | transferability | Not on the dossier's weak list. This pack's reading: the playbook shows integration work done against a vendor's APIs, not a shipped API product. Say what the playbook covers, in its words. Expect a probe on whether it was ever released as a product. |
| F3 | "Stakeholder management across engineering, sales, customers" — dossier role_profile R4 | "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier row (verified_candidate_evidence 3) | medium | [grounded] | presentation | The quote reaches customers and product in other terms. It does not name engineering or sales. Reword only what the quote says. Confidence note: limited inspectable proof, so volunteer that before a prober finds it. |
| F4 | "Technical fluency: API docs, schemas" — dossier role_profile R3 | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier row (verified_candidate_evidence 1) | low | [grounded] | discovery | The quote touches integrations and architecture without showing docs or schemas. Answer slot: if you worked from the API docs or schemas on those integrations, say which and what you did with them; if that was not your part, say so plainly and return to the architecture step, which is what the material carries. |
| F5 | "Agile delivery experience" — dossier role_profile R5 (preferred) | none given | none | [grounded] | discovery | The dossier grades this low; no quote in the material reaches it, so this pack grades it none. Answer slot, clarify strategy: see A4. |
| F6 | "Owning a roadmap and prioritization authority" — dossier uncertain_or_weak_areas, R1 sub-claim | none given. The dossier records the absence in its acknowledge_gap area, confidence none | none | [grounded] | capability | Plain acknowledgment from the dossier's acknowledge_gap area and prohibited_claims: "I have not owned a product roadmap or set prioritization for an engineering squad." No bridge. Ramp plan, stated as a plan and not as a past: [generic] first weeks on how the two squads take roadmap decisions, then a proposed priority set brought to the squad leads. |

Gap rows are graded from the dossier's own `uncertain_or_weak_areas` and `confidence` fields. The R2, R3 and F5 rows and the F1 and F4 placements are this pack's reading of the quotes and are marked [inferred] or treated as answer slots accordingly.

## Prohibited list

From the dossier's `prohibited_claims`, plus inflated-form entries built here from the quotes. Nothing in the guidance below asserts, softens or implies any of these.

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | dossier prohibited_claims (sourced) | Plain acknowledgment: "I have not held a product manager title or role." Then F1's quote at its own scope. |
| Having owned a product roadmap | dossier prohibited_claims (sourced) | F3's quote at its own scope: the sessions fed client evidence to product. Plain acknowledgment from F6. |
| Having set prioritization for an engineering squad | dossier prohibited_claims (sourced) | Plain acknowledgment from F6. Limit as the pack's observation: the material does not show prioritization for an engineering squad. |
| Owned the integration roadmap | Inflated form of F3 | F3's quote at its own scope. The pack's observation: the material says the sessions fed evidence to product, not that the candidate owned a roadmap. No first-person negative. |
| Shipped an API product | Inflated form of F2 | F2's quote at its own scope: an internal playbook. |

## Persona weights

No interviewer profile, so weights come from the hiring-manager prior, adjusted by the dossier's own unknowns.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | The title and roadmap objection, the day-one weakness question, the ask for a plan | High. A hiring manager is buying capability and derisking the gaps the dossier names. Weight 5, with 4 questions | Hold the scope, concede the title plainly, give the ramp plan as a plan |
| Case/Strategist | Live problems on partner integrations, adoption and squad trade-offs | High. The role is a live roadmap problem. Weight 3, with 4 questions | Clarify, then structure; ask for the baseline before diagnosing |
| Data-Driven Prober | Counting the 30+, which parts were yours, the medium-confidence sessions | Medium. 30+ is a headline figure and the sessions carry a stated limit. Weight 3, with 4 questions | Defend-the-number slots; volunteer the limit |
| Pressure | "How much of that was actually you?" and the playbook's reach | Medium. A short round can still test composure under attribution pressure. Weight 2, with 2 questions | Hold then concede, two follow-ups |
| Conversational | The opener walk-through and a casual question on discovery | Lower but scored. Weight 2, with 2 questions | A 90-second arc drawn from the quotes |

## Question banks

Provenance cells carry the candidate's quoted sentences that each guidance cell rests on. Sources for the dossier are its `verified_candidate_evidence` and `role_profile` lines. Session total is 16, below the usual 18 floor, because a 45-minute round cannot rehearse more; the depth sits on A1.

### A. Skeptic (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier row); negative sourced from the dossier's acknowledge_gap and prohibited_claims fields | Hold the scope: name the integrations in the quote's words and let them judge the overlap. Do not argue the three years. Concede the title and roadmap plainly: "I have not held the PM title or owned a roadmap." Then the plan, [generic]: the first 60 days on roadmap decisions with the two squad leads. Hold through two follow-ups; concede on the second. About 100 seconds. | The underwriter named this as the likeliest objection, so it gets the deepest rehearsal. The premise is sourced, so it may be asked as worded. |
| A2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] dossier acknowledge_gap area, field uncertain_or_weak_areas: "Owning a roadmap and prioritization authority" | Name roadmap ownership and prioritization authority first, plainly, with no bridge. Then the ramp plan as a plan: the first weeks on how the two squads take roadmap decisions and partner discovery, then a proposed priority set brought to the leads. About 60 seconds. | F6. The underwriter found no evidence, so the answer is acknowledgment and a plan, not a bridge. |
| A3 | "Walk me through an API schema or doc you've worked from, and your part in it." | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier row) | Answer slot: if you worked from the API docs or schemas on those integrations, say which and what you did; if that was not your part, say so plainly and return to the architecture step the quote carries. | F4. The JD's R3 raises docs and schemas, and no quote carries schema work, so the second branch is the honest route. |
| A4 | "Tell me about your agile delivery experience." | JD | [grounded] "Agile delivery experience" (dossier role_profile R5) | Answer slot: your material does not show the agile practice itself. If you ran sprints, planning or reviews on the integrations, say which and how. If you worked to a different delivery rhythm, say so, and say what you would want to confirm about how this team defines agile. | F5. Clarify strategy: no verified entry speaks to this requirement, so the second branch carries the honest route. |

### B. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A partner's integration fails UAT two weeks before go-live. What do you do?" | CASE | [generic] | Clarify what fails and for whom. Objective: get the partner live without breaking another team's release. Segment by partner and endpoint. Approach with two options and a recommendation. Metrics: time to fix, partner confidence. Risks: rushing a fix into the other squad's work. Make no claim about a past UAT. | A live problem from the role's delivery and partner work. It asks about no past, so it makes no claim. |
| B2 | "Partner API adoption is flat this quarter. Where do you start?" | CASE | [generic] | Ask for the baseline and how adoption is counted before proposing a cause. Then split by partner segment and look for where integrations stall. Name the one metric you would trust least. | The dossier lists the adoption baseline as unknown. The strongest answer asks for the number before it explains it. |
| B3 | "Partner A wants an endpoint one squad cannot staff this quarter. How do you decide?" | CASE | [generic] | Say who decides, and ask the squad leads for capacity and dependencies. Frame it as partner value against squad load, and name a decision date. Do not claim authority over either squad. | Ties to R4 and the dossier's decision-authority unknown. |
| B4 | "Engineering and sales want different things from the same partner API. Whose view wins, and how?" | CASE | [generic] | Clarify the decision rights first. Then name a principle (customer commitments against internal capacity) and how you would escalate. Claim no past resolution of such a conflict. | Covers R4's sales-and-engineering half, which no quote reaches. |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "How was the 30+ counted, and what did the count include?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier row) | Defend-the-number slots: say how the 30+ was counted, in your own words. If you counted go-lives, say so. If you kept no count, say so plainly. Name the assumption behind the 30+ you would defend least; if you have none, say so. | The headline figure. The slot is the only honest form the material allows. |
| C2 | "Of the 30+, which parts were yours and which were the team's?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier row) | Answer slot: name which of scoping, requirements, architecture, UAT and go-live you carried, and where the team carried it. | The defend-the-number slot for whose share the figure is. |
| C3 | "Your roadmap-input sessions — what did they move, and how do you know?" | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" (dossier row, medium confidence) | Volunteer the limit first: say what went into the sessions and to whom. If you have no record of what product did with it, say that. Do not supply a before-and-after. | The dossier's medium-confidence seam. A prober will find it, so the limit comes first. |
| C4 | "Which of the 30+ integrations went worst, and what did you change after?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier row) | Answer slot: if one went badly, say what happened and what changed after, in your words. If none did, say so plainly. | The question presupposes an event the quotes do not carry, so the false-premise branch keeps it honest. |

### D. Pressure / Stress

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Those 30+ integrations — how much of that was actually you?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier row) | Hold the quote: you led them end to end, from scoping to go-live. If you did not carry every step yourself, say which the team did. Hold through two follow-ups before any concession. | Composure under attribution pressure. The scoring is in the holding, not the claim. |
| D2 | "Anyone can write a playbook. Who outside your team actually used it?" | EXP | [grounded] "Wrote the internal integration playbook her team uses" (dossier row) | Hold: her team uses it, in those words. Answer slot: if anyone outside your team used it, name them; if not, say so plainly and say how you would find out. Do not describe adoption beyond the team. | Pressure on the playbook's reach. The honest answer is the team-only line. |

### E. Conversational / Rapport

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So — walk me through the journey." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier row); "Wrote the internal integration playbook her team uses" (dossier row); "Ran quarterly roadmap-input sessions feeding client evidence to product" (dossier row) | A 90-second arc in that order: the integrations, the playbook, the roadmap sessions. Name the limit on the sessions before you are asked. Add no motivation claims beyond what you can say in your own words. | The opener. Casual register, still scored. |
| E2 | "What's the hardest part of running discovery with a partner?" | JD | [grounded] "Run discovery with integration partners" (dossier role_profile responsibility) | Open prompt: pick one partner integration from your material and say what it surfaced. If none stands out, say so and describe how you would run discovery. | Covers the discovery responsibility. The honest branch covers having no discovery story. |

## Requirement coverage

| Requirement | Covered by |
|---|---|
| R1 3+ years product management | A1, A2, C4 |
| R2 Shipped API or platform products | A1, C1 |
| R3 Technical fluency: API docs, schemas | A3 |
| R4 Stakeholder management | B3, B4, D2 |
| R5 Agile delivery | A4 |
| Roadmap and prioritization authority (R1 sub-claim) | A2, B3 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" | Tests the decision-authority unknown the dossier flags. Reads as diligence. |
| 2 | "How is partner API adoption measured today, and what is the current baseline?" | The dossier names adoption as a responsibility with no stated baseline. You need the number before you accept. |
| 3 | "How is agile delivery run across the two squads, and where does the PM sit in that cadence?" | Covers R5, the discovery gap. |
| 4 | "When a partner request conflicts with a squad's capacity, who makes the call, and how quickly?" | Ties to B3 and the authority question from a different angle. |
| 5 | "What would the first six months need to show for you to call the hire a success?" | Generic, and useful: it shows you think in outcomes. |

No interviewer profile, so no reverse question ties to the interviewer's own path.

## Sources

- **Provided:** `tuesday-dossier.md` (dossier_version 1.1, job-underwriter, generated 2026-08-14). Consumed: `role_profile`, `handoff_to_mock_interview`. Not present: `evidence_map`, `evidence_state`, `risk_register` (the dossier as pasted shows only those two sections). The dossier is about three months old. If the posting or the squad structure has changed since August, the unknowns it names may have moved.
- **Searches attempted:**
  - "Quartzline values": refused (search permission not granted in this session).
  - "Quartzline Product Manager Platform APIs partner integrations": refused, same reason. This query was for role context and was not a declared target.

**Research tier:** L1, searches 0 of 6 (2 refused), fetches 0 of 2.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quartzline values` | unavailable | Values cheat sheet, section 10. Would have moved it only if a values round was detected; none was. Call refused. |
| 2. `Quartzline interview process` | unavailable | Loop structure. Not sent, because search was refused. Would have checked whether this round is the only one. |
| 3. `Quartzline strategy` / recent news | unavailable | Grounding brief and CO questions. Would have moved the CO bank. No call sent. |
| 4. Interviewer name | n/a | No name was given, so there was no query to form. The interviewer read is absent. |
| 5. Representative JD | skipped | The dossier's `role_profile` fixes the fit snapshot and the JD questions. |

## Upgrade menu

- The hiring manager's name → persona weights from public background, and a reverse question tied to their own path.
- Search permission granted → values, interview-process and strategy research, which would ground the CO bank and check the loop.
- The posting text → requirement lines quoted from the posting rather than the dossier's restatement.
- The CV behind the verified claims → F1, F2 and F3 can move from dossier quotes to CV quotes, and the presentation rows get a second source.
- A record of what the roadmap-input sessions fed to product → C3 can drop its limit and quote the record.
- Recruiter's note on any exercise or deliverable → a graded-deliverable section.
- Prep time before Thursday → a prioritized triage section.
