This is interview prep, so I'll load the mock-interview skill rather than work from memory.
I'll read the reference files the skill names before drafting, starting with the ones that govern personas, questions, and output.
The core rules are clear. Before any research, the skill says to read the research checklist and the interaction grammar's tier section.
The checklist allows about six L1 searches and two fetches. I'm running the three that can change the pack: company values, interview loop, and recent strategy. The interviewer is unnamed, so that target is n/a.
The three web searches were refused by the permission prompt, so I won't retry them. The pack will be built on your message, with the values, loop, and strategy checks marked unavailable. I'll write the pack file now.
Your prep pack is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-alone-part-2-rooms-case-6-denied-80567134/2ca6d43c-c207-414d-8b99-5a12156eca24/scratchpad/larkfield_engineering-manager_interview_pack.md`. It is one loop pack covering all three rounds, built on your message alone. Web search was refused, so the values, loop, and strategy checks are unavailable and marked as such.

# Interview prep pack: Engineering Manager, Larkfield Systems

**Mode:** loop (three rounds). **Candidate:** Yusuf (they/them). **Built on:** your message only (role summary, round schedule, your background). No CV, no full JD, no web research (see Sources).

## How to use

- **Personas** describe how a question arrives. **Types** describe what it scores.
- Type key: **VAL** values/behavioral · **EXP** work-experience deep-dive · **JD** role requirement · **CO** company/strategy · **CASE** live problem.
- Guidance is scaffolding, not a script. Say only what you did, in your own words.

## The loop

| Round | Day | Who | Length | Section |
|---|---|---|---|---|
| 1 | Tue | Director of Engineering (hiring manager, would-be boss) | 45 min | Round 1 |
| 2 | Thu | Panel: two staff engineers and a product manager | 60 min | Round 2 |
| 3 | Mon | VP Engineering, "values and leadership philosophy" | 30 min | Round 3 |

Your message establishes the loop: each round's length, who runs it, and what it holds. Round 3 is a values-style round because the recruiter's words name values as its subject.

## Fit snapshot (shared across rounds)

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "lead two squads building device-management services" (your message) | "3 as a team lead of 6" (your message) | medium | [grounded] | transferability | Words: "I was a team lead of six for three years." Your material shows one team of six, not two squads and not device management, so the bridge stays at one team. Answer slot: if you have coordinated more than one team at a time, say how; if not, say so plainly, then say what you would do in the first quarter. |
| F2 | "own delivery, hiring and growth for 11 engineers" (your message), hiring part | "I run our hiring loop for backend roles" and "about 40 interviews last year" (your message) | medium | [grounded] | presentation | Words: "I run our hiring loop for backend roles; about 40 interviews last year." This rewords only the quote. The loop is for backend roles, and nothing here shows headcount planning for 11 engineers, so expect that probe. |
| F3 | "own delivery" (your message) | "After I pushed a reliability quarter through against roadmap pressure, my team's on-call burden dropped 60%" (your message) | medium | [grounded] | transferability | Words: "After I pushed a reliability quarter through against roadmap pressure, my team's on-call burden dropped 60%." This is adjacent: one reliability quarter, not end-to-end delivery across two squads. The figure is covered by the defend-the-number slots in the banks. |
| F4 | "own delivery, hiring and growth for 11 engineers" (your message), growth part | none given | none | [grounded] | discovery | Your material does not show growth work for engineers. Answer slot: if you have grown engineers, say what you did and what happened, in your own words; if not, say so plainly. |
| F5 | "partner with hardware and product on roadmap" (your message), hardware part | "never owned a hardware-adjacent roadmap" (your message) | none | [grounded] | capability | Words: "I haven't owned a hardware-adjacent roadmap." Then how you would learn hardware roadmap work, said as a plan, never as a past. Never a claim to hardware roadmap work. |
| F6 | "partner with hardware and product on roadmap" (your message), product part | none given | none | [grounded] | discovery | Your material does not show roadmap work with product. Answer slot: if you have shaped a roadmap with a product manager, say what you did; if not, say so plainly. |
| F7 | none in the role text: your strongest story, used in the Values and Pressure banks | "pushed a reliability quarter through against roadmap pressure" (your message) | medium | [grounded] | none | Not a requirement. The quote carries the Values and Pressure banks. Its figure is probed under F3. |

**Observation, not words for you:** your material says you led one team of six and ran backend hiring. It does not show two squads, device management, hardware roadmaps, or growth work for engineers.

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Owned a hardware-adjacent roadmap | Negative you stated (F5) | Plain acknowledgment: "I haven't owned a hardware-adjacent roadmap." No slot. |
| Managed managers | Negative you stated: "I've never managed managers" (your message) | Plain acknowledgment: "I haven't managed managers." No slot. |
| Led two squads | Inflated form of F1 | F1's quote at its own scope: "3 as a team lead of 6." Limit, as the pack's observation: your material shows one team of six. |
| Owned delivery for 11 engineers | Inflated form of F3 | F3's quote at its own scope. Limit, as the pack's observation: your material shows one reliability quarter. |
| Designed the hiring loop | Inflated form of F2 | F2's quote at its own scope: "I run our hiring loop." Limit, as the pack's observation: your material says running the loop, not designing it. |
| The 60% drop was yours alone | Inflated form of F3 | The sentence says "after," not "because." The figure's attribution is the answer slot a figure raises (1C2). |

## Round 1: Director of Engineering (hiring manager), 45 min

**Persona weights.** Relationship prior for a hiring manager is Case/Strategist and Skeptic. No interviewer profile, so no adjustments.

| Persona | Weight | Why | Counter-strategy |
|---|---|---|---|
| Case/Strategist | 4 | Hiring managers buy capability and test it on their roadmap | Clarify, then structure; challenge one premise |
| Skeptic | 4 | Hiring managers derisk gaps; F1 and F5 are the gaps | Plain acknowledgment, bridge only from quoted evidence, then a ramp plan |
| Data-Driven Prober | 2 | Headline numbers (40 interviews, 60%) invite it; no profile signal | Name the weakest assumption before they do |
| Pressure | 2 | Plausible in 45 minutes with a director; no profile signal | Pause, restate, hold through two follow-ups |
| Conversational | opener only | Low prior here, so no bank | Use your 90-second arc for the opener |

**Highest-ROI prep: 1B2.** The hardware-roadmap objection is the only capability gap in the snapshot, and the role states the hardware line as a headline. It will come up in some form in every round.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 1A1 | "Two squads are shipping device-management services, and the hardware team's firmware change lands three weeks late. What do you do this week?" | CASE | [generic] | Think aloud: clarify what the late change blocks, state the objective, then who is affected and how. Challenge one premise, such as the date being fixed. Give a decision, not a survey. | A live problem from the role; presupposes nothing about your past. Covers the hardware and delivery halves (F3, F5). |
| 1A2 | "What would you do in your first 90 days with eleven engineers, two squads and growth as part of the job?" | JD | [generic] | Listen first: one-to-ones, the delivery state, the hiring state. Then one priority per squad. If you have grown engineers, say how and what happened. If not, say so plainly and say what you would do first. | Covers the scope and growth requirement; the second branch is the honest form of F4. |
| 1A3 | "Product wants a roadmap date the hardware team cannot commit to. How do you decide?" | CASE | [generic] | Clarify what each date protects and who bears the cost of being wrong. Decide by decision type, not by team loyalty. Name what would change your decision. | Tests the JD's partnership line, where F6 has no evidence. A live problem, so nothing about your past is presupposed. |
| 1A4 | "Walk me through how you would plan hiring for these two squads over the next two quarters. What do you need to know first?" | JD | [grounded] "I run our hiring loop for backend roles" (your message) | Clarify headcount, role mix and what is already open. Then the loop: stages, who decides, the bar. Say that your loop experience is backend hiring, and say which parts transfer. | F2 is the evidence; the question tests the part it does not cover. |
| 1B1 | "You have led one team of six. This role is two squads and eleven engineers. How do you lead that?" | JD | [grounded] "3 as a team lead of 6" (your message) | Hold to your scope: one team of six for three years. Answer slot: if you have coordinated more than one team at a time, say how; if not, say so plainly, then say what you would do in the first quarter. Do not describe two squads you have led. | F1 is transferability; this is the scope probe. |
| 1B2 | "You have never owned a hardware-adjacent roadmap. Why should a hardware partner trust your roadmap?" | JD | [grounded] "never owned a hardware-adjacent roadmap" and "pushed a reliability quarter through against roadmap pressure" (your message) | **Highest-ROI prep.** Open with the plain acknowledgment: "I haven't owned a hardware-adjacent roadmap." Then the one adjacent fact you stated: a reliability quarter pushed through against roadmap pressure. Hold through two follow-ups by returning to that roadmap pressure, not to hardware. Concede the hardware half once and clearly: "that part is new to me," then how you would learn it, as a plan. Answer slot: if you have worked with a hardware team at all, say how; if not, say so plainly. | F5 is the only capability row, and the hardware line is headline JD content. Deepest rehearsal: three follow-up levels. |
| 1B3 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "never owned a hardware-adjacent roadmap" (your message) | Name the weakest part honestly: the hardware roadmap, the one thing your message says you have not done. Bridge only from roadmap pressure you held. Then a first-month plan. Do not name a second weakness you have not stated. | Skeptic stem. The answer should match 1B2 in shorter form, because interviewers compare notes across rounds. |
| 1B4 | "Tell me how you have grown an engineer's career." | JD | [grounded] | Open prompt: choose a real instance. If you have one, say what you did and what happened, in your own words. If not, say so plainly, then say what you would do for each engineer in the first quarter. | No quote supports growth work, so the honest answer is the slot. Label is the JD requirement's source. |
| 1C1 | "Walk me through how the 40 interviews were counted." | EXP | [grounded] "about 40 interviews last year" (your message) | Defend-the-number, in your own words: how the count was made, what it is sensitive to, the assumption you would defend least, and which part was yours. Name the weakest assumption before they do. | Headline figure on your message; the probe tests what was yours. |
| 1C2 | "How was the 60% counted, and what part of that drop was yours?" | EXP | [grounded] "After I pushed a reliability quarter through against roadmap pressure, my team's on-call burden dropped 60%" (your message) | Defend-the-number, in your own words: how the figure was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. If you do not know how it was counted, say so plainly. Keep "after" as "after." | Your strongest number. The probe is likely; the sentence supports "after," not "because." |
| 1D1 | "Sixty seconds: why should we hire you over a candidate who has owned a hardware roadmap?" | JD | [grounded] "never owned a hardware-adjacent roadmap" and "pushed a reliability quarter through against roadmap pressure" (your message) | Pause, then restate the question. Give the reliability quarter in one sentence and concede the hardware gap in one sentence. Hold through two follow-ups; do not fold on the quarter, and do not claim hardware work. | Pressure stem. Tests whether the honest answer holds under time. |
| 1D2 | "Sixty seconds on your team of six: what did it own, and what did you decide within it?" | EXP | [grounded] "3 as a team lead of 6" (your message) | Time-boxed: the team's scope in one sentence, then your part in one sentence. Answer slot: if you set priorities or made calls, say which; if not, say so plainly, then say what you did. | Pressure time-box on F1's scope. |

**Reverse questions (Round 1).** No profile for the Director, so none ties to their career path.
- "What would a strong first 90 days look like here?" Why it lands: it makes the scope conversation concrete and shows you are planning, not pitching.
- "Where is delivery most at risk on the device-management services right now?" Why it lands: it asks about the work, and shows you read the role.
- "Which roadmap decisions sit with the hardware team, and which with product?" Why it lands: it tests the partnership line directly, and the answer shows where you would be a tiebreaker.
- "What does the hiring plan for the two squads look like over the next two quarters?" Why it lands: hiring ownership is in the role text, and this shows you read it closely.
- "What would make you say, a year from now, that this hire was the right call?" Why it lands: it hands the hiring manager the success criteria they must answer.

## Round 2: Panel (two staff engineers, one product manager), 60 min

**Persona weights.** Names are unknown, so weights apply to the panel as a blend. Staff engineers read as peers (Peer Evaluator and Prober). The product manager reads as Case/Strategist and Peer. Assign per member once names are known.

| Persona | Weight | Why | Counter-strategy |
|---|---|---|---|
| Peer Evaluator | 4 | Peers price what the hire adds to their team and their seams | Propose seam principles; name what you bring their team |
| Data-Driven Prober | 3 | Staff engineers read the CV closely; 40 and 60% will be probed | Name the weakest assumption; say plainly what you do not know |
| Case/Strategist | 2 | The PM's native register: roadmap cases | Clarify, then structure |
| Skeptic | 2 | Background-gap probes can come from any panelist | Plain acknowledgment, then bridge |

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 2F1 | "Our teams sit side by side. Where is the seam between your squads and ours, and what happens when we disagree?" | JD | [grounded] "pushed a reliability quarter through against roadmap pressure" (your message) | Propose seam principles, not a map you do not know. Name one principle for disagreement. If you disagreed with a peer team, say what about and how it ended; if not, say so and give the principle you would use. | Peer stem on the JD's partnership line. Your nearest disagreement is the reliability quarter. |
| 2F2 | "How do you handle credit when delivery spans two teams?" | JD | [generic] | Answer slot: if you have a case where credit was shared across teams, say who did what, in your own words; if not, say so plainly and give the rule you would use. | Peer probe on credit. No quote carries it, so the answer is a slot. |
| 2F3 | "What do you need from a peer team to make a roadmap commitment you can keep?" | JD | [generic] | Reciprocity framing: name what you need, then what you bring their team. State the mechanism as a principle, not as a past. | Dependencies are the peer panel's concern; reciprocity weighs heavily here. |
| 2F4 | "If reliability work competes with a feature product wants, who decides?" | JD | [grounded] "pushed a reliability quarter through against roadmap pressure" (your message) | Answer slot: if you made that call, say how; if someone else set it, say so plainly and say what you pushed for. Hold the decision you actually made. | The reliability quarter is the only roadmap-pressure fact you stated. |
| 2C1 | "Your hiring loop: which stage predicts a good hire best, and how do you know?" | EXP | [grounded] "I run our hiring loop for backend roles" (your message) | Answer slot: if you measured stage outcomes, say which stage and what you saw; if not, say so plainly and say what you would look at first. | Prober on the loop, which is your strongest hiring evidence and backend-only. |
| 2C2 | "Walk me through how that number was counted." | EXP | [grounded] "After I pushed a reliability quarter through against roadmap pressure, my team's on-call burden dropped 60%" (your message) | The same defend-the-number slots as 1C2, in your own words. If you do not know how it was counted, say so. | A staff-engineer panel will ask the denominator. |
| 2C3 | "Which assumption behind that on-call figure would you defend least?" | EXP | [grounded] the same on-call sentence (your message) | Name it yourself before they ask: the assumption you would defend least, in your own words. If you have no such assumption in mind, say so. | The weakest-assumption move, required for metric answers. |
| 2A1 | "Sketch the first quarter for two squads that depend on a hardware release date. What do you need to know first?" | CASE | [generic] | Clarify: which services depend on the release, what slips if it does, who has to say so. Then objective, segmentation, approach, metrics, risks. Think aloud. | A live problem on the partnership line; nothing about your past. |
| 2A2 | "Product wants a feature that adds load to device management next quarter; reliability says no. How do you decide?" | CASE | [generic] | Clarify impact, risk, and who bears each. Challenge one premise, such as the feature date. Give a decision and what would change it. | The PM's register; tests the roadmap line. |
| 2B1 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "never owned a hardware-adjacent roadmap" (your message) | The same honest answer as 1B3: hardware roadmap, in one sentence, then the bridge from roadmap pressure you held, then a first-month plan. Concede the hardware half once and clearly. | Skeptic stem. Match round 1, because panelists compare notes. |
| 2B2 | "I don't see device management in your background. How would you handle that in this role?" | JD | [grounded] "pushed a reliability quarter through against roadmap pressure" (your message) | Answer slot: if you have worked on device or embedded systems, say what; if not, say so plainly, then say what you would learn first and from whom. Do not claim device work. | Skeptic stem for the lead requirement. The interviewer's observation matches your material. |

**Reverse questions (Round 2).**
- "What could a new person do in their first month that would genuinely help your team?" Why it lands: a reciprocity question, weighted heavily by peer panels.
- "Where do roadmap commitments to the hardware team most often slip, and why?" Why it lands: it shows you already think about the seam.
- "How do you decide when reliability work gets roadmap time?" Why it lands: it follows up 2F4 and shows you listened.
- "What do you wish the engineering manager did in the first quarter?" Why it lands: collegial, and gives you the panel's own priorities.
- "Which decisions would you want the manager to make without asking you?" Why it lands: it asks for the autonomy line directly.

## Round 3: VP Engineering, values and leadership philosophy, 30 min

**Persona weights.** The recruiter's words make values the subject of this round. Executive altitude also pulls in Pressure and Case.

| Persona | Weight | Why | Counter-strategy |
|---|---|---|---|
| Values/Behavioral | 4 | The recruiter named values and leadership philosophy as this round's subject | Map each answer to one instance from your message, with its honest branch |
| Pressure | 2 | Executive composure in 30 minutes | Pause, hold, concede once |
| Case/Strategist | 2 | Skip-level prior, strategy-heavy; no strategy research ran | Clarify; say what you would need to know |
| Conversational | opener only | Plausible open; no bank | 90-second arc |

Published values are not in hand, so no values cheat sheet is built, and the VAL questions use the recruiter's wording as their raising source, not named values.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 3E1 | "What is your leadership philosophy, and where did it come from?" | VAL | [grounded] "pushed a reliability quarter through against roadmap pressure" (your message) | Open prompt: name one principle you acted on, then give the reliability quarter as the instance. Beats the quote states: a reliability quarter, roadmap pressure, pushed through. Answer slot: the stake, and what you told whom. If you cannot name a principle you acted on, say so plainly and give the nearest instance. | The recruiter's words raise leadership philosophy. The principle is yours to name. |
| 3E2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "pushed a reliability quarter through against roadmap pressure" (your message) | Open prompt. The reliability quarter fits only if the truth you told was unpopular with leadership; if not, say so and give the nearest instance. Answer slot: what you said, to whom, and how it landed; if it did not land, say that. | Persona stem for a values interviewer. Your quote carries roadmap pressure, not the truth itself. |
| 3E3 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Answer slot: if you did, say what the metric was and what you chose; if not, say so plainly and say what you would choose now. Do not supply a customer you did not serve. | Persona stem. No quote carries a customer story. |
| 3E4 | "When two things you value pull in opposite directions, what do you do?" | VAL | [grounded] "values and leadership philosophy" (your message, the recruiter's words) and "pushed a reliability quarter through against roadmap pressure" (your message) | Open prompt. Name a conflict you have actually faced. The nearest instance is delivery against reliability in the reliability quarter, in your own words. If you have no such instance, say so plainly. | Values round prior. The recruiter's words raise the theme. |
| 3D1 | "Sixty seconds: why leave a payments company for a hardware-adjacent role?" | JD | [grounded] "currently at a payments company" and "never owned a hardware-adjacent roadmap" (your message) | Pause, restate. Give your motivation in one sentence, in your own words, tied to the role text. Hold through two follow-ups; concede the hardware gap in one sentence. Do not describe payments as worse. | Pressure stem on motivation. The hardware gap is still the honest core. |
| 3D2 | "You have never managed managers. Why would you lead eleven engineers across two squads?" | JD | [grounded] "I've never managed managers" and "3 as a team lead of 6" (your message) | Hold: restate the scope you have, one team of six for three years. Concede in one sentence that the manager layer is new, and say how you would learn it. Do not claim managing managers. Hold through two follow-ups. | Pressure on your stated negative. The premise is your own sentence, so it may be used. |
| 3A1 | "If you were running engineering for a device company of about 600 people, what would you change in your first year?" | CO | [generic] | Clarify what you would need to know before changing anything: current priorities, the hardware plan, the company's stated values. Give two changes and what would make you drop one. Do not claim knowledge of their strategy. | Without strategy research, CO stays generic. The answer should name what it needs, not pretend. |
| 3A2 | "Two squads' reliability and feature demand conflict at executive level. How would you bring that trade-off to me?" | CASE | [generic] | Structure the trade-off: what each option protects, what it costs, who decides. Recommend one, with the trigger that would change it. Say what you would bring to the VP and what you would decide yourself. | A live problem on the JD's roadmap line; nothing about your past. |

**Reverse questions (Round 3).** No profile for the VP, so none ties to their career path.
- "What does the leadership bar look like in practice, not on paper?" Why it lands: it asks about lived behavior.
- "What would make you say the first six months went well?" Why it lands: it asks for success criteria.
- "Which decision would you want this manager to make without checking with you?" Why it lands: it signals you expect autonomy within a clear bar.
- "Where is the tension between delivery and reliability sharpest in engineering right now?" Why it lands: it shows you are thinking about the role's real trade-offs.
- "How do you want engineering managers to work with hardware leadership?" Why it lands: it goes straight at the partnership line.

## Requirement coverage

| Requirement | Questions |
|---|---|
| lead two squads building device-management services | 1B1 (JD), 1A2, 2B2, 3D2 |
| own delivery | 1A2 (JD), 1A1 |
| hiring | 1A4 (JD), 1C1, 2C1 |
| growth for 11 engineers | 1B4 (JD), 1A2 |
| partner with hardware | 1B2 (JD), 1A1, 1A3, 2B1 |
| partner with product on roadmap | 2F4 (JD), 1A3, 2A2 |
| Values and leadership philosophy (recruiter's words) | 3E1 to 3E4 (VAL) |
| Strategy-grounded CO questions: none, and why: research was refused, so 3A1 stays generic. | 3A1 |

## Sources

**Research tier: L1, searches 3 of 6, fetches 0 of 2.** Web search was not granted in this session. The three calls were refused and not retried.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Larkfield Systems values` | unavailable | Values cheat sheet, not built: no published values in hand. Query refused. |
| 2. `Larkfield Systems interview process engineering manager` | unavailable | Loop check. The loop is already established by your message; a public source would have checked it. Query refused. |
| 3. `Larkfield Systems strategy recent news industrial IoT` | unavailable | CO questions grounded in current strategy (3A1 would become CO-grounded). Query refused. |
| 4. `{interviewer name} Larkfield Systems` | n/a | No name given for the Director, so no query could be formed. Interviewer read absent. |
| 5. Representative `Engineering Manager` JD | skipped | Your role summary fixes the fit snapshot and the JD-tagged questions. Full JD text would still upgrade the rows. |

**Provided documents:** your message (role summary, round schedule, your background, the recruiter's description of round 3). No CV, no JD text, no dossier.

## Upgrade menu

- **Full JD text** (paste the posting) → F1 to F6 move from your summary to the posting's own words, and the coverage table gets exact.
- **Search permission** → the values page, the loop check, and a strategy pass. Values would add named values to 3E1 to 3E4. Strategy would make 3A1 and 2A2 CO-grounded. A deeper pass (up to six more searches and two more fetches, several minutes) is available once, on your say-so.
- **Names of the panel members** (two staff engineers and the PM) → per-member persona weights in Round 2, replacing the blend.
- **The Director's name** → an interviewer read and a reverse question tied to their career path. Public professional footprint only.
- **Your CV** → F1 to F3 gain a source. Confidence stays `medium` until something inspectable is named.
- **The on-call export before and after the reliability quarter, and your hiring tracker's interview count** → 1C1, 1C2 and 2C2 can say what was counted, against a figure you can point to. `medium` rises only if an artifact is named and inspected.
- **Prep time before each round** → a prioritized schedule: 1B2, 2B1 and 3D2 first.
- **Recruiter guidance on what each round scores** → reweights the three banks.

---

Two offers, neither pushed:
- **Drill:** I can play the Skeptic on 1B2, the hardware-roadmap question this pack names as its highest-ROI prep, and give feedback against that question's own guidance.
- **Dossier:** I can save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.

Questions:
1. Do you have the full job posting? If so, paste it. If not, I'll keep working from your role summary.
2. Can I use web search? It was refused, so the values page, the interview loop, and recent strategy are still unchecked. Say yes and I'll retry them, or no and the pack stays on your material.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: larkfield_engineering-manager_interview_pack.md -----
# Interview prep pack: Engineering Manager, Larkfield Systems

**Mode:** loop (three rounds). **Candidate:** Yusuf (they/them). **Built on:** your message only (role summary, round schedule, your background). No CV, no full JD, no web research (see Sources).

## How to use

- **Personas** describe how a question arrives. **Types** describe what it scores.
- Type key: **VAL** values/behavioral · **EXP** work-experience deep-dive · **JD** role requirement · **CO** company/strategy · **CASE** live problem.
- Guidance is scaffolding, not a script. Say only what you did, in your own words.

## The loop

| Round | Day | Who | Length | Section |
|---|---|---|---|---|
| 1 | Tue | Director of Engineering (hiring manager, would-be boss) | 45 min | Round 1 |
| 2 | Thu | Panel: two staff engineers and a product manager | 60 min | Round 2 |
| 3 | Mon | VP Engineering, "values and leadership philosophy" | 30 min | Round 3 |

Your message establishes the loop: each round's length, who runs it, and what it holds. Round 3 is a values-style round because the recruiter's words name values as its subject.

## Fit snapshot (shared across rounds)

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "lead two squads building device-management services" (your message) | "3 as a team lead of 6" (your message) | medium | [grounded] | transferability | Words: "I was a team lead of six for three years." Your material shows one team of six, not two squads and not device management, so the bridge stays at one team. Answer slot: if you have coordinated more than one team at a time, say how; if not, say so plainly, then say what you would do in the first quarter. |
| F2 | "own delivery, hiring and growth for 11 engineers" (your message), hiring part | "I run our hiring loop for backend roles" and "about 40 interviews last year" (your message) | medium | [grounded] | presentation | Words: "I run our hiring loop for backend roles; about 40 interviews last year." This rewords only the quote. The loop is for backend roles, and nothing here shows headcount planning for 11 engineers, so expect that probe. |
| F3 | "own delivery" (your message) | "After I pushed a reliability quarter through against roadmap pressure, my team's on-call burden dropped 60%" (your message) | medium | [grounded] | transferability | Words: "After I pushed a reliability quarter through against roadmap pressure, my team's on-call burden dropped 60%." This is adjacent: one reliability quarter, not end-to-end delivery across two squads. The figure is covered by the defend-the-number slots in the banks. |
| F4 | "own delivery, hiring and growth for 11 engineers" (your message), growth part | none given | none | [grounded] | discovery | Your material does not show growth work for engineers. Answer slot: if you have grown engineers, say what you did and what happened, in your own words; if not, say so plainly. |
| F5 | "partner with hardware and product on roadmap" (your message), hardware part | "never owned a hardware-adjacent roadmap" (your message) | none | [grounded] | capability | Words: "I haven't owned a hardware-adjacent roadmap." Then how you would learn hardware roadmap work, said as a plan, never as a past. Never a claim to hardware roadmap work. |
| F6 | "partner with hardware and product on roadmap" (your message), product part | none given | none | [grounded] | discovery | Your material does not show roadmap work with product. Answer slot: if you have shaped a roadmap with a product manager, say what you did; if not, say so plainly. |
| F7 | none in the role text: your strongest story, used in the Values and Pressure banks | "pushed a reliability quarter through against roadmap pressure" (your message) | medium | [grounded] | none | Not a requirement. The quote carries the Values and Pressure banks. Its figure is probed under F3. |

**Observation, not words for you:** your material says you led one team of six and ran backend hiring. It does not show two squads, device management, hardware roadmaps, or growth work for engineers.

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Owned a hardware-adjacent roadmap | Negative you stated (F5) | Plain acknowledgment: "I haven't owned a hardware-adjacent roadmap." No slot. |
| Managed managers | Negative you stated: "I've never managed managers" (your message) | Plain acknowledgment: "I haven't managed managers." No slot. |
| Led two squads | Inflated form of F1 | F1's quote at its own scope: "3 as a team lead of 6." Limit, as the pack's observation: your material shows one team of six. |
| Owned delivery for 11 engineers | Inflated form of F3 | F3's quote at its own scope. Limit, as the pack's observation: your material shows one reliability quarter. |
| Designed the hiring loop | Inflated form of F2 | F2's quote at its own scope: "I run our hiring loop." Limit, as the pack's observation: your material says running the loop, not designing it. |
| The 60% drop was yours alone | Inflated form of F3 | The sentence says "after," not "because." The figure's attribution is the answer slot a figure raises (1C2). |

## Round 1: Director of Engineering (hiring manager), 45 min

**Persona weights.** Relationship prior for a hiring manager is Case/Strategist and Skeptic. No interviewer profile, so no adjustments.

| Persona | Weight | Why | Counter-strategy |
|---|---|---|---|
| Case/Strategist | 4 | Hiring managers buy capability and test it on their roadmap | Clarify, then structure; challenge one premise |
| Skeptic | 4 | Hiring managers derisk gaps; F1 and F5 are the gaps | Plain acknowledgment, bridge only from quoted evidence, then a ramp plan |
| Data-Driven Prober | 2 | Headline numbers (40 interviews, 60%) invite it; no profile signal | Name the weakest assumption before they do |
| Pressure | 2 | Plausible in 45 minutes with a director; no profile signal | Pause, restate, hold through two follow-ups |
| Conversational | opener only | Low prior here, so no bank | Use your 90-second arc for the opener |

**Highest-ROI prep: 1B2.** The hardware-roadmap objection is the only capability gap in the snapshot, and the role states the hardware line as a headline. It will come up in some form in every round.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 1A1 | "Two squads are shipping device-management services, and the hardware team's firmware change lands three weeks late. What do you do this week?" | CASE | [generic] | Think aloud: clarify what the late change blocks, state the objective, then who is affected and how. Challenge one premise, such as the date being fixed. Give a decision, not a survey. | A live problem from the role; presupposes nothing about your past. Covers the hardware and delivery halves (F3, F5). |
| 1A2 | "What would you do in your first 90 days with eleven engineers, two squads and growth as part of the job?" | JD | [generic] | Listen first: one-to-ones, the delivery state, the hiring state. Then one priority per squad. If you have grown engineers, say how and what happened. If not, say so plainly and say what you would do first. | Covers the scope and growth requirement; the second branch is the honest form of F4. |
| 1A3 | "Product wants a roadmap date the hardware team cannot commit to. How do you decide?" | CASE | [generic] | Clarify what each date protects and who bears the cost of being wrong. Decide by decision type, not by team loyalty. Name what would change your decision. | Tests the JD's partnership line, where F6 has no evidence. A live problem, so nothing about your past is presupposed. |
| 1A4 | "Walk me through how you would plan hiring for these two squads over the next two quarters. What do you need to know first?" | JD | [grounded] "I run our hiring loop for backend roles" (your message) | Clarify headcount, role mix and what is already open. Then the loop: stages, who decides, the bar. Say that your loop experience is backend hiring, and say which parts transfer. | F2 is the evidence; the question tests the part it does not cover. |
| 1B1 | "You have led one team of six. This role is two squads and eleven engineers. How do you lead that?" | JD | [grounded] "3 as a team lead of 6" (your message) | Hold to your scope: one team of six for three years. Answer slot: if you have coordinated more than one team at a time, say how; if not, say so plainly, then say what you would do in the first quarter. Do not describe two squads you have led. | F1 is transferability; this is the scope probe. |
| 1B2 | "You have never owned a hardware-adjacent roadmap. Why should a hardware partner trust your roadmap?" | JD | [grounded] "never owned a hardware-adjacent roadmap" and "pushed a reliability quarter through against roadmap pressure" (your message) | **Highest-ROI prep.** Open with the plain acknowledgment: "I haven't owned a hardware-adjacent roadmap." Then the one adjacent fact you stated: a reliability quarter pushed through against roadmap pressure. Hold through two follow-ups by returning to that roadmap pressure, not to hardware. Concede the hardware half once and clearly: "that part is new to me," then how you would learn it, as a plan. Answer slot: if you have worked with a hardware team at all, say how; if not, say so plainly. | F5 is the only capability row, and the hardware line is headline JD content. Deepest rehearsal: three follow-up levels. |
| 1B3 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "never owned a hardware-adjacent roadmap" (your message) | Name the weakest part honestly: the hardware roadmap, the one thing your message says you have not done. Bridge only from roadmap pressure you held. Then a first-month plan. Do not name a second weakness you have not stated. | Skeptic stem. The answer should match 1B2 in shorter form, because interviewers compare notes across rounds. |
| 1B4 | "Tell me how you have grown an engineer's career." | JD | [grounded] | Open prompt: choose a real instance. If you have one, say what you did and what happened, in your own words. If not, say so plainly, then say what you would do for each engineer in the first quarter. | No quote supports growth work, so the honest answer is the slot. Label is the JD requirement's source. |
| 1C1 | "Walk me through how the 40 interviews were counted." | EXP | [grounded] "about 40 interviews last year" (your message) | Defend-the-number, in your own words: how the count was made, what it is sensitive to, the assumption you would defend least, and which part was yours. Name the weakest assumption before they do. | Headline figure on your message; the probe tests what was yours. |
| 1C2 | "How was the 60% counted, and what part of that drop was yours?" | EXP | [grounded] "After I pushed a reliability quarter through against roadmap pressure, my team's on-call burden dropped 60%" (your message) | Defend-the-number, in your own words: how the figure was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. If you do not know how it was counted, say so plainly. Keep "after" as "after." | Your strongest number. The probe is likely; the sentence supports "after," not "because." |
| 1D1 | "Sixty seconds: why should we hire you over a candidate who has owned a hardware roadmap?" | JD | [grounded] "never owned a hardware-adjacent roadmap" and "pushed a reliability quarter through against roadmap pressure" (your message) | Pause, then restate the question. Give the reliability quarter in one sentence and concede the hardware gap in one sentence. Hold through two follow-ups; do not fold on the quarter, and do not claim hardware work. | Pressure stem. Tests whether the honest answer holds under time. |
| 1D2 | "Sixty seconds on your team of six: what did it own, and what did you decide within it?" | EXP | [grounded] "3 as a team lead of 6" (your message) | Time-boxed: the team's scope in one sentence, then your part in one sentence. Answer slot: if you set priorities or made calls, say which; if not, say so plainly, then say what you did. | Pressure time-box on F1's scope. |

**Reverse questions (Round 1).** No profile for the Director, so none ties to their career path.
- "What would a strong first 90 days look like here?" Why it lands: it makes the scope conversation concrete and shows you are planning, not pitching.
- "Where is delivery most at risk on the device-management services right now?" Why it lands: it asks about the work, and shows you read the role.
- "Which roadmap decisions sit with the hardware team, and which with product?" Why it lands: it tests the partnership line directly, and the answer shows where you would be a tiebreaker.
- "What does the hiring plan for the two squads look like over the next two quarters?" Why it lands: hiring ownership is in the role text, and this shows you read it closely.
- "What would make you say, a year from now, that this hire was the right call?" Why it lands: it hands the hiring manager the success criteria they must answer.

## Round 2: Panel (two staff engineers, one product manager), 60 min

**Persona weights.** Names are unknown, so weights apply to the panel as a blend. Staff engineers read as peers (Peer Evaluator and Prober). The product manager reads as Case/Strategist and Peer. Assign per member once names are known.

| Persona | Weight | Why | Counter-strategy |
|---|---|---|---|
| Peer Evaluator | 4 | Peers price what the hire adds to their team and their seams | Propose seam principles; name what you bring their team |
| Data-Driven Prober | 3 | Staff engineers read the CV closely; 40 and 60% will be probed | Name the weakest assumption; say plainly what you do not know |
| Case/Strategist | 2 | The PM's native register: roadmap cases | Clarify, then structure |
| Skeptic | 2 | Background-gap probes can come from any panelist | Plain acknowledgment, then bridge |

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 2F1 | "Our teams sit side by side. Where is the seam between your squads and ours, and what happens when we disagree?" | JD | [grounded] "pushed a reliability quarter through against roadmap pressure" (your message) | Propose seam principles, not a map you do not know. Name one principle for disagreement. If you disagreed with a peer team, say what about and how it ended; if not, say so and give the principle you would use. | Peer stem on the JD's partnership line. Your nearest disagreement is the reliability quarter. |
| 2F2 | "How do you handle credit when delivery spans two teams?" | JD | [generic] | Answer slot: if you have a case where credit was shared across teams, say who did what, in your own words; if not, say so plainly and give the rule you would use. | Peer probe on credit. No quote carries it, so the answer is a slot. |
| 2F3 | "What do you need from a peer team to make a roadmap commitment you can keep?" | JD | [generic] | Reciprocity framing: name what you need, then what you bring their team. State the mechanism as a principle, not as a past. | Dependencies are the peer panel's concern; reciprocity weighs heavily here. |
| 2F4 | "If reliability work competes with a feature product wants, who decides?" | JD | [grounded] "pushed a reliability quarter through against roadmap pressure" (your message) | Answer slot: if you made that call, say how; if someone else set it, say so plainly and say what you pushed for. Hold the decision you actually made. | The reliability quarter is the only roadmap-pressure fact you stated. |
| 2C1 | "Your hiring loop: which stage predicts a good hire best, and how do you know?" | EXP | [grounded] "I run our hiring loop for backend roles" (your message) | Answer slot: if you measured stage outcomes, say which stage and what you saw; if not, say so plainly and say what you would look at first. | Prober on the loop, which is your strongest hiring evidence and backend-only. |
| 2C2 | "Walk me through how that number was counted." | EXP | [grounded] "After I pushed a reliability quarter through against roadmap pressure, my team's on-call burden dropped 60%" (your message) | The same defend-the-number slots as 1C2, in your own words. If you do not know how it was counted, say so. | A staff-engineer panel will ask the denominator. |
| 2C3 | "Which assumption behind that on-call figure would you defend least?" | EXP | [grounded] the same on-call sentence (your message) | Name it yourself before they ask: the assumption you would defend least, in your own words. If you have no such assumption in mind, say so. | The weakest-assumption move, required for metric answers. |
| 2A1 | "Sketch the first quarter for two squads that depend on a hardware release date. What do you need to know first?" | CASE | [generic] | Clarify: which services depend on the release, what slips if it does, who has to say so. Then objective, segmentation, approach, metrics, risks. Think aloud. | A live problem on the partnership line; nothing about your past. |
| 2A2 | "Product wants a feature that adds load to device management next quarter; reliability says no. How do you decide?" | CASE | [generic] | Clarify impact, risk, and who bears each. Challenge one premise, such as the feature date. Give a decision and what would change it. | The PM's register; tests the roadmap line. |
| 2B1 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "never owned a hardware-adjacent roadmap" (your message) | The same honest answer as 1B3: hardware roadmap, in one sentence, then the bridge from roadmap pressure you held, then a first-month plan. Concede the hardware half once and clearly. | Skeptic stem. Match round 1, because panelists compare notes. |
| 2B2 | "I don't see device management in your background. How would you handle that in this role?" | JD | [grounded] "pushed a reliability quarter through against roadmap pressure" (your message) | Answer slot: if you have worked on device or embedded systems, say what; if not, say so plainly, then say what you would learn first and from whom. Do not claim device work. | Skeptic stem for the lead requirement. The interviewer's observation matches your material. |

**Reverse questions (Round 2).**
- "What could a new person do in their first month that would genuinely help your team?" Why it lands: a reciprocity question, weighted heavily by peer panels.
- "Where do roadmap commitments to the hardware team most often slip, and why?" Why it lands: it shows you already think about the seam.
- "How do you decide when reliability work gets roadmap time?" Why it lands: it follows up 2F4 and shows you listened.
- "What do you wish the engineering manager did in the first quarter?" Why it lands: collegial, and gives you the panel's own priorities.
- "Which decisions would you want the manager to make without asking you?" Why it lands: it asks for the autonomy line directly.

## Round 3: VP Engineering, values and leadership philosophy, 30 min

**Persona weights.** The recruiter's words make values the subject of this round. Executive altitude also pulls in Pressure and Case.

| Persona | Weight | Why | Counter-strategy |
|---|---|---|---|
| Values/Behavioral | 4 | The recruiter named values and leadership philosophy as this round's subject | Map each answer to one instance from your message, with its honest branch |
| Pressure | 2 | Executive composure in 30 minutes | Pause, hold, concede once |
| Case/Strategist | 2 | Skip-level prior, strategy-heavy; no strategy research ran | Clarify; say what you would need to know |
| Conversational | opener only | Plausible open; no bank | 90-second arc |

Published values are not in hand, so no values cheat sheet is built, and the VAL questions use the recruiter's wording as their raising source, not named values.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 3E1 | "What is your leadership philosophy, and where did it come from?" | VAL | [grounded] "pushed a reliability quarter through against roadmap pressure" (your message) | Open prompt: name one principle you acted on, then give the reliability quarter as the instance. Beats the quote states: a reliability quarter, roadmap pressure, pushed through. Answer slot: the stake, and what you told whom. If you cannot name a principle you acted on, say so plainly and give the nearest instance. | The recruiter's words raise leadership philosophy. The principle is yours to name. |
| 3E2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "pushed a reliability quarter through against roadmap pressure" (your message) | Open prompt. The reliability quarter fits only if the truth you told was unpopular with leadership; if not, say so and give the nearest instance. Answer slot: what you said, to whom, and how it landed; if it did not land, say that. | Persona stem for a values interviewer. Your quote carries roadmap pressure, not the truth itself. |
| 3E3 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Answer slot: if you did, say what the metric was and what you chose; if not, say so plainly and say what you would choose now. Do not supply a customer you did not serve. | Persona stem. No quote carries a customer story. |
| 3E4 | "When two things you value pull in opposite directions, what do you do?" | VAL | [grounded] "values and leadership philosophy" (your message, the recruiter's words) and "pushed a reliability quarter through against roadmap pressure" (your message) | Open prompt. Name a conflict you have actually faced. The nearest instance is delivery against reliability in the reliability quarter, in your own words. If you have no such instance, say so plainly. | Values round prior. The recruiter's words raise the theme. |
| 3D1 | "Sixty seconds: why leave a payments company for a hardware-adjacent role?" | JD | [grounded] "currently at a payments company" and "never owned a hardware-adjacent roadmap" (your message) | Pause, restate. Give your motivation in one sentence, in your own words, tied to the role text. Hold through two follow-ups; concede the hardware gap in one sentence. Do not describe payments as worse. | Pressure stem on motivation. The hardware gap is still the honest core. |
| 3D2 | "You have never managed managers. Why would you lead eleven engineers across two squads?" | JD | [grounded] "I've never managed managers" and "3 as a team lead of 6" (your message) | Hold: restate the scope you have, one team of six for three years. Concede in one sentence that the manager layer is new, and say how you would learn it. Do not claim managing managers. Hold through two follow-ups. | Pressure on your stated negative. The premise is your own sentence, so it may be used. |
| 3A1 | "If you were running engineering for a device company of about 600 people, what would you change in your first year?" | CO | [generic] | Clarify what you would need to know before changing anything: current priorities, the hardware plan, the company's stated values. Give two changes and what would make you drop one. Do not claim knowledge of their strategy. | Without strategy research, CO stays generic. The answer should name what it needs, not pretend. |
| 3A2 | "Two squads' reliability and feature demand conflict at executive level. How would you bring that trade-off to me?" | CASE | [generic] | Structure the trade-off: what each option protects, what it costs, who decides. Recommend one, with the trigger that would change it. Say what you would bring to the VP and what you would decide yourself. | A live problem on the JD's roadmap line; nothing about your past. |

**Reverse questions (Round 3).** No profile for the VP, so none ties to their career path.
- "What does the leadership bar look like in practice, not on paper?" Why it lands: it asks about lived behavior.
- "What would make you say the first six months went well?" Why it lands: it asks for success criteria.
- "Which decision would you want this manager to make without checking with you?" Why it lands: it signals you expect autonomy within a clear bar.
- "Where is the tension between delivery and reliability sharpest in engineering right now?" Why it lands: it shows you are thinking about the role's real trade-offs.
- "How do you want engineering managers to work with hardware leadership?" Why it lands: it goes straight at the partnership line.

## Requirement coverage

| Requirement | Questions |
|---|---|
| lead two squads building device-management services | 1B1 (JD), 1A2, 2B2, 3D2 |
| own delivery | 1A2 (JD), 1A1 |
| hiring | 1A4 (JD), 1C1, 2C1 |
| growth for 11 engineers | 1B4 (JD), 1A2 |
| partner with hardware | 1B2 (JD), 1A1, 1A3, 2B1 |
| partner with product on roadmap | 2F4 (JD), 1A3, 2A2 |
| Values and leadership philosophy (recruiter's words) | 3E1 to 3E4 (VAL) |
| Strategy-grounded CO questions: none, and why: research was refused, so 3A1 stays generic. | 3A1 |

## Sources

**Research tier: L1, searches 3 of 6, fetches 0 of 2.** Web search was not granted in this session. The three calls were refused and not retried.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Larkfield Systems values` | unavailable | Values cheat sheet, not built: no published values in hand. Query refused. |
| 2. `Larkfield Systems interview process engineering manager` | unavailable | Loop check. The loop is already established by your message; a public source would have checked it. Query refused. |
| 3. `Larkfield Systems strategy recent news industrial IoT` | unavailable | CO questions grounded in current strategy (3A1 would become CO-grounded). Query refused. |
| 4. `{interviewer name} Larkfield Systems` | n/a | No name given for the Director, so no query could be formed. Interviewer read absent. |
| 5. Representative `Engineering Manager` JD | skipped | Your role summary fixes the fit snapshot and the JD-tagged questions. Full JD text would still upgrade the rows. |

**Provided documents:** your message (role summary, round schedule, your background, the recruiter's description of round 3). No CV, no JD text, no dossier.

## Upgrade menu

- **Full JD text** (paste the posting) → F1 to F6 move from your summary to the posting's own words, and the coverage table gets exact.
- **Search permission** → the values page, the loop check, and a strategy pass. Values would add named values to 3E1 to 3E4. Strategy would make 3A1 and 2A2 CO-grounded. A deeper pass (up to six more searches and two more fetches, several minutes) is available once, on your say-so.
- **Names of the panel members** (two staff engineers and the PM) → per-member persona weights in Round 2, replacing the blend.
- **The Director's name** → an interviewer read and a reverse question tied to their career path. Public professional footprint only.
- **Your CV** → F1 to F3 gain a source. Confidence stays `medium` until something inspectable is named.
- **The on-call export before and after the reliability quarter, and your hiring tracker's interview count** → 1C1, 1C2 and 2C2 can say what was counted, against a figure you can point to. `medium` rises only if an artifact is named and inspected.
- **Prep time before each round** → a prioritized schedule: 1B2, 2B1 and 3D2 first.
- **Recruiter guidance on what each round scores** → reweights the three banks.
