Your prep pack is saved as `stripe_product-operations-manager_interview_pack.md` in my scratchpad, and I've sent it to you. It's a generic first version. I had no job description, no CV, and no round details, and web search was refused, so nothing in it is specific to Stripe or to you. The 21 questions are role-family patterns for a product operations role, each marked `[generic]`. The weights are flat because I don't know who you're meeting.

The pack's highest-ROI prep is D1, "why should we hire you over someone who has done this exact job?" With no background on record, it's the objection most likely to come up in some form.

Offers, one line each:
- **Drill:** I can play a Pressure interviewer on D1 and give feedback against that question's guidance.
- **Dossier:** I can save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions.
- **Word:** I can convert the pack to .docx once you've finished iterating.

Two questions that would reshape the pack:
1. Who are you meeting, and what kind of round is it: hiring manager, peer, cross-functional, or recruiter? Did the recruiter name any focus areas or an assignment?
2. Could you paste the job description and your CV? Your exact sentences would turn the fit-snapshot rows from guesses into quoted evidence.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: stripe_product-operations-manager_interview_pack.md -----
# Stripe, Product Operations Manager: final-round interview pack

Role: Product Operations Manager. Company: Stripe. Round: final. Interviewer: not named. Relationship: not stated.
First version. Built without a job description, CV, or round details. Web search was refused, so nothing here is Stripe-specific.

## 1. How to use and type key

Personas describe how a question is asked. Types describe what it scores.

- **VAL**: behavioral and values alignment. Whether past behavior shows the value.
- **EXP**: your past work, tested for attribution. What you actually did.
- **JD**: role requirements, including gaps.
- **CO**: company and strategy knowledge. None in this pack, because no research ran.
- **CASE**: a live problem from the role, solved aloud.

Guidance is scaffolding, not a script. Every question here is `[generic]`: a pattern for a product operations role, not a fact about Stripe or about you. Answer slots are instructions for the interview, not questions to answer here.

## 2. Fit snapshot (worksheet variant)

No JD and no CV were supplied, so no requirement is quoted and no evidence cell holds anything. The requirements below are role-family patterns for a product operations role, written as plain prose. No gate rows, because no JD means no established gates.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Running a recurring cross-functional operating cadence (role-family pattern) | none given | none | [generic] | discovery | Strong evidence looks like: a named recurring meeting or document you ran, who attended, and what it decided. Answer slot: if you have run one, name it and say what it decided; if you have not, say so plainly and describe the cadence you would set up first. |
| F2 | Taking a launch or program from kickoff to close, with milestones and owners (role-family pattern) | none given | none | [generic] | discovery | Strong evidence looks like: one launch or program, its milestones, who owned each, and whether it landed. Answer slot: if you have owned one, say which milestones were yours to set; if not, say so and describe how you would track one. |
| F3 | Defining and tracking metrics for processes and programs (role-family pattern) | none given | none | [generic] | discovery | Strong evidence looks like: one metric you defined, how it was counted, and what you did with it. Answer slot: if you defined one, say how it was counted; if you did not, say so and say what you would define first. |
| F4 | Turning ambiguous requests into clear decisions, with a decision log or prioritization (role-family pattern) | none given | none | [generic] | discovery | Strong evidence looks like: one decision you helped make, who owned it, and where it was recorded. Answer slot: if you have done this, name the decision and the owner; if not, describe how you would record one. |
| F5 | Building tools or documentation that teams adopt (role-family pattern) | none given | none | [generic] | discovery | Strong evidence looks like: one tool or document, who used it, and whether they kept using it. Answer slot: if you built one, say who adopted it; if not, say so and describe how you would check adoption. |
| F6 | Working with senior stakeholders and with engineering, finance and legal partners (role-family pattern) | none given | none | [generic] | discovery | Strong evidence looks like: one disagreement with a senior or partner team, how it was resolved, and what you would do differently. Answer slot: if you have one, say what you did; if not, describe how you would handle the first one. |

## 3. Prohibited claims

No entries. The fit snapshot quotes no sentence of yours, so there is no stated claim to stretch.

Standing limit for this pack: no answer names a metric, tool, outcome or ownership you did not do. Every past-tense question is an open prompt or an answer slot, and every scaffold ends in the honest branch.

## 4. Persona weights

No relationship and no interviewer were given, so the weights are flat: no persona is weighted above another, and each gets three questions. This is the weakest form of the pack, and the upgrade menu says what would sharpen it.

| Persona | How it shows up | Weight | Counter-strategy |
|---|---|---|---|
| Case / Strategist | A live problem from the role: plan this, diagnose that | Flat (1 of 7) | Clarify, then structure, then answer. Name one assumption aloud. |
| Data-Driven Prober | Asks how a number was counted and what it is sensitive to | Flat (1 of 7) | Know what you can say about each measure, and name the weakest assumption before they do. |
| Skeptic | Quiet, persistent probing of gaps and motivation | Flat (1 of 7) | Rehearse the most predictable objection until it is ordinary. Calibrated candor over bluffing. |
| Pressure / Stress | Time-boxed challenges, devil's advocate, questions motives | Flat (1 of 7) | Pause, restate the question, hold a position through two follow-ups, then concede only the specific point you cannot defend. |
| Values / Behavioral | Scenario probes for past behavior, expects a concrete story | Flat (1 of 7) | One specific past decision per prompt. "We" for context, "I" for your part. |
| Conversational / Rapport | Friendly openers that are still scored | Flat (1 of 7) | A 90-second arc for the biography, and treat casual questions about the role as scored. |
| Peer Evaluator | Seam-splitting, credit-sharing, "what would you need from me" | Flat (1 of 7) | Reciprocity: what you bring to their team. Propose seam principles, do not pretend to know their seam. |

## 5. Question banks

Ordered within each persona by how the question is likely to land, not by weight, since all weights are flat.

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A launch you are coordinating slipped two weeks, and no one can say why. What do you do in the first 48 hours?" | CASE | [generic] | Clarify first: which milestone slipped, and whether the date or the scope must hold. Split the causes into dependency, scope, approval and capacity, and ask each owner for their blocker in one sentence. Propose one source of truth for status and one dated decision. Close on the risk you would watch next. Speakable in 90 to 120 seconds. | Live problem from the launch-ownership requirement (F2). Generic because it describes a pattern, not an event. |
| A2 | "Design the operating cadence for a 40-person program across three teams." | CASE | [generic] | Clarify decision rights first: which decisions are weekly and which monthly. Name a small set of artifacts: one status document, one decision log, one owner per workstream. Say how you would stop status meetings turning into status theatre, and what you would drop first if the cadence is too heavy. | Tests the cadence requirement (F1) as a design problem, with its failure modes. |
| A3 | "Activation fell 15% on a new onboarding flow last month. Diagnose it." | CASE | [generic] | Check measurement before explanation: did the definition or the instrumentation change? Then segment by cohort, funnel step and channel. Rank three hypotheses by how fast each can be tested. Name the metric you would trust least, and why. | Metric diagnosis, tied to the measurement requirement (F3). No company data is cited. |

### B. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a metric you used to judge whether a process was working. How was it counted?" | EXP | [generic] | Open prompt: pick a metric you actually tracked. Give the numerator, the denominator and the data source. Then name the assumption behind it that you would defend least, before they ask. Answer slot: if you did not track one, say so plainly and say what you would define first. Never describe a measure you did not track. | Probers test whether a number survives its definition. Open prompt, since no figure is on record to defend. |
| B2 | "Which number on a dashboard you inherited would you trust least, and why?" | EXP | [generic] | Name a specific data-quality failure you have seen. If you have not seen one, describe how you would check a dashboard's lineage: definitions, owners, and the last change made to it. | Tests skepticism about data, which the measurement requirement (F3) depends on. |
| B3 | "How would you know a process change actually worked?" | JD | [generic] | Before the change: state the baseline and the one outcome that would count as success. After: compare against a comparable group, and say what would make you reverse the change. Do not claim a result you have not measured. | Measurement is a core product-operations requirement (F3). The question asks for a method, not a record. |

### C. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Where would you be weakest in this role on day one?" | JD | [generic] | Name one real gap type: domain knowledge, tooling, or working with senior stakeholders. Then give a concrete 30-day plan to close it. Calibrated candor beats bluffing. | The skeptic's standard opener for a generalist. Rehearsing it removes most of its sting. |
| C2 | "What is the strongest argument against hiring you for this role?" | JD | [generic] | Give the argument in its strongest form, then the evidence you would offer against it, then what you would do if it proved right. Do not argue the premise away. | Asks for honest self-assessment directly. The answer has to survive a follow-up. |
| C3 | "Why this role, and why now?" | VAL | [generic] | Name one specific piece of the role's work that draws you, in terms of what the team needs rather than the company's reputation. Keep the "why now" to your own reason. Avoid lists of praise. | Motivation consistency. A generic answer reads as an unexamined move. |

### D. Pressure / Stress

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why should we hire you over someone who has done this exact job?" | JD | [generic] | Pause, then restate the question. Name the two or three things that matter most for the role. Say which you bring and which you would learn fastest. Do not disparage the other candidate. | Highest-ROI prep in this pack. With no background on record, this is the objection most likely to arrive in some form, so it gets the deepest rehearsal. |
| D2 | "Tell me about a process you improved. How much of the result was actually you?" | EXP | [generic] | Open prompt: choose a process you changed. Say what you did and what others did. Answer slot: if you led the change, say which decisions were yours; if you contributed, say so and name the others. | Attribution honesty under challenge. |
| D3 | "You keep saying cross-functional alignment matters. Convince me it is not a buzzword." | VAL | [generic] | Hold the position by defining alignment as observable: a named decision, a named owner, a date. Hold through two follow-ups. Concede only the specific point you cannot defend. | Hold-then-concede test. A position held without a definition collapses on the second follow-up. |

### E. Values / Behavioral

No published values were fetched, so these are generic behavioral prompts. They make no claim about any Stripe value.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Tell me about a time you delivered an unpopular truth to a senior leader." | VAL | [generic] | Open prompt: pick a moment you did say it. Give the stake, what you said, how they reacted, and the outcome, in that order. "We" for context, "I" for what you did. If you did not say it at the time, say so, then describe how you would handle it now. | Behavioral prompts score specific past behavior, not virtue. |
| E2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Open prompt: pick a time a user need conflicted with a target. Name the metric, the trade-off you made, and who decided. Answer slot: if no such time comes to mind, say so plainly, then describe how you weigh the two. | Common values probe. The honest branch matters more than the story. |
| E3 | "Describe a process you owned that failed in public. What did you change?" | VAL | [generic] | Open prompt: pick a failure you owned. Say what broke, who noticed, what you changed, and how you checked the change worked. Do not blame a team. | Tests ownership and learning, and whether you can talk about failure without spin. |

### F. Conversational / Rapport

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through your journey." | VAL | [generic] | Practise a 90-second arc: where you started, the one turn that mattered, what you do now, and why this role. Only say what you have actually done. | Casual openers are scored. The arc keeps the answer short. |
| F2 | "What are you playing with in operations tooling these days?" | JD | [generic] | Name only tools you have used, and what for. If you have not used a tool, say what you have read and what you would try first. | Casual register, scored content: the tooling requirement arrives as conversation. |
| F3 | "Tell me about a project you're proud of that nobody outside your team noticed." | EXP | [generic] | Open prompt: pick one. Say what you did, what changed for the team, and how you know. Keep the proof to what you saw. | Tests whether you can describe your own contribution without inflating it. |

### G. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Our teams sit side by side. Where's the seam between product ops and our team, and what happens when we disagree?" | VAL | [generic] | Propose seam principles, not a map of their team: who decides what, and how disagreements escalate. Say you would ask them where the seam sits before deciding. Give a disagreement story only if you have one; otherwise describe how you would handle one. | Peer probes test partnership fit and turf awareness. |
| G2 | "How do you handle credit when work spans teams?" | EXP | [generic] | Open prompt: pick a shared piece of work. Name who did what. Say which credit you would give others first, and what you claimed for yourself. | Credit-sharing probes test collegiality. |
| G3 | "What would you bring to a partner team in its first month?" | JD | [generic] | Reciprocity framing: name what you would give their team, such as a cadence, a decision log or a tool, before what you need from them. Propose; do not promise. | Peers price what a hire adds to their own load. |

## 6. Requirement coverage

Built from the role-family patterns in section 2, since no JD was supplied.

| Requirement (source) | Question IDs |
|---|---|
| Operating cadence (F1) | A2, C1 |
| Launch and milestone ownership (F2) | A1, D2 |
| Metrics and measurement (F3) | B1, B2, B3, A3 |
| Decisions and prioritization (F4) | D3, E2 |
| Tooling and documentation (F5) | F2 |
| Senior stakeholders and partner teams (F6) | D1, E1, G1, G2, G3 |
| Process ownership and learning | E3, F3 |
| Motivation and fit | C2, C3, F1 |
| Company and strategy knowledge (CO) | None, and why: no research ran, so no CO question is grounded in anything current |

## 7. Reverse questions

No interviewer profile exists, so none is tied to an interviewer's path.

| Question to ask | Why it lands |
|---|---|
| "What does a strong first 90 days look like in this role?" | Gets their scoring criteria in their own words. |
| "Which decision in this area has the least clear ownership today?" | Shows you think about ownership, which the role exists to fix. |
| "How does this team judge whether product operations is working?" | Shows you care about measures, and surfaces their actual bar. |
| "What did the last person in this role spend time on that they wish they had not?" | Surfaces the real friction. Interviewers answer this candidly. |
| "Who would I work with most in the first month, and what do they need from ops?" | Shows you plan around people, not a job description. |
| "What could a new person do in the first month that would genuinely help your team?" | Reciprocity, for a peer round. Turns a question into a working conversation. |

## 8. Sources

Provided documents: the request only (company, role title, "final round").

Research tier: L1 — searches 3 of 6, fetches 0 of 2

Queries sent, all refused by the host's permission setting:
- "Stripe company values principles": refused
- "Stripe interview process product operations manager final round": refused
- "Stripe strategy news 2026": refused

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Stripe values | unavailable | Searched, refused. Would have moved the values cheat sheet and whether a values round is detected. Neither is in this pack. |
| 2. Stripe interview process, product operations | unavailable | Searched, refused. Would have moved the loop structure and the persona weights, which are flat. |
| 3. Stripe strategy / recent news | unavailable | Searched, refused. Would have moved the CO questions and the differentiator bank. Neither is in this pack. |
| 4. Interviewer name and Stripe | n/a | No interviewer name was given, so there was no query to form. |
| 5. Representative Product Operations Manager JD | unavailable | No call sent after the refusals. Would have moved the fit-snapshot requirements from [generic] to [inferred]. |

## 9. Upgrade menu

- JD text → fit-snapshot rows F1 to F6 become quoted `[grounded]` rows, and the coverage table becomes real.
- CV or background, even bullet points → evidence cells fill with your exact sentences. The Prober, Pressure, Values and Peer banks get story maps in place of selection scaffolds.
- Round type and who you meet (manager, peer, cross-functional, recruiter) → persona weights stop being flat, and the reverse questions are retuned.
- Recruiter's note on focus areas, or any take-home or presentation → a build section for each declared deliverable.
- Stripe's values page, pasted → a values cheat sheet, if the round is values-style.
- Interviewer's name → an interviewer read, and a reverse question tied to their career path.
- Recent Stripe strategy or news, pasted (under six months old) → CO questions and a differentiator bank.
- Web search permission → the three searches above can be run again. A deeper pass (up to six more searches and two more fetches, several more minutes) is available once, if you want it.
- A `tuesday-dossier.md` from the job-underwriter, if you have one → verified evidence and any prohibited claims bind every cell.
