Your prep pack is saved as `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-alone-part-2-rooms-case-3-denied-ea35e04d/327c5192-3e46-4b42-a140-ad2c717e30db/scratchpad/stripe_product-operations-manager_interview_pack.md`. I also sent it to you as a file. Your note didn't include a CV, a job posting, or who you're meeting, so the pack is built on role-family guesses and labelled as such. Every question is tagged `[generic]`, and nothing in it claims anything about your experience.

The pack has 18 questions across seven interviewer styles, weighted equally because I don't know the round. The one to rehearse hardest is K2, "What is the weakest part of your background for this role?" With nothing in hand yet, that is the question most likely to come up in some form.

Company research didn't run. Both web searches were refused by the permission settings in this session, so the pack contains no Stripe values, no interview-process details and no recent strategy. Those sections are marked unavailable in the file. If you grant search permission, I can run them.

Once I have the answers below, I'll rebuild the pack around them.

- Is the person you're meeting your future manager, a peer, or someone from another team? And did the recruiter say what the round focuses on or whether there's a take-home?
- Can you paste the job posting and your CV, or a short summary of your background? If you'd rather not, I can keep going with what's here.

I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions. I can convert the pack to Word if you'd like it that way. Say the word and I'll play the Skeptic on K2 so you can practise it out loud.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: stripe_product-operations-manager_interview_pack.md -----
# Stripe, Product Operations Manager: final-round prep pack

Interviewer: not given. Relationship: not given. Built as a full-loop pack with flat persona weights, which is noticeably weaker than a pack built for a known interviewer. No CV, JD or company research is in hand, so every row below is a worksheet line, not a record of your experience.

## How to use + type key

Personas describe how a question will be asked. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and stop where your own experience stops.

- **VAL**: behavioral / values alignment
- **EXP**: your own experience, tested for precision and attribution
- **JD**: the role's stated responsibilities, including its gaps
- **CO**: company and strategy knowledge
- **CASE**: a live problem, structured out loud

## Fit snapshot

Worksheet variant: no evidence in hand, so every evidence cell is `none given`. Requirements are role-family prose from the role title, not quoted from a posting, so they are `[generic]`.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Designing and running an operating cadence for a product org (role family) | none given | none | [generic] | discovery | Worksheet line. Strong evidence looks like one cadence you designed, what it replaced, and what changed. Pick the nearest operating rhythm you ran or joined, and say what it did. If you have never designed one, say so plainly, then say how you would start |
| F2 | Coordinating cross-functional launches across product, engineering and go-to-market (role family) | none given | none | [generic] | discovery | Worksheet line. Strong evidence looks like one launch you coordinated end to end, with the owners named. Pick the nearest one. If none was yours to coordinate, say whose it was and what your part was |
| F3 | Building metrics and dashboards that teams act on (role family) | none given | none | [generic] | discovery | Worksheet line. Strong evidence looks like one number someone used to decide something. Pick one, and be ready to say how it was counted. If you have not built one, say so and name the first measure you would define |
| F4 | Running intake and prioritization for a stream of requests (role family) | none given | none | [generic] | discovery | Worksheet line. Strong evidence looks like one prioritization rule and what it turned away. Pick the nearest case; if you have no such rule, say so and describe how you would decide |
| F5 | Managing stakeholders who disagree on priorities (role family) | none given | none | [generic] | discovery | Worksheet line. Strong evidence looks like one disagreement you resolved, with the decision named. Pick one, say what you said, and how it ended. If none comes to mind, say so plainly, then give the nearest one you have |

Routing note: no row is a gate, since no posting has been supplied to say which requirements are gates.

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| No entries yet | There is no sentence from you to stretch. A list built without your words would be invented | Once your CV or a message from you is in, each stretched wording is listed here, at the scope of the sentence you wrote |

## Persona table

Relationship unknown, so weights are flat. Every persona gets depth; none is set above the others.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | A live product-ops problem from the role | Likely in any final loop for a process-heavy role; the pack has no basis to rank it higher | Clarify, structure, then decide; say the framework aloud once |
| Data-Driven Prober | Asks how a number was counted | Likely for any ops role, since ops is judged on its measures | Pick one number you can explain end to end, and name its weakest assumption |
| Pressure / Stress | Interrupts, time-boxes, challenges your position | Possible; the pack cannot tell from here | Pause, restate, hold through two follow-ups before conceding anything real |
| Skeptic | Probes the weakest area of the background | Likely; every final tests fit | Rehearse one honest weakest-area answer until it is plain |
| Values / Behavioral | Scenario prompts, STAR-shaped stories | Possible; the pack has not confirmed a values round | Pick a story where the outcome is yours to describe; say so where none exists |
| Conversational / Rapport | Friendly open prompts that are still scored | Common as an opener in any loop | Keep a 90-second arc ready; treat casual questions as scored |
| Peer Evaluator | Seams between teams, credit, disagreement | Likely if a peer from a partner team is in the loop | Offer what you bring to their team, not only what you need |

## Question banks

Provenance is `[generic]` throughout: no sentence of yours is in the pack, so no guidance cell makes a claim about your past. Where a question asks about your experience, the guidance is a selection scaffold ending in its honest branch.

### Case / Strategist (weight: flat)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A cross-team product launch has slipped two weeks. Walk me through how you would find out why." | CASE | [generic] | Clarify what slipped and against which date. Separate the blockers by owner. Name the one decision you would make within 24 hours, and who makes it | Live problem from F2's launch coordination. Presupposes nothing about your past |
| C2 | "Intake requests to your team doubled this quarter and nothing else changed. What do you do?" | CASE | [generic] | Ask whether volume is the problem or response time is. Segment requests by type and source. Propose one trade-off you would put to the owner | Live problem from F4. A decision, not a record |
| C3 | "You inherit a team with no operating cadence. What happens in the first month?" | CASE | [generic] | Diagnose before designing: which decisions are stuck, and who waits on whom. Name what you would change first and what you would leave alone | Live problem from F1. Asks for a plan, not a past |

### Data-Driven Prober (weight: flat)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Tell me about a metric you have reported on. How was it counted?" | EXP | [generic] | Open prompt. Pick one number you can explain end to end: source, definition, period. Name the assumption you would defend least. If you have never reported a metric, say so plainly and describe the nearest one you tracked | Open prompt from F3. The honest branch is built in |
| P2 | "How would you know a process change had worked, and what would you have measured if it hadn't?" | JD | [generic] | Name the measure before the change and what it can miss. Say what you would do if the measure moved for an unrelated reason. Do not invent a result | Tests F3's measurement requirement |
| P3 | "Our team's goal is to improve launch readiness. Make it measurable." | CASE | [generic] | Propose two measures, each with what it can miss. Choose one to lead with and say why | Live problem from F3. Asks for a design, not a record |

### Pressure / Stress (weight: flat)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| S1 | "Sixty seconds: why should we hire you over someone who has run this function longer?" | JD | [generic] | Pause. Restate the question. Lead with what you would do in the first 90 days, then concede specifically what the other person has that you do not. Hold through two follow-ups before conceding anything real | Pressure on the fit requirement. The position you hold is the one you can back from your own record |
| S2 | "That process you're proposing sounds like more meetings. How much of it is bureaucracy?" | CASE | [generic] | Hold your reasoning. Concede the real cost of the meeting, name what it buys, and offer to cut the part that buys least | Tests composure under a challenge to F1 |

### Skeptic (weight: flat)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| K1 | "Why this role, and why Stripe, now?" | CO | [generic] | Name one thing about the role's scope and one thing about the company you can state as your own observation. Keep both short. This needs company research the pack does not have, so do not guess at strategy | Motivation consistency is scored in nearly any round. CO because it needs company knowledge |
| K2 | "What is the weakest part of your background for this role, and how would you cover it in the first month?" | JD | [generic] | Open prompt. Name the weakest area you can point to in your own record, then a concrete ramp: what you would check first, whom you would ask, what you would do in week one. If you cannot name a weak area, say so plainly, then name the first thing you would verify | The highest-ROI prep in this pack: with nothing in hand yet, a weakest-area question is the one most likely to come in some form. Deepest rehearsal: three follow-up levels |

### Values / Behavioral (weight: flat)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Open prompt. Pick one case: the stake, what you said, how it ended. Use "we" for context and "I" for what you did. If none comes to mind, say so plainly, then give the nearest one you have | Persona stem. Tests disagreement with senior people, the core of F5 |
| V2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Open prompt. Pick a time the customer's need and the team's number pulled apart, and say which you chose and why. If none, say so plainly and give the nearest one | Persona stem. Pairs with F3 |
| V3 | "Tell me about a process you changed that people resisted." | VAL | [generic] | Open prompt. Name the resistance in the words people used, what you did about it, and what stayed unresolved | Persona stem. Pairs with F1 |

### Conversational / Rapport (weight: flat)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R1 | "So, walk me through the journey." | EXP | [generic] | Prepare a 90-second arc: the through-line you can defend, the two moves that shaped it, what you want next. Build it from your own record once you have one | Casual opener, scored like any other. Pre-scripted arc, no claim yet |
| R2 | "What are you playing with in product operations these days?" | JD | [generic] | Name one tool or practice you have used yourself, and what it did. Do not name one you have only read about | Casual probe on a role tool. Tests F1 and F3 without a formal prompt |

### Peer Evaluator (weight: flat)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Our teams sit side by side. Where's the seam, and what happens when we disagree?" | VAL | [generic] | Propose principles for the seam rather than claiming to know it. Describe how you have disagreed with an equal and what ended it | Peer collaboration probe on F5 |
| E2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Open prompt. Name who did what in one shared piece of work, in your own words. If you have not shared credit, say so and describe what you would do | Credit probe; tests F5 |
| E3 | "What would you need from my team to do this job well?" | JD | [generic] | Name two specific inputs and what you would give back in return | Reciprocity question. Tests F2 from the other side |

Totals: 18 questions across seven personas (3, 3, 2, 2, 3, 2, 3).

## Requirement coverage

| Requirement | Covered by |
|---|---|
| F1 operating cadence | C3, C2, V3 |
| F2 cross-functional launches | C1, E1 |
| F3 metrics and dashboards | P1, P2, P3, V2 |
| F4 intake and prioritization | C2 |
| F5 stakeholder disagreement | S1, V1, E1, E2 |
| Role tools | R2 |

## Sources

Provided documents: none. The conversation contained no CV, JD, interviewer profile, round description or recruiter guidance.

Searches sent (both refused, so no URLs came back):
- `Stripe company values principles`: refused
- `Stripe Product Operations Manager interview process final round`: refused

Research tier: L1, searches 0 of 6 (2 refused), fetches 0 of 2.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Stripe values` | unavailable | Values cheat sheet (section 10). Not produced, because the values are not in hand and a values round is not confirmed. Search was refused |
| 2. `Stripe interview process product operations` | unavailable | Loop structure, and the weights for the persona table. Search was refused |
| 3. `Stripe strategy` / recent news | unavailable | Grounding brief and CO questions. Not searched |
| 4. `{interviewer name} Stripe` | n/a | No interviewer name was given, so there is no query to form |
| 5. Representative Product Operations Manager JD | unavailable | Would have turned F1 to F5 from `[generic]` to `[inferred]`. Not searched |

## Upgrade menu

- Your round type and your relationship to the interviewer → persona weights and reverse questions set for that round, in place of flat weights
- The job posting text → F1 to F5 become quoted requirements, and the coverage table can be checked against the posting's own list
- Your CV → worksheet rows gain your quoted evidence, and selection scaffolds become story maps where a sentence of yours carries one
- Stripe's published values, pasted → a values cheat sheet, if a values round is in your loop
- Your interviewer's name → an interviewer read and a reverse question tied to their path
- Search permission for this session → company research at L1, and the option of deep research (L2) on request
- The recruiter's prep email → coverage of any deliverable they announced
- A dossier from an earlier session → inherited verified evidence and prohibited claims
