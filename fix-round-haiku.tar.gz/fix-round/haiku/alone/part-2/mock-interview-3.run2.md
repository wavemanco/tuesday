I built a first-pass prep pack from what you've given me. It's generic for now because I don't have your CV, the job description, or the round details, and web search was denied in this session, so I couldn't check anything about Stripe. Nothing about Stripe below comes from research or memory.

The pack is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-alone-part-2-rooms-case-3-denied-b220bd3a/f548cb59-0c39-4814-ad1d-d65fda2802ae/scratchpad/stripe_product_operations_manager_interview_pack.md`.

# Stripe, Product Operations Manager: final-round prep

**Assumed:** a hiring-manager final, with equal weight across personas.

**Types:** VAL is values and behavior, EXP is your past work, JD is the role's requirements, CO is company knowledge, CASE is a live problem. Guidance is scaffolding, not a script. Say only what you did, in your own words.

## Fit snapshot (worksheet)

With no JD, the requirements are general product-ops requirements, not quotes. With no evidence about you yet, every row is an open answer slot.

| # | Requirement | Gap and bridge |
|---|---|---|
| F1 | Run process design, cross-team launches, decision tracking | Name one process you changed or ran. If you didn't, say so and describe how you'd approach it. |
| F2 | Measure and report operational health | Name one metric you tracked and how it was counted. If you didn't track one, say which you'd track first. |
| F3 | Partner with engineering, finance, legal and go-to-market | Describe one cross-functional decision, who pushed back, and what you did. |
| F4 | Judgment on ambiguous, high-stakes trade-offs | Pick a decision made with incomplete information. Say what you decided and what you'd defend least. |

Hard gates such as location, onsite days or work authorization aren't in the material yet (see question 3).

## Question banks

**Skeptic**
- **A1 (EXP):** "Tell me about a decision you made that others pushed back on. What was yours to decide?" Pick a decision with a real stake where you held your position or changed it for a stated reason. If none comes to mind, say so and give the nearest one. This is the highest-value prep here: "did you decide, or coordinate?" is the most likely objection for an operations hire.

**Prober**
- **B1 (EXP):** "Pick one metric you've reported. How was it counted, and what part was yours?" Name the figure, then the assumption you'd defend least. Never invent a number.

**Case-led**
- **C1 (CASE):** "A launch slips two weeks because a dependency team is misaligned. What do you do?" Confirm the blocker and date, cost the slip, find the owner who can unblock, decide whether to re-scope or wait, and record the decision.
- **C2 (CO):** "Where would a fast-growing payments company's internal operations break first?" Name two or three likely failure points and a data check for each.
- **C3 (JD):** "How would you decide which internal process to fix first?" Criteria: frequency, cost, who it hurts, whether a fix exists, and an owner.

## Reverse questions

1. What would success look like for this role at six months?
2. Which process is the team most frustrated with right now?
3. How do product ops and product or engineering split decisions today?
4. What did the last person in this role do well, and where did they get stuck?
5. How do you measure whether an operational change worked?

## Research status

Research tier L0: no searches or fetches ran. The Stripe values, interview process and strategy sections are missing as a result. The values cheat sheet is omitted because I have no published values to map to.

## What would sharpen this

1. **Round type and who you're meeting.** Is it your future manager, a peer, or a cross-functional partner? Did the recruiter name focus areas, or a presentation or take-home?
2. **The JD and your CV**, or a few lines on your recent operations work. I can proceed without them, but the answer slots can't become real stories until I have them.
3. **Non-negotiables in the posting**, such as location, onsite days or work authorization. I'd like to check these before we go further.

Would you like a live drill? I can play the Skeptic on A1, the highest-value prep in the pack. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, and I can convert the pack to Word if you want it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: stripe_product_operations_manager_interview_pack.md -----
# Stripe, Product Operations Manager: final-round prep pack

Built without a CV, JD or round details, and without web research (search permission was denied this session). Worksheet variant: every cell about your past is an answer slot or a selection scaffold, not a story. Assumed a hiring-manager final with flat persona weights.

## How to use

Personas describe how a question is asked; types describe what is scored.

- **VAL**: behavioral and values alignment
- **EXP**: your work-experience deep-dive
- **JD**: the role's stated requirements
- **CO**: company and strategy knowledge
- **CASE**: a live problem

Guidance is scaffolding, not a script. Say only what you did, in your own words.

## Fit snapshot (worksheet)

No JD was supplied, so requirements are role-family prose tagged `[generic]`, not quotes. No evidence about you is in the conversation, so every evidence cell is `none given`.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Run product-operations work: process design, cross-team launches, decision tracking (role family) | none given | none | [generic] | discovery | Answer slot: name one process you changed or ran. If you did, say how and what changed. If not, say so and describe how you would approach it. |
| F2 | Measure and report operational health (role family) | none given | none | [generic] | discovery | Strong evidence is one metric you tracked, how it was counted, and which part was yours. Answer slot: if you tracked one, name it; if not, say which you would track first. |
| F3 | Partner with engineering, finance, legal and go-to-market on priorities (role family) | none given | none | [generic] | discovery | Strong evidence is one cross-functional decision, who pushed back, and what you did. Same answer slot as F1. |
| F4 | Judgment on ambiguous, high-stakes trade-offs (role family) | none given | none | [generic] | discovery | Selection scaffold: pick a trade-off where you decided with incomplete information. Say what you decided and what you would defend least. If no such decision comes to mind, say so plainly, then give the nearest one. |

Hard gates (location, onsite days, work authorization) are not in the material; question 3 below asks about them.

## Prohibited claims

None listed yet, because no sentences from you exist to stretch. The rule for this pack: no metric, process or decision will be attributed to you that you have not stated yourself.

## Question banks

Persona weights are flat because the round type is unknown. The session total is short of the usual 18 to 26 because a pack with no background cannot honestly reach that count without padding.

**Skeptic**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Tell me about a decision you made that others pushed back on. What was yours to decide?" | EXP | [generic] | Open prompt. Pick a decision with a named stake, where you held your position or changed it for a stated reason, and a working relationship intact at the end. Hold through two follow-ups by returning to that decision. Honest branch: if no such decision comes to mind, say so plainly, then give the nearest one or how you would handle it. | F3 and F4 have no evidence. The most predictable objection for an operations hire is "did you decide, or coordinate?" This is the highest-ROI prep in the pack. |

**Prober**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Pick one metric you have reported. How was it counted, and what part was yours?" | EXP | [generic] | Name the figure in your own words first, then the assumption you would defend least, before the interviewer raises it. Answer slot: if you did not track a metric, say so and say which you would track first. Never supply a number. | F2 has no evidence. Probers ask for the denominator. |

**Case-led**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A launch slips two weeks because a dependency team is misaligned. What do you do?" | CASE | [generic] | Structure it: confirm the real blocker and date; work out what the slip costs and who bears it; find the owner who can unblock; decide whether to re-scope or wait; write down the decision and the trigger for the next check. Makes no claim about your past. | Tests F3 as a live problem. Generic, because it is a pattern rather than a fact about this employer. |
| C2 | "Where would a fast-growing payments company's internal operations break first, and how would you find out?" | CO | [generic] | Name two or three likely failure points (volume spikes, handoffs between teams, cross-border complexity), and for each, a data check that would confirm or rule it out. | Company depth without research. Generic and labeled as such. |
| C3 | "How would you decide which internal process to fix first?" | JD | [generic] | Criteria: frequency, cost of the current state, who it hurts, whether a fix exists, and a named owner. | Covers F1 as a method. Answer with criteria; do not invent a past example. |

## Requirement coverage

No JD, so requirements are role-family prose. F1 is covered by A1 and C3. F2 by B1. F3 by A1 and C1. F4 by A1. None of the four has a dedicated JD question yet.

## Reverse questions

1. "What would success look like for this role at six months?" Why it lands: it turns the conversation into a shared target.
2. "Which process is the team most frustrated with right now?" Why it lands: it shows you want the hard problems.
3. "How do product operations and product or engineering split decisions today?" Why it lands: it reveals the authority model that the Skeptic question tests.
4. "What did the last person in this role do well, and where did they get stuck?" Why it lands: it calibrates your next conversation.
5. "How do you measure whether an operational change worked?" Why it lands: it tests whether the team measures outcomes, and ties to F2.

## Research and sources

Provided documents: none.

Search query "Stripe Product Operations Manager interview process final round" was refused: search permission denied this session. Nothing about Stripe's values, process or strategy comes from research. Nothing is stated from memory as fact.

**Research tier: L0, searches 0 of 0, fetches 0 of 0**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Stripe values | unavailable | Values cheat sheet omitted. Query refused. |
| 2. Stripe interview process, product operations | unavailable | Loop structure unknown, so persona weights are flat. Query refused. |
| 3. Stripe strategy and recent news | unavailable | CO questions stay generic. |
| 4. Interviewer name and company | n/a | No interviewer name given. |
| 5. Representative Product Operations Manager JD | unavailable | Fit snapshot stays generic. |

## Upgrade menu

- **JD text** turns F1 to F4 into quoted rows and makes the `[generic]` questions `[grounded]` or `[inferred]`.
- **CV or a few lines on your recent operations work** lets selection scaffolds become story maps.
- **Round type and who you are meeting** reweights the personas, adds an interviewer read and tailors the reverse questions.
- **The recruiter's prep email** adds a build section for any presentation or take-home.
- **Search permission** adds Stripe's values, interview process and current strategy, which makes the values cheat sheet and the CO questions specific.
