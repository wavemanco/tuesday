Your prep pack is saved as `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-alone-part-2-rooms-case-3-denied-4da5c1ce/28814e12-3415-45aa-b15f-945d0ecfa00f/scratchpad/stripe_product-operations-manager_interview_pack.md`.

I couldn't research Stripe. Web search was refused by the session's permissions, so the pack has no company-specific claims. Stripe's values, interview loop and current strategy are missing, and the values section and the company-strategy questions are left out. The requirements are typical for the role family, not from a real posting. I built the persona weights as a blend because I don't know the round format.

Here's what I'd do with the pack:
- Rehearse B1 first: "Which part of this role would you be weakest at on day one?" It's the question most likely to come up in some form, and it's the one the pack flags as highest-ROI.
- Have a figure ready for C1 if you have one you can explain. Be ready to say how it was counted and which assumption you'd defend least.

Want me to play the Skeptic on B1 in a live drill? I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

Three things would reshape it:
1. Who are you meeting, and is it a hiring manager, a peer, or a panel? Is the final one session or several?
2. Could you paste the job description and your CV? Without them, every requirement is generic and no answer is drawn from your own experience. I can proceed without them, but the pack will be much weaker.
3. Did the recruiter mention a take-home, presentation or other deliverable?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: stripe_product-operations-manager_interview_pack.md -----
# Stripe: Product Operations Manager, final round (prep pack)

Interviewer: not named. Round format and relationship: not stated, so persona weights are a blend. No JD or CV in this session. Company research was refused by the host (see Sources), so this pack carries no company-specific claims.

## How to use

- **Personas** describe how a question is asked. **Types** describe what is being scored.
- Type key: **CASE** live problem · **EXP** your past work, probed · **JD** the role's requirements and your fit · **VAL** behavior under a values lens · **CO** company knowledge (none in this pack; see Sources).
- Guidance is scaffolding, not a script. Say it in your own words, and rehearse out loud.

## Fit snapshot (worksheet variant)

No JD and no CV were supplied, so every evidence cell is empty. Requirements below are typical for the role family, not quoted from a posting.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Run recurring operating processes (planning, reviews, cadence): role-family requirement, no source supplied | none given | none | [generic] | discovery | Strong evidence looks like one recurring process you designed or ran, with its inputs and outputs named. Selection scaffold: pick a recurring process you ran; name what it produced and who relied on it. If you ran none, say so and describe the nearest one. |
| F2 | Coordinate across functions without direct authority: role-family requirement, no source supplied | none given | none | [generic] | discovery | Strong evidence looks like one decision you moved through teams you did not manage. Selection scaffold: pick a decision that needed people who did not report to you; say what moved it. If none, say so and describe how you would start. |
| F3 | Define and track outcome measures: role-family requirement, no source supplied | none given | none | [generic] | discovery | Strong evidence looks like a measure you chose, the reason for it, and what it changed. Answer slot: name a measure you chose yourself and why; if you did not choose one, say so, and say what you would measure first. |
| F4 | Lead launches or rollouts of processes or tools: role-family requirement, no source supplied | none given | none | [generic] | discovery | Strong evidence looks like one rollout you led, with its adoption result. Selection scaffold: pick a rollout; say what you did and what people did afterward. If you led none, say so and describe a rollout you watched closely. |
| F5 | Prioritize and make trade-offs under limited capacity: role-family requirement, no source supplied | none given | none | [generic] | discovery | Strong evidence looks like a choice you made between two valid asks and why. Selection scaffold: pick a trade-off you made; say what you dropped and what it cost. If none, say so and describe your decision rule. |
| F6 | Work with ambiguity and scale processes as the team grows: role-family requirement, no source supplied | none given | none | [generic] | discovery | Strong evidence looks like a process you changed when volume rose. Selection scaffold: pick a point where volume outgrew a process; say what you changed. If none, say so and say how you would find that point. |

No gate rows: with no JD, nothing is marked as a hard requirement.

## Prohibited claims

No entries yet. Nothing about your past is in the material, so there is no sentence to stretch. The rule until a CV is supplied: do not name a metric, team size, scope or outcome you cannot repeat under a second follow-up. Any figure you give will be probed.

## Persona table

Weights are a judgment, shown so you can correct them. Round format is unknown, so weights follow a final-round blend.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | Live operating problems: diagnose, plan, size | High. Final rounds for operations roles usually test structure on a live problem | Clarify, then state the objective, segment, approach, metrics and risks. Think aloud |
| Skeptic | Quiet probing of the thinnest requirement; "why this, why now" | High. Ops roles get probed on whether the candidate has really owned cross-functional work | Rehearse the single most predictable objection until it is plain. Name a real gap, then a ramp plan |
| Data-Driven Prober | Asks how a number was counted and what it assumes | Medium. Likely only if you lead with a figure | Say how each figure was counted, or say you do not know. Name the weakest assumption first |
| Peer Evaluator | Seams with adjacent teams; credit; disagreement | Medium. Likely if one interviewer is a peer or a cross-functional partner | Offer reciprocity: what you bring their team, not only what you need. Propose seam principles |
| Pressure / Stress | Interrupts, time-boxes, challenges the claim | Medium. Final rounds often include one composure check | Pause. Hold the position through two follow-ups, then concede specifically |
| Values / Behavioral | Scenario prompts asking for past behavior | Medium. Generic here: no published values were available to map to | Use one story per prompt; "we" for context, "I" for your part; say so when no story fits |
| Conversational | Friendly openers that are still scored | Low. Casual openers can still score the JD's plus-skills | Keep a 90-second career arc ready. Treat casual questions as scored |

## Question banks

Weights: Case 5 questions, Skeptic 3, Prober 3, Peer 3, Pressure 3, Values 3, Conversational 2. Total 22.

Provenance: this pack has no candidate sentences, so every row carries its label alone. Rows that ask about your past are open prompts with themes from persona stems. They do not presuppose any particular event.

### A. Case / Strategist (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A recurring process you run is getting late inputs from three teams. Walk me through what you'd do." | CASE | [generic] | Clarify what "late" means and what breaks downstream. State the objective. Segment causes (intake, owner, timing). Propose an approach, then the metric you would watch, then the risks. Keep it to 90 seconds. | Role-family live problem for F1 and F2. Makes no claim about your past |
| A2 | "The launch-readiness review keeps slipping by a week. Diagnose it." | CASE | [generic] | Ask what slips and who is waiting. Test two hypotheses, one people-side and one process-side. Say which data you would pull first. | Tests F1 and F4 structure. The guidance supplies no facts about any real review |
| A3 | "You're asked to set up an operating review for a new product area with no process. Sketch the first 90 days." | CASE | [generic] | Week 1–2: listen and map decisions. Week 3–6: pilot one cadence. Week 7–12: measure and cut. Name what you would not build yet. | Tests F1, F6. A plan, not a claim about past work |
| A4 | "Two product leads want the same capacity this quarter. How do you decide, and what do you need to know first?" | CASE | [generic] | Clarify the constraints and the cost of delay for each. State a decision rule before picking a side. Name who decides if you cannot. | Tests F5 under a live conflict |
| A5 | "A metric you're accountable for drops 20% in a week. Walk me through your first hour." | CASE | [generic] | Confirm the metric is real (definition, data freshness). Split by segment and by time. Check for a change that happened the same week. Escalate only once you can say what changed. | Tests F3 diagnosis. Metric questions name the weakest assumption: say which part of the data you trust least |

### B. Skeptic (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | **Highest-ROI prep in this pack.** Name one real gap in your own words, then the plan to close it: what you would learn, from whom, by when. Answer slot: if you have a real gap from your experience, name it. If you can point to none, say so plainly and name the first thing you would learn. Hold through two follow-ups by returning to the gap and the plan. | Asked in some form to almost every candidate in a final round. A calm, specific answer changes the interview. Nothing about your past is assumed |
| B2 | "Why leave your current role for this one, and why now?" | JD | [generic] | A 90-second arc: what you do now, what you want that you lack, why this role. Answer slot: say what this role gives you that your current one does not. If the honest answer is mostly about what you want to leave, say that and say what you want instead. | Motivation consistency is the Skeptic's standard question. The arc is for your own material; nothing is supplied |
| B3 | "Product operations often means owning things you don't formally control. Where have you had to get results without authority, and where did it not work?" | JD | [generic] | Open prompt: pick one instance where you got results without authority. Say what you did, what the other people did, and the result. Then the failure, with what you changed. | F2 and F5 probed through a failure. The question's premise is the role's, not a fact about you |

### C. Data-Driven Prober (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Pick the result you're proudest of. Walk me through how it was counted." | EXP | [generic] | Choose one figure you can repeat. Answer four things in your own words: how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. Answer slot: if you have no counted result, say so, then describe how you would measure one. Never give a figure you cannot explain | F3. Prober questions go to the denominator, and the assumptions come next |
| C2 | "Which assumption behind that number would you defend least?" | EXP | [generic] | Name the weak assumption before the interviewer does. Say what you would check if you had more time. | Follow-up to C1. Naming the weak assumption converts a gotcha into a credibility gain |
| C3 | "Of the processes you've run, what did the data show that surprised you?" | EXP | [generic] | Open prompt: pick a process where data changed your view. Say what you expected, what came back, and what you did with it. If no process produced such a surprise, say so and describe a time you checked an assumption. | F3 and F1. A real surprise is the strongest answer; a missing one is honest |

### D. Peer Evaluator (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Our teams sit side by side. Where's the seam with the teams you'd support, and what happens when we disagree?" | JD | [generic] | Propose seam principles, not facts about their teams: who owns the decision, how disagreement gets escalated, how you keep both sides' work visible. Ask one question about where they see the seam. | Peer probe on turf. Not a claim about past work |
| D2 | "How do you handle credit when work spans teams?" | EXP | [generic] | Open prompt: pick one shared piece of work. Say who did what in your words, and how you named the contributions. If you have no such example, say so and describe how you would do it. | F2. Shows credit-sharing habits |
| D3 | "What would you need from me in the first month to do this job well?" | JD | [generic] | Name two or three concrete asks: a data source, a decision-maker, a standing meeting. Then what you would bring their team in return. | Reciprocity framing. Shows you have thought about the seam |

### E. Pressure / Stress (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over an internal candidate?" | JD | [generic] | Pause. Give one claim you can back, in your own words, then stop. Hold through one follow-up. Answer slot: if you have a specific advantage from your experience, state it. If you do not, say what you bring that the role needs and why you want it. | Time-boxed challenge. Hold-then-concede: one claim, held, not padded |
| E2 | "Tell me about a time a result you reported was challenged. How much of it was yours?" | EXP | [generic] | Open prompt: pick one instance. Say what was challenged, what you defended, and what you conceded. If no result was ever challenged, say so and describe a claim you revised. | Attribution under pressure. Concede specifically, never fold on the core claim |
| E3 | "Tell me about a process change that didn't land. What did you do?" | EXP | [generic] | Open prompt: pick one. Say what you expected, what happened, what you changed. If none did not land, say so and describe a change you were unsure about. | F4 probed through failure. Honest answers are allowed here |

### F. Conversational / Rapport (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | JD | [generic] | A 90-second arc in your own words: the work, the turning points, why this role now. Rehearse it aloud twice. | Casual opener. Treat it as scored |
| F2 | "What have you been reading or building in operations lately?" | JD | [generic] | Name one thing you have read or built, and what you took from it. Say it plainly; it does not need to be impressive. | Signals current interest in the function |

### G. Values / Behavioral (weight: medium; generic)

No published company values were available, so these prompts are generic, not mapped to any company's principles.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Open prompt: pick one. Say the truth, who heard it, how it landed, what happened next. If none comes to mind, say so and describe the nearest case. | Scored behavioral prompt. Stories must have a real stake |
| G2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Open prompt: pick one. Say what the metric was, what the customer needed, what you chose, and what it cost. If none, say so and describe how you would weigh it. | Customer-first lens. A customer-over-metric story is strong if it is true |
| G3 | "Tell me about a decision you made with incomplete information." | VAL | [generic] | Open prompt: pick one. Say what you knew, what you did not, what you decided, and how you checked it afterward. | Judgment under uncertainty. Honest hedging is part of the answer |

## Requirement coverage

| Requirement (role family, no JD) | Questions |
|---|---|
| F1 Recurring operating processes | A1, A3, C3 |
| F2 Cross-functional without authority | B3, D2, D1 |
| F3 Outcome measures | A5, C1, C2 |
| F4 Launches and rollouts | A2, E3 |
| F5 Prioritization and trade-offs | A4, B3, E1 |
| F6 Ambiguity and scale | A3, G3 |
| Named tools or systems | none, and why: no JD names any |

## Reverse questions

1. "What does a strong first 90 days look like for this role, and who would I work with most?" Why it lands: forces role-specific detail and shows you plan.
2. "Who sets priorities for product operations here, and how does that get decided?" Why it lands: tests how the function is actually run, not how it is described.
3. "What is the biggest operating problem the team is working on right now?" Why it lands: shows you want the real job, not the brochure.
4. "How will success be measured for this role at six and twelve months?" Why it lands: signals you think in outcomes.
5. "What did the person who did this job best do that made the team trust them?" Why it lands: a concrete picture of the bar.
6. Reciprocity (if the interviewer is a peer): "What could a new person do in their first month that would genuinely help your team?" Why it lands: turns the close into a working conversation.

No profile exists for the interviewer, so no reverse question is tied to their career path.

## Sources

- Provided documents: none beyond the request.
- Research tier: L1 requested by default; 0 of 6 searches and 0 of 2 fetches completed.
- Searches sent, all refused by host permission (none returned results):
  - "Stripe values mission principles": refused
  - "Stripe interview process final round onsite Product Operations Manager": refused
  - "Stripe \"Product Operations Manager\" job description requirements": refused

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Stripe values | unavailable | Values cheat sheet (section 10) and mapped VAL stories. Omitted, since no values are in hand |
| 2. Stripe interview process | unavailable | Loop structure and persona weights. The blend here is a guess and would be firmer with the loop |
| 3. Stripe strategy and recent news | unavailable | CO bank and grounding brief. No CO questions are in this pack |
| 4. Interviewer name | n/a | No name was given, so there was no query to form |
| 5. Representative Product Operations Manager JD | unavailable | Would have made the fit snapshot's requirements `[inferred]` quotes |

## Upgrade menu

- **Paste the JD** → the six `[generic]` requirement rows become quoted rows, and the coverage table becomes a real check.
- **Paste your CV** → evidence cells fill with your own sentences; story-mapped answers replace the selection scaffolds; the figure questions (C1 and C2) become answerable from your material.
- **Tell me the round format and who you're meeting** → persona weights and reverse questions get specific. A peer round moves D up; a manager round moves B and A up.
- **Recruiter note on any take-home or presentation** → a build section for it.
- **Stripe's values, pasted from their site** → values cheat sheet, and G1 to G3 get mapped stories.
- **Web search permission granted** → research at L1 (values, interview process, a representative JD). Deep research at L2 is available once search works: strategy brief, interviewer talks, loop reports, under 6 further searches and 2 fetches.
- **Interviewer's name** → a tailored reverse question and persona weights from their public footprint.
