Your pack is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-alone-part-2-rooms-case-4-denied-725ab3ba/76688433-5c55-4da5-86e8-c0eaedf364aa/scratchpad/quartzline_product_manager_platform_apis_interview_pack.md`. Here's the core of it.

**Date correction:** today is Wednesday 11 November, so Thursday is **12 November**. My earlier note said the 13th, which is a Friday. The dossier is also three months old, so check the current posting against its five requirements.

## Your rules for the room

- **Concede first, then bridge.** "I haven't held a product manager title or owned a roadmap." Then the integrations you led to go-live. Then a ramp plan, stated as a plan.
- **Never claim:** holding a PM title or role, owning a roadmap, or setting prioritization for an engineering squad. Also avoid "shipped API products" as something you owned. Your material says client integrations on the vendor's APIs.

## Likely questions, by weight

**Skeptic (highest weight, the dossier's named objection):**
- A1: "Why hire you into a PM role instead of a PM with three years of the job?" This gets the deepest rehearsal. Hold on the integration work through two follow-ups, and concede the roadmap gap if pushed.
- A4: "Name a shipped API product you owned end to end." Answer in your own words. If the go-lives were client integrations, say so and stay with them.
- A5: "Did you work in sprints?" If not, say how the work was planned.

**Case/Strategist:**
- B1: First-90-days plan. Ask who decides which roadmap calls. This is the decision-authority risk.
- B3: Adoption dropped 20%. Ask for the current baseline.
- B4: Two squads and a partner want different work. Whose call is it?

**Prober:**
- C1: How was the "30+" integrations figure counted? Name the assumption you'd defend least, and which were yours.
- C2: Which adoption metric would you trust least? If you measured none, say so.

**Pressure:**
- D1: "Sixty seconds: why you?" Hold through two follow-ups.
- D2: "How much of that result was actually you?" Concede any shared credit explicitly.

**Conversational:**
- E1: "Walk me through the journey." Arc: integrations to go-live, the playbook you wrote, the roadmap-input sessions, then the PM-title gap stated once, before they find it.

## Probes to prepare for

- **Roadmap-input sessions (medium confidence):** you fed client evidence into product. You did not set roadmap content. Expect a count question, and say plainly if you didn't track one.
- **Schemas (R3):** your material shows a playbook, not schema work. Answer the slot honestly.

## Reverse questions

1. Which roadmap decisions does this PM make alone, and which belong to the squad leads?
2. How is partner API adoption measured today, and what is the baseline?
3. What should a PM here have decided by the end of the first quarter?
4. How do the two squads divide the platform work today?
5. What does a typical partner discovery session look like, and who from sales attends?

## Research status

I could not run research. Both web searches were refused for lack of permission, so the company values and interview-process sections rest on the dossier alone.

## Questions for you

None needed. The dossier covers the round type and the requirements.

- **Drill:** I can play the Skeptic on A1 and push back on your answer. Say the word.
- **Dossier:** I can save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry forward.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quartzline_product_manager_platform_apis_interview_pack.md -----
# Interview pack: Product Manager, Platform APIs at Quartzline

**Round:** 45-minute hiring-manager conversation, Thursday 12 November 2026 (today is Wednesday 11 November; my earlier note said the 13th, which is a Friday).
**Source:** the job-underwriter dossier (`tuesday-dossier.md`, dossier_version 1.1, generated 2026-08-14, decision conditional_go).
**Check first:** the dossier is about three months old. Read the current posting and confirm the five requirements below still match it.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored: JD (can you do the listed job, gaps included), EXP (does the claim survive scrutiny), CASE (live problem), CO (company knowledge), VAL (values).

Guidance is scaffolding for a spoken answer, not a script. Every claim about your past comes from a quote in your own material, or it is an answer slot you fill in your own words.

## Fit snapshot

Confidence is high, medium, low or none. Provenance is [grounded], [inferred] or [generic]. Gap types are the six from the evidence conventions.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" (dossier role_profile, R1, must_have) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier verified evidence, high, inspectable) | low | [grounded] | transferability | Integration leadership is adjacent to PM tenure, and the bridge stays at its own scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs." State the limit yourself: "I haven't held a product manager title." |
| F2 | "Shipped API or platform products" (dossier role_profile, R2, must_have) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier verified evidence, high) | medium | [grounded] | transferability | Those go-lives were client integrations built on the vendor's APIs, not a platform product you owned. Say that before they ask. Answer slot: if you owned any API product end to end, name it and what you decided; if the go-lives were client integrations only, say so and stay with them. |
| F3 | "Technical fluency: API docs, schemas" (dossier role_profile, R3, important) | "Wrote the internal integration playbook her team uses" (dossier verified evidence, high, inspectable) | high | [grounded] | discovery | A playbook touches API documentation, but the material does not show schema work. Answer slot: if you read or wrote API schemas or specs, say which and how; if you did not, say so and say what you would learn first. |
| F4 | "Stakeholder management across engineering, sales, customers" (dossier role_profile, R4, important) | "Ran quarterly roadmap-input sessions feeding client evidence to product" (dossier verified evidence, medium, limited inspectable proof); "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier verified evidence) | medium | [grounded] | transferability | Your material shows customer-side and product-side work. No quote shows managing engineering or sales. Bridge: "I ran quarterly roadmap-input sessions feeding client evidence to product." Answer slot: which engineering or sales conversations were yours to run, if any; if none, say so. |
| F5 | "Agile delivery experience" (dossier role_profile, R5, preferred) | none given | none | [grounded] | discovery | Clarify strategy. Answer slot: the interviewer will likely ask how work was planned and reviewed. Say how it was done in your integration projects; if you did not work in sprints, say so and describe how the work was planned. |
| F6 | "Own the roadmap for the partner-facing API platform" (dossier role_profile responsibilities; dossier uncertain_or_weak_areas, acknowledge_gap) | none given; you have stated no roadmap ownership | none | [grounded] | capability | Acknowledgment only, with a ramp plan. Words, from the dossier's own prohibited-claims and acknowledge-gap fields: "I haven't owned a product roadmap or set prioritization for an engineering squad." Then your ramp plan, as a plan and never as a past. No bridge here. |

## Prohibited claims

These are not to be coached, in any answer, on any question. The basis is the dossier's `prohibited_claims` list unless stated.

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | dossier prohibited_claims | "I haven't held a product manager title or role." No answer slot. |
| Having owned a product roadmap | dossier prohibited_claims and acknowledge_gap | "I haven't owned a product roadmap." Then the roadmap-input work at its own scope, which is input to product, not decisions. |
| Having set prioritization for an engineering squad | dossier prohibited_claims | "I haven't set prioritization for an engineering squad." |
| Shipped API or platform products, as products you owned | inflated form of F2 | F2's quote at its scope: integrations taken to go-live. The limit is the pack's own observation: your material says client integrations, not a product. |
| Decided roadmap input, as if you decided roadmap content | inflated form of F4 | F4's quote at its scope. Your material says input to product, not the decision. |

## Persona weights

Relationship prior: hiring manager. The dominant personas are Case/Strategist and Skeptic, because a hiring manager is buying capability and checking the gap. The dossier named the most likely objection, which puts Skeptic at the top.

| Persona | Weight | Reasoning |
|---|---|---|
| Skeptic | 5 | The PM-title gap is the central objection, which the dossier named. Highest-ROI prep. |
| Case/Strategist | 5 | Hiring manager running live problems on a partner platform. |
| Data-Driven Prober | 3 | Adoption metrics are a responsibility with no stated baseline. |
| Pressure | 3 | Squad authority and the claimed 30+ figure are where challenges land. |
| Conversational | 2 | Opening and biography questions are still scored. |

## Question banks

Each row's Provenance lists the candidate's own sentences that the guidance rests on.

### Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the job?" | JD | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product"; [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Highest-ROI rehearsal in this pack, and the dossier named this objection. Open with the concession in one sentence: "I haven't held a product manager title or owned a roadmap." Then the bridge: the integrations you led to go-live, and the client evidence you fed to product. Then the ramp plan, as a plan. Hold through two follow-ups by returning to the integration work. Concede the roadmap gap again if pushed, and never claim it. | F1 and F6. The dossier named this objection from evidence you confirmed, so the wording is theirs. |
| A2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Having owned a product roadmap" (dossier prohibited_claims) | Name roadmap ownership and setting squad priorities, once, plainly. Then the ramp. Do not add a second weakness. | F6. Skeptic stem. The answer uses the acknowledgment the dossier allows, nothing more. |
| A3 | "Your background is integrations, not product management — how would you handle the three-year requirement?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Limit first, in one clause: "I haven't held a PM title." Bridge second, in one clause, at the quote's scope. Do not argue the requirement. | F1. The question's premise is the requirement's own wording, and the limit comes before the bridge. |
| A4 | "Name a shipped API product you owned end to end." | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Answer slot: if you owned an API product end to end, name it and what you decided, in your own words. If the go-lives were client integrations on the vendor's APIs, say so and stay with them. | F2. The question presupposes product ownership the quote does not carry, so the second branch must allow that it never existed. |
| A5 | "How did work get planned and reviewed on your integration projects — did you work in sprints?" | JD | none given | Answer slot: say how it was done. If you did not work in sprints, say so and describe the planning and review you did. | F5, which is a clarify area. The requirement's wording is the probe; nothing about your past is assumed. |

### Case/Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Sketch the plan for the first 90 days on this platform — what do you need to know first?" | CASE | [generic] | Clarify, then objective, then who decides which roadmap calls, then partner segments, then how adoption is measured, then risks. Ask the decision-authority question here, out loud, because it is an open risk. | Live problem from the JD's responsibilities. Asks no claim about your past. |
| B2 | "Partner integrations are stalling at UAT. Diagnose it." | CASE | [generic] | Structure: which stage stalls, for which partners, what changed, and what you would check first. Name your assumptions. | Live problem in the integration lifecycle the JD describes. |
| B3 | "Adoption of the partner API dropped 20% quarter on quarter. Diagnose it." | CASE | [generic] | Clarify the denominator and the baseline before diagnosing. Ask for the current adoption baseline. That answer is the employer question in the reverse section. | Tests the adoption-metrics responsibility. No current baseline is stated anywhere. |
| B4 | "Two squads want different platform work for next quarter, and partners want a third thing. How do you decide, and whose call is it?" | CASE | [generic] | Give a recommendation and the decision rule you would use. Say whose call it is and what you would need to confirm. Do not claim you have ever set squad priorities. | Tests the squad-authority unknown. Asks no claim about your past. |
| B5 | "Engineering wants to delay a partner launch two weeks; sales has a commitment. What do you do?" | CASE | [generic] | Name the trade-off, the customer impact of each option, and who you would bring in. Stay with the decision rule. | R4 (stakeholder management). Live problem. |

### Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how you counted the integrations you led — what counted as one?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Defend-the-number slot: how the 30+ was counted, what it is sensitive to, the assumption you would defend least, and which of those integrations were yours. Answer in your own words. If you did not record how it was counted, say so. | The 30+ figure is the claim most likely to be probed. Attribution is the honest answer. |
| C2 | "Which adoption metric would you trust least, and what is its denominator?" | JD | [grounded] "Define and track adoption metrics" (JD responsibility, dossier role_profile) | Answer slot: if you measured adoption on any integration, say what and how. If none, say so plainly and say how you would define the metric first. | The JD names adoption metrics as a responsibility, and the material shows no measure. Second branch allows that none existed. |
| C3 | "Of the requests you brought to product through roadmap-input sessions, what share were acted on?" | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Answer slot: if you tracked the share, say how it was counted. If not, say so plainly. Do not estimate a number. | Premise is a count the quote does not carry. The slot tests whether you know your own numbers. |

### Pressure (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over an internal candidate?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Pause, restate the question, then anchor in the integrations you led to go-live. Hold through two follow-ups. Concede the PM title if pushed, and do not fold on the integration work. | Pressure stem. Hold-then-concede on the core claim. |
| D2 | "That integration result — how much of it was actually you?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Hold "led" as the quote states it. Name what was shared with the vendor or client, and concede that explicitly where it was shared. Do not add credit you cannot back. | The honest answer to a probe built to catch inflation. |
| D3 | "Which roadmap decision would you make alone, and which would the squad leads make?" | JD | [grounded] "I haven't owned a product roadmap or set prioritization for an engineering squad" (dossier prohibited_claims) | Say what you do not know about how decisions are split today, and ask rather than assume. Do not claim ownership of any roadmap decision. | Tests the decision-authority risk directly. The honest answer is a question back. |

### Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So — walk me through the journey." | VAL | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; [grounded] "Wrote the internal integration playbook her team uses"; [grounded] "I haven't held a product manager title." (dossier prohibited_claims) | A 90-second arc in this order: integrations led to go-live, the playbook you wrote, the roadmap-input sessions, then the PM-title gap stated once. Keep it in your own words. | Casual register, still scored. The arc places the gap before they find it. |
| E2 | "How would you make API docs and schemas useful to an integration team?" | JD | [grounded] "Wrote the internal integration playbook her team uses" | Story-map from the playbook: what it covers and why your team uses it. Answer slot for schemas: if you wrote or reviewed schemas, say which; if not, say so and say how you would learn to do it. | R3 has no other question. Schemas are not in your material, so the answer leaves them to the slot. |

## Requirement coverage

| Requirement | Questions covering it |
|---|---|
| R1 3+ years PM experience | A1, A3, D1 |
| R2 Shipped API or platform products | A4 |
| R3 Technical fluency: API docs, schemas | E2 |
| R4 Stakeholder management | B5, D3 |
| R5 Agile delivery experience | A5 |
| Own the roadmap (responsibility) | A1, A2, D3 |
| Define and track adoption metrics (responsibility) | B3, C2 |

## Reverse questions

Each one is taken from the dossier's employer questions or risks. Ask at most three; the first two matter most.

1. "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" Why it lands: decision authority is asserted in the JD and unevidenced. Answering it tells you whether the role fits your background.
2. "How is partner API adoption measured today, and what is the current baseline?" Why it lands: adoption is a stated responsibility with no baseline. A missing baseline is a real risk for you.
3. "What would a PM in this role be expected to have decided by the end of the first quarter?" Why it lands: tests what success looks like against your ramp plan.
4. "How do the two engineering squads divide the platform work today?" Why it lands: squad authority is the second risk the dossier flagged.
5. "What does a typical partner discovery session look like, and who from sales attends?" Why it lands: connects R4 to the actual work.

The interviewer profile is not available, so no reverse question ties to their own career path.

## Sources

- **Provided document:** the job-underwriter dossier. Sections consumed: handoff_to_mock_interview (verified evidence, weak areas and their strategies, likely objection, prohibited claims, risks, employer questions) and role_profile (requirements R1 to R5 and responsibilities). decision was read as context only.
- **Research tier: L1.** Searches 0 of 6 completed; two attempted and both refused for lack of permission. Fetches 0 of 2.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quartzline values | unavailable | Would have moved the values cheat sheet, which this round does not need unless a values round appears. |
| 2. Quartzline interview process, product manager | unavailable | Would have moved the loop structure and the persona weights. |
| 3. Quartzline strategy and recent news | unavailable | Would have moved the company-knowledge questions. No strategy brief was supplied. |
| 4. Interviewer name | n/a | No name given, so no query could be formed. |
| 5. Representative JD | skipped | The dossier's role_profile fixes the requirements. |

## Upgrade menu

- The current posting → checks the five requirements against the version the dossier was built from, which is three months old.
- Your CV or playbook excerpt → turns the dossier's quotes into your own sentences, and may upgrade F3 and F5.
- The hiring manager's name → a public-footprint read, a tailored reverse question, and persona weights tuned to them.
- Permission for web search → research on Quartzline's values and interview process at the L1 tier, six searches and two fetches.
- Deep research (L2), offered once → strategy brief, interviewer writing, role-family loop reports and recent org context, at most six further searches and two further fetches, with extra time.
- The recruiter's note on focus areas → confirms whether the round leans toward the Skeptic or the Case.
