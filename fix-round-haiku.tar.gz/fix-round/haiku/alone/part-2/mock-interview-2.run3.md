Your prep pack is saved at /tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-alone-part-2-rooms-case-2-denied-468c7425/83b8b4d7-b8fd-4e02-9858-24b680b8e901/scratchpad/Atlas_Freight_operations_manager_interview_pack.md. I built it without knowing the round or who is interviewing you, so the persona weights are blended rather than tuned. I did not run web research, because I was waiting on your answer about the round.

The biggest risk is scale. The JD asks for 12 supervisors across 4 sites, and your material shows 3 supervisors on a shift. That is question A1, and I'd rehearse it first.

Say the word and I'll play the Skeptic on A1.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Is the person you're meeting your future manager, or a peer on the team? The answer reweights every bank.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Atlas_Freight_operations_manager_interview_pack.md -----
# Operations Manager, Atlas Freight: interview prep pack

**Role:** Operations Manager, Atlas Freight (regional logistics, 800 employees)
**Interviewer:** not given. **Round type and relationship:** not given.
**Version:** first. Persona weights are blended, not tuned to a known round.

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is scored.
- Type key: **VAL** behavioral/values, **EXP** your experience, tested for attribution, **JD** the role's stated requirements, **CO** company knowledge (not included: no research ran), **CASE** a live problem.
- Guidance is scaffolding, not a script. Say it in your own words. The quoted lines are the ones you can stand behind.

## Fit snapshot

Requirements are the JD's own words, as you pasted them. Evidence is your message's own words. Nothing else is evidence. You have no CV on file, so every evidence cell comes from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" (JD) | "7 years in warehouse and distribution ops" (your message); "ran the site's peak-season surge plan two years running" (your message) | medium | [grounded] | transferability | Your material shows warehouse and distribution work and one site's peak plan. It does not show terminals or four sites. Say what you have: "I've spent seven years in warehouse and distribution ops." Answer slot: if you have run operations across more than one site, say which and how; if you have run one, say so and say what carries over. |
| F2 | "drive on-time performance and cost-per-shipment down" (JD) | "cut mis-pick rate 40% by redesigning the pick path" (your message) | medium | [grounded] | transferability | Your material shows pick accuracy, not on-time performance or cost per shipment. Say the sentence as written: "cut mis-pick rate 40% by redesigning the pick path." Answer slot: if you tracked on-time or cost per shipment on any shift or site, say what you tracked and what it showed; if you did not, say so and say how you would set up both measures. |
| F3 | "lead a team of 12 supervisors" (JD) | "currently a senior shift manager over 3 supervisors" (your message) | medium | [grounded] | transferability | Your material says three supervisors. The gap is scale, and the bridge states it plainly: "I'm a senior shift manager over three supervisors." Answer slot: if you have led more people through a structure, say how many and how it was organized; if not, say so and say how you would ramp to twelve. |
| F4 | "5+ years operations leadership required" (JD) | "7 years in warehouse and distribution ops" (your message); "currently a senior shift manager over 3 supervisors" (your message) | medium | [grounded] | discovery | Your material shows seven years in operations and a current shift-manager role. It does not show how long you have led people. Answer slot: say how long you have led people, in your words, and when it began. If it is less than five years, say so plainly. |
| F5 | "build reporting in Excel/Power BI" (JD) | "solid Excel" (your message) | low | [grounded] | discovery | "Solid" names no report, so it does not show reporting. Answer slot: name one report you built in Excel, what it covered, and who used it; if you have not built one, say what you have built in Excel. |
| F6 | "build reporting in Excel/Power BI" (JD) | "never used Power BI" (your message) | none | [grounded] | capability | You stated the absence, so the pack gives it back: "I haven't used Power BI." Then how you would learn it, said as a plan: the first report you would build and the time it would take. Never as a past. |
| F7 | "Lean/Six Sigma a plus" (JD) | "green belt certified" (your message) | medium | [grounded] | none | The quote reaches the requirement in role terms. Caveat: no certificate has been inspected, so expect a probe on which body and what project. Say it as written: "green belt certified." Answer slot: name the body, and any project you applied it to; if there was none, say so. |

## Prohibited claims

Claims this pack will not coach, and why. Each one is a stretched form of something you said, or something you stated as absent.

| Not coached | Basis | Honest form |
|---|---|---|
| "I ran terminal operations across four sites" | Inflated form of F1 | "7 years in warehouse and distribution ops," and the site-level plan. Your material says one site ("the site's"). |
| "I lead twelve supervisors," or any scale beyond three | Inflated form of F3 | "currently a senior shift manager over 3 supervisors" |
| "I drove on-time performance and cost per shipment down" | Inflated form of F2 | "cut mis-pick rate 40% by redesigning the pick path" |
| "I owned the peak-season plan" | Stretches "ran" into "owned" | "ran the site's peak-season surge plan two years running" |
| "Five years of operations leadership" | Inflated form of F4. Leadership length is not in your material. | Seven years in operations, and the current role |
| Any Power BI experience, including a dashboard you built | You stated the absence (F6) | "I haven't used Power BI." No answer slot. |
| A Lean or Six Sigma credential beyond the green belt, or a named body you have not given me | Inflated form of F7 | "green belt certified" |

## Persona table

Round type and relationship are unknown, so these weights are blended. Expect the pack to be less sharp than one built around a known round. Values/behavioral is not weighted: no company values are in hand and no values round is detected, so there is no values section.

| Persona | How it shows up here | Weight | Reasoning | Counter-strategy |
|---|---|---|---|---|
| Data-Driven Prober | Asks how the 40% was counted; asks for on-time and cost measures | 5 (B1 to B5) | The one number on your side is the easiest to test, and the JD's two metrics are the ones a prober checks first | Know what you can say about the figure, and say plainly when you do not know how it was counted. Name its weakest assumption before they do. |
| Skeptic | Probes the three gaps: scale (F3), leadership years (F4), Power BI (F6) | 4 (A1 to A4) | Your material has three visible gaps against the JD, and a skeptic reads gaps first. A1 is the most predictable objection, so it gets the deepest rehearsal. | Rehearse the scale question until it is plain. Bridge only from what you stated, and where you stated nothing, say the limit. |
| Case/Strategist | Live problems: an on-time drop, a multi-site reporting definition, a weekly report due Monday | 3 (C1 to C3) | These are the role's daily work, and they test structure more than facts | Clarify, then segment, then name the metric that proves a fix. Think aloud. |
| Pressure | Attacks the scale gap and the Power BI gap, and asks whose the 40% was | 3 (D1 to D3) | Composure under the two gaps the JD makes most visible | Pause, restate, anchor in what you said. Hold through two follow-ups, then concede one specific thing. |
| Conversational | Biography opener; Excel and next-learning questions | 2 (E1, E2) | Casual questions are still scored | Use a 90-second arc built from your quoted lines. |
| Peer Evaluator | Seams across four sites; credit sharing | 2 (F1, F2) | A peer round is possible. Weight kept low until the round is known. | Propose principles for seams and credit rather than claiming a history you do not have. |

## Question banks

Provenance comes first on each row: the sentences the guidance rests on, quoted exactly from the fit snapshot. Types are tagged in the Type column.

### A. Skeptic (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You are a senior shift manager over three supervisors. This role leads twelve across four sites. What makes you the one to close that gap?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" (your message); [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Open with the sentence: "I'm a senior shift manager over three supervisors." Then the one result you can name: "cut mis-pick rate 40% by redesigning the pick path." Answer slot: if you have directed people beyond one shift or one team, say how many and how it was organized; if not, say so and give a ramp you would propose for the first quarter. Hold through two follow-ups by returning to what you ran. Never add scale to it. | F3 is the largest gap and the JD's headline. This objection will arrive in some form, so it gets the deepest rehearsal. Highest-ROI prep in this pack. |
| A2 | "The role asks for five-plus years of operations leadership. How long have you been leading people, as opposed to working in operations?" | JD | [grounded] "7 years in warehouse and distribution ops" (your message); [grounded] "currently a senior shift manager over 3 supervisors" (your message) | Give the two numbers you can state: seven years in warehouse and distribution ops, and your current role. Answer slot: when you started leading people, in your words. If it is under five years, say so plainly and say what your leadership record covers. Do not round it up. | F4 is discovery: the material does not show leadership years. Interviewers check this number. |
| A3 | "Power BI is in the job. Have you used it?" | JD | [grounded] "never used Power BI" (your message); [grounded] "solid Excel" (your message) | Start with the plain sentence: "I haven't used Power BI." Then the Excel line, as written: "solid Excel." Then a plan, said as a plan: the first report you would rebuild and how you would learn the tool. Never describe Power BI work you have not done. | F6 is a capability gap you stated, so the plain acknowledgment is the honest answer. F5 is the Excel half. |
| A4 | "You're a senior shift manager. Why is this the next step, and not a step sideways?" | EXP | [grounded] "currently a senior shift manager over 3 supervisors" (your message) | Answer with the scope you have run and the scope you want next, in your own words. Make no claim about this company beyond what the posting says. Keep it under 90 seconds. | A motivation probe built from your current scope. It does not need a story about the new employer. |

### B. Data-Driven Prober (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Walk me through how the 40% mis-pick reduction was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Say what the figure measures, in your words, and the period it covers. Answer slot: how it was counted, the baseline if you know it, and who counted it. If you did not count it yourself, say so and say what you know of the method. Do not supply a baseline or a method the material does not carry. | The headline number on your side. Defend-the-number slot: the honest answer may be "I don't know how it was counted." |
| B2 | "Which assumption behind that 40% would you defend least?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Name the weakest assumption before they do, in your own words. If you do not know which one, say that plainly, and say what you would check first. | The weakest-assumption move converts a gotcha into a credibility point. |
| B3 | "Tell me how the pick path got redesigned, and which parts were yours to decide." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Answer slot: if you made the call on the design, say which part and why. If others decided the design, say that, and say what you did carry. Keep the redesign at the scope the sentence gives. | Your message does not say who redesigned the path. Expect a probe on exactly that. |
| B4 | "The role is measured on on-time performance and cost per shipment. Which of those have you tracked, and what did it show?" | JD | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Start from the pick accuracy measure you can state. Answer slot: if you tracked on-time or cost per shipment on any shift or site, say what it was and what it showed over the period. If you did not, say so and say how you would set up both in your first month. | F2. The JD's two measures are the scoring sheet, and a free miss if unanswered. |
| B5 | "Where have you used Lean or Six Sigma methods, and what did you do?" | JD | [grounded] "green belt certified" (your message) | Say "green belt certified" as written. Answer slot: if you applied the method to a real problem, name the problem and what you did in it. If the certification has not yet been used on a problem, say so, and name the method you would apply first to an operation like this one. | F7. A mid-list JD item that would otherwise go unrehearsed. |

### C. Case/Strategist (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "On-time performance has dropped at one of your sites this month. Walk me through how you'd diagnose it." | CASE | [generic] | Clarify first: what dropped, against what baseline, on which lanes or shifts. Then the segments, the three causes you would check first, and the metric that shows the fix. Think aloud, and challenge one premise respectfully, such as whether the metric is measured the same way at every site. | The JD's headline metric as a live problem. No claim about your past, so no quote is needed. |
| C2 | "Suppose two of your four sites measure on-time differently. How do you get one number leadership can trust?" | CASE | [generic] | Propose one definition, the owner of that definition, how you would check the two sites against it, and what you would do with the history. Say it as a plan. | Multi-site reporting, the JD's "4 sites" and its reporting line together. |
| C3 | "You need one weekly on-time and cost report across four sites by Monday. What do you build first, and in what tool?" | CASE | [generic] | Start with the definition and the data source, then the simplest report that answers the question, in Excel if that is the fastest route to Monday. Say what a Power BI version would add and when. Do not claim a tool you have not used. | Tests the Excel/Power BI requirement without asking about your past. |

### D. Pressure (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why should we hire a senior shift manager over three supervisors, for a role built on twelve?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" (your message); [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Pause, restate the question in your own words, then anchor in what you stated. Hold: the scale is new, and the result you can show is the 40% change. Concede one specific thing: you have not yet led twelve, and that is what you would learn in the role. Do not fold on the result, and do not promise the twelve. | Stress interviewer on the headline gap. Hold-then-concede. |
| D2 | "Two years running on a surge plan. Is that you, or the site?" | EXP | [grounded] "ran the site's peak-season surge plan two years running" (your message) | Hold what you stated: you ran it. Say what you set, in your words. Answer slot: which parts of the plan were yours to set and which were the site's. Concede the one thing you cannot show, specifically. | Pressure on attribution. The concession the interviewer listens for is a specific one. |
| D3 | "We'd be paying you to build our Power BI reporting, and you haven't used it. Why not hire someone who has?" | JD | [grounded] "never used Power BI" (your message); [grounded] "solid Excel" (your message) | Acknowledge it plainly: "I haven't used Power BI." Hold the Excel line as written. Concede the learning curve specifically, and name the first thing you would build. | F6, pressure on a stated absence. The plain acknowledgment needs no slot. |

### E. Conversational / Rapport (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through how you got into operations." | EXP | [grounded] "7 years in warehouse and distribution ops" (your message) | A 90-second arc from quoted lines: the seven years, the shift role you hold now, one result (the mis-pick change), and what you want next. Answer slot: how you came into operations, if you have a fuller account. Do not add a milestone. | Casual register, still scored. |
| E2 | "Where's your Excel at, and what's next on your list?" | JD | [grounded] "solid Excel" (your message); [grounded] "never used Power BI" (your message) | Name the Excel work you can name, in your words. Then: "I haven't used Power BI, and it's the next thing I'd learn." Never describe Power BI work. | The Power BI gap, asked casually. |

### F. Peer Evaluator (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Four sites will each want different things from you. Where do you expect the seams to be, and what happens when you disagree with a peer?" | JD | [generic] | Propose principles: one shared metric, a clear owner for each decision, and a rule for escalation. Do not pretend to know the seams. For a disagreement, tell only a story from your own record. If you have none, say so and give the principle. | "4 sites" is the JD's own line. Peer seam probe. |
| F2 | "How do you handle credit when work spans sites?" | VAL | [generic] | Name the principle first: credit goes to the people who did the work, and you say so in the room. Then a case from your record only if your material carries one. If not, say you would name the owner of each piece. | No published values are in hand, so this is a behavioral pattern, not a values question. |

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| Own daily terminal operations across 4 sites | A1, C2, F1 |
| Drive on-time performance and cost-per-shipment down | B4, C1 |
| Lead a team of 12 supervisors | A1, D1 |
| Build reporting in Excel/Power BI | A3, C3, D3, E2 |
| 5+ years operations leadership required | A2 |
| Lean/Six Sigma a plus | B5 |

The 40% figure is covered by B1 to B3 and D2 covers the surge plan. No JD requirement is left uncovered.

## Reverse questions

No interviewer profile exists, so none of these is tied to an interviewer's path. The upgrade menu says what a name would unlock.

1. "What would a strong first 90 days look like for whoever takes this role?" Why it lands: shows you are planning the scope, not the title.
2. "How is on-time performance defined across the four sites today: one definition, or four?" Why it lands: you are checking the number before anyone asks you to.
3. "What reporting do you use now, and is Power BI already part of it?" Why it lands: tests the gap directly, and the answer tells you the real workload.
4. "What is the operational problem the last person in this role didn't get to solve?" Why it lands: you are thinking about the job, not the title.
5. "Who would I work most closely with across the four sites?" Why it lands: shows you think in terms of the whole network.
6. Use if the round is with a peer: "What could someone on your side do in their first month that would genuinely help your team?" Why it lands: reciprocity, which a peer weighs heavily.

## Prohibited list in action

Every answer slot above is written to the honest branch. If an answer would need one of the claims in the prohibited list, the slot's second branch applies.

## Sources

Provided documents: the JD text and your background, both from your message. No dossier was provided.

Research tier: L0. No searches or fetches were run this session.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Atlas Freight values` | unavailable | Values cheat sheet, only if the round turns out to be values-style. Research not run this session. |
| 2. `Atlas Freight interview process operations manager` | unavailable | Loop structure and persona weights. Would have tuned the blended weights above. |
| 3. `Atlas Freight strategy` / recent news | unavailable | Grounding brief, and a CO question. |
| 4. `{interviewer name} Atlas Freight` | n/a | No interviewer name was given, so there is no query to form. |
| 5. Representative `Operations Manager` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions. |

## Upgrade menu

- The round type and who you are meeting (asked in the message): a reweighted persona table and a tailored reverse question
- The interviewer's name: an interviewer read, persona weights from their public footprint, and a reverse question on their path
- The recruiter's process email: the loop structure, and whether any deliverable such as a case or presentation is coming
- Your answers to A1, A2, B1 or D2, given here and not in a drill: they become quoted evidence, and the fit rows that draw on them regenerate
- Your CV: the `[grounded]` rows move from your message onto the document, which also tests whether the three-supervisor and seven-year lines are the whole picture
- The four site locations and the shift pattern: whether any gate applies to this role, which the material does not show
- How many days you have before the interview: a prioritized prep schedule
- Deep research at L1 (up to 6 searches, 2 page fetches): Atlas Freight's published values, its interview process, and current strategy, which would add CO questions
- A `tuesday-dossier.md` from job-underwriter: verified evidence and the objection worth rehearsing most, in place of the one inferred here
