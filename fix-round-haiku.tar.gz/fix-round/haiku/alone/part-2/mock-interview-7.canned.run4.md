Your prep pack is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-alone-part-2-rooms-case-7-canned-f65444d8/b42f217e-09f3-4176-9d63-4ef2e6575b32/scratchpad/saltmarsh_live-operations-producer_interview_pack.md`. I built it on the assumption that Tobias runs the Outage Hour as the hiring manager. The company's interviewing page says each loop ends in a 60-minute session with the hiring manager, so the session is a live-incident tabletop followed by a values conversation.

The biggest prep item is the two-titles question (B1). The JD's first requirement is running the calendar for two titles, and your material shows one. The pack gives you a hold-then-concede structure for it, with an honest branch if you have never planned across two titles.

Two things I could not verify: the GDC talk listing about Tobias and the Project Larkspur news item both came from search results, not full pages. Check both before you mention them to him.

Say the word and I'll play the Skeptic on B1, the question the pack names as its highest-ROI prep. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

Is Tobias the hiring manager who runs the Outage Hour? The answer confirms the persona weights and the reverse questions.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh_live-operations-producer_interview_pack.md -----
# Interview prep: Live Operations Producer, Saltmarsh Games

**Interviewer:** Tobias Wrenfield, Head of Live Operations. Assumed to be the hiring manager running the Outage Hour (see Reading the interviewer).
**Format:** One 60-minute session: a live-incident tabletop, then a values conversation (company interviewing page).

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored.
- Type key: **VAL** behavioral/values, **EXP** your experience in depth, **JD** the job's own requirements, **CO** company and strategy, **CASE** a live problem.
- Guidance is scaffolding, not a script. Where a line says "answer slot," the real answer has to come from your experience. If you did not do the thing, say so plainly. That is a strong answer here, not a weak one.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | transferability | Your material shows one title's calendar, not two. Say it in those words: "For two years I ran the weekly content-drop calendar for our main title." Answer slot: if you ever planned or scheduled work across two titles, say how; if you have not, say so and describe how you would carry one calendar's method to two. |
| F2 | "coordinate design, art, engineering and community teams on each update" (JD) | "Wrote the release checklist our QA team still uses." (your message) | low | [inferred] | discovery | Your material shows coordination with QA only. It does not show design, art, engineering or community. Answer slot: if you coordinated any of those four directly on an update, say which and how; if you worked through QA alone, say so and describe that handoff. |
| F3 | "own the post-event review and the KPIs it reports" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | medium | [grounded] | transferability | Reporting monthly KPIs is adjacent. It is not a post-event review. Say the reporting at its own scope: "I presented the monthly retention numbers to the studio head." Answer slot: if you wrote a review after a specific event, say what it covered; if not, say so. |
| F4 | "manage the release checklist with QA" (JD) | "Wrote the release checklist our QA team still uses." (your message) | medium | [grounded] | none | The quote reaches the requirement, though "wrote" is not "manage." Lead with the quote in its own words. Expect a probe on how you kept it current with QA. |
| F5 | "3+ years producing live-service games or apps" (JD) | "4 years as an associate producer at a puzzle-game studio" (your message) | medium | [grounded] | presentation | The years are there. "Live-service" is not named in your material; the content-drop calendar suggests it but does not say it. Say the years and the studio type in those words. Do not call the title live-service unless you would say so under questioning. |
| F6 | "experience running a content calendar" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | none | Direct match. Confidence is medium because no calendar has been shown. If you can show one, the band rises. |
| F7 | "comfortable with player-retention metrics" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | medium | [grounded] | none | Direct match on presentation. It does not show who calculated the numbers. Expect a probe on how they were counted. |
| F8 | "clear written communication" (JD) | "Wrote the release checklist our QA team still uses." (your message) | medium | [grounded] | presentation | A written artifact that others rely on. Say it as a document you wrote and a team that uses it. |
| F9 | Company's outage-round format (interviewing page) | none given | none | [grounded] | discovery | No quote covers live-incident response. The round tests it directly. Answer slot: if you have handled a live incident, been on call, or run a post-incident review, say what happened and what you did; if not, say so plainly and walk through how you would reason. |

Requirements are quoted from the JD you supplied. F9 is quoted from the company's interviewing page, not from the JD.

## Prohibited claims

Each entry has a basis. A claim on this list is not coached in any answer, hold, bridge or drill feedback.

| Not coached | Basis | Honest form |
|---|---|---|
| "I have run live-events calendars for two titles." | Inflated form of F1: your material says one title. | "I ran the weekly content-drop calendar for our main title for the last two years." The limit is the pack's own observation: the material shows one title, not two. |
| "I have led or managed a team." | Negative you stated ("Never led a team"). | "I haven't led a team." No answer slot. |
| "I have worked on in-app purchase monetization." | Negative you stated ("never worked on a game with in-app purchases"). | "I haven't worked on a game with in-app purchases." No answer slot. |
| "I owned the post-event review." | Inflated form of F3: your material says monthly retention reporting. | "I presented the monthly retention numbers to the studio head." |
| "I managed the release checklist with QA." | Inflated form of F4: your material says you wrote it. | "Wrote the release checklist our QA team still uses." |

## Reading the interviewer

**Public footprint only.**

- **Role:** Head of Live Operations (from your note).
- **Talk:** "Patch Notes Are a Promise," GDC 2026. From one search result, not a fetched page. Check the listing before citing it to him.
- **Background (same listing):** previously a QA lead at a console studio.
- **His stated argument:** a live team is judged by how often its patch notes describe what actually shipped.

**Implications for this session:**

1. Expect the release checklist to come up. His background is QA, and his argument is about accuracy between announcement and build.
2. Expect "what shipped vs what you said." Answer with the checklist's role in that, in your own words.
3. Accuracy will likely weigh more than volume. Do not oversell the calendar's size.
4. Shared professional ground: QA-adjacent work. This is a shared domain, not a shared career jump, and it is not a reason to build rapport on anything else.

**Shared professional path (allowed):** the checklist. "Wrote the release checklist our QA team still uses." (F4)

## Persona table

| Persona | How it shows up | Likelihood and weight | Reasoning | Counter-strategy |
|---|---|---|---|---|
| Case / Strategist | The Outage Hour's live-incident tabletop | High, weight 5 (depth 5) | The company page defines the first half as a live-incident tabletop run by the hiring manager | Clarify scope and affected players first; decide what to pause; name who you pull in; say what you would record for the review |
| Skeptic | Probes the two-titles gap, IAP, and leadership | High, weight 4 | Hiring-manager prior, plus three gaps in your own material (F1, F2, the stated negatives) | Rehearse the most predictable objection (B1) until it is calm; hold, then concede exactly what is true |
| Values / Behavioral | The values conversation after the tabletop | High, weight 4 (depth 4) | The company page says the session ends with a values conversation; three published values | Map a story to a value only where a quoted sentence carries one; otherwise use the selection scaffold and its honest branch |
| Data-Driven Prober | Asks how the retention number was counted; asks for the KPI definition | Medium, weight 3 | Retention is a JD requirement, and his QA background suggests precision | Name the assumption behind a figure you would defend least, or say you do not know how it was counted |
| Pressure / Stress | Time-boxed answers, "how much of that was you" | Low, weight 2 | No signal of a stress style in public material | Pause, restate, hold through two follow-ups |
| Conversational / Rapport | Opener and close | Low, weight 2 | Standard opener and closing slot | Prepare a 90-second arc; never treat the closing slot as small talk |

Total questions: 20, within the 18–26 range.

## Question banks

### A. Case / Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A live event is 40 minutes in and the reward grant is failing for part of the player base. Walk me through your first moves." | CASE | [generic] | Clarify: which players, how many, what the event promised. Name who you pull in (engineering, QA, community). Decide whether to pause the event or the announcement. Draft what the community hears. Note what goes into the review. | The tabletop format the company page names. [generic] because the scenario is a role-family pattern, not a fact about this studio. |
| A2 | "Which of your release checklist steps would have caught a failure like this before players did, and which would not?" | CASE | [grounded] "Wrote the release checklist our QA team still uses." | Name the steps you can recall from the checklist as you wrote it. For each gap, say what you would add. Answer slot: if you have changed the checklist after a release went wrong, say what changed; if not, say so plainly and say what you would add first. | F4 is the strongest asset here. Premised only on the sentence's scope. |
| A3 | "Retention dips the morning after a patch. What do you check first?" | CASE | [generic] | Test whether the dip is real: a cohort or measurement artifact, or the patch. Compare with the same window in prior events. Check what shipped against what was announced. Then the funnel. | Tests the retention requirement (F7) through a live problem. No claim about your past. |
| A4 | "Saltmarsh has announced one shared events calendar from February 2027. What would you need to know about it first?" | CO | [grounded] "one shared events calendar from February 2027" (saltmarshgames.com/news/project-larkspur, search result) | Ask which decisions move to the shared calendar owner and which stay with each title. Ask how the event cadence and season-pass model interact. Do not assume what the company will do. | The company's current strategy is the differentiator. Sourced from the company's own news item. |
| A5 | "How would you plan the calendar so two titles do not land their events on the same day?" | JD | [generic] | Name the constraint you would plan around: shared players, shared teams, shared release windows. Propose a lock-and-release rule for the calendar. Answer slot: if you have planned around two calendars, say how; if not, say so and describe the rule you would start with. | Covers R1 and R6 at the scale the JD names. The premise is the JD's. |

### B. Skeptic (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Your experience is one title's content calendar. This role plans two. What is your evidence that you can run two?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | **Highest-ROI prep in this pack.** Hold: "For two years I ran the weekly content-drop calendar for our main title." Hold through two follow-ups by returning to the calendar. Concede: "I haven't planned two titles at once." Answer slot: if you ever scheduled work across two products, say how; if not, say so and describe your first 30 days. | F1 is the headline requirement, and the JD's first clause puts it in front of the interviewer. Named the most likely objection because the material is thinnest here. |
| B2 | "You have never worked on a game with in-app purchases. How would you plan events for a title whose revenue depends on them?" | JD | [inferred] "never worked on a game with in-app purchases" | Acknowledge: "I haven't worked on a game with in-app purchases." Then say how you would learn it, as a plan: what you would look at first, which numbers, who you would ask. Do not describe monetization work you did not do. Answer slot on the live-service requirement (F5): if you can say whether the puzzle title ran as live-service, say so and how; if not, say what you would confirm. | The JD does not name IAP. You named it as a gap, so this is the pack's inference about where a skeptic would press. The acknowledgment has its source in your message. |
| B3 | "The JD asks you to coordinate design, art, engineering and community teams on each update. Which of those have you coordinated, and how?" | JD | [grounded] "Wrote the release checklist our QA team still uses." | Name the team, the handoff, and the step that got stuck. Answer slot: if you coordinated any of the four directly, say which and how; if you only worked through QA, say so plainly and describe the QA handoff. | F2 is discovery, not a gap you can bridge with adjectives. |
| B4 | "You have never led a team. Why would you be right to coordinate four of them?" | JD | [grounded] "Never led a team" | Acknowledge: "I haven't led a team." Then describe what you have done: you wrote the checklist and you ran the calendar. Describe coordination with QA using your own words, nothing more. | Stated negative, so the plain acknowledgment has its source. |

### C. Values / Behavioral (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time something you announced to players did not match what shipped." | VAL | [grounded] "Wrote the release checklist our QA team still uses." | Open prompt. Raising source: the company's value "Ship the Patch Not the Promise: we announce what is built, not what is hoped." If you have such a time, tell it in your words. If not, say so plainly, then name the checklist step you would add so release notes match the build. | Maps to a published value and to his talk's theme. Scaffold ends in the honest branch. |
| C2 | "Tell me about a time the calendar and the players disagreed. What did you do?" | VAL | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Open prompt. Raising source: "Players Before Plans: when the calendar and the players disagree, the players win." Pick a real conflict between a planned drop and what players were asking for: the stake, what you decided, what happened. If none comes to mind, say so plainly and give the nearest thing your material carries: the calendar, and how you would decide next time. | No sentence in your material carries this story. The scaffold is the honest form. |
| C3 | "Tell me about something you changed in a process that stuck." | VAL | [grounded] "Wrote the release checklist our QA team still uses." | Raising source: "Leave the Build Greener: every release leaves the codebase and the checklist better than it found them." Story-map the sentence: you wrote the checklist, and QA still uses it. Answer slot: if you revised it after a release, say what changed and why; if not, say so and say what you would add next. | The quote carries "still uses." The revision beat is not in your material, so it is a slot. |
| C4 | "A leader asks you to push a drop before QA has signed off. What do you say?" | VAL | [generic] | Clarify the risk and who carries it. Name what QA cannot sign off and what you would need to. Offer options: ship a smaller change, delay, or announce less. Name the value you are protecting. | A scenario from the role. Makes no claim about your past. |

### D. Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how the monthly retention numbers you presented were counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Answer slot: if you know how they were counted (the cohort, the window), say so in your words. If the counting was not yours, say so plainly and say who owned the definition and what you did own: the presentation. Name the assumption you would defend least. | F7's probe. No figure was given, so the defend-the-number slots are not raised yet. |
| D2 | "Which KPI would you own in the post-event review on day one, and what would move it?" | JD | [grounded] "Presented the monthly retention numbers to the studio head." | Name one KPI you have reported. Describe what would move it. Answer slot: if you have written a post-event review, say what it covered; if not, say so and describe the first review you would write. | F3 is the adjacent evidence; the review itself is not in your material. |
| D3 | "You reported monthly. How would you report on one event within a day of it ending?" | JD | [grounded] "Presented the monthly retention numbers to the studio head." | Name what changes between monthly and per-event: the cohort, the window, what you can know in a day. Name the assumption you would defend least. Describe the written summary you would send. | Covers R3 and R8. The summary is the written-communication evidence. |

### E. Pressure / Stress (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why should we hire you over someone who has led a team?" | JD | [grounded] "Never led a team" | Hold: "The work you are hiring for is the calendar and the checklist, and I have done both." Concede: "I haven't led a team. I would expect to learn the people side fast." Hold through two follow-ups. | The stated negative gets a plain acknowledgment. The hold is the work your material carries, not more. |
| E2 | "That checklist: how much of its success was actually you?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Hold: you wrote it, and QA still uses it. Concede what you cannot show: if you have figures on what it caught, say them; if not, say you do not have them. | A stress version of F4. The concession is the honest answer. |

### G. Conversational / Rapport (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey to here." | JD | [grounded] "4 years as an associate producer at a puzzle-game studio" and "I ran the weekly content-drop calendar for our main title for the last two years." | 90-second arc: the studio and role, the calendar, the checklist, the retention reporting, and why this role. Answer slot: why you are looking now, in your own words. | Opener. Scored as well as casual. |
| G2 | "What are you playing right now, and what would you change about one of its events?" | CO | [generic] | Name a title you actually play. Describe one event change, the reason, and whether it would sit on your calendar. Say what you would measure. | A casual route into the company's product space. No claim about your past. |

## Requirement coverage

| JD requirement | Questions |
|---|---|
| R1 "Plan and run the live-events calendar for two of our mobile titles" | A5, B1 |
| R2 "coordinate design, art, engineering and community teams on each update" | B3, A1 |
| R3 "own the post-event review and the KPIs it reports" | D2, D3 |
| R4 "manage the release checklist with QA" | A2, E2, C3 |
| R5 "3+ years producing live-service games or apps" | G1, B2 (answer slot) |
| R6 "experience running a content calendar" | B1, A5 |
| R7 "comfortable with player-retention metrics" | A3, D1 |
| R8 "clear written communication" | D3, C3 |

## Reverse questions

1. "How does a live-incident review at Saltmarsh feed back into the release checklist?" **Why it lands:** connects to Leave the Build Greener and to the QA thread.
2. "With one shared calendar from February, which decisions does the calendar owner make that the title teams used to make?" **Why it lands:** shows you read the news item (A4).
3. "Tobias, in your talk you argued patch notes are a promise. How do you check a release against its notes before it ships?" **Why it lands:** ties to his own path and argument, which is the strongest reverse question in this pack.
4. "Which KPIs does the studio head expect from live operations, and how often?" **Why it lands:** signals you want to be measured on what matters to the studio.
5. "What would a strong first ninety days look like for this role?" **Why it lands:** a standard question that signals you are planning to deliver.
6. "What does a good live event look like on this team, and what does a bad one look like?" **Why it lands:** asks for the team's own definitions, which you can use later.

## Values cheat sheet

The company's published values come from its values page (fetched). The values round is detected because the company's interviewing page says the session ends with a values conversation.

| Value | Working meaning | Mapped story |
|---|---|---|
| Players Before Plans | When the calendar and players disagree, players win. | No quoted sentence carries a story. Selection scaffold in C2, honest branch included. |
| Ship the Patch Not the Promise | Announce what is built, not what is hoped. | "Wrote the release checklist our QA team still uses." Selection scaffold in C1, honest branch included. |
| Leave the Build Greener | Every release leaves the codebase and the checklist better than it found them. | "Wrote the release checklist our QA team still uses." Revision beat is a slot in C3. |

## Sources

**Provided documents:** the job description and your background, as you wrote them.

**Research tier:** L1, searches 4 of 6, fetches 2 of 2.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | yes | Values cheat sheet: three values by name. Fetched saltmarshgames.com/values. |
| 2. Saltmarsh Games interview process, live operations producer | yes | Loop: recruiter call, then the Outage Hour, a single 60-minute interview with the hiring manager. A live-incident tabletop, then a values conversation. No take-home. Fetched saltmarshgames.com/careers/interviewing. |
| 3. Saltmarsh Games strategy / recent news | yes | CO question A4, from a search result for the Project Larkspur news item (September 2026). Not fetched. |
| 4. Tobias Wrenfield, Saltmarsh Games | yes | Interviewer read: GDC 2026 talk listing from a search result, not fetched. Verify before citing. |
| 5. Representative live operations producer JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions. |

**Searches sent:** "Saltmarsh Games values", "Saltmarsh Games interview process live operations producer", "Tobias Wrenfield Saltmarsh Games", "Saltmarsh Games mobile studio news strategy". Each returned results.

**Fetches sent:** saltmarshgames.com/values, saltmarshgames.com/careers/interviewing. Both returned text.

**No dossier was present.**

## Upgrade menu

- **A real post-event review, or a KPI you reported per event** → D2 and D3 slots become quoted, and F3 moves toward a presentation gap.
- **A figure from the retention reports, even rough** → D1 defend-the-number slots become live, and F7 gains a specific claim.
- **Any live incident you handled, were on call for, or reviewed** → F9 and A1 get a real story, and C1 gets a quote.
- **Whether you coordinated design, art, engineering or community directly** → B3 becomes a story, not a slot. F2 moves up.
- **The release checklist itself, anonymised** → A2 becomes map-to-steps, not a scaffold.
- **Confirmation that Tobias is the hiring manager for the Outage Hour** → the reverse questions and persona weights are confirmed; without it, the weights are assumed.
- **Confirmation that Tidepool Tactics and Lantern Row are the two titles in the JD** → A4 and A5 get concrete titles. The news item names them, but the link to your JD is an assumption.
- **Deep research, L2 (strategy brief, Tobias's talk and writing, recent org context)** → up to 6 more searches and 2 more fetches, several more minutes. Want it?

