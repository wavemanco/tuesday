Your prep pack is saved as /tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-alone-part-2-rooms-case-1-denied-7df39292/f55be337-f026-4df7-b05e-e6b123fa8817/scratchpad/northwind-data_senior-gtm-strategy-lead_interview_pack.md. I built it for a peer round, since you said Dan is a peer on the same VP.

Research ran at L1 but all four web searches were refused by the permission setting, so the pack rests on your notes and carries no checked source. Granting web search and asking me to rerun is one step, and it would confirm Northwind's values, the loop, the strategy framing and Dan's public footprint.

The pack's highest-ROI prep is D1: the "no quota or sales-ops work" objection, which sits in Dan's own domain. Say the word and I'll play the Skeptic on D1 with follow-ups.

I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.

If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: northwind-data_senior-gtm-strategy-lead_interview_pack.md -----
# Interview pack: Senior GTM Strategy Lead, Emerging Products, Northwind Data

**Candidate:** Priya. **Interviewer:** Dan Kovac, Director of Sales Strategy (peer, same VP). **Round:** one 60-minute conversation. **Built from:** your message (candidate background, JD highlights, interviewer profile, research note). **Research:** L1 attempted; all four searches were refused, so nothing below is checked against a published source (see Sources).

## How to use this pack

Personas describe how a question arrives. Types describe what is being scored.

| Type | Name | What it scores |
|---|---|---|
| EXP | Experience deep-dive | Whether what Priya did survives scrutiny, and where her attribution stops |
| JD | Role / JD-driven | Whether she can do the listed job, gaps included |
| CASE | Live problem | Structure and reasoning on a problem from this role |
| CO | Company and strategy | Whether she thinks at Northwind's altitude, using the priorities named in your note |

No VAL (values) type appears: no values-style round was detected, and no values page was checked.

Guidance is scaffolding, not a script. An answer slot is an instruction for the interview, not a question to you. Quoted sentences are Priya's own words as they appear in your message; "coach's notes" marks them.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" (JD highlights, your message) | "9 at a large consumer-tech company in product strategy & ops" (coach's notes) | medium | [grounded] | transferability | The material says product strategy and ops, not go-to-market for a product line. Say the product-strategy work in those words. Answer slot: if she owned any go-to-market decision for a line, say which and how she decided; if she did not, say so and say what she would do first. |
| F2 | "identify whitespace across land/adopt/expand/renew" (JD highlights, your message) | "built a partner-level revenue model used in carrier negotiations" (coach's notes) | low | [inferred] | transferability | Revenue modelling for partners is not a whitespace map across the four motions, and the bridge stops there. Answer slot: if she sized an unserved segment in any of the four motions, say which motion and how she sized it; if she has not, say so and say how she would start. |
| F3 | "run independent analysis in SQL and Tableau" (JD highlights, your message) | "skilled in SQL/Tableau" (coach's notes) | low | [inferred] | discovery | The quote names the tools, not whether she ran analysis independently. Answer slot: if she ran an analysis end to end herself, say what question it answered and what changed; if her part was one piece of someone else's analysis, say which piece; if she has not run one, say so and walk through the nearest she has done. |
| F4 | "partner-motion design experience required" (JD highlights, your message) | "built a partner-level revenue model used in carrier negotiations" (coach's notes) | medium | [grounded] | transferability | Partner-facing revenue work is adjacent to partner-motion design, and the material does not show a motion designed. Say the model's use in her words. Answer slot: if she designed any part of how a partner was paid or incentivised, say which part; if the model was an input to someone else's motion, say that plainly. |
| F5 | "strong cross-functional influence" (JD highlights, your message) | "set annual volume targets with cross-org consensus" (coach's notes) | medium | [grounded] | none | The quote reaches the requirement in role terms. Words: "I set annual volume targets with cross-org consensus." Expect a probe on her share of the consensus; keep "set" and "consensus" as the sentence states them. |
| F6 | "AI experience a plus" (JD highlights, your message) | "uses AI tools daily" (coach's notes) | low | [inferred] | transferability | Daily use of AI tools is adjacent to AI experience and is not AI product work. Words: "I use AI tools daily." State the limit; add nothing. |
| F7 | Headline metric; no JD line (your message) | "proposed a store-surface change credited with a ~$400M ARR uplift" (coach's notes) | medium | [grounded] | discovery | The material does not show how the uplift was counted or how much was hers. Words: "I proposed a store-surface change credited with a ~$400M ARR uplift." Do not restate the credit as hers alone. A1 asks the defend-the-number questions in her words. |
| F8 | Quota-setting and sales ops; not a JD highlight (coach's notes) | "No classic sales-ops or quota-setting experience." (coach's notes) | none | [grounded] | capability | A stated absence, so no answer slot. Words: "I haven't set quota or run sales ops." Then her closure plan, said as a plan and never as a past. Never describe a quota she did not set. |

Pack observations (analysis, not words for Priya): the material says the volume targets were set with cross-org consensus. It does not say whether they were quotas, or how they were tested. No gate row appears: the highlights name no authorisation, location or credential term. The full JD may add one (upgrade menu).

Confidence grades the sentences above, which are your account of Priya's CV, not the CV itself. Provenance grades what this pack wrote.

## Prohibited claims

Not coached in any guidance, slot, hold, reverse question or rationale.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned GTM for a product line | Inflated form of F1 | "9 at a large consumer-tech company in product strategy & ops." The limit is the pack's observation: the material says product strategy and ops, not GTM. |
| Designed a partner motion | Inflated form of F4 | "built a partner-level revenue model used in carrier negotiations." The material shows a model, not a motion. |
| Ran independent SQL or Tableau analysis | Inflated form of F3 | "skilled in SQL/Tableau." A3's slot asks what she ran. |
| Drove or led the ~$400M uplift | Inflated form of F7 | "proposed a store-surface change credited with a ~$400M ARR uplift." No word for sole credit. |
| Built or shipped AI products | Inflated form of F6 | "uses AI tools daily." |
| Set quotas or ran sales ops | Negative Priya stated (F8), plain acknowledgment | "I haven't set quota or run sales ops." No slot. |

## Reading the interviewer

**Career pattern (from your profile note):** pricing and monetization roles, with one early-stage startup chapter. **Self-described:** "relentlessly data-driven." Public footprint beyond your note was not checked, because the search was refused.

**Practical implications:**
1. Expect every number to be probed to its assumptions. A1, A2, A4 and E2 rehearse that.
2. Pricing and unit economics are his native language, so C1 and C2 are tilted there.
3. The early-stage chapter means builder stories land, and a scrappiness probe is likely. B3 and F1 cover it.
4. He is a peer, so reciprocity counts. Reverse question R5 carries it.

**Mirror opportunities:** no shared professional jump is offered. Priya's side of his early-stage move is not in any fit row, so per the rule the jump is not used. Shared vocabulary such as "denominator" and "assumption" can be used in analysis, not as Priya's own claims.

## Persona table

Relationship prior for a peer: Peer Evaluator plus Data-Driven Prober. The loop is set by your own words (one conversation with Dan), so no archetype fallback applies. Weights total 18 questions.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy | Qs |
|---|---|---|---|---|
| Data-Driven Prober | Denominators, assumptions, "how was that counted" | High, weight 4. His self-description and monetization spine both point here. | Know what Priya can and cannot say about each figure, name the weakest assumption first, and say plainly when she does not know. | A1–A4 |
| Peer Evaluator | Seams with pricing and sales, disagreement, credit | High, weight 4. A peer's prior: he is pricing what the hire adds to his work. | Propose seam principles rather than pretending to know his team; reciprocity framing. | B1–B4 |
| Case / Strategist | Pricing-tilted GTM cases; company priorities | Medium, weight 3. Pricing is his native register; one 60-minute session limits length. | Clarify, then objective, segmentation across the four motions, approach, metrics, risks. | C1–C3 |
| Skeptic | Quota and partner-motion gaps | Medium-high on the quota gap, weight 3. Priya stated the gap, and it sits in his own domain. | Plain acknowledgment, then the sentence she can defend, then a ramp plan as a plan. | D1–D3 |
| Pressure / Stress | "Why you over someone who ran sales ops" | Low-medium, weight 2. Peer tone makes it less likely, so it is kept to two questions. | Pause, restate, hold the quoted position through two follow-ups, concede specifically. | E1–E2 |
| Conversational | Opening arc; casual AI question | Medium, weight 2. Opening minutes are scored even when casual. | A 90-second arc, pre-scripted; treat AI as scored. | F1–F2 |

Values / Behavioral: weight 0. No values-style round is detected, and no values page was checked.

## Question banks

### Persona A: Data-Driven Prober (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how that ~$400M ARR uplift was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Say what the figure counts, in her words and from what she knows. Name the assumption she would defend least before he does. Say which part was hers: the proposal, or the uplift as credited. Answer slots: if she knows how it was counted, say how; if she does not, say plainly that she does not know the counting method. | F7 is the headline metric, and the coverage rule requires a defend-the-number question. Prober's highest-weight question. |
| A2 | "How did you set the volume targets, and which number in them would you defend least?" | EXP | [grounded] "set annual volume targets with cross-org consensus" | Describe the targets' basis and the consensus process in the sentence's own words. Name the weakest assumption. Answer slot: if she built the arithmetic, say which part; if the arithmetic came from others and she agreed it, say that plainly. Say "targets," never "quotas." | F5 and F8 meet here: the question is where the sales-ops gap is probed, so it stays on what the quote carries. |
| A3 | "Tell me about an analysis you ran yourself in SQL or Tableau that changed a decision." | JD | [grounded] "skilled in SQL/Tableau" | Story selection: pick an analysis she ran, then the decision it informed, the data, and what she changed. Answer slot: if no analysis was hers end to end, say so plainly and walk through the nearest one and her part in it. The quote supports the skill, not an independent analysis. | F3 is discovery. "Run independent analysis" is a named JD requirement, so the probe is likely. |
| A4 | "Walk me through the partner-level revenue model you built for the carrier negotiations. Which input would you defend least?" | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" | Describe the model's purpose and inputs as she knows them. Name the input she would defend least. Say which side of the table it was used on, in her words. Answer slot: if she knows what the negotiation did with the model's outputs, say what happened; if she does not, say so. | F4 has only this partner-side evidence. The prober tests whether it was a model or a motion. |

### Persona B: Peer Evaluator (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our teams sit side by side on pricing and sales. Where's the seam between your GTM work and mine?" | JD | [generic] | Propose seam principles, not facts about his team: who sets price, who owns the target, who owns partner terms. Name one principle she would propose and one thing she would need from him. Do not pretend to know his team's seam. | Peer prior. The seam is the peer probe. Labelled generic because it is a role-family pattern. Covers the cross-functional requirement. |
| B2 | "When two orgs disagree on a volume target, how do you settle it?" | EXP | [grounded] "set annual volume targets with cross-org consensus" | Describe how targets were agreed across orgs, in the sentence's words. If a real disagreement happened, say what it was and how it closed. Answer slot: if no disagreement was contested, say so and describe the agreement process instead. | F5. Peers probe how disagreement was settled. The question names no artifact of hers. |
| B3 | "How do you handle credit when work spans teams?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Name, by role, who else had a part, in her words. Say what she proposed. Do not claim the split. Answer slot: if she can say who else had a part, name them by role; if the split is not one she can state, say that. | F7 credit, from the peer side. Matches the scrappiness probe from his startup chapter. |
| B4 | "Partner motions and pricing usually collide somewhere. Where would they collide in this role, and what would you need from pricing?" | JD | [generic] | Propose collision points as principles: partner margin against list price, and partner terms against expansion deals. Say what she would need from pricing. | Partner-motion design is required, and this question tests it as a peer conversation. Generic: a role-family pattern with no claim about her past. |

### Persona C: Case / Strategist (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Two new product lines, one sales team, and a partner channel that wants a cut. Sketch the GTM plan. What do you need to know first?" | CASE | [generic] | Clarify, then objective, then segmentation across land, adopt, expand and renew, then approach, metrics and risks. Think aloud and challenge one premise. This is a live problem: draw nothing from her past. | Covers the two-product-line GTM, partner-motion and whitespace requirements. CASE because it scores structure. |
| C2 | "A partner asks for a volume discount that breaks margin on expansion deals. How do you decide?" | CASE | [generic] | Pricing angle: unit economics, what the discount buys, the test she would run, and the risk of reversal. Name the decision rule before the answer. | Tilted to his pricing spine. Covers the whitespace requirement across the expand motion. |
| C3 | "Northwind's priorities, as I understand them, are enterprise expansion, the Compass copilot launch and profitability. Where does your plan sit against those, and what happens to it if a much larger platform vendor bundles a competing product?" | CO | [grounded] "enterprise expansion, an AI copilot launch ('Compass'), and reaching profitability"; "main competitive threat is bundling by a much larger platform vendor" (your research note, unverified) | Name the priority her plan serves first and what it gives up. Say what she would watch if a platform vendor bundles. Make no claim about Northwind's internal plans. | Both quotes come from your research note. No published strategy source was checked, so the phrasing keeps "as I understand them." One question. |

### Persona D: Skeptic (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "I don't see quota or sales-ops work in your background. How would you handle that in this role?" | JD | [grounded] "No classic sales-ops or quota-setting experience."; "set annual volume targets with cross-org consensus" | Plain acknowledgment first: "I haven't set quota or run sales ops." Then the bridge in the sentence's words: "I set annual volume targets with cross-org consensus." Say what the targets were and how they were agreed, then stop. Concede explicitly that quota mechanics are new to her. Then a ramp plan, said as a plan. Hold the targets sentence through three follow-ups, and return to it rather than widen to quota. | Highest-ROI prep in this pack. The gap is one Priya stated, it sits in his domain, and it is the most likely probe. Rehearse three follow-ups, not two, and the concession wording. |
| D2 | "Partner-motion design is required for this role. What is the closest you have come to designing one?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | Start from the model's sentence, in her words. Answer slot: if she designed any part of how a partner was paid or incentivised, say which part; if the model was an input to someone else's motion, say that plainly; if she did not design one, say so and say what she would do first. Concede openly. | F4 transferability. The question's premise is the JD's, so the second branch stays open. |
| D3 | "You spent nine years in consumer-tech product strategy. Why does a B2B data GTM job make sense now?" | EXP | [grounded] "9 at a large consumer-tech company in product strategy & ops" | Say what the product-strategy work taught her that transfers, in the sentence's terms. Name what she would need to learn. Do not claim B2B experience. | Motivation probe, which the Skeptic runs as "why now." Tied to F1's transferability limit. |

### Persona E: Pressure / Stress (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why should this line go to you over someone who has run sales ops?" | JD | [grounded] "No classic sales-ops or quota-setting experience."; "built a partner-level revenue model used in carrier negotiations"; "set annual volume targets with cross-org consensus" | Pause, then restate the question in her words. Anchor on the carrier model and the volume targets. Hold that position through two follow-ups. Concede the sales-ops gap explicitly: "I haven't run sales ops." Do not fold on the carrier model. | Pressure register: hold-then-concede. The held position is one the quotes carry. |
| E2 | "That $400M. How much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Hold: "I proposed it." Do not widen the claim. If a share is one she cannot state precisely, concede that. Answer slot: if she can name the part of the uplift that was hers, say which part; if the share is not one she can state, say that and say what she can defend. | F7. Composure under a direct attribution challenge. |

### Persona F: Conversational / Rapport (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm"; "9 at a large consumer-tech company in product strategy & ops" | A 90-second arc: consulting, then nine years in product strategy and ops, then what she wants from GTM. Use the sentences' words and nothing extra. | Casual register, still scored. Covers F1's transferability in the opening minutes. |
| F2 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" | Name the tools she uses daily and the tasks, in her words. Do not describe building or deploying anything. Answer slot: if she has pointed AI at a GTM question, say what she asked and what she got; if not, say so. | The JD's plus-skill, asked casually. Covers F6. |

### Requirement coverage

| JD requirement | Question IDs |
|---|---|
| own GTM strategy for two new product lines | C1, F1, D3 |
| identify whitespace across land/adopt/expand/renew | C1, C2 |
| run independent analysis in SQL and Tableau | A3 |
| partner-motion design experience required | D2, A4, B4, C1 |
| strong cross-functional influence | B1, B2 |
| AI experience a plus | F2 |
| Headline metric, no JD line | A1, B3, E2 |
| Quota-setting, from your note, not the JD | D1, E1 |

Every stated JD requirement has at least one question. None is uncovered.

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What did your early-stage chapter teach you about pricing that the larger monetization roles didn't?" | Ties to his own path. It moves the conversation from interrogation to peer talk and shows she read him, not only the company. |
| R2 | "Where do sales strategy and pricing disagree most often on a volume target, and how is it settled?" | Opens the seam directly and shows she cares about the disagreement question. |
| R3 | "Which of the three priorities is this team measured on first?" | Shows she knows the three priorities. It asks which one matters, which a peer can answer cheaply. |
| R4 | "What does your team trust least in the whitespace data today?" | Invites him to state his assumptions, which matches his self-description and the prober register. |
| R5 | "What could a new person do in their first month that would genuinely help your team?" | Reciprocity: a peer signal that she brings something to his team. |

## Sources

- **Provided documents:** your message only. Its contents are Priya's background (coach's notes), JD highlights, his profile description, and your research note. No CV text, full JD or profile page was supplied.
- **Searches sent, all refused** (permission not granted in this session):
  - "Northwind Data company values": refused. Target 1.
  - "Northwind Data interview process Senior GTM Strategy": refused. Target 2.
  - "Northwind Data Compass AI copilot enterprise expansion profitability": refused. Target 3.
  - "Dan Kovac Director of Sales Strategy Northwind Data": refused. Target 4.
- **Fetches:** none. No URLs were returned.

**Research tier: L1 — searches 4 of 6, fetches 0 of 2**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Northwind Data values` | unavailable | Values cheat sheet, section 10. Not included either way: no values-style round is detected, so the section's condition fails. |
| 2. `Northwind Data interview process` | unavailable | Loop structure. Your own words establish the loop (one conversation with Dan), so persona weights stand without an archetype fallback. |
| 3. `Northwind Data strategy` | unavailable | CO bank. C3 rests on your research note, not a checked source. |
| 4. `Dan Kovac Northwind Data` | unavailable | Interviewer read and reverse questions. The read here uses only your profile note. |
| 5. representative JD | skipped | The JD highlights you supplied fix the fit snapshot and the JD-tagged questions. |

## Upgrade menu

- **Web search permission, then a rerun at L1** → targets 1 to 4 read `yes` or stay honest. The values cheat sheet appears only if a values round is confirmed. C3 cites a checked strategy source. Dan's public talks and posts feed the interviewer read and reverse questions.
- **Full JD text** → the six JD quotes become full text, and any gate (location, work authorisation) becomes a `hard_gate` row.
- **Priya's CV text** → the evidence rows move from coach's notes to her CV, and the sentences can be checked word for word.
- **The ~$400M analysis or the carrier revenue model** (deck or workbook) → inspectable proof. F4 and F7 can rise to high, and the slots in A1, A4 and E2 can become grounded answers.
- **Recruiter's prep email** → confirms the loop and whether a values round exists. Any take-home becomes its own section.
- **Deep research (L2):** up to 6 more searches and 2 more fetches, several more minutes, for a strategy brief, role loop reports and recent org context. Want it?
