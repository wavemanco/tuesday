Your prep pack is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-alone-part-2-rooms-case-7-canned-324549df/33a0c12b-d8f5-46e7-aaa4-c450beadbfaa/scratchpad/saltmarsh_live_operations_producer_interview_pack.md`. I built it for the hiring-manager round the company's interviewing page describes, since that page names the hiring manager as running the 60-minute Outage Hour.

# Interview prep: Live Operations Producer, Saltmarsh Games

**Interviewer:** Tobias Wrenfield, Head of Live Operations. I've treated Tobias as the hiring manager, as the page implies.
**Round:** One 60-minute session: a live-incident tabletop, then a values conversation. No take-home.

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is scored.
- Type key: **CASE** live problem from the role. **JD** a stated requirement. **EXP** a question about your past work. **VAL** published values, tested through behavior.
- Guidance is scaffolding, not a script. Say it in your own words, and give answer slots in the form they take.

## The fit snapshot

Requirements are quoted from the JD you pasted. Evidence is quoted from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years producing live-service games or apps" (JD) | "4 years as an associate producer at a puzzle-game studio" (your message) | medium | [grounded] | transferability | Four years at a puzzle-game studio. It does not say the title ran as a live-service game in the JD's sense. Answer slot: if you ran its live model yourself (drops, events, retention cadence), describe it; if not, say so and stay with the content-drop work. |
| F2 | "experience running a content calendar" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | medium | [grounded] | none | Already reaches the requirement in role terms. Limit: no artifact yet, so expect a probe on the calendar. |
| F3 | "Plan and run the live-events calendar for two of our mobile titles" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | medium | [grounded] | transferability | One title and a weekly drop calendar. Two titles and live events are not in what you've told me. Answer slot: if you planned for a second title or ran events apart from drops, say how; if not, say so and say how one calendar would inform two. |
| F4 | "coordinate design, art, engineering and community teams on each update" (JD) | none given | none | [grounded] | discovery | Your material does not show this coordination. Answer slot: if you coordinated these teams on a drop, say which and how you handled a disagreement; if none were part of your drops, describe the nearest handoff you ran. |
| F5 | "own the post-event review and the KPIs it reports" (JD) | "Presented the monthly retention numbers to the studio head" (your message) | medium | [inferred] | discovery | Presenting numbers is not owning the KPIs or a review. Answer slot: if you owned a review or KPI, name it and what you did when it moved; if you presented numbers you didn't own, say that. |
| F6 | "comfortable with player-retention metrics" (JD) | "Presented the monthly retention numbers to the studio head" (your message) | medium | [grounded] | presentation | Bridge: "I presented the monthly retention numbers to the studio head." No figure added. Expect a probe on how they were counted. |
| F7 | "manage the release checklist with QA" (JD) | "Wrote the release checklist our QA team still uses" (your message) | medium | [grounded] | presentation | Bridge: "I wrote the release checklist our QA team still uses." Answer slot: if you ran or changed it after release, say what you did; if you wrote it and handed it over, say so. |
| F8 | "clear written communication" (JD) | "Wrote the release checklist our QA team still uses" (your message) | low | [inferred] | discovery | Touches written work used by another team; doesn't show writing for readers outside QA. Answer slot: name a written artifact a non-QA reader used, and who read it. |

No requirement in this JD is a gate (location, work authorization, licence). The 3+ years line is graded on fit.

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Leading or managing people | Negative you stated: "Never led a team" | "I haven't led a team." Then what you did lead, in F2's terms. |
| Experience on a game with in-app purchases | Negative you stated: "never worked on a game with in-app purchases" | "I haven't worked on a game with in-app purchases." Then how you'd learn it, as a plan. |
| Owning the KPIs or the post-event review | Inflated form of F5 | "Presented the monthly retention numbers to the studio head." |
| Running two titles | Inflated form of F3 | The weekly content-drop calendar for one main title. |
| Owning the release process end to end | Inflated form of F7 | "Wrote the release checklist our QA team still uses." |

## Reading the interviewer

- **Career (public):** Head of Live Operations at Saltmarsh. Before that, a QA lead at a console studio, per a GDC 2026 talk listing.
- **Published position:** the talk "Patch Notes Are a Promise." As the listing states it: a live team is judged by how often its patch notes describe what actually shipped.
- **Implications:**
  1. Describe what shipped, not what was planned.
  2. The release checklist is shared vocabulary with someone who came up through QA. Use F7's quote, not an adjective.
  3. Expect the tabletop to test the patch-notes standard, not only the fix.
- **Mirror opportunity:** none offered as a shared jump. You didn't move from QA to live operations, and no quoted sentence carries that side.

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | The Outage Hour tabletop | High (5). The page names it. | Clarify first, then name the teams and their order. |
| Values / Behavioral | The values conversation | High (4). The page names it, and it's the values round the loop documents. | Map a story only where a quoted sentence carries one; otherwise use the selection scaffold. |
| Skeptic | Probes on two titles, leadership, monetization | Medium-high (4). Hiring managers derisk gaps; F1, F3 and the prohibited list show where. | Rehearse B2 until it's calm. Concede specifically. |
| Data-Driven Prober | How the retention figure was counted | Medium (3). F6 is a headline-style claim. | Name the weakest assumption first, or say you don't know how it was counted. |
| Pressure | Interrupts, time-boxes | Low (2). Nothing in the public footprint suggests it. | Pause, restate, hold through two follow-ups, concede one specific point. |
| Conversational | "Walk me through the journey" | Low (1). Still scored. | Use the 90-second arc in E3. |

## Question banks

### A. Case / Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A live event is running and players report a reward did not grant. Walk me through the first hour." | CASE | [grounded] company interviewing page: "a live-incident tabletop on a simulated outage during a live event" | Clarify: what is broken, how many players, since when. Name the teams you'd pull in (design, engineering, QA, community) and what each does first. Decide pause or patch, and what players are told. No claim about your past. | The page names this tabletop; the structure is generic. |
| A2 | "A patch fixes the reward but the calendar slips two days. What do you tell the title team and the community team?" | CASE | [grounded] company values page: "when the calendar and the players disagree, the players win" | Name the value and its trade. Say what each team hears, and in what order. Don't claim you've made this call before. | Tests the first value under pressure. |
| A3 | "Walk me through how you'd get design, art, engineering and community onto one update." | JD | [grounded] JD: "coordinate design, art, engineering and community teams on each update" | Answer slot: if you coordinated these teams on a drop, name them and the disagreement you handled. If none were part of your drops, say so and describe the nearest handoff. | F4 has no quote, so the second branch allows the premise to be false. |
| A4 | "You'd be planning and running two titles' live-events calendars. What do you look at in your first two weeks?" | JD | [grounded] JD: "Plan and run the live-events calendar for two of our mobile titles" | Describe what you'd inspect first: the calendar, the retention figures, the checklist. Make it a plan. | Hypothetical; asserts nothing about your past. |
| A5 | "What in the release checklist you wrote would you change first after a bad release?" | EXP | [grounded] "Wrote the release checklist our QA team still uses" | Answer slot: if you changed it after a failure, say what and why; if not, say what you'd change first. | Premised on F7's quote only. |

### B. Skeptic (weight 4): highest-ROI prep

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You ran one title's content calendar. What makes you think you can run two?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Hold on what you ran: "I ran the weekly content-drop calendar for our main title for the last two years." Concede: "I haven't planned across two titles." Then say how you'd start. Answer slot: if you ever coordinated more than one title's calendar, say how. | F3 is the thin bridge; this is its probe. |
| B2 | "You've never led a team, and you've never worked on a game with in-app purchases. What do you bring here?" | JD | [grounded] "Never led a team" and "never worked on a game with in-app purchases" (your message) | **Highest-ROI rehearsal.** Say both negatives first: "I haven't led a team," and "I haven't worked on a game with in-app purchases." Return to the calendar, the checklist, the retention numbers, and hold through two follow-ups by returning to them. Concede on monetization: what you'd learn first and how. Don't claim leadership or monetization work. | Both gaps are your own statements. This is the hiring manager's most likely objection. |
| B3 | "Tell me about a live update that didn't perform, and what the post-event review found." | JD | [grounded] JD: "own the post-event review and the KPIs it reports" | Open prompt. Pick the nearest update that missed; say what you measured and who reviewed it. Answer slot: if none was reviewed that way, say so and describe what you'd measure first. | F5 has no review quote, so the second branch must allow no review existed. |
| B4 | "What would QA change first in the checklist you wrote?" | EXP | [grounded] "Wrote the release checklist our QA team still uses" | Answer slot: if QA changed it after you wrote it, say what and why; if not, say so. Don't claim QA's view you haven't heard. | Tests whether the ownership claim survives. |

### C. Values / Behavioral (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time the calendar and the players disagreed. Which won?" | VAL | [grounded] company values page: "when the calendar and the players disagree, the players win." Candidate sentence: "I ran the weekly content-drop calendar for our main title for the last two years" | Selection scaffold: pick a date you'd committed to that conflicted with what players needed; say what you did. If none comes to mind, say so plainly, then describe the nearest calendar decision from the sentence above. | No quoted sentence carries a conflict, so the honest branch is required. |
| C2 | "Tell me about a time you announced something that was not yet built." | VAL | [grounded] company values page: "we announce what is built, not what is hoped." Candidate sentence: "Wrote the release checklist our QA team still uses" | Map the checklist as what decides readiness, in your words: what it covers. Answer slot: if a release went out with a gap the checklist should have caught, say what; if none, say so. | Ship the Patch Not the Promise. |
| C3 | "Describe a change you made that left the process better for the next person." | VAL | [grounded] company values page: "every release leaves the codebase and the checklist better than it found them." Candidate sentence: "Wrote the release checklist our QA team still uses" | Answer slot: if you changed a checklist or calendar process so the next release went better, say what changed. If you wrote something new, say so. | Leave the Build Greener. "I wrote it new" is an acceptable answer. |
| C4 | "Give me a time you delivered an unpopular truth to leadership." | VAL | [generic] persona stem; no candidate sentence carries it | Selection scaffold: pick a time you told the studio head something unwelcome. If none comes to mind, say so, then describe the nearest retention presentation. | Generic stem; no claim about you. |

### D. Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how the monthly retention numbers you presented were counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Say what you know. If you don't know how they were counted, say so; don't reconstruct a method. Name the weakest assumption you know of. Answer slot: if you built the count, say which part; if you only presented it, say so. | F6 is the headline-style claim. |
| D2 | "Which retention number would you defend least, and why?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Name the weakest assumption before they do. If you can't name one, say so. | Metric question with the weakest-assumption move. |
| D3 | "Which KPIs did you own, and what did you do when one moved the wrong way?" | JD | [grounded] JD: "own the post-event review and the KPIs it reports" | Answer slot: if you owned a KPI, name it and what you did when it moved. If you presented figures you didn't own, say that. Don't claim ownership from the presentation. | F5's gap. |

### E. Pressure and Conversational (weights 2 and 1)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone with live-service experience?" | JD | [grounded] your message: "4 years as an associate producer at a puzzle-game studio" | Pause and restate. Anchor in the calendar and the checklist, in those words. Concede before they press: "I haven't led a team." Hold through two follow-ups. | Pressure stem. |
| E2 | "That retention presentation: how much of the result was actually you?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Hold: "I presented the monthly retention numbers to the studio head." Concede what wasn't yours, specifically. Answer slot: if you produced the analysis, say which part. | Pressure stem on F6. |
| E3 | "So, walk me through the journey." | EXP | [grounded] your message: "4 years as an associate producer at a puzzle-game studio"; "I ran the weekly content-drop calendar for our main title for the last two years"; "Wrote the release checklist our QA team still uses"; "Presented the monthly retention numbers to the studio head" | A 90-second arc using only these sentences, in order. Stop at the last one; add no story after it. | Conversational opener, scored. |

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| Plan and run the live-events calendar for two of our mobile titles | A4, B1, F3 |
| Coordinate design, art, engineering and community teams on each update | A1, A3 |
| Own the post-event review and the KPIs it reports | B3, D3 |
| Manage the release checklist with QA | A5, B4 |
| 3+ years producing live-service games or apps | E1, B2 |
| Experience running a content calendar | B1, A4 |
| Comfortable with player-retention metrics | D1, D2, E2 |
| Clear written communication | none directly, and why: the material shows one written artifact, the checklist; B4 touches it. A question on writing for non-QA readers needs a second artifact. |

## Values cheat sheet

| Value (official name) | Working meaning (paraphrased) | Mapped story |
|---|---|---|
| Players Before Plans | When the calendar and players disagree, players win. | No quoted sentence carries a conflict. Selection scaffold (C1), with its honest branch. |
| Ship the Patch Not the Promise | Announce what is built, not hoped. | "Wrote the release checklist our QA team still uses." Answer slot (C2). |
| Leave the Build Greener | Every release leaves the codebase and checklist better than it found them. | "Wrote the release checklist our QA team still uses." That says you wrote it, not that you improved it. Answer slot (C3). |

## Graded deliverables

None. The company's page says there is no take-home.

## Reverse questions

1. "When a live event goes wrong, what does the post-event review change for the next one?" *Why it lands:* tests whether the review is a learning loop or a report, which is the role's first ownership line.
2. "Your values page says the players win when the calendar and players disagree. Who makes that call in a live incident?" *Why it lands:* asks how the first value works in practice, and shows you read the page.
3. "You came up through QA at a console studio. What from QA do you want on this team?" *Why it lands:* ties to the interviewer's own path.
4. "How often do patch notes on this team not match what shipped, and what happens then?" *Why it lands:* the question his own talk makes central.
5. "What does the KPI set include today, and who reads it?" *Why it lands:* shows you know the KPI ownership isn't yours yet, and asks what owning it means here.
6. "What would a new producer do in the first month that would help the team most?" *Why it lands:* a reciprocity question that works with a hiring manager too.

## Sources

- **Provided:** the JD text and your background message.
- **Searches (3 of 6):**
  - "Saltmarsh Games values" → `https://saltmarshgames.com/values`. Used for values.
  - "Saltmarsh Games interview process live operations producer" → `https://saltmarshgames.com/careers/interviewing`. Used for the loop.
  - "Tobias Wrenfield Saltmarsh Games" → a GDC 2026 talk listing, `https://talks.gdconf.example/2026/patch-notes-are-a-promise`. Only the search snippet was seen, not the full talk.
- **Fetches (2 of 2):** the values page and the interviewing page above.
- **No dossier** was consumed.

Research tier: L1 — searches 3 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | yes | Values cheat sheet: three values by name. C1–C3. |
| 2. Saltmarsh Games interview process | yes | Loop: one 60-minute Outage Hour with the hiring manager, tabletop then values conversation. |
| 3. Saltmarsh Games strategy / recent news | unavailable | Budget not spent. Would have moved a CO question on current position; this pack has none. |
| 4. Tobias Wrenfield, Saltmarsh Games | yes | Interviewer read. The talk's full text was not read. |
| 5. Representative Live Operations Producer JD | skipped | Your JD fixes the requirements. |

## Upgrade menu

- **Your CV** → F1, F5 and F6 can move from medium to high, since a document would show the title's live cadence or the retention sheet.
- **The retention dashboard or the checklist itself**, as an artifact you can show → F6 and F7 can move to high.
- **Confirmation that Tobias runs the Outage Hour** → persona weights stand; if someone else runs it, the interviewer read and reverse questions change.
- **A recruiter email confirming this session is the only interview** → the loop stays as the page describes it.
- **A strategy pass** (three searches left at L1) → a CO bank on Saltmarsh's current position.
- **A deeper research pass (L2):** up to 6 more searches and 2 more fetches, several more minutes, for a strategy brief, the talk's full text, and loop reports. Want it?

Two offers, neither pushed:
- A live drill on B2, the highest-ROI question: say "drill B2" and I'll play the Skeptic.
- A `tuesday-dossier.md` recording the gaps this prep exposed (two titles, live-service, monetization, leadership, KPI ownership), to carry into later sessions.

A Word version of the pack is also one line away if you want it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh_live_operations_producer_interview_pack.md -----
# Interview prep: Live Operations Producer, Saltmarsh Games

**Interviewer:** Tobias Wrenfield, Head of Live Operations. The Saltmarsh interviewing page names the hiring manager as running the Outage Hour, so this pack treats Tobias as the hiring manager. If that is wrong, the persona weights change (see the upgrade menu).
**Round:** One 60-minute session: a live-incident tabletop, then a values conversation.

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored.
- Type key: **CASE** live problem from the role. **JD** a stated requirement. **EXP** a question about your past work. **VAL** published values, tested through behavior.
- Guidance is scaffolding, not a script. Say it in your own words, and say the parts that are answer slots in the form they take.

## The fit snapshot

Requirements are quoted from the JD you pasted. Evidence is quoted from your message. Nothing in the evidence column is a summary.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years producing live-service games or apps" (JD) | "4 years as an associate producer at a puzzle-game studio" (your message) | medium | [grounded] | transferability | Your material gives four years at a puzzle-game studio. It does not say the title ran as a live-service game in the sense the JD means. Answer slot: if you ran its live model yourself (drops, events, retention cadence), describe it in your words; if the model was different, say so and stay with the content-drop work. |
| F2 | "experience running a content calendar" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | medium | [grounded] | none | The quote already reaches the requirement in role terms. Limit: no artifact yet, so expect a probe on the calendar itself. Lead with the quote as written. |
| F3 | "Plan and run the live-events calendar for two of our mobile titles" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | medium | [grounded] | transferability | Your material shows one title and a weekly content-drop calendar. Two titles and live events are not in what you have told me. Answer slot: if you planned for a second title or ran events apart from drops, say how; if you did not, say so and say how one calendar would inform two. |
| F4 | "coordinate design, art, engineering and community teams on each update" (JD) | none given | none | [grounded] | discovery | Your material does not show this coordination. Answer slot: if you coordinated design, art, engineering or community on a drop, say which and how you handled a disagreement; if none of them were part of your drops, say so and describe the nearest handoff you ran. |
| F5 | "own the post-event review and the KPIs it reports" (JD) | "Presented the monthly retention numbers to the studio head" (your message) | medium | [inferred] | discovery | Presenting numbers is not owning the KPIs or a post-event review, and the bridge should not stretch to either. Answer slot: if you owned a review or a KPI, name it and say what you did when it moved; if you presented numbers you did not own, say that. |
| F6 | "comfortable with player-retention metrics" (JD) | "Presented the monthly retention numbers to the studio head" (your message) | medium | [grounded] | presentation | The quote reaches the requirement in other terms. Bridge: "I presented the monthly retention numbers to the studio head." It adds no figure. Expect a probe on how the numbers were counted. |
| F7 | "manage the release checklist with QA" (JD) | "Wrote the release checklist our QA team still uses" (your message) | medium | [grounded] | presentation | Your words are "wrote" and "still uses." Bridge: "I wrote the release checklist our QA team still uses." Answer slot: if you ran or changed the checklist after release, say what you did; if you wrote it and handed it over, say so. |
| F8 | "clear written communication" (JD) | "Wrote the release checklist our QA team still uses" (your message) | low | [inferred] | discovery | The quote touches written work used by another team. It does not show writing for a reader outside QA. Answer slot: name a written artifact a non-QA reader used, and who read it. |

No requirement in this JD is a gate (a term such as location, work authorization or licence). The 3+ years line is graded on fit, not on the gate rule.

## Prohibited claims

Built from the fit snapshot. Each entry has its basis and its honest form. No guidance, answer slot, or reverse question below asserts or implies any of these.

| Not coached | Basis | Honest form |
|---|---|---|
| Leading or managing people | Negative you stated: "Never led a team" | "I haven't led a team." Then what you did lead or run, in F2's terms. |
| Experience on a game with in-app purchases or monetization | Negative you stated: "never worked on a game with in-app purchases" | "I haven't worked on a game with in-app purchases." Then how you would learn it, said as a plan. |
| Owning the KPIs or the post-event review | Inflated form of F5 | F5's quote at its own scope: "Presented the monthly retention numbers to the studio head." |
| Running two titles | Inflated form of F3 | F3's quote at its own scope: the weekly content-drop calendar for one main title. |
| Owning the release process end to end | Inflated form of F7 | F7's quote at its own scope: "Wrote the release checklist our QA team still uses." |

## Reading the interviewer

- **Career pattern (public):** Head of Live Operations at Saltmarsh. Before that, a QA lead at a console studio, per a GDC 2026 talk listing.
- **Published position:** the talk "Patch Notes Are a Promise." Its argument, as the listing states it: a live team is judged by how often its patch notes describe what actually shipped.
- **Implications:**
  1. Describe what shipped, not what was planned. This is the interviewer's own test.
  2. The release checklist is shared vocabulary with someone who came up through QA. Use F7's quote, not an adjective.
  3. Expect the tabletop to test the patch-notes standard, not only the fix.
- **Mirror opportunity:** none offered as a shared jump. You did not move from QA to live operations, and no quoted sentence carries that side. Shared vocabulary (the release checklist) is enough.

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | The Outage Hour tabletop on a live event | High (5). The company page names the tabletop. | Clarify first, then name the teams you would pull in and the order. |
| Values / Behavioral | The values conversation in the same hour | High (4). The company page names it, and it is the one values round the loop documents. | Map a story to a value only where a quoted sentence carries one. Otherwise use the selection scaffold and its honest branch. |
| Skeptic | Probes on gaps: two titles, leadership, monetization | Medium-high (4). Hiring managers buy capability and derisk gaps; F1, F3 and the prohibited list show where. | Rehearse the single most predictable objection (B2) until it is calm. Concede specifically. |
| Data-Driven Prober | Asks how the retention figure was counted | Medium (3). F6 is a headline-style claim. | Name the weakest assumption before they do, or say you do not know how it was counted. |
| Pressure | Interrupts, time-boxes, challenges motive | Low (2). Nothing in the public footprint suggests it. | Pause, restate the question, hold through two follow-ups, concede a specific point. |
| Conversational | Opens with "walk me through the journey" | Low (1). The opener is still scored. | Use the 90-second arc in E3; it quotes only your sentences. |

## Question banks

Provenance comes first in each row. Every sentence the guidance rests on is quoted exactly.

### A. Case / Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A live event is running and players report a reward did not grant. Walk me through the first hour." | CASE | [grounded] the company's interviewing page: "a live-incident tabletop on a simulated outage during a live event" | Clarify before you act: what is broken, for how many players, since when. Then name the teams you would pull in (design, engineering, QA, community) and what each does first. Decide whether to pause or patch, and what players are told. Make no claim about your past. | The page names this tabletop. The structure is generic; the scenario is the company's own. |
| A2 | "A patch fixes the reward but the calendar slips two days. What do you tell the title team and the community team?" | CASE | [grounded] the company's values page: "when the calendar and the players disagree, the players win" | Name the value and its trade. Say what you would tell each team and in what order. Do not claim you have made this call before. | Tests the first published value under live pressure. |
| A3 | "Walk me through how you would get design, art, engineering and community onto one update." | JD | [grounded] JD: "coordinate design, art, engineering and community teams on each update" | Answer slot: if you coordinated these teams on a drop, name them and say how you handled a disagreement. If none were part of your drops, say so and describe the nearest handoff you ran. | F4 has no quote, so the guidance is a slot whose second branch lets the premise be false. |
| A4 | "You would be planning and running two titles' live-events calendars. What do you look at in your first two weeks?" | JD | [grounded] JD: "Plan and run the live-events calendar for two of our mobile titles" | Describe what you would inspect first: the calendar, the retention figures, the checklist. Make it a plan. Do not describe two-title work you have not done. | Hypothetical, so it asserts nothing about your past. |
| A5 | "What in the release checklist you wrote would you change first after a bad release?" | EXP | [grounded] "Wrote the release checklist our QA team still uses" | Answer slot: if you changed it after a failure, say what changed and why; if you did not, say so and describe what you would change first. | Premised on F7's quote only. |

### B. Skeptic (weight 4) — highest-ROI prep

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You ran one title's content calendar. What makes you think you can run two?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Hold on the calendar you ran: "I ran the weekly content-drop calendar for our main title for the last two years." Concede plainly: "I haven't planned across two titles." Then say how you would start. Answer slot: if you ever coordinated more than one title's calendar, say how. | F3 is the thin bridge and this question is its probe. |
| B2 | "You've never led a team, and you've never worked on a game with in-app purchases. What do you bring here?" | JD | [grounded] "Never led a team" and "never worked on a game with in-app purchases" (your message) | **Highest-ROI rehearsal in this pack.** Say the two negatives first, in your words: "I haven't led a team," and "I haven't worked on a game with in-app purchases." Then return to what you did: the calendar, the checklist, the retention numbers. Hold through two follow-ups by returning to those. Concede specifically on monetization: say what you would learn first and how. Do not claim leadership or monetization work. | Both gaps are stated by you, so the pack may name them. The question is the hiring manager's most likely objection. Deepest rehearsal here. |
| B3 | "Tell me about a live update that didn't perform, and what the post-event review found." | JD | [grounded] JD: "own the post-event review and the KPIs it reports" | Open prompt. Pick the nearest update that missed, say what you measured and who reviewed it. Answer slot: if no update of yours was reviewed that way, say so plainly and describe what you would measure first. | F5 has no review quote, so the second branch must allow that no review existed. |
| B4 | "What would QA change first in the checklist you wrote?" | EXP | [grounded] "Wrote the release checklist our QA team still uses" | Answer slot: if QA changed it after you wrote it, say what changed and why; if they did not, say so. Do not claim QA's view you have not heard. | Premised on F7's quote; tests whether the checklist ownership claim survives. |

### C. Values / Behavioral (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time the calendar and the players disagreed. Which won?" | VAL | [grounded] company values page: "when the calendar and the players disagree, the players win." Candidate sentence: "I ran the weekly content-drop calendar for our main title for the last two years" | Selection scaffold: pick a date you had committed to that conflicted with what players needed. Say what you did. If no such time comes to mind, say so plainly, then describe the nearest calendar decision you made from the sentence above, in your own words. | No quoted sentence carries a conflict, so the honest branch is required. |
| C2 | "Tell me about a time you announced something that was not yet built." | VAL | [grounded] company values page: "we announce what is built, not what is hoped." Candidate sentence: "Wrote the release checklist our QA team still uses" | Map the checklist as the thing that decides what is ready to announce, but only in your words: what the checklist covers. Answer slot: if a release went out with a gap the checklist should have caught, say what it was; if none, say so. | Ship the Patch Not the Promise. The checklist is the story's only carrier. |
| C3 | "Describe a change you made that left the process better for the next person." | VAL | [grounded] company values page: "every release leaves the codebase and the checklist better than it found them." Candidate sentence: "Wrote the release checklist our QA team still uses" | Answer slot: if you changed a checklist or a calendar process so the next release went better, say what changed. If you wrote something new rather than improving something, say so. | Leave the Build Greener. The honest answer may be "I wrote it new," and that is acceptable. |
| C4 | "Give me a time you delivered an unpopular truth to leadership." | VAL | [generic] a persona stem; no candidate sentence carries it | Selection scaffold: pick a time you told the studio head something they did not want to hear. Say what you said and what happened next. If none comes to mind, say so plainly and describe the nearest retention presentation, in your words. | Generic stem from the values persona. No claim about the candidate. |

### D. Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how the monthly retention numbers you presented were counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Say what you know about how they were counted. If you do not know, say that; do not reconstruct a method. Name the weakest assumption you know of. Answer slot: if you built the count, say which part and how; if you only presented it, say so. | F6 is the headline-style claim. Each slot names what a prober asks. |
| D2 | "Which retention number would you defend least, and why?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Name the weakest assumption in your own words before they do. If you cannot name one, say so. | Metric question with the weakest-assumption move. |
| D3 | "Which KPIs did you own, and what did you do when one moved the wrong way?" | JD | [grounded] JD: "own the post-event review and the KPIs it reports" | Answer slot: if you owned a KPI, name it and say what you did when it moved. If you presented figures you did not own, say that. Do not claim ownership from the presentation. | F5's gap. The second branch allows no ownership. |

### E. Pressure and Conversational (weights 2 and 1)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone with live-service experience?" | JD | [grounded] your message: "4 years as an associate producer at a puzzle-game studio" | Pause, restate. Anchor in the calendar you ran and the checklist you wrote, in those words. Concede the gap before they press it: "I haven't led a team." Hold through two follow-ups. | Pressure stem; the premise about the other candidate is theirs and needs no answer. |
| E2 | "That retention presentation: how much of the result was actually you?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Hold: "I presented the monthly retention numbers to the studio head." Concede what was not yours specifically. Answer slot: if you produced the analysis, say which part. | A pressure stem on F6's quote. |
| E3 | "So, walk me through the journey." | EXP | [grounded] your message: "4 years as an associate producer at a puzzle-game studio"; "I ran the weekly content-drop calendar for our main title for the last two years"; "Wrote the release checklist our QA team still uses"; "Presented the monthly retention numbers to the studio head" | A 90-second arc using only these sentences, in order. Stop at the last one; do not add a story after it. | Conversational opener, scored as a communication test. |

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| Plan and run the live-events calendar for two of our mobile titles | A4, B1, F3 |
| Coordinate design, art, engineering and community teams on each update | A1, A3 |
| Own the post-event review and the KPIs it reports | B3, D3 |
| Manage the release checklist with QA | A5, B4 |
| 3+ years producing live-service games or apps | E1, B2 |
| Experience running a content calendar | B1, A4 |
| Comfortable with player-retention metrics | D1, D2, E2 |
| Clear written communication | none directly, and why: the material shows one written artifact, the checklist. B4 touches it. A question on writing for non-QA readers needs a second artifact. |

## Values cheat sheet

Values are from the company's own page, read in full.

| Value (official name) | Working meaning (paraphrased) | Mapped story |
|---|---|---|
| Players Before Plans | When the calendar and players disagree, players win. | No quoted sentence carries a conflict. Selection scaffold (C1); honest branch: say so and describe the nearest calendar decision. |
| Ship the Patch Not the Promise | Announce what is built, not what is hoped. | "Wrote the release checklist our QA team still uses." The checklist is the carrier. Answer slot (C2): name a gap the checklist should have caught, or say none. |
| Leave the Build Greener | Every release leaves the codebase and checklist better than it found them. | "Wrote the release checklist our QA team still uses." The sentence says you wrote it, not that you improved it. Answer slot (C3): if you improved a process, say what changed; if you wrote something new, say so. |

## Graded deliverables

None. The company's page says there is no take-home.

## Reverse questions

1. "When a live event goes wrong, what does the post-event review change for the next one?" *Why it lands:* it tests whether the review is a learning loop or a report, which is the role's first ownership line.
2. "Your values page says the players win when the calendar and players disagree. Who makes that call in a live incident?" *Why it lands:* it asks how the first value works in practice, and signals you read the page.
3. "You came up through QA at a console studio. What from QA do you want on this team?" *Why it lands:* ties to the interviewer's own path and the patch-notes argument in the talk.
4. "How often do patch notes on this team not match what shipped, and what happens then?" *Why it lands:* it asks the question the interviewer's own talk makes central.
5. "What does the KPI set include today, and who reads it?" *Why it lands:* it shows you know F5 is not yet yours, and asks what owning it means here.
6. "What would a new producer do in the first month that would help the team most?" *Why it lands:* a reciprocity question that works with a hiring manager too.

## Sources

- **Provided:** the JD text, and your background message.
- **Searches (3 of 6):**
  - "Saltmarsh Games values": `https://saltmarshgames.com/values` returned. Used for the values.
  - "Saltmarsh Games interview process live operations producer": `https://saltmarshgames.com/careers/interviewing` returned. Used for the loop.
  - "Tobias Wrenfield Saltmarsh Games": a GDC 2026 talk listing at `https://talks.gdconf.example/2026/patch-notes-are-a-promise` returned. Used for the interviewer read; only the search snippet was seen, not the full talk.
- **Fetches (2 of 2):** `https://saltmarshgames.com/values` and `https://saltmarshgames.com/careers/interviewing`.
- **No dossier** was consumed.

Research tier: L1 — searches 3 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | yes | Values cheat sheet: three values by name. Banks C1–C3. |
| 2. Saltmarsh Games interview process | yes | Loop: one 60-minute Outage Hour with the hiring manager, a tabletop then a values conversation. Persona weights follow it. |
| 3. Saltmarsh Games strategy / recent news | unavailable | Budget not spent here. Would have moved a CO question on the company's current position. This pack has no CO question. Offered in the upgrade menu. |
| 4. Tobias Wrenfield, Saltmarsh Games | yes | Interviewer read: role, the GDC 2026 talk's thesis. The talk's full text was not read. |
| 5. Representative Live Operations Producer JD | skipped | The JD you supplied fixes the requirements. |

## Upgrade menu

- **Your CV** → F1, F5 and F6 can move from medium to high, because a document would show the title's live cadence or the retention sheet.
- **The retention dashboard or the checklist itself** (as an artifact you can show) → F6 and F7 can move to high.
- **Confirmation that Tobias runs the Outage Hour** → persona weights stand; if another person runs it, the interviewer read and the reverse questions change.
- **A recruiter email confirming the session is the only interview** → the loop stays as the page describes it.
- **A strategy pass** (three searches left at L1) → a CO bank on Saltmarsh's current position for the reverse questions.
- **A deeper research pass (L2):** up to 6 more searches and 2 more fetches, several more minutes, for a strategy brief, the talk's full text, and loop reports. Want it?
