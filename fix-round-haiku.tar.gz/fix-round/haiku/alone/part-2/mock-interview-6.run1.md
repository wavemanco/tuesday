Your prep pack is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-alone-part-2-rooms-case-6-denied-574f61b8/1aaac0d9-257e-4227-8f48-88287fc72b03/scratchpad/larkfield_systems_engineering_manager_interview_pack.md`. It covers all three rounds. Company research was refused in this session, and no JD or interviewer names were given, so everything about Larkfield comes from your role summary and your message.

# Larkfield Systems, Engineering Manager: three-round prep pack (loop mode)

**Role:** Engineering Manager, Larkfield Systems (industrial IoT, ~600 people)
**Candidate:** Yusuf
**Rounds:**
1. Tuesday, 45 min, hiring manager (Director of Engineering)
2. Thursday after, 60 min, panel: two staff engineers and a product manager
3. Following Monday, 30 min, VP Engineering ("values and leadership philosophy", per the recruiter)

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored: VAL (values/behavioral), EXP (your experience, probed), JD (the role's stated requirements), CO (company knowledge), CASE (live problem).
- Guidance is scaffolding, not a script. Rehearse it aloud in your own words, and stop where your own material stops.
- Anything in quotation marks is a sentence you wrote or a line from your role summary. Anything marked [generic] is a pattern for the question, not a fact about Larkfield.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F0 | Location, travel or on-site terms (not in your role summary) | none given | none | [generic] | hard_gate | Your material does not establish location or travel terms, and the pack will not guess them. See the question at the end. |
| F1 | "Lead two squads building device-management services" (your role summary) | "9 years engineering, 3 as a team lead of 6" (your message) | medium | [grounded] | transferability | Your material shows one team of six for three years, not two squads. Say the team-of-six part in those words. Answer slot: the two-squad scope makes a probe on coordinating two teams likely. If you coordinated across teams yourself, say how; if you did not, say so and stay with the team of six. |
| F2 | "own delivery, hiring and growth for 11 engineers" (your role summary) | "I run our hiring loop for backend roles — about 40 interviews last year." (your message) | medium | [grounded] | presentation | Reword only: "I run our hiring loop for backend roles; about 40 interviews last year." The quote reaches hiring, for backend roles. Say backend. |
| F3 | "own delivery, hiring and growth for 11 engineers" (your role summary) | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." (your message) | medium | [grounded] | transferability | Your material shows delivery of a reliability quarter against roadmap pressure, not feature delivery for device services. The 60% is a figure you have not yet described in its counting. Answer slot: how the 60% was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. |
| F4 | "own delivery, hiring and growth for 11 engineers" (your role summary, growth) | none given | none | [grounded] | discovery | Answer slot: say what you have done to grow people on your team, in your own words. If none of it was for growth, say so plainly and say how you would start. |
| F5 | "partner with hardware and product on roadmap" (your role summary) | "I've never managed managers and never owned a hardware-adjacent roadmap." (your message) | none | [grounded] | capability | The plain acknowledgment: "I haven't owned a hardware-adjacent roadmap." Then how you would learn it, said as a plan and never as a past. |
| F6 | "partner with hardware and product on roadmap" (your role summary) | none given | none | [grounded] | discovery | Answer slot: say whether you have worked with a product manager on a roadmap, and what that work was. If you have not, say so and say how you would set up that partnership. |
| F7 | Managing managers (not in your role summary; you named it as a gap) | "I've never managed managers and never owned a hardware-adjacent roadmap." (your message) | none | [grounded] | capability | The plain acknowledgment: "I haven't managed managers." Your role summary does not say managers are in scope, and the pack cannot establish that they are. Route only as a plan. |

Confidence grades your evidence. Provenance grades what this pack wrote about it. The 60% figure is medium, not high, because you have given no inspectable record of it.

## Prohibited claims

Built locally from the fit snapshot. No coaching cell, bank question, hold or reverse question may assert any of these.

| Not coached | Basis | Honest form |
|---|---|---|
| Has managed managers | Stated negative, F7 | "I haven't managed managers." No answer slot. |
| Has owned a hardware-adjacent roadmap | Stated negative, F5 | "I haven't owned a hardware-adjacent roadmap." No answer slot. |
| Has led two squads | Inflated form of F1 | "a team of six," at its own scope. The pack's observation: your material says one team, not two. |
| Drove the 60% drop alone | Inflated form of F3 | "My team's on-call burden dropped 60% after I pushed a reliability quarter through." The pack's observation: your material does not show who else did the work. |

## Persona weights

| Round | Dominant personas | Weights (priors) | Reasoning |
|---|---|---|---|
| 1. Hiring manager (Director) | Case/Strategist, Skeptic | Skeptic 35%, Case 35%, Prober 15%, Pressure 15% | A hiring manager is buying capability and derisking gaps. Your two stated gaps, F5 and F3's counting, are what they will press. No interviewer profile exists, so these are round-type priors. |
| 2. Panel (2 staff, 1 PM) | Prober and Peer for the staff engineers; Case and Peer for the PM | Prober 30%, Case 30%, Peer 25%, Skeptic/Pressure 15% | With no names, the panel is blended by member relationship. Staff engineers test reliability numbers and architecture seams. The PM tests roadmap trade-offs. |
| 3. VP Engineering | Values/Behavioral, Pressure | Values 50%, Pressure 25%, Case 25% | Your recruiter's own words, "values and leadership philosophy," make values the scored theme. Altitude and composure test the leadership layer. |

## Round 1: Hiring manager (Director of Engineering), 45 min

**A1 is the highest-ROI prep in the whole pack.** Your hardware-roadmap gap (F5) is the objection this round is most likely to press, in some form.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You haven't owned a hardware-adjacent roadmap. What would you do first to close that?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | Plain line: "I haven't owned a hardware-adjacent roadmap." Then the plan, as learning steps you have not yet taken: time with the hardware leads, sitting in roadmap reviews. Hold the plan through follow-up one. Concede specifically on follow-up two: "I don't yet know which hardware trade-offs would surprise me." | F5 is a capability gap you stated. The Skeptic asks this in some form. This is the deepest rehearsal in the pack. |
| A2 | "Your background is backend and payments. What about device-management services is new to you?" | JD | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." "currently at a payments company." | Name what is new, in your own words. Answer slot: if you have touched device or edge services, say how. If you have not, say so. | F2 and F5. Asks about the gap where the role's scope is widest. |
| A3 | "Why leave a payments company for industrial IoT?" | JD | [generic] | Your material is silent on motivation, so there is no sentence to build on. Pick the real reason, and say it the way you would to a peer. If the honest reason is about the work, say the work. If you do not yet have one, say so and state the reason you have. | A Skeptic's motivation probe. The material supplies no content, so none is written here. |
| A4 | "You take over two squads building device-management services. Walk me through your first ninety days." | CASE | [generic] | Clarify first: what the squads own, which hardware dependencies are committed, what the roadmap already promises. Then structure: listen first, get a delivery baseline, set up roadmap partnerships. If you draw on experience, say "three as a team lead of six" and no more. Answer slot: if you have built a first-quarter plan before, say what it covered. If not, say so. | CASE on the device-management scope. F1 and F6 surface here. |
| A5 | "Two squads, 11 engineers. How do you plan to grow the team over the next year?" | CASE | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Start from the hiring loop you run, and the 40 interviews, and let the plan be structure. Claim only what you have run. Answer slot: if you have owned a hiring plan end to end, say so. If not, say so. | F2 and F4. Hiring is the strongest thing you can point to here. |
| A6 | "Walk me through how the 60% on-call reduction was counted." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Say the baseline window and the counting method in your own words. Name the assumption you would defend least, before they do. Say which part was yours: the push. If you do not know how it was counted, say so plainly. | F3. A figure you gave raises the four defend-the-number questions: method, sensitivity, weakest assumption, your share. |
| A7 | "Sixty seconds: why would we hire someone who has never owned a hardware-adjacent roadmap?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Hold: "What I did carry is a reliability quarter I pushed through against roadmap pressure." Hold through two follow-ups. Concede specifically: the hardware-roadmap part, not the whole hire. | F5 and F3. This is the pressure version of A1. |
| A8 | "So — walk me through the journey." | EXP | [grounded] "9 years engineering, 3 as a team lead of 6" "currently at a payments company." | A 90-second arc from those sentences: nine years in engineering, three leading a team of six, now at a payments company, running the backend hiring loop. Stop there and let them pull the next thread. | Casual openers are scored. The arc uses only your quoted sentences. |

**Reverse questions for Round 1**

1. "What would the first quarter's hardware dependencies look like for these two squads?" Why it lands: it names the seam before they raise it.
2. "What does success look like at six months for someone in this seat?" Why it lands: it asks for the scorecard, which a hiring manager is always ready to give.
3. "How are the eleven engineers' growth paths set today?" Why it lands: it treats growth as part of the job, the part your material does not yet show.
4. "What did the last person in this role get right, and what would you change?" Why it lands: it shows you want to inherit a working setup, not start from scratch.
5. "What would make you confident in this hire after ninety days?" Why it lands: it turns the gap into a shared test.

## Round 2: Panel (two staff engineers, one product manager), 60 min

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Take me through the reliability quarter. What was in it, and which items did you decide?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Name the items in your own words. Answer slot: if you chose which items went into the quarter, say which and why. If the list was set by someone else, or by your engineers, say so, and describe the push in your own words. | F3. Staff engineers test technical depth in the one story you have told in detail. |
| B2 | "Which assumption behind that 60% would you defend least?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Name the weakest assumption before they do. If you cannot name one, say so. | F3. A Prober's standard follow-up. |
| B3 | "Device-management services sit beside firmware and hardware teams. Where is the seam with your team, and what happens when you disagree?" | JD | [generic] | Give seam principles, not claims about hardware work. Your material shows none, so say so, then propose principles: who decides the interface, how a disagreement escalates. | F6, a discovery gap. A Peer's seam probe. |
| B4 | "How do you handle credit when work spans teams?" | JD | [generic] | Scaffold: pick a time work crossed teams and you gave credit. If none comes to mind, say so plainly, then say how you would handle it. | A Peer's credit probe. The material has no example, so none is supplied. |
| B5 | "A hardware partner wants a feature delayed two quarters for a fix that matters only at scale. Your PM says ship. How do you call it?" | CASE | [generic] | Clarify the scale, the cost of delay and who owns the risk. Name your decision rule. Concede what you do not know about hardware lead times. | A live roadmap trade-off between the PM and hardware. |
| B6 | "Sketch the first-quarter roadmap for device-management services. What do you need to know first?" | CASE | [generic] | List the inputs first: committed deliverables, hardware dependencies, on-call load. Then the structure. No specifics you have not been given. | A Case probe at the PM's altitude. |
| B7 | "I don't see hardware or roadmap ownership in your background. How would you handle that here?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | Plain line: "I haven't owned a hardware-adjacent roadmap." Then the plan, as in A1. | F5. The PM may raise this, in collegial form. |
| B8 | "You've led a team of six. Why would two squads be different?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6" | Hold: the team of six is what you have led. Concede specifically: the two-squad step is untested in your record. Name the structure you would use to cover the second squad. Hold through two follow-ups. | F1. The Pressure version of the two-squad gap. |

**Reverse questions for Round 2**

1. "Where do staff engineers want the EM to step in on architecture, and where do they want to stay out?" Why it lands: it shows you plan to hold the technical line without taking it over.
2. "What is the roadmap trade-off the PM is living with this quarter?" Why it lands: it asks for the real constraint, and the PM is in the room.
3. "Where does the seam with hardware work best today, and where does it break?" Why it lands: it asks where the friction is before you are asked to fix it.
4. "How do you decide when a reliability item goes ahead of a feature?" Why it lands: it lets the panel show you the trade-off you already made.
5. "What would a strong first month look like for someone joining this team?" Why it lands: it asks for the onboarding they would actually give.

## Round 3: VP Engineering, 30 min

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Story-mapped: the reliability quarter, the roadmap pressure, the push, the 60%. Those are the beats your sentence states. Answer slot: how you made the case, and what leadership said, in your own words. If you made the case differently, say that. | F3. This is the strongest quoted story in the pack, and it is about pressure, not about leadership. Keep it to what you pushed and what changed. |
| C2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Scaffold: pick a time a customer's need changed a number you were measured on. Your material carries no customer example. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. | A values probe with no quoted story. |
| C3 | "Tell me about someone on your team you helped grow into a bigger role." | VAL | [generic] | Scaffold: pick a person and what you did for them. If none, say so, then say how you would grow people in this role. | F4, a discovery gap. Growth is in the role summary, and nothing in your message answers it. |
| C4 | "What is your leadership philosophy, and what would you need to see to change it?" | VAL | [generic] | State it as practices you have used, not as a belief you cannot point to. Your material carries one team over three years. Keep the claim to that size. | The recruiter's own phrase, "leadership philosophy." |
| C5 | "You've led a team of six. What changes when the people you lead are managers?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." "9 years engineering, 3 as a team lead of 6" | Plain line: "I haven't managed managers." Hold the transferable part you actually did: the team of six. Concede that the manager-of-managers layer is unknown to you. | F7. Pressure form of the layer gap. |
| C6 | "Two squads, 11 engineers, a hardware partner. What would you change in your first ninety days?" | CASE | [generic] | Name the first thing you would check, then your structure. No claim about your past. | An altitude check. |

**Reverse questions for Round 3**

1. "What does leadership mean here, in one behavior you would expect from a manager in their first quarter?" Why it lands: it asks for a specific behavior, not a slogan.
2. "How do you weigh reliability against roadmap commitments when they conflict?" Why it lands: it sits on the trade-off C1 is about.
3. "What have managers here done that you would keep, and what would you retire?" Why it lands: it shows you know the culture is not yours to rewrite.
4. "What would a leadership failure look like here, specifically?" Why it lands: it asks them to name the bar.
5. "What do you hope this hire does differently in year one from the last person in the role?" Why it lands: it turns the value question into a shared plan.

## Coverage across the pack

| Requirement | Covered by |
|---|---|
| Lead two squads building device-management services | A4, B6, B8, C6 |
| Own delivery | A6, B1, C1 |
| Own hiring | A5, A2 |
| Own growth for 11 engineers | A5 (F4 slot), C3 |
| Partner with hardware and product on roadmap | A1, B3, B5, B7 |
| Hardware-adjacent roadmap (your stated gap) | A1, A7, B7 |
| Managing managers (your stated gap, not in the role summary) | C5 |
| Location and travel terms | none; gate, asked below |

Dropped sections: interviewer read (no names), values cheat sheet (no Larkfield values available, since search was refused).

## Sources

**Provided documents:** your role summary and your message. No JD, no CV, no interviewer profile.

**Searches sent:**
- "Larkfield Systems industrial IoT company values": refused. Search permission was not granted in this session.
- "Larkfield Systems engineering manager interview process": refused, for the same reason.

**Research tier:** L1. Searches 0 of 6 returned results, 2 refused. Fetches 0 of 2.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Larkfield values | unavailable | Values cheat sheet, which is dropped. The VP round's values questions use the recruiter's words instead. |
| 2. Larkfield interview process | unavailable | Loop structure. The three rounds come from your message. |
| 3. Larkfield strategy and recent news | unavailable | CO questions grounded in current strategy, none written. |
| 4. Interviewer name | n/a | No names were given. |
| 5. Representative JD for the title | unavailable | Would have made the requirement quotes [inferred] instead of [grounded]. |

## Upgrade menu

- The three interviewers' names → persona weights per person, and reverse questions tied to each person's own career path.
- The JD text for this role → F1, F2, F3, F4 and F6 take their requirement wording from the posting, and the requirement quotes become [grounded] instead of your summary.
- Larkfield's published values page, pasted here → a values cheat sheet for Round 3, and C2 and C4 get stories mapped to the values.
- Permission for web search, granted for this session → the research targets above run, and the CO bank gets written.
- The recruiter's note on what Round 2 will test → confirms the panel's mix, and the persona weights follow it.

---

Two one-line offers, neither pushed:
- Say the word and I'll run the Director round as a live drill, starting with A1, the question the pack names as highest-ROI.
- I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, so you can carry them into later sessions.

Question for you: does this role carry any location, travel or on-site requirement? Your role summary says nothing about it, so the pack treats it as unestablished (F0).

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: larkfield_systems_engineering_manager_interview_pack.md -----
# Larkfield Systems, Engineering Manager: three-round prep pack (loop mode)

**Role:** Engineering Manager, Larkfield Systems (industrial IoT, ~600 people)
**Candidate:** Yusuf
**Rounds:**
1. Tuesday, 45 min, hiring manager (Director of Engineering)
2. Thursday after, 60 min, panel: two staff engineers and a product manager
3. Following Monday, 30 min, VP Engineering ("values and leadership philosophy", per the recruiter)

No interviewer names, no JD text, no company research. Everything about Larkfield below comes from your role summary and your message.

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored: VAL (values/behavioral), EXP (your experience, probed), JD (the role's stated requirements), CO (company knowledge), CASE (live problem).
- Guidance is scaffolding, not a script. Rehearse it aloud in your own words, and stop where your own material stops.
- Anything in quotation marks is a sentence you wrote or a line from your role summary. Anything marked [generic] is a pattern for the question, not a fact about Larkfield.

## Fit snapshot

Requirements come from your role summary, quoted. Evidence is quoted from your message. There is no CV in this session, so the evidence column is only what you have typed here.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F0 | Location, travel or on-site terms (not in your role summary) | none given | none | [generic] | hard_gate | Your material does not establish location or travel terms, and the pack will not guess them. See the question at the end. |
| F1 | "Lead two squads building device-management services" (your role summary) | "9 years engineering, 3 as a team lead of 6" (your message) | medium | [grounded] | transferability | Your material shows one team of six for three years, not two squads. Say the team-of-six part in those words. Answer slot: the two-squad scope makes a probe on coordinating two teams likely. If you coordinated across teams yourself, say how; if you did not, say so and stay with the team of six. |
| F2 | "own delivery, hiring and growth for 11 engineers" (your role summary) | "I run our hiring loop for backend roles — about 40 interviews last year." (your message) | medium | [grounded] | presentation | Reword only: "I run our hiring loop for backend roles; about 40 interviews last year." The quote reaches hiring, for backend roles. Say backend. |
| F3 | "own delivery, hiring and growth for 11 engineers" (your role summary) | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." (your message) | medium | [grounded] | transferability | Your material shows delivery of a reliability quarter against roadmap pressure, not feature delivery for device services. The 60% is a figure you have not yet described in its counting. Answer slot: how the 60% was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. |
| F4 | "own delivery, hiring and growth for 11 engineers" (your role summary, growth) | none given | none | [grounded] | discovery | Answer slot: say what you have done to grow people on your team, in your own words. If none of it was for growth, say so plainly and say how you would start. |
| F5 | "partner with hardware and product on roadmap" (your role summary) | "I've never managed managers and never owned a hardware-adjacent roadmap." (your message) | none | [grounded] | capability | The plain acknowledgment: "I haven't owned a hardware-adjacent roadmap." Then how you would learn it, said as a plan and never as a past. |
| F6 | "partner with hardware and product on roadmap" (your role summary) | none given | none | [grounded] | discovery | Answer slot: say whether you have worked with a product manager on a roadmap, and what that work was. If you have not, say so and say how you would set up that partnership. |
| F7 | Managing managers (not in your role summary; you named it as a gap) | "I've never managed managers and never owned a hardware-adjacent roadmap." (your message) | none | [grounded] | capability | The plain acknowledgment: "I haven't managed managers." Your role summary does not say managers are in scope, and the pack cannot establish that they are. Route only as a plan. |

Confidence grades your evidence. Provenance grades what this pack wrote about it. Gap type is the call on the gap, from the routing in the reference rules. The 60% figure is medium, not high, because you have given no inspectable record of it.

## Prohibited claims

Built locally from the fit snapshot. No coaching cell, bank question, hold or reverse question may assert any of these.

| Not coached | Basis | Honest form |
|---|---|---|
| Has managed managers | Stated negative, F7 | "I haven't managed managers." No answer slot. |
| Has owned a hardware-adjacent roadmap | Stated negative, F5 | "I haven't owned a hardware-adjacent roadmap." No answer slot. |
| Has led two squads | Inflated form of F1 | "a team of six," at its own scope. The pack's observation: your material says one team, not two. |
| Drove the 60% drop alone | Inflated form of F3 | "My team's on-call burden dropped 60% after I pushed a reliability quarter through." The pack's observation: your material does not show who else did the work. |

## Persona weights

| Round | Dominant personas | Weights (priors) | Reasoning |
|---|---|---|---|
| 1. Hiring manager (Director) | Case/Strategist, Skeptic | Skeptic 35%, Case 35%, Prober 15%, Pressure 15% | A hiring manager is buying capability and derisking gaps. Your two stated gaps, F5 and F3's counting, are what they will press. No interviewer profile exists, so these are round-type priors. |
| 2. Panel (2 staff, 1 PM) | Prober and Peer for the staff engineers; Case and Peer for the PM | Prober 30%, Case 30%, Peer 25%, Skeptic/Pressure 15% | With no names, the panel is blended by member relationship. Staff engineers test reliability numbers and architecture seams. The PM tests roadmap trade-offs. |
| 3. VP Engineering | Values/Behavioral, Pressure | Values 50%, Pressure 25%, Case 25% | Your recruiter's own words, "values and leadership philosophy," make values the scored theme. Altitude and composure test the leadership layer. |

Depth follows weight: the top persona in each round gets the most questions.

## Round 1: Hiring manager (Director of Engineering), 45 min

Question IDs are A1 to A8. **The highest-ROI prep in the whole pack is A1.** Your hardware-roadmap gap (F5) is the objection this round is most likely to press, in some form. Rehearse A1 until the plain acknowledgment and the plan come out without hesitation.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You haven't owned a hardware-adjacent roadmap. What would you do first to close that?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | Plain line: "I haven't owned a hardware-adjacent roadmap." Then the plan, as learning steps you have not yet taken: time with the hardware leads, sitting in roadmap reviews. Hold the plan through follow-up one. Concede specifically on follow-up two: "I don't yet know which hardware trade-offs would surprise me." | F5 is a capability gap you stated. The Skeptic asks this in some form. This is the deepest rehearsal in the pack. |
| A2 | "Your background is backend and payments. What about device-management services is new to you?" | JD | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." "currently at a payments company." | Name what is new, in your own words. Answer slot: if you have touched device or edge services, say how. If you have not, say so. | F2 and F5. Asks about the gap where the role's scope is widest. |
| A3 | "Why leave a payments company for industrial IoT?" | JD | [generic] | Your material is silent on motivation, so there is no sentence to build on. Pick the real reason, and say it the way you would to a peer. If the honest reason is about the work, say the work. If you do not yet have one, say so and state the reason you have. | A Skeptic's motivation probe. The material supplies no content, so none is written here. |
| A4 | "You take over two squads building device-management services. Walk me through your first ninety days." | CASE | [generic] | Clarify first: what the squads own, which hardware dependencies are committed, what the roadmap already promises. Then structure: listen first, get a delivery baseline, set up roadmap partnerships. If you draw on experience, say "three as a team lead of six" and no more. Answer slot: if you have built a first-quarter plan before, say what it covered. If not, say so. | CASE on the device-management scope. F1 and F6 surface here. |
| A5 | "Two squads, 11 engineers. How do you plan to grow the team over the next year?" | CASE | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Start from the hiring loop you run, and the 40 interviews, and let the plan be structure. Claim only what you have run. Answer slot: if you have owned a hiring plan end to end, say so. If not, say so. | F2 and F4. Hiring is the strongest thing you can point to here. |
| A6 | "Walk me through how the 60% on-call reduction was counted." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Say the baseline window and the counting method in your own words. Name the assumption you would defend least, before they do. Say which part was yours: the push. If you do not know how it was counted, say so plainly. | F3. A figure you gave raises the four defend-the-number questions: method, sensitivity, weakest assumption, your share. |
| A7 | "Sixty seconds: why would we hire someone who has never owned a hardware-adjacent roadmap?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Hold: "What I did carry is a reliability quarter I pushed through against roadmap pressure." Hold through two follow-ups. Concede specifically: the hardware-roadmap part, not the whole hire. | F5 and F3. This is the pressure version of A1. |
| A8 | "So — walk me through the journey." | EXP | [grounded] "9 years engineering, 3 as a team lead of 6" "currently at a payments company." | A 90-second arc from those sentences: nine years in engineering, three leading a team of six, now at a payments company, running the backend hiring loop. Stop there and let them pull the next thread. | Casual openers are scored. The arc uses only your quoted sentences. |

**Requirement coverage for Round 1:** lead two squads (A4), hiring (A5), growth (A5, with F4's slot), partner on roadmap (A1), hardware-adjacent roadmap (A1, A7), delivery (A6).

**Reverse questions for Round 1**

1. "What would the first quarter's hardware dependencies look like for these two squads?" Why it lands: it names the seam before they raise it.
2. "What does success look like at six months for someone in this seat?" Why it lands: it asks for the scorecard, which a hiring manager is always ready to give.
3. "How are the eleven engineers' growth paths set today?" Why it lands: it treats growth as part of the job, the part your material does not yet show.
4. "What did the last person in this role get right, and what would you change?" Why it lands: it shows you want to inherit a working setup, not start from scratch.
5. "What would make you confident in this hire after ninety days?" Why it lands: it turns the gap into a shared test.

## Round 2: Panel (two staff engineers, one product manager), 60 min

Question IDs are B1 to B8. The panel has no names, so the persona weights are blended per member.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Take me through the reliability quarter. What was in it, and which items did you decide?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Name the items in your own words. Answer slot: if you chose which items went into the quarter, say which and why. If the list was set by someone else, or by your engineers, say so, and describe the push in your own words. | F3. Staff engineers test technical depth in the one story you have told in detail. |
| B2 | "Which assumption behind that 60% would you defend least?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Name the weakest assumption before they do. If you cannot name one, say so. | F3. A Prober's standard follow-up. |
| B3 | "Device-management services sit beside firmware and hardware teams. Where is the seam with your team, and what happens when you disagree?" | JD | [generic] | Give seam principles, not claims about hardware work. Your material shows none, so say so, then propose principles: who decides the interface, how a disagreement escalates. | F6, a discovery gap. A Peer's seam probe. |
| B4 | "How do you handle credit when work spans teams?" | JD | [generic] | Scaffold: pick a time work crossed teams and you gave credit. If none comes to mind, say so plainly, then say how you would handle it. | A Peer's credit probe. The material has no example, so none is supplied. |
| B5 | "A hardware partner wants a feature delayed two quarters for a fix that matters only at scale. Your PM says ship. How do you call it?" | CASE | [generic] | Clarify the scale, the cost of delay and who owns the risk. Name your decision rule. Concede what you do not know about hardware lead times. | A live roadmap trade-off between the PM and hardware. |
| B6 | "Sketch the first-quarter roadmap for device-management services. What do you need to know first?" | CASE | [generic] | List the inputs first: committed deliverables, hardware dependencies, on-call load. Then the structure. No specifics you have not been given. | A Case probe at the PM's altitude. |
| B7 | "I don't see hardware or roadmap ownership in your background. How would you handle that here?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | Plain line: "I haven't owned a hardware-adjacent roadmap." Then the plan, as in A1. | F5. The PM may raise this, in collegial form. |
| B8 | "You've led a team of six. Why would two squads be different?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6" | Hold: the team of six is what you have led. Concede specifically: the two-squad step is untested in your record. Name the structure you would use to cover the second squad. Hold through two follow-ups. | F1. The Pressure version of the two-squad gap. |

**Requirement coverage for Round 2:** two squads (B8, B6), device-management services (B5, B6), delivery (B1, B2), partner with hardware and product (B3, B5, B7), hardware-adjacent roadmap (B7), growth (none in this round; A5 and C3 cover it).

**Reverse questions for Round 2**

1. "Where do staff engineers want the EM to step in on architecture, and where do they want to stay out?" Why it lands: it shows you plan to hold the technical line without taking it over.
2. "What is the roadmap trade-off the PM is living with this quarter?" Why it lands: it asks for the real constraint, and the PM is in the room.
3. "Where does the seam with hardware work best today, and where does it break?" Why it lands: it asks where the friction is before you are asked to fix it.
4. "How do you decide when a reliability item goes ahead of a feature?" Why it lands: it lets the panel show you the trade-off you already made.
5. "What would a strong first month look like for someone joining this team?" Why it lands: it asks for the onboarding they would actually give.

## Round 3: VP Engineering, 30 min

Question IDs are C1 to C6. Values answers are where a story is worth most, so C1 is the one to rehearse out loud.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Story-mapped: the reliability quarter, the roadmap pressure, the push, the 60%. Those are the beats your sentence states. Answer slot: how you made the case, and what leadership said, in your own words. If you made the case differently, say that. | F3. This is the strongest quoted story in the pack, and it is about pressure, not about leadership. Keep it to what you pushed and what changed. |
| C2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Scaffold: pick a time a customer's need changed a number you were measured on. Your material carries no customer example. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. | A values probe with no quoted story. |
| C3 | "Tell me about someone on your team you helped grow into a bigger role." | VAL | [generic] | Scaffold: pick a person and what you did for them. If none, say so, then say how you would grow people in this role. | F4, a discovery gap. Growth is in the role summary, and nothing in your message answers it. |
| C4 | "What is your leadership philosophy, and what would you need to see to change it?" | VAL | [generic] | State it as practices you have used, not as a belief you cannot point to. Your material carries one team over three years. Keep the claim that size. | The recruiter's own phrase, "leadership philosophy." |
| C5 | "You've led a team of six. What changes when the people you lead are managers?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." "9 years engineering, 3 as a team lead of 6" | Plain line: "I haven't managed managers." Hold the transferable part you actually did: the team of six. Concede that the manager-of-managers layer is unknown to you. | F7. Pressure form of the layer gap. |
| C6 | "Two squads, 11 engineers, a hardware partner. What would you change in your first ninety days?" | CASE | [generic] | Name the first thing you would check, then your structure. No claim about your past. | An altitude check. |

**Requirement coverage for Round 3:** growth (C3), leadership at the manager layer (C5), values (C1, C2, C4), two squads and hardware (C6).

**Reverse questions for Round 3**

1. "What does leadership mean here, in one behavior you would expect from a manager in their first quarter?" Why it lands: it asks for a specific behavior, not a slogan.
2. "How do you weigh reliability against roadmap commitments when they conflict?" Why it lands: it sits on the trade-off C1 is about.
3. "What have managers here done that you would keep, and what would you retire?" Why it lands: it shows you know the culture is not yours to rewrite.
4. "What would a leadership failure look like here, specifically?" Why it lands: it asks them to name the bar.
5. "What do you hope this hire does differently in year one from the last person in the role?" Why it lands: it turns the value question into a shared plan.

## Interviewer read

Dropped. No interviewer names were given, so there is no public footprint to read.

## Values / principles cheat sheet

Dropped. No Larkfield values were available: the search that would have fetched them was refused (see Sources). The VP round's values questions rest on the recruiter's words, "values and leadership philosophy," and on the stems in the bank above.

## Sources

**Provided documents:** your role summary, and your message (candidate background, the three rounds, the recruiter's description of the VP round). No JD, no CV, no interviewer profile.

**Searches and fetches sent:**
- "Larkfield Systems industrial IoT company values": refused. The search permission was not granted in this session.
- "Larkfield Systems engineering manager interview process": refused, for the same reason.

**Research tier:** L1, searches 0 of 6 returned results, 2 refused, fetches 0 of 2.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Larkfield values | unavailable | Values cheat sheet, which is dropped. The VP round's values questions use the recruiter's words instead. |
| 2. Larkfield interview process | unavailable | Loop structure. The three rounds come from your message. |
| 3. Larkfield strategy and recent news | unavailable | CO questions grounded in current strategy, none written. Without search there is no source. |
| 4. Interviewer name | n/a | No names were given. |
| 5. Representative JD for the title | unavailable | Would have made the requirement quotes [inferred] instead of [grounded]. |

## Upgrade menu

- The three interviewers' names → persona weights per person, and reverse questions tied to each person's own career path.
- The JD text for this role → F1, F2, F3, F4 and F6 take their requirement wording from the posting, and the requirement quotes become [grounded] instead of your summary.
- Larkfield's published values page, pasted here → a values cheat sheet for Round 3, and C2 and C4 get stories mapped to the values.
- Permission for web search, granted for this session → the research targets above run, and the CO bank gets written.
- The recruiter's note on what Round 2 will test → confirms the panel's mix, and the persona weights follow it.
