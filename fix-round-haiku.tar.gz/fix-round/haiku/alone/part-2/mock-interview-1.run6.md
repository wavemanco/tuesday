Your prep pack is saved as /tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-alone-part-2-rooms-case-1-denied-eedf7a14/921866bc-80c8-4fc4-912d-74e4e5c06f29/scratchpad/northwind_senior-gtm-strategy-lead-emerging-products_interview_pack.md. I built it for a peer round, since your note says Dan is a peer. Web search was refused in this session, so company facts come from your notes only, and the research note is undated.

# Mock-interview pack: Senior GTM Strategy Lead, Emerging Products, Northwind Data

**Candidate:** Priya. **Interviewer:** Dan Kovac, Director of Sales Strategy, a **peer** (same VP). **Round:** single 60-minute conversation.

Built from your JD highlights, your background note, your interviewer note and your research note. No full JD text was supplied, and web search was refused in this session (see Sources), so company facts below are your notes, not checked sources.

Not included, because their conditions do not hold: values cheat sheet (no values round detected), delivery coaching (no assessment supplied), graded deliverables (none declared).

## How to use this pack

Personas describe how a question arrives. Types describe what it scores. Guidance is scaffolding for a spoken answer, not a script. "Your message" in a Provenance cell means your background or note as you sent it.

| Tag | Scores |
|---|---|
| VAL | Past behaviour against values or principles |
| EXP | What Priya actually did in past work, and how credit is attributed |
| JD | A stated requirement of the role |
| CO | Company and strategy knowledge |
| CASE | A live problem: structure and reasoning |

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" (JD highlights) | "9 at a large consumer-tech company in product strategy & ops" (your message) | medium | [grounded] | transferability | Your material shows product strategy and ops, not go-to-market for new product lines. Keep the bridge at that scope: product strategy and ops at a large consumer-tech company. Answer slot: if she set go-to-market for any launch, say which parts and how she decided; if not, say so plainly. |
| F2 | "identify whitespace across land/adopt/expand/renew" (JD highlights) | none given | none | [grounded] | discovery | The material does not show whitespace work. Answer slot: if she has sized or ranked opportunities in any of these motions, say which and what she ranked them by; if not, say so and say what she would check first. |
| F3 | "independent analysis in SQL and Tableau" (JD highlights) | "skilled in SQL/Tableau" (your message) | medium | [grounded] | none | Named tools, no inspected artifact, so expect a request to see the work. Name the tools in her own words; if she has an analysis she built, be ready to walk through one query or dashboard. |
| F4 | "partner-motion design experience required" (JD highlights) | "built a partner-level revenue model used in carrier negotiations" (your message) | medium | [grounded] | transferability | The sentence says a revenue model, used in carrier negotiations. Partner-motion design is not in it. Answer slot: if she set partner terms, incentives or channel rules, say which and how she decided; if not, say so plainly and describe the revenue model. |
| F5 | "strong cross-functional influence" (JD highlights) | "set annual volume targets with cross-org consensus" (your message) | medium | [grounded] | none | Reaches the requirement in role terms. Expect a probe on how the consensus was reached: answer in her own words what it rested on. |
| F6 | "AI experience a plus" (JD highlights) | "uses AI tools daily" (your message) | low | [inferred] | transferability | Daily use is adjacent to building AI products and does not reach it. Say what she uses daily and for what; do not describe AI product work. Derivation: a usage line about her habits, not evidence of product experience. |
| F7 | "enterprise expansion" (your message, company priority) | none given | none | [grounded] | discovery | The material is silent on enterprise B2B sales. Answer slot: if she has worked on enterprise buyers or renewals, say which and what she did; if not, say so and say how she would learn the enterprise motion. |
| F8 | Sales-ops and quota-setting (not a JD line; likely from the interviewer's title, Director of Sales Strategy) | "No classic sales-ops or quota-setting experience" (your message); "set annual volume targets with cross-org consensus" (your message) | none | [grounded] | capability | Plain acknowledgment, from the stated negative: "I haven't done classic sales-ops or quota-setting." Adjacent work, at its own scope: she set annual volume targets with cross-org consensus. Nothing here claims quota work. |
| F9 | Headline result the interviewer will probe (CV metric, plain prose) | "proposed a store-surface change credited with a ~$400M ARR uplift" (your message) | medium | [grounded] | transferability | Consumer store surface, not a B2B data product. Keep the bridge at the quoted scope: she proposed the change, and it was credited with the uplift. The attribution method is an answer slot (A1, A2, E1); nothing in this row supplies one. |

## Prohibited claims

Not coached in any cell of this pack.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned GTM strategy for a product line | Inflated form of F1 | F1's quote at its own scope. The limit stays the pack's observation: the material says product strategy and ops, not go-to-market for a launch. |
| Designed the partner motion or its incentives | Inflated form of F4 | F4's quote at its own scope. The design step is an answer slot only. |
| Built the attribution behind the $400M | Inflated form of F9 | F9's quote at its own scope. The method is an answer slot only. |
| Built or led AI products | Inflated form of F6 | "uses AI tools daily", at its own scope. |
| Ran sales-ops or quota-setting | Negative stated in your message, F8 | "I haven't done classic sales-ops or quota-setting." No slot names a quota process. |

## Reading the interviewer

Public footprint only, and only what you supplied: search was refused, so nothing here is verified.

- **"Relentlessly data-driven"** (his self-description): he will probe inputs and denominators. Bank A is built for this.
- **"Pricing and monetization roles"** (his career spine): case questions tilt toward pricing and unit economics. That is his native language, so C1 and C2 carry the most weight in the CASE material.
- **"One early-stage-startup chapter"**: builder stories land with him. Expect scrappiness probes, and a test of how big-company pace sounds.
- **Mirror opportunities:** none offered. Priya's path ("2 years strategy consulting at a top firm", then consumer tech) and his (pricing, then sales strategy) are not a shared path the material supports, so no mirror is coached.

## Persona table

| Persona | How it shows up here | Likelihood, and why | Counter-strategy | Depth |
|---|---|---|---|---|
| Data-Driven Prober | Asks for the inputs behind every number, two levels deep | High: his self-description, and a peer who runs the numbers | Name the weakest assumption first; say plainly what she does not know about how a figure was counted | 5 |
| Peer Evaluator | Seam questions, reciprocity, credit | High: the peer prior, and his sales-strategy remit overlaps her GTM work | Propose seam principles, not a map of his team; offer what she brings his team | 5 |
| Case/Strategist | Pricing, Compass, bundling | Medium-high: his pricing spine tilts cases toward pricing | Clarify, then objective, segmentation, approach, metrics, risks; use the model she built as the analogue | 4 |
| Skeptic | Quota gap, enterprise gap, consumer-to-B2B transfer | Medium: the quota gap is stated in your message; the enterprise gap is silent in the material | Rehearse the quota objection until it is plain; concede exactly what is missing | 3 |
| Pressure | Time-boxed challenge on the $400M and on the enterprise gap | Medium: the headline number is the likeliest target | Pause, restate, hold the proposal, concede the attribution if she cannot state it | 3 |
| Conversational | Opener and an AI aside | Low: an opener and a casual AI question, both scored | Pre-scripted 90-second arc; name the tools in AI | 2 |
| Values/Behavioral | Not banked | Not plausible here: a peer round, no loop source, and the Generic fallback reads no for values | None | 0 |

## Question banks

### A. Data-Driven Prober (weight: top, 5 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how the ~$400M figure was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (your message) | Start with what she proposed, in her words. Answer slot: if she did any part of the attribution, say how, in her own words; if there was no such step, or it was not hers, say so plainly and return to: she proposed the change, and it was credited with the uplift. Do not offer a sizing method she cannot repeat. | F9 is the defend-the-number case. A data-driven reader tests a headline figure first. EXP, because it tests what was actually hers. |
| A2 | "Which assumption behind that number would you defend least?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (your message) | Name the assumption she is least sure of before he does. Answer slot: if she knows which assumption is weakest, say it; if she does not know how the figure was counted, say so and say what she would ask the team that counted it. | Weakest-assumption move on F9. Naming it first turns a gotcha into a credibility gain. |
| A3 | "If you had to set first-year targets for a new product line with no sales history, what would the first number rest on?" | CASE | [generic] | Structure: what the first-year number depends on, what data would test it early, and the risk if that test fails. Name the one input she would not trust. Makes no claim about her past. | A live problem on the requirement for GTM across two new lines (F1). Dual-tagged JD in rationale; CASE is primary because it is a live problem. |
| A4 | "Your role asks for whitespace across land, adopt, expand and renew. Which of those four would your analysis be least sure about, and what would you check first?" | JD | [grounded] "identify whitespace across land/adopt/expand/renew" (your message) | Pick one motion, name the data she would use, then the weakest input. Answer slot: if she has run whitespace analysis, say which motion and what it showed; if not, say so and say what she would check first. | F2 is a discovery gap. The Prober checks whether the method exists before she describes it. |
| A5 | "Describe one analysis you ran end to end in SQL and Tableau. What did you check before you trusted it?" | EXP | [grounded] "skilled in SQL/Tableau" (your message) | Open prompt: she chooses the instance and tells it from question to recommendation. Selection scaffold: pick an analysis she built and owned. If none comes to mind, say so plainly, then describe the nearest one and what she checked. | F3 is medium confidence with no artifact, so this is where the request to see the work arrives. JD requirement is the theme; EXP is primary because it asks about her own work. |

### B. Peer Evaluator (weight: top, 5 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our teams sit side by side on sales strategy. Where is the seam between us, and what happens when we disagree?" | VAL | [generic] | Propose seam principles, not a map of his team: who owns the price, who owns the motion, who owns the target. On disagreement, take the number to the shared data, not to the org chart. Do not claim to know his team's decisions. | The peer's central probe, in collegial packaging. Makes no claim about his team, so it is generic. JD cross-functional influence is secondary. |
| B2 | "How do you handle credit when work spans teams?" | VAL | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (your message) | Reciprocity: name who did which part of the store change, without inflating anyone's role. Answer slot: if she can say who carried which part, say it; if the credit was assigned rather than earned, say so plainly. | Credit-sharing probe. The store change is the only multi-team story in the material, so it must stay at its quoted scope. |
| B3 | "Partner motion is a requirement for your role. What would you need from my team to make it work?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" (your message) | Reciprocity framing: name the inputs a partner model needs and what she would bring his team. Ask what his team's data looks like; do not assume access. Answer slot: if the carrier model needed inputs from other teams, say which and how she got them; if not, say so plainly. | F4 is the weakest bridge on a required skill, and a peer presses there by asking what she needs. |
| B4 | "Name one decision we would make jointly in your first 90 days, and one you would make alone." | JD | [generic] | Joint decision: a target or a pricing guardrail, with the reason. Solo decision: the GTM plan for the new lines. Makes no claim about her past. | JD cross-functional influence, scored as turf awareness. A standard peer scoping question. |
| B5 | "Tell me about a time you pushed back on a number someone in another org had committed to." | VAL | [grounded] "set annual volume targets with cross-org consensus" (your message) | Open prompt. Selection scaffold: pick a time she disagreed with a number another org had committed to; name the stake, what she said, and how it resolved. If the consensus had no pushback, say so plainly, then describe how it was built and whose number moved. | The nearest material is a consensus; the honest answer may be a consensus with no pushback, and should be said that way. JD cross-functional influence is the theme. |

### C. Case/Strategist (weight: mid-high, 4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Compass is coming. How would you price its first tier, and what would you need to know before you set a number?" | CASE | [grounded] "AI copilot launch ('Compass')" (your message); [grounded] "built a partner-level revenue model used in carrier negotiations" (your message) | Clarify, then objective, segmentation, approach, metrics, risks. Pricing angle: the value metric, who pays, and what a bundle does to the standalone price. Use the model she built as the analogue, and say what it was built to answer. | His pricing spine makes this his native-language case. The first quote is your research note; the second is her own sentence. CASE, with CO in the rationale. |
| C2 | "A much larger platform vendor starts bundling a comparable capability into its suite. What do you do in the first 30 days?" | CO | [grounded] "main competitive threat is bundling by a much larger platform vendor" (your message) | Clarify what the bundle includes and what it costs the buyer. Segment accounts by how much they value the standalone product. Choose price, differentiation or partnering per segment, and name the metric that tells you it is working. Say plainly what you do not yet know, such as the bundle's real price. | The competitive threat from your note, asked as a pricing case. The note is undated, so the row is grounded but its freshness is unverified. |
| C3 | "Enterprise expansion, Compass and profitability all want the same dollar. Which one wins in year one, and how would you show it?" | CO | [grounded] "reaching profitability" (your message); [grounded] "enterprise expansion" (your message) | Trade-off framing: state the objective, name what the other two give up, and one metric to report at 90 days. Make no claim about the company beyond the three priorities. | Tests altitude on the three stated priorities. A trade-off is what an executive-minded peer scores. |
| C4 | "Where would you start on whitespace across land, adopt, expand and renew, and how would you rank what you find?" | CASE | [grounded] "identify whitespace across land/adopt/expand/renew" (your message) | Structure: size, reachability, and confidence in the data. Propose a first cut she could run in a week with SQL and Tableau, and say what would change the ranking. | JD requirement in case form. A4 probes the data side; this one probes the ranking. |

### D. Skeptic (weight: mid, 3 questions; D1 is the highest-ROI prep in this pack)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You've set volume targets, but never run quota. Why should a sales-strategy leader trust you with first-year targets for two new product lines?" | JD | [grounded] "set annual volume targets with cross-org consensus" (your message); [grounded] "No classic sales-ops or quota-setting experience" (your message) | **Highest-ROI prep.** Hold: "I set annual volume targets with cross-org consensus. I haven't done classic sales-ops or quota-setting." Hold through two follow-ups by returning to what the targets were built from. Concede specifically: the quota mechanics, meaning how a volume target is split into individual quotas, are not work she has owned, and she would ask sales ops to own them. Answer slot: if she did any quota mechanics, say which, in her own words; if not, say so plainly. | The most likely objection. The sales-strategy owner sees the quota gap first, and it is stated in the material, so the answer can be rehearsed. Deepest rehearsal in the pack. JD primary; EXP secondary. |
| D2 | "The $400M came from a consumer store surface. Why would a B2B data product respond the same way?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (your message) | Concede the transfer honestly: the number does not carry over; the reasoning may, if she can say what it was. Hold the figure at its consumer scope. Answer slot as in A1. | F9's transferability gap at its sharpest. A peer uses this question to test whether a number is overclaimed. |
| D3 | "Partner motion is a required skill here. Walk me through the partner work closest to it." | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" (your message) | Keep the answer at the model's scope: what it modelled and where it was used. Answer slot: if she designed terms, incentives or channel rules, say which and how she decided; if not, say so plainly, and say how she would build the partner motion from the model. Hold; do not inflate. | F4: design is the gap, and the skeptic asks for the step the model does not reach. |

### E. Pressure (weight: mid, 3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds, no detail: how much of the $400M was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (your message) | Pause, then restate: "I proposed the change, and the uplift was credited to it." Hold through two follow-ups. Concede specifically if true: she cannot give her share without the attribution method. Answer slot: if she knows how it was attributed, say so; if not, say so and say what she would ask. | The pressure form of the attribution probe. The held position is only the proposal, which the quote carries. |
| E2 | "You've spent your career in consumer tech. What does an enterprise renewal need that a consumer-tech background doesn't give you?" | JD | [grounded] "9 at a large consumer-tech company in product strategy & ops" (your message) | Do not deny the gap and do not inflate it. Answer slot: if she has worked on an enterprise renewal in any role, say which; if not, say so plainly and name the one piece of the renewal motion she would learn first. | F7 is a discovery gap on the enterprise priority, asked as a time-boxed challenge. |
| E3 | "Half your budget is gone next quarter. What does the GTM plan for the two new lines drop first?" | CASE | [generic] | Live trade-off with no claim about her past. Structure: the plan's objectives, what each line's first milestone depends on, the cut that hurts least, and the metric she would watch. Say what she would not cut, and why. | Pressure in case form: prioritization under a time box. |

### F. Conversational (weight: low, 2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm" (your message); [grounded] "9 at a large consumer-tech company in product strategy & ops" (your message) | A 90-second arc in three beats, each a quoted sentence: strategy consulting, then product strategy and ops, then the partner model and the volume targets. Stop at the quoted scope. | A casual opener is still scored on communication economy. The arc is pre-scripted so it does not wander. |
| F2 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" (your message) | Name the tools and one concrete daily use. Do not describe building AI products. | The AI-plus requirement, asked casually, is still scored. F6 is the gap. |

**Requirement coverage**

| JD requirement | Questions |
|---|---|
| own GTM strategy for two new product lines | A3, C1, D1, E3 |
| identify whitespace across land/adopt/expand/renew | A4, C4 |
| independent analysis in SQL and Tableau | A5 |
| partner-motion design experience required | B3, D3 |
| strong cross-functional influence | B1, B4, B5 |
| AI experience a plus | F2 |

Company priorities and the research note are covered as well: enterprise expansion (E2, C3), Compass (C1), profitability (C3), the bundling threat (C2). The quota objection is covered by D1. The $400M figure is covered by A1, A2, B2, D2 and E1.

## Grounding brief

From your research note only (no search ran). The note is undated, so treat every line as provisional.

| Term | Source | Freshness |
|---|---|---|
| enterprise expansion | your message | undated |
| AI copilot launch ('Compass') | your message | undated |
| reaching profitability | your message | undated |
| main competitive threat is bundling by a much larger platform vendor | your message | undated |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "You started in pricing and monetization and spent a chapter at an early-stage startup. Which pricing call from those years still shapes how you think at Northwind?" | Ties to his own path, turning an interview into a peer conversation. Shows you researched him, not only the company. |
| R2 | "Where does sales strategy stop and GTM strategy for the two new lines begin?" | Names the seam before he probes it. Shows you expect to work alongside him. |
| R3 | "How is Compass being priced: bundled, add-on, or usage-based, and who decides?" | A pricing question in his language. The answer shows how far the copilot decision has moved. |
| R4 | "If a much larger platform vendor bundled a comparable capability tomorrow, what would the team do first?" | Tests the competitive threat from your note. His answer shows what the team already fears. |
| R5 | "What could a new person do in their first month that would genuinely help your team?" | Reciprocity for a peer. Shows you think about his load, not only your fit. |
| R6 | "Which of enterprise expansion, Compass and profitability is getting the least attention right now?" | An altitude check on the three priorities. It invites a candid answer about trade-offs. |

## Sources

- **Provided documents:** your message (JD highlights, background, interviewer note, research note). The negative "No classic sales-ops or quota-setting experience" is from your message; confirm Priya would say it in those words before she rehearses it.
- **Searches, all refused** (permission not granted in this session): "Northwind Data values operating principles"; "Northwind Data interview process"; "Dan Kovac Director of Sales Strategy Northwind Data"; "Northwind Data Compass AI copilot profitability enterprise expansion". Each returned nothing.

**Research tier: L1, searches 4 of 6, fetches 0 of 2**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Northwind Data values | unavailable | Values cheat sheet, not built, and no values round is detected in any case. Call refused. |
| 2. Northwind Data interview process | unavailable | Loop structure. The loop is unknown, so the Generic archetype applies with flat weights, said plainly. Call refused. |
| 3. Northwind Data strategy and recent news | unavailable | The CO bank rests on your undated note. Call refused. |
| 4. Dan Kovac, Northwind Data | unavailable | The interviewer read rests on your profile only. Call refused. |
| 5. Representative Director-level JD | skipped | Your JD highlights fix the fit snapshot and the JD questions. Full text is in the upgrade menu. |

## Upgrade menu

- **Full JD text:** firms the six requirement quotes, and any mid-list requirement it adds gets its own row.
- **A recruiter note on any announced presentation or take-home:** adds a graded-deliverable build section.
- **Search access** (refused here): values, loop structure, current strategy and his public footprint become checkable. A deeper pass, up to 6 more searches and 2 fetches, takes several minutes; it runs only on your say-so.
- **A dated research note:** C2 and C3 can be marked current.
- **Priya's own account of how the $400M was counted, in her words, outside a drill:** A1, A2, D2 and E1 rest on a grounded answer instead of a slot.
- **Her working-style assessment, if she has one:** adds a delivery-coaching section.

---

Two one-line offers, neither pushed:
- Want a live run? I can play Dan as the Prober on A1 and A2, the attribution questions, and give feedback against those guidance cells.
- I can save a tuesday-dossier.md recording the gaps this prep exposed, for carrying into later sessions.

I can also convert the pack to Word once you've finished iterating on it.

Two questions that would change the pack:
1. Did the recruiter announce any deliverable for this conversation, such as a presentation or take-home?
2. Can you paste the full JD text? If not, the pack stands on the highlights.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: northwind_senior-gtm-strategy-lead-emerging-products_interview_pack.md -----
# Mock-interview pack: Senior GTM Strategy Lead, Emerging Products, Northwind Data

**Candidate:** Priya. **Interviewer:** Dan Kovac, Director of Sales Strategy, a **peer** (same VP). **Round:** single 60-minute conversation.

Built from your JD highlights, your background note, your interviewer note and your research note. No full JD text was supplied, and web search was refused in this session (see Sources), so company facts below are your notes, not checked sources.

Not included, because their conditions do not hold: values cheat sheet (no values round detected), delivery coaching (no assessment supplied), graded deliverables (none declared).

## How to use this pack

Personas describe how a question arrives. Types describe what it scores. Guidance is scaffolding for a spoken answer, not a script. "Your message" in a Provenance cell means your background or note as you sent it.

| Tag | Scores |
|---|---|
| VAL | Past behaviour against values or principles |
| EXP | What Priya actually did in past work, and how credit is attributed |
| JD | A stated requirement of the role |
| CO | Company and strategy knowledge |
| CASE | A live problem: structure and reasoning |

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" (JD highlights) | "9 at a large consumer-tech company in product strategy & ops" (your message) | medium | [grounded] | transferability | Your material shows product strategy and ops, not go-to-market for new product lines. Keep the bridge at that scope: product strategy and ops at a large consumer-tech company. Answer slot: if she set go-to-market for any launch, say which parts and how she decided; if not, say so plainly. |
| F2 | "identify whitespace across land/adopt/expand/renew" (JD highlights) | none given | none | [grounded] | discovery | The material does not show whitespace work. Answer slot: if she has sized or ranked opportunities in any of these motions, say which and what she ranked them by; if not, say so and say what she would check first. |
| F3 | "independent analysis in SQL and Tableau" (JD highlights) | "skilled in SQL/Tableau" (your message) | medium | [grounded] | none | Named tools, no inspected artifact, so expect a request to see the work. Name the tools in her own words; if she has an analysis she built, be ready to walk through one query or dashboard. |
| F4 | "partner-motion design experience required" (JD highlights) | "built a partner-level revenue model used in carrier negotiations" (your message) | medium | [grounded] | transferability | The sentence says a revenue model, used in carrier negotiations. Partner-motion design is not in it. Answer slot: if she set partner terms, incentives or channel rules, say which and how she decided; if not, say so plainly and describe the revenue model. |
| F5 | "strong cross-functional influence" (JD highlights) | "set annual volume targets with cross-org consensus" (your message) | medium | [grounded] | none | Reaches the requirement in role terms. Expect a probe on how the consensus was reached: answer in her own words what it rested on. |
| F6 | "AI experience a plus" (JD highlights) | "uses AI tools daily" (your message) | low | [inferred] | transferability | Daily use is adjacent to building AI products and does not reach it. Say what she uses daily and for what; do not describe AI product work. Derivation: a usage line about her habits, not evidence of product experience. |
| F7 | "enterprise expansion" (your message, company priority) | none given | none | [grounded] | discovery | The material is silent on enterprise B2B sales. Answer slot: if she has worked on enterprise buyers or renewals, say which and what she did; if not, say so and say how she would learn the enterprise motion. |
| F8 | Sales-ops and quota-setting (not a JD line; likely from the interviewer's title, Director of Sales Strategy) | "No classic sales-ops or quota-setting experience" (your message); "set annual volume targets with cross-org consensus" (your message) | none | [grounded] | capability | Plain acknowledgment, from the stated negative: "I haven't done classic sales-ops or quota-setting." Adjacent work, at its own scope: she set annual volume targets with cross-org consensus. Nothing here claims quota work. |
| F9 | Headline result the interviewer will probe (CV metric, plain prose) | "proposed a store-surface change credited with a ~$400M ARR uplift" (your message) | medium | [grounded] | transferability | Consumer store surface, not a B2B data product. Keep the bridge at the quoted scope: she proposed the change, and it was credited with the uplift. The attribution method is an answer slot (A1, A2, E1); nothing in this row supplies one. |

## Prohibited claims

Not coached in any cell of this pack.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned GTM strategy for a product line | Inflated form of F1 | F1's quote at its own scope. The limit stays the pack's observation: the material says product strategy and ops, not go-to-market for a launch. |
| Designed the partner motion or its incentives | Inflated form of F4 | F4's quote at its own scope. The design step is an answer slot only. |
| Built the attribution behind the $400M | Inflated form of F9 | F9's quote at its own scope. The method is an answer slot only. |
| Built or led AI products | Inflated form of F6 | "uses AI tools daily", at its own scope. |
| Ran sales-ops or quota-setting | Negative stated in your message, F8 | "I haven't done classic sales-ops or quota-setting." No slot names a quota process. |

## Reading the interviewer

Public footprint only, and only what you supplied: search was refused, so nothing here is verified.

- **"Relentlessly data-driven"** (his self-description): he will probe inputs and denominators. Bank A is built for this.
- **"Pricing and monetization roles"** (his career spine): case questions tilt toward pricing and unit economics. That is his native language, so C1 and C2 carry the most weight in the CASE material.
- **"One early-stage-startup chapter"**: builder stories land with him. Expect scrappiness probes, and a test of how big-company pace sounds.
- **Mirror opportunities:** none offered. Priya's path ("2 years strategy consulting at a top firm", then consumer tech) and his (pricing, then sales strategy) are not a shared path the material supports, so no mirror is coached.

## Persona table

| Persona | How it shows up here | Likelihood, and why | Counter-strategy | Depth |
|---|---|---|---|---|
| Data-Driven Prober | Asks for the inputs behind every number, two levels deep | High: his self-description, and a peer who runs the numbers | Name the weakest assumption first; say plainly what she does not know about how a figure was counted | 5 |
| Peer Evaluator | Seam questions, reciprocity, credit | High: the peer prior, and his sales-strategy remit overlaps her GTM work | Propose seam principles, not a map of his team; offer what she brings his team | 5 |
| Case/Strategist | Pricing, Compass, bundling | Medium-high: his pricing spine tilts cases toward pricing | Clarify, then objective, segmentation, approach, metrics, risks; use the model she built as the analogue | 4 |
| Skeptic | Quota gap, enterprise gap, consumer-to-B2B transfer | Medium: the quota gap is stated in your message; the enterprise gap is silent in the material | Rehearse the quota objection until it is plain; concede exactly what is missing | 3 |
| Pressure | Time-boxed challenge on the $400M and on the enterprise gap | Medium: the headline number is the likeliest target | Pause, restate, hold the proposal, concede the attribution if she cannot state it | 3 |
| Conversational | Opener and an AI aside | Low: an opener and a casual AI question, both scored | Pre-scripted 90-second arc; name the tools in AI | 2 |
| Values/Behavioral | Not banked | Not plausible here: a peer round, no loop source, and the Generic fallback reads no for values | None | 0 |

## Question banks

### A. Data-Driven Prober (weight: top, 5 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how the ~$400M figure was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (your message) | Start with what she proposed, in her words. Answer slot: if she did any part of the attribution, say how, in her own words; if there was no such step, or it was not hers, say so plainly and return to: she proposed the change, and it was credited with the uplift. Do not offer a sizing method she cannot repeat. | F9 is the defend-the-number case. A data-driven reader tests a headline figure first. EXP, because it tests what was actually hers. |
| A2 | "Which assumption behind that number would you defend least?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (your message) | Name the assumption she is least sure of before he does. Answer slot: if she knows which assumption is weakest, say it; if she does not know how the figure was counted, say so and say what she would ask the team that counted it. | Weakest-assumption move on F9. Naming it first turns a gotcha into a credibility gain. |
| A3 | "If you had to set first-year targets for a new product line with no sales history, what would the first number rest on?" | CASE | [generic] | Structure: what the first-year number depends on, what data would test it early, and the risk if that test fails. Name the one input she would not trust. Makes no claim about her past. | A live problem on the requirement for GTM across two new lines (F1). Dual-tagged JD in rationale; CASE is primary because it is a live problem. |
| A4 | "Your role asks for whitespace across land, adopt, expand and renew. Which of those four would your analysis be least sure about, and what would you check first?" | JD | [grounded] "identify whitespace across land/adopt/expand/renew" (your message) | Pick one motion, name the data she would use, then the weakest input. Answer slot: if she has run whitespace analysis, say which motion and what it showed; if not, say so and say what she would check first. | F2 is a discovery gap. The Prober checks whether the method exists before she describes it. |
| A5 | "Describe one analysis you ran end to end in SQL and Tableau. What did you check before you trusted it?" | EXP | [grounded] "skilled in SQL/Tableau" (your message) | Open prompt: she chooses the instance and tells it from question to recommendation. Selection scaffold: pick an analysis she built and owned. If none comes to mind, say so plainly, then describe the nearest one and what she checked. | F3 is medium confidence with no artifact, so this is where the request to see the work arrives. JD requirement is the theme; EXP is primary because it asks about her own work. |

### B. Peer Evaluator (weight: top, 5 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our teams sit side by side on sales strategy. Where is the seam between us, and what happens when we disagree?" | VAL | [generic] | Propose seam principles, not a map of his team: who owns the price, who owns the motion, who owns the target. On disagreement, take the number to the shared data, not to the org chart. Do not claim to know his team's decisions. | The peer's central probe, in collegial packaging. Makes no claim about his team, so it is generic. JD cross-functional influence is secondary. |
| B2 | "How do you handle credit when work spans teams?" | VAL | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (your message) | Reciprocity: name who did which part of the store change, without inflating anyone's role. Answer slot: if she can say who carried which part, say it; if the credit was assigned rather than earned, say so plainly. | Credit-sharing probe. The store change is the only multi-team story in the material, so it must stay at its quoted scope. |
| B3 | "Partner motion is a requirement for your role. What would you need from my team to make it work?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" (your message) | Reciprocity framing: name the inputs a partner model needs and what she would bring his team. Ask what his team's data looks like; do not assume access. Answer slot: if the carrier model needed inputs from other teams, say which and how she got them; if not, say so plainly. | F4 is the weakest bridge on a required skill, and a peer presses there by asking what she needs. |
| B4 | "Name one decision we would make jointly in your first 90 days, and one you would make alone." | JD | [generic] | Joint decision: a target or a pricing guardrail, with the reason. Solo decision: the GTM plan for the new lines. Makes no claim about her past. | JD cross-functional influence, scored as turf awareness. A standard peer scoping question. |
| B5 | "Tell me about a time you pushed back on a number someone in another org had committed to." | VAL | [grounded] "set annual volume targets with cross-org consensus" (your message) | Open prompt. Selection scaffold: pick a time she disagreed with a number another org had committed to; name the stake, what she said, and how it resolved. If the consensus had no pushback, say so plainly, then describe how it was built and whose number moved. | The nearest material is a consensus; the honest answer may be a consensus with no pushback, and should be said that way. JD cross-functional influence is the theme. |

### C. Case/Strategist (weight: mid-high, 4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Compass is coming. How would you price its first tier, and what would you need to know before you set a number?" | CASE | [grounded] "AI copilot launch ('Compass')" (your message); [grounded] "built a partner-level revenue model used in carrier negotiations" (your message) | Clarify, then objective, segmentation, approach, metrics, risks. Pricing angle: the value metric, who pays, and what a bundle does to the standalone price. Use the model she built as the analogue, and say what it was built to answer. | His pricing spine makes this his native-language case. The first quote is your research note; the second is her own sentence. CASE, with CO in the rationale. |
| C2 | "A much larger platform vendor starts bundling a comparable capability into its suite. What do you do in the first 30 days?" | CO | [grounded] "main competitive threat is bundling by a much larger platform vendor" (your message) | Clarify what the bundle includes and what it costs the buyer. Segment accounts by how much they value the standalone product. Choose price, differentiation or partnering per segment, and name the metric that tells you it is working. Say plainly what you do not yet know, such as the bundle's real price. | The competitive threat from your note, asked as a pricing case. The note is undated, so the row is grounded but its freshness is unverified. |
| C3 | "Enterprise expansion, Compass and profitability all want the same dollar. Which one wins in year one, and how would you show it?" | CO | [grounded] "reaching profitability" (your message); [grounded] "enterprise expansion" (your message) | Trade-off framing: state the objective, name what the other two give up, and one metric to report at 90 days. Make no claim about the company beyond the three priorities. | Tests altitude on the three stated priorities. A trade-off is what an executive-minded peer scores. |
| C4 | "Where would you start on whitespace across land, adopt, expand and renew, and how would you rank what you find?" | CASE | [grounded] "identify whitespace across land/adopt/expand/renew" (your message) | Structure: size, reachability, and confidence in the data. Propose a first cut she could run in a week with SQL and Tableau, and say what would change the ranking. | JD requirement in case form. A4 probes the data side; this one probes the ranking. |

### D. Skeptic (weight: mid, 3 questions; D1 is the highest-ROI prep in this pack)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You've set volume targets, but never run quota. Why should a sales-strategy leader trust you with first-year targets for two new product lines?" | JD | [grounded] "set annual volume targets with cross-org consensus" (your message); [grounded] "No classic sales-ops or quota-setting experience" (your message) | **Highest-ROI prep.** Hold: "I set annual volume targets with cross-org consensus. I haven't done classic sales-ops or quota-setting." Hold through two follow-ups by returning to what the targets were built from. Concede specifically: the quota mechanics, meaning how a volume target is split into individual quotas, are not work she has owned, and she would ask sales ops to own them. Answer slot: if she did any quota mechanics, say which, in her own words; if not, say so plainly. | The most likely objection. The sales-strategy owner sees the quota gap first, and it is stated in the material, so the answer can be rehearsed. Deepest rehearsal in the pack. JD primary; EXP secondary. |
| D2 | "The $400M came from a consumer store surface. Why would a B2B data product respond the same way?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (your message) | Concede the transfer honestly: the number does not carry over; the reasoning may, if she can say what it was. Hold the figure at its consumer scope. Answer slot as in A1. | F9's transferability gap at its sharpest. A peer uses this question to test whether a number is overclaimed. |
| D3 | "Partner motion is a required skill here. Walk me through the partner work closest to it." | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" (your message) | Keep the answer at the model's scope: what it modelled and where it was used. Answer slot: if she designed terms, incentives or channel rules, say which and how she decided; if not, say so plainly, and say how she would build the partner motion from the model. Hold; do not inflate. | F4: design is the gap, and the skeptic asks for the step the model does not reach. |

### E. Pressure (weight: mid, 3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds, no detail: how much of the $400M was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (your message) | Pause, then restate: "I proposed the change, and the uplift was credited to it." Hold through two follow-ups. Concede specifically if true: she cannot give her share without the attribution method. Answer slot: if she knows how it was attributed, say so; if not, say so and say what she would ask. | The pressure form of the attribution probe. The held position is only the proposal, which the quote carries. |
| E2 | "You've spent your career in consumer tech. What does an enterprise renewal need that a consumer-tech background doesn't give you?" | JD | [grounded] "9 at a large consumer-tech company in product strategy & ops" (your message) | Do not deny the gap and do not inflate it. Answer slot: if she has worked on an enterprise renewal in any role, say which; if not, say so plainly and name the one piece of the renewal motion she would learn first. | F7 is a discovery gap on the enterprise priority, asked as a time-boxed challenge. |
| E3 | "Half your budget is gone next quarter. What does the GTM plan for the two new lines drop first?" | CASE | [generic] | Live trade-off with no claim about her past. Structure: the plan's objectives, what each line's first milestone depends on, the cut that hurts least, and the metric she would watch. Say what she would not cut, and why. | Pressure in case form: prioritization under a time box. |

### F. Conversational (weight: low, 2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm" (your message); [grounded] "9 at a large consumer-tech company in product strategy & ops" (your message) | A 90-second arc in three beats, each a quoted sentence: strategy consulting, then product strategy and ops, then the partner model and the volume targets. Stop at the quoted scope. | A casual opener is still scored on communication economy. The arc is pre-scripted so it does not wander. |
| F2 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" (your message) | Name the tools and one concrete daily use. Do not describe building AI products. | The AI-plus requirement, asked casually, is still scored. F6 is the gap. |

**Requirement coverage**

| JD requirement | Questions |
|---|---|
| own GTM strategy for two new product lines | A3, C1, D1, E3 |
| identify whitespace across land/adopt/expand/renew | A4, C4 |
| independent analysis in SQL and Tableau | A5 |
| partner-motion design experience required | B3, D3 |
| strong cross-functional influence | B1, B4, B5 |
| AI experience a plus | F2 |

Company priorities and the research note are covered as well: enterprise expansion (E2, C3), Compass (C1), profitability (C3), the bundling threat (C2). The quota objection is covered by D1. The $400M figure is covered by A1, A2, B2, D2 and E1.

## Grounding brief

From your research note only (no search ran). The note is undated, so treat every line as provisional.

| Term | Source | Freshness |
|---|---|---|
| enterprise expansion | your message | undated |
| AI copilot launch ('Compass') | your message | undated |
| reaching profitability | your message | undated |
| main competitive threat is bundling by a much larger platform vendor | your message | undated |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "You started in pricing and monetization and spent a chapter at an early-stage startup. Which pricing call from those years still shapes how you think at Northwind?" | Ties to his own path, turning an interview into a peer conversation. Shows you researched him, not only the company. |
| R2 | "Where does sales strategy stop and GTM strategy for the two new lines begin?" | Names the seam before he probes it. Shows you expect to work alongside him. |
| R3 | "How is Compass being priced: bundled, add-on, or usage-based, and who decides?" | A pricing question in his language. The answer shows how far the copilot decision has moved. |
| R4 | "If a much larger platform vendor bundled a comparable capability tomorrow, what would the team do first?" | Tests the competitive threat from your note. His answer shows what the team already fears. |
| R5 | "What could a new person do in their first month that would genuinely help your team?" | Reciprocity for a peer. Shows you think about his load, not only your fit. |
| R6 | "Which of enterprise expansion, Compass and profitability is getting the least attention right now?" | An altitude check on the three priorities. It invites a candid answer about trade-offs. |

## Sources

- **Provided documents:** your message (JD highlights, background, interviewer note, research note). The negative "No classic sales-ops or quota-setting experience" is from your message; confirm Priya would say it in those words before she rehearses it.
- **Searches, all refused** (permission not granted in this session): "Northwind Data values operating principles"; "Northwind Data interview process"; "Dan Kovac Director of Sales Strategy Northwind Data"; "Northwind Data Compass AI copilot profitability enterprise expansion". Each returned nothing.

**Research tier: L1, searches 4 of 6, fetches 0 of 2**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Northwind Data values | unavailable | Values cheat sheet, not built, and no values round is detected in any case. Call refused. |
| 2. Northwind Data interview process | unavailable | Loop structure. The loop is unknown, so the Generic archetype applies with flat weights, said plainly. Call refused. |
| 3. Northwind Data strategy and recent news | unavailable | The CO bank rests on your undated note. Call refused. |
| 4. Dan Kovac, Northwind Data | unavailable | The interviewer read rests on your profile only. Call refused. |
| 5. Representative Director-level JD | skipped | Your JD highlights fix the fit snapshot and the JD questions. Full text is in the upgrade menu. |

## Upgrade menu

- **Full JD text:** firms the six requirement quotes, and any mid-list requirement it adds gets its own row.
- **A recruiter note on any announced presentation or take-home:** adds a graded-deliverable build section.
- **Search access** (refused here): values, loop structure, current strategy and his public footprint become checkable. A deeper pass, up to 6 more searches and 2 fetches, takes several minutes; it runs only on your say-so.
- **A dated research note:** C2 and C3 can be marked current.
- **Priya's own account of how the $400M was counted, in her words, outside a drill:** A1, A2, D2 and E1 rest on a grounded answer instead of a slot.
- **Her working-style assessment, if she has one:** adds a delivery-coaching section.
