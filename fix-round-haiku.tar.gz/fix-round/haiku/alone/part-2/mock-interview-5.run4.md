Your prep pack is saved as `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-alone-part-2-rooms-case-5-denied-f1f39a9e/56d616a4-f4e0-4aa2-ac48-608cbe078dc1/scratchpad/kelverton_rail_senior_partnerships_manager_interview_pack.md`.

Three things to know before you open it:

- **Web research was refused**, so the pack has no company values, strategy, or information on Deepa or Ross. Every requirement comes from the recruiter's email, and the POV can't be checked against the internal report until you share its headlines.
- **The biggest risk is the £4M.** Nothing you gave me says how it was counted. Questions A1 and A2 are built so you say what you know and stop there. If you can't explain the method in your own words, say that rather than reconstructing one on the spot.
- **Ross's quota question is near certain (B1).** Hold "I've carried influenced revenue, not a direct quota" through two follow-ups, then concede specifically what you'd learn first.

If you have the time, the best use of the 90 minutes on the POV is to pick one thesis, write its concession first, and then time yourself out loud.

Would you like me to play the Skeptic on B1, the question the pack names as highest-ROI prep? I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

Two questions that would change the pack:

1. Can you paste the job description, or its requirements list? Without it, the requirements here are only the recruiter's words.
2. Have you confirmed your right to work in the UK, and the office or hybrid days Kelverton expects? Neither is in what you've sent, and if either is a constraint, the pack needs to surface it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: kelverton_rail_senior_partnerships_manager_interview_pack.md -----
# Interview prep pack: Senior Partnerships Manager, Kelverton Rail

Second round, Tuesday. Panel: Deepa (VP Partnerships, your future manager) and Ross (Commercial Director). 60 minutes: the first 15 are a spoken point of view on operator partnerships over 18 months; the rest is Q&A, with Ross pressing on commercials.

Built from your message and the recruiter's words you quoted in it. No JD, CV or internal strategy report was available to me, and web research was refused, so every requirement below comes from the recruiter's email and every company fact is absent. Built at the default research tier, with no research run.

## 1. How to use + type key

Personas are how a question arrives. Types are what is being scored:

- **VAL**: behavioural / values alignment (not used here: no published values in hand)
- **EXP**: your own past work, probed for what was actually yours
- **JD**: stated role requirements
- **CO**: company and strategy knowledge
- **CASE**: a live problem from the role

Guidance is scaffolding, not a script. Say it in your own words, and say it in about 90 seconds.

## 2. Prep triage (4 hours)

1. **POV talk track, 90 min.** Pick one thesis from section 5, write three spoken beats, and rehearse aloud twice against a timer at 15 minutes. Start with D1 and D2.
2. **Ross's commercials, 75 min.** Drill A1, A2 and B1 out loud. Before you rehearse, write down what you actually know about how the £4M figure was counted. If the honest answer is "not much", the drill is to say that cleanly.
3. **Gap lines, 30 min.** F3 and F4. Be able to say "I haven't" in one clean sentence, then give your plan. Do not add a story to soften it.
4. **Deepa's management questions, 30 min.** D3, D4 and D6.
5. **Reverse questions, 15 min.** Section 11. Choose three you would genuinely want the answers to.

Everything else is insurance.

## 3. Fit snapshot

Requirements are the recruiter's own words (no JD). Evidence is quoted from your message only; there is no CV text to quote.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "where you'd take our operator partnerships over the next 18 months" (recruiter email, quoted in your message) | "took it from 6 partners to 40, roughly £4M of influenced revenue" (your message) | medium | [grounded] | transferability | The material shows channel partner growth at a payments company, not operator partnerships. Say that scope yourself: "At the payments company I grew the ISV channel from six partners to forty." Answer slot: if you set any part of the partner strategy there, say which and how you decided; if you did not, say so and describe how you ran the channel. |
| F2 | "Please land on what it means for the operators themselves" (recruiter email, quoted in your message) | "so I know the operator world from the other side" (your message, after "bus and light rail network planning") | medium | [grounded] | transferability | The operator knowledge comes from bus and light-rail network planning, not train operating companies. Keep that scope. Do not present it as knowledge of how TOCs run. |
| F3 | "Ross will push on commercials" (your message) | "roughly £4M of influenced revenue" and "never carried a direct quota, only influenced revenue" (both your message) | medium | [grounded] | capability | Direct quota is a stated absence, so the words are yours: "I've never carried a direct quota." The bridge is the influenced revenue, at its own scope. Answer slot: how that figure was counted, and what part was yours. |
| F4 | Company sells "scheduling software to train operating companies" (your message) | "Never sold into rail specifically" (your message) | none | [grounded] | capability | A stated absence. Words: "I haven't sold into rail." Then how you would learn it, said as a plan and never as a past. |
| F5 | Location and office or hybrid pattern, right to work (role-family requirement, not in any input) | none given | none | [generic] | hard_gate | Your material does not establish this. The one question on it is in this message. |
| F6 | "Senior Partnerships Manager" (recruiter email, quoted in your message) | "9 years in partnerships" (your message) | medium | [grounded] | none | The quote reaches the seniority in role-relevant terms. Expect a probe on what the nine years covered. |

Limits on the snapshot: the influenced revenue figure has no stated method anywhere in the inputs, so every number-based answer below is a slot, not a claim.

## 4. Prohibited claims

Built locally from the snapshot. Each entry is a stretched form of a sentence you did say, or a claim you stated the absence of.

| Not coached | Basis | Honest form |
|---|---|---|
| Managed or grew operator partnerships | Inflated form of F1; your material is channel partners at a payments company | F1's quote at its own scope. The pack's observation: the material says channel, not operator. |
| Carried a quota, or hit one | Inflated form of F3 | "I've never carried a direct quota." Nothing about targets you did or did not hit. |
| Knows how train operating companies run or buy | Inflated form of F2 | F2's quote at its own scope: bus and light-rail planning, the other side of the table. |
| Sold into rail, or has rail contacts | Stated negative, F4 | "I haven't sold into rail." No slot. |
| The method behind the £4M figure | Not in any input; a figure the candidate gave raises the defend-the-number slots only | Answer slot in A1 and A2. Never an attribution model, baseline or assumption supplied for you. |

## 5. Graded deliverable: the 15-minute POV

The recruiter announced this as a graded deliverable: no slides, a short spoken point of view on operator partnerships over the next 18 months, landing on what it means for operators.

**Facts to build on**, each quoted exactly from its fit-snapshot evidence cell:
- F1: "took it from 6 partners to 40, roughly £4M of influenced revenue" (your message). Use it for the partner-scaling experience, scoped to the payments channel.
- F2: "so I know the operator world from the other side" (your message). Use it for why you read the operator's side of a plan. Do not extend it to TOCs.

**Theses (pick one; each has a mandatory concession):**

- **T1. Plan partnerships around the operator's planning cycle, not your release cycle.** Concession: I don't know how TOC planning cycles interact with Kelverton's product, so I'd test that before committing to anything.
- **T2. Move from referral partners to a few shared outcome commitments with operators.** Concession: that adds commercial risk, and I haven't seen Kelverton's margin or contract structure.
- **T3. Use delivery partners to carry the operator relationship, leaving the sales relationship with Kelverton.** Concession: this could dilute the operator relationship, and I'd want evidence of that before shifting it.

**Differentiation.** The likely consensus answer is "widen the partner network". I could not check this against the internal strategy report, because I do not have it. Before Tuesday, read its headline recommendations and make sure the POV is not a rewording of them. If the report's top recommendation is the one you would argue against, say so and give the reason. That is the judgement the panel is scoring.

**Close.** Land on what changes for an operator's planning team within 18 months, in their terms. Keep it to what you would need to see, not a promised outcome.

**Length.** About 15 minutes spoken: thesis (2 min), two reasons plus concession (6 min), what it means for operators (4 min), and a 3-minute stop for questions.

## 6. Persona weights

Panel: blend of the two members' relationships. Deepa is the hiring manager and future manager. Ross is the commercial director, so I've weighted him as a prober and pressure interviewer; that is an inference from title, not from anything he has published.

| Persona | Who | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|---|
| Data-Driven Prober | Ross | Asks how the £4M was counted, what you own of it | High. Influenced revenue invites attribution probes, and he is the commercial owner | Know what you can and cannot say about the figure; name the weakest assumption before he does |
| Pressure | Ross | Challenges "you've never carried a quota" | Medium-high. Your recruiter flagged that he will push on commercials | Hold the influenced-revenue position through two follow-ups, then concede the quota gap specifically |
| Case / Strategist | Deepa | The POV itself, then live problems on her roadmap | High. A hiring manager is buying judgement on the role's actual work | Clarify the operator's problem before proposing a solution |
| Skeptic | Deepa | Rail gap, the first day, why leave a payments channel | High. Her job is to derisk the hire | Bridge only from what you stated; say the limit plainly; give a ramp plan as a plan |
| Conversational | Both | Opener and the journey question | Medium. Casual register, still scored | Ninety-second arc, prepared |
| Peer Evaluator | n/a | Seam-splitting between teams | Low. Neither member is a peer | Not rehearsed |

Values / Behavioural: not weighted. No published values were in hand and no values round was detected, so the values section is omitted.

## 7. Question banks

Ordered by weight within each persona. Question types are single tokens.

### Ross (Prober, Pressure): 7 questions

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how the £4M of influenced revenue was counted." | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" (your message) | Defend-the-number slot. Say how it was counted, in your words. Name the assumption you would defend least. Answer slot: if you know the attribution rules, say them; if you did not own them, say so plainly. Never supply a method. | F1 and F3. This is the most likely probe on the number, and an explanation you cannot repeat under a second question is worse than none. |
| A2 | "Which part of that £4M did you own yourself?" | EXP | [grounded] "running the ISV channel" (your message); "took it from 6 partners to 40, roughly £4M of influenced revenue" (your message) | Name what was yours from the channel you ran. Answer slot: the partners you personally signed or grew, if you can name them; if the figure was the channel's, say so. | F3. Attribution honesty is what this probe tests. |
| B1 | "You've never carried a quota. Why should we trust you with ours?" | JD | [grounded] "never carried a direct quota, only influenced revenue" (your message) | Hold-then-concede. Hold: "I've carried influenced revenue, not a direct quota." Hold through two follow-ups. Concede specifically: you have not carried quota mechanics, and say what you would learn first. Never fold on the revenue record. | F3 is the pack's highest-ROI prep: this objection is near certain. The held position is one the quote carries. |
| B2 | "Sixty seconds: why would an operator pay for a partnership instead of buying more of our direct sales?" | CASE | [generic] | Structure: what the operator buys, what the partnership adds, what it costs them to change. Say what you do not know about Kelverton's pricing or margin. | CASE question on the commercial logic of the POV. Pricing is not in any input, so the guidance cannot assert it. |
| B3 | "You've worked on bus and light rail. What do you know about how train operating companies buy?" | EXP | [grounded] "so I know the operator world from the other side" (your message) | Scope the claim: bus and light-rail planning. Name what you would need to learn about TOC buying. Do not claim TOC knowledge. | F2. The interviewer will test where the adjacency stops. |
| C1 | "How would you structure an operator deal so that Kelverton gets paid before the operator sees the benefit?" | CASE | [generic] | Structure: the payment trigger, the risk each side carries, and what you would test first. Name what you would need to see in Kelverton's contract structure. | Commercial logic on the POV's T2. Generic because no contract data was supplied. |
| C2 | "Which operator deal would you walk away from, and what would make you do it?" | CASE | [generic] | Name a condition, not a list. Say what you would need before walking away, and who you would tell. | Ross will test whether you say no on commercial grounds. Generic. |

### Deepa (Case, Skeptic): 7 questions

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Talk us through where you'd take our operator partnerships over the next 18 months." | CO | [grounded] "where you'd take our operator partnerships over the next 18 months" (recruiter email, quoted in your message) | The graded POV in section 5. Lead with one thesis, its reasons, its concession, and what it means for operators. | Announced deliverable. The question is the recruiter's own line, so it presupposes nothing about you. |
| D2 | "What would you need to know about an operator before proposing a partnership?" | CASE | [generic] | Structure: the operator's planning constraints, its existing suppliers, its budget owner, and what it would measure. Name what you do not know about TOCs yet. | Case question on the operator-side lens in F2. Generic, because the role's operator context is not in any input. |
| D3 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never sold into rail specifically" (your message) | Plain acknowledgment: "I haven't sold into rail." Then the ramp plan, as a plan. No slot about past rail work. | F4. The interviewer will ask this in some form; the honest answer is ready before the probe. |
| D4 | "Why leave a payments channel for rail, and why now?" | JD | [generic] | Selection scaffold: give the reason in your own words. Your material does not show it, so the pack supplies no reason. If there is no single reason, say so plainly. | F6 and F1 leave motivation unstated. Persona stem for the Skeptic. |
| D5 | "How would you manage a partner that wants a different outcome from you than you want from it?" | JD | [generic] | Structure: name the disagreement, the decision it forces, and what you would put in writing. | Deepa's managing-and-partnering question. Generic; no team or partner is described in the inputs. |
| D6 | "Your partner count went from six to forty. What did the other thirty-four need that the first six didn't?" | EXP | [grounded] "took it from 6 partners to 40" (your message) | Answer slot: name what changed in how you worked with the later partners, if anything; if the scaling came from others, say so. | F1. Premised on the quote's scope only. |
| D7 | "Tell me about a partner relationship that went wrong. What did you do?" | EXP | [generic] | Selection scaffold: pick a real one with a named stake. If no such relationship comes to mind, say so plainly, then give the nearest thing you have. | Open prompt. Probes the managing trait, not a fact about your past. |

### Opener (Conversational): 1 question

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| O1 | "So, walk us through the journey." | JD | [grounded] "9 years in partnerships" and "took it from 6 partners to 40, roughly £4M of influenced revenue" (your message) | A 90-second arc: nine years in partnerships, the payments channel and its scale, the transport work that gives you the operator view, and why this role now. Use only those sentences. | F6 and F1. Casual register, scored. |

Total: 15 questions. The coverage rule asks for 18–26. The inputs are thin, and padding with questions not grounded in the recruiter's words would only add generic prep. Two more can be added once the JD is supplied.

### Requirement coverage

| Stated requirement (source) | Covered by |
|---|---|
| Operator partnership strategy, 18 months (recruiter email) | D1, D2, C1 |
| What it means for operators (recruiter email) | D2, B3 |
| Commercials (your note on Ross) | A1, A2, B1, B2, C1, C2 |
| Rail / TOC selling (company description) | D3, B3 |
| Managing and partnering (future manager) | D5, D6, D7 |
| Seniority (job title) | O1, D6 |
| Motivation | D4 |

This covers the recruiter's words only. A JD would add rows.

## 8. Reverse questions

Five, each with why it lands.

1. "What does a successful first 18 months look like here, in operator terms?" Why it lands: it hands the POV's close back to Deepa and shows you were listening for what she values.
2. "Which operator relationship would you most like to deepen, and what is stopping it?" Why it lands: it surfaces the real pipeline and the real blocker in one answer.
3. "How is partner-influenced revenue counted here, and who owns that definition?" Why it lands: it is the number Ross will probe, and asking it first shows you would check the figure before defending it.
4. "What have the last two partnership hires found hardest?" Why it lands: an honest question about the failure mode, which Deepa can answer from experience.
5. "Where do the commercial and product teams disagree about operators?" Why it lands: a seam question that shows you already see the operator side as contested terrain.

Not required here: a profile-tied question (no public footprint was retrieved) and a peer reciprocity question (neither member is a peer).

## 9. Delivery coaching

Dropped: no working-style assessment was provided.

## 10. Sources

Provided documents: your message (including the recruiter's email quoted in it). The internal market report was not provided to me in full and was not used; the POV's differentiation therefore cannot be checked against it.

Searches attempted: five, all refused at the permission step, so no URLs came back.
- "Kelverton Rail company values": refused
- "Kelverton Rail scheduling software train operating companies": refused
- "Deepa VP Partnerships Kelverton Rail": refused
- "Ross Commercial Director Kelverton Rail": refused
- "Senior Partnerships Manager rail technology train operating company job description": refused

Research tier: L1, with no results

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Kelverton Rail values | unavailable | Values section, which would have been included if values were found. Omitted: no values in hand. |
| 2. Kelverton Rail interview process | unavailable | Loop structure and persona weights. Weights here are inferred from the panel's titles. |
| 3. Kelverton Rail strategy / recent news | unavailable | Grounding brief, and the current framing of operator partnerships. The POV's differentiation is unchecked as a result. |
| 4. Interviewer names (Deepa, Ross) | unavailable | The interviewer read: career pattern and public talks. Its absence leaves the personas title-inferred. |
| 5. Representative JD | unavailable | Requirements beyond the recruiter's words. Fact-checked by nothing. |

## 11. Upgrade menu

- Your job description, or its requirements list → turns the requirement rows from recruiter words into quoted JD lines, and adds two or three JD-tagged questions
- The strategy report's headline recommendations → lets the POV's differentiation be checked against the consensus answer, and sharpens the Case persona
- Your CV → quotes the sentences the question banks and fit snapshot draw on, in place of the message
- Web research, once permitted → company values, strategy, interviewer footprint, representative JD
- The recruiter's prep email, if it has more detail on the POV → confirms the length and format of the graded deliverable
