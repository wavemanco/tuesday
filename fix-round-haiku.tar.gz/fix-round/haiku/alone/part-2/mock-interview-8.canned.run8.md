Your prep pack is saved at /tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-alone-part-2-rooms-case-8-canned-4b0cdff5/0243dc66-d274-47f4-907a-a9b40f414c57/scratchpad/ashgrove_member_experience_lead_interview_pack.md. I built it on the three rounds in your recruiter's email, with no interviewer names and no web searches, because your values, the loop and the strategy summary were already in your message.

The biggest gap is the contact centre. You've never worked in one, and the JD asks for complaints across branches and contact centre. That's B1 in the pack, and it's the one to rehearse first. The second is presenting above regional level (B3). Neither answer should claim experience you don't have.

Say the word and I'll run the 20-minute escalation case as a live drill, using C1's time split.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove_member_experience_lead_interview_pack.md -----
# Member Experience Lead, Ashgrove Credit Union: interview prep pack for Dara

**Interviews: 20 November 2026**

| Round | Length | Who | Relationship | Focus |
|---|---|---|---|---|
| 1. Recruiter screen | 30 min | Recruiter | Screen | Logistics, motivation, knockout checks |
| 2. Behavioural | 45 min | Head of Member Services | Your future manager | Mostly behavioural |
| 3. Panel | 60 min | Two branch managers | Peers on the seam | 20-minute complaint-escalation case; scored on the four values |

Interviewers are not named yet. The pack is built on the relationships above. Research: none run; your values, the recruiter's loop and the strategy brief were all in your message (see Sources).

## 2. How to use, and the type key

- **Personas** describe how a question arrives. **Types** describe what is being scored.
- **VAL** behavioural and values alignment. **EXP** experience deep-dive. **JD** role and JD-driven. **CO** company and strategy. **CASE** live problem.
- **Provenance labels.** `[grounded]` means traceable to your message, the JD, the values page or the strategy summary you sent. `[generic]` means a role-family pattern with no claim about Ashgrove or about you.
- **Answer slot.** An instruction for the interview that names two honest branches, one for the case where you did the thing and one for the case where you did not. It is not a question to me, and it is not a script.
- **Guidance is scaffolding, not a script.** Say it in your own words. Each guidance cell is built to be spoken in 90 to 120 seconds.

## 4. Fit snapshot

Requirements are quoted from the JD you sent. Evidence is quoted from your message, and only those sentences are used. Nothing on this page says you did something your sentences do not say.

**Gates.** The JD names no legal, credential or location term. Years of experience are graded on fit, not treated as a gate. No hard gate applies.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches and contact centre" (JD) | "I handled the branch's formal complaints log and trained new tellers on our escalation script." (your message) | medium | [grounded] | transferability | Your material says the branch's formal log, not the process end to end. Keep the sentence's scope: "I handled the branch's formal complaints log." Answer slot: which steps of a complaint's path, from logging to closure, were yours to run, and where the handover went. If others ran those steps, say so. |
| F2 | "across branches and contact centre" (JD) | "Never worked in a contact centre" (your message) | none | [grounded] | capability | Stated absence. Words: "I have never worked in a contact centre." Then how you would learn the centre's side, said as a plan, never as a past. |
| F3 | "4+ years in financial-services customer operations" (JD) | "6 years in retail banking, the last 3 as a branch supervisor." (your message) | medium | [grounded] | none | The quote reaches the requirement in role terms. Expect a probe on whether branch counter and supervisor work counts as customer operations. Say what the customer side of it was, in your words. |
| F4 | "experience handling regulated complaints" (JD) | "I handled the branch's formal complaints log and trained new tellers on our escalation script." (your message) | medium | [grounded] | transferability | Your material says formal complaints. The word "regulated" is not in it, so the pack does not add it. Answer slot: if the log ran to a regulatory deadline or reporting rule, say which and what you did to meet it. If it did not, say so and describe how the formal process worked. |
| F5 | "confident presenting to senior leaders" (JD) | "I've never presented to anyone above regional level." (your message) | none | [grounded] | capability | Stated absence. Words: "I've never presented to anyone above regional level." Then how you would build the skill, as a plan. Never a claim to a presentation you have not given. |
| F6 | "comfortable with Excel reporting" (JD) | "I built the monthly complaints spreadsheet our regional manager uses." (your message) | medium | [grounded] | presentation | The quote reaches the reporting in other terms. Your material does not name Excel, so say the tool by its name only if you used it. Bridge rewords only the quote: "I built the monthly complaints spreadsheet our regional manager uses." |
| F7 | "report monthly on complaint volumes" (JD) | "I built the monthly complaints spreadsheet our regional manager uses." (your message) | medium | [grounded] | presentation | Rewording only: the monthly spreadsheet is the reporting you have. Your material does not show what the sheet counted. That is the pack's observation, not words for you to say; it is an item for the upgrade menu. |
| F8 | "resolution times" (JD, from "report monthly on complaint volumes and resolution times") | none given | none | [grounded] | discovery | Answer slot: if you measured how long complaints took to close, say how, in your words. If you did not, say so and say what you would track first. |
| F9 | "coach branch supervisors on escalations" (JD) | "trained new tellers on our escalation script" (your message); "the last 3 as a branch supervisor" (your message) | medium | [grounded] | transferability | Teller training is the adjacent step. Coaching supervisors is not in your material. Answer slot: if you coached a colleague or supervisor on an escalation, say what the conversation was. If you did not, say so and say how you would start. |
| F10 | "work with digital teams on self-service journeys" (JD) | none given | none | [grounded] | discovery | Answer slot: if you worked on a digital or self-service change, say what your part was. If you did not, say so and say how you would start with a digital team. |

## 6. Grounding brief

Current Ashgrove priorities, from the 2026 strategy brief as you summarised it (July 2026, about four months old). Check the exact wording against the brief before you quote it in the room.

- **Digital shift.** Move 40% of member service to digital channels by 2028.
- **Branch footprint.** Consolidate eight branches into five hubs over 2027.
- **New product.** Launch a small-business lending product in Q1 2027.
- **Competition.** App-only banks are the main pressure.

Vocabulary to use: "member service", "digital channels", "hubs", "small-business lending", "app-only". No stale framings were flagged in the material you sent. Do not coach yourself to correct the interviewer on the brief.

## 8. Persona table

Panel = blend of the top two personas of each member's relationship. No interviewer is named, so personas are assigned by round, not by person.

| Persona | How it shows up in this loop | Likelihood and reasoning | Counter-strategy | Depth |
|---|---|---|---|---|
| Values / Behavioral | Round 2 (behavioural) and Round 3 (values score) | High. The recruiter says the panel scores against the four values, and round 2 is mostly behavioural. | Map a story per value where a quoted sentence carries one; otherwise a selection scaffold with its honest branch. "We" for context, "I" for your part. | 5 |
| Skeptic | Round 1 lightly; round 2 probes the contact-centre and presenting gaps | High. Your two stated absences (F2, F5) are the first things a manager checks against the JD. | Rehearse the contact-centre objection until it is plain. Bridges only from what you stated; a concrete plan for the rest. | 4 |
| Case / Strategist | Round 3, the 20-minute escalation case | High. The case is the one live problem the panel has said it will set. | Clarify, objective, segments, approach, metrics, risks. Think aloud. Time split is in C1. | 3 |
| Peer Evaluator | Round 3, the two branch managers | Medium to high. Branch managers are the people this role coaches; the seam between branch and centre is where they will press. | Reciprocity: what branches get from the role. Propose seam principles, not facts about the current handover. | 3 |
| Conversational / Rapport | Round 1 recruiter | Medium to high. Casual openers are still scored; the biography question comes first. | A 90-second arc in your own sentences. Treat "anything else?" as scored. | 2 |
| Data-Driven Prober | Round 2 or 3, on the monthly spreadsheet and the reporting requirement | Medium. Your reporting is the one quantitative thing in your material. | Say what the sheet counted and say plainly when you do not know. | 3 |
| Pressure / Stress | Round 2 or 3, a time-boxed challenge | Medium. No signal either way; the panel format raises it. | Pause, restate, hold the claim you can back through two follow-ups, then concede explicitly. | 2 |

Depth 5 and 4 for the two top personas reflects the panel's values scoring and the manager's gap check. The total is 23 questions, within the 18 to 26 band.

## 9. Question banks

### A. Values / Behavioral (weight: top, 5 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Tell me about a time you decided a complaint from the member's side of the counter, when the rule or the queue pointed the other way." | VAL | [grounded] "Members First, Always — we decide from the member's side of the counter." (values page, copied 11 Nov 2026) | Selection scaffold: pick a complaint where you chose the member's side over the rule or the queue. It needs a named decision, what it cost or risked, and what the member got. If no such complaint comes to mind, say so plainly, then give the nearest case from your branch log and how you handled it. | Members First is the value complaint work is scored on most often. No sentence in your material carries a story for it, so this is a scaffold, not a mapped answer. |
| A2 | "Tell me about a time you kept hold of a problem until it was fixed, even after it stopped being yours on paper." | VAL | [grounded] "Own the Fix — whoever finds the problem keeps hold of it until it is solved." (values page) | Selection scaffold: pick a problem you found that passed to someone else, and say what you did to keep it moving. Name the handover and what you checked after it. If none comes to mind, say so, then say how you would treat a pattern you found in a complaints log. | Own the Fix is the value the escalation case tests. This answer is the rehearsal for the case's "who keeps the open item" moment. |
| A3 | "Tell me about a time a member needed something explained twice, and what you changed so they didn't." | VAL | [grounded] "Plain Words — if a member needs it explained twice, we wrote it wrong." (values page); "I handled the branch's formal complaints log and trained new tellers on our escalation script." (your message) | Selection scaffold: pick a case where a member's understanding failed, and say what you changed: the words, the form, or the script. If the nearest thing is the escalation script you trained tellers on, say whether members ever needed it explained twice and what changed. If not, say so. | Plain Words. The script is the nearest carried material, but the quote does not say whether it ever needed a second explanation, so the story is a scaffold. |
| A4 | "Tell me about a branch you know well. What did its town mean for how you ran it?" | VAL | [grounded] "Neighbours, Not Numbers — every branch is part of its town." (values page); "6 years in retail banking, the last 3 as a branch supervisor." (your message) | Name one branch you supervised, and one thing about its town that changed a decision. If none did, say so and say what you would find out first about a new town. Do not borrow a local detail you have not given. | Neighbours, Not Numbers. The branch-supervisor years are your nearest material; the town link is not in your sentences, so the answer is a scaffold. |
| A5 | "Tell me about a time a target you were held to cost a member something." | VAL | [grounded] "Neighbours, Not Numbers — every branch is part of its town." (values page) | Selection scaffold: name a target or measure that pulled against a member. Say what you did and whether you raised it with anyone. If none comes to mind, say so and say how you would raise it with the centre. | A second Neighbours, Not Numbers question, aimed at the numbers side of the panel's scoring. Mapped story: none in your material. |

### B. Skeptic (weight: 4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The role covers complaints across branches and contact centre. You've never worked in a contact centre. Why should we trust you with that half?" | JD | [grounded] "Never worked in a contact centre" (your message); "I handled the branch's formal complaints log and trained new tellers on our escalation script." (your message) | **Highest-ROI rehearsal in this pack.** Plain acknowledgment: "I have never worked in a contact centre." Then hold, through two follow-ups, on what you can back: the branch complaints log and the escalation script you trained tellers on, in those words. On the second follow-up, concede explicitly that the centre's own operation is something you do not yet know. Answer slot: if any complaint you handled reached the centre or came back from it, say how. If none did, say so and say how you would learn the centre's path in your first month. Never fold on the core claim to restore harmony. | F2 is a stated absence on a JD line that names the centre. The panel's manager will check it first, so it gets the deepest rehearsal. |
| B2 | "The role is about regulated complaints. What deadlines or rules did the log you ran have to meet?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." (your message) | Answer slot: if the log ran to a regulatory deadline or reporting rule, say which and what you did to meet it. If it did not, say so and describe how the formal process worked, in your own words. Do not call the log "regulated" unless you can say what made it so. | F4. Your material says formal, not regulated, and this question tests that difference without asserting either. |
| B3 | "You've never presented above regional level. How would you present to senior leaders in this role?" | JD | [grounded] "I've never presented to anyone above regional level." (your message) | Plain acknowledgment: "I've never presented to anyone above regional level." Then how you would prepare, as a plan: the first presentation you would ask for, and what you would rehearse. Answer slot: if you have presented to a group above branch level in any setting, say what it was. If not, say so. | F5. The presenting requirement is the JD's own line. The acknowledgment is your sentence, not a claim. |
| B4 | "Why leave branch supervision for a role that sits above the branches?" | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." (your message) | Answer slot: give the reason in your own words. The material does not show one, so do not borrow one from the job description. If something in the branch work pointed you here, name it. If nothing did, say what you would like to be measured on. | A motivation probe. Your material has no reason stated, so this is an answer slot, not a story. |

### C. Case / Strategist (weight: 3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A member has complained twice. The branch and the contact centre have given different answers, and the complaint is past its target date. What do you do in the next 48 hours, and what do you change afterwards?" | CASE | [generic] escalation-case pattern for role families of this kind; no claim about Ashgrove or about you | **The 20-minute case, structured.** Time split: 3 minutes clarify (what each channel told the member, what the target date is, what the member has asked for). 5 minutes decide (objective: one answer the member can act on, with one named owner; segments: one member, a branch pattern, or a script problem). 8 minutes walk the panel through the approach (who owns the fix today, what the branch does, what the centre does, what the member hears and when). 4 minutes on change and measure (time to one answer, repeat contacts, the open-item list). Close on Members First and Own the Fix, in your own words. Do not claim a case you have handled. | The panel's case is a complaint escalation. This generic version is for rehearsal; if the recruiter sends the real case material, swap it in. |
| C2 | "Where do you expect the branch and the contact centre to disagree about a complaint?" | CASE | [generic] branch-and-centre seam pattern | Propose seam principles, not facts: who decides the outcome, who tells the member, who keeps the open item. Say what you do not know about Ashgrove's current handover, and do not claim it. | The JD's "across branches and contact centre" makes the seam the probe. The answer tests seam thinking without asserting how the handover works. |
| C3 | "Ashgrove plans to move 40% of member service to digital channels by 2028. Where would your work with the digital teams start?" | JD, CO | [grounded] "move 40% of member service to digital channels by 2028" (your summary of the 2026 strategy brief); "work with digital teams on self-service journeys" (JD) | Start from which complaints move with the channel, and where a member who cannot finish a journey on the app ends up: in a branch or the centre. Name one thing a self-service complaint journey must do so a member can explain the problem in plain words. Answer slot (F10): if you worked on a digital or self-service change, say what your part was. If not, say how you would start with a digital team. | The 40% target is the largest stated shift, and the JD line makes it the role's own job. JD tag first because the requirement is the JD's; CO for the strategy. |
| C4 | "Eight branches are becoming five hubs over 2027. What happens to a complaint that is open at a branch that closes?" | CO | [grounded] "consolidate eight branches into five hubs over 2027" (your summary of the 2026 strategy brief) | The open item moves with the member. Name the risk of a complaint that changes hands and loses its history. Say what you would check on the closure day: the open log, the member's contact details, the promised date. Say what the town loses when a branch closes, and what the member can still reach. Speak it as a plan; it makes no claim about your past. | Strategy-aware and tests whether you think at the company's altitude. The hub move is the 2027 change that puts complaints in motion. |

### D. Peer Evaluator (weight: 3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Branch managers own the member relationship day to day. What changes for them when you take this role?" | JD | [grounded] "coach branch supervisors on escalations" (JD); "the last 3 as a branch supervisor" (your message) | Reciprocity framing: say what branches get, which is support, a faster answer and fewer repeat contacts, not control. Name one decision that stays with the branch. Answer slot: from your years as a branch supervisor, say what you would have wanted from a member-experience lead, if anything. If nothing, say so. | F9 from the other side of the table. The panel's branch managers are the people this role coaches, so their question is about what it costs them. |
| D2 | "When a branch and head office disagree about a complaint's outcome, who decides?" | CASE | [generic] seam decision pattern | Propose a principle: the member's side decides the outcome; the owner is the person holding the open item; disagreement goes to one named owner within a set time. Do not claim Ashgrove's current rule. | A peer seam probe. The panel's branch managers will test spine and tact here. |
| D3 | "A fix needed both a branch and the centre. Who got the credit, and what did you say about your part?" | VAL | [generic] credit pattern for shared fixes | Selection scaffold: pick a fix others did with you. Name what they did and what you did, in your own words, and say your part plainly without making it the story. If no shared fix comes to mind, say so and give the nearest. | A peer probe on credit-sharing. Your material has no shared fix, so this is a scaffold. |

### E. Conversational / Rapport (weight: 2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey to here." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." (your message); "I handled the branch's formal complaints log and trained new tellers on our escalation script." (your message); "I built the monthly complaints spreadsheet our regional manager uses." (your message) | A 90-second arc in your own sentences: six years in retail banking, the last three as a branch supervisor; the complaints log; the teller training on the escalation script; the monthly spreadsheet. Stop at the spreadsheet. Your reasons are yours to give; do not add results. | The recruiter screen opens here. The biography is the first scored item and carries F3. |
| E2 | "Which tool did you build the complaints spreadsheet in, and what did it do for your regional manager?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." (your message) | Say the tool in your words. If it was Excel, say so. Say what your regional manager used the sheet for, using only what you know. Answer slot: if you built formulas, pivots or charts in it, say which you built. If you did not, say what the sheet did. | F6. The word "Excel" is the JD's, so the answer names only the tool you used. |

### P. Data-Driven Prober (weight: 3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Walk me through how the monthly complaints spreadsheet counted a complaint." | JD, EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." (your message) | Say what one row of the sheet represented and what it counted. Answer slot: if you set the counting rule, say what it was. If someone else set it, or there was no rule you can name, say so plainly. | F7, the monthly volumes requirement. The question asks for the method, not a figure, because your material gives no figure. |
| P2 | "Which measures did the spreadsheet carry, and which does a monthly report need that it did not?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." (your message); "report monthly on complaint volumes and resolution times" (JD) | Name the measures in your own words. If the sheet carried volumes, say so. If it carried no time-to-close measure, say that and what you would add first. | F7 and F8 together. It finds the resolution-times gap before the panel does. |
| P3 | "How would you measure how long a complaint takes to resolve?" | JD | [grounded] "report monthly on complaint volumes and resolution times" (JD) | Answer slot (F8): if you measured how long complaints took to close, say how, in your own words. If you did not, say so and say what you would track first. | F8, the resolution-times requirement, with no quote in your material. |

### S. Pressure / Stress (weight: 2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| S1 | "Sixty seconds: why you, over someone who has run a contact centre?" | JD | [grounded] "Never worked in a contact centre" (your message); "6 years in retail banking, the last 3 as a branch supervisor." (your message) | Pause. Restate the question. Hold the claim you can back: six years in retail banking, the last three as a branch supervisor, a formal complaints log and a script you trained tellers on. Hold through two follow-ups; on the second, concede explicitly that you have not run a contact centre and say how you would close that. Never fold the core claim, and never claim the centre. | Pressure on F2 and on the 4+ years requirement, delivered as a rival comparison. |
| S2 | "That complaints log. How much of it was actually you?" | EXP | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." (your message) | Hold: say what "handled" meant, in your own words, and who else touched the log. If part of it was yours, say which part. Do not widen "handled" into ownership. | An attribution check on F1. The log is the most likely place a prober asks "how much was you". |

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| Own the member complaints process end to end across branches and contact centre | B1, S2, C2 |
| Report monthly on complaint volumes and resolution times (volumes) | P1, P2, E2 |
| Report monthly on complaint volumes and resolution times (resolution times) | P3 |
| Coach branch supervisors on escalations | D1 |
| Work with digital teams on self-service journeys | C3 |
| 4+ years in financial-services customer operations | S1, E1 |
| Experience handling regulated complaints | B2 |
| Confident presenting to senior leaders | B3 |
| Comfortable with Excel reporting | E2 |

Values round: A1 to A5 and D3 carry the four published values. Every requirement has at least one JD-tagged question.

## 10. Values / principles cheat sheet

A values-style round is detected because the recruiter's email says the panel scores against the four values. No value below has a mapped story in your material, so each row carries a selection scaffold with its honest branch.

| Value (official name) | Working meaning (paraphrased) | Mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | No story in your material. Scaffold: A1. Honest branch: if no complaint comes to mind, give the nearest case from your log and say so. |
| Plain Words | If a member needs it explained twice, the wording was wrong | No story in your material. Scaffold: A3. Honest branch: if the script never needed a second explanation, say so. |
| Neighbours, Not Numbers | Every branch is part of its town | No story in your material. Scaffold: A4 and A5. Honest branch: if no town detail changed a decision, say so. |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | No story in your material. Scaffold: A2 and C1. Honest branch: if no problem you found was kept to close, say so, and say how you would hold one. |

## 11. Reverse questions

No interviewer profile exists, so these are role-generic. Each has why it lands.

1. **"Who owns a complaint once it has been logged, and what happens at the point where a branch hands it to the centre?"** Why it lands: it shows you are asking about the seam the role is built around, and it gives you the answer to the C2 probe.
2. **"What does the hub move mean for complaints that are open at a branch when it closes?"** Why it lands: it shows you have read the strategy brief and are thinking about the 2027 consolidation as a complaints question.
3. **"How is the 40% digital target measured, and does a complaint raised through the app count toward it?"** Why it lands: it shows you know the target is a count, and that the count can hide the complaints it moves.
4. **"What would a new person do in their first month that would genuinely help your branch teams?"** Why it lands: a reciprocity question for the peer round, asked of the branch managers themselves; it turns the panel into a conversation.
5. **"What would success look like at six months, measured in complaint volumes and resolution times?"** Why it lands: it sets the measures you will be judged on in the terms you already planned to report on.
6. **"What did the last person in this role leave unfinished?"** Why it lands: it shows you expect to inherit work and want to know what it is, which is the own-the-fix instinct.

## 13. Prohibited claims

Built locally from the fit snapshot. Each entry is a claim this pack will not coach, with its basis and its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end | Inflated form of F1: your material says the branch's formal log | F1's quote at its own scope: "I handled the branch's formal complaints log." The limit is the pack's observation: your material says the log, not the process end to end. |
| Worked in a contact centre | Stated negative, F2 | Plain acknowledgment: "I have never worked in a contact centre." No slot on the centre's own work. |
| Presented to senior leaders | Stated negative, F5 | Plain acknowledgment: "I've never presented to anyone above regional level." Then a plan, not a past. |
| Handled regulated complaints | Inflated form of F4: your material says formal complaints | F4's quote at its own scope, with B2's slot. The limit is the pack's observation: your material does not say "regulated". |
| Coached branch supervisors on escalations | Inflated form of F9: your material says tellers | "trained new tellers on our escalation script." F9's slot covers any coaching you did. |
| Designed the escalation script | Inflated form of the script line: your material says "our" script | "trained new tellers on our escalation script." |
| Reported resolution times each month | Inflated form of F7 and F8: no resolution-time measure is in your material | F7's rewording only; F8's slot, with its second branch allowing you never measured it. |

## 14. Sources

**Provided documents:**
1. The JD, as pasted in your message.
2. The Ashgrove values, as copied from ashgrovecu.org/about/values on 11 November 2026.
3. The recruiter's process email (three rounds, 20 November).
4. The 2026 strategy brief, as you summarised it. The quoted strategy lines in C3 and C4 come from your summary, so check them against the brief before using exact wording.
5. Your background, as written in your message.

**Searches and fetches sent:** none.

**Research tier: L1, searches 0 of 6, fetches 0 of 2.** The research budget was not used because every target's output was fixed by a provided input.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | The four values were in hand as pasted text, so the values cheat sheet (section 10) runs from the pasted values, not a fetch. |
| 2. Ashgrove interview process, customer operations | skipped | The recruiter's email fixes the three rounds, their lengths and who runs them, so persona weights (section 8) follow it. |
| 3. Ashgrove strategy and recent news | skipped | The strategy summary you sent, dated July 2026, is inside the freshness window and supplies the grounding brief (section 6). |
| 4. Interviewer name and Ashgrove | n/a | No names have been given. Reading the interviewers would need names; see the upgrade menu. |
| 5. Representative customer-operations JD | skipped | Your JD fixes the fit snapshot and the JD-tagged questions. |

## 15. Upgrade menu

- **Your complaints spreadsheet's measures, and what it counted** → upgrades F6, F7 and P1 from "your material does not show" to answers you can give.
- **Any time you measured how long complaints took to close** → upgrades F8 and P3 from an answer slot to a stated fact.
- **Any coaching of a colleague or supervisor on an escalation** → upgrades F9 and D1 from teller training to supervisor coaching, in your words.
- **Any presentation above branch level, even to a committee** → upgrades F5 and B3 from a plan to a stated experience.
- **Any digital or self-service work** → upgrades F10 and C3 from an answer slot to a stated part.
- **The panel's 20-minute case material, if the recruiter sends it in advance** → replaces the generic C1 with the real case.
- **The Head of Member Services' and the two branch managers' names** → a persona weight for each person, a tailored reverse question for each, and an interviewer read from public footprint.
- **A CV, if you have one** → exact quotes from it to add to the fit snapshot, in place of the paraphrased quotes from your message.
- **Deep research (L2)**: a strategy brief, loop reports and recent organisation news, up to 6 more searches and 2 more fetches, several minutes. Want it?
- **A tuesday-dossier.md from the job-underwriter skill** → verified evidence and prohibited claims that bind every guidance cell. None is present; this would add it.
