Your prep pack is saved as `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-alone-part-2-rooms-case-7-canned-80f79993/2bb0cf4f-8d0b-4e97-ad9e-818ef528c33f/scratchpad/saltmarsh_live_operations_producer_interview_pack.md`. I built it for a hiring-manager round, since your note didn't say who Tobias is to you.

**Key points**

- **Team leadership is the biggest gap, and the most likely objection.** The JD's "coordinate design, art, engineering and community teams on each update" makes it a probe. Question B1 is the highest-return prep. Say "I haven't led a team" first, name the nearest coordination work only if it was yours, then give a plan. Don't stretch it.
- **In-app purchases:** say "I haven't worked on a game with in-app purchases," then how you'd learn it, framed as a plan.
- **Retention:** expect "how was that counted?" and "which assumption would you defend least?" (C1, C2). Name an assumption only if you actually know it.
- **Strongest evidence:** the release checklist QA still uses. Open with it, since Tobias's background is QA and his talk is about patch notes matching what shipped.
- **Two titles:** the JD asks for two. Your material shows one (A4). Say so plainly, and don't claim the second title.

**Research found something important.** Saltmarsh announced "Project Larkspur" in September 2026. Per a search snippet, Tidepool Tactics and Lantern Row move to a season-pass model with one shared events calendar from February 2027, and per-title event teams give way to a single live-ops group. That is close to this role's shape. I read only the snippet, not the full page, so check the announcement before Friday. Reverse question 1 asks about it.

**Caveats:** I couldn't find anything on Saltmarsh's interview process. Tobias's public footprint is one GDC 2026 talk, "Patch Notes Are a Promise," and I read only its summary.

I can run a live drill on any question. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, and convert the pack to Word if you'd like.

Is Tobias your future manager, a level above you, or a peer? The answer changes how the question banks are weighted.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh_live_operations_producer_interview_pack.md -----
# Interview prep: Live Operations Producer, Saltmarsh Games

**Interviewer:** Tobias Wrenfield, Head of Live Operations. Relationship not yet confirmed; this pack assumes a hiring-manager round (see the upgrade menu).
**Format:** 60 minutes, Friday.
**Candidate:** Femi (they/them).
**Changes:** First version.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored:

- **VAL**: values and past behavior, against Saltmarsh's published values.
- **EXP**: your past work, checked closely for what was actually yours.
- **JD**: the listed job, including its gaps.
- **CO**: company and market knowledge.
- **CASE**: a live problem from the role.

This guidance is scaffolding, not a script. Say it in your own words.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material says one main title, weekly content drops, two years. It does not say two titles or live events. Say the calendar as you ran it. Answer slot: the JD's two titles make a probe on how one title's calendar scales likely. If you ran events beyond content drops, or planned a second title, say which and how, in your own words. If not, say so plainly and say how you would plan for two. |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | none given | none | [grounded] | discovery | Your material does not show coordination with any of these teams. Answer slot: the JD names four teams on every update, so expect a probe on how you worked with each. If you coordinated any of them on a drop, say which and what you did, in your own words. If you did not, say so plainly and describe how you would set up an update's work with each. |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | low | [grounded] | transferability | Your sentence is about reporting retention, not running a post-event review. Words: "Presented the monthly retention numbers to the studio head." Answer slot: the JD asks for ownership of the review, so expect a probe on whether you have run one. If you ran a review of any event or drop, say what it covered. If you did not, say so plainly and say what you would measure after the next event. |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | high | [grounded] | none | Your sentence reaches the requirement directly: you wrote it, and QA still uses it. Keep its terms. It does not show who held release sign-off; say that in your own words if asked. |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message | medium | [grounded] | presentation | The years meet the minimum in other terms. Your material does not say the games were live-service. Rewording only the quote: "4 years as an associate producer at a puzzle-game studio." Answer slot: if the title ran on a live model after launch, say how in your own words. If you cannot say, say so. |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | high | [grounded] | none | Direct match. Say it in the sentence's own terms: weekly, one main title, two years. |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | presentation | The quote reaches the requirement in other terms: you presented the numbers monthly. Rewording only the quote; no claim about how the numbers were built. Answer slot: expect the defend-the-number probes in C1 and C2. |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | presentation | The checklist is written work that others use, which reaches the requirement in other terms. Keep the sentence's words. Clarity in writing is judged on what you send; the pack cannot rehearse it aloud. See the upgrade menu. |
| F9 | Team leadership: not named in the JD; nearest line is "coordinate design, art, engineering and community teams on each update" — JD | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [grounded] | capability | Your stated negative, and the only words to use for it: "I haven't led a team." Say how you would learn to lead a team, as a plan, never as a past. Never describe leadership you did not hold. |
| F10 | Monetised mobile titles: a role-family expectation, not quoted in the JD | "never worked on a game with in-app purchases" — your message | none | [grounded] | capability | Your stated negative, and the only words to use for it: "I haven't worked on a game with in-app purchases." No answer slot. Say how you would learn that side of a live calendar, as a plan, never as a past. Never describe monetisation work you did not do. |

Gap types follow the routing rule in the output template. F9 and F10 are not JD lines; they are the two gaps you asked about, sourced from your own negatives.

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has led a team, or managed people | Stated negative: "Never led a team" (your message) | "I haven't led a team." No slot about leadership history. |
| Has worked on a game with in-app purchases | Stated negative: "never worked on a game with in-app purchases" (your message) | "I haven't worked on a game with in-app purchases." |
| Owned the live-events calendar for two titles | Inflated form of F1: "I ran the weekly content-drop calendar for our main title for the last two years." | F1's quote at its own scope. The limit is this pack's observation, not words for you: your material says one main title's content-drop calendar. F1's slot stays inside that calendar. |
| Owned the retention KPIs | Inflated form of F7: "Presented the monthly retention numbers to the studio head." | F7's quote at its own scope. This pack's observation: your material says you presented the numbers, not that you set how they are defined. |

## Reading the interviewer

Public footprint only.

- **Career pattern:** previously a QA lead at a console studio; now Head of Live Operations at Saltmarsh Games. Source: his GDC 2026 talk page.
- **His stated argument** ("Patch Notes Are a Promise", GDC 2026): a live team is judged by how often its patch notes describe what actually shipped.

Practical implications:

1. He will test accuracy. When you describe a drop, separate what shipped from what was planned.
2. His background is QA. Your release checklist (F4) is the piece of your material closest to his expertise. Lead with its terms, and expect a QA-depth probe on it.
3. Saltmarsh's published value "Ship the Patch Not the Promise" matches his talk's frame. Use the idea in your own words.

Mirror opportunity: no career jump is shared. The nearest professional mirror is the QA interface, carried only by F4: "Wrote the release checklist our QA team still uses." — your message.

## Persona table

Depth follows weight: the top personas get the most questions.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | Live problems on the calendar and on two titles | High. A hiring-manager prior, and the role is the calendar. | Clarify, objective, segments, approach, metrics, risks. Think aloud. |
| Skeptic | Probes the two stated negatives and the coordination line | High. Both negatives are in your message, and the JD's coordination line raises the leadership gap. | Hold, then concede. Plain acknowledgment. Plan as a plan, never as a past. |
| Data-Driven Prober | Asks how the retention figure was built | Medium. F7 is a figure you gave. | Name the figure's weakest assumption yourself, or say you do not know how it was counted. |
| Pressure | Time-boxed challenge to leadership | Medium. A 60-minute round with a hiring-manager weight. | Pause, restate, anchor in what you stated. |
| Values / Behavioral | Scenarios on Saltmarsh's three published values | Medium to low. A 60-minute role interview is not a dedicated values round, but his talk covers the same ground. | Selection scaffold. Honest branch where no story exists. |
| Conversational | An opening "walk me through" | Medium. Likely as an opener. | A 90-second arc built from your own sentences. |
| Peer | Seams with QA and engineering | Low, unless he turns out to be a peer. | Reciprocity framing. |

Weights: Case 5 questions, Skeptic 5, Prober 3, Values 3, Pressure 2, Conversational 2, Peer 2.

## Question banks

### Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Plan the next six weeks of live events for one title. What do you need to know first?" | CASE | [generic] | Clarify first: the title's goals, the players it serves, what the last six weeks of retention did. Then objective, segments, approach, metrics, risks. Say the first two questions aloud. | The role's first duty is a calendar. A live problem with no claim about your past, so no quote. |
| A2 | "Day-7 retention dropped after your last content drop. Diagnose it, and tell me what you'd check first." | CASE | [generic] | Name the cut you would check first (drop against baseline, by segment, by version), then hypotheses in order of cost. Say which assumption you would verify before believing the drop. | Tests metric reasoning on the figure in F7, without claiming you ran such a diagnosis. |
| A3 | "Suppose a studio moves two titles onto one shared events calendar and one live-ops group. What do you check first?" | CO | [generic] | Name what each title's audience and goals are before merging anything, and who owns the calendar's decisions. Say the risk to each title out loud. | Saltmarsh's public announcement (Project Larkspur, September 2026; see Sources) describes this structure. Phrased as a generic scenario because a news item is not a raising source. |
| A4 | "What part of a live-events calendar for two titles have you run yourself?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." — your message | Story map from that sentence: the weekly calendar, one main title, two years. Answer slot: the two-title scope is not in your material. If you planned or ran events beyond content drops, or a second title's calendar, say which and how. If not, say so plainly and return to the weekly calendar for one title. Hold through two follow-ups by returning to it. | The JD's "two of our mobile titles" is the headline scope, and F1 is where the probe lands. The question presupposes two-title work only through the slot's second branch. |
| A5 | "Walk me through how a release checklist gets run with QA for a content drop." | JD | [grounded] "Wrote the release checklist our QA team still uses." — your message | Start from the checklist you wrote and QA still uses. Describe its steps in your words. Answer slot: the material does not show who held sign-off. If you ran sign-off with QA, say what you decided. If QA owned it, say so plainly and describe your part. | F4 is the strongest evidence in the pack. The question tests whether "wrote" and "manage" are the same thing. |

### Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've never led a team, and this role coordinates four disciplines on every update. Why should we hire you for it?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." — your message | Highest-ROI prep. Open with the stated negative: "I haven't led a team, and I'd rather say that first." Then the nearest coordination work you did, in your words, if any; if none, say so. Then the plan for the rest. Hold through two follow-ups by returning to the negative and the plan. Concede the core gap specifically: "I can't yet show I've led a team." Never add leadership to close the gap. | F9 is the gap this objection will most likely press. The question's first clause is the stated negative; its second is the JD's coordination line. |
| B2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." — your message | Answer with the two gaps you know, in those words. Then say how you would close each, as a plan. Do not guess at a third gap. | Calibrated candor. Naming a gap you can prove beats one you are guessing at. |
| B3 | "You've never worked on a game with in-app purchases. How would you learn how that side of a live calendar works?" | JD | [grounded] "never worked on a game with in-app purchases" — your message | Plain acknowledgment: "I haven't worked on a game with in-app purchases." Then the plan: who you would ask, what you would read, what you would want to see in your first month. Plan language only, with no claim about past monetisation work. | The negative is yours, so the acknowledgment is sourced. The plan is the only part you can speak to. |
| B4 | "Four years at a puzzle-game studio. What would a live-service mobile title ask of you that the puzzle work did not?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio." — your message | Name the differences you have actually seen in your own work. If you have not seen a difference, say so and name what you would check. | Targets F5, the years-and-genre gap, asked as a JD question. |
| B5 | "How would you get design, art, engineering and community to agree on one update?" | JD | [generic] | Structure it: what each team needs to know, who decides the order, how a disagreement is settled, and what happens when one team misses. Make no claim about your past. If you have a real example, use only what you have. | F2 has no evidence, so this is a live version of its requirement. Covers the coordination line. |

### Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the monthly retention numbers were counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head." — your message | Answer slot: say how the figure was counted, in your words, if you know. If you did not build the calculation, say so plainly and say who did. | F7 is a figure you gave, so it draws the defend-the-number probes. EXP, because it tests what was yours. |
| C2 | "Which assumption behind that retention figure would you defend least?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." — your message | Name an assumption you actually know about, before they find it. If you know of none, say you do not know how the figure was counted. Do not name an assumption you cannot explain. | The weakest-assumption move. The pack names none, because your material names none. |
| C3 | "Have you run a post-event review? What did it cover?" | JD | [grounded] "Presented the monthly retention numbers to the studio head." — your message | Answer slot: if you ran a review of any event or drop, say what it covered in your own words. If not, say so plainly and say what you would measure after the next event. Reporting numbers is not the same as the review. | F3 is the nearest sentence, and it is about reporting, so the guidance does not treat it as a review. |

### Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why hire someone who has never led a team?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." — your message | Pause, restate the question, then answer within about ten seconds of speech: the negative, then the plan. Hold through two follow-ups. Concede the core gap specifically. | Same gap as B1, under time pressure. |
| D2 | "That retention presentation: how much of it was actually you?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." — your message | Answer slot: say what you presented and what was yours in it, in your words. If the numbers were someone else's work, say so plainly. | Pressure on attribution, from the same sentence as F7. |

### Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Tell me about a time the calendar and the players disagreed." | VAL | [generic] | Published value: "Players Before Plans." Selection scaffold: pick a drop where the schedule and what players needed pulled apart, and say what you chose and why. If no such time comes to mind, say so plainly, then give the nearest thing your calendar work carries. | Opens from a published value. No sentence of yours carries this story, so the scaffold ends in the honest branch. |
| E2 | "Tell me about a time you announced something before it was built." | VAL | [generic] | Published value: "Ship the Patch Not the Promise." Scaffold: a time you corrected or held an announcement. If none, say so plainly. Do not invent the ending. | Mirrors his talk's frame. No sentence of yours carries it, so the honest branch is required. |
| E3 | "Tell me about a time a release left the checklist better than it found it." | VAL | [grounded] "Wrote the release checklist our QA team still uses." — your message | Published value: "Leave the Build Greener." Answer slot: if you changed the checklist after a release, say what changed and why, in your words. If not, say so plainly, and say what you would change first. | F4 is the sentence the story rests on. The slot asks only what you changed. |

### Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." — your message; "I ran the weekly content-drop calendar for our main title for the last two years." — your message; "Wrote the release checklist our QA team still uses." — your message; "Presented the monthly retention numbers to the studio head." — your message | A 90-second arc from those four sentences in order: the studio, the calendar, the checklist, the monthly numbers. Each beat is a sentence you wrote; say it in those terms. | Casual openers are scored. The arc covers F5, F6, F4 and F7 in one pass. |
| F2 | "What live game have you been playing, and what is its update cadence doing right?" | CO | [generic] | Name one game, one thing its updates do well, and one thing you would change. Name only a game you actually play. | A casual register, scored like any other. Content is generic. |

### Peer

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Our QA and live teams sit side by side. Where's the seam, and what happens when you disagree?" | JD | [grounded] "Wrote the release checklist our QA team still uses." — your message | Propose a principle for the seam: who signs off, and what happens when QA says no. Do not claim you know this team's seam. | Your material shows one QA contact, the checklist. The answer should be principles, not history. |
| G2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Name the principle first: credit follows the work. Then one example, only if you have one. If not, say so. | Peer-register behavioral question. |

## Requirement coverage

| Requirement | Questions covering it |
|---|---|
| Plan and run the live-events calendar for two titles (R1) | A4, A3 |
| Coordinate design, art, engineering and community (R2) | B5, B1 |
| Own the post-event review and the KPIs (R3) | C3, C2 |
| Manage the release checklist with QA (R4) | A5, E3 |
| 3+ years producing live-service (R5) | B4, F1 |
| Experience running a content calendar (R6) | A4, F1 |
| Comfortable with player-retention metrics (R7) | C1, C2, D2 |
| Clear written communication (R8) | none, and why: clarity in writing is judged on what you send, and the pack cannot rehearse a document aloud. See the upgrade menu. |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "Saltmarsh has announced a shared events calendar for Tidepool Tactics and Lantern Row. Is this role running that calendar, and who sets its priorities?" | Shows you read the public news. Asks the scope question directly. |
| 2 | "You went from QA lead to Head of Live Operations. What did that move teach you about what QA needs from a producer?" | Ties to his own path, and turns the hardest question into a peer conversation. |
| 3 | "Which of last quarter's post-event reviews changed a decision, and who owns its KPIs?" | Ties to R3, and tests how the team actually uses its reviews. |
| 4 | "When a drop slips because of a build problem, who decides what the players hear?" | Ties to his talk's thesis about what shipped against what was promised. |
| 5 | "Your values page says players come before the calendar. Can you give me a recent time that happened?" | Puts the published value in front of him, and asks for evidence. |
| 6 | "What would you need the next hire to have learned in their first ninety days?" | A reciprocity question. It signals you are already thinking about the job. |

## Sources

**Provided documents:** your message, which carries your background, the JD text, the role title, and the interviewer's name. No CV and no dossier were provided.

**Searches and fetches sent:**

1. Search "Saltmarsh Games mobile game studio live operations": no results.
2. Search "Tobias Wrenfield Head of Live Operations Saltmarsh Games": returned https://talks.gdconf.example/2026/patch-notes-are-a-promise (GDC 2026 talk, "Patch Notes Are a Promise").
3. Search "Saltmarsh Games studio values careers": returned https://saltmarshgames.com/values.
4. Search "Saltmarsh Games mobile titles news 2026": returned https://saltmarshgames.com/news/project-larkspur (snippet only).
5. Search "Saltmarsh Games live service update strategy": returned the same Larkspur page (snippet only).
6. Fetch https://talks.gdconf.example/2026/patch-notes-are-a-promise: returned the talk summary only.
7. Fetch https://saltmarshgames.com/values: returned the three published values.

Project Larkspur, per the search snippet, dated September 2026: Tidepool Tactics and Lantern Row move to a season-pass model with one shared events calendar from February 2027, and per-title event teams give way to a single live-ops group. The snippet does not say how the season pass is monetised, and I did not fetch the full page.

**Research tier:** L1, searches 5 of 6, fetches 2 of 2.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh values | yes | Values bank E1 to E3, with the three values named. The values cheat sheet is withheld, because the round is not detected as values-style. |
| 2. Saltmarsh interview process, role family | yes | The query returned no results. The loop structure is unknown, so persona weights follow round-type priors. |
| 3. Saltmarsh strategy and recent news | yes | Project Larkspur snippet: moved A3 and reverse question 1. |
| 4. Tobias Wrenfield, Saltmarsh | yes | GDC talk summary: moved the interviewer read and reverse question 2. |
| 5. Representative JD | skipped | The JD you supplied fixes the fit snapshot. |

## Upgrade menu

- Who Tobias is to you, whether your future manager, a level above, or a peer: reweights the personas and changes reverse questions 2 and 6.
- Whether the round includes a values section, or any deliverable the recruiter named: adds a values cheat sheet, or a build section.
- The puzzle title's model, whether it was live-service with events, and how it earned money: moves F5 and B4 from a presentation gap to a clear answer.
- What the release checklist checks: sharpens the slots in E3 and A5.
- The full Larkspur announcement, read in full: lets A3 and reverse question 1 quote specifics rather than a snippet.
- Deep research (L2): a strategy brief, his talks and writing beyond the GDC talk, role-family loop reports, and recent organisational news. At most six more searches and two more page reads.
