Your prep pack covers all three rounds in one file: `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/haiku/alone/part-2/rooms/case-6-denied-c4c007d2/larkfield-systems_engineering-manager_interview_pack.md`

It's built from your role summary and your background. Web search was refused in this session, so nothing about Larkfield itself is verified. Its values, interview structure and strategy are unknown, and the pack says so.

**The main risks, across all three rounds**

- **Two squads, one team.** Your material shows one team of six over three years. This is the most likely objection, so it gets the deepest rehearsal (T2). Hold on the three years, concede that running two squads is untested, and say what you'd do in the first 60 days.
- **Hardware-adjacent roadmap.** You've never owned one. The pack gives you the plain sentence, "I've never owned a hardware-adjacent roadmap," and asks you to present how you'd close the gap as a plan, not a past. It comes up in T1, P8 and the reverse questions.
- **Managing managers.** Same treatment: "I've never managed managers," then a plan for coaching leads (T3, V5).
- **The 60% on-call drop.** Expect a "how was that counted?" probe (T7). Answer with what you can actually say, and say plainly when you don't know how it was measured.

**What's in each round**

- **Tuesday (Director):** Skeptic and Case weighted highest. Eight questions, mostly on the gaps above and on a first-90-days problem.
- **Thursday (panel):** Peer and Prober weighted highest, since the product manager and staff engineers are pricing what you cost their work. Eight questions, including seam questions about hardware and product.
- **Monday (VP):** values and leadership. The recruiter's wording makes this a values round, but there's no published values page to map against, so the VP round has seven questions and no values-to-story mapping yet.

The pack also has a requirement-coverage table, reverse questions for each round, and an upgrade menu. The upgrade menu's most useful item is Larkfield's published values page, which would let me map your stories to their values.

Two questions that would sharpen it:

1. Can you paste the full job description? The requirement rows currently quote your summary, not the posting.
2. Did the recruiter mention any take-home, presentation or written exercise for any of the rounds?

Next steps I can take on request:

- Play the Skeptic on T2, the highest-value question in the pack.
- Save a `tuesday-dossier.md` recording the gaps this prep exposed, to carry into later sessions.
- Convert the pack to Word.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: larkfield-systems_engineering-manager_interview_pack.md -----
# Larkfield Systems: Engineering Manager, three-round prep pack

**Role:** Engineering Manager, device-management services (two squads)
**Company:** Larkfield Systems (industrial IoT, ~600 people), as described in your role summary
**Rounds (loop mode):**
- **Tue, 45 min:** hiring manager, Director of Engineering (would-be boss)
- **Thu, 60 min:** panel, two staff engineers and a product manager
- **Mon after, 30 min:** VP Engineering, described by the recruiter as "values and leadership philosophy"

Built from your role summary and your background. No full job description was supplied, and web research was refused in this session, so no company fact below is verified.

---

## 1. How to use this pack, and the type key

Personas describe how a question arrives. Types describe what is being scored. Guidance is scaffolding for a spoken answer, not a script.

| Tag | Meaning |
|---|---|
| JD | Stated role responsibilities, including the gaps |
| EXP | Your own work, and whether the claims survive scrutiny |
| CASE | A live problem from the role, reasoned aloud |
| VAL | Past behaviour and leadership philosophy |
| CO | Company strategy. None in this pack, because research did not run |

Rehearse each answer to 90 to 120 seconds. Where an answer slot appears, the honest branch is a full answer, not a weakness.

---

## 2. Fit snapshot

The spine of the pack. Every story, bridge and answer slot below draws on the quoted sentences in this table.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Leads two squads building device-management services" (your message) | "3 as a team lead of 6" (your message) | medium | [grounded] | transferability | Your material shows one team of six, over three years. It does not show two squads. Say it in the quote's own terms: three years as a team lead of 6. Answer slot: expect a probe on splitting one team's work across two groups. If you have set work across two groups, say how. If not, say so and say how you would start. |
| F2 | "owns delivery, hiring and growth for 11 engineers" (your message) | "I run our hiring loop for backend roles — about 40 interviews last year." (your message) | medium | [grounded] | presentation | Hiring is the closest match, and the quote reaches it in other terms: a backend loop, about 40 interviews. Lead with the loop in those words. Do not widen it to org-wide hiring or to hires made. "Interviews" is not "hires". |
| F3 | "owns delivery, hiring and growth for 11 engineers" (your message) | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." (your message) | medium | [grounded] | transferability | Delivery under pressure is adjacent work: a reliability quarter pushed through against roadmap pressure. It is not delivery ownership across two squads. Keep the words at the quote's scope. The 60% figure triggers the defend-the-number slot in T7. |
| F4 | "owns delivery, hiring and growth for 11 engineers" (your message, growth part) | none given | none | [grounded] | discovery | Your material says nothing about growing engineers. Answer slot: if you have grown people into bigger roles, say who and how, in your own words. If not, say so plainly and say how you would start. |
| F5 | "partners with hardware and product on roadmap" (your message) | "never owned a hardware-adjacent roadmap" (your message) | none | [grounded] | capability | A stated absence. The words you can say: "I've never owned a hardware-adjacent roadmap." Then how you would close it, said as a plan and never as a past. |
| F6 | "partners with hardware and product on roadmap" (your message) | "pushed a reliability quarter through against roadmap pressure" (your message) | medium | [grounded] | transferability | A roadmap decision taken against pressure is adjacent to partnering with product. It is not a partnership model. Do not describe it as one. |
| F7 | Leading through other managers (your flag; the role summary does not state it) | "I've never managed managers" (your message) | none | [grounded] | capability | A stated absence. The words you can say: "I've never managed managers." Then the plan for coaching leads who manage engineers, said as a plan and never as a past. |
| F8 | "industrial IoT, ~600 people" (company line, your message) | "currently at a payments company" (your message) | low | [inferred] | transferability | Payments is the adjacent domain: backend and reliability, not device work. The derivation is this pack's. Your material shows no device or hardware work. |

**Reading the gaps.** The two stated absences (F5, F7) are the ones you named yourself, so the pack gives you the words for them. The rest are gaps the material is silent on, so the pack gives answer slots, not sentences. The likeliest objection is F1, one team against two squads.

---

## 3. Prohibited claims

Claims this pack will not coach. Each entry names its basis and its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Leads, or has led, two squads | Inflated form of F1 | "3 as a team lead of 6," at its own scope. Your material says one team, not two. |
| Owned hiring for the org, or for 11 engineers | Inflated form of F2 | The loop for backend roles, in your quote's terms. |
| Hired 40 engineers | Inflated form of F2 | "About 40 interviews." Interviews are not hires. |
| Drove the 60% on-call reduction alone | Inflated form of F3 | The quote as written. Who did what, and how the figure was counted, is an answer slot (T7). |
| Owned a hardware-adjacent roadmap | Negative you stated (F5) | "I've never owned a hardware-adjacent roadmap." |
| Managed managers | Negative you stated (F7) | "I've never managed managers." |

---

## 4. Persona weights by round

Relationship priors set the starting point. The loop adjusts them: each round has different people, so each has its own weights. No interviewer names were given, so no individual profile adjusts them.

| Round | Persona | Weight | How it shows up and why |
|---|---|---|---|
| Tue, Director | Skeptic | 3 | Hiring managers buy capability and derisk gaps. F1, F5 and F7 are exactly what they will test. |
| Tue, Director | Case/Strategist | 3 | Hiring manager prior. The role summary describes their roadmap, so expect live problems on it. |
| Tue, Director | Data-Driven Prober | 2 | F2 and F3 carry numbers a prober will test. |
| Thu, panel | Peer Evaluator | 3 | The product manager and the staff engineers price what you cost and add to their work. Seam questions. |
| Thu, panel | Data-Driven Prober | 2 | Staff engineers. Blended with their own prior: the top two personas for each member. |
| Thu, panel | Case/Strategist | 2 | Technical design and rollout problems on device fleets. |
| Thu, panel | Pressure | 1 | Touched, not weighted up: no signal here points to stress interviewing. P8 uses it on F5. |
| Mon, VP | Values/Behavioral | 3 | Your recruiter's words name a values and leadership round. That round is detected, so VAL questions are guaranteed. |
| Mon, VP | Pressure | 2 | Skip-level prior. Composure on F7 and on the reliability decision. |
| Mon, VP | Case/Strategist | 2 | Skip-level prior: strategy and decision rules, with no research behind them. |

Every persona is touched in at least one round's counter-strategy. Use the persona file's counter-strategy for any persona not weighted here: hold, pause, restate, and name the weakest assumption before they do.

---

## 5. Question banks

Provenance comes first on every row. A row whose guidance claims something about your experience quotes the sentence it rests on. Rows that make no claim about you carry the label alone.

### 5a. Tuesday, hiring manager (Director of Engineering)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| T1 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "I've never owned a hardware-adjacent roadmap." (your message, F5) | Name the hardware roadmap first, in those words. Then one sentence on how you would close it, as a plan. Give one weakness, not a list. Do not claim adjacent roadmap experience beyond F6's quote. | A Skeptic stem. F5 is a stated absence, so the words are yours to say. The role's hardware partnership is the raising source. |
| T2 | "You've led one team of six. This role leads two squads. Why do you think you can run two?" | JD | [grounded] "3 as a team lead of 6" (your message, F1) | **Highest-ROI prep in this pack.** Hold: three years as a team lead of six is the basis, and you should say that before anything else. Hold through two follow-ups by returning to the team you led. Concede the two-squad coordination is untested. Answer slot: if you have set work across two groups, say how, in your own words. If not, say so plainly and say what you would do in the first 60 days to split the squads. | The two-squad objection is the most predictable one for this candidate, and F1 is the thinnest evidence on the JD's first line. Deepest rehearsal here, with the concession named before it is asked for. |
| T3 | "Have you ever managed managers? If not, how will you lead people who manage engineers?" | JD | [grounded] "I've never managed managers" (your message, F7) | Acknowledge it plainly: "I've never managed managers." Then the plan: how you would coach leads, and what you would ask them to show you in their first month. Do not describe coaching a manager as past experience. | F7 is a stated gap, so the plain acknowledgment is yours to say. Asked only if the Director raises it; the role summary does not state it. |
| T4 | "Sketch how you would take over two device-management squads in the first 90 days. What do you need to know first?" | CASE | [generic] | Clarify before you structure: who the customers are, what the device fleets look like, what the squads own today. Then objective, segments, approach, metrics, risks. Name what you would ask hardware and product first. | A live problem drawn from the role summary's two-squad and hardware-partnership lines. It makes no claim about your past. |
| T5 | "A firmware update fails on 8% of units in one region, and the roadmap says ship the next feature Friday. What do you do?" | CASE | [generic] | Contain first, then diagnose with hardware and product. Decide Friday against the failure rate, not the calendar. Say what you would tell product, and what you would not commit to yet. | Scores structure and the hardware seam. The scenario is a pattern for the role, not a fact about Larkfield. |
| T6 | "What would you measure in the first quarter to know the services are healthy?" | JD | [generic] | Three measures, tied to delivery and on-call. Name the one you would defend least and say why. Do not quote a figure you have not been given. | Covers the delivery-and-growth requirement at its operational end. No claim about your history. |
| T7 | "Walk me through how the 60% on-call reduction was counted." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." (your message, F3) | Defend the number, in your own words. Answer slot: if you counted pages, hours or incidents, say which. If you did not know how it was counted, say so plainly. Name the assumption you would defend least before they do. | F3 is the headline figure, and figures are where probers press. The slot asks only how it was counted, what it is sensitive to, and which part was yours. |
| T8 | "Of the 40 interviews last year, how many did you decide the outcome of?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." (your message, F2) | Keep the number on the noun it came from: 40 interviews. Answer slot: if you set the criteria or made the calls, say which. If you ran the process and the decisions were someone else's, say so. | F2 is a presentation gap. "Interviews" does not become "hires" or "decisions", so the answer stays at the number as you gave it. |

### 5b. Thursday, panel (two staff engineers and a product manager)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Where does device-management service ownership end and the firmware team's begin today?" | JD | [grounded] "partners with hardware and product on roadmap" (role summary, F6) | No claim about your history. Describe how you would find the boundary: who owns the device contract, which interfaces change together, and what you would ask in the first two weeks. Say what you do not yet know about their boundary. | A staff engineer's probe on the hardware seam. The raising source is the role summary's partnership line. |
| P2 | "What did the reliability quarter cost the roadmap?" | EXP | [grounded] "pushed a reliability quarter through against roadmap pressure" (your message, F6) | Hold to the quote's scope: a reliability quarter pushed through against roadmap pressure. Answer slot: if any roadmap items slipped, say which, and what you told product. If none slipped, say so. | A premised question on the quote's own event. The slot allows the honest answer that nothing was given up, and it asks for no outcome the quote does not carry. |
| P3 | "Our teams sit side by side. Where's the seam, and what happens when we disagree?" | JD | [generic] | Propose seam principles, not a map you do not have: who decides scope, who decides dates, how a disagreement escalates. Say you would rather agree the principles with product in week one than guess them now. | The Peer Evaluator's stem. It is answered with principles, so it needs no claim about your past. |
| P4 | "How would you split work between two squads when a dependency crosses both?" | CASE | [generic] | Name the dependency's owner, the decision rule for who goes first, and the tradeoff you would make visible. Ask one clarifying question before you answer. | A staff-level seam problem from the two-squad line of the role summary. |
| P5 | "How do you handle credit when work spans teams?" | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." (your message, F3) | "My team" for the outcome, "I" for the decision to push the quarter through. Answer slot: if others did parts of the reliability work, name them and what they did. If you cannot separate the contributions, say so. | Peer credit probes turn on the pronoun. The quote fixes which part was yours, and the slot asks for the others' parts without inventing them. |
| P6 | "Sketch a rollout plan for a firmware-linked change across 50,000 devices. What do you need first?" | CASE | [generic] | Clarify device variants and rollback paths. Then phases, gates, and the metric that stops a rollout. Name the hardware dependency you would check before anything else. | Scores structure on a device-fleet problem the role's hardware partnership implies. No claim about your past. |
| P7 | "A device cohort goes offline after a service change. Walk me through the diagnosis." | CASE | [generic] | Scope the cohort, check whether the change is the common factor, and separate service from device symptoms. Say what you would ask the firmware team for. | A generic device-services incident problem. Scored on structure and on the seam. |
| P8 | "Two minutes: why should staff engineers trust a manager who has never owned a hardware roadmap?" | JD | [grounded] "I've never owned a hardware-adjacent roadmap." (your message, F5) | Pause before you answer. Concede the gap specifically, in those words. Hold the reliability work as what you did, and hold through two follow-ups before conceding anything more. | A Pressure stem on F5, the stated absence. The composure is scored more than the content. |

### 5c. Monday, VP Engineering (values and leadership)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "pushed a reliability quarter through against roadmap pressure" (your message, F6) | Story map from the quote: the pressure, the decision, the result. Say "we" for context and "I" for the decision. Answer slot: if the pressure came from senior leaders, say who and what you told them. If nobody senior pushed back, say so and describe the nearest case you have. | The recruiter's words make this a values round, so VAL is guaranteed here. The story is the one the quote carries. |
| V2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection criteria: pick a time you chose the people using the product over a number the team was measured on. It needs a named stake, a moment you did not fold, and a relationship that was intact at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. | No quoted sentence carries a customer story, so this is a scaffold with its honest branch, not a mapped answer. |
| V3 | "What does good leadership look like to you when you are not in the room?" | VAL | [generic] | Describe the mechanism you use to keep a team's standards without standing over it. Answer slot: if you have a practice for this, name it and what it changed. If not, say so plainly and describe how you would build one. | Leadership philosophy is the recruiter's stated focus. No quote carries a practice, so the answer slot is the honest form. |
| V4 | "Who pushed back on the reliability quarter, and what did you say?" | EXP | [grounded] "against roadmap pressure" (your message, F6) | Name who pressed, if you can. The quote says the pressure, not the person. Hold your position on the reliability quarter through two follow-ups, and concede specifically what it cost. If no one senior pressed, say so. | A premised question on the quote's pressure. The honest form allows that the pushback came from roadmap owners, not from leadership. |
| V5 | "Thirty seconds: why should we hire someone who has never managed managers for this seat?" | VAL | [grounded] "I've never managed managers" (your message, F7) | Plain acknowledgment: "I've never managed managers." Then your strongest true reason, in the quote's terms, and the plan for the gap. Hold through one follow-up before you concede anything. | F7 is a stated gap, so the acknowledgment is yours to say. The pressure is in the 30-second frame, and the reason must be one your material carries. |
| V6 | "How do you decide between a reliability quarter and a roadmap feature?" | CASE | [grounded] "pushed a reliability quarter through against roadmap pressure" (your message, F6) | Name the decision rule in your own words. Answer slot: if you used a written rule, say what it was. If you decided case by case, say so and describe how you would decide now. | Strategy-level decision making, drawn from the one decision your material shows. The slot keeps any rule you never wrote out of the answer. |
| V7 | "What would you tell us the device-management strategy should be in 18 months?" | CASE | [generic] | Three bets, one concession, and the tradeoff you would make visible. Clarify what the company has already committed to before you commit to anything. | A strategy question with no research behind it. No CO question is in this pack. The answer stays a structure, not a claim about Larkfield. |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| Lead two squads building device-management services | T2, P4 |
| Own delivery for 11 engineers | T6, T7, P2 |
| Own hiring for 11 engineers | T8 |
| Own growth for 11 engineers | V3 at the leadership level. No question on growth outcomes, because the material shows none, and an answer slot in F4 covers the honest form |
| Partner with hardware on roadmap | T1, P1, P8 |
| Partner with product on roadmap | P3, P5, V6 |
| Industrial IoT domain | T5, P6, P7 (scenarios). No question on domain history, because F8 shows none |
| Managing managers (your flag) | T3, V5 |

---

## 6. Reverse questions

Each one carries a line on why it lands. No interviewer profile exists, so none is tied to a career path. The product manager is a peer, so one reciprocity question appears in the panel's set.

| Round | Question | Why it lands |
|---|---|---|
| Tue | "What would make you say at six months that you hired the right person for this seat?" | Asks for the success measure in the Director's own words, so you can plan to it. |
| Tue | "Which part of the device-management services has caused the most trouble in the last two quarters?" | Shows you want the hard problem, and gives you the Director's real priority to plan against. |
| Thu, panel | "Where does device-management ownership end and the firmware team's begin today?" | Opens the seam question on your terms, and you learn the boundary the panel actually works to. |
| Thu, PM (reciprocity) | "What could a new engineering manager do in their first month that would genuinely help your team?" | Reciprocity for a peer: it turns the interview toward what you bring to their work. |
| Mon, VP | "How does the company define leadership philosophy in practice? Which decision last quarter would you cite as an example?" | Makes the values round concrete. A cited decision is worth more than a restated value. |
| Mon, VP | "What does the company need an engineering manager to hold on to when roadmap pressure hits?" | Ties to the pressure story in V1 and V4, and shows you have thought about the seat's hardest moment. |

---

## 7. Sources

**Provided documents:** your message (the role summary, your background, the round schedule, and the two stated gaps).

**Searches and fetches sent:**
- "Larkfield Systems industrial IoT device management engineering": **refused**. Permission to use search was not granted in this session, so no results came back. This query was aimed at the company's domain, outside the declared targets.
- "Larkfield Systems company values": **refused**, same cause.

**Research tier: L1, searches 0 of 6 returned, 2 refused; fetches 0 of 2.**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Larkfield Systems values` | unavailable | Section 10, the values cheat sheet, would have mapped the company's published values to stories. The search was refused. The section is dropped, because no published values are in hand. |
| 2. `Larkfield Systems interview process engineering manager` | unavailable | Confirmation of loop structure. Your recruiter's and your own round schedule establish the loop, so the persona weights rest on your words, not on an archetype. |
| 3. `Larkfield Systems strategy` / recent news | unavailable | Would have moved the CO questions and the strategy-level CASE questions. Without it, V7 is generic. |
| 4. `{interviewer name} Larkfield Systems` | n/a | No interviewer names were given, so there was no query to form. The interviewer read is absent. |
| 5. representative `Engineering Manager` JD | skipped | Your role summary fixes the requirement rows, so no representative JD was needed. The summary is not the full posting, which the upgrade menu asks for. |

**Un-numbered search:** the query "Larkfield Systems industrial IoT device management engineering" was refused, as above; it moved nothing.

---

## 8. Upgrade menu

- The full job description text → the requirement rows quote the posting's exact wording, so T2 and P1 are scored on the posting's own lines, not on your summary.
- Larkfield's published values page, pasted here → a values cheat sheet (section 10) with each value mapped to one of your quoted stories, and V2 and V3 get mapped answers where your material carries one.
- The recruiter's reply on round format, and any take-home, presentation or written exercise → a graded-deliverable section for each one named.
- Interviewer names for the Director, the two staff engineers, the product manager and the VP → personas assigned per person, and a reverse question tied to each person's own path.
- Your CV → the none-given row F4 and the discovery rows can be quoted, and the defend-the-number slots in T7 and P5 get exact sources.
- A story of growing an engineer into a bigger role → F4 becomes a grounded row.
- Your prep time before each round → a prioritized prep-triage section.
- Search permission for this session, then a deeper research pass (up to 6 more searches and 2 more fetches, several minutes) → the company's strategy brief, which adds CO questions and a grounding brief. Only if you want it.
- A `tuesday-dossier.md` from a job-underwriter run → verified evidence, allowed strategies per weak area, and an absolute prohibited-claims list that binds every guidance cell.
