Your prep pack is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-alone-part-2-rooms-case-5-denied-3e718467/1ebc5329-a3f9-4145-a9c8-0e13f2252d2d/scratchpad/kelverton-rail_senior-partnerships-manager_interview_pack.md`. It's built from your message and the recruiter's email quotes. Web search was refused, so there's nothing on Kelverton's values, strategy or the panel's backgrounds. The market report isn't in the workspace, so the POV section can't yet name the consensus items to differentiate from.

The two biggest risks are the ones you already named. Deepa will likely test the rail gap first (B1, the highest-ROI rehearsal). Ross will test the commercials: "influenced, not owned" and the £4M attribution (C1, C2, D2). The pack holds you to what you actually said, so the answer slots will ask you to fill in how the figures were counted and which steps were yours, in your own words.

I'd spend the first block of prep on the POV. It has to carry a concession on each thesis, and it has to land on what it means for operators, not on what Kelverton sells.

Offers, one line each:
- **Drill:** I can play Ross on C1 and give feedback against that question's guidance.
- **Dossier:** I can save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions.
- **Word:** I can convert the pack to .docx once you're done iterating.

Do you have the job description? If you paste it, the fit snapshot can quote it and the JD-tagged questions get added. If not, I'll keep the pack as it is.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: kelverton-rail_senior-partnerships-manager_interview_pack.md -----
# Interview prep pack: Senior Partnerships Manager, Kelverton Rail

**Round:** second round, panel, 60 minutes. First 15 minutes: a spoken point of view (no slides) on operator partnerships over the next 18 months, landing on what it means for the operators themselves. Remaining time: Q&A, with commercials pressed.
**Panel:** Deepa, VP Partnerships (your future manager). Ross, Commercial Director.
**Version:** first pack. No changelog.

---

## 1. How to use this pack, and the type key

Personas describe how a question arrives. Types describe what is being scored. Guidance is scaffolding for a spoken answer, not a script. Rehearse the beats out loud, in your own words.

| Type | Meaning |
|---|---|
| EXP | Your experience, and whether the claims survive a probe |
| CASE | A live problem for this role, scored on structure and reasoning |
| CO | Company or market knowledge, from the material you have read |
| VAL | Behaviour against published company values (none supplied, so no VAL bank) |
| JD | Stated job requirements (no job description supplied, so no JD bank) |

---

## 2. Prep triage (about 4 hours)

In order, each tied to a section or question ID:

1. **About 75 min: the POV.** Build the spoken outline from section 5. Talk it aloud three times, timed to 15 minutes. Each thesis must carry its concession out loud.
2. **About 45 min: the rail and quota holds.** Rehearse B1, B2 and C2 out loud. Hold the plain acknowledgment, then concede only what is true.
3. **About 45 min: defending the figures.** Work through C1, D1 and D2. For each, write down what you actually know about how the 6-to-40 and the £4M were counted. Where you do not know, the honest answer is the answer.
4. **About 30 min: operator-side framing.** Rehearse A1 and A2: clarify first, then structure.
5. **About 15 min: opener and reverse questions.** Time E1 at 90 seconds. Read section 10 aloud once.

Everything else is insurance.

---

## 3. Fit snapshot

Requirements from the recruiter's email are quoted. Requirements marked generic are role-family patterns, not quotes from your inputs. No job description was supplied.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "what it means for the operators themselves" (recruiter email) | "bus and light rail network planning, so I know the operator world from the other side" (your message) | medium | [grounded] | transferability | Your material shows operator-side planning work, not operator-facing partner value. Say the planning work in its own terms, then stop. The operator-facing value case is something you derive in the POV, not a past you have shown. |
| F2 | "Ross will push on commercials." (recruiter email) | "took it from 6 partners to 40, roughly £4M of influenced revenue" (your message) | medium | [grounded] | transferability | The material says influenced revenue, not revenue you owned. Keep the figure at that scope. Answer slot: if any part of that revenue came through a step you set, say which and how you decided, in your own words; if none did, say so and stay with what you did carry. |
| F3 | Direct revenue or quota ownership in a partnership role (generic) | "never carried a direct quota, only influenced revenue" (your message) | none | [grounded] | capability | You have stated the absence. Words: "I've never carried a direct quota." Then how you would learn quota ownership, said as a plan, never as a past. |
| F4 | Selling into rail or to train operating companies (generic) | "Never sold into rail specifically" (your message) | none | [grounded] | capability | You have stated the absence. Words: "I've never sold into rail specifically." Then how you would close it in the first 90 days, said as a plan. |
| F5 | Building and growing a partner ecosystem (generic) | "took it from 6 partners to 40" (your message) | medium | [grounded] | none | No gap. Lead with the numbers as you gave them: six partners to forty. |
| F6 | Partnership-channel leadership in a regulated, enterprise market (generic) | "running the ISV channel" (your message) | medium | [grounded] | transferability | Your channel was in payments, with ISVs as partners. Say that in those words. The change of market is yours to explain. Do not claim it away. |
| F7 | Senior partnerships experience (generic) | "9 years in partnerships" (your message) | medium | [grounded] | none | No gap. Use the figure as stated. |

**Gap-type reading.** F3 and F4 are capability gaps because you stated the absence. The pack does not supply any other words for them. F1, F2 and F6 are transferability gaps: the quotes are real but adjacent to what is being asked.

---

## 4. Prohibited claims

Claims this pack will not coach, each with its basis and its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| "I carried revenue targets" or "I owned the £4M" | Inflated form of F2 and F3. Your material says influenced revenue, and no quota | "roughly £4M of influenced revenue" at its own scope. Plain acknowledgment: "I've never carried a direct quota." |
| "I've sold into rail" or "I know how operators buy" | Inflated form of F4 and F1 | "I've never sold into rail specifically." Operator knowledge limited to "I know the operator world from the other side." |
| "I designed and built the partner programme" | Inflated verb of F5. Your sentence is "took it from 6 partners to 40" | "took it from 6 partners to 40," in your own words |

---

## 5. Graded deliverable: the POV (recruiter pre-declared, 15 minutes, spoken)

**Grounded facts to build on.**
- F1 (operator-side planning): "bus and light rail network planning, so I know the operator world from the other side"
- F5 (partner growth): "took it from 6 partners to 40"

**Shape.** Talk through it. Do not present slides. Suggested timing:
- About 1 min: frame the question as what the operators would change, not what Kelverton would sell.
- About 3 min: the operator view, built from F1.
- About 4 min: thesis one, with its concession.
- About 4 min: thesis two, with its concession.
- About 3 min: what it means for the operators themselves, and the first test you would run in 90 days.

**Theses (two, each with a mandatory concession).**
- **Thesis one:** a partnership is judged by the operator's own planning decisions before it is judged by partner pipeline. *Concession:* revenue still has to be what Ross holds the team to, and I have not yet tested this against the market report's data.
- **Thesis two:** operator partnerships should start where a few operators can show a before and after on their own planning. *Concession:* this is slower than a broad launch, and the trade-off is real.

**Differentiation strategy.** The market report is the consensus any prepared candidate has read. Bring one consensus item to show grounding, then one divergence with your reasons. The report's content is not in this workspace, so I have not named its items. Paste its headings and this section can name the consensus item and the anti-pick.

**The requested close.** End on a concrete change for the operator. The sentence is yours to write. The pack does not write it, because it would be a claim about what operators will gain.

---

## 6. Persona weights (panel)

The panel is blended from each member's relationship prior. No interviewer profiles were available, so the weights come from the role and the recorded roles only.

| Persona | Who | How it shows up | Likelihood, with reasoning | Depth | Counter-strategy |
|---|---|---|---|---|---|
| Case / Strategist | Deepa | Live operator problems, clarify-then-structure | High. Deepa is the future manager, and the hiring-manager prior is Case plus Skeptic. The POV is the case vehicle | 5 (A1 to A5) | Clarify, then objective, segments, approach, metrics, risks. Think aloud |
| Skeptic | Deepa | Quiet probing of the rail gap and the quota gap | High. You have stated both absences, so a manager will test them | 3 (B1 to B3) | Hold the acknowledgment. Bridge only from quotes. Offer a ramp plan |
| Pressure / Stress | Ross | Interrupts, time-boxes, asks how much was actually you | High. Commercial Director, and Ross has been told to press commercials | 4 (C1 to C4) | Pause, restate, anchor in what you stated. Hold through two follow-ups, then concede what is true |
| Data-Driven Prober | Ross | Asks how the figures were counted and which assumption you would defend least | High. The £4M and the 6-to-40 are headline figures, so they draw probes | 4 (D1 to D4) | Say what you know about the counting. Name the weakest assumption before it is named for you. Say plainly when you do not know |
| Conversational / Rapport | Both (opener) | A casual "walk me through" opener and a casual question about the report | Medium. Casual questions are still scored | 2 (E1, E2) | Pre-script the 90-second arc. Never answer the reverse-question slot with "I think you've covered everything" |

Values / Behavioral has no bank: no values round was detected and no published values were supplied.

---

## 7. Question banks

### Case / Strategist (Deepa)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "What would a partnership with a train operating company look like in its first 90 days?" | CASE | [generic] | Clarify first: what the operator already runs, what the partnership must change, who decides. Then structure: the operator's problem, what Kelverton offers through partners, what changes for the operator's numbers, risks. Speak it in under two minutes. Make no claim about your past | The POV's operator core, asked as a live problem. Generic because it is a pattern for the problem, not a fact about this employer |
| A2 | "Who inside an operator would own a partnership decision, and what would they measure?" | CASE | [generic] | Name the functions that usually sit around such a decision, such as operations, planning and commercial, and what each would measure. Present these as a pattern for operators, not as this operator's structure. Ask one question back to test your guess | Tests the operator-side view the POV rests on. Generic: it describes how such decisions usually sit, not Kelverton's customers |
| A3 | "How would you set a target for partner-sourced revenue when the sales cycle is long?" | CASE | [generic] | Separate what the partners can influence from what they close. Propose a target you would hold to, and what you would report alongside it. Make no claim about a target you have set before | Ross's commercial lens, asked as a design problem. No past claim is needed or allowed |
| A4 | "Which operator would you start with, and why?" | CASE | [generic] | Give your selection logic: how much the operator would learn from the partnership, whether the data needed is available, whether they would talk about it publicly. Name no operator unless you have a basis for it | A pattern question about choosing a first partner. Generic, because naming an operator would be a claim about the market |
| A5 | "What would you stop doing in the current partnerships?" | CASE | [generic] | Name one partner motion you would stop and why. Choose one you would defend under follow-up. The POV's anti-pick belongs here if the report supports it | A test of judgment and the anti-pick. Generic: it asks for your judgment, not a past event |

### Skeptic (Deepa)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've never sold into rail. Why should we hire you to lead operator partnerships on day one?" | EXP | [grounded] "Never sold into rail specifically" (your message) | **Highest-ROI prep in this pack.** Hold: "I've never sold into rail specifically." Bridge from quotes only: "running the ISV channel" and "bus and light rail network planning, so I know the operator world from the other side." Answer slot: if you have seen how a partnership decision reached a buyer in a regulated market, say what you did; if you have not, say so and say how you would learn it in the first 90 days. Hold through two follow-ups by returning to the acknowledgment and the plan | F4 is the most predictable objection: the future manager will test the gap first. The bridge is the quotes at their own scope, so the hold does not overreach |
| B2 | "Why should we trust someone whose best numbers are influenced, not owned?" | EXP | [grounded] "never carried a direct quota, only influenced revenue" (your message) | Hold the scope: "I've never carried a direct quota." Then say what the figure is and is not, in your own words. Answer slot: if any step in that revenue was yours to set, such as a deal you closed or a forecast you owned, say which and how you decided; if none was, say so and stay with what you did carry | F3 and F2 are the second gap. The question presumes the scope, which the quote states |
| B3 | "Which part of this role would you be weakest at on day one?" | EXP | [generic] | Name the rail sales cycle as the honest weakness, then the first thing you would do about it. Keep it to one weakness. Do not add a strength to soften it | A Skeptic stem. Generic because it is an open prompt about the role, with no premise about your past |

### Pressure / Stress (Ross)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "That £4M. How much of it was actually you?" | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" (your message) | Hold: "took it from 6 partners to 40," in your own words. Answer slot: say how the £4M was counted, in your own words. Name the assumption behind it you would defend least. Say which part was yours to set. If you do not know how it was counted, say that plainly | F2 is a headline figure, so it draws the defend-the-number slots. The honest answer is precise attribution |
| C2 | "You've never carried a quota. Why would I believe you can own a commercial number?" | EXP | [grounded] "never carried a direct quota" (your message) | Hold the scope: "I've never carried a direct quota." Concede what is different about owning a number. Answer slot: if you set targets, forecast, or negotiated terms, say which and how you decided; if you did none of these, say so | F3 and the commercial lens. Ross's push is the one the recruiter named |
| C3 | "Which commercial term would you give up first to win an operator?" | CASE | [generic] | Name the term categories you would trade, such as price, data access, term length and exclusivity. Pick one and say why. Say what you would protect in exchange | A live commercial trade-off with no past claim. Generic: it asks for judgment |
| C4 | "Sixty seconds, no notes: what's the first commercial mistake you'd make in your first six months?" | EXP | [generic] | Name one realistic mistake with a limit you would set against it. Keep it to one. Do not claim you have already made or avoided it | A stress stem asking for candour under time pressure. Generic, because it asks about the future, not your record |

### Data-Driven Prober (Ross)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how the six-to-forty growth was counted." | EXP | [grounded] "took it from 6 partners to 40" (your message) | Answer slot: say what counted as a partner in your count, in your own words. If you did not define it, say so. Name the weakest assumption you know of | The partner count is a headline figure. The probe is for the denominator |
| D2 | "What assumption behind the £4M would you defend least?" | EXP | [grounded] "roughly £4M of influenced revenue" (your message) | The weakest-assumption move, in your own words. If you do not know the assumption, say that plainly. Do not offer an attribution model you cannot repeat under a second question | The figure's attribution is what a prober tests. The honest answer converts the probe into credibility |
| D3 | "Influence is a claim, not a receipt. What would you accept as proof that a partner influenced a deal?" | CASE | [generic] | Name one artifact you would accept, such as a shared opportunity record or a referral trail, and what it would not prove. Keep it as a standard you would apply, not a record of what you had | Tests whether you understand the difference between influence and ownership. Generic: a standard, not a claim about your past |
| D4 | "How would you report partner revenue to a commercial director who only wants owned revenue?" | CASE | [generic] | Report the two figures separately and say which goes in the forecast. Name what you would say when the two diverge | A commercial reporting problem. Generic, because it is a design question |

### Conversational / Rapport (opener and reverse slot)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "9 years in partnerships" (your message); "bus and light rail network planning, so I know the operator world from the other side" (your message); "running the ISV channel" (your message); "took it from 6 partners to 40, roughly £4M of influenced revenue" (your message) | A 90-second arc, one beat per quote, in that order. Answer slot: say why this operator-facing business, in your own words. If you have not worked out why yet, say what you are testing | An opener that is still scored. The beats are the sentences you gave, so nothing is added |
| E2 | "What in the market report would you push back on?" | CO | [grounded] "the market report their strategy team circulated internally last quarter, which I've read" (your message) | Pick one claim from the report you would test first and say how. Give your reason, not a verdict. Bring one divergence from the consensus | Their own document, which you have read. Scored as judgment, not as recall |

---

## 8. Requirement coverage

| Requirement | Covered by |
|---|---|
| What it means for the operators themselves (recruiter) | A1, A2, E1, section 5 |
| Commercials, pressed by Ross (recruiter) | A3, C1, C2, C3, D1, D2, D4 |
| Owning revenue and a number (generic) | B2, C2, C4, F3 |
| Rail and operator selling (generic) | B1, B3, F4 |
| Partner ecosystem growth (generic) | D1, E1 |
| Differentiation from the market report | E2, section 5 |
| Job-description requirements | none, and why: no job description supplied |

---

## 9. Reverse questions

Each one, with why it lands.

1. "What did the last partnership your team lost teach you about operators?" Why it lands: it asks about losses, which shows you think beyond the pitch.
2. "How do operators decide whether a scheduling tool is worth changing their process for?" Why it lands: it shows you are asking the operator's question, not the vendor's.
3. "How is it settled when partnership and commercial disagree on a deal?" Why it lands: it names the seam between the two panel members and shows you have considered it.
4. "What would make you say this role had succeeded at twelve months?" Why it lands: it gives you their definition of success to hold your plan against.
5. "Which part of the market report does the team trust least?" Why it lands: it invites an honest view of their own material.

---

## 10. Sources

**Provided documents.** Your message: your background, the 6-to-40 and £4M figures, and the recruiter's email text as you quoted it. The market report: read by you, not in this workspace, and not used for this pack. No dossier.

**Research tier:** L1 requested by default. Searches 0 of 6, fetches 0 of 2. Both searches were refused by the host (permission not granted).

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Kelverton Rail values | unavailable | Values cheat sheet; no VAL bank. Query "Kelverton Rail company values strategy partnerships": refused |
| 2. Interview process for the role family | unavailable | Loop structure and persona weights for the panel. No query sent; search permission not granted |
| 3. Kelverton strategy and recent news | unavailable | Grounding brief and CO and CASE questions tied to current strategy. Query "Kelverton Rail company values strategy partnerships": refused |
| 4. Interviewer footprint (Deepa; Ross) | unavailable | Interviewer read and tailored reverse questions. Both names are given, so the query can be formed; no call sent |
| 5. Representative job description | unavailable | JD-tagged questions and fit-snapshot requirements. Query "Kelverton Rail scheduling software train operators": refused for a different target, so no call was sent for this one |

---

## 11. Upgrade menu

- The job description text → fit snapshot requirements become quoted and grounded, and JD-tagged questions are added
- The market report's headings or text → section 5 can name the consensus item and the anti-pick, and E2 is sharpened
- Web search permission granted → research at L1 for values, strategy and the interviewers' public footprints
- Deepa's and Ross's public profiles, pasted → personas assigned per panel member, and a reverse question tied to Deepa's own path
- Your full CV → fit snapshot evidence can quote CV lines, and confidence can rise where a document backs a claim
- The recruiter's prep email → any further pre-declared deliverables, and the process details for Ross's section
