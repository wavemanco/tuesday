Your prep pack is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-alone-part-2-rooms-case-7-canned-5e10c580/c47b3960-2713-43c7-9c9b-7309357be5ce/scratchpad/saltmarsh_live-operations-producer_interview_pack.md`.

The most important finding: Saltmarsh's careers page says the interview is the "Outage Hour." It's one 60-minute session with the hiring manager: a live-incident tabletop during a live event, then a values conversation. Most of the prep is built around that format. Practice the outage tabletop as well as the usual questions.

The gap that matters most is leading a team: you've never led one, and the role coordinates design, art, engineering and community on every update. The pack rehearses that as the highest-priority objection (B1), with an honest answer and a concession. The in-app purchase gap is also live, because Saltmarsh's Project Larkspur news moves both titles to a season-pass model. The 3+ years requirement is a weaker point, since the material doesn't say whether your four years were on a live-service title.

Things to check before Friday:
- The talk by Tobias Wrenfield that the pack draws on came from a search result, and I didn't open it. Its web address looks like a placeholder, so confirm the talk exists before you cite it.
- The Outage Hour's split between the tabletop and the values conversation isn't published. The run-of-show in the pack is my suggestion.

I took the round to be the hiring-manager session the careers page describes. Research ran at the default depth: 4 searches and 2 page fetches.

Would you like a live drill? I can play Tobias on the outage tabletop (A1) or the team-leadership objection (B1), and give feedback against each question's guidance. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for your later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh_live-operations-producer_interview_pack.md -----
# Interview prep pack: Live Operations Producer, Saltmarsh Games

**Candidate:** Femi (they/them, as the pack refers to you)
**Interviewer:** Tobias Wrenfield, Head of Live Operations
**Round:** "Outage Hour": a single 60-minute interview with the hiring manager, a live-incident tabletop on a simulated outage during a live event, then a values conversation (Saltmarsh careers page, fetched). The pack assumes Tobias runs it as the hiring manager; the careers page doesn't name the interviewer.

## How to use + type key

- **Personas** describe how a question is asked. **Types** describe what is being scored.
- **VAL**: values alignment. **EXP**: your past work, tested for attribution. **JD**: the job's stated requirements. **CO**: company knowledge. **CASE**: a live problem, no claim about your past.
- Guidance is scaffolding for a spoken answer, not a script. Where guidance says "answer slot", the interviewer's probe is likely, and you answer in your own words, from either branch the slot gives.

## Fit snapshot

Requirements are quoted from the JD you supplied, or from the company's own published pages where marked. Evidence is quoted exactly from your message or CV.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | transferability | Your material shows a calendar for one title, built on weekly content drops, not live events across two titles. Bridge: "For two years I ran the weekly content-drop calendar for our main title." Answer slot: if you planned live events, say which and how; if your calendar held only drops, say so and say what it scheduled. |
| F2 | "experience running a content calendar" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | none | The quote already reaches the requirement. Expect a probe on the calendar's scale and how many people's work it fed: say those in your own words. |
| F3 | "coordinate design, art, engineering and community teams on each update" (JD) | "Wrote the release checklist our QA team still uses." (your message) | low | [grounded] | discovery | Your material doesn't show coordinating the four named teams on an update. Answer slot: if you coordinated any of them on a release, say which, what you asked of them and what they did; if you didn't, say so and say how the checklist touched other teams. |
| F4 | "own the post-event review and the KPIs it reports" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | medium | [grounded] | transferability | The quote is reporting KPIs to the studio head. It does not show a post-event review. Bridge: "I presented the monthly retention numbers to the studio head." Answer slot: if you ran post-event reviews, say what they covered; if not, say so and describe how you would run one. |
| F5 | "manage the release checklist with QA" (JD) | "Wrote the release checklist our QA team still uses." (your message) | medium | [grounded] | presentation | The quote reaches the checklist in other terms: "wrote" and "still uses", not "manages each release". Bridge reworded from the quote only: "I wrote the release checklist; QA still uses it." Medium confidence: the checklist is inspectable, so offer to show it. |
| F6 | "3+ years producing live-service games or apps" (JD) | "4 years as an associate producer at a puzzle-game studio." (your message) | low | [grounded] | discovery | Four years is in the quote, but your material does not say whether those years were on a live-service title. This is a fit requirement, not an eligibility gate. Answer slot: say which of the four years were on live-service work, and what that work was, in your own words. |
| F7 | "comfortable with player-retention metrics" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | medium | [grounded] | presentation | The quote reaches retention in other terms: you presented it. No figure is in your material, and the probe on the figure is likely. Bridge reworded from the quote only: "I presented the monthly retention numbers to the studio head." |
| F8 | "clear written communication" (JD) | none given | none | [grounded] | discovery | No sentence in your material shows written communication. Answer slot: an example of something you wrote that people acted on, if one exists; if none comes to mind, say so and name the nearest written work you have. |
| F9 | Company news: the Larkspur consolidation moves both titles to a season-pass model with one shared events calendar from February 2027 (Saltmarsh news page, from search, not fetched) | "Never worked on a game with in-app purchases." (your message) | none | [grounded] | capability | You have stated the absence. Words: "I haven't worked on a game with in-app purchases." Then how you would ramp, as a plan, never as a past. |

**Gate check:** no gate rows. The 3+ years line is an experience requirement, not an eligibility term, so F6 is graded on fit, not treated as a gate.

## Prohibited claims

Built locally from the fit snapshot: the claims a candidate reaches for under pressure. None of these is to be said.

| Not coached | Basis | Honest form |
|---|---|---|
| Led a team or managed people | Negative you stated: "Never led a team" | Plain acknowledgment: "I haven't led a team." No slot offers a team-lead story. |
| Owned live events for two titles | Inflated form of F1: "I ran the weekly content-drop calendar for our main title" | F1's quote at its own scope. The pack's observation: your material says one title's drop calendar, not two titles' live events. |
| Owned the post-event review | Inflated form of F4: "Presented the monthly retention numbers" | F4's quote at its own scope. The pack's observation: your material says you presented numbers, not that you ran a review. |
| Four years of live-service production | Inflated form of F6: "4 years as an associate producer at a puzzle-game studio" | F6's quote. Whether the years were live-service is the answer slot, not an assertion. |
| Experience with in-app purchases | Negative you stated, F9 | "I haven't worked on a game with in-app purchases." No slot. |

## Question banks

Weights: Case/Strategist and Skeptic lead, because a hiring manager is buying capability and derisking gaps. Values/Behavioral is guaranteed, because the careers page documents a values conversation in this round. Prober, Pressure, Conversational and Peer are touched at lower depth so no style meets you for the first time live.

### A. Case / Strategist (weight: high, 5 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Players report that a limited-time event's reward is missing for some accounts, and the event is still live. Walk me through your first 30 minutes." | CASE | [grounded] "a live-incident tabletop on a simulated outage during a live event" (careers page) | Clarify first: how many players, which platforms, is the event still granting rewards. Decide the stop-the-bleed call: pause the event or the grant. Assign owners: engineering finds the cause, QA reproduces, design sets the compensation rule, community writes the player message. Announce what is known, not what is hoped. Keep a decision log for the post-event review. Say it in about 90 seconds. This is a live problem and presupposes nothing about your past. | The tabletop is the round's core, named by the company's own page. CASE because it tests structure under a live incident, not a story. |
| A2 | "Friday: a major update goes live Tuesday and QA says the build isn't stable. What do you do?" | JD | [grounded] "manage the release checklist with QA" (JD) | Name the checklist items that fail and get QA's pass criteria in writing. Options: slip, cut scope, staged rollout, or ship with a known-issue note. Pick one and say what would change your call. Speak to QA as a partner, not a gate. | The JD's release-checklist line is the raising source. Tests judgment in a live release, which the JD scores. |
| A3 | "Retention on one of the two titles drops 8% the week after a content drop. Diagnose it." | CASE | [grounded] "comfortable with player-retention metrics" (JD) | Clarify the metric's definition and window. Check instrumentation before the market. Segment by new vs returning players, cohort, platform and version, and overlap with the drop. List two or three hypotheses and the data that would separate them. Name the weakest assumption in your first hypothesis. Do not supply a baseline you do not have. | Retention is in the JD, and this is the case most likely to follow F7. |
| A4 | "Sketch the next quarter's live-events calendar across two titles. What do you need to know first?" | CASE | [grounded] "Plan and run the live-events calendar for two of our mobile titles" (JD) | Clarify the team sizes, art and QA capacity, the cadence the two titles can sustain, and the dates the business has committed to. Propose a cadence and the trade-offs. Your F1 calendar experience can inform the sketch, but do not claim the two-title planning as done. | The JD's core responsibility. Asks what you would need to know, so no past is presupposed. |
| A5 | "Project Larkspur puts both titles on one shared events calendar from February. What changes for this role first?" | CO | [grounded] company news: one shared events calendar from February 2027 (Saltmarsh news page, search result) | Say what you would want to learn in the first two weeks: the new calendar's owners, what the per-title teams hand over, and how the season-pass model changes the cadence. Do not assert knowledge of the plan beyond the public announcement. | Current company strategy is the differentiator most candidates cannot touch. Your F9 gap sits next to it. |

### B. Skeptic (weight: high, 4 questions; B1 is the highest-ROI prep)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | **Highest-ROI prep.** "You haven't led a team, and this role coordinates four of them on every update. How do you get design, art, engineering and community to move together?" | JD | [grounded] "Never led a team" (your message); [grounded] "coordinate design, art, engineering and community teams on each update" (JD) | Open with the plain acknowledgment: "I haven't led a team." Then the answer slot: if you got another team to act on a release because of your work, say which team, what you asked for, and what they did; if you did not, say so, and describe how you would run the coordination in the first month. **Follow-up levels:** (1) "Who on design would push back?" Name the real tension and how you'd handle it. (2) "Engineering refuses the date. What do you do?" Hold the position: you escalate with the trade-off, not around the team. (3) "So you've never done this?" Concede exactly: "I haven't coordinated four functions on one update." Do not fold on the rest. | F3 is the thinnest row and the most likely objection. Deepest rehearsal, three follow-up levels, and an exact concession, so the honest answer is ready before the probe. |
| B2 | "Four years, and the JD asks for three years of live-service. How many of those years were live-service work?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio." (your message); [grounded] "3+ years producing live-service games or apps" (JD) | Answer slot: say which of the four years were on live-service work and what it was, in your own words. If all four were, say so with the title. If some were not, say which and what you did in them. Do not round the years up. | F6 is the second-thinnest row, and the length-of-experience line is what a screener reads first. |
| B3 | "You've never worked on a game with in-app purchases. Our next season is a season pass. What's your ramp?" | JD | [grounded] "Never worked on a game with in-app purchases." (your message); [grounded] the season-pass model (company news, search result) | Plain acknowledgment: "I haven't worked on a game with in-app purchases." Then the ramp, as a plan: the retention and calendar work you already know are where you start; you would ask for the monetization dashboards and the season's economy notes in week one. Concede what you do not know about monetization. Do not claim knowledge of pricing or season design. | F9 is a stated absence and the company's own news makes it a live question. Calibrated candor, not bluffing. |
| B4 | "What's the part of this job you'd be weakest at on day one?" | JD | [generic] persona stem; the answer draws on F3 and F8 | Pick one honestly: the coordination of four teams (F3) or the written communication the JD asks for (F8). Name it, then the ramp: what you'd read, who you'd ask, what you'd show in the first 30 days. Do not pick the one you think sounds best. | Skeptic's standard opener. Your honest pick will be tested in B1, so pick the one you can defend. |

### C. Values / Behavioral (weight: mid-high, 4 questions)

The values are the company's own published values (fetched). Each question is a raising-source theme. The story map below is where your material carries one; where it does not, the honest branch is written in.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time a date you'd committed to had to give way because the players needed something else." | VAL | [grounded] "when the calendar and the players disagree, the players win" (values page, fetched) | Selection scaffold: pick a moment when a calendar date had to move for players. Name the stake, the call you made and who you told. If no such time comes to mind, say so plainly, then give the nearest thing your material carries: the weekly content-drop calendar you ran for two years, and what you'd do next time. Do not invent the ending. | Players Before Plans. No quoted sentence carries this story, so it is a scaffold with an honest branch. |
| C2 | "When did you announce something before it was ready, or have to walk one back?" | VAL | [grounded] "we announce what is built, not what is hoped" (values page, fetched) | Selection scaffold: a time you announced a drop, a date or a feature before it was confirmed. Say what the announcement promised, what shipped, and what you changed afterwards. If you have never walked one back, say so plainly, and say how you'd check a date before you announce it. | Ship the Patch Not the Promise. Tobias's public talk argues the same theme (see the interviewer read), so expect it. |
| C3 | "Tell me about a release checklist you wrote. What changed because of it?" | VAL | [grounded] "Wrote the release checklist our QA team still uses." (your message) | Story-mapped from F5: you wrote it, and QA still uses it. Answer slot: if it replaced an earlier checklist, say what it fixed; if you wrote it from nothing, say so. Do not claim it made the build better than it found it, unless you can name what changed. | Leave the Build Greener, the value that is closest to your quoted sentence. The "better than it found them" part is the answer slot, not an assertion. |
| C4 | "What does 'Ship the Patch Not the Promise' mean to a live team, in your own words?" | VAL | [grounded] "we announce what is built, not what is hoped" (values page, fetched) | No past claim is needed. Give the working meaning: the public announcement follows the build, and the player-facing message says what shipped. Use an example only if you have one (from C2). | A values explanation a company will expect you to give fluently. |

### D. Data-Driven Prober (weight: medium, 3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "The retention numbers you presented to the studio head: which figure, for which period, and how was it counted?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." (your message) | Answer slot. Name the figure and the period in your own words. Say how it was counted only if you know; if you did not compute it, say who did. Name the weakest assumption you know of before they do. Say which part was yours: the presenting, the counting, or both. Your material has no figure, so do not supply one. | F7's figure is missing from your material. This is the probe a prober will run, so know your answer before the interview. |
| D2 | "You wrote the release checklist. Show me one line on it, and how you'd know that line was done." | EXP | [grounded] "Wrote the release checklist our QA team still uses." (your message) | Name a line from memory only if you can. If you can't, say so plainly, then describe how you would check a line: the evidence QA would need. | Tests whether the checklist is yours and how well you know it. |
| D3 | "How would you run a post-event review, and which KPIs would it report?" | JD | [grounded] "own the post-event review and the KPIs it reports" (JD) | Answer slot from F4: if you ran post-event reviews, say what they covered. If not, say so and describe how you would build one: the questions it answers, who reads it, and two KPIs you would report. Do not claim a review you did not run. | The JD's post-event review line is the raising source. Scored on structure, and on what you actually ran. |

### E. Pressure / Stress (weight: low, 2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who has run live events for five years on a shipping title?" | JD | [generic] persona stem; the answer draws on F1, F2 and F6 | Hold: lead with the calendar you ran for two years, and the checklist QA still uses. Answer slot: say what you have run and what you have not, in your own words. Hold through two follow-ups by returning to what you ran. Concede only what is true. | Pressure tests composure. The position you hold must be one your quotes carry. |
| E2 | "That checklist: how much of it was actually you?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." (your message) | Hold: "I wrote it; QA uses it." Answer slot: if others edited it, say who and what they changed; if you wrote it alone, say so. Concede the specifics you cannot name, and do not fold on the core claim. | Attribution is the probe this sentence will get. Honest attribution is the answer. |

### F. Conversational / Rapport (weight: low, 2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F-Q1 | "So, walk me through the journey." | JD | [grounded] "4 years as an associate producer at a puzzle-game studio." (your message); [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | A 90-second arc built only from those two sentences, then the checklist and the retention numbers. Do not describe the work as live-service. Do not add anything the quotes don't carry. | Casual openers are scored. The arc is pre-scripted so it cannot wander into a claim you can't back. |
| F-Q2 | "The posting asks for clear written communication. What did you last write that people actually acted on?" | JD | [grounded] "clear written communication" (JD) | Open prompt. Choose one written thing people acted on. If none comes to mind, say so plainly, then name the checklist QA uses (quoted in F5). | F8 is the gap. The posting names it, so it is a raising source. |

### G. Peer Evaluator (weight: low, 2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Our teams sit side by side. Where's the seam between QA and live ops, and what happens when you disagree?" | JD | [generic] persona stem; the QA seam draws on F5 | Name the seam as a principle, not a fact: who decides a release, who can stop one. Disagreement story: answer slot. If you have disagreed with QA, say what it was and how it ended. | A peer-style probe at the QA seam. The principle is generic; any story must come from your material. |
| G2 | "How do you handle credit when a release spans several teams?" | JD | [generic] persona stem | Name what you credit and to whom. Answer slot: an example of shared credit, or say you have not had a release where credit was contested. | Credit-sharing probe. Peers ask it to test whether you claim the work. |

## Coverage: JD requirements to questions

| JD requirement | Covered by |
|---|---|
| Plan and run the live-events calendar for two titles | A4, A5, F-Q1 |
| Coordinate design, art, engineering and community on each update | B1, B4, G1 |
| Own the post-event review and the KPIs it reports | D3, D1 |
| Manage the release checklist with QA | A2, C3, D2, E2 |
| 3+ years producing live-service games or apps | B2, E1 |
| Experience running a content calendar | A4, F-Q1 |
| Comfortable with player-retention metrics | A3, D1 |
| Clear written communication | F-Q2 |

Every requirement has at least one question. There is no `none` line.

## Reading the interviewer (public footprint only)

- **Career pattern:** a GDC 2026 talk, "Patch Notes Are a Promise", by Tobias Wrenfield, Head of Live Operations at Saltmarsh Games, previously a QA lead at a console studio (search result; the talk page was not fetched, and its domain is one to verify before you cite it in the room).
- **Recurring theme:** a live team is judged by how often its patch notes describe what actually shipped. This matches the company value "Ship the Patch Not the Promise."
- **Implications:** expect C2 and C4 to be probed through his own argument. Be ready to say what your public announcements covered, and how you checked them.
- **Mirror opportunity (shared professional path):** he came up through QA, and your material says you wrote the release checklist QA still uses (F5). That is a shared professional touchpoint, not a shared identity. Use it in R2 only; do not claim a QA background you have not stated.

## Persona table

| Persona | How it shows up | Likelihood, and why | Counter-strategy |
|---|---|---|---|
| Case / Strategist | Live incident, release problem, retention diagnosis | High. Hiring manager round, and the company's page names a live-incident tabletop | Clarify, then structure, then owners, then player-facing message (A1–A5) |
| Skeptic | "You haven't led a team", "three years of live-service", in-app purchases | High. A hiring manager derisks the gaps, and F3, F6 and F9 are the thin rows | Plain acknowledgment, then the honest branch, then a ramp plan (B1–B4) |
| Values / Behavioral | Values-conversation probes on the three published values | Guaranteed. The careers page documents a values conversation in this round | Story where a quote carries one; scaffold with honest branch where none does (C1–C4) |
| Data-Driven Prober | The retention figure and the post-event review | Medium. Your CV names retention and a review, and the material has no figure | Name the figure and the weakest assumption; say who counted it if not you (D1–D3) |
| Pressure | "Why you over someone with five years" | Low. Not a hiring-manager default, touched to keep you from meeting it live | Hold through two follow-ups, concede exactly (E1–E2) |
| Conversational | "Walk me through the journey" | Low. Still scored | Pre-scripted 90-second arc (F-Q1–F-Q2) |
| Peer Evaluator | Seam with QA, credit | Low. Touched for completeness | Seam as principle, disagreement story as slot (G1–G2) |

## The run-of-show (60 minutes)

The careers page names the two parts but gives no split. This split is a suggestion.

| Minutes | Part | Use |
|---|---|---|
| 0–5 | Introductions | Your 90-second arc (F-Q1) |
| 5–30 | Outage Hour tabletop | A1 first, then A2–A3 if the tabletop runs long |
| 30–48 | Values conversation | C1–C4, B1 if it comes up, D1 and D3 |
| 48–55 | Your questions | R1–R3 |
| 55–60 | Close | One sentence on what you'd do in the first 30 days |

## Reverse questions

Each has a "why it lands" line.

| # | Question | Why it lands |
|---|---|---|
| R1 | "Your GDC talk argues a live team is judged by how often its patch notes describe what shipped. How do you measure that here?" | Ties to his public path, and shows you researched him rather than only the company. Verify the talk before you cite it. |
| R2 | "You came up through QA before live ops. What did that change about how you run a release?" | A shared professional path (F5), asked as a peer conversation. |
| R3 | "Project Larkspur puts both titles on one calendar from February. What does this role own under that, and what doesn't it?" | Makes the scope question concrete, and shows you read the company's news. |
| R4 | "In the Outage Hour, what does a strong first ten minutes look like?" | Shows you understand the format before you're in it. |
| R5 | "What would make you say, at 90 days, that this hire went well?" | A standard that tells you what they are scoring, in their own words. |

## Sources

- **Provided documents:** the JD and the candidate background, both from your message.
- **Searches sent (4):**
  1. "Saltmarsh Games values". Returned saltmarshgames.com/values.
  2. "Saltmarsh Games interview process Live Operations Producer". Returned saltmarshgames.com/careers/interviewing.
  3. "Tobias Wrenfield Saltmarsh Games Head of Live Operations". Returned a GDC 2026 talk listing (talks.gdconf.example/2026/patch-notes-are-a-promise). Not fetched; the domain is one to verify before citing.
  4. "Saltmarsh Games mobile studio news strategy". Returned saltmarshgames.com/news/project-larkspur.
- **Fetches sent (2):** saltmarshgames.com/values and saltmarshgames.com/careers/interviewing, both read.
- **Dossier:** none present.

**Research tier: L1 — searches 4 of 6, fetches 2 of 2; user links read 0**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | yes | Values cheat sheet (section C): three values by name, from the official page |
| 2. `Saltmarsh Games interview process` | yes | Round structure: Outage Hour, one 60-minute session with the hiring manager; a loop source establishes the loop; the values conversation makes a values-style round guaranteed |
| 3. `Saltmarsh Games strategy / news` | yes | Larkspur consolidation: A5, F9, B3, R3 |
| 4. `Tobias Wrenfield Saltmarsh Games` | yes | Interviewer read: the GDC 2026 talk theme (unverified link), career pattern, mirror opportunity, R1 and R2 |
| 5. representative JD | skipped | The JD you supplied fixes the fit snapshot and JD-tagged questions |

## Upgrade menu

- A retention figure you presented, with the period → makes D1 a defend-the-number question with a number in front of you, and F7 `medium` to `high` once a figure is in your own words.
- Which of the four years at the studio were on live-service work, and what the titles were → makes F6 grounded and turns B2 into a stated answer.
- A release checklist excerpt, or what it replaced → makes C3 and E2 inspectable, so the `medium` in F5 can rise.
- A recruiter's note confirming the Outage Hour's format and time split → replaces the suggested run-of-show with the real one.
- Confirmation from the talk itself (or a fetch of its page) → lets R1 and the interviewer read cite the talk directly.
- **Deep research (L2), offered once:** up to 6 more searches and 2 more fetches, several more minutes. It would add a strategy brief for Saltmarsh, Tobias's other talks and writing, role-family loop reports, and recent org context. Want it?
