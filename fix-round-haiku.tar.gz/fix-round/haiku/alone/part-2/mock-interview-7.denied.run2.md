Your prep pack is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-alone-part-2-rooms-case-7-denied-a17f8447/ebb60250-aad0-4a73-847c-b46473b9b379/scratchpad/saltmarsh_live-ops-producer_interview_pack.md`. Web search was refused, so the pack uses only your message and the job description. It assumes Tobias is your hiring manager until you tell me otherwise.

# Interview prep pack: Live Operations Producer, Saltmarsh Games

**Interviewer:** Tobias Wrenfield, Head of Live Operations. Relationship assumed to be hiring manager (not yet confirmed).
**Format:** 60 minutes, Friday.
**Research tier:** L0. Web search was refused, so nothing about Saltmarsh or Tobias comes from outside your material.

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored.
- Type key: **VAL** behavioral and values; **EXP** work-experience deep-dive; **JD** role-driven; **CO** company knowledge; **CASE** live problem.
- Guidance is scaffolding, not a script. Speak it in your own words.
- **Answer slots** say what to answer when the honest answer is "no" or "not mine." Use the honest branch.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | medium | [grounded] | transferability | Your material shows one main title, a weekly content-drop calendar, two years. It does not show two titles or live events. Bridge: "For two years I ran the weekly content-drop calendar for our main title." Answer slot: if you planned a second title, or your drops were live events, say so; if not, say what you would set up first for two titles. |
| F2 | "experience running a content calendar" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | high | [grounded] | none | No gap. Lead with the calendar in the quote's terms: weekly, one main title, two years. |
| F3 | "Own the post-event review and the KPIs it reports" (JD) | "Presented the monthly retention numbers to the studio head" (your message) | low | [grounded] | transferability | Your material shows presenting numbers, not owning the review or the KPIs. Bridge: "I presented the monthly retention numbers to the studio head." Answer slot: if you chose the numbers or ran a review after an event, say what; if not, say what you would own first. |
| F4 | "manage the release checklist with QA" (JD) | "Wrote the release checklist our QA team still uses" (your message) | medium | [grounded] | presentation | Bridge rewords only the quote: "I wrote the release checklist our QA team still uses." Your material does not show you running the release sign-off. |
| F5 | "coordinate design, art, engineering and community teams on each update" (JD) | none given | none | [grounded] | discovery | Silence, not a stated gap. Answer slot: if you coordinated a drop across those teams, say who and what you handed off; if not, say how you would set it up. |
| F6 | "3+ years producing live-service games or apps" (JD) | "4 years as an associate producer at a puzzle-game studio" (your message) | medium | [grounded] | hard_gate | Surfaced, not bridged. Your material does not establish producer-level work or a live-service title. This is the question asked in the message. |
| F7 | "comfortable with player-retention metrics" (JD) | "Presented the monthly retention numbers to the studio head" (your message) | medium | [grounded] | presentation | Bridge: "I presented the monthly retention numbers to the studio head." No figure is in your material. Name the figure here if you have one. |
| F8 | "clear written communication" (JD) | "Wrote the release checklist our QA team still uses" (your message) | low | [grounded] | transferability | One written artifact, used by another team. Answer slot: name another written thing others relied on, if you have one. |
| F9 | Leadership: not a JD line; you raised it | "Never led a team" (your message) | none | [grounded] | capability | Words: "I haven't led a team." Then how you got cross-team work done, as a record only if it happened; otherwise as a plan. |
| F10 | In-app purchases: not a JD line; the mobile context raises it [generic] | "never worked on a game with in-app purchases" (your message) | none | [grounded] | capability | Words: "I haven't worked on a game with in-app purchases." Then what you would learn first, as a plan. |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the KPIs and the post-event review | Inflated form of "Presented the monthly retention numbers to the studio head" | The quote at its own scope. The material says presenting, not owning. |
| Ran live-events calendars for two titles | Inflated form of "I ran the weekly content-drop calendar for our main title for the last two years" | The quote at its own scope: one main title. |
| Managed the release process with QA | Inflated form of "Wrote the release checklist our QA team still uses" | The quote at its own scope: you wrote the checklist. |
| Had three years of producer-level, live-service experience | Inflated form of "4 years as an associate producer at a puzzle-game studio" | The quote as written. |
| Led a team | Negative you stated: "Never led a team" | Plain acknowledgment: "I haven't led a team." |
| Worked on in-app purchases | Negative you stated | Plain acknowledgment: "I haven't worked on a game with in-app purchases." |

## Question banks

Weights: Case/Strategist 5, Skeptic 4, Data-Driven Prober 3, Pressure 2, Conversational 2, Values/Behavioral 2, Peer 2 (only if a panel).

### A. Case / Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You're handed the live-events calendar for two titles, and one drop slipped a week. What do you do first?" | CASE | [generic]. Raising source: JD "Plan and run the live-events calendar for two of our mobile titles" | Clarify first: why it slipped, which players and KPI are affected, what design, art, engineering and community each need and by when, what goes to QA. Think aloud. Name one premise you would challenge. | R1 and R2 coverage. CASE because it scores structure. |
| A2 | "Walk me through how you would coordinate design, art, engineering and community on one update, from scope to post-event review." | JD, CASE delivery | [generic]. Raising source: JD "coordinate design, art, engineering and community teams on each update" | A sequence of gates: scope lock, asset and build cutoffs, QA sign-off, community announcement, review date. Give it as a plan, not a record. | R2, R3, R4 coverage. |
| A3 | "How would you plan a quarter of live events across two titles?" | JD, CASE | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Start from the cadence you ran: weekly, one main title, two years. Scale it as a plan: what you would add for the second title and how you would avoid collisions. | F1. The scaling is a plan, not a claim. |
| A4 | "A drop, a fix and a seasonal event collide in one week. What gets cut?" | CASE | [generic] | Give criteria: player impact by KPI, engineering dependency, risk. If you have a real instance of cutting, say it. | R1 and R3 coverage. |
| A5 | "What three numbers belong in a post-event review, and why those?" | JD | [generic]. Raising source: JD "own the post-event review and the KPIs it reports" | One retention number, one engagement number, one spend or monetization guardrail. Name the weakest assumption before they do. You have not run this with in-app purchases, so say so and say what you would learn. | R3 and R7 coverage. |

### B. Skeptic (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The JD makes the producer own the post-event review and the KPIs. You presented retention numbers. Who owned the KPIs in your role?" | JD | [grounded] "Presented the monthly retention numbers to the studio head" | **Highest-ROI prep in this pack.** The hold: "I presented the monthly retention numbers to the studio head." Name the limit first: presenting, not owning. Answer slot: if you chose the numbers or ran a review after an event, say how; if not, say so plainly and say what you would own first. Hold through two follow-ups by returning to what you presented. Do not add ownership to make it land. | F3 is the weakest row, and the JD names the requirement directly. |
| B2 | "You have run one title's calendar. Why should we believe the second one won't slip?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Stay with the one-title record. Answer slot: if you planned or ran a second calendar, say how; if not, say the first thing you would set up. | F1 transferability. |
| B3 | "You've never led a team. How do you coordinate four functions without leading them?" | EXP | [grounded] "Never led a team" | Plain acknowledgment: "I haven't led a team." Answer slot: name a time you got cross-team work done without authority, if one happened; if not, say how you would do it as a plan. | F9. |
| B4 | "Monetization drives most mobile live-ops decisions. What do you know about in-app purchases in a live calendar?" | JD | [grounded] "never worked on a game with in-app purchases" | Plain acknowledgment: "I haven't worked on a game with in-app purchases." Then what you would learn first, as a plan. | F10. A probe the mobile context raises. |

### C. Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the retention numbers you presented were calculated." | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Defend-the-number: how it was counted, what it is sensitive to, the assumption you would defend least, which part was yours. Answer slot: if you did the counting, say how; if not, say so plainly and say what you could and could not check. | F7. |
| C2 | "Which assumption behind that retention figure would you defend least?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Name the weakest assumption before they do. If you do not know how the figure was counted, say so plainly. | Weakest-assumption move. |
| C3 | "Tell me about a time a checklist you wrote changed a release decision." | EXP | [grounded] "Wrote the release checklist our QA team still uses" | Open prompt, story-mapped from the quote. Answer slot: if one of its items changed a release, say which; if not, say what you would check first. | F4. |

### D. Pressure / Stress (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why hire someone who has never led a team for a role that coordinates four functions?" | JD | [grounded] "Never led a team" | Pause and restate. Hold a position you can back: the calendar record and the checklist. Plain acknowledgment: "I haven't led a team." Hold through two follow-ups. Concede the leadership gap specifically. Do not fold on the calendar record. | F9 and F1. Hold-then-concede. |
| D2 | "That retention presentation: how much of it was actually you?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Two honest branches. If you produced the numbers, say how. If you presented numbers someone else produced, say so plainly, then say what you did do. | Attribution under pressure. |

### E. Conversational / Rapport (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey to here." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio" | A 90-second arc: the puzzle studio, the associate producer role, the calendar, the checklist, the retention presentation. Only what is in your material. | Casual but scored. Also where the gate surfaces. |
| E2 | "What are you playing right now in mobile, and what would you change in it?" | JD | [generic] | Name a title you actually play and one live-ops decision you would question. Say nothing about Saltmarsh's games. | Comfort with the product, scored casually. |

### V. Values / Behavioral (weight 2; generic, no values research)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V1 | "Tell me about a time you had to deliver unwelcome news to a team." | VAL | [generic] | Selection scaffold: a slipped drop or a bad call delivered to design or engineering. It needs a named stake, your words, and what changed. If no such time comes to mind, say so plainly, then give the nearest thing your material carries. | No values detected, so generic. |
| V2 | "Tell me about a document you wrote that people still rely on." | VAL | [grounded] "Wrote the release checklist our QA team still uses" | Open prompt, story-mapped from the quote. Answer slot: if a team's behavior changed because of it, say how; if not, say what it is for. | F8. |

### P. Peer (weight 2; only if a panel)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Our teams sit side by side. Where is the seam between live ops and QA, and what happens when you disagree?" | VAL | [generic] | Propose seam principles, not claims about their team. Give one disagreement story from your material, or say you have not had one. | Panel-only. |
| P2 | "How do you handle credit when a drop spans several teams?" | VAL | [generic] | Name credit as shared, then one instance from your material. If there is none, say so. | Panel-only. |

## Requirement coverage

| JD requirement | Questions | Note |
|---|---|---|
| Plan and run the live-events calendar for two titles | A1, A3, B2 | |
| Coordinate design, art, engineering and community | A1, A2, B3, P1 | |
| Own the post-event review and the KPIs | A5, B1 | |
| Manage the release checklist with QA | A2, C3 | |
| 3+ years producing live-service games or apps | E1 (gate question in message) | Surfaced, not bridged |
| Experience running a content calendar | A3, B2 | |
| Comfortable with player-retention metrics | C1, C2, A5 | |
| Clear written communication | V2, C3 | |

## Persona table

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | A live problem on two titles' calendars | 5. A hiring manager tests operational capability live | Clarify, structure, name one premise |
| Skeptic | "Why you? Two titles, no team, no in-app purchases" | 4. Hiring managers derisk gaps | Rehearse B1 until it is boring |
| Data-Driven Prober | Retention numbers and their assumptions | 3. The JD names KPIs and retention | Defend the number; say what you do not know |
| Pressure | Time-boxed challenge on leadership | 2. No signal either way | Pause, hold, concede the specific gap |
| Conversational | A friendly opener that is scored | 2. A 60-minute slot often opens casually | Pre-scripted 90-second arc |
| Values / Behavioral | Generic behavioral prompts | 2. No values round detected | Scaffolds with honest branches |
| Peer | Seams and credit, panel only | 2. Only if a panel | Seam principles, not claims |

No interviewer profile is available, so the interviewer read is left out. No deliverable was declared, and no company research ran, so those sections are left out too.

## Reverse questions

1. "What does a strong first 90 days look like in this role?" Why it lands: shows you are planning to deliver.
2. "After a post-event review, what changes in the next calendar? Who decides?" Why it lands: tests the KPI ownership you were asked about.
3. "How are the two titles' calendars coordinated today, and where does that break?" Why it lands: shows you have thought about the JD's hardest part.
4. "How do QA and live ops split the release checklist today?" Why it lands: your strongest artifact, and it shows where you would fit.
5. "How monetization-led are the two titles, and how do producers work with that?" Why it lands: asks about the in-app purchase gap without claiming experience.

## Sources

- Provided material: your message and the job description text.
- Searches sent, both refused by permission, so no results came back:
  - "Saltmarsh Games mobile studio live operations" (refused)
  - "Tobias Wrenfield Head of Live Operations Saltmarsh Games" (refused)

**Research tier:** L0 (searches 0 of 6 completed, 2 refused; fetches 0 of 2).

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | unavailable | Values section and values bank |
| 2. Saltmarsh Games interview process | unavailable | Loop structure and persona weights |
| 3. Saltmarsh Games strategy and recent news | unavailable | Company-knowledge bank |
| 4. Tobias Wrenfield, Saltmarsh Games | unavailable (call refused) | Interviewer read and a tailored reverse question |
| 5. Representative JD for the title | skipped | The JD you supplied fixes the fit snapshot |

## Upgrade menu

- The round type, and whether Tobias would be your manager → reweights the persona table and banks
- Tobias's public profile, if search is approved → an interviewer read, and a reverse question tied to his path
- Saltmarsh's values, titles and recent launches, if search is approved → values section, company-knowledge bank, and [generic] rows become [grounded]
- A retention figure and how it was counted → defend-the-number answers become concrete (C1, C2)
- Any drop coordinated with design, art, engineering or community → F5 moves from discovery to a stated record (A2, B3)
- Your prep time before Friday → a prioritized prep schedule
- The recruiter's note on round format → confirms or changes the loop structure

---

Two offers, neither pushed:
- **Drill:** I can play the Skeptic on B1, the question the pack names as highest-ROI, and give feedback against its guidance cell.
- **Dossier:** I can save a `tuesday-dossier.md` recording the gaps this prep exposed (F3 and F9 especially), for later sessions.

If you'd like a Word version of the pack, say so and I'll convert it.

Two questions, both of which would restructure the pack:
1. Is Friday a one-to-one with Tobias, where he'd be your manager? Or is it a panel or a different kind of round?
2. The JD requires 3+ years producing live-service games or apps. Was your associate-producer work producer-level, and was the puzzle title live-service?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh_live-ops-producer_interview_pack.md -----
# Interview prep pack: Live Operations Producer, Saltmarsh Games

**Interviewer:** Tobias Wrenfield, Head of Live Operations. Relationship assumed to be hiring manager (not yet confirmed; see the questions in the message).
**Format:** 60 minutes, Friday.
**Research tier:** L0. The web search was refused, so nothing about Saltmarsh or Tobias comes from outside your material. Company-specific sections are left out, and the rows that depend on them are marked.

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored.
- Type key: **VAL** behavioral and values; **EXP** work-experience deep-dive; **JD** role-driven, from the job description; **CO** company knowledge; **CASE** live problem.
- Guidance is scaffolding, not a script. Speak it in your own words.
- **Answer slots** say what to answer when the honest answer is "no" or "not mine". Use the honest branch. Never describe a practice you did not do.

## Fit snapshot

Requirement quotes are from the job description. Evidence quotes are from your message. "Your message" is the only source for anything about your past.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | medium | [grounded] | transferability | Your material shows one main title, a weekly content-drop calendar, two years. It does not show two titles or live events. Bridge: "For two years I ran the weekly content-drop calendar for our main title." Answer slot: if you planned or scheduled a second title, or if your content drops were live events, say so in your own words; if not, say so and say what you would set up first for two titles. |
| F2 | "experience running a content calendar" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | high | [grounded] | none | No gap. Lead with the calendar in the quote's own terms: weekly, one main title, two years. |
| F3 | "Own the post-event review and the KPIs it reports" (JD) | "Presented the monthly retention numbers to the studio head" (your message) | low | [grounded] | transferability | Your material shows presenting numbers, not owning the review or the KPIs. Bridge: "I presented the monthly retention numbers to the studio head." Answer slot: if you chose which numbers were presented, or ran a review after an event, say what, in your own words; if not, say so and say what you would put in a post-event review first. |
| F4 | "manage the release checklist with QA" (JD) | "Wrote the release checklist our QA team still uses" (your message) | medium | [grounded] | presentation | The quote reaches the checklist and QA in other terms. Bridge rewords only the quote: "I wrote the release checklist our QA team still uses." Your material does not show you running the release sign-off itself. |
| F5 | "coordinate design, art, engineering and community teams on each update" (JD) | none given | none | [grounded] | discovery | Silence, not a gap you stated. Answer slot: if you coordinated any drop across design, art, engineering or community, say who and what you handed off; if not, say so and say how you would set it up. |
| F6 | "3+ years producing live-service games or apps" (JD) | "4 years as an associate producer at a puzzle-game studio" (your message) | medium | [grounded] | hard_gate | Gate row: surfaced, not bridged. Your material does not establish that the role was producer-level or that the title was live-service. This is the question asked in the message. The only words are your own quote. |
| F7 | "comfortable with player-retention metrics" (JD) | "Presented the monthly retention numbers to the studio head" (your message) | medium | [grounded] | presentation | The quote reaches retention reporting in other terms. Bridge: "I presented the monthly retention numbers to the studio head." No figure is in your material. Name the figure here if you have one. |
| F8 | "clear written communication" (JD) | "Wrote the release checklist our QA team still uses" (your message) | low | [grounded] | transferability | One written artifact, used by another team. Bridge: "I wrote the release checklist our QA team still uses." Answer slot: name another written thing that others relied on, if you have one. |
| F9 | Leadership: not a JD line; you raised it as a gap | "Never led a team" (your message) | none | [grounded] | capability | A stated absence. Words: "I haven't led a team." Then how you got cross-team work done, as a record only if it happened; otherwise as a plan. |
| F10 | Titles with in-app purchases: not a JD line; the mobile context raises it [generic] | "never worked on a game with in-app purchases" (your message) | none | [grounded] | capability | A stated absence. Words: "I haven't worked on a game with in-app purchases." Then what you would learn first, as a plan. |

Seven rules the columns enforce:

- Confidence, Provenance and Gap type each hold one token.
- Evidence holds only your sentences, quoted, with their origin.
- Requirement quotes come only from the JD text you supplied.
- Gap and bridge language is spoken aloud. Each clause matches a quote. Where a bridge adds nothing, it says so.
- Gap rows still have words. F9 and F10 give back your own negatives. F3 and F5 are answer slots because the material is silent.
- F6 is a gate. The pack surfaces it and does not bridge it.
- The gap type follows the evidence cell, not the writer's sense of the row.

## Prohibited claims

Not coached, with the basis and the honest form for each.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the KPIs and the post-event review | Inflated form of "Presented the monthly retention numbers to the studio head" | The quote at its own scope. Our observation, not words for you: the material says presenting, not owning. B1's slot stays inside presenting. |
| Ran live-events calendars for two titles | Inflated form of "I ran the weekly content-drop calendar for our main title for the last two years" | The quote at its own scope: one main title. |
| Managed the release process with QA | Inflated form of "Wrote the release checklist our QA team still uses" | The quote at its own scope: you wrote the checklist. |
| Had producer-level, live-service experience for three years | Inflated form of "4 years as an associate producer at a puzzle-game studio" | The quote as written. Gate question asked in the message. |
| Led a team | Negative you stated: "Never led a team" | Plain acknowledgment: "I haven't led a team." No slot. |
| Worked on in-app purchases | Negative you stated: "never worked on a game with in-app purchases" | Plain acknowledgment: "I haven't worked on a game with in-app purchases." No slot. |

## Question banks

Weights: Case/Strategist 5, Skeptic 4, Data-Driven Prober 3, Pressure 2, Conversational 2, Values/Behavioral 2, Peer 2 (only if the round is a panel). Depth follows weight.

### A. Case / Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You're handed the live-events calendar for two titles, and one drop slipped a week. What do you do first?" | CASE | [generic]. Raising source: JD "Plan and run the live-events calendar for two of our mobile titles" | Clarify first: why it slipped, which players and which KPI are affected, what design, art, engineering and community each need and by when, what goes to QA. Think aloud. Name one premise you would challenge. | R1 and R2 coverage. CASE because it scores structure. |
| A2 | "Walk me through how you would coordinate design, art, engineering and community on one update, from scope to post-event review." | JD, CASE delivery | [generic]. Raising source: JD "coordinate design, art, engineering and community teams on each update" | A sequence of gates: scope lock, asset and build cutoffs, QA sign-off, community announcement, review date. Give it as a plan, not as a record. | R2, R3 and R4 coverage. |
| A3 | "How would you plan a quarter of live events across two titles?" | JD, CASE | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Start from the cadence you ran: weekly, one main title, two years. Then scale it as a plan: what you would add for the second title and how you would avoid collisions. | F1 is the evidence for the calendar requirement. The scaling is a plan, not a claim. |
| A4 | "A drop, a fix and a seasonal event collide in one week. What gets cut?" | CASE | [generic] | Give criteria: player impact by KPI, engineering dependency, risk. If you have a real instance of cutting, say it. Otherwise give the criteria and say what you would check first. | R1 and R3 coverage. |
| A5 | "What three numbers belong in a post-event review, and why those?" | JD | [generic]. Raising source: JD "own the post-event review and the KPIs it reports" | One retention number, one engagement number, one spend or monetization guardrail. Name the weakest assumption in your choice before they do. You have not run this with in-app purchases, so say so and say what you would learn. | R3 and R7 coverage. |

### B. Skeptic (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The JD makes the producer own the post-event review and the KPIs. You presented retention numbers. Who owned the KPIs in your role?" | JD | [grounded] "Presented the monthly retention numbers to the studio head" | **Highest-ROI prep in this pack.** The hold: "I presented the monthly retention numbers to the studio head." Name the limit first: presenting, not owning. Answer slot: if you chose the numbers or ran a review after an event, say how, in your own words; if not, say so plainly and say what you would own first. Hold through two follow-ups by returning to what you presented. Do not add ownership to make the answer land. | F3 is the weakest row and the JD names the requirement directly. This objection is coming in some form, so it gets the deepest rehearsal. |
| B2 | "You have run one title's calendar. Why should we believe the second one won't slip?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Stay with the one-title record. Answer slot: if you planned or ran a second calendar, or a schedule across titles, say how; if not, say so and say the first thing you would set up. | F1 transferability. |
| B3 | "You've never led a team. How do you coordinate four functions without leading them?" | EXP | [grounded] "Never led a team" | Plain acknowledgment: "I haven't led a team." Then answer slot: name a time you got cross-team work done without authority, if one happened; if none did, say how you would do it as a plan. | F9. Coordination is the JD line; leadership is not. |
| B4 | "Monetization drives most mobile live-ops decisions. What do you know about in-app purchases in a live calendar?" | JD | [grounded] "never worked on a game with in-app purchases" | Plain acknowledgment: "I haven't worked on a game with in-app purchases." Then what you would learn first, as a plan. | F10. Not a JD line, but a probe the mobile context raises. |

### C. Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the retention numbers you presented were calculated." | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Defend-the-number: how it was counted, what it is sensitive to, the assumption you would defend least, which part was yours. Answer slot: if you did the counting, say how in your own words; if it was not yours, say so plainly and say what you could and could not check. | F7 is the evidence for retention metrics. |
| C2 | "Which assumption behind that retention figure would you defend least?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Name the weakest assumption before they do. If you do not know how the figure was counted, say so plainly. | Weakest-assumption move. |
| C3 | "Tell me about a time a checklist you wrote changed a release decision." | EXP | [grounded] "Wrote the release checklist our QA team still uses" | Open prompt. Story-map from the quote: you wrote it, and QA still uses it. Answer slot: if one of its items changed a release, say which and how; if not, say so and say what you would check first. | F4. Premised on nothing the quote does not carry. |

### D. Pressure / Stress (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why hire someone who has never led a team for a role that coordinates four functions?" | JD | [grounded] "Never led a team" | Pause and restate the question. Hold a position you can back: the calendar record and the checklist. Plain acknowledgment: "I haven't led a team." Hold through two follow-ups. Concede the leadership gap specifically. Do not fold on the calendar record. | F9 and F1. Hold-then-concede structure. |
| D2 | "That retention presentation: how much of it was actually you?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Two honest branches. If you produced the numbers, say how. If you presented numbers someone else produced, say so plainly, then say what you did do. | Attribution honesty under pressure. |

### E. Conversational / Rapport (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey to here." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio" | A 90-second arc: the puzzle studio, the associate producer role, the calendar, the checklist, the retention presentation. Use only what is in your material. | Casual but scored. Also where the gate question surfaces. |
| E2 | "What are you playing right now in mobile, and what would you change in it?" | JD | [generic] | Name a title you actually play and one live-ops decision you would question, and why. Talk only about your own play. Say nothing about Saltmarsh's games. | Comfort with the mobile product, scored casually. |

### V. Values / Behavioral (weight 2; generic, no values research)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V1 | "Tell me about a time you had to deliver unwelcome news to a team." | VAL | [generic] | Selection scaffold: pick a time you delivered a slipped drop or a bad call to design or engineering. It needs a named stake, your words, and what changed. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it. | No values detected, so this is generic. |
| V2 | "Tell me about a document you wrote that people still rely on." | VAL | [grounded] "Wrote the release checklist our QA team still uses" | Open prompt, story-mapped from the quote: you wrote it, and QA still uses it. Answer slot: if a team's behavior changed because of it, say how; if not, say what it is for. | F8. Clear written communication. |

### P. Peer (weight 2; only if the round is a panel)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Our teams sit side by side. Where is the seam between live ops and QA, and what happens when you disagree?" | VAL | [generic] | Propose seam principles, not claims about their team. Give one disagreement story from your own material, or say you have not had one. | Panel-only. |
| P2 | "How do you handle credit when a drop spans several teams?" | VAL | [generic] | Name credit as shared, then one specific instance from your material. If there is none, say so. | Panel-only. |

## Requirement coverage

| JD requirement | Questions | Note |
|---|---|---|
| Plan and run the live-events calendar for two titles | A1, A3, B2 | |
| Coordinate design, art, engineering and community | A1, A2, B3, P1 | |
| Own the post-event review and the KPIs | A5, B1 | |
| Manage the release checklist with QA | A2, C3 | |
| 3+ years producing live-service games or apps | E1 (gate question in message) | Surfaced, not bridged |
| Experience running a content calendar | A3, B2 | |
| Comfortable with player-retention metrics | C1, C2, A5 | |
| Clear written communication | V2, C3 | |

## Persona table

| Persona | How it shows up here | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | A live problem on two titles' calendars | 5. A hiring manager buys operational capability and tests it live | Clarify, then structure, then name one premise |
| Skeptic | "Why you? Two titles, no team, no in-app purchases" | 4. Hiring managers derisk gaps | Rehearse B1 until it is boring; plain acknowledgments where you have them |
| Data-Driven Prober | Retention numbers and their assumptions | 3. The JD names KPIs and retention | Defend the number; say what you do not know |
| Pressure | Time-boxed challenge on leadership | 2. No signal either way | Pause, hold, concede the specific gap |
| Conversational | A friendly opener that is scored | 2. A 60-minute slot often opens casually | Pre-scripted 90-second arc |
| Values / Behavioral | Generic behavioral prompts | 2. No values round detected; no company values in hand | Scaffolds with honest branches |
| Peer | Seams and credit, panel only | 2. Only if the round is a panel | Seam principles, not claims |

No interviewer profile is available, so the interviewer read is left out. No deliverable was declared, and no values or strategy research ran, so those sections are left out too.

## Reverse questions

1. "What does a strong first 90 days look like in this role?" Why it lands: shows you are planning to deliver.
2. "After a post-event review, what changes in the next calendar? Who decides?" Why it lands: tests the KPI ownership you were asked about.
3. "How are the two titles' calendars coordinated today, and where does that break?" Why it lands: shows you have already thought about the JD's hardest part.
4. "How do QA and live ops split the release checklist today?" Why it lands: the checklist is your strongest artifact, and this tells you where you would fit.
5. "How monetization-led are the two titles, and how do producers work with that?" Why it lands: asks about the in-app purchase gap without claiming experience.

No reverse question is tied to the interviewer's own path, because no profile exists.

## Sources

- Provided material: your message, and the job description text in the request.
- Searches sent, all refused by permission, so no results came back:
  - "Saltmarsh Games mobile studio live operations" (refused)
  - "Tobias Wrenfield Head of Live Operations Saltmarsh Games" (refused)

**Research tier:** L0 (searches 0 of 6 completed, 2 refused; fetches 0 of 2).

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | unavailable | Values section and the values bank would be grounded in company language |
| 2. Saltmarsh Games interview process | unavailable | Loop structure; persona weights would follow the named rounds |
| 3. Saltmarsh Games strategy and recent news | unavailable | The company-knowledge bank |
| 4. Tobias Wrenfield, Saltmarsh Games | unavailable (call refused) | The interviewer read and a tailored reverse question |
| 5. Representative JD for the title | skipped | The JD you supplied fixes the fit snapshot |

## Upgrade menu

- The round type, and whether Tobias would be your manager → reweights the persona table and the question banks
- Tobias's public profile, if search is approved → an interviewer read, and a reverse question tied to his path
- Saltmarsh's values, titles and recent launches, if search is approved → the values section, the company-knowledge bank, and [generic] rows become [grounded]
- A retention figure and how it was counted → the defend-the-number answers become concrete (rows C1, C2)
- Any drop coordinated with design, art, engineering or community → F5 moves from discovery to a stated record (A2, B3)
- Your prep time before Friday → a prioritized prep schedule
- The recruiter's note on round format → confirms or changes the loop structure
