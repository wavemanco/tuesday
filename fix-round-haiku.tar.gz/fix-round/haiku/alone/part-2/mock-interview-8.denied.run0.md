Your prep pack is saved as `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-alone-part-2-rooms-case-8-denied-baf8e937/2cd8b659-c4ff-456c-9b1d-8d7e762028a2/scratchpad/Ashgrove_Credit_Union_member_experience_lead_interview_pack.md`. It covers all three rounds in loop mode: a shared fit snapshot, then 8 questions per round with reverse questions, a values cheat sheet in round 3, and an upgrade menu at the end. I built it on the JD and background you gave, and weighted each round by its role because no interviewer names were given.

Three things from the pack to look at first:

- **The highest-ROI prep is B5**, the scope objection: "You've handled one branch's log. Why should I trust you with the bigger job?" Your material shows one branch's formal log, not end-to-end ownership across branches and the contact centre. The answer holds on what you handled, concedes the contact-centre gap plainly, and turns the rest into a plan rather than a claimed past.
- **Your most-quoted artifact is a number.** The monthly spreadsheet is the only thing you've described that fits the values round, but the "Neighbours, Not Numbers" story it would suggest is one you'd have to invent. C4 gives a scaffold with an honest "none" branch instead.
- **Two gaps should be stated plainly, not bridged:** no presenting above regional level, and no contact-centre work. The pack gives you the exact sentences for both.

The pack also lists six claims it won't coach, such as "presented to senior leaders" and "Excel", with the honest wording for each.

I haven't run any web research. The values, strategy brief and round structure you gave cover what the pack needed. The upgrade menu lists what would sharpen it, including interviewer names and what the spreadsheet tracked.

If you want to run a drill, I can play the branch-manager panel on B5 or C1 and give feedback against each question's guidance. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, which you can carry into later sessions. If you'd like a Word version of the pack, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Ashgrove_Credit_Union_member_experience_lead_interview_pack.md -----
# Interview prep pack: Member Experience Lead, Ashgrove Credit Union

Candidate: Dara. Built 11 November 2026 for three rounds on 20 November 2026: recruiter screen (30 min), Head of Member Services (45 min, your future manager, mostly behavioural), and a panel of two branch managers (60 min, including a 20-minute complaint escalation case, scored against the four values). No interviewer names were given, so personas are weighted by round and role.

Mode: loop. One shared fit snapshot and sources block, then a mini-pack per round.

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored.
- Type key: **VAL** behavioural and values alignment. **EXP** your own experience, tested for attribution. **JD** the role's stated requirements. **CO** Ashgrove's strategy and context. **CASE** a live problem from the role.
- Question IDs: A for round 1, B for round 2, C for round 3. Fit snapshot rows are F1 to F8.
- Provenance cells show the label and, where the guidance makes a claim about you, your own sentences quoted exactly. A row marked `[generic]` makes no claim about you.
- Guidance is scaffolding for a spoken answer, not a script. Say it in your own words.

## The fit snapshot

*Bridge language is proposed, pending your approval.*

Requirements are quoted from the job description. Evidence is quoted from your message. Nothing in the evidence column is paraphrased.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" (JD) | "6 years in retail banking, the last 3 as a branch supervisor." (your message) | medium | [grounded] | presentation | Your sentence gives the years and the branch role, not a customer-operations title, so keep the words as they are: "For six years I've worked in retail banking, three of them as a branch supervisor." Observation: the material does not show a role with that exact name. A5 holds the slot. |
| F2 | "Own the member complaints process end to end across branches and the contact centre" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | transferability | Adjacent work at one branch: a log, not the whole process, and no contact centre. Bridge: "I handled the branch's formal complaints log." Answer slot: the end-to-end line makes a probe on the stages likely. If you followed complaints beyond the log, say which and how; if the log was your whole part, say so and stay with it. |
| F3 | "experience handling regulated complaints" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | discovery | The quote touches the requirement without showing whether it reaches it. Formal is not the same as regulated, and the material does not say which rules applied. Answer slot: say what made a complaint formal at your branch, and what rules or deadlines the log had to meet, if you know them. If you worked to none, say so plainly. |
| F4 | "coach branch supervisors on escalations" (JD) | "trained new tellers on our escalation script" (your message); "the last 3 as a branch supervisor" (your message) | medium | [grounded] | transferability | Training tellers is adjacent to coaching supervisors. Bridge: "I trained new tellers on our escalation script, and for three years I was a branch supervisor." Answer slot: if you coached anyone on escalations, say how. If not, say what you did with tellers, and how coaching a supervisor would differ, as a plan. |
| F5 | "report monthly on complaint volumes and resolution times" (JD) | "I built the monthly complaints spreadsheet our regional manager uses." (your message) | medium | [grounded] | none | Reaches the requirement in role-relevant terms. Your sentence does not name volumes or resolution times, so expect a probe on what the spreadsheet tracked. No bridge needed; keep the words. A6 and C3 hold the slots. |
| F6 | "work with digital teams on self-service journeys" (JD) | none given | none | [grounded] | discovery | The material is silent here, which is not the same as a negative. Answer slot: if you worked with anyone on digital or self-service, say who and what. If not, say so and say how you would start, as a plan. |
| F7 | "confident presenting to senior leaders" (JD) | "I've never presented to anyone above regional level." (your message) | none | [grounded] | capability | You stated the absence at senior level. Words: "I've never presented to anyone above regional level." Then describe how you would prepare, as a plan, never as a past. |
| F8 | "comfortable with Excel reporting" (JD) | "I built the monthly complaints spreadsheet our regional manager uses." (your message) | medium | [grounded] | none | Reaches the requirement in role-relevant terms. The tool is not named. Say which tool you used, in your own words (A6). Do not say Excel unless it was. |

Gap-type routing: F7 is `capability` because you stated the absence. F6 is `discovery` because the material is silent. F3 and F4 are the rows where your sentence touches the requirement without showing it reaches it.

## Grounding brief: Ashgrove's 2026 strategy

Source: the strategy brief published in July 2026, sent by the recruiter. Not checked against any other source. Nothing in it is flagged as stale.

| Strategy item | Provenance | What it means for complaints | Used in |
|---|---|---|---|
| Move 40% of member service to digital channels by 2028 | [grounded] strategy brief, July 2026 | More complaints will arrive through digital journeys, so routing and ownership matter more | B8, A2, F6 |
| Consolidate eight branches into five hubs during 2027 | [grounded] strategy brief, July 2026 | Branch-level complaints are in motion; open cases must not be lost in the change | B7, B2 |
| Small-business lending product in Q1 2027 | [grounded] strategy brief, July 2026 | A new product brings a new regulated complaint stream | C2, B5 |
| Competitive pressure from app-only banks | [grounded] strategy brief, July 2026 | Members will compare speed and ease with app experiences | A7 |

Tension to be ready for: the value "Neighbours, Not Numbers" sits beside a plan to consolidate branches. Do not critique the plan to the panel. Ask how complaints from a closing branch's members will be handled.

---

## Round 1: Recruiter screen (30 minutes)

**Personas**

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / rapport | Friendly opener, logistics, motivation | 3 questions: a recruiter screen leads with biography and motivation | Practise the 90-second arc; treat casual questions as scored |
| Skeptic | Knockout checks against the four requirements | 3 questions: the screen is where the requirements are checked off | Name the gaps before they are asked; no bluffing |
| Case / CO | Light strategy check | 2 questions: lighter than a hiring-manager round | Use the strategy brief's own language |

*Guidance is proposed, pending your approval.*

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, walk me through the journey to here." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log" "I built the monthly complaints spreadsheet our regional manager uses." | A 90-second arc in your words: six years in retail banking, three as a branch supervisor. Then the formal complaints log you handled, then the monthly spreadsheet your regional manager uses. Close on why that work points to this role. | The biography question is always scored. It draws on F1, F2 and F5, and nothing else. |
| A2 | "What drew you to Ashgrove?" | CO | [grounded] strategy brief, July 2026 | Name one thing from the July brief in your own words, such as the move to digital service or the hub plan. Say what it would mean for complaints. Do not recite the brief. | Shows you read the brief. Recruiters check that the answer is current, not general. |
| A3 | "What does a normal week of complaints work look like for you?" | EXP | [grounded] "I handled the branch's formal complaints log" | Describe the log and how you worked it, in your own words. Answer slot: if other work filled the week, say what. Do not give case counts or timings you did not record. | An open prompt about the one sentence you have on complaints. It tests whether the log is real work you can describe. |
| A4 | "Never worked in a contact centre. Why shouldn't I screen you out?" | JD | [grounded] "Never worked in a contact centre" | "I haven't worked in a contact centre." Then the nearest thing you have: the formal complaints log at branch level. Do not claim knowledge of contact-centre routines. | This is the knockout most likely to be asked first. Calibrated candour beats a bluff. Source: F2 and P5. |
| A5 | "The role asks for four years in financial-services customer operations. How do six years in retail banking match that?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | State the six years and the three as a branch supervisor. Then say what the branch's customer work involved day to day, in your words. Do not extend the years to a title. | Tests the requirement that is easiest to overstate. F1 is the evidence, presentation-gap only. |
| A6 | "You built a spreadsheet. Which tool was it, and what did it record?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Name the tool you used. Answer slot: if it was Excel, say so; if it was another tool, name it. Say what it recorded, as far as you set it up. If you did not set its columns, say who did. | Tests the Excel requirement (F8) and the monthly report (F5). A figure would raise a defend-the-number slot; none is given here. |
| A7 | "What do you think app-only banks are doing to member expectations?" | CO | [grounded] strategy brief, July 2026: "Competitive pressure from app-only banks" | Say what expectations shift toward, speed and ease, in your own words, and what that means for how a complaint is taken and answered. | Tests whether the strategy is internalised. Lighter than round 2 but scored. |
| A8 | "What would you do in your first 90 days?" | CASE | [generic] | Listen first: map complaints from branches and the contact centre. Check what the monthly report counts against what members say. Name one early change you would test, and how you would know it worked. | A live problem from the role. It makes no claim about your past. |

**Reverse questions (round 1)**

| Question | Why it lands |
|---|---|
| "What happens after the three rounds, and when would you expect to decide?" | Shows you are planning the process, not waiting for it |
| "Who else will I meet, and what does each round score?" | The panel scores against the values. Knowing the scoring frame helps you prepare |
| "Is there anything about the role you'd want me to address before the 20th?" | Invites the recruiter to name a concern while there is still time to answer it |

---

## Round 2: Head of Member Services (45 minutes, your future manager)

**Personas**

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Values / behavioural | STAR-shaped questions on the four values | 3 questions: the round is mostly behavioural | Map each story to a value only where your sentences carry it; say so when they do not |
| Skeptic (with Pressure in B5) | Probes the gaps: scope, contact centre, senior presenting | 3 questions: hiring-manager prior is Skeptic plus Case, and the scope gap is the one a manager tests first | Name the gaps first; hold one position through two follow-ups, then concede exactly |
| Case / strategist | A live problem on the hubs or digital routing | 2 questions: a manager buys capability and tests it on the roadmap | Clarify, then structure, then state your metrics |

*Guidance is proposed, pending your approval.*

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a complaint you took all the way through to the end yourself." | VAL | [grounded] "I handled the branch's formal complaints log" | Pick one case from the formal log. Say what came in, what you did, and how you knew it had closed. Answer slot: if you followed it past the first reply, say how. If you only logged it, say so and what you did with the outcome. | Tests the end-to-end requirement with the Own the Fix value. F2 is the only evidence and it is adjacent. |
| B2 | "Tell me about a time you decided something from the member's side of the counter." | VAL | [generic] scaffold; nearest carrier: "I handled the branch's formal complaints log" | Pick a complaint outcome that turned on what the member needed. If no such time comes to mind, say so plainly, then give the nearest thing: the formal log and what you did in it. | Members First is scored. Your sentences do not show the member's side, so the scaffold makes the honest branch the default. |
| B3 | "Tell me about a time someone needed an explanation twice." | VAL | [grounded] "trained new tellers on our escalation script" | Pick a time an explanation had to be given again. Beats: the first wording, why it did not land, the second. Answer slot: if you rewrote the script after tellers got stuck, say so. If you did not, say what you did. | Plain Words. The training sentence carries the teaching, not the wording, so the wording is a slot. |
| B4 | "What part of this role would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre" "I've never presented to anyone above regional level." | Name the two plainly: the contact centre, and presenting above regional level. Then give your plan for each, as a plan. Do not soften either into experience. | A direct gap question. F7 and P5 are both stated by you, so you can say them plainly. |
| B5 | "The role owns complaints across every branch and the contact centre. You've handled one branch's log. Why should I trust you with the bigger job?" | JD | [grounded] "I handled the branch's formal complaints log" "I built the monthly complaints spreadsheet our regional manager uses." "Never worked in a contact centre" | Hold: "I handled the branch's formal complaints log, and that is the part I can speak to." If pressed on scope across branches, answer as a plan, not a past: "I would map open complaints by branch and by route before changing anything." If pressed again, concede exactly: "I haven't worked in a contact centre, and I haven't run a process across more than one branch." Then return to what you would bring and how you would learn the rest. Never add a second branch or a contact-centre month to the answer. | Highest-ROI prep in this pack. The scope gap in F2 is the objection a manager will test first, in some form. Deepest rehearsal here: two follow-ups, one exact concession, and the limit named before it is asked for. |
| B6 | "How would you coach a branch supervisor who sends every complaint up to you?" | JD | [inferred] derived from "trained new tellers on our escalation script" and "the last 3 as a branch supervisor" | Answer slot: if you coached anyone on escalations, say how. If you trained tellers on the script, say that. Then say how coaching a supervisor would differ, as a plan. You were a supervisor for three years, so you can speak from that side of the desk. | The JD raises coaching supervisors on escalations. F4 is a training fact, so the answer is a slot, not a claim. |
| B7 | "If a few branches were combined into hubs, what would you check first about complaints?" | CASE | [generic] strategy brief, July 2026: "Consolidate eight branches into five hubs during 2027" | Clarify: which complaint types, which members, what changes at the hub. Objective: no complaint lost or delayed in the move. Approach: list open complaints per branch before the move; track open count, age and anything reopened. Name the member whose town loses its branch. | Tests strategic altitude on the hub plan. Written as a hypothetical, so it presumes nothing about the plan. |
| B8 | "If more complaints came in through the app than through branches, how would you route them?" | CASE | [generic] strategy brief, July 2026: "Move 40% of member service to digital channels by 2028" | Clarify channel mix, volume and timescales. Route each complaint to one owner until solved. Give the supervisor a view of what is open. Answer slot: if you have worked with a digital team on any journey, say which. If not, say you would start with the journey map. | Tests the digital requirement (F6) without asserting digital experience. |

**Reverse questions (round 2)**

| Question | Why it lands |
|---|---|
| "What would a strong first 90 days look like in this role?" | Shows you are planning ownership, not waiting for a brief |
| "How are complaints across the eight branches reported to you today, and what would you change first?" | Signals you have read the structure and want to know the real baseline |
| "How will complaints handling be kept in view while the hubs are set up?" | Lands on the 2027 plan and the member who loses a branch, without critiquing it |
| "Which part of the complaints process works least well today?" | Candour in the question invites candour back |
| "How do you want escalations from branch supervisors handled in practice?" | Ties the coaching requirement to how the manager actually works |

---

## Round 3: Panel of two branch managers (60 minutes, with a 20-minute case)

Values scoring happens in this round, so the values cheat sheet sits here.

**Personas**

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Case / strategist | The 20-minute escalation case | 3 questions: a third of the round is a live case | Clarify what resolved means, then structure, then decide and record |
| Values / behavioural | Each panellist scores against the four values | 3 questions: the panel's score is the values score | One story per value, carried only by your own sentences; say when there is none |
| Peer evaluator | Seams between branch and contact centre, credit | 2 questions: branch managers judge what the hire adds to their work | Reciprocity: what you bring their branches, not only what you need |

Panel members are not yet named, so each member's persona is not assigned.

*Guidance is proposed, pending your approval.*

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A member has complained three times about the same fee at your branch. The supervisor says it's resolved. The member says it isn't. What do you do?" | CASE | [generic] | Clarify what "resolved" means and what the record shows across the three contacts. Objective: the member's fix, and a record that matches it. Options: check the fee's cause with the supervisor; check whether other members paid it; decide who owns the fix. Say what you would report, and to whom. Answer slot: if you have handled a repeat complaint before, say how, using the formal log. | The 20-minute case is an escalation. It presumes nothing about you, so the guidance makes no claim. |
| C2 | "The member says they'll take it further outside the credit union. What changes in how you handle it?" | JD | [generic] | Name the outside route, the clock you would check, and who else must know. Say what you would tell the member and when. Do not name a rule you cannot cite. | Tests regulated-complaint handling (F3) as a live problem rather than a record. |
| C3 | "Complaints in your branches are up this quarter. Where do you start, and what does the monthly report show?" | CASE | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Clarify: volumes or rate. Split by product, channel and branch. Check what the report counts before reading any trend. Answer slot: if you used your spreadsheet for trend reads, say what it counted. If you did not, say what you would check first. | Tests F5 and F8 under pressure. The spreadsheet is the nearest evidence, so the slot is about what it counted. |
| C4 | "Tell me about a time a number pointed one way and the people in a branch pointed the other." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Your most-quoted artifact is a number, so this is the trap. Scaffold: pick a time a local fact changed what a figure meant for you. If no such time comes to mind, say so plainly, then say how you would keep a monthly report honest about a branch's circumstances. Do not present the spreadsheet as a neighbours story unless you can name the local fact. | Neighbours, Not Numbers is scored. Your only quoted artifact is a figure, so a rehearsed story here would be invented. |
| C5 | "Tell me about a time you explained something to a member or colleague and had to explain it again." | VAL | [grounded] "trained new tellers on our escalation script" | Pick a time an explanation had to be given twice. Beats: the first wording, what changed, the second. If no such time comes to mind, say so plainly, then give the nearest thing: the training you gave. | Plain Words is scored. The training sentence carries the teaching, not the wording. |
| C6 | "Tell me about a complaint you did not let go of until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log" | Pick a case. Say what you did after the log entry, and how you knew it was solved. Answer slot: if you only logged it and moved on, say so, and say what you would do differently. | Own the Fix is scored. The log sentence is the nearest carrier, and it covers handling, not outcome. |
| C7 | "Our branches send escalations to the contact centre. Where's the seam, and what happens when we disagree about who owns a complaint?" | JD | [generic] and plain acknowledgment: "Never worked in a contact centre" | Propose a principle, not a fact: one owner for each complaint until it is solved. Say you have not worked in a contact centre, and that you would want the seam described by the people on both sides first. Do not claim knowledge of how the contact centre works. | Peer seam probe. The honest answer is a principle plus a request to learn. |
| C8 | "How do you give credit when your team fixes a complaint but the contact centre logged it?" | VAL | [generic] | Name who did which step. Credit the people who did the step, and say so plainly. Do not claim the whole flow. | Credit-sharing is a peer probe. The answer is about naming, which needs no claim about your past. |

**Values cheat sheet**

*Proposed language, pending your approval.* Each value maps to a story only where a sentence of yours carries one. Where none does, the scaffold ends in the honest branch.

| Value (official name) | Working meaning | Mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | F2 carries handling, not the member's side. Scaffold: pick a complaint outcome that turned on what the member needed. If none comes to mind, say so, then give the formal log. |
| Plain Words | If a member needs it explained twice, it was written wrong | F4's training sentence carries the teaching, not the wording. Scaffold: pick a time an explanation had to be given twice. If none, say so, then give the training. |
| Neighbours, Not Numbers | Every branch is part of its town | F5 is a figure, and the trap. Scaffold: pick a time a local fact changed what a figure meant. If none, say so plainly, then say how you would keep the report honest about a branch's circumstances. |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | F2 carries handling at its own scope. Scaffold: pick a complaint you kept until it was solved. If you only logged it, say so and what you would change. |

**Reverse questions (round 3)**

| Question | Why it lands |
|---|---|
| "What could a new person do in their first month that would genuinely help your branch?" | Reciprocity. The branch managers are the peers the hire affects |
| "When a complaint crosses between your branch and the contact centre, who owns it today?" | Probes the seam from the inside, which the panel will know |
| "What does a branch manager need from the complaints function that it doesn't give you now?" | Puts Neighbours, Not Numbers into a practical question |
| "How do you know a complaint is fixed, rather than just closed?" | Signals you already think in terms of Own the Fix |
| "What would a strong answer to the escalation case look like to you?" | Shows you want the standard, not just the answer. Some panels will not answer; that is still information |

---

## Requirement coverage

Each JD requirement mapped to the questions that cover it.

| JD requirement | Covered by |
|---|---|
| Own the member complaints process end to end across branches and the contact centre | B1, B5, C1, C7 |
| Report monthly on complaint volumes and resolution times | A6, C3, F5 |
| Coach branch supervisors on escalations | B6, C1 |
| Work with digital teams on self-service journeys | B8, F6. No question asserts digital experience |
| 4+ years in financial-services customer operations | A5 |
| Experience handling regulated complaints | C2, F3 |
| Confident presenting to senior leaders | B4, F7. None of the three rounds asks for a presentation, so no presenting question is rehearsed |
| Comfortable with Excel reporting | A6, F8 |

## Prohibited claims

Built from the fit snapshot, before the question banks were written. The pack will not coach any of these, and each lists its basis.

| Not coached | Basis | Honest form |
|---|---|---|
| Ran the complaints process end to end across branches and the contact centre | Inflated form of F2 | "I handled the branch's formal complaints log." Observation: your material shows one branch's log, not the process across branches. B5 stays inside the log. |
| Handled regulated complaints | Inflated form of F3 | "I handled the branch's formal complaints log." Observation: the material says formal, not regulated. F3's slot asks only what made them formal. |
| Coached branch supervisors on escalations | Inflated form of F4 | "I trained new tellers on our escalation script." Observation: no coaching of supervisors is shown. |
| Presented to senior leaders | Stated negative, F7 | Plain acknowledgment: "I've never presented to anyone above regional level." No slot. |
| Worked in a contact centre | Stated negative, your message | Plain acknowledgment: "I haven't worked in a contact centre." |
| Built the reporting in Excel | Inflated tool name, F8 | "I built the monthly complaints spreadsheet our regional manager uses." Name the tool only if you say which one you used. |

---

## Sources

**Provided documents**
- Job description, pasted.
- Your background, from your message: six years in retail banking, the last three as a branch supervisor; the formal complaints log; the escalation script training; the monthly complaints spreadsheet; no contact-centre work; no presenting above regional level.
- Values, copied from the Ashgrove website on 11 November 2026.
- Strategy brief, July 2026, sent by the recruiter.
- Recruiter email on the three rounds on 20 November 2026.

**Searches and fetches**

None sent. Every target below is fixed by a provided input, so no call was needed.

**Research tier: L1, searches 0 of 6, fetches 0 of 2**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | The values text is in hand. The values cheat sheet in round 3 runs on it |
| 2. Ashgrove interview process, member services | skipped | The recruiter's email fixes the three rounds, their lengths and the panel's makeup. Persona weights follow them |
| 3. Ashgrove strategy and recent news | skipped | The July 2026 brief is in hand. The grounding brief uses it and was not checked against news |
| 4. Interviewer name and background | n/a | No names were given, so there was no query to form. Round personas are weighted by role |
| 5. Representative JD for the title | skipped | The JD supplied fixes the fit snapshot and the JD-tagged questions |

Deep-research targets (L2) were not run. They are offered in the upgrade menu.

## Upgrade menu

- Interviewer names for rounds 1 to 3 → a read of each interviewer's public background, persona weights per interviewer, and reverse questions tied to their path.
- The tool you used for the monthly spreadsheet, and its column headings in your own words → A6, C3 and F8 can state what it tracked, grounded in your sentences rather than in a slot.
- What made complaints "formal" at your branch, and any rules or deadlines the log had to meet → F3 and C2 move from discovery to grounded wording.
- Any work with digital or self-service teams, even small → F6 gets a quote, and B8 can use it.
- Any coaching of colleagues on escalations, or any presenting beyond your regional manager → F4 and F7 can be upgraded from their current wording.
- Your full CV → fit-snapshot rows can quote beyond the summary sentences you gave here.
- Any presentation or take-home that the recruiter requests before 20 November → a build section for each deliverable.
- Deep research (L2): up to six more searches and two fetches, covering recent Ashgrove news, the strategy brief against other coverage, and role-family loop reports. Time cost: a few minutes of checking.
