Your prep pack is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-alone-part-2-rooms-case-7-denied-f19fbd12/01689852-88bc-4a30-a346-1613e4c0ea31/scratchpad/saltmarsh_live_operations_producer_interview_pack.md`. I built it for a hiring-manager round, since Tobias heads the function. Company facts are missing because the web search permission was refused, so I did not retry it.

**Key points**

- **Your strongest material:** the weekly content-drop calendar (two years), the release checklist QA still uses, and the monthly retention presentation. Each maps to a JD line, and the pack quotes your sentences exactly.
- **Biggest gap, highest-ROI prep (B2):** in-app purchases. Live-ops roles at mobile studios usually carry monetisation, so expect a probe. The honest answer is "I haven't worked on a game with in-app purchases," followed by the questions you would ask the economy team, framed as a plan, not a past.
- **Second gap (B3, D1):** "I haven't led a team," then a concrete 90-day plan. Don't stretch "coordinated" into "led."
- **Inflation traps:** don't say you ran live events across two titles, owned the post-event review, or managed the QA release process. Each one stretches a sentence you actually wrote. The pack's prohibited list gives the honest wording for each.
- **Weakest evidence:** owning KPIs (you presented numbers; the pack does not show who defined them) and coordinating design, art and engineering (no evidence either way).
- **Questions:** 19 across six personas, with case questions weighted highest, plus six reverse questions for Tobias. The case and CO questions are labelled `[generic]`, since no company research ran.

**Questions for you** (the pack is built on the assumptions above, so these would reshape it):

1. Is Tobias your future manager, or are there other interviewers or a recruiter exercise in the 60 minutes?
2. Is the role location-based, or does it need work authorisation you should check first?

**Offers, not pushed:**
- I can run a live drill with Tobias's persona on B2, the in-app purchases question, and give feedback against that question's guidance.
- I can save a `tuesday-dossier.md` recording the gaps this prep exposed, so they carry into later sessions.
- I can convert the pack to a Word document if you'd like one.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh_live_operations_producer_interview_pack.md -----
# Live Operations Producer, Saltmarsh Games: interview prep pack

Interviewer: Tobias Wrenfield, Head of Live Operations. Relationship assumed: hiring manager (not yet confirmed; see the first question in the message). Round: 60 minutes, one session. Research tier: L0 (see Sources: web search was not permitted, so company facts are absent or labelled `[generic]`).

## How to use this pack and the type key

Personas describe how a question arrives. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and stop where your material stops.

| Tag | Name | What it scores |
|---|---|---|
| VAL | Behavioural / values | Whether past behaviour shows the values; no company values are in hand, so these are generic |
| EXP | Experience deep-dive | Whether what you wrote on your CV or told me holds up under scrutiny |
| JD | Role / JD-driven | Whether you can do the listed job, including its gaps |
| CO | Company knowledge | Homework depth. Not grounded: no research ran |
| CASE | Live problem | Structure and reasoning on a problem from the role |

## Fit snapshot

Requirements are quoted from the JD you supplied. Your evidence is quoted from your message. Gap and bridge language is what you may say aloud; anything in an answer slot is a question for you to answer in the interview, not a claim.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material says a content-drop calendar for one title, for two years. It does not show live events, or more than one title. Say the one-title calendar in your own words. Answer slot: if you have planned for more than one title, or planned live events rather than drops, say what that was; if not, say so and say how you would run two. |
| F2 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | The quote reaches the requirement directly. Limit: it does not show how the calendar was kept. Expect a probe on method. |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | low | [inferred] | transferability | Presenting numbers is adjacent to owning a review and its KPIs, and the bridge should not be stretched. Your material does not show whether you defined the numbers or ran any review. Answer slot: if you chose which numbers were reported, or ran a review after a release, say how; if you presented numbers others defined, say so. |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | none | The quote reaches the requirement in role terms. Limit: it shows the checklist was written and is still used, not that you ran each release against it. Expect a probe. |
| F5 | "coordinate design, art, engineering and community teams on each update" — JD | none given | none | [grounded] | discovery | Nothing in your material shows coordinating these functions. Answer slot: if you coordinated any of them on a release, name which and how; if you did not, say so plainly. |
| F6 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message | medium | [grounded] | transferability | Four years of producing at a puzzle-game studio covers the length. The sentence does not say the title was live-service; F2's calendar describes regular drops, which bears on that and no further. Answer slot: describe the title's update model in your own words. |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | presentation | The quote reaches the requirement in other terms. Say it as it stands: you presented the monthly retention numbers to the studio head. Add nothing to it. |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | low | [inferred] | discovery | A written artifact exists. Nothing shows how the writing reached a decision or a reader outside QA. Answer slot: name a piece of writing someone acted on; if you have no example, say so and offer a sample. |
| F9 | Live-service monetisation experience (not in the JD; raised by you) | "never worked on a game with in-app purchases" — your message | none | [grounded] | capability | A stated absence. Words: "I haven't worked on a game with in-app purchases." Then how you would learn it, said as a plan, never as a past. Nothing added to make the gap feel smaller. |
| F10 | Leading a team (not in the JD as written; raised by you. The JD's coordination line is F5) | "Never led a team" — your message | none | [grounded] | capability | A stated absence. Words: "I haven't led a team." Then a plan. The pack does not turn coordinating into leading. |

Gate check: the JD names no location, work-authorisation or schedule gate. The pack cannot tell whether one applies; see the questions in the message.

Observation (analysis, not words for you): the material shows a one-title content calendar, a checklist, and a retention presentation. It does not show live events across two titles, owning a post-event review, coordinating four functions, leading anyone, or live-service monetisation.

## Prohibited claims

Built locally from the fit snapshot. Each entry names its basis; each has one honest form. None of these may be coached, implied or softened in any answer.

| Not coached | Basis | Honest form |
|---|---|---|
| Led or managed a team | Negative you stated (F10) | "I haven't led a team." No answer slot. |
| Worked on a game with in-app purchases | Negative you stated (F9) | "I haven't worked on a game with in-app purchases." No answer slot. |
| Ran live events across two titles | Inflated form of F1 | "I ran the weekly content-drop calendar for our main title for the last two years." The limit is the pack's observation: the material says one title's drops, not live events across two. |
| Owned the post-event review and its KPIs | Inflated form of F3 | "Presented the monthly retention numbers to the studio head." The limit is the pack's observation: the material says presenting, not owning. |
| Managed the release process with QA | Inflated form of F4 | "Wrote the release checklist our QA team still uses." |

## Persona weights

No loop source was read, and no interviewer footprint was available, so the loop falls back to the generic archetype (flat weights, said plainly). Relationship prior: hiring manager (Case/Strategist and Skeptic dominant). The JD's retention and KPI language moves the Prober up.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy | Questions |
|---|---|---|---|---|
| Case / Strategist | Live problems on the calendar, a release, a retention dip | High: a hiring manager with a 60-minute slot will test live thinking | Clarify, then structure, then metrics; think aloud | 5 (A) |
| Skeptic | "Two titles is a different job"; "never led a team" | High: F9 and F10 are the gaps a hiring manager will test | Rehearse the single predictable objection until plain; bridge only from what you stated | 4 (B) |
| Data-Driven Prober | "How was that number counted?" | High: the JD names retention metrics and KPIs, and F7 is a number-adjacent line | Say what you know about how a figure was counted and say when you do not | 4 (C) |
| Pressure | "Sixty seconds: why you over someone who has led a team?" | Medium: a scored composure check, less likely from a hiring manager than a skip-level | Hold through two follow-ups, then concede the specific limit | 2 (D) |
| Conversational | Opening "walk me through" and a casual game question | Medium: almost every interview opens this way, and it is scored | A 90-second arc; treat casual questions as scored | 2 (E) |
| Values / Behavioural | Open prompts on telling people hard things | Low: no values round is detected (no loop source, generic archetype), but the fallback is never assumed absent | Selection scaffolds with their honest branch | 2 (F) |
| Peer Evaluator | Seam questions with adjacent teams | Not plausible for a hiring manager; no bank is built | — | 0 |

Total: 19 questions, within the 18–26 range.

## Question banks

Provenance carries the quoted sentence each claim about you rests on. `[generic]` means a pattern for the problem, not a fact about Saltmarsh.

### A. Case / Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Two live titles both have a behind-schedule calendar next quarter. What do you need to know first, and what would you change?" | CASE | [generic] | Clarify first: which KPIs each title reports, what is locked, what the release checklist requires. Then state the objective, the trade-offs, and one risk. Think aloud. You need no past claim for this. | A live problem from the calendar mandate of the JD's first line. Generic because it is a pattern for the problem. |
| A2 | "A retention figure drops sharply in the week after a big update. Walk me through how you would diagnose it." | CASE | [generic] | Separate the update's audience from the baseline; check whether the drop sits in that audience; name the assumption you would test first. | Covers the post-event review and KPI line of the JD. Generic. |
| A3 | "Design wants an update two weeks earlier than art can deliver. How do you coordinate that?" | CASE | [generic] | Decide who owns the trade-off; put it in writing; keep the release checklist as the constraint; agree the date with each function. Make no claim about having done this. | Tests the JD's coordination line (F5, a discovery row). Generic. |
| A4 | "QA says the checklist is missing a step for a live-events release. How do you handle it?" | CASE | [generic] | Find out what the step guards; agree the change with QA in writing; decide whether the checklist or the release changes. | Tests the checklist requirement (F4). The guidance makes no claim about your checklist. |
| A5 | "What would you need to know about a title's in-app purchase model before planning its events?" | CASE | [generic] | Name what you would ask: the economy goals, the offer cadence, what the team already measures about spend. You may say plainly that you have not worked on a game with in-app purchases, and that you would learn the model from the team that owns it. | Points at the largest gap (F9) without a confession. |

### B. Skeptic (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You ran one title's calendar. Two titles is a different job. Why are you ready for it?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Say what you ran, at its own scope: one title, weekly, for two years. Answer slot: if you have run or planned a second title's cadence, say how; if you have not, say so, and say how you would split the two calendars. | F1 is the evidence for the calendar requirement and the likeliest place for a scope probe. |
| B2 (highest-ROI prep) | "What changes in a live calendar when a game has in-app purchases?" | JD | [grounded] "never worked on a game with in-app purchases" | Hold: "I haven't worked on a game with in-app purchases." Then say what you do know: cadence, retention, how the calendar is kept. Name the first things you would check: offer cadence, price points, whether events move spend, all as questions to the economy team. Hold through two follow-ups by returning to "I haven't." Concede specifically: "I don't yet know how much the calendar changes with IAP." | F9 is the largest gap, and a monetisation probe is the most predictable one for a live-ops role. `[generic]` pattern: live-ops roles at mobile studios usually carry monetisation. Deepest rehearsal here. |
| B3 | "You've never led a team. When design and engineering disagree on a live update, and you have no authority over either, what do you do?" | JD | [grounded] "Never led a team" | Say "I haven't led a team." Then answer slot: if you have moved a cross-functional decision without authority, name the decision and how; if not, say so, and describe how you would make the call: find who owns it, put the trade-off in writing, agree a date. | F10 and F5. The question presupposes only the negative you stated. |
| B4 | "What is the most important thing you have written, and what did it change?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Name the checklist and that QA still uses it, in those words. Answer slot: if it changed anything, say what; if you cannot say, say so. | F8 is a discovery row: writing exists, its effect is unshown. |

### C. Data-Driven Prober (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You presented monthly retention numbers to the studio head. Which number was it, and how was it counted?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Name the figure you would defend. Answer slot, in your own words: how it was counted, what it is sensitive to, the assumption you would defend least, and which part of it was yours. If you do not know how it was counted, say so. | F7. Defend-the-number slot: the pack supplies no method, baseline or assumption. |
| C2 | "Tell me about a retention number that moved and what you did about it." | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Open prompt: pick one instance. If no such time comes to mind, say so plainly, then give the nearest thing your material carries: the monthly presentation, and what you did with it. Do not add a diagnosis you did not make. | The JD's retention line raises the theme. The premise is only that a number existed, which your sentence states. |
| C3 | "Which post-event KPI would you own, and which would you only report?" | JD | [generic] | Separate owning a KPI (defining it, deciding what it means) from reporting it. Name one of each you would hold. Future tense: no past claim. | Tests F3's gap (owning versus presenting) without asserting either. |
| C4 | "Who set the retention definition you presented, and could you change it?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Answer slot: if you chose the definition, say which and how; if someone else set it, say so plainly, and say what you could still check. | F3 and F7 together: the definition's origin is not in the material, so the slot asks for it. |

### D. Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why should we hire someone who has never led a team over someone who has?" | JD | [grounded] "Never led a team" | Hold: "I haven't led a team." Hold the position that the calendar and checklist work is the evidence you have. Concede the specific limit: leadership is the gap. Say what you would do in your first 90 days to close it, as a plan. Hold through two follow-ups; do not fold on the calendar work. | F10. Hold-then-concede structure. |
| D2 | "That retention work was a presentation. How much of that number was actually you?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Hold the quote: you presented the monthly retention numbers to the studio head. Concede what you did not do: if you did not define or check the number, say so. Do not claim more than the sentence. | F7 and F3. Tests honest attribution under pressure. |

### E. Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the last few years." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." | A 90-second arc: four years as an associate producer at a puzzle-game studio, the weekly calendar for the main title, the checklist, the monthly retention presentation. Stop there. Ground it in those sentences only. | Openers are scored. Keep it to what you stated. |
| E2 | "What game are you playing right now, and what would you change about how it updates?" | JD | [generic] | Name one live game you play and one update change you would make. A plain, specific observation; no claim about your past. | Casual, and it touches the JD's live-service requirement. Generic. |

### F. Values / Behavioural (weight 2; no values round detected)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Tell me about a time you had to tell a team something they did not want to hear." | VAL | [generic] | Open prompt: pick one instance where the message landed. If no such time comes to mind, say so plainly, then give the nearest thing your material carries. | Persona stem for the values bank. `[generic]`: no company values are in hand. |
| F2 | "When did you put a player's experience ahead of a metric?" | VAL | [generic] | Open prompt. Pick an instance where the trade-off was real and you can say what you gave up. If none comes to mind, say so plainly and give the nearest thing your material carries. | Persona stem; no company values are in hand, so no value is mapped. |

## Coverage

| JD requirement | Covered by |
|---|---|
| Plan and run the live-events calendar for two titles | A1, B1 |
| Coordinate design, art, engineering and community on each update | A3, F5 (in the fit snapshot) |
| Own the post-event review and the KPIs it reports | A2, C3, C4 |
| Manage the release checklist with QA | A4, B4 |
| 3+ years producing live-service games or apps | E1, B1 |
| Experience running a content calendar | B1 |
| Comfortable with player-retention metrics | C1, C2 |
| Clear written communication | B4, F1 |
| Stated gap: in-app purchases (not in JD) | B2, A5 |
| Stated gap: leading a team (not in JD) | B3, D1 |

## Reverse questions

No interviewer profile was available, so these are role-generic. Each has its reason.

1. "What does success look like at 90 days for whoever holds this role, and what would you need to see by day 30?" Why it lands: it turns the leadership gap into a plan you can discuss.
2. "Who decides what goes on each title's calendar, and where does that argument happen today?" Why it lands: it shows you want to know the coordination model you would walk into.
3. "How are post-event reviews run now: who writes them, and what happens when a KPI misses?" Why it lands: it tests where ownership sits, the F3 line, from the other side.
4. "How much of each title's monetisation is set by live operations, and how much by the economy or design team?" Why it lands: it asks about the IAP gap as a question about how the team works, not as a confession.
5. "Where does the release checklist with QA struggle most today?" Why it lands: it treats the checklist requirement as a live problem.
6. "What would you want the person in this role to stop doing in the first month?" Why it lands: a candid answer shows you what the job's real friction is.

## Sources

Provided documents: the job description and your background message. No document was consumed as a dossier.

Research tier: L0. Research was attempted at L1 but the web search permission was not granted, so each search was refused. Not retried.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | unavailable | Would have moved the values cheat sheet. Refused: "Saltmarsh Games values" |
| 2. `Saltmarsh Games interview process Live Operations Producer` | unavailable | Would have moved the loop structure and persona weights. Refused: "Saltmarsh Games interview process Live Operations Producer" |
| 3. `Saltmarsh Games strategy` / recent news | unavailable | Would have moved the CO bank. Refused: "Saltmarsh Games mobile studio strategy news" |
| 4. `Tobias Wrenfield Saltmarsh Games` | unavailable | Would have moved the interviewer read and reverse questions. Refused: "Tobias Wrenfield Head of Live Operations Saltmarsh Games" |
| 5. representative JD | skipped | The JD you supplied fixes the fit snapshot |

Consequence: no CO question is grounded in Saltmarsh's strategy, and no values round was confirmed. Those banks are labelled `[generic]`.

## Upgrade menu

- Saltmarsh's public values page (pasted, or search permission granted) → a values cheat sheet mapped to your stories, and the values-bank questions become grounded
- The recruiter's note on the process, or a loop description → the loop becomes known, and persona weights stop being a fallback
- Tobias Wrenfield's public profile or talks (pasted, or search permission granted) → an interviewer read, persona weights tuned to him, and a reverse question tied to his path
- A recent Saltmarsh news item or strategy note → CO questions grounded in current strategy
- Any post-event review or KPI report you wrote (a sample, with names removed) → F3 and F8 rise from low or discovery to grounded
- Any pre-declared exercise from the recruiter → a graded-deliverable section
