This matches the mock-interview prep skill, so I'll load it and build the prep pack from it.
The skill's spec says to read its reference files before writing anything, so I'll load the ones this run needs.
I've read the spec. The pack needs L1 research (values, loop structure, strategy, and a representative JD since no JD was supplied), so I'll load the web tools first.
Web search was refused by the host, so the pack will run without research and label those parts honestly. Writing the pack file now.
Your prep pack is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-alone-part-2-rooms-case-6-denied-fc774d7c/73c2338e-c2d0-4400-9df3-85f158204bff/scratchpad/larkfield_engineering-manager_interview_pack.md`. It covers all three rounds with their own question banks and reverse questions, plus a shared fit snapshot.

Web search was refused by the host, so the company values, interview process and strategy are not sourced. Those parts are labeled `[generic]`. The Round 3 values section is themed on your recruiter's wording rather than published values. If you grant search permission, or paste the values page, an interview guide or a recent strategy piece, I can add the sourced material.

The highest-ROI prep is question A1 for Round 1: "You haven't managed managers, and you haven't owned a hardware-adjacent roadmap. Why should I hire you for this seat?" The same gap comes back in C4 with the VP.

Say the word and I'll play the Skeptic on A1 as a live drill. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

Can you paste the full job description? It turns the role-text rows into quoted rows and checks for any location, travel or work-authorization terms the material doesn't settle.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: larkfield_engineering-manager_interview_pack.md -----
# Larkfield Systems: Engineering Manager loop prep pack

**Role:** Engineering Manager, Larkfield Systems (industrial IoT, ~600 people)
**Format:** Loop mode, three scheduled rounds, one shared fit snapshot
**Interviewers:** names not given, so no interviewer read is included
- Round 1, Tuesday, 45 min: hiring manager (Director of Engineering)
- Round 2, Thursday of the following week, 60 min: panel, two staff engineers and a product manager
- Round 3, following Monday, 30 min: VP Engineering, described by the recruiter as "values and leadership philosophy"

**Changes from the first pass:** none (first version).

---

## 1. How to use this pack

- **Personas** describe how a question is asked. **Types** describe what is being scored.
- **Type key:** VAL = behavioral/values alignment · EXP = work-experience deep-dive · JD = stated role requirement · CO = company and strategy knowledge · CASE = live problem
- Guidance is scaffolding for a spoken answer, not a script. Rehearse the structure and your own words.
- Where guidance says "Answer slot", the material does not show that thing. Answer it from your own experience in the interview, either way you can truthfully.

**Research status:** web search was refused by the host during this run. Company values, interview process and strategy are therefore **not established**. Anything that would have come from them is labeled `[generic]`. Round structure comes from your own message, which establishes it.

---

## 2. Fit snapshot

Requirements come from your role text, quoted from your message, since no full job description was supplied. Evidence is quoted verbatim from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" (your message) | "3 as a team lead of 6" (your message) | medium | [grounded] | transferability | Your material says a team lead of six for three years. Two squads and device-management services are not in it. Answer slot: if you have led work across two teams, say how, in your own words; if not, say so and stay with the team of six. |
| F2 | "building device-management services" (your message) | none given | none | [grounded] | discovery | Your material does not show device-management services. Answer slot: name the closest service you have owned, what it did, and whether it touched devices; if none did, say so. |
| F3 | "own delivery" (your message) | "pushed a reliability quarter through against roadmap pressure" (your message) | medium | [grounded] | presentation | Reword only the quote: you pushed a reliability quarter through against roadmap pressure. Answer slot: say what the quarter changed for delivery, in your own words, if you can. |
| F4 | "own delivery, hiring and growth for 11 engineers" (your message) | "I run our hiring loop for backend roles — about 40 interviews last year." (your message) | medium | [grounded] | none | No gap on hiring, but the quote is backend roles, not 11 engineers across two squads. Expect a probe on scope. |
| F5 | "growth for 11 engineers" (your message) | none given | none | [grounded] | discovery | Your material does not show growth work. Answer slot: if you have grown engineers into bigger roles or levels, say what you did; if not, say so and say how you would start. |
| F6 | "partner with hardware and product on roadmap" (your message) | "I've never owned a hardware-adjacent roadmap." (your message) | none | [grounded] | capability | Words: "I've never owned a hardware-adjacent roadmap." Then how you would learn it, said as a plan and never as a past. |
| F7 | "partner with hardware and product on roadmap" (your message) | "against roadmap pressure" (your message) | low | [inferred] | transferability | Roadmap pressure is not partnering on a roadmap. Use the quote at its own scope; do not describe partnership you have not stated. The derivation is the roadmap-pressure clause in F3. |
| F8 | "no manager-of-managers experience" (your message, gap note; not in the role text) | "I've never managed managers and never owned a hardware-adjacent roadmap." (your message) | none | [grounded] | capability | Words: "I've never managed managers." Then a plan for developing leads, said as a plan. |

**Confidence** grades your evidence. **Provenance** grades what this pack wrote. Gap types follow the routing rule in the spec.

---

## 3. Prohibited claims

These are not to be coached in any answer. Each entry names its basis.

| Not coached | Basis | Honest form |
|---|---|---|
| Led two squads, or led 11 engineers | Inflated form of F1 | "3 as a team lead of 6" at its own scope. The pack's observation: your material says a team of six, not two squads. |
| The 60% drop was yours alone | Inflated form of F3 | Your sentence: "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." Your sentence does not say what else changed. |
| Ran hiring for all 11 engineers | Inflated form of F4 | "I run our hiring loop for backend roles." Backend roles only. |
| Owned a hardware-adjacent roadmap | Negative you stated, F6 | "I've never owned a hardware-adjacent roadmap." No slot. |
| Managed managers | Negative you stated, F8 | "I've never managed managers." No slot. |

---

## 4. Loop structure and persona weights

No loop source was read, since search was refused. The three rounds and who runs each come from your message, which establishes the loop. No values-style round is established by a published source. Round 3 is a values-style round because your recruiter's own words name it.

| Round | Relationship | Dominant personas (weight) | Why |
|---|---|---|---|
| 1, hiring manager | Director of Engineering, would-be boss | Skeptic (top, 4 questions) · Case/Strategist (4) · Conversational (2) | They are buying capability and derisking the gaps in F1, F6 and F8. Expect live problems on their roadmap. |
| 2, panel | Two staff engineers, one PM | Peer Evaluator (2) · Data-Driven Prober (3) · Case/Strategist (2) · JD (1) | Staff engineers test the numbers and seams; the PM tests trade-offs. Blend per member. |
| 3, VP Engineering | Senior, values and leadership | Values/Behavioral (top, 3) · Pressure (3) · Conversational (1) | Scored values conversation at altitude. Time-boxed. |

**Delivery depth:** the top persona in each round gets four or five questions, mid-weight three, low-weight two. Every round touches every plausible persona so you never meet a style for the first time live.

---

## 5. Round 1: Hiring manager (Director of Engineering), 45 min

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You haven't managed managers, and you haven't owned a hardware-adjacent roadmap. Why should I hire you for this seat?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." "pushed a reliability quarter through against roadmap pressure" "I run our hiring loop for backend roles — about 40 interviews last year." | **Highest-ROI prep in this pack.** Open with the two negatives, unhedged, in your own words: "I haven't managed managers, and I haven't owned a hardware-adjacent roadmap." Then the adjacent evidence, quoted exactly. Then a 90-day plan, said as a plan, never as a past. Hold through two follow-ups by returning to the quote, not by adding to it. Concede with the sentence you have: "I've never managed managers." Never fold on the adjacent claim. Answer slot: if you have worked with a manager of managers or a hardware team in any form, say how, in your own words; if not, say so. | F8 and F6 are the largest gaps and the most predictable objection; this is the Skeptic's natural target. Typed JD because it scores the requirements in your role text. |
| A2 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I've never owned a hardware-adjacent roadmap." | Name the hardware-roadmap part plainly, from the sentence you have. Then the plan. Do not name anything else you are weak at unless you want to. | Persona stem for the Skeptic; the answer is F6. |
| A3 | "Why leave a payments company, and why this role now?" | JD | [grounded] "currently at a payments company" | Your motive is not in your material. Answer with the reason you would give this interviewer, in your own words. Do not invent a story about the company. Answer slot: if the reason involves the hardware or device work, say what it is. | Motivation consistency is the Skeptic's favorite test. Your quote is the only fact you have. |
| A4 | "Sketch how you'd take over a device-management service that is missing its roadmap commitments. What do you ask first?" | CASE | [generic] | Clarify the commitments and the customers first, then the objective, then the segments, then your approach, then the metrics, then the risks. Name one premise you would challenge. Make no claim about your past. | A live problem from the role text. Generic because search was refused. |
| A5 | "A hardware team says a firmware release slips six weeks. Product needs the feature. What is your call as the manager?" | CASE | [generic] | Confirm the dependency and what each side needs. Decide the sequencing trade. State what you would record. Make no claim about your past. | Partnering with hardware and product (role text). Generic. |
| A6 | "Your two squads disagree: pay down reliability debt, or ship the next device feature. Walk me through how you'd decide." | CASE | [generic] | Name the data you need, the decision rule, and who decides. Say what you would do if the data does not settle it. | Delivery under roadmap pressure (role text, F3). |
| A7 | "Walk me through the backend hiring loop you run. How was the 40 counted, and which assumption behind it would you defend least?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Say what you run, in those words. Defend the number: how it was counted, and the weakest assumption you know of, named before they name it. Answer slot: if you set the loop's stages, say which and how you decided; if you inherited them, say so and what you changed. If you do not know how the 40 was counted, say that. | F4 is the hiring evidence and the likeliest place to be probed. The number is a magnet; attribution must be exact. |
| A8 | "So, walk me through the last nine years." | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." | A 90-second arc, one beat per quoted clause: nine years in engineering; three as team lead of six; now at a payments company; then the hiring loop; then the reliability quarter. Each beat in your own words. | The biography question is scored in a casual register. Give the arc from your quotes, nothing added. |
| A9 | "What are you most curious about in device management?" | JD | [generic] | Answer from your own reasons. Do not borrow the company's language to sound informed. | Casual question about a hot JD topic, scored as a plus. Generic because no company material was read. |

**Round 1 reverse questions**

1. "What would the first 90 days need to produce for the two squads?" Why it lands: it turns a question about you into a scope question.
2. "Which hardware dependency is most likely to slip next year?" Why it lands: it signals you know where this domain breaks.
3. "What does this role need that a team lead of six would not already do?" Why it lands: it addresses the F1 and F8 gap in their terms.
4. "How much of the roadmap is set by product, and how much by hardware constraints?" Why it lands: it shows you already think about the partnership.
5. "How will you judge the first six months?" Why it lands: it hands them a rubric for the rest of the loop.

---

## 6. Round 2: Panel, two staff engineers and a product manager, 60 min

Blended weights: the two staff engineers carry the Prober and Peer questions; the product manager carries the Case questions.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Walk me through how the 60% on-call drop was counted." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Defend the number: what you counted, over what period, in your own words. Name the weakest assumption you know before they do. Say what was yours: you pushed the quarter through. Answer slot: if you did not count it yourself, say so plainly and say where the number came from. | F3 is the strongest delivery evidence and the magnet for a prober. |
| B2 | "Which assumption behind the 60% would you defend least?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Name the assumption you know of. If you do not know how the figure was counted, say so; that is an honest branch. Do not reason your way to a cleaner number. | Weakest-assumption move. A figure the candidate gave raises exactly this slot. |
| B3 | "How many of those 40 interviews did you run yourself, and where did the rubric come from?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Separate participation from owning the loop. Answer slot: if you set the rubric, say so; if it was set before you, say so. | F4 probed for attribution. |
| B4 | "Our teams sit side by side on device services. Where's the seam, and what happens when we disagree?" | JD | [generic] | Propose seam principles rather than pretending to know the seam. For disagreement, use the quoted roadmap-pressure situation, at its own scope. Show spine and tact together. | Peer persona stem. The seam is the question about partnership (F7). |
| B5 | "How do you handle credit when work spans teams?" | VAL | [generic] | Name what each team did, not only what you did. No claim about your past beyond what you can say in your own words. | Peer persona stem, credit-sharing probe. |
| B6 | "A customer wants a feature that delays reliability work by a quarter. What do you tell product?" | CASE | [generic] | Clarify the customer's cost and the reliability risk. Decide with the data you can get. State the trade out loud. | PM's trade-off question on the partnership seam. Generic. |
| B7 | "Which device metric would you move first, and what would you stop measuring?" | CASE | [generic] | Name one metric, and say what you would stop watching and why. Do not invent a metric baseline. | PM's product-sense question. Generic. |
| B8 | "You own delivery for 11 engineers. How would you know a squad is behind before its milestone slips?" | JD | [grounded] "own delivery, hiring and growth for 11 engineers" (your message) | Name the signals you would watch. Answer slot: if you have used a signal like this, say which; if not, say so and name what you would watch first. | F3 and F5. Raising source: your role text. |

**Round 2 reverse questions**

1. "What could a new person do in their first month that would genuinely help your team?" Why it lands: the reciprocity question. It is required when the interviewers are peers.
2. "Where do the two squads' services touch yours, and which interface breaks most often?" Why it lands: it shows you are already thinking about the seam.
3. "Which roadmap decision in the last two quarters would you most like to have made differently?" Why it lands: a PM asked this way will tell you the real trade-offs.
4. "What does the hardware team need from software that it isn't getting?" Why it lands: it shows you want the partnership, not just the title.
5. "How do you decide between a reliability item and a feature when both are in the same quarter?" Why it lands: it invites them to describe their own rubric.

---

## 7. Round 3: VP Engineering, values and leadership philosophy, 30 min

The values-style round is detected from your recruiter's own words. No published company values were read, so the values cheat sheet is not included; it needs published values in hand. The VAL questions below are themed on the recruiter's words, and each uses a selection scaffold with an honest branch where your material carries no story.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "pushed a reliability quarter through against roadmap pressure" | Selection scaffold: pick a time you told someone senior something they did not want to hear. It needs a named stake, a moment you did not fold, and an intact relationship at the end. If none comes to mind, say so plainly, then give the nearest thing your material carries: the reliability quarter, in the quoted words. | The recruiter's theme. The quote is the nearest story you have. |
| C2 | "How have you grown an engineer into a bigger role?" | VAL | [generic] | Selection scaffold: pick a time you helped someone take on more. Answer slot: if you have, say what you did and what happened; if not, say so and say how you would start. Do not name an engineer you have not stated. | F5 is the growth gap. This question checks it in a values frame. |
| C3 | "How do you decide what your team stops doing?" | VAL | [generic] | Name the rule you use to stop work, and one time you applied it. If you have no such time, say so and give how you would decide. | Leadership philosophy in operational terms. |
| C4 | "Sixty seconds: why should we trust you to grow leaders when you have never managed managers?" | VAL | [grounded] "I've never managed managers" (your message) | Hold-then-concede. Say the negative, then the honest plan for developing a lead, as a plan. Concede specifically if pushed: "I've never managed managers." Do not fold on the plan. | F8, time-boxed. The VP will ask it. |
| C5 | "That 60% — how much of it was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Hold to the sentence: you pushed the quarter through. Say what part was yours, in your own words. If you cannot separate your share from the team's, say that plainly. | Attribution probe. The hold is the sentence you wrote, not a bigger one. |
| C6 | "In a sentence, what is your leadership philosophy?" | VAL | [generic] | Give one sentence in your own words, and do not borrow the company's values language to sound aligned. | Conversational-style opener that is scored. |
| C7 | "Tell me about a decision you'd reverse from the last two years." | VAL | [generic] | Selection scaffold: name a decision, why it was wrong, and what you changed. If none comes to mind, say so, then give the nearest one you can state. | Pressure probe on self-assessment. |

**Round 3 reverse questions**

1. "What does leadership look like here when a roadmap fight with hardware is unresolved?" Why it lands: it signals you care how decisions are made, not only what is decided.
2. "Which leadership behaviors have you seen fail here?" Why it lands: it shows candor and gives you the real bar.
3. "What did you learn from the last manager you hired at this level?" Why it lands: it asks them to look back, which senior leaders value.
4. "What would make you say in a year that this hire was the right call?" Why it lands: it hands you their success measure directly.
5. "What is the one thing you'd want a new engineering manager to understand in their first month?" Why it lands: it is the reciprocity question at executive altitude.

---

## 8. Requirement coverage

| Requirement | Source | Covered by |
|---|---|---|
| Lead two squads building device-management services | Role text | A1, A4, C4 (F1, F2) |
| Own delivery | Role text | A6, B1, B8 (F3) |
| Own hiring | Role text | A7, B3 (F4) |
| Growth for 11 engineers | Role text | B8, C2 (F5) |
| Partner with hardware and product on roadmap | Role text | A1, A5, B4, B6 (F6, F7) |
| Manager-of-managers experience | Your gap note | A1, C4 (F8) |

---

## 9. Sources

Provided documents: your message (role text, your background, your gap notes, and the three round descriptions).

**Research tier: L1 — searches 4 of 6, fetches 0 of 2 (all calls refused)**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Larkfield Systems values` | unavailable | Search refused. Published values not established, so no values cheat sheet; Round 3 is themed on the recruiter's words. |
| 2. `Larkfield Systems interview process engineering manager` | unavailable | Search refused. The loop is established by your message, not by a source. |
| 3. `Larkfield Systems strategy news industrial IoT` | unavailable | Search refused. The CO bank is generic; no current strategy sentence is in the pack. |
| 4. `{interviewer name} Larkfield Systems` | n/a | No interviewer name was given, so there was no query to form. No interviewer read. |
| 5. Representative engineering-manager JD for device-management services | unavailable | Search refused. The fit snapshot rests on your role text, not on a full JD. |

Queries sent, all refused:
- "Larkfield Systems values": refused
- "Larkfield Systems interview process engineering manager": refused
- "Larkfield Systems strategy news industrial IoT": refused
- "engineering manager device management services industrial IoT job description": refused

No page fetch was sent. Nothing from web sources is used anywhere in this pack.

---

## 10. Upgrade menu

- **Full job description text** → converts the role-text rows to JD-quoted rows, and checks for any gate terms (location, travel, work authorization, schedule). Any gate the material does not settle becomes a `hard_gate` row.
- **Web search permission granted, or the Larkfield values page, interview guide and a recent strategy piece pasted** → unlocks the values cheat sheet for Round 3, loop-sourced round structure, and strategy-grounded CO and CASE questions in place of the `[generic]` ones.
- **Interviewer names for the three rounds** → an interviewer read, persona weights per person, and reverse questions tied to each person's own path.
- **Recruiter's note on each round's focus** → confirms which bank each round needs and whether any deliverable is announced.
- **Deeper research (L2)**, offered once: up to 6 more searches and 2 more fetches, several minutes. Want it?
