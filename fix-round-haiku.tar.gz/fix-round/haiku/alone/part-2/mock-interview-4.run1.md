Your prep pack is saved at `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/haiku/alone/part-2/rooms/case-4-denied-68c396b2/quartzline_product_manager_platform_apis_interview_pack.md`.

Three things you should know first:

- **The interview is tomorrow.** Today is Wednesday 11 November, so Thursday is the 12th. I wrote the 14th in my request, which was wrong, and the pack carries the correct date.
- **The dossier is about three months old.** If the JD has changed since 14 August, paste the current one and I'll regenerate the fit rows and the questions built on them.
- **Research was refused.** The three company searches were denied, so the pack has no Quartzline values or current strategy, and I didn't build a values section. It rests entirely on your dossier.

Read A1 and A2 first. A1 is the objection the dossier named ("why hire you into a PM role without the title?"), and it gets the deepest rehearsal. A2 is the roadmap question, where the honest answer is a plain acknowledgment and a ramp plan, not a bridge.

The pack also flags one thing your dossier doesn't: R2 ("shipped API or platform products") is a must-have, but the dossier gives it no weak-area entry. Your integration work is adjacent to it, not a match, so expect a probe there (A5).

Say the word and I'll run a live drill as the Skeptic on A1. I can also save a `tuesday-dossier.md` with a `pack_feedback` section, which records what rehearsal exposes for the underwriter to verify later. If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quartzline_product_manager_platform_apis_interview_pack.md -----
# Interview prep pack: Product Manager, Platform APIs at Quartzline

**Round:** hiring-manager conversation, 45 minutes, Thursday 12 November 2026 (tomorrow as of this pack)
**Interviewer:** not named; relationship taken as hiring manager from your note
**Stage:** interviewing
**Built on:** your job-underwriting dossier (decision `conditional_go`, generated 14 August 2026, about three months old). Research was refused, so the pack rests on the dossier and nothing else.

---

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and stop where your material stops.

Type key:

- **VAL**: behavioral / values alignment. Not used here; no values-style round detected.
- **EXP**: work-experience deep-dive. Tests whether your claims survive scrutiny.
- **JD**: role-driven. Tests the stated requirements, gaps included.
- **CO**: company and strategy knowledge. Not used here; no current strategy was retrieved.
- **CASE**: live problem from the role. Scored on structure and reasoning.

---

## Fit snapshot

Evidence quotes come from your dossier. `dossier row V1` is the first `verified_candidate_evidence` entry, V2 the second, V3 the third. Confidence notes from the dossier sit in the Confidence column, not in the quotes. V2's sentence continues past the quote; the rest is not needed for any row, so it is left out.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" — dossier role profile, R1 (must-have) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier row V1; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier row V3 | low | [grounded] | transferability | Adjacent work, not the title. Bridge at the quotes' own scope with the limit named: "Led 30+ end-to-end client integrations of the vendor's REST APIs," and "Ran quarterly roadmap-input sessions feeding client evidence to product." Then: "I haven't held a product manager title" (plain acknowledgment, sourced to the dossier's prohibited_claims item). Never stretch the bridge into a PM record. |
| F2 | "Owning a roadmap and prioritization authority (R1 sub-claim)" — dossier uncertain_or_weak_areas | none given | none | [grounded] | capability | No bridge: the dossier found no credible evidence, so none is written. Plain acknowledgment, sourced to the acknowledge_gap area: "I haven't owned a product roadmap or set prioritization for an engineering squad." V3 is input to a roadmap, and is described only as input. Then a ramp plan, said as a plan, never as a past. |
| F3 | "Agile delivery experience" — dossier role profile, R5 (preferred) | none given | low | [grounded] | discovery | Evidence may exist and the material does not show it, so the words are an answer slot. If you delivered work with engineers on a regular cadence, describe it in your own words. If you worked another way, say so, and ask what this team means by Agile delivery. |
| F4 | "Technical fluency: API docs, schemas" — dossier role profile, R3 (important) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier row V1; "Wrote the internal integration playbook" — dossier row V2 | high | [grounded] | presentation | The quotes reach the requirement in other terms. Reword only: the integrations and the playbook. Do not add docs or schemas; nothing in the material says you wrote either. |
| F5 | "Stakeholder management across engineering, sales, customers" — dossier role profile, R4 (important) | "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier row V3; the scope list of "Led 30+ end-to-end client integrations of the vendor's REST APIs" — dossier row V1 | medium | [grounded] | transferability | The limit: the material shows customer-side integration and product-facing input. It does not show managing sales or engineering stakeholders directly. Answer slot inside V1's scope: if you worked with engineers or sales on any of those integrations, say who was involved and what you did with them, in your own words. |
| F6 | "Shipped API or platform products" — dossier role profile, R2 (must-have) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier row V1 | medium | [grounded] | transferability | The quote shows integrating a vendor's APIs, not shipping an API or platform product. The dossier lists R2 as high-priority but gives it no weak-area entry, so this pack treats it as a likely probe. Words at the quote's scope, with the limit named as the pack's own observation. |
| F7 | "Write specs and drive delivery with two engineering squads" — dossier role profile, responsibilities | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier row V1 | low | [grounded] | transferability | Requirements on client integrations are the reach. Spec-writing for engineering squads is not shown. Answer slot inside the quote's scope: if you wrote specs for engineering work, say which and what they covered; if you did not, say so. |
| F8 | "Run discovery with integration partners" — dossier role profile, responsibilities | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier row V1 | medium | [grounded] | presentation | Scoping and requirements with clients is the closest reach. Reword only: scoping and requirements on client integrations. Do not describe a discovery programme. |
| F9 | "Define and track adoption metrics" — dossier role profile, responsibilities | none given | none | [grounded] | discovery | No evidence in the dossier. Answer slot: if you counted adoption of anything you integrated, say what, and from whom; if you did not, say so and say what you would measure first. |

Grading note: the dossier's handoff lists R2 as high-priority but gives it no weak-area entry. This pack treats F6 as a likely probe on its own reading. That gap is worth recording back to the underwriter (see the dossier offer below).

---

## Prohibited claims

Built from the dossier's `prohibited_claims` and the fit snapshot. Nothing in the answers below may assert, soften or imply these.

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | Dossier `prohibited_claims` | The pack's observation: the material shows integration leadership, not the title. Plain acknowledgment, sourced to the prohibited_claims item: "I haven't held a product manager title." Used only as a limit, never as a lead. |
| Having owned a product roadmap | Dossier `prohibited_claims` and the acknowledge_gap area | Plain acknowledgment: "I haven't owned a product roadmap." Then the ramp plan. |
| Having set prioritization for an engineering squad | Dossier `prohibited_claims` and the acknowledge_gap area | Plain acknowledgment: "I haven't set prioritization for an engineering squad." |
| Owned the partner integration programme, or chose which integrations shipped | Inflated form of V1 "Led 30+ end-to-end client integrations" | V1's quote at its own scope. The limit is the pack's observation: the material says you led integrations, not the programme. Answer slots stay inside the integrations. |
| Designed the API architecture | Inflated form of "architecture" in V1's scope list | V1's quote. The observation: "architecture" is one item in a list of integration scope items. |
| Shipped an API or platform product | Inflated form of F6 | V1's quote at its own scope. The observation: the material shows integrating a vendor's APIs. |
| Decided what product got built from client evidence | Inflated form of V3 "feeding client evidence to product" | V3's quote at its own scope. The observation: the material says input, not decisions. |

---

## Persona weights

Relationship prior for a hiring-manager round: Case/Strategist and Skeptic, because the hiring manager is buying capability and derisking gaps. The dossier's named objection pushes Skeptic to the top. JD responsibilities supply the live problems for Case/Strategist. The headline count of 30+ puts a Data-Driven Prober at mid weight.

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy | Weight |
|---|---|---|---|---|
| Skeptic | Probing of the PM-title and roadmap gaps | High. Hiring-manager prior, and the dossier named this objection | Plain acknowledgment, ramp plan, bridge with its limit (A1–A5) | 5 |
| Case/Strategist | Live problems on the partner platform | High. Hiring-manager prior, and JD responsibilities give raising sources | Clarify first, state decision rights, structure aloud (B1–B5) | 5 |
| Data-Driven Prober | Counting the 30+ integrations; adoption metrics | Medium. V1's count is the one headline figure | Defend-the-number slots (C1–C3) | 3 |
| Pressure | Time-boxed challenges to the title and roadmap | Medium. The objection can be asked hard | Hold, then concede specifically (D1–D3) | 3 |
| Conversational | Warm-up and "what are you working with" | Low to medium. Casual openers are still scored | 90-second arc (E1–E2) | 2 |
| Values / Behavioral | Not detected; no published values retrieved | n/a | Dropped | — |
| Peer Evaluator | Not applicable: this is a hiring-manager round | n/a | Dropped | — |

---

## Question banks

Question IDs are by persona. Provenance comes first: it lists the sentences each guidance cell rests on. The interviewer's question is the line you will hear; the guidance is for your answer.

### A. Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have never held the PM title or owned a roadmap, so why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier row V1); [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" (dossier row V3). The two negatives are sourced by the dossier's prohibited_claims item "Having held a product manager title or role" and the uncertain_or_weak_areas acknowledge_gap area "Owning a roadmap and prioritization authority (R1 sub-claim)". | **Highest-ROI prep in this pack.** Give the adjacent work at its own scope, quoting V1. Then the limit, in your words: "I haven't held a product manager title or owned a product roadmap." Then the ramp plan: what you would learn in the first 90 days, and from whom. **Follow-up 1:** "What did you decide on those 30 that a PM would decide?" Answer slot: if you set scope, sequence or priority on any of them, say which and how you decided. If you did not, say so and describe your role. **Follow-up 2:** "So why trust you with the roadmap?" Hold: point to V1 and the ramp plan, and concede the gap specifically. Do not claim the title or call yourself "a PM in all but title." | The underwriter named this objection, so the pack uses its wording. It presses F1 and F2. The dossier's negatives are sourced, so the question may be asked as written. |
| A2 | "Have you ever set the order of work for an engineering team?" | JD | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" (dossier row V3). The negative is sourced by the acknowledge_gap area "Owning a roadmap and prioritization authority (R1 sub-claim)". | Plain acknowledgment, with no answer slot: "I haven't set prioritization for an engineering squad." Then the adjacent part at its own scope: the roadmap-input sessions, described as input. Then a ramp plan, said as a plan: how you would learn to set order across two squads. Do not stretch V3 into an ordering decision. | F2 is `capability`. An answer slot here would reopen the bridge the dossier closed. |
| A3 | "Which requirement in this role would you be weakest at on day one?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier row V1); the requirement texts "3+ years product management experience" and "Agile delivery experience" from the dossier role profile. | Name the two areas your material shows least of, in your own words: the PM years and roadmap ownership (F1, F2), then Agile delivery (F3). For each, give one plan, not a past. Do not add a strength to balance the list. | Skeptic stem asking for honest self-assessment. The answer is the gap rows already drawn, so it adds nothing new to claim. |
| A4 | "Tell me about how you've delivered work with engineers." | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier row V1) | Answer slot: if you delivered work with engineers on a regular cadence, describe it in your own words, and use only the scope items V1 lists. If you did not work that way, say so, and ask what this team means by Agile delivery. | The requirement's own wording is the probe (R5). No verified entry speaks to Agile directly, so this is a scaffold, not a bridge. |
| A5 | "When have you shipped an API or platform change, and what was your part?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier row V1) | Answer slot: if you shipped an API or platform change yourself, say what it was and what you did, in your own words. If the closest thing is the integrations you led, say that, and say what they did not include. | R2 is a must-have with no weak-area entry. F6 is `transferability`, so the slot stays inside the integrations. |

### B. Case / Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Partners are integrating, but adoption of the newest endpoint is flat across the top twenty accounts. Walk me through how you'd diagnose it." | CASE | [generic] | Clarify first: what counts as adoption, over what window, against what baseline. Then objective, segments (partner size, integration stage, endpoint), approach (interviews, usage logs, drop-off points), metrics (first successful call, sustained use), and risks (measurement artifacts). Say the framework aloud before you use it. Make no claim about your past. | Raising source: JD "Define and track adoption metrics." F9 is the gap, so your reasoning carries the answer, not your record. The figures are invented for the exercise. |
| B2 | "Two engineering squads disagree on a breaking change to a partner endpoint, and both leads say it's your call. What do you do?" | CASE | [generic] | Establish first whether the decision is yours. Say so aloud, rather than assuming authority. Name the information you need: partner usage, migration cost, contract commitments. Propose a decision rule and a partner-facing test. If the decision is not yours, offer to escalate with a recommendation. | Raising source: JD "Write specs and drive delivery with two engineering squads." This tests the decision-authority risk live. Reverse question R-Q1 asks the same thing of them. |
| B3 | "You're three months in. What does your first round of partner discovery look like, and who's in the room?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier row V1) | Name the partner segments first, then the questions, then who attends. Bring what V1 gives you (how scoping and requirements ran on client integrations) in those terms. Do not present it as a discovery track record. | Raising source: JD "Run discovery with integration partners." F8 is the closest reach. The answer is a plan, supported only through V1's scope. |
| B4 | "Partners want three things that conflict on the roadmap. Which do you pick, and what would you need to know first?" | CASE | [generic] | Structure the call: which partner outcome matters most, what each option costs, and what you would need to know (usage, revenue exposure, squad capacity). Say whose call it finally is. Do not claim you have made this call before; it is a live problem. | Raising source: JD "Own the roadmap for the partner-facing API platform." This is the acknowledged-gap area, asked as a live problem, which is allowed because it asks about no past. The guidance adds no bridge. |
| B5 | "A partner needs a breaking change to unblock their launch next week. What's your default answer?" | CASE | [generic] | Name your default and the conditions that would change it: contract terms, how many partners are affected, whether a versioned endpoint is possible. Say where you would bring in the squad leads. | A live tradeoff from the partner-facing platform. It tests judgment, not history. |

### C. Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You've led thirty-plus integrations. How did you count them, and would the number change if you counted only the ones that reached go-live?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier row V1) | Answer slot, defend-the-number: say how the count was made, in your own words. If it was an estimate, say so. For sensitivity, say how the figure would look on a different definition, if you know. If you did not count it that way, say what the count includes. Do not supply a counting method or a go-live split. | The headline count in V1 is the figure you gave, and a prober will test it. The pack supplies no method. |
| C2 | "For those integrations, which parts did you do yourself?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier row V1) | Answer slot: say which of the scope items were yours (scoping, requirements, architecture, UAT, go-live), in your own words. If some were not yours, say so plainly. | An attribution probe. The slot stays within V1's scope list. |
| C3 | "What assumption behind that number would you defend least?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier row V1) | Answer slot, weakest assumption: name it in your own words before the interviewer does. If you cannot name one, say you do not know how the count was made. Do not name an assumption the material does not state. | The weakest-assumption move is the slot a figure raises. No quote states an assumption. |

### D. Pressure (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Thirty integrations. How much of that was actually you?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier row V1) | Hold: state what you led end to end, at V1's scope, in one sentence, then hold it through two follow-ups. Answer slot inside that scope: say which scope items were yours. If the rest were shared or someone else's, concede that specifically. Never fold on the led-end-to-end claim. | A pressure stem that tests whether you hold a quoted claim without inflating it. |
| D2 | "You haven't set a roadmap. So which items would you cut from the platform backlog on day one?" | JD | [grounded] The negative is sourced by the uncertain_or_weak_areas acknowledge_gap area "Owning a roadmap and prioritization authority (R1 sub-claim)". | Concede the premise plainly: "I haven't owned a product roadmap." Hold: you would want the backlog and the squads' input before cutting anything, and you would say what you would check first. Hold through two follow-ups. Do not invent a cut list. | Pressure on a sourced gap. The failure is folding into a roadmap history you do not have. |
| D3 | "Give me the time you pushed back on a partner's demand. Quickly." | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier row V1) | Open prompt on R4. Pick one instance and keep it to about 60 seconds. If you have none, say so plainly, then give the nearest thing V1 carries (requirements or UAT with a client) and how you would handle a demand you disagreed with. Second follow-up: "Did they accept it?" Concede if they did not. | The open prompt makes you choose an instance. The honest branch is the scaffold's, not an invented story. |

### E. Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey to here." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier row V1); [grounded] "Wrote the internal integration playbook" (dossier row V2); [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" (dossier row V3) | A 90-second arc in this order: the integrations at V1's scope, the playbook (V2), the roadmap-input sessions (V3), then why the platform now, in one sentence. Do not open with the title gap; raise it only if asked. | An opening question that is still scored. |
| E2 | "What are you actually working with in the partner APIs these days?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs" (dossier row V1); [grounded] "Wrote the internal integration playbook" (dossier row V2) | Name the vendor REST APIs you integrated, and say what the playbook covers, in your own words. Do not make docs or schema claims. | Raising source: R3, "Technical fluency: API docs, schemas." F4 is `presentation`; no schema work is quoted. |

---

## Requirement coverage

| Requirement | Question IDs |
|---|---|
| R1: 3+ years product management experience | A1 (JD), D2, E1 |
| R1 sub-claim: owning a roadmap and prioritization authority | A2, B4, D2 |
| R2: shipped API or platform products | A5 (JD), F6 |
| R3: technical fluency, API docs and schemas | E2 (JD) |
| R4: stakeholder management across engineering, sales, customers | D3 (JD), B2 |
| R5: Agile delivery experience | A4 (JD), A3 |
| Own the roadmap for the partner-facing API platform | B4, B5 |
| Run discovery with integration partners | B3 |
| Write specs and drive delivery with two engineering squads | B2 |
| Define and track adoption metrics | B1; the employer question R-Q2 |

Total: 18 questions. No CO question: research did not run, so no current-strategy question is grounded.

---

## Values / principles cheat sheet

Dropped: no values-style round detected, and no published values were retrieved or pasted.

## Graded deliverables

Dropped: none declared.

## Reading the interviewer

Dropped: no interviewer name or profile was given.

## Delivery coaching

Dropped: no working-style assessment was provided.

---

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R-Q1 | "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" | Dossier question for the employer. It answers the decision-authority risk you need settled before accepting, and it reads as diligence. |
| R-Q2 | "How is partner API adoption measured today, and what is the current baseline?" | Dossier question for the employer. It answers the missing-baseline risk, and it tells you whether the job starts from data or from nothing. |
| R-Q3 | "Two squads split this work. Where do they disagree most, and how does that get decided?" | Inferred from the JD's two-squad responsibility. It shows you took the squads seriously and gets at how decisions move in practice. |
| R-Q4 | "What would make the first ninety days feel like a success to you?" | Generic. It converts the hire into a shared plan and exposes what the hiring manager actually expects. |
| R-Q5 | "What did the last person in this seat get right, and where did they get stuck?" | Generic. The answer is usually the real job description. |

No reverse question is tied to the interviewer's own path, because no profile was given. Reciprocity is not required, since the interviewer is not a peer.

---

## Sources

- **Provided document:** the job-underwriting dossier (`tuesday-dossier.md`, pasted in conversation). Consumed sections: `handoff_to_mock_interview` (verified evidence, uncertain areas and their strategies, likely objection, opportunity risks, employer questions, prohibited claims), `role_profile` (requirements R1–R5 and the responsibilities), and `decision` as context only. Not present in the pasted dossier: `evidence_map`, `evidence_state`, `risk_register`.
- **Dossier age:** generated 14 August 2026. The role may have changed since. Rows F1–F9 and the questions built on them are current only if the JD still reads as the dossier quoted it.
- **Research tier:** L1 was requested, and every search was refused, so the effective tier is L0. Searches: "Quartzline company values principles" (refused), "Quartzline interview process product manager platform APIs" (refused), "Quartzline partner API platform strategy news" (refused). No fetches were attempted.

**Target accounting**

Research tier: L0. L1 was requested and its searches were refused; the pack rests on the dossier alone.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quartzline values | unavailable | Would have shown whether a values round is in play. The pack drops the values section on the assumption that it is not. |
| 2. Quartzline interview process, product management | unavailable | Would have set the loop structure and weights. The hiring-manager prior stands in its place. |
| 3. Quartzline strategy / recent news | unavailable | Would have fed the CO bank. No strategy brief was supplied, so the bank is absent. |
| 4. Interviewer name and Quartzline | n/a | No interviewer name was given, so no query could be formed. |
| 5. Representative Product Manager, Platform APIs JD | skipped | The dossier's role profile already supplies the requirements. |

---

## Upgrade menu

- **Current JD**, if the role has changed since August → rows F1–F9 and the questions built on them regenerate against the current wording.
- **Interviewer's name** → persona weights from their public footprint, and a reverse question tied to their own path.
- **Research access** → Quartzline's values and current strategy, which would add a CO bank and possibly a values section, and confirm the loop structure.
- **Your raw CV** → the V-rows get their own sentences quoted, and the bridges can cite your actual wording.
- **Recruiter's note on the round's focus** → would reweight the personas if the round leans Pressure or Peer.
