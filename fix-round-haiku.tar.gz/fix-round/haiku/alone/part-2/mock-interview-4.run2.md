Your prep pack is saved as `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-alone-part-2-rooms-case-4-denied-15aa2c52/fe543c9e-7ecc-4381-a679-c471f413b13e/scratchpad/quartzline_product-manager-platform-apis_interview_pack.md`. It is built from your dossier alone. Web search was refused in this session, so the pack has nothing on Quartzline's values, interview loop, or recent news.

Start with A1. The dossier names it as the likeliest objection, and it is the one to rehearse out loud until it is plain: "why hire you into a roadmap role when you've never held the PM title or owned a roadmap." The pack's answer holds on the integration record, concedes the title and the roadmap directly, and never claims either.

Say the word and I'll play the Skeptic on A1, using the dossier's objection and the follow-ups it would draw.

I can also save a `tuesday-dossier.md` with a `pack_feedback` section recording what this prep exposed, for you to carry forward.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quartzline_product-manager-platform-apis_interview_pack.md -----
# Interview prep: Product Manager, Platform APIs at Quartzline

Round: hiring-manager interview, 45 minutes, Thursday. Interviewer: not named. Built from your underwriting dossier (dated 2026-08-14). Web search was refused in this session, so nothing about Quartzline itself is in this pack beyond the dossier and the job requirements it carries. The dossier is about three months old: if the posting or the stage has changed, paste the current job description and the pack will be rebuilt.

**How to use:** Personas are how a question is asked; types are what it scores. Type key: **EXP** work-experience deep-dive, **JD** role-driven, **CASE** live problem. VAL and CO are omitted: no values round was detected and no company research ran. Guidance is scaffolding for a spoken answer, not a script.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" (dossier role_profile, R1, must_have) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence | high | [grounded] | transferability | Adjacent work, with its limit named by you. Bridge: "I led 30+ end-to-end client integrations of the vendor's REST APIs." Limit, in your words, from the dossier's prohibited_claims item "Having held a product manager title or role": "I haven't held the PM title." |
| F2 | "Shipped API or platform products" (dossier role_profile, R2, must_have) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence | high | [grounded] | transferability | Your material shows integrations built against the vendor's APIs and taken to go-live. It does not show an API product you shipped, and the pack does not say it does. Answer slot: if you shipped anything another team consumed as an API, say what and what part was yours; if you did not, say so and stay with the integrations you led to go-live. |
| F3 | "Technical fluency: API docs, schemas" (dossier role_profile, R3, important) | "Wrote the internal integration playbook her team uses" — dossier verified_candidate_evidence | high | [grounded] | discovery | The playbook touches docs but the material does not show whether it covers schemas. Answer slot: if the playbook covers API docs or schemas, say what it covers and how you used it; if not, say so and say what you would check first. |
| F4 | "Stakeholder management across engineering, sales, customers" (dossier role_profile, R4, important) | "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence | medium | [grounded] | transferability | Confirmed, with limited inspectable proof: expect a probe. The sessions carried client evidence to product. The quote names no engineering or sales stakeholders. Answer slot: if you managed engineering or sales stakeholders on any of this, say how; if you did not, say so and stay with the sessions. |
| F5 | "Agile delivery experience" (dossier role_profile, R5, preferred) | none given | low | [inferred] (derivation: the dossier's uncertain_or_weak_areas entry "Agile delivery inside a product org (R5)", gap type discovery, strategy clarify) | discovery | No verified entry speaks to Agile. Answer slot in the clarify form: ask what the interviewer means by Agile on these squads, say what you have run, and say what you would want to confirm about how they define it. |
| F6 | "Owning a roadmap and prioritization authority" (dossier uncertain_or_weak_areas, R1 sub-claim) | none given | none | [grounded] (dossier acknowledge_gap entry, named by its field) | capability | Plain acknowledgment from the dossier's acknowledge_gap entry and its prohibited_claims items "Having owned a product roadmap" and "Having set prioritization for an engineering squad": "I haven't owned a product roadmap, and I haven't set prioritization for an engineering squad." Then the ramp, said as a plan and never as a past. |

**Provenance and gap-type reading:** F1 and F2 rest on the same verified quote for different requirements; F2's gap is the shipping claim, which the quote does not reach. F6 is the only capability gap, and it is one you stated in the dossier, so the pack gives you its words.

## Prohibited claims

Not coached in any answer, slot, hold, or drill feedback in this pack.

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | Dossier prohibited_claims | Plain acknowledgment: "I haven't held the PM title." (F1, A1) |
| Having owned a product roadmap | Dossier prohibited_claims | Plain acknowledgment: "I haven't owned a product roadmap." (F6, A2) |
| Having set prioritization for an engineering squad | Dossier prohibited_claims | Plain acknowledgment: "I haven't set prioritization for an engineering squad." (F6, B4) |
| Owned the partner-facing API roadmap (widens the JD's "Own the roadmap for the partner-facing API platform") | Inflated form of F6 and F1, built locally | F1's quote at its own scope. The limit is the pack's observation, not words for you: the material says integrations led, not a roadmap owned. |
| Ran the product process behind API features (widens "Ran quarterly roadmap-input sessions feeding client evidence to product") | Inflated form of F4, built locally | F4's quote at its own scope. The material says sessions that fed client evidence to product, not the process. |
| Shipped API or platform products (widens F2's requirement text) | Inflated form of F2, built locally | F2's quote at its own scope; the slot stays inside the integrations led to go-live. |

## Persona weights

Hiring-manager prior: Case/Strategist and Skeptic dominate, because the hiring manager is buying capability and checking the gaps. No interviewer profile exists, so no interviewer-signal adjustments apply. No loop schedule is known, so the pack is a single session. Total 18 questions, weighted by persona:

| Persona | Weight | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|---|
| Skeptic | 5 questions (A) | The title and roadmap gaps, asked directly | High: the dossier names the title objection as likely, and F1 and F6 are the visible gaps | Rehearse the objection until it is plain. Hold on the integration record, and concede the title and the roadmap directly. |
| Case/Strategist | 5 questions (B) | Live problems on the actual job: adoption metrics, partner discovery, two squads | High: the job is roadmap and adoption work, and the hiring manager will test it on live problems | Clarify, then structure, then state a metric and a risk. Ask who decides before you claim a call. |
| Data-Driven Prober | 3 questions (C) | The "30+" count and the playbook | Medium: F1 and F3 are the figures a prober will reach for | Name how the count was made, if you know. If you do not, say so. Name the weakest assumption before it is raised. |
| Pressure | 3 questions (D) | "Why you over a PM with three years", and "how much was actually you" | Medium: the title gap is an easy composure test | Pause, restate, hold the integration record through two follow-ups, then concede the title. |
| Conversational | 2 questions (E) | Opener, and a casual question on partner APIs | Low to medium: casual questions are still scored | Use the 90-second arc. Treat the partner-API question as scored. |

The Peer Evaluator persona is omitted: the relationship is a hiring manager, and no peer on the loop is named.

## Question banks

Guidance is the candidate's own words, drawn from the fit snapshot rows listed in each Provenance cell. Where a line is an answer slot, it is an instruction for the interview, not a question for this conversation.

### A. Skeptic (5 questions, highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Why should we hire you into a roadmap role when you've never held the PM title or owned a roadmap, rather than a PM with three years of the actual job?" | JD | [grounded] "Having held a product manager title or role" (dossier prohibited_claims) and "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (F1) | The highest-ROI rehearsal in this pack. The dossier named this objection; you can rehearse it word for word. Start with the plain acknowledgment: "I haven't held the PM title." Then the record, in the quote's own terms: "I led 30+ end-to-end client integrations of the vendor's REST APIs." Name what the record does and does not cover. Then the ramp, said as a plan: which roadmap decision you would learn first and how you would learn it. Hold through two follow-ups by returning to the integrations. Concede the title and the roadmap on the second follow-up, never the record. | The dossier named this as the likeliest objection (F1, F6). The negatives in the question are sourced by the dossier's prohibited_claims and acknowledge_gap fields. |
| A2 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Own the roadmap for the partner-facing API platform" (JD, dossier role_profile) and "I haven't owned a product roadmap." (F6 plain acknowledgment) | Open prompt, theme from the JD's roadmap line. Name the roadmap ownership as the weakest area, with the plain acknowledgment. Then say what you would do first, as a plan. Do not add a roadmap you did not own. | F6 is the capability gap; this question is the place it surfaces, so the words are ready before it does. |
| A3 | "Tell me about the API work you've shipped, and the part you led." | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (F2) | Open prompt, theme from the JD's shipped-products requirement. Answer from the integrations you led to go-live. Answer slot: if you shipped anything another team consumed as an API, say what and what part was yours; if you did not, say so and stay with the integrations. Never describe an API product you did not ship. | F2 is the shipping gap. The question presupposes a shipping event the quotes do not contain, so the guidance gives the second branch as well. |
| A4 | "How have you worked in Agile delivery inside a product org?" | JD | [generic] | Answer slot, clarify form: ask what the interviewer means by Agile delivery on these squads. Then say what you have run, from your own record. If no verified entry speaks to it, say so, and say what you would want to confirm about how they define it. Do not describe an Agile practice you did not run. | F5 is discovery: no verified evidence speaks to Agile, so the answer is a question-shaped answer, not a bridge. |
| A5 | "Of engineering, sales and customers, which have you actually managed, and how?" | JD | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" (F4) | Say what the sessions did, in those words: client evidence to product. Answer slot: if you managed engineering or sales stakeholders on any of this, say how; if you did not, say so and stay with the sessions. Expect a probe, because F4 is confirmed with limited inspectable proof. | F4 is the stakeholder requirement at medium confidence, so the probe is likely and the answer is ready before it comes. |

### B. Case/Strategist (5 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Sketch how you'd choose the partner-API adoption metric to track first. What do you need to know before you pick?" | CASE | [generic]; raising source: "Define and track adoption metrics" (JD) | Clarify the objective first: adoption of what, by whom. Then segment, then propose an approach and one metric, then name the risk. Ask for the current baseline. You do not know it yet and should say so. | JD responsibility; the baseline is an employer question below. |
| B2 | "A partner integration's go-live rate drops 20% in one quarter. Diagnose it." | CASE | [generic] | Clarify, then segment by partner and integration type, then state the two hypotheses you would test first. Name how you would check each. Presupposes nothing about your past. | Generic live problem for the role's integration work. |
| B3 | "A partner asks for a feature you would rather not build. How do you run discovery with them?" | JD | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" (F4) | Use the sessions as the frame for how you bring partner input to the product side, in the quote's words. Separate what the partner asks from what they need. Do not describe a partner discovery process you did not run; if you have not run one, say so and describe the sessions. | JD responsibility (partner discovery). The quote supplies the only record, and it is client-facing. |
| B4 | "Two squad leads disagree on sequencing for the same quarter. What is your first move?" | CASE | [generic]; raising source: "Write specs and drive delivery with two engineering squads" (JD) | Name who decides, and ask it before you claim a call. Say what you would need from each squad lead, and what you would bring to the disagreement. Do not claim authority over squad prioritization: "I haven't set prioritization for an engineering squad." | The dossier lists decision authority against the squad leads as an unknown. This question tests it without the pack assuming an answer. |
| B5 | "Write the spec for a new partner-facing endpoint. What is in it, and what is out?" | CASE | [generic]; raising source: "Write specs and drive delivery with two engineering squads" (JD) | Structure: the problem, the users, the scope in and out, the contract details the partner needs, and the open questions for the squads. Do not describe a spec you wrote; the question is a live exercise. | JD responsibility (specs). |

### C. Data-Driven Prober (3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You led thirty integrations. How was thirty counted, and which of them were yours to decide?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (F1) | Defend-the-number slot. Say how the count was made, in your own words. Name what it is sensitive to and the assumption you would defend least. Say which part was yours. If you do not know how it was counted, say that plainly. Do not supply a counting method. | F1 is the headline figure, so a prober will press on it. The slot is the only honest form the material supports. |
| C2 | "Walk me through how the integration playbook was written and how your team uses it." | EXP | [grounded] "Wrote the internal integration playbook her team uses" (F3) | Say what you wrote and who uses it, in those words. Answer slot: if you measured whether the playbook worked, say how; if you did not, say so. | F3 is the playbook; the premise (team use) is in the quote, the measurement is not, so it is a slot. |
| C3 | "The job lists API docs and schemas. Which of those have you handled, and how?" | JD | [grounded] "Wrote the internal integration playbook her team uses" (F3); raising source: "Technical fluency: API docs, schemas" (JD) | Answer slot: if the playbook covers API docs or schemas, say what it covers and how you used it; if not, say so and say what you would check first. Do not describe schema work you did not do. | F3 is discovery: the playbook touches docs, and the material does not show schemas. |

### D. Pressure (3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over a PM with three years of the job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (F1) | Pause, then restate the question. Give the record in its own terms. Hold through two follow-ups. Concede the title on the second. Never answer by claiming the title. | F1 is the record you have to hold; the title is the concession. |
| D2 | "Did product ever act on the roadmap input you sent them? Name one thing, if you can." | JD | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" (F4) | Answer slot: if product acted on something you sent, name it and what part was yours; if you cannot name one, say so and stay with the sessions. Never describe an outcome the material does not carry. | The question presupposes an outcome; the slot's second branch lets the premise be false. |
| D3 | "Your record is integration work. Is that product management at all?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (F1) | Hold: the integrations are adjacent to the product work, and the record is what it is. Name the limit, "I haven't held the PM title", without apologising for the record. Concede the title if pressed a second time. | F1 is the transferability gap; the pressure version tests whether the limit stays named. |

### E. Conversational (2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey to here." | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; "Ran quarterly roadmap-input sessions feeding client evidence to product" (F1, F3, F4) | Ninety-second arc, in this order: the integrations, the playbook, the sessions. State the limit once, in your own words. Stop at ninety seconds. | Casual opener; it is scored, and the arc keeps the record in the quotes' own words. |
| E2 | "What are you playing with in partner APIs these days?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs" (F1) | Name what you have actually used, starting with the vendor's REST APIs. Do not list tools you have not touched. | Casual phrasing of a JD topic; it is scored. |

## Requirement coverage

| Requirement | Question IDs |
|---|---|
| R1: 3+ years product management experience | A1, A2, D1, D3 |
| R2: Shipped API or platform products | A3 |
| R3: Technical fluency, API docs and schemas | C2, C3 |
| R4: Stakeholder management across engineering, sales, customers | A5, B3, D2 |
| R5: Agile delivery experience | A4 |
| Responsibility: roadmap for the partner-facing API platform | A2 |
| Responsibility: partner discovery | B3 |
| Responsibility: specs and delivery with two squads | B4, B5 |
| Responsibility: define and track adoption metrics | B1 |

## Reverse questions

Five questions, each with why it lands. None has an interviewer profile to tie to, so none is tied to their path.

1. "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" Why it lands: decision authority against the two squad leads is the dossier's first unknown; asking it reads as diligence and answers something you need before accepting.
2. "How is partner API adoption measured today, and what is the current baseline?" Why it lands: the dossier flags that no baseline is stated. The answer tells you whether the adoption metric is a reporting job or a definition job.
3. "What does Agile look like on these squads: cadence, and who owns the backlog?" Why it lands: it turns F5 into a question about their practice, which is what the clarify strategy wants.
4. "Which of the two squad leads would be my first working partnership, and what do they need from a PM?" Why it lands: it makes B4 concrete and shows you are planning the first ninety days.
5. "What did the last person in this role get right, and what did they wish they had?" Why it lands: it tests what the team values in the role without assuming an answer.

## Sources

**Provided documents:** the underwriting dossier you pasted (dossier_version 1.1). Sections consumed: role_profile (requirements R1 to R5, responsibilities, unknowns), evidence (verified_candidate_evidence), handoff_to_mock_interview (weak areas and their strategies, likely objection, prohibited_claims, risks and employer questions). Decision: conditional_go. No job description or CV was supplied beyond the dossier.

**Research tier:** L1 attempted, 0 of 6 searches completed, 0 of 2 fetches. Web search was refused by permission in this session.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quartzline values | unavailable | Would have fed a values cheat sheet. Query sent: "Quartzline company values": refused. Section omitted: no values round was detected. |
| 2. Quartzline interview process, product manager | unavailable | Would have set the loop structure and persona weights. Query sent: "Quartzline product manager platform APIs interview process": refused. Persona weights rest on the relationship prior alone. |
| 3. Quartzline strategy and recent news | unavailable | Would have fed the grounding brief and any CO questions. Query sent: "Quartzline partner API platform news 2026": refused. No CO questions appear. |
| 4. Interviewer name and company | n/a | No interviewer name was given. Interviewer read omitted. |
| 5. Representative Product Manager, Platform APIs JD | skipped | The dossier's role_profile fixes the requirements and JD-tagged questions. |

## Upgrade menu

- Interviewer's name → an interviewer read, persona weights tuned to their public footprint, and a reverse question tied to their own path.
- Web search re-enabled for this session → Quartzline's values, interview process, and recent news (targets 1 to 3 above), and a grounding brief if you want the deeper pass.
- Current job description → the requirements and the JD-tagged questions are rechecked against the posting, since the dossier is from 2026-08-14.
- A CV or notes on the integrations → F1 to F4 gain a fuller record, and the defend-the-number slots in C1 and C2 can be answered from material rather than memory.
- Round details from the recruiter, such as any focus areas or a take-home → coverage of any pre-declared deliverable.
