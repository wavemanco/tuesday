Your prep pack is saved as `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-alone-part-2-rooms-case-5-denied-b3878180/f47e0f3d-e7a7-418b-8617-0cc76bf58182/scratchpad/kelverton_rail_senior_partnerships_manager_interview_pack.md`. I built it for a panel with a hiring manager and a commercial director, since that's what your recruiter's email describes.

**What I could and couldn't do:** web search was refused in this session, so the pack has no company, rail-market or interviewer facts. I also haven't seen the recruiter's market report, only your description of it. The POV differentiation is therefore unchecked against the report's likely consensus answer.

**Where to spend your four hours:**
1. **The POV (about 90 min).** Two theses, each with a concession you say aloud, plus an anti-pick. The sentence about "the operator world from the other side" is your strongest bridge into it. Write bullets, not a script, and time it.
2. **The rail gap (about 45 min).** Deepa's question on selling into rail is the highest-return rehearsal. Hold "I haven't sold into rail specifically," concede it, then give a ramp plan framed as a plan.
3. **The numbers (about 45 min).** Ross will press on the £4M of influenced revenue and on having no direct quota. Write from memory how the 40 partners and the £4M were counted, and mark what you don't know. Don't adopt a counting method you haven't used.
4. **Reverse questions and the first 90 days (about 30 min).**

Two questions before the panel:
1. Can you paste the job description, or should I proceed without it? Without it, none of the requirement rows is graded against the JD.
2. Does the role carry any eligibility term (right to work, office days, travel) I should check? I haven't assumed one, and the pack flags it as unchecked.

I can also play the Skeptic on A2, the rail question, which the pack names as the highest-ROI prep. I can save a `tuesday-dossier.md` recording the gaps this prep exposed, for carrying into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: kelverton_rail_senior_partnerships_manager_interview_pack.md -----
# Kelverton Rail: Senior Partnerships Manager, second round (panel)

**Panel, Tuesday, 60 minutes.** Deepa (VP Partnerships, your future manager) and Ross (Commercial Director). First 15 minutes: a spoken point of view (POV), no slides. Then Q&A, with Ross pressing on commercials.

**Changelog:** first pack. No job description was supplied, and no web research ran (search permission was not granted in this session). Requirements come from the recruiter's email as you quoted it, and from your own message.

## How to use + type key

- **Personas** describe how a question arrives. **Types** describe what is being scored.
- **VAL**: values and behavioural alignment. **EXP**: your own experience, and whether it survives scrutiny. **JD**: stated requirements. **CO**: commercial and company knowledge. **CASE**: a live problem.
- Guidance is scaffolding, not a script. Rehearse it aloud, in your own words.

## Prep triage (about 4 hours)

1. **90 min: the POV.** Build it from the POV section below. Write bullets, not a script. Say it aloud twice and time it against 15 minutes.
2. **45 min: A2 and B1.** These are the two objections most likely to come up. Rehearse each aloud, holding the plain fact through two follow-ups.
3. **45 min: B2 and B3.** Write, from memory only, how the 40 partners and the £4M were counted. Mark anything you do not know. Do not fill the gaps with a method you have not used.
4. **30 min: reverse questions and A1.** Choose five reverse questions and rehearse your first 90 days in operator terms.

Everything else is insurance.

## Fit snapshot

Requirements come from the recruiter's words (quoted from your message) and from your company description. No JD text was supplied, so no row is graded against a JD.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "what it means for the operators themselves" (recruiter, your message) | "5 years in transport consulting" and "bus and light rail network planning, so I know the operator world from the other side" (your message) | medium | [grounded] | transferability | Your material puts you on the planning side of operators, not on the buying side of partnering. Bridge at the quote's own scope: "I spent five years on bus and light rail network planning, so I know the operator world from the other side." Answer slot: if any of your work touched an operator's own decisions, say which and how; if none did, say that the operator view comes from planning. |
| F2 | "Ross will push on commercials" (recruiter, your message) | "never carried a direct quota, only influenced revenue" (your message) | none | [grounded] | capability | You stated this absence yourself. Words: "I haven't carried a direct quota. My number was influenced revenue." Then how you would agree a commercial number, said as a plan, never as a past. |
| F3 | "our operator partnerships" (recruiter); partner growth (your message) | "running the ISV channel, took it from 6 partners to 40" (your message) | medium | [grounded] | none | No gap. The quote reaches partner growth in role-relevant terms. Caveat: self-reported, so expect a probe on what drove the growth. Lead with the start and end points in the quote's own terms. |
| F4 | "Ross will push on commercials" (recruiter, your message) | "roughly £4M of influenced revenue" (your message) | medium | [grounded] | discovery | Your material does not show how influenced revenue was counted, or how much of it you could claim. Answer slot: if you counted it, say how, in your own words; if you did not count it, say so, and say what you would count first. |
| F5 | "scheduling software to train operating companies" (your message, company description) | "Never sold into rail specifically" (your message) | none | [grounded] | capability | You stated this absence yourself. Words: "I haven't sold into rail specifically." Then a ramp plan, stated as a plan. |
| F6 | Eligibility terms (none supplied) | none given | none | [generic] | hard_gate | Your material does not establish any eligibility term for this role, such as right to work, office days or travel. I have not checked one. Surface it before the panel, not in it. |

## Prohibited claims

The pack will not coach these, because each stretches a sentence you did say or contradicts one.

| Not coached | Basis | Honest form |
|---|---|---|
| Ran operator partnerships, or sold into rail | Inflated form of F1 and F5 | F1's quote at its own scope. The pack's observation, in its own analysis: your material shows planning-side knowledge of operators, not partnering with them. |
| Carried a direct quota or closed direct revenue | Negative you stated, F2 | "I haven't carried a direct quota." Plain acknowledgment, no slot. |
| Influenced revenue presented as sourced or closed revenue | Inflated form of F4 | The quote "roughly £4M of influenced revenue" at its own scope. No answer names a counting method. |
| Knowledge of rail economics or train operator finances | Inflated form of F1 | The planning-side quote at its own scope only. |

## Deliverable: the POV (recruiter-declared)

The recruiter asked for "a short POV on where you'd take our operator partnerships over the next 18 months", with "no slides needed". Graded deliverable, so this section is part of the pack.

**Grounded facts to build on.** F1: "bus and light rail network planning, so I know the operator world from the other side". F3: "took it from 6 partners to 40".

**Theses.** Pick two. Each carries a concession you must say aloud.

- **T1 (generic): measure partnerships by what changes for the operator first, and partner revenue second.** Concession: outcome measures are slower to show up in revenue, so say which bridge number you would use in year one. Ross will press here.
- **T2 (generic): partner with the operator's planning team, not only its procurement team.** Concession: fewer, deeper partners, and a slower pipeline in the short run.
- **Anti-pick (generic): do not build a bespoke version for the largest operator first.** Concession: that is the easiest deal to win, and you should say why you would still say no to it.

**Differentiation.** The recruiter's market report is the likely consensus answer. I have not seen it, because only your description of it reached me. Name one item from it to show you read it, then diverge with one thesis and your reason.

**Requested close (what it means for the operators themselves).** One sentence, in operator terms, in your own words. Do not borrow a phrase from the report.

**Timing:** 2 min frame (use F1's quote), 6 min T1 and T2 with concessions, 4 min the anti-pick and the operator close, 3 min the commercial bridge, which is the bridge number from T1's concession.

## Persona table

Relationship priors: hiring manager (Case/Strategist and Skeptic) for Deepa; commercial director (Data-Driven Prober and Pressure) for Ross. No interviewer profile was supplied, so no further adjustment is made.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist (Deepa) | Live problem on the first 90 days or the POV | High: hiring managers buy capability on their own roadmap | Clarify, then structure, then answer. Say the framework aloud |
| Skeptic (Deepa) | Probes the rail gap and the planning-side background | High: F5 is the largest gap, and she is the future manager | Hold the plain fact; ramp plan as a plan |
| Data-Driven Prober (Ross) | Asks how £4M and 40 were counted | High: F3 and F4 are headline numbers, and he is the commercial director | Name the weakest assumption before he does; say what you do not know |
| Pressure (Ross) | Challenges influenced revenue and the value of partnerships against price | Medium-high: he is "pushing on commercials" by the recruiter's own words | Pause, restate, hold through two follow-ups, concede specifically |
| Conversational | Opening biography | Low: the panel is structured | 90-second arc from your own sentences only |

## Question banks

**Deepa (hiring manager)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Where would you start in your first 90 days with our operator accounts?" | CASE | [generic] | Clarify first: which operators, which renewal and planning calendar. Then pick two operators to learn from, and define one measure. Name no operator. | A live problem from the role; asks nothing about your past, so it carries no claim. |
| A2 | "Which part of selling to train operating companies have you not done?" | JD | [grounded] "Never sold into rail specifically" (your message) | **Highest-ROI prep in this pack.** Hold: "I haven't sold into rail specifically." Concede the gap plainly, then the ramp plan as a plan. Answer slot: if any of your planning-side work touched an operator's decisions, say which and how; if none did, say so and say what you know from the planning side. Hold through two follow-ups by returning to the planning side. | F5 is the largest gap, and the future manager is likely to press it. |
| A3 | "Tell me about a partner that grew with you. What did you do?" | VAL | [grounded] "running the ISV channel, took it from 6 partners to 40" (your message) | Open prompt. Beats the sentence states: the start point, the end point, and the channel you ran. Answer slot: which of the 40 you recruited, and what you did to keep them; if you cannot name one, describe the channel programme in your own words. | F3 is your strongest quote, and this prompt asks for a story from it. |
| A4 | "What does an operator actually need from a partner that a software vendor does not give them?" | CASE | [grounded] "Please land on what it means for the operators themselves" (recruiter, your message) | The recruiter's own words raise this. Answer from the planning side only, using F1's quote. Name one operator need, in your words, without claiming operator-side experience. | Your POV close depends on the same answer. |
| A5 | "What did your planning work show you about how operators make decisions?" | EXP | [grounded] "bus and light rail network planning" (your message) | Answer from the planning side and say where that view stops. If you are inferring how operators buy, say it is an inference. | F1 is your credible bridge; the question tests whether you claim more than planning saw. |

**Ross (commercial director)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've never carried a direct quota. Why should I trust you with a commercial number here?" | EXP | [grounded] "never carried a direct quota, only influenced revenue" (your message) | Plain acknowledgment: "I haven't carried a direct quota. My number was influenced revenue." Hold, then say what commercial number you would accept, as a plan. Concede where the gap is real. | F2, the stated negative. Ross will press this directly. |
| B2 | "Roughly £4M of influenced revenue. How much of that did you close yourself?" | EXP | [grounded] "roughly £4M of influenced revenue" (your message) | Defend the number. Answer slots: how it was counted; the assumption you would defend least; which part was yours. If you counted it, say how; if you did not, say so. Name no method. | F4, a headline figure. The weakest-assumption move converts a gotcha into a credibility gain. |
| B3 | "Influenced or sourced: which number did you own?" | CO | [grounded] "roughly £4M of influenced revenue" (your message) | Name the number you owned and the part you played. Say plainly if you did not own a sourced number. | Ross separates the two figures. Keep it short. |
| B4 | "Operators are cutting budgets. Why should one pay for partnership value rather than the licence price?" | CASE | [generic] | Pressure. Hold the position that value is measured by outcome. Concede the price pressure specifically. Name one thing you would test first. Hold through two follow-ups. | Pressure persona on commercials; no fact about any operator is in the material, so none is claimed. |
| B5 | "Sketch the commercial model for one operator partnership. What is the price, who pays, and what margin?" | CASE | [generic] | Clarify first: which operators, what product scope, what margin is acceptable. Then the structure: fee or revenue share, and what the partner pays. Give no figures. | Ross's native test; you have no operator-side price history in the material, so none is given. |

**Requirement coverage**

| Requirement (source) | Covered by |
|---|---|
| POV on operator partnerships over 18 months (recruiter) | POV section; A1 |
| What it means for operators (recruiter) | POV close; A4; A5 |
| Commercial pressure (recruiter) | B1 to B5 |
| Partner growth (your message) | A3 |
| Rail sales experience (company description) | A2 |
| Eligibility terms | none, and why: no JD or term list was supplied (see the upgrade menu) |

## Reverse questions

1. "What would a good first 90 days with the operator accounts look like to you?" Lands: shows you are thinking about operators, not only the role.
2. "How did you get to running partnerships at this level?" Lands: a peer conversation, aimed at Deepa's own path, and it is role-generic because no profile was supplied.
3. "Where do the operator outcomes and the commercial model pull against each other today?" Lands: a question only a commercial person can answer, and it is aimed at Ross.
4. "What did the last partnerships hire get wrong?" Lands: it invites an honest answer about expectations.
5. "What would be most useful from me in the first month?" Lands: it signals you are planning for the job, not interviewing for it.

## Sources

- **Provided documents:** your message, which holds the recruiter's quoted sentences and your background. The recruiter's market report was not in this session, so I have not read it; the POV differentiation is unchecked against it.
- **Searches:** three attempted, all refused (search permission not granted):
  - "Kelverton Rail scheduling software train operating companies": refused
  - "Great British Railways train operating companies partnerships 2026 reform": refused
  - "UK rail timetable planning software suppliers operators 2026": refused

**Research tier:** L1 requested, 0 of 6 searches and 0 of 2 fetches run.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Kelverton Rail values` | unavailable | Values cheat sheet omitted; no values were in hand |
| 2. `Kelverton Rail interview process senior partnerships` | unavailable | Loop structure unknown; persona weights rest on the panel and the recruiter's words |
| 3. `Kelverton Rail strategy` / recent news | unavailable | Current strategy grounding brief omitted; the POV is generic and says so |
| 4. `Deepa Kelverton Rail`, `Ross Kelverton Rail` | unavailable | Interviewer read omitted; reverse questions are role-generic |
| 5. representative `Senior Partnerships Manager` JD | unavailable | Requirement rows stay sourced from the recruiter's words; no JD-tagged row is graded |

## Upgrade menu

- The JD text → requirement rows move from recruiter words to `[grounded]` JD lines, and a JD-tagged question set can be added.
- The market report's shortlist, pasted → the POV's differentiation can be checked against the consensus answer.
- Search permission granted → company values, the interview process and current rail context can be checked. Until then the pack states no fact about Kelverton or the rail market.
- Deepa's and Ross's public profiles, if you have their names and links → an interviewer read and tailored reverse questions.
- Any eligibility term (right to work, office days, travel) → the F6 row becomes a checked gate.
