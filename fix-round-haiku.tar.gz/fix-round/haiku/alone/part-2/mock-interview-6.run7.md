Web search was refused by the host, so I'll build the pack from your message alone and flag where that matters. Writing the pack to the scratchpad now.
Your prep pack is saved at /tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-alone-part-2-rooms-case-6-denied-0dc1922a/d7c03b24-e20a-47bb-9914-ae9ed3c706c3/scratchpad/Larkfield_engineering-manager_interview_pack.md. It covers all three rounds: a bank of questions for each, with the Director's round weighted toward your two stated gaps, the panel toward peer and technical probes, and the VP round toward values.

Web search was refused by the host, so the pack has no Larkfield facts. Its company values, interview structure and strategy are absent, and the questions that would need them are marked generic. Pasting Larkfield's values page would let me build the values cheat sheet, which I left out for now.

Two things to check before you rely on it:
- The pack treats "I've never managed managers" and "I've never owned a hardware-adjacent roadmap" as the gaps the Director is most likely to press. Rehearse the plain acknowledgment followed by your plan, not a claim of experience you don't have.
- The answer slots mark where your own answer has to supply the detail, such as how the 60% was counted and which part was yours. Don't fill them with what you think the answer should be.

Do you have the full job posting? If you paste it, the requirements get quoted from the posting instead of your summary. If not, the pack stands as built.

Would you like a one-line drill, where I play the Director and push on your gap answer? Or I can save a tuesday-dossier.md recording what this prep exposed, for later sessions. I can also convert the pack to Word if you want it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Larkfield_engineering-manager_interview_pack.md -----
# Larkfield Systems, Engineering Manager: prep pack for three rounds (loop mode)

Candidate: Yusuf. Rounds: Tuesday, Director of Engineering (45 min); the Thursday after, panel of two staff engineers and a product manager (60 min); the following Monday, VP Engineering (30 min, "values and leadership philosophy").

Research: web search was refused by the host, so no Larkfield facts appear in this pack. Every claim about the company is absent, and every question that would need one is marked `[generic]`.

## How to use

- **Personas** describe how a question is asked. **Types** describe what is being scored: `JD` (the role's requirements), `EXP` (your past work, under scrutiny), `CASE` (a live problem), `VAL` (values and leadership), `CO` (company knowledge; none built, since research did not run).
- Guidance is scaffolding, not a script. Each guidance cell is about 90 seconds spoken.
- Anything you say about your past must be something you did. Where the material is silent, the pack gives you an answer slot, not words.

## Fit snapshot

Requirements come from the role text you pasted. Evidence is quoted from your message only.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" (role text you pasted) | "9 years engineering, 3 as a team lead of 6" (your message) | medium | [grounded] | transferability | Your material shows a team of six, not two squads and not device management. Say it at its own scope: "Three years as a team lead of six." Answer slot: if you have led more than one team, or any device work, say which and what you did, in your own words; if not, say so plainly and stay with the team of six. |
| F2 | "own delivery, hiring and growth for 11 engineers" (role text you pasted) | "I run our hiring loop for backend roles — about 40 interviews last year." (your message); "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." (your message) | medium | [grounded] | transferability | Hiring is shown for backend roles. Delivery is shown only through the reliability quarter. Growth is not shown, and the bridge does not stretch to it. Answer slot: if you have grown an engineer's career, say who and what changed; if not, say so plainly. |
| F3 | "partner with hardware and product on roadmap" (role text you pasted) | "I've never managed managers and never owned a hardware-adjacent roadmap." (your message) | none | [grounded] | capability | A stated absence, so the words are yours: "I've never owned a hardware-adjacent roadmap." Then how you would learn it, said as a plan and never as a past. No claim to roadmap work, and nothing added to make the gap feel smaller. |
| F4 | "no manager-of-managers experience" (your gap statement, not in the role text) | "I've never managed managers" (your message) | none | [grounded] | capability | A stated absence: "I haven't managed managers." Then how you would build that skill, said as a plan. |

Your material does not show product partnership on a roadmap. F3 covers the roadmap half of "partner with hardware and product".

## Prohibited claims

Built locally from the fit snapshot. Do not say these, in any answer, slot or drill.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned a hardware-adjacent roadmap | Negative you stated (F3) | "I've never owned a hardware-adjacent roadmap." No slot. |
| Managed managers | Negative you stated (F4) | "I haven't managed managers." No slot. |
| Led two squads, or 11 engineers | Wider form of F1 and F2 | Your quote at its own scope: a team of six. The material does not show two squads. |
| Designed the reliability quarter, or redesigned on-call | Practice you did not state; wider form of "pushed a reliability quarter through" | "I pushed a reliability quarter through against roadmap pressure." The material does not show what the quarter contained. |
| Hired across the whole engineering org | Wider form of the hiring sentence | "I run our hiring loop for backend roles." |

## Round 1: Director of Engineering (Tuesday, 45 min)

**Persona weights**

| Persona | Weight | Reasoning |
|---|---|---|
| Skeptic | 5 | Hiring-manager prior. Your two stated gaps are what a hiring manager buying capability will test first. |
| Case/Strategist | 4 | Hiring-manager prior. Expect a live problem on the hardware roadmap. |
| Data-Driven Prober | 3 | You quoted a 60% drop and about forty interviews. Both get probed. |
| Pressure | 2 | Low for a 45-minute round, but present. |

No interviewer profile was given, so these weights are round-type priors only.

**Question bank**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You haven't managed managers and haven't owned a hardware-adjacent roadmap. What makes you the right person for this?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." (your message); "9 years engineering, 3 as a team lead of 6" (your message) | Highest-ROI prep in this pack. Open with the plain acknowledgment: "I haven't managed managers, and I haven't owned a hardware-adjacent roadmap." Then the nearest thing your material carries: "Three years as a team lead of six." Then a plan, said as a plan: what you would learn first, and from whom. Hold through two follow-ups by returning to the acknowledgment and the plan. If pressed on the roadmap, concede specifically. Do not add to the record. | This is the most predictable objection. F3 and F4 are your own stated gaps. Type JD because it scores the role's requirements. |
| A2 | "Walk me through how you pushed the reliability quarter through against roadmap pressure." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." (your message) | Tell the beats the sentence states, in your own words: the roadmap pressure, the quarter, the push, the drop. Answer slot: the 60% raises a probe on how it was counted. If you know, say what was counted, over what window, and which part was yours to decide. If you do not know how it was counted, say so plainly. Name the weakest assumption before they do. | F2's delivery evidence and your strongest quote. Type EXP because it tests what was yours. |
| A3 | "Hardware ships on a different clock than software. How would you set up a working partnership with the hardware team in your first ninety days?" | CASE | [generic] | Clarify first: the hardware release cadence, who decides sequencing, what is shared. Then structure: listen, map the dependencies, agree on one decision forum. Make no claim about past work. | Live problem from the hardware-partnership line (F3). Generic because research did not run on Larkfield's hardware cadence. |
| A4 | "Two squads, eleven engineers. One squad's delivery slips two sprints. What do you do on Monday?" | CASE | [generic] | Clarify what slipped and why. Check the squad's own plan before changing it. Decide who you tell and when. Name one thing you would not do. Make no claim about past work. | Tests delivery judgment at the role's real scale. Generic. |
| A5 | "Tell me about someone whose growth you shaped. What changed for them?" | JD | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." (your message) | Open prompt on the growth requirement. Selection: pick a time you had a hand in someone's growth: a named change, what you did, what they did. If none comes to mind, say so plainly, then give the nearest thing your material carries: the hiring loop, and what you took from it. Answer slot: if you did this, say how, in your own words; if not, say so plainly. | F2's growth gap. The open prompt asks you to choose an instance, so it presupposes nothing. |
| A6 | "You ran about forty interviews last year. How was that number counted, and what would you defend least about it?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." (your message) | Defend-the-number slot: say how you counted, what the count includes, and the assumption you would defend least. If you do not know how it was counted, say so. | The figure raises the defend-the-number slot. Probers check counts. |
| A7 | "That's a long way from managing managers. Convince me in sixty seconds." | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." (your message) | Pressure form. Open with the plain acknowledgment, then the nearest thing you did (the team of six, the hiring loop), then the plan. Hold through two follow-ups. Concede where the material is thin, specifically, and do not harden into a claim. | Pressure weight 2. Tests composure on the gap. |
| A8 | "How would you know, ninety days in, that device-management delivery is on track?" | CASE | [generic] | Name two or three signals you would watch, who gives them to you, and what would make you change course. No past claim. | Tests whether you think at the role's altitude. Generic. |

**Reverse questions** (none tied to the interviewer's path, since no profile was given)

- "What would success look like for these squads at the end of year one?" Why it lands: it shows you think in outcomes.
- "Where does the hardware team's planning meet yours, and who decides when they clash?" Why it lands: it shows the partnership is your real concern.
- "What did the last person in this role do that you want to keep, and what would you change?" Why it lands: it asks about their standard.
- "What is the biggest risk to the device-management roadmap that you do not yet have an answer for?" Why it lands: it shows you read for risk.
- "What does a good first ninety days look like in this role?" Why it lands: it turns the hard question into a shared plan.

## Round 2: Panel, two staff engineers and a product manager (Thursday, 60 min)

**Persona weights** (per-member blend; no names, so no per-person assignment)

| Persona | Weight | Reasoning |
|---|---|---|
| Peer Evaluator | 5 | Staff engineers and a PM are peers. Peer priors dominate. |
| Data-Driven Prober | 4 | Two staff engineers will check your numbers and your design choices. |
| Case/Strategist | 3 | The PM carries the roadmap and hardware trade-offs. |
| Skeptic | 2 | Lower here. A1 already rehearses the gap. |

**Question bank**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Where would you draw the seam between device-management services and the hardware team? What happens when you disagree with a peer team?" | JD | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." (your message) | Open prompt on disagreement. Selection: a time you disagreed with a peer team, with a named stake, a moment you did not fold, and the relationship intact at the end. If none comes to mind, say so plainly, then give the nearest thing your material carries: the reliability quarter against roadmap pressure. Answer slot: say how that pressure was settled, in your own words. | Peer seam probe. The hardware partnership is the role's stated line. |
| B2 | "Your team is six. Our two squads are eleven. What is different about running the bigger group?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6" (your message) | Span-of-control probe. Say what you did with six. Say what you have not yet done at eleven. Answer slot: if you have coordinated more than one team, say how; if not, say so plainly and say what you would change first. | F1's gap, asked directly. |
| B3 | "A firmware release goes out and breaks devices in the field. What do you do in the first hour?" | CASE | [generic] | Clarify scope and severity. Stop the rollout. Decide who you wake up and what you tell customers. No past claim. | Live problem near device management. Generic. |
| B4 | "Reliability and feature work both want the same engineers. How do you set that trade-off with product?" | JD | [grounded] "I pushed a reliability quarter through against roadmap pressure." (your message) | Story map from the sentence: the roadmap pressure, the push. Answer slot: how the trade-off was decided with product. If it was decided above you, or you did not set it, say so plainly and stay with what you pushed through. | The PM's domain. F2's delivery evidence. |
| B5 | "Tell me about a technical design you disagreed with a staff engineer on. Who was right?" | JD | [generic] | Selection: pick a design argument. Name what you argued, what they argued, and how it resolved. If you did not argue the design, say so plainly and describe how you would handle the disagreement. | Staff-engineer probe. Open prompt, so no claim about you. |
| B6 | "Which assumption behind that 60% would you defend least?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." (your message) | Weakest-assumption move. Name the assumption in your own words before they do. Answer slot: if you know how the figure was counted, say what was counted; if you do not, say so plainly. | Prober check on the figure, the same figure as A2 in a different frame. |

**Reverse questions**

- "What would a new engineering manager do in the first month that would genuinely help your team?" Why it lands: this is the reciprocity question for peers, and it shows you think about what you add to their load.
- "Where do the staff engineers feel the most friction with product today?" Why it lands: it opens the seam conversation from their side.
- "How are design decisions made across the device and service boundary?" Why it lands: it shows you are asking how the work actually moves.
- "What does the product manager need from engineering that the team does not give yet?" Why it lands: it turns the trade-off into a shared problem.
- "What has gone wrong on the device roadmap in the last year, and what changed afterwards?" Why it lands: it signals you want the real history, not the pitch.

## Round 3: VP Engineering, values and leadership philosophy (Monday, 30 min)

Values-style round, detected from the recruiter's own words. The published values section is omitted because Larkfield's values are not in hand. Paste them and a values cheat sheet can be built.

**Persona weights**

| Persona | Weight | Reasoning |
|---|---|---|
| Values/Behavioral | 5 | The recruiter named the round. |
| Pressure | 3 | Executive altitude and a 30-minute composure test. |
| Case/Strategist | 2 | VP-level strategy probes, generic because research did not run. |

**Question bank**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." (your message) | Story map: the roadmap pressure, the push, the drop. Answer slot: what you said to the people who wanted features, and whether it landed. If the push was reversed, or the pressure won, say so. If no such moment comes to mind, say so plainly, then give the nearest thing your material carries. | The reliability quarter is your only quote for a hard message. |
| C2 | "What is your leadership philosophy in one sentence, and where did it come from?" | VAL | [generic] | Scaffold: name one belief you act on, and one decision that shows it. If you hold no philosophy in words yet, say so and name the one you are testing. | Open prompt. A pattern for the round, with no claim about you. |
| C3 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Scaffold: pick a time an internal number and a customer outcome pulled apart. Say what you chose and what it cost. If none comes to mind, say so plainly, then say how you would handle it. | Persona stem. Generic because the company's values are not in hand. |
| C4 | "You've never managed managers. Why would you be good at developing the people who lead squads?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." (your message) | Plain acknowledgment: "I haven't managed managers." Then the nearest thing your material carries: "I run our hiring loop for backend roles." Then a plan: how you would build manager-of-manager skill, and from whom. Hold through two follow-ups. Concede specifically. | The VP is probing your stated gap in a values frame. |
| C5 | "Sixty seconds: why should we hire someone who has never owned a hardware-adjacent roadmap?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." (your message) | Pressure form. Open with "I haven't owned one." Then the plan you would follow to learn it. Hold through two follow-ups. Do not offer a reason you can't back. | Tests composure on F3. |
| C6 | "How would you tell whether two squads are pointed at the right outcome?" | CASE | [generic] | Name the outcome, the signals that lead to it, and who checks them with you. No claim about company strategy. | Executive altitude. Generic. |
| C7 | "That 60% — how much of it was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." (your message) | Say which part was yours to decide and which was the team's. If the team owned it, say so and say what you did as lead. Answer slot: how the figure was counted. | The attribution probe. Honesty is the test here. |

**Reverse questions**

- "How does this leadership team decide when a device roadmap and a reliability commitment conflict?" Why it lands: it shows the values question is live for you.
- "What do the best managers here do in their first ninety days?" Why it lands: it asks for the standard, not the pitch.
- "What leadership behavior would you most want more of in the next year?" Why it lands: it asks what they are missing.
- "When a team misses a commitment here, what happens next?" Why it lands: it reveals the culture behind the values.
- "What would you want the new manager to have decided by the end of month three?" Why it lands: it turns the round into a plan.

## Requirement coverage

| Requirement (source) | Covered by |
|---|---|
| "Lead two squads building device-management services" (role text) | A1, A3, A8, B2, C6 |
| "own delivery, hiring and growth for 11 engineers" (role text) | A2, A4, A5, A6, B1, B4 |
| "partner with hardware and product on roadmap" (role text) | A1, A3, B1, B4, C5 |
| "no manager-of-managers experience" (your gap statement) | A1, A7, C4 |

## Sources

Provided documents: your message (the role description, your background and the three round descriptions).

Research tier: L1 requested, unavailable. The host refused web search permission, so the pack was built at L0.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Larkfield Systems values` | unavailable | Values cheat sheet, omitted. Search refused. |
| 2. `Larkfield Systems engineering manager interview process` | unavailable | Loop structure. Round weights are round-type priors. Search refused. |
| 3. `Larkfield Systems industrial IoT device management strategy` | unavailable | Company strategy for CO and CASE questions. Search refused. |
| 4. Interviewer name and company | n/a | No names given, so there was no query to form. |
| 5. Representative JD | skipped | The role description you supplied fixes the requirements. |

Queries sent, all refused: `Larkfield Systems values`; `Larkfield Systems engineering manager interview process`; `Larkfield Systems industrial IoT device management strategy`.

## Upgrade menu

- The full job posting → the requirements in F1 to F3 become quoted lines instead of your summary, and the coverage table gets exact.
- The recruiter's note on each round's focus → sharper round weights, and a check on whether the Round 3 values framing is right.
- Larkfield's published values, pasted → the values cheat sheet for Round 3, and VAL questions mapped to them.
- The Director's, staff engineers' and PM's names → per-person persona weights, and reverse questions tied to their career paths.
- A deeper research pass (up to 6 more searches and 2 fetches, several minutes), needs search permission → strategy-grounded CO and CASE questions in place of the `[generic]` ones.
- Any device or IoT work you have done, or a time you led more than one team → turns F1, F3 and the B2 and C4 slots into your own quotes.
