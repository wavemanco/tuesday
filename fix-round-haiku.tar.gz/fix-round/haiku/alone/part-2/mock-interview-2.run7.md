Your prep pack is saved as /tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-alone-part-2-rooms-case-2-denied-2d81eadd/a9ce89c1-e051-4e90-baeb-b80d735a5e7a/scratchpad/Atlas_Freight_operations-manager_interview_pack.md. I built it for a hiring-manager round, since your note didn't say who you're meeting, and without company research, since I haven't run any yet.

Say the word and I'll play the Skeptic on A1, the scale question, which the pack names as the highest-ROI prep. I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

Who are you meeting: your future manager, or a peer? The answer reweights the persona table.

Should I run a quick research pass on Atlas Freight first (values, interview format, recent news)? It would replace the generic Values and Case questions with company-specific ones.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Atlas_Freight_operations-manager_interview_pack.md -----
# Interview pack: Operations Manager, Atlas Freight

Round: assumed hiring-manager round (your note didn't say who you're meeting). Interviewer: not known. Research: not run (no consent yet). Built from the job description and your background as you wrote it.

## How to use + type key

Personas are how a question is asked. Types are what it scores.

- **JD**: the job description's own requirements
- **EXP**: your past work, and whether it holds up under scrutiny
- **CASE**: a live problem from the role, solved aloud
- **VAL**: behavioral, past-behavior questions
- **CO**: company knowledge. None in this pack, because no research was run.

Guidance is scaffolding, not a script. Aim for 90 to 120 seconds spoken. Where guidance says "answer slot," the answer is yours to give from your own experience, in your own words, including the honest branch.

## The fit snapshot

Quotes are your own words (from your background message) or the JD's words. Nothing in the evidence column is paraphrased.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" (JD) | "7 years in warehouse and distribution ops" (your message); "currently a senior shift manager over 3 supervisors" (your message) | medium | [grounded] | transferability | Your material shows a shift over three supervisors, and nothing about terminals or sites. Stay at that scope: "I'm a senior shift manager over three supervisors." Answer slot: the four-site scope makes a probe likely. If you have run operations across more than one site or a terminal, say which and what you were responsible for. If not, say so plainly and describe the largest scope you have run. |
| F2 | "drive on-time performance and cost-per-shipment down" (JD) | "cut mis-pick rate 40% by redesigning the pick path" (your message) | medium | [grounded] | transferability | Your material shows an accuracy metric, not on-time performance or cost per shipment. Bridge: "I cut mis-pick rate 40% by redesigning the pick path." Answer slot: the JD names on-time and cost, so expect a probe. If you tracked either, say what and how it moved. If not, say so and say what you would measure first. |
| F3 | "lead a team of 12 supervisors" (JD) | "currently a senior shift manager over 3 supervisors" (your message) | medium | [grounded] | transferability | Three is the number your material gives; twelve is the JD's scope. Bridge: state the three. Answer slot: if you have led a larger group than three supervisors, say how many and over what. If not, say so and say how you would structure a team of twelve. |
| F4 | "5+ years operations leadership required" (JD) | "7 years in warehouse and distribution ops" (your message); "currently a senior shift manager over 3 supervisors" (your message) | low | [grounded] | discovery | Your material gives seven years in operations but not how many were in a leading role, so the five-year leadership test is unsettled. Answer slot: state how many of your seven years were in a leading role, and over whom. If fewer than five, say so and say what you have led since. |
| F5a | "build reporting in Excel/Power BI" (JD) | "solid Excel" (your message) | low | [grounded] | transferability | Excel is claimed, but no report you built is quoted. Bridge: "I'm solid in Excel." Answer slot: if you have built a report others used, describe what it tracked and who used it. If not, say so and say what you would build first. |
| F5b | "build reporting in Excel/Power BI" (JD) | "never used Power BI" (your message) | high | [grounded] | capability | You stated this absence, so the pack gives your words back: "I've never used Power BI." Then how you would learn it, as a plan with a timeframe you can commit to, never as a past. Never claim Power BI work to close the gap. |
| F6 | "Lean/Six Sigma a plus" (JD) | "green belt certified" (your message) | medium | [grounded] | none | Your material says the certification, not what you applied it to, so expect a probe on use. Lead with the certification in your words: "I'm green belt certified." The certificate is the artifact that would raise this to high. |

## The prohibited list

Claims this pack will not coach, and why. Each has a basis and an honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Leads or led twelve supervisors | Inflated form of F3 | "over 3 supervisors," at its own scope. Your material says three; the limit is the pack's observation, not a claim you make. A1's answer slot stays inside the three |
| Runs terminal operations across four sites | Inflated form of F1 | "I'm a senior shift manager over 3 supervisors." The pack observes your material says a shift, not terminals or sites |
| Cut cost per shipment or lifted on-time performance | Inflated form of F2: the mis-pick cut stretched into the JD's metrics | "I cut mis-pick rate 40% by redesigning the pick path," at its own scope. Your material does not show the JD's two metrics |
| Designed the pick-path redesign alone | Attribution inflation of F2's quote, which does not say who designed it | The quote at its own scope. C2's answer slot asks whose part it was |
| Built Power BI reports, or any Power BI experience | Negative you stated (F5b) | "I've never used Power BI." Plain acknowledgment, no slot |
| Built reporting dashboards in Excel | Inflated form of F5a's "solid Excel" | "solid Excel," at its own scope |
| Led Lean or Six Sigma projects | Inflated form of F6's "green belt certified" | "green belt certified," at its own scope |

## Persona table

Relationship prior: hiring manager. Priors: Case and Skeptic dominant. No interviewer profile, so no adjustments. Depth follows weight: top persona 5, then 4, mid 3, low 2.

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (A) | Presses on scale, the four sites, and Power BI | Highest, weight 5. Hiring-manager prior names Skeptic first, and the JD's twelve-supervisor, four-site and Power BI lines are where your material is thinnest | Rehearse A1 until it's routine. Name each gap in your words, then give the ramp plan. Don't bluff |
| Case / Strategist (B) | Live problems on terminal performance, peak planning, reporting and Lean | Weight 4. Hiring-manager prior names Case second, and the role is operational, so live problems are likely | Clarify first, then structure aloud. Don't invent numbers to fill a case |
| Data-Driven Prober (C) | Tests your 40% and your Excel and metrics claims | Weight 3. A quantified claim invites denominators and counting questions | Say how a figure was counted only if you did. Name the assumption you'd defend least. "I don't know" is an honest answer |
| Pressure / Stress (D) | Time-boxed challenge on scale; "how much was actually you" | Weight 2. Not in the hiring-manager prior, but the 40% claim makes attribution questions likely | Hold through two follow-ups. Concede specifically, not wholesale |
| Values / Behavioral (E) | Story prompts. No published values in hand, so no values-style round is detected | Weight 2. Behavioral questions are common in operations hiring | Selection scaffold; take the honest branch if no story fits |
| Conversational / Rapport (G) | An opening walkthrough, and Excel asked casually | Weight 2. Casual questions still score, especially on JD topics | A 90-second arc built from your quotes. Treat casual Excel as scored |

## Question banks

Question IDs: letter by persona. Type is one token, the primary tag; rationale notes any second tag.

### Skeptic (A), weight 5

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You lead three supervisors today, and this role leads twelve across four sites. What's the step between those?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" (your message) | Name the three in your words. Then the honest step: what you did to run the three, and what changes at twelve. Answer slot: if you have led a larger group or more than one site, say how many and where. If not, say so plainly and describe how you would structure the twelve. Hold through two follow-ups by returning to the three. This is the highest-ROI prep in the pack | Scale is the objection the JD's twelve-and-four lines make most likely, and it sits where your material is thinnest (F3, F1). The premise is the three, which you quoted. "Twelve" and "four" come from the JD |
| A2 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "never used Power BI" (your message) | Name Power BI first, in your words: "I've never used Power BI." Then how you would close it, as a plan. Concede that one gap specifically; don't add a second weakness to look balanced | The standard Skeptic opener. Power BI is the one absence you stated, and the question is aimed at it |
| A3 | "The role asks for five-plus years of operations leadership. How many of yours were in a leading role?" | JD | [grounded] "7 years in warehouse and distribution ops" (your message); [grounded] "currently a senior shift manager over 3 supervisors" (your message) | Answer slot: state the number of years in a leading role and over whom, from your own record. If fewer than five, say so and say what you have led since. Don't round up | A length-of-experience test, graded on fit. Your quotes give seven years in operations but not the leading share (F4) |
| A4 | "Power BI is in the job description. Where are you on it?" | JD | [grounded] "never used Power BI" (your message); [grounded] "solid Excel" (your message) | One plain sentence: "I've never used Power BI." Then the bridge your quotes carry: "solid Excel." Then how you would learn it, as a plan, never as a past | The stated absence, asked directly. The question presupposes the gap, which your own statement confirms |
| A5 | "What's the largest operation you've run, in sites and in people?" | EXP | [grounded] "7 years in warehouse and distribution ops" (your message) | Answer with the largest, in sites and people, from your record. If you have not run more than one site, say so and state the largest site. Hold to the record | The same scale objection as A1, from another angle. A second chance to state the true scope |

### Case / Strategist (B), weight 4

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "On-time at one of your four sites has slipped for three weeks, and cost per shipment rose at the same time. Where do you start?" | CASE | [generic] | Clarify what changed and when. Define on-time and cost per shipment the same way across sites. Split the problem before touching it, by cause, shift or site. Name one hypothesis to test first. Say what you would hold steady meanwhile. Structure aloud. Don't claim you've solved a case like this | A live problem from the JD's on-time and cost lines. Generic because it names nothing from your past |
| B2 | "Peak season starts in six weeks and forecast volume is up sharply. Sketch the plan." | CASE | [generic] ; [grounded] "ran the site's peak-season surge plan two years running" (your message) | Clarify the forecast basis and what's fixed (headcount, sites, dock hours). Structure by labor, space and flow. Name one risk to surface early. Use your surge plan as a bridge only if asked where you've done this, and say it as you wrote it: "ran the site's peak-season surge plan two years running" | Peak planning is a core operations skill, and the surge-plan quote is your closest analogue. The question doesn't ask about it, so it stays a bridge |
| B3 | "If supervisors' daily numbers came from several spreadsheets nobody trusts, what would you build first?" | JD | [grounded] "build reporting in Excel/Power BI" (JD); [grounded] "solid Excel" (your message) | Name the one decision the report must support, then the first number. Excel first, Power BI as your ramp. Don't claim you've built this report | The JD's reporting line, asked as a problem. The Excel quote is the only reporting-adjacent claim you have |
| B4 | "Where would you start a Lean project on this floor, and what would make you stop it?" | CASE | [grounded] "green belt certified" (your message) | Pick a process with measurable waste. Name the measure, then the stop rule. Use green-belt vocabulary only as you learned it. Describe an application only if you have one: answer slot | The JD's Lean line, and your green-belt certification is the only credential in your material, so this tests it |

### Prober (C), weight 3

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "How was that 40% counted, and what would make it wrong?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Story-map on the quote: the mis-pick rate, cut 40%, by the pick-path redesign. Weakest-assumption move: name, in your words, the assumption you'd defend least. Answer slot: if you did the counting, say how, in your own words. If you did not, say so plainly and say where the figure came from. Don't reconstruct a method you can't repeat | Your headline metric. Probers test counting first. The figure raises only the defend-the-number slots |
| C2 | "Who designed the pick-path redesign behind that 40%, and what was yours in it?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Answer slot: say whose redesign it was, and your part, in your words. If you led it, say what you decided. If you proposed it, or executed someone else's design, say that. Never claim the design alone | The attribution probe. "By redesigning" doesn't say who designed it, so the guidance holds only what the quote carries |
| C3 | "Have you tracked cost per shipment or on-time performance yourself? What did you do with it?" | JD | [grounded] "drive on-time performance and cost-per-shipment down" (JD) | Answer slot: if you tracked either, say which, how, and what changed. If not, say so plainly and say what you would measure first | Raised by the JD's metric line. Your material has nothing on either metric, so the honest branch is written in |

### Pressure / Stress (D), weight 2

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you, for a role that wants twelve supervisors, when you lead three?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" (your message) | Pause. Restate the question in your words. Answer in three moves: what you do now, what carries to twelve, what you'd need to learn first. Hold the three-supervisor fact. Concede the scale gap by name; don't defend the whole candidacy | A pressure test on the biggest gap (F3). The premise is your quote |
| D2 | "That 40% — how much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Hold-then-concede. Hold the part that was yours, in the quote's words. Concede the shared part specifically. Answer slot: if the redesign was yours, say which part. If it was shared, say how you contributed, in your own words. Never fold to zero, never inflate to all | Attribution under pressure. The one cell where folding is the failure |

### Values / Behavioral (E), weight 2

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time you told someone senior something they didn't want to hear. It needs a named stake, the moment you said it, and what happened after. If no such time comes to mind, say so plainly, then give the nearest thing you have done, or how you would handle it | A common behavioral prompt in operations hiring. No values sheet in hand, so there is no mapped value |
| E2 | "Tell me about the peak season you ran, and what you'd keep." | VAL | [grounded] "ran the site's peak-season surge plan two years running" (your message) | Story-map on the quote. Two beats it states: the plan, and that you ran it two years running. Anything beyond is an answer slot: if you can state an outcome, say how you know it; if not, say what you would measure | Your strongest story is in the quote. Results beyond it aren't in your material, so they stay an answer slot |

### Conversational / Rapport (G), weight 2

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So — walk me through the journey." | EXP | [grounded] "7 years in warehouse and distribution ops" (your message); [grounded] "currently a senior shift manager over 3 supervisors" (your message); [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message); [grounded] "ran the site's peak-season surge plan two years running" (your message) | A 90-second arc in this order: seven years in operations, now a senior shift manager over three, the pick-path result, the peak plan. Each beat is one of your quotes; add nothing | Opening biography is scored for economy. Your quotes give the beats |
| G2 | "What are you playing with in Excel these days?" | JD | [grounded] "solid Excel" (your message) | Say what you use Excel for, only what you've done. Keep "solid" as your word. Answer slot: if you've built a report others used, describe what it tracked and who used it. If not, say what you would build first | Casual register, but the JD's Excel line is scored. Excel is your strongest reporting claim, and it is unverified |

## Requirement coverage

| JD requirement | Covered by |
|---|---|
| Own daily terminal operations across 4 sites | A1, A5, B1 |
| Drive on-time performance and cost-per-shipment down | B1, C3 |
| Lead a team of 12 supervisors | A1, D1 |
| Build reporting in Excel/Power BI | A2, A4, B3, G2 |
| 5+ years operations leadership required | A3 |
| Lean/Six Sigma a plus | B4 |

## Reverse questions

Each one lands for a specific reason. No interviewer profile, so these are role-specific, not personal.

1. "What would the first ninety days look like, and where do you expect me to change something first?" Why it lands: shows you're planning the role, not waiting to be told.
2. "Of the four sites, which is hardest to run right now, and why?" Why it lands: signals you think site by site.
3. "How is on-time performance measured across the sites, and which number does the team check first?" Why it lands: tests the definition before you own the number.
4. "What reporting do supervisors have today, and where do they say it falls short?" Why it lands: connects straight to the Excel and Power BI requirement.
5. "What did the last person in this role do well, and what would you change?" Why it lands: invites an honest conversation about scope.
6. "What would make you say in a year that this was the right hire?" Why it lands: asks for the success measure you'll be held to.

## Sources

- Provided: the job description and your background, both in your message. No CV was provided.
- Research tier: L0. No research has been run; no consent given yet.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Atlas Freight values | unavailable | Values cheat sheet. No research consent yet |
| 2. Atlas Freight interview process, operations | unavailable | Loop structure and persona weights. No research consent yet |
| 3. Atlas Freight strategy / recent news | unavailable | Current strategy and recent moves, for the Case bank. No research consent yet |
| 4. Interviewer name + Atlas Freight | n/a | No interviewer name was given, so there was no query to form |
| 5. Representative operations manager JD | skipped | Your supplied JD fixes the fit snapshot and the JD questions |

## Upgrade menu

- Who you're meeting, and their role → reweights the persona table and makes the reverse questions specific
- Your consent to a standard research pass → Atlas Freight's values, interview loop and recent news, moving the Values and Case banks from generic to grounded
- The number of years you've been in a leading role → A3 and F4 move from discovery to grounded
- Your Green Belt certificate → F6 moves from medium to high confidence
- An example Excel report you built, described in your words → B3 and G2 gain grounded detail
- Site count, sizes and headcount for the four sites → A5 and B1 gain concrete scope
- Any Power BI work since you wrote this → A2 and A4 get an honest update. Tell me exactly what it was
- Prep time before the interview → a prioritized schedule, sized to the time
- A tuesday-dossier.md from an earlier job review → verified evidence and stated limits in place of the inferred objection
