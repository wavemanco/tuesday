Your prep pack is saved as `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-alone-part-2-rooms-case-8-canned-2911e1f5/37d83667-ac2b-46f8-bd4b-09a72168387b/scratchpad/ashgrove_member-experience-lead_interview_pack.md`.

I built it as a three-round loop: a shared fit snapshot, then a mini-pack for each round. I ran no web research, since your pasted material covered the values, the process and the strategy summary. Two things will shift the pack most: your actual CV, and the names of the Head of Member Services and the two branch managers.

The most important finding is the gap read. Your strongest material is the six years in retail banking, the complaints log and the spreadsheet. The three gaps the panel will press are the contact centre, presenting above regional level, and ownership across branches. Question B2 (the contact-centre objection) is the highest-return rehearsal, and I'd practise the stated gaps as plans, not as past experience.

Would you like me to run a drill on B2? I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions. If you'd rather have the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove_member-experience-lead_interview_pack.md -----
# Interview prep: Member Experience Lead, Ashgrove Credit Union

**For:** Dara · **Rounds:** 20 November 2026 (three rounds, one day)
- **R1, 30 min:** recruiter
- **R2, 45 min:** Head of Member Services, your future manager, mostly behavioural (not yet named)
- **R3, 60 min:** panel of two branch managers, including a 20-minute complaint-escalation case, scored against the four values (not yet named)

**Mode:** loop. The recruiter's email names the rounds, so each round gets its own mini-pack on a shared fit snapshot.
**Built from:** the JD, the recruiter's email, the values text you pasted, the strategy summary the recruiter relayed, and your background note. No CV was provided, so every candidate quote below comes from your message.

## 1. How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored.
- **VAL** behavioural and values · **EXP** your own past work · **JD** the listed job · **CO** company and strategy · **CASE** live problem
- Guidance is scaffolding, not a script. Lines marked *answer slot* are instructions for the interview: answer whichever branch is true for you.
- Where guidance rests on something you did, the Provenance column shows the sentence it rests on. If you cannot say it in your own words, do not use it.

## 2. Fit snapshot (shared across rounds)

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" (JD) | "6 years in retail banking, the last 3 as a branch supervisor" (your message) | medium | [grounded] | none | Years line up. Say the six years and the three as supervisor in your own words. Expect a probe on whether branch counter work counts as customer operations at volume. |
| F2 | "experience handling regulated complaints" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | transferability | The material shows a formal complaints log for one branch. It does not show regulatory deadlines or how the log was judged. Answer slot: if complaints you handled ran to a regulatory timeline, say which and how you tracked it; if they did not, say so and stay with the log. |
| F3 | "Own the member complaints process end to end across branches and the contact centre" (JD) | "I handled the branch's formal complaints log" (your message) | low | [inferred] | transferability | Your material covers one branch's log, not ownership across branches. Use the log as the adjacent work and name the limit: it is one branch. Answer slot: if you ever coordinated complaint handling across more than one site, say how; if not, say so. |
| F4 | "across branches and the contact centre" (JD) | "Never worked in a contact centre" (your message) | none | [grounded] | capability | A gap you stated. Words: "I haven't worked in a contact centre." Then how you would learn it, said as a plan. Never a claim to contact-centre work. |
| F5 | "report monthly on complaint volumes and resolution times" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | medium | [grounded] | discovery | Monthly volume reporting is shown. Resolution times are not shown. Answer slot: if the spreadsheet tracked how long complaints took to close, say how it was measured; if it did not, say so plainly. |
| F6 | "coach branch supervisors on escalations" (JD) | "trained new tellers on our escalation script" (your message) | medium | [grounded] | transferability | Training tellers is adjacent to coaching supervisors. Say the training, then name the step up as the part you have not done. |
| F7 | "work with digital teams on self-service journeys" (JD) | none given | none | [grounded] | discovery | Nothing in your material touches this. Answer slot: if you worked with anyone on a digital or self-service journey, say who and what; if not, say so and say how you would start. |
| F8 | "confident presenting to senior leaders" (JD) | "I've never presented to anyone above regional level" (your message) | none | [grounded] | capability | A gap you stated. Words: "I haven't presented to anyone above regional level." Then the plan, said as a plan. Do not claim confidence you have not shown. |
| F9 | "comfortable with Excel reporting" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | medium | [grounded] | presentation | The quote already reaches the requirement in other terms. Do not say "Excel" unless you used it. If asked, name the tool and what you built, in your words. |

**Gap read.** Your strongest material is F1, F2 and F9. The three gaps the panel will press are F4 (contact centre), F8 (senior presenting) and F3 (across branches). The rounds should rehearse those three, not the strengths.

## 3. Graded deliverables

None declared by the recruiter. Section dropped.

## 4. Grounding brief (strategy, as the recruiter relayed it)

Source: the recruiter's summary of Ashgrove's July 2026 strategy brief. The brief itself was not read. Vocabulary to use: *member service*, *digital channels*, *branch hubs*, *small-business lending*, *app-only banks*.
- Move 40% of member service to digital channels by 2028.
- Consolidate eight branches into five hubs over 2027.
- Launch a small-business lending product in Q1 2027.
- Main competitive pressure: app-only banks.

## 5. Persona weights (per round)

| Round | Relationship | Weights | Reasoning |
|---|---|---|---|
| R1 recruiter | Conversational 3, light Skeptic 2 | Recruiter screen prior. Logistics, motivation and knockout checks. The risk is treating it as unscored. |
| R2 Head of Member Services | Skeptic 4, Values/Behavioral 4, Pressure 2 | Hiring-manager prior: they are buying capability and checking gaps. "Mostly behavioural" lifts Values. |
| R3 panel | Values/Behavioral 5, Case/Strategist 4, Peer Evaluator 3, Pressure 2 | Blend of the top two personas per member. The panel also scores the four values, so Values leads. |

**Highest-ROI prep:** B2. The objection, "you have never worked in a contact centre, so why would you own complaints that come through one?", is the one most likely to arrive in some form in R2 and again in R3. It gets the deepest rehearsal and is drilled in every round.

## 6. Question banks

### Round 1: recruiter (Conversational and light Skeptic)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Tell me about your background and what brought you to Ashgrove." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" (your message); "I handled the branch's formal complaints log" (your message) | Open with the six years and the three as supervisor, in those words. Then the complaints log, and stop there. Give your reason for applying in your own words; the pack cannot supply it. | F1 and F2 open the conversation. The recruiter checks consistency with the CV. |
| A2 | "This role includes a contact centre. Where does your experience sit against that?" | JD | [grounded] "Never worked in a contact centre" (your message) | Say it plainly: "I haven't worked in a contact centre." Then the nearest thing you did, which is the branch log, and how you would learn the rest. Do not soften it. | F4 is a stated gap. A recruiter's knockout check hears a hedge as a yes. |
| A3 | "What would make a role a no for you?" | CO | [generic] | Name one or two real limits in your own terms. Keep them about the role, not about the employer's strategy. | Motivation check. No claim about your past is needed. |
| A4 | "Our strategy moves 40% of member service to digital and consolidates eight branches into five hubs. What's your view?" | CO | [grounded] recruiter's summary of the strategy brief (recruiter email) | Speak as a complaints person: when channels or branches change, complaints move. Answer slot: if you have seen a branch change affect complaints, say what and how; if not, say so and say what you would check first, such as complaint volumes by channel. | Grounded in the strategy summary the recruiter sent. Shows you read it without pretending to know the brief's detail. |

### Round 2: Head of Member Services (Skeptic, Values/Behavioral, Pressure)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a complaint from the log that was hard to resolve." | VAL | [grounded] "I handled the branch's formal complaints log" (your message) | Pick one complaint from the log. Beats: what the member wanted, what the log required, what you decided, how it closed. Answer slot: if it closed, say how; if it did not, say what you did to keep it moving. Own the Fix is the test: whoever finds the problem keeps hold of it. | F2 is your best story. The question checks Own the Fix. |
| B2 | "You've never worked in a contact centre. How would you run complaints that come through one?" | JD | [grounded] "Never worked in a contact centre" (your message) | **Highest-ROI rehearsal.** Hold: "I haven't worked in a contact centre." Then what you do know about how complaints arrive from a branch, from the log. Then a 30-day plan, said as a plan: listen to calls, read a sample of contact-centre complaint files, meet the team leads. Hold through two follow-ups by returning to the plan. Never claim contact-centre experience. | F4 is a stated gap and F3 is the adjacent work. A non-defensive, specific plan scores better than a bluff. |
| B3 | "You've handled one branch's complaints log. Owning complaints across branches is a different job. What is the difference?" | JD | [grounded] "I handled the branch's formal complaints log" (your message) | Name the scope honestly: one branch. Then name the difference you can see, such as coordinating handling across sites and keeping one owner per complaint. Answer slot: if you ever coordinated across more than one site, say how; if not, say so. | F3 is low confidence. Name the limit yourself before the panel does. |
| B4 | "Walk me through your monthly complaints spreadsheet. What did it count, and how long did complaints take to close?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" (your message) | Defend the number: say what it counted, in your words. Name the one assumption you would defend least. Answer slot on resolution times: if it tracked closure time, say how it was measured; if it did not, say so. Do not say how it was calculated unless you know. | F5 and F9. This is the likeliest place for a probe. The slot is the only honest answer to "how long" if the sheet did not track it. |
| B5 | "Tell me about a time a member's situation didn't fit the script or the rules." | VAL | [generic] | Selection scaffold: pick a case where you chose the member's side of the counter over the procedure. Give the choice, what it cost, and what you told the member. Honest branch: if no such case comes to mind, say so plainly and describe how you would handle one. | Members First. No quote in your material carries this story, so the guidance gives selection criteria only. |
| B6 | "You trained tellers. Coaching branch supervisors is a step up. What makes you ready?" | JD | [grounded] "trained new tellers on our escalation script" (your message) | Hold: say what you trained, in those words. Then the step up, and concede it: you have not coached supervisors. Name what you would do first, such as sitting in on supervisors' escalation reviews. Hold through two follow-ups; concede the gap, do not fold on the training. | F6, transferability. Hold-then-concede is the pressure structure. |
| B7 | "You have never presented above regional level. How would you present complaint trends to the executive team?" | JD | [grounded] "I've never presented to anyone above regional level" (your message) | Say the negative first: "I haven't presented to anyone above regional level." Then the plan: anchor on the spreadsheet you already built, rehearse with your manager, keep to three numbers. Do not claim you can. | F8, stated gap. Pressure: the second follow-up will ask why you think you can. Hold the plan. |
| B8 | "Where would you start with a self-service journey you didn't design?" | JD | [grounded] none given: the JD line "work with digital teams on self-service journeys" | Answer slot: if you have worked with anyone on a digital or self-service journey, say who and what; if not, say so. Then your start: complaint volumes by channel from the log, and a conversation with the digital team on where members get stuck. | F7, discovery. Your material is silent. The plan is a plan, not a claim. |

### Round 3: panel of two branch managers (Values/Behavioral, Case/Strategist, Peer Evaluator)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you put a member ahead of a process." | VAL | [generic] | Same selection scaffold as B5. Give the choice, the cost, and the outcome. Honest branch: if none comes to mind, say so and describe your approach. | Members First. Scored by the panel. |
| C2 | "Tell me about a time you explained something to a member who needed it said twice." | VAL | [grounded] "trained new tellers on our escalation script" (your message) | If you trained tellers to explain the escalation path, say the words you used. Answer slot: if the script was not written in plain words, say so, and say what you did to make it plainer. Do not claim the script was yours to write. | Plain Words. F6 is the nearest quote; the story is only as wide as its sentence. |
| C3 | "How does a branch's place in its town change how you'd handle its complaints?" | VAL | [generic] | Scaffold: pick a branch you know well. Say what the town knows about it, and what is lost when a branch folds into a hub. Honest branch: if you have not worked through a branch closure or merger, say so, and say what you would ask staff and residents first. | Neighbours, Not Numbers, linked to the hub strategy. Your material carries no branch-community story. |
| C4 | "Tell me about a complaint you did not close. What did you do?" | VAL | [grounded] "I handled the branch's formal complaints log" (your message) | Own the Fix: the question tests whether you stayed with it. If you can name an unclosed complaint from the log, say what you did to keep it moving and who owned it. If you cannot, say so, and describe how you would keep one owned until solved. | Own the Fix. A different angle from B1, on purpose. |
| C5 | Escalation case (see section 7). | CASE | [generic] | Use the structure in section 7. | The round's scored case. |
| C6 | "How would you find out whether the 40% digital target is hurting complaint handling?" | CASE | [grounded] "move 40% of member service to digital channels by 2028" (recruiter email) | Clarify first: what counts as member service, and what has changed. Then the measures: complaint volume by channel, time to resolve by channel, repeat contacts. Name a risk: members who cannot use the app. | CO and CASE from the strategy summary. Structure and vocabulary, not a claim about Ashgrove's numbers. |
| C7 | "Our branches and the contact centre disagree about who owns a complaint. Where is the seam, and what do you do?" | JD | [generic] raising source: the JD line "across branches and the contact centre" | Propose seam principles, not a history: one owner per complaint, a named handoff, and a shared log. Do not pretend to have solved it. | Peer Evaluator. A seam question from a peer. The JD names this seam. |
| C8 | "When a fix needs three teams, how do you handle credit?" | VAL | [generic] | Scaffold: name who did what, and say the fix needed all three. Honest branch: if you have not had that situation, say how you would handle it. | Peer Evaluator. Collegial version of the credit probe. |
| C9 | "You haven't presented above regional level. Why should the executive team hear it from you?" | JD | [grounded] "I've never presented to anyone above regional level" (your message) | Hold: say the negative. Then the plan. Hold through two follow-ups. Concede the gap; do not fold on the plan. | F8, pressure version of B7. |

**Requirement coverage**

| JD requirement | Question IDs |
|---|---|
| 4+ years in financial-services customer operations | A1 |
| Experience handling regulated complaints | B1, C4 |
| Own the complaints process end to end across branches and the contact centre | B2, B3, C7 |
| Report monthly on volumes and resolution times | B4 |
| Coach branch supervisors on escalations | B6 |
| Work with digital teams on self-service journeys | B8 |
| Confident presenting to senior leaders | B7, C9 |
| Comfortable with Excel reporting | B4 |
| Member-owned, neighbours (values) | C3 |
| No question: none | — |

## 7. Values cheat sheet

Values and the working meaning are from the text you pasted. Two values have a quoted sentence behind them. The other two get a selection scaffold with an honest branch.

| Value | Working meaning | Mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | Scaffold only: B5, C1. No quote carries this story. |
| Plain Words | If a member needs it explained twice, it was written wrong | C2, with "trained new tellers on our escalation script" (your message). Story is only as wide as that sentence. |
| Neighbours, Not Numbers | Every branch is part of its town | Scaffold only: C3. |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | B1 and C4, with "I handled the branch's formal complaints log" (your message). The quote does not say solved, so the story stops at the log. |

## 8. The 20-minute escalation case (R3)

**Generic scenario, not an Ashgrove case.** A member has complained three times about a fee charged after a card was reissued. Each time, a different person gave a different answer. Today they came to a branch, asked for a supervisor, and said they would go to the regulator if it is not fixed today. You are the supervisor on shift. The panel asks: what happens next?

**Structure (say it aloud in a line before you start):**
1. **Clarify (2 min).** What is the fee, what rule applies, what has been promised, and what is the member asking for today? Name what you do not know.
2. **Member first (4 min).** Decide the immediate action the member can see today. Say what you can decide yourself and what you must escalate, and to whom, and by when.
3. **One owner (5 min).** Who owns this complaint end to end? Name one owner, one log, one handoff with the contact centre.
4. **Plain words (4 min).** One explanation to the member, in writing, in plain language. Say how you would check that it landed.
5. **Own the fix (3 min).** Keep the case open until it is solved. Set a date you will check it.
6. **Prevent (2 min).** Is this a pattern? Who else should know, and how would you coach the teller or agent who gave different answers?

**Honest branch.** If you have not handled an escalation like this, say so, then use the structure. Do not invent a similar case. If you have, say what you actually did.

## 9. Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "How do complaints move today between a branch and the contact centre, and where do they stall?" | Shows you think end to end and invites them to name the seam. |
| 2 | "As branches fold into hubs in 2027, how do you keep complaint handling close to each town?" | Ties to Neighbours, Not Numbers and the hub plan. |
| 3 | "What does the monthly complaints report look like now, and what decision does it drive?" | Shows reporting interest with a purpose, not just a format. |
| 4 | "What would make the first 90 days a success for this role?" | Gives them a standard to answer against. |
| 5 | "How does the team work with digital on self-service journeys today?" | Ties to the 40% target and the JD line on digital teams. |
| 6 | (Panel, peer reciprocity) "What could a new person do in their first month that would genuinely help your branch?" | Turns the panel into a peer conversation. |

No interviewer profile exists, so no reverse question is tied to a career path.

## 10. Prohibited claims

Built locally from the fit snapshot. Nothing in this pack asserts, softens or implies these.

| Not coached | Basis | Honest form |
|---|---|---|
| Worked in or ran a contact centre | Negative you stated (F4) | "I haven't worked in a contact centre." |
| Owned complaints across branches and the contact centre | Inflated form of F3 | "I handled the branch's formal complaints log." Limit, in analysis: your material covers one branch. |
| Presented to senior leaders | Negative you stated (F8) | "I haven't presented to anyone above regional level." |
| Reported resolution times | Inflated form of F5 | "I built the monthly complaints spreadsheet our regional manager uses." Resolution times are an answer slot. |
| Coached branch supervisors | Inflated form of F6 | "trained new tellers on our escalation script." |

## 11. Sources

- **Provided documents:** your background note; the JD; the recruiter's email (rounds, round format, values scoring, strategy summary); the Ashgrove values text you pasted (copied 11 November 2026).
- **Research tier:** L0. No searches or fetches were run in this pass. Everything above comes from the provided material.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | The pasted values text fixes the values cheat sheet (section 7). |
| 2. Ashgrove interview process | skipped | The recruiter's email fixes the three-round structure (loop mode). |
| 3. Ashgrove strategy / recent news | skipped | The recruiter's strategy summary fixes the grounding brief (section 4). The brief itself was not read. |
| 4. Interviewer names | n/a | No names given, so there is no query to form. The interviewer read is absent. |
| 5. Representative JD | skipped | The supplied JD fixes the fit snapshot and the JD questions. |

## Upgrade menu

- Your CV → F-rows quote the CV instead of your message; confidence can move on any row a document shows.
- A description of the complaints spreadsheet, the columns it had, and whether it tracked closure time → B4 and F5 move from answer slots to stated detail.
- Names of the Head of Member Services and the two branch managers → persona weights from their public footprint, an interviewer read, and a tailored reverse question.
- Deep research (L2), offered once: the full strategy brief, interviewer talks, loop reports for this role family, and recent Ashgrove news. Capped at six further searches and two further page fetches. It would ground the CO bank beyond the recruiter's summary.
- A dossier from a prior session would add verified evidence and any prohibited claims. None is present.
