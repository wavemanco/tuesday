Your prep pack is saved as `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-alone-part-2-rooms-case-5-denied-536bbeea/ddbbb321-9c61-444d-b77b-1f6868f355a9/scratchpad/kelverton-rail_senior-partnerships-manager_interview_pack.md`. I built it for a panel with no job description, no interviewer profiles and no research, since the one search was refused.

# Kelverton Rail: Senior Partnerships Manager, second-round panel

Panel on Tuesday, 60 minutes. Deepa (VP Partnerships, your future manager) and Ross (Commercial Director). First 15 minutes: a short spoken point of view on operator partnerships over the next 18 months, landing on what it means for the operators themselves. Remaining time: Q&A, with Ross pushing on commercials.

Requirements come from the recruiter's email, quoted, and from your background as you wrote it.

## 2. How to use this pack

Personas are how a question is asked. Types are what is being scored: **JD** (the role's requirements), **EXP** (what you actually did), **CO** (commercial and market knowledge), **CASE** (a live problem). Guidance is scaffolding, not a script. Say it in your own words.

## 3. Prep triage (about 4 hours)

1. **45 min: write the POV.** Use section 5. Write the three beats in your own words, then say the 15-minute version aloud once.
2. **45 min: the rail gap (D2) and the quota gap (R2).** Say each answer out loud three times: the plain sentence, the bridge, the concession.
3. **30 min: the £4M and 6-to-40 numbers (R1, D3, R4).** Write how each figure was counted, which assumption you'd defend least, and which part was yours. Where the answer is "not mine to set", write that down too.
4. **30 min: the transport consulting bridge (F1).** Write what you did on bus and light rail planning, at the scope you actually had. Don't describe it as operator experience.
5. **30 min: the internal market report.** Pick one consensus item to acknowledge and one place you'd depart from it.
6. **30 min: reverse questions and a timed run.** Run the 15-minute talk twice, then R1 to R3.

Everything else is insurance.

## 4. Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "a short POV on where you'd take our operator partnerships over the next 18 months" (recruiter email) | "bus and light rail network planning" (your message) | medium | [grounded] | transferability | Your material places the planning work in transport consulting, not inside an operator, so the bridge stops there. Answer slot: if any of that work changed how an operator ran or bought something, say what and how you know; if none of it did, say so plainly and stay with the planning work. |
| F2 | "what it means for the operators themselves" (recruiter email) | "took it from 6 partners to 40" (your message) | low | [inferred] | discovery | The material shows partner growth, not what reached an operator, and the bridge shouldn't be stretched to that. Answer slot: if you measured anything that reached an operator, say what and how; if not, say so and say what you would measure first. |
| F3 | "Ross will push on commercials" (recruiter email) | "roughly £4M of influenced revenue" (your message) | medium | [grounded] | presentation | The quote already reaches commercial accountability in other terms. Reword only that: "I was measured on roughly £4M of influenced revenue." Expect a probe on how it was counted. |
| F4 | Direct revenue accountability, role-family pattern (no source supplied) | "never carried a direct quota, only influenced revenue" (your message) | none | [grounded] | capability | A gap you stated. Words: "I've never carried a direct quota." Then how you would become accountable for a number, as a plan, never as a past. |
| F5 | Experience selling into rail, role-family pattern (no source supplied) | "Never sold into rail specifically" (your message) | none | [grounded] | capability | A gap you stated. Words: "I haven't sold into rail specifically." Then the transferable part at its own scope (F1), and how you would learn operator buying, as a plan. |

Note on F1: "so I know the operator world from the other side" is your sentence, but "from the other side" points at the consultant's side of the table. Read the relationship as consulting, not operating.

## 5. Graded deliverable: the 15-minute point of view

Facts you can build on:
- F1: "bus and light rail network planning" (your message), at its own scope.
- F2: "took it from 6 partners to 40" (your message), as partner growth, not operator outcomes.

**Thesis A: measure operator partnerships on what operators can see, not partner count** [generic]
- Concession: operator budgets and procurement cycles are slow, and an outcome may be hard to write into a contract. I haven't checked how Kelverton's operator contracts are structured.
- Differentiation: the common answer is to widen partner reach and co-sell. This is fewer, deeper operator relationships, each with an outcome both sides agree.

**Thesis B: route operator partnerships through the people who already change operator networks** [generic]
- Build on F1 only: you worked on the planning side of bus and light rail networks, so you know who those advisers are. Say it as a view of the channel, not as relationships you hold.
- Concession: this channel may reach operators through advisers' own contracts, which changes who owns the relationship.
- Differentiation: most candidates say "partners". This names a specific partner type.

**Thesis C (the anti-pick): don't copy the ISV playbook** [generic]
- Concession: the ISV model rewarded breadth, and rail has few buyers, so breadth may be the wrong measure. I could be wrong if Kelverton's operator base is wider than I assume.
- The anti-pick: I wouldn't add partners in the first two quarters just to hit a count.

**The close, as requested:** what changes for an operator's team day to day in eighteen months, and how you'd know it's working before revenue shows. [generic]

**Structure, 15 minutes:** where the market is (one consensus item, from the report once pasted); your thesis; the concession; what it means for operators; one ask of the panel.

## 8. Persona table

| Interviewer | Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|---|
| Deepa | Case/Strategist, then Skeptic | A live operator-partnership problem; "why would an operator take the meeting?" | High. As future manager she is buying capability and checking the rail gap | Clarify before structuring. Hold the rail gap in one plain sentence, then the bridge (D1, D2, D4) |
| Ross | Pressure, then Data-Driven Prober | Attribution of the £4M; the missing quota; a commercial model challenged in one line | High. Named for commercials; the influenced-revenue figure invites a probe | Hold, then concede specifically. Name the weakest assumption before he does (R1 to R3) |
| Both | Skeptic on the rail gap | The rail question from either member | High. It's the largest gap in the material | D2 is the highest-return rehearsal in this pack |

## 9. Question banks

**Deepa**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sketch how you'd find the first operator partnerships that matter in the first six months. What do you need to know first?" | CASE | [generic] | Clarify first: which operators, which contract cycles, what success means to Kelverton. Then segmentation, approach, metrics, risks. No claim about your past | CASE tests structure on the role's own problem, raised by "operator partnerships over the next 18 months" |
| D2 | "You've never sold into rail. Why would an operator take a partnership meeting with you?" | JD | [grounded] "Never sold into rail specifically" (your message); "bus and light rail network planning" (your message) | Hold: "I haven't sold into rail specifically." Then the transferable part at its scope: "I worked on bus and light rail network planning in transport consulting." Hold through two follow-ups by returning to what that work gave you. Don't claim operator relationships. Concede specifically: rail selling is new, and the first 90 days would go on finding which operators' problems you could help with | JD because it scores a stated gap. F5 is the evidence, F1 the bridge. Highest-return rehearsal in the pack |
| D3 | "Take me through the ISV channel. What did you set up yourself, and what came from the team?" | EXP | [grounded] "running the ISV channel" (your message); "took it from 6 partners to 40" (your message) | Give the growth and the number in your own words. Answer slot: if you set the recruitment approach or partner terms, say so and how you decided; if others set them, say so plainly and describe the part you ran | EXP tests attribution. F2 carries the growth quote; the slot is the honest form of the probe |
| D4 | "Why would an operator still be a partner in year three, and what would they see?" | CASE | [generic] | Structure: what the operator's team gets day to day, how you'd know it's working before revenue shows, what could end the partnership. No claim about past operator results | CASE. The recruiter asked for "what it means for the operators themselves"; F2 is the honest limit |

**Ross**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R1 | "Your £4M. Walk me through how it was counted." | EXP | [grounded] "roughly £4M of influenced revenue" (your message) | Weakest-assumption move: name, in your words, the assumption behind the figure you'd defend least, before he does. Answer slot: how it was counted, what it's sensitive to, which part was yours. If you didn't set the method, say so and say who did. Don't supply a method | EXP, a defend-the-number slot. F3 is the evidence |
| R2 | "You've never carried a quota. Why should I trust you to own a number here?" | JD | [grounded] "never carried a direct quota, only influenced revenue" (your message) | Hold: the measure you were held to was influenced revenue, and you want to agree a number you can own. Hold through two follow-ups. Concede the specific gap: you haven't carried a quota, and name what you'd need to see to be accountable (the definition, the territory, the first quarter's plan). Don't hold a claim the material doesn't carry | Pressure stem, hold then concede. F4 is the stated negative |
| R3 | "Operators run on fixed budgets and long contracts. How would you price a partnership with one?" | CO | [generic] | Structure: who pays, what value is measured, the term, the risk, what you'd give up. Name a range only if you can defend it. If you set partner terms at the payments company, say what they were; if not, say so and reason from the structure | CO. Uses market structure, not a claim about you |
| R4 | "You took partners from six to forty. Do you want that number here?" | CASE | [grounded] "took it from 6 partners to 40" (your message) | The anti-pick: in the ISV channel the count was a good signal. For operators, keep it as a watch number, not the goal. Concession: I could be wrong if Kelverton's operator market needs breadth | Anti-pick, tied to Thesis C |

## 11. Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "What would you need to see at eighteen months to sign off this role as a success?" | Gets the commercial definition before Ross states it |
| 2 | "Which operators are partners today, and what do they buy from you?" | Shows you'd start from accounts, not a pitch |
| 3 | "How are partner terms set today: margin, referral, or resale?" | A commercial question for Ross that tests the model without a claim from you |
| 4 | "What did the last person in this role get right, and what would you have them do differently?" | For Deepa: shows you want the real problem |
| 5 | "How do you know a partnership is working before revenue shows?" | For Deepa: ties to D4 and to what operators will see |

No interviewer profile exists, so no question is tied to either panel member's career path.

## 13. Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Operator-side experience ("I know the operator world") | Inflated form of "so I know the operator world from the other side", whose "other side" is the consultant's | "bus and light rail network planning" at its scope. Limit, as the pack's observation: your material places you in consulting, not inside an operator |
| Carried a quota, or owned a revenue number | Inflated form of F3; F4's stated negative | "roughly £4M of influenced revenue", and the plain acknowledgment "I've never carried a direct quota." |
| Built the ISV channel | Inflated form of "running the ISV channel" | "took it from 6 partners to 40" at its own scope. D3's slot asks what you set |
| Sold into rail | Negative you stated (F5) | "I haven't sold into rail specifically." |
| £4M of revenue | Dropping "influenced" changes the claim | "roughly £4M of influenced revenue", exactly |

## 14. Sources

- Provided: the recruiter's email, as quoted in your message; your background, as written in your message. The internal market report wasn't supplied as text, so none of its content is used.
- Search sent: "Kelverton Rail scheduling software train operating companies". Result: refused.

Research tier: L1, searches 0 of 6 (one attempted, refused), fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Kelverton values | unavailable | Values cheat sheet. Not produced: the recruiter's note doesn't trigger a values round |
| 2. Kelverton interview process | unavailable | Loop structure. Round and panel come from the recruiter's note |
| 3. Kelverton strategy and recent news | unavailable | Grounding brief. The internal report would supply it once pasted |
| 4. Deepa and Ross public footprint | unavailable | Interviewer read, per-member weights, a reverse question on their paths |
| 5. Representative JD | unavailable | Would turn the role-family rows F4 and F5 into quoted requirements |

## 15. Upgrade menu

- The job description text → a requirement-coverage line and JD-tagged questions; F4 and F5 move from role-family patterns to quoted requirements.
- The headline items from the internal market report → the consensus item for section 5, and a named divergence from it.
- Public profiles of Deepa and Ross → an interviewer read, per-member weights, and a reverse question tied to their career paths. Needs search, which was refused here.
- Deep research (L2), offered once: strategy brief, interviewer talks and writing, loop reports, recent organisation context. Caps: six further searches and two further fetches. Runs only on your consent.
- Your answers to the answer slots (R1, D3, F1), given outside a drill → quoted material, which regenerates the rows that draw on them.

---

Two things I'd like from you, if you have them:

1. **The job description text**, or the recruiter's role spec. If you don't have it, say so and I'll carry on without it.
2. **The headline items from the internal market report**: the shortlist and its main claims. Section 5 needs them to name the consensus answer you're departing from.

Two offers, neither pushed:
- **Drill:** I can play Ross on R2 (the quota challenge) and push you through two follow-ups. Say the word.
- **Dossier:** I can save a `tuesday-dossier.md` with the gaps this prep exposed (the rail gap, the quota gap, the £4M attribution) to carry into later sessions.

If you'd like this as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: kelverton-rail_senior-partnerships-manager_interview_pack.md -----
# Kelverton Rail: Senior Partnerships Manager, second-round panel

Panel on Tuesday, 60 minutes. Deepa (VP Partnerships, your future manager) and Ross (Commercial Director). First 15 minutes: a short spoken point of view on operator partnerships over the next 18 months, landing on what it means for the operators themselves. Remaining time: Q&A, with Ross pushing on commercials.

Built with no job description, no interviewer profiles and no research (one search was refused). Requirements come from the recruiter's email, quoted, and from your background as you wrote it.

## 2. How to use this pack

Personas are how a question is asked. Types are what is being scored: **JD** (the role's requirements), **EXP** (what you actually did), **CO** (commercial and market knowledge), **CASE** (a live problem). Guidance is scaffolding, not a script. Say it in your own words.

## 3. Prep triage (about 4 hours)

1. **45 min: write the POV.** Use section 5. Write the three beats in your own words, then say the 15-minute version aloud once. Everything else depends on this.
2. **45 min: the rail gap (D2) and the quota gap (R2).** Say each answer out loud three times: the plain sentence, the bridge, the concession. The hold must be yours, not a line you memorised.
3. **30 min: the £4M and the 6-to-40 numbers (R1, D3, R4).** Write, in your own words, how each figure was counted, which assumption you'd defend least, and which part was yours. Where the answer is "not mine to set", write that down too.
4. **30 min: the transport consulting bridge (F1).** Write what you did on bus and light rail planning, at the scope you actually had. Do not describe it as operator experience.
5. **30 min: the internal market report.** Pick the one consensus item to acknowledge and the one place you'd depart from it (once you've pasted it, see the questions below).
6. **30 min: reverse questions and a timed run.** Run the 15-minute talk twice, then the commercial questions R1 to R3.

Everything else is insurance.

## 4. Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "a short POV on where you'd take our operator partnerships over the next 18 months" (recruiter email) | "bus and light rail network planning" (your message) | medium | [grounded] | transferability | Your material places the network planning in transport consulting, not inside an operator, so the bridge stops there. Say the planning work at that scope. Answer slot: if any of that work changed how an operator ran or bought something, say what and how you know; if none of it did, say so plainly and stay with the planning work. |
| F2 | "what it means for the operators themselves" (recruiter email) | "took it from 6 partners to 40" (your message) | low | [inferred] | discovery | The material shows partner growth, not what reached an operator, and the bridge should not be stretched to that. Answer slot: if you measured anything that reached an operator, say what and how; if you did not, say so and say what you would measure first. |
| F3 | "Ross will push on commercials" (recruiter email) | "roughly £4M of influenced revenue" (your message) | medium | [grounded] | presentation | The quote already reaches commercial accountability in other terms: you were measured on influenced revenue. Reword only that: "I was measured on roughly £4M of influenced revenue." Expect a probe on how it was counted. |
| F4 | Direct revenue accountability, role-family pattern for this role (no source supplied) | "never carried a direct quota, only influenced revenue" (your message) | none | [grounded] | capability | A gap you stated. Words: "I've never carried a direct quota." Then how you would become accountable for a number, said as a plan and never as a past. |
| F5 | Experience selling into rail, role-family pattern for a rail-tech vendor (no source supplied) | "Never sold into rail specifically" (your message) | none | [grounded] | capability | A gap you stated. Words: "I haven't sold into rail specifically." Then the transferable part at its own scope (F1), and how you would learn operator buying as a plan. |

Note on F1: the sentence "so I know the operator world from the other side" is yours, but "from the other side" points at the consultant's side of the table. Read the relationship as consulting, not operating.

## 5. Graded deliverable: the 15-minute point of view

The recruiter asked for a spoken POV with no slides, ending on what it means for operators. You have not seen Kelverton's internal report as text here, so the consensus answer below is generic. Once you paste the shortlist, the differentiation step can name it.

**Facts you can build on**
- F1: "bus and light rail network planning" (your message), at its own scope.
- F2: "took it from 6 partners to 40" (your message), as partner growth, not operator outcomes.

**Thesis A: measure operator partnerships on what operators can see, not on partner count** [generic]
- Concession: operator budgets and procurement cycles are slow, and an outcome may not be easy to write into a contract. I have not checked how Kelverton's operator contracts are structured.
- Differentiation: the common answer is to widen partner reach and co-sell. This thesis is fewer, deeper operator relationships, each with an outcome both sides agree.

**Thesis B: route operator partnerships through the people who already change operator networks** [generic]
- Build on F1 only: you worked on the planning side of bus and light rail networks, so you know who those advisers are. Say it as a view of the channel, not as relationships you hold.
- Concession: this channel may reach operators through advisers' own contracts, which changes who owns the relationship.
- Differentiation: most candidates say "partners". This names a specific partner type.

**Thesis C (the anti-pick): do not copy the ISV playbook** [generic]
- Concession: the ISV model rewarded breadth, and rail has few buyers, so breadth may be the wrong measure. I could be wrong if Kelverton's operator base is wider than I assume.
- The anti-pick: I would not add partners in the first two quarters just to hit a count.

**The close, as requested:** what changes for an operator's team day to day in eighteen months, and how you would know it is working before revenue shows. [generic]

**Structure, 15 minutes:** where the market is (one consensus item, from the report once pasted); your thesis; the concession; what it means for operators; one ask of the panel.

## 8. Persona table

| Interviewer | Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|---|
| Deepa | Case/Strategist, then Skeptic | A live operator-partnership problem; "why would an operator take the meeting?" | High. As the future manager she is buying capability and checking the gap in rail | Clarify before structuring. Hold the rail gap in one plain sentence, then the bridge (D1, D2, D4) |
| Ross | Pressure, then Data-Driven Prober | Attribution of the £4M; the missing quota; a commercial model challenged in one line | High. He was named for commercials, and the influenced-revenue figure invites a probe | Hold, then concede specifically. Name the weakest assumption before he does (R1 to R3) |
| Both | Skeptic on the rail gap | The rail question from either panel member | High. It is the largest gap in the material | D2 is the highest-return rehearsal in this pack |

## 9. Question banks

**Deepa (top weight, four questions)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sketch how you'd find the first operator partnerships that matter in the first six months. What do you need to know first?" | CASE | [generic] | Clarify first: which operators, which contract cycles, and what success means to Kelverton. Then segmentation, approach, metrics, risks. The guidance makes no claim about your past | CASE tests structure on the role's own problem. Raised by the recruiter's "operator partnerships over the next 18 months" |
| D2 | "You've never sold into rail. Why would an operator take a partnership meeting with you?" | JD | [grounded] "Never sold into rail specifically" (your message); "bus and light rail network planning" (your message) | Hold: "I haven't sold into rail specifically." Then the transferable part at its scope: "I worked on bus and light rail network planning in transport consulting." Hold through two follow-ups by returning to what that work gave you. Do not claim operator relationships. Concede specifically: rail selling is new, and the first 90 days would go on finding which operators' problems you could help with | JD because it scores a stated gap. F5 is the evidence, F1 the bridge. This is the highest-return rehearsal in the pack |
| D3 | "Take me through the ISV channel. What did you set up yourself, and what came from the team?" | EXP | [grounded] "running the ISV channel" (your message); "took it from 6 partners to 40" (your message) | Give the growth and the number in your own words. Answer slot: if you set the recruitment approach or the partner terms, say so and how you decided; if others set them, say so plainly and describe the part you ran | EXP because it tests attribution. F2 carries the growth quote; the slot is the honest form of the probe |
| D4 | "Why would an operator still be a partner in year three, and what would they see?" | CASE | [generic] | Structure: what the operator's team gets day to day, how you would know it is working before revenue shows, and what could end the partnership. Make no claim about past operator results | CASE. The recruiter asked for "what it means for the operators themselves", and F2 is the honest limit: partner growth, not operator outcomes |

**Ross (top weight, four questions)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R1 | "Your £4M. Walk me through how it was counted." | EXP | [grounded] "roughly £4M of influenced revenue" (your message) | Weakest-assumption move: name, in your words, the assumption behind the figure you would defend least, before he does. Answer slot: how it was counted, what it is sensitive to, and which part was yours. If you did not set the method, say so and say who did. Do not supply a method | EXP and a defend-the-number slot. F3 is the evidence |
| R2 | "You've never carried a quota. Why should I trust you to own a number here?" | JD | [grounded] "never carried a direct quota, only influenced revenue" (your message) | Hold: the measure you were held to was influenced revenue, and you want to agree a number you can own. Hold through two follow-ups. Concede the specific gap: you haven't carried a quota, and name what you would need to see to be accountable (the definition, the territory, the first quarter's plan). Do not hold a claim the material does not carry | Pressure stem, hold then concede. F4 is the stated negative: "I've never carried a direct quota." |
| R3 | "Operators run on fixed budgets and long contracts. How would you price a partnership with one?" | CO | [generic] | Structure: who pays, what value is measured, the term, the risk, and what you would give up. Name a range only if you can defend it. If you set partner terms at the payments company, say what they were; if not, say so and reason from the structure | CO. The guidance uses market structure, not a claim about you. Commercials are Ross's bank |
| R4 | "You took partners from six to forty. Do you want that number here?" | CASE | [grounded] "took it from 6 partners to 40" (your message) | The anti-pick: in the ISV channel the count was a good signal. For operators, keep it as a watch number, not the goal. Concession: I could be wrong if Kelverton's operator market needs breadth | Anti-pick, tied to Thesis C in section 5 |

## 11. Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "What would you need to see at eighteen months to sign off this role as a success?" | Gets the commercial definition before Ross states it, and shows you want a measure |
| 2 | "Which operators are partners today, and what do they buy from you?" | Shows you would start from accounts, not from a pitch |
| 3 | "How are partner terms set today: margin, referral, or resale?" | A commercial question for Ross that tests the model without a claim from you |
| 4 | "What did the last person in this role get right, and what would you have them do differently?" | For Deepa: shows you want the real problem and will take a view on it |
| 5 | "How do you know a partnership is working before revenue shows?" | For Deepa: ties to D4 and to what operators will see |

No interviewer profile exists, so no question is tied to either panel member's career path. That is in the upgrade menu.

## 13. Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Operator-side experience ("I know the operator world") | Inflated form of "so I know the operator world from the other side", whose "other side" is the consultant's | "bus and light rail network planning" at its scope. Limit, as the pack's observation: your material places you in consulting, not inside an operator |
| Carried a quota, or owned a revenue number | Inflated form of F3 and F4's stated negative | "roughly £4M of influenced revenue", and the plain acknowledgment "I've never carried a direct quota." |
| Built the ISV channel | Inflated form of "running the ISV channel" (incident or practice) | "took it from 6 partners to 40" at its own scope. D3's slot asks what you set |
| Sold into rail | Negative you stated (F5) | "I haven't sold into rail specifically." |
| £4M of revenue | Dropping "influenced" changes the claim | "roughly £4M of influenced revenue", exactly |

## 14. Sources

- Provided: the recruiter's email, as quoted in your message; your background, as written in your message. The internal market report was not supplied as text; you have read it and none of its content is used here.
- Search sent: "Kelverton Rail scheduling software train operating companies". Result: refused.

Research tier: L1, searches 0 of 6 (one attempted, refused), fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Kelverton values | unavailable | Values cheat sheet (section 10). Not produced: the recruiter's note does not trigger a values round |
| 2. Kelverton interview process | unavailable | Loop structure. The round and panel come from the recruiter's note, so the persona weights rest on that |
| 3. Kelverton strategy and recent news | unavailable | Grounding brief. The internal report would supply the current picture once pasted |
| 4. Deepa and Ross public footprint | unavailable | Interviewer read, per-member persona weights, and a reverse question on their paths |
| 5. Representative JD | unavailable | Would turn the role-family rows in F4 and F5 into inferred requirements |

## 15. Upgrade menu

- The job description text → a requirement-coverage line and JD-tagged questions; F4 and F5 move from role-family patterns to quoted requirements.
- The headline items from the internal market report → the consensus item for section 5, and a named divergence from it.
- Public profiles of Deepa and Ross → an interviewer read, per-member weights, and a reverse question tied to their career paths. Needs search, which was refused here.
- Deep research (L2), offered once: a strategy brief, interviewer talks and writing, loop reports, recent organisation context. Caps: six further searches and two further fetches. Runs only on your consent.
- Your answers to the answer slots (R1, D3, F1), given outside a drill → quoted material, which regenerates the rows that draw on them.
