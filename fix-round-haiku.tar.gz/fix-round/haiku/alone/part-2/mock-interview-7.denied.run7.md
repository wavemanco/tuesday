Your prep pack is saved as `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-alone-part-2-rooms-case-7-denied-79a072fe/572bcaf2-2ff4-4324-b908-470773f866d7/scratchpad/saltmarsh_live-operations-producer_interview_pack.md`. I built it for a hiring-manager round, since your note didn't say who Tobias is to you. Web search was refused in this session, so the pack has no company research, no values, and no read on Tobias.

# Live Operations Producer, Saltmarsh Games: interview prep pack

Role: Live Operations Producer. Company: Saltmarsh Games (mobile, about 350 people). Interviewer: Tobias Wrenfield, Head of Live Operations. Relationship: assumed hiring manager, not confirmed. Length: 60 minutes, Friday.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored.

- **EXP**: what you actually did in past work
- **JD**: whether you can do the listed job, gaps included
- **CASE**: a live problem from the role, reasoned aloud

Guidance is scaffolding, not a script. "Answer slot" means: say the honest branch that matches your experience.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | medium | [grounded] | transferability | Bridge at that scope: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: the JD asks about live events across two titles, so expect a probe on drops versus events, and on a second title. If you planned events beyond the drop schedule, or ran more than one title, say which. If not, say so and describe the drop calendar. |
| F2 | "manage the release checklist with QA" (JD) | "Wrote the release checklist our QA team still uses." (your message) | medium | [grounded] | none | Lead with it: "I wrote the release checklist our QA team still uses." Expect a probe on whether you still maintain it. Do not describe ownership of QA's process. |
| F3 | "own the post-event review and the KPIs it reports" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | medium | [grounded] | transferability | Bridge: "I presented the monthly retention numbers to the studio head." Answer slot: if you wrote a review after a drop, or chose what the numbers measured, say what it measured and what changed. If not, say so and say how you would run one. |
| F4 | "3+ years producing live-service games or apps" (JD) | "4 years as an associate producer at a puzzle-game studio" (your message) | medium | [grounded] | presentation | Keep the title as written: "associate producer." Your material doesn't say the puzzle title was live-service. Describe the drop calendar rather than applying a label. Answer slot: if the title updated on a schedule after launch, say how. If not, say so. |
| F5 | "experience running a content calendar" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | medium | [grounded] | none | Lead with the quote as written. A redacted calendar would move this to high. |
| F6 | "comfortable with player-retention metrics" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | medium | [grounded] | presentation | Bridge, reworded from the quote only: "I presented the monthly retention numbers to the studio head." Answer slot: expect a probe on how they were built. If you calculated them, say how they were counted. If someone else did, say so. |
| F7 | "coordinate design, art, engineering and community teams on each update" (JD) | "Never led a team." (your message) | none | [grounded] | discovery | Your sentence is about leading, not coordinating, so it doesn't reach this requirement. Answer slot: if you coordinated any of those four teams on a drop, say which and how. If not, say so plainly and say how you'd set that up. |
| F8 | No JD line names in-app purchases. Role-family pattern: [generic] | "Never worked on a game with in-app purchases." (your message) | none | [grounded] | capability | "I haven't worked on a game with in-app purchases." Then a learning plan, given as a plan and never as a past. |

Pack observation, in analysis and not as words for you: your material shows a drop calendar for one title, a checklist, and retention presentations. It does not show a post-event review, KPI ownership, planning across two titles, or coordinating the four teams.

## Prohibited list

| Not coached | Basis | Honest form |
|---|---|---|
| "Led a team" | Negative you stated | "I haven't led a team." |
| "Producer" as a title | Inflated form of "associate producer" | Keep "associate producer." |
| Worked on a monetised title | Negative you stated | "I haven't worked on a game with in-app purchases." |
| Owned the calendar, or the post-event review and KPIs | Inflated form of F1 and F3 | The quotes at their own scope. |
| Defined the retention metrics | Inflated form of F6 | "I presented the monthly retention numbers to the studio head." |
| Owns QA sign-off or the release process | Inflated form of F2 | "I wrote the release checklist our QA team still uses." |

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Probes leadership, coordination, monetisation | High. Hiring managers derisk gaps, and yours are visible in your own message. Depth 5. | Rehearse the leadership objection until it's calm. |
| Case / Strategist | Live problems on two titles, a release, a drop due Thursday | High. The JD is written as live problems. Depth 4. | Clarify before structuring. |
| Data-Driven Prober | How the retention numbers were counted | Medium. Retention metrics and the KPI line invite it. Depth 3. | Name the weakest assumption first. |
| Pressure / Stress | Time-boxed challenges on your gaps | Medium. No skip-level signal, so lower weight. Depth 3. | Pause, restate, hold two follow-ups, concede one specific thing. |
| Conversational | Casual openers | Medium. Still scored. Depth 3. | Use a 90-second arc. |
| Peer, Values | Excluded | Round reads as a manager round; no values in hand. | None. |

## Question banks

### Skeptic (top weight, 5 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Four teams touch every update here, and you've never led one. How do you get design, art, engineering and community moving together on a drop?" | JD | [grounded] "Never led a team." (your message); "coordinate design, art, engineering and community teams on each update" (JD) | **Highest-ROI prep in this pack.** Hold: "I haven't led a team." Describe what you did with the calendar and checklist, in those words. Answer slot: if you coordinated any of the four teams on a drop, say which and how. If not, say so and say how you'd set it up in week one. Hold through two follow-ups. Concede one specific team where your experience is thinnest. | F7 is where this lands, and the leadership negative makes it near-certain. |
| A2 | "Walk me through the last drop you planned, from calendar slot to live." | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | Story map: the weekly cadence, the main title, the two years. Answer slot: if any step between slot and live was yours to set, say which. If not, say so and describe what you did do. Don't supply the stages. | F1 is the likeliest place to be probed. |
| A3 | "After a live event, what would you measure, and how would you know it worked?" | JD | [generic] | Name the goal, pick three measures including one retention measure, say what you'd compare against and what you wouldn't claim from one event. Answer slot: if you've measured anything after a drop, say what and how it was counted. If not, say so. | The JD gives you the review; this asks for method before past. |
| A4 | "You presented retention to the studio head. What did you own in retention, as against presenting it?" | JD | [grounded] "Presented the monthly retention numbers to the studio head." (your message) | Hold the sentence as written. Answer slot: if you set the metrics or wrote the analysis, say which. If you presented others' numbers, say that. | Presenting versus owning is the likely probe. |
| A5 | "You've never worked on a game with in-app purchases. How would you plan a monetised event you haven't run before?" | CASE | [grounded] "never worked on a game with in-app purchases" (your message) | "I haven't worked on a game with in-app purchases." Then a plan, as a plan: what you'd learn from the monetisation team, which numbers you'd watch, what you'd add to the checklist. | F8 is your own disclosure; the JD doesn't name monetisation. |

### Case / Strategist (4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Plan the next six weeks of live events for a title whose retention is falling." | CASE | [generic] | Clarify which cohort is falling and what the calendar holds. Then objective, segmentation, approach, metrics, risks. | Tests planning, not history. |
| C2 | "Two titles, one live calendar. How do you decide which gets the next update slot?" | CASE | [generic] | State the decision rule before the example. | The two-title line is the one requirement no other question tests. |
| C3 | "A release build misses a checklist step and ships broken. What changes in the process?" | CASE | [generic] | Name the step's owner, what the checklist would have caught, what changes, who signs it. | Tests the checklist as a tool. |
| C4 | "The drop is due Thursday and design says the art isn't ready. What's your call?" | CASE | [generic] | Clarify "not ready," then ship smaller, slip a week, or cut a piece. Name who decides. | Coordination as a decision. |

### Data-Driven Prober (3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The retention numbers you presented: how were they counted, and which assumption would you defend least?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." (your message) | Name the weakest assumption in your words. Answer slot: how it was counted, what it's sensitive to, the assumption you'd defend least, and which part was yours. If you didn't calculate them, say so and what you'd check first. | Attribution, with a short honest form. |
| B2 | "When would a monthly retention number mislead you?" | JD | [generic] | Two or three failure modes as general patterns: cohort mix, a launch in the same window, a tracking change. | Judgment about the metric. |
| B3 | "Show me what a good release checklist does that a weak one doesn't." | JD | [grounded] "Wrote the release checklist our QA team still uses." (your message) | Describe its structure in your words. Answer slot: if you added steps after a miss, say which. If not, say so. | The written artifact behind "clear written communication." |

### Pressure / Stress (3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why hire someone who has never led a team for a role that coordinates four?" | JD | [grounded] "Never led a team." (your message); "coordinate design, art, engineering and community teams on each update" (JD) | Pause, restate, then hold: the calendar and the checklist, each in your words. Concede once: "I haven't led a team." No invented coordination story. | F7 under time pressure. |
| D2 | "That retention result you presented: how much of it was actually you?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." (your message) | "I presented them. The part I can say was mine is..." Name your share; if it's presenting only, say that and stop. | Attribution pressure on F6. |
| D3 | "You've never worked on a monetised title. Why should we believe you'd run one?" | CASE | [grounded] "never worked on a game with in-app purchases" (your message) | Hold, concede the real risk in one line, then the A5 plan. Don't promise results. | Pressure version of A5. |

### Conversational / Rapport (3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the last four years." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio"; "I ran the weekly content-drop calendar for our main title for the last two years"; "Wrote the release checklist our QA team still uses."; "Presented the monthly retention numbers to the studio head." (all your message) | 90-second arc: studio and title, calendar, checklist, retention, then why this role. Add no beat. | Casual openers are scored. |
| E2 | "What's a live game you follow, and what does its update rhythm tell you?" | JD | [generic] | Pick a title you've played and say what its calendar tells you. | A casual JD topic. |
| E3 | "Why Saltmarsh, and why this role over another producer role?" | JD | [generic] | What the role asks that you've done, and what you want to learn. | Motivation check. |

**Requirement coverage:** two-title calendar → A2, C2 · coordinate four teams → A1, C4, D1 · post-event review and KPIs → A3, A4, B1 · release checklist with QA → B3, C3 · 3+ years live-service → E1 (F4) · content calendar → A2, E1 · retention metrics → B1, B2, A4 · written communication → B3 · in-app purchases (not a JD line) → A5, D3.

## Reverse questions

1. "What does a good post-event review look like here, and who reads it?" *Why it lands:* treats the review line as the job.
2. "Which two titles will this role cover, and how far apart are their calendars?" *Why it lands:* tests how much of your drop experience transfers.
3. "How does the release checklist work with QA today, and where does it break most often?" *Why it lands:* shows you want to see the step you've built.
4. "On an update, who makes the final call when design, art, engineering and community disagree?" *Why it lands:* the question behind your coordination gap.
5. "Which retention and KPI reports will this role own in the first three months, and which are already set?" *Why it lands:* separates owned from inherited.

## Sources

- **Provided:** your message (JD, background, interview details).
- **Searches attempted, both refused** (web search permission not granted): "Saltmarsh Games mobile studio live operations"; "Tobias Wrenfield Head of Live Operations Saltmarsh Games."
- **Research tier:** L1 requested, run as L0 in effect: searches 0 of 6 (2 refused), fetches 0 of 2.

| Target | Status | What it moved, or would have |
|---|---|---|
| Company values | unavailable | Values cheat sheet dropped. |
| Interview process | unavailable | Loop structure stayed on hiring-manager priors. |
| Strategy / recent news | unavailable | Query refused. Would have moved a grounding brief and CO questions. |
| Tobias's public footprint | unavailable | Query refused. Would have moved the interviewer read and a reverse question. |
| Representative JD | skipped | Your JD fixes the snapshot. |

**Not included:** prep triage (no prep time stated), values cheat sheet, grounding brief, interviewer read, graded deliverables, delivery coaching (no assessment).

## Upgrade menu

- Web search permission → company values, loop structure, strategy, and Tobias's public footprint: values, persona weights, a grounding brief, a tailored reverse question.
- Whether Tobias would manage you, or sit beside you → reweights every bank.
- Any focus areas or deliverable from the recruiter → coverage of any graded deliverable.
- A redacted copy of one content-drop calendar → F1 and F5 from medium to high.
- A redacted copy of the release checklist → F2 and B3 get an artifact.
- Any retention figure you calculated, with how it was counted → resolves F6 and B1.
- Whether the puzzle title updated on a schedule after launch → resolves F4.

---

Two offers, neither pushed:
- I can play the Skeptic on A1, the highest-ROI question in the pack, as a live drill. Say the word and I'll run it.
- I can save a `tuesday-dossier.md` recording the gaps this prep exposed (leadership, coordination, monetisation) for later sessions.

If you'd like this as a Word document, say so and I'll convert it.

Is Tobias the person who would manage you, or someone you'd work beside, and did the recruiter name any focus areas or a deliverable?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh_live-operations-producer_interview_pack.md -----
# Live Operations Producer, Saltmarsh Games: interview prep pack

Role: Live Operations Producer. Company: Saltmarsh Games (mobile, about 350 people). Interviewer: Tobias Wrenfield, Head of Live Operations. Relationship: assumed hiring manager, not confirmed. Length: 60 minutes, Friday.

Built on: a hiring-manager round, your JD and background as you pasted them. No web research ran (see Sources).

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored.

- **EXP**: what you actually did in past work
- **JD**: whether you can do the listed job, gaps included
- **CASE**: a live problem from the role, reasoned aloud
- **VAL**: values alignment (none in this pack, see Persona table)
- **CO**: company knowledge (none in this pack, no research ran)

Guidance is scaffolding, not a script. "Answer slot" means: say the honest branch that matches your experience. It is an instruction for the interview, not a question for me.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | medium | [grounded] | transferability | Your material says a weekly content-drop calendar for one title, for the last two years. Bridge at that scope: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: the JD asks about live events across two titles, so expect a probe on the difference between drops and events, and on a second title. If you planned events beyond the drop schedule, or ran more than one title, say which. If not, say so and describe the drop calendar. |
| F2 | "manage the release checklist with QA" (JD) | "Wrote the release checklist our QA team still uses." (your message) | medium | [grounded] | none | The quote already reaches the requirement in role terms: a checklist QA still uses. Lead with it in your words: "I wrote the release checklist our QA team still uses." Expect a probe on whether you still maintain it. Do not describe ownership of QA's process. |
| F3 | "own the post-event review and the KPIs it reports" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | medium | [grounded] | transferability | Your material shows presenting retention numbers, not a post-event review and not choosing the KPIs. Bridge at that scope: "I presented the monthly retention numbers to the studio head." Answer slot: if you wrote a review after a drop, or chose what the numbers measured, say what it measured and what changed. If you did not, say so and say how you would run one. |
| F4 | "3+ years producing live-service games or apps" (JD) | "4 years as an associate producer at a puzzle-game studio" (your message) | medium | [grounded] | presentation | The years and the title are quoted. Keep the title as written: "associate producer." Your material does not say the puzzle title was live-service. The drop calendar suggests it, so describe the calendar rather than applying a label. Bridge: "I was an associate producer at a puzzle-game studio for four years." Answer slot: expect a probe on whether that title updated after launch on a schedule. If it did, say how. If not, say so. |
| F5 | "experience running a content calendar" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | medium | [grounded] | none | The quote reaches the requirement directly. Lead with it: "I ran the weekly content-drop calendar for our main title for the last two years." A redacted copy of one calendar would move this to high (upgrade menu). |
| F6 | "comfortable with player-retention metrics" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | medium | [grounded] | presentation | The quote reaches retention in role terms: you presented the numbers. Bridge, reworded from the quote only: "I presented the monthly retention numbers to the studio head." Answer slot: the JD raises retention metrics, so expect a probe on how they were built. If you calculated them, say how they were counted. If someone else did, say so. |
| F7 | "coordinate design, art, engineering and community teams on each update" (JD) | "Never led a team." (your message) | none | [grounded] | discovery | Your sentence is about leading, not coordinating, so it does not reach this requirement. Answer slot: if you coordinated any of design, art, engineering or community on a drop, say which and how, in your own words. If you did not, say so plainly and say how you would set that coordination up. |
| F8 | No JD line names in-app purchases. Role-family pattern: live events on a monetised title usually touch purchase mechanics. [generic] | "Never worked on a game with in-app purchases." (your message) | none | [grounded] | capability | A gap you stated, so the pack may give back your words: "I haven't worked on a game with in-app purchases." Then a learning plan, given as a plan and never as a past (see A5). |

Pack observation, in analysis and not as words for you: your material shows a drop calendar for one title, a checklist, and retention presentations. It does not show a post-event review, KPI ownership, live-events planning across two titles, or coordination of the four teams.

## Prohibited list

Claims this pack will not coach, and why.

| Not coached | Basis | Honest form |
|---|---|---|
| "Led a team" | Negative you stated: "Never led a team." | "I haven't led a team." Plain acknowledgment; no slot needed. |
| "Producer" as a title | Inflated form of "4 years as an associate producer at a puzzle-game studio" | Keep the title as written: "associate producer." |
| Worked on a monetised title | Negative you stated: "never worked on a game with in-app purchases" | "I haven't worked on a game with in-app purchases." |
| Owned the live-events calendar, or owned the post-event review and KPIs | Inflated form of F1 and F3 | F1 and F3 quotes at their own scope. The limit is the pack's observation: your material shows a drop calendar for one title, and presenting retention numbers, not a review or the KPI set. |
| Defined the retention metrics | Inflated form of F6 | "I presented the monthly retention numbers to the studio head." |
| Owns QA sign-off or the release process | Inflated form of F2 | "I wrote the release checklist our QA team still uses." |

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Probes the gaps: leadership, coordination, monetisation | High. A hiring manager buys capability and derisks gaps, and your gaps are visible in your own message. Depth: 5 questions. | Rehearse the leadership and coordination objection until it is calm. Use the plain acknowledgment, then the slot. |
| Case / Strategist | Live problems from the two titles, the release, and a drop due Thursday | High. Hiring-manager prior, and the JD is written as live problems. Depth: 4 questions. | Clarify before structuring. Name the decision rule first. |
| Data-Driven Prober | Asks how the retention numbers were counted, and which assumption you would defend least | Medium. Retention metrics and the KPI line invite it. Depth: 3 questions. | Name the weakest assumption in your own words before they do. Say plainly what you did not calculate. |
| Pressure / Stress | Time-boxed challenges on the leadership gap and the monetisation gap | Medium. No skip-level signal, so the weight is lower. Depth: 3 questions. | Pause, restate, hold through two follow-ups, then concede one specific thing. |
| Conversational / Rapport | Casual openers: your four years, what you play | Medium. Casual questions are still scored. Depth: 3 questions. | Use a 90-second arc. Treat "any questions" as a scored slot. |
| Peer Evaluator | Seams with other teams | Excluded. The round is with the head of live operations, which reads as a manager round unless you tell me otherwise. | None in this pack. |
| Values / Behavioral | Published-value probes | Excluded. No company values in hand, and no values-style round detected. | None in this pack. |

## Question banks

Coverage: 18 questions. Weighted by persona, top first.

### Skeptic (weight: top, 5 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Four teams touch every update here, and you've never led one. How do you get design, art, engineering and community moving together on a drop?" | JD | [grounded] "Never led a team." (your message); "coordinate design, art, engineering and community teams on each update" (JD) | Highest-ROI prep in this pack. Hold the first clause: "I haven't led a team." Then describe what you did with the calendar and checklist, in those words. Answer slot: nothing in your material shows coordinating the four teams. If you coordinated any of them on a drop, say which and how. If you did not, say so plainly and say how you would set it up in week one. Hold through two follow-ups by returning to the calendar. Concede one specific team where your experience is thinnest. | F7 is the row this probe lands on, and the leadership negative makes it near-certain. Three follow-up levels is the rehearsal depth it earns. |
| A2 | "Walk me through the last drop you planned, from calendar slot to live." | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | Story map from the quote: the weekly cadence, the main title, the two years, in your own words. Answer slot: if any step between slot and live was yours to set, say which and how you decided. If none was, say so and describe what you did do. The quote does not carry the stages between slot and live, so do not supply them. | F1 is the evidence for the calendar requirement and the likeliest place to be probed. EXP because it tests what was yours. |
| A3 | "After a live event, what would you measure, and how would you know it worked?" | JD | [generic] | Open prompt on a live problem. Structure: name the event's goal first, then pick three measures, one of them a retention measure. Say what you would compare against, and what you would not claim from one event. Answer slot: if you have measured anything after a drop, say what and how it was counted. If not, say so and stay with the plan. | The JD gives you the post-event review. This asks for the method before the past, and makes no claim about your history. |
| A4 | "You presented retention to the studio head. What did you own in retention, as against presenting it?" | JD | [grounded] "Presented the monthly retention numbers to the studio head." (your message) | Hold the sentence as written: "I presented the monthly retention numbers to the studio head." Answer slot: if you set which metrics were reported, or wrote the analysis behind them, say which and how. If you presented numbers others produced, say that. Concede the boundary specifically rather than widening it. | F3 and F6 sit under the JD's KPI ownership line, and presenting versus owning is the likely probe. |
| A5 | "You've never worked on a game with in-app purchases. How would you plan a monetised event you haven't run before?" | CASE | [grounded] "never worked on a game with in-app purchases" (your message) | Plain acknowledgment: "I haven't worked on a game with in-app purchases." Then a plan, given as a plan and never as a past: what you would learn from the monetisation team first, which numbers you would watch before and after, and what you would add to the checklist. | F8 is a gap you stated. The JD does not name monetisation, so the question draws on your own disclosure, not a requirement. |

### Case / Strategist (weight: high, 4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Plan the next six weeks of live events for a title whose retention is falling." | CASE | [generic] | Clarify first: which cohort is falling, and what the calendar already holds. Then objective, segmentation, approach, metrics, risks. Speak the plan aloud as a plan. | The JD asks you to plan and run the calendar. This tests the planning step, not your history. |
| C2 | "Two titles, one live calendar. How do you decide which one gets the next update slot?" | CASE | [generic] | State the decision rule before the example: the criteria, what each title's data says, and what you would tell the other title's team. | The JD's two-title line is the only requirement no question yet tests. |
| C3 | "A release build misses a checklist step and ships broken. What changes in the process?" | CASE | [generic] | Name the step's owner first, then what the checklist would have caught, then what changes and who signs it. Tell it as a process, not as something that happened to you. | The JD asks you to manage the release checklist with QA. This tests the checklist as a tool. |
| C4 | "The drop is due Thursday and design says the art isn't ready. What's your call?" | CASE | [generic] | Clarify what "not ready" means and what the drop's data depends on. Options: ship a smaller drop, slip a week, or cut a piece. Name who decides. | A live coordination problem from the JD's four-team line, asked as a decision, not a record. |

### Data-Driven Prober (weight: medium, 3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The retention numbers you presented: how were they counted, and which assumption would you defend least?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." (your message) | Name the weakest assumption in your own words. Answer slot: the four defend-the-number questions are how the figure was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. If you did not calculate the figures, say so plainly and say what you would check first. | F6 is a retention claim with no method in the material. The probe asks for attribution, and the honest form is short. |
| B2 | "When would a monthly retention number mislead you?" | JD | [generic] | Name two or three failure modes as patterns: cohort mix, a launch in the same window, a tracking change. Present them as general cases, not as things that happened to you. | The JD asks for comfort with retention metrics. This tests judgment about the metric, not your record. |
| B3 | "Show me what a good release checklist does that a weak one doesn't." | JD | [grounded] "Wrote the release checklist our QA team still uses." (your message) | Describe the checklist's structure in the words you used for it. Answer slot: if you added steps after a miss, say which and why. If you did not, say so. | F2 is the written artifact behind "clear written communication," and the JD's checklist line. |

### Pressure / Stress (weight: medium, 3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why hire someone who has never led a team for a role that coordinates four?" | JD | [grounded] "Never led a team." (your message); "coordinate design, art, engineering and community teams on each update" (JD) | Pause, restate the question, then hold. Name the two things your material shows, the calendar you ran and the checklist QA uses, each in your words. Concede once, specifically: "I haven't led a team." Do not add a coordination story the material does not carry. Hold through two follow-ups. | F7 under time pressure. |
| D2 | "That retention result you presented: how much of it was actually you?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." (your message) | Hold-then-concede: "I presented them. The part I can say was mine is..." Answer slot: name your share in your words. If the share is presenting only, say that and stop. Do not argue for more. | Attribution pressure on F6. |
| D3 | "You've never worked on a monetised title. Why should we believe you'd run one?" | CASE | [grounded] "never worked on a game with in-app purchases" (your message) | Hold: "I haven't worked on a game with in-app purchases." Concede the real risk in one line, then give the learning plan from A5, as a plan. Do not promise results. | The pressure version of A5. |

### Conversational / Rapport (weight: low, 3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the last four years." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio" (your message); "I ran the weekly content-drop calendar for our main title for the last two years" (your message); "Wrote the release checklist our QA team still uses." (your message); "Presented the monthly retention numbers to the studio head." (your message) | A 90-second arc: the studio and title, the calendar, the checklist, the retention presentation, then why this role. Each beat is one of your quotes. Add no beat. | Casual openers are scored. The arc covers F4, F5, F2 and F6 in order. |
| E2 | "What's a live game you follow, and what does its update rhythm tell you?" | JD | [generic] | Pick one title you have played. Say what its calendar tells you about how the team works. | A casual question on a JD topic, scored as the JD asks. |
| E3 | "Why Saltmarsh, and why this role over another producer role?" | JD | [generic] | Name what the role asks that you have done (the calendar, the checklist) and what you want to learn (monetised titles). Keep motives to what you have said. | A motivation check. It is not a values question, since no values are in hand. |

Requirement coverage:

| Requirement | Questions |
|---|---|
| Plan and run live-events calendar, two titles | A2, C2 |
| Coordinate design, art, engineering, community | A1, C4, D1 |
| Own post-event review and KPIs | A3, A4, B1 |
| Manage release checklist with QA | B3, C3 |
| 3+ years live-service | E1 (F4) |
| Content calendar experience | A2, E1 |
| Player-retention metrics | B1, B2, A4 |
| Clear written communication | B3 |
| Not a JD line: in-app purchases | A5, D3 |

## Reverse questions

Each one has a reason to ask it.

1. "What does a good post-event review look like here, and who reads it?" Why it lands: it treats the JD's review line as the job, and shows you read it that way.
2. "Which two titles will this role cover, and how far apart are their calendars?" Why it lands: it asks about the two-title scope the JD names, and the answer tells you how much of your drop-calendar experience transfers.
3. "How does the release checklist work with QA today, and where does it break most often?" Why it lands: it asks about the step you have already built, and shows you want to see where it stands.
4. "On an update, who makes the final call when design, art, engineering and community disagree?" Why it lands: it asks the question behind the coordination requirement, where your gap is.
5. "Which retention and KPI reports will this role own in the first three months, and which are already set?" Why it lands: it separates what you would own from what is inherited, which is the difference the KPI line turns on.

## Sources

- **Provided documents:** your message, which holds the JD text, your background, and the interview details.
- **Searches attempted:**
  - "Saltmarsh Games mobile studio live operations": refused. Web search permission was not granted in this session.
  - "Tobias Wrenfield Head of Live Operations Saltmarsh Games": refused, for the same reason.
- No fetches ran. No dossier was present.

Research tier: L1 requested by default, but both search calls were refused, so the run is L0 in effect: searches 0 of 6 (2 refused), fetches 0 of 2.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | unavailable | Values cheat sheet dropped. No values in hand, and no values-style round detected. |
| 2. Saltmarsh Games interview process (live operations) | unavailable | Loop structure and persona weights stayed on hiring-manager priors. |
| 3. Saltmarsh Games strategy / recent news | unavailable | Query refused. Would have moved a grounding brief and CO questions. None included. |
| 4. Tobias Wrenfield public footprint | unavailable | Query refused. Would have moved the interviewer read and a tailored reverse question. Interviewer read dropped. |
| 5. Representative JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions. |

## Sections not included

- Prep triage: prep time was not stated.
- Values cheat sheet: no values in hand.
- Grounding brief: no research ran.
- Reading the interviewer: no public footprint retrieved.
- Graded deliverables: none declared.
- Delivery coaching: no assessment provided.

## Upgrade menu

- Permission to run web search (refused this session) → company values, interview loop structure, recent strategy, and Tobias's public footprint: a values cheat sheet, persona weights, a grounding brief, and a tailored reverse question.
- Whether Tobias would manage you, or sit beside you → reweights every bank.
- Any focus areas or deliverable from the recruiter → coverage of any graded deliverable.
- A redacted copy of one content-drop calendar → F1 and F5 from medium to high, with a real artifact for the probe.
- A redacted copy of the release checklist → F2 from medium to high, and B3 gets its artifact.
- Any retention figure you calculated yourself, with how it was counted → resolves the slot in F6 and B1.
- Whether the puzzle title updated on a schedule after launch, and how → resolves the slot in F4.
