Your prep pack is saved as `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-alone-part-2-rooms-case-8-canned-e3678567/5f3724e3-55cd-40a4-91d6-add1bcf66d3c/scratchpad/ashgrove_member_experience_lead_interview_pack.md`. I built it as a loop, one mini-pack per round, since you have three scheduled rounds on 20 November.

# Ashgrove Credit Union: Member Experience Lead interview pack

**Candidate:** Dara
**Role:** Member Experience Lead, Ashgrove Credit Union (member-owned, about 900 staff)
**Mode:** Loop (three scheduled rounds on 20 November 2026)

- **R1:** recruiter, 30 minutes
- **R2:** Head of Member Services (your future manager), 45 minutes, mostly behavioural
- **R3:** panel of two branch managers, 60 minutes, including a 20-minute complaint-escalation case; scored against the four values

Interviewers for R2 and R3 are not assigned yet, so there is no interviewer read. The recruiter is the only named interviewer.

## How to use this pack

Personas describe how a question arrives. Types describe what it scores.

- **VAL:** behavioural / values. Does past behaviour show a published value?
- **EXP:** experience deep-dive. Does what you did survive scrutiny?
- **JD:** role-driven. Can you do the listed job, gaps included?
- **CO:** company and strategy knowledge.
- **CASE:** live problem from the role. Asks about no past.

"Your message" means the background and JD you sent me. Answer slots are instructions for the interview, not questions for me. Guidance is scaffolding, not a script. Rehearse only what you actually did.

## Fit snapshot

No requirement in the JD is a gate in the skill's sense (no licence, credential or legal bar is named). The four years and the regulated-complaints line are graded like any other requirement.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | transferability | Your material says one branch's formal complaints log. Keep the bridge at that scope: "I handled the branch's formal complaints log." Answer slot: if you set how complaints moved through the branch from first contact to close, say which steps were yours and how you decided; if others set them, say so and describe the log you handled. |
| F2 | "and the contact centre" (JD) | "Never worked in a contact centre" (your message) | none | [grounded] | capability | A gap you stated yourself. Say it plainly: "I've never worked in a contact centre." Then how you would learn the contact-centre side of a complaint, as a plan and never as a past. |
| F3 | "report monthly on complaint volumes and resolution times" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | medium | [grounded] | presentation | The quote already reaches monthly reporting in other terms. The bridge rewords only that sentence and adds no figure. Answer slot: the JD names volumes and resolution times, so expect a probe on what the sheet counted; if it held volumes or resolution times, say which and how you counted them; if it did not hold resolution times, say so. |
| F4 | "comfortable with Excel reporting" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | low | [inferred] | discovery | Your material shows a spreadsheet. It does not name Excel or your level in it, so no Excel claim is coached. Answer slot: name the tool and the functions you used, in your own words, and say which you would need help with. |
| F5 | "4+ years in financial-services customer operations" (JD) | "6 years in retail banking, the last 3 as a branch supervisor" (your message) | medium | [grounded] | none | The quote reaches the requirement. Say its facts: six years in retail banking, three of them as a branch supervisor. Confidence is medium because there is no inspectable proof yet. |
| F6 | "experience handling regulated complaints" (JD) | "I handled the branch's formal complaints log" (your message) | low | [inferred] | discovery | Formal is not the same as regulated. Your material does not say the log ran to any regulated standard. Answer slot: if the log was held to a regulator's or the credit union's formal timelines, say which and how you tracked them; if it was not, say so and describe how formal complaints were handled. |
| F7 | "confident presenting to senior leaders" (JD) | "I've never presented to anyone above regional level" (your message) | none | [grounded] | capability | Your own negative, so the words are yours: "I haven't presented to anyone above regional level." Then how you would prepare for a senior audience, as a plan. |
| F8 | "coach branch supervisors on escalations" (JD) | "trained new tellers on our escalation script" (your message) | medium | [grounded] | transferability | Tellers and branch supervisors are different audiences. Bridge at the quote's scope: "I trained new tellers on our escalation script." Coaching supervisors is a plan, not a past. |
| F9 | "work with digital teams on self-service journeys" (JD) | none given | none | [grounded] | discovery | Your material is silent here, so no claim is coached. Answer slot: if you have worked with a digital team on a customer journey, say which and what your part was; if you have not, say so and say how you would start. |

## Prohibited claims

Built from the fit snapshot before the banks were written. Nothing below may be asserted, softened or implied in any answer, bridge or reverse question.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end across branches and the contact centre | Inflated form of F1 and F2 | F1's quote at its own scope. The pack's observation: your material says one branch's log, and the contact-centre side is a stated gap. |
| Coached branch supervisors on escalations | Inflated form of F8: tellers are a different audience | "I trained new tellers on our escalation script." Supervisor coaching is a plan. |
| Built a monthly report on resolution times | Inflated form of F3: your material says a spreadsheet, not what it held | F3's quote at its own scope; what it counted is the answer slot. |
| Advanced Excel skills | Inflated form of F4 | The spreadsheet quote. The tool and your level are the answer slot. |
| Regulated complaints experience | Inflated form of F6 | F6's quote at its scope; the regulated question is an answer slot. |
| Presented to senior leaders | Your own stated negative (F7) | "I haven't presented to anyone above regional level." |
| Contact-centre experience | Your own stated negative (F2) | "I've never worked in a contact centre." |

## Persona weights by round

Relationship priors set the start; the loop and the interviewer roles adjust them. Depth follows weight.

**R1, recruiter screen (30 min)**

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport | Open questions on background and motivation | High. Recruiter screens run friendly and are still scored on consistency | Pre-arrange a 90-second background; treat the motivation question as scored |
| Skeptic (light) | Knockout checks on the contact centre and presenting | Medium. The recruiter's job is to clear gaps early | Say the stated gaps plainly, once, with a plan |

**R2, Head of Member Services (45 min, mostly behavioural)**

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Probes the contact centre and presenting gaps; "why should I believe you" | High. The JD's own wording points there, and a manager is buying capability while derisking gaps | Hold the quote-backed position, then concede the gap specifically |
| Values / Behavioral | STAR-shaped stories, mostly behavioural per the recruiter | High. The recruiter named the format | Pick stories where your own part is clear; say where you have none |
| Case / Strategist | Live problem on the manager's roadmap | Medium. A manager's first round often includes one | Clarify before answering; think aloud |

**R3, panel of two branch managers (60 min, includes 20-minute case)**

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | Scored against the four published values | High. The recruiter says the panel scores against them | Map each value to what you did, or say you have no story |
| Case / Strategist | 20-minute complaint-escalation case | High. The case is a third of the round's time | Clarify first; name the order of steps; say what you would check first |
| Pressure | Branch managers test the branch-side view | Medium. Two branch managers may challenge a branch-side answer | Hold through two follow-ups; concede specifically |

## Question banks

### R1, recruiter screen (8 questions; depth weighted to Conversational)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through your background in about two minutes." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "I handled the branch's formal complaints log"; "trained new tellers on our escalation script"; "I built the monthly complaints spreadsheet our regional manager uses" (your message) | About 90 seconds, in order: the six years, the three as a supervisor, then the complaints work in one sentence each. Say each fact once, in your own words, and stop. | Opener in a friendly register, still scored. F5 is the one row with no gap, so the arc starts there. |
| A2 | "Why this role, and why now?" | CO | [grounded] "move 40% of member service to digital channels by 2028" (the strategy brief as summarised in your message) | Tie motivation to the job's own content: complaints across branches and the contact centre, and the move to digital. Say what draws you to the work. Do not claim contact-centre experience. | Motivation consistency is a screen check. The brief's digital target gives a current, specific reason to want this job. |
| A3 | "The role covers branches and the contact centre. What's your experience of the contact-centre side?" | JD | [grounded] "Never worked in a contact centre" (your message) | Say it plainly: "I've never worked in a contact centre." Then how you would learn its side of a complaint, as a plan. No slot is needed; this is your own stated negative. | F2 is the first knockout check. A plain acknowledgment with a plan answers it without bluffing. |
| A4 | "You handled complaints at your branch. How did that work?" | EXP | [grounded] "I handled the branch's formal complaints log" (your message) | Describe the log at its own scope, in your words. Answer slot: if you set how cases were timed or closed, say which and how you decided; if others set them, say so. | F1 and F6. The regulated question is parked for R2, and the answer slot is ready before it arrives. |
| A5 | "What did you build that your regional manager uses?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" (your message) | Say what you built, in its own words. Answer slot: if it held volumes or resolution times, say which and how you counted them; if it did not, say so. | F3. The answer slot is what the JD's reporting line raises. |
| A6 | "Which Excel functions do you use day to day?" | JD | [inferred] "I built the monthly complaints spreadsheet our regional manager uses" (your message) | Answer slot: name the tool and the functions you used, in your own words, and say what you would need help with. Coach no Excel level. | F4 is low-confidence. The tool question is the honest form of "comfortable with Excel reporting". |
| A7 | "What do you know about where we're heading?" | CO | [grounded] "move 40% of member service to digital channels by 2028" and "consolidate eight branches into five hubs over 2027" (the strategy brief as summarised in your message) | Name the two items: the 40 per cent digital target by 2028 and the eight-to-five hub move. Say one thing you would want to understand about each. Do not correct the brief. | The brief is current and the recruiter sent it. Sounding current is the company-knowledge bar at screen level. |
| A8 | "Is there anything from your background you'd want us to know before the next round?" | JD | [grounded] "I've never presented to anyone above regional level" (your message) | Say the plain acknowledgment first: "I haven't presented to anyone above regional level." Then how you would prepare for a senior audience, as a plan. | F7 is the gap R2 is most likely to press. Saying it here, in your words, means it is not a surprise. |

### R2, Head of Member Services (9 questions; depth weighted to Skeptic)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've never worked in a contact centre, and this role owns the complaints process across it. Why should I believe you can run it end to end?" | JD | [grounded] "Never worked in a contact centre" and "I handled the branch's formal complaints log" (your message) | **Highest-ROI prep in this pack.** Hold the position your quotes carry: the branch log is the closest work you have done, and you do not claim the contact-centre side. Say the plain acknowledgment, then the log at its own scope, then the plan to learn the contact-centre side first. Hold through two follow-ups by returning to the log. When pressed, concede the scope specifically: one branch's log, and the contact centre is what you would learn first. Never describe your past as "end to end". | The objection the JD's own wording makes near certain. F1 and F2 are the rows it lands on. Deepest rehearsal, because a specific concession changes the round more than a defence does. |
| B2 | "Tell me about a time you had to hold a position with a senior person." | VAL | [generic] | Choose one instance where you held a view under pressure from someone senior: a named stake, a moment you did not fold, and a working relationship at the end. Give the parts you did. If none comes to mind, say so plainly, then say how you would handle it now. | Behavioural frame drawn from the persona stems. No claim about your past is written here. |
| B3 | "Describe a complaint you couldn't close cleanly. What did you do?" | VAL | [grounded] "I handled the branch's formal complaints log" (your message) | Open prompt: choose one complaint from the log. Say what you kept hold of and what closed it. Answer slot: if no complaint stayed open for you to carry, say so, then say how you would keep hold of one that is not yours to fix. | Own the Fix made concrete. F1 is the only record of your handling, so the example comes from the log. |
| B4 | "Walk me through your first 90 days on the complaints process across branches and the contact centre." | JD | [generic] | Plan, not past: first listen to branch supervisors and contact-centre leads; then agree one shared record of a complaint; then choose the first measure and say why. Keep each step short. | The JD's ownership line asked as a plan. No claim about your history. |
| B5 | "What would you change first in the monthly report?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" (your message) | Say what you would change, framed as a plan. Answer slot: if the sheet held resolution times, say how you counted them; if it did not, say so and say what you would add first. | F3. The JD names resolution times, so a probe on the sheet's contents is likely. |
| B6 | "You trained tellers on the escalation script. How would you coach a supervisor who escalates too late?" | JD | [grounded] "trained new tellers on our escalation script" (your message) | Bridge at the tellers: "I trained new tellers on our escalation script." The supervisor coaching is a plan: review a few escalations together, agree the trigger point, check again after a month. | F8. The gap is audience, not script. The plan answers the coaching line without a claim. |
| B7 | "What's the first thing about this job you'd be weakest at?" | JD | [grounded] "I've never presented to anyone above regional level" (your message) | Name presenting to senior leaders with the plain acknowledgment: "I haven't presented to anyone above regional level." Then how you would prepare, as a plan. Do not add a second weakness to look balanced. | F7. A direct answer shows the honest self-assessment this round scores. |
| B8 | "The strategy moves 40% of member service to digital by 2028. What do you know about self-service journeys?" | JD | [grounded] "move 40% of member service to digital channels by 2028" (the strategy brief as summarised in your message) | Answer slot: if you have worked with a digital team on a customer journey, say which and what your part was; if you have not, say so and say how you would start. | F9. Your material is silent, so this is the honest form of the digital requirement. |
| B9 | "If complaints move into the app, what happens to the monthly report?" | CASE | [grounded] "move 40% of member service to digital channels by 2028" (the strategy brief as summarised in your message) | Reason aloud: what volumes and channels the report would see, what it would miss, and what you would measure in the app. No claim about your past. | A live problem from the role, linking the report line to the digital target. |

### R3, panel of two branch managers (9 questions; depth weighted to Values and Case)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you put a member ahead of an internal target." | VAL | [generic]; "I handled the branch's formal complaints log" (your message) | Choose one case where the member's side decided what you did: name the stake, the call you made, and the outcome you can state. If none comes to mind, say so plainly, then say which complaint in your log you would tell first, and why. | Members First, asked as an open prompt. No past event is written here. |
| C2 | "When did you have to explain something to a member twice, and what did you change?" | VAL | [grounded] "trained new tellers on our escalation script" (your message) | Answer slot: if you changed the wording of a script or letter so a member could follow it, say what changed; if you did not, say so, and say how you would test a letter for plain words. | Plain Words. The script is the only piece of your material about explaining, so the slot is the honest form. |
| C3 | "How do you weigh a branch's place in its town against its numbers?" | VAL | [generic] | Say the principle you would use and how you would test it in a branch you had not run before. If you have no branch story of your own, say so plainly; do not supply one. Do not take a view on the hub plan you have not been briefed on. | Neighbours, Not Numbers, asked as a principle. No quoted sentence carries a story, so the guidance gives none. |
| C4 | "Tell us about a problem you found that wasn't yours to solve, and what you did until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log" (your message) | Open prompt: name the problem, what you kept hold of, and when it closed. Answer slot: if you kept a complaint open until it was solved, say which and how; if you handed it on, say to whom and what you checked. If none comes to mind, say so plainly. | Own the Fix. The log is the only place your material shows you holding cases. |
| C5 | "A member was charged a fee in error at a branch. The branch logged the complaint as resolved. Three weeks later the member writes to the regional office, and the contact centre has no record of the first contact. The branch supervisor says the policy is clear. You have 20 minutes: what do you do, in what order?" | CASE | [generic] | Clarify first: what the record shows and what the member has been told. Then the member first, one named owner, an interim reply in plain words, the cause of the wrong resolved status, and the branch supervisor's position heard before you decide. Say which part you would check first and what you would need from the contact centre. Do not claim you have handled such a case. | Scored on Own the Fix, Members First, Plain Words and Neighbours at once. The scenario is invented, so it is generic. The contact-centre gap (F2) is what a bluff would show. |
| C6 | "A supervisor refuses to accept a decision you've made on a complaint. What do you do?" | JD | [grounded] "I handled the branch's formal complaints log" (your message) | Hold the decision if the member's outcome depends on it. Say what you would test with the supervisor, in your own words. Hold through two follow-ups before conceding anything. Concede the local context you have not seen, specifically. | Pressure, hold-then-concede, on the coaching line. The hold rests on the log work, and no past event is supplied. |
| C7 | "A branch on the consolidation list has complaints open today. What do you tell its staff?" | CO | [grounded] "consolidate eight branches into five hubs over 2027" (the strategy brief as summarised in your message) | Say what you would do for members with open complaints during the move, and what you would not say before you were briefed. Do not speculate on which branches close. | Pressure on Neighbours. The hub line is the sensitive one for branch managers on this panel. |
| C8 | "How would you coach a supervisor who escalates everything?" | JD | [generic] | Plan: review a few escalations together, agree what justifies escalating, then check the next month's cases. No claim about past coaching. | The JD's coaching line asked as a plan, from the branch side. |
| C9 | "Name the first measure you would put on complaint resolution, and the assumption it rests on." | JD | [generic] | One measure, why it matters to a member, and the assumption you would defend least. Say it in one breath. | The JD's resolution-times line. Your material has no headline figure, so there is no defend-the-number question. |

**Requirement coverage.** Every JD requirement maps to at least one question, or says why it does not.

| JD requirement | Covered by |
|---|---|
| Own the complaints process end to end across branches | B1, B4, C5 |
| Report monthly on volumes and resolution times | A5, B5, C9 |
| Coach branch supervisors on escalations | B6, C6, C8 |
| Work with digital teams on self-service journeys | B8, B9 (answer slot only; your material is silent) |
| 4+ years in financial-services customer operations | A1 |
| Experience handling regulated complaints | A4, B3 (regulated question in the answer slot) |
| Confident presenting to senior leaders | B7, A8. None of the three rounds asks you to present; the gap is still probed through B7 and A8 |
| Comfortable with Excel reporting | A5, A6 |

Session total: 26 questions. Depth follows persona weight.

## Values cheat sheet (R3)

The values are the four on the company's values page, copied on 11 November 2026. Only the quoted sentences in the fit snapshot count as your stories. Where none carries a story, the honest branch is given.

| Value | Working meaning | Your mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | F1 carries no story about a member's decision. Selection: pick one complaint from the log where the member's side changed what you decided; say what changed. If none did, say so plainly, then say how you would check a decision from the member's side. |
| Plain Words | If a member needs it explained twice, the wording was wrong | F8 carries training, not a member's second explanation. Selection: pick a script or letter a member had to ask about twice; say what you changed. If you changed nothing, say so, then say how you would test a letter for plain words. |
| Neighbours, Not Numbers | Every branch is part of its town | No quoted sentence carries a story. Say so plainly, then give the principle you would use and how you would test it in a branch you did not know. |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | F1 is the closest. Selection: pick one complaint you followed to close; say what you kept hold of. If you handed one on, say to whom and what you checked. |

## Grounding brief

Built from the strategy points in your message. The brief itself was not pasted, so this uses your summary only.

- Digital shift: move 40% of member service to digital channels by 2028. [grounded]
- Branch network: consolidate eight branches into five hubs over 2027. [grounded]
- Lending: launch a small-business lending product in Q1 2027. [grounded]
- Competition: the main competitive pressure is app-only banks. [grounded]
- Read-across to complaints (a reading, not a fact about the company): the digital shift changes what the monthly report sees, and the hub move puts complaint handling in a different place for branch staff. Both are reasoning from the brief, not claims about its content. [inferred]

## Reverse questions

Each carries why it lands. No interviewer profile exists, so these are role-generic. R3 has no peer seat, so no reciprocity question is included.

| Round | Question | Why it lands |
|---|---|---|
| R1 | "Which of the four values carries the most weight with the panel, and how do they score them?" | Shows you read the panel brief and plan to be scored on the values. |
| R1 | "What does the Head of Member Services most want to change in the complaints process over the next year?" | Points your R2 preparation at the manager's own priorities. |
| R2 | "Where do complaints get stuck today between the branches and the contact centre?" | Signals Own the Fix and shows you are already thinking about the handoff. |
| R2 | "What would a strong first 90 days look like, and what would I be expected to have inherited?" | Manager-altitude question; it reads as ownership, not as a request for a job description. |
| R2 | "Who reads the monthly complaints report besides the regional manager?" | Shows you are thinking about the report's audience, which is the senior-leader presenting gap in a useful form. |
| R3 | "When a branch and the contact centre disagree about a complaint's outcome, who decides today?" | Tests the ownership line directly. The answer tells you where the process actually breaks. |
| R3 | "As more service moves to digital, how should a branch manager see the complaints that come from the app?" | Connects the strategy to the branch side. Asked while the hub plan is still moving, it does not presume a closure. |
| R3 | "What does a good escalation look like to you, when a supervisor gets it right?" | Gives the panel a way to describe the coaching standard, which you can match in C8. |

## Sources

**Provided documents**

- JD text, as you sent it (your message)
- Company values, copied from the company's values page on 11 November 2026 (your message)
- Recruiter's process email: three rounds on 20 November, round structure, and the panel's values scoring (your message)
- Strategy points from the July 2026 strategy brief, as you summarised them (your message)
- Your background: six years in retail banking, three as a branch supervisor; complaints log; escalation training; monthly spreadsheet; no contact-centre work; no presenting above regional level (your message)

**Searches and fetches:** none sent.

**Research tier: L1, searches 0 of 6, fetches 0 of 2**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | Values cheat sheet and R3 values questions. The four values are pasted, so the input fixes them. |
| 2. Ashgrove interview process, role family | skipped | Round structure and persona weights. The recruiter's email fixes the three rounds and their lengths. |
| 3. Ashgrove strategy / recent news | skipped | Grounding brief and CO questions. The points you pasted fix the headline items; a search could add detail beyond the brief's headlines, and the pack does not use it. |
| 4. Interviewer name and company | n/a | No interviewer name was given, so there was no query to form. The upgrade menu says what a name would unlock. |
| 5. Representative JD for the role title | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions. |

## Upgrade menu

- The strategy brief itself (or the page it came from) → the grounding brief quotes its wording, not your summary
- The recruiter's note on any presentation or written exercise, if one is planned → a graded-deliverable section
- The names of the R2 and R3 interviewers, when assigned → persona weights per interviewer and an interviewer read
- Your CV text → fit rows cite it as your CV, and any figure on it raises defend-the-number questions
- Your answers to the answer slots (F1, F3, F4, F6, F9, and the C2 and C4 slots) → each row upgrades from a slot to a quoted line, only if you state the facts yourself
- The tool you use for reporting (F4) → A6 and the Excel row can name it
- Prep time before 20 November → a prep-triage schedule

---

Say the word and I'll run a drill as the Skeptic on B1, the question the pack names as the highest-ROI prep. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove_member_experience_lead_interview_pack.md -----
# Ashgrove Credit Union: Member Experience Lead interview pack

**Candidate:** Dara
**Role:** Member Experience Lead, Ashgrove Credit Union (member-owned, about 900 staff)
**Mode:** Loop (three scheduled rounds on 20 November 2026)

- **R1:** recruiter, 30 minutes
- **R2:** Head of Member Services (your future manager), 45 minutes, mostly behavioural
- **R3:** panel of two branch managers, 60 minutes, including a 20-minute complaint-escalation case; scored against the four values

Interviewers for R2 and R3 are not assigned yet, so there is no interviewer read. The recruiter is the only named interviewer.

## How to use this pack

Personas describe how a question arrives. Types describe what it scores.

- **VAL:** behavioural / values. Does past behaviour show a published value?
- **EXP:** experience deep-dive. Does what you did survive scrutiny?
- **JD:** role-driven. Can you do the listed job, gaps included?
- **CO:** company and strategy knowledge.
- **CASE:** live problem from the role. Asks about no past.

"Your message" means the background and JD you sent me. Answer slots are instructions for the interview, not questions for me. Guidance is scaffolding, not a script. Rehearse only what you actually did.

## Fit snapshot

No requirement in the JD is a gate in the skill's sense (no licence, credential or legal bar is named). The four years and the regulated-complaints line are graded like any other requirement.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | transferability | Your material says one branch's formal complaints log. Keep the bridge at that scope: "I handled the branch's formal complaints log." Answer slot: if you set how complaints moved through the branch from first contact to close, say which steps were yours and how you decided; if others set them, say so and describe the log you handled. |
| F2 | "and the contact centre" (JD) | "Never worked in a contact centre" (your message) | none | [grounded] | capability | A gap you stated yourself. Say it plainly: "I've never worked in a contact centre." Then how you would learn the contact-centre side of a complaint, as a plan and never as a past. |
| F3 | "report monthly on complaint volumes and resolution times" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | medium | [grounded] | presentation | The quote already reaches monthly reporting in other terms. The bridge rewords only that sentence and adds no figure. Answer slot: the JD names volumes and resolution times, so expect a probe on what the sheet counted; if it held volumes or resolution times, say which and how you counted them; if it did not hold resolution times, say so. |
| F4 | "comfortable with Excel reporting" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | low | [inferred] | discovery | Your material shows a spreadsheet. It does not name Excel or your level in it, so no Excel claim is coached. Answer slot: name the tool and the functions you used, in your own words, and say which you would need help with. |
| F5 | "4+ years in financial-services customer operations" (JD) | "6 years in retail banking, the last 3 as a branch supervisor" (your message) | medium | [grounded] | none | The quote reaches the requirement. Say its facts: six years in retail banking, three of them as a branch supervisor. Confidence is medium because there is no inspectable proof yet. |
| F6 | "experience handling regulated complaints" (JD) | "I handled the branch's formal complaints log" (your message) | low | [inferred] | discovery | Formal is not the same as regulated. Your material does not say the log ran to any regulated standard. Answer slot: if the log was held to a regulator's or the credit union's formal timelines, say which and how you tracked them; if it was not, say so and describe how formal complaints were handled. |
| F7 | "confident presenting to senior leaders" (JD) | "I've never presented to anyone above regional level" (your message) | none | [grounded] | capability | Your own negative, so the words are yours: "I haven't presented to anyone above regional level." Then how you would prepare for a senior audience, as a plan. |
| F8 | "coach branch supervisors on escalations" (JD) | "trained new tellers on our escalation script" (your message) | medium | [grounded] | transferability | Tellers and branch supervisors are different audiences. Bridge at the quote's scope: "I trained new tellers on our escalation script." Coaching supervisors is a plan, not a past. |
| F9 | "work with digital teams on self-service journeys" (JD) | none given | none | [grounded] | discovery | Your material is silent here, so no claim is coached. Answer slot: if you have worked with a digital team on a customer journey, say which and what your part was; if you have not, say so and say how you would start. |

## Prohibited claims

Built from the fit snapshot before the banks were written. Nothing below may be asserted, softened or implied in any answer, bridge or reverse question.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end across branches and the contact centre | Inflated form of F1 and F2 | F1's quote at its own scope. The pack's observation, in its analysis: your material says one branch's log, and the contact-centre side is a stated gap. |
| Coached branch supervisors on escalations | Inflated form of F8: tellers are a different audience | "I trained new tellers on our escalation script." Supervisor coaching is a plan. |
| Built a monthly report on resolution times | Inflated form of F3: your material says a spreadsheet, not what it held | F3's quote at its own scope; what it counted is the answer slot. |
| Advanced Excel skills | Inflated form of F4 | The spreadsheet quote. The tool and your level are the answer slot. |
| Regulated complaints experience | Inflated form of F6 | F6's quote at its scope; the regulated question is an answer slot. |
| Presented to senior leaders | Your own stated negative (F7) | "I haven't presented to anyone above regional level." |
| Contact-centre experience | Your own stated negative (F2) | "I've never worked in a contact centre." |

## Persona weights by round

Relationship priors set the start; the loop and the interviewer roles adjust them. Depth follows weight: the top persona gets the most questions.

**R1, recruiter screen (30 min)**

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport | Open questions on background and motivation | High. Recruiter screens run friendly and are still scored on consistency | Pre-arrange a 90-second background; treat the motivation question as scored |
| Skeptic (light) | Knockout checks on the contact centre and presenting | Medium. The recruiter's job is to clear gaps early | Say the stated gaps plainly, once, with a plan |

**R2, Head of Member Services (45 min, mostly behavioural)**

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Probes the contact centre and presenting gaps; "why should I believe you" | High. The JD's own wording points there, and a manager is buying capability while derisking gaps | Hold the quote-backed position, then concede the gap specifically |
| Values / Behavioral | STAR-shaped stories, mostly behavioural per the recruiter | High. The recruiter named the format | Pick stories where your own part is clear; say where you have none |
| Case / Strategist | Live problem on the manager's roadmap | Medium. A manager's first round often includes one | Clarify before answering; think aloud |

**R3, panel of two branch managers (60 min, includes 20-minute case)**

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | Scored against the four published values | High. The recruiter says the panel scores against them | Map each value to what you did, or say you have no story |
| Case / Strategist | 20-minute complaint-escalation case | High. The case is a fifth of the round's time | Clarify first; name the order of steps; say what you would check first |
| Pressure | Branch managers test the branch-side view | Medium. Two branch managers may challenge a branch-side answer | Hold through two follow-ups; concede specifically |

## Question banks

### R1, recruiter screen (8 questions; depth weighted to Conversational)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through your background in about two minutes." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "I handled the branch's formal complaints log"; "I built the monthly complaints spreadsheet our regional manager uses" (your message) | About 90 seconds, in order: the six years, the three as a supervisor, then the complaints work in one sentence each. Say each fact once, in your own words, and stop. | Opener in a friendly register, still scored. F5 is the one row with no gap, so the arc starts there. |
| A2 | "Why this role, and why now?" | CO | [grounded] "move 40% of member service to digital channels by 2028" (the strategy brief as summarised in your message) | Tie motivation to the job's own content: complaints across branches and the contact centre, and the move to digital. Say what draws you to the work. Do not claim contact-centre experience. | Motivation consistency is a screen check. The brief's digital target gives a current, specific reason to want this job. |
| A3 | "The role covers branches and the contact centre. What's your experience of the contact-centre side?" | JD | [grounded] "Never worked in a contact centre" (your message) | Say it plainly: "I've never worked in a contact centre." Then how you would learn its side of a complaint, as a plan. No slot is needed; this is your own stated negative. | F2 is the first knockout check. A plain acknowledgment with a plan answers it without bluffing. |
| A4 | "You handled complaints at your branch. How did that work?" | EXP | [grounded] "I handled the branch's formal complaints log" (your message) | Describe the log at its own scope, in your words. Answer slot: if you set how cases were timed or closed, say which and how you decided; if others set them, say so. | F1 and F6. The regulated question is parked for R2 and the answer slot is ready before it arrives. |
| A5 | "What did you build that your regional manager uses?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" (your message) | Say what you built, in its own words. Answer slot: if it held volumes or resolution times, say which and how you counted them; if it did not, say so. | F3. The answer slot is what the JD's reporting line raises. |
| A6 | "Which Excel functions do you use day to day?" | JD | [inferred] "I built the monthly complaints spreadsheet our regional manager uses" (your message) | Answer slot: name the tool and the functions you used, in your own words, and say what you would need help with. Coach no Excel level. | F4 is low-confidence. The tool question is the honest form of "comfortable with Excel reporting". |
| A7 | "What do you know about where we're heading?" | CO | [grounded] "move 40% of member service to digital channels by 2028" and "consolidate eight branches into five hubs over 2027" (the strategy brief as summarised in your message) | Name the two items: the 40 per cent digital target by 2028 and the eight-to-five hub move. Say one thing you would want to understand about each. Do not correct the brief. | The brief is current and the recruiter sent it. Sounding current is the company-knowledge bar at screen level. |
| A8 | "Is there anything from your background you'd want us to know before the next round?" | JD | [grounded] "I've never presented to anyone above regional level" (your message) | Say the plain acknowledgment first: "I haven't presented to anyone above regional level." Then how you would prepare for a senior audience, as a plan. | F7 is the gap R2 is most likely to press. Saying it here, in your words, means it is not a surprise. |

### R2, Head of Member Services (9 questions; depth weighted to Skeptic)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've never worked in a contact centre, and this role owns the complaints process across it. Why should I believe you can run it end to end?" | JD | [grounded] "Never worked in a contact centre" and "I handled the branch's formal complaints log" (your message) | **Highest-ROI prep in this pack.** Hold the position your quotes carry: the branch log is the closest work you have done, and you do not claim the contact-centre side. Say the plain acknowledgment, then the log at its own scope, then the plan to learn the contact-centre side first. Hold through two follow-ups by returning to the log. When pressed, concede the scope specifically: one branch's log, and the contact centre is what you would learn first. Never describe your past as "end to end". | The objection the JD's own wording makes near certain. F1 and F2 are the rows it lands on. Deepest rehearsal, because a specific concession changes the round more than a defence does. |
| B2 | "Tell me about a time you had to hold a position with a senior person." | VAL | [generic] | Choose one instance where you held a view under pressure from someone senior: a named stake, a moment you did not fold, and a working relationship at the end. Give the parts you did. If none comes to mind, say so plainly, then say how you would handle it now. | Behavioural frame drawn from the persona stems. No claim about your past is written here. |
| B3 | "Describe a complaint you couldn't close cleanly. What did you do?" | VAL | [grounded] "I handled the branch's formal complaints log" (your message) | Open prompt: choose one complaint from the log. Say what you kept hold of and what closed it. Answer slot: if no complaint stayed open for you to carry, say so, then say how you would keep hold of one that is not yours to fix. | Own the Fix made concrete. F1 is the only record of your handling, so the example comes from the log. |
| B4 | "Walk me through your first 90 days on the complaints process across branches and the contact centre." | JD | [generic] | Plan, not past: first listen to branch supervisors and contact-centre leads; then agree one shared record of a complaint; then choose the first measure and say why. Keep each step short. | The JD's ownership line asked as a plan. No claim about your history. |
| B5 | "What would you change first in the monthly report?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" (your message) | Say what you would change, framed as a plan. Answer slot: if the sheet held resolution times, say how you counted them; if it did not, say so and say what you would add first. | F3. The JD names resolution times, so a probe on the sheet's contents is likely. |
| B6 | "You trained tellers on the escalation script. How would you coach a supervisor who escalates too late?" | JD | [grounded] "trained new tellers on our escalation script" (your message) | Bridge at the tellers: "I trained new tellers on our escalation script." The supervisor coaching is a plan: review a few escalations together, agree the trigger point, check again after a month. | F8. The gap is audience, not script. The plan answers the coaching line without a claim. |
| B7 | "What's the first thing about this job you'd be weakest at?" | JD | [grounded] "I've never presented to anyone above regional level" (your message) | Name presenting to senior leaders with the plain acknowledgment: "I haven't presented to anyone above regional level." Then how you would prepare, as a plan. Do not add a second weakness to look balanced. | F7. A direct answer shows the honest self-assessment this round scores. |
| B8 | "The strategy moves 40% of member service to digital by 2028. What do you know about self-service journeys?" | JD | [grounded] "move 40% of member service to digital channels by 2028" (the strategy brief as summarised in your message) | Answer slot: if you have worked with a digital team on a customer journey, say which and what your part was; if you have not, say so and say how you would start. | F9. Your material is silent, so this is the honest form of the digital requirement. |
| B9 | "If complaints move into the app, what happens to the monthly report?" | CASE | [grounded] "move 40% of member service to digital channels by 2028" (the strategy brief as summarised in your message) | Reason aloud: what volumes and channels the report would see, what it would miss, and what you would measure in the app. No claim about your past. | A live problem from the role, linking the report line to the digital target. |

### R3, panel of two branch managers (9 questions; depth weighted to Values and Case)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you put a member ahead of an internal target." | VAL | [generic]; "I handled the branch's formal complaints log" (your message) | Choose one case where the member's side decided what you did: name the stake, the call you made, and the outcome you can state. If none comes to mind, say so plainly, then say which complaint in your log you would tell first, and why. | Members First, asked as an open prompt. No past event is written here. |
| C2 | "When did you have to explain something to a member twice, and what did you change?" | VAL | [grounded] "trained new tellers on our escalation script" (your message) | Answer slot: if you changed the wording of a script or letter so a member could follow it, say what changed; if you did not, say so, and say how you would test a letter for plain words. | Plain Words. The script is the only piece of your material about explaining, so the slot is the honest form. |
| C3 | "How do you weigh a branch's place in its town against its numbers?" | VAL | [generic] | Say the principle you would use and how you would test it in a branch you had not run before. If you have no branch story of your own, say so plainly; do not supply one. Do not take a view on the hub plan you have not been briefed on. | Neighbours, Not Numbers, asked as a principle. No quoted sentence carries a story, so the guidance gives none. |
| C4 | "Tell us about a problem you found that wasn't yours to solve, and what you did until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log" (your message) | Open prompt: name the problem, what you kept hold of, and when it closed. Answer slot: if you kept a complaint open until it was solved, say which and how; if you handed it on, say to whom and what you checked. If none comes to mind, say so plainly. | Own the Fix. The log is the only place your material shows you holding cases. |
| C5 | "A member was charged a fee in error at a branch. The branch logged the complaint as resolved. Three weeks later the member writes to the regional office, and the contact centre has no record of the first contact. The branch supervisor says the policy is clear. You have 20 minutes: what do you do, in what order?" | CASE | [generic] | Clarify first: what the record shows and what the member has been told. Then the member first, one named owner, an interim reply in plain words, the cause of the wrong resolved status, and the branch supervisor's position heard before you decide. Say which part you would check first and what you would need from the contact centre. Do not claim you have handled such a case. | Scored on Own the Fix, Members First, Plain Words and Neighbours at once. The scenario is invented, so it is generic. The contact-centre gap (F2) is what a bluff would show. |
| C6 | "A supervisor refuses to accept a decision you've made on a complaint. What do you do?" | JD | [grounded] "I handled the branch's formal complaints log" (your message) | Hold the decision if the member's outcome depends on it. Say what you would test with the supervisor, in your own words. Hold through two follow-ups before conceding anything. Concede the local context you have not seen, specifically. | Pressure, hold-then-concede, on the coaching line. The hold rests on the log work, and no past event is supplied. |
| C7 | "A branch on the consolidation list has complaints open today. What do you tell its staff?" | CO | [grounded] "consolidate eight branches into five hubs over 2027" (the strategy brief as summarised in your message) | Say what you would do for members with open complaints during the move, and what you would not say before you were briefed. Do not speculate on which branches close. | Pressure on Neighbours. The hub line is the sensitive one for branch managers on this panel. |
| C8 | "How would you coach a supervisor who escalates everything?" | JD | [generic] | Plan: review a few escalations together, agree what justifies escalating, then check the next month's cases. No claim about past coaching. | The JD's coaching line asked as a plan, from the branch side. |
| C9 | "Name the first measure you would put on complaint resolution, and the assumption it rests on." | JD | [generic] | One measure, why it matters to a member, and the assumption you would defend least. Say it in one breath. | The JD's resolution-times line. Your material has no headline figure, so there is no defend-the-number question. |

**Requirement coverage.** Every JD requirement maps to at least one question, or says why it does not.

| JD requirement | Covered by |
|---|---|
| Own the complaints process end to end across branches | B1, B4, C5 |
| Report monthly on volumes and resolution times | A5, B5, C9 |
| Coach branch supervisors on escalations | B6, C6, C8 |
| Work with digital teams on self-service journeys | B8, B9 (answer slot only; your material is silent) |
| 4+ years in financial-services customer operations | A1 |
| Experience handling regulated complaints | A4, B3 (regulated question in the answer slot) |
| Confident presenting to senior leaders | B7, A8. None of the three rounds asks you to present; the gap is still probed through B7 and A8 |
| Comfortable with Excel reporting | A5, A6 |

Session total: 26 questions. Depth follows persona weight.

## Values cheat sheet (R3)

The values are the four published on the company's values page, copied on 11 November 2026. Only the quoted sentences in the fit snapshot count as your stories. Where none carries a story, the honest branch is given.

| Value | Working meaning | Your mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | F1 carries no story about a member's decision. Selection: pick one complaint from the log where the member's side changed what you decided; say what changed. If none did, say so plainly, then say how you would check a decision from the member's side. |
| Plain Words | If a member needs it explained twice, the wording was wrong | F8 carries training, not a member's second explanation. Selection: pick a script or letter a member had to ask about twice; say what you changed. If you changed nothing, say so, then say how you would test a letter for plain words. |
| Neighbours, Not Numbers | Every branch is part of its town | No quoted sentence carries a story. Say so plainly, then give the principle you would use and how you would test it in a branch you did not know. |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | F1 is the closest. Selection: pick one complaint you followed to close; say what you kept hold of. If you handed one on, say to whom and what you checked. |

## Grounding brief

Built from the strategy points in your message. The brief itself was not pasted, so this uses your summary only.

- Digital shift: move 40% of member service to digital channels by 2028. [grounded]
- Branch network: consolidate eight branches into five hubs over 2027. [grounded]
- Lending: launch a small-business lending product in Q1 2027. [grounded]
- Competition: the main competitive pressure is app-only banks. [grounded]
- Read-across to complaints (a reading, not a fact about the company): the digital shift changes what the monthly report sees, and the hub move puts complaint handling in a different place for branch staff. Both are reasoning from the brief, not claims about its content. [inferred]

## Reverse questions

Each one carries why it lands. No interviewer profile exists, so these are role-generic. The R3 round has no peer seat, so no reciprocity question is included.

| Round | Question | Why it lands |
|---|---|---|
| R1 | "Which of the four values carries the most weight with the panel, and how do they score them?" | Shows you read the panel brief and plan to be scored on the values. |
| R1 | "What does the Head of Member Services most want to change in the complaints process over the next year?" | Points your R2 preparation at the manager's own priorities. |
| R2 | "Where do complaints get stuck today between the branches and the contact centre?" | Signals Own the Fix and shows you are already thinking about the handoff. |
| R2 | "What would a strong first 90 days look like, and what would I be expected to have inherited?" | Manager-altitude question; it reads as ownership, not as a request for a job description. |
| R2 | "Who reads the monthly complaints report besides the regional manager?" | Shows you are thinking about the report's audience, which is the senior-leader presenting gap in a useful form. |
| R3 | "When a branch and the contact centre disagree about a complaint's outcome, who decides today?" | Tests the ownership line directly. The answer tells you where the process actually breaks. |
| R3 | "As more service moves to digital, how should a branch manager see the complaints that come from the app?" | Connects the strategy to the branch side. Asked while the hub plan is still moving, it does not presume a closure. |
| R3 | "What does a good escalation look like to you, when a supervisor gets it right?" | Gives the panel a way to describe the coaching standard, which you can match in C8. |

## Sources

**Provided documents**

- JD text, as you sent it (your message)
- Company values, copied from the company's values page on 11 November 2026 (your message)
- Recruiter's process email: three rounds on 20 November, round structure, and the panel's values scoring (your message)
- Strategy points from the July 2026 strategy brief, as you summarised them (your message)
- Your background: six years in retail banking, three as a branch supervisor; complaints log; escalation training; monthly spreadsheet; no contact-centre work; no presenting above regional level (your message)

**Searches and fetches:** none sent.

**Research tier: L1, searches 0 of 6, fetches 0 of 2**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | Values cheat sheet and R3 values questions. The four values are pasted, so the input fixes them. |
| 2. Ashgrove interview process, role family | skipped | Round structure and persona weights. The recruiter's email fixes the three rounds and their lengths. |
| 3. Ashgrove strategy / recent news | skipped | Grounding brief and CO questions. The points you pasted fix the headline items; a search could add detail beyond the brief's headlines, and the pack does not use it. |
| 4. Interviewer name and company | n/a | No interviewer name was given, so there was no query to form. The upgrade menu says what a name would unlock. |
| 5. Representative JD for the role title | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions. |

## Upgrade menu

- The strategy brief itself (or the page it came from) → the grounding brief quotes its wording, not your summary
- The recruiter's note on any presentation or written exercise, if one is planned → a graded-deliverable section
- The names of the R2 and R3 interviewers, when assigned → persona weights per interviewer and an interviewer read
- Your CV text → fit rows cite it as your CV, and any figure on it raises defend-the-number questions
- Your answers to the answer slots (F1, F3, F4, F6, F9, and the C2 and C4 slots) → each row upgrades from a slot to a quoted line, only if you state the facts yourself
- The tool you use for reporting (F4) → A6 and the Excel row can name it
- Prep time before 20 November → a prep-triage schedule
