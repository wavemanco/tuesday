Your prep pack is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-alone-part-2-rooms-case-4-denied-425b6bb2/c9bb7a4d-c7f3-46f7-bf68-00559063152f/scratchpad/quartzline_product-manager-platform-apis_interview_pack.md`.

Three things to know before you open it:

- **Thursday is tomorrow.** Today is Wednesday 11 November, so the interview is Thursday 12 November.
- **Research didn't run.** The web search was refused by the host, so the pack has no company values, interview-loop structure or current strategy. The banks are generic on company strategy.
- **The dossier is about three months old.** It's dated 14 August, so check the JD hasn't changed.

The pack is built on the dossier only, since no CV was supplied. It treats your bridge as integration leadership and never as PM experience. The question it marks as highest-ROI prep is the one the underwriter named: "You've never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" Rehearse that one first. Hold the integration work, then concede the roadmap specifically.

Two questions to ask the hiring manager are worth using, since the dossier flags both as unresolved: which roadmap decisions this PM makes alone versus the squad leads, and how partner API adoption is measured today, with the current baseline.

If you tell me how many hours you have before Thursday, I can turn the pack into a prioritised schedule.

I can also run a live drill with me playing the Skeptic on the highest-ROI question, which is the most useful rehearsal in the pack.

I can also save a `tuesday-dossier.md` with `pack_feedback` recording what this prep exposes, for you to carry forward.

If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quartzline_product-manager-platform-apis_interview_pack.md -----
# Interview pack: Product Manager, Platform APIs at Quartzline

**Round:** Hiring-manager round, 45 minutes. Interviewer name not given.
**When:** Thursday. Today is Wednesday 11 November 2026, so Thursday is 12 November. Check this against your calendar.
**Basis:** Your job-underwriter dossier (dated 2026-08-14, decision `conditional_go`). No CV was supplied, so the candidate evidence below is only what the dossier's verified entries contain. This is the first pack for this role.

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored.
- Type key: **VAL** behavioural/values, **EXP** work-experience deep-dive, **JD** role-driven, **CO** company and strategy, **CASE** live problem.
- Guidance is scaffolding for a spoken answer, not a script.
- An *answer slot* is an instruction for the interview: it is addressed to your answer, not a question to me.
- Your bridge is **adjacent integration and platform leadership**. Never present it as product-management experience. The pack will not coach the claims in section 13.

## The fit snapshot

Requirements are quoted from the dossier's `role_profile` (R1 to R5). Evidence is quoted from its `verified_candidate_evidence` (E1 to E3), numbered by position in that list.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" (dossier role_profile R1, must-have) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier E1) | low | [inferred] | transferability | Length of experience is not a gate, so this is a fit question. The bridge is the dossier's transferability read: E1 is adjacent work, not PM work. Say the quote at its own scope and name the limit yourself: integration leadership, not a product-management role. |
| F2 | "Owning a roadmap and prioritization authority (R1 sub-claim)" (dossier uncertain_or_weak_areas, acknowledge_gap) | none given | none | [grounded] | capability | Words come only from the dossier's `acknowledge_gap` area: "I haven't owned a product roadmap." Then a ramp plan, said as a plan. No bridge is coached here. |
| F3 | "Shipped API or platform products" (dossier role_profile R2, must-have) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier E1) | high | [grounded] | transferability | Say the quote at its own scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs, from scoping through go-live." The limit is the pack's observation: these were integrations built on someone else's API, not an API product you shipped. Any wider step is an answer slot inside the quote's scope. |
| F4 | "Technical fluency: API docs, schemas" (dossier role_profile R3, important) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier E1) | low | [inferred] | discovery | "Architecture" touches the requirement but does not show whether docs or schemas were involved. Answer slot: if you wrote, reviewed or changed API docs or schemas, say which and how. If you did not, say so and say what you would learn first. |
| F5 | "Stakeholder management across engineering, sales, customers" (dossier role_profile R4, important) | "Ran quarterly roadmap-input sessions feeding client evidence to product" (dossier E3); "Wrote the internal integration playbook her team uses" (dossier E2) | medium | [grounded] | transferability | Confirmed but with limited inspectable proof, so expect a probe on E3. Customer and product work is what the quotes reach. Engineering and sales are not in any quote, so do not claim them. Name the caveat before it is extracted: the sessions gave client evidence to product; they did not decide the roadmap. |
| F6 | "Agile delivery experience" (dossier role_profile R5, preferred) | none given | low | [inferred] | discovery | No verified entry speaks to agile, so there is no quote to bridge from. Answer slot: say how you have worked with delivery teams, in your own words. If you have not worked in an agile team, say so, and say what you would expect to learn first. |

**Confidence and gap type routing.** No requirement is a gate: the dossier lists no hard gates, and R1 is a length-of-experience requirement, not a credential. So no `hard_gate` row appears.

## Prohibited claims

Each entry names its basis, and each has one honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | Sourced: dossier prohibited_claims: "Having held a product manager title or role" | Plain acknowledgment: "I haven't held a product manager title or role." Then the F1 quote at its own scope. |
| Having owned a product roadmap | Sourced: dossier prohibited_claims: "Having owned a product roadmap" and acknowledge_gap | Plain acknowledgment: "I haven't owned a product roadmap." Then the E3 quote at its own scope: you ran the input sessions, not the roadmap. |
| Having set prioritization for an engineering squad | Sourced: dossier prohibited_claims: "Having set prioritization for an engineering squad" | Plain acknowledgment: "I haven't set prioritization for an engineering squad." E3 is input to product, not prioritization, so do not let it drift there. |
| Shipped an API or platform product of your own | Inflated form of F3: the wording stretches E1, which is integrations of the vendor's API | The E1 quote at its own scope. The limit is the pack's observation of the material, not a first-person negative: your material shows integrations, not a product you shipped. |

## Persona table

Hiring-manager priors are Case/Strategist and Skeptic. The dossier also names one likely objection, which is Skeptic-born. Weights are shown so you can adjust them.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet, persistent probing of the R1 gap and "why you, why now" | **High, weight 5.** The dossier's named objection sits here, and R1 is must-have | Rehearse A1 until it is boring. Hold the bridge, then concede the roadmap specifically |
| Case/Strategist | Live roadmap problems on the two squads and partner discovery | **High, weight 5.** Hiring managers buy capability and derisk gaps with live problems | Clarify the decision rights first, then structure. The decision-rights question is unknown in the dossier, so ask it |
| Pressure | Interruptions and "how much was actually you" on E1 and E3 | **Medium, weight 3.** E3 is medium confidence, and the roadmap is the sharpest point of pressure | Pause, restate, hold through two follow-ups, then concede the specific gap |
| Data-Driven Prober | Counts and assumptions behind "30+" and the sessions | **Medium, weight 3.** E1 carries a count, and the dossier says no adoption baseline exists | Defend the number in your own words and name the weakest assumption before they do |
| Conversational | Open arc, "walk me through," and a closing "any questions?" | **Low, weight 2.** Casual openers are still scored | Prepare a 90-second arc from quoted material only. Never answer the closing slot with "no questions" |
| Values/Behavioural | Not in this pack | **Not weighted.** No values round was detected; this is a hiring-manager round | None |
| Peer Evaluator | Not in this pack | **Not weighted.** The interviewer is the hiring manager | None |

## Question banks

**Requirement coverage**

| Requirement or responsibility | Questions |
|---|---|
| R1 "3+ years product management experience" | A1, A2, C1, E1 |
| R2 "Shipped API or platform products" | A3 |
| R3 "Technical fluency: API docs, schemas" | B5 |
| R4 "Stakeholder management across engineering, sales, customers" | A4 |
| R5 "Agile delivery experience" | A5 |
| Responsibility: own the roadmap for the partner API platform | A2, B4 |
| Responsibility: run discovery with integration partners | B1 |
| Responsibility: write specs and drive delivery with two squads | B2 |
| Responsibility: define and track adoption metrics | B3, D3 |

Every JD-tagged requirement has at least one JD-tagged question. No requirement is left without a question.

### A. Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] dossier E1 "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; dossier prohibited_claims "Having held a product manager title or role" and "Having owned a product roadmap"; dossier acknowledge_gap "Owning a roadmap and prioritization authority (R1 sub-claim)" | **Hold, then concede.** Open with the plain acknowledgment: "I haven't held a product manager title or role, and I haven't owned a product roadmap." Then the bridge, with its limit named: "I led 30+ end-to-end client integrations of the vendor's REST APIs, from scoping through go-live." Say that this is integration leadership, not roadmap ownership. Then your ramp plan, as a plan: which roadmap decisions you would learn first. Hold through two follow-ups by returning to the integration scope, never by adding a roadmap or prioritization decision. Answer slot: if you had any say in what partners were asked to prioritise, say what it was, in your own words. If you had none, say so and stay with the ramp. | The underwriter named this as the likeliest objection, so it is the highest-ROI prep in the pack. F1 and F2 are its sources. Typed JD because it scores R1 as written. Its negatives are sourced from the dossier's prohibited_claims and acknowledge_gap fields, so it is asked as the underwriter wrote it. |
| A2 | "What part of a platform roadmap have you owned yourself?" | JD | [grounded] dossier E3 "Ran quarterly roadmap-input sessions feeding client evidence to product"; dossier acknowledge_gap "Owning a roadmap and prioritization authority (R1 sub-claim)" | Plain answer: "I haven't owned a product roadmap." Then E3 at its own scope: you ran the input sessions and fed client evidence to product. Answer slot: if you chose anything on a roadmap, say what and how you decided. If you did not, say so and return to the input sessions. | F2 is capability, so the honest answer is a limit with a ramp. The premise of "owned" is the JD's roadmap line, and the second branch lets it be false. |
| A3 | "Which of your integrations went live, and what was your part in the go-live?" | JD | [grounded] dossier E1 "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Story-mapped on E1: scoping, requirements, architecture, UAT and go-live are the beats the quote states. Name what you scoped and what you took to go-live, in your own words. Limit: these are integrations of the vendor's API, not an API product you shipped. Say that before they ask. Answer slot: if you shipped any API product of your own, say what it was and your part in it. If you did not, say so and stay with the integrations. | F3 is the evidence for R2, and R2 is must-have. A premise of a shipped product is not in any quote, so the second branch lets it be false. |
| A4 | "Tell me about a time you managed stakeholders across engineering, sales and customers at once." | JD | [grounded] dossier E3 "Ran quarterly roadmap-input sessions feeding client evidence to product"; dossier E1 "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Open prompt. Choose a time you held a decision across people who wanted different things. Use the customer and product path in E3 and E1. Engineering and sales are not in any quote: if the nearest example you have is client-to-product, say that, and do not claim engineering or sales work. If no such time comes to mind, say so plainly, then give the nearest thing your material carries. | F5 is the evidence for R4, with a medium-confidence caveat on E3. Engineering and sales are the thin side, and a Skeptic probes thin sides. |
| A5 | "Describe the delivery cadence you have worked in, and where you have worked agile." | JD | [inferred] dossier uncertain_or_weak_areas: "Agile delivery inside a product org (R5)", discovery, clarify. No verified entry speaks to agile. | Clarify. Say what cadence your integration projects followed, in your own words. Then the honest form: "Here's what I'd want to confirm about how you define agile delivery." Second branch: if you have not worked in an agile team, say so, and say what you would expect to learn in the first month. | F6 is discovery, and the dossier's strategy is clarify. Nothing is quoted because nothing in the evidence speaks to agile. |

### B. Case/Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Partner integrations are stalling after go-live, and adoption has been flat for three months. What do you do in your first 30 days?" | CASE | [generic] | Clarify the objective first: adoption for which partners, measured how. Segment the partners. Then the approach, then the metrics, then the risks. Think aloud, and name one premise you would challenge. | Live problem from the JD's partner discovery line. It presupposes nothing about your past. |
| B2 | "Two engineering squads and one partner API roadmap. A partner asks for a breaking change, and one squad says no. How do you decide?" | CASE | [generic] | First ask who holds the call between you and the squad leads. The dossier lists this as unknown, so asking is the answer, not a dodge. Then the criteria and the people you would consult. Do not claim the decision is yours. | Tests the unknown in the dossier, decision authority versus the squad leads. |
| B3 | "How would you define and measure adoption for a partner-facing API?" | JD | [generic] | Name the metric, the denominator and the cohort. State the weakest assumption behind your choice before they do. Then the reverse question on the current baseline. | JD responsibility "define and track adoption metrics." The dossier states no current baseline. |
| B4 | "You have three partner requests and one platform backlog. How would you prioritise them?" | CASE | [generic] | Ask what the backlog's constraints are. Name your criteria. Say whom you would consult, and confirm with the squad leads who holds the engineering call here. Do not state a prioritisation authority you do not have. | Tests the R1 sub-claim as a live problem, without asserting that you have prioritised anything. |
| B5 | "A partner tells you the docs are why they stalled. What would you change first?" | JD | [generic] | Answer slot: if you have written or reviewed API docs or schemas, say which and what changed. If you have not, say so, and say what you would check first in the docs. | F4 is discovery for R3. This is the R3 probe, asked as a problem. |

### C. Pressure (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Sixty seconds: why you over a PM with three years in the job?" | JD | [grounded] dossier E1 "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; dossier E2 "Wrote the internal integration playbook her team uses"; dossier prohibited_claims "Having held a product manager title or role" | **Hold, then concede.** Hold with E1 and E2, at their own scope: integration leadership and the playbook. Concede specifically: "I haven't held a product manager title or role, and I would expect a PM with that background to ramp faster on roadmap decisions." Hold through two follow-ups by returning to E1 and E2. Concede only the roadmap. | Pressure on R1, the same gap as A1 in a shorter time box. The concession must be specific, not a general "I'm not perfect." |
| C2 | "That integration playbook — how much of it did you actually write, and how much did your team write?" | EXP | [grounded] dossier E2 "Wrote the internal integration playbook her team uses" | Say what you wrote and what you edited, in your own words. Hold to the word "wrote." Do not extend it to "designed the team's process." | Attribution test on E2, which is high-confidence and inspectable. The playbook is inspectable, so the question is about the share. |
| C3 | "You ran roadmap-input sessions, so the roadmap was yours in practice?" | EXP | [grounded] dossier E3 "Ran quarterly roadmap-input sessions feeding client evidence to product"; dossier prohibited_claims "Having owned a product roadmap" | Hold: "I ran the sessions, and they fed client evidence to product." Concede: "No. The roadmap decisions weren't mine." Do not let "input" become "decision." | E3 is medium confidence, and this question tests whether you inflate it under pressure. |

### D. Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You've done 30+ integrations. Walk me through how that count was made: what's in it and what's out?" | EXP | [grounded] dossier E1 "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Defend-the-number slots, in your own words. How the count was made: answer slot, and if none was kept, say so. What it is sensitive to: answer slot. The assumption you would defend least: name it before they do. Which part was yours: say it plainly. | E1 is a headline count, and counts are where probers go first. The method is not in any quote, so the guidance supplies none. |
| D2 | "How did you know the evidence from those sessions reached product?" | EXP | [grounded] dossier E3 "Ran quarterly roadmap-input sessions feeding client evidence to product" | Answer slot: if you tracked whether the evidence reached product, say how. If you did not, say so and say what you would track. | E3 is medium confidence with limited inspectable proof, so this probe is likely. |
| D3 | "Which adoption number would you trust least, and why?" | JD | [generic] | Name the number, the assumption behind it, and what would change your mind. Do not invent a baseline. If you have tracked an adoption figure, say how it was counted. | Responsibility "define and track adoption metrics." The dossier says no baseline exists. |

### E. Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey to here." | EXP | [grounded] dossier E1 "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; dossier E2 "Wrote the internal integration playbook her team uses"; dossier E3 "Ran quarterly roadmap-input sessions feeding client evidence to product" | A 90-second arc from these three quotes in order: integrations, then the playbook, then the client-to-product sessions. End with the gap said plainly: "The part I haven't done is own a product roadmap." | Casual openers are scored. The arc is written from quotes only, so it can be defended. |
| E2 | "What have you been reading about partner API platforms lately?" | CO | [generic] | Name one thing you have read, in your own words. If nothing recent comes to mind, say so plainly. Do not recite a consensus list. | No research ran, so this is a role-family pattern and not a company claim. |

## Reverse questions

Five questions. Each is a point where the dossier records an unresolved risk.

1. **"Which roadmap decisions does this PM make alone, and which belong to the squad leads?"** *Why it lands:* decision authority versus the squad leads is asserted in the JD but not evidenced. Asking it converts the Skeptic's probe into diligence.
2. **"How is partner API adoption measured today, and what is the current baseline?"** *Why it lands:* the JD names adoption as a responsibility, but the dossier states no current baseline.
3. **"What would you need the person in this seat to have decided by the end of the first 90 days?"** *Why it lands:* it tests whether the role's decision rights are real, and it answers B2's unknown.
4. **"What did the last person in this seat do with their first sixty days?"** *Why it lands:* it shows how the role has actually run, which the JD does not show.
5. **"What would make you call this hire a success at six months?"** *Why it lands:* it asks the hiring manager to name the outcome, which makes the adoption question concrete.

## Prohibited claims: check

The list in section 13 binds every cell above. The question banks cite the dossier's own prohibited_claims items by their field name, and no answer slot names a listed claim as fact.

## Sources

- **Provided:** `tuesday-dossier.md`, version 1.1, generated 2026-08-14, decision `conditional_go`. Consumed sections: `role_profile` (R1 to R5 requirement text, unknowns), `verified_candidate_evidence` (E1 to E3, by position), `uncertain_or_weak_areas`, `likely_interviewer_objections`, `opportunity_risks_to_validate`, `questions_for_employer`, `prohibited_claims`, and `decision`. Not present in the dossier: `evidence_map`, `evidence_state` and `risk_register`, so the fit snapshot and risk items come from the sections it did supply.
- **Dossier age:** about three months old. The JD may have changed since August.
- **No CV was supplied.** Candidate evidence is the dossier's verified entries only.

**Research tier: L1 — searches 1 of 6, fetches 0 of 2**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quartzline values` | unavailable | Search refused by the host: permission was not granted. Would have confirmed whether a values round applies. This round is hiring-manager, so no values section would be built either way. |
| 2. `Quartzline interview process product manager platform APIs` | unavailable | Same refusal. Would have moved persona weights if a loop structure were published. |
| 3. `Quartzline strategy` / recent news | unavailable | Same refusal. Would have fed the CO bank with current strategy. The reverse questions and banks above are therefore generic on company strategy. |
| 4. Interviewer name and company | n/a | No interviewer name given, so there was no query to form. |
| 5. Representative product-manager JD | skipped | The dossier's `role_profile` fixes the requirements, so a representative JD would move nothing. |

Search sent: `Quartzline careers product manager platform APIs interview process values` (standard), refused. It is the single call that counts toward the tier.

## Upgrade menu

- Hours you have before Thursday → a prioritised prep schedule, with the highest-ROI rehearsal first (A1).
- Interviewer's name → an interviewer read, persona weights from their public footprint, and a tailored reverse question.
- Search permission on the next run → the three refused targets above, which would tighten persona weights and add company-strategy questions.
- Quarterly input-session output, such as a written summary → lifts E3 from medium toward inspectable proof, which strengthens A2, C3 and D2.
- A current JD, if it has changed since August → refreshes R1 to R5 and any rows they move.
- The answer to reverse question 1 → turns B2 from an unknown into a premised question.
