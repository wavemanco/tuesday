Your prep pack is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-alone-part-2-rooms-case-5-denied-c728dc90/66e442d9-2fe6-4d2a-8e97-c84b28c61b70/scratchpad/kelverton_senior-partnerships-manager_interview_pack.md`.

Web search was refused on this host, so the pack has no Kelverton values, interview-process, strategy or interviewer research. Those gaps are listed in the Sources section. The POV theses are general reasoning about the rail operator market, and they need checking against the internal report before you rely on them.

The most important prep is B1: "You've never sold into rail." Rehearse a plain acknowledgement, then the nearest thing your experience supports, and hold that position through two follow-ups. The POV section has three theses, each with a concession, and the close Deepa and Ross asked for: what it means for the operators.

Say the word and I'll play Ross on C1 and score your answer against that question's guidance. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed. If you'd like the pack as a Word document, say so and I'll convert it.

Two things would strengthen it:
1. Can you paste the job description? If not, I'll keep the pack as it is, built on the recruiter's own requirements.
2. Can you paste the market report's key points, meaning its segments, headline numbers and the shortlist it recommends? The POV can then be checked against it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: kelverton_senior-partnerships-manager_interview_pack.md -----
# Kelverton Rail: Senior Partnerships Manager, second-round panel

Panel: Deepa (VP Partnerships, your future manager) and Ross (Commercial Director). 60 minutes: first 15 minutes a spoken POV on operator partnerships over the next 18 months, no slides, landing on what it means for the operators themselves; the rest is Q&A, with Ross pushing on commercials.

Built without research. Web search was refused on this host, so the company, process and interviewer facts below are not established; see Sources.

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored.
- Type key: **VAL** behavioural/values; **EXP** your experience, tested for attribution; **JD** the role's stated requirements (here, the recruiter's own words); **CO** company and strategy knowledge; **CASE** a live problem.
- Guidance is scaffolding, not a script. Rehearse it aloud, in your own words.

## Prep triage (about 4 hours)

1. **75 min: build the POV.** Choose one thesis, write its concession, write the operator-level close. Say it aloud three times, timed to about 8 minutes. (Section "The POV".)
2. **45 min: commercials drill.** C1, C2, D1, D3. Answer each in about 90 seconds, out loud.
3. **40 min: the rail gap.** B1 and B2. This is the highest-return rehearsal in the pack: a plain acknowledgement, then a plan, held through two follow-ups.
4. **20 min: reverse questions.** Pick three from the list and know why each lands.
5. **Remaining 40 min:** A1 and A2 walk-through, E1 arc.

Everything else is insurance.

## The fit snapshot

No job description was supplied, so the requirements below are the recruiter's own words, quoted. Candidate evidence is quoted from your message only.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "where you'd take our operator partnerships over the next 18 months" — recruiter email | "9 years in partnerships" — your message; "took it from 6 partners to 40, roughly £4M of influenced revenue" — your message | medium | [grounded] | transferability | Your material shows a channel, not operators, and the words stay there: "took it from 6 partners to 40." Answer slot: if you set any direction for that channel, say which and what would carry over to operators. If you did not set one, say so, and say how you would learn the operator side first. |
| F2 | "Please land on what it means for the operators themselves." — recruiter email | "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" — your message | medium | [grounded] | none | Your own words give the operator side, from network planning: "so I know the operator world from the other side." Nothing needs bridging. The POV builds the operator angle from that sentence. |
| F3 | "Ross will push on commercials." — recruiter email | "took it from 6 partners to 40, roughly £4M of influenced revenue" — your message; "never carried a direct quota, only influenced revenue" — your message | medium | [grounded] | transferability | Your material says influenced revenue, not revenue you carried. The stated limit is "I've never carried a direct quota." Answer slot: if you can say how the influence was measured, say it in your own words; if you cannot, say so. |
| F4 | "our operator partnerships" — recruiter email | "Never sold into rail specifically" — your message | none | [grounded] | capability | A gap you stated, so the words are yours: "I've never sold into rail specifically." Then how you would learn the rail buying side, said as a plan, never as a past. |

**Pack observation (analysis, not words for you):** the material shows partnership growth in a payments channel and network planning in transport. It does not show operator partnership management or any rail selling.

### Requirement coverage

| Requirement (source) | Covered by |
|---|---|
| "where you'd take our operator partnerships over the next 18 months" (recruiter) | A1, A2, A3, A4, A5 |
| "Please land on what it means for the operators themselves." (recruiter) | A1, E1, the POV section |
| "Ross will push on commercials." (recruiter) | C1, C2, C3, C4, D1, D2, D3 |
| "our operator partnerships", with rail selling not established (F4) | B1, B2 |
| POV, first 15 minutes (recruiter) | A1 and the POV section |
| Fit as future manager (Deepa's role) | B3, B4, E2 |

No requirement is left uncovered.

## Prohibited claims

Built locally from the fit snapshot. Nothing in this pack may assert these, soften them, or imply them.

| Not coached | Basis | Honest form |
|---|---|---|
| "I owned operator partnerships" or "I worked with operators on partnerships" | Inflated form of F1 and F2: the material shows a payments channel and network planning, not operator partnerships | F1 and F2 quoted at their own scope. The limit is the pack's observation: the material does not show operator partnership management |
| "I've sold into rail" or any rail sales experience | Stated negative, F4 | Plain acknowledgement: "I've never sold into rail specifically." No slot |
| "I carried a quota" or "I hit a target" | Stated negative: "never carried a direct quota" | Plain acknowledgement: "I've never carried a direct quota." No slot |
| "I grew £4M of revenue" | Inflated form of "roughly £4M of influenced revenue" | The quote at its own scope: "roughly £4M of influenced revenue" |

## The POV

A graded deliverable: the recruiter pre-declared it (first 15 minutes, no slides). Build it so the operator is the subject of every paragraph.

**Grounded facts to build on**
- F1 evidence: "took it from 6 partners to 40, roughly £4M of influenced revenue" (your message). Use it only as the scale of partner work you did, with the influence scope kept.
- F2 evidence: "so I know the operator world from the other side" (your message). This is the honest way to speak to operators' side of the table.

**Three theses, each with a mandatory concession** (all theses are [generic] reasoning about the role; none is a claim about Kelverton's operators, which this pack could not establish)

- **T1. Plan partnerships around the operator's own delivery measures, not partner count.** Concession: I have not seen Kelverton's operators' measures. This holds only if operators judge partners on delivery, which I would need to check.
- **T2. Share the outcome: structure operator deals so the partner carries some of the result.** Concession: outcome-linked terms move risk onto Kelverton, so it only works if the margin supports it. I would want the market report's view on margin before committing.
- **T3. Line partnership timing up with the operator's contract and planning cycles over the 18 months.** Concession: I do not know those cycles for Kelverton's operators. The report should show them, and it is the first thing I would check.

**Differentiation from the likely consensus.** The consensus answer is more partners, more integrations and more co-selling. The anti-pick: do not chase partner numbers in 18 months; go deeper with fewer operators and say so. This is judgement, not a finding about Kelverton. If the internal report lists a shortlist, check your thesis against it: you need one consensus point to show you read it, and one thesis-driven departure.

**The close (requested by the recruiter).** End on what changes for the operator, in one sentence: name the one thing an operator's planning team would see differently. Keep it to an outcome you can defend, not a number.

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | POV follow-ups; live operator problems | High, weight 5. The POV is a case by another name, and the hiring-manager prior puts this first | Clarify, then structure, then one metric; name the one premise you would test |
| Skeptic | "Why you, given no rail sales?" | High, weight 4. Deepa is the future manager, the hiring-manager prior puts Skeptic beside Case, and F4 is the obvious gap | Plain acknowledgement, then a plan; hold through two follow-ups; concede the specific limit |
| Pressure | Interruptions on commercials; "how much of it was you?" | High, weight 4. Ross is Commercial Director and the recruiter said Ross will push on commercials | Pause, restate the question, hold the stated scope, then concede the specific limit |
| Data-driven Prober | How figures were counted; denominators; assumptions | Medium, weight 3. The £4M is the only headline number, so it draws the probe | Say how it was counted in your words, or say you do not know; name the weakest assumption first |
| Conversational | Opening biography; the reading question | Low, weight 2. The first 15 minutes are already structured, but casual openers are still scored | Rehearse one 90-second arc from your quoted sentences |
| Values / Behavioural | Stories of unwelcome truths; customer over metric | Low, weight 2. No values round is detected: no loop source established the loop, and the archetype is unknown. Kept at two for coverage | Selection scaffold; say so plainly if no story comes |

Weights come from the roles the recruiter named. No public footprint for Deepa or Ross was established, so no interviewer tilt is applied.

## Question banks

Session total: 20 questions. The highest-ROI prep is **B1**.

### A: Case / Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Take us through your point of view on where we should take operator partnerships over the next eighteen months." | CASE | [grounded] "present a short POV on where you'd take our operator partnerships over the next 18 months" — recruiter email | Use the POV section. Open with what changes for the operator, then one thesis, its concession and the close. Aim for about 8 minutes so the rest of the 15 is for follow-up. Say the concession aloud; do not bury it. | The recruiter named this as the graded first 15 minutes. CASE because it scores structure and altitude. The only source is the recruiter's words, so the guidance makes no claim about your history. |
| A2 | "What would have to be true for an operator to change how it buys partnership services from us?" | CASE | [generic] | Clarify first: which operator, which buying decision, who signs. Then a hypothesis: the change is driven by contract timing, delivery pain or budget owner. Test the biggest one with one data point you would ask for. | Tests the clarify-then-structure habit a case interviewer scores. Generic because it names no fact about Kelverton's operators. |
| A3 | "You have three operators and time for one partnership push this year. How do you choose?" | CASE | [generic] | Criteria in order: exposure to the change in A2, an existing relationship you could use, and whether the operator can co-deliver. Name the trade-off you accept. | A live problem from the operator focus of the role. Asks nothing about your past. |
| A4 | "Operators buy differently from one another. How does that change your plan?" | CASE | [generic] | Segment before you generalise: name two or three operator types by how they buy, then say which one the POV is built for. | Pressure on the POV's single-operator assumption. No claim about you. |
| A5 | "What would you learn in your first thirty days before proposing anything to an operator?" | CASE | [generic] | Name three inputs: how operators decide on partnerships, what the internal market report says, and what your colleagues on the sales side have seen. Say them as a plan, not a past. | Gives the F4 gap an answer as a plan, without claiming experience. |

### B: Skeptic (Deepa, weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've never sold into rail. What makes you credible on operator partnerships here?" | JD | [grounded] "Never sold into rail specifically" — your message; "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" — your message | The highest-ROI rehearsal in this pack. Start with the plain acknowledgement: "I've never sold into rail specifically." Then the nearest thing your material carries, in your words: "bus and light rail network planning" and "so I know the operator world from the other side." Hold through two follow-ups by returning to those sentences, not adding to them. When pushed, concede the specific limit: "I haven't done the buying side in rail, and that's the part I'd learn first." Do not fold on the network planning. | F4 is the gap, and this objection will land in some form. A calm acknowledgement, then a held position, changes how the rest of the interview is heard. |
| B2 | "I don't see rail sales in your background. How would you handle that in this role?" | JD | [grounded] "Never sold into rail specifically" — your message | A ramp plan, said as a plan: name the first two things you would do, and what you would have in writing after the first month. Do not say you have done any of it. | The skeptic's stem. Calibrated candour with a ramp plan beats bluffing a competency the interviewer owns. The plan elements are [generic]. |
| B3 | "Why would you leave a payments company for a rail-tech business of around six hundred people?" | JD | [grounded] "last 4 at a payments company running the ISV channel" — your message; "so I know the operator world from the other side" — your message | The material gives no reason for leaving. Answer slot: give the reason in your own words. If it is the operator side, say what you mean by "the operator world from the other side," and do not add a trigger the material does not show. | Motivation is the Skeptic's favourite probe. The reason is yours to give, so the pack supplies a slot, not a story. |
| B4 | "Where would running an ISV channel tell you least about working with an operator?" | JD | [grounded] "running the ISV channel" — your message | Name the limits first: the two things that would not carry across, in your words, then the one thing that would. A specific limit lands better than a general claim of transferability. | Turns the transfer question into candour. The Skeptic scores whether you know the limits of your own experience. |

### C: Pressure (Ross, weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "In sixty seconds: why should we trust a revenue figure you never carried?" | EXP | [grounded] "never carried a direct quota, only influenced revenue" — your message | Hold: the figure is influenced revenue, and you can say what that means. Concede: "I never carried a direct quota, so I can't give you quota attainment." Hold through two follow-ups by restating the scope, then concede the specific limit. Do not fold on the influence itself. | Pressure tests composure and whether you concede without folding. The hold uses only your own stated scope. |
| C2 | "Your £4M of influenced revenue. What was yours in that number?" | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" — your message | Answer the scope as the sentence states it: influenced, roughly £4M. Answer slot: if you led any part of that revenue, say which and what you did. If you did not, say so plainly, then say what your part was, in your words. Do not claim a deal you did not run. | Ross's attribution pressure. The honest answer is the scope in your words. |
| C3 | "Operators have fixed budgets. What would you give up to win one?" | CASE | [generic] | Name the trade explicitly: margin, term length or scope. Choose one and say why. Concede the cost of that trade-off plainly. | A commercial trade-off probe. No claim about you. |
| C4 | "A partnership clears on volume but loses money. Would you back it?" | CASE | [generic] | State the condition you would need before backing it (a margin floor, a term, or an exit), and say what you would stop. Hold that condition through the second follow-up. | Pressure on commercial discipline. No claim about you. |

### D: Data-driven Prober (Ross, weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how the £4M was counted." | EXP | [grounded] "roughly £4M of influenced revenue" — your message | Answer slot: say how it was counted, in your words. If it was counted on a basis you cannot repeat, say so, and say what basis you would use now. Do not supply a method the material does not carry. | First of the figure's defend-the-number slots. |
| D2 | "Of the forty partners, how many did you count as active?" | EXP | [grounded] "took it from 6 partners to 40" — your message | Answer slot: say what counted as active, in your words. If you did not count activity, say so plainly, and say what you would track first. | Denominator probe on the partner count. Asks for a method the material does not carry. |
| D3 | "Which assumption behind that revenue figure would you defend least?" | EXP | [grounded] "roughly £4M of influenced revenue" — your message | Name the assumption you would defend least before Ross has to ask. Answer slot: if you can name it, say it in your words; if you cannot, say so. | The weakest-assumption move. It turns a probe into a credibility gain. |

### E: Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" — your message; "9 years in partnerships" — your message; "last 4 at a payments company running the ISV channel" — your message; "took it from 6 partners to 40, roughly £4M of influenced revenue" — your message | A 90-second arc in this order: the consulting years, the partnership years, the last four years running the ISV channel, and the growth from 6 to 40. Each beat is one of your quoted sentences. Put the why-now in your own words; the material gives none. | A casual opener is still scored. The arc uses only what the quotes carry. |
| E2 | "What have you been reading about rail operators lately?" | CO | [grounded] "She also attached the market report their strategy team circulated internally last quarter, which I've read." — your message | Name one point from the report, and refer to it as material Kelverton sent you, not as your own research. Name the point you would test. Do not recite a shortlist. | A rapport question that tests whether you have done the homework, and whether you can differentiate from the shared report. |

### F: Values / Behavioural (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Tell me about a time you told a partner something they did not want to hear." | VAL | [generic] | Selection scaffold: pick a time you told a partner something unwelcome. It needs a named stake, a moment you did not fold, and a relationship intact at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it. | A values-style stem. No values page was read, so nothing is mapped. Generic because no sentence in your material carries a story. |
| F2 | "When did you put a customer ahead of an internal target?" | VAL | [generic] | Same scaffold: a named customer ahead of a named metric. If none, say so plainly, then the nearest thing your material carries, or how you would handle it. | A persona stem. Generic for the same reason as F1. |

## Reverse questions

Each one, with why it lands.

1. **To Deepa:** "What did the last person in this role get right in the first ninety days, and what did they get wrong?" Why it lands: shows you are planning the job, and gives you the real bar.
2. **To Ross:** "When a partnership clears on margin but misses on revenue, which way does the decision go?" Why it lands: asks for the commercial rule, which is the thing C4 is testing.
3. **To both:** "Which part of the POV is the team least sure of?" Why it lands: invites a conversation about the thinking rather than a verdict on it.
4. **To both:** "What would an operator say about Kelverton's partnerships today, if you asked them?" Why it lands: puts the operator at the centre, which is the recruiter's own ask.
5. **To both:** "What would make this role clearly successful at eighteen months, in terms an operator would notice?" Why it lands: turns the close of the POV into a success measure you can work against.

## Sources

**Provided documents**
- Your message: your background, the panel, the format, and the recruiter's email as you quoted it.
- The internal market report: referenced in your message, not in the files available to this pack. Nothing from it is used here.

**Searches and fetches sent**

Every call was refused by the host ("permission not granted"). None returned a result.
- "Kelverton Rail values": refused.
- "Kelverton Rail interview process Senior Partnerships Manager": refused.
- "Kelverton Rail strategy news scheduling software train operators": refused.
- "Deepa VP Partnerships Kelverton Rail": refused.
- "Ross Commercial Director Kelverton Rail": refused.
- "Senior Partnerships Manager rail technology train operating company job description": refused.
- No page fetches were sent.

Research tier: L1 — searches 6 of 6 (all refused), fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Kelverton Rail values | unavailable | Values cheat sheet, which is omitted: no published values established, and no values round detected |
| 2. Kelverton Rail interview process, Senior Partnerships Manager | unavailable | Loop structure. Persona weights follow the roles the recruiter named, not a documented loop |
| 3. Kelverton Rail strategy and recent news | unavailable | CO questions. Only E2 touches it, and the POV rests on the recruiter's words and [generic] reasoning, not current strategy |
| 4. Deepa and Ross, Kelverton Rail | unavailable | Interviewer read. Both calls refused; no public footprint established |
| 5. Representative Senior Partnerships Manager JD | unavailable | JD-tagged questions. The fit snapshot uses the recruiter's words instead of a JD |

## Upgrade menu

- **Job description text** → F1 to F3 are rebuilt against its own lines, and the JD-tagged questions expand. Any gate lines in it (right to work, location, office days) get their own rows.
- **The market report's key points (or a paste of its segments, headline numbers and shortlist)** → the POV's differentiation is checked against the report, C3 and C4 get real numbers to test, and E2 names a specific point.
- **Permission to run web search** → rerun the L1 targets: values, interview process, strategy, the interviewers' public footprint, and a representative JD. A values section appears only if a loop source documents a values round.
- **Deepa's and Ross's public professional profiles (you can paste them)** → the interviewer read, persona weights tuned to their careers, and a reverse question tied to one of their own paths.
- **The recruiter's confirmation that the 60 minutes is one session** → the loop is established, so the pack can say how many rounds it covers.
- **A deeper research pass (L2)**: up to 6 more searches and 2 more fetches, several minutes; it would add a strategy brief, interviewer talks and writing, and recent organisational context. Offered once; say if you want it.
