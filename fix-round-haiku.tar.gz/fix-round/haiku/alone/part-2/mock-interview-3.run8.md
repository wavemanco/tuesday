I couldn't run web research: the search tool was denied permission, so this first pack is built from general knowledge only. Stripe's values, loop structure, and the role's real requirements are unverified, and I've labeled everything that depends on them. No JD, CV, or dossier was provided, so the fit snapshot is a worksheet for you to fill in.

## 1. Fit snapshot (worksheet)

| Typical requirement (generic) | Your evidence (fill in, quoting your own sentences) | Gap type |
|---|---|---|
| Run operating cadences: planning, reviews, metrics | _to fill_ | evidence missing |
| Cross-functional program leadership without direct authority | _to fill_ | evidence missing |
| Use data to find problems and prioritize | _to fill_ | evidence missing |
| Launch or roll out changes with clear ownership | _to fill_ | evidence missing |
| Communicate crisply to executives | _to fill_ | evidence missing |

Confidence: low. Every row is unverified until you add your material.

## 2. Prohibited claims (built locally)

- Don't state a metric, team size, or outcome you couldn't defend with a source document.
- Don't claim knowledge of Stripe internals, strategy, or recent launches. Anything about them must come from research you've checked.
- Don't describe a shared project as solely yours. Say what you did.

## 3. Persona weights (priors, not researched)

For a final round, expect a senior interviewer, often the hiring manager or a leader on the function, who tests judgment, ownership, and ambiguity. Weight it roughly: senior leader 50%, hiring manager 30%, cross-functional peer 20%. Reweight once you know who is in the loop.

## 4. Question banks

**Hiring manager: behavioral**
- *Tell me about a process you designed that others actually adopted.* Type: behavioral. Provenance: generic. Guidance: problem, your specific design choices, adoption path, measured result. Use one story you can tell in under three minutes.
- *Describe a time you had to drive a decision without authority.* Type: behavioral. Guidance: name the stakeholders, the disagreement, and how you resolved it.

**Senior leader: situational and judgment**
- *You inherit a team with unclear priorities and missed deadlines. First 30 days?* Type: situational. Guidance: listen and map before changing. Name the first metric you'd check and why.
- *How do you decide what not to do?* Type: judgment. Guidance: give a real tradeoff and what you gave up.

**Skeptic (the most likely objection, so rehearse this hardest)**
- *Operations work is often seen as reactive. What proof do you have that you move outcomes, not just process?* Type: skeptic. Guidance: answer with one concrete before-and-after you can source. If you have no such example, say so and describe the closest real one. Don't invent a result.

**Pressure**
- *Which of your claims would you struggle to defend under questioning?* Type: pressure. Guidance: name one honestly and explain how you'd verify it. This question rewards calibration, not polish.

**Cross-functional partner (if a peer round)**
- *How do you work with engineering and finance when you disagree on priority?* Type: collaboration. Guidance: describe a real disagreement, the data you used, and the outcome.

## 5. Values cheat sheet

Skipped. Without research, I can't confirm Stripe's published values, so I won't map stories to them.

## 6. Reverse questions

- What does success look like for this role in the first six months?
- Which operating decision in the last quarter would you want this person to have owned?
- Where does this function have the most friction with product and engineering today?

## 7. Upgrade menu

- **Round type and interviewers** (who, and whether there's a take-home or presentation): would reshape the persona weights and banks.
- **Full JD**: would replace the generic requirements with the real ones.
- **Your CV or a background summary**: would turn the worksheet into story-mapped answers.
- **Research at the default tier** (values, loop structure, recent strategy): needs search permission granted, then I can run it.
- **Recruiter guidance on focus areas**: usually one email to the recruiter.

---

Would you like a live drill on the Skeptic question? I'd play the interviewer and give feedback against that question's guidance.

I can also draft `tuesday-dossier.md` from your materials later, if you have the underwriter tooling.

Questions:
1. What's the round type, and who will you meet: the hiring manager, a panel, or a peer?
2. Can you paste the JD and a short background summary or CV?
3. Should I retry research once search permission is granted, or do you prefer to skip it?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.