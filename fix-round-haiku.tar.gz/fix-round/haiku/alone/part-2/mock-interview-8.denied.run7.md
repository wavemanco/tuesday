Your prep pack is saved at /tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-alone-part-2-rooms-case-8-denied-2013ce53/befe5c45-2c8b-40af-8b1f-09f00dc5c41d/scratchpad/ashgrove_member_experience_lead_interview_pack.md. I built it as a loop, one mini-pack per round, since the recruiter has scheduled three rounds on 20 November. It uses only what you pasted: no CV and no interviewer names, so the fit snapshot draws on your message and the interviewer read is absent. I didn't run any web searches, because the values, process and strategy you pasted already cover them.

**What the pack says, in short**

- **Your strongest material is the branch-side work:** six years in retail banking, three as a supervisor, the complaints log, escalation training, and the spreadsheet your regional manager uses.
- **Your gaps are stated or visible in the JD:** the scope is one branch's log, not end-to-end across sites and a contact centre; you have never presented above regional level; and you have no contact-centre or digital-team work in your material. Each gets a plain acknowledgment or an answer slot in the banks, and none is covered by a claim you didn't make.
- **Highest-return prep:** B1 in Round 2. It is the question that presses the headline requirement, where your material is thinnest. Concede the one-branch scope in a sentence, then give your first steps across sites as plans.
- **Round 3's 20-minute case (C1, C2):** the pack gives a structure for a complaint escalation, not a story. Write out the first hour on paper and speak it in two minutes.
- **Strategy:** the digital shift (40% of member service by 2028) and the hub consolidation (eight branches into five) are both in Round 2 and Round 3. Use the brief's own wording, and don't claim to know how the plan will be carried out.
- **Values:** the panel scores against the four values, so Round 3 has a cheat sheet. Two values (Members First, Plain Words) have no story in your material, so they get a selection scaffold with an honest branch. Say so if none comes to mind, rather than inventing one.

The pack also has a prep schedule for the nine days you have, the requirement-by-question coverage table, and the upgrade menu.

**Offers, not pushed:**

- I can play the Skeptic on B1 as a drill, then give feedback against that question's guidance.
- I can save a `tuesday-dossier.md` recording the gaps this prep exposed, to carry into later sessions.
- I can convert the pack to Word if you want it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove_member_experience_lead_interview_pack.md -----
# Ashgrove Credit Union: Member Experience Lead, interview pack (Dara)

**Role:** Member Experience Lead, Ashgrove Credit Union (member-owned, about 900 staff)
**Interviews:** 20 November 2026, three rounds. Interviewers beyond their roles are not yet assigned, so no interviewer read is included.
**Mode:** Loop mode. The shared fit snapshot comes first, then one mini-pack per round.

## How to use this pack

- **Personas** describe how a question is asked. **Types** describe what is being scored:
  - **VAL**: values and behaviour, scored against Ashgrove's published values
  - **EXP**: your own experience, tested for what you actually did
  - **JD**: the job's stated requirements, including the gaps
  - **CO**: company and strategy knowledge
  - **CASE**: a live problem from the job, worked out aloud
- Question IDs are letter-by-round: A is Round 1, B is Round 2, C is Round 3.
- **Guidance is scaffolding, not a script.** Say it in your own words. Where a guidance cell says "answer slot", it is an instruction for the interview: answer from your own experience, or say plainly that the practice was not yours. Neither branch is a failure.
- Provenance shows the sentence of yours each claim rests on. If a sentence is not quoted, the guidance does not assume it.

## Prep triage

Nine days to 20 November. Work in this order; everything else is insurance.

1. **Days 1 and 2:** Say the fit-snapshot quotes aloud until you can say them without reading (F1, F2, F3, F8, F9). Then rehearse B1 and B2, the hardest Round 2 questions.
2. **Days 3 and 4:** Write out the first hour of the complaint case (C1) on paper, then speak it in two minutes. Rehearse C2.
3. **Day 5:** Choose a story or an honest branch for each value in the Round 3 cheat sheet.
4. **Day 6:** Round 1: A5, A6 and A8, the three questions most likely to test the gaps.
5. **Days 7 and 8:** Drill B1 and C9 aloud twice each, with someone pushing back if you can.

## Fit snapshot (shared across all rounds)

Requirements are quoted from the job description you supplied. Evidence is quoted from your message, the only candidate source so far; there is no CV yet. No requirement is a hard gate, because each is either a length of experience or a practice rather than a licence or credential, so every row is graded on fit and gap type alone.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor" — your message | medium | [grounded] | none | No gap in years or sector. Say it as written: "6 years in retail banking, the last 3 as a branch supervisor." The material does not show a CV to check the dates against, so expect a check. |
| F2 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | presentation | Your material says a formal complaints log, not regulation. Say: "I handled the branch's formal complaints log." Answer slot: the JD says regulated, so expect a probe on which rules shaped the log. If you worked to a regulatory timescale or review, say which and what you did. If the log ran on branch practice alone, say so plainly and describe how you handled a complaint from start to finish. |
| F3 | "Own the member complaints process end to end across branches and the contact centre" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | transferability | Your material covers one branch's log, not an end-to-end process across sites. Say the scope you can speak to: "The log I handled was one branch's." Answer slot: if you owned any step beyond your own branch, say which. If you did not, say so plainly. |
| F4 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | presentation | Your material says the spreadsheet and that the regional manager uses it. It does not say what it counts. Say: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: if it counted volumes or resolution times, say which and how each was counted. If it did not, say so. |
| F5 | "coach branch supervisors on escalations" — JD | "trained new tellers on our escalation script" — your message | medium | [grounded] | transferability | Your material shows coaching of new tellers, not supervisors. Say: "I trained new tellers on our escalation script." Answer slot: if you coached anyone on escalations beyond new tellers, say who and what you did. If not, say so. |
| F6 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material is silent on this. Answer slot: if you worked with anyone on channel or app journeys, say what you did. If not, say so, then say what you would want to learn first. That is a plan, not a past. |
| F7 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | discovery | Your material does not name Excel. Answer slot: say which tool you built the spreadsheet in and what it did, in your own words. |
| F8 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap you stated. Words: "I haven't presented to anyone above regional level." Then how you would learn it, as a plan. Do not add any presentation you have not described. |
| F9 | "across branches and the contact centre" — JD | "Never worked in a contact centre" — your message | none | [grounded] | capability | A gap you stated. Words: "I haven't worked in a contact centre." Then how you would learn that side, as a plan. |

**Reading the snapshot:** You have the core of the branch-side job: six years in retail banking, three as a supervisor, a complaints log, escalation training, and a spreadsheet a regional manager relies on. The clearest gaps are scope (one branch, not sites and a contact centre), presenting above regional level, and the digital and contact-centre sides. Those gaps are where the hardest questions will come, so they get the most rehearsal.

## Grounding brief (from the strategy brief you supplied)

| Fact | Source |
|---|---|
| "move 40% of member service to digital channels by 2028" | Strategy brief, July 2026 |
| "consolidate eight branches into five hubs over 2027" | Strategy brief, July 2026 |
| "launch a small-business lending product in Q1 2027" | Strategy brief, July 2026 |
| "the main competitive pressure is app-only banks" | Strategy brief, July 2026 |

The brief is the only source on strategy; it is a company document, not an outside view. Use its vocabulary (member service, digital channels, hubs) when speaking to it. Do not claim knowledge of how the plan will be carried out. The consolidation and digital shift are the likeliest strategy topics this loop, so Round 2 and Round 3 each carry one question on them.

## Prohibited claims

These are claims this pack will not coach, because the material does not support them. Each is shown with its basis and its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end across branches and the contact centre | Inflated form of F3 | "I handled the branch's formal complaints log." The limit is the pack's observation: your material shows one branch's log, not an end-to-end process. |
| Owned the reporting the region runs on | Inflated form of F4 | "I built the monthly complaints spreadsheet our regional manager uses." |
| Coached branch supervisors on escalations | Inflated form of F5 | "I trained new tellers on our escalation script." |
| Presented to senior leaders | Negative you stated, F8 | "I haven't presented to anyone above regional level." No answer slot. |
| Worked in a contact centre | Negative you stated, F9 | "I haven't worked in a contact centre." No answer slot. |

---

## Round 1: Recruiter screen (30 minutes)

**Relationship:** Recruiter. The recruiter's email sets the agenda: logistics, motivation, and the knockout checks against the job description.

**Persona weights**

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational (5 questions, A1 to A5) | Friendly openers, unstructured | High. A recruiter screen is a conversational register, and it is still scored. | Pre-scripted 90-second arc for the opening. Treat casual questions about the JD's topics as scored. |
| Skeptic (3 questions, A6 to A8) | Checks the JD's requirements one at a time | Moderate. A recruiter is screening against the job description, so the regulated, contact-centre and Excel lines get asked. | Say what you did, then the gap in one sentence. Do not defend beyond it. |

**Question bank**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how you got into banking and into branch supervision." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" — your message | Open with the six years and the three as a supervisor, in those words. Then the complaints log and the escalation training as the thread. Keep it to 90 seconds. | F1 is the strongest sentence you have. The arc is built only from F1 and F2. |
| A2 | "What is drawing you to this role?" | JD | [generic] | Name one line of the job description in your own words, and say why it matters to you. Do not claim experience you have not described. | A motivation question. Its answer carries no claim about your past, so it has no evidence to quote. |
| A3 | "Ashgrove wants 40% of member service online by 2028. What is your read?" | CO | [grounded] "move 40% of member service to digital channels by 2028" — strategy brief, July 2026 | Give a plain view: a channel shift moves complaints as well as volume, so the question is which ones stay human. Name one thing you would check first. Do not claim knowledge of the digital plan. | Ties to F6, where your material is silent. A view with a question is stronger than a claim. |
| A4 | "Which of the four requirements do you feel strongest on?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" — your message; [grounded] "I built the monthly complaints spreadsheet our regional manager uses" — your message | Lead with years and the complaints log (F1, F2), then the spreadsheet (F4). Do not volunteer the presenting gap here; Round 2 covers it. | A recruiter tests whether you can map yourself to the list. Stay on what you can show. |
| A5 | "Tell me about the contact-centre side of this role." | JD | [grounded] "Never worked in a contact centre" — your message | Plain acknowledgment: "I haven't worked in a contact centre." Then the branch-side handling you know, and a plan: shadow contact-centre complaint handling and read their logs. | F9. A premised question, answered by the stated gap, with a plan. |
| A6 | "What did regulated complaints handling mean in your branch day to day?" | JD | [grounded] "I handled the branch's formal complaints log" — your message | Answer slot: say what the formal log was and what it had to show. If the rules set timescales or reviews you worked to, name them in your own words. If the log ran on branch practice rather than a regulatory standard, say so plainly, then describe how you handled a complaint from start to finish. | F2. The question presumes regulated handling; the second branch lets that be false. |
| A7 | "You've run one branch's complaints. Why would this work across branches and a contact centre?" | JD | [grounded] "I handled the branch's formal complaints log" — your message | Concede the scope first: "The log I handled was one branch's." Then the first steps you would take across sites, as plans. Hold it through one follow-up by returning to the scope you can speak to. This is the warm-up for B1. | F3. Practise on the easier version before B1. |
| A8 | "What have you built in a spreadsheet, and what did it have to do?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" — your message | Name the spreadsheet, its monthly cycle and who uses it, in those words. Answer slot: say which tool it was built in and what it did. If it was mostly data entry into a template you did not design, say so. | F7. Excel is in the JD and the spreadsheet is the only evidence you have. |

**Reverse questions**

| Question | Why it lands |
|---|---|
| "What does a strong first 90 days look like in this role?" | Shows you are thinking about the job, not only the offer. |
| "Who is on the panel, and what does each person look at?" | Panel members are not assigned yet. Asking now lets you tune Round 3 without guessing. |
| "What is the complaints process today, and where does it sit across the branches and the contact centre?" | Shows interest in the current process, and invites the scope question on your terms. |

---

## Round 2: Head of Member Services, your future manager (45 minutes, mostly behavioural)

**Relationship:** Hiring manager. The hiring-manager prior is Case and Skeptic. The recruiter describes this round as mostly behavioural, so Values/Behavioral is weighted up from the prior. No interviewer profile exists, so no interviewer-signal adjustments apply.

**Persona weights**

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (4 questions, B1 to B4) | Probes the gaps against the JD | Top weight. Your gaps (scope, presenting, coaching supervisors) are the manager's first concern, because they would manage them. | Concede the one-branch scope in one sentence, then the plan. Hold through two follow-ups. |
| Values/Behavioral (3 questions, B5 to B7) | Behavioural stems, STAR-shaped | Raised from the prior because the round is mostly behavioural. | Select a story where one exists. Where none does, say so, then the nearest thing your material carries. |
| Case/Strategist (2 questions, B8 and B9) | A live problem from the job | Mid weight. The strategy brief names two changes this manager will have to deliver. | Clarify, then structure, then answer. Think aloud. |

**Question bank**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Your experience is one branch's complaints log. This role owns the process across branches and the contact centre. Why would it work for you?" | JD | [grounded] "I handled the branch's formal complaints log" — your message | **Highest-ROI prep in this pack.** Concede the scope first: "The log I handled was one branch's." Then what you did with that log, in your words, and the first three steps you would take across sites, as plans. Hold through two follow-ups by returning to the one branch and to what you would do first. Do not claim cross-site work. | This objection will be asked in some form. The headline requirement is the one your material covers least, so it gets the deepest rehearsal. F3. |
| B2 | "You've never presented above regional level. How would you present a complaints position to the executive?" | JD | [grounded] "I've never presented to anyone above regional level." — your message | Plain acknowledgment: "I haven't presented to anyone above regional level." Then a plan with dated steps: who you would present to first, how you would prepare, and how you would ask for feedback. Do not describe any presentation you have not described. | F8. A premised question answered by the stated gap, with a plan. Hold the plan; do not claim readiness. |
| B3 | "What does the monthly complaints spreadsheet show, and who acts on it?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" — your message | Say who uses it and that they use it, in those words. Answer slot: say which measures it counted, and how each was counted. If it did not count volumes or resolution times, say so. | F4. The JD names the metrics; your quote does not, so the answer is a slot. |
| B4 | "Tell me about coaching someone on escalations. Who was it, and what happened?" | JD | [grounded] "trained new tellers on our escalation script" — your message | Answer slot: if you coached anyone on escalations beyond new tellers, say who and what you did. If you did not, say so plainly, then describe how you trained the tellers on the script. | F5. The question asks about supervisors, which your material does not show. The second branch allows that you did not coach them. |
| B5 | "Tell me about a time you had to tell someone senior something they did not want to hear." | VAL | [generic] | Scaffold: pick a time a complaint outcome went against the branch's wishes or a senior person's preference. It needs a named stake, a moment you held your position, and a relationship that was intact after. If no such time comes to mind, say so plainly. Then give the nearest thing your material carries, which is the complaints log, and how you handled it. | Persona stem. Your material does not show a hard-truth story. Say so, rather than supply an ending. |
| B6 | "When did you put a member ahead of an internal measure?" | VAL | [generic] | Scaffold: pick a time a member's outcome cost the branch a target, a service measure, or a quicker close. Say what the member needed and what you did. If none comes to mind, say so plainly, then the complaints log as the nearest instance. | Maps to Members First, Always. A selection scaffold, with its honest branch. |
| B7 | "Tell me about a time a complaint stayed with you until it was resolved." | VAL | [grounded] "I handled the branch's formal complaints log" — your message | Answer slot: if you followed one complaint from first contact to close, walk through its steps in your own words. If the log only recorded complaints and others resolved them, say so plainly and describe what you did on the log. | Maps to Own the Fix. The open prompt is built from the published value; the answer rests on F3. |
| B8 | "Eight branches become five hubs during 2027. A complaints spike hits one of the branches due to close. What do you do first?" | CASE | [grounded] "consolidate eight branches into five hubs over 2027" — strategy brief, July 2026 | Clarify before you structure: which complaints, what changed, what the member has been told. Then objective (members keep their resolution), segments (complaint type, vulnerable members), approach, metrics (time to resolution, repeat complaints), risks (members lost in the move). Think aloud. | A live problem from the strategy. It asks about no past of yours. |
| B9 | "The plan puts 40% of member service online by 2028. Which complaints should stay with a person, and why?" | CO | [grounded] "move 40% of member service to digital channels by 2028" — strategy brief, July 2026 | Form a view. Separate what can be self-served from what needs a person: disputes, vulnerable members, anything that needs an explanation. Name the member's side. Do not claim digital-team work, which F6 leaves unevidenced. | Digital shift is the likeliest strategy topic. The answer is a view, with no claim of experience. |

**Reverse questions**

| Question | Why it lands |
|---|---|
| "How does the monthly complaints report reach the executive today?" | Names the route you would have to present into. It points at the presenting gap as a process, not a personal failing. |
| "How will the consolidation change the complaints team's work during 2027?" | Ties the strategy to the job the manager would be hiring for. |
| "What would you want the first three months to prove?" | Gives the manager a chance to name the expectations, which you can then meet or question. |

*No interviewer profile exists, so no reverse question ties to an interviewer's own path.*

---

## Round 3: Panel of two branch managers (60 minutes, including a 20-minute case; the panel also scores the four values)

**Relationship:** Panel. Each member's relationship prior is manager and peer-manager. The panel blends the top two personas of each. Values/Behavioral is guaranteed here because the recruiter says the panel scores against the four values. Case gets the most weight because of the 20-minute case. Pressure is included for the second member.

**Persona weights**

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist (4 questions, C1 to C4) | A complaint escalation worked live | Top weight. The 20-minute case is a complaint escalation, which is the job. | Clarify, structure, answer. Speak aloud, and name what you would need to know first. |
| Values/Behavioral (3 questions, C5 to C7) | Scored against the four values | Guaranteed by the panel's stated role. | Map a story to each value, or give the honest branch. |
| Pressure/Stress (3 questions, C8 to C10) | Interruptions, time limits, motive checks | Moderate. The second panel member is the likelier one. | Pause. Restate. Anchor in what you did. Hold through two follow-ups before any concession. |

**Question bank**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A member at the counter says a fee was charged after they were told it had been waived. The teller says it is policy. The member asks for a manager and says they will go to the regulator. Walk us through the first hour." | CASE | [generic] | Clarify: what was said, who said it, what the record shows. Objective: resolve with the member, record the decision, check whether the teller stated policy correctly. Segment: a fee dispute versus a conduct complaint. Approach: one decision owner, a written record, a time for the answer. Metrics: time to first response, outcome, whether it reopens. Risks: the regulator complaint, the teller's handling. Speak it in two minutes. | A live problem from the job, asking about no past of yours. Deepest rehearsal is on the structure, not on any story. |
| C2 | "The member has now raised it with two branch managers. Who decides, and how do you stop it bouncing?" | CASE | [generic] | One decision owner and one case record. A return date the member is told. What the escalation script should say about who holds the case. Say how you would coach supervisors on it. Do not claim supervising experience. | Escalation ownership is the coaching requirement and the Own the Fix value in one case. |
| C3 | "Consolidation means one complaints team serves five hubs instead of eight branches. What changes first for the member?" | CO | [grounded] "consolidate eight branches into five hubs over 2027" — strategy brief, July 2026 | Name what a member loses first: walk-in complaints, a local face, a familiar name. Say how you would check, with a plan. Do not claim knowledge of the hub plan. | Neighbours, Not Numbers. Tests whether you can think about the town, not only the count. |
| C4 | "Name one measure you would add to the monthly report. What question does it answer?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" — your message | Name one measure and the member outcome it protects, such as repeat complaints or a complaint reopened after close. Answer slot: say which measures the spreadsheet already carries. If it carries none you can name, say so. | F4. The question asks for a new measure, not a claim about the old one. |
| C5 | "Tell us about a time you held a line on a decision a senior person pushed back on." | VAL | [generic] | Scaffold: a named stake, a held position, a relationship intact at the end. If none comes to mind, say so plainly, then the nearest thing your material carries: the complaints log and how you kept a case to its outcome. | Maps to Own the Fix. The panel scores this value. |
| C6 | "Tell us about a time a member needed something explained twice. What happened?" | VAL | [grounded] "trained new tellers on our escalation script" — your message | Answer slot: if the explanation was in a script you trained tellers on, say what the script said and what you changed, only if you changed it. If nothing comes to mind, say so plainly, then give the training as the nearest instance. | Maps to Plain Words. The open prompt is built from the published value; the answer rests on F5. |
| C7 | "Tell us about a time local context changed how a branch handled a complaint." | VAL | [generic] | Scaffold: what the local context was, what you knew of it, and what you did because of it. If none comes to mind, say so plainly. Do not describe the town beyond what you know. | Maps to Neighbours, Not Numbers. The material does not show this, so the honest branch is the answer. |
| C8 | "Sixty seconds: why should we hire you over a contact-centre lead?" | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" — your message; [grounded] "Never worked in a contact centre" — your message | Pause. Restate. Anchor in what you did: the years, the supervisor role, the log. Concede plainly: "I haven't worked in a contact centre." Then say what branch-side work transfers, and the plan. Hold through two follow-ups. | F1 and F9. A time-boxed pressure question; the concession is a stated gap, not a new one. |
| C9 | "That spreadsheet: how much of it was actually you?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" — your message | Say what you built and how the manager uses it, in those words. Answer slot: say which parts were yours and which were set by the regional manager. If the layout was theirs, say so. Hold the position that you built it. Concede precisely what you do not know: how the manager reads it. | F4 and F7. Honest attribution under challenge. |
| C10 | "Our regional managers present to the executive. You haven't. Why would you be ready?" | JD | [grounded] "I've never presented to anyone above regional level." — your message | Plain acknowledgment: "I haven't presented to anyone above regional level." Then the plan: first audience, preparation, feedback. Do not claim readiness. | F8. The panel's version of B2. Same plain acknowledgment, same plan. |

**Values cheat sheet (Round 3 panel, because the panel scores the four values)**

| Value (official name) | Working meaning | Your mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | No quoted sentence carries a member-side decision. Scaffold: a time a complaint or decision looked different from the member's side. If none comes to mind, say so, then the nearest instance: the complaints log (F3). |
| Plain Words | If a member needs it explained twice, the wording was wrong | Nearest sentence: "trained new tellers on our escalation script" (F5). Scaffold: what the script said, in words a member would follow. Honest branch: if you did not write or review the wording, say so and say what you did do. |
| Neighbours, Not Numbers | Every branch is part of its town | No quoted sentence carries it. Scaffold: a time local context changed a branch's handling (C7). Honest branch: say so, then the branch-level log you handled (F3). |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | "I handled the branch's formal complaints log" (F3, at its own scope). Answer slot: if you kept a complaint open until it was resolved, say what you did at each step. If the log only recorded complaints and others resolved them, say so plainly. |

**Reverse questions**

| Question | Why it lands |
|---|---|
| "What could someone do in their first month that would genuinely help your branches?" | A reciprocity question for a panel of peer managers. It turns the close into a conversation about their work. |
| "Where does an escalation currently stop, between a branch and the contact centre?" | Asks about the seam the role would own. It shows you think in process, which the case will test too. |
| "What is the hardest kind of complaint your branches see right now?" | Shows interest in the members rather than only the metrics. Neighbours, Not Numbers, in a question. |

---

## Requirement coverage

| JD requirement | Question IDs |
|---|---|
| 4+ years in financial-services customer operations | A1, A4 |
| Own the member complaints process end to end across branches and the contact centre | A7, B1, C2 |
| Across branches and the contact centre (contact-centre side) | A5, C8 |
| Report monthly on complaint volumes and resolution times | B3, C4 |
| Coach branch supervisors on escalations | B4, C2 |
| Work with digital teams on self-service journeys | A3, B9 |
| Experience handling regulated complaints | A6, B1 |
| Confident presenting to senior leaders | B2, C10 |
| Comfortable with Excel reporting | A8, B3, C9 |

No requirement is left uncovered.

## Sources

- **Provided documents:** the job description, the four Ashgrove values (copied from the values page), the July 2026 strategy brief, the recruiter's email on the rounds, and your background message.
- **Searches and fetches sent:** none.

**Research tier:** L0, searches 0 of 0, fetches 0 of 0.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | The pasted values text fixes the cheat sheet, so no search was needed. |
| 2. Interview process | skipped | The recruiter's email fixes the loop structure and round lengths. |
| 3. Strategy and recent news | skipped | The strategy brief you supplied fixes the grounding brief. |
| 4. Interviewer name | n/a | No names were given, so there was no query to form. |
| 5. Representative role JD | skipped | The job description you supplied fixes the fit snapshot and the JD questions. |

## Upgrade menu

- **Your CV** → verifies the four rows graded medium (F1 to F4), and can move them from quotes of your message to quotes of the CV.
- **Names of the Round 2 and Round 3 interviewers** → public-footprint read, personas weighted per person, and one reverse question per interviewer tied to their own path.
- **Whether you have worked on channel or app journeys, or with a digital team** → F6 moves from discovery to a stated answer and sharpens B9.
- **The Excel tool and one example of the spreadsheet's layout, in your own words** → F7 and C9 gain a concrete answer, not a slot.
- **Deep research (offered once):** four more targets, namely the full strategy brief, public interviewer writing, role-family loop reports, and recent organisation news. At most six searches and two fetches, adding a short wait. Say if you want it.
- **A dossier from the job-underwriter skill, if you have one** → its verified evidence would replace the quotes of your message with confirmed claims and add prohibited-claim guardrails.
