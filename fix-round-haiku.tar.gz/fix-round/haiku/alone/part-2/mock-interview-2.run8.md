Your prep pack is saved as `atlas-freight_operations-manager_interview_pack.md` in the scratchpad, and I've attached it. I built it with no round type and no interviewer, so the persona weights are a generic fallback.

**Web research didn't run.** The search tool was refused permission three times, so there is nothing on Atlas Freight's values, interview loop or strategy. The pack leaves those out rather than guessing. The CO and values sections are missing for that reason.

**What the pack says about your fit**

- **Your strongest material:** the pick-path redesign (mis-pick rate down 40%), the peak-season plan you ran two years running, green belt, and Excel. Each has a quote from your own words to rehearse from.
- **Your biggest gaps against the JD:**
  - **Scale of team:** three supervisors now, twelve in the JD. This is the most likely objection. B2 is the one to rehearse hardest.
  - **Scope:** you've run one site. The JD says four.
  - **Leadership years:** seven years in ops, but the material doesn't say how many had people reporting to you. You need an honest split ready.
  - **Power BI:** you've never used it. Say that plainly, then give a learning plan with a date.
- **Don't claim:** multi-site operations, twelve supervisors, five years of leadership, on-time or cost-per-shipment gains, or any Power BI use. Each is listed in the pack with its honest wording.
- **The 40% figure** will be probed. Be ready to say how it was counted, which assumption you'd defend least, and which part was yours. If you can't answer those, say so.

**Questions for you**

1. Who is the round with: your future manager, a peer, or a panel? Did the recruiter say what they'll focus on or send anything to prepare? The answer reweights every bank.

**Next steps (none pushed)**

- I can run a live drill on B2, the team-size question, playing the Skeptic.
- I can save a `tuesday-dossier.md` recording the gaps this prep exposed, to carry into later sessions.
- I can convert the pack to Word.

If you grant web search, I'll run the company research on values, interview loop and strategy, and the CO questions will come in.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: atlas-freight_operations-manager_interview_pack.md -----
# Interview prep pack: Operations Manager, Atlas Freight

Round type and interviewer unknown, so persona weights are the generic fallback and the pack is a full-loop pack. Web research was not run (search permission was refused), so company facts are absent and labelled as such.

## How to use

- **Personas** = how a question is asked. **Types** = what is being scored.
- Type key: **JD** role requirement · **EXP** your experience, tested for precision · **CASE** live problem, no past claimed · **VAL** values (none detected here) · **CO** company knowledge (none researched).
- Guidance is scaffolding for a spoken answer, not a script.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" — JD | "currently a senior shift manager over 3 supervisors" — your message; "ran the site's peak-season surge plan two years running" — your message | medium | [grounded] | transferability | Your material shows one site, at that site's scope; the four-site scope is not in it. Say it in your terms: "I ran the site's peak-season surge plan two years running." Answer slot: if you have run daily operations at more than one site, say where and how; if not, say so plainly and say how you would learn a second site's operation. |
| F2 | "lead a team of 12 supervisors" — JD | "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | Three supervisors is specific; twelve is four times that and the material does not show more. Words: "I'm currently over three supervisors." Answer slot: if you have led more than three supervisors at once, say how; if not, say so and say how you would build out from three. |
| F3 | "5+ years operations leadership required" — JD | "7 years in warehouse and distribution ops" — your message; "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | discovery | Seven years is operations time; the material does not say how many of them had people reporting to you. Answer slot: say which of those years had people reporting to you, in your own words; if you cannot split them, give the honest split. |
| F4 | "drive on-time performance and cost-per-shipment down" — JD | "cut mis-pick rate 40% by redesigning the pick path" — your message | medium | [grounded] | transferability | This is accuracy, not timeliness or cost per shipment. Words: "I cut the mis-pick rate 40% by redesigning the pick path." Answer slot: if you have moved on-time or cost figures, say which and how; if not, say so and offer the pick-path work as the nearest evidence. |
| F5 | "Lean/Six Sigma a plus" — JD | "green belt certified" — your message | medium | [grounded] | none | The quote reaches the requirement. No certificate has been inspected, so expect a probe. Words: "I'm green belt certified." |
| F6a | "build reporting in Excel/Power BI" — JD (Excel) | "solid Excel" — your message | medium | [grounded] | none | Quote reaches the Excel half. Expect a probe on what you have built in it. Words: "I'm solid in Excel." |
| F6b | "build reporting in Excel/Power BI" — JD (Power BI) | "never used Power BI" — your message | none | [grounded] | capability | A gap you stated. Words: "I haven't used Power BI." Then how you would learn it, said as a plan with a date, never as past experience. |

## Prohibited claims

Not to be coached, in any answer, hold or bridge.

| Not coached | Basis | Honest form |
|---|---|---|
| Ran operations across multiple sites | Inflated form of F1 | "currently a senior shift manager" at one site. Pack observation: your material shows one site. |
| Led a team of twelve supervisors | Inflated form of F2 | "over 3 supervisors". Pack observation: the material shows three. |
| Five-plus years in operations leadership | Inflated form of F3 | Seven years in operations; leadership years are not shown. |
| Improved on-time performance or cost per shipment | Inflated form of F4 | The mis-pick rate only. |
| Any Power BI use | Negative you stated, F6b | "I haven't used Power BI." No slot. |

The 40% figure raises the defend-the-number slots (A1, A2 below). Method, baseline and assumptions behind it are not supplied here; they are asked of you.

## Persona weights

Generic fallback, since round type is unknown and no loop source was read. Depth follows weight.

| Persona | Weight | Why |
|---|---|---|
| Skeptic | 4 | The JD's five-plus years, twelve supervisors and four sites all sit above what your material shows |
| Data-Driven Prober | 3 | Your 40% and the peak plan are headline claims a prober will test |
| Pressure | 3 | The team-size and seniority gap is a natural place to test composure |
| Case / Strategist | 3 | The JD is operational; live problems are likely in any loop |
| Values / Behavioral | 2 | No published values were read, so these are persona-stem themes only |
| Conversational | 2 | Casual openers can carry the Power BI and Lean questions |
| Peer | 2 | Covers a round with someone running an adjacent site or team |

## Question banks

### A. Data-Driven Prober (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how the 40% mis-pick reduction was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Start with the change: the pick path, redesigned. Then the figure. Answer slot: how you counted it, what it is sensitive to, and which part was yours. If you did not count it formally, say so plainly. | F4 is a headline metric; the prober checks precision before anything else. |
| A2 | "Which assumption behind that 40% would you defend least?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Name the weakest assumption before they do. Answer slot: state it in your own words, or say you do not know of one that is weak. | Converts a gotcha into a credibility gain. |
| A3 | "Describe the peak-season surge plan you ran. What was yours in it?" | EXP | [grounded] "ran the site's peak-season surge plan two years running" | Describe the plan as the sentence states it: you ran it, two years running. Answer slot: which parts you designed, which you ran, and what you measured. If you did not measure outcomes, say so. | The plan is a stated fact; outcomes are not, so they are asked, not asserted. |

### B. Skeptic (4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Four sites and a team of twelve are the core of this role. What would you do on day one?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" | Name what you run today in those words. Then a 30-day plan across the sites: what you would look at first. Answer slot: if you have run anything across more than one site, say where and how; if not, say so plainly. | F1 and F2 are the largest gaps; this is the most likely objection in some form. |
| B2 | "Twelve supervisors is four times the team you run now. How would you lead that many?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" | Highest-ROI prep. Say the three in your words. Hold through two follow-ups by returning to them. Name what you would check first: how supervisors' spans would be split. Answer slot: if you have led more people through other supervisors, say how; if not, say so and say how you would learn it. | F2 is the requirement with the widest gap. Rehearse the honest limit before it is asked for. |
| B3 | "The role requires five-plus years of operations leadership. Where is yours?" | JD | [grounded] "7 years in warehouse and distribution ops" | Give the seven years in those words. Then the split: which years had people reporting to you. Answer slot: if you cannot split them, say so and give the nearest honest split. | F3 is a discovery gap; this probe targets it directly. |
| B4 | "The role builds reporting in Power BI. How would you produce it in the first quarter?" | JD | [grounded] "never used Power BI" | Say it plainly: "I haven't used Power BI." Then your Excel: "I'm solid in Excel." Then a learning plan with a date you would commit to. | F6b is a stated gap; the answer is honest and has a plan. |

### C. Pressure (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Sixty seconds: why you, for a team four times the size of the one you lead?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" | Hold the position: what you have done with the three, and what you would bring. Concede specifically: "I haven't led twelve." Do not fold on the core claim to restore harmony. | F2 tested under time pressure. |
| C2 | "That 40% — how much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Hold: the redesign was your work. Concede only what is true about the split. Answer slot: if you cannot separate the redesign from other changes, say so. | Hold-then-concede on the most-tested claim. |
| C3 | "Why move you from shift manager to a four-site role?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" | Hold the reason, in your words. Concede the scale: the four sites are larger than what you run. | Tests motivation against the scope gap. |

### D. Case / Strategist (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Mis-picks rose 15% at one site after a shift change. Diagnose it." | CASE | [generic] | Clarify: what changed, when, and what the baseline is. Structure the hypotheses. Name the metrics you would check first. | A live problem; asks about no past. |
| D2 | "On-time performance is down at one site and cost per shipment is up at another. Which do you look at first, and why?" | CASE | [generic] | Clarify scope. Pick one site and one metric to start, and say why. | Live multi-site prioritisation. |
| D3 | "Plan your first 90 days across four sites with a reporting gap." | CASE | [generic] | Structure: listen, measure, fix one thing. Name the reporting gap and how you would close it without a tool you do not yet have. | Live problem tied to F6b, asked as a decision. |

### E. Values / Behavioral (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Tell me about a time you had to deliver an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time you held a position with someone senior, with a named stake, a moment you did not fold, and an intact relationship. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it. | No values were read; this is a persona-stem theme only. |
| E2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold, same honest branch as E1. | As E1. |

### F. Conversational (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F-Q1 | "So, walk me through the journey." | JD | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors" | A 90-second arc in those words, ending at the role. | Casual openers are scored. |
| F-Q2 | "What are you actually playing with in Lean and Six Sigma these days?" | JD | [grounded] "green belt certified" | "I'm green belt certified." Answer slot: if you have applied it to a project, describe it; if not, say so. | The JD's plus-skill, asked casually. |

### G. Peer (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Where would our team's seam with yours be, and what happens when we disagree?" | JD | [generic] | Propose seam principles, not a claimed seam. Disagreement story only if you have one; otherwise describe how you would handle it. | Persona-stem theme; no claim about your past. |
| G2 | "How do you handle credit when a fix spans two teams?" | JD | [generic] | Name the principle first. Answer slot: if you have a specific case, describe it in your words. | Persona-stem theme. |

Requirement coverage: JD line "Own daily terminal operations across 4 sites" → B1, A3. "Lead a team of 12 supervisors" → B2, C1, C3. "Build reporting in Excel/Power BI" → B4, D3, F-Q1. "5+ years operations leadership" → B3. "Drive on-time performance and cost-per-shipment down" → D2, A1. "Lean/Six Sigma a plus" → F-Q2. Session total: 23 questions.

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does the first 90 days look like for someone taking on the four sites?" | Shows you are planning the scope, not just the title. |
| R2 | "How is the supervisor team structured across the four sites today?" | Tests whether the twelve-supervisor line is a real team or a target. |
| R3 | "Which site is furthest from its on-time target, and what is the working theory?" | Signals you think in site-level diagnosis. |
| R4 | "What reporting exists now, and what would Power BI add to it?" | Opens the tool gap as a shared problem rather than a weakness. |
| R5 | "What would a new person do in their first month that would genuinely help the team?" | A reciprocity question, which lands well in a peer conversation. |

## Sources

- Your message: the job description, your background, and the Power BI and Excel statements.
- Research tier: L1 — searches 3 of 6, fetches 0 of 2. Web search was not permitted, so all three calls were refused.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Atlas Freight values | unavailable | Values cheat sheet; search refused |
| 2. Atlas Freight interview process | unavailable | Loop structure and persona weights; search refused |
| 3. Atlas Freight strategy / news | unavailable | CO bank; search refused |
| 4. Interviewer name + company | n/a | No interviewer name was given |
| 5. Representative JD | skipped | The supplied JD fixes the fit snapshot |

Queries sent and refused: "Atlas Freight regional logistics company values"; "Atlas Freight operations manager interview process"; "Atlas Freight logistics strategy news".

## Upgrade menu

- Web search permission → company values, interview loop, and strategy questions (CO bank), replacing the generic rows.
- Round type and the person you are meeting → persona weights, and a reverse question tied to their path.
- Recruiter's prep email → coverage of any deliverable they name.
- Any experience across more than one site, or with more than three people at once → F1, F2 and F3 move from transferability or discovery to grounded.
- Certificate for the green belt → F5 moves to inspectable proof.
