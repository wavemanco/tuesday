I'll use the mock-interview prep skill for this, since it covers tailoring to a specific interviewer and company.
The skill's spec calls for a default L1 research pass (up to 6 searches) unless the user declined. Before I write the pack, I'll load the search tool and check what's public about Saltmarsh Games.
Search permission was denied, so I can't run the L1 research pass. I'll build the pack at L0 from your JD and background only, and say so in the pack. I'll save the pack as a file and present it here.
I saved the pack to `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-alone-part-2-rooms-case-7-denied-c526066a/f6e94aad-cde2-406c-815e-3c04fe4b2895/scratchpad/saltmarsh_live_ops_producer_interview_pack.md`. The full pack is below.

I could not run the company research. Web search was refused by permission, so the pack uses only your JD and your background. It has no company values, no interview-process detail and no information about Tobias. The two questions at the end would change the pack most.

# Live Operations Producer, Saltmarsh Games: interview pack (Femi)

**Interviewer:** Tobias Wrenfield, Head of Live Operations. I've assumed a hiring-manager round; this is not confirmed. Round length: 60 minutes.

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is scored: VAL (values), EXP (your experience, probed), JD (the role's stated requirements), CO (company knowledge), CASE (live problem).
- Guidance is scaffolding, not a script. Rehearse the beats in your own words.
- "Answer slot" means the honest form: say what you did, or say plainly that it was not yours or did not happen.

## 60-minute plan

1. **0–5 min, opening.** Give the 90-second arc (R1). Stay on what you did.
2. **5–25 min, live problems and scope.** Work the CASE questions (C1–C3) out loud. The two-title question (S1) is the one you most need to get right.
3. **25–40 min, probes on your record.** Expect the Skeptic and Prober questions (S2–S4, P1–P4). Hold, then concede where the material is thin.
4. **40–50 min, role fit.** Coordination across teams (C4), then the pressure question (X1).
5. **50–60 min, your questions.** Ask three or four from the reverse list, and leave time for Tobias to talk.

## The fit snapshot

Requirements are quoted from the JD. Evidence is quoted from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | transferability | Your material says one title's weekly calendar. Say that in those terms. Answer slot: if you planned across more than one title, say how; if not, say so and say how you would split capacity across two. |
| F2 | "coordinate design, art, engineering and community teams on each update" (JD) | "Wrote the release checklist our QA team still uses." (your message) | low | [grounded] | discovery | Your material shows coordination with QA only. Answer slot: describe an update that needed other teams; say what you did to coordinate and whose call each step was. |
| F3 | "own the post-event review and the KPIs it reports" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | low | [grounded] | transferability | Presenting numbers is not owning the KPIs. Answer slot: if you chose which KPIs were reported or ran a review, say how; if not, say so and say what you would measure. |
| F4 | "manage the release checklist with QA" (JD) | "Wrote the release checklist our QA team still uses." (your message) | high | [grounded] | none | The quote reaches the requirement. "Still uses" is your strongest word. Say you wrote it; the sign-off process is a separate question. |
| F5 | "3+ years producing live-service games or apps" (JD) | "4 years as an associate producer at a puzzle-game studio." (your message) | medium | [grounded] | presentation | The years are stated. Live-service is shown by F1's weekly drops, not by the title. Gate question in Step 1 below. |
| F6 | "experience running a content calendar" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | high | [grounded] | none | The quote reaches the requirement directly. |
| F7 | "comfortable with player-retention metrics" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | medium | [grounded] | presentation | The quote reaches the requirement in other terms. Defend-the-number slot: how the figure was defined and counted. |
| F8 | "clear written communication" (JD) | "Wrote the release checklist our QA team still uses." (your message) | low | [grounded] | presentation | One written artifact is the evidence. There is no writing sample. Bring one if you can. |
| F9 | Not in the JD text; a likely probe for mobile live-ops | "never worked on a game with in-app purchases." (your message) | none | [grounded] | capability | Your own negative. Words: "I haven't worked on a game with in-app purchases." Then how you would learn it, as a plan, never as a past. |
| F10 | Not in the JD text; the JD says coordinate, not lead | "Never led a team" (your message) | none | [grounded] | capability | Your own negative. Words: "I haven't led a team." Then what you did coordinate, in F2's terms. |

## The prohibited list

| Not coached | Basis | Honest form |
|---|---|---|
| Planned live events across two titles | Inflated form of F1 | "I ran the weekly content-drop calendar for our main title." The limit is the pack's observation: your material says one title, not two. |
| Owned the KPIs and the post-event review | Inflated form of F3 | "I presented the monthly retention numbers to the studio head." The material does not show ownership of the KPI set. |
| Led people or managed a team | Stated negative, F10 | "I haven't led a team." |
| Ran in-app purchase or monetization work | Stated negative, F9 | "I haven't worked on a game with in-app purchases." |

## Persona weights

Hiring-manager prior. No public profile was available, so the weights are not adjusted for the interviewer.

| Persona | Weight | How it shows up here | Counter-strategy |
|---|---|---|---|
| Case / Strategist | 5 (top) | Live calendar and diagnosis problems on the actual role | Clarify, then structure, then answer. Think aloud. |
| Skeptic | 4 | Two titles, no IAP, no team lead | Hold the core, concede the gap plainly, bring a ramp plan. |
| Data-Driven Prober | 3 | Retention figure and how it was counted | Name the definition you know. Say when you do not know. |
| Pressure | 2 | Sixty-second case for hiring you over an internal candidate | Pause, restate, hold through two follow-ups. |
| Conversational | 2 | Opening biography, casual question on live-ops games | 90-second arc. Treat casual questions as scored. |
| Values / Behavioral | 1 | Unpopular truth to leadership | Choose the true story. If none fits, say so. |
| Peer Evaluator | 1 | Seam with design and art | Propose seam principles. Do not invent the seam. |

## Question banks

### Case / Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Two titles each have a major update landing in the same week, and one has a server issue. How do you plan the next four weeks?" | CASE | [generic] | Clarify what is fixed and what is movable, and who owns each title's risk. Structure: capacity, dependencies, cut rules, communication. Decide, then say what you would check first. | A live problem, so it presupposes nothing about you. Tests the calendar line in a live form. |
| C2 | "An update slips two days before launch. Who do you call first, and what do you decide?" | CASE | [generic] | Structure the call tree: engineering, QA, community. Decide on a rule, not a feeling. Say what you would tell players and when. | Tests coordination and the QA checklist. No past claim. |
| C3 | "Day-7 retention drops ten percent the week after a content drop. Walk me through your diagnosis." | CASE | [generic] | Clarify the cohort and the definition first. Split into drop-in-release versus baseline shift. Name the assumption you would test first. | Tests the metrics comfort in the JD. No past claim. |
| C4 | "How would you coordinate design, art, engineering and community on one update?" | JD | [generic]; nearest quote: "Wrote the release checklist our QA team still uses." | Pick one update that needed more than one team and name the handoffs you ran. Answer slot: if you coordinated more than QA, say how; if the coordination was not yours, say so. | Scores F2. The JD raises it. The quote does not show four-team coordination, so the guidance does not claim it. |
| C5 | "Walk me through how you ran the weekly content-drop calendar." | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Story map from the quote: the calendar, weekly, the main title, two years. Name what the calendar decided, in your words. Answer slot: which calendar decisions were yours, and which were the studio's. | Premised on F1's quote, at the quote's scope. |

### Skeptic (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| S1 | "You have run one title's calendar. How would you run two at once?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | **Highest-ROI prep in this pack.** Hold: "For two years I ran the main title's weekly calendar." Concede plainly that two titles are new to you. Answer slot: how you would split capacity, and what you would need to know about each title first. Hold through two follow-ups by returning to the calendar. | F1 is where the two-title line presses hardest. The premise is the JD's; the guidance does not adopt a claim that you have done it. |
| S2 | "You have not worked with in-app purchases. Why would a monetized calendar be any different?" | JD | [grounded] "never worked on a game with in-app purchases." | Plain acknowledgment: "I haven't worked on a game with in-app purchases." Then a plan: which store and offer data you would look at first, and who owns it. | F9 is your stated negative. Never claim IAP work. |
| S3 | "You have never led a team. Why should we believe you can coordinate four of them?" | JD | [grounded] "Never led a team"; [grounded] "Wrote the release checklist our QA team still uses." | Plain acknowledgment: "I haven't led a team." Then the coordination you did, in the checklist's terms, and what you would do differently with four teams. Hold, then concede. | F10 and F2. The guidance does not extend the QA work into leadership. |
| S4 | "The JD asks you to own the post-event review and its KPIs. Which KPI would you have reported, and why that one?" | JD | [grounded] "Presented the monthly retention numbers to the studio head." | Answer slot: if you chose which figure went in the report, say which and why; if not, say so and say what you would measure first. | F3's thin bridge, asked so the honest answer is ready before the probe. |

### Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "How was the monthly retention figure you presented defined and counted?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Answer in your own words: the definition, the cohort, the window. If you do not know how it was counted, say so. Do not reconstruct a method you cannot repeat. | F7's defend-the-number slot. |
| P2 | "Which assumption behind that retention figure would you defend least?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Name the weakest assumption before they do. If you do not know one, say that. | F7's weakest-assumption move. |
| P3 | "How did you know a content drop had worked, and what did you tell the studio head?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years."; [grounded] "Presented the monthly retention numbers to the studio head." | Answer slot: if you measured a drop, name the metric and the baseline in your words. If the calendar was judged on something else, say what. | Joins F1 to F7. Asks for the measure, not the number. |
| P4 | "Walk me through the release checklist you wrote. What does QA do with it when a build fails?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." | You wrote it and QA still uses it. Answer slot: if you made the go or no-go call, say how; if QA made it, say so. | F4 and F8. Tests whether "manage with QA" is yours. |

### Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| X1 | "Sixty seconds: why should we hire you over someone who has run two titles?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio."; [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Hold the core: four years, a weekly calendar, a live title. Concede plainly that an internal candidate with two titles starts ahead. Say what you would do in the first 90 days to close the gap. Hold through two follow-ups. | Tests composure. The hold is only what your quotes carry. |
| X2 | "That retention number. How much of it was actually you?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Say what you presented and what you did not own. Pause before answering. | F3 and F7, asked as a probe on credit. |

### Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio."; [grounded] "Wrote the release checklist our QA team still uses." | A 90-second arc: the studio, the calendar, the checklist, the retention report. Stop there. | Opening question. Casual, and scored. |
| R2 | "What are you playing right now in mobile live-ops, and what would you change?" | CO | [generic] | Name a game you know and one specific change you would make. Make no claim about the company. | The JD's mobile focus, asked casually. |

### Values / Behavioral (weight 1)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V1 | "Tell me about a time you had to tell leadership something they did not want to hear." | VAL | [generic]; nearest quote: "Presented the monthly retention numbers to the studio head." | Answer slot: if a retention result you presented was bad news, tell that one. If none was, say so and give the nearest case. | Open prompt. No values were detected, so this is a selection scaffold, not a mapped story. |

### Peer Evaluator (weight 1)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Design and art run their own schedules. Where does the seam with live-ops sit, and what happens when you disagree?" | JD | [generic] | Propose seam principles: who sets the date, who sets the scope. Do not invent a history of disagreements. | Low weight for a hiring-manager round, kept so the style is not new to you live. |

**Coverage.** R1 maps to S1, C1, C5. R2 maps to C4, S3. R3 maps to S4, P1, P2. R4 maps to P4. R5 is covered by F5 and waits on the Step 1 gate answer. R6 maps to C5 and P3. R7 maps to P1, P2, X2. R8 maps to P4 and R1.

## Reverse questions

1. "What would the first two live events I own look like, and which title would I start on?" Why it lands: it turns the two-title gap into a planning question.
2. "Where does QA sign-off sit in the release process, and who holds the go or no-go?" Why it lands: it checks F4's scope before you rely on it.
3. "How do you define the KPIs the post-event review reports, and who sets them?" Why it lands: it tests F3 directly and shows you know the job.
4. "How do you handle in-app purchase timing against content drops?" Why it lands: it turns the IAP gap into a shared problem.
5. "What does success look like for this role at six months?" Why it lands: it gives you the bar to aim at.

## Sources

- Provided documents: the JD text and your background message.
- Searches: three standard searches were sent (company, company values and careers, the interviewer). All three were refused by permission; none returned results.
- Fetches: 0 of 2.

**Research tier:** L0 (L1 declined by permission)

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | unavailable | Values cheat sheet not built. Search refused. |
| 2. Saltmarsh Games interview process, live ops | unavailable | Loop structure and persona weights. Search refused. |
| 3. Saltmarsh Games strategy and recent news | skipped | The JD fixes the calendar and KPI questions; a strategy brief would only add CO depth. |
| 4. Tobias Wrenfield, Saltmarsh Games | unavailable | Interviewer read and a tailored reverse question. Search refused. |
| 5. Representative live-ops producer JD | skipped | The JD you supplied fixes the fit snapshot. |

## Upgrade menu

- The round type (hiring manager, panel, or other) → restructures the persona weights.
- The company's values or careers page → a values cheat sheet and mapped stories.
- Tobias's public profile, if you can share it → a tailored reverse question and interviewer-specific weights.
- Whether "3+ years producing live-service" was a hard filter → settles the gate row F5.
- Any calendar or retention numbers you can state → the answer slots on P1–P3 become grounded.

---

Two quick questions, and each one changes the pack:

1. Is Friday's round a hiring-manager interview with Tobias, a panel, or something else?
2. Would the JD's "3+ years producing live-service games or apps" count your four years as an associate producer on a puzzle game with weekly drops? If it is a hard filter, that matters for F5.

Two offers, neither pushed: I can run a drill with me as Tobias, starting with S1, the two-title question. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, to carry into later sessions. If you'd like this as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh_live_ops_producer_interview_pack.md -----
# Live Operations Producer, Saltmarsh Games: interview pack (Femi)

**Interviewer:** Tobias Wrenfield, Head of Live Operations. Relationship assumed to be hiring manager; not yet confirmed. Round length: 60 minutes.
**Research tier:** L0. Web search was declined by permission, so company values, interview process and the interviewer's public background are not in this pack. The pack is built only from the JD and your background message.

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored: VAL (values), EXP (your experience, probed), JD (the role's stated requirements), CO (company knowledge), CASE (live problem).
- Guidance is scaffolding, not a script. Rehearse the beats in your own words.
- "Answer slot" means the honest form: say what you did, or say plainly it was not yours or did not happen.

## 60-minute plan

1. **0 to 5 min, opening.** Give the 90-second arc (C5 / R1). Stay on what you did.
2. **5 to 25 min, live problems and scope.** Work the CASE questions (C1 to C3) out loud. Name the two-title question (S1) as the one you most need to get right.
3. **25 to 40 min, probes on your record.** Expect the Skeptic and Prober questions (S2 to S4, P1 to P4). Hold, then concede where the material is thin.
4. **40 to 50 min, role fit.** Coordination with design, art, engineering and community (C4), and the pressure question (X1).
5. **50 to 60 min, your questions.** Ask 3 to 4 from the reverse-question list, and leave time for the interviewer to talk.

## The fit snapshot

Requirements are quoted from the JD. Evidence is quoted from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | transferability | Your material says one title's weekly calendar. Say that in those terms. Answer slot: if you planned across more than one title, say how; if not, say so and say how you would split capacity across two. |
| F2 | "coordinate design, art, engineering and community teams on each update" (JD) | "Wrote the release checklist our QA team still uses." (your message) | low | [grounded] | discovery | Your material shows coordination with QA only. Answer slot: describe an update that needed other teams; say what you did to coordinate and whose call each step was. |
| F3 | "own the post-event review and the KPIs it reports" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | low | [grounded] | transferability | Presenting numbers is not owning the KPIs. Answer slot: if you chose which KPIs were reported or ran a review, say how; if not, say so and say what you would measure. |
| F4 | "manage the release checklist with QA" (JD) | "Wrote the release checklist our QA team still uses." (your message) | high | [grounded] | none | The quote reaches the requirement. "Still uses" is the strongest word you have. Say you wrote it; the sign-off process is a separate question. |
| F5 | "3+ years producing live-service games or apps" (JD) | "4 years as an associate producer at a puzzle-game studio." (your message) | medium | [grounded] | presentation | The years are stated. Live-service is shown by F1's weekly drops, not by the title. Gate question in Step 1 (d). |
| F6 | "experience running a content calendar" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | high | [grounded] | none | The quote reaches the requirement directly. |
| F7 | "comfortable with player-retention metrics" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | medium | [grounded] | presentation | The quote reaches the requirement in other terms. Defend-the-number slot: how the figure was defined and counted. |
| F8 | "clear written communication" (JD) | "Wrote the release checklist our QA team still uses." (your message) | low | [grounded] | presentation | One written artifact is the evidence. Your material has no writing sample. Bring one if you can. |
| F9 | Not in the JD text; a likely probe for mobile live-ops | "never worked on a game with in-app purchases." (your message) | none | [grounded] | capability | Your own negative. Words: "I haven't worked on a game with in-app purchases." Then how you would learn it, as a plan, never as a past. |
| F10 | Not in the JD text; the JD says coordinate, not lead | "Never led a team" (your message) | none | [grounded] | capability | Your own negative. Words: "I haven't led a team." Then what you did coordinate, in F2's terms. |

## The prohibited list

| Not coached | Basis | Honest form |
|---|---|---|
| Planned live events across two titles | Inflated form of F1 | "I ran the weekly content-drop calendar for our main title." The limit is the pack's observation: your material says one title, not two. |
| Owned the KPIs and the post-event review | Inflated form of F3 | "I presented the monthly retention numbers to the studio head." The pack observes that the material does not show ownership of the KPI set. |
| Led people or managed a team | Stated negative, F10 | "I haven't led a team." |
| Ran in-app purchase or monetization work | Stated negative, F9 | "I haven't worked on a game with in-app purchases." |

## Persona weights

Hiring-manager prior, since the interviewer is Head of Live Ops and the round is likely a hiring-manager round. Weights are not adjusted by interviewer signals, because no public profile was available.

| Persona | Weight | How it shows up here | Counter-strategy |
|---|---|---|---|
| Case / Strategist | 5 (top) | Live calendar and diagnosis problems on the actual role | Clarify, then structure, then answer. Think aloud. |
| Skeptic | 4 | Two titles, no IAP, no team lead | Hold the core, concede the gap plainly, bring a ramp plan. |
| Data-Driven Prober | 3 | Retention figure and how it was counted | Name the definition you know. Say when you do not know. |
| Pressure | 2 | Sixty-second case for hiring you over an internal candidate | Pause, restate, hold through two follow-ups. |
| Conversational | 2 | Opening biography and a casual question on live-ops games | Give a 90-second arc. Treat casual questions as scored. |
| Values / Behavioral | 1 | Unpopular truth to leadership | Choose the true story. If none fits, say so. |
| Peer Evaluator | 1 | Seam with design and art | Propose seam principles. Do not invent the seam. |

## Question banks

Provenance is quoted from the fit snapshot, or from the JD, or [generic]. Each guidance cell rests only on its own row's quotes.

### Case / Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Two titles each have a major update landing in the same week, and one has a server issue. How do you plan the next four weeks?" | CASE | [generic] | Clarify: what is fixed, what is movable, who owns each title's risk. Structure: capacity, dependencies, cut rules, communication. Decide, then say what you would check first. The question names no past event. | Tests the JD's calendar line in a live form. The question is a live problem, so it presupposes nothing about you. |
| C2 | "An update slips two days before launch. Who do you call first, and what do you decide?" | CASE | [generic] | Structure the call tree: engineering, QA, community. Decide on a rule, not a feeling. Say what you would tell players and when. | Tests coordination and the QA checklist. No past claim. |
| C3 | "Day-7 retention drops ten percent the week after a content drop. Walk me through your diagnosis." | CASE | [generic] | Clarify the cohort and the definition first. Then split into drop-in-release versus baseline shift. Name the assumption you would test first. | Tests the metrics comfort in the JD. No past claim. |
| C4 | "How would you coordinate design, art, engineering and community on one update?" | JD | [generic]; nearest quote: "Wrote the release checklist our QA team still uses." | Selection scaffold: pick one update that needed more than one team. Name the handoffs you ran. If the handoffs were not yours, say so and describe how you would run them. Answer slot: "if you coordinated more than QA, say how; if the coordination was not yours, say so." | Scores F2. The JD raises it. The quote does not show four-team coordination, so the guidance does not claim it. |
| C5 | "Walk me through how you ran the weekly content-drop calendar." | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Story map from the quote: the calendar, weekly, the main title, two years. Name what the calendar decided in your words. Answer slot: which calendar decisions were yours to make, and which were the studio's. | Premised on F1's quote, at the quote's scope. |

### Skeptic (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| S1 | "You have run one title's calendar. How would you run two at once?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | **Highest-ROI prep in this pack.** Hold: "For two years I ran the main title's weekly calendar." Concede plainly: two titles are new to you. Answer slot: how you would split capacity, and what you would need to know about each title first. Hold through two follow-ups by returning to the calendar. | F1 is where the JD's two-title line presses hardest. The question's premise is the JD's, and the guidance does not adopt the claim that you have done it. |
| S2 | "You have not worked with in-app purchases. Why would a monetized calendar be any different?" | JD | [grounded] "never worked on a game with in-app purchases." | Plain acknowledgment: "I haven't worked on a game with in-app purchases." Then a plan: which store and offer data you would look at first and who owns it. | F9 is your stated negative. Never claim IAP work. |
| S3 | "You have never led a team. Why should we believe you can coordinate four of them?" | JD | [grounded] "Never led a team"; [grounded] "Wrote the release checklist our QA team still uses." | Plain acknowledgment: "I haven't led a team." Then the coordination you did, in the QA checklist's terms, and what you would do differently with four teams. Hold, then concede. | F10 and F2. The guidance does not extend the QA work into leadership. |
| S4 | "The JD asks you to own the post-event review and its KPIs. Which KPI would you have reported, and why that one?" | JD | [grounded] "Presented the monthly retention numbers to the studio head." | Answer slot: if you chose which figure went in the report, say which and why; if you did not choose it, say so and say what you would measure first. | F3's thin bridge. Asked so that the honest answer is ready before the probe. |

### Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "How was the monthly retention figure you presented defined and counted?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Answer in your own words: the definition, the cohort, the window. If you do not know how it was counted, say so. Do not reconstruct a method you cannot repeat. | F7's defend-the-number slot. |
| P2 | "Which assumption behind that retention figure would you defend least?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Name the weakest assumption before they do. If you do not know one, say that. | F7 weakest-assumption move. |
| P3 | "How did you know a content drop had worked, and what did you tell the studio head?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years."; [grounded] "Presented the monthly retention numbers to the studio head." | Answer slot: if you measured a drop, name the metric and the baseline in your words. If the calendar was judged on something else, say what. | Joins F1 to F7. Asks for the measure, not the number. |
| P4 | "Walk me through the release checklist you wrote. What does QA do with it when a build fails?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Story map: you wrote it, QA still uses it. Answer slot: if you made the go or no-go call, say how; if QA made it, say so. | F4 and F8. Tests whether "manage with QA" is yours. |

### Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| X1 | "Sixty seconds: why should we hire you over someone who has run two titles?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio."; [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Hold the core: four years, a weekly calendar, a live title. Concede plainly: an internal candidate with two titles starts ahead. Say what you would do in the first 90 days to close it. Hold through two follow-ups. | Tests composure. The hold is only what your quotes carry. |
| X2 | "That retention number. How much of it was actually you?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Answer: what you presented, and what you did not own. Pause before answering. | F3 and F7. Asked as a probe on credit. |

### Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio."; [grounded] "Wrote the release checklist our QA team still uses." | Give a 90-second arc: the studio, the calendar, the checklist, the retention report. Stop there. | Opening question. Casual, and scored. |
| R2 | "What are you playing right now in mobile live-ops, and what would you change?" | CO | [generic] | Name a game you know and one specific change you would make. No claim about the company. | The JD's mobile focus, asked casually. |

### Values / Behavioral (weight 1)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V1 | "Tell me about a time you had to tell leadership something they did not want to hear." | VAL | [generic]; nearest quote: "Presented the monthly retention numbers to the studio head." | Answer slot: if a retention result you presented was bad news, tell that one. If none was, say so and give the nearest case. | Open prompt. No values were detected, so this is a selection scaffold, not a mapped story. |

### Peer Evaluator (weight 1)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Design and art run their own schedules. Where does the seam with live-ops sit, and what happens when you disagree?" | JD | [generic] | Propose seam principles: who decides the date, who decides the scope. Do not invent a history of disagreements. | Low weight for a hiring-manager round, kept so the style is not new live. |

**Coverage.** R1 maps to S1, C1, C5. R2 maps to C4, S3. R3 maps to S4, P1, P2. R4 maps to P4. R5 is covered by F5 and is pending the Step 1 (d) answer. R6 maps to C5 and P3. R7 maps to P1, P2, X2. R8 maps to P4 and R1.

## Reverse questions

1. "What would the first two live events I own look like, and which title would I start on?" Why it lands: it turns the two-title gap into a planning question.
2. "Where does the QA sign-off sit in the release process, and who holds the go or no-go?" Why it lands: it checks F4's scope before you rely on it.
3. "How do you define the KPIs the post-event review reports, and who sets them?" Why it lands: it tests F3 directly and shows you know the job.
4. "How do you handle in-app purchase timing against content drops?" Why it lands: it turns the IAP gap into a shared problem.
5. "What does success look like for this role at six months?" Why it lands: it gives you the bar to aim at.

## Sources

- Provided documents: the JD text and your background message.
- Searches: 0 of 6 run. Three standard searches were sent for the company, its values and the interviewer. All three were refused by permission. No results were returned.
- Fetches: 0 of 2.

**Research tier:** L0 (L1 declined by permission)

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | unavailable | Values cheat sheet, not built. Search refused. |
| 2. Saltmarsh Games interview process, live ops | unavailable | Loop structure and persona weights. Search refused. |
| 3. Saltmarsh Games strategy and recent news | skipped | The JD fixes the calendar and KPI questions; the strategy brief would only add CO depth. |
| 4. Tobias Wrenfield Saltmarsh Games | unavailable | Interviewer read and tailored reverse question. Search refused. |
| 5. Representative live-ops producer JD | skipped | The JD you supplied fixes the fit snapshot. |

## Upgrade menu

- A line on the round type (hiring manager, panel, or other) → restructures the persona weights.
- The company's values or a careers page → a values cheat sheet and mapped stories.
- Tobias Wrenfield's public profile, if you can share it → a tailored reverse question and interviewer-specific weights.
- Whether the JD's "3+ years producing live-service" was a hard filter → the gate row in F5 is settled.
- Any retention or calendar numbers you can state → answer slots on P1 to P3 become grounded.
