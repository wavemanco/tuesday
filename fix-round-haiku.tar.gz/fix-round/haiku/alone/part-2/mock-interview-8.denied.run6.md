Your prep pack is saved as `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-alone-part-2-rooms-case-8-denied-3768de7e/05880617-2aa5-41f4-b5b8-7e3e7c1e4376/scratchpad/ashgrove_credit_union_member_experience_lead_interview_pack.md`. I built it as a three-round loop, with 25 questions in total: 8 for the recruiter, 9 for the Head of Member Services and 8 for the panel.

The two gaps the panel will press on are the ones you stated yourself: no contact-centre work, and no presenting above regional level. The first matters most, because the JD's headline scope is end-to-end ownership across branches and the contact centre. Question B4 is the one to rehearse hardest.

Say the word and I'll play the Skeptic on B4, the contact-centre scope question.

I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.

If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove_credit_union_member_experience_lead_interview_pack.md -----
# Ashgrove Credit Union: Member Experience Lead interview pack

- **Role:** Member Experience Lead
- **Company:** Ashgrove Credit Union (member-owned, about 900 staff)
- **Mode:** Loop, three rounds on 20 November 2026
  - Round 1: 30 minutes with the recruiter
  - Round 2: 45 minutes with the Head of Member Services, your future manager, mostly behavioural
  - Round 3: 60 minutes with a panel of two branch managers, including a 20-minute complaint escalation case; the panel scores against the four values
- **Interviewer names:** not given. Round 2 and round 3 interviewers are not yet assigned.
- **Changelog:** first delivery.
- **Built on:** the JD you pasted, your four values as copied from the site, the recruiter's email as you quoted it, your summary of the July 2026 strategy brief, and your background message. No research was run (see Sources).

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script. Rehearse only what you actually did, in your own words.

| Type | Name | What it tests |
|---|---|---|
| VAL | Behavioural / values | Whether past behaviour shows the published values |
| EXP | Experience deep-dive | Whether your CV claims hold up under questions about what you did |
| JD | Role / JD-driven | Whether you can do the listed job, including its gaps |
| CO | Company and strategy | Whether you can think at Ashgrove's level about its plans |
| CASE | Live problem | Structure and reasoning on a problem from the role |

## Fit snapshot (shared across all rounds)

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches and the contact centre" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | transferability | Keep to the quote's scope: "I handled the branch's formal complaints log." End to end across branches is not in your words. Answer slot: if you set any step beyond the log, say which and how you decided, in your own words; if you did not, say so and stay with the log. |
| F2 | "across branches and the contact centre" (JD) | "Never worked in a contact centre" (your message) | none | [grounded] | capability | Your stated gap. Words: "Never worked in a contact centre." Then how you would close it, said as a plan: which contact-centre work you would learn first. Never a claim to contact-centre work. |
| F3 | "report monthly on complaint volumes" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | medium | [grounded] | presentation | Same words, same scope: "I built the monthly complaints spreadsheet, and my regional manager uses it." Volumes are what the quote reaches; nothing wider is added. |
| F4 | "resolution times" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | low | [grounded] | discovery | The quote does not show whether resolution times were on the spreadsheet. Answer slot: if they were, say how they were counted; if they were not, say so and say what you would measure first. |
| F5 | "comfortable with Excel reporting" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | medium | [grounded] | none | No gap on the quote's terms. The quote says spreadsheet, not Excel, so expect a depth probe. Say what you built in it, in your words. |
| F6 | "4+ years in financial-services customer operations" (JD) | "6 years in retail banking, the last 3 as branch supervisor" (your message) | medium | [grounded] | none | No gap. Say it as your years, in the quote's words. Length of experience is not a gate; it is met on your message. |
| F7 | "experience handling regulated complaints" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | presentation | The quote reaches the requirement in other terms. Keep it as written. "Regulated" is the JD's word, not yours; do not adopt it for your work. The probe on rules is handled in B2, not here. |
| F8 | "coach branch supervisors on escalations" (JD) | "trained new tellers on our escalation script" (your message) | low | [inferred] | transferability | Derived by adjacency from the teller-training quote; coaching supervisors is this pack's inference, not your sentence. Words: "I trained new tellers on our escalation script." Any wider step is an answer slot: if you have coached anyone on escalations beyond tellers, say who and what you did; if not, say so and say how you would start with supervisors. |
| F9 | "work with digital teams on self-service journeys" (JD) | none given | none | [grounded] | discovery | Nothing in your material touches digital or self-service work. Answer slot: if you have worked with a digital team on a customer journey, say what you did; if not, say so and say how you would start. |
| F10 | "confident presenting to senior leaders" (JD) | "I've never presented to anyone above regional level" (your message) | none | [grounded] | capability | Your stated gap. Words: "I've never presented to anyone above regional level." Then how you would build the skill, said as a plan, never as a past. |

**Reading the snapshot.** No requirement in this JD is a gate, so there is no hard-gate row. Your 6 years in retail banking meet the 4+ years requirement on your message. The two real gaps are both ones you stated: contact-centre work (F2) and presenting above regional level (F10). F1 is the scope objection the interviewers are most likely to press.

## Prohibited list

These claims are not coached anywhere in this pack, and each has its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Ran the complaints process end to end across branches and the contact centre | Inflated form of F1 (the JD's wording) | "I handled the branch's formal complaints log." The limit is this pack's observation: your material says the log, at branch level. |
| Contact-centre experience of any kind | Negative you stated (F2) | "Never worked in a contact centre." |
| Presented to senior leaders, or above regional level | Negative you stated (F10) | "I've never presented to anyone above regional level." |
| Handled regulated complaints to a defined external standard | Inflated form of F7 | "I handled the branch's formal complaints log." |
| Owned resolution-time reporting | Inflated form of F4 (no quote carries resolution times) | "I built the monthly complaints spreadsheet our regional manager uses." |
| Coached branch supervisors on escalations | Inflated form of F8 | "I trained new tellers on our escalation script." |

## Grounding brief

Your summary of Ashgrove's July 2026 strategy, as you wrote it. I have only your summary, not the brief itself, so check the wording against the brief before you quote it back.

- [grounded] "move 40% of member service to digital channels by 2028". Vocabulary: member service, digital channels.
- [grounded] "consolidate eight branches into five hubs over 2027". Vocabulary: hubs. The brief's main consequence for a complaints lead is branch-level change, so expect it to come up.
- [grounded] "launch a small-business lending product in Q1 2027". Relevant only if the interviewer raises new complaint types.
- [grounded] "the main competitive pressure is app-only banks". Vocabulary: app-only banks, self-service.

## Values cheat sheet

Values copied from ashgrovecu.org/about/values on 11 November 2026, as you pasted them. I have not fetched the page.

| Value | Working meaning | Mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | F1: "I handled the branch's formal complaints log". The quote carries no member-side decision. Selection scaffold: pick a formal complaint where the member's need changed the outcome; if none comes to mind, say so plainly, then give the nearest one your log carries. |
| Plain Words | If a member needs it explained twice, it was written wrong | F8: "trained new tellers on our escalation script". The quote carries the teaching. Selection scaffold: pick a time an explanation had to be given again; if none comes to mind, say so, then give the nearest thing your training carries. Do not add results. |
| Neighbours, Not Numbers | Every branch is part of its town | No quote carries a community story. Selection scaffold: pick a time a branch's number and its place in its town pulled apart; if none comes to mind, say so, then say how you would keep counts from being the whole story. |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | F3: "I built the monthly complaints spreadsheet our regional manager uses". The quote carries no finding. Selection scaffold: pick a problem you found and whether you kept hold of it until it was solved; if none comes to mind, say so plainly and say how you would keep hold of one. |

## Persona weights by round

| Round | Relationship (recruiter's email) | Prior | Adjustment | Weights |
|---|---|---|---|---|
| 1. Recruiter screen, 30 min | Recruiter | Conversational plus light Skeptic | None: no interviewer profile | Conversational 3, Skeptic 2, Values 2, Prober 1 |
| 2. Head of Member Services, 45 min | Hiring manager, your future manager | Case plus Skeptic | The recruiter says mostly behavioural, so Values moves to the top. Case stays for the hub and digital problems. | Values 3, Skeptic 2, Case 2, Pressure 1, Prober 1 |
| 3. Panel of two branch managers, 60 min | Two peers in the process | Blend of Peer Evaluator and Values | The panel scores against the four values, so Values is top. The case is 20 of 60 minutes, so Case gets two. | Values 4, Case 2, Peer 1, Prober 1 |

Persona weights across the three rounds, with how each shows up here:

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioural | Scored stories against the four values; STAR-shaped asks | High in rounds 2 and 3: the recruiter says round 2 is mostly behavioural and the panel scores on values | Map a story to each value where a quote carries one; where none does, say so and take the honest branch |
| Skeptic | Probes the scope gap and the presenting gap; "why leave, why here" | High in round 2, where the future manager is checking the gaps; light in round 1 | Rehearse B4 until it is routine; hold your stated negatives in your own words |
| Case / Strategist | Live problems: the hub move, the digital shift, the complaint escalation | High in round 2 (B6, B7) and round 3 (C4, C5) | Clarify, then structure: objective, segmentation, metrics, risks |
| Pressure | Interrupts and time-boxes on the presenting gap | Medium, round 2 only (B8); no interviewer profile to raise it | Pause, restate, hold through two follow-ups, then concede the plan |
| Prober | Asks how figures were counted | Medium across rounds: the spreadsheet is the CV's one metric and the denominator will come up | Name the weakest assumption before it is asked; say plainly what you do not know |
| Conversational | Opening biography, motivation, a casual Excel question | High in round 1; casual questions are still scored | A pre-scripted 90-second arc; treat casual questions as scored |
| Peer Evaluator | The seam between branches and complaints; disagreement | Medium in round 3: branch managers are peers in the process | Propose seam principles, not a seam you have not seen |

## Round 1: recruiter screen (30 minutes)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through your six years in retail banking." | EXP | [grounded] "6 years in retail banking, the last 3 as branch supervisor" (your message) | A 90-second arc using only the quote's beats: six years in retail banking, the last three as a branch supervisor. Then the two things you did in that role, the complaints log and the teller training, each in one sentence and your own words. Add no roles or dates. | Conversational opener, but scored. F6 is the CV fact it rests on. |
| A2 | "What do you use the spreadsheet you built for, day to day?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" (your message) | Say what it tracks and who uses it, in your words. If you used formulas, pivots or charts in it, name the one you can explain. If you have not used a feature, say so. | Casual wording on a JD requirement (Excel reporting, F5). Rehearse only what you did. |
| A3 | "Why this role, and why now?" | VAL | [grounded] "6 years in retail banking, the last 3 as branch supervisor" (your message) | About 60 seconds, in your words. Say what from your branch years makes this the next step. Do not invent motives the material does not carry; if your reason is about Ashgrove's plans, say it as your own view. | Motivation is scored in every round. The guidance can rest only on the quote, so no reason is added for you. |
| A4 | "Why would someone who has never worked in a contact centre be right for this role?" | JD | [grounded] "Never worked in a contact centre" (your message); [grounded] "I handled the branch's formal complaints log" (your message) | Say the plain fact in the quote's words, then the nearest thing your material carries: the branch-side complaints log, at its own scope. Then how you would learn the contact-centre side first, as a plan. Hold the fact; do not argue it away. | F2 is the stated gap. Met here as a screening check; B4 is the same objection rehearsed to depth. |
| A5 | "Why leave a branch role after three years as a supervisor?" | EXP | [grounded] "6 years in retail banking, the last 3 as branch supervisor" (your message) | Answer from the quote's facts: three years as a branch supervisor. Then what you want next, in your words. Make no claims about problems at your branch. | The Skeptic's why-now probe. The answer is built from the one sentence you gave. |
| A6 | "Tell me about a formal complaint where the member's need changed what you decided." | VAL | [grounded] "I handled the branch's formal complaints log" (your message) | Selection scaffold: pick a complaint from the log where the member's need changed the decision. Say what you decided and why, in your words. If no such case comes to mind, say so plainly, then give the nearest one the log carries. | Maps to Members First. The quote carries the log, not the member-side decision, so this is a scaffold. |
| A7 | "Tell me about the escalation script you taught, and how you checked the tellers had it." | VAL | [grounded] "trained new tellers on our escalation script" (your message) | Say what you taught, in the order you taught it. If you checked understanding, say how; if you did not check, say so. Do not add results. | Maps to Plain Words through the teller training. The "how you checked" clause is an answer slot. |
| A8 | "Walk me through what the monthly complaints spreadsheet counts." | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" (your message) | Name the counting unit in your words, then the assumption you would defend least. Say plainly if you do not know how a figure was built. Answer slot: if you chose the counting rule, say how; if your regional manager set it, or you do not know, say so. | Defend-the-number question on the CV's one metric (F3, F5). Rehearse precise attribution. |

**Reverse questions (round 1)**

| # | Question | Why it lands |
|---|---|---|
| R1-1 | "How is the panel's values scoring weighted, and is the case scored on its own?" | Shows you read the scoring, and tells you where to put your effort. |
| R1-2 | "Who will I work most with in the first month, and what do they need from complaints data?" | Places the role among stakeholders and gives you a first-month picture before round 2. |

## Round 2: Head of Member Services (45 minutes, mostly behavioural)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time you had to tell someone senior something they did not want to hear." | VAL | [generic] | Selection scaffold: pick an instance; name the message and the person's level in your words; say what happened next. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, which is how you would handle it. | Values / Behavioural. Tests Own the Fix and Members First. No claim about your past is made here. |
| B2 | "Tell me about a formal complaint from the log, and what happened to it." | EXP | [grounded] "I handled the branch's formal complaints log" (your message) | Say the steps you took yourself, in order. Say who else handled it and what you handed over. Answer slot: if you kept hold of it until it was solved, say how; if someone else closed it or it was left open, say so. Second slot, because the JD asks about regulated complaints: if it followed a set external timescale or rules, say which and how you tracked against them; if not, or you do not know, say so. | Covers F1 and F7 and tests Own the Fix. Expect the rules probe here, not in the fit snapshot. |
| B3 | "How would you coach a branch supervisor who has escalated the wrong complaint?" | JD | [grounded] "trained new tellers on our escalation script" (your message) | Structure: first find out why the escalation was made; then coach against the script with the supervisor, not at them; then check the decision together. Answer slot: if you have coached anyone on escalations beyond tellers, say who and what you did; if not, say so and say how you would start. | Covers the coaching requirement (F8), the one with the thinnest evidence. The coaching claim is not asserted for you. |
| B4 | "This role owns complaints end to end across the branches and the contact centre. You've never worked in a contact centre. What makes you the right person to own that end to end?" | JD | [grounded] "Never worked in a contact centre" (your message); [grounded] "I handled the branch's formal complaints log" (your message) | **Highest-ROI prep in this pack.** Hold: "Never worked in a contact centre." Then what the log taught you about how complaints move, at its own scope. Follow-up 1: return to the log, do not add to it. Follow-up 2: concede the gap plainly: "The contact-centre side is what I would learn first, starting with..." Concede the gap, never a claim. Answer slot: if any part of ending a complaint end to end was yours to set, say which and how you decided; if none was, say so. | The JD's headline scope meets the stated gap here (F1, F2). A non-defensive hold-then-concede is worth more than any added claim. Rehearse it until it is routine. |
| B5 | "You've never presented above regional level. What would you do in your first month to be ready to present to senior leaders?" | JD | [grounded] "I've never presented to anyone above regional level" (your message) | Say the plain fact: "I've never presented to anyone above regional level." Then the plan in your words: what you would practise and with whom. A dry run with your regional manager is a plan, not a past. Do not say you have presented to senior leaders. | F10 is a capability gap. The stated negative is the only words here, and the plan is the answer. |
| B6 | "The strategy says eight branches become five hubs over 2027. What would you look at first to keep complaints from getting worse during the move?" | CASE | [grounded] "consolidate eight branches into five hubs over 2027" (your summary of the brief) | Clarify first: which complaints move, which members lose a branch they use, whether hubs keep a local contact. Objective: no member loses a way to get a complaint resolved. Segmentation: by branch, complaint type, channel. Metrics: volumes by branch before and after, resolution times, repeat contacts. Risks: a spike in complaints, members in towns losing a branch, regulatory timelines. Do not say the consolidation is good or bad. | A live problem from the brief's own plan. It asks about the future, so it presupposes nothing about your past. |
| B7 | "The plan moves 40% of member service to digital by 2028. Which complaints should never be pushed into the app?" | CASE | [grounded] "move 40% of member service to digital channels by 2028" (your summary of the brief); the JD line "work with digital teams on self-service journeys" is the raising source | Structure: complaint types that need a person (disputes with no clear rule, anything with a deadline, anything involving a vulnerable member); how a complaint routes from the app back to a person; how you would bring complaints data into a self-service journey with the digital team. Claim no digital experience. | Covers F9, the digital requirement with no evidence. A CO-style question grounded in the brief. |
| B8 | "Sixty seconds: why should we trust you to take complaint trends to senior leaders, when you haven't done it?" | JD | [grounded] "I've never presented to anyone above regional level" (your message); [grounded] "I built the monthly complaints spreadsheet our regional manager uses" (your message) | Pressure question. Hold: "I've never presented to anyone above regional level." Then what you did carry: "I built the monthly complaints spreadsheet our regional manager uses", at its own scope. Follow-up 1 ("so what's different?"): return to the spreadsheet. Follow-up 2: concede: "You'd want me to prove it before I'm in front of senior leaders; I would agree and start with..." Never fold on the spreadsheet's scope. | F10 under pressure. Hold-then-concede is the structure; the held position is the one the quotes carry. |
| B9 | "Did your spreadsheet track resolution times, and how were they counted?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" (your message) | Say whether it had resolution times. If it did, name the start and stop of the clock in your words, and the assumption you would defend least. If it did not, say so, and say what you would measure first. | F4 and the JD's resolution-times requirement. The answer is the slot; there is no story to rehearse. |

**Reverse questions (round 2)**

| # | Question | Why it lands |
|---|---|---|
| R2-1 | "What would a good first 90 days look like for complaints, and what is the first number you would want me to fix?" | Signals an outcomes focus and gets the manager's priorities in their own words. |
| R2-2 | "How would you want the hub move to show up in complaints data before the first hub opens?" | Shows you read the 2027 plan and places the complaints role in it. |
| R2-3 | "When digital teams build a self-service journey, where do complaints come in, and who decides what the journey does with them?" | Tests the seam the JD names with digital teams. |

No interviewer profile exists yet, so no reverse question is tied to the manager's career path. The upgrade menu says what a name would unlock.

## Round 3: panel of two branch managers (60 minutes, scored on values)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time the member's side of the counter and the process pulled in different directions." | VAL | [grounded] "I handled the branch's formal complaints log" (your message) | Selection scaffold: pick an instance; say which side you took and why, in your words. If none comes to mind, say so plainly, then give the nearest complaint the log carries. | Members First, scored by the panel. The quote carries the log, so this is a scaffold. |
| C2 | "When did a branch target and a branch's standing in its town pull against each other?" | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" (your message) | Selection scaffold: pick an instance where a number and a branch's place in its town did not line up. If none comes to mind, say so, then say how you would keep counts from being the whole story, using the spreadsheet as the example you can describe. | Neighbours, Not Numbers. No quote carries a community story, so the spreadsheet is only the nearest thing. |
| C3 | "Tell me about a problem you found that nobody had asked you to fix, and what happened to it." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" (your message) | Selection scaffold: pick a problem you found and whether you kept hold of it until it was solved. If the spreadsheet surfaced it, say so. If no such problem comes to mind, say so plainly and say how you would keep hold of one. | Own the Fix. The quote is the nearest tool, not a finding. |
| C4 | Case, 20 minutes: "A member has complained three times about the same fee. Each branch answer so far has been no, and the member now says they will take it to the regulator. You have twenty minutes. Talk us through what you do." | CASE | [generic] | Use the time roughly as three minutes to clarify, five to structure, ten to decide, two to close. Clarify: what the fee is, what each answer said, what the member needs to hear. Objective: the member gets a clear decision they can follow, and does not need a third contact. Approach: name one owner now; check the facts across branch and contact-centre records; decide, or escalate with a recommendation and a date; reply in plain words. Metrics: repeat contacts, time to resolution, reopened complaints. Risks: a missed regulatory deadline, a branch decision overturned, lost trust. | A live problem in the role. It presupposes nothing about your past; the scenario is generic, not Ashgrove's process. Values are scored in how the case ends. |
| C5 | Case follow-up: "Halfway through, the branch manager tells you the fee was correct under policy. What do you say?" | CASE | [generic] | Hold the member's need separate from the policy question. Say what you would check first: whether the policy was explained to the member in plain words. Concede plainly if the policy is right: the member still needs a clear answer. Two follow-ups: return to what the member needs to hear, never to who was right. | A pressure moment inside the case. Tests Plain Words and holding a position without folding. |
| C6 | "Our branches send complaints to you and we decide on the redress. Where's the seam, and what happens when we disagree?" | JD | [generic] | Propose seam principles, not a seam you have not seen: one named owner for each redress decision; a disagreement goes to a named person with a date. Answer slot: if you have disagreed with a peer on a decision and it was settled well, say how; if not, say so and say what you would propose. | Peer Evaluator. Tests partnership with the managers who would send you cases. |
| C7 | "Tell me about a letter or reply you rewrote so a member could follow it." | VAL | [generic] | Selection scaffold: pick an instance where the wording changed. If none comes to mind, say so plainly, then say how you would check a reply reads plainly before it goes out. Do not claim a letter you have not written. | Plain Words. No quote speaks to written replies, so this is a scaffold with an honest branch. |
| C8 | "Give us a complaint rate you would not want to defend, and the denominator behind it." | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" (your message) | Name the denominator behind any rate, in your words, then the assumption you would defend least. Say plainly if you do not know how a rate was counted. Answer slot: if you chose the counting rule, say how; if someone else set it or you do not know, say so. | Defend-the-number, for the panel's prober. Covers F3, and F4 through the resolution-times slot. |

**Reverse questions (round 3, reciprocity for peers)**

| # | Question | Why it lands |
|---|---|---|
| R3-1 | "What could a new complaints lead do in their first month that would genuinely help your branches?" | Peer reciprocity: it makes you a colleague, not a candidate. |
| R3-2 | "Where do complaints from your branches get stuck today, and which stage do you most wish you could see?" | Shows Own the Fix and tests where the seam really is. |

## Requirement coverage

| JD requirement | Question IDs |
|---|---|
| Own the complaints process end to end across branches and the contact centre | B4, C4, C6 |
| Report monthly on complaint volumes | A8, C8 |
| Report monthly on resolution times | B9, C8 |
| Coach branch supervisors on escalations | B3 |
| Work with digital teams on self-service journeys | B7, R2-3 |
| 4+ years in financial-services customer operations | A1 |
| Experience handling regulated complaints | B2 |
| Confident presenting to senior leaders | B5, B8 |
| Comfortable with Excel reporting | A2, A8 |

Question count: 25 across three rounds (8, 9 and 8), with seven reverse questions.

## Sources

**Provided documents**
1. The JD, as you pasted it.
2. Your four values, copied from ashgrovecu.org/about/values on 11 November 2026, as you pasted them.
3. The recruiter's email, as you quoted it: round structure, the panel scoring against values.
4. Your summary of Ashgrove's July 2026 strategy brief. The brief itself was not pasted.
5. Your background message.

**Research tier:** L1, searches 0 of 6, fetches 0 of 2. No search was run, because every target's output is fixed by the documents above.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | The values cheat sheet is fixed by the values you pasted. Not fetched from the site. |
| 2. Interview process, Member Experience Lead | skipped | The recruiter's email fixes the three rounds and the panel's values scoring. |
| 3. Ashgrove strategy and recent news | skipped | Your summary of the July 2026 brief supplies the priorities. News after July 2026 is unchecked. |
| 4. Interviewer names | n/a | No names were given, so there is no query to form. |
| 5. Representative JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions. |

## Upgrade menu

- **The three interviewers' names** → persona weights checked against their public footprint, and a reverse question tied to the manager's career path (round 2) and to a panel member's path (round 3).
- **One formal complaint you handled, with the member's details removed** → B2, A6 and C1 move from scaffolds to story-mapped answers, upgrading F1 and F7.
- **Whether your spreadsheet tracked resolution times, and how they were counted** → upgrades F4 from a slot to a rehearsed answer, and sharpens B9 and C8.
- **Any presentation you have given to a group, however small, with the audience** → gives the presenting row (F10) a grounded quote, and sharpens B5 and B8.
- **Any work with a digital team or a self-service journey** → upgrades F9, and sharpens B7.
- **Whether the role requires working across the five hubs, or travel between them** → if it does, that is a gate and gets its own hard-gate row. The JD says nothing on it, so ask the recruiter.
- **Whether round 2 includes a written or practical exercise** → any pre-declared deliverable gets its own build section.
- **Deep research (L2), if you want it** → at most six more searches and two more fetches, on news since July 2026 and on the interviewers' public footprint once named. Offered once; it runs only if you say so.
