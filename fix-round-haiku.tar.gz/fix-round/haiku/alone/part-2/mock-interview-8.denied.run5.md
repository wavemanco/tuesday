Your prep pack is saved as `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-alone-part-2-rooms-case-8-denied-e6310d74/a333f74e-5aa5-44a2-9d75-6c0e9304a8ac/scratchpad/ashgrove_member-experience-lead_interview_pack.md`. I built it as a three-round loop, with a shared fit snapshot and a mini-pack for each round.

Three things to know before you open it:

- **Round B is the one to rehearse.** B1 is the question most likely to come up in some form: "You have never worked in a contact centre, and you have not presented above regional level. This role owns both. Why should I hire you?" Both gaps are ones you stated yourself, so the pack has you concede them and give a plan rather than bluff.
- **The values round has no ready-made stories.** None of your sentences carries a story for any of the four values, so the cheat sheet gives selection prompts with an honest "if none comes to mind" branch.
- **I did no web research.** Your pasted values, the JD, the recruiter's outline and the strategy brief covered everything, so the Sources section marks each research target as skipped. The strategy brief is quoted from your message, not pasted verbatim.

Say the word and I'll play the Skeptic on B1 as a drill. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove_member-experience-lead_interview_pack.md -----
# Member Experience Lead, Ashgrove Credit Union: interview prep pack

**Format:** loop mode, three rounds on 20 November 2026. Shared fit snapshot and prohibited list, then one mini-pack per round.
**Built from:** the job description and your background as you wrote them, the values as you copied them on 11 November 2026, the recruiter's round outline, and the July 2026 strategy brief as quoted to me.
**Interviewer names:** not yet known. Persona weights use round type and the recruiter's notes only.

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored.
- **Type key:** VAL = behavioural and values alignment. EXP = your own work, probed for what you actually did. JD = the job's listed duties and requirements. CO = company and strategy knowledge. CASE = a live problem from the job.
- **Guidance is scaffolding, not a script.** Say it in your own words, in about 90 to 120 seconds.
- **Answer slots** are instructions for the interview. They are not questions to me. Each has two honest branches. Use whichever is true.
- Quotes in the Provenance column are your own sentences or the job description's. Nothing here says you did something your sentences do not say.

## Fit snapshot (shared across all rounds)

Requirements are quoted from the job description you pasted. Your evidence is quoted from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches and the contact centre" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | transferability | Your sentence covers the branch log, not the end-to-end process. Bridge: "At branch level, I handled the formal complaints log." Answer slot: if any step beyond the branch log was yours to set, say which and how you decided, in your own words; if none was, say so and stay with the log. |
| F2 | "across branches and the contact centre" — JD | "Never worked in a contact centre" — your message | none | [grounded] | capability | You stated this absence yourself. Words: "Never worked in a contact centre." Then how you would learn the contact-centre side, as a plan and never as a past. |
| F3 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor" — your message | medium | [grounded] | presentation | Bridge reworded from your sentence only: "I've spent six years in retail banking, the last three as a branch supervisor." Your sentence says retail banking. Keep that wording rather than stretching it to "customer operations". |
| F4 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log" — your message | low | [grounded] | discovery | Your sentence says formal, not regulated. Answer slot: if the log was run to rules set outside the branch, say which rules and how you applied them, in your own words; if it was not, say so plainly and describe how the log was run. |
| F5 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | discovery | Your sentence shows a monthly complaints report. It does not say what the report counted. Answer slot: if it tracked volumes or resolution times, say which and how each was counted; if it did not, say so and say what you would track first. |
| F6 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | discovery | Your sentence does not name a tool. Answer slot: say what the spreadsheet was built in and what you built in it, in your own words; if it was not Excel, say so. |
| F7 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level" — your message | none | [grounded] | capability | You stated this absence yourself. Words: "I've never presented to anyone above regional level." Then your plan for building that skill, as a plan and never as a past. |
| F8 | "coach branch supervisors on escalations" — JD | "trained new tellers on our escalation script" — your message | medium | [grounded] | transferability | Bridge: "I trained new tellers on our escalation script." Your sentence says tellers, not supervisors. Answer slot: if you coached other supervisors on escalations, say how; if you did not, say so and say how you would start. |
| F9 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material says nothing on this. Answer slot: pick a time you worked with a team outside your own on a customer-facing change; if none comes to mind, say so plainly and say how you would start with a digital team. |

**Requirement coverage line.** Every JD requirement maps to a question: the end-to-end ownership line (F1, F2) is covered by A4 and B1; 4+ years (F3) by A1; regulated complaints (F4) by A6 and B3; monthly reporting on volumes and resolution times (F5) by B4 and C8; Excel reporting (F6) by B4; senior presenting (F7) by A5 and B1; coaching supervisors on escalations (F8) by A6, B5 and C1; digital teams on self-service journeys (F9) by B2 and C7. No requirement is uncovered.

## Prohibited list (shared)

These are claims this pack will not coach, in any round. Each entry gives its basis and its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end across branches and the contact centre | Inflated form of F1 and F2 | "I handled the branch's formal complaints log." The limit is the pack's own observation, not words for you: your material shows the branch log and no contact-centre work. |
| Worked in a contact centre | Negative you stated (F2) | "Never worked in a contact centre." No slot beyond the learning plan. |
| Handled regulated complaints | Inflated form of F4 | "I handled the branch's formal complaints log." |
| Presented to senior leaders | Negative you stated (F7) | "I've never presented to anyone above regional level." No slot beyond the plan. |
| Reported on complaint volumes and resolution times | Inflated form of F5 | The spreadsheet sentence at its own scope. The answer slot asks only what the report counted. |
| Built the reporting in Excel | Inflated form of F6 | The spreadsheet sentence. Your material does not name the tool. |
| Coached branch supervisors on escalations | Inflated form of F8 | "I trained new tellers on our escalation script." |

## Grounding brief: the strategy as you quoted it

Source: the July 2026 strategy brief, as the recruiter sent it and as you quoted it to me. Provenance is [grounded] to that brief.

| Brief's words | What it means for these rounds |
|---|---|
| "move 40% of member service to digital channels by 2028" | Any complaint routed through self-service is still a member complaint. Expect questions on how a digital journey keeps the member's side of the counter in view. |
| "consolidate eight branches into five hubs over 2027" | The panel are branch managers, and their branches may be affected. Do not argue with the plan. Speak to how complaint handling holds through the change. |
| "launch a small-business lending product in Q1 2027" | Little bearing on this role. Mention only if asked what you know. |
| "the main competitive pressure is app-only banks" | Use this framing when asked why the digital move matters. |

**Tension to know before the panel.** The brief's hub plan and your value "Neighbours, Not Numbers" pull in different directions. The panel will score the answer to that tension, not the plan itself. Say what you would protect for the town, not whether the consolidation is right.

**Note:** this brief is quoted from your message, not pasted verbatim. Paste the exact wording and these rows can be re-checked word for word (see upgrade menu).

---

## Persona weights

Relationship priors set the starting weights. The recruiter's notes adjust them: round B is "mostly behavioural", and round C has a 20-minute case and is the values round. Depth follows weight: the top persona gets 4 questions, mid-weight 3, low-weight 1 or 2.

| Round | Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|---|
| A recruiter (30 min) | Conversational / Rapport | Walk-me-through openers, motivation | 5 of 8. The recruiter prior is conversational, and the recruiter's notes are the scored record. | A 90-second arc. Treat casual questions as scored. |
| A recruiter | Skeptic (light) | Why leave, the two stated gaps | 3 of 8. The light-skeptic prior applies, and your two stated absences are the likely early flags. | Name both gaps plainly, with a plan. |
| B Head of Member Services (45 min) | Skeptic | "Why should I hire you" against the JD | 4 of 8. The manager prior is case plus skeptic. Your stated absences are what a manager needs to be sure of. | Hold, then concede. B1 is the highest-ROI prep in the pack. |
| B | Values / Behavioral | STAR probes | 3 of 8. "Mostly behavioural" moves this up from the manager prior. | Own the Fix. "We" for context, "I" for your part. |
| B | Case / Strategist | One planning question | 1 of 8. The manager prior, lowered by "mostly behavioural". | Clarify before structuring. |
| C panel of two branch managers (60 min) | Values / Behavioral | Four value probes; scored against the four values | 4 of 8. The recruiter said the panel scores values. Each value needs at least one probe. | Map a story per value, or give the honest branch. |
| C | Case / Strategist | The 20-minute escalation case, then a strategy follow-up | 2 of 8. The case is the stated format; the follow-up tests the brief. | Clarify, structure, think aloud, challenge one premise. |
| C | Peer Evaluator | Seam between teams, disagreement | 1 of 8. Branch managers are peers in the panel prior. | Propose seam principles. Give reciprocity. |
| C | Data-Driven Prober | "What goes on the first page" | 1 of 8. The JD's reporting line. | Name the assumption behind each number. |

---

## Round A: recruiter screen (30 min, 8 questions)

Weights: conversational 5, light skeptic 3.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through your background." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" — your message; [grounded] "I handled the branch's formal complaints log" — your message; [grounded] "trained new tellers on our escalation script" — your message; [grounded] "I built the monthly complaints spreadsheet our regional manager uses" — your message | A 90-second arc with four beats, each one of your quoted sentences: six years in retail banking, the last three as a branch supervisor; the formal complaints log; training tellers on the escalation script; the monthly spreadsheet. Stop at what those sentences carry. Do not add a move from branch to contact centre. | Opening question, scored for economy. F3 is the spine; F1, F8 and F5 are the beats that show up later. |
| A2 | "Why this role, and why now?" | CO | [grounded] "move 40% of member service to digital channels by 2028" — strategy brief via recruiter | Connect one line of the brief to one of your sentences. Example: the brief moves member service to digital, and your log is where a complaint ends up when the channel fails. Say it as an observation about the work, not as proof of your experience. | Motivation-consistency check. The recruiter will note whether you have read the brief. |
| A3 | "What do you know about Ashgrove?" | CO | [grounded] "consolidate eight branches into five hubs over 2027" — strategy brief via recruiter | Use the brief's own numbers. Name one thing that matters to a member-owned bank in the hub plan, and do not take a side on the plan. | Current-language check. Stale framing scores worse than silence. |
| A4 | "The role owns complaints across branches and a contact centre. Which part is new to you?" | JD | [grounded] "Never worked in a contact centre" — your message | Say the stated fact in your words: "Never worked in a contact centre." Then the first step you would take, as a plan. This is a plain acknowledgment, so you can say it without a source problem. | F2 is the requirement with a stated absence. Naming it first beats being caught on it. |
| A5 | "How comfortable are you presenting to senior leaders?" | VAL | [grounded] "I've never presented to anyone above regional level" — your message | Say: "I've never presented to anyone above regional level." Then your plan for building it. Do not say you are very comfortable. If pressed, return to the same words. | F7 is a knockout-style check. The recruiter's register scores the honest answer, not confidence. |
| A6 | "Tell me about a complaint you escalated." | EXP | [grounded] "trained new tellers on our escalation script" — your message; [grounded] "I handled the branch's formal complaints log" — your message | Open prompt; the theme comes from the JD's escalation line. Selection scaffold: pick a complaint you took beyond the first contact, and say what you did with it, in your own words. If none went beyond first contact, say so plainly and give the nearest thing your sentences carry: the escalation script you trained tellers on, and how you would use it. | F8 and F4 meet here. The honest branch matters more than the story. |
| A7 | "Why are you looking to leave your branch role?" | JD | [grounded] "the last 3 as a branch supervisor" — your message | Say what you want from a role that covers more than one site, in your own words. Do not criticise your current employer. Describe the step; do not claim the experience you do not have. | Skeptic probe on motivation and scope. |
| A8 | "Is there anything about your background I should note before the next round?" | EXP | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level" — your message | Give the two stated gaps, plainly, each with one line of plan. Let the recruiter record them before round B rather than meet them cold. | A pre-emptive use of the screen. Round B will otherwise find both gaps itself. |

**Reverse questions (round A)**

- "How will the three rounds be weighted in the decision?" Why it lands: shows you want to know how you will be scored, and tells you what the panel's score will carry.
- "Who should I expect in each round, and what does each one want to hear about?" Why it lands: asks for the scoring context, which a recruiter can answer, and signals you are preparing for each round as a separate conversation.

---

## Round B: Head of Member Services (45 min, 8 questions, your future manager)

Weights: skeptic 4, values / behavioral 3, case 1.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You have never worked in a contact centre, and you have not presented above regional level. This role owns both. Why should I hire you?" | JD | [grounded] "Never worked in a contact centre" — your message; [grounded] "I've never presented to anyone above regional level" — your message; [grounded] "I handled the branch's formal complaints log" — your message | The highest-ROI rehearsal in this pack. Hold: "I handled the branch's formal complaints log, and I trained tellers on the escalation script" — say what that gives you that transfers, and stop there. Hold through two follow-ups by returning to those sentences. Concede: the contact-centre side is new, and presenting above regional level is new. Then the plan: learn the contact-centre complaint route first; present first to your own branch managers, then to regional. Do not claim contact-centre or senior-presenting experience. | This question is coming in some form. F2 and F7 are both stated absences, so the honest concession is the one to rehearse, not a bluff. |
| B2 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "work with digital teams on self-service journeys" — JD | Answer slot: name the part you have the least evidence for, in your own words. If it is digital-team work, say what you have done with a team outside your branch on a customer-facing change, or say you have not, and how you would start. Do not claim digital experience. | F9 is discovery. The day-one question is the skeptic's standard, and the honest answer is the slot's second branch. |
| B3 | "How did you run the branch's complaints log day to day?" | EXP | [grounded] "I handled the branch's formal complaints log" — your message | Describe the steps as you ran them, in your own words. Answer slot: if any closing decision was yours, say which and what you weighed; if the decision sat with someone else, say so plainly. Do not add a rule set you did not work to. | F4 asks whether the log was regulated; this probe asks who decided. Attribution honesty. |
| B4 | "You built the monthly spreadsheet your regional manager uses. What does it count?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" — your message | Answer slot: if it counts volumes or resolution times, say which and how each was counted. If it does not, say so and say what you would count first. Name the assumption behind the number you would defend least. | F5 and F6. This is the reporting requirement, tested on your own artefact. |
| B5 | "Tell me about a time you had to tell your own manager something they did not want to hear." | VAL | [grounded] "the last 3 as a branch supervisor" — your message | Open prompt; theme from the manager's behavioral mandate. Selection scaffold: pick a time you raised a problem with a manager who would have preferred not to hear it, and say what happened. If none comes to mind, say so plainly and give the nearest thing your sentences carry: the three years as a supervisor, and how you handled a problem you had to raise. | A behavioural probe for the manager. Mostly behavioural round. |
| B6 | "Tell me about a complaint you kept hold of until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log" — your message | Open prompt; theme from the published value Own the Fix. Selection scaffold: pick one complaint you kept hold of from start to close. If the log only recorded complaints, say so and describe how you followed one through. Do not name an outcome you did not see. | Own the Fix. The honest branch matters: the log may record, not resolve. |
| B7 | "When did you explain something to a member who needed it explained twice? What did you change?" | VAL | [grounded] "trained new tellers on our escalation script" — your message | Open prompt; theme from the published value Plain Words. Selection scaffold: if you changed the wording, steps or training for the script, say what. If the script stayed as written, say so and say what you would change now. | Plain Words. The script sentence carries training, not rewriting; do not claim it was rewritten. |
| B8 | "In your first 90 days, what would you do before changing anything?" | CASE | [generic] | Structure: listen first (volumes, backlog, escalation routes), then visit list, then the measures you would set up, then a coaching plan for supervisors. Name the order and the first two steps. The question needs no claim about your past, so the guidance makes none. | A live problem from the JD's coaching and reporting lines. Generic pattern, not a fact about this employer. |

**Reverse questions (round B)**

- "What does a good first month look like for someone in this role?" Why it lands: a manager question that reads as preparation for the job, and tells you what they will judge in month one.
- "Which branch supervisor do you most want this role to support, and what do they find hardest about escalations?" Why it lands: ties your answer to the JD's coaching line and invites the manager to describe the work, not the pitch.

---

## Round C: panel of two branch managers (60 min, 8 questions, values round with a 20-minute case)

Weights: values 4, case 2, peer 1, prober 1. The values cheat sheet lives here, because the recruiter named this round as the values round.

**Values cheat sheet.** No sentence in your material carries a story for any of the four values, so each value gets a selection scaffold with an honest branch. Do not invent a story to fill a value.

| Value (official name) | Working meaning | Mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | No quoted sentence carries a story. Scaffold: C3. |
| Plain Words | If a member needs it explained twice, the wording was wrong | No quoted sentence carries a story. Scaffold: C6. |
| Neighbours, Not Numbers | Every branch is part of its town | No quoted sentence carries a story. Scaffold: C4. |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | The sentence "I handled the branch's formal complaints log" carries handling, not a solved problem. Scaffold: C5, with the honest branch. |

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A member has waited three weeks for a reply about a fee and says they will take it to the ombudsman. A branch supervisor wants to waive the fee and close the complaint. What do you do?" | CASE | [generic] | Structure: clarify what the complaint is, what the member asked for, what the supervisor has already done, and what timescale applies (name the rule and say you would check it; do not state one as fact). Objective: resolve it from the member's side and keep the complaint record honest. Approach: decide the escalation route first, then the fee. Metrics: time to reply, outcome, repeat contact. Risk: a waiver sets a precedent for other branches. Challenge one premise: a waiver fixes the fee, not the three weeks. | The panel's 20-minute case. Generic escalation pattern; no claim about your past. |
| C2 | "Your branch is one of the eight going into a hub. Your supervisors' escalations go to a central team. What changes, and what does not?" | CASE | [grounded] "consolidate eight branches into five hubs over 2027" — strategy brief via recruiter | Hold on what does not change: the member's route to a reply and the time to reply. Concede what you do not know about the hub design, and ask how the hub's complaint route will work, in your own words. Do not argue with the plan. | Pressure follow-up. Tests strategy awareness at the panel's altitude. |
| C3 | "Tell me about a time you put a member ahead of a branch target." | VAL | [grounded] "I handled the branch's formal complaints log" — your message | Open prompt; theme from Members First, Always. Selection scaffold: pick a time a member's side changed the decision, and say what you weighed. If none comes to mind, say so plainly and give the nearest thing your log carries: a complaint you followed to its close, and what the member's side required. | No quoted sentence carries the story. The honest branch is the answer. |
| C4 | "Tell me about a time you thought about the town a branch serves when you decided something about a complaint." | VAL | [grounded] "I handled the branch's formal complaints log" — your message | Open prompt; theme from Neighbours, Not Numbers. Selection scaffold: pick a decision where the local context changed the answer. If none, say so plainly and say how you would find out what a branch's town needs before you decided. | No quoted sentence carries it. Your answer should not invent local knowledge. |
| C5 | "Walk me through a problem you found that nobody had asked you to fix, and what you did next." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" — your message | Open prompt; theme from Own the Fix. Selection scaffold: if the spreadsheet came from a problem you found, say what the problem was and what you did. If it did not, say so and give the nearest thing: what the spreadsheet showed. | Own the Fix. The spreadsheet sentence does not say it came from a found problem. |
| C6 | "Tell me about a letter or explanation you rewrote so a member could follow it the first time." | VAL | [grounded] "trained new tellers on our escalation script" — your message | Open prompt; theme from Plain Words. Selection scaffold: if you rewrote a letter or explanation, say what changed. If you did not, say so, and say how you would test one for plain words. | Plain Words. The script sentence does not say anything was rewritten. |
| C7 | "Our teams sit side by side on complaints and digital changes. Where is the seam, and what happens when we disagree?" | JD | [grounded] "work with digital teams on self-service journeys" — JD | Propose seam principles, not facts about their teams: who owns a complaint once it goes digital, and who decides when the two sides disagree. For disagreement, pick a time you disagreed with a peer and said so, in your own words; if none, say how you would raise it. | Peer probe on the digital seam. Reciprocity: what you would bring their team. |
| C8 | "What would you put on the first page of the monthly complaints report, and why?" | JD | [grounded] "report monthly on complaint volumes and resolution times" — JD | Name volumes and resolution times as the two numbers the JD asks for. For each, name the assumption behind it that you would defend least, in your own words. Do not supply a figure or a method you did not use. | The prober's question on the JD's reporting line. Metric answers name their weakest assumption. |

**Reverse questions (round C)**

- "What could a new person do in their first month that would genuinely help your branch?" Why it lands: a reciprocity question, the peer's own test of partnership fit.
- "How do you and your supervisors currently decide when an escalation goes to the regional team?" Why it lands: asks about the escalation route the case raised, and shows you are already thinking about the job.

---

## Sources

**Provided documents**

- Job description, pasted in your message.
- Values, copied from ashgrovecu.org/about/values on 11 November 2026, as pasted in your message.
- Recruiter's round outline, as pasted in your message.
- Strategy brief (July 2026), as quoted in your message, via the recruiter.
- Your background, as written in your message.

**Searches and fetches:** none sent. The inputs above fix the outputs each target would have fed.

**Research tier:** L1, searches 0 of 6, fetches 0 of 2.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | The values cheat sheet, in round C, from the pasted values page. |
| 2. Ashgrove interview process | skipped | Loop structure, from the recruiter's round outline. |
| 3. Ashgrove strategy / recent news | skipped | The grounding brief, from the strategy brief as quoted to me. |
| 4. Interviewer name | n/a | No names were given, so there was no query to form. The interviewer read is absent, and the upgrade menu says what a name would unlock. |
| 5. Representative JD | skipped | The job description you pasted fixes the fit snapshot and the JD-tagged questions. |

---

## Upgrade menu

- Interviewer names for rounds A, B and C → persona weights from public footprint, a tailored reverse question for each round, and the interviewer read.
- The strategy brief's exact wording, pasted → the four grounding quotes become verbatim [grounded] rather than quoted from your message.
- Your CV → the F-rows quoted from your message gain a second source, and confidence can rise where a CV sentence matches.
- Any complaint figures you can state from the branch log → F5 and B4 rehearse your own numbers, with the defend-the-number slots answered in your words.
- Whatever the 20-minute case gives you in advance, if anything → C1 and C2 can be drilled on the real material.
- Prep time available before 20 November → a prioritised triage section.
- Deep research (L2), on request: up to six further searches and two further fetches for the brief, interviewer talks and recent organisation context. Time cost is a few minutes; say the word and I will run it.
- A tuesday-dossier from job-underwriter, if you have one → verified evidence and a prohibited-claims guardrail. Not needed for this pack.
