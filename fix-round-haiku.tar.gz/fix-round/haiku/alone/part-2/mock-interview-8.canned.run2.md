Your prep pack is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-alone-part-2-rooms-case-8-canned-de705e67/bec4a14c-6cf1-431f-8d98-81f4625ee06f/scratchpad/ashgrove-credit-union_member-experience-lead_interview_pack.md`. I built it as a three-round loop from the recruiter's email, using your message for your background and the JD and values as you pasted them. No searches were needed, because your material already covers what a search would have checked.

The main findings:

- **Your two widest gaps are stated, so the pack gives you the words for them.** You've never worked in a contact centre, and you've never presented above regional level. The manager round is most likely to press on these together. Question B5 is the one to rehearse hardest, because a hold you can't back is what fails on the second follow-up.
- **Some JD lines have only a thin match.** Your "handled the branch's formal complaints log" doesn't show the regulated, end-to-end scope the JD asks for. Resolution times are not in your material at all. The pack gives you answer slots for these, and it doesn't supply the detail for you.
- **Don't say the things listed in the pack's prohibited-claims table.** The main ones: "owned the process end to end," "coached supervisors," "reported to senior leaders," and any named tool, Excel included.
- **Consolidation is sensitive.** "Consolidate eight branches into five hubs" pulls directly against "Neighbours, Not Numbers." The pack says not to argue the strategy or cheer it, but to answer on the members of a branch in transition (C2). Your spreadsheet is also the thing most likely to be used against the "Neighbours, Not Numbers" value, so B3 and C6 are worth practising.
- **The panel case is a generic one.** C1 is a complaint escalation I wrote from the pattern of the problem. If the recruiter shares the real brief, I can swap it in.

Two things to be aware of: the strategy figures come from your summary, not the brief itself, so check them before round 3. And the interviewers for rounds 2 and 3 aren't named yet, so the persona weights are based on the round types only.

Want me to play the pressure version of B5, the contact-centre and senior-presentation objection? I'll score your answer against its guidance.

I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for carrying into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove-credit-union_member-experience-lead_interview_pack.md -----
# Member Experience Lead, Ashgrove Credit Union: interview prep pack

**Regeneration:** none. This is the first version.
**Rounds:** three, on 20 November 2026. Round 1, recruiter (30 min). Round 2, Head of Member Services, your future manager (45 min, mostly behavioural). Round 3, panel of two branch managers (60 min, including a 20-minute complaint escalation case; the panel scores the four values). Names for rounds 2 and 3 are not assigned yet.

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored.
- **Type key:** VAL = behavioural, tests whether past behaviour shows a published value. EXP = experience deep-dive, tests whether your claims survive scrutiny. JD = role-driven, tests the listed requirements, gaps included. CO = company and strategy knowledge. CASE = live problem from the role.
- **Guidance is scaffolding, not a script.** Where the guidance says "answer slot", it means the honest answer is the one you give from your own experience, in your own words, including "that was not mine" or "I haven't done that".
- Sections are numbered as in the skill's template. Sections for prep triage, graded deliverables, the interviewer read and delivery coaching are omitted because no prep time, deliverable, interviewer profile or working-style assessment was given.

## 4. Fit snapshot

Requirements are quoted from the job description you pasted. Evidence is quoted from your message. No requirement in the JD is a gate: "4+ years" and "regulated complaints" are experience requirements, not credentials, so every row is graded on fit and gap type.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" (JD) | "6 years in retail banking, the last 3 as a branch supervisor" (your message) | medium | [grounded] | presentation | Your material says retail banking and a branch supervisor role. It does not use the words customer operations, so say the years and the role in your own terms: "six years in retail banking, the last three as a branch supervisor." |
| F2 | "experience handling regulated complaints" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | transferability | Says you handled the branch's formal complaints log, and nothing about whether that log was regulated. Bridge stays at the quote's scope. Answer slot: if the log followed a timeline or standard you can name, say which and how you applied it; if it followed none you can name, say so plainly. |
| F3 | "Own the member complaints process end to end across branches and the contact centre" (JD) | "I handled the branch's formal complaints log" (your message) | low | [grounded] | transferability | The quote is one branch's log, not an end-to-end process across branches. Confidence is low because the scope is thin. Answer slot: which stages of a complaint you ran from first contact to close, and where a complaint went if it left your hands. |
| F4 | "across branches and the contact centre" (JD) | "Never worked in a contact centre" (your message) | none | [grounded] | capability | A stated absence, so the words come from it: "I haven't worked in a contact centre." Then how you would learn it, said as a plan and never as a past. |
| F5 | "report monthly on complaint volumes" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | medium | [grounded] | presentation | The quote reaches monthly complaints reporting in other terms. Say it in those words. Answer slot: if you ran the monthly figures yourself, say which; if someone else ran them, say so. |
| F6 | "resolution times" (JD, from "report monthly on complaint volumes and resolution times") | none given | none | [grounded] | discovery | Your material is silent on resolution times, and the snapshot does not claim you measured them. Answer slot: if you tracked resolution times, say how they were counted; if you did not, say so and say what you would measure first. |
| F7 | "coach branch supervisors on escalations" (JD) | "trained new tellers on our escalation script" (your message) | medium | [grounded] | transferability | Teller training on an escalation script is adjacent to coaching supervisors on escalations, and the bridge stays at tellers. Answer slot: if you ever coached a supervisor on an escalation decision, say what they decided and what you said; if not, say so and say how you would approach it. |
| F8 | "work with digital teams on self-service journeys" (JD) | none given | none | [grounded] | discovery | No quote touches this. Answer slot: if you worked with any team on a customer-facing process or channel change, say which and what you did; if not, say so and say how you would start with a digital team. |
| F9 | "confident presenting to senior leaders" (JD) | "I've never presented to anyone above regional level" (your message) | none | [grounded] | capability | A stated absence, so the words come from it: "I've never presented to anyone above regional level." Then how you would build the skill, as a plan. |
| F10 | "comfortable with Excel reporting" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | medium | [grounded] | presentation | The quote does not name Excel, and the snapshot does not assume it. Answer slot: name the tool you built the spreadsheet in, and one thing you built in it, in your own words. |

Rules applied to the table: Evidence cells hold only your sentences. Confidence grades your evidence, and provenance grades what this pack says about it.

## Prohibited claims: where not to over-claim

These are the claims this pack will not coach, and why. Nothing in the banks, the values table or the reverse questions asserts, softens or implies them.

| Not coached | Basis | Honest form |
|---|---|---|
| "Owned the member complaints process end to end" | Inflated form of F3. The material says one branch's log. | "I handled the branch's formal complaints log." The limit is this pack's observation: your material does not show an end-to-end process. |
| "Handled regulated complaints" | Inflated form of F2. The material does not say the log was regulated. | "I handled the branch's formal complaints log." The limit is this pack's observation: regulation is not in your material. |
| "Coached branch supervisors on escalations" | Inflated form of F7. The material says tellers. | "trained new tellers on our escalation script." |
| "Ran a contact centre" or "managed contact-centre complaints" | Stated negative, F4. | "I haven't worked in a contact centre." |
| "Presented to senior leaders" or "presented to our leadership" | Stated negative, F9. | "I've never presented to anyone above regional level." |
| "Reported the complaints figures to senior leaders" | Inflated form of F5. The spreadsheet is one your regional manager uses; who ran the figures is not stated. | "I built the monthly complaints spreadsheet our regional manager uses." |
| "Used Excel" or any named tool | Inflated form of F10. No tool is named in your material. | "I built the monthly complaints spreadsheet." Name the tool only if you know it. |

## 6. Grounding brief

Built from the strategy summary you gave, not from the brief itself. Check every figure against the brief before round 3.

| Item | What the brief says, as you summarised it | How to use it |
|---|---|---|
| Digital shift | "move 40% of member service to digital channels by 2028" | Use "member service" and "digital channels" in those words. Check the figure against the brief. |
| Branch consolidation | "consolidate eight branches into five hubs over 2027" | Treat as sensitive. Do not argue it and do not cheer it. Answer on the members of a branch in transition (C2). This is the point where the brief pulls hardest against the value "Neighbours, Not Numbers". |
| Small-business lending | "launch a small-business lending product in Q1 2027" | Know it exists. Make no claim about how complaints for it would be handled. |
| Competitive pressure | "the main competitive pressure is app-only banks" | Vocabulary for C3. Make no claim about any bank's app. |

## 8. Persona table

Relationship priors set the start. The recruiter's email sets the loop: round 2 is "mostly behavioural", and round 3 is the panel that "score[s] against the four values" with a 20-minute case. Interviewer signals are absent, so no adjustments are made.

| Round | Persona | Depth | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|---|---|
| R1 Recruiter, 30 min | Conversational / rapport | 5 (A1 to A5) | Friendly biography and motivation openers | High. Screens are the round people treat as unscored; the risk is that casual questions are scored. | A 90-second arc built from your own sentences. Treat casual questions about the JD's topics as scored. |
| R1 | Skeptic, light | 3 (A6 to A8) | Scope and the two stated gaps, each asked once | Medium. A recruiter checks the JD's widest lines before passing you on. | Plain acknowledgment first, plan second. |
| R2 Head of Member Services, 45 min | Values / Behavioral | 4 (B1 to B4) | Scenario probes on the four values | High. The email says the round is mostly behavioural, and this is your future manager. | STAR-shaped answers. Decision over description. Use the honest branch where no story exists. |
| R2 | Skeptic | 4 (B5 to B7, B10) | The contact-centre and presentation gaps, cross-examined | High for B5. A manager is buying capability and checking gaps. | Hold-then-concede on B5. Attribution on B6. |
| R2 | Case / Strategist | 2 (B8, B9) | A live coaching problem and a "fixed, not closed" test | Medium. Manager rounds often add a live problem. | Clarify, name one owner, fix, tell the member. |
| R3 Panel, 60 min incl. 20-min case | Case / Strategist | 3 (C1 to C3) | The scored case, plus the consolidation and digital questions | High. The case is in the email, and the brief is in the loop's material. | Clarify before structuring. Name one owner. State the member's next step. |
| R3 | Values / Behavioral | 4 (C4 to C7) | The panel scores each value | High. The email says the panel scores the four values. | The values cheat sheet below. Hard-truth stories where your material carries one. |
| R3 | Pressure / Skeptic | 2 (C8, C9) | A composed challenge, and a live question you cannot answer | Medium. A panel of two can take turns. | Pause, restate, hold, then concede the specific gap. |

## 9. Question banks

Question types are one token each. Provenance quotes are exact.

### Round 1: recruiter screen (A1 to A8)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, walk me through your background." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "I handled the branch's formal complaints log"; "trained new tellers on our escalation script"; "I built the monthly complaints spreadsheet our regional manager uses" (your message) | About 90 seconds, in this order: the six years and the last three as branch supervisor, then the complaints log, the teller training and the spreadsheet, in those words. Stop when the sentences run out. Do not add a role, a number or a result you have not said in this conversation. | The opening question is scored for economy. Every clause draws on F1, F2, F7 and F5. |
| A2 | "Why Ashgrove, and why this role?" | VAL | [generic] | Start from the role's own line, that complaints should be owned end to end. Add one line from the values page in plain words, such as "decide from the member's side of the counter." Then your reason, in your own words. Answer slot: if your reason is about the branch you work in, say so plainly. | Motivation is checked at the screen. The question asks for your reason, which this pack does not supply. |
| A3 | "Are you free for all three rounds on 20 November? When is your earliest start date?" | JD | [generic] | Yes or no first. If a time clashes, say so now. Give the earliest start you can actually commit to. | Logistics checks happen at screens. Tagged JD because it is the only type a knockout can carry. |
| A4 | "What would you want members to say about complaints in a year?" | VAL | [grounded] "decide from the member's side of the counter" (values, as pasted) | Name one thing a member would say, in plain words, and say how you would know. Do not name a target number you have not set. | Members First, tested at screen as motivation. |
| A5 | "Which self-service journeys have you seen work, and which didn't?" | JD | [grounded] "work with digital teams on self-service journeys" (JD) | Open. If you have used or seen a self-service journey from the member's side, name one and what made it work or fail. If not, say so, and name what you would look at first. | The JD line is the raising source. F8 is discovery, so the honest branch carries the answer. |
| A6 | "Your experience is branch-based. Have you run anything wider than a branch?" | EXP | [grounded] "I handled the branch's formal complaints log" (your message) | Answer slot: if you ran anything wider than your branch, say what and what your part was. If not, say so plainly, and name the widest thing your branch work covered. | Probes F3's scope at the screen. The premise is the branch scope in the quote. |
| A7 | "You've never worked in a contact centre. Does that worry you?" | JD | [grounded] "Never worked in a contact centre" (your message) | Yes or no first. Then: "I haven't worked in a contact centre." Then how you would learn it, as a plan. No claim about any contact-centre work. | Premised on your stated negative, quoted. F4 is capability, so the answer is the plain acknowledgment plus a plan. |
| A8 | "What's one thing you'd change about how complaints work in a branch today?" | VAL | [grounded] "I handled the branch's formal complaints log" (your message); "whoever finds the problem keeps hold of it until it is solved" (values, as pasted) | Name one change, from what the log showed you. If the log never showed a problem worth changing, say so plainly and name what you would check first. | Open prompt on the Own the Fix value. Scored for specificity. |

### Round 2: Head of Member Services (B1 to B10)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time you made a call on a complaint from the member's side, when the policy pointed the other way." | VAL | [grounded] "I handled the branch's formal complaints log" (your message) | Selection scaffold: pick a complaint where the policy and the member's position pulled apart. Say what the member needed, what you decided and why. Your quote carries only that you handled the log, so the decision must be one you actually made. If none comes to mind, say so plainly, then give the nearest complaint the log carries, or how you would handle it. | Members First. The manager weighs the decision more than the description. F2 and F3 are the nearest rows, and neither supplies the decision. |
| B2 | "Tell me about a time something you had written or taught needed explaining twice." | VAL | [grounded] "trained new tellers on our escalation script" (your message) | If you changed a script or an explanation after someone did not follow it, say the change in order. If you did not, say so and say how you would test a letter or script for clarity. | Plain Words. F7 is the nearest sentence. The guidance does not supply the change. |
| B3 | "Tell me about a time a count told you one story about a branch, and the branch told you another." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" (your message) | If you looked behind a count and found what it hid, say what it was. If you have not, say so, and name what you would check before trusting a branch's number. Do not describe the spreadsheet as having shown anything you have not said. | Neighbours, Not Numbers is the value your spreadsheet most readily cuts against, and the panel will test it. F5 is the row. |
| B4 | "Tell me about a complaint you kept hold of until it was fixed, when it could have been passed on." | VAL | [grounded] "I handled the branch's formal complaints log" (your message) | Answer slot: say what happened, in order, from first contact to close. If complaints left your desk before they were fixed, say where they went and who held them. If you did not follow complaints through to a fix, say so and say how you would. | Own the Fix. The manager tests whether the owner stayed with it. The verb is "handled", and the guidance keeps it there. F3 is the row. |
| B5 | "You've never worked in a contact centre and you've never presented above regional level. Why should we trust you with complaints across both?" | JD | [grounded] "Never worked in a contact centre"; "I've never presented to anyone above regional level" (your message); "I handled the branch's formal complaints log"; "trained new tellers on our escalation script" (your message) | HIGHEST-ROI PREP. Pause and restate the question. Then the plain words: "I haven't worked in a contact centre, and I've never presented to anyone above regional level." Then what carries over, from your quotes: the complaints log and the teller training. Then your plan for each gap, as a plan. Hold through two follow-ups by returning to the log and the training, not to scope you do not have. On the first follow-up, concede specifically: "I can't yet say how a contact centre handles a complaint." | This is the objection the manager is most likely to raise, because it aims at the JD's two widest lines. F4 and F9 are stated gaps, so the words come from your own negatives. This gets the deepest rehearsal because a hold you cannot back is the one the second follow-up breaks. |
| B6 | "How much of the monthly complaints spreadsheet did you build yourself, and how much did your regional manager do?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" (your message) | Answer slot: if you built the structure and ran the monthly figures, say which parts. If you built it and someone else ran the figures, say so. Say which tool it was built in, if you know. | Premised on the quote, which carries the build and the manager's use. F5 and F10 attribution is what a prober tests. |
| B7 | "How are resolution times counted in the monthly report, and what did you measure?" | JD | [grounded] "report monthly on complaint volumes and resolution times" (JD) | Answer slot: if you tracked resolution times, say how they were counted, what they were sensitive to, and which assumption you would defend least. If you did not track them, say so, and say what you would measure first. | F6 is discovery: the material is silent on times. The question's premise is the JD's own line, and no figure is supplied. |
| B8 | "A supervisor in one of your branches asks how to handle a complaint that has been escalated twice. What do you tell them?" | CASE | [generic] | Structure it. Ask what the two escalations were about, what the member has been told and what the deadline is. Then say what the supervisor decides, what you check, and what you coach. Do not say you have done this before. | A live problem from the JD's coaching line, asked as a decision. No claim about your past, so none is needed. F7 is the honest bridge: the question tests how you would coach. |
| B9 | "How would you know a complaint was fixed for the member, not just closed on the system?" | CASE | [grounded] "whoever finds the problem keeps hold of it until it is solved" (values, as pasted) | Name what you would check with the member: what they were promised, what they now have, and whether they would agree the problem is solved. Name one thing you would record. | Own the Fix as a live problem. The value sets the test. |
| B10 | "Which rules or timelines did the formal complaints log follow, and who checked them?" | JD | [grounded] "experience handling regulated complaints" (JD) | Answer slot: if the log followed a timeline or standard you can name, say which and how you applied it. If it followed none you can name, say so plainly and say what the log did follow. | F2 is transferability. The material does not say the log was regulated, so the slot is the only route to it. |

### Round 3: panel of two branch managers (C1 to C9)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A member comes to the counter. A fee was taken twice. They want it fixed today, and the branch can't reverse it or reach the contact centre before close. They say they'll go to a complaints service if nothing happens. Walk us through the next 24 hours." | CASE | [generic] | Clarify aloud first: the fee, the amount, the account history. Then the member's immediate need. Name one owner for the complaint. Fix what can be fixed within a day. Tell the member plainly what happens next and when. Then what you record for the monthly figures, and what you change at branch level. | The scored 20-minute case. The one-owner step answers Own the Fix and the plain-words step answers Plain Words. [generic] because it is a pattern for the problem, not a fact about this employer. The real case may differ: see the upgrade menu. |
| C2 | "Eight branches are moving into five hubs over 2027. What happens to complaints that are open in a branch on the day it moves?" | CO | [grounded] "consolidate eight branches into five hubs over 2027" (recruiter's brief, as you summarised it) | Name what you would need to know: how many complaints are open, how old they are, and which members are affected. Then the handover: one named owner for each open complaint, and the member told plainly. Do not argue for or against the consolidation. Keep the answer on the members of the branch. | The brief is the loop's own material. The panel may include branch managers whose branches are in scope. The pack does not know that, so the guidance does not assume it. |
| C3 | "Forty per cent of member service moving to digital by 2028. What should stay with a person?" | CO | [grounded] "move 40% of member service to digital channels by 2028" (recruiter's brief, as you summarised it) | Name the complaints that most need a person: a dispute about money, a member who cannot explain the problem in any form, a vulnerable member. Say you would test the digital journey with the digital team before deciding. | The complaints lead is the link between the brief and the JD's digital line. F8 is discovery, so the guidance asks for a view, not a history. |
| C4 | "Tell me about a time you had to say something hard about a member's outcome to someone more senior than you." | VAL | [grounded] "decide from the member's side of the counter" (values, as pasted); "I handled the branch's formal complaints log" (your message) | Selection scaffold: pick a time you disagreed with a senior colleague on what a member should get, and say what you said and what changed. If none comes to mind, say so plainly, then give the nearest thing the log carries, or how you would raise it. Do not finish the story with an ending you have not had. | Members First, scored by the panel. The material carries no such exchange, so the honest branch is the answer. F2 is the nearest row. |
| C5 | "Tell me about a letter or explanation that went wrong, and how you fixed the words." | VAL | [grounded] "trained new tellers on our escalation script" (your message) | If you rewrote a script or a letter after it confused someone, say what changed and how you knew. If you have not, say so, and say how you would test one with a member. | Plain Words. F7 is the nearest real story. The guidance does not supply a rewrite. |
| C6 | "How would you judge a branch's complaints against its own town, not the group average?" | VAL | [grounded] "every branch is part of its town" (values, as pasted) | Name what you would compare: the branch's own history, what its members raise, and what its branch manager knows. Say you would check the picture with the branch manager before drawing a conclusion. | Neighbours, Not Numbers as a method question. It is hypothetical, so it makes no claim about your past. |
| C7 | "Tell me about a complaint decision you got wrong. What did you do?" | VAL | [grounded] "whoever finds the problem keeps hold of it until it is solved" (values, as pasted) | Selection scaffold: name a decision you would now make differently, what you did when you found out, and who you told. If you cannot name one, say so, then describe how you check your own calls. | Own the Fix, turned on the candidate. The panel tests whether the answer owns the error. The guidance supplies no error. F3 is the row. |
| C8 | "A branch manager here would say you know complaints from the counter, not from a contact centre or a regional table. What's your answer?" | JD | [grounded] "Never worked in a contact centre"; "I've never presented to anyone above regional level" (your message); "I handled the branch's formal complaints log" (your message) | Pause and restate. Then: "I haven't worked in a contact centre, and I've never presented above regional level." Then what carries over from the counter: the log. Then your plan for the contact centre, as a plan. Hold through two follow-ups. On the first, concede the specific gap, not the whole objection. | The panel's version of B5, shorter. The hold is on the core claim: the complaints work carries over; the scope you have not worked in does not. F4 and F9. |
| C9 | "Someone senior asks you a question, live and in front of others, that you can't answer. What do you do?" | JD | [grounded] "I've never presented to anyone above regional level" (your message) | Say what you know. Then say what you do not know and when you will come back with it, with a date. Do not guess a figure, and do not claim you have handled a live question at that level. | Confident presenting to senior leaders (F9) is scored on composure and candour under live questions. The stated negative is the premise. |

### Coverage check against the JD and the values

| Requirement or line | Question IDs |
|---|---|
| 4+ years in financial-services customer operations | A1, B5 |
| experience handling regulated complaints | B10, B1 |
| confident presenting to senior leaders | B5, C8, C9 |
| comfortable with Excel reporting | B6, with the tool name as an answer slot inside it |
| Own the member complaints process end to end across branches and the contact centre | A6, B4, B5, C7, C8 |
| report monthly on complaint volumes and resolution times | B3, B6, B7 |
| coach branch supervisors on escalations | B8 |
| work with digital teams on self-service journeys | A5, C3 |
| Round 3 case | C1 |
| Values: Members First, Always | B1, C4 |
| Values: Plain Words | B2, C5 |
| Values: Neighbours, Not Numbers | B3, C6 |
| Values: Own the Fix | B4, B9, C7 |

No requirement is uncovered.

### Persona weights and depth

Round 1 carries 8 questions, round 2 carries 10 and round 3 carries 9, each inside the loop's 8 to 12 range. Round 2's B5 is the single most predictable objection in the pack and gets the deepest rehearsal.

## 10. Values cheat sheet

This section sits with round 3, the round the recruiter names as the values round. Each row maps a published value to a sentence from your message where one carries a story, or gives a selection scaffold with its honest branch where none does.

| Value (official name) | Working meaning | Mapped story or scaffold | Honest branch |
|---|---|---|---|
| Members First, Always | Decide from the member's side of the counter | F2: "I handled the branch's formal complaints log" | Scaffold: a call you made from the member's side. If you cannot name one, say so and say how you would decide. |
| Plain Words | If a member needs it explained twice, we wrote it wrong | F7: "trained new tellers on our escalation script" | Scaffold: a script or letter you changed after it confused someone. If none, say so and say how you would test one. |
| Neighbours, Not Numbers | Every branch is part of its town | F5: "I built the monthly complaints spreadsheet our regional manager uses" | Scaffold: a count that hid something about a branch. If you have not looked behind a count, say so. This is the value your spreadsheet most readily cuts against. |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | F3: "I handled the branch's formal complaints log" | Scaffold: a complaint you followed to a fix. If complaints left your desk unsolved, say where they went. |

## 11. Reverse questions

Round 1:

- "Is the round 3 case a standard one, or written for this role?" Why it lands: tells you whether to prepare the generic case or a specific one, and shows you plan around the scored part.
- "What made the team decide to hire for this role now?" Why it lands: the answer shows whether the pressure is the digital shift, the 2027 consolidation or the complaints backlog, and shows you read the brief.

Round 2:

- "Where does a complaint currently fall between the branches and the contact centre?" Why it lands: it shows you read the scope line and went straight to the seam.
- "How are the monthly complaint reports used by senior leaders, and which decision did the last one change?" Why it lands: it links to F5 and F6, and asks what the reporting is for.
- "What is the first complaint theme you would want fixed, and how would you know it was fixed?" Why it lands: it invites your manager to set the Own the Fix test in their own words.

Round 3:

- "How should complaints be handled for members of a branch that moves into a hub in 2027?" Why it lands: it takes the Neighbours, Not Numbers value into the consolidation without taking a side on it.
- "Which digital self-service journey is first on the table, and which complaints does it come from?" Why it lands: it turns the digital line into a conversation about where complaints come from.
- "What would a new person in this role do in the first month that would genuinely help your branches?" Why it lands: a reciprocity question for a panel of branch managers, asked as a colleague would ask it.

## 13. Sources

- Provided documents: the job description text in your message; the values page as you copied it on 11 November 2026 (I did not fetch ashgrovecu.org); the recruiter's process email; the 2026 strategy brief as you summarised it (the brief itself is not in hand); your background, in your message.
- Searches and fetches sent: none.

**Research tier: L1, searches 0 of 6, fetches 0 of 2.** Every L1 target was already fixed by the material you supplied, so no call was needed.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | The pasted values fix the values cheat sheet (section 10) and the value-based questions. |
| 2. Ashgrove interview process, customer operations | skipped | The recruiter's email fixes the loop structure, and the round weights follow it. |
| 3. Ashgrove strategy and recent news | skipped | The strategy summary you gave fixes the grounding brief (section 6) and the C2 and C3 questions. |
| 4. Interviewer name and Ashgrove | n/a | No interviewer is named, so there is no query to form. The interviewer read is absent. |
| 5. Representative customer-operations JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions. |

## 15. Upgrade menu

- The names of the round 2 and round 3 interviewers → persona weights for each panel member, and reverse questions tied to their own career paths.
- The round 3 case brief, if the recruiter shares it → replaces the generic C1 with the real case.
- The 2026 strategy brief itself → checks the figures and wording in section 6, and catches any stale framing.
- Your answers to the answer slots in F5, F6, F10 and B4 → each answer is new quoted material; F5, F6 and F10 can move up from medium and none, and B6 gains a specific slot.
- The structure of the complaints spreadsheet, without any member data → F5 and F10 move from medium to high, because an inspectable artifact exists.
- The complaint-handling timelines or standard the formal log followed → F2 and B10 can move from transferability to presentation.
- An engagement with a digital team, if you had one → F8 moves from discovery, and A5 and C3 gain a specific slot.
- Prep time before 20 November → a prep triage section that orders the banks by time available.
