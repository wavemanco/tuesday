Your prep pack is saved as `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-alone-part-2-rooms-case-7-canned-e8fdd97b/8f16ccf0-4e7f-4b4f-b858-2495768bb7cf/scratchpad/saltmarsh_live_operations_producer_interview_pack.md`, and I've sent it to you. I built it for a hiring-manager round, since your note didn't say how Tobias fits in. Company research didn't run, so the pack uses only your JD and your background. It includes the 60-minute plan you asked for.

The biggest finding: the Skeptic questions on your gaps are the highest-value prep. Those are no team lead, no in-app purchase experience, and running only one title's calendar against a two-title role. The pack gives each one an honest answer shape: state the gap plainly, point to the closest real work, then describe the ramp as a plan.

Two things to know before Friday:
- Your three numbers-related items (the retention presentation, the post-event review, and the KPIs) have no record behind them in what you've told me. The pack treats them as "say what you did, or say plainly you didn't."
- Tobias's pronouns weren't given, so the pack uses they/them.

I can also:
- Play Tobias in a live drill, starting with the Skeptic question A1.
- Save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions.
- Convert the pack to Word if you want it.

Is Tobias your hiring manager, or someone you'd work beside? Also, is there a take-home or presentation in the process? Either answer changes how the questions are weighted.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh_live_operations_producer_interview_pack.md -----
# Interview prep pack: Femi, Live Operations Producer, Saltmarsh Games

**Interviewer:** Tobias Wrenfield, Head of Live Operations. Relationship not given, so this pack is built on hiring-manager priors (see persona table). No profile was supplied, so there is no interviewer read. Pronouns not stated; the pack uses they/them.
**Round:** 60 minutes. Format (take-home, presentation, panel) not given.
**Research tier:** L0, provided material only. No company research ran. See Sources.
**Changelog:** first version.

## How to use

Personas describe how a question arrives. Types describe what it scores.

| Tag | Name | What it scores |
|---|---|---|
| JD | Role / JD-driven | Whether you can do the listed job, gaps included |
| EXP | Experience deep-dive | Whether what you wrote survives scrutiny, and what was actually yours |
| VAL | Behavioral / values | Past behavior, against values. None published here, so these are generic |
| CO | Company knowledge | Not in this pack: research did not run, so company questions would be generic |
| CASE | Live problem | Structure and reasoning on a problem from the role |

Guidance is scaffolding, not a script, and each cell is written to be said in 90 to 120 seconds. "Answer slot" lines are instructions for the interview. Answer them from what actually happened, in your own words.

## Your 60 minutes (you asked for this)

This sits outside the standard skeleton because you asked for it. Times are a suggestion.

| Minutes | Segment | Questions |
|---|---|---|
| 0 to 5 | Opening: your journey, and why live mobile now | E1, A4 |
| 5 to 20 | Gaps, early: no team lead, no in-app purchases, two titles | A1, A2, A3 |
| 20 to 35 | The calendar and the checklist | B2, C1, C4, D2 |
| 35 to 47 | Retention and KPIs | C2, C3 |
| 47 to 54 | A live problem | B1 or B3 |
| 54 to 60 | Your questions | R1, R2, R6 |

## Fit snapshot

Requirement quotes come from the JD you pasted. Evidence quotes come from your message. Nothing else is quoted.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "experience running a content calendar" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | medium | [grounded] | none | No gap. Expect a probe on what the calendar held and who agreed to it. Say what you ran, in your own words. |
| F2 | "manage the release checklist with QA" (JD) | "Wrote the release checklist our QA team still uses" (your message) | medium | [grounded] | presentation | Your material says you wrote the checklist and QA still uses it. Words: "I wrote the release checklist, and our QA team still uses it." Do not add how many releases it has run through. |
| F3 | "comfortable with player-retention metrics" (JD) | "Presented the monthly retention numbers to the studio head" (your message) | low | [inferred] | discovery | Presenting a number does not show you can work with the metric. Answer slot: if you built or checked those numbers, say how they were counted. If you only presented them, say so, and say what you would check before presenting one again. |
| F4 | "own the post-event review and the KPIs it reports" (JD) | none given | none | [grounded] | discovery | Your material does not show a post-event review. Answer slot: if you have run one, say what it covered and who used it. If not, say so and describe the review you would run first. |
| F5 | "Plan and run the live-events calendar for two of our mobile titles" (JD) | "I ran the weekly content-drop calendar for our main title" (your message) | medium | [grounded] | transferability | Adjacent work: a weekly drop calendar for one title. The JD asks for two titles and live events. Words: "I ran the weekly content-drop calendar for our main title." Any wider step is an answer slot inside that scope: if you ever ran two calendars, or an event that was not a content drop, say what and how. |
| F6 | "coordinate design, art, engineering and community teams on each update" (JD) | none given | none | [grounded] | discovery | Your material does not show coordinating those teams. Answer slot: if you coordinated any of them on an update, say which and how. If you worked mostly with QA, say so. |
| F7 | "clear written communication" (JD) | "Wrote the release checklist our QA team still uses" (your message) | low | [inferred] | presentation | One written artifact is the only writing your material shows. Words: "I wrote the release checklist our QA team still uses." Say nothing about its length or other audiences. |
| F8 | "3+ years producing live-service games or apps" (JD) | "4 years as an associate producer at a puzzle-game studio" (your message) | medium | [grounded] | transferability | Not a gate, so it is graded on fit. The four years meet the number. The title is associate producer, and the sentence does not say the work was live-service. Words: "I spent four years as an associate producer at a puzzle-game studio." Answer slot: say what you produced in those four years, and which parts ran after launch. |
| F9 | Team leadership, not named in the JD [generic] | "Never led a team" (your message) | none | [grounded] | capability | A stated absence, and the JD asks for coordination rather than leadership. Words: "I haven't led a team." Then how you would coordinate four teams without leading them, said as a plan. Never a claim to have led. |
| F10 | Monetised live games, not named in the JD [generic] | "never worked on a game with in-app purchases" (your message) | none | [grounded] | capability | A stated absence. Words: "I haven't worked on a game with in-app purchases." The JD does not name it, so it raises no answer slot, though an interviewer may still ask. |

Confidence grades your evidence. Provenance grades what this pack wrote. Gap type says what kind of gap each requirement is.

Not a gate: the JD's years line is a length-of-experience requirement, so it is graded on fit like the others.

## Prohibited claims

Each entry names its basis. Inflated forms are stretched wording of something you did say. The honest form is your quote at its own scope.

| Not coached | Basis | Honest form |
|---|---|---|
| Managed the release checklist with QA | Inflated form of F2 | "I wrote the release checklist our QA team still uses." Your material does not show you managed each release. |
| Owned retention analysis or set retention KPIs | Inflated form of F3 | "Presented the monthly retention numbers to the studio head." Your material does not show who built them. |
| Ran two titles' calendars | Inflated form of F5 | "I ran the weekly content-drop calendar for our main title." |
| Produced live-service games | Inflated form of F8 | "4 years as an associate producer at a puzzle-game studio." |
| Led a team | Your own stated negative (F9) | "I haven't led a team." |
| Worked on a game with in-app purchases | Your own stated negative (F10) | "I haven't worked on a game with in-app purchases." |

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet questions on the gaps: no team lead, no in-app purchases, two titles | High. Hiring-manager prior, and F9, F10 and F5 are the gaps a hiring manager would test first | Hold the stated negatives plainly, then the nearest work, then the ramp as a plan |
| Case / Strategist | Live problems from the role: a drop going wrong, a cross-team event, falling retention | High. Hiring managers buy capability on their own roadmap | Clarify, then structure, then one metric, then a risk |
| Data-Driven Prober | Attribution probes on the retention figure and the calendar | High. The JD owns KPIs and retention, and F3 is the one number in your material | Name the weakest assumption before they do, or say you don't know how it was counted |
| Pressure | Time-boxed challenges to your leadership and your ownership | Medium. Leadership is the obvious pressure point | Hold, then concede the specific thing |
| Conversational | A friendly opener and a casual question about games | Medium. Casual questions are still scored | A 90-second arc, and a considered answer to the casual question |
| Values / Behavioral | Stories about hard truths and players | Low to medium. No company values were known, so these are generic | Selection scaffolds with an honest branch |
| Peer Evaluator | Seam and credit questions | Low. Not a peer, so not banked. Cross-team probes sit in the Case bank | None |

## Question banks

Questions are ordered by persona weight. Skeptic 4, Case 4, Prober 4, Pressure 2, Conversational 2, Values 2.

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You haven't led a team, and you haven't worked on a game with in-app purchases. What makes you ready to run live events for two mobile titles?" | JD | [grounded] "Never led a team" (your message); [grounded] "never worked on a game with in-app purchases" (your message) | Hold without arguing: "That's right. I haven't led a team, and I haven't worked on a game with in-app purchases." Then the nearest work, in your words: "I ran the weekly content-drop calendar for our main title for the last two years," and "Wrote the release checklist our QA team still uses." Then the ramp, as a plan: what you would learn first about the monetisation side, and what you would ask the two teams for in week one. Answer slot: if you coordinated any of design, art, engineering or community on an update, say which and how; if not, say so plainly. Hold through two follow-ups by returning to the calendar. Concede specifically: "Monetised events are new to me, and I'd want to learn them before I was sure of them." | Highest-ROI prep in the pack. F9 and F10 are your own negatives, and F6 is where the JD's scope runs past your material. The question is the hiring manager's, so expect it early. |
| A2 | "You ran the calendar for your main title. How would you run calendars for two titles at once?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | Answer from the quote's scope: one calendar, weekly drops, two years. Answer slot: if you ever ran two calendars, or ran a live event as well as drops, say what and how. If not, say so plainly, then describe how you would sequence two calendars, as a plan. Never say you have run two. | F5 is transferability. The JD's "two of our mobile titles" is the raising source, so the question is fair, and the honest first branch is no. |
| A3 | "The post-event review and its KPIs are yours in this role. Where is your evidence that you've owned one?" | JD | [grounded] "own the post-event review and the KPIs it reports" (JD) | Open with what your material does carry: "Presented the monthly retention numbers to the studio head." Answer slot: if you have run a post-event review, say what it covered and who used it. If not, say so plainly, and describe the first review you would run and which KPIs it would report. Name a KPI only if you can say how it was counted. | F4 is discovery: no quote reaches the requirement. A plan is the honest answer when there is no record. |
| A4 | "Your background is a puzzle studio. Why is live mobile your next step?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio" (your message) | Give the reason in your own words. Anchor it in what you did: "I ran the weekly content-drop calendar for our main title for the last two years." Say what drew you to live operations, if it is true for you. This pack does not supply that reason. | Tests motivation. The question is a skeptic's "why now", and the answer should draw only on what you did. |

### B. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Two weeks before a content drop, QA finds a blocking bug in one of the two titles. Walk me through your next 48 hours." | CASE | [generic] | Clarify first: what is blocking, what the drop contains, who can make the go or no-go call. Then options with their cost: slip the drop, ship without the content, or hotfix. Name where the decision gets recorded on the release checklist, and who tells the community what. Think aloud, and challenge one premise respectfully. | A live problem from the JD's release-checklist line. It asks about no past, so the guidance makes no claim about you. |
| B2 | "Design wants a live event touching art, engineering and community, in three weeks. How do you run it?" | CASE | [grounded] "coordinate design, art, engineering and community teams on each update" (JD) | Structure: scope, dependencies, one owner per team, checkpoints, cut lines, community messaging. Answer slot: if you coordinated those teams on an update, say which and how. If the nearest thing you did was the checklist, say so: "I wrote the release checklist our QA team still uses." | F6 is discovery. The guidance does not claim the coordination happened. |
| B3 | "Plan next quarter's live events for a mobile title whose retention is falling. What do you need to know first?" | CASE | [generic] | Clarify: when the fall started, what changed (releases, pricing, competitors), and which players. Set the objective and the metric before choosing events. Propose one or two event types, each with a stated reason and a review date. | Tests the calendar and retention requirements together. A generic case, with no claim about your past. |
| B4 | "What does your first ninety days look like with two titles?" | JD | [grounded] "Plan and run the live-events calendar for two of our mobile titles" (JD) | A plan sequence: learn both calendars and their post-event data first; meet QA and the community leads in week one; then one event per title, each with a review. Say every step as a plan, never as a record. | Tests ramp and realism. F5 and F4 are checked here. |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how you ran the content-drop calendar." | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | Say the cadence and what a week's drop contained, in your words. Answer slot: if you decided what went into each drop, say how you decided. If someone else did, say so. Keep "ran" within what the quote says. | F1 is the calendar evidence. The probe is about what was yours. |
| C2 | "How were the retention numbers you presented counted?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" (your message) | Weakest-assumption move: name the assumption behind the figure you would defend least, before they name it. Answer slot: if you built or checked the figures, say how they were counted. If you only presented them, say so plainly. "I don't know how they were counted" is an honest branch. Then say what you would check first. | F3 is discovery. Metric questions get the weakest-assumption move, and the pack does not supply the counting method. |
| C3 | "The role says you're comfortable with player-retention metrics. Which retention figure would you challenge first?" | JD | [grounded] "comfortable with player-retention metrics" (JD) | Name the assumption you would defend least, in your words. If you cannot name a figure you would challenge, say how you would find out what is behind a figure you are handed. Do not name a retention method you have not used. | F3 is the thin bridge. The question's premise is the JD's, and the guidance does not adopt it. |
| C4 | "Your release checklist is still in use. How do you know it catches what it's meant to?" | EXP | [grounded] "Wrote the release checklist our QA team still uses" (your message) | "Still uses" is the evidence. Do not claim it has caught particular bugs. Answer slot: if you have a record of what it caught, say what. If not, say that the team still uses it, and how you and QA would find out if it missed something. | F2 is presentation. This probe is for an impact claim the material does not carry. |

### D. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why should we hire someone who has never led a team?" | JD | [grounded] "Never led a team" (your message) | Hold: "The role asks me to coordinate four teams on each update, and I haven't led a team." Then the nearest thing: "I wrote the release checklist our QA team still uses." Concede specifically: "If the role needs someone to manage people from day one, that isn't my experience yet." | F9. Hold-then-concede: do not fold on the coordination point. |
| D2 | "That checklist: how much of it was actually yours?" | EXP | [grounded] "Wrote the release checklist our QA team still uses" (your message) | Hold to the quote: "I wrote it, and QA still uses it." Concede exactly what you cannot claim. Answer slot: if QA shaped it, say how. If you wrote it alone, say so. Do not fold on "I wrote it." | F2. Tests attribution under pressure. |

### E. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | JD | [grounded] "4 years as an associate producer at a puzzle-game studio" (your message) | A 90-second arc: the studio, the four years, the content-drop calendar, the checklist, the retention presentation, and why this role. Stay with the quotes, and add no titles or results. | A casual opener that is still scored. It sets up A1 and A4, and it carries F1 and F8. |
| E2 | "What mobile game have you played recently, and what did its live updates do well?" | JD | [generic] | Name one game you have played and one update you noticed. Give your view of what it did for players, and label it as your view. Do not describe another company's internals. | Casual, but it is the JD's live-update area. It asks about no past, so the guidance makes no claim about you. |

### F. Values / Behavioral (generic: no company values known)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Tell me about a time you had to tell a senior person something they didn't want to hear." | VAL | [generic] | Selection scaffold: pick a time a senior person heard something unwelcome from you. Name the stake, what you said, and what happened after. If no such time comes to mind, say so plainly, then say how you would handle it now. | No company values are known at L0. Your material carries no hard-truth story, so none is offered. |
| F2 | "When did you put a player's experience ahead of a metric?" | VAL | [generic] | Same scaffold: pick a time, name the metric and the player issue, and the call you made and why. If none comes to mind, say so, then say how you would weigh it. | Generic, with no claim about your past. |

**Requirement coverage**

| JD requirement | Covered by |
|---|---|
| Plan and run the live-events calendar for two titles | A2, B4, C1 |
| Coordinate design, art, engineering and community on each update | B2 (also A1) |
| Own the post-event review and the KPIs it reports | A3, C3 |
| Manage the release checklist with QA | B1, C4, D2 |
| 3+ years producing live-service games or apps | E1 |
| Experience running a content calendar | C1 |
| Comfortable with player-retention metrics | C2, C3 |
| Clear written communication | None, and why: no question tests it. It is judged on how every answer is delivered. |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What would a good first quarter look like for this role, and what would make you say it went wrong?" | Shows you want the bar stated, and surfaces what they actually measure. |
| R2 | "Are the two titles' live calendars planned together, or separately?" | Shows you have read the JD closely, and tells you how much of A2 is real. |
| R3 | "When a post-event review changed a decision, what did it change?" | Tests whether their reviews drive decisions, which matters for the KPI ownership line. |
| R4 | "Who makes the go or no-go call on a release, and where does QA's view sit in that?" | Shows you think of the checklist as a decision, not a form. |
| R5 | "What did the last person in this role do well, and what did they wish they had in place earlier?" | Role-generic: there is no interviewer profile, so no path-based question is possible. Asks for the working reality. |
| R6 | "If someone joined without monetisation experience, what would you want them to learn first?" | Lets Tobias name the gap and the ramp, which turns A1 into a plan they gave you. |

## Sources

Provided material: the JD and your background, both pasted in this conversation. No links were given.

Research tier: L0. No searches were run and no pages were fetched. Research was not consented to at this stage, so the target rows below stand as unavailable, with what each would have moved.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh values | unavailable | Values cheat sheet (not in this pack). Values questions F1 and F2 are generic |
| 2. Saltmarsh interview process | unavailable | Loop structure; persona weights are hiring-manager priors |
| 3. Saltmarsh strategy / recent news | unavailable | No CO questions in this pack |
| 4. Tobias Wrenfield, Saltmarsh | unavailable | Interviewer read, personalised persona weights, path-based reverse question |
| 5. Representative Live Operations Producer JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Tobias's public profile or talks → an interviewer read, persona weights from their footprint, and a path-based reverse question
- Permission to run L1 research (up to 6 searches and 2 page fetches) → Saltmarsh's values, so the values cheat sheet can be written; their interview process, so the persona weights can reflect the loop
- Your CV → fit evidence can quote your CV as well as your message
- The interview format (take-home, presentation, or panel) → a graded-deliverable section, if one is declared
- Your own account of how a retention figure was counted, in your words → turns F3's answer slot into a grounded row, upgrades C2
