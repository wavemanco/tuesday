Your prep pack is saved as `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-alone-part-2-rooms-case-3-denied-553b0af4/052310a7-7e2f-4709-ad20-0438d624bc0e/scratchpad/stripe_product_operations_manager_interview_pack.md`.

It is a generic pack. The host refused web search, so nothing in it about Stripe's values, interview process or strategy has been checked, and I haven't guessed at any of it. There is also no JD or CV yet, so the fit snapshot is a worksheet and every requirement is labelled `[generic]`. The 20 questions are weighted evenly, since I don't know the round format or who you're meeting.

The highest-return prep is D1: "Which part of this role would you be weakest at on day one?" Without a CV on file, a skeptical interviewer is likely to ask it directly, so have a specific, honest answer ready.

I can also play the skeptic on D1 in a live drill, if you want to rehearse it. Two more one-line offers, neither pushed: I can save a `tuesday-dossier.md` recording the gaps this prep exposed, and I can convert the pack to Word.

Two questions would restructure the pack:
1. Who is the final round with (hiring manager, peer, skip-level), and what format is it: one conversation, a panel, or several sessions?
2. Could you paste the job description and a short summary of your background? Your own sentences go straight into the answer guidance, and the generic rows become grounded.

If you allow web search, I can rerun the Stripe values, process and strategy research and add it to the pack.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: stripe_product_operations_manager_interview_pack.md -----
# Interview prep pack: Product Operations Manager, Stripe (final round)

Interviewer: not known. Relationship: not known. This is a flat-weight pack, built on a generic pattern for the role, not on Stripe's documented process. No job description and no CV were provided. Web search was refused by the host, so nothing in this pack about Stripe's values, interview process or strategy has been checked; all of it is labelled `[generic]`.

## How to use

- **Personas** describe how a question is asked. **Types** describe what is being scored.
- Type key: **VAL** behavioural/values alignment · **EXP** your own experience, probed · **JD** the role's stated responsibilities · **CO** company and strategy knowledge · **CASE** a live problem.
- Guidance is scaffolding, not a script. Aim for 90–120 seconds spoken.

## Fit snapshot

No JD and no CV, so every evidence cell is `none given`. The requirements are a role-family pattern, written as plain prose and labelled `[generic]`; they are not quotes from a source.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Running processes that cross product, engineering, go-to-market and finance (role-family pattern, no source) | none given | none | [generic] | discovery | Strong evidence is one process you ran end to end, with the teams it touched and what changed. Answer slot: if you have run such a process, name it and your part in it, in your own words; if not, say so and say how you would learn the seams first. |
| F2 | Operating cadence: planning, business reviews, launch readiness (role-family pattern, no source) | none given | none | [generic] | discovery | Strong evidence is a recurring meeting or review you designed or ran, and what it decided. Answer slot: name the cadence you have run and what you changed in it; if you have not run one, say so and describe the one you would start with. |
| F3 | Defining and tracking outcome measures (role-family pattern, no source) | none given | none | [generic] | discovery | Strong evidence is a measure you chose, what it counted, and who used it. Answer slot: if any figure you tracked was counted and used, say what was counted; if none was, say so and say what you would measure first. |
| F4 | Analysis with data, with tradeoffs made explicit (role-family pattern, no source) | none given | none | [generic] | discovery | Strong evidence is an analysis you did yourself, the decision it fed, and its main limit. Answer slot: if you did such an analysis, say which part was yours; if not, say so and describe how you would check a number before using it. |
| F5 | Influencing senior stakeholders without formal authority (role-family pattern, no source) | none given | none | [generic] | discovery | Strong evidence is a disagreement with a senior person, how it was resolved, and what you did. Answer slot: if you have one, say what you did and how it ended; if not, say so and say how you would approach it. |
| F6 | Designing intake, prioritisation or tooling for other teams (role-family pattern, no source) | none given | none | [generic] | discovery | Strong evidence is a request or intake system you designed or changed, and its owner. Answer slot: if you built or changed one, say what it replaced and who owned it; if you did not, say so and describe the first thing you would look at. |

Requirement coverage: F1 → A1, B2, C1 · F2 → C2 · F3 → A1, A2, A3 · F4 → A2, C1 · F5 → B1, B2 · F6 → C3. No requirement is uncovered. A gate row cannot be identified until a JD is in hand; none is listed here.

## Prohibited claims

Built locally, because no background was supplied. Nothing about your past is coached as fact.

| Not coached | Basis | Honest form |
|---|---|---|
| Any metric, outcome or result from your past | None is in the material yet | The pack's own observation: the material shows none. Answer slots in A2, A3 and B2 ask for what you have. |
| Familiarity with Stripe's internal tools, processes or products | Nothing supplied; a common overreach for this role | Only what you have read or used yourself, named as such. |
| Audit, compliance or finance-close ownership | JD-typical for this role family; not in the material | No slot is scripted. If it comes up, answer from what you did, or say you have not done it. |

## Persona table

Relationship and round type are unknown, so the weights are flat, which is the fallback for an unknown loop. No loop source establishes Stripe's rounds, and no values round is detected. Each persona gets 2–3 questions.

| Persona | How it shows up | Likelihood | Counter-strategy |
|---|---|---|---|
| Data-Driven Prober | Asks how a number was counted and what it rests on | Medium (flat); every role of this kind probes metrics | Name the weakest assumption before they do; say plainly where you do not know how a figure was counted. |
| Pressure | Challenges a position, time-boxes answers | Medium (flat); common in final rounds | Pause, restate the question, hold through two follow-ups, concede only what is true. |
| Case / Strategist | Live operational problems | Medium (flat); the role's core work is ambiguous process problems | Clarify, then objective, options, decision, and the risk you would watch. |
| Skeptic | Probes the gap between the CV and the role | Medium (flat); with no CV, the interviewer will ask the question directly | Answer the weakest-area question honestly, with one area and a ramp plan. |
| Conversational | Opens with "walk me through" and tools questions | Medium (flat); casual questions are still scored | A prepared 90-second arc; treat tool questions as scored. |
| Peer Evaluator | Seams between teams, credit, disagreement | Low (flat) unless the round is with a peer | Propose seam principles, not claimed knowledge of their seam. |
| Values / Behavioural | Scenario questions about past behaviour | Low (flat); no values round detected | Choose stories where the hard truth landed; if none, say so and give the nearest. |

## Question banks

Provenance is `[generic]` throughout: the questions and guidance make no claim about your history. Where the guidance asks about your experience, it is a selection scaffold ending in an honest branch.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| **Data-Driven Prober** | | | | | |
| A1 | "Walk me through how you would define the success metric for a process you were asked to improve." | JD | [generic] | Name the metric, the denominator and the one assumption you would defend least. Use a real example if you have one; if not, say how you would count it and what would change your mind. | F3 and F1 read through this: outcome definition is a core ask of the role family. |
| A2 | "Which assumption behind that number would you defend least?" | EXP | [generic] | Name it before they do. Say plainly where you do not know how a figure was counted. Answer slot: if you counted a figure yourself, say how and what it was sensitive to; if you did not, say so and return to the decision it fed. | F3 and F4: a metric answer rests on its assumption, and this is where it breaks. |
| A3 | "Tell me about a time you used data to change a decision." | EXP | [generic] | Pick a time the decision changed and name it. Say what the data showed and what you did yourself. If no such time comes to mind, say so plainly, then give the nearest thing you did or how you would approach it. | F3 and F4. An open prompt, so the choice of instance is yours. |
| **Pressure** | | | | | |
| B1 | "Sixty seconds: why should we hire you over an internal candidate?" | JD | [generic] | Pick the one strongest, specific thing you bring. State where an internal candidate would be stronger, once. Hold through two follow-ups; concede a specific point only if it is true. | F5. The pressure persona tests composure, not content. |
| B2 | "Tell me about a process that didn't land. How much of that was actually you?" | EXP | [generic] | Separate what you owned from what the team owned. If adoption failed, concede that specifically. Do not fold on the core claim. If no such process comes to mind, say so and give the nearest. | F5 and F1. The hold-then-concede structure is the rehearsal. |
| B3 | "Give me a reason this would fail in six months." | JD | [generic] | Name two realistic failure modes and the one you would watch first. Pause before answering. | Tests judgement under pressure; generic to the role family. |
| **Case / Strategist** | | | | | |
| C1 | "A launch slipped two weeks and sales is unhappy. What do you do in the next 48 hours?" | CASE | [generic] | Clarify what is slipping and who is affected, then the options, the decision and the date. Think aloud. Challenge one premise, respectfully. | F4 and F1: a cross-functional tradeoff under time pressure. |
| C2 | "Our review meeting has grown to forty people in the room. How would you redesign it?" | CASE | [generic] | Clarify which decisions the meeting makes. Separate information-sharing from decisions. Propose one change and a way to test it. | F2: the operating cadence. A live problem, so it assumes nothing about you. |
| C3 | "Design an intake process for requests to the product team from the rest of the company." | CASE | [generic] | Name the intake criteria, the owner, a response target, and what gets declined and why. | F6. |
| **Skeptic** | | | | | |
| D1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | Name one specific area you have least direct practice in. Say how you would close it in the first 30 to 60 days. Do not bluff a competency. If you do have direct practice in the area, say which. | **Highest-ROI prep in this pack.** With no CV on file, the skeptic is likely to ask this directly. A rehearsed, specific, non-defensive answer changes the interview. |
| D2 | "Why are you leaving where you are, and why now?" | EXP | [generic] | One honest reason, framed around what you want rather than what you are escaping. If the honest reason is a constraint, say it plainly. | Motivation consistency is scored in every skeptic round. |
| D3 | "Why Stripe, and why this role rather than a product role?" | CO | [generic] | Name one thing about Stripe you have read yourself, and say where you read it. Do not claim knowledge of internal work. | CO without research: generic by design. Use only what you have verified. |
| **Conversational** | | | | | |
| E1 | "So, walk me through the journey." | EXP | [generic] | A 90-second arc: where you started, the kind of work, the through-line into this role. Selection scaffold, since no background was supplied. | Opening question; casual register, still scored. |
| E2 | "What are you actually playing with in operations tooling these days?" | JD | [generic] | Name one tool you have used and what you used it for. Do not list tools you have only read about. | Tool questions are scored even when asked casually. |
| E3 | "What have you been reading about product operations lately?" | CO | [generic] | Name one source you actually read and give a short view on it. | Tests genuine interest and currency. |
| **Peer Evaluator** | | | | | |
| F1 | "Our teams sit side by side. Where's the seam, and what happens when we disagree?" | JD | [generic] | Propose seam principles, not claimed knowledge of their seam. Scaffold: how you have handled disagreement with an equal; if none, the principle you would use. | Peer round, only if it is one; a flat-weight pack still touches it. |
| F2 | "How do you handle credit when work spans teams?" | EXP | [generic] | Name the shared credit and your own contribution, separately. If you have no example, say so and give the principle. | Credit-sharing probe. |
| F3 | "What would you need from us to do this job well?" | JD | [generic] | Three concrete asks: data access, a decision owner, a standing meeting. | Reciprocity framing, the strongest peer signal. |
| **Values / Behavioural** | | | | | |
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Pick a time the truth landed. If none, say so and give the nearest. Use "we" for context and "I" for what you did. | Included because all plausible personas are touched. No values round is detected, so this is not weighted. |
| G2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a time the customer outcome beat the internal number, and what you gave up. If none, say so. | As G1. |

## Reverse questions

Role-generic, since no interviewer profile exists.

1. "What would the first 90 days look like for someone in this role, and which process would they own first?" Why it lands: shows you are thinking about the operating work, not the title.
2. "Where is the hardest cross-functional seam on this team right now, and what has been tried?" Why it lands: asks for the real problem and signals you will not pretend to know the answer.
3. "How will success in this role be measured in the first year, and who sets the metrics?" Why it lands: connects to F3 and shows you expect outcomes to be defined.
4. "What prompted opening this role now?" Why it lands: the honest answer tells you whether the role is new or a backfill.
5. "How does product operations work day to day with product and engineering: a shared intake, a planning cycle, or something ad hoc?" Why it lands: shows you think in systems.
6. Only if the interviewer is a peer: "What could a new person do in their first month that would genuinely help your team?" Why it lands: the reciprocity question.

## Sources

- Provided documents: none beyond the conversation. No JD, CV or interviewer information was supplied.
- Searches sent, all refused by the host:
  - "Stripe company values operating principles": refused
  - "Stripe interview process Product Operations Manager final round": refused
  - "Stripe strategy recent news 2026": refused

Research tier: L0 (L1 was the default; all three searches were refused, so nothing ran).

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Stripe values` | unavailable | Values cheat sheet, not produced. Would have named Stripe's published values. |
| 2. `Stripe interview process Product Operations Manager` | unavailable | Loop structure and persona weights. Persona weights are flat because of this. |
| 3. `Stripe strategy` / recent news | unavailable | CO bank. D3 and E3 are generic because of this. |
| 4. `{interviewer name} Stripe` | n/a | No interviewer name was given, so there was no query to form. |
| 5. Representative Product Operations Manager JD | unavailable | Fit snapshot requirements, which are `[generic]` because of this. |

## Upgrade menu

- Job description text → F1–F6 become `[grounded]` rows, and the JD-tagged questions take the posting's wording.
- Your CV or a short background summary → the confidence column rises from `none`, and the answer slots in A2, A3 and B2 get your own sentences to draw on.
- Round type and who the interviewer is (manager, peer, skip-level) → persona weights are recomputed; they are flat now.
- Recruiter's note on the format of the final → the loop structure replaces the generic pattern.
- Permission for web search → Stripe's values, interview process and strategy at L1; the values cheat sheet and grounded CO questions become possible.
- The interviewer's name → their public footprint, and a reverse question tailored to their career.
- No dossier is present. A `tuesday-dossier.md` from job-underwriter would add verified evidence in place of the `none` rows.
