Your prep pack is saved as `saltmarsh_live_operations_producer_interview_pack.md` (path above). I couldn't run any web research, so the pack rests only on your JD and your background note. I've built it as a hiring-manager round with the loop unconfirmed.

**What to rehearse first:** The JD asks you to plan live events for two titles and own the KPIs. Your material shows one title's content-drop calendar for two years. Question A2 is the most likely probe, and it's the one to rehearse hardest. Your honest answer is the calendar you ran. Don't add steps you didn't own.

**Other gaps the pack flags:**
- You haven't led a team, and the JD asks you to coordinate four teams on every update. Your material doesn't show that coordination.
- You haven't worked on an in-app purchase game. The JD doesn't ask for it, but expect it.
- "Own the post-event review" isn't in your material. Retention reporting is the nearest thing you have.

The pack gives you plain acknowledgments for those gaps, then a plan for closing them, and it never supplies a story you didn't tell me. Your figures get a "how was it counted" question, and you'll need an answer in your own words.

**Research:** Three web searches (Saltmarsh values, interview process, Tobias Wrenfield) were refused by the permission check, so no results came back. The pack has no company values, no loop structure, no strategy and no interviewer read. Reverse questions are role-generic. If you paste Saltmarsh's values page, or any public talk or post by Tobias, I can add those.

I'd also offer, in one line each:
- **Drill:** I can play the Skeptic on A2 and push back on your answer.
- **Dossier:** I can save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions.
- **Word:** I can convert the pack to .docx if you want it.

Is Friday's 60 minutes a one-to-one with Tobias, or a panel or multi-part round? Is he the person you'd report to? The answer changes how the question banks are weighted.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh_live_operations_producer_interview_pack.md -----
# Interview prep: Live Operations Producer, Saltmarsh Games

**Interviewer:** Tobias Wrenfield, Head of Live Operations. Relationship not confirmed; weighted as a hiring-manager round (see Persona table).
**Format:** 60 minutes, one session. Loop not documented (see Sources).

## How to use

Personas describe how a question arrives. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and stop where your own experience stops.

Type key:
- **JD**: can you do the listed job, including its gaps
- **EXP**: do your past claims survive scrutiny, and what exactly was yours
- **CASE**: structure and reasoning on a live problem from this role
- **CO**: company knowledge (not covered: company research did not run)
- **VAL**: values alignment (not covered: no values-style round detected)

## Fit snapshot

Requirements are the JD's own words. Evidence is your own sentences, verbatim, with the source named.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | transferability | Your material says one title's content-drop calendar, weekly, for two years. It does not say live events, or a second title. Bridge in those terms only: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: the JD asks for two titles, so expect a probe on the second. If you planned or shared planning on another title, say which and how; if not, say so plainly and say how you would carry one calendar across two. |
| F2 | "own the post-event review and the KPIs it reports" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | medium | [grounded] | presentation | Your sentence reaches KPI reporting in other terms: you presented retention numbers. It does not show a post-event review. Bridge: "Presented the monthly retention numbers to the studio head." Answer slot: if any event was reviewed after it ran, say which and what changed; if none was, say so plainly. |
| F3 | "manage the release checklist with QA" (JD) | "Wrote the release checklist our QA team still uses." (your message) | medium | [grounded] | none | Your sentence already reaches the requirement in role terms. Keep the verb: wrote, not managed. The checklist is inspectable; expect a probe on what it covers. |
| F4 | "3+ years producing live-service games or apps" (JD) | "4 years as an associate producer at a puzzle-game studio" (your message) | medium | [grounded] | transferability | Four years matches the years. Your material does not say the title ran as a live-service game. Bridge: "4 years as an associate producer at a puzzle-game studio." Answer slot: if you can say how the title's updates were run, say so in your own words. |
| F5 | "experience running a content calendar" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | none | Reaches the requirement directly. Expect a probe on scope; no claim beyond the sentence. |
| F6 | "comfortable with player-retention metrics" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | medium | [grounded] | presentation | Reaches the requirement in other terms: you presented the numbers. Bridge keeps that scope. Answer slot: how the figures were counted, in your own words; if you did not define them, say so. |
| F7 | "coordinate design, art, engineering and community teams on each update" (JD) | none given | none | [grounded] | discovery | Your material does not show coordination across these teams. Answer slot: if you coordinated any of them on a drop, say which and how; if not, say so and say how you would set it up. |
| F8 | "clear written communication" (JD) | "Wrote the release checklist our QA team still uses." (your message) | medium | [grounded] | none | A written document another team uses every release. Better evidence than an adjective; say what it does. |
| F9 | Leading a team (generic: role-family pattern, not quoted from the JD) | "Never led a team" (your message) | none | [grounded] | capability | A negative you stated. Plain acknowledgment: "I haven't led a team." Then how you would learn it, said as a plan, never as a past. |
| F10 | In-app purchase monetisation (generic: role-family pattern, not quoted from the JD) | "never worked on a game with in-app purchases" (your message) | none | [grounded] | capability | A negative you stated. Plain acknowledgment: "I haven't worked on a game with in-app purchases." Then how you would learn it, as a plan. |

Confidence is set by inspectable proof: a checklist or calendar you can show would raise F3 and F5. Your own sentences are the only evidence in this pack; nothing else is claimed about your experience.

## Prohibited claims

Built locally from the fit snapshot. These are the claims a candidate reaches for under pressure. The pack will not coach any of them.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the live-events calendar for two titles | Inflated form of F1 | "I ran the weekly content-drop calendar for our main title for the last two years." Your material says one title, not two. |
| Owned the post-event review and its KPIs | Inflated form of F2 | "Presented the monthly retention numbers to the studio head." |
| Managed the release process with QA | Inflated form of F3 | "Wrote the release checklist our QA team still uses." |
| Experience of live-service games | Inflated form of F4 | "4 years as an associate producer at a puzzle-game studio." |
| Led a team, or coordinated design, art, engineering and community on updates | Negative you stated (F9), and silence (F7) | "I haven't led a team." For F7, the answer slot only. |
| Has planned around in-app purchases | Negative you stated (F10) | "I haven't worked on a game with in-app purchases." |

## Persona table

| Persona | How it shows up here | Likelihood (reasoning) | Counter-strategy |
|---|---|---|---|
| Skeptic | Questions the one-title scope and the missing team leadership | Highest. Hiring-manager prior, and your two gaps are in the JD's own terms | Rehearse the single predictable objection until plain. Bridges stay inside your sentences; name the gap yourself |
| Case / Strategist | Live problems from the role: a release going wrong, a retention drop, two titles' calendars | High. A hiring manager buys capability by asking for a plan | Clarify, then structure: goal, constraint, options, what you would check first. Think aloud |
| Data-Driven Prober | Asks how the retention figures were counted and what the checklist covers | High. Every CV figure is a magnet; you presented retention numbers | Say what you know and what you do not. Name the weakest assumption before they do |
| Pressure | Time-boxed challenges on your gaps and on "how much was you" | Medium. Interview length is 60 minutes, so time-boxing is likely | Pause, restate, hold through two follow-ups, then concede the specific gap |
| Conversational | Opening biography and a casual question about a live-service game | Low-medium. Casual questions are still scored | Pre-script a 90-second arc. Never give "I think you've covered everything" as the reverse-question answer |

Weights: Skeptic 5, Case 4, Prober 4, Pressure 3, Conversational 2. Relationship not confirmed, so these are hiring-manager priors. No interviewer signals exist: research did not run.

## Question banks

Type column carries one tag per question. Provenance carries your sentences the guidance rests on.

### A. Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Your background is one title's content calendar. This role plans live events across two titles. What makes you ready for the second?" | JD, EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Hold on the calendar you ran. Bridge: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: if you planned or shared planning on another title, say which and how; if not, say so plainly, then say how you would carry one calendar across two. Hold through two follow-ups by returning to the calendar | F1 is the evidence for the two-title requirement. JD-raised, so the premise is the JD's line |
| A2 | "What part of live events for a title have you owned yourself, end to end?" | JD, EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | **Highest-ROI prep in this pack.** The deepest rehearsal: three follow-ups. Your honest answer is the calendar. Answer slot: if you owned any step beyond the calendar, say which steps, which decisions and how you decided, in your own words; if not, say so plainly and stay with the calendar. Never add a step | F1 and the JD's end-to-end ownership line. This objection is the most likely one, and the one where a pack is most tempted to thicken the material |
| A3 | "You haven't led a team, and this role coordinates four teams on every update. Why would that work?" | JD | [grounded] "Never led a team" | Plain acknowledgment: "I haven't led a team." Then describe what you did coordinate, only as your sentences state it: the calendar and the checklist. Answer slot: if you coordinated design, art, engineering or community on a drop, say which and how; if not, say how you would set up that coordination | F9 is the gap. The answer is candour, then a plan |
| A4 | "What draws you from a puzzle studio to a live-service role?" | VAL, EXP | [grounded] "4 years as an associate producer at a puzzle-game studio" | Say what you want from the role in your own words, and stop where your four years stop. Do not claim live-service work | F4 is the stated years. Motivation is probed under the Skeptic persona |
| A5 | "Have you planned live events for a game where in-app purchases are part of the economy?" | JD | [grounded] "never worked on a game with in-app purchases" | Plain acknowledgment: "I haven't worked on a game with in-app purchases." Then how you would learn the economy, as a plan. Answer slot: if you planned any event around a non-content lever, say which and how | F10 is the stated negative. Question presupposes nothing about the candidate |

### B. Case / Strategist (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Two weeks before a major update, QA flags a crash in the new content. Walk me through your next hour." | CASE | [grounded] "Wrote the release checklist our QA team still uses." | Clarify: what the crash affects and how many players. Options: delay, hotfix, ship and mitigate. Who to tell: QA, engineering, design, community. What to check first. The checklist is a structure you wrote, not evidence of an outcome | A live release problem from F3's requirement. The question presupposes nothing about your past |
| B2 | "Retention on one title dropped over a month. How do you diagnose it?" | CASE | [grounded] "Presented the monthly retention numbers to the studio head." | Clarify the definition and cohort. Check for a calendar change in the window, then segment. Name the assumption you would test first. The retention numbers you presented are a place to say how a figure is counted, only if you did count it | Retention is in the JD; this is the case form of F6 |
| B3 | "Plan the next 90 days of live events for two titles that share one design team. What do you cut?" | CASE | [generic] | Clarify goals and the KPI for each title. Sequence events against capacity, and say what you would drop first. Name the trade-off in your own words | A live problem from the JD's two-title requirement. Presupposes nothing about your history |
| B4 | "A community team reports a spike in complaints about a reward after a drop. What do you do?" | CASE | [generic] | Triage: is it a bug or a design issue? Who decides a fix, and how fast? What you tell the community. What you log for the post-event review | Covers the JD's community coordination and review requirements. Generic; no claim about your past |

### C. Data-Driven Prober (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the retention numbers you presented were counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Answer slot: say how the figures were counted, in your own words; name the assumption you would defend least; say which part was yours. If you did not define the metric, say so plainly. The pack supplies no method | F6 is the figure. Defend-the-number slots apply |
| C2 | "What did you measure after a content drop, and what did you do with the result?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Answer slot: if you reviewed any drop's results, name the metric and what changed. If you did not, say so plainly, and name the monthly retention numbers you presented as the nearest thing your material carries | F1 is the calendar; the post-event review is not in your material (F2) |
| C3 | "How would you know a live event worked, and how soon would you know?" | JD | [grounded] "Presented the monthly retention numbers to the studio head." | Name leading indicators and a baseline, and say how early each would show. Use the retention numbers only as your sentence states them, and say what you would check first | F2 and F6 are the nearest quotes. The question is the JD's KPI line |
| C4 | "Walk me through what your release checklist covers." | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Walk through the checklist's sections in your own words. Offer to show it: it is inspectable. Answer slot: if QA's use changed it, say how; if not, say so | F3 is inspectable. Expect the next question to be "what did it catch?" Answer only from what you know |

### D. Pressure (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You have sixty seconds: why should we hire you over someone who has run live events for two titles?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Pause. Restate the question. Lead with the calendar you ran. Hold for two follow-ups. Concede the two-title gap in one specific sentence, then say how you would close it | The hold-then-concede structure on F1 |
| D2 | "The retention numbers you presented: how much of them was actually you?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Answer slot: if you produced the figures, say how; if others did, name who did and what you did with them. Hold what you presented; concede any part you did not produce, specifically | F6. Hold-then-concede on attribution |
| D3 | "You haven't worked on a game with in-app purchases. What would you get wrong first?" | JD | [grounded] "never worked on a game with in-app purchases" | Plain acknowledgment: "I haven't worked on a game with in-app purchases." Name one thing you would check first, as a plan. Do not defend the gap as a strength | F10. Hold the acknowledgment; do not fold on it either |

### E. Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio" | 90-second arc: four years at the studio, the calendar you ran, the checklist you wrote, the retention numbers you presented. Stop where your sentences stop | A scripted arc from your own sentences. Casual is still scored |
| E2 | "What live-service mobile game do you follow most closely, and what does it do with its events?" | CO | [generic] | Name a game you know, and describe one event mechanic in your own words. Do not claim insider knowledge | Company research did not run, so this is a general-market CO question |

## Requirement coverage

| JD requirement | Questions |
|---|---|
| Plan and run the live-events calendar for two titles | A1, A2, B3 |
| Coordinate design, art, engineering and community on each update | A3, B1, B4 |
| Own the post-event review and the KPIs it reports | C2, C3, C1 |
| Manage the release checklist with QA | B1, C4 |
| 3+ years producing live-service games or apps | A4, E1 |
| Experience running a content calendar | A1, A2, A4 |
| Comfortable with player-retention metrics | B2, C1, C3, D2 |
| Clear written communication | C4 (the checklist). No written-sample question: see upgrade menu |
| In-app purchases (generic, not in the JD) | A5, D3 |
| Leading a team (generic, not in the JD) | A3 |

## Reverse questions

Each lands for a reason. No interviewer profile exists, so none is tied to the interviewer's own path.

1. "What would a good first 90 days look like, and which title's calendar would this person inherit first?" Why it lands: it shows you are already planning, and it tests the two-title scope.
2. "How are the two titles' live-event calendars planned today, and where do design, art, engineering and community come in?" Why it lands: it asks for the seam, not a job description.
3. "How are post-event reviews run now, and which KPIs does the studio head expect them to report?" Why it lands: it points at the requirement you cannot yet claim, and asks for the standard.
4. "Who owns the release checklist with QA today, and what has changed on it recently?" Why it lands: it shows you respect the document you wrote, and invites the inheritance question.
5. "How does the team weigh in-app purchase events against content drops, and who owns that trade-off?" Why it lands: it names the gap you have, as a question, which signals honesty.
6. "What would success look like for this role at six months?" Why it lands: it gets the scoring criteria in their words.

## Sources

Provided documents: the job description and the background note in your message.

Research tier: L1 — searches 3 of 6, fetches 0 of 2; user links read 0. Every search sent was refused by the host's permission check, so no result came back.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | unavailable | Refused: "Saltmarsh Games company values". Values cheat sheet omitted |
| 2. Saltmarsh Games interview process | unavailable | Refused: "Saltmarsh Games interview process live operations producer". No loop source, so the Generic archetype applies: screen, hiring manager, panel; flat weights; no values round assumed |
| 3. Saltmarsh Games strategy / recent news | unavailable | No call sent after the refusals. Would have moved the CO bank and the grounding brief; CO question E2 is generic for that reason |
| 4. Tobias Wrenfield, Saltmarsh Games | unavailable | Refused: "Tobias Wrenfield Saltmarsh Games Head of Live Operations". Interviewer read omitted; reverse questions are role-generic |
| 5. Representative Live Operations Producer JD | skipped | Your JD fixes the fit snapshot and the JD-tagged questions |

Company identity is not established: nothing about Saltmarsh Games is used from memory or from any source.

## Upgrade menu

- Interviewer's public talks or posts, or a bio you can paste → an interviewer read, persona weights from their footprint, and a reverse question tied to their own path
- Saltmarsh's values page, pasted → a values cheat sheet mapped to your sentences
- The recruiter's prep email → coverage of any pre-declared deliverable, and the round structure
- A checklist or calendar you can show → raises F3 and F5 from medium confidence toward high
- A short written sample of your own (a checklist note, a post-event summary) → a written-communication question with grounded evidence for F8
- A deeper research pass (company strategy brief, interviewer talks, loop reports): up to 6 more searches and 2 more fetches, several more minutes → a strategy-grounded CO bank and a documented loop
