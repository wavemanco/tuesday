Your prep pack is saved as /tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-alone-part-2-rooms-case-8-denied-fc230ab0/05c58a56-12c0-4ba1-8e3a-ebe5f59ae144/scratchpad/ashgrove_member-experience-lead_interview_pack.md. I built it for all three rounds on 20 November from the JD, your background, and the values and strategy text you pasted. No interviewer names are known yet, so the persona weights rest on the round types. I ran no web searches, because your inputs already covered everything the research would have fed.

The highest-value prep is the contact-centre gap (question B1). It is the objection the Head of Member Services is most likely to raise, since they would be your manager and the JD names the contact centre directly.

Say the word and I'll play the Skeptic on B1. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove_member-experience-lead_interview_pack.md -----
# Ashgrove Credit Union: Member Experience Lead interview pack

**For:** Dara
**Interviews:** 20 November 2026
**Rounds:** recruiter (30 min); Head of Member Services (45 min, your future manager, mostly behavioural); panel of two branch managers (60 min, including a 20-minute complaint escalation case, scored against the four values)
**Interviewer names:** not yet assigned. Persona weights rest on round type and the recruiter's description of each round.

## How to use

Personas describe how a question arrives. Types describe what is being scored. The guidance is scaffolding, not a script: rehearse the shape, then say it in your own words.

| Type | Meaning |
|---|---|
| VAL | Values and behaviour, scored against one of Ashgrove's published values |
| EXP | Your own past work, tested for what was actually yours |
| JD | The job's stated requirements |
| CO | Ashgrove's strategy and competitive position |
| CASE | A live problem from the role |

## Fit snapshot

Each JD requirement is set against the sentences you wrote about yourself. Every quote below is from your message or the JD. Where your material is silent, the row says so as the pack's own observation, and the words you would say are an answer slot. None of the JD's requirements is a credential, legal or location term, so none is a gate; each is graded on fit.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" (JD) | "6 years in retail banking, the last 3 as a branch supervisor" (your message) | medium | [grounded] | transferability | The years and the sector match the JD's words. The limit, as the pack's own observation: your material shows retail banking and branch supervision, not a customer operations function. Say the branch part as it was. |
| F2 | "experience handling regulated complaints" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | presentation | "I handled the branch's formal complaints log." The quote reaches the requirement in other terms; the word "regulated" is not in it. Answer slot: the JD raises regulation, so expect a probe on the rules the log ran to. If it ran to rules or deadlines you were held to, say which and how you tracked them; if it did not, say so plainly. |
| F3 | "Own the member complaints process end to end across branches" (JD) | "I handled the branch's formal complaints log and trained new tellers on our escalation script" (your message) | medium | [grounded] | transferability | Your material shows one branch's log and teller-level training, not an end-to-end process across branches. Say those, at that scope. |
| F4 | "across branches and the contact centre" (JD) | "Never worked in a contact centre" (your message) | none | [grounded] | capability | "I haven't worked in a contact centre." Then how you would learn that side, said as a plan and never as a past. |
| F5 | "report monthly on complaint volumes and resolution times" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | medium | [grounded] | presentation | The spreadsheet is monthly reporting in the quote's own terms, but the material does not say what it measured. Answer slot: if it held complaint volumes or resolution times, say which and how each was counted; if it held neither, say so. |
| F6 | "coach branch supervisors on escalations" (JD) | "trained new tellers on our escalation script" (your message) | medium | [grounded] | transferability | Adjacent work: you taught tellers, not supervisors. Say what you taught and to whom, and stop there. |
| F7 | "comfortable with Excel reporting" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | medium | [grounded] | presentation | The spreadsheet is your reporting evidence in the quote's own terms; Excel is not named in it. Answer slot: say which Excel features you used and which parts were yours to decide; if the work was simple, say so. |
| F8 | "confident presenting to senior leaders" (JD) | "I've never presented to anyone above regional level" (your message) | none | [grounded] | capability | "I haven't presented to anyone above regional level." Then how you would prepare, said as a plan. |
| F9 | "work with digital teams on self-service journeys" (JD) | none given | none | [grounded] | discovery | Answer slot: if you have worked with a digital or self-service team, say what it was and your part in it; if you have not, say so and say what you would learn first. |

## Prohibited claims

These are claims the pack will not coach, because the material does not support them or your own sentences rule them out.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end across branches | Inflated form of F3 | "I handled the branch's formal complaints log and trained new tellers on our escalation script." The limit is the pack's observation: the material shows one branch, not an end-to-end process across branches. |
| Worked in a contact centre, or ran complaints through one | Negative you stated (F4) | "I haven't worked in a contact centre." No answer slot. |
| Presented to senior leaders | Negative you stated (F8) | "I haven't presented to anyone above regional level." No answer slot. |
| Coached branch supervisors on escalations | Inflated form of F6 | "trained new tellers on our escalation script" |
| Reported on complaint volumes and resolution times | Inflated form of F5 | The spreadsheet quote at its own scope. The pack observes that the material does not say what the spreadsheet measured. |

Silence is not on this list. Digital and self-service work does not appear in your material, so F9's answer slot covers it; the pack does not assert that you lack it.

## Grounding brief

Your summary of the July 2026 strategy brief, as you pasted it. The pack has not read the full brief, so check wording against it before the interview.

| Item | What the summary says | Provenance |
|---|---|---|
| Digital shift | Move 40% of member service to digital channels by 2028 | [grounded] your summary of the brief |
| Branch network | Consolidate eight branches into five hubs over 2027 | [grounded] your summary of the brief |
| Lending | Launch a small-business lending product in Q1 2027 | [grounded] your summary of the brief |
| Competition | App-only banks are the main competitive pressure | [grounded] your summary of the brief |

Stale framings: none flagged in the summary as given.

## Persona table

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy | Weight | Bank |
|---|---|---|---|---|---|
| Values / Behavioral | Scenario prompts tied to each value; STAR-shaped stories expected | High. The panel scores all four values, and the Head of Member Services round is mostly behavioural | Map each value to a quoted sentence where one carries a story; use a selection scaffold with its honest branch where none does | 5 | A |
| Skeptic | Presses the two gaps the JD names: the contact centre and presenting to senior leaders | High. The Head of Member Services would be your manager, and the gaps are on the page | Rehearse B1 until it is plain: a plain admission, then a plan | 4 | B |
| Case / Strategist | The panel's 20-minute escalation case; strategy-led questions about hubs and digital | Certain for the case; likely for the hub and digital questions | Clarify before structuring; name who owns the complaint | 3 | C |
| Data-Driven Prober | Probes the spreadsheet, the monthly figures and the Excel work | Medium. Your CV names one reporting artefact and no figure, which invites a probe on how it worked | Say what the spreadsheet held and say plainly where you do not know | 3 | D |
| Conversational / Rapport | The recruiter's open start and a question on strategy | High for the recruiter round, but scored lightly | A 90-second arc; close on your two gaps before they are found | 3 | E |
| Pressure / Stress | A branch manager testing how much of the work was yours | Medium. Branch managers judge the escalation case and may test attribution | Hold the quoted position through two follow-ups, then concede specifically | 2 | F |
| Peer Evaluator | Not expected in the rounds as set | Low for these rounds. Touched by F2 and reverse question 4 | Reciprocity framing: what you would need from them | 0 | none |

Weighting reasoning. The recruiter round takes the recruiter priors: Conversational, with a light Skeptic. The hiring-manager prior is Case plus Skeptic, but the 45-minute round is mostly behavioural, so Values / Behavioral rises to the top. The panel blends the top two priors of its members, Values / Behavioral and Case / Strategist, and adds Pressure because branch managers judge the escalation case. The panel is the values round, so Values / Behavioral is guaranteed somewhere in the loop.

## Question banks

### A. Values / Behavioral (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Tell me about a time you put a member's side of the counter ahead of the process." | VAL | [grounded] "I handled the branch's formal complaints log" | Start from the log: you handled the branch's formal complaints log, and the beats stop there. Pick one logged complaint where the member's side changed your decision, and say what you did in your own words. Answer slot: if you did this, say how; if there was no such complaint, or the decision was not yours, say so plainly and describe how you handled the log. | Members First is scored by the panel. F2 is the only quoted complaints sentence, so the story starts there and no outcome is supplied. |
| A2 | "Tell me about a time someone needed something explained to them twice." | VAL | [grounded] "trained new tellers on our escalation script" | Start from the training: you trained new tellers on the escalation script. If a teller needed it explained twice and you changed how you explained it, say what changed. Answer slot: if you checked that someone had understood, say how; if you did not check, say that plainly and say what you would check now. | Plain Words. The script is the nearest plain-language artefact the material holds. F6 is teller-level training, so the story stays there. |
| A3 | "Tell me about a time a decision about one place affected the people who lived there." | VAL | [generic] | Selection scaffold, with no story mapped: pick a time you dealt with a member as a neighbour, not as a figure. Name the place, the decision, and what you did for the people in it. If no such time comes to mind, say so plainly. Your material does not show one, so say how you would weigh a figure against a neighbour's complaint. | Neighbours, Not Numbers is the value the spreadsheet quote works against, so this is the thinnest mapping in the pack. Expect the panel to test it against the hub plan. |
| A4 | "Tell me about a time you kept hold of a problem until it was fixed, though it was not yours to solve." | VAL | [grounded] "I handled the branch's formal complaints log" | Use the log as the anchor and say whether the complaint stayed with you until it closed. If you followed one through to a fix, say what the fix was and what your part was. Answer slot: if you did not follow one through, say so plainly and name the part you did keep hold of. | Own the Fix. The value is about keeping hold, so the answer has to say what was held and for how long. |
| A5 | "Tell me about a time you had to tell someone senior something they did not want to hear." | VAL | [generic] | Selection scaffold: pick a time you took a hard position to someone above you. Name the stake, the position you held, and whether the working relationship survived. If no such time comes to mind, say so plainly, then say how you would raise a pattern in complaints with your regional manager. | A persona stem for the Values / Behavioral interviewer. It tests honesty upward, which the Pressure persona also tests. |

### B. Skeptic (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You haven't worked in a contact centre, and this role owns complaints across one. Why should we trust you with that?" | JD | [grounded] "Never worked in a contact centre"; JD "across branches and the contact centre" | Hold: "I haven't worked in a contact centre. The complaints I have handled came through a branch's formal complaints log, and I trained tellers on its escalation script." Follow-up 1, "What would you get wrong first?": say the contact-centre side is the part you would expect to know least, and that you would learn it before changing anything. Follow-up 2, "So why you?": return to the log and the script, then state the plan again. Concede specifically: "I won't pretend to know the contact-centre side. I would learn it before changing anything." | The most predictable objection and the highest-ROI prep in this pack. F4 is the gap the JD names most directly, and this is the Skeptic's first question. It has three levels of rehearsal because the second follow-up is where candidates fold. |
| B2 | "How would you work with our digital teams on a self-service journey?" | JD | [grounded] "work with digital teams on self-service journeys" (JD) | Plan-based answer: how you would start, which member problem you would look at first, and whom you would bring in. Answer slot: if you have worked with a digital or self-service team, say what it was and your part in it; if not, say so plainly and say what you would learn first. Do not describe digital work the material does not show. | F9 is silence, not a stated absence, so this is a slot. The strategy's 40% digital target makes the question near-certain at the Head of Member Services round. |
| B3 | "You've never presented to anyone above regional level. How would you take a complaints trend to an executive?" | JD | [grounded] "I've never presented to anyone above regional level" | Plain acknowledgment: "I haven't presented to anyone above regional level." Then the plan: the one thing you would put in front of an executive first, how you would test it with your regional manager beforehand, and how you would keep it to what the figures show. The plan is about the future, never a past presentation. | F8 is a negative you stated, so the pack may give you the words. The JD's senior-presenting requirement cannot be closed by the material, so the bank rehearses a plain admission and a credible plan. |
| B4 | "You trained tellers. This role coaches supervisors. What is the difference, and how would you close it?" | JD | [grounded] "trained new tellers on our escalation script" | Say the difference in plain words: tellers were taught the script; supervisors make escalation decisions and need coaching on those decisions. Name what you would observe first in a supervisor's escalations. Answer slot: if you have coached anyone above teller level, say how; if not, say so plainly. | F6 is the only quoted teaching sentence. The JD's "coach branch supervisors on escalations" raises the question, so the answer must start from the teller work and say where it stops. |

### C. Case / Strategist (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A member has complained three times about the same charge, and this time they say they are taking it further. You have twenty minutes with the supervisor who will handle it. Walk me through what you do." | CASE | [generic] | Clarify first: what the charge is, who has looked at it, what the member was told, and whether a deadline applies. Objective: a fair answer to the member and a fix that holds. Structure: stop the repeat contact, decide who owns the complaint end to end, check the charge, decide the response, then coach the supervisor on the escalation without taking the case off them. Risks: a member who feels passed between teams, and a fix that only moves the complaint. This is a structure, not a claim about your past. | This is the panel's own case, and the question wording here is a stand-in: the panel's version may differ, but the structure does not. Structure scores over the answer. Escalation coaching is in the JD and Own the Fix is scored, so the case covers both. |
| C2 | "We are moving eight branches into five hubs over 2027. What happens to a member's open complaint when their branch closes?" | CO | [grounded] "consolidate eight branches into five hubs over 2027" (your summary of the brief) | Structure: which complaints are open at the point of change, who owns each one through the move, how the member is told, and what the hub inherits. Name what you do not know: your summary does not say how many members are affected or how the hub plan treats open complaints. Ask them that as a reverse question. Do not speak about any particular branch's future. | A CO question from the brief: the strategy fact most likely to change the complaints workload. The pack asserts no detail of the plan beyond your summary. |
| C3 | "Forty per cent of member service is moving to digital channels by 2028. Which complaints should move with it, and which should not?" | CO | [grounded] "move 40% of member service to digital channels by 2028" (your summary of the brief) | A role-pattern sort, not an Ashgrove fact: complaints a self-service journey can resolve, such as status questions, on one side; disputes, members in difficulty and anything needing judgement on the other. Present the sort as a hypothesis to test with data. Answer slot: if you have sorted complaints by channel before, say how; if not, say you would test the split first. | The digital shift is the company's stated direction, and this question asks for the complaints lens on it. The answer shows judgement at the company's altitude. |

### D. Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how the monthly complaints spreadsheet is built." | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Walk it in the order you built it: what it holds, where the figures come from, and what the regional manager uses it for. Name the assumption behind it that you would defend least, in your own words, before they find it. Answer slot: say which Excel features you used and which decisions were yours; if the regional manager set the layout or the measures, say so. | F5 and F7 rest on this sentence. The question is EXP because it tests what was yours, and the Excel requirement is scored here too. |
| D2 | "Did your spreadsheet report complaint volumes or resolution times?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Answer in the spreadsheet's terms, not the JD's. Answer slot: if it reported volumes or resolution times, say which and how each was counted, in your own words; if it reported neither, say so plainly and say what you would report first each month. | F5 is a presentation gap: the material does not say what the spreadsheet measured. The JD names both measures, so the question is likely, and either honest branch works. |
| D3 | "What rules did the complaints log have to follow, and how did you keep to them?" | JD | [grounded] "I handled the branch's formal complaints log" | The JD raises regulated complaints, so expect this probe. Answer slot: if the log ran to rules or deadlines you were held to, say which and how you tracked them; if the rules were set by someone else, or the log ran to none, say so plainly and say what you did know about the rules. | F2 is a presentation gap: the quote reaches the requirement, but "regulated" is the word the material does not use. This is the probe the JD invites. |

### E. Conversational / Rapport (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through your background." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "I handled the branch's formal complaints log"; "I built the monthly complaints spreadsheet our regional manager uses" | A 90-second arc: six years in retail banking, the last three as a branch supervisor; the complaints log; teller training on the escalation script; the monthly spreadsheet. Close on your two gaps in one sentence: "I haven't worked in a contact centre, and I haven't presented to anyone above regional level." Then stop. | The recruiter's opener is scored as conversation, and it sets the first note the Head of Member Services reads. Naming the gaps first means the Skeptic does not have to find them. |
| E2 | "Why this role, and why now?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | Your reason for moving is not in the material, so the answer is yours to give. Say it in your own words, in two sentences, and tie it to the complaints work. Answer slot: if the reason is the role's scope across branches and the contact centre, say so; if it is something else, say that. Do not connect it to any branch's future. | Motivation is checked at every round. The pack assumes no reason for the move, so the answer has to come from you. |
| E3 | "What do you know about where we are heading?" | CO | [grounded] "move 40% of member service to digital channels by 2028"; "consolidate eight branches into five hubs over 2027"; "launch a small-business lending product in Q1 2027"; "app-only banks" (your summary of the brief) | Name three things in the brief's terms: the digital shift to 2028, the hubs over 2027, and the small-business lending launch in Q1 2027. Then one point on app-only banks as the main competitive pressure. Close with one question back about how the hub plan treats open complaints. Add no figure or date the brief did not give you. | A CO question grounded in the brief. Sounding current is scored here, and the facts are your summary's, so check them against the full brief. |

### F. Pressure / Stress (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "That complaints log: how much of the outcome was actually you?" | EXP | [grounded] "I handled the branch's formal complaints log" | Pause, then restate what the log says you did: you handled it. Hold that through two follow-ups without widening it. Concede the uncertainty you actually have, in your own words, if you cannot separate your part from the team's for every outcome. Then name the part that was yours. | The Pressure persona tests composure and attribution on the one complaints sentence the material holds. The held position is only the quoted one. |
| F2 | "Two of us here run branches. What would you do in your first month that we would not already be doing?" | JD | [generic] | A plan question: name one thing you would do first that depends on their knowledge rather than yours, such as asking which complaints come back and why. Do not claim to know their branches. | The branch managers judge whether a coaching role treats them as the experts. This is also where the Peer persona is touched. |

## Requirement coverage

| JD requirement | Covered by |
|---|---|
| Own the member complaints process end to end across branches | A4, C1 |
| ...and the contact centre | B1, C2 |
| Report monthly on complaint volumes and resolution times | D2 |
| Coach branch supervisors on escalations | B4, C1 |
| Work with digital teams on self-service journeys | B2, C3 |
| 4+ years in financial-services customer operations | E1 |
| Experience handling regulated complaints | D3, F1 |
| Confident presenting to senior leaders | B3 |
| Comfortable with Excel reporting | D1 |

Each of the four values has at least one VAL question: Members First, Always (A1); Plain Words (A2); Neighbours, Not Numbers (A3); Own the Fix (A4).

## Values cheat sheet

The panel scores against these four values, so this section is included.

| Value | Working meaning | Mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | F2, quoted: "I handled the branch's formal complaints log." Selection scaffold: a logged complaint where the member's side changed your call. If none did, say so plainly. |
| Plain Words | If a member needs it explained twice, we wrote it wrong | F6, quoted: "trained new tellers on our escalation script." Selection scaffold: a time the script or the teaching changed after someone needed it twice. If it did not, say what you would change. |
| Neighbours, Not Numbers | Every branch is part of its town | F5, quoted: "I built the monthly complaints spreadsheet our regional manager uses." No sentence carries a story here. Selection scaffold: a time you dealt with a place rather than a figure. If there is none, say so. This is the thinnest value in the pack. |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | F2, quoted: "I handled the branch's formal complaints log." Selection scaffold: a complaint followed to its fix. If the log only recorded them, say so, and name what you did keep hold of. |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "When a branch's open complaints move to a hub, who holds them until they close?" | It names the exact seam the consolidation creates, and shows you have read the brief. |
| 2 | "Where does the monthly complaints report go, and what decision does it feed?" | It treats the report as an instrument, which is the role's core job. |
| 3 | "How is the digital target being measured, and which complaint types are in scope?" | It shows fluency in the 40% goal and asks the question the strategy leaves open. |
| 4 | "What would you need from the branch managers in the first month?" | It is the reciprocity question for the panel, and it lets them name the seam themselves. |
| 5 | "How do supervisors escalate today, and where do they get stuck?" | It tells the Head of Member Services you will start from the coaching problem, not the org chart. |
| 6 | "What would success look like at six months for complaint resolution times?" | It asks for the measure the role will be judged on, in their words. |

## Sources

**Provided documents:**
- The JD text in your message.
- The four values, as copied from ashgrovecu.org/about/values on 11 November 2026.
- The recruiter's description of the three rounds.
- The July 2026 strategy brief, as summarised in your message.
- Your background, in your message.

No dossier was present.

**Research tier:** Research tier: L1, searches 0 of 6, fetches 0 of 2. No search or fetch was sent.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. ashgrovecu.org values | skipped | The four values are pasted in full, which fixes the values cheat sheet |
| 2. Ashgrove interview process, member services | skipped | The recruiter's description fixes the three rounds, their lengths and the content of the case; persona weights follow them |
| 3. Ashgrove strategy and recent news | skipped | The pasted summary of the July 2026 brief fixes the strategy claims in the pack. Anything published after it is not searched; the upgrade menu names it |
| 4. Interviewer name and company | n/a | No interviewer name was given, so there was no query to form |
| 5. Representative Member Experience Lead JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The full July 2026 brief, as a file or pasted → the grounding brief and E3 quote its wording instead of your summary.
- Interviewer names, once the recruiter has them → persona weights for each panel member and reverse questions tuned to each.
- Your complaints log or monthly spreadsheet, shown in anonymised form → F2 and F5 move from medium to high confidence, because each becomes an inspectable artefact.
- Your prep hours before 20 November → a prioritised triage section, with the few things to do first.
- Deep research (L2): the strategy brief's source, interviewers' public talks, loop reports for similar roles, and recent organisation news. Cost: up to 6 further searches and 2 further fetches. Offered once; it runs only on your go-ahead.
- A tuesday-dossier.md from an earlier underwriter review → the verified evidence and prohibited-claims list in place of the locally built ones.
- The recruiter's note on any written or presented task → a build section for it.
