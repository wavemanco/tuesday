Your prep pack is saved as `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-alone-part-2-rooms-case-1-denied-3013246d/1fe01f1e-2980-4fd9-b12e-53604de93195/scratchpad/Northwind_senior-gtm-strategy-lead_interview_pack.md`.

It's built for a peer round, which weights the 19 questions toward a data-driven prober (5), then a peer evaluator (4). The highest-ROI prep is D1: Dan's home turf is sales strategy, and Priya has no quota-setting experience, so expect that probe. The $400M figure (A2, E1) is the next most likely to be pressed.

I ran no searches, since you said you already have everything. A light pass on Dan's public writing and the loop structure would sharpen it; both are in the upgrade menu.

Would you like me to play the Skeptic on D1, the question the pack names as its highest-ROI prep? I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Northwind_senior-gtm-strategy-lead_interview_pack.md -----
# Interview prep pack: Senior GTM Strategy Lead, Emerging Products, Northwind Data

**Interviewer:** Dan Kovac, Director of Sales Strategy. **Relationship:** peer, reporting to the same VP. **Round:** single 60-minute conversation.
**Changelog:** first version.

## 1. How to use this pack

- **Personas** describe how a question arrives (tone, style, pressure). **Types** describe what is being scored.
- **Type key:** VAL = values alignment (not used here, see section 8); EXP = your experience, deep-dive; JD = the role's stated requirements; CO = company and strategy; CASE = a live problem.
- Guidance is scaffolding for a spoken answer, not a script. Each answer should run 90 to 120 seconds.
- **Answer slots** are instructions for the interview, not questions to me. Where a slot says "if you did this, say how; if not, say so," the honest branch is always available to you.
- Question IDs are letter-by-persona (A1, B2 and so on) so the drill and the coaching can refer to them.

## 2. Fit snapshot

Requirements are quoted from the JD highlights you supplied (quotation marks mark exact text). Evidence is quoted from your coach's notes and your research note. Confidence grades your evidence; provenance grades what this pack wrote about it.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" (JD highlights) | "built a partner-level revenue model used in carrier negotiations" (coach's notes) | medium | [grounded] | transferability | Your notes say you built a model. They do not say you owned a GTM strategy. Say it at its own scope: "I built a partner-level revenue model, used in carrier negotiations." Answer slot: if you made any GTM decision for a product line, say which and how you decided; if not, say the work was the model and the negotiations it fed. |
| F2 | "identify whitespace across land/adopt/expand/renew" (JD highlights) | "set annual volume targets with cross-org consensus" (coach's notes) | low | [inferred] | discovery | The quote touches targets, not whitespace, and does not show whether it reaches the requirement. Answer slot: if you ever found where growth was unclaimed, say how you found it; if you did not, say how you would find it across the four motions. Rehearsed as a plan (C3). |
| F3 | "run independent analysis in SQL and Tableau" (JD highlights) | "skilled in SQL/Tableau" (coach's notes) | medium | [grounded] | none | The tools are named in your own terms. No artifact is attached, so expect a probe on an analysis you ran yourself (A3). |
| F4 | "partner-motion design experience required" (JD highlights) | "built a partner-level revenue model used in carrier negotiations" (coach's notes) | medium | [grounded] | transferability | The model is partner-facing work. A partner motion is the incentives, enablement and channel design around partners. Say what the model is. Name a partner motion you designed only if you did. |
| F5 | "strong cross-functional influence" (JD highlights) | "set annual volume targets with cross-org consensus" (coach's notes); "proposed a store-surface change credited with a ~$400M ARR uplift" (coach's notes) | medium | [grounded] | none | The consensus sentence carries cross-org influence; say who was in the room. The store-surface sentence has an attribution limit: "credited with" describes the figure, not your share of it (E1). |
| F6 | "AI experience a plus" (JD highlights) | "uses AI tools daily" (coach's notes) | low | [inferred] | transferability | Use is not building. Say how you use AI tools in your analysis, not that you built AI products. |
| F7 | Quota-setting and sales-plan experience, not in the JD highlights; [generic] for a Sales Strategy peer | "No classic sales-ops or quota-setting experience." (coach's notes) | none | [grounded] | capability | This is a gap your notes state. The words for it are yours to say, not the pack's: "I haven't set quotas," once you agree with it in your own words. The nearest thing your material carries is the volume-target sentence in F2. Then a plan: how you would learn the quota process. |

**Gate rows:** none. The highlights name no eligibility or term gate. If the full JD names one, send it (upgrade menu).

## 3. Prohibited claims

This pack will not coach these claims. The list is built locally from the fit snapshot, and it binds every cell below.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned GTM strategy for a product line | Inflated form of F1 | The model, at its own scope. The material says you built a model, not that you owned the strategy. |
| Set quotas or rep-level targets | Inflated form of the volume-target sentence (F2, F5) | "Annual volume targets with cross-org consensus," as written. Not rep quotas. |
| Designed partner motions | Inflated form of F4 | The model used in carrier negotiations. |
| Built AI products or led AI work | Inflated form of F6 | "Uses AI tools daily," with what you check. |
| Delivered the full ~$400M | Inflated form of "credited with" (F5) | "Proposed" the change; the figure is credited to it. |

## 4. Persona weights

| Persona | How it shows up in this round | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Data-Driven Prober | Every CV number and analysis claim taken to its assumptions | **5 questions (top).** Dan self-describes as "relentlessly data-driven." Relationship prior for a peer puts this persona first. | Know what you can and cannot say about how each number was counted. Name the weakest assumption before he does. |
| Peer Evaluator | Seams with Sales Strategy, disagreement on targets, what the hire does to his load | **4 questions.** Peer is the relationship prior, and you share a VP. | Propose seam principles, not a map. Reciprocity: say what you bring his team. |
| Case / Strategist | Live problems: Compass sizing, a bundling threat, whitespace | **3 questions.** Pricing and monetization is his career spine, so the case angles tilt to packaging and unit economics. | Clarify, objective, segmentation across land/adopt/expand/renew, approach, metrics, risks. Name profitability as a constraint. |
| Skeptic | Weakest area on day one; the partner-motion mismatch; why leave consumer tech | **3 questions.** Quota-setting (F7) is the gap a sales-strategy peer is most likely to press. | Rehearse the predictable objection until it is plain. Name the gap before he does. |
| Pressure / Stress | Attribution of the $400M; a 60-second "why you" | **2 questions.** Low for a peer, but a data-driven peer can challenge a headline figure. | Hold the proposal; concede the figure's shared credit, not your part. |
| Conversational / Rapport | Opener and casual AI question | **2 questions.** Casual is still scored. | Pre-scripted 90-second arc. Treat the AI question as a JD question. |
| Values / Behavioral | Not weighted (0) | No values round is detected and no company values are in hand. | Not in this pack. |

## 5. Reading the interviewer

Public footprint only: the self-description and career pattern you supplied. Nothing else was researched.

- **Career pattern:** pricing and monetization, plus one early-stage startup chapter, now in sales strategy. Expect monetization vocabulary: revenue model, pricing, packaging, unit economics.
- **Self-described style:** "relentlessly data-driven." Every number will be probed for its inputs and denominator.
- **Implications:** (1) expect A-bank probes on every figure; (2) answer case questions in pricing terms first; (3) the startup chapter may bring a pace or scrappiness probe, so give one concrete example of working at speed in a large company, from your own material, or say plainly that you want to test the pace question.
- **Mirror opportunities:** shared vocabulary only. The "revenue model" in F4 uses his language. **No shared career jump:** his pricing-to-sales-strategy path and your consulting-to-consumer-product path are not similar, so do not offer one.

## 6. Question banks

### Bank A: Data-Driven Prober (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through the annual volume targets you set. How did you arrive at the number?" | EXP | [grounded] "set annual volume targets with cross-org consensus" | Say the target's scope and the consensus, in those words. Answer slot: how the number was built, what it is most sensitive to, the assumption you would defend least, and which part was yours. If you proposed a number that others then changed, say that. | The nearest thing to a quota probe that your material carries (F2, F7). EXP because it tests what was yours. Makes no quota claim. |
| A2 | "That ~$400M ARR uplift. How was it counted, and what is it most sensitive to?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Story-mapped on F5: you proposed the change, and the figure is credited to it. Answer slots, in your own words: how it was counted (if you do not know, say so), what it is sensitive to, the assumption you would defend least, and your part. Name the weakest assumption before he does. | Headline metric on the CV. This is the defend-the-number rule: the pack supplies no counting method. |
| A3 | "Tell me about an analysis you ran yourself in SQL or Tableau. What question did it answer?" | JD | [grounded] "skilled in SQL/Tableau" | Open prompt, from the JD's "run independent analysis." Selection scaffold, since the quote carries the skill and no analysis: pick one where you wrote the query or built the view; name the question, the data, and what the answer changed. Answer slot: if the work was mostly someone else's, or you did not produce the analysis yourself, say so and describe the nearest one you did. Hold through follow-ups on which table and what you would check first. | The JD's analysis requirement is the one with no artifact (F3), so it is probed. |
| A4 | "The partner-level revenue model you built for carrier negotiations. What went into it, and where was it most sensitive?" | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" | Story: the model, and the negotiations it was used in. Answer slot: the inputs, the assumption the output was most sensitive to, the assumption you would defend least, and which part was yours. If others built it with you, name them. | The strongest CV item for the partner requirement (F4). A model is exactly what a prober takes apart, so the weakest-assumption move comes first. |
| A5 | "Which AI tool changed how you work, and how do you check what it gives you?" | JD | [grounded] "uses AI tools daily" | Name the tools and one concrete use. Answer slot: the check you run on output. If you verify against data, say how; if you do not, say so and say what you would check. Do not describe AI products or launches. | The JD's "AI experience a plus" (F6, low confidence). Verification is what a prober tests. |

### Bank B: Peer Evaluator (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our teams sit side by side. Where's the seam between GTM strategy and Sales Strategy, and what happens when we disagree?" | JD | [grounded] "set annual volume targets with cross-org consensus" | Propose seam principles rather than a map: which decisions start in sales strategy, which start in GTM strategy, and who decides when they collide. Do not pretend to know his team's process. Answer slot: if you disagreed with an equal over a target, describe how it ended and what you would keep; if consensus came without a fight, say so plainly. End with what you would bring his team. | The peer's probe on cross-functional influence (F5). Its collegial form. |
| B2 | "When two teams want different targets for the same product line, who wins, and how do you decide?" | JD | [grounded] "set annual volume targets with cross-org consensus" | Principle first: the decision's owner, and the evidence on the table. Then an example. Answer slot: if a target you proposed changed, say what changed it and whether that was you; if none changed, say that and describe what you did instead. | Tests disagreement style with equals (F5). |
| B3 | "What would you need from my team in the first ninety days?" | JD | [generic] | Name two concrete inputs (the decisions his team makes, and the data it owns) and one thing you would bring his team. Do not invent a relationship. | Reciprocity: the peer's load question, which also covers first-month contribution. |
| B4 | "How would you split the Compass launch work with my team?" | CO | [grounded] "AI copilot launch ('Compass')" (your research note) | Propose a split by decision, not by function, and say it is a proposal. Make no claim about your past. | Compass is a stated company priority. A peer probes how GTM strategy lands on his plate. |

### Bank C: Case / Strategist (weight 3, pricing tilt)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "We're launching Compass. Sketch how you'd size its go-to-market for the enterprise base. What do you need to know first?" | CASE | [grounded] "enterprise expansion"; "AI copilot launch ('Compass')"; "reaching profitability" (your research note) | Clarify, objective, segmentation across land, adopt, expand and renew, approach, metrics, risks. Tilt to packaging: is Compass an add-on or bundled? That is his native question. Name profitability as a constraint and challenge one premise. | Company priority question, with the pricing angle his career invites. |
| C2 | "A much larger platform vendor starts bundling a comparable capability into its suite. What happens to our enterprise renewals in the next two quarters?" | CO | [grounded] "bundling by a much larger platform vendor" (your research note) | Structure: which renewals are exposed (segment them), what the bundle changes in price perception, what you would watch in the first two weeks, and packaging responses as options with trade-offs. No claim about your past. | The main competitive threat in your research note. A pricing-literate peer will press the renewal math. |
| C3 | "Where's the whitespace across land, adopt, expand and renew for a new product line, and how would you find it in the first thirty days?" | JD | [grounded] "identify whitespace across land/adopt/expand/renew" | Structure: the data you would pull (your SQL and Tableau path), the segments, the motion where the gap looks largest, and two sources to validate it. Make no claim that you have found whitespace before. | The JD's requirement with no evidence behind it (F2). Rehearsed as a plan, which is the honest form. |

### Bank D: Skeptic (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Which part of this role would you be weakest at on day one, and what would you do about it in the first sixty days?" | JD | [grounded] "No classic sales-ops or quota-setting experience." (coach's notes) | **Highest-ROI prep in this pack.** Name the gap before he does, in your own words. If you agree with your notes, say: "I haven't set quotas." That line is a plain acknowledgment only once you say it. Then the nearest thing your material carries: "set annual volume targets with cross-org consensus," not rep quotas. Then the ramp plan: sit in on a quota cycle with his team and learn how the number is built. Hold through two follow-ups by returning to the ramp plan. Concession: "I haven't owned quota-setting. Here's how I'd close it." | Sales Strategy is his home turf, so quota is the likely probe. The gap is the one F7 states, and the objection is aimed where the material is thinnest. |
| D2 | "Partner-motion design is required here. What's the difference between a partner-level revenue model and a partner motion, and which have you built?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | Name the model and what it fed (the negotiations). Say a partner motion is the incentives, enablement and channel design around partners. Answer slot: if you designed any partner-facing incentive, enablement or channel element, say what it was and your part; if not, say the model is what you built, and describe how you would design a motion. Never call the model a motion. | The JD says "required," and F4 is transferability. A data-driven peer will catch the model-versus-motion blur, so the distinction goes first. |
| D3 | "Why leave a consumer-tech company for B2B data infrastructure, and why now?" | JD | [grounded] "9 at a large consumer-tech company in product strategy & ops" | Motivation from your through-line: product strategy and ops, and the revenue model. Say what the B2B work offers in terms of the work itself. Avoid "more stable" or "faster" unless you can say why. If he tests big-company pace (his startup chapter), answer with one concrete example from your own material. | A motivation probe. The startup chapter makes a pace probe likely. |

### Bank E: Pressure / Stress (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "That $400M. How much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Hold: "I proposed it. The figure is credited to the change, and here is my part." Concede: "The number is shared, and I can't claim all of it." Concede the figure, not the proposal. Answer slot: your part, in your words. Hold through two follow-ups. | The attribution limit (F5) is the deepest risk on the CV, and this probe exists to catch inflation. |
| E2 | "Sixty seconds: why you over someone who has run a GTM plan for a B2B product line?" | JD | [grounded] "own GTM strategy for two new product lines" (JD highlights); "built a partner-level revenue model used in carrier negotiations" (coach's notes) | Anchor in the model and its use in negotiations. Hold that through the first follow-up. Concede the gap on the second: you have not owned a GTM plan for a B2B product line, in your own words. | Pressure on the headline requirement (F1). |

### Bank F: Conversational / Rapport (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm"; "9 at a large consumer-tech company in product strategy & ops"; "built a partner-level revenue model used in carrier negotiations" | A 90-second arc: consulting, then consumer tech, then the model. Do not add a role or a number. | A casual opener that is still scored. Pre-scripted, so it does not wander. |
| F2 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" | Name two tools and one workflow. Say what you check, using A5's answer. Do not overclaim. | The JD's AI plus, asked casually (F6). |

## 7. Requirement coverage

| JD requirement | Question IDs | Note |
|---|---|---|
| own GTM strategy for two new product lines | C1, D1, E2 | |
| identify whitespace across land/adopt/expand/renew | C3 | Rehearsed as a plan (F2) |
| run independent analysis in SQL and Tableau | A3 | |
| partner-motion design experience required | A4, D2 | |
| strong cross-functional influence | B1, B2, A1 | |
| AI experience a plus | A5, F2 | |

Headline metrics: $400M ARR (A2, E1). Volume targets (A1). Carrier model (A4).

## 8. Values / principles cheat sheet

Not included. No values-style round is detected and no company values are in hand.

## 9. Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "You moved from pricing and monetization into sales strategy. What did that change about how you decide a target?" | Ties to his own path. It turns an interview into a peer conversation. |
| R2 | "What did the early-stage chapter teach you about pace inside a company this size?" | Ties to his path, and gives him a reason to talk about his own work. |
| R3 | "Where does Sales Strategy own a decision the new product lines would need, and where would you want GTM strategy in the room?" | Shows you have thought about the seam. |
| R4 | "How will Compass be measured against enterprise expansion this year?" | Shows you have read the company's priorities. |
| R5 | "How does the team watch bundling exposure today?" | Shows you have read the main threat. |
| R6 | "What could a new person do in their first month that would genuinely help your team?" | Reciprocity, as a peer. |

## 10. Prep priorities

No prep time was given, so there is no schedule. The highest-value items, in order: D1 (quota gap), A2 and E1 (the $400M), A1 and A4 (the two number-bearing stories), C2 (renewal math).

## 11. Sources

**Provided documents:** your coach's notes (the candidate summary); the JD highlights; the interviewer's self-description and career summary; your research note (three priorities and the bundling threat).

**Research tier:** L0. No searches or fetches were run, because you said you have everything needed.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Northwind Data values` | unavailable | Section 8 values cheat sheet, only if a values round is detected |
| 2. `Northwind Data interview process, Senior GTM` | unavailable | Loop structure and persona weights |
| 3. `Northwind Data strategy` / recent news | skipped | Your research note already supplies priorities and the bundling threat |
| 4. `Dan Kovac Northwind Data` | unavailable | Interviewer's public writing; a tailored reverse question and persona weights |
| 5. Representative `Senior GTM Strategy Lead` JD | skipped | The JD highlights you supplied fix the fit snapshot |

## 12. Upgrade menu

- The full JD text → the six JD requirements become exact `[grounded]` quotes, and any gate rows (location, work authorization) become visible.
- Your own words on "no quota-setting" (F7) → D1 and E2 can use a plain acknowledgment in place of an answer slot.
- Your account of the $400M, in your own words → A2 and E1 get a stronger answer slot. Anything you state becomes quoted material.
- A light research pass on Dan Kovac's public talks and writing → persona weights read from his writing, and a tailored reverse question.
- Deeper research on the loop and strategy, up to 6 searches and 2 fetches → loop structure and a strategy brief for C1 and C2.
- A recruiter email on the round's focus → coverage of any deliverable they name.
- A `tuesday-dossier.md` from the underwriter → verified evidence and a named objection to rehearse, in place of the one inferred here.
