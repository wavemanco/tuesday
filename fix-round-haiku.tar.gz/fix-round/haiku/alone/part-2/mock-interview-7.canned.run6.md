Your prep pack is saved as /tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-alone-part-2-rooms-case-7-canned-48feaf92/8c9a6277-4b46-4a32-8c74-3ca227566a17/scratchpad/saltmarsh_live-operations-producer_interview_pack.md.

Three things from the research shape the pack:

- **The interview is one 60-minute session.** Saltmarsh's careers page describes it as a live-incident tabletop on a simulated outage during a live event, then a values conversation. I weighted the pack toward that tabletop (questions A1 to A5).
- **Project Larkspur changes the job.** Per a September 2026 news item, both your titles move to a season-pass model and one shared events calendar from February 2027, and the per-title event teams are retired. I only saw the search snippet, so check it before quoting it.
- **Your biggest gap is coordinating design, art, engineering and community.** Nothing in your background covers it, so C1 is the question to rehearse hardest. Your in-app purchase gap is the likely probe on Larkspur's season pass (C3).

Tobias Wrenfield's GDC 2026 talk, "Patch Notes Are a Promise," is also relevant: he was a QA lead before live ops, so your checklist work is your strongest link to him. I only saw a search snippet of it, so don't cite it unless you've read it yourself.

I didn't need to ask anything before building the pack, so there are no open questions.

Offers, neither pushed:
- **Drill:** I can play the Skeptic on C1, the highest-return question in the pack.
- **Dossier:** I can save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions.
- **Word:** say so and I'll convert the pack to .docx.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh_live-operations-producer_interview_pack.md -----
# Interview prep pack: Live Operations Producer, Saltmarsh Games

**Candidate:** Femi
**Role:** Live Operations Producer, Saltmarsh Games (mobile, about 350 people)
**Interviewer:** Tobias Wrenfield, Head of Live Operations. Relationship: hiring manager. The company's interviewing page says the single 60-minute session, the Outage Hour, is run by the hiring manager.
**Format:** One 60-minute session: a live-incident tabletop on a simulated outage during a live event, then a values conversation. No take-home.

---

## How to use this pack

- **Personas** describe how a question is asked. **Types** describe what is being scored: VAL (values), EXP (your past work), JD (the job's stated requirements), CO (company knowledge), CASE (a live problem).
- Guidance is scaffolding, not a script. Say it in your own words. Answer slots are instructions for the interview, not questions to me.
- Provenance: [grounded] means traceable to the JD, your message, or a company page; [inferred] means derived from one of those with the derivation named; [generic] means a pattern for the role, with no claim about this company or about you.

---

## The fit snapshot

Requirement text is quoted from the JD you pasted. Evidence is quoted from your message. Nothing outside those two is treated as your experience.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | medium | [grounded] | transferability | Your material shows one main title and a content-drop calendar, not two titles or live events. Bridge in the quote's terms: "For two years I ran the weekly content-drop calendar for our main title." Answer slot: if you have planned across more than one title or run events, say which and how; if not, say so plainly and say how you would run two calendars. |
| F2 | "coordinate design, art, engineering and community teams on each update" (JD) | none given | none | [grounded] | discovery | Nothing in the material shows this. Answer slot: if you coordinated any of those four teams on an update, say which, how, and what you decided; if you did not, say so plainly and describe how you would set up the handoffs. This is the largest gap in the pack. See C1. |
| F3 | "own the post-event review and the KPIs it reports" (JD) | "Presented the monthly retention numbers to the studio head" (your message) | medium | [grounded] | transferability | Reporting retention is adjacent to owning a post-event review, and the bridge should not stretch it: "I presented the monthly retention numbers to the studio head." Answer slot: if you chose which numbers went in or how they were counted, say so; if not, say whose they were and what you did with them. |
| F4 | "manage the release checklist with QA" (JD) | "Wrote the release checklist our QA team still uses" (your message) | medium | [grounded] | presentation | The quote reaches the requirement in other terms. Bridge only with the quote's verbs: "I wrote the release checklist our QA team still uses." Do not turn "wrote" into "managed". Answer slot: if you ran the checklist with QA beyond writing it, say what you did in a release; if not, stay with what you wrote. |
| F5 | "3+ years producing live-service games or apps" (JD) | "4 years as an associate producer at a puzzle-game studio" (your message) | medium | [grounded] | discovery | The years are shown; whether the puzzle title was live-service is not. Answer slot: say whether the title was updated on a schedule after launch. If it was, give the cadence; if not, say so and point to any live-service work you did. See C4. |
| F6 | "experience running a content calendar" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | medium | [grounded] | none | The quote reaches the requirement. Expect a probe on how the calendar was run and what artifact shows it. |
| F7 | "comfortable with player-retention metrics" (JD) | "Presented the monthly retention numbers to the studio head" (your message) | medium | [grounded] | none | The quote reaches the requirement. The figure's method is not in the material, so expect the defend-the-number probes in D1 and D2. |
| F8 | "clear written communication" (JD) | none given | none | [grounded] | discovery | No written work is shown in the material. Answer slot: name one piece of written work, such as the checklist or the retention presentation, and say what it was for. |

Gate check: no requirement in the JD is a gate in the sense the suite defines (a legal, credential, location, schedule or pay term). "3+ years" is graded like any other requirement, so no row is `hard_gate`.

---

## Reading the interviewer

Public footprint only, from search results. I did not open the talk page; the content below is from its search snippet.

- **Career pattern:** Head of Live Operations at Saltmarsh Games. Previously a QA lead at a console studio (talk bio, search result).
- **Self-described thesis:** His GDC 2026 talk, "Patch Notes Are a Promise", argues that a live team is judged by how often its patch notes describe what actually shipped (search result).

**Practical implications**

1. QA is his home ground. Your strongest sentence for him is the one about the checklist: "Wrote the release checklist our QA team still uses" (your message). Lead with it when QA comes up.
2. Expect the patch-note-versus-QA scenario (A5) in his register. It is his thesis turned into a question.
3. Only cite his talk in the room if you have read it yourself. The pack has only the snippet, and the link returned by search should be checked before you rely on it.
4. Shared professional ground is QA, not identity. Build on the quoted checklist sentence, not on any personal connection.

---

## Persona table

| Persona | How it shows up | Weight, with reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | The Outage Hour tabletop on a live-event incident, then a plan question on two titles | 5. The interviewing page makes the tabletop the core of the session. This is the heaviest persona. | Clarify, decide, then say what you would record. Name your first two calls before the details. |
| Values / Behavioral | The values conversation after the tabletop, using the three named values | 4. The page places a values conversation in the same session. | Map stories only to quoted sentences. Where none carries a story, use the scaffold and say the honest branch. |
| Skeptic | Quiet probing of the gaps: coordination across teams, two titles, in-app purchases, leadership | 4. Hiring-manager prior, with fit gaps F1, F2 and F5, and the in-app purchase and leadership negatives you stated. | Rehearse C1 until it is plain. Name limits before they are asked for. |
| Data-Driven Prober | Asks how the retention figure was counted and which assumption is weakest | 3. Retention is the one metric the material shows, and the JD asks for KPIs. | Name the weakest assumption before the interviewer does. |
| Conversational | A 90-second biography, or a casual question about a live title | 2. The opening question is scored; the risk is the friendly register. | Use the pre-scripted arc in E1, built only from your quoted sentences. |
| Pressure | Holds a challenged position on leadership or on scale | 2. Plausible for a hiring manager; often time-boxed. | Hold through two follow-ups. Concede one specific limit, never the core claim. |

---

## Question banks

Question IDs are letter by persona. Weights: Case 5, Values 4, Skeptic 4, Prober 3, Conversational 2, Pressure 2. Total: 19.

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A live event is running. A reward patch went out 40 minutes ago, and players report that rewards are granting twice. Walk me through the first 30 minutes." | CASE | [inferred] the company's Outage Hour page: "a live-incident tabletop on a simulated outage during a live event" (saltmarshgames.com/careers/interviewing). The scenario is this pack's own. | No claim about your past. Order: say what you know and what you do not; decide whether the reward stops or the event pauses, and who signs that off; name who you pull in first, in order (engineering on call, QA, community); decide what players are told and when; say what you record and who receives it. Speakable in about 90 seconds, then take follow-ups. | This is the format the company describes. It also covers the written record, which is where clear written communication shows up. The scenario is generic, so do not treat it as the interviewer's real incident. |
| A2 | "The reward economy was tuned for two weeks of play, and players hit the cap on day three. What do you change, and what do you tell the community?" | CASE | [generic] | Diagnose before changing: which assumption about pace broke, and what data you would need first. Then the options, each with its cost: pull the reward, slow it, or accept it. Then a community message that says what is built and what is not, without promising a fix date. No claim about past work. | Live-event tuning is central to the calendar job. The tabletop rewards structure over a right answer. [generic] because it is a pattern, not a fact about this studio. |
| A3 | "Two titles, one calendar, and both titles have a launch in the same month. Build the first two weeks of the calendar: what do you lock first?" | JD | [grounded] JD line: "Plan and run the live-events calendar for two of our mobile titles" | Order out loud: lock the dates players can see and the dates QA needs. Treat shared engineering and art capacity as the constraint. Name one thing you would cut and why. No claim about past work. | Covers the calendar requirement for two titles, which the material does not show (F1). Because it asks for a plan, the answer cannot overstate experience. |
| A4 | "Project Larkspur puts both titles on one shared events calendar from February 2027 and retires the per-title event teams. What would you protect in the first 90 days, and what would you give up?" | CO | [grounded] "moves Tidepool Tactics and Lantern Row to a season-pass model with one shared events calendar from February 2027" (saltmarshgames.com/news/project-larkspur, search result, not opened) | Protect the player-facing rhythm of each title and the QA gate. Give up one thing you would defer, with the reason. Say who should hold the shared calendar and why. One thesis, with its risk named. No claim about past work. | The differentiator question. Most candidates will not have read this news. Verify the page before quoting it in the room. |
| A5 | "A patch note says the fix went live. QA says it did not. Who do you believe, and what do you do in the next hour?" | CASE | [inferred] the company's published value: "we announce what is built, not what is hoped" (saltmarshgames.com/values, opened), and the interviewer's public thesis (see Reading the interviewer) | Verify against the build, not the report. Hold the note or correct it publicly. Name who must approve the correction. State the principle in one line: announce what is built. No claim about past work. | The interviewer's own theme, drawn from the company's published values. It is his question, and the guidance does not assume his views. |

### B. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time the calendar and the players disagreed. Which one won?" | VAL | [grounded] "Players Before Plans: when the calendar and the players disagree, the players win" (saltmarshgames.com/values, opened). Nearest sentence from your message: "I ran the weekly content-drop calendar for our main title for the last two years" | Selection scaffold: pick a drop date that held against player feedback, or feedback that moved a drop. Name the stake, what you moved, and who you asked. Honest branch: if no such time comes to mind, say so plainly, then give the nearest thing the calendar carries: the weekly rhythm you kept for two years, and how you decided its timing. | An open prompt on the company's first value. The quoted sentence is the nearest one you have; it is not a story, and the guidance does not make it one. |
| B2 | "Tell me about a release checklist you changed after something got past it." | VAL | [grounded] "Leave the Build Greener: every release leaves the codebase and the checklist better than it found them" (saltmarshgames.com/values, opened). "Wrote the release checklist our QA team still uses" (your message) | Mapped on F4: you wrote the checklist, and QA still uses it. Those are the beats the quote states. Answer slot: if you changed the checklist after a miss, say what got past it and what you changed; if you did not change it after a miss, or no miss came up, say so plainly and name the one check you would add now. | The checklist is your strongest sentence, and the company's third value names checklists directly. The change-after-a-miss step is not in the quote, so it is a slot. |
| B3 | "Tell me about a time you had to announce a date or a feature before it was built." | VAL | [grounded] "Ship the Patch Not the Promise: we announce what is built, not what is hoped" (saltmarshgames.com/values, opened) | Selection scaffold: pick a time you announced something ahead of the build, or held an announcement back until it was built. Name the stake and the hard truth you told. Honest branch: if you never announced anything ahead of a build, say so, then describe how you would word a note under "built, not hoped". | Open prompt on the company's second value, which is also the interviewer's public theme. No candidate sentence carries a story here, so the guidance is a scaffold. |

### C. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you had to get design, art, engineering or community moving on the same update." | JD | [grounded] JD line: "coordinate design, art, engineering and community teams on each update" | Answer slot. No quoted sentence carries it. If you coordinated any of those four teams on an update, say which teams, what the handoff was, and what you decided, in your own words. If you did not, say so plainly, then describe how you would set up the handoffs on a two-title calendar. Hold through the first follow-up by returning to a handoff you can describe. Concede only what is true, in your own words, and never name a team you did not work with. | The highest-return prep in this pack. F2 has no quote at all, and the JD names this as the job's daily work. Interviewers ask it in some form; a rehearsed honest limit beats an improvised story. |
| C2 | "You ran the calendar for your main title. This job runs the calendar for two. What is the difference you would have to learn?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" (your message); JD line: "Plan and run the live-events calendar for two of our mobile titles" | Story-map from F1, using the quote's beats: the calendar, the main title, two years. Answer slot: if you have planned across more than one title, say how; if not, say so plainly and name what you would check first on the second title. Do not say you have run two. | F1 is a transferability gap, and this is the probe it invites. The question presupposes "main title", which the quote carries, and does not presuppose two titles. |
| C3 | "Both titles move to a season-pass model next year. You have never worked on a game with in-app purchases. What do you bring to that?" | JD | [grounded] "moves Tidepool Tactics and Lantern Row to a season-pass model" (Project Larkspur, search result); "Never worked on a game with in-app purchases" (your message) | Plain acknowledgment, from your own negative: "I haven't worked on a game with in-app purchases." Then name the parts of your work a season pass would touch, in the quoted terms: the calendar you ran and the retention numbers you presented. Say what you would check first. Do not describe purchase economics. | In-app purchases are not a JD requirement. They are a gap you stated, and the company news makes them the likely probe. The acknowledgment is your own negative, so it can be said aloud. The link to a season pass is an inference, and it is labelled as one. |
| C4 | "Four years at a puzzle studio. Why should anyone count that as live-service experience?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio" (your message); JD line: "3+ years producing live-service games or apps" | Answer slot: say whether the puzzle title was live-service, meaning updated on a schedule after launch. If it was, give the cadence and what you shipped on it. If it was not, say so plainly and point to any live-service work you did. Do not offer the years as the answer. | F5 is a discovery gap: the years are shown, and the live-service nature is not. This question tests whether the years are being used as proof. |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how the retention numbers you presented were counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head" (your message) | Defend-the-number slots: how the figure was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. Answer slot: if you did this step, say how, in your own words; if you did not choose the method, say so plainly and say whose it was. | F7 and F3 rest on this sentence. The figure is not in the material, so nothing about its method is supplied. |
| D2 | "Which retention number you presented would you distrust most, and why?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" (your message) | Weakest-assumption move: name the assumption behind the figure you would defend least, before the interviewer does. Answer slot: if you can name one, say it in your own words; if you cannot, say so plainly. | Turns a gotcha into a credibility gain. The sentence's scope is kept: monthly retention numbers, presented. |
| D3 | "You would own the post-event review and the KPIs it reports. Which KPI would you report first after a live event, and what would make you distrust it?" | JD | [grounded] "own the post-event review and the KPIs it reports" (JD) | Plan, not past. Pick one KPI you could defend from a live event, name its weakest assumption, and say what you would check against it before reporting. No claim about past work. | Covers the post-event review requirement, which no quote in the material reaches. The answer is a plan, and the guidance keeps it one. |

### E. Conversational / Rapport

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey, from the puzzle studio to here." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio"; "I ran the weekly content-drop calendar for our main title for the last two years"; "Wrote the release checklist our QA team still uses"; "Presented the monthly retention numbers to the studio head" (your message) | A 90-second arc using only the quoted beats, in order: four years as an associate producer; two years running the weekly content-drop calendar for the main title; wrote the release checklist QA still uses; presented monthly retention numbers to the studio head; why this role, with two titles and one calendar. Use your own words. | Casual register, but scored. Every beat is one of your sentences. |
| E2 | "What are you playing right now, and what would you change in it?" | CO | [generic] | Name a live-service game you actually play and one update you watched closely. Say what you would change and why. If you have played Tidepool Tactics or Lantern Row, say so; if not, say that, and name the nearest genre you have played. Do not claim familiarity you do not have. | A hot topic in a friendly register. [generic] because the right answer depends on what you play, which the material does not show. |

### P. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Sixty seconds: why should we give a two-title calendar to someone who has never led a team?" | JD | [grounded] "Never led a team" (your message). Plain acknowledgment: "I haven't led a team." | Hold: say "I haven't led a team," then the calendar and checklist work in the quoted terms. Hold through two follow-ups by returning to what you ran, not by adding to it. Concede one specific: name what leading a team would require that you have not yet done. | The likely pressure line: leadership is what a single live-ops group implies. The position held is your own negative, so the hold is one you can back. |
| P2 | "This is one live-ops group running four teams. Your strongest sentence is a checklist. Why would that scale?" | JD | [grounded] "Wrote the release checklist our QA team still uses" (your message); "a single live-ops group" (Project Larkspur, search result) | Hold on the quote: the checklist is what QA still uses, and say so. Follow-up: the coordination across four teams is the part your material does not show; name it in your own words and describe the first thing you would do. Concede the limit; do not extend the checklist to a team you did not run. | Pressure on scale. The quote holds the position, and the limit is named before it is asked for. |

---

## Requirement coverage

| JD requirement | Question IDs |
|---|---|
| Plan and run the live-events calendar for two of our mobile titles | A3, A4, C2 |
| Coordinate design, art, engineering and community teams on each update | C1, A1, P2 |
| Own the post-event review and the KPIs it reports | D3, D1, D2 |
| Manage the release checklist with QA | B2, E1, P2 |
| 3+ years producing live-service games or apps | C4 |
| Experience running a content calendar | C2, E1 |
| Comfortable with player-retention metrics | D1, D2, E1 |
| Clear written communication | A1 (the written record in the tabletop) |

---

## Values cheat sheet

The values conversation follows the tabletop in this session, so this section applies. Official value names are from the company's values page.

| Value (official name) | Working meaning | Mapped story |
|---|---|---|
| Players Before Plans | When the calendar and the players disagree, the players win | No quoted sentence carries a story. Scaffold: B1. The nearest sentence is F6's "I ran the weekly content-drop calendar for our main title for the last two years". Honest branch: if no such time comes to mind, say so, then give that nearest thing. |
| Ship the Patch Not the Promise | Announce what is built, not what is hoped | No quoted sentence carries a story. Scaffold: B3. The nearest sentence is F4's "Wrote the release checklist our QA team still uses". Honest branch as in B3. |
| Leave the Build Greener | Every release leaves the codebase and the checklist better than it found them | Mapped to F4 only for what is quoted: you wrote the checklist. The change-after-a-miss step is an answer slot (B2), with its honest branch. |

---

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Larkspur retires the per-title event teams for one live-ops group. Which calendar decisions would sit with this role, and which with the group?" | Shows you read the news, and asks for the scope that matters most to you. |
| R2 | "When a patch note and QA's report disagree, who decides what goes out, and how often has that come up?" | Asks about the thesis behind his talk, in the job's own terms. |
| R3 | "You came to live ops from QA. What do you still check yourself on a patch that a producer usually would not?" | Ties to his own path. It turns a motivation probe into a conversation between two people who know the work. |
| R4 | "What did the last post-event review change in the calendar, and who wrote it?" | Tests whether KPI ownership is real or nominal. |
| R5 | "What would make this hire a clear success at 90 days?" | The standard question, asked with the detail that suits this interviewer. |
| R6 | "How does the season-pass move change what a producer on this team measures in its first quarter?" | Turns the in-app purchase gap into a question about the job. |

---

## Prohibited claims

Each entry names its basis and its honest form. Sourced entries come from your own negatives. Inflated-form entries come from widening a sentence you did say.

| Not coached | Basis | Honest form |
|---|---|---|
| Led a team | Negative you stated: "Never led a team" (your message) | Plain acknowledgment: "I haven't led a team." See P1 for the hold. |
| Worked on in-app purchase economics | Negative you stated: "Never worked on a game with in-app purchases" (your message) | Plain acknowledgment: "I haven't worked on a game with in-app purchases." See C3. |
| Owned the release process with QA | Inflated form of F4, "Wrote the release checklist our QA team still uses" | F4's quote at its own scope. The limit is the pack's observation, not words for you: the material says the checklist, not the release process. B2 and the F4 slot stay inside what was written. |
| Ran the live-events calendar for two titles | Inflated form of F1, "I ran the weekly content-drop calendar for our main title for the last two years" | F1's quote at its own scope: one main title, a content-drop calendar. C2's slot asks only what you planned across titles, if anything. |
| Owned the post-event review and its KPIs | Inflated form of F3, "Presented the monthly retention numbers to the studio head" | F3's quote at its own scope. D1's slot asks whether you chose the method, and if not, whose it was. |

---

## Sources

**Provided documents:** the JD text you pasted; your background message.

**Searches and fetches, with what came back**

1. Search "Saltmarsh Games values": saltmarshgames.com/values, returned. Fetched and opened.
2. Search "Saltmarsh Games mobile studio live operations interview process": saltmarshgames.com/careers/interviewing, returned. Fetched and opened.
3. Search "Saltmarsh Games strategy 2026 news": saltmarshgames.com/news/project-larkspur, returned. Search snippet only; not opened.
4. Search "Tobias Wrenfield Saltmarsh Games Head of Live Operations": a GDC 2026 talk page, returned. Search snippet only; not opened. The link returned should be checked before you rely on it.

**Research tier: L1 — searches 4 of 6, fetches 2 of 2**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | yes | Values cheat sheet and B1 to B3, A5, R2. The three value names come from the opened page. |
| 2. `Saltmarsh Games interview process live operations` | yes | The loop: one 60-minute Outage Hour with the hiring manager, a tabletop and then a values conversation. Persona weights and A1 follow it. |
| 3. `Saltmarsh Games strategy` / recent news | yes | Project Larkspur, September 2026. Moved A4, C3, P2, R1 and R6. |
| 4. `{interviewer name} {company}` | yes | GDC 2026 talk snippet and career line. Moved the interviewer read, A5 and R2 to R3. Snippet only. |
| 5. representative JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions. |

Un-numbered calls: none.

---

## Upgrade menu

- Your CV or resume → F1 to F7 move from quotes in your message to inspectable evidence, and the medium bands get a named artifact to check.
- The full text of Tobias Wrenfield's talk, opened or pasted → the interviewer read uses his argument rather than a search snippet.
- Whether you have played Tidepool Tactics or Lantern Row → E2 and A4 become specific.
- The retention figure you presented, with what it counted → D1 changes from an answer slot to a defended figure, if you are comfortable sharing it.
- The checklist document, or the retention presentation → F4 and F8 gain an artifact you can point to.
- A deeper research pass (L2): a strategy brief on Saltmarsh's financials and the effect of Project Larkspur, Tobias Wrenfield's other talks and writing, role-family loop reports, and recent organisational news. It is up to 6 more searches and 2 more fetches, several more minutes. Want it?
