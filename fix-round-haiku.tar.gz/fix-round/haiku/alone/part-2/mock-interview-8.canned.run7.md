Your prep pack is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-alone-part-2-rooms-case-8-canned-9de9512e/90215622-7bc9-4699-b3d9-b0e3cbe8dac0/scratchpad/ashgrove_member_experience_lead_interview_pack.md`. The full text is below.

# Interview pack: Member Experience Lead, Ashgrove Credit Union

**Candidate:** Dara
**Company:** Ashgrove Credit Union (member-owned, about 900 staff)
**Built on:** the job description, the values page (copied 11 November 2026), the recruiter's email, the July 2026 strategy brief as described to me, and your background. No web research was run (tier L0).

**Rounds, 20 November 2026**

1. Recruiter, 30 minutes: screen, logistics, motivation.
2. Head of Member Services, 45 minutes, mostly behavioural. This is your future manager.
3. Panel of two branch managers, 60 minutes. Includes a 20-minute complaint-escalation case. The panel scores against the four values. Panel names are not yet known.

## 1. How to use this pack

- **Personas** describe how a question is asked. **Types** describe what is being scored.
- **Types:** VAL is values and behaviour. EXP is your own experience, probed. JD is a stated requirement of the role. CO is company and strategy. CASE is a live problem.
- Guidance is scaffolding, not a script. Rehearse the shape, then say it in your own words.
- An **answer slot** is an instruction for the interview. Answer whichever branch is true for you. Both branches are honest.
- Words in quotation marks in the evidence column are your own sentences. They are the only facts this pack uses about your past.

## 2. Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches and the contact centre" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | transferability | Your material says one branch's formal log. It does not show end-to-end ownership, and the bridge stays at the log's scope: "I handled the branch's formal complaints log." Answer slot: if you set which steps a complaint went through, say which, in your words. If those steps were set above you, say so and say what you did inside them. |
| F2 | "Own the member complaints process end to end across branches and the contact centre" (JD), contact-centre part | "Never worked in a contact centre" (your message) | none | [grounded] | capability | The limit, in your words: "I've never worked in a contact centre." Then how you would learn it, said as a plan, never as a past. |
| F3 | "report monthly on complaint volumes and resolution times" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | medium | [grounded] | presentation | Reword only the quote: "I built the monthly complaints spreadsheet our regional manager uses." Your material does not say which measures it carried, so do not name volumes or resolution times as yours until you can. Answer slot: if resolution times were on it, say how they were counted. If not, say which measures were. |
| F4 | "coach branch supervisors on escalations" (JD) | "trained new tellers on my escalation script" (your message); "6 years in retail banking, the last 3 as a branch supervisor" (your message) | medium | [grounded] | transferability | Adjacent work: you trained tellers, and you were a branch supervisor. Coaching other supervisors on escalations is not in your material. Bridge at the quote's scope: "I trained new tellers on my escalation script." Answer slot: if you coached other supervisors on escalations, say how. If not, say which part of the tellers' training you would take to supervisors. |
| F5 | "work with digital teams on self-service journeys" (JD) | none given | none | [grounded] | discovery | Your material does not show digital or self-service work, and that is all the pack can say. Answer slot: if you have worked with a digital or self-service team, say what the work was. If not, say so, and say what you would do first. |
| F6 | "4+ years in financial-services customer operations" (JD) | "6 years in retail banking, the last 3 as a branch supervisor" (your message) | medium | [grounded] | presentation | The years are in the quote. Reword only: "six years in retail banking, the last three as a branch supervisor." Whether branch work counts as customer operations is for the interviewer to decide. Say the branch work in those terms. |
| F7 | "experience handling regulated complaints" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | transferability | Formal complaints handling is adjacent to regulated complaints work. Your material does not name the rules or timeframes you worked to. Bridge at the log's scope. Answer slot: if you worked to a specific timeframe or set of rules, name it in your words. If you did not, say so, and say how you would learn the ones Ashgrove uses. |
| F8 | "confident presenting to senior leaders" (JD) | "I've never presented to anyone above regional level" (your message) | none | [grounded] | capability | The limit, in your words: "I've never presented to anyone above regional level." Then your plan for building the skill, as a plan. No claim of presenting experience. |
| F9 | "comfortable with Excel reporting" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | medium | [grounded] | presentation | Reword only: your quote says spreadsheet. Do not name Excel or any tool you have not named yourself. Answer slot: name the tool you used, in the words you used for it. |

**Gates:** none of the requirements ties to a legal or credential bar in the posting, so no row is a hard gate. Length of experience (F6) is graded on fit like any other requirement.

## 3. Prohibited list

These are claims the pack will not coach, and why.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end across branches and the contact centre | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: your material says one branch's formal log. |
| Built the monthly reporting on resolution times | Inflated form of F3 | F3's quote at its own scope. The material names the spreadsheet, not its measures. |
| Coached branch supervisors on escalations | Inflated form of F4 | F4's quote at its own scope. |
| Used Excel | Inflated form of F9 | F9's quote. The tool is the one you name. |
| Worked in a contact centre | Negative you stated (F2) | "I've never worked in a contact centre." |
| Presented to senior leaders | Negative you stated (F8) | "I've never presented to anyone above regional level." |

Digital and self-service work is not on this list. Your material is silent on it, so it is an answer slot (F5), not a prohibited claim.

## 4. Grounding brief

From the July 2026 strategy brief, as you described it. This is the only source for current strategy, and I have not checked it against newer news.

| Item | From the brief | Where it lands in this pack |
|---|---|---|
| Digital shift | "move 40% of member service to digital channels by 2028" | D2. Complaints by channel are where this lands. |
| Branch consolidation | "consolidate eight branches into five hubs over 2027" | D3, C5. Expect it in Round 2 and Round 3. |
| Small-business lending | A new product launch in Q1 2027 | Not a complaints topic. Know it exists. |
| Competitive pressure | App-only banks | D2, and reverse question R1. |

## 5. Persona weights

Round priors come from the relationship to each interviewer. Round 3 is the panel blend. No interviewer profiles exist yet, so there is no interviewer read.

| Persona | Rounds | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|---|
| Values / Behavioral | Round 2 (top weight), Round 3 (the panel scores the four values) | Scenario probes on Members First, Plain Words, Neighbours, Not Numbers, Own the Fix | High. Round 2 is mostly behavioural, and the panel scores values by name. | Map a quoted sentence to each value where one carries a story. Where none does, select a time and say so if none fits. |
| Skeptic | Round 1 (light), Round 2 (main) | Probes the one-branch and no-contact-centre gaps | High. The hiring-manager prior is capability plus gap-derisking, and F1, F2 and F8 are on the record. | Hold the stated position through two follow-ups, then concede the limit plainly. |
| Case / Strategist | Round 3 (20-minute case), Round 2 (strategy) | The escalation case, and questions tied to the brief | High. The case is on the panel's agenda. | Clarify, structure, decide, record. Think aloud. |
| Conversational | Round 1 | Background and motivation | High. The recruiter-screen prior. | A 90-second arc built only from quoted beats. |
| Pressure | Round 3 | Composure challenges from branch managers | Medium. A prior from the panel blend, not anything known about these two people. | Pause, restate the question, hold two follow-ups before any concession. |
| Data-Driven Prober | Round 3 | Questions on the spreadsheet | Medium. The spreadsheet is the one quantified-type claim you have made. | Say what you built. Say plainly what you cannot account for. |
| Peer Evaluator | None scheduled | Seams between branches and the hub plan | Low. No peer round. Branch managers may act like peers on the hub work. Touched in C5 and D3. | Propose principles, not seams you do not yet know. |

## 6. Question banks

Question types: VAL, EXP, JD, CO, CASE. One token per row. Secondary types are noted in the rationale.

### A. Conversational (Round 1)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through your background in about two minutes." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "I handled the branch's formal complaints log" | A 90-second arc with three beats the quotes state: six years in retail banking, the last three as a branch supervisor, the branch's formal complaints log. Then one sentence on why this role, in your words. Add no beats. | F6 and F1 are the first things the recruiter checks. The arc is built only from quoted beats. |
| A2 | "Why Ashgrove, and why this role now?" | CO | [grounded] "move 40% of member service to digital channels by 2028" (recruiter's strategy brief) | Pick one thing in the brief you would want to work on, and say why in your words. Do not recite the brief back. Your reason is what counts. | Motivation is scored at screen. The brief is the freshest source the recruiter sent. |
| A3 | "Your background is branch-based. Have you worked in a contact centre?" | JD | [grounded] "Never worked in a contact centre" | Plain acknowledgment: "I've never worked in a contact centre." Then what carries across from branch work, and how you would learn the contact centre, as a plan. | F2. A recruiter may treat this as a knockout check. |

### B. Skeptic (Rounds 1 and 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've handled one branch's complaints log. This role runs complaints across every branch and the contact centre. How would you show you can run it end to end?" | JD | [grounded] "I handled the branch's formal complaints log"; "Never worked in a contact centre" | **Highest-ROI prep in this pack.** Hold: "I handled the branch's formal complaints log," and return to it through two follow-ups. Never add to it. Concede plainly: "I've never worked in a contact centre." Answer slot: which steps of a complaint's life you set, and which were set above you. Say which, in your words. If a step was not yours, say so and say how you would cover it. | The objection will come in some form in Rounds 2 and 3. F1 and F2 are its two sides. The premise is your own sentences, and the answer slot lets the end-to-end part be answered either way. |
| B2 | "Why would a branch supervisor move into a role that is mostly reporting and coaching?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | Give your reason in your words. If the honest answer is scope, or the reporting, say that. Do not invent a motive. | F6 sets the years. The question tests whether the move follows from them. |
| B3 | "What would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre"; "I've never presented to anyone above regional level" | Name the two limits yourself: "I've never worked in a contact centre." and "I've never presented to anyone above regional level." Then your ramp plan, as a plan. | F2 and F8. A Skeptic checks whether you name the gap before they do. |
| B4 | "Present a complaints trend to the executive team in ten minutes. What do you lead with?" | JD | [grounded] "I've never presented to anyone above regional level" | Plain acknowledgment: "I've never presented to anyone above regional level." Then a structure: the decision the trend needs, the figure that supports it, the risk. Any figure must be yours to give. None is supplied here. | F8, tested as a live task. The structure is a method, not a claim about you. |

### C. Values / Behavioral (Round 2 and the Round 3 panel)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you handled a complaint you couldn't fully fix." | VAL | [grounded] "I handled the branch's formal complaints log" | Story map from the quote: the log, and your part in it. Beats the quote states: you handled it, in the branch's log. Answer slot: what you decided, and what the member got. If the decision was yours, say how. If it was not, say so and say what you did with it. Values: Members First, Own the Fix. | An open prompt. The raising source is the JD's line on owning the complaints process end to end. |
| C2 | "When did you put a member ahead of an internal process or target?" | VAL | [grounded] "I handled the branch's formal complaints log" | Selection scaffold: pick a complaint where the member's side of the counter changed what you did, and say what the member would otherwise have had. If none comes to mind, say so plainly, then give the nearest case your log holds. | Members First is the value the log sits closest to. The material shows the log, not a member-side decision, so this is a scaffold. |
| C3 | "Tell me about a time you explained something to a member so they understood it the first time." | VAL | [grounded] "trained new tellers on my escalation script" | Teaching the script: if you changed its wording so tellers could say it once, say what changed and why. If you taught it as written, say that, and how you checked the tellers understood it. | Plain Words. The nearest sentence is the training in F4, and the answer does not stretch it. |
| C4 | "Tell me about a time you found a pattern in the numbers and took it further than the report." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Selection scaffold ending in its honest branch: if a pattern in the monthly figures led to a fix, say which fix, and who kept hold of it. If the figures went to your regional manager and stopped there, say so, and say what you would do differently. | Own the Fix needs a fix someone held. The sentence gives the spreadsheet, not what it found. |
| C5 | "Tell me about a time a branch's local situation changed a decision that a number alone would have made." | VAL | [generic] | Selection scaffold, honest branch: if none comes to mind, say so. Then say what you would check locally before trusting a figure about a branch. | Neighbours, Not Numbers has no sentence of yours behind it. The consolidation brief tests it hardest. It also covers the peer-seam angle. |

### D. Case / Strategist (Round 3 case, Round 2 strategy)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "A member has written three times about a fee that was waived in writing and then charged. The branch says it's policy. The member has now written to the regional office. Talk us through the next twenty minutes of decisions." | CASE | [generic] | Time plan for 20 minutes. 3 minutes to clarify: which fee, which written waiver, what the regional office has asked. 5 minutes to structure: who owns the case, what clock applies (confirm it, do not assume it), what the member needs now, what goes to the branch. 8 minutes on the fix path: correct the fee if the waiver stands, or explain the policy in plain words and say what happens next. 4 minutes to record and hand over: what the log says, and who keeps hold until it is solved. Values: Members First, Plain Words, Own the Fix. | This is the panel's 20-minute case. No case has been supplied, so this one is generic and built to rehearse the pattern. |
| D2 | "Ashgrove plans to move 40% of member service to digital channels by 2028. What happens to the complaints you'd own as that shifts?" | CO | [grounded] "move 40% of member service to digital channels by 2028" (recruiter's strategy brief) | Clarify first: what counts as a complaint on a digital channel, and who sees it. Then volume, routing, resolution time, and what a member does when the app fails. Make no claim about your experience. | The company's current direction, asked straight from the brief. Also the app-only bank pressure. |
| D3 | "Eight branches become five hubs over 2027. A member at a branch that closes has an open complaint. What happens to it?" | CASE | [grounded] "consolidate eight branches into five hubs over 2027" (recruiter's strategy brief) | Clarify: what is open at closure, and who holds it. Structure: continuity of ownership, the local knowledge that goes with the branch (see C5), the record, and a member told once, clearly. Make no claim about closures you have worked through. Your material contains none. | Hub consolidation is the likeliest operational probe. A panel of branch managers will hear it as their own problem. |
| D4 | "Which self-service journey would you fix first, and what is your first step?" | CASE | [generic] | Name a journey by where members give up or call in. First step: listen to where they give up. Answer slot: if you have worked with a digital team, say what the work was. If not, say so, and say what you would do first. | F5. The second branch of the answer slot is the honest one for your material as it stands. |
| D5 | "A supervisor escalates three cases a week that the policy says she could close herself. How do you coach her?" | CASE | [generic] | Structure: ask why she escalates before you tell her what to do. Check the policy with her. Agree a rule for which cases come to you. Follow up in a week. Say what you would check in the escalations. Do not describe past coaching. | Coaching supervisors on escalations is the JD's line (F4). Asked as a live problem, so it needs no claim about your past. Primary type CASE; the JD content is noted here. |

### E. Pressure (Round 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why should we hire you when you've never worked in a contact centre?" | JD | [grounded] "Never worked in a contact centre"; "6 years in retail banking, the last 3 as a branch supervisor" | Hold: the years and the supervisor step, in your words. Concede plainly and specifically: the contact centre is new to you. Then your plan for it. Hold two follow-ups before any concession beyond that. | The Pressure stem, built on your own negative. Hold, then concede. |
| E2 | "That spreadsheet. How much of it was actually you?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Hold: say what you built, and how your regional manager uses it, in those words. Answer slot: which parts were your decision and which were set by the regional manager. If you cannot say how a figure was counted, say so. | The sentence is the whole claim. Do not stretch it under pressure. |

### F. Data-Driven Prober (Round 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Which measures were on that monthly spreadsheet?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Say which measures, in your words. If you can name a figure from it, say how it was counted, and name the assumption you would defend least. If you cannot say how a figure was counted, say so plainly. Do not name volumes or resolution times as measures until you can. | F3 and F9: the JD's reporting requirement, and the nearest thing you have to Excel reporting. The defend-the-number slot applies only if you give a figure. |

### Requirement coverage

| JD requirement | Question IDs |
|---|---|
| Own the complaints process end to end across branches and the contact centre | B1, C1, D1, D3 |
| Report monthly on complaint volumes and resolution times | F1, E2, C4 |
| Coach branch supervisors on escalations | D5 |
| Work with digital teams on self-service journeys | D2, D4 |
| 4+ years in financial-services customer operations | A1, B2 |
| Experience handling regulated complaints | D1, B1 |
| Confident presenting to senior leaders | B3, B4 |
| Comfortable with Excel reporting | F1. No Excel claim is written. |

Session total: 20 questions.

## 7. Values cheat sheet

The panel scores against these four values, so this section is required.

| Value (official name) | Working meaning | Mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | F1 is the nearest sentence, but it carries the log and not a member-side decision. Selection scaffold (C1, C2): pick a complaint where the member's side changed your decision. If none did, say so and give the nearest case. |
| Plain Words | If a member needs it explained twice, we wrote it wrong | F4 carries "trained new tellers on my escalation script." Selection scaffold (C3): if you changed the script's wording, say what changed. If you taught it as written, say that. |
| Neighbours, Not Numbers | Every branch is part of its town | No sentence of yours carries this. Selection scaffold (C5): pick a time a local circumstance changed what a figure alone would have decided. If none, say so, and say what you would check locally first. |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | F3 carries "I built the monthly complaints spreadsheet our regional manager uses." Selection scaffold (C4): pick a pattern you saw through to a fix. If you did not see one through, say you raised it, and what happened to it. |

## 8. Reverse questions

Your interviewers' profiles are not known yet, so no reverse question is tied to an interviewer's career path. Round 3 includes branch managers, so R5 is a reciprocity question.

| # | Question | Why it lands |
|---|---|---|
| R1 | "Which branches are in the first consolidation wave, and how will their open complaints move to the hubs?" | Shows you read the strategy brief and want the operational detail. |
| R2 | "How are complaints split between branches and the contact centre today, and where do resolution times sit against target?" | Shows you want the baseline before you judge it. A number-minded question. |
| R3 | "What would success look like in the first ninety days?" | A manager's question. The answer tells you the real scope of the role. |
| R4 | "Which of the four values do branch teams find hardest to live by in a complaints queue?" | The panel scores the values. The answer shows how they work day to day. |
| R5 | "What would a branch manager who handles complaints well do differently from one who doesn't?" | Reciprocity for the panel. It asks for their judgment and places you alongside them on the work. |
| R6 | "What is the one part of the escalation process you would change first, if you could?" | Shows you think about fixing the process, not only running it. |

## 9. Sources

**Provided documents**

- The job description, as pasted in your message.
- The values page text, copied 11 November 2026, as pasted in your message.
- The recruiter's email: round structure and the panel's values scoring.
- The Ashgrove 2026 strategy brief, July 2026, as sent by the recruiter and described in your message.
- Your background, as stated in your message.

**Research tier:** L0, provided documents only. No searches or fetches were sent.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | The values cheat sheet, section 7. The pasted values page fixes it. |
| 2. Ashgrove interview process | skipped | Round structure and persona weights, fixed by the recruiter's email. |
| 3. Ashgrove strategy / recent news | skipped | The grounding brief, section 4. The July brief you supplied fixes the current priorities. Recent news was not checked. |
| 4. Named interviewer footprint | n/a | No interviewer names are known, so there was no query to form. |
| 5. Representative JD | skipped | The job description you supplied fixes the fit snapshot and the JD questions. |

## 10. Upgrade menu

- **Interviewer names** (Head of Member Services and the two panel branch managers) → persona weights from their public footprint, and a tailored reverse question. Needs a light research pass on their public profiles.
- **A figure you can stand behind** from your reporting (a volume or a resolution time, even approximate) → F1 and F3 gain a defend-the-number slot you can rehearse.
- **Any digital, self-service, or contact-centre work**, however small → F2 and F5 move from capability or discovery to material you can rehearse.
- **The rules or timeframes you worked to on the formal log** → F7's bridge gets the names you used at the time.
- **Hours you have before 20 November** → a prep-triage schedule, sized to the time.
- **Deep research (L2):** recent Ashgrove news, and the status of the hub plan. Roughly six more searches and two page fetches. Run only if you want it.

---

- Say the word and I'll run a live drill. I'd start with B1, the highest-ROI question.
- I can save a `tuesday-dossier.md` recording the gaps this prep exposed, to carry into later sessions. I can also convert the pack to Word if you want it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove_member_experience_lead_interview_pack.md -----
# Interview pack: Member Experience Lead, Ashgrove Credit Union

**Candidate:** Dara
**Company:** Ashgrove Credit Union (member-owned, about 900 staff)
**Built on:** the job description, the values page (copied 11 November 2026), the recruiter's email, the July 2026 strategy brief as described to me, and your background. No web research was run (tier L0).

**Rounds, 20 November 2026**

1. Recruiter, 30 minutes: screen, logistics, motivation.
2. Head of Member Services, 45 minutes, mostly behavioural. This is your future manager.
3. Panel of two branch managers, 60 minutes. Includes a 20-minute complaint-escalation case. The panel scores against the four values. Panel names are not yet known.

## 1. How to use this pack

- **Personas** describe how a question is asked. **Types** describe what is being scored.
- **Types:** VAL is values and behaviour. EXP is your own experience, probed. JD is a stated requirement of the role. CO is company and strategy. CASE is a live problem.
- Guidance is scaffolding, not a script. Rehearse the shape, then say it in your own words.
- An **answer slot** is an instruction for the interview. Answer whichever branch is true for you. Both branches are honest.
- Words in quotation marks in the evidence column are your own sentences. They are the only facts this pack uses about your past.

## 2. Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches and the contact centre" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | transferability | Your material says one branch's formal log. It does not show end-to-end ownership, and the bridge stays at the log's scope: "I handled the branch's formal complaints log." Answer slot: if you set which steps a complaint went through, say which, in your words. If those steps were set above you, say so and say what you did inside them. |
| F2 | "Own the member complaints process end to end across branches and the contact centre" (JD), contact-centre part | "Never worked in a contact centre" (your message) | none | [grounded] | capability | The limit, in your words: "I've never worked in a contact centre." Then how you would learn it, said as a plan, never as a past. |
| F3 | "report monthly on complaint volumes and resolution times" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | medium | [grounded] | presentation | Reword only the quote: "I built the monthly complaints spreadsheet our regional manager uses." Your material does not say which measures it carried, so do not name volumes or resolution times as yours until you can. Answer slot: if resolution times were on it, say how they were counted. If not, say which measures were. |
| F4 | "coach branch supervisors on escalations" (JD) | "trained new tellers on my escalation script" (your message); "6 years in retail banking, the last 3 as a branch supervisor" (your message) | medium | [grounded] | transferability | Adjacent work: you trained tellers, and you were a branch supervisor. Coaching other supervisors on escalations is not in your material. Bridge at the quote's scope: "I trained new tellers on my escalation script." Answer slot: if you coached other supervisors on escalations, say how. If not, say which part of the tellers' training you would take to supervisors. |
| F5 | "work with digital teams on self-service journeys" (JD) | none given | none | [grounded] | discovery | Your material does not show digital or self-service work, and that is all the pack can say. Answer slot: if you have worked with a digital or self-service team, say what the work was. If not, say so, and say what you would do first. |
| F6 | "4+ years in financial-services customer operations" (JD) | "6 years in retail banking, the last 3 as a branch supervisor" (your message) | medium | [grounded] | presentation | The years are in the quote. Reword only: "six years in retail banking, the last three as a branch supervisor." Whether branch work counts as customer operations is for the interviewer to decide. Say the branch work in those terms. |
| F7 | "experience handling regulated complaints" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | transferability | Formal complaints handling is adjacent to regulated complaints work. Your material does not name the rules or timeframes you worked to. Bridge at the log's scope. Answer slot: if you worked to a specific timeframe or set of rules, name it in your words. If you did not, say so, and say how you would learn the ones Ashgrove uses. |
| F8 | "confident presenting to senior leaders" (JD) | "I've never presented to anyone above regional level" (your message) | none | [grounded] | capability | The limit, in your words: "I've never presented to anyone above regional level." Then your plan for building the skill, as a plan. No claim of presenting experience. |
| F9 | "comfortable with Excel reporting" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | medium | [grounded] | presentation | Reword only: your quote says spreadsheet. Do not name Excel or any tool you have not named yourself. Answer slot: name the tool you used, in the words you used for it. |

**Gates:** none of the requirements ties to a legal or credential bar in the posting, so no row is a hard gate. Length of experience (F6) is graded on fit like any other requirement.

## 3. Prohibited list

These are claims the pack will not coach, and why.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end across branches and the contact centre | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: your material says one branch's formal log. |
| Built the monthly reporting on resolution times | Inflated form of F3 | F3's quote at its own scope. The material names the spreadsheet, not its measures. |
| Coached branch supervisors on escalations | Inflated form of F4 | F4's quote at its own scope. |
| Used Excel | Inflated form of F9 | F9's quote. The tool is the one you name. |
| Worked in a contact centre | Negative you stated (F2) | "I've never worked in a contact centre." |
| Presented to senior leaders | Negative you stated (F8) | "I've never presented to anyone above regional level." |

Digital and self-service work is not on this list. Your material is silent on it, so it is an answer slot (F5), not a prohibited claim.

## 4. Grounding brief

From the July 2026 strategy brief, as you described it. This is the only source for current strategy, and I have not checked it against newer news.

| Item | From the brief | Where it lands in this pack |
|---|---|---|
| Digital shift | "move 40% of member service to digital channels by 2028" | D2. Complaints by channel are where this lands. |
| Branch consolidation | "consolidate eight branches into five hubs over 2027" | D3, C5. Expect it in Round 2 and Round 3. |
| Small-business lending | A new product launch in Q1 2027 | Not a complaints topic. Know it exists. |
| Competitive pressure | App-only banks | D2, and reverse question R1. |

## 5. Persona weights

Round priors come from the relationship to each interviewer. Round 3 is the panel blend. No interviewer profiles exist yet, so there is no interviewer read.

| Persona | Rounds | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|---|
| Values / Behavioral | Round 2 (top weight), Round 3 (the panel scores the four values) | Scenario probes on Members First, Plain Words, Neighbours, Not Numbers, Own the Fix | High. Round 2 is mostly behavioural, and the panel scores values by name. | Map a quoted sentence to each value where one carries a story. Where none does, select a time and say so if none fits. |
| Skeptic | Round 1 (light), Round 2 (main) | Probes the one-branch and no-contact-centre gaps | High. The hiring-manager prior is capability plus gap-derisking, and F1, F2 and F8 are on the record. | Hold the stated position through two follow-ups, then concede the limit plainly. |
| Case / Strategist | Round 3 (20-minute case), Round 2 (strategy) | The escalation case, and questions tied to the brief | High. The case is on the panel's agenda. | Clarify, structure, decide, record. Think aloud. |
| Conversational | Round 1 | Background and motivation | High. The recruiter-screen prior. | A 90-second arc built only from quoted beats. |
| Pressure | Round 3 | Composure challenges from branch managers | Medium. A prior from the panel blend, not anything known about these two people. | Pause, restate the question, hold two follow-ups before any concession. |
| Data-Driven Prober | Round 3 | Questions on the spreadsheet | Medium. The spreadsheet is the one quantified-type claim you have made. | Say what you built. Say plainly what you cannot account for. |
| Peer Evaluator | None scheduled | Seams between branches and the hub plan | Low. No peer round. Branch managers may act like peers on the hub work. Touched in C5 and D3. | Propose principles, not seams you do not yet know. |

## 6. Question banks

Question types: VAL, EXP, JD, CO, CASE. One token per row. Secondary types are noted in the rationale.

### A. Conversational (Round 1)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through your background in about two minutes." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "I handled the branch's formal complaints log" | A 90-second arc with three beats the quotes state: six years in retail banking, the last three as a branch supervisor, the branch's formal complaints log. Then one sentence on why this role, in your words. Add no beats. | F6 and F1 are the first things the recruiter checks. The arc is built only from quoted beats. |
| A2 | "Why Ashgrove, and why this role now?" | CO | [grounded] "move 40% of member service to digital channels by 2028" (recruiter's strategy brief) | Pick one thing in the brief you would want to work on, and say why in your words. Do not recite the brief back. Your reason is what counts. | Motivation is scored at screen. The brief is the freshest source the recruiter sent. |
| A3 | "Your background is branch-based. Have you worked in a contact centre?" | JD | [grounded] "Never worked in a contact centre" | Plain acknowledgment: "I've never worked in a contact centre." Then what carries across from branch work, and how you would learn the contact centre, as a plan. | F2. A recruiter may treat this as a knockout check. |

### B. Skeptic (Rounds 1 and 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've handled one branch's complaints log. This role runs complaints across every branch and the contact centre. How would you show you can run it end to end?" | JD | [grounded] "I handled the branch's formal complaints log"; "Never worked in a contact centre" | **Highest-ROI prep in this pack.** Hold: "I handled the branch's formal complaints log," and return to it through two follow-ups. Never add to it. Concede plainly: "I've never worked in a contact centre." Answer slot: which steps of a complaint's life you set, and which were set above you. Say which, in your words. If a step was not yours, say so and say how you would cover it. | The objection will come in some form in Rounds 2 and 3. F1 and F2 are its two sides. The premise is your own sentences, and the answer slot lets the end-to-end part be answered either way. |
| B2 | "Why would a branch supervisor move into a role that is mostly reporting and coaching?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | Give your reason in your words. If the honest answer is scope, or the reporting, say that. Do not invent a motive. | F6 sets the years. The question tests whether the move follows from them. |
| B3 | "What would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre"; "I've never presented to anyone above regional level" | Name the two limits yourself: "I've never worked in a contact centre." and "I've never presented to anyone above regional level." Then your ramp plan, as a plan. | F2 and F8. A Skeptic checks whether you name the gap before they do. |
| B4 | "Present a complaints trend to the executive team in ten minutes. What do you lead with?" | JD | [grounded] "I've never presented to anyone above regional level" | Plain acknowledgment: "I've never presented to anyone above regional level." Then a structure: the decision the trend needs, the figure that supports it, the risk. Any figure must be yours to give. None is supplied here. | F8, tested as a live task. The structure is a method, not a claim about you. |

### C. Values / Behavioral (Round 2 and the Round 3 panel)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you handled a complaint you couldn't fully fix." | VAL | [grounded] "I handled the branch's formal complaints log" | Story map from the quote: the log, and your part in it. Beats the quote states: you handled it, in the branch's log. Answer slot: what you decided, and what the member got. If the decision was yours, say how. If it was not, say so and say what you did with it. Values: Members First, Own the Fix. | An open prompt. The raising source is the JD's line on owning the complaints process end to end. |
| C2 | "When did you put a member ahead of an internal process or target?" | VAL | [grounded] "I handled the branch's formal complaints log" | Selection scaffold: pick a complaint where the member's side of the counter changed what you did, and say what the member would otherwise have had. If none comes to mind, say so plainly, then give the nearest case your log holds. | Members First is the value the log sits closest to. The material shows the log, not a member-side decision, so this is a scaffold. |
| C3 | "Tell me about a time you explained something to a member so they understood it the first time." | VAL | [grounded] "trained new tellers on my escalation script" | Teaching the script: if you changed its wording so tellers could say it once, say what changed and why. If you taught it as written, say that, and how you checked the tellers understood it. | Plain Words. The nearest sentence is the training in F4, and the answer does not stretch it. |
| C4 | "Tell me about a time you found a pattern in the numbers and took it further than the report." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Selection scaffold ending in its honest branch: if a pattern in the monthly figures led to a fix, say which fix, and who kept hold of it. If the figures went to your regional manager and stopped there, say so, and say what you would do differently. | Own the Fix needs a fix someone held. The sentence gives the spreadsheet, not what it found. |
| C5 | "Tell me about a time a branch's local situation changed a decision that a number alone would have made." | VAL | [generic] | Selection scaffold, honest branch: if none comes to mind, say so. Then say what you would check locally before trusting a figure about a branch. | Neighbours, Not Numbers has no sentence of yours behind it. The consolidation brief tests it hardest. It also covers the peer-seam angle. |

### D. Case / Strategist (Round 3 case, Round 2 strategy)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "A member has written three times about a fee that was waived in writing and then charged. The branch says it's policy. The member has now written to the regional office. Talk us through the next twenty minutes of decisions." | CASE | [generic] | Time plan for 20 minutes. 3 minutes to clarify: which fee, which written waiver, what the regional office has asked. 5 minutes to structure: who owns the case, what clock applies (confirm it, do not assume it), what the member needs now, what goes to the branch. 8 minutes on the fix path: correct the fee if the waiver stands, or explain the policy in plain words and say what happens next. 4 minutes to record and hand over: what the log says, and who keeps hold until it is solved. Values: Members First, Plain Words, Own the Fix. | This is the panel's 20-minute case. No case has been supplied, so this one is generic and built to rehearse the pattern. |
| D2 | "Ashgrove plans to move 40% of member service to digital channels by 2028. What happens to the complaints you'd own as that shifts?" | CO | [grounded] "move 40% of member service to digital channels by 2028" (recruiter's strategy brief) | Clarify first: what counts as a complaint on a digital channel, and who sees it. Then volume, routing, resolution time, and what a member does when the app fails. Make no claim about your experience. | The company's current direction, asked straight from the brief. Also the app-only bank pressure. |
| D3 | "Eight branches become five hubs over 2027. A member at a branch that closes has an open complaint. What happens to it?" | CASE | [grounded] "consolidate eight branches into five hubs over 2027" (recruiter's strategy brief) | Clarify: what is open at closure, and who holds it. Structure: continuity of ownership, the local knowledge that goes with the branch (see C5), the record, and a member told once, clearly. Make no claim about closures you have worked through. Your material contains none. | Hub consolidation is the likeliest operational probe. A panel of branch managers will hear it as their own problem. |
| D4 | "Which self-service journey would you fix first, and what is your first step?" | CASE | [generic] | Name a journey by where members give up or call in. First step: listen to where they give up. Answer slot: if you have worked with a digital team, say what the work was. If not, say so, and say what you would do first. | F5. The second branch of the answer slot is the honest one for your material as it stands. |
| D5 | "A supervisor escalates three cases a week that the policy says she could close herself. How do you coach her?" | CASE | [generic] | Structure: ask why she escalates before you tell her what to do. Check the policy with her. Agree a rule for which cases come to you. Follow up in a week. Say what you would check in the escalations. Do not describe past coaching. | Coaching supervisors on escalations is the JD's line (F4). Asked as a live problem, so it needs no claim about your past. Primary type CASE; the JD content is noted here. |

### E. Pressure (Round 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why should we hire you when you've never worked in a contact centre?" | JD | [grounded] "Never worked in a contact centre"; "6 years in retail banking, the last 3 as a branch supervisor" | Hold: the years and the supervisor step, in your words. Concede plainly and specifically: the contact centre is new to you. Then your plan for it. Hold two follow-ups before any concession beyond that. | The Pressure stem, built on your own negative. Hold, then concede. |
| E2 | "That spreadsheet. How much of it was actually you?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Hold: say what you built, and how your regional manager uses it, in those words. Answer slot: which parts were your decision and which were set by the regional manager. If you cannot say how a figure was counted, say so. | The sentence is the whole claim. Do not stretch it under pressure. |

### F. Data-Driven Prober (Round 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Which measures were on that monthly spreadsheet?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Say which measures, in your words. If you can name a figure from it, say how it was counted, and name the assumption you would defend least. If you cannot say how a figure was counted, say so plainly. Do not name volumes or resolution times as measures until you can. | F3 and F9: the JD's reporting requirement, and the nearest thing you have to Excel reporting. The defend-the-number slot applies only if you give a figure. |

### Requirement coverage

| JD requirement | Question IDs |
|---|---|
| Own the complaints process end to end across branches and the contact centre | B1, C1, D1, D3 |
| Report monthly on complaint volumes and resolution times | F1, E2, C4 |
| Coach branch supervisors on escalations | D5 |
| Work with digital teams on self-service journeys | D2, D4 |
| 4+ years in financial-services customer operations | A1, B2 |
| Experience handling regulated complaints | D1, B1 |
| Confident presenting to senior leaders | B3, B4 |
| Comfortable with Excel reporting | F1. No Excel claim is written. |

Session total: 20 questions.

## 7. Values cheat sheet

The panel scores against these four values, so this section is required.

| Value (official name) | Working meaning | Mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | F1 is the nearest sentence, but it carries the log and not a member-side decision. Selection scaffold (C1, C2): pick a complaint where the member's side changed your decision. If none did, say so and give the nearest case. |
| Plain Words | If a member needs it explained twice, we wrote it wrong | F4 carries "trained new tellers on my escalation script." Selection scaffold (C3): if you changed the script's wording, say what changed. If you taught it as written, say that. |
| Neighbours, Not Numbers | Every branch is part of its town | No sentence of yours carries this. Selection scaffold (C5): pick a time a local circumstance changed what a figure alone would have decided. If none, say so, and say what you would check locally first. |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | F3 carries "I built the monthly complaints spreadsheet our regional manager uses." Selection scaffold (C4): pick a pattern you saw through to a fix. If you did not see one through, say you raised it, and what happened to it. |

## 8. Reverse questions

Your interviewers' profiles are not known yet, so no reverse question is tied to an interviewer's career path. Round 3 includes branch managers, so R5 is a reciprocity question.

| # | Question | Why it lands |
|---|---|---|
| R1 | "Which branches are in the first consolidation wave, and how will their open complaints move to the hubs?" | Shows you read the strategy brief and want the operational detail. |
| R2 | "How are complaints split between branches and the contact centre today, and where do resolution times sit against target?" | Shows you want the baseline before you judge it. A number-minded question. |
| R3 | "What would success look like in the first ninety days?" | A manager's question. The answer tells you the real scope of the role. |
| R4 | "Which of the four values do branch teams find hardest to live by in a complaints queue?" | The panel scores the values. The answer shows how they work day to day. |
| R5 | "What would a branch manager who handles complaints well do differently from one who doesn't?" | Reciprocity for the panel. It asks for their judgment and places you alongside them on the work. |
| R6 | "What is the one part of the escalation process you would change first, if you could?" | Shows you think about fixing the process, not only running it. |

## 9. Sources

**Provided documents**

- The job description, as pasted in your message.
- The values page text, copied 11 November 2026, as pasted in your message.
- The recruiter's email: round structure and the panel's values scoring.
- The Ashgrove 2026 strategy brief, July 2026, as sent by the recruiter and described in your message.
- Your background, as stated in your message.

**Research tier:** L0, provided documents only. No searches or fetches were sent.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | The values cheat sheet, section 7. The pasted values page fixes it. |
| 2. Ashgrove interview process | skipped | Round structure and persona weights, fixed by the recruiter's email. |
| 3. Ashgrove strategy / recent news | skipped | The grounding brief, section 4. The July brief you supplied fixes the current priorities. Recent news was not checked. |
| 4. Named interviewer footprint | n/a | No interviewer names are known, so there was no query to form. |
| 5. Representative JD | skipped | The job description you supplied fixes the fit snapshot and the JD questions. |

## 10. Upgrade menu

- **Interviewer names** (Head of Member Services and the two panel branch managers) → persona weights from their public footprint, and a tailored reverse question. Needs a light research pass on their public profiles.
- **A figure you can stand behind** from your reporting (a volume or a resolution time, even approximate) → F1 and F3 gain a defend-the-number slot you can rehearse.
- **Any digital, self-service, or contact-centre work**, however small → F2 and F5 move from capability or discovery to material you can rehearse.
- **The rules or timeframes you worked to on the formal log** → F7's bridge gets the names you used at the time.
- **Hours you have before 20 November** → a prep-triage schedule, sized to the time.
- **Deep research (L2):** recent Ashgrove news, and the status of the hub plan. Roughly six more searches and two page fetches. Run only if you want it.
