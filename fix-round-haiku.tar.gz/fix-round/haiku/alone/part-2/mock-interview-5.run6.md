Your prep pack is saved as /tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-alone-part-2-rooms-case-5-denied-3036eee9/477e3783-b962-40e0-aba0-0a88a64a1868/scratchpad/kelverton-rail_senior-partnerships-manager_interview_pack.md. It's built without a job description and without web research, because the search permission was refused. So it has no company values or interview-process material, and it doesn't use the market report, which isn't in our conversation.

The highest-ROI prep is A1: Ross will likely test "£4M of influenced revenue" against closed business. The POV section gives you two theses and an anti-pick, each with a concession.

Say the word and I'll play Ross on A1, with follow-ups that react to your answer. I can also save a tuesday-dossier.md recording the gaps this prep exposed, for your later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

Two things would strengthen the pack:
1. Can you paste the job description text? Without it, the requirements are quoted from the recruiter's email only.
2. Can you paste the main findings from the market report you read? The POV has to differ from the consensus in it, and I can't check that without the report.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: kelverton-rail_senior-partnerships-manager_interview_pack.md -----
# Kelverton Rail, Senior Partnerships Manager: second-round prep pack

**Panel (Tuesday, 60 min):** Deepa (VP Partnerships, your future manager) and Ross (Commercial Director).
**Format:** first 15 min, a short spoken POV on operator partnerships over 18 months, no slides, ending on what it means for the operators themselves. Remaining time is Q&A, and Ross will push on commercials.
**Built on:** your message and the recruiter's email as you quoted it. No job description and no research: the host refused search permission, so this pack has no company values, interview-process or strategy material, and the market report is not in hand.

## How to use

- **Personas** describe how a question arrives. **Types** describe what is being scored.
- Type key: **EXP** work-experience deep-dive (does your claim survive scrutiny). **JD** role-driven (can you do the listed job, gaps included). **CO** company and market knowledge. **CASE** live problem, scored on structure. **VAL** values and behaviour (not run: no published values in hand).
- Guidance is scaffolding, not a script. Rehearse the shape, then say it in your own words.
- Every row marked **[grounded]** rests on a sentence you wrote or said. **[inferred]** is this pack's derivation. **[generic]** is general practice, not a fact about Kelverton.

## Prep triage (about four hours)

1. **POV build, about 90 min.** Write the three theses in your own words (section 5). Speak them to a timer. Cut to 12 minutes so the 15 has room.
2. **Commercials, about 75 min.** A1 first, then A2. Write the one sentence you can defend about the £4M and the one about the quota. Rehearse holding each through two follow-ups.
3. **Operator side, about 45 min.** B4, B5 and C2. These are where the POV meets questions about your real experience.
4. **Reverse questions and D2, about 20 min.**

Everything else is insurance.

## The fit snapshot

No job description was supplied, so the requirement column quotes the recruiter's own words, and role-family requirements are plain prose labelled [generic].

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Please land on what it means for the operators themselves." (recruiter's email) | "bus and light rail network planning" (your message), "so I know the operator world from the other side" (your message) | medium | [grounded] | transferability | Your material places you on the operator side through planning work, not through their buying decisions. Bridge in your words: "bus and light rail network planning" after five years in transport consulting. Answer slot: expect a probe on how operators decide on scheduling tools. If you saw one of those decisions made from the planning side, say which and what you saw; if you did not, say so and say where you would check first. |
| F2 | "Ross will push on commercials." (recruiter's email) | "never carried a direct quota, only influenced revenue" (your message) | none | [grounded] | capability | A gap you stated, so the pack gives back your words: "I haven't carried a direct quota." Then how you would learn the quota cycle, said as a plan, never as a past. |
| F3 | "they sell scheduling software to train operating companies" (your message, describing Kelverton) | "Never sold into rail specifically" (your message) | none | [grounded] | capability | A gap you stated: "I haven't sold into rail." Then how you would learn the rail buying cycle, said as a plan. |
| F4 | Build and run a partner channel (role family, [generic]) | "took it from 6 partners to 40, roughly £4M of influenced revenue" (your message) | high | [grounded] | none | The quote already reaches the requirement. Say it in those terms: partners from 6 to 40, and roughly £4M of influenced revenue. Expect the figure to be probed (A1). |
| F5 | "Ross will push on commercials." (recruiter's email) | none given | none | [inferred] | discovery | Your material does not show pricing or contracting with a buyer. Answer slot: if you priced or structured a partner deal with a buyer, say how and what you decided; if you did not, say so and say how you would build a price. |

Confidence grades your evidence. Provenance grades this pack's statement. F5's provenance is [inferred] because the gap is this pack's reading of your material, which is silent on it.

## Graded deliverable: the 15-minute POV

Recruiter-declared, so it is a graded deliverable. Facts to build on, each from a fit-snapshot row:
- F1: "bus and light rail network planning"
- F4: "took it from 6 partners to 40, roughly £4M of influenced revenue"

**Thesis 1, operators plan change on fixed cycles, so partnerships should be built around their change process, not the vendor's sales cycle.** [generic] Concession: operator change windows limit how fast any partner can deliver, and a partner route that ignores them would fail on the first project.

**Thesis 2, a partner route into the tool operators already use lets them buy an outcome rather than a licence.** [generic] Concession: operator planning teams may prefer a direct vendor relationship, and a partner layer adds a party to manage.

**Anti-pick, do not build a broad marketplace of rail partners.** [generic] The buyer population is small, so depth beats breadth. Concession: the lesson from 6 to 40 may not transfer, because that channel had far more buyers. Say so.

**Differentiation.** The consensus answer is "more partners, more co-selling, more certification." Lead with the operator's change process and say why partner count is the wrong measure. Do not recite a shared report. The market report is not in this pack, so the divergence cannot yet be checked against it (see the upgrade menu).

**Close, as the recruiter asked.** Finish on one operator-side outcome you would measure, for example the number of timetable changes that need rework after publication. [generic] This is an example, not a Kelverton fact. Say it as a test, not as a result.

## Persona table

| Persona | Who | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|---|
| Pressure / Stress | Ross | Interrupts on the £4M and the quota; time-boxes answers | High. The recruiter says he will push on commercials, and a commercial director at this level weights composure and altitude. | Pause, restate, anchor in your own sentence, hold two follow-ups before conceding. |
| Data-Driven Prober | Ross | Asks how the figure was counted and what it assumes | High. F4's figure is the only number in your material and it is influenced, not closed. | Name the weakest assumption before he does. Say plainly what you do not know. |
| Case / Strategist | Deepa and Ross | Live problems on operators and pricing; the POV follow-ups | High. The POV is strategy by design, and the future manager is buying judgment. | Clarify, structure, then answer. Name one premise you would challenge. |
| Skeptic | Deepa | "Why rail, having never sold into it?" "What would you do on day one?" | Medium-high. F3 is a stated gap and the manager carries its risk. | Answer the concern first. Concede the gap in one sentence, then bridge to channel-building. |
| Conversational | Both, at the open | "Walk me through the journey." | Low. Casual openers are still scored. | Keep a 90-second arc. |
| Values / Behavioural | Not detected | No values round named, no published values in hand | Not weighted. Section 10 is dropped. | None. |
| Peer Evaluator | Not applicable | Deepa is your future manager, not a peer | Not weighted. | None. |

Weights, from relationship priors (manager plus commercial director, so Case and Skeptic for Deepa, Pressure and Prober for Ross), then the panel split: Pressure and Prober 5 questions, Case and Skeptic 5, POV follow-ups 3, conversational 2.

## Question banks

**Highest-ROI prep: A1.** Ross is likely to test "influenced revenue" against "closed." Your only number is influenced, so the one most likely objection is about that figure, and it will come from the person who signs off commercial terms.

### Bank A: Pressure and commercial (Ross), weight 5

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You took partners from 6 to 40 and report roughly £4M of influenced revenue. How much of that would show up as closed business, and how was it counted?" | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" (your message) | Give the count in your own words, and say what you counted as influenced. Name the assumption behind the figure that you would defend least, before he asks. Answer slot: if you did this, say how, in your own words; if there was no such step, or it was not yours, say so plainly and return to "roughly £4M of influenced revenue." | F4's figure is the number he will test. EXP because it tests what was yours. |
| A2 | "You've never carried a direct quota. Why would this role be different?" | JD | [grounded] "never carried a direct quota, only influenced revenue" (your message) | Hold the position that you have not carried a quota and that your number was influenced revenue. Concede the gap plainly. Then your plan for learning the quota cycle, as a plan. Hold through two follow-ups by returning to the influenced number. | F2 is a stated gap and the commercial director will press it. |
| A3 | "A rail operator buys on a multi-year procurement window. What does your first year's pipeline look like?" | CASE | [generic] | Clarify first: what counts as pipeline here, who decides, what the renewal calendar is. Then structure by operator, by decision point, then the first 90 days of conversations. Do not assert any buying-cycle length as fact. | A live problem, asked as a decision. It meets F2 without asking for a past. |
| A4 | "How would you price a partner programme to an operator that buys under public procurement rules?" | CASE | [generic] | Who pays, what the operator gains, what the procurement route is, and a pilot before a price. No numbers. | Commercial pushback on pricing, which F5 does not cover. The procurement premise is a general risk, not a fact about this employer. |
| A5 | "A finance director asks what it costs them before what it gives them. Answer that." | CASE | [generic] | Lead with the operator's cost and the number you would need to know. Then the value. | A commercial director's usual probe. Tests altitude more than knowledge. |

### Bank B: Case and Skeptic (Deepa), weight 5

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Why partnerships, at a rail company, when you've never sold into rail?" | JD | [grounded] "Never sold into rail specifically" (your message); "took it from 6 partners to 40" (your message) | Concede first: "I haven't sold into rail." Then bridge to the channel-building you did: "took it from 6 partners to 40." Do not argue the point. | F3 is a stated gap and the future manager's first doubt. |
| B2 | "What would you do in your first 90 days with our operator partners?" | CASE | [generic] | Listen first, then map which partners and operator relationships matter, and what you would bring in writing. Ask one question about the change process before you propose anything. | The ramp question. A manager is hiring a plan, not a list of ideas. |
| B3 | "Tell me about a partner relationship that went wrong." | EXP | [generic] | Pick a partner relationship that went wrong. It needs a named stake, what you did, and what changed. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. | Open prompt, no quote carries a story, so this is a selection scaffold. |
| B4 | "How do operators choose scheduling tools today?" | CO | [grounded] "bus and light rail network planning" (your message) | From the planning side: what you saw of how operators changed timetables and who was in the room. Answer slot: if you saw any buying decision, say what you saw; if you saw none, say so and say where you would check first, with operator planning and procurement, not the vendor's own view. | F1 is the closest you have to the operator view. Asked as a fact about the market, so answer in the planning terms. |
| B5 | "You did network planning for five years. Tell me about one decision you made that an operator would recognise." | EXP | [grounded] "bus and light rail network planning" (your message); "so I know the operator world from the other side" (your message) | One planning decision, in your words, with the part you were responsible for. Answer slot: if the decision was yours alone, say so; if it was a team's, say your part of it. | Turns F1 into a story. The interviewer's "recognise" is their framing. Do not add an operator reaction you did not see. |

### Bank C: POV follow-ups (Case and Prober), weight 3

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Which of your three theses would you drop if you had to?" | CASE | [generic] | Name the weakest thesis and the concession you wrote for it. Do not defend it past the concession. | The first POV follow-up. Tests whether the theses are real. |
| C2 | "What would make your view of operators wrong?" | CASE | [generic] | Name one operator behaviour that would falsify the POV, for example operators continuing to buy direct from vendors. Say what evidence you would collect first. | Tests calibration on the operator side, which the recruiter asked you to land on. |
| C3 | "How would we know in 18 months that it worked for operators, not just for us?" | CASE | [generic] | One operator-side measure, who would report it, and the denominator you would need. Name the assumption you would test first: whether operators share the data. | Metric probe on the POV's close. No figure is asserted. |

### Bank D: Conversational (both), weight 2

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey." | EXP | [grounded] "bus and light rail network planning"; "running the ISV channel"; "took it from 6 partners to 40" (your message) | A 90-second arc: operator-side planning, then the ISV channel, then what you would bring. Use only those beats. | Opener. Casual, but scored. |
| D2 | "What have you been reading about operators lately?" | CO | [generic] | Name what you have actually read, in your words, and say where you would push back. Do not recite a shared document. | Tests whether you read the market and can differentiate from it. |

### Requirement coverage

No job description was supplied, so there are no JD requirements to check. The recruiter's named items:

| Item | Covered by |
|---|---|
| "Please land on what it means for the operators themselves." | POV section, B4, B5, C2, C3, D1 |
| "Ross will push on commercials." | A1 to A5, reverse questions R4 and R5 |
| Partner channel build and run (role family, [generic]) | B1, B3, D1 |
| Selling into train operating companies | B1, B4, D2 |
| Every other requirement | None, and why: no JD text was supplied |

Session total is 15 questions. That is below the usual 18 to 26, because there is no JD to cover; the upgrade menu raises it.

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | (To Deepa) "What did the operators already on the channel tell you last year that the team did not expect?" | Asks the manager for the operator view and shows you are listening to operators. |
| R2 | (To Deepa) "What would this role be measured on at 18 months, and who sets that number?" | Reveals her scorecard and whether influence or revenue carries the role. |
| R3 | (To Deepa) "Which operator relationship is most at risk right now, and why?" | Shows you think in accounts, not in channel totals. |
| R4 | (To Ross) "How are partner-sourced deals credited in the commercial model today?" | Goes straight to the attribution question A1 will test. Signals you know credit is the crux. |
| R5 | (To Ross) "Where does the commercial team see the widest gap between an operator's interest and its buying window?" | Asks for his commercial pain in his terms, and turns the pushback into a shared problem. |

No interviewer profile was supplied, so no reverse question ties to Deepa's or Ross's career path. Full names would enable that (upgrade menu).

## Prohibited claims

Built from the fit snapshot before the banks were written. Nothing in the pack asserts, softens or implies these.

| Not coached | Basis | Honest form |
|---|---|---|
| "I have sold into rail" | Stated negative, F3 | "I haven't sold into rail." |
| "I have carried a quota" | Stated negative, F2 | "I haven't carried a direct quota." |
| "I generated £4M" (closed or booked) | Inflated form of F4 | "roughly £4M of influenced revenue," at its own scope. The pack's observation: your material says influenced, not closed. |
| "I know how operators buy" | Inflated form of F1 | "bus and light rail network planning," at its own scope. The pack's observation: your material says planning, not buying decisions. |

## Sources

No provided document was used beyond the recruiter's email as you quoted it and your message. The market report was read by you and not attached, so it has not been used.

**Research tier: L1, searches 0 of 6, fetches 0 of 2 (the host refused search permission).**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Kelverton Rail values | unavailable | Refused: "Kelverton Rail values". Would have moved the values cheat sheet (dropped). |
| 2. Kelverton Rail interview process, partnerships | unavailable | Refused: "Kelverton Rail interview process partnerships". Would have moved loop structure and persona weights. |
| 3. Kelverton Rail strategy and recent news | unavailable | Refused: "Kelverton Rail scheduling software train operating companies news strategy". Would have moved the CO bank and the POV's differentiation. |
| 4. Deepa and Ross, public footprint | unavailable | No query sent. The host offers no search, and first names with title and company are enough to form one. Would have moved the interviewer read and the reverse questions. |
| 5. Representative partnerships-manager JD | unavailable | No query sent. The host offers no search. No JD was supplied, so the JD tier is empty. |

## Upgrade menu

- A job description, pasted as text → the fit-snapshot requirements become quoted [grounded] rows, and the requirement coverage table gets a row per requirement.
- The main findings from the market report you read, pasted as text → the POV theses are rebuilt against the report's shortlist, with the consensus item named and the divergence set out.
- Full names of Deepa and Ross → persona weights per panel member, an interviewer read, and reverse questions tied to their careers.
- Your CV → the fit-snapshot quotes become fuller, and B5 and D1 get more to build on.
- Deep research (L2): a strategy brief, published values, interview-process reports. This needs search permission on this host, and it adds up to six more searches and two fetches.
