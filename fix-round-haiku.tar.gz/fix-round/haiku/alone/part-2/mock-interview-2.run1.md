Your prep pack is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-alone-part-2-rooms-case-2-denied-612a7c43/6f4410b8-574e-4adc-b708-64327b06a578/scratchpad/atlas_freight_operations_manager_interview_pack.md`. I built it for a hiring-manager round, since your note didn't say who you're meeting. Web search was refused in this session, so the pack has nothing on Atlas Freight's values, interview process or strategy. It uses your JD and background only.

# Operations Manager, Atlas Freight: interview prep pack

**Role:** Operations Manager
**Company:** Atlas Freight (regional logistics, 800 employees, per your JD)
**Interviewer:** not given
**Round:** not given; built as a hiring-manager round

## How to use

- **Personas** describe how a question arrives. **Types** describe what is being scored.
- Type key: **JD** = a stated requirement; **EXP** = a claim from your history; **CASE** = a live problem; **CO** = company knowledge; **VAL** = values (none detected here).
- Guidance is scaffolding, not a script. Answer in your own words. Where a cell says "answer slot," give your real answer, either branch.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" (JD) | "7 years in warehouse and distribution ops" (your message); "ran the site's peak-season surge plan two years running" (your message) | medium | [grounded] | transferability | Your material shows warehouse and distribution operations and a peak plan. It does not show terminals or four sites. Words: "I've spent seven years in warehouse and distribution operations." Answer slot: if you have run terminal or multi-site operations, say where and what you were accountable for; if not, say so and say what you would need to see across four sites first. |
| F2 | "drive on-time performance and cost-per-shipment down" (JD) | "cut mis-pick rate 40% by redesigning the pick path" (your message) | medium | [grounded] | transferability | The figure you have is mis-pick rate, not on-time performance or cost-per-shipment. Lead with it in those terms. Answer slot: if you have moved either of the JD's metrics, name the measure and your part; if not, say so and name the measure you would watch first. |
| F3 | "lead a team of 12 supervisors" (JD) | "currently a senior shift manager over 3 supervisors" (your message) | medium | [grounded] | transferability | Your material shows three supervisors, not twelve. Words: "I'm a senior shift manager over three supervisors." Answer slot: if you have led more people, or directed managers through a layer below you, say whom and how; if three is your span, say that and say what you would do first with twelve. |
| F4 | "build reporting in Excel/Power BI" (JD) | "solid Excel" (your message) | low | [inferred] | discovery | "Solid" is a self-assessment and the material does not say what you built in Excel. Answer slot: name the reports you built in Excel, what they were for, and who used them; if you built none, say so. |
| F5 | "build reporting in Excel/Power BI" (JD) | "never used Power BI" (your message) | none | [grounded] | capability | Words: "I haven't used Power BI." Then how you would close it, said as a plan and never as a past. |
| F6 | "5+ years operations leadership required" (JD) | "7 years in warehouse and distribution ops" (your message); "currently a senior shift manager over 3 supervisors" (your message) | low | [inferred] | discovery | Seven years of operations is on record. The material does not say when leadership began. Answer slot: say when you first had people reporting to you, and in what role; if you had no reporting line before this role, say so and count only the time you can date. The length requirement is not a gate, so it is graded like the rest. |
| F7 | "Lean/Six Sigma a plus." (JD) | "green belt certified" (your message) | medium | [grounded] | none | No gap. The certificate is inspectable, so bring it; until you do, expect a probe. |

## Prohibited claims

Built here, from the fit snapshot, because no dossier was provided. Each entry names its basis; the honest form is what the banks use instead.

| Not coached | Basis | Honest form |
|---|---|---|
| Ran terminal operations across four sites | Inflated form of F1: the JD line widens "warehouse and distribution ops" | The F1 quote at its own scope. Pack observation, in analysis only: your material says warehouse and distribution, not terminals or four sites. |
| Leads twelve supervisors | Inflated form of F3 | "a senior shift manager over three supervisors" |
| Owns on-time performance or cost-per-shipment | Inflated form of F2 | The mis-pick figure in its own terms; B3's slot covers the rest |
| Knows Power BI, or built Power BI reporting | Negative you stated, F5 | Plain acknowledgment: "I haven't used Power BI." No slot. |
| Runs Lean or Six Sigma projects | Inflated form of F7 | "green belt certified" |
| Five years of operations leadership | Inflated form of F6: the material does not date leadership | "seven years in warehouse and distribution ops"; A4's slot |
| Set the peak plan's volume or staffing numbers | Incident or practice: the role usually involves it, and no quote says you did | "ran the site's peak-season surge plan two years running"; B4 asks what was yours |

## Persona table

Round type, relationship and interviewer are unknown, and no loop source was found, so the pack falls back to a generic archetype with a hiring-manager prior. That is a pattern, not a documented process for this company.

| Persona | How it shows up here | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Probes the three JD gaps: twelve supervisors, Power BI, terminals | 5 (A1 to A5). A hiring manager buys capability and de-risks gaps, and your gaps are the JD's headline lines. | Rehearse A1 until it is boring; hold the fact and concede the scale exactly. |
| Data-Driven Prober | Asks how the 40% and the peak plan were counted | 4 (B1 to B4). Your two figures are the probe magnets. | Defend-the-number slots in B1 and B2; say plainly what you do not know. |
| Case / Strategist | Live terminal problems | 3 (C1 to C3). Operations manager rounds often include a live problem, and the JD's two metrics give the structure. | Clarify, segment, metrics, risks. |
| Pressure / Stress | Time-boxed challenges: why you, how much was you, Power BI | 3 (D1 to D3). Manager rounds often interrupt. | Pause, restate, hold through two follow-ups. |
| Conversational | Opens with "walk me through," casual Lean question | 2 (E1, E2). Casual, but scored. | A 90-second arc; treat the Lean question as scored. |
| Peer Evaluator | Multi-site seams, credit, disagreement | 2 (P1, P2). The JD is multi-site, so peers may probe it. | Reciprocity framing; a disagreement scaffold. |
| Values / Behavioral | Not expected | 0. No values round was found and the generic archetype says no. | None. |

## Question banks

Ordered by weight. Depth follows weight: 5, 4, 3, 3, 2, 2.

### A. Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You're a senior shift manager over three supervisors now, and this role leads twelve. What's the step between those?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" (your message) | **Highest-ROI prep in this pack.** Hold the fact in the quote's terms: "I'm a senior shift manager over three supervisors." Concede the scale explicitly, in your words, and never fold on the fact. Answer slot: if you have led more people, or directed managers through a layer below you, say whom and how; if three is your span, say that and say what you would do first with twelve. Follow-up one, "what did you do with those three?": answer from your own record, and add no result. Follow-up two, "so you haven't done twelve?": say yes, then return to what you would do first. | F3 is the JD's headline requirement and the largest gap. The Skeptic will press it in some form, so a non-defensive answer is worth the most rehearsal here. |
| A2 | "The role builds reporting in Excel and Power BI. Where are you with both?" | JD | [grounded] "never used Power BI" (your message); "solid Excel" (your message) | Plain acknowledgment, which your own words support: "I haven't used Power BI." Answer slot for Excel: if you have built reports others acted on, name them and who used them; if not, say so and describe what you do in Excel. Then how you would close the Power BI gap, as a plan. In any follow-up, claim no Power BI skill. | F4 and F5 are the two halves of the reporting requirement. The Power BI negative is one you stated, so you can say it plainly. |
| A3 | "Your background is warehouse and distribution, and this role owns daily terminal operations across 4 sites. Which part would you be weakest at on day one?" | JD | [grounded] "7 years in warehouse and distribution ops" (your message) | Answer slot: name the part you would find hardest, in your own words, and what your first 30 days on it would look like. If you have worked in terminal or multi-site operations, say where and what you were accountable for; if you have not, say so and do not present it as covered. Name one part, not every gap. | The Skeptic's stem, aimed at F1's transferability gap. The answer has to come from your experience, so the slot allows that the premise may not hold. |
| A4 | "The role requires 5+ years of operations leadership. When did your leadership start?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" (your message) | Open answer: date the start of your first reporting line, and the role you held then, from your own record. Answer slot: if you can date it, say the date and role; if you had no reporting line before this role, say so and count only the time you can date. Do not round years up. | F6 is low confidence on leadership duration, so the question asks for a date rather than assuming one. |
| A5 | "Why this role, and why now?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" (your message) | The material gives no reason, so the reason is yours. Say it in one sentence about the job itself, then stop. If it concerns your current site, say it without naming people or problems. Do not offer a reason you do not hold. | The Skeptic's motive probe. The quote anchors where you are now, so your answer should be about moving from there. |

### B. Data-Driven Prober (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "How was the 40% reduction in mis-pick rate counted?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Answer slot, in your own words: how the figure was counted, what it is sensitive to, and which part of the change was yours to decide. If you do not know how it was counted, say so plainly and say who would. Do not reconstruct a method you cannot repeat under a second question. | The 40% is your headline figure and the probers' favorite target. These are the four defend-the-number slots. |
| B2 | "Which assumption behind that 40% would you defend least?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Weakest-assumption move: name it before they do, in your own words. If the figure was reported to you rather than counted by you, say so; that is a true answer. Hold through one follow-up, then concede the assumption you named, not the figure. | Turns a gotcha into a credibility gain. The assumption is yours to name; the pack does not name one. |
| B3 | "The role is about on-time performance and cost-per-shipment. What have you measured on either?" | JD | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Say the figure you have in its own terms: mis-pick rate. Answer slot: if you have measured on-time performance or cost-per-shipment, name the measure and your part in it; if not, say so and name the measure you would watch first. Do not describe either metric as yours unless you did. | F2: the JD's two headline metrics are not the metric in your material. This question checks that. |
| B4 | "What did the peak-season surge plan cover, and how did you know it was working?" | EXP | [grounded] "ran the site's peak-season surge plan two years running" (your message) | Story-mapped only on the quote's beats: the plan, the two years, and your role in running it. Answer slot: if you tracked something to know it worked, name what and who saw it; if not, say so and say what you relied on. Do not claim it succeeded unless you can show it. | The surge plan is your strongest operations story. The probe checks whether you can say how you know it worked. |

### C. Case / Strategist (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You take over four terminals. What do you need to know in week one before you change anything?" | CASE | [generic] | Clarify what the four sites are and what "on-time" means. Segment by site, shift and lane. Then approach, then metrics (on-time performance and cost-per-shipment, the two the JD names), then risks. Think aloud and name one premise you would test first. | A live problem from the JD's first line. The answer is structure, not history, so the guidance makes no claim about you. |
| C2 | "On-time performance fell at one site last month. How do you diagnose it?" | CASE | [generic] | Clarify the definition of on-time. Split by lane, shift and carrier. Check the data before acting. State one hypothesis early and say how you would test it. | Tests the JD's on-time line as a diagnosis. No claim about your past. |
| C3 | "What would you want to fix first in our cost-per-shipment, and why?" | CO | [generic] | No company material is in hand, so this stays generic. Name the cost driver you would check first and the data that would confirm it. Before the round, read what the company publishes about its network and rehearse against it. | Company research did not run. The question takes the JD's cost-per-shipment line, so it stays generic until you have the company's own material. |

### D. Pressure / Stress (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you for this role?" | JD | [grounded] "7 years in warehouse and distribution ops" (your message); "cut mis-pick rate 40% by redesigning the pick path" (your message) | Pause, restate, then anchor in the two quotes. Hold seven years and the pick-path result. Through two follow-ups, keep the position. If the interviewer names the three-supervisor gap, concede it in one specific sentence, in your own words, and do not fold on the operations record. | A time-boxed challenge aimed at the twelve-supervisor line. The hold matters more than length. |
| D2 | "That 40%: how much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Hold-then-concede. Answer by describing your part of the redesign in your own words. Answer slot: if part of the change was someone else's, say whose and which part; if you cannot separate it, say so plainly. Do not concede the result itself. | The attribution probe on F2's headline figure. A held position is only one you can describe. |
| D3 | "Power BI is in the job, and you haven't used it. Why should we believe you'll get there?" | JD | [grounded] "never used Power BI" (your message) | Hold the plain acknowledgment: "I haven't used Power BI." Do not fold into a skill claim. Then answer as a plan: what you would do, and by when, in your own words. Through two follow-ups, keep the honest statement and concede the timeline if it is uncertain. | F5 asked as a challenge. A held honest position beats a rehearsed skill claim that a second follow-up would break. |

### E. Conversational / Rapport (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "7 years in warehouse and distribution ops" (your message); "currently a senior shift manager over 3 supervisors" (your message); "cut mis-pick rate 40% by redesigning the pick path" (your message); "ran the site's peak-season surge plan two years running" (your message); "green belt certified" (your message) | A 90-second arc in this order: where you started, where you are now, the pick-path result, the peak plan, the green belt. Use only these sentences, in your own words. Stop at the green belt and ask a question back. | Rapport openers are scored. A scripted arc keeps the answer short and tied to quotes. |
| E2 | "What are you playing with in Lean these days?" | JD | [grounded] "green belt certified" (your message) | Answer slot: say where you have applied Lean or Six Sigma in your own work. If you have only the certification, say so and say what you would apply first. Do not describe a project you cannot name. | The JD's plus-skill, asked casually. Treat it as scored. |

### P. Peer Evaluator (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "If we disagree about priorities across 4 sites, how do you handle it?" | JD | [generic] | Selection scaffold: pick a time you disagreed with a peer over a shared resource, and how it resolved. If no such time comes to mind, say so plainly, then describe how you would approach it. Do not claim an outcome you cannot name. | The peer seam in the JD's multi-site line. No quoted sentence carries a disagreement, so the slot is a scaffold. |
| P2 | "How do you handle credit when work spans teams?" | EXP | [grounded] "ran the site's peak-season surge plan two years running" (your message) | Use the surge plan only if it crossed teams. If it did not, say so and give the nearest example. Say what was yours and what was not. | Peer evaluators probe credit-sharing. The plan is the one quoted story that might cross teams, and the answer must say whether it did. |

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| Own daily terminal operations across 4 sites | A3, C1, P1 |
| drive on-time performance and cost-per-shipment down | B3, C2, C3 |
| lead a team of 12 supervisors | A1, D1 |
| build reporting in Excel/Power BI | A2, D3 |
| 5+ years operations leadership required | A4 |
| Lean/Six Sigma a plus | E2 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "What does a successful first 90 days look like for someone taking on the four sites?" | Shows you are thinking in the role's scope, not its title. |
| 2 | "Which site is furthest from its on-time target, and what is the working theory?" | Sounds like someone who will walk in on day one. |
| 3 | "Is cost-per-shipment defined the same way across all four sites?" | A definitional question that a prober respects. |
| 4 | "What reporting do the sites use today, and what would the Power BI work need to replace?" | Turns your known gap into a scope question. |
| 5 | "How many of the twelve supervisors are new to their role, and how has turnover run?" | Shows you care about team health before you inherit the team. |

No interviewer profile exists, so no question ties to a career path. The round is not a peer round, so no reciprocity question is included.

## Sources

- **Provided:** your message, read as supplied: the JD text and your background. No CV file, no dossier.
- **Searches sent:** three, all refused, because web search permission was not granted in this session:
  1. "Atlas Freight regional logistics company values": refused
  2. "Atlas Freight operations manager interview process": refused
  3. "Atlas Freight logistics news 2026 strategy terminals": refused
- **Fetches:** none sent; no URL was returned.
- **Flag:** nothing about Atlas Freight was found, so nothing about the company is asserted here. The 800 employees and the four sites come from your JD only. "Atlas Freight" may be a common name, so nothing outside your inputs should be attributed to it.

**Research tier:** L1 requested. Searches 0 of 6 completed (3 refused); fetches 0 of 2.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Atlas Freight values | unavailable | Values cheat sheet: not built, since no values round was detected. Would have named the published values. |
| 2. Atlas Freight interview process, operations | unavailable | Loop structure: persona weights run on the hiring-manager prior, not a documented loop. |
| 3. Atlas Freight strategy / recent news | unavailable | CO bank: C3 is generic. |
| 4. Interviewer name + company | n/a | No name was given, so there was no query to form. |
| 5. Representative operations manager JD | skipped | The JD you supplied fixes the fit snapshot. |

## Upgrade menu

- Who you are meeting and the round type → recomputed persona weights and a tailored reverse question.
- The company's values page, pasted → a values cheat sheet built on the published values, by name.
- The recruiter's note on the interview format → the loop structure, replacing the flat weights.
- Company strategy material or recent news, pasted → C3 and a CO bank move from [generic] to [grounded].
- Your green belt certificate → F7 becomes inspectable proof.
- Your mis-pick measurement notes → B1 and B2 can be rebuilt on the sentences you quote.
- Any terminal or multi-site experience, with dates → F1 and A3's answer slots.
- The date you first had people reporting to you → F6 moves from low confidence, and A4 can be answered from it.
- The interviewer's name → an interviewer read from public professional footprint.

---

Two offers, neither pushed:
- Want a drill? I can play the Skeptic on A1, the highest-ROI question in the pack. Say the word and I'll run it.
- I can also save a `tuesday-dossier.md` recording the gaps this prep exposed (leadership span, Power BI, terminals), to carry into later sessions.

If you'd like the pack as a Word document, say so and I'll convert it.

Who are you meeting, what round is it (your future manager, a peer, or someone else), and how many prep days do you have? The answer reweights the banks and sets the schedule.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: atlas_freight_operations_manager_interview_pack.md -----
# Operations Manager, Atlas Freight: interview prep pack

**Role:** Operations Manager
**Company:** Atlas Freight (regional logistics, 800 employees, per your JD)
**Interviewer:** not given
**Round:** not given; built as a hiring-manager round

## How to use

- **Personas** describe how a question arrives. **Types** describe what is being scored.
- Type key: **JD** = a stated requirement; **EXP** = a claim from your history; **CASE** = a live problem; **CO** = company knowledge; **VAL** = values (none detected here).
- Guidance is scaffolding, not a script. Answer in your own words. Where a cell says "answer slot," give your real answer, either branch.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" (JD) | "7 years in warehouse and distribution ops" (your message); "ran the site's peak-season surge plan two years running" (your message) | medium | [grounded] | transferability | Your material shows warehouse and distribution operations and a peak plan. It does not show terminals or four sites. Words: "I've spent seven years in warehouse and distribution operations." Answer slot: if you have run terminal or multi-site operations, say where and what you were accountable for; if not, say so and say what you would need to see across four sites first. |
| F2 | "drive on-time performance and cost-per-shipment down" (JD) | "cut mis-pick rate 40% by redesigning the pick path" (your message) | medium | [grounded] | transferability | The figure you have is mis-pick rate, not on-time performance or cost-per-shipment. Lead with it in those terms. Answer slot: if you have moved either of the JD's metrics, name the measure and your part; if not, say so and name the measure you would watch first. |
| F3 | "lead a team of 12 supervisors" (JD) | "currently a senior shift manager over 3 supervisors" (your message) | medium | [grounded] | transferability | Your material shows three supervisors, not twelve. Words: "I'm a senior shift manager over three supervisors." Answer slot: if you have led more people, or directed managers through a layer below you, say whom and how; if three is your span, say that and say what you would do first with twelve. |
| F4 | "build reporting in Excel/Power BI" (JD) | "solid Excel" (your message) | low | [inferred] | discovery | "Solid" is a self-assessment and the material does not say what you built in Excel. Answer slot: name the reports you built in Excel, what they were for, and who used them; if you built none, say so. |
| F5 | "build reporting in Excel/Power BI" (JD) | "never used Power BI" (your message) | none | [grounded] | capability | Words: "I haven't used Power BI." Then how you would close it, said as a plan and never as a past. |
| F6 | "5+ years operations leadership required" (JD) | "7 years in warehouse and distribution ops" (your message); "currently a senior shift manager over 3 supervisors" (your message) | low | [inferred] | discovery | Seven years of operations is on record. The material does not say when leadership began. Answer slot: say when you first had people reporting to you, and in what role; if you had no reporting line before this role, say so and count only the time you can date. The length requirement is not a gate, so it is graded like the rest. |
| F7 | "Lean/Six Sigma a plus." (JD) | "green belt certified" (your message) | medium | [grounded] | none | No gap. The certificate is inspectable, so bring it; until you do, expect a probe. |

## Prohibited claims

Built here, from the fit snapshot, because no dossier was provided. Each entry names its basis; the honest form is what the banks use instead.

| Not coached | Basis | Honest form |
|---|---|---|
| Ran terminal operations across four sites | Inflated form of F1: the JD line widens "warehouse and distribution ops" | The F1 quote at its own scope. Pack observation, in analysis only: your material says warehouse and distribution, not terminals or four sites. |
| Leads twelve supervisors | Inflated form of F3 | "a senior shift manager over three supervisors" |
| Owns on-time performance or cost-per-shipment | Inflated form of F2 | The mis-pick figure in its own terms; B3's slot covers the rest |
| Knows Power BI, or built Power BI reporting | Negative you stated, F5 | Plain acknowledgment: "I haven't used Power BI." No slot. |
| Runs Lean or Six Sigma projects | Inflated form of F7 | "green belt certified" |
| Five years of operations leadership | Inflated form of F6: the material does not date leadership | "seven years in warehouse and distribution ops"; A4's slot |
| Set the peak plan's volume or staffing numbers | Incident or practice: the role usually involves it, and no quote says you did | "ran the site's peak-season surge plan two years running"; B4 asks what was yours |

## Persona table

Round type, relationship and interviewer are unknown, and no loop source was found, so the pack falls back to a generic archetype with a hiring-manager prior. That is a pattern, not a documented process for this company.

| Persona | How it shows up here | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Probes the three JD gaps: twelve supervisors, Power BI, terminals | 5 (A1 to A5). A hiring manager buys capability and de-risks gaps, and your gaps are the JD's headline lines. | Rehearse A1 until it is boring; hold the fact and concede the scale exactly. |
| Data-Driven Prober | Asks how the 40% and the peak plan were counted | 4 (B1 to B4). Your two figures are the probe magnets. | Defend-the-number slots in B1 and B2; say plainly what you do not know. |
| Case / Strategist | Live terminal problems | 3 (C1 to C3). Operations manager rounds often include a live problem, and the JD's two metrics give the structure. | Clarify, segment, metrics, risks. |
| Pressure / Stress | Time-boxed challenges: why you, how much was you, Power BI | 3 (D1 to D3). Manager rounds often interrupt. | Pause, restate, hold through two follow-ups. |
| Conversational | Opens with "walk me through," casual Lean question | 2 (E1, E2). Casual, but scored. | A 90-second arc; treat the Lean question as scored. |
| Peer Evaluator | Multi-site seams, credit, disagreement | 2 (P1, P2). The JD is multi-site, so peers may probe it. | Reciprocity framing; a disagreement scaffold. |
| Values / Behavioral | Not expected | 0. No values round was found and the generic archetype says no. | None. |

## Question banks

Ordered by weight. Depth follows weight: 5, 4, 3, 3, 2, 2. Types are one token each; the primary type is listed.

### A. Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You're a senior shift manager over three supervisors now, and this role leads twelve. What's the step between those?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" (your message) | **Highest-ROI prep in this pack.** Hold the fact in the quote's terms: "I'm a senior shift manager over three supervisors." Concede the scale explicitly, in your words, and never fold on the fact. Answer slot: if you have led more people, or directed managers through a layer below you, say whom and how; if three is your span, say that and say what you would do first with twelve. Follow-up one, "what did you do with those three?": answer from your own record, and add no result. Follow-up two, "so you haven't done twelve?": say yes, then return to what you would do first. | F3 is the JD's headline requirement and the largest gap. The Skeptic will press it in some form, so a non-defensive answer is worth the most rehearsal here. |
| A2 | "The role builds reporting in Excel and Power BI. Where are you with both?" | JD | [grounded] "never used Power BI" (your message); "solid Excel" (your message) | Plain acknowledgment, which your own words support: "I haven't used Power BI." Answer slot for Excel: if you have built reports others acted on, name them and who used them; if not, say so and describe what you do in Excel. Then how you would close the Power BI gap, as a plan. In any follow-up, claim no Power BI skill. | F4 and F5 are the two halves of the reporting requirement. The Power BI negative is one you stated, so you can say it plainly. |
| A3 | "Your background is warehouse and distribution, and this role owns daily terminal operations across 4 sites. Which part would you be weakest at on day one?" | JD | [grounded] "7 years in warehouse and distribution ops" (your message) | Answer slot: name the part you would find hardest, in your own words, and what your first 30 days on it would look like. If you have worked in terminal or multi-site operations, say where and what you were accountable for; if you have not, say so and do not present it as covered. Name one part, not every gap. | The Skeptic's stem, aimed at F1's transferability gap. The answer has to come from your experience, so the slot allows that the premise may not hold. |
| A4 | "The role requires 5+ years of operations leadership. When did your leadership start?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" (your message) | Open answer: date the start of your first reporting line, and the role you held then, from your own record. Answer slot: if you can date it, say the date and role; if you had no reporting line before this role, say so and count only the time you can date. Do not round years up. | F6 is low confidence on leadership duration, so the question asks for a date rather than assuming one. |
| A5 | "Why this role, and why now?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" (your message) | The material gives no reason, so the reason is yours. Say it in one sentence about the job itself, then stop. If it concerns your current site, say it without naming people or problems. Do not offer a reason you do not hold. | The Skeptic's motive probe. The quote anchors where you are now, so your answer should be about moving from there. |

### B. Data-Driven Prober (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "How was the 40% reduction in mis-pick rate counted?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Answer slot, in your own words: how the figure was counted, what it is sensitive to, and which part of the change was yours to decide. If you do not know how it was counted, say so plainly and say who would. Do not reconstruct a method you cannot repeat under a second question. | The 40% is your headline figure and the probers' favorite target. These are the four defend-the-number slots. |
| B2 | "Which assumption behind that 40% would you defend least?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Weakest-assumption move: name it before they do, in your own words. If the figure was reported to you rather than counted by you, say so; that is a true answer. Hold through one follow-up, then concede the assumption you named, not the figure. | Turns a gotcha into a credibility gain. The assumption is yours to name; the pack does not name one. |
| B3 | "The role is about on-time performance and cost-per-shipment. What have you measured on either?" | JD | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Say the figure you have in its own terms: mis-pick rate. Answer slot: if you have measured on-time performance or cost-per-shipment, name the measure and your part in it; if not, say so and name the measure you would watch first. Do not describe either metric as yours unless you did. | F2: the JD's two headline metrics are not the metric in your material. This question checks that. |
| B4 | "What did the peak-season surge plan cover, and how did you know it was working?" | EXP | [grounded] "ran the site's peak-season surge plan two years running" (your message) | Story-mapped only on the quote's beats: the plan, the two years, and your role in running it. Answer slot: if you tracked something to know it worked, name what and who saw it; if not, say so and say what you relied on. Do not claim it succeeded unless you can show it. | The surge plan is your strongest operations story. The probe checks whether you can say how you know it worked. |

### C. Case / Strategist (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You take over four terminals. What do you need to know in week one before you change anything?" | CASE | [generic] | Clarify what the four sites are and what "on-time" means. Segment by site, shift and lane. Then approach, then metrics (on-time performance and cost-per-shipment, the two the JD names), then risks. Think aloud and name one premise you would test first. | A live problem from the JD's first line. The answer is structure, not history, so the guidance makes no claim about you. |
| C2 | "On-time performance fell at one site last month. How do you diagnose it?" | CASE | [generic] | Clarify the definition of on-time. Split by lane, shift and carrier. Check the data before acting. State one hypothesis early and say how you would test it. | Tests the JD's on-time line as a diagnosis. No claim about your past. |
| C3 | "What would you want to fix first in our cost-per-shipment, and why?" | CO | [generic] | No company material is in hand, so this stays generic. Name the cost driver you would check first and the data that would confirm it. Before the round, read what the company publishes about its network and rehearse against it. | Company research did not run (see Sources). The question takes the JD's cost-per-shipment line, so it stays generic until you have the company's own material. |

### D. Pressure / Stress (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you for this role?" | JD | [grounded] "7 years in warehouse and distribution ops" (your message); "cut mis-pick rate 40% by redesigning the pick path" (your message) | Pause, restate, then anchor in the two quotes. Hold seven years and the pick-path result. Through two follow-ups, keep the position. If the interviewer names the three-supervisor gap, concede it in one specific sentence, in your own words, and do not fold on the operations record. | A time-boxed challenge aimed at the twelve-supervisor line. The hold matters more than length. |
| D2 | "That 40%: how much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Hold-then-concede. Answer by describing your part of the redesign in your own words. Answer slot: if part of the change was someone else's, say whose and which part; if you cannot separate it, say so plainly. Do not concede the result itself. | The attribution probe on F2's headline figure. A held position is only one you can describe. |
| D3 | "Power BI is in the job, and you haven't used it. Why should we believe you'll get there?" | JD | [grounded] "never used Power BI" (your message) | Hold the plain acknowledgment: "I haven't used Power BI." Do not fold into a skill claim. Then answer as a plan: what you would do, and by when, in your own words. Through two follow-ups, keep the honest statement and concede the timeline if it is uncertain. | F5 asked as a challenge. A held honest position beats a rehearsed skill claim that a second follow-up would break. |

### E. Conversational / Rapport (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "7 years in warehouse and distribution ops" (your message); "currently a senior shift manager over 3 supervisors" (your message); "cut mis-pick rate 40% by redesigning the pick path" (your message); "ran the site's peak-season surge plan two years running" (your message); "green belt certified" (your message) | A 90-second arc in this order: where you started, where you are now, the pick-path result, the peak plan, the green belt. Use only these sentences, in your own words. Stop at the green belt and ask a question back. | Rapport openers are scored. A scripted arc keeps the answer short and tied to quotes. |
| E2 | "What are you playing with in Lean these days?" | JD | [grounded] "green belt certified" (your message) | Answer slot: say where you have applied Lean or Six Sigma in your own work. If you have only the certification, say so and say what you would apply first. Do not describe a project you cannot name. | The JD's plus-skill, asked casually. Treat it as scored. |

### P. Peer Evaluator (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "If we disagree about priorities across 4 sites, how do you handle it?" | JD | [generic] | Selection scaffold: pick a time you disagreed with a peer over a shared resource, and how it resolved. If no such time comes to mind, say so plainly, then describe how you would approach it. Do not claim an outcome you cannot name. | The peer seam in the JD's multi-site line. No quoted sentence carries a disagreement, so the slot is a scaffold. |
| P2 | "How do you handle credit when work spans teams?" | EXP | [grounded] "ran the site's peak-season surge plan two years running" (your message) | Use the surge plan only if it crossed teams. If it did not, say so and give the nearest example. Say what was yours and what was not. | Peer evaluators probe credit-sharing. The plan is the one quoted story that might cross teams, and the answer must say whether it did. |

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| Own daily terminal operations across 4 sites | A3, C1, P1 |
| drive on-time performance and cost-per-shipment down | B3, C2, C3 |
| lead a team of 12 supervisors | A1, D1 |
| build reporting in Excel/Power BI | A2, D3 |
| 5+ years operations leadership required | A4 |
| Lean/Six Sigma a plus | E2 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "What does a successful first 90 days look like for someone taking on the four sites?" | Shows you are thinking in the role's scope, not its title. |
| 2 | "Which site is furthest from its on-time target, and what is the working theory?" | Sounds like someone who will walk in on day one. |
| 3 | "Is cost-per-shipment defined the same way across all four sites?" | A definitional question that a prober respects. |
| 4 | "What reporting do the sites use today, and what would the Power BI work need to replace?" | Turns your known gap into a scope question. |
| 5 | "How many of the twelve supervisors are new to their role, and how has turnover run?" | Shows you care about team health before you inherit the team. |

No interviewer profile exists, so no question ties to a career path. The round is not a peer round, so no reciprocity question is included.

## Sources

- **Provided:** your message, read as supplied: the JD text and your background. No CV file, no dossier.
- **Searches sent:** three, all refused, because web search permission was not granted in this session:
  1. "Atlas Freight regional logistics company values": refused
  2. "Atlas Freight operations manager interview process": refused
  3. "Atlas Freight logistics news 2026 strategy terminals": refused
- **Fetches:** none sent; no URL was returned.
- **Flag:** nothing about Atlas Freight was found, so nothing about the company is asserted here. The 800 employees and the four sites come from your JD only. "Atlas Freight" may be a common name, so nothing outside your inputs should be attributed to it.

**Research tier:** L1 requested. Searches 0 of 6 completed (3 refused); fetches 0 of 2.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Atlas Freight values | unavailable | Values cheat sheet: not built, since no values round was detected. Would have named the published values. |
| 2. Atlas Freight interview process, operations | unavailable | Loop structure: persona weights run on the hiring-manager prior, not a documented loop. |
| 3. Atlas Freight strategy / recent news | unavailable | CO bank: C3 is generic. |
| 4. Interviewer name + company | n/a | No name was given, so there was no query to form. |
| 5. Representative operations manager JD | skipped | The JD you supplied fixes the fit snapshot. |

## Upgrade menu

- Who you are meeting and the round type → recomputed persona weights and a tailored reverse question.
- The company's values page, pasted → a values cheat sheet built on the published values, by name.
- The recruiter's note on the interview format → the loop structure, replacing the flat weights.
- Company strategy material or recent news, pasted → C3 and a CO bank move from [generic] to [grounded].
- Your green belt certificate → F7 becomes inspectable proof.
- Your mis-pick measurement notes → B1 and B2 can be rebuilt on the sentences you quote.
- Any terminal or multi-site experience, with dates → F1 and A3's answer slots.
- The date you first had people reporting to you → F6 moves from low confidence, and A4 can be answered from it.
- The interviewer's name → an interviewer read from public professional footprint.
