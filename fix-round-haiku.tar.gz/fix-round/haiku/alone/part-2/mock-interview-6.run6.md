I couldn't run web research, so the pack is built from your message alone. Your role summary isn't a full job posting, so I've treated its lines as the requirements.
Your prep pack is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-alone-part-2-rooms-case-6-denied-8ca5c491/1f361179-c9a5-4b5c-b256-6dc2aa42cc9c/scratchpad/larkfield_engineering-manager_interview_pack.md`. It covers all three rounds as one loop, with a shared fit snapshot and a mini-pack per round. It is built without web research, because the search permission was refused.

# Larkfield Systems, Engineering Manager: interview prep pack

**Loop:** three rounds. Hiring manager, Director of Engineering, Tuesday, 45 min. Panel of two staff engineers and a product manager, Thursday, 60 min. VP Engineering, following Monday, 30 min, described by the recruiter as "values and leadership philosophy." No names given for any interviewer.

**Built without web research.** The search permission was refused for all three checks. Company facts are therefore absent or generic, and the Sources section says where.

## How to use this pack

Personas describe how each question is asked. Types describe what it scores:

- **VAL**: behavioural and values alignment
- **EXP**: deep-dive on your own experience
- **JD**: the role's stated requirements
- **CO**: company and strategy knowledge (none in this pack, because no research ran)
- **CASE**: a live problem, which asks about no past of yours

Question IDs: **A** = Tuesday hiring manager, **B** = Thursday panel, **C** = Monday VP.

Guidance is scaffolding, not a script. An **answer slot** is an instruction for the interview, not a question to me. It asks for no reply here. Say the honest branch when the true answer is the other one.

## Sources

**Provided documents:** your message (the role summary, your background, the three rounds, the recruiter's "values and leadership philosophy"). **Not provided:** a full job posting, a values page, interviewer names, recruiter notes on focus areas.

**Research tier:** L1, searches 3 of 6, fetches 0 of 2. Every call was refused, so none returned a result.

- "Larkfield Systems values": refused
- "Larkfield Systems interview process engineering manager": refused
- "Larkfield Systems strategy industrial IoT device management news": refused

I did not retry the refused calls.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Larkfield Systems values | unavailable | The values cheat sheet (section 10). Its condition, published values in hand, is unmet, so the section is dropped. |
| 2. Larkfield Systems interview process, engineering manager | unavailable | Loop detail. Your three named rounds already establish the loop, so this would have checked detail, not structure. |
| 3. Larkfield Systems strategy and recent news | unavailable | The CO bank and any strategy-grounded CASE question. None written, so the CASE questions are generic. |
| 4. Interviewer name | n/a | No names given, so there was no query to form. |
| 5. Representative engineering manager JD | unavailable | JD-tagged questions beyond the lines of your role summary. |

**Loop:** established by your message, which names each round and who runs it. No archetype fallback was needed.

**Values-style round:** detected from the recruiter's words on the Monday round. No published values are in hand, so Round C's VAL questions are themed on "values and leadership philosophy," not on named values.

## The fit snapshot

Requirements come from your role summary. Evidence quotes are your own sentences.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" (your role summary) | "9 years engineering, 3 as a team lead of 6" (your message) | medium | [grounded] | transferability | Your material shows one team of six for three years, not two squads. Bridge in those words: "For three years I was a team lead of six." Expect a probe on scale. Answer slot: if you have run work across two groups at once, say how and what you decided; if you have not, say so, and give your plan for splitting ownership across two squads. |
| F2 | "own delivery, hiring and growth for 11 engineers" (your role summary, hiring) | "I run our hiring loop for backend roles — about 40 interviews last year." (your message) | medium | [grounded] | transferability | Your material shows hiring for backend roles, and about 40 interviews, not hires. Bridge: "I run our hiring loop for backend roles, about 40 interviews last year." Expect a probe on whether the role spans more than backend. Answer slot: if you have hired for a non-backend role, say what you did; if you have not, say so. |
| F3 | "own delivery, hiring and growth for 11 engineers" (your role summary, growth) | none given | none | [grounded] | discovery | Your material does not show growth: promotions, development, or engineers you moved on. Answer slot: name an engineer you helped grow and what you did; if none comes to mind, say so and say how you would start. |
| F4 | "own delivery" (your role summary) | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." (your message) | medium | [grounded] | none | No gap; the quote reaches delivery in role-relevant terms. Expect a probe on the 60%, since no artifact is shown. The defend-the-number slots sit in A7. |
| F5 | "partner with hardware and product on roadmap" (your role summary, hardware) | "I've never managed managers and never owned a hardware-adjacent roadmap." (your message) | none | [grounded] | capability | The stated negative is the words: "I've never owned a hardware-adjacent roadmap." Then how you would learn it, said as a plan and never as a past. |
| F6 | "partner with hardware and product on roadmap" (your role summary, product and roadmap) | "I pushed a reliability quarter through against roadmap pressure" (your message) | medium | [grounded] | transferability | Your material shows you holding a roadmap line under pressure. It does not show partnering with product or hardware on a roadmap. Bridge at the quote's own scope: "I pushed a reliability quarter through against roadmap pressure." Answer slot: how you worked with product on that quarter; if you did not, say so. |
| F7 | Leading managers across the two squads (role-family pattern, not in your role summary) | "I've never managed managers" (your message) | none | [grounded] | capability | The stated negative is the words: "I've never managed managers." Then the plan for learning it, said as a plan. No answer slot, because your own negative is the answer. |

**Note on the table.** F2 is `transferability`, not `presentation`, because the quote is backend-only and the requirement is not. F3 is `discovery` because the material is silent, not because you lack growth. F5 and F7 are `capability` only because you stated the absence yourself.

## Prohibited claims

Built locally from the snapshot. No dossier was provided. These are the claims this pack will not coach, even though they are the ones a candidate reaches for under pressure.

| Not coached | Basis | Honest form |
|---|---|---|
| "I led two squads," "I've led two teams" | Inflated form of F1 | "For three years I was a team lead of six." Limit, as the pack's own observation: your material shows one team. |
| "I grew engineers into promotions," "I developed people who moved up" | Inflated form of F3, no quote | Nothing to say here. A3's slot and A4's honest branch cover it. |
| "I built the hiring function," "I hired 40 engineers" | Inflated form of F2 | The quote at its scope: about 40 interviews on the backend loop. |
| "I cut on-call by 60%" as your sole work | Inflated form of F4 | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." |
| "I've owned a hardware-adjacent roadmap" | Your stated negative, F5 | Plain acknowledgment: "I've never owned a hardware-adjacent roadmap." |
| "I've managed managers" | Your stated negative, F7 | Plain acknowledgment: "I've never managed managers." |

## Coverage

| Requirement | Questions |
|---|---|
| Lead two squads (F1) | A1, C6 |
| Own delivery (F4) | A7, B4 |
| Hiring (F2) | A4, B5 |
| Growth for 11 engineers (F3) | A4 (answer slot only, since no quote carries growth) |
| Partner with hardware on the roadmap (F5) | A3, B8 |
| Partner with product on the roadmap (F6) | B1, B6 |
| Leading managers (F7) | A2, C4, C8 |
| Values and leadership philosophy (recruiter's words) | C1, C2, C3, C5 |

No CO questions: no research succeeded, so none could be grounded in strategy. CASE questions are generic and labelled so.

---

## Round A: hiring manager (Director of Engineering), Tuesday, 45 min

**Persona weights**

| Persona | Weight | Depth | Why |
|---|---|---|---|
| Skeptic | high | 4 (A1–A4) | A hiring manager buys capability and derisks gaps. F1, F5 and F7 are the gaps they will press. |
| Case/Strategist | high | 2 (A5–A6) | Expect a live problem on the actual roadmap. |
| Data-Driven Prober | medium | 1 (A7) | The 60% and the 40 interviews are your only numbers. |
| Pressure | low | 1 (A8) | A time-boxed "why you" is a common opener for this relationship. |

Conversational is not weighted in this round. Its arc sits in C7.

**Question bank, by persona**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have led a team of six. What changes when the job is two squads?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6" (your message); [grounded] "Lead two squads building device-management services" (your role summary) | Start with the team of six, in those words: what it taught you about delivery. Then say what changes at two. That is your reasoning, not a claim about your past. Answer slot: if you have run work across two groups at once, say how and what you decided; if you have not, say so, and give your plan for splitting ownership across two squads. Hold to the scale in the quote. | F1 is transferability. The scale step is the likeliest probe. |
| A2 | "How would you coach a senior engineer who is strong technically but slow to delegate?" | JD | [generic] question; [grounded] "I've never managed managers" (your message) | Give the coaching approach you would use, in your words. If the managers question follows, say plainly: "I've never managed managers." Then how you would learn it, as a plan. Hold one follow-up. | F7 is the gap this round is most likely to raise. The plain acknowledgment is ready before the probe. |
| A3 | "Which hardware-adjacent roadmap have you owned?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." (your message); [grounded] "I pushed a reliability quarter through against roadmap pressure" (your message) | **Highest-ROI prep in this pack.** First branch: say it plainly. "I've never owned a hardware-adjacent roadmap." Pause. Second branch, if the question presses: the nearest thing your material carries is the reliability quarter, at its own scope. Then the plan for hardware partnership, as a plan. Hold through two follow-ups by returning to the quarter and the plan. Never describe a hardware roadmap you did not own. | F5 is a capability gap in the one area the role names. This objection is almost certain in some form. Rehearsing it until it is boring is what turns it into a credible answer. |
| A4 | "Tell me about an engineer you've helped grow. What did you do, and how did you know it worked?" | JD | [generic] open prompt, theme from your role summary's "growth"; [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." (your message) | Selection scaffold: pick an engineer whose work you changed, a change you made and what you saw. Honest branch: if no such engineer comes to mind, say so plainly, then give the nearest thing your material carries: running the backend hiring loop, about 40 interviews. | F3 is discovery. This is where the gap sits, so the honest answer should be ready before the probe arrives. |
| A5 | "Two device-fleet services miss a rollout date because the hardware team sends firmware late. Walk me through your first week." | CASE | [generic] | Clarify the date, the blast radius and the firmware contract. State the objective. Segment the fleet by hardware variant and region. Give options: hold, partial rollout, ship behind a flag. Name the metrics and risks. Challenge one premise: that the date is fixed. Keep it to 90–120 seconds. | A live problem from the role's own hardware seam. It asks about no past of yours. |
| A6 | "Product wants a feature next quarter, and the squads' top ask is reliability debt. How do you decide?" | CASE | [generic] question; [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." (your message), used only if you tell that story | Clarify the horizon and the cost of each option. State your decision rule. If you use your own example, tell the reliability quarter in its quoted beats: the pressure, the push, the 60% after. Do not stretch the decision to the whole roadmap. | The role's roadmap partnership. The link to F4 and F6 uses only the quote. |
| A7 | "Walk me through how the 60% on-call figure was counted." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." (your message) | Say what you can, in your words. Name the assumption behind the figure you would defend least, before they do. Say what was yours: the push. Answer slot: how it was counted. If you know, say it. If you do not, say so plainly. Do not name a method. | F4 is medium, and a figure raises the defend-the-number slots. |
| A8 | "Sixty seconds: why you over a candidate who has managed managers?" | JD | [grounded] "I've never managed managers" (your message); [grounded] "I pushed a reliability quarter through against roadmap pressure" (your message) | Pause and restate the question in your words. Concede the managers gap in one sentence. Then give what you have: the team of six, the quarter. Hold through two follow-ups. Concede the gap; do not fold the case. | Pressure is low weight here, but the concession has to come in one sentence. |

**Reverse questions**

1. "What would make the first six months a clear success for you?" Why it lands: it shows you plan to be measured against their own expectations.
2. "Which of the two squads worries you most right now, and what has it cost?" Why it lands: it shows you read the team before you walk in.
3. "How do you want to hear that a squad is in trouble, before or after it is visible?" Why it lands: it maps to your reliability record.
4. "What has made earlier engineering managers in this org struggle?" Why it lands: an honest question with a pattern as its answer.
5. "What does the hardware team expect from an engineering manager that a product team would not?" Why it lands: it tests the seam directly and sets up A3.
6. "What would you want the next person in this seat to do differently?" Why it lands: it invites them to name the job's real difficulty.

---

## Round B: panel (two staff engineers, product manager), Thursday, 60 min

**Persona weights.** Panel member names are unknown, so the personas are blended per relationship. Assignment per member waits on names.

| Persona | Weight | Depth | Why |
|---|---|---|---|
| Peer Evaluator | high | 3 (B1–B3) | Two staff engineers price what you cost and add to their work. |
| Data-Driven Prober | high | 2 (B4–B5) | Staff engineers check numbers. |
| Case/Strategist | medium | 2 (B6–B7) | The product manager runs roadmap trade-offs. |
| Skeptic | low | 1 (B8) | Carried over from the hiring round. |

Pressure and Conversational are not weighted in this round.

**Question bank, by persona**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our teams sit side by side. Where's the seam between your squads and firmware, and what happens when you disagree?" | JD | [generic] stem; [grounded] "I pushed a reliability quarter through against roadmap pressure" (your message) | State the principle first: who decides what when firmware and cloud disagree. Then the quarter: the pressure and the push. Do not claim to know their seam. Answer slot: if you disagreed with a peer team and what it cost, say so; if you did not, say so and say what you would do. | F6, and the seam is named in your role summary. Peers test this collegially. |
| B2 | "How do you handle credit when a delivery spans two teams?" | JD | [generic] stem; [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through" (your message) | Say who did what, in your words. The push was yours to say. The 60% followed it. Name others you know carried parts. Answer slot: who else carried the work. | Credit probes come collegially from peers. |
| B3 | "What would you need from our staff engineers to get a reliability workstream into the plan?" | JD | [grounded] "I pushed a reliability quarter through against roadmap pressure" (your message) | Reciprocity first: what you would bring to their teams. Then what you need. Use the quarter as the example of what you would push for. | Peer panels weight what the hire contributes, not only what they need. |
| B4 | "What in the on-call figure would you defend least?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." (your message) | Name the weakest assumption behind the figure in your own words, before they do. Say plainly what the figure cannot tell them. Say what was yours. Answer slot: how it was counted. If you do not know, say so. | Same figure as A7, a different probe. Rehearse them separately. |
| B5 | "How do you know your interview loop works?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." (your message) | Say what you watched, in your words. If you tracked nothing, say so plainly, then say how you would check. Answer slot: if you tracked outcomes, name what; if you did not, say so. | "About 40 interviews" counts interviews, not hires. Do not stretch it. |
| B6 | "A hardware dependency has slipped two quarters. Product still wants the feature. What do you do?" | CASE | [generic] question; [grounded] "I pushed a reliability quarter through against roadmap pressure" (your message), as the nearest precedent only | Clarify what the dependency gates and what the feature costs, and to whom. Options: re-scope, split, hold. Name the risks. Say what you would tell product first. | The roadmap partnership. The link to your past uses only the quote. |
| B7 | "Update success on the fleet fell eight points week over week. Diagnose it." | CASE | [generic] | Clarify the scope and what changed. Segment by hardware variant, region, firmware version and rollout wave. Pick metrics that separate cause from noise. Ask for the logs before theorising. | A live problem. The panel's engineers will test structure. |
| B8 | "Which part of this roadmap would you be weakest at on day one?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." (your message) | Plain acknowledgment: "I've never owned a hardware-adjacent roadmap." Then your day-one plan, said as a plan. Do not claim the seam is known. | F5 again, from the other side. The panel will likely check the same gap. |

**Reverse questions**

1. "What could a new engineering manager do in the first month that would genuinely help your team?" Why it lands: it is the reciprocity question for a peer panel.
2. "Where does the firmware-to-cloud seam cause the most rework today?" Why it lands: it invites them to name the seam, and shows you are thinking about it.
3. "When engineering and product disagree on the roadmap, how is it actually decided?" Why it lands: it tests the role's real decision path.
4. "What did the last engineering manager leave undone?" Why it lands: a frank answer tells you what they most need.
5. "Which reliability work do you wish had been planned earlier?" Why it lands: it lets the staff engineers name their own ask.

---

## Round C: VP Engineering, Monday, 30 min

**Persona weights**

| Persona | Weight | Depth | Why |
|---|---|---|---|
| Values/Behavioral | high | 3 (C1–C3) | The recruiter named this round for "values and leadership philosophy." |
| Pressure | high | 2 (C4–C5) | A skip-level prior: composure and time-boxed answers. |
| Case/Strategist | medium | 1 (C6) | Strategy-heavy altitude. |
| Conversational | low | 1 (C7) | The opening arc. |
| Skeptic | low | 1 (C8) | The managers gap at this altitude. |

**Values cheat sheet:** dropped. No published values are in hand, and section 10 requires them.

**Question bank, by persona**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] open prompt, theme from the recruiter's words; [grounded] "I pushed a reliability quarter through against roadmap pressure" (your message) | Selection scaffold: a time you held a position under pressure from someone senior, with a named stake, a moment you did not fold, and a relationship intact at the end. Nearest thing your material carries: the reliability quarter, in its beats: the roadmap pressure, the push, the 60% after. If no such time comes to mind, say so plainly, then give that. | The recruiter named values for this round. The hard truth has to land, and this is the answer the pack can support. |
| C2 | "What's your leadership philosophy, and what decision shows it?" | VAL | [generic] question; [grounded] "9 years engineering, 3 as a team lead of 6" (your message) | Give one principle you would defend, in one sentence. Then one decision from your record that shows it, in your words. Honest branch: if no decision in your record shows the principle, say so, and say what you would do. | "Leadership philosophy" is the recruiter's phrase. A principle without a decision reads as a slogan. |
| C3 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] stem | If your record has such a moment, tell it in its beats. If it does not, say so plainly. Do not reach for a customer story the material does not carry. | The honest branch carries the answer. |
| C4 | "Sixty seconds: why you over an internal candidate?" | JD | [grounded] "I've never managed managers" (your message); [grounded] "9 years engineering, 3 as a team lead of 6" (your message) | Pause and restate the question. Give 60 seconds: the team of six for three years, the reliability quarter. Concede the managers gap in one sentence. Then hold: the case is what you have done. Hold through two follow-ups, and do not fold on the case. | Skip-level pressure. The concession has to be short and clean. |
| C5 | "That 60% — how much of it was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." (your message) | Hold: the push was yours, and the quote says so. Concede specifically: name the part of the 60% you cannot attribute to yourself. Answer slot: name anyone else who carried the work. | An attribution probe. The honest answer is the concession. |
| C6 | "Our device fleet is growing faster than the reliability budget. How do you think about where next year's investment goes?" | CASE | [generic] | Clarify what the budget is measured against. Ask about the strategy first. Name the trade-off between new device classes and the reliability floor. Say one thing you would stop doing. | Altitude. No strategy research ran, so this is generic and labelled so. |
| C7 | "So — walk me through the journey." | EXP | [grounded] "9 years engineering, 3 as a team lead of 6" and "currently at a payments company" (your message) | A 90-second arc in your words, using only those beats. No extra roles or dates. | Casual openers are scored. Pre-script the arc. |
| C8 | "Which part of this leadership job would you be weakest at on day one?" | JD | [grounded] "I've never managed managers" (your message) | Plain acknowledgment: "I've never managed managers." Then the first thing you would do to learn it, said as a plan. | F7 at this altitude. |

**Reverse questions**

1. "When you say values, which one has cost this company something recently?" Why it lands: it asks them for the hard truth, not the slogan.
2. "What does a leadership failure look like here, in one specific case?" Why it lands: a concrete answer tells you what they punish.
3. "What would make you regret this hire in a year?" Why it lands: it exposes the hard expectation.
4. "Where is engineering's biggest risk over the next year?" Why it lands: it shows you think at their altitude.
5. "What do you want to see more of from engineering managers, and less of?" Why it lands: it asks for behaviour, not slogans.

---

## Upgrade menu

- **Full job posting text** → the requirement quotes in the fit snapshot come from the posting, not your summary, and each round's JD-tagged questions are re-checked against it.
- **The recruiter's note on what the Director and the panel will focus on, and any take-home or deliverable** → reweights Rounds A and B, and adds a build section if a deliverable is declared.
- **Larkfield's published values page, pasted** → the values cheat sheet (section 10), and Round C's VAL questions mapped to named values.
- **Interviewer names (Director, two staff engineers, product manager, VP)** → a public-footprint read, persona assignments per panel member, and tailored reverse questions.
- **Web search permission** → I rerun the three L1 checks (values, interview process, strategy). A deeper strategy pass (L2) would add up to six more searches and two fetches, taking several more minutes; it would make the CO and CASE questions specific. Offered once.
- **Your answers to the slots in A4, A7, B5 and C5** → would quote into the snapshot and upgrade F2, F3 and F4.
- **A `tuesday-dossier.md` from job-underwriter** → would ground the A3 objection in evidence and add prohibited claims from the underwriter's review.

---

Drill offer: I can play the Skeptic on A3, the hardware-roadmap question the pack names as highest-ROI, before Tuesday. Say which persona and question you want.

Dossier offer: I can save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into the later rounds.

If you'd rather have this as a Word document, say so and I'll convert it.

Two things would sharpen the pack:
1. Can you paste the full job posting? It would turn the role summary's lines into quoted requirements in the fit snapshot.
2. Did the recruiter say what the Director and the panel will focus on, or send anything to prepare, such as a take-home?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: larkfield_engineering-manager_interview_pack.md -----
# Larkfield Systems, Engineering Manager: interview prep pack

**Loop:** three rounds. Hiring manager, Director of Engineering, Tuesday, 45 min. Panel of two staff engineers and a product manager, Thursday, 60 min. VP Engineering, following Monday, 30 min, described by the recruiter as "values and leadership philosophy." No names given for any interviewer.

**Built without web research.** The search permission was refused for all three checks. Company facts are therefore absent or generic, and the Sources section says where.

## How to use this pack

Personas describe how each question is asked. Types describe what it scores:

- **VAL**: behavioural and values alignment
- **EXP**: deep-dive on your own experience
- **JD**: the role's stated requirements
- **CO**: company and strategy knowledge (none in this pack, because no research ran)
- **CASE**: a live problem, which asks about no past of yours

Question IDs: **A** = Tuesday hiring manager, **B** = Thursday panel, **C** = Monday VP.

Guidance is scaffolding, not a script. An **answer slot** is an instruction for the interview, not a question to me. It asks for no reply here. Say the honest branch when the true answer is the other one.

## Sources

**Provided documents:** your message (the role summary, your background, the three rounds, the recruiter's "values and leadership philosophy"). **Not provided:** a full job posting, a values page, interviewer names, recruiter notes on focus areas.

**Research tier:** L1, searches 3 of 6, fetches 0 of 2. Every call was refused, so none returned a result.

- "Larkfield Systems values": refused
- "Larkfield Systems interview process engineering manager": refused
- "Larkfield Systems strategy industrial IoT device management news": refused

I did not retry the refused calls.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Larkfield Systems values | unavailable | The values cheat sheet (section 10). Its condition, published values in hand, is unmet, so the section is dropped. |
| 2. Larkfield Systems interview process, engineering manager | unavailable | Loop detail. Your three named rounds already establish the loop, so this would have checked detail, not structure. |
| 3. Larkfield Systems strategy and recent news | unavailable | The CO bank and any strategy-grounded CASE question. None written, so the CASE questions are generic. |
| 4. Interviewer name | n/a | No names given, so there was no query to form. |
| 5. Representative engineering manager JD | unavailable | JD-tagged questions beyond the lines of your role summary. |

**Loop:** established by your message, which names each round and who runs it. No archetype fallback was needed.

**Values-style round:** detected from the recruiter's words on the Monday round. No published values are in hand, so Round C's VAL questions are themed on "values and leadership philosophy," not on named values.

## The fit snapshot

Requirements come from your role summary. Evidence quotes are your own sentences.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" (your role summary) | "9 years engineering, 3 as a team lead of 6" (your message) | medium | [grounded] | transferability | Your material shows one team of six for three years, not two squads. Bridge in those words: "For three years I was a team lead of six." Expect a probe on scale. Answer slot: if you have run work across two groups at once, say how and what you decided; if you have not, say so, and give your plan for splitting ownership across two squads. |
| F2 | "own delivery, hiring and growth for 11 engineers" (your role summary, hiring) | "I run our hiring loop for backend roles — about 40 interviews last year." (your message) | medium | [grounded] | transferability | Your material shows hiring for backend roles, and about 40 interviews, not hires. Bridge: "I run our hiring loop for backend roles, about 40 interviews last year." Expect a probe on whether the role spans more than backend. Answer slot: if you have hired for a non-backend role, say what you did; if you have not, say so. |
| F3 | "own delivery, hiring and growth for 11 engineers" (your role summary, growth) | none given | none | [grounded] | discovery | Your material does not show growth: promotions, development, or engineers you moved on. Answer slot: name an engineer you helped grow and what you did; if none comes to mind, say so and say how you would start. |
| F4 | "own delivery" (your role summary) | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." (your message) | medium | [grounded] | none | No gap; the quote reaches delivery in role-relevant terms. Expect a probe on the 60%, since no artifact is shown. The defend-the-number slots sit in A7. |
| F5 | "partner with hardware and product on roadmap" (your role summary, hardware) | "I've never managed managers and never owned a hardware-adjacent roadmap." (your message) | none | [grounded] | capability | The stated negative is the words: "I've never owned a hardware-adjacent roadmap." Then how you would learn it, said as a plan and never as a past. |
| F6 | "partner with hardware and product on roadmap" (your role summary, product and roadmap) | "I pushed a reliability quarter through against roadmap pressure" (your message) | medium | [grounded] | transferability | Your material shows you holding a roadmap line under pressure. It does not show partnering with product or hardware on a roadmap. Bridge at the quote's own scope: "I pushed a reliability quarter through against roadmap pressure." Answer slot: how you worked with product on that quarter; if you did not, say so. |
| F7 | Leading managers across the two squads (role-family pattern, not in your role summary) | "I've never managed managers" (your message) | none | [grounded] | capability | The stated negative is the words: "I've never managed managers." Then the plan for learning it, said as a plan. No answer slot, because your own negative is the answer. |

**Note on the table.** F2 is `transferability`, not `presentation`, because the quote is backend-only and the requirement is not. F3 is `discovery` because the material is silent, not because you lack growth. F5 and F7 are `capability` only because you stated the absence yourself.

## Prohibited claims

Built locally from the snapshot. No dossier was provided. These are the claims this pack will not coach, even though they are the ones a candidate reaches for under pressure.

| Not coached | Basis | Honest form |
|---|---|---|
| "I led two squads," "I've led two teams" | Inflated form of F1 | "For three years I was a team lead of six." Limit, as the pack's own observation: your material shows one team. |
| "I grew engineers into promotions," "I developed people who moved up" | Inflated form of F3, no quote | Nothing to say here. A3's slot and A4's honest branch cover it. |
| "I built the hiring function," "I hired 40 engineers" | Inflated form of F2 | The quote at its scope: about 40 interviews on the backend loop. |
| "I cut on-call by 60%" as your sole work | Inflated form of F4 | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." |
| "I've owned a hardware-adjacent roadmap" | Your stated negative, F5 | Plain acknowledgment: "I've never owned a hardware-adjacent roadmap." |
| "I've managed managers" | Your stated negative, F7 | Plain acknowledgment: "I've never managed managers." |

## Coverage

| Requirement | Questions |
|---|---|
| Lead two squads (F1) | A1, C6 |
| Own delivery (F4) | A7, B4 |
| Hiring (F2) | A4, B5 |
| Growth for 11 engineers (F3) | A4 (answer slot only, since no quote carries growth) |
| Partner with hardware on the roadmap (F5) | A3, B8 |
| Partner with product on the roadmap (F6) | B1, B6 |
| Leading managers (F7) | A2, C4, C8 |
| Values and leadership philosophy (recruiter's words) | C1, C2, C3, C5 |

No CO questions: no research succeeded, so none could be grounded in strategy. CASE questions are generic and labelled so.

---

## Round A: hiring manager (Director of Engineering), Tuesday, 45 min

**Persona weights**

| Persona | Weight | Depth | Why |
|---|---|---|---|
| Skeptic | high | 4 (A1–A4) | A hiring manager buys capability and derisks gaps. F1, F5 and F7 are the gaps they will press. |
| Case/Strategist | high | 2 (A5–A6) | Expect a live problem on the actual roadmap. |
| Data-Driven Prober | medium | 1 (A7) | The 60% and the 40 interviews are your only numbers. |
| Pressure | low | 1 (A8) | A time-boxed "why you" is a common opener for this relationship. |

Conversational is not weighted in this round. Its arc sits in C7.

**Question bank, by persona**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have led a team of six. What changes when the job is two squads?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6" (your message); [grounded] "Lead two squads building device-management services" (your role summary) | Start with the team of six, in those words: what it taught you about delivery. Then say what changes at two. That is your reasoning, not a claim about your past. Answer slot: if you have run work across two groups at once, say how and what you decided; if you have not, say so, and give your plan for splitting ownership across two squads. Hold to the scale in the quote. | F1 is transferability. The scale step is the likeliest probe. |
| A2 | "How would you coach a senior engineer who is strong technically but slow to delegate?" | JD | [generic] question; [grounded] "I've never managed managers" (your message) | Give the coaching approach you would use, in your words. If the managers question follows, say plainly: "I've never managed managers." Then how you would learn it, as a plan. Hold one follow-up. | F7 is the gap this round is most likely to raise. The plain acknowledgment is ready before the probe. |
| A3 | "Which hardware-adjacent roadmap have you owned?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." (your message); [grounded] "I pushed a reliability quarter through against roadmap pressure" (your message) | **Highest-ROI prep in this pack.** First branch: say it plainly. "I've never owned a hardware-adjacent roadmap." Pause. Second branch, if the question presses: the nearest thing your material carries is the reliability quarter, at its own scope. Then the plan for hardware partnership, as a plan. Hold through two follow-ups by returning to the quarter and the plan. Never describe a hardware roadmap you did not own. | F5 is a capability gap in the one area the role names. This objection is almost certain in some form. Rehearsing it until it is boring is what turns it into a credible answer. |
| A4 | "Tell me about an engineer you've helped grow. What did you do, and how did you know it worked?" | JD | [generic] open prompt, theme from your role summary's "growth"; [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." (your message) | Selection scaffold: pick an engineer whose work you changed, a change you made and what you saw. Honest branch: if no such engineer comes to mind, say so plainly, then give the nearest thing your material carries: running the backend hiring loop, about 40 interviews. | F3 is discovery. This is where the gap sits, so the honest answer should be ready before the probe arrives. |
| A5 | "Two device-fleet services miss a rollout date because the hardware team sends firmware late. Walk me through your first week." | CASE | [generic] | Clarify the date, the blast radius and the firmware contract. State the objective. Segment the fleet by hardware variant and region. Give options: hold, partial rollout, ship behind a flag. Name the metrics and risks. Challenge one premise: that the date is fixed. Keep it to 90–120 seconds. | A live problem from the role's own hardware seam. It asks about no past of yours. |
| A6 | "Product wants a feature next quarter, and the squads' top ask is reliability debt. How do you decide?" | CASE | [generic] question; [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." (your message), used only if you tell that story | Clarify the horizon and the cost of each option. State your decision rule. If you use your own example, tell the reliability quarter in its quoted beats: the pressure, the push, the 60% after. Do not stretch the decision to the whole roadmap. | The role's roadmap partnership. The link to F4 and F6 uses only the quote. |
| A7 | "Walk me through how the 60% on-call figure was counted." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." (your message) | Say what you can, in your words. Name the assumption behind the figure you would defend least, before they do. Say what was yours: the push. Answer slot: how it was counted. If you know, say it. If you do not, say so plainly. Do not name a method. | F4 is medium, and a figure raises the defend-the-number slots. |
| A8 | "Sixty seconds: why you over a candidate who has managed managers?" | JD | [grounded] "I've never managed managers" (your message); [grounded] "I pushed a reliability quarter through against roadmap pressure" (your message) | Pause and restate the question in your words. Concede the managers gap in one sentence. Then give what you have: the team of six, the quarter. Hold through two follow-ups. Concede the gap; do not fold the case. | Pressure is low weight here, but the concession has to come in one sentence. |

**Reverse questions**

1. "What would make the first six months a clear success for you?" Why it lands: it shows you plan to be measured against their own expectations.
2. "Which of the two squads worries you most right now, and what has it cost?" Why it lands: it shows you read the team before you walk in.
3. "How do you want to hear that a squad is in trouble, before or after it is visible?" Why it lands: it maps to your reliability record.
4. "What has made earlier engineering managers in this org struggle?" Why it lands: an honest question with a pattern as its answer.
5. "What does the hardware team expect from an engineering manager that a product team would not?" Why it lands: it tests the seam directly and sets up A3.
6. "What would you want the next person in this seat to do differently?" Why it lands: it invites them to name the job's real difficulty.

---

## Round B: panel (two staff engineers, product manager), Thursday, 60 min

**Persona weights.** Panel member names are unknown, so the personas are blended per relationship. Assignment per member waits on names.

| Persona | Weight | Depth | Why |
|---|---|---|---|
| Peer Evaluator | high | 3 (B1–B3) | Two staff engineers price what you cost and add to their work. |
| Data-Driven Prober | high | 2 (B4–B5) | Staff engineers check numbers. |
| Case/Strategist | medium | 2 (B6–B7) | The product manager runs roadmap trade-offs. |
| Skeptic | low | 1 (B8) | Carried over from the hiring round. |

Pressure and Conversational are not weighted in this round.

**Question bank, by persona**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our teams sit side by side. Where's the seam between your squads and firmware, and what happens when you disagree?" | JD | [generic] stem; [grounded] "I pushed a reliability quarter through against roadmap pressure" (your message) | State the principle first: who decides what when firmware and cloud disagree. Then the quarter: the pressure and the push. Do not claim to know their seam. Answer slot: if you disagreed with a peer team and what it cost, say so; if you did not, say so and say what you would do. | F6, and the seam is named in your role summary. Peers test this collegially. |
| B2 | "How do you handle credit when a delivery spans two teams?" | JD | [generic] stem; [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through" (your message) | Say who did what, in your words. The push was yours to say. The 60% followed it. Name others you know carried parts. Answer slot: who else carried the work. | Credit probes come collegially from peers. |
| B3 | "What would you need from our staff engineers to get a reliability workstream into the plan?" | JD | [grounded] "I pushed a reliability quarter through against roadmap pressure" (your message) | Reciprocity first: what you would bring to their teams. Then what you need. Use the quarter as the example of what you would push for. | Peer panels weight what the hire contributes, not only what they need. |
| B4 | "What in the on-call figure would you defend least?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." (your message) | Name the weakest assumption behind the figure in your own words, before they do. Say plainly what the figure cannot tell them. Say what was yours. Answer slot: how it was counted. If you do not know, say so. | Same figure as A7, a different probe. Rehearse them separately. |
| B5 | "How do you know your interview loop works?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." (your message) | Say what you watched, in your words. If you tracked nothing, say so plainly, then say how you would check. Answer slot: if you tracked outcomes, name what; if you did not, say so. | "About 40 interviews" counts interviews, not hires. Do not stretch it. |
| B6 | "A hardware dependency has slipped two quarters. Product still wants the feature. What do you do?" | CASE | [generic] question; [grounded] "I pushed a reliability quarter through against roadmap pressure" (your message), as the nearest precedent only | Clarify what the dependency gates and what the feature costs, and to whom. Options: re-scope, split, hold. Name the risks. Say what you would tell product first. | The roadmap partnership. The link to your past uses only the quote. |
| B7 | "Update success on the fleet fell eight points week over week. Diagnose it." | CASE | [generic] | Clarify the scope and what changed. Segment by hardware variant, region, firmware version and rollout wave. Pick metrics that separate cause from noise. Ask for the logs before theorising. | A live problem. The panel's engineers will test structure. |
| B8 | "Which part of this roadmap would you be weakest at on day one?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." (your message) | Plain acknowledgment: "I've never owned a hardware-adjacent roadmap." Then your day-one plan, said as a plan. Do not claim the seam is known. | F5 again, from the other side. The panel will likely check the same gap. |

**Reverse questions**

1. "What could a new engineering manager do in the first month that would genuinely help your team?" Why it lands: it is the reciprocity question for a peer panel.
2. "Where does the firmware-to-cloud seam cause the most rework today?" Why it lands: it invites them to name the seam, and shows you are thinking about it.
3. "When engineering and product disagree on the roadmap, how is it actually decided?" Why it lands: it tests the role's real decision path.
4. "What did the last engineering manager leave undone?" Why it lands: a frank answer tells you what they most need.
5. "Which reliability work do you wish had been planned earlier?" Why it lands: it lets the staff engineers name their own ask.

---

## Round C: VP Engineering, Monday, 30 min

**Persona weights**

| Persona | Weight | Depth | Why |
|---|---|---|---|
| Values/Behavioral | high | 3 (C1–C3) | The recruiter named this round for "values and leadership philosophy." |
| Pressure | high | 2 (C4–C5) | A skip-level prior: composure and time-boxed answers. |
| Case/Strategist | medium | 1 (C6) | Strategy-heavy altitude. |
| Conversational | low | 1 (C7) | The opening arc. |
| Skeptic | low | 1 (C8) | The managers gap at this altitude. |

**Values cheat sheet:** dropped. No published values are in hand, and section 10 requires them.

**Question bank, by persona**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] open prompt, theme from the recruiter's words; [grounded] "I pushed a reliability quarter through against roadmap pressure" (your message) | Selection scaffold: a time you held a position under pressure from someone senior, with a named stake, a moment you did not fold, and a relationship intact at the end. Nearest thing your material carries: the reliability quarter, in its beats: the roadmap pressure, the push, the 60% after. If no such time comes to mind, say so plainly, then give that. | The recruiter named values for this round. The hard truth has to land, and this is the answer the pack can support. |
| C2 | "What's your leadership philosophy, and what decision shows it?" | VAL | [generic] question; [grounded] "9 years engineering, 3 as a team lead of 6" (your message) | Give one principle you would defend, in one sentence. Then one decision from your record that shows it, in your words. Honest branch: if no decision in your record shows the principle, say so, and say what you would do. | "Leadership philosophy" is the recruiter's phrase. A principle without a decision reads as a slogan. |
| C3 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] stem | If your record has such a moment, tell it in its beats. If it does not, say so plainly. Do not reach for a customer story the material does not carry. | The honest branch carries the answer. |
| C4 | "Sixty seconds: why you over an internal candidate?" | JD | [grounded] "I've never managed managers" (your message); [grounded] "9 years engineering, 3 as a team lead of 6" (your message) | Pause and restate the question. Give 60 seconds: the team of six for three years, the reliability quarter. Concede the managers gap in one sentence. Then hold: the case is what you have done. Hold through two follow-ups, and do not fold on the case. | Skip-level pressure. The concession has to be short and clean. |
| C5 | "That 60% — how much of it was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." (your message) | Hold: the push was yours, and the quote says so. Concede specifically: name the part of the 60% you cannot attribute to yourself. Answer slot: name anyone else who carried the work. | An attribution probe. The honest answer is the concession. |
| C6 | "Our device fleet is growing faster than the reliability budget. How do you think about where next year's investment goes?" | CASE | [generic] | Clarify what the budget is measured against. Ask about the strategy first. Name the trade-off between new device classes and the reliability floor. Say one thing you would stop doing. | Altitude. No strategy research ran, so this is generic and labelled so. |
| C7 | "So — walk me through the journey." | EXP | [grounded] "9 years engineering, 3 as a team lead of 6" and "currently at a payments company" (your message) | A 90-second arc in your words, using only those beats. No extra roles or dates. | Casual openers are scored. Pre-script the arc. |
| C8 | "Which part of this leadership job would you be weakest at on day one?" | JD | [grounded] "I've never managed managers" (your message) | Plain acknowledgment: "I've never managed managers." Then the first thing you would do to learn it, said as a plan. | F7 at this altitude. |

**Reverse questions**

1. "When you say values, which one has cost this company something recently?" Why it lands: it asks them for the hard truth, not the slogan.
2. "What does a leadership failure look like here, in one specific case?" Why it lands: a concrete answer tells you what they punish.
3. "What would make you regret this hire in a year?" Why it lands: it exposes the hard expectation.
4. "Where is engineering's biggest risk over the next year?" Why it lands: it shows you think at their altitude.
5. "What do you want to see more of from engineering managers, and less of?" Why it lands: it asks for behaviour, not slogans.

---

## Upgrade menu

- **Full job posting text** → the requirement quotes in the fit snapshot come from the posting, not your summary, and each round's JD-tagged questions are re-checked against it.
- **The recruiter's note on what the Director and the panel will focus on, and any take-home or deliverable** → reweights Rounds A and B, and adds a build section if a deliverable is declared.
- **Larkfield's published values page, pasted** → the values cheat sheet (section 10), and Round C's VAL questions mapped to named values.
- **Interviewer names (Director, two staff engineers, product manager, VP)** → a public-footprint read, persona assignments per panel member, and tailored reverse questions.
- **Web search permission** → I rerun the three L1 checks (values, interview process, strategy). A deeper strategy pass (L2) would add up to six more searches and two fetches, taking several more minutes; it would make the CO and CASE questions specific. Offered once.
- **Your answers to the slots in A4, A7, B5 and C5** → would quote into the snapshot and upgrade F2, F3 and F4.
- **A `tuesday-dossier.md` from job-underwriter** → would ground the A3 objection in evidence and add prohibited claims from the underwriter's review.
