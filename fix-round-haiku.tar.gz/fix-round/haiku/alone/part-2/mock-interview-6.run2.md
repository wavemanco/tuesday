Your prep pack for all three rounds is saved at /tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-alone-part-2-rooms-case-6-denied-c43d4db5/7fdda8ca-0649-40ab-86ec-eaa1947baffa/scratchpad/larkfield_engineering-manager_interview_pack.md. I built it in loop mode from your role summary and background, with per-round banks, a shared fit snapshot, and a prohibited list. Web search was refused in this session, so the Larkfield values and loop structure are not confirmed, and the pack has no values cheat sheet.

The main thing to rehearse for all three rounds is the hardware-roadmap gap. Question A2 is the highest-return prep, and the pack's quotes limit what you can say about it to what you have actually said.

Say the word and I'll run a drill on A2 with a Skeptic persona. I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

1. Can you paste the full job description and your CV, or a short background? The role summary you gave is condensed, and the fit snapshot currently quotes only your message.
2. Is on-site or hardware-site presence required for this role, and can you meet it? The material doesn't say, and no rehearsal can close that.
3. Should I retry the Larkfield values and interview-process searches if you grant web search? That would fill the Round 3 values section, and it's the only part of the pack that needs research.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: larkfield_engineering-manager_interview_pack.md -----
# Interview prep pack: Engineering Manager, Larkfield Systems

Loop mode, three rounds, prepared for Yusuf. Built from your role summary and background message. No job description text, no CV, and no web research (the searches were refused; see Sources).

| Round | Who | Length | Note |
|---|---|---|---|
| 1 | Hiring manager (Director of Engineering) | 45 min, Tuesday | Name not given |
| 2 | Panel: two staff engineers and a product manager | 60 min, Thursday | Names not given |
| 3 | VP Engineering | 30 min, following Monday | Recruiter's description: "values and leadership philosophy" |

## How to use this pack

Personas describe how a question arrives. Types describe what is being scored. Type key: **VAL** behavioral and values alignment; **EXP** work-experience deep-dive; **JD** role and job-description driven; **CO** company and strategy; **CASE** live problem. Guidance is scaffolding for a spoken answer, not a script. Quoted sentences in the Provenance column are yours, from your message. An **answer slot** is an instruction for the interview: answer it honestly on whichever branch is true.

## Sources

Research tier: L1 — searches 3 of 6, fetches 0 of 2

Provided documents: your message (the role summary, your background, and the three round descriptions). No dossier was provided.

Searches sent, all refused by the host (permission not granted):

- "Larkfield Systems values": refused
- "Larkfield Systems interview process engineering manager": refused
- "Larkfield Systems industrial IoT device management strategy": refused

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `{company} values` | unavailable | The values cheat sheet, which is not built: no published values are in hand. Round 3's VAL questions theme on the recruiter's words instead |
| 2. `{company} interview process {role family}` | unavailable | Loop structure. The three rounds come from your message, which establishes the loop, so the search would only have confirmed it |
| 3. `{company} strategy` / recent news | unavailable | The CO bank. C8 is therefore `[generic]` and says nothing about current strategy |
| 4. `{interviewer name} {company}` | n/a | No interviewer name was given, so there was no query to form. The interviewer read is absent |
| 5. representative `{role title}` JD | skipped | Your role summary fixes the requirement lines the fit snapshot quotes. Full JD text would replace it (upgrade menu) |

## Shared fit snapshot

Requirements are quoted from your role summary. Evidence is quoted from your message. Gap and bridge language follows the routing rule. The "managing managers" gap you named is not a requirement in the role summary, so it has no row; it appears in the prohibited list and in C7. A gate row is included because the material is silent on location.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" — role summary | "9 years engineering, 3 as a team lead of 6, currently at a payments company" — your message | medium | [grounded] | transferability | Your material shows one team of six, not two squads. Words: "For three years I was a team lead of six." Answer slot: if you have coordinated work across more than one team, say how; if you have not, say so, and say how you would split the work between two squads. |
| F2 | "own delivery, hiring and growth for 11 engineers" — role summary (hiring part) | "I run our hiring loop for backend roles — about 40 interviews last year." — your message | medium | [grounded] | presentation | The quote already reaches hiring in other terms, so reword nothing: "I run our hiring loop for backend roles, about 40 interviews last year." It covers the loop for backend roles, not hiring decisions for a team. Answer slot: if you set hiring decisions for your team, say which; if others decided and you ran the process, say so. |
| F3 | "own delivery, hiring and growth for 11 engineers" — role summary (delivery part) | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | medium | [grounded] | transferability | Your material carries delivery at the scope of one reliability quarter for a team. Keep the quote at that scope. Answer slot: if you tracked delivery across the team's work in that quarter, say how; if not, say so. |
| F4 | "own delivery, hiring and growth for 11 engineers" — role summary (growth part) | none given | none | [grounded] | discovery | Your material is silent on growth: development, promotion, or how engineers grew under you. Answer slot: if you have grown people, say how, in your own words; if you have not, say so and say how you would find out what each engineer needs first. |
| F5 | "partner with hardware and product on roadmap" — role summary (roadmap part) | "I pushed a reliability quarter through against roadmap pressure" — your message | medium | [grounded] | transferability | The quote reaches the roadmap under pressure, not a partnership with product. Answer slot: if you worked with product on the roadmap in that quarter, say how; if you did not, say so. |
| F6 | "partner with hardware and product on roadmap" — role summary (hardware part) | "I've never managed managers and never owned a hardware-adjacent roadmap." — your message | none | [grounded] | capability | A stated absence. Words: "I haven't owned a hardware-adjacent roadmap." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller. |
| F7 | On-site or hardware-site presence (not stated in the role summary) — [generic] | none given | none | [generic] | hard_gate | Your material does not establish this. The gate is not bridged, and no rehearsed answer closes it. The message asks whether it is met. |

Notes on the snapshot. F3 and F5 are the same quote read against two requirements, and each keeps its own scope. F6 is the single most likely objection in all three rounds.

## Prohibited list

Built locally from the snapshot, since no dossier was provided. Each entry names its basis and its honest form. No answer slot, hold, bridge or rationale in this pack asserts, softens or implies any entry.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the hardware-adjacent roadmap, or any hardware partnership | Negative you stated, F6 | "I haven't owned a hardware-adjacent roadmap." No slot about owning it |
| Managed managers, or led a lead | Negative you stated, F6 | "I haven't managed managers." Used only when asked, in C7 and A9 |
| Ran two squads, or led two teams | Inflated form of F1 | F1's quote at its own scope: "For three years I was a team lead of six." |
| Owned hiring decisions for eleven engineers | Inflated form of F2 | F2's quote at its own scope. Its limit is the pack's observation: the material says the loop for backend roles |
| Cut on-call by 60% myself | Inflated form of F3 | F3's quote at its own scope. Your material says the team's burden fell after you pushed the quarter through. It does not say what share of that was the quarter |

## Persona weights, by round

Relationship priors set the start. No interviewer profiles exist, so no interviewer signals adjust them. The loop comes from your message, so it is established.

### Round 1: Hiring manager (Director of Engineering), 45 min

| Persona | Weight | Why |
|---|---|---|
| Case/Strategist | 3 | Hiring managers buy capability; expect live problems on the two squads' roadmap |
| Skeptic | 3 | They are derisking the hardware gap and the managers gap in the same conversation |
| Data-Driven Prober | 2 | The on-call figure is a headline CV number, and it will be probed |
| Conversational | 2 | Casual openers are still scored; the biography and motivation questions set up the rest |

### Round 2: Panel (two staff engineers, one product manager), 60 min

Panel rule: blend the top two personas of each member's relationship. Names are not given, so the blend is per role.

| Persona | Weight | Why |
|---|---|---|
| Data-Driven Prober | 2 | Staff engineers test whether "pushed through" means technical ownership |
| Pressure | 2 | Staff engineers push on technical direction; the held position must be one you can back |
| Peer Evaluator | 2 | The product manager prices the seam between product, hardware and your squads |
| Case/Strategist | 2 | Roadmap and device-fleet problems are the product manager's native ground |

### Round 3: VP Engineering, 30 min

| Persona | Weight | Why |
|---|---|---|
| Values/Behavioral | 4 | The recruiter named the round "values and leadership philosophy"; this is the documented values-style round |
| Pressure | 2 | Executive altitude and time-boxing; "why you over an internal candidate" is the likely stem |
| Case/Strategist | 2 | Skip-level prior: altitude and strategy. C8 is generic because no research ran |

## Round 1: Hiring manager (Director of Engineering), 45 min

Persona weights are above. Ten questions, within the per-round bank of 8 to 12.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Two squads will partner with hardware and product on the roadmap. What would you need to know before you changed anything?" | CASE | [grounded] role summary: "partner with hardware and product on roadmap" | Structure, don't recite. Clarify what the squads own and where the hardware constraints sit. Then objective, the delivery state, the people on the two squads, and the first conversation you would have with each partner. Name the first question you would ask hardware. Says nothing about your past. | Tests structure at the role's altitude. The requirement is the employer's own line, so the question is grounded in it. A2 and A9 rehearse the hardware-facing gap. |
| A2 | "You haven't owned a hardware-adjacent roadmap. How would you go about this role without one?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | The highest-ROI rehearsal in this pack. Open with the plain acknowledgment: "I haven't owned a hardware-adjacent roadmap." Then the close, as a plan: learn the hardware constraints and dates from the hardware leads first. Then the one part of your record that bears on it, at its own scope: "I pushed a reliability quarter through against roadmap pressure." Say it once and do not extend it to hardware. Answer slot: if you have worked on a hardware-adjacent roadmap in any form, say what and how; if not, say so and stay with the plan. Hold through two follow-ups by returning to the plan. Concede that hardware is new to you and name what you would check first. | F6 is the most likely objection, and it will arrive in some form. The deepest rehearsal goes here: the concession wording, and the limit stated before it is asked for. Scored as JD because it tests the stated requirement. |
| A3 | "What's pulling you from payments into device management?" | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | Give the reason in your own words, anchored to the work rather than to leaving. The material gives no reason for the move, so the reason must be the one you actually have. Answer slot: if the pull is the problem itself, such as devices or a plant floor, say what about it draws you; if it is mainly the chance to lead, say so. Keep it under 60 seconds. Don't criticize payments. | Conversational register, scored. Motivation consistency is what the Skeptic checks, and Round 3 asks the same thing differently. Your material gives the employer side, not the reason. |
| A4 | "Your team's on-call burden dropped 60%. Walk me through how that was counted." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | The defend-the-number slots, in your own words, before the interviewer asks: how the figure was counted; what it is sensitive to, such as the period and what counted as on-call; the assumption you would defend least; and which part was yours and which was the team's. Answer slot: if you counted it yourself, say how; if you did not, say so plainly and say where the figure came from. Name the weakest assumption first. Never say you alone cut it by 60%. | The headline CV figure, so it gets a defend-the-number question. F3 is the evidence. Scored on attribution, not on the number. |
| A5 | "You've led one team of six. What changes with two squads?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | Transferability, at the quote's scope: the team of six. Then the step to two squads as an answer slot: if you have coordinated work across more than one team, say how; if not, say so, and say how you would split the work between the two squads and what you would check first. Don't stretch "team lead of 6" into "two teams". | A Skeptic probe on the first requirement, where F1 is thin. Scored as JD because it tests whether the candidate can do the listed job. |
| A6 | "Eleven engineers across two squads, and a delivery date you're already behind. Where do you start?" | CASE | [grounded] "own delivery, hiring and growth for 11 engineers" (role summary) | Clarify the commitment and the cause of the slip. Separate what is in flight from what is new. Then the people, then the roadmap conversation with product. Speak in the order you would act. Makes no claim about your past. | A live problem from the delivery requirement. Structure is what is scored. |
| A7 | "You've run a hiring loop for backend roles. Which parts of it were yours to set, and which were set for you?" | JD | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Say what you run and where the decisions sat. Answer slot: if you set the loop's criteria, say which and how you decided; if they came from someone else, say so and say what you added. Name a scorecard or calibration step only if you did it. "Backend roles" is the limit; device-management hiring is the next step. | F2 is `presentation`: the quote reaches hiring, but the ownership question stays open. The question asks where the decision sat, which the quote does not settle. |
| A8 | "Walk me through the last nine years in two minutes." | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | A 90-second arc using only these beats: nine years in engineering, three of them leading a team of six, now at a payments company. Add the next beat in your own words: why you are here. Don't add titles, companies or dates that are not in your message. | Conversational, but scored. The biography sets up every later probe, so it must not outrun F1. |
| A9 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | Answer the honest gap first, in plain words: "I haven't owned a hardware-adjacent roadmap." Then the one thing you would do first to close it, as a plan. You may name the managers gap in the same breath, since your sentence covers it, but lead with hardware because the role summary names it. | The Skeptic's version of A2. Rehearsing it until it is boring is the counter-strategy. |
| A10 | "Eleven people across two squads. Where would you start the hiring plan?" | CASE | [grounded] "own delivery, hiring and growth for 11 engineers" (role summary) | Clarify the constraints: approved headcount, open roles, a time-to-hire target. Then the loop you would keep, the loop you would change, and what calibration you would need across two hardware-adjacent roles. Draw on your backend loop only as the quote states it. | A live problem scored on structure. The backend-loop experience is the one fact it may touch, and only as a quote. |

Round 1 reverse questions:

- "What did the last person in this seat do in the first 90 days that you would want me to repeat?" Why it lands: it shows you are thinking about the job, not only about being hired.
- "Which part of the device-management roadmap is hardest to get hardware to agree to right now?" Why it lands: it shows you already know the seam is where the work is.
- "How would you describe success for these two squads at the end of year one?" Why it lands: it asks for the outcome they will grade you on.

## Round 2: Panel (two staff engineers, one product manager), 60 min

Eight questions, within the per-round bank.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about the reliability quarter. What was your part in the technical work?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Story-mapped to the quote's beats: the quarter, pushed through, against roadmap pressure, and the team's on-call burden fell. Your technical part is an answer slot: if you did technical work in it, name it and say what you decided; if your part was the push rather than the technical work, say so plainly. Don't name a specific fix you cannot defend. Offer to walk through the on-call data if they ask. | Staff engineers will test whether "pushed through" means technical ownership. F3 is transferability, so the answer stays at the quote's scope. Prober persona. |
| B2 | "Roadmap pressure usually wins. What did you do so it didn't this time?" | JD | [grounded] "I pushed a reliability quarter through against roadmap pressure" — F5 quote, your message | Hold the held position: you pushed it through against pressure, which is the quote. Hold two follow-ups by returning to what you did, not to a stronger claim. Concede the cost: name what the roadmap gave up, if you know it. If you do not know, say so. | Pressure persona. The second follow-up breaks a position you cannot back, so the concession is the part to rehearse. |
| B3 | "Product and hardware both have a say on your squads' roadmap. Where does that say end, and where would you draw the line?" | JD | [grounded] role summary: "partner with hardware and product on roadmap" | Seam principles, not a seam you pretend to know. Name the decision rights you would propose: who decides scope, who decides dates, who decides hardware constraints. Then what happens on disagreement. Reciprocity: say what your squads would bring to each partner. Makes no claim about your past. | Peer Evaluator. The seam is unknown to you, so principles are the honest answer. |
| B4 | "A firmware update goes to the field fleet, and the failure rate doubles overnight. What do you do first?" | CASE | [generic] scenario | Clarify the scope: how many devices, what the failure is, whether rollback is possible. Then contain, then the people, then the roadmap consequence. Speak the sequence aloud. Makes no claim about your past. | A device-management live problem. The scenario is a generic pattern, not a fact about Larkfield. |
| B5 | "Eleven engineers in two squads. What does growth look like for someone on them in their first year?" | JD | [grounded] "own delivery, hiring and growth for 11 engineers" (role summary) | Growth is the requirement your message does not carry. Answer slot: if you have grown engineers, say what you did and what changed, in your own words; if you have not, say so, and describe how you would find out what each engineer needs. Don't describe a growth framework you have not run. | F4 is `discovery`: the material is silent, and you have not stated an absence. A Peer question about shared work. |
| B6 | "Tell me about one interview you ran where the signal was hard to read. What did you do with it?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Selection scaffold: pick an interview where the signal was hard to read. It needs a decision you made about the candidate, and an honest account of what the others on the loop did. If no such interview comes to mind, say so, then give the nearest thing you did in the loop. | Prober persona. This tests the F2 ownership question at interview level. Open prompt, so no event is supplied. |
| B7 | "Staff engineers here will push on technical direction. Give me a time someone with more technical depth than you pushed back, and what you did." | EXP | [generic] persona stem; "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Selection criteria: a named technical pushback, a moment you did not fold, and a relationship intact at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, which is the reliability quarter at its own scope, or how you would handle it. Hold, then concede only what is true. | Pressure persona, open prompt. The quote is in Provenance because the fallback branch rests on it. |
| B8 | "A hardware team says the next device generation slips a quarter. How do you reshape the squads' roadmap?" | CASE | [grounded] role summary: "partner with hardware and product on roadmap" | Structure: clarify what slips and what it blocks. Lay out the options with the cost of each. Name who needs to decide, and what you tell the squads. Name the one roadmap item you would protect and why. You do not need hardware experience to structure this, and don't pretend you have it. Makes no claim about your past. | The hardware seam as a case, scored on structure at the role's altitude. |

Round 2 reverse questions:

- To the panel as a whole: "What could a new engineering manager do in the first month that would genuinely help your team?" Why it lands: a reciprocity question. It shows you are asking what you can bring, not only what you need.
- To the staff engineers: "Where do technical decisions get made here that the managers never see?" Why it lands: it shows you want to understand how influence works before you change anything.
- To the product manager: "When product and hardware disagree on the roadmap, how is it decided today?" Why it lands: it asks about the seam directly, which B3 rehearses.

## Round 3: VP Engineering, 30 min, "values and leadership philosophy"

This is the documented values-style round, from the recruiter's words.

**Values cheat sheet: not built.** It needs published company values in hand, and the values search was refused. Round 3's VAL questions theme on the recruiter's words instead. Once the values page is available, this section can be built.

**Interviewer read: absent.** No name was given.

Eight questions, within the per-round bank.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "What's your leadership philosophy, in a sentence or two, and where did it come from?" | VAL | [grounded] recruiter's words: "values and leadership philosophy" (your message). Anchor: "I pushed a reliability quarter through against roadmap pressure." | A 90-second answer. Give the sentence first, then the story at its scope: the quarter, pushed through against pressure. Pick one principle you actually hold. If the principle is one you hold but have not tested, say so. Don't adopt a philosophy from the job description. | The round's own theme, from the recruiter. Values are not in hand, so the question themes on the recruiter's words rather than on published values. |
| C2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] persona stem; "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Open prompt. Choose one instance with a named stake, the point where you said it, and what leadership did next. If the reliability quarter is the nearest, use it at its scope and describe the pushback in your own words. If no such time comes to mind, say so, then give the nearest thing your material carries. | Values persona. An open prompt, so the candidate chooses the instance. |
| C3 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] persona stem | Your material carries no customer story. If one comes to mind, use it in your own words, with the metric it cost you. If none does, say so plainly, and say how you would weigh a customer outcome against a delivery target. | Values persona. No raising source in your material, so the stem is an open prompt and the guidance adds no story. |
| C4 | "What decision as a lead would you make differently now?" | VAL | [generic] persona stem; "9 years engineering, 3 as a team lead of 6, currently at a payments company" | Open prompt. Pick one decision from the three years, name what you would change, and say what you learned. Pick a real one, not a safe one dressed as a mistake. If you cannot name one, say so and say what you would check on the next team. | Values persona. Tests self-assessment candor, which this round scores. |
| C5 | "Sixty seconds: why you over an internal candidate?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company"; "I've never managed managers and never owned a hardware-adjacent roadmap." | Hold: nine years, three of them leading a team of six. Hold through the first follow-up by returning to that. When pressed on hardware, concede in plain words: "I haven't owned a hardware-adjacent roadmap," then what you would do first. Don't argue you are better than an internal candidate. Say what you bring that is specific. | Pressure persona. The hold is what your quotes carry, and the concession is the part you cannot skip. |
| C6 | "Your strongest evidence is a team of six. Why would the engineering org trust you with two squads?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company"; "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Hold the team-of-six record and what it shows: the quarter. Then concede the step plainly at its scope: your material shows one team of six, and say how you would earn trust across two squads. Don't claim two-squad experience. | Pressure persona, time-boxed. The honest form is the transferability limit, said once and not defended. |
| C7 | "One of your squads has a lead who is stronger in the work than you are. How do you run that?" | CASE | [generic] scenario; "I've never managed managers and never owned a hardware-adjacent roadmap." | Name what the lead owns, what you own, what you would want to see in the first month, and where you would step in. If asked whether you have done this, use your plain acknowledgment: "I haven't managed managers." Don't describe having managed one. | The managers gap you named. It is hypothetical, so no claim about your past is made. The sourced acknowledgment covers the honest form. |
| C8 | "How would you describe where device management should go at Larkfield over the next three years?" | CO | [generic] | No research ran, so you have no current strategy to cite. Speak in terms of what you would need to know, and how you would test a view against it. Don't name a company priority from memory. | Case/Strategist at executive altitude. CO questions go generic without research; this is the honest cost. |

Round 3 reverse questions:

- "What would you want the engineering org to look like twelve months from now that it doesn't look like today?" Why it lands: an altitude question that asks for the change they are paying for.
- "How does reliability work get its place against roadmap commitments in planning?" Why it lands: it asks about the same tension C6 and B2 rehearse, and the answer shows how they weigh it.
- "What would you want to hear from me in this conversation that I haven't said yet?" Why it lands: it invites the one thing they want to test, which you can then answer directly.

## Requirement coverage

| Requirement (role summary) | Questions | Note |
|---|---|---|
| Lead two squads building device-management services | A5, B4, C6, C7 | |
| own delivery | A4, A6, B1, B4 | |
| own hiring | A7, A10, B6 | |
| own growth for 11 engineers | B5 | `discovery`; no rehearsed story exists, and the answer slot is the honest form |
| partner with hardware and product on roadmap | A1, A2, A9, B2, B3, B8 | The hardware part is the highest-ROI rehearsal (A2) |
| On-site or hardware-site presence (gate) | none, and why | A gate is met or not met. Wording cannot close it, so the message asks whether it is met |

Values-style coverage: the round's theme is covered by C1 to C4, from the recruiter's words. No published value is covered, because none is in hand.

## Upgrade menu

- The full job description text: the four requirement rows become quoted JD lines, and any mid-list requirement that appears once gets its own question.
- Your CV: checks every quote in F1 to F5, and any line it carries beyond your message upgrades the stories in A1, A4, B1 and C4.
- Permission for web search: the values cheat sheet for Round 3, a loop check against the Larkfield interview process, and a strategy-based version of C8 and B8. Up to three more searches and two fetches remain in the L1 budget.
- Whether the squads have leads of their own: turns C7 from a hypothetical into a question about the role as described, and sharpens F1.
- Whether on-site or hardware-site presence is required, and whether you can meet it: resolves gate row F7. If it is not met, F7 stays `hard_gate` and the pack says so.
- The interviewers' names: an interviewer read for each round, persona weights per person, and a tailored reverse question for each.
- The part of the reliability quarter that was yours, in one sentence: once stated, it enters the snapshot verbatim and upgrades the answer slots in A4, B1, B7 and C2 to story-mapped answers.
- Any written note from the recruiter on the panel format and the VP round's content: confirms the loop and the values-style round at source.
- Prep time before each round: adds a prep-triage section with the order to work in.
