Your prep pack is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-alone-part-2-rooms-case-7-canned-6e803b66/fd04ee3d-9a3d-4683-9de6-e9d1364b0961/scratchpad/saltmarsh_games_live_operations_producer_interview_pack.md`.

The key finding is the format. Saltmarsh's interviewing page says the round is a single 60-minute Outage Hour with the hiring manager: a live-incident tabletop on a simulated outage during a live event, then a values conversation. I've weighted the pack toward the tabletop. I've also assumed Tobias Wrenfield is the hiring manager.

The pack's highest-ROI prep is C1, the "you've never led a team" objection. I'd rehearse it through three follow-ups.

Two things to check before you rely on the research:
- One search result claimed a GDC 2026 talk by Tobias Wrenfield. It came from a domain I couldn't verify, so I didn't use it, and the pack has no interviewer read.
- The Project Larkspur news (one shared events calendar for two titles from February 2027, on a season-pass model) came from a search snippet. I didn't open the page. A4 and some reverse questions use it.

Say the word and I'll play the Pressure interviewer on C1, the question the pack names as highest-ROI prep. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.

Is there any live incident you've handled, such as a bad release, an outage or a reward bug? If so, what did you do in the first hour?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh_games_live_operations_producer_interview_pack.md -----
# Saltmarsh Games: Live Operations Producer interview prep pack

Role: Live Operations Producer. Company: Saltmarsh Games. Interviewer: Tobias Wrenfield, Head of Live Operations (assumed to be the hiring manager). Round: the Outage Hour, 60 minutes, Friday. Research tier: L1. No dossier was provided. This is the first version, so there is no changelog.

## How to use + type key

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script. Each guidance cell is written to be said aloud in 90 to 120 seconds.

Type key:
- **VAL**: behavioral and values alignment. Does past behavior show the published values?
- **EXP**: experience deep-dive. Do your claims survive scrutiny? What did you actually do?
- **JD**: role-driven. Can you do the listed job, gaps included?
- **CO**: company and strategy knowledge.
- **CASE**: a live problem from the role, solved aloud.

Fit rows are numbered S1 to S10. Question IDs are letter-by-persona. Highest-ROI prep: **C1**, the "never led a team" objection. It is the most predictable challenge to this profile, and it is the one the candidate most needs to answer without flinching. Rehearse C1 through three follow-ups.

## Format of the round (from the company page)

The company's interviewing page describes the loop as a recruiter call, then the **Outage Hour**: "a single 60-minute interview with the hiring manager — a live-incident tabletop on a simulated outage during a live event, then a values conversation. There is no take-home." That is the whole round, so the pack is weighted toward it. The loop source establishes the loop, so no archetype fallback is used.

## 1. Fit snapshot

Requirement quotes are from the job description you supplied. Evidence quotes are from your message. Two requirements below are not in the JD text; they are gaps you flagged yourself (S9, S10).

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| S1 | "Plan and run the live-events calendar for two of our mobile titles" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | transferability | Your material says one title's content-drop calendar, not a live-events calendar across two titles. Keep it at that scope. Answer slot: the JD says two titles, so expect a probe on how you would split your time between them. If you ever planned across more than one title, say how; if you did not, say so and say how you would sequence two. |
| S2 | "coordinate design, art, engineering and community teams on each update" (JD) | none given | none | [grounded] | discovery | Your material does not show coordinating these four teams on an update. Answer slot: if you coordinated any of them on a release or event, say which and how; if you did not, say so and describe how you would bring each team in. |
| S3 | "own the post-event review and the KPIs it reports" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | medium | [grounded] | transferability | Presenting monthly numbers is adjacent to owning a review, and the bridge stops there. Say you presented the numbers. Answer slot: if you ran any review of a content drop, say what it reported; if you did not, say so and describe the first review you would run. |
| S4 | "manage the release checklist with QA" (JD) | "Wrote the release checklist our QA team still uses." (your message) | medium | [grounded] | none | No gap: the quote reaches the requirement in role terms. Keep the verbs as written: you wrote it, and QA still uses it. Do not turn "wrote" into "managed" unless you did. |
| S5 | "3+ years producing live-service games or apps" (JD) | "4 years as an associate producer at a puzzle-game studio." (your message) | medium | [grounded] | transferability | The years are stated. Whether the title was live-service is not in your material. Say the title's model in your own words, and keep "associate producer" as your title. Answer slot: if the title ran content drops, say what that involved; if you cannot characterise its model, say so. |
| S6 | "experience running a content calendar" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | none | Direct. Keep the quote's scope: one title, two years. |
| S7 | "comfortable with player-retention metrics" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | medium | [grounded] | presentation | The quote reaches the requirement in other terms: you presented retention monthly. The bridge rewords only that sentence: "I presented the monthly retention numbers to the studio head." It adds no analysis. Expect a probe on how the numbers were counted; that is D1. |
| S8 | "clear written communication" (JD) | "Wrote the release checklist our QA team still uses." (your message) | medium | [grounded] | presentation | The checklist is the written evidence you have. Let the artifact carry the claim; do not say your writing is clear. A redacted sample would let an interviewer check it (see upgrade menu). |
| S9 | Leading a team: not a JD line; you flagged it | "Never led a team" (your message) | none | [grounded] | capability | "I haven't led a team." Then how you would learn to coordinate without line authority, said as a plan, never as a past. Add nothing to make the gap feel smaller. |
| S10 | Working on a game with in-app purchases: not a JD line; you flagged it | "never worked on a game with in-app purchases" (your message) | none | [grounded] | capability | "I haven't worked on a game with in-app purchases." Then the plan: what you would learn first about how a game earns money. Add nothing. |

Observation for your own reading (not words for the interview): the Outage Hour's tabletop is not a JD line, and nothing in your material shows live-incident handling. The pack therefore asks the tabletop as a live problem (A1) and does not presume you have handled an incident.

## 2. Prohibited claims

These are the claims this pack will not coach. Each has a basis and an honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the post-event review or the KPIs it reports | Inflated form of S3 | S3's quote at its own scope. Observation: your material says you presented monthly retention numbers, not that you owned a review. D2's slot stays inside what you ran. |
| Managed the release checklist with QA | Inflated form of S4 | "Wrote the release checklist our QA team still uses." B2 and E2 ask only what changed. |
| Ran the live-events calendar for two titles | Inflated form of S1 | S1's quote at its own scope. A3 is a generic case, not a claim. |
| Analysed retention | Inflated form of S7 | "Presented the monthly retention numbers to the studio head." Observation: presented, not analysed. |
| Three years of live-service producing | Inflated form of S5 | "4 years as an associate producer at a puzzle-game studio." D3 asks what the title was. |
| Led a team | Negative you stated (S9) | "I haven't led a team." No slot. |
| Worked on a game with in-app purchases | Negative you stated (S10) | "I haven't worked on a game with in-app purchases." No slot. |

## 3. Persona table

| Persona | How it shows up here | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist | A live-incident tabletop on a simulated outage, then the values conversation | **5 (top).** The loop source names the tabletop as the session's core, so this is the dominant style. | Clarify before structuring. State the objective, then the decisions, and think aloud. |
| Values/Behavioral | The values conversation in the same hour | **3.** The loop source documents a values conversation, so a values-style round is detected. | Map each published value to a story where a quoted sentence carries one; use a selection scaffold with its honest branch where none does. |
| Skeptic | "Weakest on day one"; "never led a team" | **3.** Hiring-manager prior, plus two gaps you stated (S9, S10) and a thin S2. | Say the gap in one plain sentence, then a ramp plan. |
| Data-Driven Prober | Counting retention; the review you would run | **3.** The JD names retention metrics and KPIs, and S7 is a presentation, not an analysis. | Name the weakest assumption you know of, or say plainly that you do not know how a figure was built. |
| Pressure / Stress | "Why hire someone who has never led a team?" | **2.** Lower than the Skeptic for a hiring manager, though a time-boxed tabletop can tighten it. | Pause, hold the position that the quotes carry, concede the specific gap, and hold through two follow-ups. |
| Conversational / Rapport | A casual "walk me through" and an open warm-up | **2.** Casual register is still scored. | A pre-scripted 90-second arc built only from your quoted sentences. |
| Peer Evaluator | (none expected) | **0, not weighted.** The interviewer is the hiring manager, so there is no peer bank. Seam questions with engineering and design come through A1 and C1. | (none) |

Totals: 18 questions (5 / 3 / 3 / 3 / 2 / 2).

## 4. Question banks

### A. Case/Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A reward bug went out during a live event, and players are posting about it. Walk me through the first hour." | CASE | [grounded] (the Outage Hour page, saltmarshgames.com/careers/interviewing) | Clarify first: how many players, which platform, whether the event is still running, what has already been said publicly. Set one objective: stop the harm, then tell players what is known. Name who you bring in: engineering on call, QA, community, and the owner of the reward. Separate what you can say now from what is built, and do not give a fix date you cannot back. Name the one decision you would escalate. | The loop source names this tabletop as the session's core. It is a live problem from the role; it asks about no past of yours, so it presupposes nothing about you. Scored on structure and clarification. |
| A2 | "Day-7 retention on your main title fell four points the week after a content drop. Diagnose it." | CASE, JD | [generic] | Clarify the cohort definition and whether the measurement changed. Segment by platform, cohort start and who took part in the drop. Check what else changed that week before blaming the drop. Name your weakest assumption before they do: that the drop caused the fall. Propose one check you could run in a day. | Covers S7's requirement, retention metrics. A generic metric diagnosis; no claim about your history. |
| A3 | "Plan the next six weeks of live events across two titles. What is fixed, what do you cut, and why?" | CASE, JD | [generic] | Start with what cannot move: seasonal dates, partner commitments, releases already in QA. Give each title its own calendar and one shared capacity line for the teams. Set the cut rule before you need it: what goes first when a build slips. Tie each event to one retention or revenue objective. | Covers the JD's "two of our mobile titles" line. This is where the one-title gap in S1 gets probed. |
| A4 | "Project Larkspur puts two titles onto one shared events calendar from February. What would you protect first?" | CO, CASE | [grounded] "September 2026: Project Larkspur moves Tidepool Tactics and Lantern Row to a season-pass model with one shared events calendar from February 2027" (saltmarshgames.com/news/project-larkspur, search result) | Use the company's own framing as context: one calendar, two titles, a season-pass model. Protect the player promises first: the events players have already planned around. Name the trade you would make between the two calendars. Say what you do not know about the season-pass economics rather than guessing. Do not claim experience with season passes or in-app purchases. | The coverage rule asks for one CO question grounded in current strategy. The question's premise is the company's public statement, not a claim about you. |
| A5 | "Draft the player-facing message for a bug that cost players a reward. You have two minutes." | CASE, JD | [generic] | Say what happened, what is fixed, what is not, and when players will hear next. Announce only what is built; no date you cannot back. Short sentences, one action for the player. Read it back once for any sentence that promises more than you know. | Covers "clear written communication" live. The published value "Ship the Patch Not the Promise" frames the standard. |

### B. Values/Behavioral (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time the calendar and what players were telling you disagreed." | VAL, EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | Selection scaffold: pick a time when the calendar you ran and player feedback pointed different ways. Say what you saw, what you chose, and what happened to the calendar. If no such time comes to mind, say so plainly, then give the nearest thing: how the drops were ordered across those two years. Answer slot: if you changed a drop because of players, say what changed and who decided; if you did not, say so and say what you would weigh first. | Players Before Plans is the first published value. S6 is the only row with a calendar, so it carries the nearest story. The question is an open prompt drawn from the value, not a claim about you. |
| B2 | "When did you ship something smaller than the plan, so you did not promise what was not built?" | VAL | [grounded] "Wrote the release checklist our QA team still uses." (your message) | Selection scaffold: pick a release where what you announced was smaller than what was planned, and say what decided it. Name the checklist only as far as it goes. Answer slot: if the checklist gated what was announced, say how; if it did not, say so and say what you would gate announcements on. | Ship the Patch Not the Promise. S4 is the only artifact you have, so a story about announcements needs the answer slot. |
| B3 | "How have you left a process better than you found it?" | VAL, EXP | [grounded] "Wrote the release checklist our QA team still uses." (your message) | Scaffold: name a process you changed, what it was before, and what changed. If the checklist was your first version, say so; it started from nothing. If you can say what it has caught since, say that. If you cannot, say so. | Leave the Build Greener. Your sentence says "wrote", not "improved", so the story cannot claim an improvement it does not carry. |

### C. Skeptic (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You've never led a team, and this role coordinates four of them on every update. How does that work without authority?" | JD, EXP | [grounded] "Never led a team" (your message); "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | Say it first, plainly: "I haven't led a team." Then the bridge is a plan. Use the calendar you ran, which other teams had to hit. Answer slot: if you coordinated design, art, engineering or community on an update, say who and how; if you did not, say so and describe the first two weeks you would spend with each team, and how the calendar would get its dates from them. Hold through one follow-up before offering the learning plan. Rehearse through three follow-ups. | Highest-ROI prep. The JD names four teams (S2 is discovery) and you stated the team-leadership absence (S9), so the plain acknowledgment has its source. The premise that you coordinated anyone is an answer slot with a second branch. |
| C2 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "never worked on a game with in-app purchases" (your message); "Never led a team" (your message) | Name two, no more. Plain acknowledgments: "I haven't worked on a game with in-app purchases." and "I haven't led a team." Then one ramp step each, said as a plan. Do not add a third weakness to look candid. If you have handled a live incident, say how in your own words; if not, say so. | The most direct Skeptic probe. Both stated gaps (S9, S10) meet it. The live-incident branch is a neutral conditional, not a premise. |
| C3 | "You haven't worked on a game with in-app purchases. What would you need to understand about how a game earns money before you planned its events?" | JD | [grounded] "never worked on a game with in-app purchases" (your message) | Plain acknowledgment: "I haven't worked on a game with in-app purchases." Then the learning plan: which revenue numbers you would read first, whom you would ask about monetisation, and which events would change revenue. Claim no monetisation practice on any title you have worked on. | A stated absence, so the acknowledgment has its source. The question asks what you would learn, not what you did. |

### D. Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how the monthly retention numbers you presented were counted." | EXP, JD | [grounded] "Presented the monthly retention numbers to the studio head." (your message) | Answer slot: the question assumes you know the counting method, and your sentence does not carry it. If you know how the numbers were counted, say so in your own words: which cohort, which window, which data. If you did not calculate them, say so plainly and say what you would check first: the cohort definition and the data source. Then the weakest assumption you know of, or say you do not know it. Name no method the sentence does not carry. | S7's defend-the-number probe. The second branch allows that you did not compute the figures. |
| D2 | "Walk me through the post-event review you'd run after an event that missed its retention target." | JD, CASE | [grounded] "Presented the monthly retention numbers to the studio head." (your message) | Structure: what you would compare (target, control, the previous event), who you would bring in (design, engineering, community), what you would recommend, and what the KPI report would show. Answer slot: if you ran any post-event review, say what it reported and who received it; if you did not, say so and describe the first review you would run. Do not infer ownership of a review from the presenting line. | Covers the JD's post-event review line. S3 is transferability: presenting is not owning a review. |
| D3 | "Was the puzzle title you worked on a live-service game? Describe its update cadence." | JD, EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." (your message); "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | Say the title's model in your own words, and your role as an associate producer. If the title ran weekly content drops, say so and say what that cadence involved for you. If you cannot characterise its model, say so. Do not count the years as live-service producing unless you can say what the title was. | Covers "3+ years producing live-service games." Length of experience is not a gate; whether the title was live-service is not in your material. |

### E. Pressure / Stress (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds. Why should I hire someone who has never led a team to run two live titles?" | JD | [grounded] "Never led a team" (your message); "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | Pause. Hold the position the quotes carry: the calendar you ran for two years. Concede the specific gap: "I haven't led a team, and I haven't run two titles." Then the ramp. Hold through two follow-ups. Do not concede the core claim, that you can run a calendar, unless they show it is false. | Pressure: hold, then concede the specific gap. The hold is your quote, no more. |
| E2 | "Your release checklist. How much of it was actually you?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." (your message) | Say what you wrote, what QA changed after, and what it covers today, in your own words. Answer slot: if QA changed it after you wrote it, say what changed and who made it; if you still maintain it, say so; if you do not know what they changed, say so. Hold at "wrote" and stop there. | Covers "manage the release checklist with QA." An attribution probe; the answer is the sentence and nothing more. |

### F. Conversational / Rapport (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Walk me through how you ran the content-drop calendar, like I just joined the team." | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | A 90-second arc: the title, the weekly rhythm, the two years, what the calendar was for. Stop at the sentence's scope. Answer slot: how decisions about what went into each week were made, if you made them; if someone else set the order, say so. | Covers "experience running a content calendar." The casual register is scored, for content and for attribution. |
| F2 | "What's the last live event you played that you'd have run differently?" | CASE | [generic] | Pick one live event you actually played. Say what worked, what you would change, and why, one sentence each. Claim no knowledge of the game's internals. | A casual version of the live-ops judgment the role needs; probes the JD's "plan and run the live-events calendar" line. |

## 5. Requirement coverage

| Requirement | Covered by |
|---|---|
| Plan and run the live-events calendar for two of our mobile titles | A3, A4, F2 (S1 gap) |
| Coordinate design, art, engineering and community teams on each update | C1, A1 (S2 discovery) |
| Own the post-event review and the KPIs it reports | D2, D1 (S3 gap) |
| Manage the release checklist with QA | E2, B2 (S4) |
| 3+ years producing live-service games or apps | D3 (S5 gap) |
| Experience running a content calendar | F1 (S6) |
| Comfortable with player-retention metrics | D1, A2 (S7) |
| Clear written communication | A5 (S8) |
| Not in the JD, flagged by you: leading a team | C1, C2, E1 (S9) |
| Not in the JD, flagged by you: in-app purchases | C2, C3 (S10) |
| Not in the JD, from the format: live-incident tabletop | A1, C2 |

## 6. Values / principles cheat sheet

Detected: the loop source documents a values conversation (see the format section). The company's published values were fetched from its own page.

| Value (official name) | Working meaning | Mapped story |
|---|---|---|
| Players Before Plans | When the calendar and the players disagree, the players win. | Selection scaffold: B1. Nearest row S6: "I ran the weekly content-drop calendar for our main title for the last two years." Honest branch: say so if no such time comes to mind. |
| Ship the Patch Not the Promise | Announce what is built, not what is hoped. | B2 and S4: "Wrote the release checklist our QA team still uses." Answer slot: if the checklist gated announcements, say how; if not, say so. |
| Leave the Build Greener | Every release leaves the codebase and the checklist better than it found them. | B3 and S4: the same sentence. Scaffold: name a process you changed; if the checklist was your first version, say so. |

## 7. Reverse questions

| Question | Why it lands |
|---|---|
| "Project Larkspur puts Tidepool Tactics and Lantern Row on one shared events calendar from February 2027. What will this role own in that calendar, and what stays with each title's team?" | Shows you read the company's own news. It surfaces the real scope of the role. |
| "Which of the three published values did your last miss come down to?" | Treats Players Before Plans and Ship the Patch Not the Promise as operating tests, not slogans. |
| "How do you split the post-event review between the live-ops group and the title teams?" | Tests the JD's "own the post-event review" line, the one you can least rehearse. |
| "What does a good first 90 days look like on the KPIs this role reports?" | Converts the gap into a measurable plan and asks what success looks like. |
| "What would you want me to understand about how the games earn money within my first month?" | Addresses the in-app-purchase gap as a learning question, with no claim of past experience. |

The interviewer-path question is omitted: the one search result about this interviewer could not be verified (see Sources).

## 8. Delivery coaching

Dropped: no working-style assessment was provided.

## 9. Sources

Provided documents: your message (background, JD text, the Outage Hour round and the interviewer's name and title).

Searches and fetches, all in one tally:

1. Query "Saltmarsh Games values": returned saltmarshgames.com/values. Fetched it. Three published values: Players Before Plans; Ship the Patch Not the Promise; Leave the Build Greener.
2. Query "Saltmarsh Games interview process Live Operations Producer": returned saltmarshgames.com/careers/interviewing. Fetched it. Loop: recruiter call, then the Outage Hour (60-minute interview with the hiring manager; live-incident tabletop, then a values conversation; no take-home).
3. Query "Saltmarsh Games mobile studio news": returned saltmarshgames.com/news/project-larkspur. Not fetched; the search snippet is the source. Used only in A4 and the reverse questions.
4. Query "Tobias Wrenfield Saltmarsh Games Head of Live Operations": returned one result, a page claiming a GDC 2026 talk by the interviewer, on a domain (talks.gdconf.example) I could not verify. Not fetched, not used. The interviewer read is absent for this reason.

No dossier was consumed.

### Research tier: L1 — searches 4 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | yes | Values cheat sheet (section 6): three values by name, from the fetched page. |
| 2. Saltmarsh Games interview process, Live Operations Producer | yes | Loop structure: the Outage Hour, one 60-minute session with the hiring manager; persona weights (Case 5); a values round detected. |
| 3. Saltmarsh Games strategy / recent news | yes | One current fact (Project Larkspur, September 2026) for A4 and the reverse questions. Not a full strategy pass. |
| 4. Tobias Wrenfield Saltmarsh Games | yes | No usable public footprint. The one result is unverified and dropped; the interviewer read and the interviewer-path reverse question are absent. |
| 5. Representative Live Operations Producer JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions. |

## 10. Upgrade menu

- Your CV, or a current résumé → S1 to S8 move from "your message" to a document. Confidence can rise where the document shows the work.
- A redacted sample of the release checklist, or a retention summary you wrote → S4, S8 and D1 get inspectable proof; S8's confidence can rise to high.
- The recruiter's note on what the 60 minutes cover, and whether you will be asked to write anything → confirms the tabletop structure behind A1 and A5.
- A page you can open for the interviewer's public talks → the interviewer read, a shared-professional-path reverse question, and a check on the unverified GDC result.
- A live-incident story, if you have one → fills the A1 and C2 slots with your own words (asked in the message that presents this pack).
- A deeper research pass, offered once: up to 6 more searches and 2 more fetches, several more minutes. It would add a strategy brief for A4, the interviewer's public talks, role-family loop reports and recent org context. Want it?
