Your prep pack is saved at /tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-alone-part-2-rooms-case-2-denied-ff1942cc/f0da0d3c-c5f3-4b24-bb36-bf722ee1ec2a/scratchpad/atlas-freight_operations-manager_interview_pack.md. I built it for a hiring-manager-style round, since your note didn't say who you're meeting. Web research was refused in this session, so nothing about Atlas Freight's values, interview process or strategy is in it. It rests on the JD you pasted and your background.

The most important prep is S1: "You run three supervisors today. This job has twelve across four sites. What's your evidence you can do that?" Your three-supervisor scale is the biggest gap against the JD, so rehearse the honest answer until it's routine.

I can also play the Skeptic on S1 in a live drill, or save a tuesday-dossier.md recording the gaps this prep exposed. If you'd like the pack as a Word document, say so and I'll convert it.

1. Who are you meeting, and is it your future manager, a peer, or a panel? That changes the persona weights and the reverse questions.
2. Did the recruiter name any focus areas or a deliverable, such as a presentation or take-home?
3. Can you paste Atlas Freight's values page or any recent news about the company? Without it, the pack has no company-specific material.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: atlas-freight_operations-manager_interview_pack.md -----
# Interview prep pack: Operations Manager, Atlas Freight

Interviewer: not named. Round type: not stated. Built as a session-mode pack with flat-to-hiring-manager weights, since no loop source is in hand (see Persona table).

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored.
- Type key: **EXP** = work-experience deep-dive, tests whether your claims survive scrutiny. **JD** = stated responsibility or qualification, tests whether you can do the listed job. **CASE** = live problem from the role, tests structure and reasoning. **VAL** = behavioral, tests past behavior. **CO** = company knowledge (none in this pack; research did not run).
- Guidance is scaffolding, not a script. Rehearse it aloud until it sounds like you.

## Fit snapshot

Requirements are quoted from the JD you pasted. Evidence is quoted from your message, marked "your message". Nothing else is treated as your history.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" (JD) | "ran the site's peak-season surge plan two years running" (your message); "cut mis-pick rate 40% by redesigning the pick path" (your message) | medium | [grounded] | transferability | Your material shows one site, not four, and the words stay there: "I ran the site's peak-season surge plan two years running." Answer slot: if you have run more than one site, or coordinated work across sites, say how, in your own words; if you have not, say so plainly and describe how you would set up four. |
| F2 | "drive on-time performance and cost-per-shipment down" (JD) | "cut mis-pick rate 40% by redesigning the pick path" (your message) | medium | [grounded] | transferability | Your evidence is a quality metric, not on-time or cost per shipment, so do not stretch it: "I cut mis-pick rate 40% by redesigning the pick path." Answer slot: if you tracked on-time or cost per shipment, name the figure and how it was counted; if you did not, say so. |
| F3 | "lead a team of 12 supervisors" (JD) | "currently a senior shift manager over 3 supervisors" (your message) | medium | [grounded] | transferability | Your evidence is three supervisors, on one shift structure. Say that: "I am a senior shift manager over three supervisors." Answer slot: if you have led more people than that, say how; if not, say so and describe how you would run twelve. |
| F4 | "5+ years operations leadership required" (JD; a length-of-experience requirement, not a gate) | "7 years in warehouse and distribution ops" (your message); "currently a senior shift manager over 3 supervisors" (your message) | low | [grounded] | discovery | Your material gives seven years in operations, not how many were in a lead role. Answer slot: count the years you held a lead or manager role, in your own words; if fewer than five, say so, then say what the seven years covered. |
| F5 | "build reporting in Excel/Power BI" (JD, Excel half) | "solid Excel" (your message) | medium | [grounded] | presentation | Bridge reworded from the quote only: "I am solid in Excel." Your material does not show reporting you built in it. Answer slot: if you have built operational reporting in Excel, name what it tracked; if not, say so. |
| F6 | "build reporting in Excel/Power BI" (JD, Power BI half) | "never used Power BI" (your message) | none | [grounded] | capability | A negative you stated, so you may say it: "I haven't used Power BI." Then how you would learn it, said as a plan and never as a past. Never claim Power BI work. |
| F7 | "Lean/Six Sigma a plus" (JD) | "green belt certified" (your message) | medium | [grounded] | none | "I am Green Belt certified." Caveat: the certificate is not inspected, so expect a probe on a project behind it. |

Confidence grades your evidence. Provenance grades what this pack wrote. Gap type says how each requirement's gap is handled.

## Prohibited claims

Not coached, because each would stretch something you said. The honest form is the quote at its own scope.

| Not coached | Basis | Honest form |
|---|---|---|
| Owns daily operations across four sites | Inflated form of F1: the material says one site | "I ran the site's peak-season surge plan two years running." |
| Leads 12 supervisors | Inflated form of F3: the material says three | "I am a senior shift manager over three supervisors." |
| Drove on-time performance and cost-per-shipment down | Inflated form of F2: the material says a mis-pick rate | "I cut mis-pick rate 40% by redesigning the pick path." |
| Built Power BI reporting, or built reporting at scale | Inflated form of F5 and F6: no reporting is in the material, and Power BI is stated unused | "I am solid in Excel." and "I haven't used Power BI." |

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | Live problems on four sites and the on-time gap | High. The JD is operational and multi-site; a hiring manager will test whether you can diagnose before you prescribe. | Clarify, baseline, segment by site, then act. Think aloud. |
| Skeptic | "You have three supervisors; this job has twelve" | High. The 5+ years line, the scale jump, and the Power BI gap are the three likeliest objections. | Rehearse the scale objection until it is boring. Bridge from what you actually did; say limits plainly. |
| Data-Driven Prober | "How was the 40% counted?" | Medium-high. A headline metric on the CV draws probes; the JD also names reporting. | Name the weakest assumption before they do. Say plainly what you do not know. |
| Pressure / Stress | "Why should we believe you can scale this?" | Medium. A hiring manager with a 12-person team to fill often pushes. | Hold the claim you can defend for two follow-ups, then concede the specific limit. |
| Conversational / Rapport | Friendly opener, "walk me through your journey" | Medium. Usually a screen or opener; still scored. | Practise a 90-second career arc. Treat casual questions on JD topics as scored. |
| Values / Behavioral | Stories about peaks, pressure, and unpopular truths | Low-medium. No loop source names a values round and no company values were read, so no values round is detected. Behavioral stems stay because they are generic. | Map a story where your material carries one; where it does not, select one and say so rather than invent an ending. |

Weighting reasoning: no interviewer name, no round type, and no loop source, so weights follow the hiring-manager prior with the Skeptic and Case personas up. This is a pattern, not a documented process at Atlas Freight.

## Question banks

Types: CASE, JD, EXP, VAL. Question IDs are letter-by-persona so drills can reference them. Answer slots are instructions for the interview, not questions to me.

### Case / Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Your four sites run on-time at different rates. Where do you start in your first 30 days?" | CASE | [generic] | Clarify what on-time means and how it is measured. Get a baseline per site. Segment (by shift, by lane, by product) before you pick a fix. Name the first two actions and how you would know they worked. | Covers R1 and R2 from the JD. Generic: a pattern for the problem, not a fact about this employer. |
| C2 | "Cost per shipment rose about 8% over two quarters. Diagnose it." | CASE | [generic] | Ask what changed first: volume mix, labour hours, the cost basis itself. Split the rise into controllable and uncontrollable parts. Name one hypothesis to test first. | Covers R2 (cost-per-shipment). Generic. |
| C3 | "A site is two supervisors short in peak week. What do you do this week?" | CASE | [generic] | Protect the critical roles first. Decide what work stops or moves. Say who you would call, and what you would tell the team. | Covers R3 (leading 12 supervisors) in a live form. Generic. |
| C4 | "Mis-pick rates rose after a new hire class. What's your first move?" | CASE | [generic] | Check whether the rise is the new class or the process change. Look at the pick path and the training before you blame the people. | Adjacent to F1's pick-path quote, but asked as a problem, not a record. Generic. |
| C5 | "Build the on-time dashboard a site lead would use: what do you show, and what decision does it drive?" | CASE | [generic] | Name the three to five measures the decision depends on. Say what each one tells the site lead to do. Say where the data comes from and how often it refreshes. | Covers R4 (reporting) without any claim about your past. Generic. |

### Skeptic (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| S1 | "You run three supervisors today. This job has twelve across four sites. What's your evidence you can do that?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" (your message) | The highest-ROI rehearsal in this pack. Hold: "I am a senior shift manager over three supervisors." Answer slot: if you have led more people or more than one site, say how, in your own words; if not, say so plainly and describe how you would structure the twelve. Hold through two follow-ups by returning to the three you lead, never by adding to it. | F3 is the largest gap against the JD's scale. Skeptics go straight to a scale jump. |
| S2 | "The posting asks for five-plus years in operations leadership. How many years have you held a lead role?" | JD | [grounded] "7 years in warehouse and distribution ops" (your message); "currently a senior shift manager over 3 supervisors" (your message) | Answer with the number you can defend, in your own words. Answer slot: if fewer than five years were in a lead role, say so plainly, then say what the seven years of operations covered. | F4 is low confidence. Do not round up to five. |
| S3 | "Power BI is in the job description. Have you used it?" | JD | [grounded] "never used Power BI" (your message) | "I haven't used Power BI." Then, as a plan: how you would learn it, with a timeline you can keep. | F6 is a stated gap, so a plain acknowledgment is honest. Coach the plan, never a past. |
| S4 | "Why leave a senior shift role for a job with twelve people and four sites?" | JD | [generic] | No motive is in your material, so the pack does not supply one. Give the reason you actually have. If it is scope, say what scope you want and which part of your current work already points that way. | Motivation probes are standard in skeptic loops. Generic because the motive is yours to state. |

### Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Walk me through how the 40% mis-pick reduction was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Say the baseline period, the measurement, and what the 40% is relative to. Then name the weakest assumption behind it before they do. Answer slot: if you know how it was counted, say so in your own words; if not, say plainly that you do not know. | A headline CV figure is the likeliest prober target. Do not explain how it was reached if you cannot repeat it under a second question. |
| P2 | "Which part of the pick-path change was yours to decide?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Answer slot: if you made the design decisions, say which and how; if others decided parts, or you implemented someone else's design, say that plainly. | Attribution probe. The honest answer is precise, not bigger. |
| P3 | "How would you show on-time performance and cost-per-shipment to a site lead, from raw data, in Excel?" | JD | [grounded] "solid Excel" (your message) | Describe the sheet you would build: the source data, the measures, the refresh. Answer slot: if you have built operational reporting in Excel, name the file and what it tracked; if not, say so and describe the build. | Covers R4 in Excel. Power BI is a separate gap, handled by S3. |

### Pressure / Stress (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| X1 | "Your mis-pick number is good, but it's one metric at one site. Why should we believe you can move on-time performance at four?" | JD | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Hold: the result is real, and it is one metric at one site. Concede the scope limit specifically. Do not fold on the result. | Hold-then-concede. The second follow-up is where a held position breaks if it is stronger than your material. |
| X2 | "That surge plan: how much of its result was actually you?" | EXP | [grounded] "ran the site's peak-season surge plan two years running" (your message) | Hold what you ran, in your own words. Concede which parts were shared or set by others, if that is true. Do not invent a share. | Attribution pressure. Hold the part you ran; concede the rest specifically. |
| X3 | "Be honest: why shouldn't we hire someone who already runs a bigger team?" | JD | [generic] | Acknowledge the strength of that candidate in one sentence. Then name the part of the role you can do now and the part you would have to grow into. Concede the gap, then hold your fit on the parts you can defend. | Pressure on the scale gap, asked as a comparison. Generic. |

### Behavioral (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time you led a team through a peak period." | VAL | [grounded] "ran the site's peak-season surge plan two years running" (your message) | Open prompt mapped from your quote: the peak plan, the two years, and what you did in each. Tell it in your own words. If the team in question was not yours to lead, say so and say what you did run. | Behavioral stems on peaks are standard for this role. |
| B2 | "Tell me about a time you had to tell a senior leader something they did not want to hear." | VAL | [generic] | Select a time you held a position under pressure from someone senior. It needs a named stake, a moment you did not fold, and a relationship that was intact after. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry. | Generic stem. Your material does not show this, so the honest branch is the scaffold. |

### Conversational / Rapport (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R1 | "So, walk me through your journey." | JD | [grounded] "7 years in warehouse and distribution ops" (your message); "currently a senior shift manager over 3 supervisors" (your message) | A 90-second arc in this order: where you started, what you did in warehouse and distribution, where you lead now. Use only the sentences in the quotes. | Opening question; the answer sets the rest of the interview. |
| R2 | "Tell me about the Green Belt, what project did you run?" | JD | [grounded] "green belt certified" (your message) | Answer slot: if you ran a project under the Green Belt, name it and what it changed; if the certificate was the course alone, say so. | Covers the Lean/Six Sigma plus (F7). Expect a probe on the project behind it. |

## Requirement coverage

| JD requirement | Covered by |
|---|---|
| "Own daily terminal operations across 4 sites" | C1, S1, F1 |
| "drive on-time performance and cost-per-shipment down" | C1, C2, P3, F2 |
| "lead a team of 12 supervisors" | S1, C3, X3 |
| "build reporting in Excel/Power BI" | P3, C5, S3, F5, F6 |
| "5+ years operations leadership required" | S2, F4 |
| "Lean/Six Sigma a plus" | R2, F7 |

## Reverse questions

Each lands for a reason. Ask the ones that fit the interviewer you meet.

1. "What does the first 90 days look like for the person in this role, and what would success look like at day 90?" Lands because it shows you are planning for the job, not just the interview.
2. "How are the four sites' on-time figures tracked today, and who reviews them?" Lands because it tells you where the reporting gap is before you claim to fill it.
3. "Which of the twelve supervisors are newest, and what support do they get?" Lands because it shows you are thinking about the team, not only the metrics.
4. "What reporting does leadership review weekly, and is Power BI already in use?" Lands because it tests whether the Power BI gap matters on day one.
5. "What would make the first six months a clear success for you personally?" Lands because it asks the hiring manager to say what they want, which is the strongest signal you can get.

## Research and sources

Provided documents: the JD text you pasted, and your message describing your background.

Research tier: L1 — searches 2 of 6, fetches 0 of 2; user links read: none

Search and fetch calls sent: "Atlas Freight regional logistics company values" (search, refused), "Atlas Freight operations manager interview process" (search, refused). Search permission was not granted in this session, so no results came back.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Atlas Freight values | unavailable | Refused. Would have moved the values cheat sheet, which is not built: no values round is detected. |
| 2. Atlas Freight interview process | unavailable | Refused. Would have moved the loop structure and the persona weights. Both rest on the archetype fallback instead. |
| 3. Atlas Freight strategy / recent news | unavailable | No call sent; search permission was not granted. Would have moved the CO bank, which is absent from this pack. |
| 4. Interviewer name and company | n/a | No name given, so there was no query to form. The interviewer read is absent. |
| 5. Representative operations manager JD | skipped | The JD you pasted fixes the fit snapshot and the JD-tagged questions. |

Loop detection: no loop source establishes the loop. The persona weights rest on the generic archetype (flat weights, said plainly), not on a documented Atlas Freight process.

The company name is unresearched. Anything about Atlas Freight in this pack comes from the JD you pasted, not from research.

## Upgrade menu

- Who you are meeting and the round type → persona weights and the reverse questions reweighted to that round
- The interviewer's name → a tailored reverse question, and weights read from their public footprint, if web search is permitted
- The recruiter's prep email, if one exists → coverage of any declared focus area or deliverable
- Atlas Freight's values page, pasted → the values cheat sheet, and VAL questions mapped to published values
- Atlas Freight's recent news or strategy, pasted → the CO bank, and the differentiator questions
- Your CV → F4 and F1 rise from low and medium, and the stories behind your quotes get more exact
- Your Power BI plan, if you have one → the S3 answer gets a concrete learning step you can state
