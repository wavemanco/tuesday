Your prep pack is saved at /tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-alone-part-2-rooms-case-7-canned-175b6548/0399096b-03ca-480f-a751-208e2e5c8382/scratchpad/saltmarsh_live-operations-producer_interview_pack.md. I built it for the Outage Hour: the company's careers page describes the interview as one 60-minute hiring-manager session with a live-incident tabletop, then a values conversation. That matches your slot, so I didn't need to ask you anything.

The three things to spend your time on:

- **The KPI ownership gap (C1).** The JD says you'll "own the post-event review and the KPIs it reports." Your material says you presented the retention numbers. This is the most likely objection, so it gets the deepest rehearsal. The honest answer depends on whether you chose the KPIs or were handed them.
- **The tabletop (A1 to A5).** It's a live outage during an event, so structure matters more than past experience. Clarify scope first, then decide who owns the fix and what to say to players.
- **The values round (B1 to B4).** Two of the three published values have a story from your material, and the third doesn't. For Players Before Plans and Leave the Build Greener, the pack gives you a selection scaffold with an honest "say so plainly" branch, not an invented story.

Two things from research: Saltmarsh announced Project Larkspur in September 2026, which moves two titles to one shared events calendar from February 2027. Reverse question 2 uses it. Tobias also gave a GDC 2026 talk, "Patch Notes Are a Promise," which makes release checklists a good topic for you. I only saw the talk's listing, not its text.

I'm assuming Friday's session is the Outage Hour. If it's a different session, the weights change.

Two offers, neither pushed:
- Say the word and I'll play Tobias on C1, the question the pack names as your highest-priority prep.
- I can save a tuesday-dossier.md recording the gaps this prep exposed, so you can carry them into later sessions.

If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh_live-operations-producer_interview_pack.md -----
# Live Operations Producer, Saltmarsh Games: interview prep pack

**Role:** Live Operations Producer, Saltmarsh Games (mobile, about 350 people)
**Interviewer:** Tobias Wrenfield, Head of Live Operations. Hiring manager, per the company's interview page.
**Round:** The Outage Hour, one 60-minute session: a live-incident tabletop, then a values conversation. No take-home.
**Mode:** Session. Prepared 2026-11-11.

---

## 2. How to use this pack

Personas describe how a question arrives. Types describe what is being scored.

| Type | Name | What it scores |
|---|---|---|
| VAL | Behavioral / values | Whether past behavior shows Saltmarsh's published values |
| EXP | Experience deep-dive | Whether your claims survive questions, and what you actually did |
| JD | Role-driven | The listed responsibilities and qualifications, gaps included |
| CO | Company and strategy | Whether you know what the company is doing now |
| CASE | Live problem | Structure and reasoning on a role problem; asks nothing about your past |

Guidance is scaffolding, not a script. Answer in your own words. Where the guidance says "say so plainly", that is a true answer, and it is the answer the interviewer is testing for.

---

## 4. Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" (JD) | "I ran the weekly content-drop calendar for the main title for the last two years." (your message) | medium | [grounded] | transferability | Your material says one title and weekly content drops, not two titles and live events. The bridge stays at that scope: "I ran the weekly content-drop calendar for the main title for the last two years." Answer slot: if you planned events or split a calendar across more than one title, say which and how. If you did not, say so and describe how you planned that one title's drops. |
| F2 | "experience running a content calendar" (JD) | "I ran the weekly content-drop calendar for the main title for the last two years." (your message) | medium | [grounded] | none | The quote reaches the requirement directly. Expect a probe on how the calendar was built and what it fed, not on whether you ran one. |
| F3 | "3+ years producing live-service games or apps" (JD) | "4 years as an associate producer at a puzzle-game studio." (your message) | medium | [grounded] | presentation | The years are there. Your material does not use the words "live-service", so the bridge reworks only the quote: "I spent four years as an associate producer at a puzzle-game studio." Length of experience is graded on fit, not treated as a gate. |
| F4 | "manage the release checklist with QA" (JD) | "Wrote the release checklist our QA team still uses." (your message) | medium | [grounded] | none | No gap. Expect a probe on what the checklist checks and whether it has ever stopped a release. See A2, B2 and D3. |
| F5 | "comfortable with player-retention metrics" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | medium | [grounded] | presentation | The quote reaches the requirement in other terms. Bridge: "I presented the monthly retention numbers to the studio head." Answer slot: how the figure was counted, and which assumption behind it you would defend least. If you do not know how it was counted, say so. |
| F6 | "own the post-event review and the KPIs it reports" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | low | [inferred] | transferability | Derivation: presenting a KPI is adjacent to owning the KPIs and the review. The quote does not show that you chose the KPIs or ran a review after an event. This pack's observation: your material shows presenting the numbers, not setting them. Answer slot: if you chose which figures went into a report, or ran a review after an event, say which and how. If the numbers were set elsewhere, say so and name the KPI you would define first. |
| F7 | "coordinate design, art, engineering and community teams on each update" (JD) | "Wrote the release checklist our QA team still uses." (your message) | low | [inferred] | discovery | Derivation: a checklist is a cross-team artifact, so coordination may exist without the material showing it. The quote touches a release process with QA and does not show coordination across design, art, engineering or community. Answer slot: if you coordinated any of those four on a release, say which and how. If you worked mainly with QA, say so and describe that. |
| F8 | "clear written communication" (JD) | none given | none | [grounded] | discovery | Your material shows one written artifact, the release checklist, and no sample of your writing. Answer slot: name one written piece you produced and who relied on it. |

Not in the JD, but raised by your own notes: in-app purchases and people management. The JD names neither. They appear only as your stated negatives in the prohibited list (section 13) and in the Skeptic bank.

---

## 7. Reading the interviewer

**Public footprint only.**

- **Career pattern:** Head of Live Operations. A GDC 2026 talk listing describes him as previously a QA lead at a console studio.
- **Talk:** "Patch Notes Are a Promise." Its argument, per the listing: a live team is judged by how often its patch notes describe what actually shipped.
- **Self-described style:** not available beyond the talk's own argument. Nothing further is inferred.

**Practical implications**

1. Expect release-quality probes from his QA background. The release checklist (F4) is a rehearsal topic, not a side point.
2. His talk thesis matches the published value "Ship the Patch Not the Promise." Use the value's own words when you talk about checklists.
3. Expect probes on whether announcements matched shipped builds (B2).

**Mirror opportunity:** the release checklist with QA, which matches his QA background. Quoted from your material: "Wrote the release checklist our QA team still uses." (your message). This is a shared domain, not a shared career jump, so no jump is offered.

The talk is known from a search listing only. Its text was not read.

---

## 8. Persona table

Relationship: hiring manager. The company's interview page establishes the loop: one 60-minute session, a tabletop, then a values conversation. Session mode, so weights reflect that one session.

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy | Depth |
|---|---|---|---|---|
| Case/Strategist | An outage tabletop during a live event; a two-title calendar | Highest. The company documents the tabletop, and a hiring manager is buying capability | Clarify, then triage, then decisions. Say the trade-offs aloud | 5 (A1 to A5) |
| Values/Behavioral | The values conversation on the three published values | High. The round is documented | Map only what your quotes carry. Where none does, say so | 4 (B1 to B4) |
| Skeptic | KPI ownership, no team leadership, no in-app purchase experience | High. These are the gaps between the JD and your material | Plain acknowledgment of stated negatives. Bridges at quote scope | 4 (C1 to C4) |
| Data-Driven Prober | How the retention figure was counted | Medium. One CV-style number, presented rather than owned | Name the assumption you would defend least. "I don't know how it was counted" is a valid answer | 3 (D1 to D3) |
| Pressure | Composure on the leadership gap and the retention presentation | Medium. A single time-boxed hour | Hold the position through two follow-ups, then concede specifically | 2 (E1, E2) |
| Conversational | The opener, and what you have been playing | Low to medium. A 60-minute hiring-manager opener is still scored | A 90-second arc, prepared in advance | 2 (G1, G2) |

---

## 9. Question banks

### A. Case/Strategist (weight: highest)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "It's Saturday, mid-event. A patch went out at ten and players are reporting a reward missing. Walk me through it." | CASE | [generic] | Clarify first: the scope, which title, how many players, what changed in the patch. Then name who owns the fix, the call on the event (keep running, pause the reward, post a notice), and who you would pull in: engineering, QA, community. Say the trade-off aloud. This makes no claim about your past. | The company documents this tabletop, so it is the highest-weight question. It is CASE because it tests structure, not experience. |
| A2 | "The next event ships Friday. Design wants a late change, and QA says the release checklist isn't finished. What do you do?" | CASE | [grounded] "Wrote the release checklist our QA team still uses." (your message) | Name the gate and who owns the call. Then what you would cut and what you would hold. The checklist is the reference point: say what it is for and that QA signs off on it. Answer slot: if you have held a release on the checklist, say so and what decided it. If you never had to, say so plainly and say how you would decide. | Covers F4 and F7. The question presumes the JD's release process. The second branch allows that no hold ever happened. |
| A3 | "Two titles, one shared calendar, and events landing in the same week. How do you plan it?" | CASE | [grounded] (JD line: "Plan and run the live-events calendar for two of our mobile titles") | Clarify the constraints: player time zones, which event carries more risk, the release slots. Set the priority rule before you assign slots. Name the trade-off between the two titles' players. | The JD's first line is the scoring sheet for this case. |
| A4 | "Retention dropped eight percent in the week after an event. Where do you start?" | CASE | [generic] | Clarify the denominator and the cohort: which players, which event, how retention is defined. Check whether the drop comes from the event, the calendar or a release before you blame any one. Name the first query you would run. | Tests the post-event review requirement (F6) without asking you to have run one. |
| A5 | "Players say a new season pass feels like a paywall. Community is loud, and design disagrees with them. What's your move?" | CASE | [generic] | Separate what players say from what the numbers show. Name the decision owner. Propose a test that could settle the disagreement before you take a side. | Tests the cross-team coordination in F7 under a live disagreement. The scenario is a pattern for season-pass launches, not a fact about this company. |

### B. Values/Behavioral (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time you put a player's experience ahead of a calendar date." | VAL | [generic] | Pick a time a dated plan and a player problem collided. Name the stake, what you moved and what you held. If no such time comes to mind, say so plainly, then give the nearest case your material carries, or how you would handle it. | Players Before Plans is the first published value. None of your sentences covers a player-over-calendar call, so this is a selection scaffold with its honest branch. |
| B2 | "Tell me about a time an announcement had to match what actually shipped." | VAL | [grounded] "Wrote the release checklist our QA team still uses." (your message) | The quote gives the beats: you wrote the checklist, and QA still uses it. Say, in your own words, what the checklist checks before anything is announced. Answer slot: if you can name one thing it caught or stopped, say so. If you cannot, say so plainly and describe how the checklist protects an announcement. | Ship the Patch Not the Promise is the value. This quote is the only sentence of yours that touches it. |
| B3 | "When did you leave a process or an artifact better for the next person?" | VAL | [generic] | Pick a process you changed for someone else. Say what it was before and what it is after, in your words. If none comes to mind, say so plainly, then give the nearest thing your material carries. | The third value's definition was not retrieved (see section 10), so this cell uses the value's name only. The scaffold's honest branch applies. |
| B4 | "Tell me about a time you had to give leadership news they didn't want." | VAL | [grounded] "Presented the monthly retention numbers to the studio head." (your message) | Hold to the quote: you presented the monthly retention numbers to the studio head. Say what the head did with them, if you know. Answer slot: if the numbers were unwelcome and you said so, say what happened. If they were not contested, say so, and give the nearest case of a number you had to deliver. | The quote carries the presentation, not the reaction, so the slot asks for the reaction. |

### C. Skeptic (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "The role owns the post-event review and the KPIs it reports. You presented retention numbers. Which of the KPIs did you choose?" | JD | [grounded] "Presented the monthly retention numbers to the studio head." (your message) | Hold the quote: you presented the monthly retention numbers to the studio head. Hold through two follow-ups by returning to what you presented. Concede specifically, never on the core: if you did not choose the KPIs, say so and name the one you would define first. Answer slot: if you chose which figures went into the report, or ran a review after an event, say which and how, in your own words. | **Highest-ROI prep in this pack.** The JD says "own" and your material says "presented", so this is the most predictable objection. The rehearsal is deepest here. The second branch allows that the KPIs were set elsewhere. |
| C2 | "You've never led a team. How will you coordinate design, art, engineering and community with no authority over any of them?" | JD | [grounded] "Never led a team" (your message) | Plain acknowledgment: "I haven't led a team." Then describe only what your material shows: "I wrote the release checklist our QA team still uses." Answer slot: if you coordinated any of the four on a release, say which and how. If you worked mainly with QA, say so and describe how you would bring in the other three. | The JD asks you to coordinate four teams, not to lead one. The question turns that into a leadership probe. Your acknowledgment is yours to give because you stated the negative. |
| C3 | "Have you worked on anything with in-app purchases?" | EXP | [grounded] "never worked on a game with in-app purchases" (your message) | Plain acknowledgment: "I haven't worked on a game with in-app purchases." Then one sentence from your material that carries across: "I ran the weekly content-drop calendar for the main title for the last two years." Do not claim the calendar taught you monetisation. | In-app purchases are not in the JD, so this is a probe, not a requirement. The honest answer is the acknowledgment. |
| C4 | "Why leave a puzzle studio you spent four years at for this role?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio." (your message) | Name what drew you to live operations, in your own words. Then the four years: what you learned there that this role needs. Answer slot: if you have a specific reason to move, say it. If the move is about the role itself, say that. | Motivation is a Skeptic's probe. The four years are the quoted sentence it rests on. |

### D. Data-Driven Prober (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how that retention number was counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head." (your message) | Say what you know about the counting: the definition, the cohort, the period. Answer slot: if you did not set or check how it was counted, say so plainly. Then name the assumption behind the figure you would defend least, in your words. | Every headline metric gets a defend-the-number question. The count is not in the quote, so the honest answer is the slot. |
| D2 | "Which assumption behind that retention figure would you defend least?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." (your message) | Name the weakest assumption you know of, before the interviewer names it for you. If you know of none, say you do not know how the figure was counted. This cell supplies no figure and no method. | The weakest-assumption move. Your quote gives no assumption, so the cell asks for yours. |
| D3 | "Tell me about a time the release checklist stopped a release. If it never did, say so." | EXP | [grounded] "Wrote the release checklist our QA team still uses." (your message) | Open prompt. If the checklist ever held a release, say what it caught and who decided. If it never did, say so, then describe what the checklist is for. No event is supplied. | The raising source is the JD's "manage the release checklist with QA". This tests whether your checklist record survives a probe. |

### E. Pressure (weight: medium-low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why should we hire someone who has never led a team over someone who has?" | JD | [grounded] "Never led a team" (your message); [grounded] "I ran the weekly content-drop calendar for the main title for the last two years." (your message) | Hold on the calendar: that is your strongest true claim. Concede the gap specifically: "I haven't led a team, and for a role that coordinates four functions, that's a real question." Do not fold on the calendar, and do not add a leadership claim. | Pressure on the gap. Hold on the quoted claims only, then concede the stated negative. |
| E2 | "That retention presentation: how much of it was actually you?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." (your message) | Hold to the quote: you presented them. Concede what was not yours, as the quote shows it. Answer slot: if you did more than present them, say which part and how. If not, say so plainly. | A time-boxed attribution challenge. Hold the presentation, concede the rest. |

### G. Conversational (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the last four years." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." (your message); [grounded] "I ran the weekly content-drop calendar for the main title for the last two years." (your message) | A 90-second arc in this order: the four years, the two years on the calendar, the checklist, the monthly numbers. Use your own words. Add nothing. | A casual opener that is still scored on delivery and time. The quotes are the arc's beats. |
| G2 | "What live-service game have you played lately, and what did you notice about its events?" | JD | [generic] | Name one live-service game you have actually played, and one event you noticed in it. If you have not played one recently, say so plainly. | A casual question on a JD topic. Labelled [generic] because nothing in your material says what you play. |

---

## 10. Values cheat sheet

Included because the company's interview page documents a values conversation in the Outage Hour. Values are from the company's own values page, read through a search result. The page was not fetched.

| Value (official name) | Working meaning (paraphrased) | Your mapped story |
|---|---|---|
| Players Before Plans | When the calendar and the players disagree, the players win. | No quoted sentence carries it. Selection scaffold, with its honest branch, in B1. |
| Ship the Patch Not the Promise | Announce what is built, not what is hoped. | F4: "Wrote the release checklist our QA team still uses." (your message). Story: the checklist as the gate between built and announced, in B2. Answer slot: what it has caught. If nothing, say so. |
| Leave the Build Greener | Not retrieved. The search result cut off before its definition. | No mapping from the material. Selection scaffold in B3, honest branch applies. Fetch the values page to firm this up (see upgrade menu). |

---

## 11. Reverse questions

Ask these at the end. Each one tests something specific.

| # | Question | Why it lands |
|---|---|---|
| 1 | "In the Outage Hour's tabletop, what separates a strong answer from a weak one?" | Shows you read the process, and gets the scoring from the person doing the scoring. |
| 2 | "Project Larkspur moves Tidepool Tactics and Lantern Row to one shared events calendar from February 2027. How will the single live-ops group split its time across those two titles before then?" | Uses the company's public announcement, and tests altitude on the same calendar problem the JD describes. |
| 3 | "Your GDC talk argues a live team is judged by how often its patch notes describe what shipped. Which one measure would you want this role to own?" | Ties his public path to the role. |
| 4 | "Who owns the post-event review today, and where do the KPIs it reports come from?" | Asks the KPI-ownership question directly. The answer tells you what the role really owns. |
| 5 | "How do design, art, engineering and community plan an update together today, and which document is the source of truth?" | Tests the coordination requirement, and shows you read the four teams. |
| 6 | "What would you need to see in the first 90 days to call this hire a success?" | Standard, but scored. It lets you name the calendar. |

---

## 13. Prohibited claims

Built from the fit snapshot before the banks were written. Each entry names its basis.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the live-events calendar across two titles | Inflated form of F1. Your sentence is one title's weekly content drops. | The F1 quote at its own scope. This pack's observation: your material says one title's drops, not two titles' events. |
| Owned the post-event review and the KPIs it reports | Inflated form of F6. Your sentence is "Presented the monthly retention numbers to the studio head." | The quote at its own scope. This pack's observation: presenting, not setting. C1's slot asks which KPIs you chose. |
| Led cross-functional teams on releases | Inflated form of F7. The quote is a QA checklist, nothing more. | The QA quote at its scope. This pack's observation: no coordination across the four functions is shown. |
| Led a team | Negative you stated: "Never led a team." | Plain acknowledgment: "I haven't led a team." No answer slot. |
| In-app purchase or monetisation experience | Negative you stated: "never worked on a game with in-app purchases." | Plain acknowledgment: "I haven't worked on a game with in-app purchases." No answer slot. |

---

## 14. Sources

**Provided documents:** the JD text and your background, both in your message. No CV. No dossier.

**Searches and fetches**

| Query | Returned |
|---|---|
| Saltmarsh Games values | saltmarshgames.com/values (search snippet only; not fetched) |
| Saltmarsh Games interview process Live Operations Producer | saltmarshgames.com/careers/interviewing (fetched) |
| Saltmarsh Games strategy news | saltmarshgames.com/news/project-larkspur (fetched) |
| Tobias Wrenfield Saltmarsh Games Head of Live Operations | talks.gdconf.example/2026/patch-notes-are-a-promise (search snippet only; not fetched) |

**Research tier: L1 — searches 4 of 6, fetches 2 of 2**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | yes | Values in section 10, by name and the first two meanings from the snippet. The third meaning is cut off in the snippet. |
| 2. Saltmarsh Games interview process, Live Operations Producer | yes | The loop: a 60-minute hiring-manager Outage Hour with a tabletop and a values conversation. This sets the persona weights and the CASE bank. |
| 3. Saltmarsh Games strategy / recent news | yes | Project Larkspur (September 2026): season-pass model, one shared calendar from February 2027, per-title event teams retired. Feeds A5, reverse question 2, and the calendar framing in A3. |
| 4. Tobias Wrenfield, Saltmarsh Games | yes | GDC 2026 talk listing, "Patch Notes Are a Promise", and a QA-lead background. Feeds section 7 and reverse question 3. The talk text was not read. |
| 5. Representative Live Operations Producer JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions. |

Un-numbered calls: none.

---

## 15. Upgrade menu

- A transcript or slides from Tobias's talk → quotes from his argument for B2 and reverse question 3. Today the talk is known from a listing only.
- The values page, fetched → the third value's meaning, which upgrades B3 from a scaffold. It also confirms the wording of the other two.
- Confirm that Friday is the Outage Hour → the weights above rest on the company's documented round. If Friday is a different session, the weights change.
- A written sample, such as a post-event review or release notes → upgrades F8 from discovery, and gives B2 a second sentence.
- Which KPIs you chose for the retention report, and how the figure was counted → upgrades F5 and F6, and D1 and D2.
- Whether you coordinated design, art, engineering or community on a release → upgrades F7 from discovery.
- Your CV → more quoted sentences for the fit snapshot. Confidence can rise above medium where the CV carries an inspectable artifact.
- A deeper research pass (L2): up to 6 more searches and 2 more fetches, several minutes. It would add a strategy brief, Tobias's other talks, loop reports from candidates, and recent leadership context. Want it?
