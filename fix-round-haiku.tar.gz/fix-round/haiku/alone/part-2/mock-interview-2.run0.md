Your prep pack is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-alone-part-2-rooms-case-2-denied-4cbc349d/f1ab6919-e27a-4dd4-b756-22e468ade605/scratchpad/atlas-freight_operations-manager_interview_pack.md`. I built it without knowing who you're meeting, so it assumes a hiring-manager round, and I didn't run any web research.

**Where the JD will press you:**
- **Scale:** you lead three supervisors; the role says twelve. This is the most likely objection, so it gets the deepest rehearsal (A1, D3).
- **Years in leadership:** "7 years in warehouse and distribution ops" doesn't show how many were leadership. The JD asks for 5+ (A2).
- **Four sites:** nothing in your material shows you've run more than one (A3).
- **Power BI:** you've never used it. The honest answer is "I haven't used Power BI," followed by a plan. Don't bridge it to Excel (A4).
- **On-time and cost-per-shipment:** your 40% mis-pick cut is an accuracy metric, not either of these (A5, C4).

**Highest-ROI prep:** rehearse A1 until the concession sounds natural. Then work C1 and C2 on the 40% figure: how it was counted, its baseline, and the assumption you'd defend least. If you can't answer those from memory, say so in the interview rather than inventing a baseline.

The pack has 20 questions across seven personas, a coverage table against every JD requirement, five reverse questions, and a list of claims not to rehearse, such as "runs four sites" or "built Power BI reporting."

Two questions before I rework the weights:

1. What round is this, and who are you meeting? A hiring manager, a peer, or a skip-level? Anything the recruiter said about focus areas or a take-home also helps.
2. Can you work at all four sites on the schedule the role needs? Your material doesn't say, and I've flagged it as unresolved.

Offers, not pushed:
- I can run a live drill: I play the Skeptic on A1 and push back on your answer.
- I can save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions.
- I can convert the pack to Word if you'd like it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: atlas-freight_operations-manager_interview_pack.md -----
# Atlas Freight — Operations Manager interview prep pack

**Role:** Operations Manager, Atlas Freight (regional logistics, 800 employees)
**Interviewer:** not given. **Relationship:** not given. Working assumption: hiring manager round (see persona table).
**Changelog:** first version.

## How to use

- **Personas** = how a question is asked (the register). **Types** = what is being scored.
- Type key: **JD** role/JD-driven · **EXP** your past work, tested for attribution · **CASE** live problem · **VAL** values/behavioral · **CO** company knowledge (none in this pack: no research run).
- Guidance is scaffolding for a spoken answer of 90–120 seconds, not a script.
- Question IDs are letter-by-persona (A1, B2…) so you can refer to them in drills.

## Fit snapshot

Requirements are the JD's own words. Evidence is quoted from your message; no CV was supplied.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" — JD | "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | Your material describes one shift role over three supervisors. It does not say how many sites you have run. Words: "I'm a senior shift manager over three supervisors." Answer slot: if you have run operations across more than one site, say which and how you kept them consistent, in your own words; if you have run one, say so and name what carries over. |
| F2 | "lead a team of 12 supervisors" — JD | "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | Scale gap: three supervisors against twelve. Words: "three supervisors." Answer slot: if you have led more than three supervisors, or a layer above them, say when and how; if not, say so, and say how you would build a team of twelve. |
| F3 | "5+ years operations leadership required" — JD | "7 years in warehouse and distribution ops" — your message | low | [inferred] | discovery | Seven years of operations is in the material. How many of those years were in leadership is not. Answer slot: give the years you have led people, in your own words; if it is under five, say so and say what you would bring from the other years. |
| F4 | "build reporting in Excel/Power BI" — JD | "solid Excel" — your message | low | [inferred] | discovery | "Solid" is a self-rating with no artifact behind it. The material does not show reporting you built. Answer slot: name any reports you have built in Excel and what they changed; if you have mostly used spreadsheets others built, say so. |
| F5 | "build reporting in Excel/Power BI" — JD | "never used Power BI" — your message | none | [grounded] | capability | Power BI is an absence you stated. Words: "I haven't used Power BI." Then how you would learn it, said as a plan and never as past use. |
| F6 | "Lean/Six Sigma a plus" — JD | "green belt certified" — your message | medium | [grounded] | none | The quote already reaches the requirement. Words: "I'm Green Belt certified." Limit: a certificate you can produce would raise this to high; expect a probe on the project behind it. |
| F7 | "drive on-time performance and cost-per-shipment down" — JD | "cut mis-pick rate 40% by redesigning the pick path" — your message | medium | [grounded] | transferability | Adjacent work: an accuracy measure, not an on-time or cost measure. Words: "I cut mis-pick rate 40% by redesigning the pick path." Limit, in the pack's analysis: the material says accuracy, not timeliness or cost. |
| F8 | "drive on-time performance and cost-per-shipment down" — JD | none given | none | — | discovery | Nothing in the material shows ownership of on-time performance or cost per shipment. Answer slot: which cost or timeliness measures you have owned, and how they moved; if none, say so. |
| F9 | "Own daily terminal operations across 4 sites" — JD | none given | none | [grounded] | hard_gate | The role sets terms of location and schedule (daily operations at four sites). The material does not establish them. Surfaced, not bridged; the one question on it is in the message (Step 1 item d). |

## Prohibited claims

Built locally from the fit snapshot. These are the claims a candidate reaches for under pressure. No answer in this pack asserts, softens or implies them.

| Not coached | Basis | Honest form |
|---|---|---|
| "Runs operations across four sites" | Inflated form of F1 | F1's quote at its own scope. Pack observation: the material describes one shift over three supervisors, not four sites. A1 and A3 stay inside that scope. |
| "Leads twelve supervisors" / "manages a team of twelve" | Inflated form of F2 | "three supervisors", at its own scope. A1 and D3 hold the step-up as a plan. |
| "Five-plus years in operations leadership" | Inflated form of F3 | "7 years in warehouse and distribution ops", at its own scope. Years in leadership is an answer slot (A2). |
| "Built Power BI reporting" / "has Power BI experience" | Negative you stated (F5) | "I haven't used Power BI." Plain acknowledgment; no slot on it. |
| "Built Excel reporting that changed decisions" | Inflated form of F4 | "solid Excel", at its own scope. C3 asks what you built, without assuming any. |
| "Owned on-time performance or cost per shipment" | Inflated form of F7 and F8 | The mis-pick quote at its own scope. A5 and C4 are answer slots. |

## Persona weights

No interviewer is known. The working assumption is a hiring manager round, which sets the priors to Case/Strategist and Skeptic. The gaps in the fit snapshot push the Skeptic highest, and the 40% figure and reporting requirement push the Prober up.

| Persona | Weight | Questions | How it shows up here | Why this weight |
|---|---|---|---|---|
| Skeptic | 5 | A1–A5 | The scale gap, years in leadership, four sites, Power BI, cost per shipment | Prior for a hiring manager; F1, F2, F3, F5 and F8 are the rows it will press |
| Case/Strategist | 4 | B1–B4 | Diagnose on-time performance; cost per shipment; peak plan; Lean tool choice | Prior; an operations role is scored on live problems |
| Data-Driven Prober | 4 | C1–C4 | The 40% figure, reporting, on-time performance | The one figure on your CV is a magnet for probes (F7) |
| Pressure | 3 | D1–D3 | Why you over an internal candidate; how much of the 40% was you; three supervisors vs twelve | Stress register on the same gaps |
| Conversational | 2 | E1–E2 | "Walk me through the journey"; "what are you playing with in Excel" | Casual openers still score |
| Peer Evaluator | 1 | F1 | Seam between sites and the network team | Low: no peer relationship is known |
| Values/Behavioral | 1 | G1 | A time you delivered a hard truth | Low: no values round is detected; kept so the style is not new live |

Total: 20 questions, inside the 18–26 range.

## Question banks

### A — Skeptic (weight 5)

**Highest-ROI prep:** A1. The scale gap (three supervisors against twelve) is the objection most likely to come up in some form. Rehearse it until it is boring. Hold through two follow-ups, then concede specifically.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" | Lead with what you have done: "I'm a senior shift manager over three supervisors." Hold that position through two follow-ups. Concede specifically: "I haven't led twelve; the step-up is a ramp I would plan, and here is the first thing I would do." Answer slot: if you have led more than three supervisors, say when and how, in your own words; if not, say so and give the ramp. | F2 is the scale gap. The question invites a concession; the guidance gives it a shape that does not overstate. |
| A2 | "The role asks for five-plus years of operations leadership. How long have you been leading people?" | JD | [grounded] "7 years in warehouse and distribution ops" | Give the number of years you have led people, in your words. Answer slot: if it is fewer than five, say so, then say what the other years were in and what you would bring from them. Never round the number up. | F3. The seven-year figure is operations, not leadership; the answer must keep that distinction. |
| A3 | "The role covers four sites. Have you run operations at more than one, and how did you keep them consistent?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" | Answer slot: if you ran more than one site, say which and how you kept them consistent, in your own words; if you ran one, say so plainly and name what carries over to four. | F1. The question's premise is the JD's, not your record; the second branch allows that you have not run more than one site. |
| A4 | "This role builds reporting in Power BI. You haven't used it. Why should we hire you for it?" | JD | [grounded] "never used Power BI" | Plain acknowledgment: "I haven't used Power BI." Then a plan, not a past: how you would learn it in the first 90 days, and what you would build first. Do not mention any Power BI work. | F5. A stated absence is answered with the absence, not with a bridge. |
| A5 | "Which cost measures have you owned, and how did they move?" | JD | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Use the quote as your only measured result: the mis-pick rate, cut 40% by redesigning the pick path. Answer slot: if you owned a cost or timeliness measure, name it and how it moved; if you did not, say so plainly and say which measure you did own. | F8. The question presupposes a cost measure the material does not show; the second branch allows you have none. |

### B — Case/Strategist (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "On-time performance has slipped at one of four terminals. How would you diagnose it in your first two weeks?" | CASE | [generic] | Clarify first: what "slipped" means, against what baseline, over what period. Then structure: by site, shift, lane, carrier, volume. Name the three metrics you would check first and one risk. Speak it as a plan. | A live problem from the JD's on-time line (F8). It needs no claim about your past, so it carries none. |
| B2 | "Cost per shipment is up at the network level while volume is flat. What do you check first?" | CASE | [generic] | Clarify whether the cost is labour, linehaul or handling. Then segment by site and cost line before proposing anything. State one hypothesis early and say what would disprove it. | A live problem from the cost-per-shipment line (F8). Structure matters more than the answer. |
| B3 | "Peak season starts in six weeks and one site is short of staff. What is your plan?" | CASE | [grounded] "ran the site's peak-season surge plan two years running" | You may draw on the surge plan you ran, in those words, and say which of its parts were yours to decide. Answer slot: if you set the staffing trigger or the cut-off for temporary labour, say how, in your own words; if someone else set them, say so and say what you did inside them. | Your peak plan is the strongest operational story in the material; the question invites it. The slot keeps the decisions attributed. |
| B4 | "A process has high rework. Which Lean or Six Sigma tool do you reach for first, and why?" | CASE | [grounded] "green belt certified" | Name one tool and the condition that makes you reach for it, for example process mapping or a Pareto of defect causes. Say what you would measure before and after. Do not describe a project unless you can name one. | F6. Green Belt is the credential; the guidance does not extend it to projects you have not named. |

### C — Data-Driven Prober (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how you counted the 40% mis-pick reduction." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Story-mapped on the sentence: the metric, the redesign, the 40%, in its own terms. Answer slots: how it was counted (period, baseline, denominator); what it is sensitive to; the assumption you would defend least; which part was yours. Each in your own words. If you do not know how it was counted, say so. Do not supply a baseline or a denominator you cannot repeat. | The headline figure on your CV. The four slots are the defend-the-number set; the pack does not know your baseline and must not invent one. |
| C2 | "Which assumption behind that 40% would you defend least?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Name the weakest assumption before they do: for example, that the mis-pick count was complete for the period. Answer slot: if you name one, say why you would defend it least; if you do not know what the count excluded, say so plainly. | Weakest-assumption move. Converts a gotcha into a credibility gain. |
| C3 | "What reporting have you built in Excel, and what did it change?" | JD | [inferred] "solid Excel" | Answer slot: name any reports you have built and what they changed. If you have mostly used spreadsheets others built, say so and say which parts you changed. | F4. "Solid" is a self-rating; the question asks for an artifact, and the guidance does not assume one. |
| C4 | "What is the first on-time metric you would track, and how would you know it is right?" | JD | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Answer slot: if you have tracked on-time performance, say how it was counted. If you have not, say which metric you did track and how you knew it was right. Mis-pick is the one you cut, and it is an accuracy measure. | F7 and F8. The guidance names no on-time figure; it names the measure you did have. |

### D — Pressure (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over an internal candidate?" | JD | [grounded] "7 years in warehouse and distribution ops" | Hold: anchor in what you have done and the seven years. Concede specifically: "They may have more years leading people than I do; here is what I would bring that they may not." Do not argue with the premise that someone else is better. | Pressure register on the leadership-years gap (F3). |
| D2 | "That 40% — how much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Hold through two follow-ups. Answer slot: say which part of the redesign was yours to decide, in your own words; if the redesign was a team's, say so and say what you specifically did. Do not claim the whole change. | Pressure on attribution; the slot keeps the answer to the sentence's scope. |
| D3 | "You've led three people. Why would anyone give you twelve?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" | Hold: you run a shift over three supervisors, and the cut in mis-pick came through them. Concede specifically: "I haven't led twelve. Here is how I would build the layer, and what I would check at six weeks." | F2. Hold-then-concede on the scale gap, with the step-up stated as a plan. |

### E — Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So — walk me through the journey." | VAL | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors"; "cut mis-pick rate 40% by redesigning the pick path"; "ran the site's peak-season surge plan two years running" | A 90-second arc in your own words, in that order: seven years in warehouse and distribution, now a senior shift manager over three supervisors, the mis-pick redesign, two years of peak plans, and then one sentence on why this role. | Casual openers are scored. The arc uses only your quoted sentences. |
| E2 | "What are you playing with in Excel these days, and anything in Power BI?" | JD | [grounded] "solid Excel, never used Power BI" | Excel: say what you actually do in Excel, in your words; do not repeat "solid" as a claim of expertise. Power BI: "I haven't used Power BI," then how you would start. | F4 and F5 in a casual register. |

### F — Peer Evaluator (weight 1)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Our network team sits beside yours. Where's the seam, and what happens when we disagree?" | VAL | [generic] | Propose seam principles rather than pretending to know the seam: who owns the handoff, who decides when volume shifts. Name one disagreement style you use with equals and what you do after. | Low weight; no peer is known. Kept so the style is not new live. |

### G — Values/Behavioral (weight 1)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you had to deliver an unwelcome truth to leadership." | VAL | [generic] | Selection scaffold: pick a time you delivered a hard truth, with a named stake and an outcome you can state. If none comes to mind, say so plainly, then give the nearest thing your material carries, which is the peak-season plan, and how you handled the pushback. | An open prompt; no quoted sentence names this event, so the guidance supplies no event. |

## Coverage: JD requirement → questions

| JD requirement | Covered by |
|---|---|
| Own daily terminal operations across 4 sites | A3, B1, F9 (gate, surfaced) |
| Drive on-time performance down | B1, C4, F7, F8 |
| Drive cost-per-shipment down | A5, B2 |
| Lead a team of 12 supervisors | A1, D3 |
| Build reporting in Excel/Power BI | A4, C3, E2 |
| 5+ years operations leadership required | A2, D1 |
| Lean/Six Sigma a plus | B4 |

## Reverse questions

1. "What would a strong first 90 days look like for the person in this role?" *Why it lands:* it turns the Skeptic's day-one question into a plan you can build on.
2. "How is on-time performance measured across the four sites today, and where does it run hardest?" *Why it lands:* it asks for the number the role will be judged on, and shows you listen for definitions.
3. "Which of the four sites is hardest to run right now, and why?" *Why it lands:* it signals you want the operational truth, not the pitch.
4. "What reporting exists today, and what is missing that a Power BI build would fix?" *Why it lands:* it frames the gap you stated as a build task the team needs, not a deficit.
5. "What does the supervisor team look like today: tenure, and where do they need the most help?" *Why it lands:* it prepares you for the step from three supervisors to twelve, asked as a question rather than a claim.

## Sources

- **Provided documents:** the JD text and your background, both in this conversation. No CV was supplied.
- **Research tier:** L0. No search was run. The tier was not consented to; it is offered in the upgrade menu.
- **Searches sent:** none.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Atlas Freight values` | unavailable | Values cheat sheet, which is not in this pack; no values round is detected. Would have checked their published values. |
| 2. `Atlas Freight interview process operations manager` | unavailable | Loop structure and persona weights. The weights here are the hiring-manager prior, not a checked loop. |
| 3. `Atlas Freight strategy` / recent news | unavailable | The CO bank. None is in this pack. |
| 4. `{interviewer name} Atlas Freight` | n/a | No name was given, so there was no query to form. |
| 5. Representative Operations Manager JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions. |

Research tier: L0. Searches 0 of 0, fetches 0 of 0.

## Upgrade menu

- Your interviewer's name → persona weights from their public footprint, and a tailored reverse question. Also lets research check Atlas Freight's values and loop (L1).
- Round type and relationship (answer to Step 1 item a) → reweights every bank. Without it, the hiring-manager prior stands.
- Green Belt certificate → F6 rises from medium to high.
- A sample Excel report you built → C3 and F4 upgrade from low to grounded, and A4 gains a concrete example.
- Years you have led people → F3 and A2 get a number to state.
- Mis-pick figure, period, and how it was counted → C1 answerable from a repeatable count instead of a slot.
- Recruiter's prep email → any pre-declared focus areas or deliverables.
- Confirmation of the four-site and schedule requirement (Step 1 item d) → F9 is resolved either way.
