Priya's pack is saved as /tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-alone-part-2-rooms-case-1-denied-8b66ed1a/66ea5e2a-928c-45ee-87c3-c2f9d203a7fb/scratchpad/northwind_senior-gtm-strategy-lead-emerging-products_interview_pack.md, and it's attached above. I built it for a peer round with Dan, since you described him as a same-VP peer. Web search was refused on every attempt, so the company-side content (values, loop structure, strategy) rests on your research note and is labeled as such.

The pack covers 21 questions across five personas and five question types, weighted toward the Data-Driven Prober and the Peer Evaluator. The highest-ROI rehearsal is D1: "You haven't set quotas or run sales ops. What qualifies you to design a GTM plan a sales org will actually run?" Dan owns sales strategy and the JD says GTM, so this is the objection most likely to come up in some form.

Three things to check before the session:
- **The ~$400M figure** (A1, A2, A5, E2). Priya needs to know how it was counted and which part was hers. If she doesn't know, the pack tells her to say so.
- **"Volume targets" versus "quotas."** The pack keeps these separate and warns her not to let the first stand in for the second.
- **Your research note is undated.** C1, C3 and R5 use its priorities, so check the date before relying on them.

Do you want me to rerun the web searches if you approve them? That would add Northwind's official values, the interview loop, and Dan's public talks and writing.

Would you like a drill, where I play Dan and push on one question? I can also save a tuesday-dossier.md recording the gaps this prep exposed, and convert the pack to Word if you want it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: northwind_senior-gtm-strategy-lead-emerging-products_interview_pack.md -----
# Interview pack: Priya, Senior GTM Strategy Lead, Emerging Products, Northwind Data

**Interviewer:** Dan Kovac, Director of Sales Strategy. Peer, same VP. Single 60-minute conversation. Session mode.
**Built on:** the JD highlights, your summary of Priya's background, your research note, and your description of Dan. Web research did not run this time (see Sources), so the company-side content is thin and labeled as such.

## How to use this pack and type key

Personas describe how a question arrives. Types describe what is being scored. Guidance is scaffolding for a spoken answer, not a script. Rehearse the shape, then say it in your own words.

| Tag | Name | What it scores |
|---|---|---|
| VAL | Behavioral / values | Past behavior that shows a published value. None detected here, so these two are generic. |
| EXP | Work-experience deep-dive | Whether the CV's claims survive scrutiny and what Priya actually did. |
| JD | Role / JD-driven | Stated responsibilities and qualifications, including the gaps. |
| CO | Company and strategy | Whether she thinks at Northwind's altitude. Limited here, since research did not run. |
| CASE | Live problem | Structure and reasoning on a problem from the role, delivered live. |

## Fit snapshot

Requirements are quoted from the JD highlights you supplied. Evidence is quoted from your message. Nothing in the Evidence column is a summary.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" (JD highlights, your message) | "9 at a large consumer-tech company in product strategy & ops" (your message) | medium | [grounded] | transferability | Says product strategy and ops, at its own scope: nine years at a large consumer-tech company in product strategy and ops. Your material does not show go-to-market ownership for a product line. Answer slot: the JD makes a probe on GTM ownership likely. If she set go-to-market choices for a product she worked on, say which and how she decided; if not, say so and name the adjacent decisions that were hers. |
| F2 | "identify whitespace across land/adopt/expand/renew" (JD highlights, your message) | none given | none | [grounded] | discovery | The material is silent on the land, adopt, expand and renew stages. Answer slot: if she has mapped or sized where accounts sit across those stages, say how and what she counted; if not, say so and say what she would look at first. This is a plan, not a past. |
| F3 | "run independent analysis in SQL and Tableau" (JD highlights, your message) | "skilled in SQL/Tableau" (your message) | medium | [grounded] | presentation | Reword only the quote: skilled in SQL and Tableau. The quote does not show independence. Answer slot: if she pulled the data and built the views herself, say which; if someone else prepared the inputs, say so. |
| F4 | "partner-motion design experience required" (JD highlights, your message) | "built a partner-level revenue model used in carrier negotiations" (your message) | medium | [grounded] | transferability | Says a revenue model used in carrier negotiations, at that scope. Partner-motion design (channel terms, incentives, enablement) is not shown. Answer slot: if she shaped terms or incentives the model fed, say which and how she decided; if not, say so and say what the model did in the negotiations. |
| F5 | "strong cross-functional influence" (JD highlights, your message) | "set annual volume targets with cross-org consensus" (your message) | medium | [grounded] | presentation | Reword only the quote: she set annual volume targets with cross-org consensus. Do not upgrade "with consensus" to "led". Answer slot: whose call the targets were, if she knows; if the material does not show it, say so. |
| F6 | Sales operations and quota-setting: no JD line; a generic requirement that a GTM plan be run by a sales org | "No classic sales-ops or quota-setting experience." (your message) | none | [grounded] | capability | A stated absence, so the words come from her own negative. Words: "I haven't done classic sales ops or quota-setting." Then the adjacent work at its own scope: volume targets set with cross-org consensus (F5). The pack observes, in its own analysis, that the material says volume targets, not quotas. |
| F7 | "AI experience a plus" (JD highlights, your message) | "uses AI tools daily" (your message) | low | [inferred] | transferability | Clarify before the interview what the daily use is for, then say that in her own words. Daily use is the only AI evidence and it is not AI product experience. Low confidence: this is a coaching note, not a claim to assert. |
| F8 | Headline CV figure: no JD line | "proposed a store-surface change credited with a ~$400M ARR uplift" (your message) | medium | [grounded] | discovery | Says proposed and credited, at its own scope. The material does not show how the figure was counted or which share was hers. Expect a probe; the caveat is the limited inspectable proof. Answer slot: the defend-the-number slots are in A1 and A2. |
| F9 | Background: no JD line | "2 years strategy consulting at a top firm" (your message) | medium | [grounded] | none | Says consulting at a top firm, at that scope. No gap. |

Confidence grades the evidence. Provenance grades what this pack wrote. Gap type is the separate call on what needs recovering.

## Prohibited claims

Built locally from the fit snapshot, because no dossier was supplied. These are the claims a candidate reaches for under pressure. None of them may be asserted, softened or implied in any answer, hold or rationale in this pack.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned GTM strategy for a product line | Inflated form of F1 | F1's quote at its own scope. The pack's own observation: the material says product strategy and ops. |
| Has run sales ops or set quotas | Negative she stated, F6 | "I haven't done classic sales ops or quota-setting." No slot. |
| Set quotas | Inflated form of F5 and F6 | F5's quote at its own scope. The material says volume targets. |
| Drove the ~$400M | Inflated form of F8 | F8's quote at its own scope, keeping "credited with." The slot asks which part was hers. |
| Led cross-functional alignment | Inflated verb of F5 | F5's quote, unchanged. |
| Built AI products | Inflated form of F7 | "uses AI tools daily," at its own scope. |
| Designed the partner motion | Inflated form of F4 | F4's quote at its own scope. The slot asks only whether she shaped terms the model fed. |

## Persona table and weights

Relationship prior: peer. Dominant personas are the Data-Driven Prober and the Peer Evaluator. Interviewer signals: Dan describes himself as "relentlessly data-driven," so the Prober weight goes up. His pricing and monetization career tilts case questions toward pricing and unit economics. The loop is unknown: no loop source was read, so the weights rest on the relationship prior and your description, not on a documented process.

| Persona | How it shows up in this conversation | Likelihood and reasoning | Counter-strategy | Weight and depth |
|---|---|---|---|---|
| Data-Driven Prober | Two-level follow-ups on the ~$400M figure and on the SQL/Tableau claim. | high. Dan's self-description plus a headline CV figure. | Name the weakest assumption before he does. Say plainly what you don't know about how figures were counted. | Top, 5 questions (A1 to A5) |
| Peer Evaluator | Seam questions about GTM versus sales strategy; credit-sharing; "what would you need from my team." | high. Peer relationship is a dominant prior, and the JD's cross-functional line is the raising source. | Reciprocity: what she brings, then what she needs. Propose seam principles, not a claim about his team. | Co-dominant, 4 questions (B1 to B4) |
| Case / Strategist | Pricing or packaging problems: whitespace, AI sequencing, a bundling threat. | medium. Pricing is Dan's native language; the JD's whitespace line is a case. | Clarify, then structure: objective, segmentation, approach, metrics, risks. | Mid, 3 questions (C1 to C3) |
| Skeptic | "Why should I trust a GTM plan from someone who has not run sales ops?" | medium. The sales-ops gap is the most predictable objection, and the JD says GTM. | Rehearse the acknowledgment and the bounded claim until they are boring. | Mid, 3 questions (D1 to D3) |
| Pressure / Stress | A 60-second fit pitch; "that result, how much was you?" | low. Peer register softens it, but a single 60-minute slot can still time-box. | Hold through two follow-ups, then concede specifically. | Low, 2 questions (E1 and E2) |
| Conversational / Rapport | A biography opener; an AI question asked casually. | low. Casual openers are still scored. | A 90-second arc; treat the AI question as scored. | Low, 2 questions (G1 and G2) |
| Values / Behavioral | Generic behavioral prompts. No values round detected. | low. The fallback archetype's values flag is no. | Selection scaffolds with an honest branch. | Low, 2 questions (H1 and H2), generic |

## Question banks

Ordered by persona weight. Provenance carries the quotes each guidance cell rests on.

### A. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how that number was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (your message) | Say what the change was, then what "credited with" means in your words, and what the uplift was measured against. Defend-the-number slots: how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. Answer slot: if you know how it was counted, say how in your own words; if you don't, say so plainly and say what you do know. Do not supply a baseline or a method. | F8 is the evidence. Dan's self-description makes a figure probe near-certain. EXP because it tests attribution. |
| A2 | "If that uplift were half the size, what would still be true about your part in it?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (your message) | Hold to the proposal, which the quote states. Concede that the size is uncertain as far as you know. Answer slot: say which part of your account survives a smaller number and which does not. If you can't separate your share from the credit, say so. Don't argue the figure up. | One level deeper than A1. Tests whether she knows which part is hers. EXP, probing attribution under a hypothetical. |
| A3 | "What were the inputs to that partner-level revenue model, and which one would you trust least today?" | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" (your message) | Name the model's purpose and the negotiation it fed, at that scope. Name the input you would trust least, if you remember the inputs; if you don't, say so. Answer slot: if she set any input herself, say which and how; if the inputs came from elsewhere, say so. | F4 is the model. A Prober tests any model this way. EXP, JD-adjacent for partner motion. |
| A4 | "Tell me about an analysis you ran in SQL or Tableau. What question did you start with?" | EXP (JD) | [grounded] "skilled in SQL/Tableau" (your message) | Pick one analysis she ran, end to end, and state the question first. Answer slot: if she pulled the data and built the view herself, say which; if someone else prepared the inputs, say that. If no analysis comes to mind that was hers from start to finish, say so plainly and describe the nearest SQL or Tableau work she did. | The JD asks for independent analysis; the quote claims only skill. This open prompt exposes the difference. EXP because it asks for an instance; JD because it scores the requirement. |
| A5 | "How would you separate the effect of that store-surface change from seasonality or other launches?" | EXP (CASE) | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (your message) | Answer as method, labeled as method: what she would do today, versus what she did then. Do not claim a test was run unless it was. Answer slot: if she separated the effect at the time, say how; if someone else's analysis attributed the uplift, say so and say what she would check first. | The probe behind A1 in its most common form. The honest answer keeps method apart from history. EXP because it concerns her figure; CASE because the method is live reasoning. |

### B. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You'd own GTM for two new product lines. Where would you draw the seam with sales strategy, and what happens when we disagree?" | JD | [grounded] "own GTM strategy for two new product lines" (JD highlights, your message) | Propose seam principles, not a map of his team: who decides price, who owns the forecast, who owns the account list. Do not claim to know where his seam falls; ask him. For disagreement: if she has a story of disagreeing with an equal, use only what the material carries; if not, describe how she would settle it: data first, a named decision owner, a dated review. | The seam question is the most likely peer probe on a GTM role that touches his team. JD because it scores cross-functional influence. |
| B2 | "What would you need from my team in the first 90 days, and what would you bring to it?" | JD | [grounded] "set annual volume targets with cross-org consensus" (your message); [grounded] "built a partner-level revenue model used in carrier negotiations" (your message) | Lead with what she would bring, at each quote's scope: the partner-level model and the cross-org target-setting. Then name what she would need: data access, the decision calendar, the current partner terms. Do not claim what his team lacks. | Reciprocity is what the peer probe scores. What she brings is answered by quoted work, never by a promise. JD because it scores influence and partner fit. |
| B3 | "Tell me about a time you disagreed with an equal about a number. What did you do?" | JD | [grounded] "set annual volume targets with cross-org consensus" (your message) | Pick a disagreement with an equal where the number was contested. Give the stake, the step she took, and the working relationship at the end. Hold on what she proposed, not on what she won. Answer slot: if there was no such disagreement, say so and give the nearest thing the material carries: the volume targets set with cross-org consensus. Say how consensus was reached only as far as she was in it. | JD raises influence. The open prompt asks for an instance; the quote supplies only the nearest real one. JD because the requirement is influence. |
| B4 | "How do you handle credit when work spans teams? Give me one case where credit was shared." | JD | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (your message) | Answer with a case she was in. Answer slot: if credit was shared on a change, say who and how it was split as far as she knows; if it was not shared, say so. Do not describe others' roles she did not see. Say "credited with" for the uplift; the attribution is the company's, not hers. | Credit probes follow a credited figure. Peer personas weight credit-sharing. JD because the requirement is cross-functional influence. |

### C. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Where would you look first for whitespace across land, adopt, expand and renew for a new product line?" | CASE (CO) | [grounded] "identify whitespace across land/adopt/expand/renew" (JD highlights, your message); [grounded] "enterprise expansion" (your research note) | Clarify: which product line and which customer base. Define whitespace as accounts or motions not yet covered. Segment by lifecycle stage. Name the first data pull (SQL) and the first metric. Name one risk. Company priority: "enterprise expansion" is listed in your research note, which is undated and unverified; say so if you use it. Do not describe an internal plan. | The JD names the whitespace task, which is the raising source. The priority is cited from your note, not presupposed in the question. CASE because the answer is live structure. |
| C2 | "If one of your two lines were an AI product, how would you sequence its GTM against expansion of the existing base?" | CO (CASE) | [grounded] "AI experience a plus" (JD highlights, your message); [grounded] "uses AI tools daily" (your message) | Clarify whether the AI line sells to existing accounts or new ones. Sequence by where the buyer already is. Name the metric that would show the sequencing is wrong. Compass appears only in your research note, so use it only if Dan raises it, and then answer his framing. For the AI evidence, state only the daily use, at its own scope; do not describe building AI products. | Kept hypothetical because "Compass" is not a raising source, so the question presupposes nothing about Northwind. CO because it tests company altitude; CASE because the sequencing is live. |
| C3 | "A much larger platform vendor bundles a product like one of yours into its suite at no extra cost. What do you do with price in the first 90 days?" | CASE (CO) | [grounded] "bundling by a much larger platform vendor" (your research note) | Clarify: who is exposed, which segment, and what win-loss or churn data exists. Options: hold price with a stated value difference, package down, partner, or bundle back. Name the metric to watch: retention in the exposed segment, not list price. The framework is generic; the threat is from your note, so mention it only if Dan does. | Pricing is Dan's native language, and the bundling threat is the note's stated risk. The question is hypothetical, so it presupposes nothing about Northwind. |

### D. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You haven't set quotas or run sales ops. What qualifies you to design a GTM plan a sales org will actually run?" | JD (EXP) | [grounded] "No classic sales-ops or quota-setting experience." (your message); [grounded] "set annual volume targets with cross-org consensus" (your message) | Plain acknowledgment: "I haven't done classic sales ops or quota-setting." Then the quoted work at its scope: "I set annual volume targets with cross-org consensus." Concede precisely: the targets are not quotas, and she would learn the sales-ops mechanics first with his team. Hold through two follow-ups by returning to the targets. Never say she can run a sales org. Answer slot: if she tracked attainment against those targets, say how; if she did not, say so. | The single most predictable objection. Dan owns sales strategy, and the JD says GTM. The acknowledgment is her own negative, and the quoted work bounds the claim. This is the highest-ROI rehearsal in the pack. JD because it scores GTM ownership. |
| D2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "partner-motion design experience required" (JD highlights, your message); [grounded] "built a partner-level revenue model used in carrier negotiations" (your message) | Name partner-motion design as the nearest gap. Say that she built a partner-level revenue model used in carrier negotiations, and that partner motion (channel terms, incentives, enablement) is what she would learn first. Give the ramp as a plan: the first month reading current partner terms and revenue data, then one proposal to test. Never describe partner-motion design as past work. | A persona stem with the JD's required line as the raising source. The answer should be a plan, not a claim. JD because it scores partner-motion fit. |
| D3 | "Your background is strategy consulting and product strategy. How would you get a sales org to adopt a GTM plan it didn't write?" | CASE (JD) | [grounded] "2 years strategy consulting at a top firm" (your message); [grounded] "9 at a large consumer-tech company in product strategy & ops" (your message) | Structure: name the owners of the number, agree decision rights up front, co-draft targets with them, pilot before scaling. Use the cross-org target-setting as the nearest example, at its quoted scope. Do not claim sales-org adoption she has not seen. | The question uses her stated path and asks about adoption without asserting a past. CASE because the answer is a mechanism; JD because it scores GTM influence. |

### E. Pressure / Stress

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you, for a role that owns GTM for two new product lines?" | JD (EXP) | [grounded] "own GTM strategy for two new product lines" (JD highlights, your message); [grounded] "built a partner-level revenue model used in carrier negotiations" (your message); [grounded] "set annual volume targets with cross-org consensus" (your message); [grounded] "No classic sales-ops or quota-setting experience." (your message) | Hold on the quoted work at its scope: the partner-level model and the cross-org targets. If he says "that isn't GTM," hold: that work is what she can show, and the gap is sales-ops mechanics. If he says "why should I believe you'd run the sales motion," hold on the targets, then concede specifically: "I haven't set quotas or run sales ops; I'd learn that with your team first." Never fold on the work she did. | The time-boxed fit pitch under pressure. The hold uses only quoted work; the concession uses the stated negative. Hold-then-concede is the structure. |
| E2 | "That result: how much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (your message) | Hold the proposal, which the quote states. Concede the share of credit that others took or shared, if any. If he presses, "So you're not claiming the $400M?": "I'm claiming what I proposed; the uplift was credited with it." Never say she drove the uplift. | Tests composure on the headline figure. The proposal is true; the share of credit is what the quote leaves open. EXP because it tests attribution. |

### G. Conversational / Rapport

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm" (your message); [grounded] "9 at a large consumer-tech company in product strategy & ops" (your message); [grounded] "built a partner-level revenue model used in carrier negotiations" (your message); [grounded] "set annual volume targets with cross-org consensus" (your message); [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (your message) | A 90-second arc. Each beat is a quoted clause at its own scope: two years of consulting at a top firm, nine years in product strategy and ops at a large consumer-tech company, the partner-level model, the cross-org targets, the store-surface proposal. Close on the role. Don't offer a motive the material does not state. | Casual openers are scored, and a biography is the most likely first question in a peer chat. EXP because it walks her record. |
| G2 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" (your message) | Say the daily use in her own words, at its scope: which tools and for what. Answer slot: if she has built anything with AI, say what; if she only uses the tools, say that. Do not upgrade "uses" to "built" or "experience". | The JD's plus-item, asked casually. Treated as scored. JD because the requirement is AI experience. |

### H. Values / Behavioral (generic; no values round detected)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] scaffold. Nearest thing: "set annual volume targets with cross-org consensus" (your message) | Selection scaffold: pick a time she put a number in front of someone who wanted a different one. It needs a named stake, the moment she said it, and an intact working relationship at the end. If none comes to mind, say so plainly, then give the nearest thing the material carries, and only what that sentence says. | Low-weight generic probe. No values page was read, so this is generic. |
| H2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] scaffold | Selection scaffold: pick a time a customer-facing outcome cost an internal target. Name the customer, the metric and what was given up. If none comes to mind, say so and say what she would weigh first. Do not claim a customer outcome the material does not carry. | Low-weight generic probe. If a values page is supplied, this bank is reweighted. |

### Coverage

Question types across the pack: VAL 2 (H1, H2). EXP 7 (A1, A2, A3, A4, A5, E2, G1). JD 8 (B1, B2, B3, B4, D1, D2, E1, G2). CO 1 primary (C2), with CO also on C1 and C3. CASE 3 (C1, C3, D3). Total 21 questions. That is inside the 18 to 26 band.

| Requirement | Covered by |
|---|---|
| GTM strategy for two new product lines | B1, C1, D1, E1 |
| Whitespace across land/adopt/expand/renew | C1 only. Thin, and flagged. |
| Independent analysis in SQL and Tableau | A4 |
| Partner-motion design (required) | A3, D2 |
| Cross-functional influence | B1, B2, B3, B4, D3 |
| AI experience (plus) | C2, G2 |
| Headline figure (~$400M) | A1, A2, A5, E2, B4 |
| Sales-ops and quota-setting (stated absence) | D1, E1 |
| Biography | G1 |
| Values | none as a round. H1 and H2 are generic. |

## Reading the interviewer

Built from your description only. No public footprint was read.

- **Career pattern:** pricing and monetization roles, with one early-stage-startup chapter.
- **Self-described style:** "relentlessly data-driven."

Practical implications:

1. Every metric will be probed to its assumptions. Rehearse A1 and A2 until the defend-the-number answers are plain.
2. Case questions will lean toward pricing, packaging and unit economics. C1 and C3 are the ones to rehearse.
3. The startup chapter means builder stories land well. Expect scrappiness probes on big-company pace.
4. The peer register makes the seam question (B1) the likeliest collegial test.

Mirror opportunities: there is no shared career jump. Pricing and monetization is a shared domain, which is why F4's partner-level revenue model may draw pricing questions. Treat it as a reason to expect probes, not as a mirror. Do not build on any affinity.

## Reverse questions

Every question is for the candidate to ask Dan, at the close.

| # | Question | Why it lands |
|---|---|---|
| R1 | "Pricing and monetization were most of your career. Which pricing call would you most want a new product line's team to re-check?" | Ties to his path. Turns an interrogation into a peer conversation. |
| R2 | "What did the early-stage chapter change about how you approach pricing?" | Shows she researched him, not only the company. |
| R3 | "What could a new peer do in the first month that would genuinely help your team?" | Reciprocity framing, which the peer persona scores. |
| R4 | "Where does the seam fall between your team and product on the two new lines? Which calls come to you?" | Asks for the seam, which the peer persona will test. |
| R5 | "Between enterprise expansion and the AI launch, which one gets first call on account capacity?" | Uses the priorities from your note, so check the note's date first. |
| R6 | "What would you need to see from someone in this role by month six?" | Turns the close into a success definition. |

## Delivery coaching

Not included: no working-style assessment was provided.

## Sources

**Provided documents:** your message, which contained the JD highlights, the summary of Priya's background, your research note, and your description of Dan. No dossier was supplied.

**Searches sent (all refused by the host, permission not granted):**

- "Northwind Data values principles": refused
- "Northwind Data interview process sales strategy": refused
- "Dan Kovac Northwind Data Director of Sales Strategy": refused
- "Northwind Data Compass AI copilot launch": refused (quick check of your research note)

**Fetches:** 0 of 2. User links read: 0.

**Research tier: L1, searches 4 of 6, fetches 0 of 2**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Northwind values | unavailable | Values cheat sheet omitted. No values page in hand. The fallback archetype is generic, so no values round is detected. |
| 2. Northwind interview process, sales strategy | unavailable | Loop unknown. Persona weights rest on the peer prior and your description. |
| 3. Northwind strategy and recent news | unavailable | Your research note is used as provided, undated and unverified. The quick check was refused. |
| 4. Dan Kovac, Northwind | unavailable | Interviewer read is from your description only. Reverse questions are not tied to a public talk or post. |
| 5. Representative JD | skipped | The JD highlights you supplied fix the fit snapshot. |

## Upgrade menu

- **Approve web search, and I'll rerun the four refused queries.** Would add the values page for a values cheat sheet, the loop structure, Dan's public footprint for persona weights and a tailored reverse question, and a date check on your research note.
- **Full JD text.** Would add any requirement beyond the six highlights. A location, work-authorization or pay term would surface as a gate row, which this pack has not checked.
- **Full CV.** Would add quoted sentences to the thin rows, F2 and F7 in particular.
- **Your recruiter's note on the process.** Would settle whether a values round exists, which changes the Values weight.
- **The date of your research note.** Would show whether its priorities are current enough for C1, C3 and R5.
- **Deeper research (L2):** up to 6 more searches and 2 more fetches, several more minutes. Want it?
- `[generic]` rows H1 and H2 become `[grounded]` with a values page.

