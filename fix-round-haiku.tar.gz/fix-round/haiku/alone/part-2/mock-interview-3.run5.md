I'll load the reference files the skill calls for before building anything.
The reference rules are loaded. Next I'll load the search tools for the default L1 research pass on Stripe's values, interview process and recent strategy.
The three web searches were refused by permission, so no Stripe-specific research ran. I'm building the pack from the role family and labelling it as generic rather than filling the gaps from memory.
Your prep pack is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-alone-part-2-rooms-case-3-denied-bca0a4d0/a5e5d725-ad76-4754-9055-0922d6e8b7ad/scratchpad/Stripe_product-operations-manager_interview_pack.md`.

I built it from the role alone, since you haven't shared a CV, a posting, or who you're meeting. Web search was refused when I tried it, so nothing about Stripe's values, interview process, or current strategy is in the pack. I didn't fill those gaps from memory. The requirements are generic role-family patterns, so every row is labelled `[generic]`. Personas are weighted flat.

The most useful part right now is S2, "Why leave where you are, and why this role?" It's the question I'd rehearse hardest, because a final-round Skeptic will almost certainly ask it. The pack gives you a way to answer it honestly without inventing a motive.

Say the word and I'll play that Skeptic in a live drill. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, and convert the pack to Word if you want it.

1. Who are you meeting, and is it your future manager or a peer? That reweights every persona.
2. Can you paste your CV and the job posting? Either one turns most `[generic]` rows into quoted evidence from you or from the posting.
3. Are you eligible to work in the posting's location, or will you need sponsorship?

If you grant web search, I'll rerun the research pass for Stripe's values, the interview format, and recent strategy. That adds the values cheat sheet and company-specific questions the pack currently lacks.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Stripe_product-operations-manager_interview_pack.md -----
# Interview prep pack: Product Operations Manager, Stripe

**Role:** Product Operations Manager
**Company:** Stripe
**Round:** Final round. Interviewer and relationship not yet known.
**Status:** First pack. Built without a CV, job posting, or web research (see Sources).

## How to use this pack

- **Personas** describe how a question is asked. **Types** describe what is being scored.
- Type key:
  - **VAL**: behavioral and values alignment
  - **EXP**: deep-dive on your own past work
  - **JD**: the role's stated responsibilities
  - **CO**: company and strategy knowledge
  - **CASE**: a live problem from the role
- Guidance is scaffolding, not a script. Speak it in your own words, in 90 to 120 seconds.
- Every provenance label is one of `[grounded]`, `[inferred]` or `[generic]`. This pack has no `[grounded]` rows yet, because it has no sentence from you and no posting to quote.

## Fit snapshot

No posting or CV was supplied, so the requirements below are role-family patterns, not quotes from Stripe. Your evidence column is `none given` throughout. Each bridge is a selection scaffold, because nothing in the material raises a specific requirement. Each scaffold ends in an honest branch.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| W1 | Designing and running cross-functional operating processes (role-family pattern, no posting) | none given | none | [generic] | discovery | Strong evidence is a process you changed that other teams depended on, what you changed, and what you left alone. Your material does not show whether you have one. Pick one process that others depended on. If you have not changed one, say so plainly and name the nearest process you ran. |
| W2 | Running launches or rollouts across several teams (role-family pattern, no posting) | none given | none | [generic] | discovery | Strong evidence is a launch with named teams, a date, and a way you tracked readiness. Your material does not show this. Pick one launch you had a hand in. If none, say so and name the nearest coordinated rollout. |
| W3 | Defining metrics and using dashboards to inform decisions (role-family pattern, no posting) | none given | none | [generic] | discovery | Strong evidence is a metric you chose and why. Your material does not show one. Pick a metric you used, and say what it was for. If you have not chosen one, say so and name the metric you would start with. |
| W4 | Managing stakeholders in engineering, finance, legal and support (role-family pattern, no posting) | none given | none | [generic] | discovery | Strong evidence is a disagreement with a team that did not report to you, and how it was settled. Your material does not show one. Pick one such disagreement. If none, say so and describe how you would approach it. |
| W5 | Owning internal tools or workflow systems (role-family pattern, no posting) | none given | none | [generic] | discovery | Strong evidence is a tool or workflow you configured or maintained, and who used it. Your material does not show one. Name the tools you have used, and say what you did with each. If you have used few, say so. |
| W6 | Writing playbooks and driving adoption of changes (role-family pattern, no posting) | none given | none | [generic] | discovery | Strong evidence is a document people used after you wrote it. Your material does not show one. If you have written one, say who used it. If not, say so and describe how you would check adoption. |
| G1 | Eligibility to work in the posting's location, or a sponsorship need (common hard gate for roles like this; confirm against the posting) | none given | none | [generic] | hard_gate | Your material does not establish this. Not bridged here. It is asked in the message that accompanies this pack. |

## Prohibited claims

No entries yet.

**Basis:** the material holds no sentence from you about your work, so there is no stated wording to stretch into a bigger claim.

**Rule that holds regardless:** no answer in this pack asserts experience you have not stated. This list is rebuilt when your CV or any sentence about your work arrives.

## Persona table

No relationship is known, so the weights are flat. Likelihoods below are priors, not findings about this interviewer.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | Live problems from the role: plan this, diagnose that | High. Product-operations work is usually probed with live problems, so this is a role-family prior, not a fact about this team | Clarify, then structure, then answer. Name one premise you would challenge |
| Skeptic | Probes motivation and gaps: why leave, why here, what is missing | Medium-high. Flat prior, weighted up because a final round is where motivation is checked | Rehearse S2 until it is plain. Name a real gap and a concrete plan. Do not bluff |
| Data-Driven Prober | Asks how a number was counted and which assumption is weakest | Medium. Flat prior; there is no CV to read yet | Name the weakest assumption before they do. Say plainly what you do not know |
| Pressure / Stress | Interrupts, time-boxes, questions motive | Medium. Flat prior; round type unknown | Pause, restate the question, hold through two follow-ups, concede specifically |
| Conversational / Rapport | Warm opener, casual questions on hot topics | Low. Flat prior | Keep a 90-second arc ready. Treat casual questions as scored |
| Peer Evaluator | Seam-splitting between teams; credit and disagreement | Low. No peer signal in the material | Propose seam principles rather than pretending to know their seam |
| Values / Behavioral | Scenario probes tied to published values | Not detected. No loop source names a values round and no published values are in hand, so no values bank is built | If a values round is on your schedule, send the company's values page and this bank gets built |

## Question banks

Question counts are below the usual range because there is no CV or posting to anchor them. Each row is a selection scaffold until one arrives.

### Case / Strategist (flat weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A launch you own goes live in two weeks, and the support team says it is not ready. What do you do?" | CASE | [generic] | Clarify first: what "not ready" means, and who decides. Then the objective, the options (delay, narrow the scope, launch with a guardrail), the one metric you would watch, and the risk you would accept and say aloud. | A live problem from launch work (W2). It makes no claim about your past, so it carries no quote. |
| A2 | "A metric your team tracks drops 20 percent in one week. Walk me through how you would diagnose it." | CASE | [generic] | Segment first (region, plan, channel, time). Check whether the instrumentation changed before anything else. Then recent launches, then external events. Name what you would rule out first. | Tests the metrics requirement (W3) as a live problem. The structure is what gets scored. |
| A3 | "How would you choose which manual review process to automate first?" | CASE | [generic] | Set criteria before candidates: volume, cost of error, how stable the rules are, who depends on the output. Pick one, say why, and name what you would measure to confirm the choice. | Process design (W1) as a decision. |
| A4 | "Sketch your first 90 days in this role. What do you need to know before you change anything?" | CASE | [generic] | Lead with the questions you would ask in week one. Then a sequence: learn the processes, meet the owners, pick one fix with a measure. Name what would make you pause the plan. | Tests W1, W2 and W4, and whether you act before you know enough. |

### Skeptic (medium-high weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| S1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | Name one area, briefly and honestly. Then the concrete step to close it: who you would ask, what you would read or shadow, and by when. Do not defend the gap and do not apologise for it. | Skeptic stem. Honest self-assessment is scored here. |
| S2 | "Why leave where you are, and why this role?" | EXP | [generic] | **Highest-ROI prep in this pack.** Give the real reason first, in your own words. Then one specific thing about this role that you can name from the posting or from the interviewer, and nothing you cannot source. Hold the reason through two follow-ups by returning to what you want to do next. If the reason is partly pay or scope, say so. Do not invent a higher motive. | Motivation is the probe a Skeptic most reliably asks. Without a CV, the pack cannot yet say what your past supports. A rehearsed, honest answer changes this interview more than any other item here. |
| S3 | "Point to the part of this role that is least like anything you have done. How would you handle it?" | JD | [generic] | Pick it cleanly. Say what in your background is closest, and what you would do in the first month. If the closest thing is thin, say so. | Skeptic stem, mapped to W2 or W5 depending on the posting. |

### Data-Driven Prober (medium weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Which assumption behind a metric you have reported would you defend least?" | EXP | [generic] | Pick one metric you actually used. Name the assumption you are least sure of, in one sentence. If you have not reported a metric, say so, then describe how you would check the one you would use. | Prober stem. Tests whether you know the limits of your own numbers (W3). |
| P2 | "Tell me about a dashboard or report you built, and what people did differently because of it." | EXP | [generic] | Choose one you built or used. Say what changed in someone's decision, if anything. If you cannot show a change, say so plainly and say how you would find out whether it was used. Never describe adoption you cannot show. | Tests W3 and the honest version of impact. An open prompt, so it carries no quote. |
| P3 | "Six months after launch, how would you know a cross-team process is working?" | CASE | [generic] | Define the outcome first, then the leading indicator, then what would make you change course. Ask what "working" means to each team before you choose a measure. | Tests W1 and W2 at the level of the measure. A prober asks for the measure, not the feeling. |

### Pressure / Stress (medium weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| Q1 | "Sixty seconds: why you over someone who has done this exact job before?" | JD | [generic] | Hold: one reason you can defend, stated first. Under the second follow-up, concede the gap plainly and specifically: what you have not done, and how you would close it. Do not fold on the reason. | Pressure stem. Scored on composure, not on the answer. |
| Q2 | "Who would disagree with your approach to this role, and why?" | EXP | [generic] | Name a real type of disagreement (a finance lead on cost, an engineer on tool scope) and how you would handle it, in your own words. Hold your position through two follow-ups. Concede what is actually uncertain. | The pressure version of W4, the stakeholder requirement. |

### Conversational / Rapport (low weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, walk me through the journey." | EXP | [generic] | Build a 90-second arc from three or four moves, in order, each one a sentence you could defend in a follow-up. No flourishes, and no claim you could not repeat. | Casual register is still scored. This is the opener most candidates over-decorate. |
| C2 | "What are you playing with in operations tooling these days?" | JD | [generic] | Name the tools you have actually used and what you used them for. If you have used few, say so and name the one you would learn first. | A casual form of a JD-adjacent question. It is scored as a plus, asked casually. |

### Peer Evaluator (low weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| PE1 | "Our teams sit side by side. Where's the seam, and what happens when we disagree?" | JD | [generic] | Propose a principle for the seam, such as who owns the decision and how a disagreement escalates, rather than pretending to know their seam. Give one disagreement you have handled, if you have one. If not, say so and give the principle. | Peer stem. A peer is checking whether the hire adds to their load or reduces it. |

## Requirement coverage

| Requirement | Covered by |
|---|---|
| W1 | A3, A4, P3 |
| W2 | A1, A4, S3 |
| W3 | A2, P1, P2 |
| W4 | A4, Q2, PE1 |
| W5 | S3, C2 |
| W6 | none, and why: the role's real wording on change and documentation is not in hand. Add it with the posting |
| G1 | none, and why: a gate is asked in the message, not rehearsed |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a strong first 90 days look like here, and what would make you say it went wrong?" | Turns your plan into success criteria the interviewer has to state |
| R2 | "Which operational process here most needs to change right now, and who owns it?" | Shows you care about the work, and names the owner you would work with |
| R3 | "How does this team decide between building a process and buying a tool?" | Shows you know the role involves tooling authority, and asks how much it has |
| R4 | "What has the person in this role handled well, and what did they find hardest?" | Shows you want the job's history, not a repeat of it |
| R5 | "Which metric does this team watch most closely, and what does it tend to miss?" | Invites the limits conversation that prober-style interviewers reward |

## Sources

- **Provided documents:** your message only, naming the company, role and round. No CV, no posting, no interviewer name.
- **Searches sent:** three, all refused by the session's permission setting. Nothing came back.
  - "Stripe company values principles": refused
  - "Stripe interview process product operations manager": refused
  - "Stripe strategy recent news 2026": refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Stripe values | unavailable | Values cheat sheet (section 10). Not built: no values in hand, and the search was refused |
| 2. Stripe interview process, product operations | unavailable | Loop structure and persona weights. Flat weights used, and no loop is established |
| 3. Stripe strategy / recent news | unavailable | CO bank. Not built, so this pack has no CO or company-strategy questions |
| 4. Interviewer name + Stripe | n/a | No name was given, so there was no query to form |
| 5. Representative Product Operations Manager JD | unavailable | Would have turned requirement rows into `[inferred]` rows. No call sent after the search was refused |

Nothing about Stripe's values, process, or strategy in this pack comes from memory. Those facts are absent, not assumed.

## Upgrade menu

- Grant web search → the L1 pass runs (Stripe's values page, the interview process, a recent-strategy sweep), which unlocks the values cheat sheet, the loop structure, and CO questions
- Your CV → the fit snapshot rows get quoted evidence, and selection scaffolds become story maps from your own sentences
- The job posting text → requirement rows become `[grounded]`, JD-tagged questions are added, and the coverage table is completed
- The interviewer's name → persona weights from their public background, plus a reverse question tied to their path
- A deeper L2 pass after L1 → a strategy brief for CO questions. Up to 6 more searches and 2 more fetches, several minutes
