Your prep pack is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-alone-part-2-rooms-case-1-denied-e1267244/414928b0-3275-4c49-b45e-dee954e4d25c/scratchpad/Northwind_Senior-GTM-Strategy-Lead_interview_pack.md`. It's built on your JD highlights and your notes, not the full JD or CV text. The four web searches I tried were refused permission, so nothing about Northwind or Dan was checked.

# Interview pack: Senior GTM Strategy Lead, Emerging Products, Northwind Data

**Round:** 60-minute conversation with Dan Kovac, Director of Sales Strategy. A peer, reporting to the same VP.

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what it scores: VAL (values), EXP (experience), JD (role), CO (company strategy), CASE (live problem).
- Guidance is scaffolding for a spoken answer, not a script. Each cell is speakable in about 90 to 120 seconds.
- Answer slots (sentences that start "Answer slot:") are instructions for the interview. Answer them in your own words, honestly, either way.

## Fit snapshot

Quotes are your own words, from the coach's notes (your summary) or the JD highlights.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" — JD highlights | "9 at a large consumer-tech company in product strategy & ops" — the coach's notes | medium | [grounded] | transferability | Your notes place you in product strategy and ops, not GTM ownership, and name no GTM launch. Words: "Nine years at a large consumer-tech company in product strategy & ops." Answer slot: expect a probe on whether you have owned a launch's go-to-market. If you did, say which and what you owned; if you did not, say so and describe the nearest work. |
| F2 | "partner-motion design experience required" — JD highlights | "built a partner-level revenue model used in carrier negotiations" — the coach's notes | medium | [grounded] | transferability | Partner economics is adjacent to partner-motion design, and the bridge does not stretch it. Words: "I built a partner-level revenue model used in carrier negotiations." Answer slot: a motion probe asks which partner-facing motions you designed, such as recruitment, enablement or incentives. If you designed any, say which; if none were yours, say so and stay with the model. |
| F3 | "run independent analysis in SQL and Tableau" — JD highlights | "skilled in SQL/Tableau" — the coach's notes | medium | [grounded] | none | The words reach the requirement. The caveat is that nothing inspectable is in hand, so expect a probe. Words: "I'm skilled in SQL and Tableau." Answer slot: which analysis you ran yourself and what decision it changed; if the analysis was done by others, say so. |
| F4 | "identify whitespace across land/adopt/expand/renew" — JD highlights | none given | none | [grounded] | discovery | Nothing in your material shows whitespace work. Answer slot: if you have sized unclaimed demand across a customer lifecycle, say what you sized and how; if not, say so and say how you would start. |
| F5 | "strong cross-functional influence" — JD highlights | "set annual volume targets with cross-org consensus" — the coach's notes | medium | [grounded] | presentation | The words reach cross-org influence in other terms. Words: "I set annual volume targets with cross-org consensus." No practice added. |
| F6 | Gap in your notes: "No classic sales-ops or quota-setting experience." Not a JD highlight; the likeliest peer probe from a sales-strategy director | "set annual volume targets with cross-org consensus" — the coach's notes | low | [inferred] | transferability | Volume targets are adjacent to quota-setting, not the same work. The bridge stays at the quote's scope; the wider step is an answer slot. Derivation: the quote read against your note's gap. Answer slot: if you set quotas or ran sales operations, say how; if the targets were the only such work, say what they were used for. |
| F7 | "AI experience a plus" — JD highlights | "uses AI tools daily" — the coach's notes | low | [inferred] | transferability | Usage is adjacent to AI experience. Derivation: the usage quote read against the plus line. Clarify-strategy note only: say the usage in your own words, and do not extend it to building anything. |
| F8 | Headline metric, not a JD requirement: the figure you will be asked to defend | "proposed a store-surface change credited with a ~$400M ARR uplift" — the coach's notes | medium | [grounded] | none | The figure is credited, not verified, so the risk is attribution. Words: "I proposed a store-surface change, and the uplift is credited to it." Answer slots: how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. |

**Gates.** None of the material ties a legal or credential term to this role. Location, travel and work authorization are not in your highlights, so no gate row exists. The full JD could show one.

**Pack observation (analysis, not words for Priya).** Your material shows product strategy and ops, consulting, a partner-level revenue model and volume targets. It does not show a GTM launch owned, a B2B sales motion, whitespace work, quota-setting, or inspected analysis.

## Prohibited claims

Built locally from the fit snapshot. These are the stretched wordings a candidate reaches for under pressure. None may be said in this interview.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned go-to-market for a product line | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: your material shows product strategy and ops, not GTM ownership. D1's slot stays inside the quote. |
| Designed the partner motion | Inflated form of F2 | "I built a partner-level revenue model used in carrier negotiations." B3 stays on the model. |
| Set quotas or ran sales operations | Inflated form of F5 and F6 | "I set annual volume targets with cross-org consensus." The wider step is an answer slot. |
| Drove the ~$400M uplift | Inflated form of F8 ("credited with") | "I proposed a store-surface change, and the uplift is credited to it." |
| Ran independent analyses end to end | Inflated form of F3 ("skilled in") | "I'm skilled in SQL and Tableau." A2 asks for one only if you ran it. |
| Built AI features | Inflated form of F7 ("uses AI tools daily") | "I use AI tools every day." |

No sourced entries exist: there is no dossier, and you have not stated a negative about yourself. Your note's "No classic sales-ops or quota-setting experience" is a coach's observation, not your words, so the pack gives you no negative to say. You answer it in the room, with the slots above.

## Grounding brief

From your research note, not verified:

- Three stated priorities: enterprise expansion; the AI copilot launch, "Compass"; reaching profitability.
- Main competitive threat: bundling by a much larger platform vendor.

## Reading the interviewer

Source: your note on Dan's profile. Public footprint only, not checked.

- **"Relentlessly data-driven."** Every number you give will be probed to its assumptions. Expect the defend-the-number slots first.
- **Career spine in pricing and monetization.** Case questions will tilt to pricing, packaging and unit economics. C2 and C3 use that lens.
- **One early-stage startup chapter.** Builder stories land well with a startup background. Expect a scrappiness probe. Have one plain account of work done with few resources, if you have one. Do not invent one.
- **Mirror opportunities: none.** The material shows no shared professional path, and the pack does not invent one.

## Persona table

Weights follow the peer relationship prior (Peer Evaluator and Prober dominant), adjusted up for the self-described data focus and toward pricing by his career spine.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy | Weight and depth |
|---|---|---|---|---|
| Data-Driven Prober | Asks for denominators and assumptions, two levels deep | Highest: self-described as relentlessly data-driven | Name your weakest assumption before he does | 5 |
| Peer Evaluator | Seams, credit, what would you need from me | High: a peer round is a relationship prior | Reciprocity: what you bring their team | 4 |
| Case / Strategist | Live problems on pricing and whitespace | Medium: pricing career tilts it | Clarify, then structure, then metrics | 3 |
| Skeptic | Why you, and where you are weakest | Medium: F1 and F6 are the gaps a peer would notice | Rehearse the one predictable objection until it is boring | 3 |
| Pressure / Stress | Time-boxed challenges on the headline number | Low to medium: peer rounds rarely time-box, but E1 is predictable | Hold through two follow-ups, then concede precisely | 2 |
| Conversational | Biography and an AI question asked casually | Low to medium: rapport openers are scored too | Pre-scripted 90-second arc | 2 |
| Values / Behavioral | Unpopular truths, customers over metrics | Low: no values round detected, no published values in hand | Selection scaffolds with honest branches | 2 |

Total: 21 questions.

## Question banks

Provenance quotes are the sentences each guidance cell rests on. Rows that make no claim about Priya carry their label alone.

### A. Data-Driven Prober (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how the ~$400M figure was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (the coach's notes) | Defend-the-number slots, in your words. How it was counted: if you know, say how; if not, say so. Sensitivity: name what it moves with. Weakest assumption: name the one you would defend least before he finds it. Which part was yours: "I proposed the change." | F8 is the headline figure and the likeliest prober target. EXP because it tests attribution. |
| A2 | "Tell me about an analysis you ran in SQL or Tableau, and what it changed." | JD | [grounded] "skilled in SQL/Tableau" (the coach's notes) | Open prompt. Answer slot: if you ran an analysis yourself, pick the one you can defend, walk it end to end, and name the decision it changed. If the work was done for you, say so plainly. | F3 and the JD's independent-analysis line. Open prompt, so it presupposes no analysis. |
| A3 | "Walk me through the inputs of the partner-level revenue model. Which one would you defend least?" | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" (the coach's notes) | Weakest-assumption move: name the input you would defend least, in your words. Answer slot: if any input was set by someone else, say who; if you set them, say so. | F2. Premised only on the model, which the quote carries. |
| A4 | "If I gave you a land, adopt, expand and renew funnel tomorrow, what would you pull first, and what would you distrust?" | JD | [grounded] "identify whitespace across land/adopt/expand/renew" (the JD highlights) | Scaffold: define the stages, pick the denominator, name the source of truth, then say what you would distrust first. No past claim. | F4. Tests the whitespace line as a live problem. |
| A5 | "Which of your own numbers would you expect me to challenge first, and what would you say?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" and "built a partner-level revenue model used in carrier negotiations" (the coach's notes) | Name the weakest assumption across both figures, and say which you can defend and which you cannot. Answer slot: if you have not checked one, say so. | F8 and F2. A self-challenge turns a gotcha into a credibility gain. |

### B. Peer Evaluator (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Where's the seam between your work and sales operations, and what happens when we disagree about a number?" | JD | [grounded] "set annual volume targets with cross-org consensus" (the coach's notes) | Name the seam as a principle, not a fact about his team. On disagreement, use the quoted sentence. Answer slot: if you disagreed with a team on a target, say how it was resolved; if none arose, say so. | F5. Peer probe on cross-functional influence. |
| B2 | "How do you handle credit when work spans teams?" | VAL | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (the coach's notes) | Open prompt. Answer slot: if others shared the change, name them and what they did; if it was yours alone, say so; say how the credit was actually assigned. | F8. A peer's credit probe lands on the headline figure. |
| B3 | "We're designing partner motions for two new lines. What would you need from my team on day one?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" (the coach's notes) | Reciprocity: what you would bring their team (the model's logic, in its own terms) and what you would need (data access, partner list, decision rights). Do not claim partner motion design. | F2. The JD's partner-motion line, asked as a peer. |
| B4 | "How did you get the orgs involved in the volume targets to agree to them?" | EXP | [grounded] "set annual volume targets with cross-org consensus" (the coach's notes) | Story-mapped on the quote: targets set, consensus across orgs. Answer slot: the step that secured agreement. If you did this, say how; if it was not yours, say so. | F5 and F6. A quota-adjacent probe, kept to the quote's scope. |

### C. Case / Strategist (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Sketch how you'd find the whitespace across land, adopt, expand and renew for enterprise accounts." | JD | [grounded] "identify whitespace across land/adopt/expand/renew" (the JD highlights); "enterprise expansion" (your research note) | Clarify, objective, segmentation, approach, metrics, risks. Think aloud. Name the stage where a land-to-expand gap is most likely. No claim about your past. | F4 and the research note's first priority. A live problem. |
| C2 | "A much larger platform vendor bundles a comparable capability into its suite. What do you do to our pricing next quarter?" | CO | [grounded] "bundling by a much larger platform vendor" (your research note) | Pricing lens. What the bundle changes for the buyer; match, package or hold; what you would measure. Challenge one premise respectfully: the bundle's price is not known. | Main threat from the note. His pricing career tilts the case to packaging and unit economics. |
| C3 | "Enterprise expansion, Compass and profitability: which would you deprioritize if you had to, and why?" | CO | [grounded] "enterprise expansion", "AI copilot launch ('Compass')" and "reaching profitability" (your research note) | Pick one, state the trade, and name the metric you would watch to learn you were wrong. No past claim. | Tests altitude on the three priorities. |

### D. Skeptic (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "set annual volume targets with cross-org consensus" and "skilled in SQL/Tableau" (the coach's notes) | **Highest-ROI prep in this pack.** Name the gap in the JD's terms, then the nearest thing you have. Your material does not show a GTM launch owned, a B2B sales motion, or quota-setting; that observation is for you, not words to say. Answer slots: if you have owned a launch's go-to-market, say which; if not, say so plainly. If quota is the gap, say how far your volume-target work goes. Follow-up 1 ("which launch?"): name the nearest thing and stop. Follow-up 2 ("how fast could you learn it?"): give a ramp plan as a plan, never as past. Concede only what is true, then give the ramp. | F1 and F6 are the gaps a peer will notice. The objection arrives in some form, so the rehearsed non-defensive answer is the highest-value prep. |
| D2 | "Tell me about a time you wrote a plan that someone else had to execute. What happened?" | EXP | [grounded] "set annual volume targets with cross-org consensus" (the coach's notes) | Open prompt. Story-mapped on the quote: targets set with consensus across orgs. Answer slot: the outcome, if you know it; if not, say so. Hold to the plan you wrote. | F1 and F5. The outcome is an answer slot and is never supplied. |
| D3 | "Two years in consulting, then consumer-tech product ops. Why would a B2B data company need you over someone who has run B2B go-to-market?" | EXP | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" (the coach's notes); "built a partner-level revenue model used in carrier negotiations" (the coach's notes) | Answer by describing the work, not the inference. Your strongest B2B-adjacent sentence is the partner model. Do not claim B2B go-to-market. Answer slot: if you have run a B2B go-to-market, say which; if not, say so and say what the model did. | F1 and F2. The comparison is his framing, not a claim about you. |

### E. Pressure / Stress (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "That $400M. How much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (the coach's notes) | Hold-then-concede. Hold through two follow-ups: "I proposed the change, and the figure is credited to it." Concede what is unknown, specifically: how the credit was split, or how the figure was counted, if you do not know. Never fold on "proposed" or "credited." Answer slot: how the uplift was counted, if you know. | F8. The hold is only what the quote carries. |
| E2 | "Sixty seconds: why you over someone who has run a B2B sales motion?" | JD | [grounded] "9 at a large consumer-tech company in product strategy & ops" (the coach's notes) | Time-boxed. Lead with your strongest sentence, then what it did. Hold: do not argue the B2B point; return to the partner model. Answer slot: if you have run a B2B sales motion, say which; if not, say so and hold on the model. | F1 and F2. The first-person negative is in answer-slot form, not coached. |

### G. Conversational / Rapport (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" (the coach's notes) | A pre-scripted 90-second arc built from the two quoted sentences, in your words. Claim nothing beyond them. End on the partner model as the bridge to this role. | Rapport openers are scored. The arc is the answer. |
| G2 | "What are you actually playing with in AI these days?" | JD | [inferred] "uses AI tools daily" (the coach's notes); derivation: the usage quote read against the plus line | Clarify-strategy note only: say how you use AI tools every day, in your own words, and do not extend it to building. | F7. The JD's plus line, asked casually and scored. |

### V. Values / Behavioral (weight 2)

No values round was detected and no published values are in hand, so these two use persona stems.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold ending in its honest branch: pick a time you had to tell senior people something they did not want to hear. It needs a named stake and an outcome you saw. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. | Persona stem. Makes no claim about Priya. |
| V2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | The same scaffold. If the decision cost a metric, name what it cost; if no such decision comes to mind, say so. | Persona stem, low weight. |

### Requirement coverage

| Requirement | Questions |
|---|---|
| Own GTM strategy for two new product lines | D1, D2, E2 |
| Identify whitespace across land/adopt/expand/renew | C1, A4 |
| Run independent analysis in SQL and Tableau | A2 |
| Partner-motion design experience (required) | A3, B3 |
| Strong cross-functional influence | B1, B4 |
| AI experience (a plus) | G2 |
| Headline figure (~$400M) | A1, A5, B2, E1 |
| Quota-setting and sales-ops (your note, not a JD highlight) | D1, B4, D3 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Your career has run through pricing and monetization. Which pricing decision of the last few years do you think sales got wrong, and how did you find out?" | Ties to his own path. Turns an interrogation into a peer conversation and shows you researched him. |
| R2 | "What could a new person do in their first month that would genuinely help your team?" | Reciprocity, and the peer's own load. |
| R3 | "Of enterprise expansion, Compass and profitability, which is your team most at odds with on how to measure?" | Shows you know the priorities, and invites the disagreement a peer would have. |
| R4 | "How does sales strategy divide enterprise expansion work from product strategy today?" | The seam question. Shows you plan to work with his team, not around it. |
| R5 | "When a platform vendor bundles something close to your product, what has your team learned about where discounting really starts?" | Pricing, his native language, tied to the main threat. |

## Sources

- **Provided documents:** your JD highlights (the full JD was not supplied); your summary of Priya's background (coach's notes, no CV text); your research note; your note on Dan's profile. No dossier was used.
- **Searches sent (4), all refused, none returned a result:** "Northwind Data company values"; "Northwind Data interview process sales strategy"; "Dan Kovac Director of Sales Strategy Northwind Data"; "Senior GTM Strategy Lead Emerging Products B2B data infrastructure job description."
- **Fetches:** none sent.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Northwind values | unavailable | Refused. No values cheat sheet: no values round was detected. |
| 2. Interview process, sales strategy | unavailable | Refused. Persona weights follow the peer prior and your round description, not a named loop. |
| 3. Strategy / recent news | skipped | Your research note fixes the three priorities and the bundling threat. The C bank uses it. |
| 4. Dan Kovac footprint | unavailable | Refused. The interviewer read rests on your note alone. |
| 5. Representative JD | unavailable | Refused. The snapshot runs on your highlights, with no [inferred] requirement lines. |

## Upgrade menu

- **Full JD text** → checks for location, travel or work-authorization gates, and turns the highlights into quoted requirements.
- **Your CV text, sentences as written** → F1 to F8 move from the coach's notes to your own words, the strongest grounding available.
- **Recruiter guidance on focus areas or any exercise in the 60 minutes** → persona weights and any graded sections.
- **Dan's public footprint, if you can share what you have seen** → sharper reverse questions and a checked interviewer read.
- **How the ~$400M figure was counted, or a sample analysis, if you can share them** → moves A1, A2, E1 and E2 from answer slots to grounded answers.

---

Two offers, neither pushed:
- **Drill:** I can play Dan as the Prober on A1, or as the Skeptic on D1, the question the pack names as its highest-ROI prep, and give feedback against that question's own guidance.
- **Dossier:** I can save a `tuesday-dossier.md` recording the gaps this prep exposed (F1, F2, F6 and the D1 objection), to carry into later sessions.

I can also convert the pack to a Word document if you want one.

Two questions that would reshape it:
1. Does the 60 minutes include any exercise, presentation, or focus areas from recruiter guidance?
2. Can you paste the full JD text? Without it, the pack stands on your highlights.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Northwind_Senior-GTM-Strategy-Lead_interview_pack.md -----
# Interview pack: Senior GTM Strategy Lead, Emerging Products, Northwind Data

**Round:** 60-minute conversation with Dan Kovac, Director of Sales Strategy. A peer, reporting to the same VP.
**Built on:** your JD highlights (not the full JD), your summary of Priya's background (not CV text), your research note, and your note on Dan's profile. Nothing was verified by web search: the searches were refused (see Sources).

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what it scores: VAL (values), EXP (experience), JD (role), CO (company strategy), CASE (live problem).
- Guidance is scaffolding for a spoken answer, not a script. Each cell is speakable in about 90 to 120 seconds.
- Answer slots (sentences that start "Answer slot:") are instructions for the interview. Answer them in your own words, either branch honestly.

## Fit snapshot

Quotes are your own words, either from the coach's notes (your summary) or the JD highlights. Confidence is set by what can be inspected, not by how the claim sounds.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" — JD highlights | "9 at a large consumer-tech company in product strategy & ops" — the coach's notes | medium | [grounded] | transferability | Your notes place you in product strategy and ops, not GTM ownership, and name no GTM launch. Words: "Nine years at a large consumer-tech company in product strategy & ops." Answer slot: expect a probe on whether you have owned a launch's go-to-market. If you did, say which and what you owned; if you did not, say so and describe the nearest work. |
| F2 | "partner-motion design experience required" — JD highlights | "built a partner-level revenue model used in carrier negotiations" — the coach's notes | medium | [grounded] | transferability | Partner economics is adjacent to partner-motion design, and the bridge does not stretch it. Words: "I built a partner-level revenue model used in carrier negotiations." Answer slot: a motion probe asks which partner-facing motions you designed, such as recruitment, enablement or incentives. If you designed any, say which; if none were yours, say so and stay with the model. |
| F3 | "run independent analysis in SQL and Tableau" — JD highlights | "skilled in SQL/Tableau" — the coach's notes | medium | [grounded] | none | The words reach the requirement. The caveat is that nothing inspectable is in hand, so expect a probe. Words: "I'm skilled in SQL and Tableau." Answer slot: which analysis you ran yourself and what decision it changed; if the analysis was done by others, say so. |
| F4 | "identify whitespace across land/adopt/expand/renew" — JD highlights | none given | none | [grounded] | discovery | Nothing in your material shows whitespace work. Answer slot: if you have sized unclaimed demand across a customer lifecycle, say what you sized and how; if you have not, say so and say how you would start. |
| F5 | "strong cross-functional influence" — JD highlights | "set annual volume targets with cross-org consensus" — the coach's notes | medium | [grounded] | presentation | The words reach cross-org influence in other terms. Words: "I set annual volume targets with cross-org consensus." No practice added. |
| F6 | Gap in your notes: "No classic sales-ops or quota-setting experience." Not a JD highlight; the likeliest peer probe from a sales-strategy director | "set annual volume targets with cross-org consensus" — the coach's notes | low | [inferred] | transferability | Volume targets are adjacent to quota-setting, not the same work. The bridge stays at the quote's scope and the wider step is an answer slot. Derivation: the quote read against your note's gap. Answer slot: if you set quotas or ran sales operations, say how; if the targets were the only such work, say what they were used for. |
| F7 | "AI experience a plus" — JD highlights | "uses AI tools daily" — the coach's notes | low | [inferred] | transferability | Usage is adjacent to AI experience. Derivation: the usage quote read against the plus line. Clarify-strategy note only: say the usage in your own words, and do not extend it to building anything. |
| F8 | Headline metric, not a JD requirement: the figure you will be asked to defend | "proposed a store-surface change credited with a ~$400M ARR uplift" — the coach's notes | medium | [grounded] | none | The figure is credited, not verified, so the risk is attribution. Words: "I proposed a store-surface change, and the uplift is credited to it." Answer slots: how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. |

**Gates.** None of the material ties a legal or credential term to this role. Location, travel and work authorization are not in your highlights, so no gate row exists. The full JD could show one (see the upgrade menu).

**Pack observation (analysis, not words for Priya).** Your material shows product strategy and ops, consulting, a partner-level revenue model and volume targets. It does not show a GTM launch owned, a B2B sales motion, whitespace work, quota-setting, or inspected analysis.

## Prohibited claims

Built locally from the fit snapshot. These are the stretched wordings a candidate reaches for under pressure. None of them may be said in this interview.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned go-to-market for a product line | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: your material shows product strategy and ops, not GTM ownership. D1's slot stays inside the quote. |
| Designed the partner motion | Inflated form of F2 | "I built a partner-level revenue model used in carrier negotiations." B3 stays on the model. |
| Set quotas or ran sales operations | Inflated form of F5 and F6 | "I set annual volume targets with cross-org consensus." The wider step is an answer slot. |
| Drove the ~$400M uplift | Inflated form of F8 ("credited with") | "I proposed a store-surface change, and the uplift is credited to it." |
| Ran independent analyses end to end | Inflated form of F3 ("skilled in") | "I'm skilled in SQL and Tableau." A2 asks for one only if you ran it. |
| Built AI features | Inflated form of F7 ("uses AI tools daily") | "I use AI tools every day." |

No sourced entries exist: there is no dossier, and you have not stated a negative about yourself. Your note's "No classic sales-ops or quota-setting experience" is a coach's observation, not your words, so the pack gives you no negative to say. You answer it in the room, with the slots above.

## Grounding brief

From your research note, not verified (no search succeeded):

- Three stated priorities: enterprise expansion; the AI copilot launch, "Compass"; reaching profitability. Provenance: [grounded] your research note.
- Main competitive threat: bundling by a much larger platform vendor. Provenance: [grounded] your research note.

## Reading the interviewer

Source: your note on Dan's profile. Public footprint only, and not checked.

- **Self-described "relentlessly data-driven."** Every number you give will be probed to its assumptions. Expect the defend-the-number slots to come first.
- **Career spine in pricing and monetization.** Case questions will tilt to pricing, packaging and unit economics. Use that lens in C2 and C3.
- **One early-stage startup chapter.** Builder stories land well with a startup background. Expect a scrappiness probe, so have one plain account of work done with few resources, if you have one. Do not invent one.
- **Mirror opportunities: none.** The material shows no shared professional path, and the rules do not allow inventing one.

## Persona table

Weights follow the peer relationship prior (Peer Evaluator and Data-Driven Prober dominant), adjusted by the self-described data focus (Prober up) and the pricing spine (Case tilted to pricing). The round is a single session, so no loop structure applies.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy | Weight and depth |
|---|---|---|---|---|
| Data-Driven Prober | Asks for denominators and assumptions; two levels deep | Highest: Dan describes himself as relentlessly data-driven | Name your weakest assumption before he does | 5 |
| Peer Evaluator | Seams, credit, what would you need from me | High: a peer round is a relationship prior | Reciprocity: what you bring their team | 4 |
| Case / Strategist | Live problems on pricing and whitespace | Medium: pricing career tilts it | Clarify, then structure, then metrics | 3 |
| Skeptic | Why you, and where you are weakest | Medium: F1 and F6 are the gaps a peer would notice | Rehearse the one predictable objection until it is boring | 3 |
| Pressure / Stress | Time-boxed challenges on the headline number | Low to medium: peer rounds rarely time-box, but E1 is a predictable challenge | Hold through two follow-ups, then concede precisely | 2 |
| Conversational | Biography and an AI question asked casually | Low to medium: rapport openers are scored too | Pre-scripted 90-second arc | 2 |
| Values / Behavioral | Unpopular truths, customers over metrics | Low: no values round detected, and no published values in hand | Selection scaffolds with honest branches | 2 |

Total: 21 questions.

## Question banks

Provenance quotes are the sentences each guidance cell rests on. Where a row makes no claim about Priya, it carries its label alone.

### A. Data-Driven Prober (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how the ~$400M figure was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (the coach's notes) | Defend-the-number slots, in your words. How it was counted: if you know, say how; if you do not, say so. Sensitivity: name what it moves with. Weakest assumption: name the one you would defend least before he finds it. Which part was yours: "I proposed the change." | F8 is the headline figure and the likeliest prober target. EXP because it tests attribution. |
| A2 | "Tell me about an analysis you ran in SQL or Tableau, and what it changed." | JD | [grounded] "skilled in SQL/Tableau" (the coach's notes) | Open prompt. Answer slot: if you ran an analysis yourself, pick the one you can defend, walk it end to end, and name the decision it changed. If the work was done for you, say so plainly. | F3 and the JD's independent-analysis line. Open prompt, so it presupposes no analysis. |
| A3 | "Walk me through the inputs of the partner-level revenue model. Which one would you defend least?" | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" (the coach's notes) | Weakest-assumption move: name the input you would defend least, in your words. Answer slot: if any input was set by someone else, say who set it; if you set them, say so. | F2. Premised only on the model, which the quote carries. |
| A4 | "If I gave you a land, adopt, expand and renew funnel tomorrow, what would you pull first, and what would you distrust?" | JD | [grounded] "identify whitespace across land/adopt/expand/renew" (the JD highlights) | Scaffold: define the stages, pick the denominator, name the source of truth, then say what you would distrust first. No past claim. | F4. Tests the whitespace line as a live problem. |
| A5 | "Which of your own numbers would you expect me to challenge first, and what would you say?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" and "built a partner-level revenue model used in carrier negotiations" (the coach's notes) | Name the weakest assumption across both figures, and say which you can defend and which you cannot. Answer slot: if you have not checked one, say so. | F8 and F2. A self-challenge turns a gotcha into a credibility gain. |

### B. Peer Evaluator (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Where's the seam between your work and sales operations, and what happens when we disagree about a number?" | JD | [grounded] "set annual volume targets with cross-org consensus" (the coach's notes) | Name the seam as a principle, not as a fact about his team. On disagreement, use the quoted sentence. Answer slot: if you disagreed with a team on a target, say how it was resolved; if no disagreement arose, say so. | F5. Peer probe on cross-functional influence. |
| B2 | "How do you handle credit when work spans teams?" | VAL | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (the coach's notes) | Open prompt. Answer slot: if others shared the change, name them and what they did; if it was yours alone, say so; say how the credit was actually assigned. | F8. A peer's credit probe lands on the headline figure. |
| B3 | "We're designing partner motions for two new lines. What would you need from my team on day one?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" (the coach's notes) | Reciprocity: what you would bring their team (the model's logic, in its own terms) and what you would need (data access, partner list, decision rights). Do not claim partner motion design. | F2. The JD's partner-motion line, asked as a peer. |
| B4 | "How did you get the orgs involved in the volume targets to agree to them?" | EXP | [grounded] "set annual volume targets with cross-org consensus" (the coach's notes) | Story-mapped on the quote: targets set, consensus across orgs. Answer slot: the step that secured agreement. If you did this, say how; if it was not yours, say so. | F5 and F6. A quota-adjacent probe, kept to the quote's scope. |

### C. Case / Strategist (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Sketch how you'd find the whitespace across land, adopt, expand and renew for enterprise accounts." | JD | [grounded] "identify whitespace across land/adopt/expand/renew" (the JD highlights); "enterprise expansion" (your research note) | Clarify, objective, segmentation, approach, metrics, risks. Think aloud. Name the stage where a land-to-expand gap is most likely. No claim about your past. | F4 and the research note's first priority. A live problem. |
| C2 | "A much larger platform vendor bundles a comparable capability into its suite. What do you do to our pricing next quarter?" | CO | [grounded] "bundling by a much larger platform vendor" (your research note) | Pricing lens. Structure: what the bundle changes for the buyer; match, package or hold; what you would measure. Challenge one premise respectfully: the bundle's price is not known. | Main threat from the note. Dan's pricing career tilts the case to packaging and unit economics. |
| C3 | "Enterprise expansion, Compass and profitability: which would you deprioritize if you had to, and why?" | CO | [grounded] "enterprise expansion", "AI copilot launch ('Compass')" and "reaching profitability" (your research note) | Pick one, state the trade, and name the metric you would watch to learn you were wrong. No past claim. | Tests altitude on the three stated priorities. |

### D. Skeptic (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "set annual volume targets with cross-org consensus" and "skilled in SQL/Tableau" (the coach's notes) | **Highest-ROI prep in this pack.** Name the gap in the JD's own terms, then the nearest thing you have. Your material does not show a GTM launch owned, a B2B sales motion, or quota-setting; that observation is for you, not words to say. Answer slots: if you have owned a launch's go-to-market, say which; if not, say so plainly. If quota is the gap, say how far your volume-target work goes. Follow-up 1 ("which launch?"): name the nearest thing and stop. Follow-up 2 ("how fast could you learn it?"): give a ramp plan as a plan, never as past. Concede only what is true, in your words, then give the ramp. | F1 and F6 are the gaps a peer will notice. The objection arrives in some form, so the rehearsed non-defensive answer is the highest-value prep. |
| D2 | "Tell me about a time you wrote a plan that someone else had to execute. What happened?" | EXP | [grounded] "set annual volume targets with cross-org consensus" (the coach's notes) | Open prompt. Story-mapped on the quote: targets set with consensus across orgs. Answer slot: the outcome, if you know it; if you do not, say so. Hold to the plan you wrote. | F1 and F5. The outcome is an answer slot and is never supplied. |
| D3 | "Two years in consulting, then consumer-tech product ops. Why would a B2B data company need you over someone who has run B2B go-to-market?" | EXP | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" (the coach's notes); "built a partner-level revenue model used in carrier negotiations" (the coach's notes) | Answer by describing the work, not the inference. Your strongest B2B-adjacent sentence is the partner model. Do not claim B2B go-to-market. Answer slot: if you have run a B2B go-to-market, say which; if not, say so and say what the model did. | F1 and F2. The comparison is his framing, not a claim about you. |

### E. Pressure / Stress (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "That $400M. How much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (the coach's notes) | Hold-then-concede. Hold through two follow-ups: "I proposed the change, and the figure is credited to it." Concede what is unknown, specifically: how the credit was split, or how the figure was counted, if you do not know. Never fold on "proposed" or "credited." Answer slot: how the uplift was counted, if you know. | F8. The hold is only what the quote carries. |
| E2 | "Sixty seconds: why you over someone who has run a B2B sales motion?" | JD | [grounded] "9 at a large consumer-tech company in product strategy & ops" (the coach's notes) | Time-boxed. Lead with your strongest sentence, then what it did. Hold: do not argue the B2B point; return to the partner model. Answer slot: if you have run a B2B sales motion, say which; if not, say so and hold on the model. | F1 and F2. Time-boxed. The first-person negative is in answer-slot form, not coached. |

### G. Conversational / Rapport (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" (the coach's notes) | A pre-scripted 90-second arc built from the two quoted sentences, in your words. Claim nothing beyond them. End on the partner model as the bridge to this role. | Rapport openers are scored. The arc is the answer. |
| G2 | "What are you actually playing with in AI these days?" | JD | [inferred] "uses AI tools daily" (the coach's notes), derivation: the usage quote read against the plus line | Clarify-strategy note only: say how you use AI tools every day, in your own words, and do not extend it to building. | F7. The JD's plus line, asked casually and scored. |

### V. Values / Behavioral (weight 2)

No values round was detected, and no published values are in hand. These two use persona stems.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold ending in its honest branch: pick a time you had to tell senior people something they did not want to hear. It needs a named stake and an outcome you saw. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. | Persona stem. Makes no claim about Priya. |
| V2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | The same scaffold. If the decision cost a metric, name what it cost; if no such decision comes to mind, say so. | Persona stem, low weight. |

### Requirement coverage

| Requirement | Questions |
|---|---|
| Own GTM strategy for two new product lines | D1, D2, E2 |
| Identify whitespace across land/adopt/expand/renew | C1, A4 |
| Run independent analysis in SQL and Tableau | A2 |
| Partner-motion design experience (required) | A3, B3 |
| Strong cross-functional influence | B1, B4 |
| AI experience (a plus) | G2 |
| Headline figure (~$400M) | A1, A5, B2, E1 |
| Quota-setting and sales-ops (your note, not a JD highlight) | D1, B4, D3 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Your career has run through pricing and monetization. Which pricing decision of the last few years do you think sales got wrong, and how did you find out?" | Ties to his own path. Turns an interrogation into a peer conversation and shows you researched him. |
| R2 | "What could a new person do in their first month that would genuinely help your team?" | Reciprocity, and the peer's own load. |
| R3 | "Of enterprise expansion, Compass and profitability, which is your team most at odds with on how to measure?" | Shows you know the priorities, and invites the disagreement a peer would have. |
| R4 | "How does sales strategy divide enterprise expansion work from product strategy today?" | The seam question. Shows you plan to work with his team, not around it. |
| R5 | "When a platform vendor bundles something close to your product, what has your team learned about where discounting really starts?" | Pricing, his native language, tied to the main threat. |

## Sources

- **Provided documents:** your JD highlights (your summary; the full JD was not supplied); your summary of Priya's background (the coach's notes; no CV text); your research note (priorities and bundling threat); your note on Dan's profile. No dossier was consumed.
- **Searches sent (4), all refused, none returned a result:**
  - "Northwind Data company values": refused
  - "Northwind Data interview process sales strategy": refused
  - "Dan Kovac Director of Sales Strategy Northwind Data": refused
  - "Senior GTM Strategy Lead Emerging Products B2B data infrastructure job description": refused
- **Fetches:** none sent.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Northwind values | unavailable | Refused. The values cheat sheet is absent: no values round was detected. |
| 2. Interview process, sales strategy | unavailable | Refused. Persona weights follow the peer prior and your round description, not a named loop. |
| 3. Strategy / recent news | skipped | Your research note fixes the three priorities and the bundling threat. The C bank uses it. |
| 4. Dan Kovac footprint | unavailable | Refused. The interviewer read rests on your note alone. |
| 5. Representative JD | unavailable | Refused. The snapshot runs on your highlights, with no [inferred] requirement lines. |

## Upgrade menu

- **Full JD text** → checks for location, travel or work-authorization gates, and turns the highlights into quoted requirements.
- **Your CV text, sentences as written** → F1 to F8 move from the coach's notes to your own words, the strongest grounding available.
- **Recruiter guidance on focus areas or any exercise in the 60 minutes** → persona weights and any graded sections.
- **Dan's public footprint, if you can share what you have seen** → sharper reverse questions and a checked interviewer read. The search was refused.
- **How the ~$400M figure was counted, or a sample analysis, if you can share them** → moves A1, A2, E1 and E2 from answer slots to grounded answers.
