Your prep pack is saved as `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-alone-part-2-rooms-case-1-denied-166973cf/dfaee35c-7af1-4c54-a063-19222e44d48c/scratchpad/northwind-data_senior-gtm-strategy-lead-emerging-products_interview_pack.md`. I built it for a peer conversation with Dan, since your note says he reports to the same VP.

The pack has 22 questions across seven personas, weighted toward Peer Evaluator and Data-Driven Prober. Each question carries its type, provenance quotes, guidance, and rationale, and there is a requirement-coverage table mapping each JD line to question IDs.

Web search was refused by the host, so the pack runs on your inputs only. Company values and the interview process are not verified. The pack says so in its Sources section.

The biggest exposure is the missing sales-ops and quota-setting experience. Question D1 carries the deepest rehearsal, because Dan will almost certainly press on it. The pack gives her a plain concession and a hold based on "set annual volume targets with cross-org consensus," which it treats as target-setting, not quota design.

Two choices to check:
- I worked from your JD highlights and background summary, not full text or a CV. Quotes are attributed to "your note" or "your message," so they should be swapped for the real documents if you have them.
- The $400M figure gets defend-the-number questions (B1, B2, E2), but the pack supplies no counting method. Her own account of how it was counted is the only thing that can fill that slot.

Would you like me to run the Skeptic (D1) as a live drill with Dan's pushback?

Would you like a Word version of the pack?

Two questions that would change the pack:
- Does the recruiter expect a deliverable for the 60 minutes, such as a take-home or a short presentation?
- Is Dan the only interviewer, or is anyone else joining?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: northwind-data_senior-gtm-strategy-lead-emerging-products_interview_pack.md -----
# Interview prep pack: Senior GTM Strategy Lead, Emerging Products, Northwind Data

**Interviewer:** Dan Kovac, Director of Sales Strategy. **Relationship:** peer, same VP. **Format:** one 60-minute conversation.
**Candidate:** Priya.

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored.
- **Type key:** VAL = behavioral and values alignment. EXP = your experience, deep-dived. JD = the role's stated requirements. CO = company and strategy knowledge. CASE = a live problem.
- Each question's type is its primary tag. Dual tags are explained in the rationale.
- Guidance is scaffolding for a spoken answer, not a script. Quotes in the Provenance column are your own words from what you sent me. Labels: `[grounded]` traces to a supplied document or to your words. `[inferred]` is my derivation, named. `[generic]` is a role-family pattern with no claim about you or Northwind.
- Question IDs are letter-by-persona. Letter F is skipped so question IDs never collide with fit-snapshot row IDs.

## Fit snapshot

Requirements are quoted from your JD highlights. Evidence is quoted from your message. Nothing in the material is a gate (no work-authorization, location, licence or similar term appears), so no row is `hard_gate`.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" (your JD highlights) | "proposed a store-surface change credited with a ~$400M ARR uplift" (your message) | medium | [grounded] | transferability | Your material shows a proposed product change, not GTM strategy for a product line. Words: "I proposed a store-surface change." Answer slot: if you set the go-to-market for that change, who it reached or how it was sequenced, say what you decided; if you did not, say so plainly and describe what you did own. |
| F2 | "identify whitespace across land/adopt/expand/renew" (your JD highlights) | none given | none | [grounded] | discovery | Nothing in the material shows whitespace work. No words are supplied. Answer slot: name a whitespace you identified and how you sized it, if you did; if not, say how you would find one first. |
| F3 | "run independent analysis in SQL and Tableau" (your JD highlights) | "skilled in SQL/Tableau" (your message) | low | [inferred] derived from F3's evidence cell | discovery | "Skilled in" names tools, not independent analysis. Not to be asserted as your claim. Answer slot: name one analysis you ran yourself, end to end, with its question and result; if none ran that way, say so and say what you would build first. |
| F4 | "partner-motion design experience required" (your JD highlights) | "built a partner-level revenue model used in carrier negotiations" (your message) | medium | [grounded] | transferability | The model is partner-facing economics used in negotiations, not partner-motion design (channels, incentives, enablement). Words: "I built a partner-level revenue model used in carrier negotiations." Answer slot: if you shaped the terms or the motion the model fed, say which and how; if you did not, say so and say what the model taught you about partner economics. |
| F5 | "strong cross-functional influence" (your JD highlights) | "set annual volume targets with cross-org consensus" (your message) | medium | [grounded] | presentation | The quote already reaches cross-functional influence in its own terms. Words reword only the quote: "I set annual volume targets with consensus across orgs." Adds no practice and no figure. |
| F6 | "AI experience a plus" (your JD highlights) | "uses AI tools daily" (your message) | low | [inferred] derived from F6's evidence cell | transferability | Daily use is not the same as building or evaluating AI products. Coaching note only, not an assertion: if you can name what you built or evaluated with AI tools, say so; if you have used them only, say that. |
| F7 | sales-ops and quota-setting experience (your message: not in the JD highlights) | "No classic sales-ops or quota-setting experience" (your message) | none | [grounded] | capability | A stated absence. Words: "I haven't done classic sales-ops or quota-setting work." Then the nearest thing your material carries is F5, which is target-setting, not quota design. Present it as targets, never as quotas. |

**Background sentences used in the pack** (your message): "2 years strategy consulting at a top firm"; "9 at a large consumer-tech company in product strategy & ops." Both are `[grounded]` where cited.

**Analysis (my reading, not words for you):** your material shows target-setting, a partner-facing revenue model and one product change with a credited figure. It does not show GTM ownership of a product line, whitespace work, independent SQL analysis or a sales-ops process. Those are the places the interviewer is most likely to press.

## Prohibited claims

Built locally from the fit snapshot. Each entry is wording the pack will not coach, with its basis and its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the store-surface change or its ~$400M result | Inflated form of F1 ("proposed" widened to "owned" or "drove") | F1's quote at its own scope. "Credited with" stays credited with. |
| Set quotas or ran sales ops | Inflated form of F5 (volume targets widened to quotas) | F5's quote at its own scope. Analysis: your material says volume targets, not quotas. |
| Designed the partner motion | Inflated form of F4 (revenue model widened to motion design) | F4's quote at its own scope. |
| Expert in SQL or Tableau, or ran independent analysis end to end | Inflated form of F3 | F3's slot only. "Skilled in" is the most the material says. |
| Built AI products | Inflated form of F6 | F6's quote only, as a coaching note. |

Plain acknowledgment allowed: "I haven't done classic sales-ops or quota-setting work" (source: F7's quote). No other negative is coached.

## Reading the interviewer

Source: your note only. Public footprint research did not run (see Sources), so there are no published talks or posts behind this read.

- **Career pattern:** pricing and monetization roles as the main spine, with one early-stage startup chapter.
- **Self-described style:** "relentlessly data-driven."
- **Practical implications:**
  1. Expect every number you cite to be probed to its inputs. Prepare the attribution slots, not extra detail.
  2. Use a pricing and packaging angle in case questions. That is his native language.
  3. Builder and scrappiness stories land with a startup-chapter person. Do not expect them to read big-company pace as a credential.
  4. This is a peer seam, not an evaluation of your credentials: expect questions about where sales strategy and GTM for emerging products split, and who decides what.
- **Mirror opportunities:** none offered. No sentence in your material carries a jump comparable to his.

## Persona table

Relationship priors for a peer round set Peer Evaluator and Data-Driven Prober as dominant. Interviewer signals raise the Prober further and tilt case questions toward pricing. The loop is one session, established by your own words ("single 60-minute conversation" with Dan). No loop source documents a values-style round, so no values round is detected and no archetype fallback is applied.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy | Weight and depth |
|---|---|---|---|---|
| Peer Evaluator | seam questions, "what do you need from me," credit and disagreement probes | Very high. Peer prior, and the JD makes GTM ownership a seam with his team. | Reciprocity framing. Propose seam principles, not a map of his team. | Top, 5 questions (A1 to A5) |
| Data-Driven Prober | denominators, assumptions, "walk me through how that was counted" | Very high. His self-description plus the peer prior. The $400M figure is the magnet. | Name the weakest assumption before he does. Say plainly what you do not know about counting. | Top, 5 questions (B1 to B5) |
| Case / Strategist | live problems on Compass, enterprise expansion, profitability | High. The research note gives three priorities, and his pricing career suits pricing cases. | Clarify, then structure. Challenge one premise per case. | Mid, 3 questions (C1 to C3) |
| Skeptic | "where are you weakest," the sales-ops gap, B2B fit | High. F7 is the largest gap and the most predictable objection. | Concede the absence once, precisely. Hold with what you did, then give a ramp plan. | Mid, 3 questions (D1 to D3) |
| Pressure / Stress | time-boxed "sixty seconds," "how much was actually you" | Moderate. Peer rounds rarely press, but a peer may test composure on the figure. | Pause, restate, hold through two follow-ups, concede specifically. | Low, 2 questions (E1 to E2) |
| Conversational / Rapport | "walk me through the journey," casual AI question | Moderate. Casual openers are still scored, especially the AI plus-skill. | A 90-second arc, and treat the AI question as scored. | Low, 2 questions (G1 to G2) |
| Values / Behavioral | "unpopular truth," "customer ahead of an internal metric" | Low. No values round is detected and no published values are in hand. | Selection scaffolds with honest branches. | Low, 2 questions (H1 to H2) |

## Question banks

Provenance comes before guidance. Each guidance cell rests only on the quotes in its own Provenance column.

### A. Peer Evaluator (top weight, 5 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Our teams sit side by side. Where's the seam between sales strategy and GTM for the new lines, and what happens when we disagree?" | JD | [grounded] "set annual volume targets with cross-org consensus" (your message) | Propose seam principles, not a map of his team: who sets targets, who sets launch sequence, and how a disagreement goes to the VP. Your consensus process is the example, in the quote's own terms. Answer slot: if a disagreement with a peer was settled in a particular way, say how and what was yours; if none has been, say so and give the principle. | Peer prior; F5 is the nearest evidence. JD is the primary type because the seam is GTM ownership; the peer's probe is CASE-like in delivery. |
| A2 | "How do you handle credit when work spans teams?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (your message) | Open prompt: pick a time credit was contested. Beats: who did what, what you proposed, how the credit was split. If no such time comes to mind, say so, then give the nearest thing: the store-surface change, where the uplift was credited to the change. Answer slot: if others shaped the change, name them and say what you would claim for your part; if you cannot split it, say that. | Persona stem. F1 is the credit-bearing sentence, and the answer is where a peer tests credit. |
| A3 | "If we launched one of the new lines through partners, what would you need from my team before we committed?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" (your message) | Propose the principles a partner launch needs (terms, incentives, enablement, who owns the partner's number). Your model is the example of partner economics. Answer slot: if the model's output set any terms, say which and how; if it did not, say so and say what it taught you. | Covers the JD's partner-motion requirement (F4) with a question the peer can genuinely answer with you. |
| A4 | "Platform vendors are bundling AI into their suites. If that hit our new lines, what would you change first?" | CO | [grounded] "main competitive threat is bundling by a much larger platform vendor" (your research note) | Name what you would defend first and why, in terms of where bundling reaches the buyer. Propose one test you would run before changing pricing. No claim about your past. | Competitive threat from the research note. CO because it scores altitude on the company's own frame. |
| A5 | "Tell me about a time you disagreed with an equal on a launch or a target." | EXP | [grounded] "set annual volume targets with cross-org consensus" (your message) | Open prompt. Beats the quote states: who was consulted, how consensus was reached or not. Answer slot: if the consensus was contested, say how it resolved and what part was yours; if no disagreement arose, say so and give the nearest one you handled. | Persona stem. Tests the disagreement style the seam question raises. |

### B. Data-Driven Prober (top weight, 5 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Walk me through how that $400M was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (your message) | Defend-the-number slot, in your own words. Four parts: how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. Answer slot: if you did this, say how; if there was no such step, or it was not yours, say so plainly and return to "credited with." Do not supply a method. | F1 is the figure a prober targets first. The four slots are the rubric's defend-the-number slots. |
| B2 | "Which assumption behind that uplift would you defend least?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (your message) | Weakest-assumption move. Name it before he does, in your words. Answer slot as in B1: name it only if you know it; if you do not know how the figure was counted, say so. | F1 again, second level. Keeps the prober one level deeper than the first answer. |
| B3 | "You set annual volume targets. What did you measure them against, and how did you know they were right?" | EXP | [grounded] "set annual volume targets with cross-org consensus" (your message) | Answer slot: if you measured the targets against a baseline or forecast, say which and how; if none was used, say so plainly and say what you would use now. Do not name a baseline. | F5 is the sentence. The question presupposes a measurement step the quote does not carry, so its guidance is a slot whose second branch lets the premise be false. |
| B4 | "Walk me through the inputs to the partner-level revenue model, and which one you'd defend least." | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" (your message) | Name two inputs you can defend and the one you would flag. Answer slot: if you did not set the inputs, say so and say whose they were. | F4 is the only partner-economics evidence; the answer decides how far the bridge to partner-motion design can go. |
| B5 | "Describe the last SQL or Tableau analysis you ran yourself, end to end: the question, the data, the result." | JD | [inferred] "skilled in SQL/Tableau" (your message) | Coaching note only. Answer slot: if you ran one, describe the question, data and result in your own words; if the work has been on someone else's query or dashboard, say that, and say what you would build first. | F3 is low confidence. The guidance asserts nothing beyond the tools. The question is the JD's independent-analysis requirement. |

### C. Case / Strategist (mid weight, 3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Compass is launching. How would you price and package an AI copilot for an existing enterprise customer?" | CASE | [grounded] "AI copilot launch ('Compass')" (your research note) | Clarify (what the customer already pays for; is the copilot a seat tier or a separate SKU) → objective → segment → approach (bundle, tier, or add-on) → metrics → risks. Challenge one premise, for example that a copilot should be priced per seat. Pricing angle suits his background. | Compass is a stated priority. CASE because it is a live problem with no claim about your past. |
| C2 | "A mid-size enterprise expansion account has renewed flat for two cycles. Diagnose it." | CASE | [grounded] "whitespace across land/adopt/expand/renew" (your JD highlights) | Structure across land, adopt, expand and renew. Name the data you would pull first. Name one hypothesis early. No past claim. | Ties the JD's lifecycle language to the stated expansion priority. CASE is the delivery; JD is the scored requirement. |
| C3 | "Profitability is a stated priority. Where would you look for it in a new line's GTM spend, and what would you cut first?" | CO | [grounded] "reaching profitability" (your research note) and [generic] unit-economics framing | Name the unit-economics levers, then the one you would test first. The framework is [generic]; the priority is grounded. No claim about your past. | Profitability is in the research note and a pricing person will test it. |

### D. Skeptic (mid weight, 3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You've never run sales ops or set quotas. How would you handle quota design for a new line on day one?" | JD | [grounded] "No classic sales-ops or quota-setting experience" (your message) and [grounded] "set annual volume targets with cross-org consensus" (your message) | **Highest-ROI prep in this pack.** Concede once, precisely: "I haven't done classic sales-ops or quota-setting work." Hold through two follow-ups: "What I have done is set annual volume targets with consensus across orgs. That is target-setting, not quota design, and I would not call it quota work." Concede specifically on the second follow-up: "I would want sales ops to own the quota mechanics; here is how I would approach the design." Never say you have designed quotas. | F7 is the largest gap, so this objection is near-certain. The hold uses only F5's words; the concession is the plain acknowledgment F7 gives. |
| D2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "partner-motion design experience required" (your JD highlights) and [grounded] "built a partner-level revenue model used in carrier negotiations" (your message) | Name partner-motion design as the honest weakest area. Bridge with F4's words, at their scope. Give a ramp plan as a plan, not as past: how you would learn partner motion in the first 30 days. | Persona stem. F4 is the biggest partner gap; the answer shows calibrated candor, not a bluff. |
| D3 | "Northwind sells data infrastructure to enterprises. How would you handle a buyer who has never seen a consumer-tech product?" | JD | [grounded] "a large consumer-tech company in product strategy & ops" (your message) and [grounded] "built a partner-level revenue model used in carrier negotiations" (your message) | Answer slot: if you have sold to or negotiated with enterprise buyers beyond carriers, say so and how; if not, say that, and say how you would learn the buyer. Carrier negotiations are the nearest thing your material carries; name them as B2B counterparties only in their own words. | The question names the consumer-tech background, which is quoted. The data-infrastructure buyer comes from your note, not from a claim about you. |

### E. Pressure / Stress (low weight, 2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over an internal candidate?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" (your message), [grounded] "set annual volume targets with cross-org consensus" (your message) | Hold: a 60-second arc of your two quoted sentences, with no claim about any internal candidate. Concede specifically on quota design (F7) at the second follow-up. | Persona stem. Tests composure and a short answer. |
| E2 | "That $400M, how much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (your message) | Hold on "proposed." Concede precisely: the uplift was credited to the change; your share is one you would have to check, and say how you would check it. Do not add a share. Answer slot: if you can split it, say how; if you cannot, say so. | Persona stem on F1. The hold-then-concede structure is the rehearsal, not a claim. |

### G. Conversational / Rapport (low weight, 2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm" and [grounded] "a large consumer-tech company in product strategy & ops" (your message) | 90-second arc: consulting, then consumer-tech product strategy and ops, then the partner model and volume targets, then why this role. Use only the quoted sentences. | Casual opener still scored. The arc keeps the sentences at their own scope. |
| G2 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" (your message) and [grounded] "AI experience a plus" (your JD highlights) | Scored, though casual. Name the tool and one task you actually use it for. Do not claim building or evaluating AI products. | Persona stem on the JD's plus-skill, which the interviewer will treat as scored. |

### H. Values / Behavioral (low weight, 2 questions)

No values round is detected and no published values are in hand, so these are selection scaffolds with honest branches.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you delivered an unpopular truth to leadership." | EXP | [generic] selection scaffold; [grounded] "set annual volume targets with cross-org consensus" (your message) as the nearest thing | Pick a time you told leadership something unwelcome, with a named stake, a moment you did not fold, and a relationship intact at the end. If none comes to mind, say so, then give the nearest thing: the volume-target consensus, where the targets were tested. Answer slot: if the truth did not land, say so; do not supply an ending. | Persona stem. No values round, so this is a scaffold, not a mapped story. |
| H2 | "When did you put a customer ahead of an internal metric?" | EXP | [generic] selection scaffold | Pick a time a customer outcome beat an internal number. If none comes to mind, say so plainly and give how you would decide that trade-off now. Do not invent a customer story. | Persona stem. Covers the values persona without claiming a published value. |

### Requirement coverage

| JD requirement (your JD highlights) | Covered by | Note |
|---|---|---|
| own GTM strategy for two new product lines | A1, A3, D2, C3 | F1 is the evidence; F1 is transferability. |
| identify whitespace across land/adopt/expand/renew | C2 | F2 is discovery; no question uses a quote that carries whitespace work. |
| run independent analysis in SQL and Tableau | B5 | F3 is low confidence and `[inferred]`. |
| partner-motion design experience required | A3, B4, D2 | F4 is transferability; D2 is the deepest. |
| strong cross-functional influence | A1, A5, H1 | F5 is presentation. |
| AI experience a plus | G2 | F6 is coaching only. |

Company priorities from your research note (not JD requirements): enterprise expansion covered by C2; Compass covered by C1; profitability covered by C3; bundling covered by A4.

### Reverse questions

Two are required (interviewer path, reciprocity). All five are for a peer conversation.

| # | Question | Why it lands |
|---|---|---|
| R1 | "Your background is pricing and monetization. Which pricing decision on your team today would have gone better if GTM had seen it earlier?" | Tied to his own career path. It converts an interrogation into a peer conversation and shows you researched him, not only the company. |
| R2 | "What could a new person do in their first month that would genuinely help your team?" | Reciprocity question. It answers "any questions for me?" in a way a peer weighs. |
| R3 | "Where do sales strategy and GTM strategy for emerging products currently split, and who settles it when they disagree?" | Names the seam directly and makes the peer relationship concrete. |
| R4 | "How will Compass be measured in its first two quarters, and which result would make you change course?" | Uses the stated priority and asks for the metric, which a strategist answers with pride. |
| R5 | "Where are you seeing bundling show up first in deals?" | Uses the threat from your research note and asks for evidence the team has. |

## Sources

- **Provided documents:** your message (candidate background summary, role summary, interviewer summary). Your JD highlights (not full JD text). Your research note (three stated priorities, competitive threat, the Compass launch). Your interviewer read (Dan's self-description and career spine).
- **Searches sent:** 3. Each was refused by the host (permission not granted). No result was returned, and nothing is used from them.
  - "Northwind Data company values principles" (target 1): refused.
  - "Northwind Data interview process strategy roles" (target 2): refused.
  - "Dan Kovac Director of Sales Strategy Northwind Data" (target 4): refused.
- **Fetches:** none sent.
- **User links read:** 0.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Northwind Data values` | unavailable | Every call was refused. It would have checked for published values. No loop source documents a values round, so the values section would not have been triggered, and the H bank would have stayed a scaffold. |
| 2. `Northwind Data interview process` | unavailable | Every call was refused. Your own words already establish the loop: one session, a conversation run by Dan. The search would only have checked for extra sessions. |
| 3. Strategy / recent news | skipped | Your research note already supplies the priorities and the competitive threat. This fixes C1 to C3 and A4. |
| 4. `Dan Kovac Northwind Data` | unavailable | The call was refused. It would have added his public talks and posts to the interviewer read and reverse questions. |
| 5. Representative JD | skipped | Your JD highlights fix the fit snapshot and the JD-tagged questions. |

## Grounding brief

Company content comes only from your research note, not from search. Your note's date is not given, so treat the priorities as current only as of when you wrote it. Confirm them with the recruiter before the interview. Priorities: enterprise expansion; the Compass AI copilot launch; reaching profitability. Competitive threat: bundling by a much larger platform vendor.

## Upgrade menu

- Full JD text, in place of the highlights → turns the JD highlights into quoted JD lines and firms up F1 to F7 and the JD-tagged questions.
- Your CV or résumé → replaces the "your message" quotes with CV-sourced quotes and may surface stories the summary does not.
- How the $400M figure was counted, in your own words → lets B1 and B2 hold a counted figure. It is new material only if you say it outside the drill.
- A SQL or Tableau sample you built → moves F3 from low confidence to medium and lets B5 hold a story instead of a slot.
- Web search allowed in this host → runs the three refused targets above. This is the L1 research the pack could not run.
- Dan's public talks or posts → adds recurring themes to the interviewer read and to reverse questions.
- The recruiter's note on any deliverable for the 60 minutes → a graded-deliverable section if one is announced.
- Whether a second interviewer joins → restructures the personas if the round becomes a panel.
