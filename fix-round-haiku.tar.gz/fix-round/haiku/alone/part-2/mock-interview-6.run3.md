Your prep pack is saved as `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-alone-part-2-rooms-case-6-denied-72521482/dc4e0116-0b4f-475c-88d9-05dbce5f52e6/scratchpad/larkfield_engineering_manager_interview_pack.md`. It's organized by round, with a shared fit snapshot, prohibited claims, and sources at the top. It was built from your message alone, with no JD text, interviewer names, or company research. So the values sheet is missing, since I can't state Larkfield's values without their published page.

The biggest gap is hardware: you've never owned a hardware-adjacent roadmap, and the role's partnership line is built around it. Question H2 in the file is the one to rehearse hardest. Managing managers is the second gap, and it depends on whether the two squads have leads under you.

I can also drill any question with a live interviewer, save a `tuesday-dossier.md` recording the gaps this prep exposed, or convert the pack to Word.

Three questions, so the pack can be sharpened:

1. Does the role involve any location, on-site or hardware-site travel, or work-authorization constraint that your role summary doesn't mention?
2. Do the two squads have their own leads under you? That decides whether managing managers is a live gap in every round.
3. Did the recruiter name any focus areas, or a deliverable such as a take-home or presentation, for any of the three rounds?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: larkfield_engineering_manager_interview_pack.md -----
# Larkfield Systems — Engineering Manager: three-round prep pack (loop mode)

Role: Engineering Manager, Larkfield Systems (industrial IoT, ~600 people). Lead two squads building device-management services; own delivery, hiring and growth for 11 engineers; partner with hardware and product on roadmap.

Rounds: **Round 1** Tuesday, 45 min, hiring manager (Director of Engineering) · **Round 2** Thursday of the following week, 60 min panel (two staff engineers, one product manager) · **Round 3** the following Monday, 30 min, VP Engineering ("values and leadership philosophy").

Built at research tier L0 from your message alone. No JD text, no interviewer names, no company research. Every fact about you below is one of your own sentences, quoted.

## How to use + type key

Personas describe how a question arrives. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and stop where the quoted material stops.

- **VAL**: behavioral / values alignment
- **EXP**: work-experience deep-dive; whether your claims survive scrutiny
- **JD**: stated responsibilities, including the ones you don't yet have
- **CO**: company and strategy knowledge (not covered by this pack; no research ran)
- **CASE**: live problem from the role, delivered out loud

## Shared: fit snapshot

Requirements are quoted from your role summary (the message you sent), or marked `[generic]` where no source supplied them. Evidence is quoted from your message only.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own delivery" (role summary, your message) | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | medium | [grounded] | transferability | Your material shows a delivery call under pressure, on reliability work. It does not show a squad's delivery owned end to end. Words: "I pushed a reliability quarter through against roadmap pressure." Answer slot: if you set delivery targets or sequencing for a team's work, say which and how you decided; if you did not, say so and describe how you tracked the reliability quarter. |
| F2 | "hiring" (role summary, your message) | "I run our hiring loop for backend roles — about 40 interviews last year." — your message | medium | [grounded] | none | Reaches the requirement in role-relevant terms. Words: "I run our hiring loop for backend roles — about 40 interviews last year." Expect a probe on which hiring decisions were yours, since the sentence does not say. |
| F3 | "growth for 11 engineers" (role summary, your message) | "3 as a team lead of 6" — your message | medium | [grounded] | discovery | Your material shows three years leading six people. It does not show anyone grown into a new role. Answer slot: name one person you grew, what changed for them, and what you did, in your own words; if none comes to mind, say so and describe how you develop people. |
| F4 | "lead two squads" (role summary, your message) | "3 as a team lead of 6" — your message | medium | [grounded] | transferability | One team of six is adjacent to two squads totalling 11 engineers, and the bridge should say so. Words: "I've led a team of six for three years." |
| F5 | managing managers, if the two squads have leads under you (`[generic]` role-family pattern, no source) | "I've never managed managers" — your message | none | [grounded] | capability | A gap you stated. Words: "I've never managed managers." Then how you would learn it, as a plan and never as a past. Nothing added to make the gap feel smaller. Whether this is a live gap depends on Question 2 below. |
| F6 | "partner with hardware and product on roadmap" (role summary, your message) | "I've never managed managers and never owned a hardware-adjacent roadmap." — your message | none | [grounded] | capability | A gap you stated. Words: "I've never owned a hardware-adjacent roadmap." Then how you would learn hardware dependencies, as a plan. This is the largest gap against the role's center of gravity. |
| F7 | "partner with hardware and product on roadmap" (role summary, your message) | "I pushed a reliability quarter through against roadmap pressure." — your message | medium | [grounded] | transferability | Adjacent to roadmap negotiation; it does not reach hardware. Words: "I pushed a reliability quarter through against roadmap pressure." Answer slot: if you traded scope with product or made the case to a peer, say what was traded and how; if you did not, say so. |
| F8 | "device-management services" (role summary, your message) | "currently at a payments company" — your message | medium | [grounded] | transferability | Backend work in a payments company, not device telemetry. Words: "currently at a payments company." Say the domain limit before a probe does. |

**Requirement coverage**

| Requirement | Covered by | Note |
|---|---|---|
| Lead two squads building device-management services | H5, H6, P8, V6 | |
| Own delivery | H5, P4, P6 | |
| Hiring | H8 | |
| Growth for 11 engineers | H9 | Thin: H9 touches it in the walk-through. No dedicated question; see upgrade menu. |
| Partner with hardware | H2, P1, P6 | |
| Partner with product on roadmap | P3, P6, P7 | |
| Managing managers (`[generic]`) | H1, H10, V5 | |
| Device-management domain | H6, P5, V6 | |
| Eleven engineers across two squads | H4, P8, V5 | |

## Shared: prohibited claims

Built locally from the fit snapshot. These are the wordings this pack will not coach.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the product roadmap | Inflated form of F7 | F7's quote at its own scope. Pack observation: your material says a reliability quarter pushed through, not roadmap ownership. |
| Made the final hiring decisions | Inflated form of F2 | F2's quote. H8's slot asks which decisions were yours. |
| Did the reliability engineering yourself | Inflated form of F7 | F7's quote. Pack observation: the material does not show whose engineering produced the 60%. |
| Managed managers | Negative you stated, F5 | "I've never managed managers." |
| Owned a hardware-adjacent roadmap | Negative you stated, F6 | "I've never owned a hardware-adjacent roadmap." |

## Shared: sources

- Provided: your message (role summary and background).
- Research tier: L0. No searches or fetches were run in this pass.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Larkfield values | unavailable | Values sheet (section 10). Not run at this tier. Its absence is why no values cheat sheet appears below. |
| 2. Larkfield interview process | unavailable | Loop structure; would confirm the round weights below. |
| 3. Larkfield strategy / recent news | unavailable | CO bank and the grounding brief. Not run at this tier. |
| 4. Interviewer names | n/a | No names were given, so there was no query to form. |
| 5. Representative JD for the title | unavailable | Would turn the role-summary quotes above into `[grounded]` JD quotes, and surface mid-list requirements. |

---

## Round 1: hiring manager (Tuesday, 45 min)

### Persona weights

| Persona | Weight | Why |
|---|---|---|
| Skeptic | top (4) | Hiring managers buy capability and derisk gaps. F5 and F6 are the two stated gaps they will test. |
| Case / Strategist | 2 | Expect a live problem on their roadmap. Hardware dependencies are the likeliest topic. |
| Data-Driven Prober | 2 | Your headline figures (60%, 40 interviews) are magnets for probes. |
| Conversational | 1 | Opening biography is scored even when casual. |
| Pressure | 1 | Short, sharp challenge to the hire-over-candidate case. |

Reasoning: relationship prior for a hiring manager (Case + Skeptic), with Prober added because two figures on your CV carry it.

### Question banks

**Skeptic**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "You've never managed managers. Why would you be the right person to lead two squads?" | JD | [grounded] "I've never managed managers" — your message | Plain acknowledgment: "I haven't managed managers." Then what you have done: "I've led a team of six for three years" (F4). Hold through two follow-ups by returning to how you would learn it. Answer slot: if you have supported a lead of leads or a peer manager, say how, in your own words; if not, say so. | F5 is the most direct gap in the role's structure; the question presupposes only your own negative. |
| H2 | "I don't see hardware in your background. How would you partner with them on this roadmap?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." — your message | **Highest-ROI prep in this pack.** Say the plain acknowledgment first: "I've never owned a hardware-adjacent roadmap." Then the plan, as a plan: which hardware dependencies you would learn first, and from whom. Hold through two follow-ups by returning to the plan; concede specifically on what you do not yet know about firmware release cycles. Answer slot: if you have worked on a roadmap with a hardware dependency at all, say how, in your own words; if not, say so. | F6 is the largest gap and this question will come in some form. Deepest rehearsal: three follow-up levels. |
| H3 | "What draws you to industrial IoT, away from payments?" | JD | [generic] | Answer from your own reasons. Any claim about past work must rest on one of your quoted sentences. If the honest answer is that you have not worked in the domain, say that and give the reason you want to. | Motivation probe; the question is an open prompt, so it presupposes nothing about your history. |
| H4 | "What would make you fail in the first six months here?" | JD | [generic] | Name one real risk: hardware dependencies, or managing leads you have not managed. Say what you would do about it first. | Skeptic stem; invites candor about F5 and F6 without asserting either. |

**Case / Strategist**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H5 | "Hardware needs a firmware change this quarter and product wants a feature in the same window. What do you do in week one?" | CASE | [grounded] "partner with hardware and product on roadmap" — role summary, your message | Clarify first: what the firmware change unblocks, what the feature is worth, and what each team can actually ship. Then sequence, state the trade-off out loud, and name who decides. No claim about past decisions. | Live version of the role's partnership line; the requirement names both partners, so the question does too. |
| H6 | "A device fleet stops checking in after a release. Walk me through your first hour." | CASE | [generic] | Structure: scope (how many devices, which firmware), the rollback question, who you page, and what you would stop doing. Think aloud; challenge one premise. | Device-management domain (F8's limit applies: say you have not run this fleet). |

**Data-Driven Prober**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H7 | "How was the 60% on-call drop counted?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | Defend-the-number slot. Name the weakest assumption you know of before they do. Answer slot: if you did the counting, say how, in your own words; if you did not, say so plainly and say what you can say about the figure. | Headline metric on your CV; this is where a probe lands first. |
| H8 | "Of the roughly 40 interviews, how many final calls were yours?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." — your message | Give the figure as you said it. Answer slot: if you made the final call on any, say how many and how you decided; if you did not, say so and say what your part was. | F2 is medium; a number invites a question about the decision behind it. |

**Conversational / Rapport Builder**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H9 | "So, walk me through the journey." | EXP | [grounded] "9 years engineering, 3 as a team lead of 6" — your message | A 90-second arc: the nine years, the three leading six, then the pivot to the payments role. Only what those sentences carry. | Scored casually; also the only place growth for 11 engineers comes up, so give it a clause. |

**Pressure / Stress**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H10 | "Sixty seconds: why you rather than someone who has run a team of eleven?" | JD | [grounded] "I've never managed managers" — your message | Pause, restate the question. Hold: "I haven't managed managers; what I have done is lead six for three years." Concede specifically on scale. Do not fold on the core claim. | Stress probe on F4's scale gap; the premise is your own negative. |

### Reverse questions (Round 1)

1. "What would the first 90 days look like with the two squads' leads in place?" — Why it lands: shows you think about structure before people.
2. "Which squad is closer to the hardware roadmap today, and where is the hardest handoff?" — Why it lands: names the role's partnership problem directly.
3. "What would you want a new manager to have changed in six months?" — Why it lands: invites a concrete expectation.
4. "What does success on hiring look like for this team by the end of next year?" — Why it lands: a hiring manager's own scorecard.
5. "What are you least sure about in this role?" — Why it lands: an honest question that invites the interviewer to name the gap.

---

## Round 2: panel (Thursday, 60 min)

### Persona weights (per member, blended)

| Member | Dominant personas | Why |
|---|---|---|
| Staff engineer 1 | Peer Evaluator + Data-Driven Prober | Pricing what the hire costs their work; technical depth probes. |
| Staff engineer 2 | Peer Evaluator + Data-Driven Prober | Same relationship prior; reliability and on-call are likely seams. |
| Product manager | Peer Evaluator + Case | Roadmap trade-offs and partnership. |

Pressure is absent from this round by design: the panel is peer-weighted, and Pressure has its place in Round 1. Skeptic appears once, from the peer seam.

### Question banks

**Peer Evaluator**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Our teams sit side by side. Where's the seam with hardware, and what happens when you disagree?" | JD | [grounded] "partner with hardware and product on roadmap" — role summary, your message | Propose seam principles rather than pretending to know the seam. For the disagreement story, use F7 only: "I pushed a reliability quarter through against roadmap pressure." Answer slot: if you disagreed with a peer team and held a position, say how, in your own words; if not, say so and describe how you would handle it. | Peer-seam question; disagreement with equals is scored. |
| P2 | "How do you handle credit when delivery spans two teams?" | EXP | [generic] | Selection scaffold: pick a time work crossed two teams; say who did what, in your own words. If none comes to mind, say so and describe your rule. | Persona stem; no claim about your history is made by the question. |
| P3 | "What would you need from product in the first quarter?" | JD | [grounded] "partner with hardware and product on roadmap" — role summary, your message | Reciprocity framing: what you bring their team, then what you would need. Do not claim a seam you have not seen. | Peer reciprocity; the question names the partnership the role's sentence names. |

**Data-Driven Prober**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P4 | "Which parts of the reliability quarter would you defend hardest, and which least?" | EXP | [grounded] "I pushed a reliability quarter through against roadmap pressure." — your message | Weakest-assumption move: name the part you would defend least. Answer slot: if you chose what the quarter fixed, say how; if you did not, say so and say what you pushed for. | F1 and F7 carry the reliability story; a staff engineer will ask what was inside it. |
| P5 | "How would you tell a device-fleet failure from a control-plane failure?" | CASE | [generic] | Structure the question: what each failure looks like from the outside, what you would check first, and what you do not know about the device side. | Domain depth the pack cannot supply; say what you don't know. |

**Case / Strategist**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P6 | "Product wants a device-onboarding feature by Q3, and hardware cannot ship the firmware until Q4. How do you sequence?" | CASE | [grounded] "partner with hardware and product on roadmap" — role summary, your message | Clarify, then sequence, then name the trade-off. No claim about past sequencing. | Sharpens H5 for the panel; it is the same partnership problem in product terms. |
| P7 | "How much roadmap capacity would you protect for reliability, and how would you defend that?" | JD | [grounded] "I pushed a reliability quarter through against roadmap pressure." — your message | Hold the position: reliability capacity is a deliberate choice, defended with the 60% figure in your own words. Hold through two follow-ups; concede the cost specifically. Answer slot: if you set the capacity figure for a past quarter, say how; if you did not, say so. | Hold-then-concede on the one position your material carries. |

**Skeptic**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P8 | "You've led six for three years. Why should two squads trust that?" | JD | [grounded] "3 as a team lead of 6" — your message | Plain statement: "I've led a team of six for three years." Then the nearest scale evidence your material carries, and a plan for the step to eleven. Answer slot: if you have run anything at more than six people, say how. | F4 is medium; a peer-level skeptic will test the scale step. |

### Reverse questions (Round 2)

1. "What could a new person do in their first month that would genuinely help your team?" — Why it lands: the reciprocity question a peer panel weights most.
2. "Where does review load sit on the staff engineers today?" — Why it lands: shows you care about their workload.
3. "How are roadmap trade-offs decided with hardware right now?" — Why it lands: targets the partnership the role names.
4. "What would make the seam between your squads and theirs easier to run?" — Why it lands: a seam question in the interviewer's own terms.
5. "What is the reliability work you wish had more time?" — Why it lands: invites a concrete shared priority.

---

## Round 3: VP Engineering (following Monday, 30 min)

### Persona weights

| Persona | Weight | Why |
|---|---|---|
| Values / Behavioral | top (3) | The recruiter's own words, "values and leadership philosophy", are the raising source. Values are guaranteed in this round. |
| Pressure | 2 | Executive composure; time-boxed answers. |
| Case / Strategist | 2 | Altitude: decisions about a device product, not a sprint. |
| Skeptic | 1 | Why now, and why not stay. |

Reasoning: skip-level prior (Case + Pressure), shifted toward Values because the recruiter named the round's subject.

**Values sheet, not built.** Larkfield's published values are not in hand, so no values sheet appears. V1 to V3 use the recruiter's words and your own quoted sentences; see upgrade menu.

### Question banks

**Values / Behavioral**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "I pushed a reliability quarter through against roadmap pressure." and "My team's on-call burden dropped 60%" — your message | Map the reliability quarter. Beats the sentences state: the decision, the roadmap pressure it went against, the 60% outcome. Answer slot: if you took it to someone above you, say what you said; if there was no such moment, say so and give the nearest thing your material carries. Use "we" for context, "I" for your decision. | F7 is the only story your material carries here, and it is about a decision under pressure. |
| V2 | "What is your leadership philosophy, in a sentence, and show me one example of it." | VAL | [grounded] "values and leadership philosophy" — recruiter's words | Write your own sentence before the interview; do not borrow the company's language. Example: a sentence you can say, mapped to F2 or F7. Do not invent a philosophy your material does not show. | The recruiter's wording is the raising source; the example must come from your quoted sentences. |
| V3 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a time a customer or user outcome beat an internal number. If none comes to mind, say so, then give the nearest thing your material carries: the reliability quarter, if it fits. | Persona stem; the question presupposes no past event. |

**Pressure / Stress**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V4 | "That was one quarter. What happens next time the roadmap wins?" | JD | [grounded] "I pushed a reliability quarter through against roadmap pressure." — your message | Hold: the quarter was a decision, and the next one is a decision too. Concede specifically on what the first quarter did not solve. Do not fold on the core claim. | Hold-then-concede on the one position the material carries. |
| V5 | "You're asking to lead leaders you haven't led. Why isn't that a reach?" | JD | [grounded] "I've never managed managers" — your message | Plain acknowledgment: "I haven't managed managers." Then the honest concession: it is a reach in that way. Hold: what you have done, and how you would learn the rest. | F5 at the executive level; the question presupposes only your own negative. |

**Case / Strategist**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V6 | "Where would you draw the line between a device-product decision and an engineering decision?" | CASE | [generic] | Structure: what the product owns, what engineering owns, and the cases that sit between. Name a test you would use. | Altitude question on the role's partnership; no claim about the past. |
| V7 | "What do you think software teams underestimate about industrial IoT engineering?" | CO | [generic] | Give your own view as a pattern, and label it as one. Do not claim research on the company. | Without research, this is generic; the guidance says so. |

**Skeptic**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V8 | "Why now, and why not stay where you are?" | JD | [generic] | Answer from your own reasons. Any past claim must rest on one of your quoted sentences. | Motivation probe; the question presupposes nothing about your history. |

### Reverse questions (Round 3)

1. "What does leadership philosophy look like in a decision you are proud of here?" — Why it lands: turns the round's subject into a shared question.
2. "What would you want a new engineering manager to protect in their first year?" — Why it lands: a VP-altitude expectation.
3. "How do you hold a manager accountable to delivery without becoming the bottleneck?" — Why it lands: a leadership-philosophy question with a real trade-off.
4. "Where has the company's engineering org been most surprised by its own growth?" — Why it lands: invites current context.
5. "What would make you say the first year went well?" — Why it lands: asks for the success measure.

---

## Upgrade menu

- Full JD text → the role-summary quotes in the fit snapshot become `[grounded]` JD quotes; mid-list requirements get questions.
- Confirm whether the two squads have leads under you → decides whether F5 is a live gap in every round (also Question 2 below).
- Larkfield's published values page → values cheat sheet, and V1 to V3 map to published principles.
- The five interviewers' names → personas per member, interviewer read, reverse questions tied to each person's path.
- Recruiter email on focus areas or pre-declared deliverables → graded-deliverable sections, if any.
- Prep time available → a prioritized triage section.
- Deep research (offered once) → strategy brief, interviewer talks and writing, loop reports, recent org context. Tier L2: up to six further searches and two further fetches, a few minutes of run time.
