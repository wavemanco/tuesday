Your prep pack is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-alone-part-2-rooms-case-8-canned-12383111/a09d7acc-5e04-4fb2-ba26-0cf74fff3d94/scratchpad/ashgrove_member_experience_lead_interview_pack.md`. It's in loop mode, with one shared fit snapshot and a bank of 8 to 9 questions for each of the three rounds.

The gaps you asked me to flag:

- **Contact centre (F2) and senior presentations (F8)** are the two plain gaps. The pack doesn't claim either. Round 2 (B5) is where your manager is most likely to press on both together, so that's the answer to rehearse hardest.
- **Digital and self-service work (F5)** has no evidence in your material. Expect a probe there too, and the answer is whatever you've actually done, even if it's nothing.
- **The values round** has no story sentence in your material for any of the four values. The cheat sheet gives a selection scaffold for each, with the honest branch written in.
- **Presenting to the regional manager** is also an open question. If you've ever presented the spreadsheet to them, say so. That would change F8 and C6.

The panel's 20-minute escalation case is C1, with a pressure follow-up in C2. It's built as a structure to talk through, so it makes no claim about your past.

Two things I'd check before you rely on the pack:

- The strategy rows use your summary of the July brief, not the document. Check the brief before quoting numbers.
- I didn't run any web research. The values and strategy are from what you pasted.

Two one-line offers, neither pushed:

- **Drill:** I can play the Skeptic on B5 and push back on your answer.
- **Dossier:** I can save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions.

I can also convert the pack to Word if you'd like it that way.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove_member_experience_lead_interview_pack.md -----
# Member Experience Lead, Ashgrove Credit Union: interview pack (loop mode)

**Candidate:** Dara
**Role:** Member Experience Lead, Ashgrove Credit Union (member-owned, about 900 staff)
**Rounds:** three, 20 November 2026
1. Recruiter, 30 minutes
2. Head of Member Services (future manager), 45 minutes, mostly behavioural
3. Panel of two branch managers, 60 minutes, including a 20-minute complaint-escalation case. The panel scores against the four values.

First pack, so no changelog. Built on your message, the JD, the recruiter's email, the values you copied on 11 November 2026, and your summary of the July 2026 strategy brief. No web research was run.

---

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored: VAL (values and behaviour), EXP (your experience), JD (the listed requirements), CO (company and strategy), CASE (a live problem).
- **Guidance is scaffolding, not a script.** Say it in your own words. Where a guidance cell quotes a sentence, that sentence is what you can say, and nothing beyond it.
- **Answer slots** are instructions for the interview. Each one has an honest branch, so if the experience isn't there, say so and move on.
- **Provenance** shows what each claim rests on. `[grounded]` means traceable to your words or a supplied document. `[inferred]` means derived from one. `[generic]` means a pattern for the role, with no claim about you or Ashgrove.

---

## The fit snapshot

Shared across all three rounds. Requirements are quoted from the JD. Your evidence is quoted from your message.

Where you are exposed: F2 (no contact-centre work), F8 (no presentations above regional level) and F5 (no digital or self-service work on record). Those three are the likeliest probes. F2 and F8 together are the objection rehearsed hardest in B5.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches and the contact centre" (the JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | transferability | Your material shows the branch log, not the process end to end. Say it as you did: "I handled the branch's formal complaints log." Answer slot: if you ran any stage beyond the log, say which and how you decided, in your own words. If the process stopped at the log, say so and stay with it. |
| F2 | "Own the member complaints process end to end across branches and the contact centre" (the JD) | "Never worked in a contact centre" (your message) | none | [grounded] | capability | Plain acknowledgment: "I haven't worked in a contact centre." Then how you would learn it, as a plan and never as past. |
| F3 | "report monthly on complaint volumes and resolution times" (the JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | medium | [grounded] | presentation | The sentence reaches the requirement in other terms: a monthly complaints spreadsheet. Bridge reworded only from that sentence, adding nothing. Answer slot: if the spreadsheet counted volumes or resolution times, say which and how you read them. If it counted neither, say what it did count. |
| F4 | "coach branch supervisors on escalations" (the JD) | "trained new tellers on our escalation script" (your message) | medium | [grounded] | transferability | Adjacent work: teller training, not supervisor coaching. Bridge at its own scope: "I trained new tellers on our escalation script." Answer slot: if any of that training reached supervisors, say how. If not, say you have trained tellers, not supervisors. |
| F5 | "work with digital teams on self-service journeys" (the JD) | none given | none | [grounded] | discovery | Your material is silent here. Answer slot: say whether you have worked on a digital or self-service journey. If you have, say what you did and what changed. If not, say so and say what you would learn first. |
| F6 | "4+ years in financial-services customer operations" (the JD) | "6 years in retail banking, the last 3 as a branch supervisor" (your message) | medium | [grounded] | none | No gap. Say it in these words. |
| F7 | "experience handling regulated complaints" (the JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | transferability | The log is formal complaints work. Your material does not show that it was regulated, or on what terms. Bridge at its own scope: "I handled the branch's formal complaints log." Answer slot: if the log followed rules with set timescales or an outside review route, say which. If you did not know the rules, say so. |
| F8 | "confident presenting to senior leaders" (the JD) | "I've never presented to anyone above regional level" (your message) | none | [grounded] | capability | Plain acknowledgment: "I've never presented to anyone above regional level." Then how you would prepare for a senior audience, as a plan. |
| F9 | "comfortable with Excel reporting" (the JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | medium | [grounded] | none | The sentence reaches the requirement in role-relevant terms, but it says spreadsheet, not Excel. Name the software only if you used it. |

---

## Grounding brief

What the panel will assume you know. Two sources, both from you.

- **Values**, as you copied them on 11 November 2026: Members First, Always (decide from the member's side of the counter); Plain Words (if a member needs it explained twice, we wrote it wrong); Neighbours, Not Numbers (every branch is part of its town); Own the Fix (whoever finds the problem keeps hold of it until it is solved).
- **Strategy**, from your summary of the July 2026 brief: move 40% of member service to digital channels by 2028; consolidate eight branches into five hubs over 2027; launch a small-business lending product in Q1 2027; the main competitive pressure is app-only banks.

Check the brief itself before you quote any number. You have my summary, not the document.

---

## Persona weights by round

No interviewer profiles were supplied, so these are relationship priors adjusted by the round structure your recruiter described.

| Round | Who | Persona weights | Reasoning |
|---|---|---|---|
| 1, recruiter, 30 min | Recruiter | Conversational 4, Skeptic 3, others 1 | Recruiter-screen prior: friendly register, with motivation and knockout checks. Your two plain gaps (F2, F8) may come up lightly here. Scored all the same. |
| 2, Head of Member Services, 45 min | Your future manager | Values/Behavioral 5, Skeptic 4, Case 2, Pressure 2, Conversational 1 | Hiring-manager prior is Case plus Skeptic. Your recruiter's "mostly behavioural" moves Values/Behavioral to the top. Skeptic stays high because the manager will own the gaps F2 and F8. |
| 3, panel, 60 min | Two branch managers | Values/Behavioral 4, Case/Strategist 4, Peer Evaluator 3, Data-Driven Prober 2 | Panel prior is the top two personas for each member's relationship. The recruiter says the panel scores the four values and runs the escalation case, which lifts Values and Case. Branch managers are closest to peers, and they will test the seam with the branches. Persona per member waits for their names. |

**Persona counter-strategies, as they apply to you**
- **Skeptic** (rounds 1 and 2): hold the plain acknowledgment, then concede the gap with a plan. Never claim the missing experience.
- **Values/Behavioral** (rounds 2 and 3): one story per value where your sentences carry one. Where they don't, a selection scaffold, with its honest branch.
- **Case/Strategist** (round 3): clarify before you structure, and decide for the member before you fix the process.
- **Data-Driven Prober** (round 3): know what your spreadsheet counted, and say plainly when you don't know.
- **Peer Evaluator** (round 3): propose principles for the seam, not a map you haven't seen.

---

## Round 1: recruiter, 30 minutes (20 November)

Coverage for this round: F6 and F1 through F4 (A1), F2 (A4, A7), F8 and F5 (A7), F1 and F7 (A3, A6).

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through your background." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" "I handled the branch's formal complaints log" "trained new tellers on our escalation script" "I built the monthly complaints spreadsheet our regional manager uses" | A 90-second arc with these beats only, in this order: six years in retail banking, three as a branch supervisor; the complaints log you handled; the teller training on the escalation script; the spreadsheet your regional manager uses. Say each in your own words and stop there. Do not add a result the sentences don't state. | Opening question for any screen. F6, F1, F4 and F3 are the four sentences the arc can use, and the order is the only thing added. |
| A2 | "What's drawing you to Ashgrove?" | VAL | [generic] | Answer with one sentence about the work and one about Ashgrove as a member-owned credit union. If you don't yet have a specific reason, say what you want to learn in the role. | Motivation is a screen item in this register. Ashgrove's published values are the vocabulary the panel will use (section on values below). |
| A3 | "Tell me about the complaints you handled day to day." | EXP | [grounded] "I handled the branch's formal complaints log" | Story-mapped on F1: the log, and what you did with each entry, in your words. Answer slot: the JD asks about resolution times. If you tracked how long complaints took, say how. If you did not, say what you did track. Do not give a volume you cannot name. | Premised on the log the sentence quotes. The slot is raised by the JD's monthly reporting line (F3). |
| A4 | "You've mostly worked in branches. Why would a role across the contact centre suit you?" | JD | [grounded] "Never worked in a contact centre" | Answer the motivation. Then the plain acknowledgment: "I haven't worked in a contact centre." Then what you know about how complaints move through one, if anything. If you know little, say it is a plan to learn. | F2's plain acknowledgment, in a motivation question, so the words are ready before the harder probe in round 2. |
| A5 | "Why are you looking to leave branch work now?" | VAL | [grounded] "the last 3 as a branch supervisor" | Give the true reason, in your words, about the work. Don't criticise the bank you're in. If the honest reason is the step up, say so. | Skeptic's why-now stem. The three years are F6's, so the sentence carries the premise and no more. |
| A6 | "How much of the complaints work you describe was your own decision, and how much was the process?" | EXP | [grounded] "I handled the branch's formal complaints log" "trained new tellers on our escalation script" | Attribution, in your own words. Name the part of the log that was yours and the part the process or the script set. If none of it was yours to decide, say so plainly. | The attribution probe. F1 and F4 are the two sentences it tests, and honest attribution is what it scores. |
| A7 | "Which part of this role would you be weakest in on day one?" | JD | [grounded] "Never worked in a contact centre" "I've never presented to anyone above regional level" | Name the contact-centre side and the senior presentations, in those words, with one line of plan for each. Then the digital journeys: say whether you have worked on self-service, and if not, what you would learn first. Answer slot for the digital part, since your material is silent on it. | Skeptic stem. The recruiter round is where a gap is first named, so name it cleanly. F2, F8 and F5 are the three rows it draws on. |
| A8 | "Anything you'd want us to know that isn't on the CV?" | VAL | [generic] | Have one true item ready, or say there's nothing beyond what you've said. Don't use this slot to add a claim about your work that you haven't already made in this round. | The recruiter's closing slot. A new claim here is the first thing round 2 will test. |

**Reverse question**
- "What happens between the third round and a decision?" Why it lands: it shows you know the loop and want the process, not just the outcome.

---

## Round 2: Head of Member Services, 45 minutes (behavioural, your future manager)

Coverage for this round: values (B1, B2, B3, B4), JD requirements (B5, B6, B7), EXP (B8), case (B9).

**Highest-ROI prep:** B5. Your manager will test F2 and F8 together, and a rehearsed hold-then-concede answer changes the round more than any other single answer in this pack.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time you put a member's interest ahead of a process rule." | VAL | [grounded] raising source: "Members First, Always" (the values text you copied). No candidate sentence carries a story here. | Open prompt, so a selection scaffold ending in its honest branch. Pick a time the rule and the member's need pulled apart. Name the rule, what the member needed, what you did and why. If no such time comes to mind, say so plainly, then give the nearest case in your complaints work and how you handled it. | Members First is the panel's first scoring line, and it is the value a manager tests most directly. |
| B2 | "Tell me about a time you had to simplify an explanation so it landed first time." | VAL | [grounded] "trained new tellers on our escalation script" | Story-mapped on F4: the script and the training you gave. Beats: what the script says, what tellers found hard, what you did about it. Say only what you did. If you changed the wording, say so. If you did not, say what you did in the sessions and what you would change. | Plain Words. The teller training is the nearest sentence, and it is about explaining a process, so it fits the value without stretching. |
| B3 | "What does a branch need from its complaints process that a monthly number won't show?" | VAL | [generic] question. [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Answer from the principle: a branch is part of its town, and a number does not carry the local story. Then one line on how you would find it out: go to the branch, read the complaints by reason or area, ask the supervisor. If you give the spreadsheet as an example, call it what it was, numbers, and no more. | Neighbours, Not Numbers is the value this tests. Your spreadsheet is the numbers side. The town side is not in your material, so the answer is a principle and a method, not a story. |
| B4 | "Tell me about a complaint you kept hold of until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log" | Story-mapped on F1: a complaint you kept on the log until it closed. Beats: the log, the entry, the close. Anything more (how many handoffs, which team, what the member said) is an answer slot. If the complaint went through other hands, say who held it and what you did to keep it moving. If you had no such complaint, say so and describe how you would keep one. | Own the Fix. The sentence gives the log, not the follow-through, so the story is thin and the slot does the work. |
| B5 | "You've never worked in a contact centre, and you've never presented above regional level. Why should we trust you with an end-to-end role across both?" | JD | [grounded] "Never worked in a contact centre" "I've never presented to anyone above regional level" | **Hold:** "What I've handled is complaints end to end inside a branch: the log, the escalation, the answer." **Follow-up one** (the contact centre carries most of the volume): concede. "Yes, the contact-centre side is new to me. In the first 90 days I'd sit with the contact-centre complaints team, map where cases stall between channels, and bring the map back to you." **Follow-up two** (senior leaders are a different room): concede. "Yes, I haven't presented above regional level. I'd rehearse with a peer first, lead with the member impact, and bring only numbers I can defend." Never claim contact-centre or senior-presentation experience. | The hiring manager's skeptic line. F2 and F8 together, in the candidate's own words. The concessions are plans, never history. The objection will come up in some form in every round. |
| B6 | "How would you coach a supervisor who escalates every complaint upward?" | JD | [inferred] derived from F4: "trained new tellers on our escalation script" | Start with why the supervisor escalates, then coach the decision they can make themselves, then agree what stays with the escalation route. Answer slot: if you have coached anyone on escalation decisions, say how. If you have trained tellers only, say that, and say how you would adapt it for supervisors. | The JD's coaching line, with no supervisor-coaching sentence on record. F4 is the bridge, so its limit is written into the answer. |
| B7 | "What would the monthly complaints report to us contain?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Describe what the report would show for volumes and for resolution times, and how you would read each. Answer slot: say what your spreadsheet counted. If it showed volumes or resolution times, say which and how. If not, say so. If you give a figure, name the assumption you would defend least. | The JD's monthly reporting line (F3). The question asks about the report, not about your past, and the spreadsheet only sets the premise. |
| B8 | "What did your regional manager do with the spreadsheet?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Say what they used it for, in the words you know. If you don't know, say so. Don't infer decisions from it. | Premised on the artifact. Tests whether the spreadsheet had a reader and a use, which a manager will check. |
| B9 | "A member writes that they've been passed between three departments. What do you do first?" | CASE | [generic] | Structure: find the one person who will own the complaint; check where it has stalled; send the member a plain update; then fix the handoff. Speak through the first 24 hours. | A short live problem from the JD's end-to-end line. It needs no claim about your past, so the guidance makes none. |

**Reverse questions**
- "What would a good first 90 days look like from your side?" Why it lands: you ask the manager to define success, which gives you the scoreboard.
- "How do you want complaints handled differently once the branches move into hubs?" Why it lands: it ties to the 2027 consolidation in the brief, asked of the person who owns the outcome.
- "What part of this role does the JD leave out that takes people by surprise?" Why it lands: it invites your manager to describe the real job, and it signals you expect more than the listing says.

---

## Round 3: panel of two branch managers, 60 minutes (with the 20-minute case)

Coverage for this round: C1 and C2 (the escalation case), C3 and C4 (strategy), C5 (seam with the contact centre), C6 and C7 (senior presentation and reporting), C8 (Own the Fix).

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A member's fee complaint has been escalated three times and is on day 40. The branch says its decision was right; the contact centre says the member was misinformed. You have 20 minutes. Walk us through it." | CASE | [inferred] derived from the JD's escalation line ("coach branch supervisors on escalations") and the value Own the Fix | Structure it aloud. First, check what the file says and which timescale applies. Next, decide what the member should hear first, in plain words. Name one owner who keeps the case until it closes. Then separate the fix for this member from the fix for the process. Say the decision for the member before the process. | The 20-minute case is the panel's main test. It scores structure and member-side thinking. It needs no claim about your past, so none is made. |
| C2 | "The branch manager says that's fine for this case, but it will happen again next week. What do you do?" | CASE | [generic] | Move from the case to the pattern. Find the trigger in the file, count how often it recurs, name the owner for the fix, and say how it would show in the monthly report. Don't promise a number you haven't seen. | Pressure follow-up. Tests whether the fix becomes a system change. |
| C3 | "How would you protect a town's complaints service when its branch closes in a hub move?" | CO | [grounded] "eight branches into five hubs over 2027" (your summary of the July 2026 brief) | Say what the town loses (a person nearby, local knowledge) and what moves (the case, the follow-up, the deadline). Plan the notice to members and the handover of open complaints before the move. If you have been through a branch change, say how. If not, say so and say how you would plan one. | Neighbours, Not Numbers is the value this tests, and the consolidation is the strategy line the panel will care about. |
| C4 | "Forty per cent of member service moves to digital by 2028. Which complaints should move with it, and which shouldn't?" | CO | [grounded] "move 40% of member service to digital channels by 2028" (your summary of the July 2026 brief) | Segment. Routine, rule-based complaints can move. Complaints that need a person stay human: vulnerable members, disputes with a regulatory clock, members who can't use the app. Name what you would watch in the monthly report to see whether the move works. Don't call the target achievable or not, since you have no data for that. | Works with digital teams on self-service journeys (F5). Segmentation is the answer the panel is looking for, and it is a method, not an experience claim. |
| C5 | "Our branches and the contact centre each think the other causes the complaints. How would you handle that as the person reporting on them?" | JD | [generic] | Principle first: one owner per complaint across channels, a shared view of each case, and a joint review of the cases where the two sides disagree. Say you would not pretend to know where the seam is before you have seen it. If you have settled a dispute between two teams, say how. If not, say so. | The peer seam. The panel's branch managers will test whether the role can hold the contact centre to account without taking sides. |
| C6 | "When a branch manager disagrees with a monthly number you put in front of senior leaders, what happens?" | JD | [grounded] "I've never presented to anyone above regional level" | Plain acknowledgment: "I've never presented to anyone above regional level." Then the method: check the count first, name the assumption you would defend least, and agree what would change the number. | Senior presentation (F8) and the reporting question together. The acknowledgment is your own words. |
| C7 | "What did your spreadsheet count, and how did you count it?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Answer slot. Say what it counted, in your words. If it defined a resolved complaint, say how. If it had no definition, say so and say what you would define first. Name the figure you would defend least. | Data-Driven Prober's defend-the-number question. The spreadsheet is the only figure artifact in your material. The question presupposes only that it exists. |
| C8 | "Tell me about a complaint that came back to you after you'd closed it." | VAL | [grounded] "I handled the branch's formal complaints log" | Open prompt on Own the Fix. If a complaint reopened, say what the first close missed and what you did next. If none came back to you, say so, then say what you would do the first time one does. | The value is tested by what happens after the close. The sentence gives the log, not the reopen, so the slot carries the story. |

**Reverse questions**
- "What does Own the Fix look like when a complaint crosses from a branch into the contact centre?" Why it lands: it shows you take the value seriously, and it is asked of the people who would carry the handover.
- "When the branch and contact-centre views of a complaint conflict, who decides?" Why it lands: it names the seam and shows you think about ownership before you walk in.

---

## Values cheat sheet

The panel scores against these four. None of your sentences carries a full story for any of them, so each row is a selection scaffold with its honest branch. The one exact quote in the table comes from F1 or F4, where the sentence reaches the value.

| Value (official name) | Working meaning | Mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | No quoted sentence carries a story. Scaffold: a decision you made for a member when the process pointed the other way. If none comes to mind, say so, then give the nearest complaint you handled and what it asked of you. |
| Plain Words | If a member needs it explained twice, we wrote it wrong | Nearest sentence: "trained new tellers on our escalation script" (F4). Scaffold: a letter or explanation you made clearer. If you did not change the wording, say the training was the nearest thing, and say what you would change. |
| Neighbours, Not Numbers | Every branch is part of its town | No quoted sentence carries a story. Scaffold: a branch-level pattern you saw that a number hid. If none, say so, and say how you would find out what a town needs. |
| Own the Fix | Whoever finds the problem keeps hold of it until solved | Nearest sentence: "I handled the branch's formal complaints log" (F1). Scaffold: a complaint you kept on the log until it closed. Honest branch: if the follow-through was not yours, say so and say whose it was. |

---

## Prohibited claims

Built locally from the fit snapshot. These are the claims your material does not support and that the pack will not coach. Each entry has its basis and its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Worked in a contact centre | Negative you stated: "Never worked in a contact centre" | Plain acknowledgment: "I haven't worked in a contact centre." No slot on this. |
| Presented to senior leaders | Negative you stated: "I've never presented to anyone above regional level" | Plain acknowledgment: "I've never presented to anyone above regional level." No slot on this. |
| Owned complaints end to end across branches and the contact centre | Inflated form of F1: "I handled the branch's formal complaints log" | The quote at its own scope. Limit, as the pack's observation: your material shows the branch log, not the end-to-end process. The slot in B4 stays inside the log. |
| Coached branch supervisors on escalations | Inflated form of F4: "trained new tellers on our escalation script" | The quote at its own scope: "I trained new tellers on our escalation script." The slot in B6 asks about supervisors. |
| Your spreadsheet tracked volumes and resolution times | Inflated form of F3. The sentence says a monthly complaints spreadsheet, not what it counted | The quote at its own scope. What it counted is an answer slot (B7, C7), not a claim. |
| Ran a regulated complaints process | Inflated form of F7 | The quote at its own scope: "I handled the branch's formal complaints log." |

---

## Sources

- **Provided documents:** your message (background, the two plain gaps, the spreadsheet, the log, the training); the JD text; the recruiter's email (three rounds on 20 November and the round structure); the values text you copied on 11 November 2026; your summary of the July 2026 strategy brief.
- **Searches and fetches:** none. The research tier is L0, provided documents only.

**Research tier: L0, provided documents only**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | The values text you pasted fixes the cheat sheet and the grounding brief. No search needed at L0. |
| 2. Ashgrove interview process, member services | skipped | The recruiter's email fixes the three rounds and the panel's values scoring. |
| 3. Ashgrove strategy and recent news | skipped | Your summary of the July 2026 brief fixes the grounding brief. A search would add recent news only (L2). |
| 4. Interviewer name and Ashgrove | n/a | No names were given for the round 2 manager or the panel. |
| 5. Representative JD for the title | skipped | Your JD fixes the fit snapshot and the JD-tagged questions. |

---

## Upgrade menu

- **What your spreadsheet counted, and which software you used.** Upgrades F3 and F9 to grounded facts, and lets B7 and C7 use your own numbers instead of slots.
- **Any contact-centre work, even a shadow shift or a small project.** Turns F2 from a plain acknowledgment into a quoted bridge, and gives B5 a real sentence to hold.
- **Any presentation above regional level, even to a committee or a regional meeting.** Gives B5 and C6 a second sentence to hold.
- **Any digital or self-service work, even a small one.** Turns F5 from a discovery gap into a quoted row.
- **Whether the hub moves change your base or your travel.** Location and travel are terms the JD does not state. If they apply, the pack adds a hard-gate row, so it is worth knowing before 20 November.
- **How many prep hours you have before 20 November.** Adds a prioritised prep triage section.
- **The names of the round 2 manager and the two panel members.** Adds per-person persona weights and an interviewer read.
- **The July 2026 brief itself.** Checks the strategy rows against the source, and lets you quote its wording.
- **Deep research (L2), offered once.** Four more targets: the interviewers' public footprint, their published talks, recent Ashgrove news, and role-family loop reports. Caps: 6 more searches and 2 more page fetches. Time cost: a few minutes of searching. Run only if you want it.
