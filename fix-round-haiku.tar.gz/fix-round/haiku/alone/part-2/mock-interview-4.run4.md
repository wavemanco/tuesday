Your prep pack is saved as /tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-alone-part-2-rooms-case-4-denied-c9d5e11c/6e7d6239-574c-4d0a-b51a-a32c9340d31c/scratchpad/quartzline_product_manager_platform_apis_interview_pack.md. I built it for a hiring-manager round, using your dossier. Web search was refused in this session, so the pack has no Quartzline values, strategy, or interview-process detail; the file's Sources section lists the refused calls.

Say the word and I'll play the Skeptic on A1, the question the pack names as its highest-ROI prep.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Has anything changed since the dossier was generated on 14 August, such as the role's status or who the squad leads are?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quartzline_product_manager_platform_apis_interview_pack.md -----
# Interview pack: Product Manager, Platform APIs at Quartzline

**Round:** hiring-manager conversation, 45 minutes, Thursday. **Interviewer:** not named.
**Changelog:** first pack, built from `tuesday-dossier.md` (dossier_version 1.1, generated 2026-08-14).
**Check before Thursday:** the dossier is about three months old. Confirm the role is still open and that the two squad leads are the same people the JD describes.

## How to use this pack

- **Personas** are how a question arrives (friendly, skeptical, numerical, pressing). **Types** are what is being scored.
- Type key: **JD** = tests a stated requirement or responsibility. **EXP** = tests a claim from your own experience. **CASE** = a live problem from the role; it asks nothing about your past. **CO** and **VAL** are not used in this pack.
- Guidance is scaffolding, not a script. Rehearse it in your own words.

## Fit snapshot

Requirements are quoted from the JD as the dossier's role_profile gives them. Evidence is quoted from the dossier's verified_candidate_evidence (origin `dossier E1` to `dossier E3`). Gap and bridge language is the pack's own, and every clause about what you did rests on a quote in its row.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" — JD (dossier R1) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier E1 | low | [grounded] | transferability | Position the work as adjacent, never as PM experience. Your material shows integration delivery from scoping to go-live. It does not show a product-management title or role, and the bridge stops there. Plain acknowledgment, named by field: prohibited_claims. "I haven't held the product manager title." |
| F2 | "Shipped API or platform products" — JD (dossier R2) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier E1 | low | [inferred] | discovery | The quote touches the requirement without showing it reaches it. Your material shows integrations of the vendor's APIs, not APIs you shipped. Answer slot: if you shipped a product partners used directly, say what it was and your part in it; if the work was integrating the vendor's APIs, say that as it is. The handoff does not grade R2 (see Sources). |
| F3 | "Stakeholder management across engineering, sales, customers" — JD (dossier R4) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier E1; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier E3 | medium | [grounded] | discovery | Customer and product touchpoints are in the quotes. Engineering and sales are not. Answer slot: name an engineering or sales counterpart you worked with on a client integration and what you agreed; if there was none, say so and stay with the customer and product work. |
| F4 | "Technical fluency: API docs, schemas" — JD (dossier R3) | "Wrote the internal integration playbook her team uses" — dossier E2 | medium | [grounded] | discovery | The playbook is an internal integration guide. Your material does not show that it is API documentation or schemas. Answer slot: if you wrote or reviewed API docs or schemas, say which; if the playbook is the nearest thing, say what it covers. |
| F5 | "Agile delivery experience" — JD (dossier R5, preferred) | none given | low | [grounded] | discovery | No quoted sentence speaks to agile delivery, so there is no bridge. Answer slot as in A4: if you have run planning or sprints with engineers, say which and your part; if you have not worked that way, say so. |
| F6 | "Owning a roadmap and prioritization authority" — JD (dossier R1 sub-claim, responsibilities) | none given | none | [grounded] | capability | Plain acknowledgment, named by field: acknowledge_gap, prohibited_claims. "I haven't owned a product roadmap or set priorities for an engineering squad." Then a plan, never a past: what you would map in your first month, and with whom. |
| F7 | "Define and track adoption metrics" — JD (dossier role_profile responsibilities) | none given | none | [grounded] | discovery | Your material is silent on adoption metrics. Answer slot, as in A3: if you have measured adoption, say what and how; if not, say so and say what you would measure first. |

Gap types follow the routing rule: `capability` only where the dossier records the absence (F6); `transferability` where a quote carries adjacent work that does not reach the requirement (F1); `discovery` where the material is silent or touches without showing (F2 to F5, F7). No row is `hard_gate`: the dossier lists no hard gates.

## Persona table

| Persona | Weight (depth) | How it shows up | Why this weight | Counter-strategy |
|---|---|---|---|---|
| Skeptic | 5 (5 questions) | Asks about the gap directly: why a PM hire without the title | Hiring-manager prior, plus the dossier's named objection and two gap rows (F1, F6) | Rehearse A1 until it is routine. Plain acknowledgment for F6. Bridge only from quotes. |
| Case / Strategist | 5 (5 questions) | Live problems on this platform: a breaking change, a metric drop, a 90-day plan | Hiring-manager prior: they are buying capability and checking how you decide | Clarify, then structure, then state decision rights out loud. Do not claim to decide alone. |
| Data-Driven Prober | 3 (3 questions) | Asks how the 30+ figure was counted and what the playbook's use means | The 30+ figure and the playbook are the two claims most likely to be tested | Say how it was counted, or say you do not know. Name the weakest assumption you know of. |
| Pressure | 3 (3 questions) | Time-boxed challenges to the objection and to the roadmap claim | 45-minute manager round; the objection invites pushback | Pause, restate, hold through two follow-ups, then concede the specific gap. |
| Conversational | 2 (2 questions) | Opens with "walk me through the journey", then asks casually about API docs | Low weight, but casual questions are still scored | Use a 90-second arc. Treat the casual question on API docs as scored. |

Not weighted: Peer (the round is a hiring manager's) and Values (no values round detected, no company values in hand).

## Question banks

### A. Skeptic (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier E1; "Wrote the internal integration playbook her team uses" — dossier E2; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier E3 | The highest-ROI rehearsal in this pack. Do not argue the title. Name the limit first, plainly: "I haven't held the product manager title or owned a product roadmap" (plain acknowledgment, named by field: prohibited_claims, acknowledge_gap). Then restate the work in the quotes' own terms: the integrations from scoping to go-live, the playbook your team uses, the input sessions that fed client evidence to product. Concede the specific gap: the part you would need to earn is roadmap calls and squad priorities, and your first month would map which of those calls the squads make and who makes them. Hold through two follow-ups by returning to the quoted work, never by adding to it. | The underwriter named this as the likeliest objection; it aims at F1 and F6, the thinnest area, so it gets the deepest rehearsal. Its negatives are sourced by named dossier fields. |
| A2 | "Which part of this JD would you be weakest at on day one?" | JD | Plain acknowledgment, named by field: acknowledge_gap (R1 sub-claim, F6) | Answer plainly: owning the roadmap and setting squad priorities, and say that you have not done either. Then a plan: what you would map, who you would ask, and what you would confirm in the first month. Do not name a second weakness unless it is in the quotes. | F6 is `capability`. A plain acknowledgment a candidate can say without it becoming a bluff. |
| A3 | "How would you know whether partners were adopting the API?" | JD | [generic] | Answer slot: if you have measured adoption, name the measure and how it was counted, in your own words; if you have not, say so plainly and say what you would measure first. Do not describe a measure you did not track. | F7 is silent in the material; the question asks for the method, not a claim. |
| A4 | "What's your experience running agile delivery inside a product org?" | JD | [generic] | Clarify strategy: no quoted sentence speaks to agile delivery, so there is no story. Answer slot: if you have run planning or sprints with engineers, say which and what your part was. If you have not worked that way inside a product org, say so, and ask what they mean by the term and what they would want from the first sprint. | F5 is `discovery` with a clarify strategy; the honest answer is a question back. |
| A5 | "Tell me about a time sales and engineering wanted different things from you on a client integration. What did you do?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier E1 | Open prompt. Tell one integration through the stages the quote states: scoping, requirements, architecture, UAT, go-live, in your own words. Answer slot: if sales or engineering disagreed on that integration, say what each wanted and what you did. If no such disagreement happened, say so plainly and tell the nearest integration. | F3 is `discovery` on engineering and sales. The question asks for an instance you choose; the quote supplies its stages. |

### B. Case / Strategist (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A partner needs a breaking change to the auth API. Engineering wants a quarter; sales says the partner churns in six weeks. Who decides, and how?" | CASE | [generic] | Clarify the objective and the partner's real deadline first. Segment the affected partners. Then say who you would want to make the call and why. Name decision rights out loud, and do not claim you would decide alone. Close with the risks of each option. | Tests R1 decision authority as a live problem, with no claim about your past. |
| B2 | "Partner API adoption fell 20% last quarter. Diagnose it." | CASE | [generic] | Clarify the baseline and the definition of adoption before any cause. Then split the drop by partner segment, by release, and by integration stage. Ask for the baseline you would need. | Tests the adoption responsibility (F7) as a live problem. |
| B3 | "Plan your first 90 days on this platform. What do you need to know first?" | CASE | [generic] | Lead with the questions: which roadmap calls exist, who makes them, which partner discovery is open. Then a plan with checkpoints. State no past experience. | Tests the ramp plan that F6 requires, and the spec-and-delivery responsibility. |
| B4 | "What would you cut from the partner API roadmap this year, and why?" | CASE | [generic] | Name one cut and the evidence you would need before making it. Say that the call belongs to whoever owns the roadmap, and that you would bring the case to them. | Tests roadmap judgment without claiming roadmap ownership. |
| B5 | "Two partners need the same endpoint change, and only one squad can take it. Which partner goes first?" | CASE | [generic] | Clarify what each partner's delay costs. Propose the principle for choosing, then the decision owner. Name the squad lead as the person who weighs capacity. | Tests partner discovery and the squads, the two responsibilities this round is about. |

### C. Data-Driven Prober (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how you counted the 30+ integrations." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier E1 | Defend the number in your own words: how it was counted, what it is sensitive to, the assumption you would defend least, and which of the integrations were yours to lead. Answer slot: if you do not know how it was counted, say so plainly and say what you can confirm. Do not supply a counting method. | Headline figure on the strongest claim. The four defend-the-number slots are the rehearsal, and no method is supplied because none is in the quotes. |
| C2 | "Your team uses the playbook you wrote. How do you know they follow it?" | EXP | [grounded] "Wrote the internal integration playbook her team uses" — dossier E2 | Answer slot: if you checked adherence, say how; if you did not, say so and say what you would check. Hold to the quote: your team uses the playbook; nothing about how closely. | E2 is `high` confidence and inspectable; the prober asks how you know. |
| C3 | "What happened to the client evidence after the input sessions reached product?" | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier E3 | Medium confidence: volunteer the limit before it is extracted. Answer slot: if you saw what product did with the evidence, say what; if you did not, say so. Stay with feeding the sessions; do not describe product's decisions. | E3 is `medium`: confirmed, with limited inspectable proof. The seam is what a prober finds. |

### D. Pressure (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over a PM with three years?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier E1; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier E3 | Pause before answering. Restate the question. Hold the position through two follow-ups: the integration work and the input sessions, in the quotes' words. Concede specifically on roadmap authority, not in general. | Tests composure. The hold is only what the quotes carry. |
| D2 | "Name a platform product you have shipped, in thirty seconds." | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier E1 | Open prompt. Name the product and your part if you shipped one. If the work was integrating the vendor's APIs, say that plainly. Do not stretch "integrations" into "shipped products". | R2 has no other question. The pressure is on wording: the quote supports integrations, not shipping. |
| D3 | "You've never owned a roadmap. Why would the squads listen to you?" | JD | Plain acknowledgment, named by field: acknowledge_gap (R1 sub-claim, F6) | Acknowledge plainly: you have not owned a roadmap. Then what would earn the squads' trust in your first months, as a plan. Do not describe trust you have already built. | F6 is `capability`. The negative is sourced by the dossier's acknowledge_gap field. |

### E. Conversational (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So — walk me through the journey." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier E1; "Wrote the internal integration playbook her team uses" — dossier E2 | A 90-second arc: integration delivery, then the playbook, then the input sessions. Name the limit in the arc: the work is adjacent to product management, and you have not held the title. | Low weight; the opener sets the register and the arc is rehearsed before anything else. |
| E2 | "What are you playing with in API docs these days?" | JD | [grounded] "Wrote the internal integration playbook her team uses" — dossier E2 | Treat it as scored. Answer slot: if you have written or reviewed API docs or schemas, name them; if the playbook is the nearest, say what it covers. | R3 is asked casually here. |

### Coverage

| Requirement or responsibility | Covered by |
|---|---|
| R1: 3+ years PM experience | A1, A2, B1, D3 |
| R2: Shipped API or platform products | D2 |
| R3: API docs, schemas | C2, E2 |
| R4: Stakeholder management | A5, D1 (engineering and sales: slot only) |
| R5: Agile delivery | A4 |
| Define and track adoption metrics | A3, B2 |
| Own the roadmap | A2, B4 |
| Write specs and drive delivery with two squads | B3, B5 |
| Run discovery with integration partners | B5 |

## Reverse questions

Five, each with why it lands. No peer or interviewer profile exists, so none ties to the interviewer's own path.

1. **"Which roadmap decisions does this PM make alone, and which belong to the squad leads?"** It lands because decision authority is the biggest unknown, and it reads as diligence. The dossier names it as an opportunity risk.
2. **"How is partner API adoption measured today, and what is the current baseline?"** It lands because the JD names adoption metrics with no stated baseline. Asking for the baseline signals you will set a target only after one exists.
3. **"What would a strong first 90 days look like for this seat?"** It lands because it converts the objection into their expectation, and it lets you show your ramp plan on their terms.
4. **"Where do the two squads and partner discovery most often pull priorities apart?"** It lands because it finds the seam where R1 and R4 get tested, and it shows you have thought about the job's real friction.
5. **"What does agile delivery look like day to day between this PM and the squads?"** It lands because R5 is unclear in the JD. Their answer tells you what they mean by it.

## Prohibited claims

Not coached in any answer, slot, hold, or reverse question. Each entry names its basis and its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | Sourced: dossier prohibited_claims | Plain acknowledgment, named by field: "I haven't held the product manager title." No slot on it. |
| Having owned a product roadmap | Sourced: dossier prohibited_claims, acknowledge_gap | F6's plain acknowledgment. No slot on it. |
| Having set prioritization for an engineering squad | Sourced: dossier prohibited_claims | F6's plain acknowledgment. No slot on it. |
| Ran the roadmap | Inflated form of E3 ("Ran quarterly roadmap-input sessions…") | E3 at its own scope. The limit is the pack's observation: your material says input sessions feeding client evidence to product, not roadmap decisions. |
| Shipped API products | Inflated form of E1 ("Led 30+ end-to-end client integrations…") | E1 at its own scope. The limit is the pack's observation: integrations of the vendor's APIs, not APIs you shipped. |
| Wrote API documentation or schemas | Inflated form of E2 ("Wrote the internal integration playbook…") | E2 at its own scope. The limit is the pack's observation: a playbook, not shown to be API docs or schemas. |

Silence is not listed: engineering and sales stakeholder work, adoption measurement, and agile delivery get answer slots, not prohibitions.

## Sources

- **Provided document:** `tuesday-dossier.md`, pasted into the conversation. dossier_version 1.1, which this skill reads. Consumed: `handoff_to_mock_interview` (all of it), `role_profile` (satisfies the JD tier), and `decision` (context only). Not present in the pasted dossier: `evidence_map`, `evidence_state`, `risk_register`. The fit snapshot's grades therefore come from the handoff's entries, and R2 is not graded anywhere in the dossier, so F2 is this skill's grade.
- **Searches sent this session:**
  - "Quartzline company partner API platform" — refused (search permission not granted).
  - "Quartzline values product management interview" — refused (search permission not granted).
- **Fetches:** none sent.

**Research tier:** L1 — searches 0 of 6 (2 refused), fetches 0 of 2.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quartzline values` | unavailable | Values cheat sheet, which would apply only if a values round were detected. Calls refused, so no values are in hand. |
| 2. `Quartzline interview process product manager` | unavailable | Loop structure; persona weights would follow any named rounds. Calls refused, so the pack uses the hiring-manager prior. |
| 3. `Quartzline strategy` / recent news | unavailable | Current-strategy CO questions. No search was sent for it: search permission was denied, and no strategy brief was supplied. |
| 4. `{interviewer name} Quartzline` | n/a | No interviewer name was given. The interviewer read is absent; the upgrade menu says what a name would unlock. |
| 5. representative JD | skipped | The dossier's role_profile fixes the requirements and the JD-tagged questions. |

## Upgrade menu

- The interviewer's name → a tailored reverse question, and persona weights read from their public footprint.
- Quartzline's values page or a strategy brief, pasted → a values cheat sheet and current-strategy CO questions. Search was refused, so these are missing.
- The current JD text → checks the wording of each requirement against the quotes; R2 is not graded in the dossier.
- The dossier's `evidence_map` → grades F2 and F4 from the underwriter's map, not this skill's.
- Prep hours before Thursday → a prioritized triage schedule.
- Confirmation that the role is still open, given the dossier date → confirms the pack's assumptions about the squads.
