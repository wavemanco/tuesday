I couldn't run the live Ashgrove search because the permission for it was declined, so the pack below is built only from what you gave me: the JD, the recruiter's email, the values and strategy text, and your background. The strategy's recent-news check is marked unavailable.
Your prep pack is saved at `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/haiku/alone/part-2/rooms/case-8-denied-347a279c/ashgrove_member-experience-lead_interview_pack.md`. The full pack is below.

# Interview prep pack: Member Experience Lead, Ashgrove Credit Union

**Interviews:** 20 November 2026. Round 1 is the recruiter, 30 min. Round 2 is the Head of Member Services (your future manager), 45 min, mostly behavioural. Round 3 is a panel of two branch managers, 60 min, with a 20-minute escalation case; the panel also scores the four values. Interviewer names for rounds 2 and 3 aren't assigned yet.

## How to use this pack

- **Personas** describe how a question is asked. **Types** describe what is scored: VAL (values), EXP (your experience), JD (the listed job), CO (company and strategy), CASE (live problem).
- Guidance is scaffolding, not a script. Say it in your own words.
- Quoted sentences come from your message, the JD, or the values text. Nothing in quotation marks was written by me.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" (JD) | "6 years in retail banking, the last 3 as a branch supervisor" (your message) | high | [grounded] | presentation | The years are there. Say them: "I've spent six years in retail banking, the last three as a branch supervisor." |
| F2 | "experience handling regulated complaints" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | hard_gate | Your material does not establish regulated complaints handling; it shows a formal complaints log. No bridge is written for a gate. Step 1 asks one question about it. |
| F3 | "confident presenting to senior leaders" (JD) | "I've never presented to anyone above regional level" (your message) | none | [grounded] | capability | Words: "I haven't presented to anyone above regional level." Then how you would learn it, as a plan, never as a past. |
| F4 | "comfortable with Excel reporting" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | medium | [grounded] | none | The quote reaches the requirement. Expect a probe on how the spreadsheet is built; say what it counts, in your own words. |
| F5 | "Own the member complaints process end to end across branches and the contact centre" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | transferability | Your material shows one branch's log, not a process run end to end across branches. Words at its own scope: "I handled the branch's formal complaints log." |
| F6 | "report monthly on complaint volumes and resolution times" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | medium | [grounded] | transferability | Monthly reporting reaches the requirement; resolution times don't appear in the quote. |
| F7 | "coach branch supervisors on escalations" (JD) | "trained new tellers on our escalation script" (your message) | medium | [grounded] | presentation | Escalation coaching in other terms, with tellers rather than supervisors. Words: "I trained new tellers on our escalation script." Don't say you coached supervisors. |
| F8 | "work with digital teams on self-service journeys" (JD) | none given | none | [grounded] | discovery | Your material is silent. Answer slot: if you've worked with a digital or product team on any customer journey, say what you did; if not, say so plainly. |
| F9 | Contact-centre experience, from "across branches and the contact centre" (JD) | "Never worked in a contact centre" (your message) | none | [grounded] | capability | Words: "I haven't worked in a contact centre." Then how you'd learn it, as a plan. |

Your material shows the years, the branch log, the tellers' training and the spreadsheet. It does not show regulated complaints, presenting above regional level, contact-centre work, or digital-team work. Those are the four places the interviews will press.

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end across branches and the contact centre | Inflated form of F5 | "I handled the branch's formal complaints log." |
| Has regulated complaints experience | Inflated form of F2 | "I handled the branch's formal complaints log." Changes only if you answer the Step 1 question. |
| Has presented to senior leaders | Negative you stated (F3) | "I haven't presented to anyone above regional level." |
| Has worked in a contact centre | Negative you stated (F9) | "I haven't worked in a contact centre." |
| Tracked resolution times | Inflated form of F6 | The spreadsheet quote at its own scope. |
| Trained or coached branch supervisors | Inflated form of F7 | "I trained new tellers on our escalation script." |

## Persona weights

| Round | Dominant personas | Reasoning | Counter-strategy |
|---|---|---|---|
| 1. Recruiter, 30 min | Conversational, light Skeptic | Screens check logistics, motivation and knockout facts. The risk is treating it as unscored. | Pre-script a 90-second background arc. |
| 2. Head of Member Services, 45 min | Skeptic, Values/Behavioral, then Case | Your manager will test F3 and F9 first, then values in behavioural questions, then the digital and strategy angles. | Hold through two follow-ups on the gaps; use STAR stories and say which parts were yours. |
| 3. Branch-manager panel, 60 min | Values/Behavioral, Data-Driven Prober, Case, Peer | Two branch managers score the four values; the 20-minute case is the escalation scenario; the prober will test the spreadsheet. | Map a story to each value where your material carries one; name the assumption behind any figure first. |

## Question banks

### Bank A: Recruiter screen

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through your background." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | Ninety-second arc: six years in retail banking, the last three as a branch supervisor; then the complaints log and teller training, in those words. | F1 and F7 are the arc. |
| A2 | "Why Ashgrove, and why now?" | CO | [grounded] (strategy brief from the recruiter) | Name one strategy item, such as the 40% digital target or the hub consolidation, and what it means for complaints work. Claim nothing beyond the brief. | Motivation is scored. |
| A3 | "The role covers the contact centre. What's your experience there?" | JD | [grounded] "Never worked in a contact centre" | "I haven't worked in a contact centre." Then the nearest thing your material carries: the branch complaints log. | F9 is a stated gap the recruiter will check early. |
| A4 | "What did the monthly complaints spreadsheet cover?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Say what it counted. Answer slot: if it tracked resolution times, say how; if not, say so plainly. | F6 is the gap between volumes and resolution times. |

### Bank B: Head of Member Services

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time a member didn't like the answer to their complaint." | VAL | [grounded] "I handled the branch's formal complaints log" | Pick one case from the log: what the member wanted, the decision, how you explained it in plain words, the outcome you actually saw. Answer slot: if no case comes to mind, say so, then give the nearest one. | Members First. |
| B2 | **Highest-ROI prep.** "You haven't worked in a contact centre, and you haven't presented above regional level. What would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre"; [grounded] "I've never presented to anyone above regional level" | Hold: "I haven't worked in a contact centre, and I haven't presented above regional level." Name the weakest day-one area honestly, then a ramp plan as a plan. Hold through two follow-ups by returning to the branch log. Concede one specific gap rather than defending the whole profile. | F3 and F9 are what the manager is most likely to test. |
| B3 | "A branch supervisor is escalating too many complaints. What do you do in your first conversation?" | CASE | [generic] | Listen first, look at the escalations, agree one change, set a check-in. | JD: coaching supervisors on escalations. No past claim. |
| B4 | "Digital and branches both take complaints now. How would you make sure an app complaint isn't lost?" | CASE | [grounded] (strategy brief: 40% of member service to digital by 2028) | One case queue across channels, one owner per complaint, a shared record. Answer slot: if you've worked with a digital team, say what you did; if not, say so. | F8 has no quote; this is the JD's digital line plus the 40% target. |
| B5 | "Why would you take this role over an internal candidate with contact-centre time?" | Skeptic | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | Answer with the years and the log; say what you bring, and concede the contact-centre gap plainly. | Motivation probe. |
| B6 | "What would you change in the monthly report in your first 90 days?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | A plan, not a claim: what you would measure first. | F6, planned forward. |

### Bank C: Branch-manager panel

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you put a member ahead of a target." | VAL | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | Selection scaffold: a time a member's interest cost you something measurable. If none comes to mind, say so, then give the nearest one from the log. | Members First. Your material carries no story, so this is a scaffold. |
| C2 | "When did you have to explain something to a member more than once?" | VAL | [grounded] "trained new tellers on our escalation script" | Scaffold: a time the first explanation failed and what you changed in the words. If you changed no words, say so. | Plain Words. |
| C3 | "When did a local detail change a decision a central rule would have made?" | VAL | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | Scaffold: a case from your branch; the local detail and what you did. | Neighbours, Not Numbers. |
| C4 | "Tell me about a problem you found and stayed with until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log" | A complaint pattern from the log: what you found, what you kept owning, when it was solved. If it isn't solved, say so. | Own the Fix. |
| C5 | **Escalation case, 20 min:** "A member has complained three times about a charge. It's now been escalated to you. What do you do?" | CASE | [generic] | Clarify what the member needs and what the three complaints said. Then structure: first contact, the charge, the decision, the explanation, the record, the check-back. Name one risk: a second escalation. | The panel's case; scores structure, not the answer. |
| C6 | "What did you count in your monthly spreadsheet, and which assumption would you defend least?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Name the weakest assumption before they do. Answer slot: if you counted complaint volumes by branch, say so; if you didn't track times, say so plainly. | Prober; defend-the-number for F4 and F6. |
| C7 | "How would you measure resolution time across eight branches and a contact centre?" | JD | [generic] | Define the start and end of a complaint, the sources, the sample, the monthly cut. | JD: resolution times across branches and the contact centre. |
| C8 | "The branches go from eight to five hubs in 2027. What happens to open complaints in a branch that closes?" | CO | [grounded] (strategy brief: eight branches into five hubs over 2027) | A hand-over list, named owners, a check at each hub. Claim no past consolidation. | Peer seam and strategy altitude. |

## Requirement coverage

| JD requirement | Question IDs |
|---|---|
| 4+ years in financial-services customer operations | A1 |
| experience handling regulated complaints | none, and why: the gate question is asked in this message; a question follows its answer |
| confident presenting to senior leaders | none, and why: no presentation is scheduled in these rounds; B2 rehearses the gap |
| comfortable with Excel reporting | C6 |
| Own the complaints process end to end across branches and the contact centre | B2, C7 |
| report monthly on complaint volumes and resolution times | A4, B6, C7 |
| coach branch supervisors on escalations | B3, C5 |
| work with digital teams on self-service journeys | B4 |

## Values cheat sheet

None of your quoted sentences carries a full story for any value, so each is a selection scaffold.

| Value | Working meaning | Mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter. | Scaffold: a complaint where the member's view changed the decision. Nearest quote: "I handled the branch's formal complaints log". If none, say so. |
| Plain Words | If a member needs it explained twice, the wording was wrong. | Scaffold: a time you rewrote an explanation. Nearest quote: "trained new tellers on our escalation script". If you didn't change the wording, say so. |
| Neighbours, Not Numbers | Every branch is part of its town. | Scaffold: a local detail that changed a decision. Nearest quote: "6 years in retail banking, the last 3 as a branch supervisor". If none, say so. |
| Own the Fix | Whoever finds the problem keeps hold of it until solved. | Scaffold: a problem you found and stayed with. Nearest quote: "I handled the branch's formal complaints log". Say when it was solved, or that it isn't yet. |

## Grounding brief

From the 2026 strategy brief the recruiter sent in July 2026. I haven't checked for news since.

- **Digital shift:** 40% of member service to digital channels by 2028.
- **Branch consolidation:** eight branches into five hubs over 2027.
- **New product:** small-business lending in Q1 2027.
- **Competitive pressure:** app-only banks.

## Reverse questions

| Question | Why it lands |
|---|---|
| "What does a successful first six months look like in this role?" | Frames your ownership around Own the Fix. |
| "How will complaints handling change as eight branches become five hubs?" | Shows you read the brief and think about the effect on complaints. |
| "Which branch managers do you rely on most for escalations?" | Links to Neighbours, Not Numbers; shows you know escalations depend on people. |
| "As the digital share rises toward 40%, will the monthly report change?" | Tests the strategy and shows you think about measurement. |
| "How will complaints about the small-business lending product be handled from Q1 2027?" | Names the new product and the regulated-complaints risk. |
| To the recruiter: "What does the panel's scoring look like for each of the four values?" | Lets you prepare for the scored round. |

## Sources

- **Provided by you:** the JD; the recruiter's email on the rounds; the four values, copied 11 November 2026; the July 2026 strategy brief as summarised in your message; your background.
- **Searches:** one web search for recent Ashgrove news was attempted and refused because permission wasn't granted.

**Research tier:** L1, searches 0 of 6 (1 refused), fetches 0 of 2.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | The pasted values fix the values cheat sheet. |
| 2. Ashgrove interview process | skipped | The recruiter's email fixes the rounds and the panel's values scoring. |
| 3. Ashgrove strategy and recent news | unavailable | The brief covers strategy; news since July 2026 would have been checked, but the search was refused. |
| 4. Interviewer footprint | n/a | No interviewer names are assigned yet. |
| 5. Representative JD | skipped | Your JD fixes the fit snapshot and the JD questions. |

## Upgrade menu

- Your answer to the regulated-complaints question → F2 becomes a grounded row, and A1, B1 and C4 can use it.
- The panel and Head of Member Services names → persona weights from their public footprint and a tailored reverse question.
- Your CV → more quoted sentences for F5, F9 and the escalation case.
- Permission for a web search of recent Ashgrove news → target 3 can be checked against news since July 2026.
- Deep research, offered once: up to six more searches and two fetches on the strategy brief and interviewer material. It takes a few minutes and needs your go-ahead.

---

One question, the only one the material leaves open: **were the formal complaints you handled under a regulator's or ombudsman's rules, with set response times or reports filed outside the branch?** If yes, say which; if not, say so. The answer changes F2 and the regulated-complaints answers.

Two offers, neither pushed:
- **Drill:** I can play the Skeptic on B2, the question the pack names as highest-ROI prep, and give feedback against its guidance.
- **Dossier:** I can save a `tuesday-dossier.md` recording the gaps this prep exposed, for carrying into later sessions.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove_member-experience-lead_interview_pack.md -----
# Interview prep pack: Member Experience Lead, Ashgrove Credit Union

**Interviews:** 20 November 2026. Round 1: recruiter, 30 min. Round 2: Head of Member Services (your future manager), 45 min, mostly behavioural. Round 3: panel of two branch managers, 60 min, including a 20-minute escalation case. The panel also scores the four values. Interviewer names not yet assigned for rounds 2 and 3.

## How to use this pack

- **Personas** describe how a question is asked. **Types** describe what is being scored: VAL (values), EXP (your experience), JD (the listed job), CO (company and strategy), CASE (live problem).
- Guidance is scaffolding, not a script. Say it in your own words.
- Quoted sentences come from your message or the JD or values text. Nothing in quotation marks was written by me.

## Fit snapshot

Requirements are quoted from the JD. Evidence is quoted from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" (JD) | "6 years in retail banking, the last 3 as a branch supervisor" (your message) | high | [grounded] | presentation | The years are there. Say them: "I've spent six years in retail banking, the last three as a branch supervisor." |
| F2 | "experience handling regulated complaints" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | hard_gate | Your material does not establish regulated complaints handling. It shows a formal complaints log. No bridge is written for a gate. Step 1 asks one question about it. |
| F3 | "confident presenting to senior leaders" (JD) | "I've never presented to anyone above regional level" (your message) | none | [grounded] | capability | Words: "I haven't presented to anyone above regional level." Then how you would learn it, said as a plan, never as a past. |
| F4 | "comfortable with Excel reporting" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | medium | [grounded] | none | The quote reaches the requirement. Expect a probe on how the spreadsheet is built. Say what it counts, in your own words. |
| F5 | "Own the member complaints process end to end across branches and the contact centre" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | transferability | Your material shows one branch's log, not a process run end to end across branches. Words at its own scope: "I handled the branch's formal complaints log." |
| F6 | "report monthly on complaint volumes and resolution times" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | medium | [grounded] | transferability | Monthly reporting reaches the requirement. Resolution times do not appear in the quote. Words: "I built the monthly complaints spreadsheet our regional manager uses." |
| F7 | "coach branch supervisors on escalations" (JD) | "trained new tellers on our escalation script" (your message) | medium | [grounded] | presentation | The quote reaches escalation coaching in other terms, with tellers rather than supervisors. Words: "I trained new tellers on our escalation script." Do not say you coached supervisors. |
| F8 | "work with digital teams on self-service journeys" (JD) | none given | none | [grounded] | discovery | Your material is silent here. Answer slot: if you have worked with a digital or product team on any customer journey, say what you did. If you have not, say so plainly. |
| F9 | Contact-centre experience, from "across branches and the contact centre" (JD) | "Never worked in a contact centre" (your message) | none | [grounded] | capability | Words: "I haven't worked in a contact centre." Then how you would learn the contact centre, as a plan. |

Your material shows the years, the branch log, the tellers' training and the spreadsheet. It does not show regulated complaints, presenting above regional level, a contact centre, or digital-team work. Those are the four places the interviews will press.

## Prohibited claims

These are not to be coached, in any answer.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end across branches and the contact centre | Inflated form of F5 | "I handled the branch's formal complaints log." The limit is my observation: your material shows one branch's log. |
| Has regulated complaints experience | Inflated form of F2 | "I handled the branch's formal complaints log." Your material does not establish regulation. This changes if you answer the Step 1 question. |
| Has presented to senior leaders | Negative you stated (F3) | "I haven't presented to anyone above regional level." |
| Has worked in a contact centre | Negative you stated (F9) | "I haven't worked in a contact centre." |
| Tracked resolution times | Inflated form of F6 | The spreadsheet quote at its own scope. |
| Trained or coached branch supervisors | Inflated form of F7 | "I trained new tellers on our escalation script." |

## Persona weights

| Round | Dominant personas | Weights and reasoning | Counter-strategy |
|---|---|---|---|
| 1. Recruiter, 30 min | Conversational, with light Skeptic | Recruiter screens check logistics, motivation and knockout facts in a friendly register. The risk is treating it as unscored. | Pre-script a 90-second background arc. Treat casual questions about the JD as scored. |
| 2. Head of Member Services, 45 min | Skeptic, Values/Behavioral, then Case | Your future manager will test the gaps F3 and F9 first, then the values in behavioural questions, then the digital and strategy angles. | Hold through two follow-ups on the gaps. Use STAR-shaped stories and say which parts were yours. |
| 3. Branch-manager panel, 60 min | Values/Behavioral, Data-Driven Prober, Case, Peer | Two branch managers score the four values. The 20-minute case is the escalation scenario. The prober will test the spreadsheet. | Map a story to each value where your material carries one. Say the assumption behind any figure before they do. |

## Question banks

Provenance comes before guidance. Every candidate sentence the guidance relies on is quoted in the Provenance column.

### Bank A: Recruiter screen (Conversational, light Skeptic)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through your background." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | Ninety-second arc: six years in retail banking, the last three as a branch supervisor. Then the complaints log and the teller training, in those words. | F1 and F7 are the arc. Keep it to what they state. |
| A2 | "Why Ashgrove, and why now?" | CO | [grounded] (strategy brief from the recruiter) | Name one strategy item from the brief, such as the 40% digital target or the hub consolidation, and say what it means for the complaints work. Do not claim knowledge beyond the brief. | Motivation is scored. The brief is the only source of company detail in this pack. |
| A3 | "The role covers the contact centre. What's your experience there?" | JD | [grounded] "Never worked in a contact centre" | Plain acknowledgment: "I haven't worked in a contact centre." Then the nearest thing your material carries: the branch complaints log, which handles the same complaint types. | F9 is a stated gap and the recruiter will check it early. |
| A4 | "What did the monthly complaints spreadsheet cover?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Say what it counted, in your words. Answer slot: if it tracked resolution times, say how; if not, say so plainly. Do not extend the sheet beyond what you built. | F6 is the gap between monthly volumes and resolution times. |

### Bank B: Head of Member Services (Skeptic, Values/Behavioral, Case)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time a member didn't like the answer to their complaint." | VAL | [grounded] "I handled the branch's formal complaints log" | Pick one case from the log. Say what the member wanted, the decision you made, how you explained it in plain words, and the outcome you actually saw. Answer slot: if no such case comes to mind, say so, then give the nearest one. | Members First. Open prompt with the theme from the Values/Behavioral stem. |
| B2 | **Highest-ROI prep.** "You haven't worked in a contact centre, and you haven't presented above regional level. What would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre"; [grounded] "I've never presented to anyone above regional level" | Hold: "I haven't worked in a contact centre, and I haven't presented above regional level." Name the weakest day-one area honestly, then a ramp plan as a plan. Hold through two follow-ups by returning to the branch log. Concede one specific gap rather than defending the whole profile. Never claim contact-centre or senior-presentation experience. | F3 and F9 are the gaps the manager is most likely to test. This is where a non-defensive answer matters most. |
| B3 | "A branch supervisor is escalating too many complaints. What do you do in your first conversation?" | CASE | [generic] | Structure it: listen first, look at the escalations, agree one change, set a check-in. The question needs no claim about your past. | JD: coaching supervisors on escalations. Live problem, no past claim. |
| B4 | "Digital and branches both take complaints now. How would you make sure an app complaint is not lost?" | CASE | [grounded] (strategy brief: 40% of member service to digital by 2028) | Structure: one case queue across channels, one owner per complaint, a shared record. Do not claim digital-team work. Answer slot: if you have worked with a digital team, say what you did. If not, say so. | F8 has no quote. The question is the JD's digital line plus the strategy's 40% target. |
| B5 | "Why would you take this role over an internal candidate with contact-centre time?" | Skeptic | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | Answer with the quoted years and the log. Say what you bring that they do not, in your words, and concede the contact-centre gap plainly. | Motivation and comparison probe. |
| B6 | "What would you change in the monthly report in your first 90 days?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | A plan, not a claim. Say what you would measure first. | F6, planned forward. |

### Bank C: Branch-manager panel (Values, Prober, Case, Peer)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you put a member ahead of a target." | VAL | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | Selection scaffold: pick a time a member's interest cost you something measurable. If no such time comes to mind, say so, then give the nearest one from the log. | Members First. Your material does not carry a story, so this is a scaffold. |
| C2 | "When did you have to explain something to a member more than once?" | VAL | [grounded] "trained new tellers on our escalation script" | Selection scaffold: pick a time the first explanation failed. Say what you changed in the words. If you did not change any words, say so. | Plain Words. Tests whether you can show a plain explanation that worked. |
| C3 | "When did a local detail change a decision that a central rule would have made?" | VAL | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | Selection scaffold: pick a case from your branch. Say what the local detail was and what you did. | Neighbours, Not Numbers. Open prompt. |
| C4 | "Tell me about a problem you found and stayed with until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log" | Pick a complaint pattern from the log. Say what you found, what you kept owning, and when it was actually solved. If it is not solved, say so. | Own the Fix. |
| C5 | **Escalation case (20 minutes):** "A member has complained three times about a charge. The complaint has now been escalated to you. What do you do?" | CASE | [generic] | Clarify: what the member needs, what the three complaints said, what the regulatory timeline is. Then structure: first contact, the charge, the decision, the explanation, the record, the check-back. Name one risk: a second escalation. | The panel's case. Scores structure, not the right answer. |
| C6 | "What did you count in your monthly spreadsheet, and which assumption would you defend least?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Name the weakest assumption in your own words before they do. Answer slot: if you counted complaint volumes by branch, say so. If you did not track times, say so plainly. | Data-Driven Prober. Defend-the-number slot for F4 and F6. |
| C7 | "How would you measure resolution time for complaints across eight branches and a contact centre?" | JD | [generic] | Structure: define the start and end of a complaint, the sources, the sample, the monthly cut. No claim about your past. | JD: resolution times across branches and the contact centre. |
| C8 | "The branches go from eight to five hubs in 2027. What happens to open complaints in a branch that closes?" | CO | [grounded] (strategy brief: eight branches into five hubs over 2027) | Structure: a hand-over list, named owners, a check at each hub. No claim about past consolidation. | Peer seam and strategy. Tests whether you think at the company's altitude. |

## Requirement coverage

| JD requirement | Question IDs |
|---|---|
| 4+ years in financial-services customer operations | A1 |
| experience handling regulated complaints | none, and why: the gate question is asked in this message; a question follows its answer |
| confident presenting to senior leaders | none, and why: no presentation is scheduled in these three rounds; B2 rehearses the gap |
| comfortable with Excel reporting | C6 |
| Own the complaints process end to end across branches and the contact centre | B2, C7 |
| report monthly on complaint volumes and resolution times | A4, B6, C7 |
| coach branch supervisors on escalations | B3, C5 |
| work with digital teams on self-service journeys | B4 |

## Values cheat sheet

Each value has a selection scaffold, because none of your quoted sentences carries a full story for it.

| Value | Working meaning | Mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter. | Scaffold: pick a complaint where the member's view changed the decision. Nearest quote: "I handled the branch's formal complaints log" (F5). If none comes to mind, say so, then give the nearest one. |
| Plain Words | If a member needs it explained twice, the wording was wrong. | Scaffold: pick a time you rewrote an explanation. Nearest quote: "trained new tellers on our escalation script" (F7). If you did not change the wording, say so. |
| Neighbours, Not Numbers | Every branch is part of its town. | Scaffold: pick a local detail that changed a decision. Nearest quote: "6 years in retail banking, the last 3 as a branch supervisor" (F1). If none, say so. |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved. | Scaffold: pick a problem you found and stayed with. Nearest quote: "I handled the branch's formal complaints log" (F5). Say when it was solved, or that it is not yet. |

## Grounding brief

From the 2026 strategy brief the recruiter sent in July 2026. I have not checked for news since then.

- **Digital shift:** move 40% of member service to digital channels by 2028.
- **Branch consolidation:** eight branches into five hubs over 2027.
- **New product:** small-business lending in Q1 2027.
- **Competitive pressure:** app-only banks.

Use these in your answers. Do not present them as knowledge beyond the brief.

## Reverse questions

| Question | Why it lands |
|---|---|
| "What does a successful first six months look like in this role?" | Frames your ownership around the Own the Fix value. |
| "How will complaints handling change as the eight branches become five hubs?" | Shows you read the brief and think about the consolidation's effect on complaints. |
| "Which branch managers do you rely on most for the escalation process?" | Links to Neighbours, Not Numbers and shows you know escalations depend on people. |
| "As the digital share rises toward 40%, will the monthly report change?" | Tests the strategy and shows you think about measurement. |
| "How will complaints about the small-business lending product be handled from Q1 2027?" | Names the new product and the regulated-complaints risk. |
| To the recruiter: "What does the panel's scoring look like for each of the four values?" | Lets you prepare for the scored round. |

## Sources

- **Provided by you:** the Member Experience Lead JD; the recruiter's email on the three rounds; the four published values, copied 11 November 2026; the July 2026 strategy brief as summarised in your message; your background.
- **Searches:** one web search was attempted for recent Ashgrove news. It was refused because permission was not granted.

**Research tier:** L1, searches 0 of 6 (1 refused), fetches 0 of 2.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | The pasted values fix the values cheat sheet. |
| 2. Ashgrove interview process | skipped | The recruiter's email fixes the three rounds and the panel's values scoring. |
| 3. Ashgrove strategy and recent news | unavailable | The brief covers strategy. News since July 2026 would have been checked; the search was refused. |
| 4. Interviewer footprint | n/a | No interviewer names are assigned yet. |
| 5. Representative JD | skipped | Your JD fixes the fit snapshot and the JD questions. |

## Upgrade menu

- Your answer to the regulated-complaints question → F2 becomes a grounded row and A1, B1 and C4 can use it.
- The interviewers' names for rounds 2 and 3 → persona weights from their public footprint and a tailored reverse question.
- Your CV → more quoted sentences for F5, F9 and the escalation case.
- Permission for a web search of recent Ashgrove news → target 3 can be checked against news since July 2026.
- Deep research, offered once: up to six more searches and two fetches for the strategy brief and interviewer material. It takes a few minutes and needs your go-ahead.
