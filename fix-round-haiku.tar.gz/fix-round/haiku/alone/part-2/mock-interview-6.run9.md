Your three-round pack is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-alone-part-2-rooms-case-6-denied-796e153d/8cd6578b-bfd5-4d01-9577-3e586391542d/scratchpad/larkfield_engineering-manager_interview_pack.md`.

It covers all three rounds with a shared fit snapshot, a per-round persona table and question bank (8 to 10 questions each), and reverse questions. The fit snapshot quotes your own sentences, so the answers only claim what you've told me. The highest-ROI prep is the Director's "You haven't managed managers. Why would we hire you to lead leads?" (A4). Practise holding "I've never managed managers" through two follow-ups, then moving to your plan.

Things you should know:

- **Research didn't run.** The two web searches were refused because search permission wasn't granted in this session. So the pack has no company values, no strategy brief and no representative JD. The VP round's values questions are scaffolds rather than mapped to Larkfield's published values. Pasting their values page would fix that.
- **No job description was supplied**, so the requirements are your summary of the role. The Round 1 and 2 questions are built on that summary.
- **No gates identified.** If the role has location, on-site or authorization requirements, tell me and I'll add them.

Offers:
- Want me to play the Skeptic on A4 as a drill? Or any persona and question you pick.
- I can save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions.
- I can convert the pack to Word if you'd like it that way.

Could you paste the Larkfield job description? It would move the role requirements from your summary to the posted wording, and let me tighten the JD-tagged questions.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: larkfield_engineering-manager_interview_pack.md -----
# Larkfield Systems — Engineering Manager — Three-round prep pack

**Role:** Engineering Manager, device-management services (two squads, 11 engineers)
**Company:** Larkfield Systems (industrial IoT, ~600 people)
**Rounds:** (1) Tuesday, 45 min, Director of Engineering, hiring manager. (2) Thursday, 60 min, panel: two staff engineers and a product manager. (3) Following Monday, 30 min, VP Engineering, "values and leadership philosophy."
**Loop mode.** One shared fit snapshot, then a mini-pack per round.
**Changelog:** First version. No regeneration yet.

---

## How to use this pack

- **Personas** describe how a question arrives (style). **Types** describe what is being scored.
- Type key: **EXP** work-experience deep-dive; **JD** role-driven; **CASE** live problem from the role; **VAL** values and leadership; **CO** company knowledge (none included, research did not run).
- Guidance is scaffolding, not a script. Each guidance cell is speakable in 90 to 120 seconds.
- Every claim about your past rests on a sentence you wrote, quoted in the Provenance cell. If a question needs a fact that is not in your sentences, the guidance is an answer slot: you give the true answer, including "no."

## Fit snapshot (shared across rounds)

Requirements come from the role description you pasted. No job description was supplied, so the requirements are your summary, not the employer's posting. Evidence is quoted from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" — role description you pasted | "3 as a team lead of 6" — your message | medium | [grounded] | transferability | Your material says three years as a team lead of six. It does not show two squads or device-management services, so do not claim either. Answer slot: if you ever ran more than one group at once, say how; if not, say so and say how you would pace the move to two squads. |
| F2 | "own delivery, hiring and growth for 11 engineers" — role description you pasted | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | medium | [grounded] | transferability | Your material shows delivery work at team scale, with a result on on-call load. It does not show delivery across 11 engineers. Answer slot: if you ran delivery planning beyond your own team, say what you ran; if not, say so and say what you would put in place first. |
| F3 | "own delivery, hiring and growth for 11 engineers" — role description you pasted | "I run our hiring loop for backend roles — about 40 interviews last year." — your message | medium | [grounded] | none | Hiring is well covered: the quote already reaches the requirement in role terms. Lead with the loop and the count, in your words. Expect a probe on how much of the loop was yours to set. |
| F4 | "own delivery, hiring and growth for 11 engineers" — role description you pasted | none given | none | [grounded] | discovery | Your material does not show growth outcomes for engineers. Answer slot: if you have grown engineers into larger scope or a promotion, say which and how you know it held; if not, say so and say how you would start. |
| F5 | "partner with hardware and product on roadmap" — role description you pasted | "I've never managed managers and never owned a hardware-adjacent roadmap." — your message | none | [grounded] | capability | Your own words: "I've never owned a hardware-adjacent roadmap." Then how you would learn hardware constraints, said as a plan, never as a past. |
| F6 | Leading the leads of two squads — [inferred] from F1's requirement | "I've never managed managers and never owned a hardware-adjacent roadmap." — your message | none | [inferred] | capability | Your own words: "I've never managed managers." Then how you would prepare to lead through leads, as a plan. Nothing added to make the gap feel smaller. |
| F7 | "partner with hardware and product on roadmap" — role description you pasted | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | medium | [grounded] | transferability | You have negotiated roadmap against pressure from one side of the table. That is not yet a shared roadmap with hardware and product. Answer slot: how you decided what went into the quarter and what product agreed to; if product did not agree, say so. |

**Gates.** The material identifies no gate rows (no authorization, location, schedule or credential requirement). If the role carries any, the snapshot needs them; see the upgrade menu.

**Reading of the snapshot.** Your strongest material is F3 and the reliability result. The three weakest areas are F5 and F6 (hardware roadmap; leading leads) and F4 (growth). Those are where the Director's round will press, and they are the basis for the highest-ROI prep below.

## Prohibited list

Claims this pack will not coach, each with its basis and its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Has managed managers | Your own negative | "I've never managed managers." No slot; plain acknowledgment. |
| Has owned a hardware-adjacent roadmap | Your own negative | "I've never owned a hardware-adjacent roadmap." No slot beyond how you would learn it. |
| Led two squads or an 11-person organization | Inflated form of F1 | The quote at its own scope: "3 as a team lead of 6." The pack's observation: your material shows one team of six. The slot stays inside what you led. |
| Owned hiring strategy or growth for an organization | Inflated form of F3 | The quote at its own scope: "I run our hiring loop for backend roles." The pack's observation: the material shows a backend loop, not an organization-wide plan. |
| The 60% drop was yours alone | Inflated form of F2 and F7 | "My team's on-call burden dropped 60% after I pushed a reliability quarter through." The pack's observation: the material says the drop followed the quarter, not that the quarter alone caused it. Slot: what else changed, in your words, or say you do not know. |

## Round 1 — Director of Engineering (hiring manager), Tuesday, 45 min

### Personas and weights

| Persona | Weight | How it shows up | Why (reasoning) | Counter-strategy |
|---|---|---|---|---|
| Skeptic | 5 (top) | Quiet, persistent probing of F5, F6, F4 | A future boss is buying capability and derisking the two gaps you named yourself | Rehearse the managing-managers objection until it is boring; hold for two follow-ups, then concede the specific gap and give a plan |
| Case / Strategist | 3 | Live problems from two squads and a hardware dependency | Hiring managers test structure on their own roadmap | Clarify, then structure, then name metrics |
| Data-Driven Prober | 2 | Asks how the 60% was counted | F2 and F7 carry the only headline number | Name the weakest assumption before they do |
| Conversational | 2 | Opening biography and motivation | Casual openers are scored | Pre-script a 90-second arc |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how you got to engineering management." | EXP | [grounded] "9 years engineering, 3 as a team lead of 6" — your message | A 90-second arc: the years in engineering, the three as team lead, the team of six, the payments company. Tell it in your words. Do not add a title or scope the quote does not carry. | Conversational opener; the arc is built only from F1's quote. |
| A2 | "Why Larkfield, and why now?" | JD | [generic] | Answer with the device-management work itself, not the company's reputation. Name one thing about the role you want to own and why. Keep it to what you can speak to from the role description. | Motivation is a Skeptic question in disguise; the answer must be yours, not a research claim. |
| A3 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." — your message | Name the weakest part as you already stated it: hardware roadmap, then leading leads. Then your plan for the first 90 days. Do not add a third weakness to look candid. | Asks the question the Skeptic will open with; the answer is the quoted negatives plus a plan. |
| A4 | "You haven't managed managers. Why would we hire you to lead leads?" | JD | [grounded] "I've never managed managers" — your message | Hold: "I've never managed managers." Then what you have done that is closest, from your quotes, and how you would prepare: a plan. Hold through two follow-ups by returning to the plan. Concede the specific gap if pressed: "I haven't done this yet." | Highest-ROI prep in this round. The objection is certain; the non-defensive answer is the one you can rehearse. Its premise is your own sentence, not an invention. |
| A5 | "Hardware constraints are not software constraints. What have you seen of them?" | CASE | [generic] | Answer slot: if you have worked near device or firmware constraints, say what and how; if not, say so and name what you would learn first. Do not claim hardware experience. | A live problem from the role, asked about past exposure; the honest branch is "none." |
| A6 | "Walk me through how the on-call number was counted." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | Name the window and the baseline in your words. Name the assumption you would defend least (for example, whether the quarter was the only change). If you do not know how it was counted, say so. Four slots: how counted, what it is sensitive to, the weakest assumption, which part was yours. | Defend-the-number question. The pack does not supply a method or baseline. |
| A7 | "Two squads: one is late on a device-provisioning release, the other is on track. What do you do in the first 30 days?" | CASE | [generic] | Clarify what late means and what the date is for. Separate the squads' objectives. Decide what you would look at before you talk to anyone. State one trade-off you would make. | Live problem from the role; no claim about your past. |
| A8 | "Hardware is a month late and product wants the date. What do you say?" | CASE | [generic] | Name who owns the dependency. Separate what you know from what you are guessing. Propose one option with a cost. Say what you would not promise. | Tests the partner-with-hardware-and-product requirement directly. |
| A9 | "That reliability quarter: how much of the result was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | Hold: you pushed the quarter through, and the result followed it. Concede what you do not know about other causes. Answer slot: what else changed, in your words, or say you do not know. | Pressure version of A6; the honest answer is the one the quote carries. |
| A10 | "You say you run the backend hiring loop. How many of the 40 interviews did you set up, and how many did you only take?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." — your message | Give the share in your own words. If you set the loop structure, say so; if you only ran interviews, say so. The number is yours to state. | Hiring is your strongest material; the probe is about who decided what. |

**Requirement coverage (Round 1).** F1 covered by A1, A3, A4. F5 by A3, A5. F6 by A4. F2 by A6, A9. F3 by A10. F4 by none in this round, and why: growth is covered in Round 3 (C2) and in the panel's reverse question R5; the Director's round has time for four probes only. F7 by A8.

### Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What would make you say the first 90 days went well for the person in this seat?" | Shows you plan for the role, not just the interview. |
| R2 | "Which of the two squads carries more delivery risk into next quarter, and why?" | Tests whether you already see the seam between squads. |
| R3 | "How have hardware and software commitments been shared on past roadmaps?" | Lands on your weakest area without making you say it first. |
| R4 | "What have you already tried in hiring for this role, and what did not work?" | Shows you are thinking about the hiring loop as the Director's problem too. |

No interviewer profile exists, so none of these ties to the Director's own career path.

## Round 2 — Panel (two staff engineers, one product manager), Thursday, 60 min

### Personas and weights

| Persona | Weight | How it shows up | Why (reasoning) | Counter-strategy |
|---|---|---|---|---|
| Data-Driven Prober | 4 (top) | Staff engineers ask for inputs, denominators and validation | The staff engineers will test technical depth and the reliability result | Know what you can and cannot say about each figure |
| Peer Evaluator | 3 | PM probes the seam between product and engineering | The PM prices what this hire adds to their work | Reciprocity framing; propose seam principles, not invented detail |
| Case / Strategist | 3 | Architecture and sequencing problems | Panels test structure on shared work | Clarify, then structure |
| Pressure | 2 | A staff engineer challenges an architectural position | Composure under a technical challenge | Pause, restate, hold two follow-ups |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "How did you decide what the reliability quarter would fix?" | EXP | [grounded] "I pushed a reliability quarter through against roadmap pressure" — your message | Name how the scope was chosen, in your words. Answer slot: if the choice was not yours, say whose it was and what your part was. | Premised on your own quote; the staff engineers will ask about scope before results. |
| B2 | "Which assumption behind the 60% would you defend least?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | Name the assumption before they do. If you do not know how the figure was counted, say so. | Metric question; the panel's prober will go two levels deeper than your first answer. |
| B3 | "Our device-management architecture is wrong. Why shouldn't we rewrite it?" | CASE | [generic] | Hold your position on the part you can defend, concede the part you cannot, and say what evidence would change your mind. Do not claim you have seen this architecture. | Pressure from a staff engineer; tests composure, not content. |
| B4 | "You'll partner with product on the roadmap. Where does your authority stop and mine start?" | JD | [generic] | Propose a principle for the seam (for example, who decides scope and who decides sequencing), not a rule you invented. Name where you would escalate. | Peer Evaluator probe on the partner-with-product line. |
| B5 | "Tell me about a time the roadmap and reliability work collided." | EXP | [grounded] "I pushed a reliability quarter through against roadmap pressure." — your message | Open prompt built from your quote: the pressure, the quarter, the result. Answer slot: how product got to yes; if they did not, say so. | The panel will ask for the story behind the quote. |
| B6 | "A firmware update fails on three percent of devices. How do you triage it with the hardware team?" | CASE | [generic] | Clarify scope and rollback. Name who owns each step. Propose the first action and what you would not do. | Live problem from the device-management domain; no claim about past experience. |
| B7 | "Two squads, one roadmap, one hardware dependency. How do you sequence the quarter?" | CASE | [generic] | State the objective first, then the dependency, then what is reversible. Say what you would communicate and to whom. | Tests the two-squads scale without claiming two squads. |
| B8 | "Where have you disagreed with a senior engineer, and how did it end?" | EXP | [generic] | Selection scaffold: pick a disagreement that had a named stake and an intact relationship at the end. If none comes to mind, say so, then give the nearest one your material carries. | Persona stem for disagreement; your material does not carry a specific instance, so the honest branch applies. |

**Requirement coverage (Round 2).** F1 by B5. F2 by B1, B2. F7 by B4, B5. F5 by B4, B6. F3 by none in this round, and why: hiring was tested in Round 1 (A10). F4 by none in this round, and why: growth is not a panel topic in the role description.

### Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R5 | "What could a new manager do in the first month that would genuinely help your team?" | Reciprocity question for the PM; asks what the hire adds, not what it needs. |
| R6 | "Where does the device-management codebase hurt most today?" | Shows you want the technical picture from the people who live in it. |

## Round 3 — VP Engineering (values and leadership philosophy), Monday, 30 min

### Personas and weights

| Persona | Weight | How it shows up | Why (reasoning) | Counter-strategy |
|---|---|---|---|---|
| Values / Behavioral | 5 (top) | Scenario probes; expects STAR-shaped stories | The recruiter named this as a values and leadership round | Map a story where one of your quotes carries one; otherwise a selection scaffold with its honest branch |
| Pressure | 3 | Time-boxed challenge on the managing-managers gap | An executive tests composure in a short round | Pause, restate, hold two follow-ups |
| Case / Strategist | 2 | Trade-offs between reliability and roadmap | Altitude test | Name the trade-off before the answer |

**Values cheat sheet: not included.** The company's published values were not in hand. Research did not run (see Sources), so the pack has no values to map. The VAL questions below are scaffolds, not mapped stories. Paste the values page (upgrade menu) and this section is written.

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "What does reliability mean to you as a leadership value, not as a metric?" | VAL | [generic] | Answer with one decision the reliability quarter forced, in your words. Do not claim a principle the decision does not show. Answer slot: if no decision of yours shows the value, say so and name the decision you would make. | Values question with no published value to anchor it; the honest form is a decision, not a slogan. |
| C2 | "Tell me about a time you had to deliver an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a moment with a named stake, a point where you did not fold, and a relationship intact at the end. If none comes to mind, say so, then give the nearest thing your material carries (the roadmap pressure from F7), or how you would handle it. | Values behavioral probe; your material does not show the truth landing, so the scaffold ends in the honest branch. |
| C3 | "How do you decide between shipping a feature and fixing reliability?" | VAL | [generic] | State the criteria you would use, then one example from your quotes. Name the trade-off you accept. | Leadership philosophy question; no claim about the company's values. |
| C4 | "You have thirty seconds: why would we make you a manager of managers when you've never managed managers?" | JD | [grounded] "I've never managed managers" — your message | Hold: "I've never managed managers." Then the plan and the support you would ask for. Concede the gap plainly. Do not add a past you do not have. | Pressure version of the Round 1 objection; the VP will test whether you hold it without folding. |
| C5 | "Reliability work costs roadmap time. How do you tell leadership that trade-off?" | CASE | [generic] | Name the cost in dates and the risk in plain words. Propose the option that keeps the roadmap honest. | Strategy-altitude probe on the trade-off you already made. |
| C6 | "What is one strategic bet you would question in device management?" | CASE | [generic] | Ask one question about the bet before you challenge it. State what evidence would change your view. Do not assert facts about the company's strategy: you have not researched it. | Altitude test; the honest form is a question, since the strategy is not in your material. |
| C7 | "What is your leadership philosophy in one sentence?" | VAL | [generic] | Build the sentence from one decision in your material, not from a slogan. Say it aloud once before the interview. | Conversational opener to the values round; the sentence must be yours. |
| C8 | "Tell me about a time you put a customer ahead of an internal metric." | VAL | [generic] | Selection scaffold: pick a moment where a metric and a customer pulled apart. If none comes to mind, say so, then give the nearest thing your material carries or how you would decide. | Values probe; no quote carries a customer example. |

**Requirement coverage (Round 3).** Managing managers (F6) by C4. Growth (F4) by C2, C7, and by Round 1's R-questions. Reliability and roadmap (F2, F7) by C1, C3, C5. Hardware roadmap (F5) by C6.

### Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R7 | "What separates the managers here who grow their engineers from those who only hit the roadmap?" | Lands on growth, the requirement with no quote in your material. |
| R8 | "What did the last leader of these squads get right that you would keep?" | Shows you are asking about continuity, not replacement. |

## Sources

**Provided documents:** your message (role description, candidate background). No CV, no job description, no interviewer profile, no recruiter guidance beyond the round descriptions, no assessment, no dossier.

**Searches sent:**
- "Larkfield Systems values industrial IoT" — refused (WebSearch permission not granted in this session).
- "Larkfield Systems engineering manager interview process" — refused (same cause).

**Research tier:** L1 requested, not run. Searches 0 of 6, fetches 0 of 2.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Larkfield Systems values` | unavailable | Values cheat sheet, section 10. Call refused, so the values round uses scaffolds. |
| 2. `Larkfield Systems interview process engineering manager` | unavailable | Loop structure; persona weights follow the three rounds you named, not a published loop. |
| 3. `Larkfield Systems strategy` / recent news | unavailable | CO questions in Round 3 (C6 is a question, not a fact). No search was sent; the host refused search. |
| 4. Interviewer name | n/a | No names given, so no query could form. The interviewer read is absent. |
| 5. Representative JD for an EM at an industrial IoT company | unavailable | Would have supplied a raising source and [inferred] requirement lines. No search was sent; the host refused search. |

## Upgrade menu

- **Job description text** → F1 to F5 move from your summary to [grounded] JD lines, and the JD-tagged questions are tightened to the posted wording.
- **Any gates (location, on-site days, authorization, schedule)** → a gate row would surface prominently in the fit snapshot. None is identified yet.
- **Interviewer names (Director, the two staff engineers, the PM, the VP)** → persona weights per member, and one reverse question tied to each person's career path.
- **Company's published values (or the VP's values page)** → the values cheat sheet appears in Round 3, and C1, C2, C3, C8 gain mapped stories where your material carries one.
- **Recruiter's process note for the VP round** → confirms whether the VP round is values-only or includes a leadership case.
- **Growth evidence (a promotion, a career conversation, an engineer you grew)** → F4 moves from an answer slot to a story.
- **The on-call baseline and window (time before and after, what else changed)** → A6 and B2 get the numbers you can defend. No numbers are supplied by this pack.
- **Company strategy and recent news (research)** → CO questions for Round 3. Research did not run this session; see Sources.
