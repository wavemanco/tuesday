Your prep pack is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-alone-part-2-rooms-case-4-denied-2e5f4c13/1ac913b9-85cd-445d-a514-9e22017f2ccd/scratchpad/quartzline_product-manager-platform-apis_interview_pack.md`. It's built for your 45-minute hiring-manager conversation and uses your dossier. Company research didn't run because the search permission was refused, so the pack has no Quartzline values, interview-process or strategy content.

One thing to settle before Thursday: your dossier doesn't flag the "shipped API or platform products" requirement as weak, but the pack does. The integration work you've confirmed shows you integrating the vendor's APIs, not whether you stood on the side that built and shipped one. If you did, say so in the interview; the pack's answer slot A3 covers both cases.

If you'd like, I can open the live drill now as the Skeptic on A1, the "why hire you into a PM role" question. I can also save a `tuesday-dossier.md` with `pack_feedback` from what the prep exposes, and convert the pack to Word if you want it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quartzline_product-manager-platform-apis_interview_pack.md -----
# Interview prep pack: Product Manager, Platform APIs at Quartzline

**Round:** 45-minute conversation with the hiring manager, Thursday. Interviewer not named.
**Built from:** your underwriting dossier (decision conditional_go, dated 2026-08-14). No company research ran (see Sources), so nothing about Quartzline's values, loop or strategy is in this pack.

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what it scores: **JD** (a stated requirement), **EXP** (what you actually did), **CASE** (a live problem from the role), **CO** (company knowledge; none here), **VAL** (values; none here, since no values round is documented).
- Guidance is scaffolding, not a script. Each cell is speakable in 90 to 120 seconds.
- Answer slots are instructions for the interview. Each gives both honest branches. Use the one that is true.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" (JD, dossier role_profile R1) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier verified evidence); "Ran quarterly roadmap-input sessions feeding client evidence to product" (dossier verified evidence) | low | [inferred] | transferability | Your adjacent work is real and is quoted at its own scope. It is not PM experience. Say the limit first: "I haven't held a product manager title" (sourced to dossier prohibited_claims, "Having held a product manager title or role"). Then the quoted work, as what it was. The derivation is the dossier's transferability bridge. |
| F2 | "Shipped API or platform products" (JD, dossier role_profile R2) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier verified evidence) | high | [grounded] | discovery | Not in the dossier's weak areas, and this pack does not treat it as settled. The quote shows integrations of the vendor's APIs. It does not show which side of an integration you stood on, or any API you shipped to partners. That is the pack's observation, and it is the largest open risk in your file. Answer slot A3. |
| F3 | "Technical fluency: API docs, schemas" (JD, dossier role_profile R3) | "Wrote the internal integration playbook her team uses" (dossier verified evidence) | high | [grounded] | discovery | The playbook is inspectable. It does not show schema or API reference work. Answer slot E2. |
| F4 | "Stakeholder management across engineering, sales, customers" (JD, dossier role_profile R4) | "Ran quarterly roadmap-input sessions feeding client evidence to product" (dossier verified evidence, medium: confirmed, limited inspectable proof, expect a probe); "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier verified evidence) | medium | [grounded] | transferability | Shows work with clients (UAT, go-live) and with product (roadmap-input sessions). Your material does not show engineering or sales work. Name the medium caveat before a prober extracts it: the roadmap-input work has limited proof. Say what you did with product and clients, and say plainly that engineering and sales are not in what you have confirmed. |
| F5 | "Agile delivery experience" (JD, dossier role_profile R5, preferred) | none given | low | [inferred] | discovery | Clarify strategy, per the dossier. No verified entry speaks to agile delivery, so nothing is quoted. Answer slot A4. |
| F6 | "Own the roadmap for the partner-facing API platform" (JD responsibility; dossier R1 sub-claim) | none given | none | [grounded] | capability | Dossier acknowledge_gap area: capability, confidence none. Plain acknowledgment, sourced to dossier prohibited_claims "Having owned a product roadmap" and "Having set prioritization for an engineering squad": "I haven't owned a product roadmap, and I haven't set prioritization for an engineering squad." No slot, and no bridge into roadmap ownership. These are your statements. Confirm they are true before Thursday. |
| F7 | "Define and track adoption metrics" (JD responsibility) | none given | none | [grounded] | discovery | The material is silent. Answer slot C2. The employer's missing baseline is theirs to answer; do not offer one. |

**Observations, as the pack's own analysis (not words for you):**
- The dossier you pasted has no evidence_map, so grades are the dossier's where it gave them (R1, its sub-claim, R5, the three verified entries) and this pack's everywhere else (F2, F3, F4, F7).
- The dossier does not flag R2 as weak. This pack does, because the quoted integration work does not show the side of the integration the requirement asks about. Settle this before Thursday; it is the question an interviewer is most likely to find.
- The dossier's decision prose says "seven years of integration leadership." No verified entry carries a duration, so this pack does not use it. If it is true and you can point to an inspectable record of it, add it as a verified entry and it becomes usable.

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | Sourced: dossier prohibited_claims | Plain acknowledgment: "I haven't held a product manager title." No slot. |
| Having owned a product roadmap | Sourced: dossier prohibited_claims | Plain acknowledgment: "I haven't owned a product roadmap." No slot. |
| Having set prioritization for an engineering squad | Sourced: dossier prohibited_claims | Plain acknowledgment: "I haven't set prioritization for an engineering squad." No slot. |
| Set roadmap priorities from partner or client evidence | Inflated form of E3 ("Ran quarterly roadmap-input sessions…"): running sessions is not setting priorities | E3 at its own scope. The limit is the pack's observation: your material says you ran the sessions and fed evidence to product, not that you set what it prioritised. |
| Shipped an API product to partners, or owned the provider side of the integrations | Inflated form of the integration quote (F2); the material does not show which side | The quote at its own scope. The limit is the pack's observation. Slot A3 stays inside the integrations you led. |
| Seven years of integration leadership | Dossier decision prose only; not in any verified entry | Not coached until a verified entry carries a duration. |

## Persona table

| Persona | How it shows up | Weight | Reasoning | Counter-strategy |
|---|---|---|---|---|
| Skeptic | "Why hire you into a PM role instead of a PM with three years?" Probes the roadmap gap | 5 (top) | Hiring-manager prior, plus the dossier's named objection and the R1 and roadmap gaps | Concede first, bridge with quotes, ramp as a plan. Hold through two follow-ups. |
| Case/Strategist | Live problems: adoption baseline, a squad disagreement, partner discovery | 4 | Hiring-manager prior: they are buying capability on their own roadmap | Clarify before structuring. Name the assumption you would test first. |
| Data-Driven Prober | "How did you count the 30+?" Adoption metrics | 3 | "30+" is a headline figure; adoption is a named responsibility with no baseline | Defend-the-number slots: how counted, what it is sensitive to, weakest assumption, which part was yours. "I don't know how it was counted" is an honest branch. |
| Pressure | "How much of that was actually you?" | 2 | Tests composure on the step from integrations to product ownership | Pause, restate the quoted scope, hold it, concede only what is true and specific. |
| Conversational | "Walk me through the journey." A casual question about API docs | 2 | Opening and casual questions are still scored | A 90-second arc built only from quoted sentences. |
| Peer Evaluator | Where is the seam with the two squads? Credit when work spans teams | 2 | The squads are the peers this role works with; decision authority is the open question | Seam principles, not claimed seam knowledge. Credit clients and squads. |
| Values/Behavioral | none | 0 | No values round is documented. Your note fixes one 45-minute hiring-manager session, so no archetype fallback applies | Not applicable |

## Question banks

**Skeptic (weight 5)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Why should we hire you into a PM role instead of a PM with three years of the actual job?" | JD | [grounded] dossier prohibited_claims "Having held a product manager title or role"; [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | **Highest-ROI prep in this pack.** The dossier named this objection; it is asked as written, and its negatives are sourced. (1) Concede first, in your own words: you have not held the PM title or owned a roadmap, and a PM with three years of that job is the safer hire for the roadmap itself. (2) Bridge with the quotes at their own scope: the 30+ integrations from scoping to go-live, and the roadmap-input sessions that fed client evidence to product. (3) State the limit plainly: you brought that evidence to the roadmap, and you did not set it. (4) Ramp as a plan, never a past: how you would learn how roadmap decisions are made with the squad leads, and what you would have clear within the first month. Hold through two follow-ups by returning to the quoted work. Concede specifically on the roadmap, never on the integrations. | F1 is where this objection lands. The dossier's likely_interviewer_objections item, asked as written. |
| A2 | "What would be weakest about you on day one in this role?" | JD | [grounded] dossier prohibited_claims "Having owned a product roadmap" | Name the roadmap, and the decision rights between you and the squads, as the day-one gap, in those words. Then the ramp. Do not argue the gap is smaller than it is. | F6, a capability gap the dossier records. Skeptic stem. |
| A3 | "Tell me about an API or platform product you shipped, and what your part in it was." | JD | [grounded] JD "Shipped API or platform products"; [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Open prompt, since the JD raises shipped products. Story map from the quote: describe the integrations you led, scoping to go-live. Answer slot: if you shipped or changed an API your side owned, say what it was and your part; if you integrated APIs someone else owned, say so plainly and say what you took from that. Never describe the vendor's API as yours. | F2 is the row where a shipping claim could be made, and the answer must stay on the side the quote shows. |
| A4 | "What does agile delivery look like day to day for a product manager, and where have you practised it?" | JD | [grounded] JD "Agile delivery experience" | Answer slot (F5). If you have run work that way, say how. If you worked a different way, say so and describe your cadence. If you can't yet define it, say what you would want to confirm about how this team defines it. | F5 is a clarify area. The second branch allows that you have never worked this way. |
| A5 | "What is most likely to surprise you about this role?" | JD | [generic] | Name one thing you have not yet seen first-hand, such as decision rights or the adoption measure, and what you would do first. Make no claim about your past. | Open skeptic probe. Labelled generic: the question is about the role, not about you. |

**Case/Strategist (weight 4)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Partner API adoption has no agreed baseline. How would you find out where we are, and what would you measure first?" | CASE | [generic] | Clarify what counts as adoption: a first call, a live integration, sustained use. Segment partners. Pick one measure you would defend, and say what it hides. Name what you would need from the squads. | Live problem from the adoption responsibility (F7). Makes no past claim. |
| B2 | "Your two engineering squads disagree on what ships next quarter for the partner platform. How do you decide, and who decides?" | CASE | [grounded] JD "Write specs and drive delivery with two engineering squads" | Clarify decision rights before structuring. Then a principle: the evidence you would bring, the tradeoff stated out loud, the escalation path. Do not claim you have settled a disagreement like this. | Squad authority is the open question, and part of the answer is the employer's to give. |
| B3 | "How would you run discovery with integration partners for this platform?" | JD | [grounded] JD "Run discovery with integration partners"; [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Structure first: what you need to learn (use cases, blockers, what partners build), who you would talk to, how you would turn it into requirements. Use the scoping and requirements work you led, as quoted. Do not say you ran a discovery programme. | Responsibility coverage. The claim is limited to the quoted scoping work. |
| B4 | "A partner's integration stalls after go-live. What do you check first?" | CASE | [generic] | Structure: is the blocker in the API, the docs, or the partner's own build? Check usage and errors before the conversation. Say how you would tell these apart. | Live problem drawn from the role's go-live work. Makes no past claim. |

**Data-Driven Prober (weight 3)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how you counted the 30+ integrations, and which part of them was yours." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Defend-the-number slots, in your own words. (a) How were the 30 counted? If you cannot say, say that plainly. (b) What would make the count smaller? (c) Which assumption would you defend least? (d) For each integration, which part was yours (scoping, requirements, architecture, UAT, go-live), and which you did not lead. The pack supplies no counting method, baseline or attribution model. | The headline figure on your verified evidence. Defend-the-number applies. Tests attribution. |
| C2 | "How would you know a partner has adopted the API? What have you measured?" | JD | [grounded] JD "Define and track adoption metrics" | Answer slot (F7). If you defined or tracked a usage measure, say which and how it was counted. If you did not, say so and say what you would measure first. Do not describe a measure you did not track. | F7: a JD responsibility with no quote, so the answer is the slot. |
| C3 | "Give me one metric for platform health you would put on a dashboard, and tell me what it hides." | CASE | [generic] | Pick one metric. Name its denominator and the failure it hides. Use the weakest-assumption move in your own words. | Prober style. Makes no past claim. |

**Pressure (weight 2)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "That integration work. How much of it was actually you?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Hold: restate the scope as quoted. You led the integrations from scoping to go-live. Hold through two follow-ups. Then concede what is true and specific: name, in your own words, the decisions that were not yours. Do not concede the scope itself. | Hold-then-concede on what the quotes carry. |
| D2 | "You haven't owned a roadmap. So what would you actually decide on day one?" | JD | [grounded] dossier prohibited_claims "Having owned a product roadmap" | Concede the premise plainly. Then name two decisions you would want to make from the evidence you can bring, and say which you would take to the squad leads first. Do not assert decisions you have made. | Premised question on a sourced negative, asked as the dossier's objection is asked. |

**Conversational (weight 2)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey to here." | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; [grounded] "Wrote the internal integration playbook her team uses"; [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | A 90-second arc built only from these three quotes, in your words: the integrations, the playbook, the sessions. Close on the limit: you feed product; you do not set its priorities. | Casual register is still scored. |
| E2 | "What are you working with in API docs and schemas these days?" | JD | [grounded] "Wrote the internal integration playbook her team uses" | Answer slot (F3). If you wrote or reviewed schemas or API reference docs, say which. If not, say what the playbook covered and what you read. | R3 is covered only by the slot. |

**Peer Evaluator (weight 2)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Your engineering squads sit beside the product work. Where's the seam, and what happens when you disagree?" | JD | [grounded] JD "Write specs and drive delivery with two engineering squads" | Seam principles, not claimed knowledge of this seam: who decides scope, who owns the spec, how disagreement is escalated and settled. | Peer probe on the seam. |
| F2 | "How do you handle credit when work spans teams?" | JD | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Credit the clients and squads for what they did. Name your part in your own words, as the quote states it: you fed evidence to product. Do not claim credit for roadmap outcomes. | Peer probe on credit. The quote carries the contribution. |

## Requirement coverage

| Requirement | Covered by | Note |
|---|---|---|
| R1: 3+ years product management (must) | A1, A2, D2 | Covered as concession and bridge. No PM-experience claim. |
| R2: Shipped API or platform products (must) | A1, A3 | A3 is a slot. The side of the integrations is unresolved. |
| R3: Technical fluency, API docs, schemas (important) | E2 | Slot only. No schema claim. |
| R4: Stakeholder management, engineering, sales, customers (important) | B2, F1, F2, D1 | Sales: none, because no sales work is quoted. No question beyond the slot. |
| R5: Agile delivery (preferred) | A4 | Clarify slot. |
| Responsibility: own the roadmap | A1, A2, D2 | Acknowledgment only. |
| Responsibility: discovery with partners | B3 | |
| Responsibility: specs and delivery with two squads | B2, F1 | |
| Responsibility: define and track adoption metrics | B1, C2, C3 | |

## Reverse questions

Each one answers something your file leaves open.

1. **"Which roadmap decisions does this PM make alone, and which belong to the two squad leads?"** Why it lands: the dossier's first unknown. You need this answer before you accept, and asking it reads as diligence.
2. **"How is partner API adoption measured today, and what is the current baseline?"** Why it lands: the second unknown. It shows you read the responsibilities and gives the employer a reason to say what they have.
3. **"What would you need to see in the first 90 days to feel this was the right hire?"** Why it lands: it surfaces their actual bar, which is the thing your ramp plan has to meet.
4. **"Where have product and the squads disagreed most recently, and how was it settled?"** Why it lands: it shows how decisions actually get made here, not how the JD describes them.
5. **"What is the hardest partner problem the next hire would walk into?"** Why it lands: it connects the role to the integration work you can actually describe, and it tests whether the problem is one the role can take on.

## Sources

- **Provided:** your dossier, tuesday-dossier.md, pasted in this conversation. Dossier version 1.1, decision conditional_go, dated 2026-08-14.
- **Dossier sections consumed:** role_profile (the requirement text, as the supplied JD lines); verified_candidate_evidence; handoff_to_mock_interview (weak areas, the likely objection, risks, employer questions, prohibited_claims). The decision is context only. evidence_map and risk_register were not in the pasted file.
- **The dossier is about three months old.** Check that the JD and responsibilities still match the role you have.
- **Searches sent:**
  - "Quartzline values principles": refused by the host's search permission.
  - "Quartzline interview process product manager platform APIs": refused by the same permission.
  - Neither was retried.

Research tier: L1 — searches 2 of 6, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quartzline values | unavailable | Would have fixed the values cheat sheet. Both calls for this target were refused, so no values round is detected and no cheat sheet is included. |
| 2. Quartzline interview process, product manager | unavailable | Would have confirmed loop structure. Your note already fixes one 45-minute hiring-manager session, so no archetype fallback was applied. The call was refused. |
| 3. Quartzline strategy / recent news | unavailable | Would have moved the CO bank. No call was sent after the two refusals, so the CO bank is empty. |
| 4. Interviewer name at Quartzline | n/a | No interviewer name was given. |
| 5. Representative product manager, platform APIs JD | skipped | Your dossier's role_profile fixes the requirements and the JD-tagged questions. |

## Upgrade menu

- **Quartzline's values page, or a pasted copy:** a values cheat sheet, only if the process documents a values round. Otherwise nothing changes.
- **Permission to rerun the two refused searches, or the interview-process page pasted:** loop structure from a named source. It would confirm the session shape you described.
- **A few lines on Quartzline's current priorities or a recent strategy note:** CO questions, which the pack lacks entirely. Each would be grounded, not generic.
- **The interviewer's name:** an interviewer read, persona weights from their public footprint, and a tailored reverse question.
- **Your CV, or the underwriter's full evidence_map:** settles F2 (which side of the integrations you stood on) and F4 from a document rather than the dossier's quotes.
- **The recruiter's note on what the 45 minutes cover:** reweights the personas to the actual agenda.
