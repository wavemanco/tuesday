Your prep pack is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-alone-part-2-rooms-case-8-canned-b700f276/4ed4cfe0-834a-4375-bee8-c1767ce16177/scratchpad/ashgrove_member_experience_lead_interview_pack.md`. The full text is below.

# Ashgrove Credit Union: Member Experience Lead interview pack

**Role:** Member Experience Lead. **Company:** Ashgrove Credit Union. **Built:** 11 November 2026.
**Mode:** Loop (three rounds on 20 November 2026).
- **Round A:** recruiter screen, 30 min.
- **Round B:** Head of Member Services, 45 min, mostly behavioural. This person would be your manager.
- **Round C:** panel of two branch managers, 60 min, including a 20-minute complaint escalation case. The panel also scores the four values.

**Inputs used:** the JD text, your background as written in your message, the four values as pasted from ashgrovecu.org, the strategy brief summary in your message, and the recruiter's email.
**Research tier:** L1, with 0 of 6 searches and 0 of 2 fetches. Every research target was already fixed by pasted inputs.

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored.
- **Type key:** VAL = values, EXP = your experience, JD = a stated job requirement, CO = company and strategy, CASE = a live problem.
- Guidance is scaffolding, not a script. Rehearse the beats, not the sentences.
- **Answer slot:** an instruction for the interview. It asks for an answer in the room, not here. Give the branch that is true.

## Fit snapshot

Your sentences are quoted exactly. Everything the pack says about your past rests on these quotes or on plain acknowledgments you have stated.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" (JD) | "6 years in retail banking, the last 3 as a branch supervisor." (your message) | medium | [grounded] | presentation | Your material says retail banking, not customer operations. Bridge with the quote as written: "Six years in retail banking, the last three as a branch supervisor." Answer slot: the JD names customer operations, so expect a probe on whether your branch work was that. If it was, say which parts; if not, say so plainly. |
| F2 | "experience handling regulated complaints" (JD) | "I handled the branch's formal complaints log and trained new tellers on our escalation script." (your message) | medium | [grounded] | discovery | Your material shows formal complaints handled at branch level. It does not show whether they carried regulatory timescales or regulator reporting. Answer slot: expect "what timescale applied, and who did you report to?" If one applied, say which and how you tracked it; if none did, say so plainly. |
| F3 | "Own the member complaints process end to end across branches and the contact centre" (JD) | "I handled the branch's formal complaints log" (your message) | low | [inferred] | transferability | Handling one branch's log is adjacent to owning the process across branches. Bridge at the quote's own scope: "I handled the branch's formal complaints log." Limit, in the pack's own words: the material shows one branch's log, not ownership across branches. Answer slot: expect "which steps of the process were yours to decide?" Say which steps you ran and which you did not. |
| F4 | "report monthly on complaint volumes and resolution times" (JD) | "I built the monthly complaints spreadsheet our regional manager uses." (your message) | medium | [grounded] | discovery | The sheet is monthly and used upward. The material does not show whether it counted volumes, resolution times, or both. Answer slot: expect "what did the sheet count, and how did you define a resolution?" Say what it counted in your own words. If resolution times were not in it, say so and say what you would measure first. |
| F5 | "coach branch supervisors on escalations" (JD) | "trained new tellers on our escalation script" (your message) | medium | [grounded] | transferability | Training tellers on the escalation script is adjacent to coaching supervisors, and the audience differs. Bridge at its own scope: "I trained new tellers on our escalation script." Answer slot: expect "have you coached anyone above teller level?" If you did, say who and what you did; if not, say so and say how you would start. |
| F6 | "confident presenting to senior leaders" (JD) | "Never worked in a contact centre, and I've never presented to anyone above regional level." (your message) | none | [grounded] | capability | You stated this absence. Your plain acknowledgment: "I've never presented to anyone above regional level." Then how you would build the skill, as a plan and never as a past. Nothing added to make the gap feel smaller. |
| F7 | "comfortable with Excel reporting" (JD) | "I built the monthly complaints spreadsheet our regional manager uses." (your message) | medium | [grounded] | presentation | The quote reaches the requirement in other terms (a built spreadsheet). It does not name Excel. Bridge reworded only from the quote: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: expect a probe on how it is built. Say what it does and which parts you built. |
| F8 | "work with digital teams on self-service journeys" (JD) | none given | none | [grounded] | discovery | Your material is silent on this, so it is shown neither way. Answer slot: if you have worked with a digital or product team on any customer-facing process, say what and what you contributed. If not, say so plainly and say how you would start. |
| F9 | "across branches and the contact centre" (JD) | "Never worked in a contact centre, and I've never presented to anyone above regional level." (your message) | none | [grounded] | capability | You stated this absence. Your plain acknowledgment: "I've never worked in a contact centre." Then how you would learn contact-centre operations, as a plan. |

**Gate rows:** none. The JD states no location, schedule, travel, credential or legal term. "4+ years" is a length-of-experience requirement, so it is graded on fit, not treated as a gate.

## Grounding brief (strategy)

From the 2026 strategy brief as summarised in your message. Use these words; they are the company's current vocabulary.

- "move 40% of member service to digital channels by 2028"
- "consolidate eight branches into five hubs over 2027"
- "launch a small-business lending product in Q1 2027"
- Competitive pressure named as "app-only banks"

Nothing in the pasted material looks stale. Recent news was not checked, so do not cite dates or moves beyond this brief.

## Persona weights

| Round | Persona | Questions | Reasoning |
|---|---|---|---|
| A | Conversational / rapport | 5 (A1, A2, A4, A7, A8) | Recruiter screen. Logistics, motivation and knockout checks in a friendly register. Casual questions are still scored. |
| A | Skeptic | 3 (A3, A5, A6) | Light skeptic prior for a recruiter screen. Probes the contact-centre and regulated-complaints gaps early. |
| B | Values / behavioral | 3 (B1, B2, B8) | Head of Member Services, mostly behavioural. Scored against the values and the job. |
| B | Skeptic | 2 (B3, B4) | Hiring-manager prior: they are buying capability and de-risking gaps. B3 is the highest-ROI rehearsal. |
| B | Data-driven prober | 2 (B6, B7) | Your spreadsheet is the figure they will test. |
| B | Case / strategist | 1 (B5) | A live escalation problem. |
| C | Values / behavioral | 3 (C3, C4, C5) | The panel scores the four values, so this is the heaviest persona. |
| C | Case / strategist | 3 (C1, C2, C8) | Includes the 20-minute escalation case and a strategy question. |
| C | Data-driven prober | 1 (C6) | One figure-checking probe from branch managers. |
| C | Peer evaluator | 1 (C7) | Panel members are branch managers, so seam questions come collegially. |

Panel member names are not known, so weights are blended by round. No interviewer profiles were supplied, so there is no interviewer read.

## Prohibited claims

Built locally from the fit snapshot. These are the claims that are easy to reach for under pressure. No answer, hold or reverse question below asserts, softens or implies them.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end across branches and the contact centre | Inflated form of F3 and F9 | "I handled the branch's formal complaints log." The limit is the pack's own observation: the material shows one branch's log. Contact centre: "I've never worked in a contact centre." |
| Coached branch supervisors on escalations | Inflated form of F5 | "I trained new tellers on our escalation script." |
| Reported monthly on resolution times | Inflated form of F4 | The spreadsheet quote at its own scope. Which figures it counted is an answer slot. |
| Presented to senior leaders | Negative you stated, F6 | "I've never presented to anyone above regional level." |
| Handled regulated complaints; advanced Excel | Inflated forms of F2 and F7 | The quotes at their own scope. Nothing about regulation or Excel expertise is stated. |

## Values cheat sheet

Your material carries no story for any of the four values, so each row is a selection scaffold ending in its honest branch.

| Value | Working meaning | Your mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter. | No quoted sentence carries a story. Pick a decision where you chose the member's outcome over a process convenience. If none comes to mind, say so plainly, then give the complaints log you handled and how you would decide it from the member's side. |
| Plain Words | If a member needs it explained twice, it was written wrong. | No quoted sentence carries a story. Pick a time you explained something so it landed first time. If none comes to mind, say so plainly, then give the teaching you did: "trained new tellers on our escalation script." |
| Neighbours, Not Numbers | Every branch is part of its town. | No quoted sentence carries a story. Pick a complaint you saw as a local problem rather than a branch figure. If none comes to mind, say so plainly, and do not invent a community detail. |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved. | No quoted sentence carries a story. Pick a problem you found and held until it was solved. If none comes to mind, say so plainly, then give the nearest thing your material carries: "I handled the branch's formal complaints log." |

## Question banks

Provenance comes first on every row. Your quoted sentences sit beside any claim about your past. Guidance is 90 to 120 seconds spoken.

### Round A: recruiter screen (30 min)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Take me through your six years in retail banking." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Tell it in order: retail banking, the three years as branch supervisor, then the complaints log and the teller training. Use the sentence's own beats. | F1 is the first requirement the screen checks. Premised on that sentence only. |
| A2 | "Why a member-owned credit union?" | VAL | [grounded] the four values as pasted | Answer from what you have seen at the counter, and keep it to what is true for you. If the reason is the member-owned model itself, say that. | Values scoring starts here; the recruiter is listening for "Neighbours, Not Numbers" in plain words. |
| A3 | "You haven't worked in a contact centre. How would you run a process across one?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Plain acknowledgment: "I've never worked in a contact centre." Then describe how you would learn it, as a plan. Do not claim contact-centre knowledge. | F9 and the JD's "across branches and the contact centre". Asked as a probe, so the honest answer is the first branch. |
| A4 | "So, walk me through the journey." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | A 90-second arc: where you started, the branch, supervising, the complaints work. Say it in your words. | An open opener is scored for economy. The arc is A1's beats, shorter. |
| A5 | "Why leave branch supervision now?" | EXP | [generic] | Give your reason in your own words. Do not reach for a claim about the company's strategy beyond the brief. | A motivation probe. No fit row carries a reason, so the guidance makes no claim. |
| A6 | "Which of those complaints had a regulatory deadline, and who did you report to?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Answer slot per F2. If a timescale or report applied, say which and how you tracked it. If none did, say so plainly. | F2 is the requirement the material does not settle, and the JD raises it by name. |
| A7 | "What are you working with in spreadsheets these days?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Say what the sheet does and which parts you built. Answer slot per F7. | F7 is the Excel requirement, asked casually. Casual questions about the JD are still scored. |
| A8 | "Ashgrove plans to move 40% of member service to digital channels by 2028. What would that change in a complaints role?" | CO | [grounded] "move 40% of member service to digital channels by 2028" (strategy brief) | Name two things: what moves to self-service, and what still needs a person, such as a complex complaint. Propose principles; do not claim an outcome. | The rubric requires one strategy question. This tests whether you think at the company's altitude, using only its brief. |

### Round B: Head of Member Services (45 min, your future manager)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time you had to tell a member something they didn't want to hear." | VAL | [grounded] "I handled the branch's formal complaints log" | STAR-shaped: "we" for context, "I" for your part. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, the log you handled, and how you would handle it now. | Behavioural, mapped to Members First. No story is in the material, so the honest branch is written in. |
| B2 | "How did you handle a member whose problem the escalation script didn't cover?" | EXP | [grounded] "trained new tellers on our escalation script" | Answer slot: if you did this, say how, in your own words. If you never met such a case, say so plainly and describe how you would use the script's gaps. | The script is your own training material. The question asks for an instance, which the material does not supply. |
| B3 | "You have never worked in a contact centre, and this role runs across one. Why should we hire you to own the process across it?" | JD | [grounded] "Never worked in a contact centre" (your message); "I handled the branch's formal complaints log" | **Highest-ROI rehearsal.** Hold, then concede. (1) Say the plain acknowledgment: "I've never worked in a contact centre." (2) Name what carries across: "I handled the branch's formal complaints log," and say that is one branch's log. (3) Concede the specific gap, then give your first 90 days as a plan. Hold through two follow-ups by returning to the log. Do not fold on the log's scope. | The most predictable objection. F9 is its negative and F3 its only evidence. The panel will likely ask some version of it too. |
| B4 | "This role is expected to be confident presenting to senior leaders. You haven't presented above regional level. How would you do that?" | JD | [grounded] "I've never presented to anyone above regional level." | Plain acknowledgment: "I've never presented to anyone above regional level." Then a plan: how you would prepare, and who you would present to first. | F6 is a stated gap. The words given back are the negative you stated; the rest is a plan. |
| B5 | "A member has waited 25 days for an answer promised in 10, and their branch manager has left. Walk me through this week." | CASE | [generic] | Clarify the promise and the deadline. Then contact the member, name who now owns the case, record the delay, and set a date you will keep. | An escalation mechanic. The question needs no claim about your past. |
| B6 | "Walk me through the monthly complaints spreadsheet, and tell me which figure you would defend least." | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Name what it counts, then the weakest assumption you know behind a figure. If you do not know how a figure was counted, say so plainly. Do not explain a method you cannot repeat. | Defend-the-number rule for a headline figure. F4 is where the probe lands. |
| B7 | "This role reports monthly on volumes and resolution times. Which of those did your sheet count?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Answer slot per F4. Say what it counted in your own words. If resolution times were not in it, say so and say what you would measure first. | F4 is the JD's reporting line, and the material does not show which figures the sheet held. |
| B8 | "Coaching branch supervisors on escalations is part of this job. Have you coached anyone above teller level?" | JD | [grounded] "trained new tellers on our escalation script" | Answer slot per F5. If you coached any supervisor or senior colleague on escalations, say who and what you did. If not, say so and say how you would start. | F5. The JD names coaching supervisors; your quote is about tellers. |

### Round C: panel of two branch managers (60 min, includes 20-min case, values scored)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A member disputes a fee. It has been through the branch twice and now comes to you. Walk me through the first hour." | CASE | [generic] | Clarify what outcome the member wants and what the branch already did. Then decide who owns the decision, what gets recorded, and what must escalate. Name the decision you would make first. | The 20-minute escalation case. A live problem; it makes no claim about your past. |
| C2 | "A branch manager tells you these complaints belong to the complaints team, not to her. What do you do?" | CASE | [grounded] "trained new tellers on our escalation script" | Clarify what she means by "belong". Then agree who owns what, write it down, and go back to the member. Hold the position that the member's case has one owner. | The JD's "coach branch supervisors on escalations", asked as a live problem. The quote is the nearest thing you have to a supervisor-facing process. |
| C3 | "Tell me about a complaint you read as a town's problem rather than a branch figure." | VAL | [grounded] "I handled the branch's formal complaints log" | Selection scaffold: pick a complaint that mattered beyond one member. If none comes to mind, say so plainly, then give the log you handled and how you would read it as a local problem. Do not invent a community detail. | Scored against Neighbours, Not Numbers. The honest branch is written in because the material has no such story. |
| C4 | "Tell me about a letter or explanation you rewrote so a member understood it first time." | VAL | [generic] | Selection scaffold: pick a time you explained something in plain words. If none comes to mind, say so plainly, then give the teaching you did: "trained new tellers on our escalation script." | Scored against Plain Words. The fallback quote is the teaching sentence, so the story stays within it. |
| C5 | "Tell me about a problem you found and kept hold of until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log" | Selection scaffold: pick a problem you found and held. If none comes to mind, say so plainly, then give the log you handled and what stayed open. | Scored against Own the Fix. The material's limit: a log is not a found problem. |
| C6 | "How would you know whether your monthly figures are right?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Name the weakest assumption you know of in the sheet. If you have not checked the figures against another source, say so plainly. | The data-driven probe on your headline output. The honest answer is the one you can repeat under a second question. |
| C7 | "Our digital team is building self-service for complaints. Where is the seam with branch work, and what would you need from them?" | JD | [grounded] "work with digital teams on self-service journeys" (the JD) | Answer slot per F8. If you have worked with a digital or product team, say what. If not, say so, then propose seam principles, not a claim. | A peer seam question, collegially framed. F8 is silent in the material, so the honest branch matters. |
| C8 | "Eight branches become five hubs during 2027. How do complaints stay with the member when a branch closes?" | CO | [grounded] "consolidate eight branches into five hubs over 2027" (strategy brief) | Propose principles: one case owner, a hand-over record, and a dated check with the member. Say what you do not know about the hubs. Do not claim an outcome. | The rubric asks for a strategy question. This uses the brief's own consolidation, which the panel is likely to know well. |

## Requirement coverage

| JD requirement | Question IDs |
|---|---|
| 4+ years in financial-services customer operations | A1, A4 |
| Experience handling regulated complaints | A6, B2 |
| Confident presenting to senior leaders | B4 |
| Comfortable with Excel reporting | A7, B6 |
| Own the member complaints process end to end across branches and the contact centre | B3, A3, C1 |
| Report monthly on complaint volumes and resolution times | B7, C6 |
| Coach branch supervisors on escalations | B8, C2 |
| Work with digital teams on self-service journeys | C7 |

## Reverse questions

No interviewer profiles were supplied, so these are role-generic.

**Round A (recruiter):**
1. "What does a good first 90 days look like for this role?" Why it lands: it shows you think about the job's shape, not the title.
2. "Roughly how many complaints does the role handle in a month today?" Why it lands: it asks for a number, not a story, and tells you how much the role carries.

**Round B (Head of Member Services):**
3. "What would you need from me in the first month that would make the biggest difference?" Why it lands: it treats them as your manager and asks what they will do for you.
4. "Which kind of complaint will change most when the branches become hubs?" Why it lands: it ties your question to the strategy the brief names.

**Round C (panel):**
5. "What does your branches' complaints team do that the process document does not say?" Why it lands: it asks for the unwritten practice, which branch managers know and documents often miss.
6. Reciprocity: "What could a new person do in their first month that would genuinely help your branches?" Why it lands: a peer-framed question that puts their needs first, which panels score as partnership fit.

## Sources

Provided documents: the JD text, your background in your message, the four values as pasted from ashgrovecu.org (copied 11 November 2026), the strategy brief summary in your message, and the recruiter's email with the three rounds.

**Research tier: L1, with 0 of 6 searches and 0 of 2 fetches.** Every target was fixed by pasted inputs, so no call was needed.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | The values cheat sheet. The four values are pasted, so the output is fixed by input. |
| 2. Ashgrove interview process | skipped | Loop structure and persona weights. The recruiter's email names the three rounds and the panel. |
| 3. Ashgrove strategy / recent news | skipped | The grounding brief. The pasted strategy brief supplies current priorities. Recent news was not checked. |
| 4. Interviewer name + Ashgrove | n/a | No names yet. The interviewer read is absent; the upgrade menu says what a name would unlock. |
| 5. Representative JD for the role | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions. |

## Upgrade menu

- The complaints spreadsheet's column headings, with no data → F4 and F7 get quoted columns, and B7 gets a sourced answer.
- Panel members' names → per-member persona weights in Round C.
- The Head of Member Services' name → Round B reverse questions and weights from public footprint.
- Prep time before 20 November → a prioritised prep schedule.
- Deep research (L2) → current Ashgrove news and recent moves, checked against the brief.
- A complaint you resolved from start to finish, if one happened → a quoted row for F3, which turns its answer slot into a story.

---

**Highest-ROI prep:** B3. The contact-centre objection is the one most likely to be asked in some form, and the honest answer is short: say the plain acknowledgment, name the one thing that carries across, and give a plan for the rest.

Want a live run of B3? I'll play the Head of Member Services and push back on each answer until you hold or concede. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions, and convert the pack to Word if you want it.

Could you paste the column headings from your complaints spreadsheet? No data needed; that upgrades F4 and F7 from answer slots to quoted columns.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove_member_experience_lead_interview_pack.md -----
# Ashgrove Credit Union: Member Experience Lead interview pack

**Role:** Member Experience Lead. **Company:** Ashgrove Credit Union. **Built:** 11 November 2026.
**Mode:** Loop (three rounds on 20 November 2026).
- **Round A:** recruiter screen, 30 min.
- **Round B:** Head of Member Services, 45 min, mostly behavioural. This person would be your manager.
- **Round C:** panel of two branch managers, 60 min, including a 20-minute complaint escalation case. The panel also scores the four values.

**Inputs used:** the JD text, your background as written in your message, the four values as pasted from ashgrovecu.org (copied 11 November 2026), the strategy brief summary in your message, and the recruiter's email.
**Research tier:** L1, with 0 of 6 searches and 0 of 2 fetches. Every research target was already fixed by pasted inputs (see Sources).

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored.
- **Type key:** VAL = values, EXP = your experience, JD = a stated job requirement, CO = company and strategy, CASE = a live problem.
- Guidance is scaffolding, not a script. Rehearse the beats, not the sentences.
- **Answer slot:** an instruction for the interview. It asks you for an answer in the room, not here. Give the branch that is true.

## Fit snapshot

Your sentences are quoted exactly. Everything the pack says about your past rests on these quotes or on the plain acknowledgments you have stated.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" (JD) | "6 years in retail banking, the last 3 as a branch supervisor." (your message) | medium | [grounded] | presentation | Your material says retail banking, not customer operations. Bridge with the quote as written: "Six years in retail banking, the last three as a branch supervisor." Answer slot: the JD names customer operations, so expect a probe on whether your branch work was that. If it was, say which parts; if not, say so plainly. |
| F2 | "experience handling regulated complaints" (JD) | "I handled the branch's formal complaints log and trained new tellers on our escalation script." (your message) | medium | [grounded] | discovery | Your material shows formal complaints handled at branch level. It does not show whether they carried regulatory timescales or regulator reporting. Answer slot: expect "what timescale applied, and who did you report to?" If a timescale or report applied, say which and how you tracked it; if none did, say so plainly. |
| F3 | "Own the member complaints process end to end across branches and the contact centre" (JD) | "I handled the branch's formal complaints log" (your message) | low | [inferred] | transferability | Handling one branch's log is adjacent to owning the process across branches. Bridge at the quote's own scope: "I handled the branch's formal complaints log." Limit, in the pack's own words: the material shows one branch's log, not ownership across branches. Answer slot: expect "which steps of the process were yours to decide?" Say which steps you ran and which you did not. |
| F4 | "report monthly on complaint volumes and resolution times" (JD) | "I built the monthly complaints spreadsheet our regional manager uses." (your message) | medium | [grounded] | discovery | The sheet is monthly and used upward. The material does not show whether it counted volumes, resolution times, or both. Answer slot: expect "what did the sheet count, and how did you define a resolution?" Say what it counted in your own words. If resolution times were not in it, say so and say what you would measure first. |
| F5 | "coach branch supervisors on escalations" (JD) | "trained new tellers on our escalation script" (your message) | medium | [grounded] | transferability | Training tellers on the escalation script is adjacent to coaching supervisors, and the audience differs. Bridge at its own scope: "I trained new tellers on our escalation script." Answer slot: expect "have you coached anyone above teller level?" If you did, say who and what you did; if not, say so and say how you would start. |
| F6 | "confident presenting to senior leaders" (JD) | "Never worked in a contact centre, and I've never presented to anyone above regional level." (your message) | none | [grounded] | capability | You stated this absence. Your plain acknowledgment: "I've never presented to anyone above regional level." Then how you would build the skill, as a plan and never as a past. Nothing added to make the gap feel smaller. |
| F7 | "comfortable with Excel reporting" (JD) | "I built the monthly complaints spreadsheet our regional manager uses." (your message) | medium | [grounded] | presentation | The quote reaches the requirement in other terms (a built spreadsheet). It does not name Excel. Bridge reworded only from the quote: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: expect a probe on how it is built. Say what it does and which parts you built. |
| F8 | "work with digital teams on self-service journeys" (JD) | none given | none | [grounded] | discovery | Your material is silent on this, so it is shown neither way. Answer slot: if you have worked with a digital or product team on any customer-facing process, say what and what you contributed. If not, say so plainly and say how you would start. |
| F9 | "across branches and the contact centre" (JD) | "Never worked in a contact centre, and I've never presented to anyone above regional level." (your message) | none | [grounded] | capability | You stated this absence. Your plain acknowledgment: "I've never worked in a contact centre." Then how you would learn contact-centre operations, as a plan. |

**Gate rows:** none. The JD states no location, schedule, travel, credential or legal term. "4+ years" is a length-of-experience requirement, so it is graded on fit and not treated as a gate.

## Grounding brief (strategy)

From the 2026 strategy brief as summarised in your message. Use these words; they are the company's current vocabulary.

- "move 40% of member service to digital channels by 2028"
- "consolidate eight branches into five hubs over 2027"
- "launch a small-business lending product in Q1 2027"
- Competitive pressure named as "app-only banks"

Nothing in the pasted material looks stale. Recent news was not checked (research tier L1 ran no searches), so do not cite dates or moves beyond this brief.

## Persona weights

| Round | Persona | Questions | Reasoning |
|---|---|---|---|
| A | Conversational / rapport | 5 (A1, A2, A4, A7, A8) | Recruiter screen. Logistics, motivation and knockout checks in a friendly register. Casual questions are still scored. |
| A | Skeptic | 3 (A3, A5, A6) | Light skeptic prior for a recruiter screen. Probes the contact-centre and regulated-complaints gaps early. |
| B | Values / behavioral | 3 (B1, B2, B8) | Head of Member Services, mostly behavioural. Scored against the values and the job. |
| B | Skeptic | 2 (B3, B4) | Hiring-manager prior: they are buying capability and de-risking gaps. B3 is the highest-ROI rehearsal in the pack. |
| B | Data-driven prober | 2 (B6, B7) | Your spreadsheet is the figure they will test. |
| B | Case / strategist | 1 (B5) | A live escalation problem. |
| C | Values / behavioral | 3 (C3, C4, C5) | The panel scores the four values, so this is the heaviest persona. |
| C | Case / strategist | 3 (C1, C2, C8) | Includes the 20-minute escalation case, and a strategy question. |
| C | Data-driven prober | 1 (C6) | One figure-checking probe from branch managers. |
| C | Peer evaluator | 1 (C7) | Panel members are branch managers, so seam questions come collegially. |

Panel member names are not known, so persona weights are blended by round. No interviewer profiles were supplied, so there is no interviewer read.

## Prohibited claims

Built locally from the fit snapshot. These are the claims that are easy to reach for under pressure. No answer, hold or reverse question below asserts, softens or implies them.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end across branches and the contact centre | Inflated form of F3 and F9 | "I handled the branch's formal complaints log." The limit is the pack's own observation: the material shows one branch's log. Contact centre: "I've never worked in a contact centre." |
| Coached branch supervisors on escalations | Inflated form of F5 | "I trained new tellers on our escalation script." |
| Reported monthly on resolution times | Inflated form of F4 | The spreadsheet quote at its own scope. Which figures it counted is an answer slot. |
| Presented to senior leaders | Negative you stated, F6 | "I've never presented to anyone above regional level." |
| Handled regulated complaints; advanced Excel | Inflated forms of F2 and F7 | The quotes at their own scope. Nothing about regulation or Excel expertise is stated. |

## Values cheat sheet

Your material carries no story for any of the four values, so each row is a selection scaffold ending in its honest branch.

| Value | Working meaning | Your mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter. | No quoted sentence carries a story. Pick a decision where you chose the member's outcome over a process convenience. If none comes to mind, say so plainly, then give the complaints log you handled, and how you would decide it from the member's side. |
| Plain Words | If a member needs it explained twice, it was written wrong. | No quoted sentence carries a story. Pick a time you explained something so it landed first time. If none comes to mind, say so plainly, then give the teaching you did: "trained new tellers on our escalation script." |
| Neighbours, Not Numbers | Every branch is part of its town. | No quoted sentence carries a story. Pick a complaint you saw as a local problem rather than a branch figure. If none comes to mind, say so plainly, and do not invent a community detail. |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved. | No quoted sentence carries a story. Pick a problem you found and held until it was solved. If none comes to mind, say so plainly, then give the nearest thing your material carries: "I handled the branch's formal complaints log." |

## Question banks

Provenance comes first on every row. Your quoted sentences sit beside any claim about your past. Guidance is 90 to 120 seconds spoken.

### Round A: recruiter screen (30 min)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Take me through your six years in retail banking." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Tell it in order: retail banking, then the three years as branch supervisor, then the complaints log and the teller training. Use the sentence's own beats. | F1 is the first requirement the screen checks. Premised on that sentence only. |
| A2 | "Why a member-owned credit union?" | VAL | [grounded] the four values as pasted | Answer from what you have seen at the counter, and keep it to what is true for you. If the reason is the member-owned model itself, say that. | Values scoring starts here, and the recruiter is listening for "Neighbours, Not Numbers" in plain words. |
| A3 | "You haven't worked in a contact centre. How would you run a process across one?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Plain acknowledgment: "I've never worked in a contact centre." Then describe how you would learn it, as a plan. Do not claim contact-centre knowledge. | F9 and the JD's "across branches and the contact centre". The question is asked as a probe, so the honest answer is the first branch. |
| A4 | "So, walk me through the journey." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | A 90-second arc: where you started, the branch, supervising, the complaints work. Say it in your words. | An open opener is scored for economy. The arc is the same beats as A1, shorter. |
| A5 | "Why leave branch supervision now?" | EXP | [generic] | Give your reason in your own words. Do not reach for a claim about the company's strategy beyond the brief. | A motivation probe. No fit row carries a reason, so the guidance makes no claim. |
| A6 | "Which of those complaints had a regulatory deadline, and who did you report to?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Answer slot per F2. If a timescale or report applied, say which and how you tracked it. If none did, say so plainly. | F2 is the requirement the material does not settle, and the JD raises it by name. |
| A7 | "What are you working with in spreadsheets these days?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Say what the sheet does and which parts you built. Answer slot per F7. | F7 is the Excel requirement, asked casually. Casual questions about the JD are still scored. |
| A8 | "Ashgrove plans to move 40% of member service to digital channels by 2028. What would that change in a complaints role?" | CO | [grounded] "move 40% of member service to digital channels by 2028" (strategy brief) | Name two things: what moves to self-service, and what still needs a person, such as a complex complaint. Propose principles; do not claim an outcome. | The rubric requires one strategy question. This one tests whether you can think at the company's altitude, using only its brief. |

### Round B: Head of Member Services (45 min, your future manager)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time you had to tell a member something they didn't want to hear." | VAL | [grounded] "I handled the branch's formal complaints log" | STAR-shaped: "we" for context, "I" for your part. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, the log you handled, and how you would handle it now. | Behavioural, mapped to Members First. No story is in the material, so the honest branch is written in. |
| B2 | "How did you handle a member whose problem the escalation script didn't cover?" | EXP | [grounded] "trained new tellers on our escalation script" | Answer slot: if you did this, say how, in your own words. If you never met such a case, say so plainly and describe how you would use the script's gaps. | The script is your own training material. The question asks for an instance, which the material does not supply. |
| B3 | "You have never worked in a contact centre, and this role runs across one. Why should we hire you to own the process across it?" | JD | [grounded] "Never worked in a contact centre" (your message); "I handled the branch's formal complaints log" | **Highest-ROI rehearsal.** Hold, then concede. (1) Say the plain acknowledgment: "I've never worked in a contact centre." (2) Name what carries across: "I handled the branch's formal complaints log," and say that is one branch's log. (3) Concede the specific gap, then give your first 90 days as a plan. Hold through two follow-ups by returning to the log. Do not fold on the log's scope. | This is the most predictable objection. F9 is its negative and F3 its only evidence. The panel will likely ask some version of it too. |
| B4 | "This role is expected to be confident presenting to senior leaders. You haven't presented above regional level. How would you do that?" | JD | [grounded] "I've never presented to anyone above regional level." | Plain acknowledgment: "I've never presented to anyone above regional level." Then a plan: how you would prepare, and who you would present to first. | F6 is a stated gap. The words given back are the negative you stated, and the rest is a plan. |
| B5 | "A member has waited 25 days for an answer promised in 10, and their branch manager has left. Walk me through this week." | CASE | [generic] | Clarify the promise and the deadline. Then contact the member, name who now owns the case, record the delay, and set a date you will keep. | An escalation mechanic. The question needs no claim about your past. |
| B6 | "Walk me through the monthly complaints spreadsheet, and tell me which figure you would defend least." | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Name what it counts, then the weakest assumption you know behind a figure. If you do not know how a figure was counted, say so plainly. Do not explain a method you cannot repeat. | Defend-the-number rule for a headline figure. F4 is where the probe lands. |
| B7 | "This role reports monthly on volumes and resolution times. Which of those did your sheet count?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Answer slot per F4. Say what it counted in your own words. If resolution times were not in it, say so and say what you would measure first. | F4 is the JD's reporting line, and the material does not show which figures the sheet held. |
| B8 | "Coaching branch supervisors on escalations is part of this job. Have you coached anyone above teller level?" | JD | [grounded] "trained new tellers on our escalation script" | Answer slot per F5. If you coached any supervisor or senior colleague on escalations, say who and what you did. If not, say so and say how you would start. | F5. The JD names coaching supervisors, and your quote is about tellers. |

### Round C: panel of two branch managers (60 min, includes 20-min case, values scored)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A member disputes a fee. It has been through the branch twice and now comes to you. Walk me through the first hour." | CASE | [generic] | Clarify what outcome the member wants and what the branch already did. Then decide who owns the decision, what gets recorded, and what must escalate. Name the decision you would make first. | The 20-minute escalation case. It is a live problem and makes no claim about your past. |
| C2 | "A branch manager tells you these complaints belong to the complaints team, not to her. What do you do?" | CASE | [grounded] "trained new tellers on our escalation script" | Clarify what she means by "belong". Then agree who owns what, write it down, and go back to the member. Hold the position that the member's case has one owner. | The JD's "coach branch supervisors on escalations", asked as a live problem. The quote is only the nearest thing you have to a supervisor-facing process. |
| C3 | "Tell me about a complaint you read as a town's problem rather than a branch figure." | VAL | [grounded] "I handled the branch's formal complaints log" | Selection scaffold: pick a complaint that mattered beyond one member. If none comes to mind, say so plainly, then give the log you handled and how you would read it as a local problem. Do not invent a community detail. | Scored against Neighbours, Not Numbers. The honest branch is written in because the material has no such story. |
| C4 | "Tell me about a letter or explanation you rewrote so a member understood it first time." | VAL | [generic] | Selection scaffold: pick a time you explained something in plain words. If none comes to mind, say so plainly, then give the teaching you did: "trained new tellers on our escalation script." | Scored against Plain Words. The fallback quote is the teaching sentence, so the story stays within it. |
| C5 | "Tell me about a problem you found and kept hold of until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log" | Selection scaffold: pick a problem you found and held. If none comes to mind, say so plainly, then give the log you handled and what stayed open. | Scored against Own the Fix. The honest branch is the material's limit: a log is not a found problem. |
| C6 | "How would you know whether your monthly figures are right?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Name the weakest assumption you know of in the sheet. If you have not checked the figures against another source, say so plainly. | The data-driven probe on your headline output. The honest answer is the one you can repeat under a second question. |
| C7 | "Our digital team is building self-service for complaints. Where is the seam with branch work, and what would you need from them?" | JD | [grounded] "work with digital teams on self-service journeys" (the JD) | Answer slot per F8. If you have worked with a digital or product team, say what. If not, say so, then propose seam principles, not a claim. | A peer seam question, collegially framed. F8 is silent in the material, so the honest branch is the one that matters. |
| C8 | "Eight branches become five hubs during 2027. How do complaints stay with the member when a branch closes?" | CO | [grounded] "consolidate eight branches into five hubs over 2027" (strategy brief) | Propose principles: one case owner, a hand-over record, and a dated check with the member. Say what you do not know about the hubs. Do not claim an outcome. | The rubric asks for a strategy question. This one uses the brief's own consolidation, which the panel is likely to know well. |

## Requirement coverage

| JD requirement | Question IDs |
|---|---|
| 4+ years in financial-services customer operations | A1, A4 |
| Experience handling regulated complaints | A6, B2 |
| Confident presenting to senior leaders | B4 |
| Comfortable with Excel reporting | A7, B6 |
| Own the member complaints process end to end across branches and the contact centre | B3, A3, C1 |
| Report monthly on complaint volumes and resolution times | B7, C6 |
| Coach branch supervisors on escalations | B8, C2 |
| Work with digital teams on self-service journeys | C7 |

## Reverse questions

Each is paired with why it lands. No interviewer profiles were supplied, so these are role-generic.

**Round A (recruiter):**
1. "What does a good first 90 days look like for this role?" Why it lands: it shows you think about the job's shape, not the title.
2. "Roughly how many complaints does the role handle in a month today?" Why it lands: it asks for a number, not a story, and it tells you how much the role carries.

**Round B (Head of Member Services):**
3. "What would you need from me in the first month that would make the biggest difference?" Why it lands: it treats them as your manager and asks what they will do for you.
4. "Which kind of complaint will change most when the branches become hubs?" Why it lands: it ties your question to their current strategy, which the brief names.

**Round C (panel):**
5. "What does your branches' complaints team do that the process document does not say?" Why it lands: it asks for the unwritten practice, which branch managers know and documents often miss.
6. Reciprocity: "What could a new person do in their first month that would genuinely help your branches?" Why it lands: a peer-framed question that puts their needs first, which the panel scores as partnership fit.

## Sources

Provided documents: the JD text, your background in your message, the four values as pasted from ashgrovecu.org (copied 11 November 2026), the strategy brief summary in your message, and the recruiter's email with the three rounds.

**Research tier: L1, with 0 of 6 searches and 0 of 2 fetches.** Every target was fixed by pasted inputs, so no call was needed.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | The values cheat sheet. The four values are pasted, so the output is fixed by input. |
| 2. Ashgrove interview process | skipped | Loop structure and persona weights. The recruiter's email names the three rounds and the panel. |
| 3. Ashgrove strategy / recent news | skipped | The grounding brief. The pasted strategy brief supplies current priorities. Recent news was not checked. |
| 4. Interviewer name + Ashgrove | n/a | No names yet. The interviewer read is absent, and the upgrade menu says what a name would unlock. |
| 5. Representative JD for the role | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions. |

## Upgrade menu

- The complaints spreadsheet's column headings, with no data → F4 and F7 get quoted columns, and B7 gets a sourced answer.
- Panel members' names → per-member persona weights in Round C.
- The Head of Member Services' name → Round B reverse questions and weights from public footprint.
- Prep time before 20 November → a prioritised prep schedule.
- Deep research (L2) → current Ashgrove news and recent moves, checked against the brief.
- A complaint you resolved from start to finish, if one happened → a quoted row for F3, which turns its answer slot into a story.
