Your prep pack is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-alone-part-2-rooms-case-7-denied-46d32f46/1bd881cd-1a5c-4815-bf76-40448309e563/scratchpad/saltmarsh_live_operations_producer_interview_pack.md`. It has 20 questions across six personas, a fit snapshot against your JD, a list of claims not to coach, and reverse questions for Tobias.

Two things to know before you read it:

- **No research ran.** The web searches were refused by the session's permissions, so the pack uses only your message. Tobias's background, Saltmarsh's values and its interview format are all missing. The upgrade menu at the end of the file says what each would add.
- **I assumed a hiring-manager round.** If Friday is a peer conversation, the persona weights shift.

The biggest gap is in-app purchases, so B1 is the question to rehearse hardest. Your sentence "never worked on a game with in-app purchases" is the one to say plainly, then follow with what you have done and a plan for what you would learn first. The pack flags two other gaps too: running two titles, and the post-event review and KPI ownership, since your material shows you presented retention numbers but not that you owned the review.

Say the word and I'll play the Skeptic on B1. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

Is Friday a one-to-one with Tobias, or a panel? The answer reweights every bank.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh_live_operations_producer_interview_pack.md -----
# Interview pack: Live Operations Producer, Saltmarsh Games

**Interviewer:** Tobias Wrenfield, Head of Live Operations. Relationship assumed to be hiring manager (not confirmed).
**Round:** 60 minutes, Friday. Format not stated.
**Research:** none ran. Both web searches were refused by the session's permissions, so this pack is built from your message alone. See Sources.

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored.
- Type key: **VAL** behavioral and values; **EXP** your own experience, probed for what you actually did; **JD** the role's stated needs, including your gaps; **CO** company knowledge; **CASE** a live problem from the role.
- Guidance is scaffolding, not a script. Say it in your own words. Anything in the guidance that is not in your own quoted sentences is a prompt to think, not a fact to say.
- Every claim about your past is either a sentence you wrote, quoted below, or an answer slot: a question you answer truthfully from your own experience, with both branches allowed.

## The fit snapshot

Requirements are quoted from your JD. Your evidence is quoted from your message. Only those quotes may be used as your experience.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | transferability | Your material shows one main title and weekly content drops, not two titles or live events. Keep the words as they are: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: the JD names two titles, so expect a probe on how you would split a calendar across them. If you have ever run more than one calendar, say which; if you have not, say so and describe how you would plan the second. |
| F2 | "experience running a content calendar" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | none | Reaches the requirement directly. Expect a probe anyway, because it is a line with nothing inspected behind it. Name the calendar, the cadence and the title; that is the proof you have. |
| F3 | "manage the release checklist with QA" (JD) | "Wrote the release checklist our QA team still uses." (your message) | medium | [grounded] | none | Reaches the requirement. Keep to the quote: "I wrote the release checklist our QA team still uses." Expect a probe on whether you maintain it or wrote it once; say what you know about its current state. |
| F4 | "comfortable with player-retention metrics" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | medium | [grounded] | presentation | Your material already reaches this in other terms; the bridge only rewords it: "I presented the monthly retention numbers to the studio head." It adds no figure, method or result. |
| F5 | "own the post-event review and the KPIs it reports" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | low | [inferred] | transferability | The quote carries reporting, not ownership. Your material does not show a post-event review or who set the KPIs. Pack's observation, not words for you: the material shows reporting retention, not owning the review. Answer slot: if you ran a review after an event or chose which KPIs were reported, say what you did in your own words; if neither was yours, say so plainly and stay with the monthly retention report. |
| F6 | "coordinate design, art, engineering and community teams on each update" (JD) | none given (your message) | none | [grounded] | discovery | Your material does not show coordination with design, art, engineering or community. Answer slot: if you coordinated any of those teams on a content drop, say which and what you did in your own words; if you did not, say so plainly and describe how you would coordinate them on an update. |
| F7 | "3+ years producing live-service games or apps" (JD) | "4 years as associate producer at a puzzle-game studio." (your message) | medium | [grounded] | transferability | Four years and a puzzle-game studio reach the years. The title and the puzzle game do not by themselves show live-service producing. Bridge: "4 years as associate producer at a puzzle-game studio." Answer slot: the JD asks for live-service, so expect a probe on whether that work was live-service in the sense of ongoing updates. If the content calendar was that work, say what it was; if not, say so. |
| F8 | "clear written communication" (JD) | "Wrote the release checklist our QA team still uses." (your message) | medium | [grounded] | presentation | The quote reaches the requirement in other terms: a written artifact others use. The bridge only rewords it: "I wrote the release checklist our QA team still uses." It adds no claim about clarity beyond that. |
| F9 | [generic] Monetization-related KPIs for a mobile live-ops role (role-family pattern, not in the JD) | "never worked on a game with in-app purchases." (your message) | none | [grounded] | capability | A negative you stated, so it can be said back as a plain acknowledgment: "I haven't worked on a game with in-app purchases." Any learning plan is said as a plan, never as past experience. No answer slot, because the requirement is generic. |

## Prohibited claims

Built from the fit snapshot before the banks were written. These are not to be coached, in any cell.

| Not coached | Basis | Honest form |
|---|---|---|
| Ran the live-events calendar for two titles | Inflated form of F1 | F1's quote at its own scope. The pack's observation: the material shows one main title's content calendar. A1's and B2's slots stay inside that calendar. |
| Led a team, or managed people | Sourced negative: "Never led a team" | Plain acknowledgment: "I've never led a team." No slot about having done it. |
| Owned the post-event review, or set the KPIs | Inflated form of F5 | F5's quote at its own scope: presented monthly retention numbers. The slot asks only what you did. |
| Ran monetization or in-app purchase work | Sourced negative, F9 | Plain acknowledgment: "I haven't worked on a game with in-app purchases." No slot about having done it. |
| Owned the release process with QA | Inflated form of F3 | F3's quote at its own scope: "Wrote the release checklist our QA team still uses." |

## Persona weights

Relationship prior: hiring manager, so Case/Strategist and Skeptic lead. No interviewer profile was available, so there is no interviewer read; the weights rest on the round-type prior and the JD. If the round turns out to be a peer conversation, Peer and Prober move up.

| Persona | How it shows up | Weight, with reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist | Live problems from the calendar and a metric drop | 5. A hiring manager buys capability on the actual job, and the JD is almost all process and planning. | Clarify, then structure, then name the metric before the figure. Use the calendar you ran as the nearest case. |
| Skeptic | Your gaps, put as questions: two titles, purchases, leadership | 4. Your stated gaps are the obvious probes, and the JD's scope makes them sharper. | Say the gap plainly, bridge only from quotes, and give a plan for closing it, said as a plan. |
| Data-Driven Prober | Retention figures and what "owning" a KPI means | 4. Your retention presentation is a headline claim, and the JD asks for KPI ownership. | Say how the figure was counted if you know, and say so if you do not. Name the weakest assumption first. |
| Pressure | Hold and concede on your strongest claims | 3. Mid-weight for a hiring manager; likely on the purchase gap and the checklist. | Pause, restate, hold through two follow-ups, concede the specific gap. |
| Conversational | A casual opener that is scored | 2. Likely at the start, and easy to undersell. | A 90-second arc from your quotes, in order. |
| Peer | Seams with design and engineering | 2. Likely in the coordination area. | Name the seam concretely and state a principle for disagreement. |

Values/Behavioral is not weighted. No values round was detected, no loop source established the loop, and the generic archetype reads no values round.

## Question banks

Provenance comes first in each row. Your quoted sentences are what the guidance may say about you. Answer slots are instructions for the answer, not questions to me.

### A. Case/Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You'd be planning live events for two of our mobile titles. How would you set up the calendar for the next quarter?" | CASE | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Clarify before you structure: each title's update cadence, what the team can absorb, and which dates are fixed by partners or the platform. Then lay out one calendar with both titles in view: shared design and art capacity, a QA gate before each release, and one metric per event decided before it ships. Name the calendar you have run as the nearest thing, say which parts carry over, and say which would change with a second title. Do not claim you have planned two. | The JD's first line is the raising source. CASE because it is a live problem from the role. The quote is the only thing you may say about your past. |
| A2 | "Walk me through one live update, from the first design idea to the post-event review." | CASE | [grounded] "Wrote the release checklist our QA team still uses." | Structure it: scope and goal; the design, art, engineering and community handoffs; the QA gate; release; then the review that scores the update against its goal. Keep the review specific: what was measured, what it was compared with, and what changes next time. Where you name the checklist, use its quoted scope only. | JD raises the update flow. CASE because the question is hypothetical. The quote lets you name the checklist at its own scope. |
| A3 | "Suppose retention dropped 15 percent in the week after an update. What do you check first?" | CASE | [generic] | Clarify the cohort definition and the date window. Then separate the update from confounds: other releases, marketing, seasonality, a bug or a platform change. Name the weakest assumption in your first read before anyone else does. Say what would change your mind. | Retention is in the JD. This is the Case persona's metric stem. A hypothetical, so no claim about your past. |
| A4 | "A designer is out for six weeks in the middle of the quarter. What do you cut?" | CASE | [generic] | Clarify which updates depend on that designer and what is already locked with partners. Then rank: what must ship, what can move, what can be scoped down, and who you tell first. Say the trade-off aloud with the cost of each option. | A calendar trade-off on the JD's coordination line. No past claim needed. |
| A5 | "Show me how you'd write up a post-event review for an update that missed its target." | CASE | [grounded] "Presented the monthly retention numbers to the studio head." | Structure the write-up: target and actual, one line each; what you believe caused the gap and how sure you are; what you would change; who owns each change. Keep it to one page. Name the monthly retention presentation as the nearest thing you have, and say what the write-up adds to it. | The JD's post-event review line and "clear written communication" both score here, as a written task. |

### B. Skeptic (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | **Highest-ROI prep.** "You haven't worked on a game with in-app purchases. How would you get up to speed before your first update?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Say it plainly first: "I haven't worked on a game with in-app purchases." Then the nearest thing you do have: the retention figures you presented and the calendar you ran. Put the learning plan in the future tense: what you would read, which numbers you would ask for, who on the team you would ask. Hold through two follow-ups by returning to what you have done. If pressed, concede the specific gap. Never imply you have done purchase work. | Rehearse this most. The gap is the one a live-ops hire at a mobile studio is most likely to be tested on, and the question presupposes only your own sourced negative. |
| B2 | "You ran one main title's calendar. This role covers two. What is your honest answer?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Answer at the quote's scope first: one main title, weekly, for two years. Then say what you would do first with a second title: learn its cadence, its retention baseline and its team's capacity before you move any date. Hold through two follow-ups. Do not claim you have split a calendar. Concede the part you have not done. | F1's inflated form is the risk. The honest answer is the quote's scope plus a plan. JD line one is the raising source. |
| B3 | "I don't see people leadership in your background. How would you coordinate design, art, engineering and community on an update, when you would manage none of them?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." [grounded] "Wrote the release checklist our QA team still uses." | Say the stated negative plainly: "I've never led a team." Then how you would coordinate without authority: agree the calendar, the gates and the decision owner up front. Name the checklist only at its quoted scope, as process doing some of the coordinating. Answer slot: if you coordinated design, art, engineering or community on a content drop, say which and how; if you did not, say so plainly and describe your plan. Concede the leadership gap without apologising for it. | The JD's coordination line is the raising source. The leadership negative is yours. Coordinating without authority is the probe the role invites. |
| B4 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Name the weakest part in one sentence, using one of your own stated gaps. Say what you would do in the first 30 days to close it, said as a plan. Do not add a third gap to look modest. | Skeptic stem. The answer draws only on the two negatives quoted here and in B1 and B3. |

### C. Data-Driven Prober (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the monthly retention numbers you presented were counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Answer slot: say how the figures were counted, in your own words. If you know the cohort definition and the window, say them. If you did not define them, say so plainly. Name the assumption behind them that you would defend least, before the second question. If none of the counting was yours, say that too. | A headline claim is where a prober starts. A figure you gave raises the defend-the-number slots, which is why the guidance asks how it was counted and not for a method. |
| C2 | "How did you tell whether a content drop had worked?" | EXP | [inferred] "Presented the monthly retention numbers to the studio head." | Open prompt. Answer slot: say what you looked at after a drop, if anything, and against what. If you did not measure drops one by one, say so plainly, and say what you would measure first. Do not describe a review you did not run. | F5 is low confidence, so the provenance is inferred; the guidance asserts no review. The JD's post-event review line is the raising source. |
| C3 | "Retention is a lagging metric. How would you know within a week that an update was working?" | JD | [generic] | Name the leading signals: early engagement with the new content, completion of the event's first session, and the cohort you would compare against. Say what you would not conclude yet. | JD retention requirement. The prober tests metric thinking, not history. |
| C4 | "Which KPI would you stop reporting if you could report only three?" | JD | [generic] | Pick the KPI you would drop because it changes least with decisions, and say why. Name the one you would keep and the one you would add. Say which assumption behind your choice you would defend least. | Prober stem on the JD's "the KPIs it reports" line. |

### D. Pressure (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why should we hire someone with no in-app purchase experience over someone who has run live purchase offers?" | JD | [grounded] "never worked on a game with in-app purchases." | Pause, then restate the question in your own words. Hold the position you can state: the calendar you ran and the reporting you have done. Concede the purchase gap in one specific line, and say what you would close first. Do not fold on the core claim to restore the mood, and do not offer experience you do not have. | Hold-then-concede. The comparison is the interviewer's. The premise is your own sourced negative only. |
| D2 | "That retention presentation. How much of it was actually you?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Answer slot: say which part was yours, presenting, or also producing the numbers. If someone else produced them, say so and say what you did with them. If you did not produce the analysis, do not claim it. | The attribution probe. The honest branch is whichever is true. |
| D3 | "You wrote the QA checklist. Why would QA still need it, when they run their own tests?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Hold that the checklist is one QA still uses. Say what it covers and what it does not, in your own words. If you do not know what QA's own tests cover, say so; do not argue for their process. Concede where the checklist is weak if they show you. | Hold-then-concede on a headline item. The "run their own tests" premise is the interviewer's challenge, not a fact about you. |

### E. Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So walk me through the journey. How did you end up producing?" | EXP | [grounded] "4 years as associate producer at a puzzle-game studio." | A 90-second arc in this order: the four years as associate producer at a puzzle-game studio, the calendar, the checklist, the retention reporting. Use only those beats, in your own words. End on what you want next. | A casual opener is still scored. The arc uses only your quoted sentences. |
| E2 | "What's a live mobile game you play closely, and what would you change about its calendar?" | CASE | [generic] | Pick one title you know well and describe the calendar you see from outside: cadence, event types, what repeats. Propose one change and its cost. Stay with what you can see as a player. | Casual on the surface, but the calendar question is scored. No claim about your past. |

### P. Peer (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Designers and engineers often see a producer as the bottleneck. Where do you expect that seam to be on an update, and what happens when you disagree?" | JD | [generic] | Name the seam concretely: sign-off points and dependencies, not personalities. State a principle for disagreement: decide on the goal and the date, escalate once, write the decision down. Do not claim a disagreement you resolved unless you have one to tell. | Peer seam on the coordination line. A principle-level answer, with no claim about your past. |
| P2 | "When a content drop went well, whose work was that?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Answer slot: credit goes to the people who made the content. Say what you did to make the calendar hold. If others did parts you did not own, name them; if you did the calendar work alone, say so plainly. Do not credit yourself with art or engineering work. | Credit probe. The answer depends on the scope of the calendar quote. |

**Requirement coverage**

| JD requirement | Covered by | Note |
|---|---|---|
| Plan and run the live-events calendar for two titles | F1: A1, A2, B2 | |
| Coordinate design, art, engineering and community teams | F6: B3, P1, A2 | |
| Own the post-event review and the KPIs it reports | F5: C2, A5, C4 | |
| Manage the release checklist with QA | F3: A2, D3 | |
| 3+ years producing live-service games or apps | F7: B4, E1 | |
| Experience running a content calendar | F2: E1, P2 | |
| Comfortable with player-retention metrics | F4: C1, C3, D2 | |
| Clear written communication | F8: A5 | |

## Reverse questions

Each has a reason it lands. No interviewer profile exists, so these are role-generic.

1. "What does a good quarter look like for these two titles, and how is it judged?" Why it lands: it asks about outcomes and KPIs before activity.
2. "How are design and art capacity split across the two titles today?" Why it lands: it shows you are planning around the real constraint.
3. "What did the last post-event review change?" Why it lands: it asks about decisions, not reports.
4. "What would the first 90 days need to deliver for whoever you hire into this role?" Why it lands: it signals you are thinking about ownership.
5. "What has changed in the release checklist since it went live?" Why it lands: it shows you know the checklist exists and care how it is kept.
6. "Who would I work with most closely on an update, and how do they like to be asked?" Why it lands: it shows you are thinking about the cross-functional work the JD describes.

## Sources

**Provided documents:** your message (the JD text, your background, the interview details).

**Searches sent:**
- "Saltmarsh Games mobile studio": refused by the session's search permission. A general company query, outside the named targets.
- "Tobias Wrenfield Head of Live Operations Saltmarsh Games": refused by the session's search permission.

**Research tier:** L0. Research was intended to run at L1 by default, but both search calls were refused, so no page was read or fetched.

**Target accounting**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | unavailable | No values page was read, because the search was refused. Would have moved section 10 of the template, the values cheat sheet, if a values round is detected. |
| 2. Saltmarsh Games interview process, live operations | unavailable | No call was sent for this target, and the search permission was refused. Would have set the loop structure. Without it, persona weights use the round-type prior. |
| 3. Saltmarsh Games strategy and recent news | unavailable | No call was sent for this target, and the search permission was refused. Would have fed the CO bank; the CO bank is absent. |
| 4. Tobias Wrenfield, Saltmarsh Games | unavailable | The query was refused. Would have produced the interviewer read, persona weights from public footprint, and a tailored reverse question. |
| 5. Representative live-operations producer JD | skipped | You supplied the JD, which fixes the fit snapshot and the JD-tagged questions. |

**Dossier:** none present.

## Upgrade menu

- Allow web search, and I'll run the L1 targets for the company and for Tobias: values, interview process, strategy and the interviewer's public footprint. This would also give you the interviewer read and a tailored reverse question.
- Paste Saltmarsh's values page or interview guide → a values cheat sheet, and the loop structure.
- Paste recent Saltmarsh news or a strategy note → CO questions for the differentiator bank.
- The names of the two titles and their genres → sharpens A1 and A3.
- A post-event review or KPI sheet you wrote → F5 moves from low to medium, and C2 and A5 get stronger.
- Your recruiter's prep email → coverage of any deliverable they name.
- A deeper research pass, offered once: up to 6 more searches and 2 more fetches, several more minutes. Want it?
