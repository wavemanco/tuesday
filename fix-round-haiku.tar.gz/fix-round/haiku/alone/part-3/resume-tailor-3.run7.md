I'll load the resume-tailoring skill, then find the dossier file.
The skill is loaded. Before I build the ledger, I need its row shape and audit rules. I'll read those references, and I'll also check whether the dossier file exists on disk.
I built the ledger from the CV and dossier excerpt you pasted. The dossier file itself wasn't on disk where I looked, so I'm relying on the excerpt. Nothing below is applied. Every row waits for your approval.

## Coverage map

The posting marks only the PM years as must-have. I've treated the rest as important.

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| 1 | 3+ years in product management | must-have | not_evidenced | Adjacent only: seven years of solutions and implementation work, no PM title. Recovery is a named absence. | `[grounded]` CV; dossier R1 |
| 2 | Shipped API or platform products | important | not_evidenced | Adjacent: 30+ integrations of your REST APIs, delivered from the client side. No product shipping is evidenced. Recovery: C2. | `[grounded]` CV; dossier R2 |
| 3 | Technical fluency | important | already_evidenced | "Comfortable in Postman, SQL, OpenAPI specs." Stays as written. | `[grounded]` CV |
| 4 | Stakeholder management | important | surfaced_by_edit | E2 (client feedback sessions) and E3 (client integrations). | `[grounded]` CV |
| 5 | Own the roadmap for the partner API platform | important | not_evidenced | You collected roadmap input. Prioritisation authority is not evidenced (dossier R1). Recovery: C1. | `[grounded]` CV; dossier R1 |
| 6 | Discovery with integration partners | important | surfaced_by_edit | E2 shows client feedback collection, not discovery research. Partial. | `[grounded]` CV |
| 7 | Write specs and drive delivery with two engineering squads | important | not_evidenced | E1 is documentation of integration practice, not product specs. Recovery: C2. | `[grounded]` CV |
| 8 | Define adoption metrics | important | not_evidenced | Nothing in the CV. Recovery: C3. | `[grounded]` CV |

## The edit ledger

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Role description | *(not on its own line; I didn't receive the exact current wording)* | "Wrote the internal integration playbook the whole team uses." | surface | "Wrote the internal integration playbook the whole team uses." | `[grounded]` CV; dossier edit E1 | pending your approval |
| E2 | Role description | *(not on its own line; exact current wording not received)* | "Ran quarterly roadmap-input sessions collecting client feedback for product." | surface | "Ran quarterly roadmap-input sessions collecting client feedback for product." | `[grounded]` CV | pending your approval |
| E3 | Role description | "Led 30+ client integrations of our REST APIs end to end." | Same sentence, moved to the top of the role | reorder | "Led 30+ client integrations of our REST APIs end to end." | `[grounded]` CV | pending your approval |

E1 is the dossier's pending edit, and I audited it again against your sentence. Position and wording are unchanged. Nothing else in the CV is touched. The tools line is left alone, since it is already evidenced.

## Recovery for gaps

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Own the roadmap for the partner API platform (row 5) | important | Roadmap-input sessions that collect client feedback | Roadmap ownership is the core of this role, and it is the first thing a PM interview probes | Quarterly roadmap-input sessions: did you decide which requests went in, or pass them to product? | A roadmap-input summary, a backlog export, or a note of a call you made | `[grounded]` CV; `[generic]` roadmap ownership is usually probed first in PM interviews |
| C2 | Shipped API products; write specs and drive delivery (rows 2 and 7) | important | Playbook authorship; 30+ integrations delivered client-side | Both requirements ask for work on the product itself, not its integrations | The 30+ integrations, if any changed the API: a spec you wrote or reviewed, a versioning or deprecation decision, a fix you drove with engineers | A spec, ticket, changelog entry, or release note | `[grounded]` CV; `[generic]` PM postings of this kind usually expect product-side artefacts |
| C3 | Define adoption metrics (row 8) | important | No metrics | The posting names adoption as an owned responsibility | Across the 30+ integrations: time to go live, which clients kept using the APIs, any adoption counts you tracked | A tracker, dashboard, or summary you sent to someone | `[grounded]` CV |

**Named absence, row 1 (3+ years of PM).** You have never held a PM title, and seven years of solutions work does not count as product management, so no edit can close this. Closing it takes years in a PM-titled role, which this application cannot do. The honest route is to apply to roles that describe what you have done, such as integration-led roles. If C1 comes back with real prioritisation authority, that is your strongest adjacent case, but it still does not add the years.

## Prohibited claims

Not written, and why:

- **"Product Manager" in the role header.** You have never held the title, and the posting asks for it.
- **"Owned the roadmap" or "set priorities."** You ran input sessions. Dossier R1 marks ownership and prioritisation authority as not evidenced.
- **"Built an internal request-triage tool."** Rejected in the dossier. You could not confirm ownership. Carried over unaltered.
- **"Worked with a partner API platform as a customer."** Rejected in the dossier. You worked vendor-side. Carried over unaltered.
- **"Wrote OpenAPI specs."** Your CV says you are comfortable in them. It does not say you wrote any.
- **"Defined" or "tracked adoption metrics."** Nothing in the CV supports either.
- **"Discovery" or "partners."** These are the posting's words. Your CV says "collecting client feedback" and "client". Changing either moves which side of the table you sat on.
- **"Drove delivery with two engineering squads."** Not in the CV.

## Parse-safety check

Not run. I only had pasted text, not a resume file, so the file-based checks (layout, columns, headers, hidden text) could not be performed. Nothing in the pasted text looked hidden.

## Upgrade menu

- **Proposal (x): a work sample.** A copy of the integration playbook, a roadmap-input summary, or one integration write-up would let E1 cite a document rather than a sentence. It could also answer C2 and C3 directly.
- **Proposal (x): the resume file.** Sending the .docx or PDF would let me run the parse-safety check that I couldn't perform here.

## Questions

**C1 — Roadmap.** In the quarterly roadmap-input sessions, did you decide which requests went into the roadmap, or did you collect them and pass them to product?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**C2 — Product side.** Beyond the client integrations, did you touch the API product itself? For example, writing or reviewing specs, making versioning or deprecation calls, or working with engineers on changes that shipped.
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**C3 — Metrics.** Across the 30+ integrations, did you track anything, such as time to go live or which clients kept using the APIs? Did you define what should be measured?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

To approve, reply with row numbers, for example "Approved: E1, E2, E3".

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.