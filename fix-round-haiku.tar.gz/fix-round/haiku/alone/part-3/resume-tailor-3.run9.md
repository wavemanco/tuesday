I drafted the ledger from your message and the dossier excerpt. Nothing is applied yet, and every row is pending your approval.

Two limits on this draft:
- I couldn't open `tuesday-dossier.md` from disk because a file lookup was refused. I used the excerpt you pasted.
- Your CV came to me as a summary, not as the document. The "Traces to" quotes are your sentences from your message. If you paste the CV text, I'll re-check every quote and current line against it word for word.

## The edit ledger

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience | "Wrote the internal integration playbook the whole team uses." | Same sentence, on its own line | surface | "Wrote the internal integration playbook the whole team uses." | `[grounded]` your message; dossier edit E1 | pending your approval |
| E2 | Summary | (no current line) | "7 years solutions engineer / implementation lead at an enterprise software vendor. Led 30+ client integrations of our REST APIs end to end." | merge | "7 years solutions engineer / implementation lead at an enterprise software vendor."; "Led 30+ client integrations of our REST APIs end to end." | `[grounded]` your message | pending your approval |
| E3 | Experience | "Ran quarterly roadmap-input sessions collecting client feedback for product." | Own bullet, wording unchanged | surface | "Ran quarterly roadmap-input sessions collecting client feedback for product." | `[grounded]` your message | pending your approval |

E2 keeps your two sentences separate and keeps your verbs. "Led" stays "Led", and "client" stays "client". E3 keeps "input" and "for product" because they are what limits the claim.

Your current title, "Solutions engineer / implementation lead", stays as it is.

## Coverage map

Priority follows the posting. Only the PM requirement is marked must-have there, so the rest are marked important.

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| 1 | 3+ years PM | must-have | not_evidenced | No PM role. Adjacent: E2, E3. Recall C1. | `[grounded]` your message: "Never held a PM title." |
| 2 | Shipped API or platform products | important | not_evidenced | Adjacent: E2 (client integrations of your REST APIs). You shipped integrations, not a product. Recall C1. | `[grounded]` your message |
| 3 | Own the roadmap for the partner-facing API platform | important | not_evidenced | E3 shows input to product, not ownership. Recall C1. | `[grounded]` your message |
| 4 | Run discovery with integration partners | important | not_evidenced | Nearest is E3, but collecting client feedback is a different kind of work from discovery. Named absence below. | `[grounded]` your message |
| 5 | Write product specs | important | not_evidenced | Your text has the playbook (E1) and OpenAPI fluency, not product specs. Named absence below. | `[grounded]` your message |
| 6 | Drive delivery with two engineering squads | important | surfaced_by_edit | E2 covers end-to-end delivery. The squads are not in your text. | `[grounded]` your message |
| 7 | Define adoption metrics | important | not_evidenced | Nothing on measuring integrations after go-live. Recall C2. | `[grounded]` your message |
| 8 | Stakeholder management | important | surfaced_by_edit | E2 and E3 show client-facing work. The term itself is not claimed. | `[grounded]` your message |
| 9 | Technical fluency (Postman, SQL, OpenAPI) | important | already_evidenced | As written: "Comfortable in Postman, SQL, OpenAPI specs." | `[grounded]` your message |

## Recovery for the gaps

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | 3+ years PM; roadmap ownership; shipped products | must-have | Input to product (E3). No decisions you owned are stated. | The screen will look for decisions you owned: what got built, what waited, and why. `[generic]` | A sprint, release or client request where you chose what shipped or deferred it; a feature you pushed to a later version | Release note, roadmap doc, scope email, backlog screenshot | `[grounded]` your message; `[generic]` the screen-test point |
| C2 | Define adoption metrics | important | Nothing on how integrations were measured after go-live. | The posting makes this part of the job, not a side task. `[generic]` | Go-live checklists you tracked; usage figures you reported to a client; time-to-first-call numbers | QBR slides, go-live tracker, usage exports | `[grounded]` your message; `[generic]` the posting point |

**Named absences:**
- **Discovery with integration partners.** Discovery as a practice, meaning research interviews and problem framing, is not in your text. Your client-feedback sessions are the nearest fit, and the resume has to describe them as collecting input.
- **Product specs.** Your text shows no spec you wrote that a team built against. Closing this would take a spec you designed and shipped against, such as an OpenAPI spec for a client-facing endpoint. If that doesn't exist, the gap stands.

## Not written, and why

- **"Product Manager" or any PM title.** You have never held one, and the posting makes it a must-have.
- **"Owned the roadmap" or "set priorities".** Your text shows you ran input sessions for product. Owning the decision is a different job, and an interviewer will test it.
- **"Shipped API products".** You led integrations of the vendor's REST APIs. Those are not products you shipped.
- **"Discovery" or "partners".** These are the posting's words. Your words are "client" and "client feedback", and changing them moves which side of the table you were on.
- **"Adopted company-wide" from "the whole team uses".** That widens the scope of the playbook beyond what you said.
- **"Stakeholder management" as a claimed skill.** Your text shows client-facing work. It doesn't use the term.
- **"Built an internal request-triage tool".** Rejected in the dossier: memory lead, and you could not confirm ownership.
- **"Has been the customer of a partner API platform".** Rejected in the dossier: you worked vendor-side.

## Parse-safety check

No resume file was supplied, so I could not run the file-level check. The proposed lines are plain text with no tables or columns.

## Options (proposals, built only if you approve)

- **Mock-interview:** a practice session on the PM-decision questions in C1. This is the sibling skill, named once.

**Questions**

C1 — Did you ever decide what an API release, feature, or client request would include, or defer something someone else wanted? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

C2 — After a client's integration went live, did you track anything about whether it was used, such as active calls, time to first call, or a go-live checklist? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.