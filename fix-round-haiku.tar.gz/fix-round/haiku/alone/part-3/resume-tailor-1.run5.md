I built the ledger from the facts in your message, since the full CV text wasn't pasted. Each row quotes your sentences exactly, so if your CV wording differs, paste it and I'll re-trace the rows. No dossier was present. Every row is pending your approval, and nothing has been applied.

## Edit ledger

| # | Section | Current line (your sentence) | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| L1 | Summary (new) | *(none)* | Senior Software Engineer, 7 years. Currently at a payments company: Go and Rust daily for 4 years, Python before that. | `merge` | "Senior Software Engineer, 7 years. Currently at a payments company. Go and Rust daily for 4 years, Python before that." | `[grounded]` your CV facts | pending your approval |
| L2 | Experience | "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak." | Same text, moved to the top of Experience. | `reorder` | "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak." | `[grounded]` | pending your approval |
| L3 | Experience | "Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer." | Same text, moved above the service bullet. | `reorder` | "Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer." | `[grounded]` | pending your approval |
| L4 | Experience | "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | On-call rotation every fourth week for two years. I've run six incidents as incident commander. | `split` | "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | `[grounded]` | pending your approval |
| L5 | Experience | "I do onboarding for new hires on my team — usually two or three a year, I pair with them for their first month." | Usually onboard two or three new hires a year on my team, pairing with them for their first month. | `compress` | "I do onboarding for new hires on my team — usually two or three a year, I pair with them for their first month." | `[grounded]` | pending your approval |
| L6 | Skills | "CV also lists: Kafka, Postgres, Terraform, gRPC, Datadog." | Kafka, Postgres, Terraform, gRPC, Datadog (in a Skills line near the top). | `surface` | "CV also lists: Kafka, Postgres, Terraform, gRPC, Datadog." | `[grounded]` | pending your approval |

L1 is the only row with no predecessor, so every clause of it traces to your sentence. It keeps your title and does not add "backend", which your material never states.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| 1 | 5+ years backend | must-have | surfaced_by_edit | L1 gives 7 years as Senior Software Engineer. It doesn't say how many were backend. See Q1. | `[grounded]` |
| 2 | Production Go | must-have | surfaced_by_edit | L1 (Go daily for 4 years), L2 (owns services) | `[grounded]` |
| 3 | Distributed systems at scale | must-have | surfaced_by_edit | Partial. L2 gives the 40k/min scale and L6 lists Kafka. "Distributed" is never stated. | `[grounded]` |
| 4 | Design and ship high-volume Go services | important | surfaced_by_edit | L2 | `[grounded]` |
| 5 | Drive down p99 latency | important | surfaced_by_edit | L3. The work was on the balance-read path, not a build cache. | `[grounded]` |
| 6 | Own on-call for your services | important | already_evidenced | The on-call sentence as written | `[grounded]` |
| 7 | Strong incident response | must-have | surfaced_by_edit | L4 (six incidents as commander). The record supports the count and role, not "strong". | `[grounded]` |
| 8 | Mentor mid-level engineers | must-have | surfaced_by_edit | Partial. L5 shows pairing with new hires for a month. No mid-level mentoring is stated. See C1. | `[grounded]` |
| 9 | Partner with product on roadmap sequencing | important | not_evidenced | Nothing in your material. See C2. | `[grounded]` |
| 10 | Build-cache platform domain | important | not_evidenced | Named absence below | `[grounded]` |

## Recall prompts

**C1 — Mentoring mid-level engineers (row 8, must-have).** Your resume shows onboarding and pairing with new hires. It doesn't show anyone past onboarding, or any engineer above new-hire level.
- *Why it matters:* the JD lists mentoring as a requirement and names mid-level engineers as the audience.
- *Experience that may count:* pairing a mid-level engineer on a project; coaching someone through code review; running a growth plan with a colleague.
- *Useful evidence:* a review record, a growth-plan note, or a thread where you coached someone.

**C2 — Roadmap sequencing with product (row 9, important).** Nothing in your material touches product or roadmap work.
- *Why it matters:* the JD makes this an ownership duty, and a reader won't find it.
- *Experience that may count:* deciding build order with a PM; trading reliability work against feature work; scoping a quarter's technical roadmap.
- *Useful evidence:* a planning doc, a roadmap, a ticket thread with product.

**Named absence — Build-cache platform (row 10).** Your CV has no build-system or developer-tools work. The cache-layer rework (L3) is the nearest match, and it stays labelled as balance-read. I see no way to close this by editing the CV. The honest approach is to name it in the application rather than imply it.

## Prohibited claims

Not written, and why:
- **"Senior backend engineer" or "5+ years backend"** — your material gives 7 years of engineering and doesn't say how many were backend.
- **"Distributed systems" as a stated claim** — the record shows scale and Kafka, not the word.
- **"Strong" incident response** — the record shows the count and role. "Strong" is a judgement the sentence can't make.
- **"Mentored mid-level engineers"** — you onboarded and paired with new hires. The level and the mentoring relationship aren't in your material.
- **"Partnered with product on roadmap"** — nothing in your material supports it.
- **Build-cache experience** — the cache work was on balance reads in payments.
- **The 380ms → 95ms result applied to the platform as a whole** — the number belongs to the balance-read path only.
- **Depth in Kafka, gRPC or Terraform** — L6 lists them as tools you use, not as areas you own.

## Parse-safety check

You pasted text rather than sending a file, so I could not check layout, columns, tables, or headers. Once you have the file, I can run the check. For the lines proposed here, use conventional headings: Summary, Experience, Skills.

**Offer (not built):** once you've approved rows, I can draft a short cover note using only those rows. Say if you want one.

**Questions**
- **Q1 (row 1):** How many of your 7 years were backend work? A figure with the scope would let row 1 move from partial to evidenced.
- **C1:** Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.
- **C2:** Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.