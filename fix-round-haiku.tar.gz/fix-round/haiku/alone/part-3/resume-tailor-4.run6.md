This is a resume-tailoring request, so I'll load the resume-tailor skill first.
## Keyword matching is probably not the main cause

Keywords may affect ranking, but the evidence doesn't make them the main cause of rejection. A résumé-builder vendor interviewed 25 recruiters, and it says the findings are themes rather than nationally representative statistics. Two of those 25 had content-based auto-rejection configured (C25). The same source says: "When automated filters are used, they’re almost always knockout questions" (C26). Those are yes/no eligibility checks on the application form, and this skill doesn't change them. Keywords mostly affect order: "Many teams use match scores/filters to prioritize who gets reviewed first" (C27).

Your résumé also doesn't show most of what the posting names: Terraform, Argo CD, Istio, Vault, Helm, Prometheus, Grafana and Go. Your Kubernetes work was a proof-of-concept. Keyword placement can make you easier to find, but it can't cover that gap. Whether to apply anyway, given possible knockouts and the gap, is job-underwriter's call.

**Caveat on sources:** your PDF wasn't attached, so the trace quotes below are verbatim from your message, not from the file. Check each one against the PDF before you approve it.

## Edit ledger (all pending your approval)

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Skills or Experience | Ran a Kubernetes proof-of-concept for two months last year — never went to production. | Kubernetes proof-of-concept (two months); never went to production | surface | "Ran a Kubernetes proof-of-concept for two months last year — never went to production." | [grounded] resume | pending your approval |
| E2 | Experience (Jenkins role) | Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs. | Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs. (moved to the top of the role) | reorder | "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs." | [grounded] resume | pending your approval |

E2 changes only position. Nothing about the Jenkins work is upgraded, and I have not added "CI/CD" to it. The posting's term is broader than "deploy pipeline", and you haven't said whether the pipeline builds and tests as well as deploys.

## Coverage map

Priorities are my reading. The posting doesn't rank its requirements.

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| 1 | Kubernetes | must-have | surfaced_by_edit | E1. Proof-of-concept only; the resume cannot say production. | [grounded] |
| 2 | Terraform | must-have | not_evidenced | R1 | [grounded] |
| 3 | Argo CD and GitOps | must-have | not_evidenced | R2 | [grounded] |
| 4 | Helm | must-have | not_evidenced | R2 | [grounded] |
| 5 | AWS EKS | must-have | not_evidenced | R2. AWS is evidenced; EKS is not. | [grounded] |
| 6 | Prometheus and Grafana | must-have | not_evidenced | R3 | [grounded] |
| 7 | Observability | must-have | already_evidenced | CloudWatch monitoring only, as a general term. Prometheus and Grafana remain the gap (R3). | [grounded] |
| 8 | Istio and service mesh | must-have | not_evidenced | Named absence below | [grounded] |
| 9 | Vault | must-have | not_evidenced | Named absence below | [grounded] |
| 10 | SRE practices and platform reliability | must-have | not_evidenced | Named absence below | [grounded] |
| 11 | CI/CD (GitLab) | important | surfaced_by_edit | E2. Jenkins CI/CD is evidenced; GitLab is not. | [grounded] |
| 12 | Python | important | already_evidenced | "Bash and Python scripting" already states it. | [grounded] |
| 13 | Go | important | not_evidenced | Named absence below | [grounded] |
| 14 | Developer experience | important | not_evidenced | Named absence below | [grounded] |

## Recall prompts

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| R1 | Terraform | must-have | Nothing. Ansible is listed for configuration management. | Infrastructure-as-code is the first thing a platform screener looks for. | Any infrastructure you defined in code, including Ansible if it provisioned resources. | A repo, module or config file. | [grounded] what the resume does not say; [generic] Terraform is commonly how platform roles define AWS infrastructure |
| R2 | Argo CD, GitOps, Helm, EKS | must-have | "Ran a Kubernetes proof-of-concept for two months last year — never went to production." Nothing on EKS, Helm or Argo CD. | The Kubernetes line is the posting's most specific match, so its depth decides whether it counts. | The proof-of-concept itself: where it ran, how it was deployed, and any Helm charts or Argo CD sync. | A design note, diagram, or repo from the proof-of-concept. | [grounded] what the resume does not say; [inferred] the proof-of-concept is the only Kubernetes evidence described |
| R3 | Prometheus and Grafana | must-have | "CloudWatch for monitoring." | Observability is named in the posting, and CloudWatch alone may not read as that. | Dashboards or alerting you built, in CloudWatch or elsewhere. | A dashboard screenshot or alert rule, with its purpose. | [grounded] what the resume does not say; [generic] monitoring stacks of this kind are usually judged by what they alert on |

## Named absences

- **Istio and service mesh.** Not in your résumé or your description. A closing path is a hands-on install in a sandbox cluster that you can describe in your own words.
- **Vault.** Not present. If you've handled secrets or IAM roles in Jenkins, that's adjacent and worth naming, but it doesn't close the requirement.
- **SRE practices and platform reliability.** Nothing you've described covers SLOs, incident response, or on-call ownership. If you have on-call or post-incident work, that's the material to bring. Without it, this is a real gap for this role.
- **Go.** Not present. A small tool you wrote in Go, shown as an artifact, would close it.
- **Developer experience.** Nothing shows engineers as users of what you built. If other teams used your pipeline, say so only with a number you can defend.

## Not written, and why

- **"Production Kubernetes."** The proof-of-concept never went to production, and you said so.
- **Terraform, Argo CD, Helm, Istio, Vault, EKS, GitOps, Prometheus, Grafana, Go or GitLab listed as skills.** A listed tool is a tool claimed as owned. A keyword block of the posting's terms would be exactly that.
- **"Led" or "managed" the Kubernetes work.** You ran a proof-of-concept. Nothing says you led it.
- **"Owned platform reliability" or "SRE practices."** The posting's words for a role you haven't described holding.
- **"CI/CD" for the Jenkins work.** The posting's term, and broader than the deploy pipeline you described.
- **"Observability" beyond CloudWatch monitoring.** Your evidence covers monitoring, not the posting's wider term.

## Parse-safety check

I could not run the file-level checks: the PDF wasn't attached, so these come from your description. Each is a risk to confirm, not a finding.

| Check | What breaks | What it costs |
|---|---|---|
| Two-column layout | Parsers can read across columns, so text interleaves | Dates can detach from the roles they belong to |
| Icons for skills | Icons are read as garbage characters or skipped | Any skill level the icons carried is lost |
| Contact details in the header | Headers are often treated as page furniture and discarded | You may become unreachable |
| Canva export | It is not clear whether the text is a text layer | If it is an image, nothing is extracted |

A single-column `.docx`, or a PDF with a text layer, with the contact details in the body and standard headings (Experience, Skills), is the safe pair. This is about extraction, not appearance.

## Offer

- Offer, if you want it: a repo, config, or design note from the Kubernetes proof-of-concept would let me upgrade E1 from a sentence to an artifact. That is the row the posting most needs.
- Offer, if you want it: after you approve rows, I can produce the résumé from approved rows only, as a single-column text-layer PDF or `.docx`.

## Questions

1. R1: Have you written Terraform for any AWS resources, such as a module or stack, even outside work?
2. R2: What did the proof-of-concept run on, EKS or self-managed, and did it use Helm, Argo CD or GitOps?
3. R3: Did you build Prometheus or Grafana dashboards, or only CloudWatch alarms?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.