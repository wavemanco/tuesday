I worked from your description, not a resume file, so every "current line" and quote below is taken from your message. Check them against the document you send. Read this way, the resume can show the real overlap with data engineering (star schema, dbt, tests on a nightly job, cron scripts). It cannot honestly claim the must-haves you don't have: 3+ years of data engineering, Airflow or equivalent, and Spark, Kafka or streaming. No row below claims them.

## Edit ledger

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Summary | *(none)* | "Designed the star schema for the orders mart with our then-DE. Built and maintained about 25 dbt models including the core orders mart." | `merge` | "I designed the star schema for the orders mart with our then-DE."; "Built and maintained about 25 dbt models including the core orders mart." | `[grounded]` cv | pending your approval |
| E2 | Experience | "I designed the star schema for the orders mart with our then-DE." | *(unchanged, moved to lead the Experience bullets)* | `reorder` | "I designed the star schema for the orders mart with our then-DE." | `[grounded]` cv | pending your approval |
| E3 | Experience | "I've fixed our nightly dbt job when it breaks and added tests to it." | "Fixed our nightly dbt job when it breaks and added tests to it." | `reframe` | "I've fixed our nightly dbt job when it breaks and added tests to it." | `[grounded]` cv | pending your approval |
| E4 | Experience | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | "Scripted pulls of vendor APIs, run on a cron." | `split` | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | `[grounded]` cv | pending your approval |
| E5 | Experience | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | "Wrote Python for analysis in pandas." | `split` | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | `[grounded]` cv | pending your approval |

E4 says "scripted" and "run on a cron" and does not say "production". E1 keeps "with our then-DE", so the star schema stays shared credit.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| 1 | 3+ years data engineering | must-have | not_evidenced | Five years in analytics; no data engineering role stated. Nearest work is E1–E3. This is a length requirement, so it is not a gate. | `[grounded]` cv |
| 2 | Production Python | must-have | surfaced_by_edit | E4, E5. The cron scripts are the evidence; "production" is not claimed. | `[grounded]` cv |
| 3 | Airflow or equivalent orchestration | must-have | not_evidenced | Your nightly dbt job and cron scripts run on a schedule, but nothing says what scheduled them. dbt is a transformation tool, not an orchestrator. | `[grounded]` cv |
| 4 | Dimensional modelling | must-have | surfaced_by_edit | E1, E2: star schema for the orders mart. | `[grounded]` cv |
| 5 | Model the warehouse | important | surfaced_by_edit | E1, E2: same work as row 4, for one mart. | `[grounded]` cv |
| 6 | Own data quality | important | surfaced_by_edit | E3: tests added and breaks fixed. Ownership is not stated. | `[grounded]` cv |
| 7 | Own SLAs | important | not_evidenced | No SLA or freshness target appears in your material. | `[grounded]` cv |
| 8 | Build and own batch pipelines | important | not_evidenced | Your dbt models are the transformation layer (E1). Ingestion and scheduling ownership are not stated. | `[grounded]` cv |
| 9 | Spark and Kafka | important | not_evidenced | "Never used Airflow or Spark. Never touched Kafka." | `[grounded]` cv |
| 10 | Streaming pipelines | preferred | not_evidenced | No streaming work in your material. | `[grounded]` cv |
| 11 | Partner with analytics on requirements | important | not_evidenced | You sit on the analytics side. Gathering requirements from data consumers is not stated. | `[grounded]` cv |

## Recovery per gap

Recall prompts for rows with something to pull. Each one's question is in the closing block.

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Airflow or equivalent orchestration | must-have | Scheduled jobs are mentioned, not what scheduled them. | Orchestration is a listed must-have, and the posting names Airflow. | Any setup, config or change to a scheduler, cron host or workflow tool. | A DAG, job config, or the scheduler's run history. | `[grounded]` what the resume does and does not say; `[generic]` analytics-to-engineering applications are often screened on the listed must-haves first |
| C2 | Build and own batch pipelines | important | dbt models transform data; no ingestion or load work is stated. | "Build and own" is the first duty in the posting. | Any new data source, load, or pipeline you set up rather than modelled. | A repo, runbook, or pipeline diagram. | `[grounded]` what the resume does and does not say; `[generic]` a role built around "build and own" is usually judged on that duty first |
| C3 | Own SLAs and data quality | important | Tests and break fixes (E3); no targets stated. | Ownership of quality targets is the second duty in the posting. | Any freshness or delivery target you tracked, alerts you received, or incidents you ran. | An alert config, dashboard, or incident note. | `[grounded]` what the resume does and does not say; `[generic]` data quality roles are usually judged on who owns the targets |

Named absences, with no recall prompt:

- **3+ years of data engineering (row 1).** You don't have this and no current work closes it. The closest honest target is an analytics engineering role, where dbt and dimensional work are the core of the job. Whether to apply at all is a call for job-underwriter.
- **Spark, Kafka and streaming (rows 9, 10).** Closing this takes a real project, such as a small Kafka topic loaded into a warehouse table or a Spark job on a public dataset, kept in a public repo. That is a few months of work. Without it, these rows stay open.
- **Partnering with analytics on requirements (row 11).** Nothing in your material shows it. You can claim it only if you ran requirements sessions with data consumers.

## Not written, and why

- **"Data Engineer" title or data engineering experience.** You have never held either, and the posting makes three years a must-have.
- **"Built and owned batch pipelines" or "owned the warehouse."** Your dbt work is transformation, and the star schema was shared with the then-DE.
- **Airflow, "orchestration," or any "equivalent."** You have never used these, and nothing in your material is an equivalent.
- **Spark, Kafka, or streaming in any form.** You never used or touched them.
- **"Owned data quality and SLAs."** You added tests and fixed breaks. Ownership and SLAs are not stated.
- **"Production Python."** The word "production" is not in your material.
- **"Partnered with analytics on requirements."** That is the posting's phrase, and your side of that table is the consumer side.

## Parse-safety check

No file was attached, so I haven't run the parse-safety check. Send the resume as a .docx or PDF and I'll run it.

## Offer (optional, not built)

A small public repo with a dbt project and an Airflow DAG loading one public dataset would give rows 1, 3 and 8 something inspectable to point at. It would take a few weekends. I'd build it only if you want it.

## Questions

**C1 — Orchestration:** What scheduled the nightly dbt job and the cron scripts, and did you ever set up or change that scheduler?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**C2 — Pipeline ownership:** Did you ever set up a new data source or load, rather than modelling data that was already landing?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**C3 — Quality and SLAs:** Did anyone set or track a freshness or delivery target for the orders data, and did you receive the alerts or own the response when it slipped?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

To approve, reply by row, for example: `Approved: E1, E2, E3` and `Rejected: E4 — reason`. Nothing is applied until you approve.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.