I worked from the dossier excerpt in your message, since I couldn't find `tuesday-dossier.md` on disk. I also worked from the CV summary you gave, not the full document. The "Current line" cells use those sentences, so if your CV wording differs, I need the exact text before you approve anything. The JD tiers only the PM requirement as must-have, so I've treated the rest as important.

## Edit ledger

Nothing is applied. Every row is pending your approval.

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience | Playbook sentence sits inside another bullet (dossier E1) | Wrote the internal integration playbook the whole team uses. | split | "Wrote the internal integration playbook the whole team uses." | [grounded] resume; dossier E1 | pending your approval |
| E2 | Experience | Led 30+ client integrations of our REST APIs end to end. (current position) | Led 30+ client integrations of our REST APIs end to end. (moved to lead the role) | reorder | "Led 30+ client integrations of our REST APIs end to end." | [grounded] resume | pending your approval |
| E3 | Experience | Ran quarterly roadmap-input sessions collecting client feedback for product. (current position) | Ran quarterly roadmap-input sessions collecting client feedback for product. (moved beside E2) | reorder | "Ran quarterly roadmap-input sessions collecting client feedback for product." | [grounded] resume | pending your approval |

E1 is the dossier's pending edit. I audited it before including it. Its trace quotes your sentence exactly, and it adds nothing to the scope or verb.

## Coverage map

Only the PM requirement is must-have. The rest are important.

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| 1 | 3+ years product management | must-have | not_evidenced | Nearest is 7 years as solutions engineer / implementation lead. No PM title held. Dossier R1: adjacent, transferability, medium. | [grounded] dossier R1; resume |
| 2 | Shipped API or platform products | important | not_evidenced | Adjacent: led 30+ client integrations of the vendor's REST APIs. No product shipped is stated. Dossier R2: adjacent, medium. | [grounded] dossier R2; resume |
| 3 | Owns roadmap for partner-facing API platform | must-have | not_evidenced | E3 shows input to a roadmap, not ownership of one. | [grounded] resume |
| 4 | Technical fluency | important | already_evidenced | "Comfortable in Postman, SQL, OpenAPI specs." | [grounded] resume |
| 5 | Stakeholder management | important | surfaced_by_edit | Client-facing work is carried by E2 and E3. No row names it as stakeholder management. | [grounded] resume |
| 6 | Run discovery with integration partners | important | not_evidenced | Nearest is E3, client feedback collected for product. "Discovery" does not appear in the resume. | [grounded] resume |
| 7 | Write specs | important | not_evidenced | OpenAPI is listed as a tool you are comfortable in, not as specs you wrote. | [grounded] resume |
| 8 | Drive delivery with two engineering squads | important | not_evidenced | E2 is delivery of integrations. No engineering squads are stated. | [grounded] resume |
| 9 | Define adoption metrics | important | not_evidenced | Nothing in the resume measures adoption. | [grounded] resume |

## Recovery per gap

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Roadmap ownership, prioritisation, and discovery with partners (rows 3, 6) | must-have | Roadmap input sessions. Input, not decisions. | The first responsibility in the JD is owning the roadmap. A reader will take input for a different job. | Deciding which client requests went into a release; setting order across integration work; running partner interviews about what they needed | A backlog export or roadmap doc from those sessions; a decision log | [grounded] resume; [generic] roadmap ownership is usually the first thing screened for in PM applications |
| C2 | Define adoption metrics (row 9) | important | No measure of integration outcomes | The JD asks you to define how adoption is measured. A reader can't see whether you have measured it before. | Time to first successful call across the 30+ integrations; partners live versus stalled; usage after go-live | An integration tracker, go-live checklist, or dashboard | [grounded] resume; [generic] adoption measures are usually asked about in interviews for this kind of role |
| C3 | Shipped products, specs, and delivery with engineering (rows 2, 7, 8) | important | E2 covers integrations delivered end to end. No engineering teams named. | The JD wants delivery with two squads and specs written by you. | An API change taken from request to release with engineers; a spec engineering built against; a release you were accountable for | Release notes, a ticket history, or a spec you wrote | [grounded] resume; [generic] delivery with engineering is usually probed in PM interviews |

**Named absence: 3+ years product management (row 1, must-have).** You have never held a PM title, and the JD makes three years a must-have. This resume can't close that gap, and nothing in the wording can cover it. The honest path is a role where the integration or solutions background is the stated fit, or a move into product on the vendor side, which would take roughly three years to reach the requirement. Row 2 follows the same path unless C3 turns up a shipped product.

## Not written, and why

- **"3+ years of product management," or any PM title.** You have never held one, and the JD makes it a must-have. The nearest evidence is in the solutions role.
- **"Owned the API platform roadmap," or "set priorities for the platform."** Your resume shows roadmap input. Prioritisation authority is not evidenced (dossier R1).
- **"Shipped API products."** Dossier R2 marks this adjacent. The resume shows integrations of the vendor's APIs, not a product you shipped.
- **"Ran discovery with integration partners."** That is the JD's term. Your sentence says "collecting client feedback".
- **"Partner" in place of "client."** The JD says partner, and your sentence says client. The word change would move which side of the table you sat on: you were the vendor, and the clients were integrating with you.
- **"Drove delivery with two engineering squads," or "wrote specs."** Neither is in evidence. OpenAPI is a tool you are comfortable in.
- **"Defined adoption metrics."** None are stated.
- **Dossier rejected inference: "built an internal request-triage tool."** You could not confirm ownership of it, so it stays out.
- **Dossier rejected inference: "has been the customer of a partner API platform."** You worked vendor-side.

## Parse-safety check

I could not run this check. The resume arrived as a summary in your message, not as a file, so layout, tables, headers and footers, headings and file type are all unchecked.

## Offers (not built)

- **Offer:** Attach the integration playbook, or its table of contents. This would give E1 a document trace beyond your sentence alone.
- **Offer:** Attach a roadmap-input summary or backlog export. This would let C1 ground a decision rather than input.
- **Offer:** Attach an integration tracker or go-live data. This would let C2 show measured adoption.

C1 — Did you ever decide what the product team built next, such as setting the order of requests, owning a backlog, or signing off scope, rather than only collecting input?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

C2 — After the integrations you led went live, did you track whether partners kept using them, and do you have any figures?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

C3 — Did you take an API change from request to release alongside engineers, and were you accountable for it landing?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.