## Tailoring ledger: Nadia, Quartzline Product Manager, Platform APIs

I worked from the dossier excerpt in your message; I couldn't open the full `tuesday-dossier.md` from here. The CV sentences in the ledger are the ones you wrote in your message. If your CV reads differently, send the file and I'll re-quote every trace verbatim.

The ledger makes the CV accurate and easier to read for an adjacent-role screen. It does not close the must-have gap: the CV shows no product-management tenure or title, and it shouldn't be made to. **Nothing is applied.** Every row is pending your approval.

### Edit ledger

I've assumed the playbook sentence currently sits inside another bullet. If it's already its own line, E1 drops.

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience | "Wrote the internal integration playbook the whole team uses." | "Wrote the internal integration playbook the whole team uses." (own line) | `surface` | "Wrote the internal integration playbook the whole team uses." | `[grounded]` CV; dossier E1 | pending your approval |
| E2 | Experience | "Led 30+ client integrations of our REST APIs end to end." | Unchanged, moved to the first bullet of the role | `reorder` | "Led 30+ client integrations of our REST APIs end to end." | `[grounded]` CV | pending your approval |
| E3 | Experience | "Ran quarterly roadmap-input sessions collecting client feedback for product." | Unchanged, placed directly after E2 | `reorder` | "Ran quarterly roadmap-input sessions collecting client feedback for product." | `[grounded]` CV | pending your approval |
| E4 | Skills | "Comfortable in Postman, SQL, OpenAPI specs." | Unchanged, moved to the top of Skills | `reorder` | "Comfortable in Postman, SQL, OpenAPI specs." | `[grounded]` CV | pending your approval |

**Audit notes.** E1 was inherited from the dossier, so I re-audited it. "The whole team" is the scope you stated, and it stays as written. E3 keeps "collecting", which is what the sessions did. It does not become "shaped the roadmap", because the CV doesn't say that. No row changes the title. "Solutions engineer / implementation lead" stays as it is.

### Coverage map

I've marked only R1 as must-have, since the JD labels only that requirement. The rest are marked important; tell me if the JD ranks them differently.

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 3+ years product management | must-have | not_evidenced | Adjacent only: E2 and E3 are product-facing work. No PM tenure or title. Dossier R1: adjacent, transferability. | `[grounded]` CV; dossier R1 |
| R2 | Shipped API or platform products | important | not_evidenced | E2 shows delivery of client integrations of the vendor's REST APIs, not shipping a product. Dossier R2: adjacent. | `[grounded]` CV; dossier R2 |
| R3 | Own the roadmap for the partner-facing API platform | important | not_evidenced | E3 shows client feedback gathered for product. Nothing shows you set or owned priorities. Dossier: roadmap ownership not evidenced. | `[grounded]` CV; dossier R1 |
| R4 | Run discovery with integration partners | important | surfaced_by_edit | E3 is the closest evidence: client feedback sessions, quarterly. Not discovery as a practice you ran. | `[grounded]` CV |
| R5 | Write specs and drive delivery with two engineering squads | important | not_evidenced | No spec-writing or squad-facing delivery in the CV. E1 is process documentation, not specs. | `[grounded]` CV |
| R6 | Define adoption metrics | important | not_evidenced | The CV gives delivery counts ("30+"), not adoption measures. | `[grounded]` CV |
| R7 | Technical fluency | important | surfaced_by_edit | E2 (REST APIs, end to end) and E4 (tools). "Comfortable in" is your wording. | `[grounded]` CV |
| R8 | Stakeholder management | important | surfaced_by_edit | E2 (client integrations end to end) and E3 (client feedback sessions). Not a management claim. | `[grounded]` CV |

No requirement is `already_evidenced` as written.

### Gap handling

**C1 (R1, R3): roadmap decision authority.** The CV shows you collecting feedback for product. It doesn't show you deciding what got built.
Why it matters: the must-have is PM tenure, and a screener reading an adjacent CV will mark it as not met in one pass. Experience that may count: a quarterly input session where your call changed the order of work; a deprioritisation you proposed and product accepted. Useful evidence: your roadmap-input summary, a decision log, a slide. Provenance: `[grounded]` the CV's sentence; `[generic]` the screening effect of a missing must-have.

**C2 (R5): specs and squad delivery.** The CV shows OpenAPI fluency and a playbook, not specs or delivery with engineering. Experience that may count: an OpenAPI spec you wrote for a client integration; a build you drove with product or engineering. Useful evidence: a sanitised spec or the playbook's API section. Provenance: `[grounded]` the CV.

**C3 (R6): adoption metrics.** The CV shows an integration count and no usage measure. Experience that may count: time to first successful call, integrations live against plan, client usage of the API. Useful evidence: any report or dashboard you tracked. Provenance: `[grounded]` the CV.

**R2: shipped API or platform product (named absence).** The CV shows you delivered the vendor's APIs to clients; it doesn't show you shipped one as the product. The only path to closing this is a role where you own an API as a product for six months or more. The honest target is an integration-product or solutions-leadership role, not a PM role. This resume shouldn't try to close it.

### Prohibited claims

Not written, and why:

- **"Product Manager" or "Product Manager, Platform APIs" as a title.** You have never held one, and the JD's title is the one thing this can't become.
- **Any product-management tenure, including "3+ years".** The CV shows none.
- **"Owned the API roadmap" or "set priorities".** Not evidenced. The sessions collected feedback.
- **"Shipped API products" or "built platform products".** You delivered integrations. You didn't ship a product.
- **"Partner-facing" or "partner API platform" experience.** The dossier rejected this inference: you worked vendor-side, and your counterparts were clients. "Partner" also moves which side of the table you sat on.
- **"Run discovery with integration partners" as a practice you did.** That's the JD's vocabulary applied to your history. R4 is surfaced only as client feedback sessions.
- **"Wrote specs" or "drove delivery with engineering squads".** Not in your material.
- **"Defined adoption metrics".** Not in your material.
- **"Expert in" Postman, SQL or OpenAPI.** "Comfortable in" is your word.
- **"Built an internal request-triage tool".** Rejected inference from the dossier, recorded unaltered: "built an internal request-triage tool — memory lead, candidate could not confirm ownership".
- **"Has been the customer of a partner API platform".** Rejected inference from the dossier, recorded unaltered: "has been the customer of a partner API platform — candidate worked vendor-side".

### Parse-safety check

- **Could not run:** multi-column layout, tables, text boxes, headers and footers, and file type. Your CV arrived as a description in your message, not a file.
- **Observed:** nothing in the proposed lines relies on layout. The ledger is plain sentences.
- **To run it:** send the .docx or a text-layer PDF and I'll check it.

**Upgrade menu (offers, not part of the ledger):**
- **Send the playbook, or a sanitised section of it.** That grounds E1 in a real artifact, and gives R7 more than a tool list.
- **Send the CV as a file.** That lets the parse-safety check run on the real document.
- **Rehearse the C1 and R2 questions with mock-interview.** This is the sibling skill; it's named once here.
- **Once C1 to C3 are answered,** I'll turn each answer into a new row through the confirmation card. Nothing gets written before you confirm it.

**Questions:**

C1 — Did you ever make the call on what got built next, or set priorities that engineering acted on, even for one quarter?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

C2 — Did you write or co-write an API spec, or drive delivery with a product or engineering team on a client build? If so, which one?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

C3 — Did you track any adoption figures for the integrations you led, such as time to first call, integrations live, or client usage?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.