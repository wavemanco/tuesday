**Two corrections first.** On keyword rejection, the evidence doesn't support "the ATS is auto-rejecting me." Content-based auto-rejection exists but is uncommon: in one vendor's interviews with 25 recruiters, two had it configured (cite C25). Keywords more often affect ranking: "Many teams use match scores/filters to prioritize who gets reviewed first" (cite C27). The filter most often reported to reject without a person is the knockout questions in the application form, such as work authorization, required licence and location (cite C26). Those sit outside the resume, so check them on the form. I can't see your rejections, so I can't say which applies.

The posting names 16 items. Your current text supports two as written, Python and AWS in general, and CI/CD only through Jenkins. Kubernetes appears only as a proof-of-concept. That gap is real whatever a parser does, so keywords alone won't close it. The changes below make your existing experience easier to find and fix the parse risks. They don't add tools you haven't used.

I worked from the text you pasted, not the PDF. Quotes below are from that text.

## Edit ledger

Nothing is applied. Every row is pending your approval.

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| L1 | Skills | *(Kubernetes not listed)* | Kubernetes — two-month proof-of-concept, never in production | `surface` | "Ran a Kubernetes proof-of-concept for two months last year — never went to production" | `[grounded]` cv | pending your approval |
| L2 | Summary (new) | *(no current line)* | DevOps Engineer, 4 years. Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs. Ran a Kubernetes proof-of-concept for two months last year — never went to production. | `merge` | "DevOps Engineer, 4 years"; "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs"; "Ran a Kubernetes proof-of-concept for two months last year — never went to production" | `[grounded]` cv | pending your approval |

L2 merges three sentences and adds no project. The Kubernetes qualifier stays in both rows.

## Coverage map

The posting doesn't mark priorities. I tiered it: its core responsibilities and named platform tools are must-have, the rest important, and Go preferred. Tell me if you'd tier it differently.

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| K1 | Kubernetes | must-have | surfaced_by_edit | L1, L2. Proof-of-concept only, not production | `[grounded]` cv |
| K2 | AWS EKS | must-have | not_evidenced | C1. Your PoC's platform isn't stated | `[grounded]` cv |
| K3 | Terraform | must-have | not_evidenced | C2. Ansible is config management, not provisioning | `[grounded]` cv |
| K4 | GitOps / ArgoCD | must-have | not_evidenced | Named absence N1 | `[grounded]` cv |
| K5 | Platform reliability and developer experience | must-have | not_evidenced | C3 | `[grounded]` cv |
| K6 | SRE practices | important | not_evidenced | C3 | `[grounded]` cv |
| K7 | Observability | important | not_evidenced | C3. CloudWatch monitoring is the only evidence | `[grounded]` cv |
| K8 | Prometheus, Grafana | important | not_evidenced | Named absence N2 | `[grounded]` cv |
| K9 | Vault | important | not_evidenced | Named absence N3 | `[grounded]` cv |
| K10 | Istio, service mesh | important | not_evidenced | Named absence N4 | `[grounded]` cv |
| K11 | Helm | important | not_evidenced | Named absence N5 | `[grounded]` cv |
| K12 | CI/CD (GitLab) | important | surfaced_by_edit | L2 surfaces Jenkins. GitLab isn't in your material | `[grounded]` cv |
| K13 | Python | important | already_evidenced | "Bash and Python scripting" is already on the page | `[grounded]` cv |
| K14 | AWS | important | already_evidenced | "AWS (EC2, S3, RDS, IAM)" is already on the page | `[grounded]` cv |
| K15 | Go | preferred | not_evidenced | Named absence N6 | `[grounded]` cv |

## Gap handling

**Recall prompts.** Each carries no question here. The questions are in the closing block.

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | AWS EKS | must-have | "Ran a Kubernetes proof-of-concept for two months" — the platform isn't named | The posting names EKS specifically | The PoC cluster, if it was EKS; any EKS work outside the PoC | PoC design note, cluster config, a repo | `[grounded]` what the resume does and does not say |
| C2 | Terraform / infrastructure as code | must-have | "Ansible for config management"; AWS listed with no provisioning method | Ansible is configuration management, and the posting asks for provisioning | AWS resources (EC2, S3, RDS, IAM) created from code, with any tool | A repo or a module you wrote | `[grounded]` what the resume does and does not say |
| C3 | Platform reliability, developer experience, SRE practices | must-have | "Built our deploy pipeline in Jenkins"; "CloudWatch for monitoring" | The role is defined by owning reliability and developer experience | On-call or incident response; alerts you set or tuned; pipeline changes made for developers | A runbook, alert config, a postmortem | `[grounded]` what the resume does and does not say |

**Named absences.** Each gap is stated, then the path to closing it.

- **N1 — GitOps / ArgoCD.** Nothing in your material shows either. Closing path: a small Git-driven deployment on a cluster you can run, with ArgoCD syncing it. `[generic]` what closing it takes.
- **N2 — Prometheus, Grafana.** Not in your material. Closing path: a metrics stack and dashboard on the same test cluster. `[generic]`
- **N3 — Vault.** Not in your material. Closing path: a secrets setup in a test environment. `[generic]`
- **N4 — Istio, service mesh.** Not in your material. Closing path: a mesh deployed in the test cluster. `[generic]`
- **N5 — Helm.** Not in your material. Closing path: charts for one of your own services. `[generic]`
- **N6 — Go.** Not in your material. Closing path: a small tool written in Go. `[generic]`

GitLab is also absent. Your Jenkins work is the CI evidence; I've not renamed it.

## Prohibited claims

Not written, and why:

- **"Platform Engineer" as your title.** You hold DevOps Engineer. A retitle is an equivalent, not an upgrade.
- **Terraform, ArgoCD, GitOps, Istio, Vault, Helm, Prometheus, Grafana, Go, GitLab, EKS in the skills list.** None is in your material, and listing one is the claim.
- **"Kubernetes" without the proof-of-concept qualifier.** It would read as production.
- **"Owned platform reliability" or "SRE practices."** Nothing you wrote says you owned either.
- **Ansible as a stand-in for Terraform.** Different work, and the interviewer will ask.
- **"CI/CD" or "Observability" added to your own lines.** Those are the posting's words. Your lines say "deploy pipeline" and "monitoring," and the swap moves your work into the posting's category. Keep yours until a recall answer gives the scope.

## Parse-safety check

I couldn't inspect the PDF, so these are risks your layout implies, not confirmed findings.

| Check | What breaks | What it costs | Observed here |
|---|---|---|---|
| Multi-column layout | Parsers read linearly, so columns interleave | Dates can detach from the roles they belong to | Not inspected. You described two columns |
| Icons per skill | Icons come through as garbage or are skipped | Any skill label that is an image is lost | Not inspected |
| Contact details in header | Header content is treated as page furniture | You could be unreachable | Check: if you can't select the header text in the PDF, a parser probably can't read it |
| Section headings | Non-standard headings aren't detected | Sections may not be recognized | Check that headings read Experience, Skills, Education |
| File type | Varies by parser; Canva exports can be image-only | A text-free PDF reads as empty | Check: if you can't select the body text, the file has no text layer |

## Upgrade menu

- **(x) Plain-text version.** A single-column rebuild of the same lines so a parser reads them in order. Built only on your approval.
- **(x) Closing path for the must-have gaps.** A small public repo that provisions an EKS cluster with Terraform and deploys to it with ArgoCD. It would give C1–C3 real material to draw on. Only worth it if you'd build it.

Whether to apply at all, given four must-have gaps, is job-underwriter's question.

## Questions

**C1 — Which platform did the Kubernetes proof-of-concept run on, and did you deploy to it yourself?**
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**C2 — Have you provisioned any AWS resources (EC2, S3, RDS, IAM) with code, using Terraform, CloudFormation or anything else?**
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**C3 — Have you been on call, responded to incidents, or set and tuned alerts? Which pipeline changes were made because developers asked for them?**
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.