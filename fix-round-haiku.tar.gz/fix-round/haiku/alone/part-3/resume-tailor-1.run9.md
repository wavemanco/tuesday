I built this from the sentences in your message. No CV file came through, so each "Current line" is your sentence as you wrote it. I treated them as self-report. I read "7 years" as software engineering overall, not backend, and I did not assume the ledger services are in Go. Nothing is applied yet. Approve or reject by row number, and the tailored resume will come only from approved rows.

## Edit ledger

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Summary (new) | — | "Senior Software Engineer, 7 years. Go and Rust daily for 4 years, Python before that. Own three services in our ledger pipeline at a payments company; one handles about 40k requests/minute at peak." | `merge` | "Senior Software Engineer, 7 years."; "Go and Rust daily for 4 years, Python before that."; "Currently at a payments company."; "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak." | `[grounded]` self-report | pending your approval |
| E2 | Experience | "Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer." | *(unchanged; moved to the first Experience bullet)* | `reorder` | "Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer." | `[grounded]` self-report | pending your approval |
| E3 | Experience | "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | "On-call rotation every fourth week for two years." | `split` | "On-call rotation every fourth week for two years" | `[grounded]` self-report | pending your approval |
| E4 | Experience | (same sentence as E3) | "Ran six incidents as incident commander." | `split` | "I've run six incidents as incident commander" | `[grounded]` self-report | pending your approval |
| E5 | Experience | "I do onboarding for new hires on my team — usually two or three a year, I pair with them for their first month." | "Onboard new hires on my team, usually two or three a year." | `split` | "I do onboarding for new hires on my team — usually two or three a year" | `[grounded]` self-report | pending your approval |
| E6 | Experience | (same sentence as E5) | "Pair with new hires for their first month." | `split` | "I pair with them for their first month." | `[grounded]` self-report | pending your approval |

The ledger services are not repeated as an Experience bullet, because E1 carries them in the summary. E1 puts "Go and Rust" beside the services without saying which language they are written in. That is the question in Q1 below.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| C1 | 5+ years backend | must-have | surfaced_by_edit | E1. Your sentence says "7 years" as a Senior Software Engineer. The word "backend" is not in it; I have assumed the work was server-side. | `[grounded]` |
| C2 | Production Go | must-have | surfaced_by_edit | E1: "Go and Rust daily for 4 years." "Production" and the language of the ledger services are not stated (Q1). | `[grounded]` |
| C3 | Distributed systems at scale | must-have | surfaced_by_edit | E1: the 40k/min peak is the scale evidence. "Distributed" is not stated. Kafka and gRPC appear only in your list, with no work attached. | `[grounded]` |
| C4 | Design and ship high-volume Go services | important | surfaced_by_edit | E1: "I own three services… 40k requests/minute." Owning is stated; designing and shipping are not. Language as C2. | `[grounded]` |
| C5 | Drive down p99 latency | important | already_evidenced | Your sentence as written. E2 moves it to the top. | `[grounded]` |
| C6 | Strong incident response | must-have | already_evidenced | E4: six incidents as incident commander. "Strong" is a judgement the CV cannot make for you. | `[grounded]` |
| C7 | Own on-call for your services | important | already_evidenced | E3: on-call rotation for two years. Which services are not stated. | `[grounded]` |
| C8 | Experience mentoring | must-have | surfaced_by_edit | E5 and E6: onboarding and pairing with new hires, as separate bullets. The word "mentoring" is not in your sentences and will not be written. | `[grounded]` |
| C9 | Mentor mid-level engineers | important | not_evidenced | Nothing about mid-level engineers. Recall prompt R1. | `[grounded]` |
| C10 | Partner with product on roadmap sequencing | important | not_evidenced | Nothing in the material. Recall prompt R2. | `[grounded]` |
| C11 | Build-cache platform work | important | not_evidenced | Nothing about build caching. Adjacent: the cache-layer rework in E2. | `[grounded]` |

## Recovery per gap

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| R1 | Mentor mid-level engineers | important | Pairing with new hires for their first month (E6). Nothing about engineers past onboarding. | The JD names it as a responsibility, a step beyond onboarding. | A mid-level engineer you coached through a project or a promotion; a review or growth plan you wrote for them. | A 1:1 or review note, a growth plan, a promotion case you wrote. | `[grounded]` JD wording; `[generic]` onboarding alone is usually read as a narrower thing than mentoring |
| R2 | Partner with product on roadmap sequencing | important | Nothing. | The JD names it as a responsibility, so a reader will look for it. | A roadmap decision you pushed on with a product manager; a dependency you sequenced against a launch. | A roadmap doc, a planning thread, a launch note listing your dependencies. | `[grounded]` JD wording; `[generic]` roadmap work is usually visible in planning artifacts |

**Named absence, C11 (build-cache work).** You have not worked on a build cache, and the CV does not claim it. The closest evidence is the cache-layer rework in E2, on a payments balance-read path. It is adjacent, not direct, and the resume should not say otherwise. Closing it would take hands-on work in build caching, such as a project or a work sample in that area, or a role that puts you on it. Whether it is worth closing for this role is your call. `[grounded]` for the CV reading; `[generic]` for what a build-cache role usually needs.

## Prohibited claims

Not written, and why:

- **"Backend" as a title or a claim about all 7 years.** Not stated.
- **"Senior Backend Engineer" as your title.** The CV says "Senior Software Engineer", and that stays.
- **"Production Go" for the ledger services.** The language of those services is not in what you gave me.
- **"Distributed systems."** The scale is stated; the label is not.
- **"Mentored" or "mentoring" for the new-hire work.** You onboarded and paired. Calling it mentoring would change the kind of work.
- **"Mentored mid-level engineers," "partnered with product," "roadmap sequencing."** Nothing supports them.
- **Anything about build caching.** Nothing supports it.
- **"Led" incidents, or "strong" incident response.** "Ran" is what you wrote, and "strong" is a judgement.
- **Kafka, Postgres, Terraform, gRPC and Datadog as experience.** They appear only in your list, with no work attached. A tool listed is not a tool owned.
- **Figures you did not give.** I have kept "about 40k requests/minute" and added no team sizes or conversions.

## Parse-safety check

The material arrived as sentences in a message, not as a file. I could not check layout, tables, headers or footers, or file type. Nothing in the text itself raises a parse risk.

## Upgrade menu (offers, not applied)

- **Send the CV file.** I can then run the parse check on the real document and check the current lines verbatim. The ledger quotes only the sentences you typed.
- **Send the incident write-up for one of the six incidents.** A postmortem or doc would turn C6 from a sentence into an inspectable artifact.

## Questions

**Q1 (C2):** Are the three ledger services written in Go, Rust, or something else? If Go, "production Go" can go in the summary. If not, it cannot.

**Q2 (R1):** Think of a mid-level engineer you helped grow, through a project, a review or a promotion. What did you do, and over what period?

**Q3 (R2):** Describe one roadmap decision you shaped with a product manager. What got sequenced, and what did you contribute?

Answer in text, a voice transcript, a document, or a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.