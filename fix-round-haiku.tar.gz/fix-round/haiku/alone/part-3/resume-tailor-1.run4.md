I built the ledger from the summary in your message, since no CV file came through. Quotes are verbatim from that text, so check them against your actual CV before approving anything. Nothing is applied yet. Every row is pending your approval.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| 1 | 5+ years backend | must-have | already_evidenced | Title and "7 years" are stated. "Backend" never appears in your material, so I haven't used it. | `[grounded]` Senior Software Engineer, 7 years |
| 2 | Production Go | must-have | surfaced_by_edit | R2 surfaces "Go and Rust daily for 4 years". "In production" is not stated, so I haven't written it. | `[grounded]` background prose |
| 3 | Distributed systems at scale | must-have | surfaced_by_edit | The 40k requests/minute figure is the only scale evidence. "Distributed" is not your word, and Kafka and gRPC are listed, not described. | `[grounded]` background prose |
| 4 | Drive down p99 latency | important | already_evidenced | 380ms to 95ms on the balance-read path. R1 only moves it up. | `[grounded]` background prose |
| 5 | Own on-call for your services | must-have | surfaced_by_edit | Buried in one sentence. R3 splits it out. | `[grounded]` background prose |
| 6 | Strong incident response | must-have | surfaced_by_edit | Six incidents as incident commander. R4 splits it out. "Strong" is the JD's word, not yours. | `[grounded]` background prose |
| 7 | Design and ship Go services | important | not_evidenced | You own three services and reworked the cache layer. Designing and shipping are not stated. | `[grounded]` what the text does and does not say |
| 8 | Mentor mid-level engineers, and experience mentoring | must-have | not_evidenced | Onboarding pairing (R5) is adjacent but narrower. It is not mid-level mentoring. | `[grounded]` onboarding only |
| 9 | Partner with product on roadmap sequencing | important | not_evidenced | Nothing in your material covers product work. | `[grounded]` nothing shown |

## Edit ledger

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| R1 | Experience | "Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer." | Same line, moved above the ledger-services line | reorder | "Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer." | `[grounded]` background prose | pending your approval |
| R2 | Skills (top) | "Go and Rust daily for 4 years, Python before that." | Same line, surfaced into a Skills line at the top | surface | "Go and Rust daily for 4 years, Python before that." | `[grounded]` background prose | pending your approval |
| R3 | Experience | "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | "On-call rotation every fourth week for two years." | split | "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | `[grounded]` background prose | pending your approval |
| R4 | Experience | (same sentence as R3) | "Ran six incidents as incident commander." | split | "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | `[grounded]` background prose | pending your approval |
| R5 | Experience | "I do onboarding for new hires on my team — usually two or three a year, I pair with them for their first month." | "Onboard new hires on my team, usually two or three a year, pairing with each for their first month." | compress | "I do onboarding for new hires on my team — usually two or three a year, I pair with them for their first month." | `[grounded]` background prose | pending your approval |

## Gap handling

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Mentor mid-level engineers | must-have | Onboarding pairing with new hires for their first month (R5). Nothing on mentoring mid-level engineers. | The JD names mentoring twice. Interviewers usually probe the gap between onboarding and mentoring. | Growing a mid-level engineer over months; feedback or stretch work; a promotion case you supported | Notes from 1:1s, a promotion packet, a feedback thread | `[grounded]` onboarding only; `[generic]` mid-level mentoring is usually judged by growth over months, not single sessions |
| C2 | Partner with product on roadmap sequencing | important | Nothing. | The JD makes this a standing responsibility for a senior hire. | Deciding the order of cache or ledger work with a PM; a sequencing call you pushed for | A roadmap doc, planning notes, a ticket thread | `[grounded]` nothing shown; `[generic]` senior backend roles usually involve sequencing work with product |
| C3 | Design and ship Go services | important | You own three services and reworked the cache layer. Designing and shipping are not stated. | "Design and ship" is a standing responsibility, and the requirement for distributed systems at scale rests on this evidence too. | Writing the design for the cache rework; shipping it to production; how the ledger services communicate | A design doc, a PR link, a launch note, an architecture diagram | `[grounded]` what the text does and does not say |

## Prohibited claims

Not written, and why:

- **"Mentored mid-level engineers"** — you described onboarding pairing, which is a narrower kind of work. C1 covers the gap.
- **"Strong incident response"** — the word "strong" is the JD's. The six incidents you ran are the evidence, and they stand as written.
- **"Designed and shipped the cache layer" or "led the cache rework"** — you said "reworking". Adding who designed or led it changes the verb and the claim. C3 covers it.
- **"Built on Kafka" or "owns Kafka, Postgres, Terraform, gRPC, Datadog"** — the CV lists these. A listed tool is not an owned tool.
- **"Backend" or "distributed systems"** as your own words — both are the JD's vocabulary, not yours.
- **"In production" for Go** — not in your material.
- **"At scale"** — the scale figure is 40k requests/minute at peak, and that is the phrase I've kept.
- **"Partnered with product"** — there is no evidence for it. C2 covers the gap.

## Parse-safety check

This came as pasted text, not a file, so I could not check layout, tables, text boxes, icons, headers or footers, or the file type. Those checks need the file itself.

## Upgrade menu

- **Offer, built only if you ask:** once you answer C1–C3, I can draft a summary block using only your existing sentences and confirmed answers.
- **Offer, built only if you ask:** send the CV file and I can run the quote check and the parse-safety check against the real text.

## Questions

C1 — When you have mentored a mid-level engineer, not just onboarded a new hire, what did you do with them over months, and what changed for them?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

C2 — Have you shaped what your team builds next with product, such as deciding the order of cache or ledger work? If so, give one example.
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

C3 — For the cache-layer rework, did you write the design and ship it to production yourself?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.