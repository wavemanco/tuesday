I built the ledger from the CV sentences you pasted. Nothing is applied yet: every row is `pending your approval`. Your strongest matches are the p99 result, the on-call and incident record, Go, and the 40k requests/minute figure. Three requirements have no support in the CV (backend years, designing and shipping services, and product sequencing), and two more are only partly supported (distributed systems, mentoring). I've kept the gaps visible rather than writing around them.

**Assumption:** the "Current line" column uses your sentences as pasted, and "moved" assumes they sit lower in your document than I've placed them. If your real CV wording differs, the trace quotes need checking against it.

## Edit ledger

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| L1 | Summary (new top line) | (none) | Go and Rust daily for 4 years, Python before that. | `surface` | "Go and Rust daily for 4 years, Python before that." | `[grounded]` CV | pending your approval |
| L2 | Experience, pipeline bullet | "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak." | Own three services in our ledger pipeline; one handles about 40k requests/minute at peak. | `compress` | "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak." | `[grounded]` CV | pending your approval |
| L3 | Experience, top bullet | "Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer." | *(unchanged, moved to the top of Experience)* | `reorder` | "Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer." | `[grounded]` CV | pending your approval |
| L4 | Experience, incident bullet | "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | On-call rotation every fourth week for two years. | `split` | "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | `[grounded]` CV | pending your approval |
| L5 | Experience, incident bullet | (same as L4) | Run six incidents as incident commander. | `split` | "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | `[grounded]` CV | pending your approval |
| L6 | Experience, onboarding bullet | "I do onboarding for new hires on my team — usually two or three a year, I pair with them for their first month." | Onboard new hires on my team: usually two or three a year, pairing with each for their first month. | `compress` | "I do onboarding for new hires on my team — usually two or three a year, I pair with them for their first month." | `[grounded]` CV | pending your approval |

No cuts are proposed. The Kafka, Postgres, Terraform, gRPC and Datadog list stays as it is, because nothing in your CV says what you used them for.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| 1 | 5+ years backend | must-have | not_evidenced | Years and service ownership are stated; the word backend and how many of the seven years were backend are not. Recall C1. | `[grounded]` "Senior Software Engineer, 7 years." |
| 2 | Production Go | must-have | already_evidenced | Go daily for four years, on payments-platform work. L1 moves it to the top. | `[grounded]` "Go and Rust daily for 4 years, Python before that." |
| 3 | Distributed systems at scale | must-have | not_evidenced | Scale is shown (40k requests/minute at peak, L2). "Distributed" is not stated, and Kafka appears with no use attached. Named absence N1. | `[grounded]` "I own three services in our ledger pipeline…"; "CV also lists: Kafka…" |
| 4 | Strong incident response | must-have | already_evidenced | Six incidents as incident commander, plus on-call every fourth week for two years (L4, L5). | `[grounded]` "…I've run six incidents as incident commander." |
| 5 | Experience mentoring | must-have | not_evidenced | Onboarding pairs are stated (L6). Mentoring mid-level engineers is not. Named absence N2. | `[grounded]` "I do onboarding for new hires on my team…" |
| 6 | Own high-volume Go services in production | important | surfaced_by_edit | Owns three services, one at about 40k requests/minute at peak. This is the payments ledger pipeline, not the build-cache platform (L2). | `[grounded]` "I own three services in our ledger pipeline…" |
| 7 | Drive down p99 latency | important | already_evidenced | 380ms to 95ms on the balance-read path. L3 moves it up. | `[grounded]` "Cut p99 on the balance-read path from 380ms to 95ms…" |
| 8 | Own on-call for your services | important | already_evidenced | Every fourth week for two years. | `[grounded]` "On-call rotation every fourth week for two years…" |
| 9 | Design and ship new Go services | important | not_evidenced | Owning services is stated. Designing or shipping a new one is not. Recall C2. | `[grounded]` what the CV does not say |
| 10 | Partner with product on roadmap sequencing | important | not_evidenced | Nothing in the CV. Recall C3. | `[grounded]` what the CV does not say |

## Recovery per gap

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | 5+ years backend | must-have | Seven years as a Senior Software Engineer, and services you own. Backend years are not stated. | A reader has to infer backend from "services," and the title does not say it. | Time on the ledger pipeline services; earlier roles if they were service work. | A service README, an on-call runbook, or a design doc for one of the three services. | `[grounded]` what the CV says; `[generic]` that a reader will check the title against the posting |
| C2 | Design and ship new Go services | important | You own three services. Nothing says you designed or launched one. | Ownership is not building, and the posting asks for building. | Any service you designed or launched, or the cache-layer rework if you designed it rather than inherited it. | A design doc, a PR, or a launch note. | `[grounded]` what the CV says; `[generic]` that the posting asks for design and ship |
| C3 | Partner with product on roadmap sequencing | important | Nothing. | The posting names it as a responsibility, and the CV is silent. | A decision where you sequenced or pushed back on work with product or a PM. | A roadmap doc or planning thread. | `[grounded]` what the CV does not say |

**N1 — Distributed systems at scale (named absence).** The CV shows scale (40k requests/minute at peak) and a cache layer, but no multi-node problem: partitioning, failover, or consistency. To close it, you would need one specific problem you solved across machines or regions, with numbers. If none exists, this stays a gap, and the role is a weaker match on this requirement than on the others. Say that, rather than writing "distributed."

**N2 — Mentoring mid-level engineers (named absence).** Onboarding is real and stated. Mentoring a mid-level engineer over months is not. To close it, you would need a named engineer you developed beyond their first month, with an outcome you can point to. Only use it if it is true. If there isn't one, the accurate description is onboarding experience, and a reader will hear that difference.

## Not written, and why

- **"Senior Backend Engineer" as your title.** You hold Senior Software Engineer. The posting's title is not yours.
- **"Designed," "built," or "launched" any service.** The CV says you own them.
- **"Distributed systems."** Not stated anywhere in the CV.
- **"Mentored mid-level engineers."** The CV says onboarding, with a month of pairing per hire.
- **"Partnered with product on roadmap."** Nothing in the material supports it, and "partner" is the posting's word.
- **"Led" the incidents.** "Incident commander" is the role's name. "Led" is an upgrade of the verb.
- **"40k requests per second," or 40k without "/minute" and "at peak."** The number stays attached to its unit and qualifier.
- **A platform-wide p99 reduction.** It was the balance-read path only.
- **Kafka, Postgres, Terraform, gRPC or Datadog tied to specific work.** They are listed, not described.
- **Build-cache experience.** Your cache work is a balance-read cache in a payments pipeline. The posting's build-cache platform is a different system, and a reader who knows the domain will see the gap.
- **Dropping "payments" or "ledger."** Cutting that context makes the claim larger than your sentences make it.

## Parse-safety check

You pasted text rather than a file, so I could not check layout, columns, tables, headers or footers, file type, or section headings. The pasted text contains no hidden or off-page content. For a real check, send the file as a `.docx` or a text-layer PDF.

Upgrade offer (optional, not built unless you ask): attach the design doc or postmortem for the cache rework, or for any one incident. The latency and incident rows would then quote your own document rather than this summary, and C2 would have something to answer against.

**Questions**

C1 — Of your seven years, how many were backend or service work?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

C2 — Did you design or launch any service yourself, or did you inherit the three you own?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

C3 — Have you ever shaped what your team built next with product or a PM?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.