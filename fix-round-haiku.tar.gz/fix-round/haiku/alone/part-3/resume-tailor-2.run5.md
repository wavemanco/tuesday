I worked from the sentences in your message, since I don't have a resume file. Every quoted trace below is one of those sentences, verbatim. Priorities come from the posting's own labels: only "3+ years" is marked must-have, so I treated the other listed requirements as important and streaming as preferred.

The honest picture: this rewrite can make your dbt, star-schema and scheduled-Python work read clearly. It cannot supply the must-have years, Airflow, Spark, Kafka or SLA ownership, and the ledger doesn't try. Whether to apply with those gaps is a call for job-underwriter, not this rewrite.

## Edit ledger

Every row is pending your approval. Lines not listed stay as they are. The section names are my assumption, since you didn't give headings.

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| L1 | Experience | "Built and maintained about 25 dbt models including the core orders mart." | "Built and maintained about 25 dbt models including the core orders mart." (moved to first bullet) | `reorder` | "Built and maintained about 25 dbt models including the core orders mart." | `[grounded]` resume | pending your approval |
| L2 | Experience | "I designed the star schema for the orders mart with our then-DE." | "Designed the star schema for the orders mart with our then-DE." (moved under L1) | `reorder` | "I designed the star schema for the orders mart with our then-DE." | `[grounded]` resume | pending your approval |
| L3 | Experience | "I've fixed our nightly dbt job when it breaks and added tests to it." | "Fixed our nightly dbt job when it broke." | `split` | "I've fixed our nightly dbt job when it breaks and added tests to it." | `[grounded]` resume | pending your approval |
| L4 | Experience | "I've fixed our nightly dbt job when it breaks and added tests to it." | "Added tests to our nightly dbt job." | `split` | "I've fixed our nightly dbt job when it breaks and added tests to it." | `[grounded]` resume | pending your approval |
| L5 | Experience | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | "Python for analysis in pandas." | `split` | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | `[grounded]` resume | pending your approval |
| L6 | Experience | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | "Some scripting to pull vendor APIs on a cron." | `split` | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | `[grounded]` resume | pending your approval |

L6 keeps "some". Dropping it would read as a larger body of work than you described. If the real extent is bigger, tell me and that version becomes a new row.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| K1 | 3+ years data engineering | must-have | not_evidenced | No DE years are stated. The adjacent work is in L1, L3–L6. The years can't be claimed. Recall prompt C1. | `[grounded]` resume: "Senior Data Analyst, 5 years, retail." |
| K2 | Build and own batch pipelines (Airflow, Spark) | important | surfaced_by_edit | Building is in L1, L3, L4. "Own" appears in none of your sentences, so no row claims it. Spark is not evidenced (see named absences). | `[grounded]` resume |
| K3 | Airflow or equivalent orchestration | important | not_evidenced | Named absence below. | `[grounded]` resume: "Never used Airflow or Spark." |
| K4 | Build and own streaming pipelines (Kafka) | preferred | not_evidenced | Named absence below. | `[grounded]` resume: "Never touched Kafka." |
| K5 | Production Python | important | surfaced_by_edit | L5 and L6 separate the pandas analysis from the cron scripts, the closest evidence. "Production" is not established. Recall prompt C3. | `[grounded]` resume |
| K6 | Dimensional modelling | important | already_evidenced | L2 states the star schema as yours, built with the then-DE. | `[grounded]` resume |
| K7 | Model the warehouse | important | surfaced_by_edit | L1 moves the 25-model line to the top. | `[grounded]` resume |
| K8 | Own data quality | important | surfaced_by_edit | Tests are in L4. "Own" is not claimed. | `[grounded]` resume |
| K9 | Own SLAs | important | not_evidenced | No SLA appears in your sentences. Recall prompt C2. | `[grounded]` resume: no SLA stated |
| K10 | Partner with analytics on requirements | important | not_evidenced | Named absence below. | `[grounded]` resume: you sat on the analytics side |

## Recovery per gap

**Recall prompts** (questions are asked once, in the closing block)

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | 3+ years data engineering | must-have | 5 years as Senior Data Analyst, with dbt work, the nightly job and cron scripts. No DE years stated. | The only must-have label on the posting. The years are graded as fit, not as a gate. | dbt model builds before the orders mart; fixing the nightly job; the cron API pulls; any ingestion or load work before the analyst title | Dated commits in the dbt repo, job run history, the cron config, a manager's note on scope | `[grounded]` the resume's years and titles; `[generic]` that a must-have the resume can't show tends to end the read early on postings like this |
| C2 | Own SLAs; own data quality | important | Tests added to the nightly job (L4). No SLA. | The posting makes the DE own deadlines. A fixer who never owned one will be asked about it early. | Any time the orders job had to be ready by a fixed hour; any alert, late-load complaint or on-time measure | A freshness check, a failure-alert config, a runbook, a thread about a late load | `[grounded]` the resume; `[generic]` that interviewers probe deadlines on this kind of role |
| C3 | Production Python | important | Cron scripts (L6), with no stated failure handling or ownership | "Production" means unattended runs someone answers for | Vendor-API scripts that failed silently, raised alerts, were rerun or were handed to you | The crontab or scheduler config, the script repo, logs, the alert channel | `[grounded]` the resume; `[generic]` what "production" usually means in job postings |

**Named absences** (gap, then closing path)

- **Airflow (K3).** You have never run it, and the posting lists it. Your nightly dbt job and cron scripts are scheduled work, but no orchestrator is named in your sentences, so no line can call them orchestration. Closing path: move one job you already run, such as the nightly dbt build or one vendor-API pull, into an Airflow DAG and run it for several weeks. Only after that can a line say so.
- **Spark (K2).** You have never used it, and the posting names it under batch pipelines. Closing path: rerun one existing transform in PySpark on data large enough that pandas strains. A tutorial doesn't count as evidence.
- **Kafka and streaming (K4).** No streaming work. The posting calls it a plus, not a requirement. Closing path: a small producer and consumer project. For this role, it may not be worth the time.
- **Partnering on requirements (K10).** Your sentences put you on the analytics side of the orders mart, not gathering requirements for it. Closing path: take one orders-mart change from a stakeholder's request through to a written spec, hand it to whoever builds it, and keep the spec.

## Not written, and why

- **"3+ years data engineering"** or any DE year count. You haven't stated those years (K1).
- **"Data Engineer" as a title.** You've never held it. The headline stays Senior Data Analyst.
- **"Owned the nightly pipeline" or "owned data quality."** You fixed the job and added tests. "Own" is the posting's word, not yours.
- **"Owned SLAs."** None are stated.
- **"Production Python."** Not established. C3 asks.
- **"Orchestrated," "Airflow," or "equivalent orchestration."** Never held (K3).
- **"Spark," "Kafka," "streaming."** Never used.
- **"Built pipelines."** "Pipelines" is the posting's word. Your work is dbt models and cron scripts, and I won't relabel them.
- **"Led the star schema design."** You designed it with the then-DE. "Led" changes who held the decision.
- **"Partnered with analytics on requirements."** "Partner" is the posting's word. You were the analytics side, and that relationship would change.

## Parse-safety check

Not run. You sent the content as text, not as a file, so I can't check layout, tables, headers or fonts. Send the file and I'll check which of those can be verified.

## Upgrade menu

- **x1.** Share the dbt project and the cron-script repo, or links to them. That makes K2, K5 and K8 inspectable instead of self-reported. I'll rewrite only from what I can read.
- **x2.** Once C1 to C3 are answered, I'll turn any confirmed answers into rows through the confirmation step.

## Questions

**C1.** Before or alongside the analyst title, how much of your time went to pipeline work (dbt model builds, job fixes, cron pulls, loads) rather than reporting? Give the start month, not just a year count.
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**C2.** Did the nightly orders job have a time it had to be ready by? Who depended on it, and did anyone track whether it made that time?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**C3.** Do the vendor-API cron scripts run unattended? When one fails, who finds out: an alert, a log, or someone looking at the output?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.