Here is the ledger for the Bellhaven Data Engineer posting. Nothing is applied. Every row is pending your approval. The quotes are from your original message, not from my shorter summary to the skill, so check them against what you wrote.

## Edit ledger

Your sentences came without section headings, so I've assumed they sit under the analyst role. The headline "Senior Data Analyst, 5 years, retail." is unchanged. I didn't add a summary line, because any summary would have to claim a target role, and nothing you've given me supports one.

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience (assumed) | I designed the star schema for the orders mart with our then-DE. | Designed the star schema for the orders mart with our then-DE. | reframe | "I designed the star schema for the orders mart with our then-DE." | `[grounded]` resume | pending your approval |
| E2 | Experience (assumed) | Built and maintained about 25 dbt models including the core orders mart. | Built and maintained about 25 dbt models including the core orders mart. | reorder | "Built and maintained about 25 dbt models including the core orders mart." | `[grounded]` resume | pending your approval |
| E3 | Experience (assumed) | I've fixed our nightly dbt job when it breaks and added tests to it. | Added tests to our nightly dbt job. | split | "I've fixed our nightly dbt job when it breaks and added tests to it." | `[grounded]` resume | pending your approval |
| E4 | Experience (assumed) | I've fixed our nightly dbt job when it breaks and added tests to it. | Fixed our nightly dbt job when it breaks. | split | "I've fixed our nightly dbt job when it breaks and added tests to it." | `[grounded]` resume | pending your approval |
| E5 | Experience (assumed) | I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron. | Wrote Python for analysis in pandas. | split | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | `[grounded]` resume | pending your approval |
| E6 | Experience (assumed) | I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron. | Wrote some scripting to pull vendor APIs on a cron. | split | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | `[grounded]` resume | pending your approval |

Notes on the rows:
- **E1** keeps "with our then-DE". Dropping it would turn a shared design into a solo one. The change in E1 is voice only: "I" comes out, as it does in resume bullets generally.
- **E2** moves the dbt line up. The star schema and the dbt work are your strongest evidence for this posting, so they lead.
- **E3 and E4** split one sentence into the two things it says. Each half is quoted in full. "Added tests" is the strongest data-quality evidence you have, and it currently sits at the end of a sentence.
- **E5 and E6** split the Python sentence. The "some" stays in E6, because removing it would make the scripting sound larger than you described it.

## Coverage map

Priority comes from the posting. Only the 3+ years line is marked must-have. The other requirements are listed without a tag, so I've marked them important. Streaming is marked preferred because the posting calls it a plus.

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 3+ years data engineering | must-have | not_evidenced | No years of data-engineering work on the resume. See C1. | `[grounded]` the resume claims 5 years as an analyst and no data-engineering years |
| R2 | Production Python | important | surfaced_by_edit | E5 and E6 surface the pandas work and the vendor-API scripts. "Production" is not established. See C4. | `[grounded]` |
| R3 | Batch pipelines, built and owned | important | surfaced_by_edit | Ingestion (E6) and transformation (E2) appear in separate lines. No end-to-end pipeline is claimed. | `[grounded]` |
| R4 | Airflow or equivalent orchestration | important | not_evidenced | No scheduler is named. See C3. | `[grounded]` |
| R5 | Dimensional modelling | important | already_evidenced | The star schema line (E1, moved up). | `[grounded]` |
| R6 | Model the warehouse | important | already_evidenced | The star schema line (E1) and "SQL every day on Redshift" as written. | `[grounded]` |
| R7 | Own data quality | important | surfaced_by_edit | Tests added to the nightly dbt job (E3). "Own" is not established. See C4. | `[grounded]` |
| R8 | Own SLAs | important | not_evidenced | No target times, alerts or freshness checks appear. See C4. | `[grounded]` |
| R9 | Partner with analytics on requirements | important | not_evidenced | Nothing shows requirements gathered for a data build. Named absence below. | `[grounded]` |
| R10 | Streaming pipelines (Kafka, Spark) | preferred | not_evidenced | Your resume says Spark and Kafka were never used. Named absence below. | `[grounded]` your message |

R5 and R6 need no edit to be met. E1 is moved up for emphasis, not because the coverage depends on it.

## Gap handling

**Recall prompts.** Each one is a row here. The question it implies is asked once, in the closing block.

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | 3+ years data engineering | must-have | 5 years as an analyst, and dbt and star-schema work inside that. No data-engineering years are claimed. | This is the only requirement the posting marks must-have. | Fixing the nightly job; the orders-mart build; vendor-API pulls; any stretch where pipeline work was most of the role. | The dbt repo history, the star-schema design doc, dated notes on when the pipeline work started. | `[grounded]` what the resume says and leaves out. `[generic]` a years floor is usually checked against dates on the resume. |
| C3 | Airflow or equivalent orchestration | important | Names no scheduler. "A cron" and "our nightly dbt job" are the only scheduling it shows. | `[generic]` cron runs a job on a clock but does not by itself manage dependencies or retries, which is the posting's sense of orchestration. | A scheduler behind the nightly dbt job; job dependencies you set; retries or failure alerts you configured. | The scheduler's job list or config, or a screenshot of it. | `[grounded]` the resume names only cron and a nightly job. `[generic]` the cron distinction above. |
| C4 | Own SLAs (also bears on production Python and data quality) | important | Shows you fixed the nightly job and added tests. No target time, alert or freshness check appears. | Owning SLAs means a deadline the data has to meet. "Fixed it when it breaks" is reactive. | A deadline the nightly job had to meet; a failure someone reported to you; a freshness check on the orders mart. | Alert history, a runbook, a dashboard or check config. | `[grounded]` the resume's reactive wording. `[generic]` SLA ownership is usually discussed in interviews. |

**Named absences.** These two have no question this turn.

| # | Gap | Closing path | Provenance |
|---|---|---|---|
| R9 | Partnering with analytics on requirements | The resume shows no requirements gathered for a data build. If you have a case where a request from analytics changed a model you built, that is worth recalling later. Without one, don't write the claim. | `[grounded]` nothing on the resume covers it |
| R10 | Spark and Kafka | Streaming is a plus here, not a requirement. Closing it would take a small streaming project you build and can show. | `[generic]` a project of that kind is usually a few months of part-time work |

## Prohibited claims

Not written, and why:

- **"Data Engineer" as a title or headline.** The title is not held, and the posting's must-have is years of it.
- **"5 years of data engineering."** The 5 years is analyst time on your resume.
- **"Built end-to-end batch pipelines."** Merging the vendor-API pulls and the dbt models into one pipeline would invent a project that never existed.
- **"Owned data quality and SLAs."** "Fixed when it breaks" and "added tests" are not ownership, and no SLA appears anywhere.
- **"Production Python."** Your resume says "for analysis" and describes scripts, not production systems.
- **"Partnered with analytics on requirements."** You sat on the analytics side of that relationship. Writing "partnered" would move you to the other side of the table.
- **"Ran the nightly job."** "Fixed it when it breaks" is not operating it.
- **Airflow, Spark, Kafka, or "orchestration" in a skills line or bullet.** You've never used them, and an interviewer would ask first.
- **Your "Never used Airflow or Spark" and "Never touched Kafka" notes.** These answer the JD. They are not resume lines.

## Parse-safety check

Your resume arrived as pasted text, not as a file. Layout checks (columns, tables, text boxes, headers and footers, icons) could not be run. If you send the file, the check can run on it.

## Proposal, not built

If you want, send the resume as a .docx or a text-layer PDF and I'll run the parse-safety check on the file. Separately, if R4 or R10 matters to you, I can outline a small Airflow or Kafka project you could build and show. I'd build it only if you ask.

## Questions

**C1 —** Across your 5 years, roughly how much of the work was pipeline work (loads, scheduling, fixing failed jobs, building models) rather than analysis?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**C3 —** What runs the nightly dbt job and the vendor-API pulls: plain cron, a scheduler tool, or something else? Does anything in it handle retries or dependencies?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**C4 —** When the nightly job or a vendor pull failed, did anyone get alerted, did you have a deadline for when the data had to be ready, and did you check it afterward?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.