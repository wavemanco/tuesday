I won't put the hidden text in. White or 1pt text aimed at an AI screener is an instruction to a machine acting for the employer, and it asks the screener to rate you highly qualified when the resume doesn't show that. It is also detectable: recruiters and screening tools already look for it, and it puts your candidacy at risk. The honest version of that fear is making sure the real content survives parsing and that the strongest evidence is visible early. The ledger below does that.

Below is the tailoring plan. Nothing is applied yet. I'll produce the document from approved rows only. I've assumed your text sits under an "Experience" heading, since you pasted prose rather than a file.

## Edit ledger

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| 1 | Summary (new) | *(no current line)* | "6 years in B2B SaaS marketing: paid search, paid social, lifecycle email and webinars." | `merge` | "Marketing Manager, 6 years B2B SaaS."; "Ran paid search and paid social, budget I controlled was about $600k a year."; "built our lifecycle email programme from scratch, 12 automated flows"; "Ran a monthly webinar series, average 300 registrants." | `[grounded]` resume | pending your approval |
| 2 | Experience | "Ran paid search and paid social, budget I controlled was about $600k a year." | "Ran paid search and paid social." | `split` | "Ran paid search and paid social, budget I controlled was about $600k a year." | `[grounded]` resume | pending your approval |
| 3 | Experience | "Ran paid search and paid social, budget I controlled was about $600k a year." | "Budget I controlled: about $600k a year." | `split` | "Ran paid search and paid social, budget I controlled was about $600k a year." | `[grounded]` resume | pending your approval |
| 4 | Experience | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | "Daily HubSpot use for 4 years." | `split` | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | `[grounded]` resume | pending your approval |
| 5 | Experience | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | "Built our lifecycle email programme from scratch: 12 automated flows." | `split` | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | `[grounded]` resume | pending your approval |

Row 1 is a summary built only from existing sentences. It does not say "demand generation" or give a number of years for it, because your resume doesn't. Rows 2–5 don't add anything; they make the budget and the lifecycle work visible instead of buried inside longer sentences.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| 1 | 5+ years B2B demand gen | must-have | surfaced_by_edit | Row 1. Your resume shows 6 years in B2B SaaS marketing; how many of those were demand gen specifically is not stated (see closing question C2) | `[grounded]` resume |
| 2 | HubSpot or Marketo | must-have | already_evidenced | "HubSpot daily for 4 years". No Marketo appears, and none is claimed | `[grounded]` resume |
| 3 | SQL-literate | must-have | not_evidenced | Absent from the resume. See named absence below | `[grounded]` resume and your note |
| 4 | Managed a budget over $500k | must-have | surfaced_by_edit | Rows 2–3. Your budget is about $600k a year, currently inside the paid-search sentence | `[grounded]` resume |
| 5 | Paid search | important | already_evidenced | "Ran paid search and paid social" | `[grounded]` resume |
| 6 | Lifecycle email | important | surfaced_by_edit | Rows 1 and 5. "12 automated flows" is currently buried in the HubSpot sentence | `[grounded]` resume |
| 7 | Webinars | important | already_evidenced | "Ran a monthly webinar series, average 300 registrants" | `[grounded]` resume |
| 8 | Content distribution | important | not_evidenced | Nothing on the resume. See recall prompt C4 | `[grounded]` resume is silent |

## Gap handling

**Recall prompt**

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C4 | Own content distribution | important | Nothing. The resume doesn't mention content | `[grounded]` the posting lists it as one of four areas you would own; `[generic]` a screener reading that list will look for it | Promoting blog posts or gated assets through paid or email channels; newsletter sends; partner or social syndication | A distribution plan, a content calendar, or a campaign report with reach numbers | `[grounded]` resume is silent; `[generic]` screening reads posting scope |

**Named absence**

| # | Requirement | Priority | The gap | What closing it would take | Provenance |
|---|---|---|---|---|---|
| 3 | SQL-literate | must-have | You've said you aren't strong in SQL and ask your analyst for queries. The posting makes it a must-have, so this is a real gap for this role, not a wording problem | Writing your own queries against HubSpot or warehouse data, regularly, until you can produce a report without the analyst, then a project you can name, such as a campaign-to-pipeline query. `[generic]` that is typically months of practice, not weeks | `[grounded]` your note; `[generic]` time estimate |

## Prohibited claims

Not written, and why:

- **"SQL" or "SQL-literate"**: you've said you're not strong in it and rely on your analyst.
- **"Marketo"**: it isn't in your history.
- **"5+ years of demand gen" or "6 years of demand generation"**: your resume says 6 years of B2B SaaS marketing. The demand-gen share is unknown until you answer C2.
- **"Owned demand generation"**: your resume says "Ran". "Own" is the posting's verb.
- **"Managed a $600k budget"**: your sentence says "budget I controlled". "Managed" is the posting's word, and it would move the claim about your role.
- **Any content-distribution line**: nothing in the resume supports it.
- **Hidden text, white text, or a keyword block**: refused, for the reasons above.

## Parse-safety check

The resume arrived as pasted text, not a file, so I couldn't check the layout. What I can see: no tables or columns in what you pasted. When you send the real file, check three things: it's a .docx or a text-layer PDF; your contact details are in the body, not only in a header or footer; and the section headings are standard labels such as "Experience" and "Skills".

Keywords stay where the evidence already puts them. HubSpot, paid search, paid social, lifecycle email and webinars are all in visible text, and no term is added that you can't defend.

**Upgrade menu**

- **HubSpot report or export for one of the 12 flows, or for the webinar series** (screenshot or CSV). Unlocks outcome figures such as conversion or pipeline. The resume currently has no results, only activity.
- **Exact annual budget figures for the last two or three years.** Unlocks replacing "about $600k" with a precise figure. Until then "about" stays.

**Questions**

- **C4 —** Did you ever own distribution of content, such as promoting blog posts or gated assets, newsletter sends, or partner or social syndication? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.
- **C2 —** Of your 6 years, how many were spent on demand-gen work (paid search, lifecycle, webinars) rather than other marketing? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.