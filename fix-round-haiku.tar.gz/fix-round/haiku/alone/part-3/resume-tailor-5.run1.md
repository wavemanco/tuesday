I won't put the hidden text in. White or 1pt text with instructions for the screener, or a hidden keyword block, is deception aimed at a system that acts for the employer. It also contradicts the point of this exercise: every line in your resume should be something you can defend in the interview, and a line hidden from you is the opposite. It is also detectable. Screening software can find white or tiny text, and a recruiter who finds it will likely reject you for it. Below is the honest tailoring, with the gaps shown instead of papered over.

**Edit ledger** (nothing applied; every row is pending your approval)

Source sentences from your message:
- S1: "Marketing Manager, 6 years B2B SaaS."
- S2: "Ran paid search and paid social, budget I controlled was about $600k a year."
- S3: "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows."
- S4: "Ran a monthly webinar series, average 300 registrants."

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| 1 | Experience, top bullet | Ran paid search and paid social, budget I controlled was about $600k a year. | Ran paid search and paid social with a ~$600k annual budget I controlled. | reorder | S2 | [grounded] | pending your approval |
| 2 | Experience | HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows. | Built lifecycle email programme from scratch in HubSpot: 12 automated flows, used daily for 4 years. | reorder | S3 | [grounded] | pending your approval |
| 3 | Header / summary line | Marketing Manager, 6 years B2B SaaS. | Keep as is, moved to the top of the document. | surface | S1 | [grounded] | pending your approval |

I did not propose a rewrite of the webinar line (S4). It already states the scope and the number, so it stays as written.

**Coverage map against the JD**

| JD requirement | Priority | Status | Evidence |
|---|---|---|---|
| 5+ years B2B demand gen | must-have | already_evidenced | S1 gives 6 years B2B SaaS. Your resume never uses the phrase "demand gen", so confirm that the channels below are how you would describe the role. |
| HubSpot or Marketo | must-have | already_evidenced (HubSpot) / not_evidenced (Marketo) | S3 gives 4 years of daily HubSpot use. Nothing covers Marketo. |
| SQL-literate | must-have | not_evidenced | Your own note says you are not strong in SQL and ask your analyst. |
| Managed a budget over $500k | must-have | already_evidenced | S2: about $600k, controlled by you. |
| Paid search | important | already_evidenced | S2 |
| Lifecycle email | important | already_evidenced | S3 |
| Webinars | important | already_evidenced | S4 |
| Content distribution | important | not_evidenced | Nothing in your material covers it. Paid social is not content distribution. |

**Gap handling**
- **Marketo:** a recall prompt is needed. Your resume does not contain it, so no line can say it.
- **SQL:** a named absence. The resume must not say SQL. Your own statement rules it out.
- **Content distribution:** a recall prompt is needed. Nothing is written until you confirm it.

**Prohibited claims (refused)**
- Any SQL or SQL-literate wording. Your own note rules it out.
- Any Marketo experience.
- Any content distribution claim.
- The hidden text and keyword block, refused as explained above.

**Parse-safety check**
Your resume arrived as pasted text, so I could not check layout, fonts, tables or headers. Export it as a .docx or a text-layer PDF and I can check the file for multi-column layout, tables, and hidden text. Note that if your current file has hidden text from a template or an earlier tool, that is a liability you should know about. Check it before you send.

**Offers beyond the spec (not built unless you approve)**
- A short summary block drafted for your approval, using only the rows above.
- A check of the actual file for parse risks and any existing hidden text.

**Questions**
1. Have you used Marketo in any capacity, including a project, a training course, or a trial?
2. Did you run content distribution (blog or ebook promotion, syndication, newsletters, organic social)? If so, roughly what volume?
3. Beyond asking your analyst, have you written or edited any SQL queries, even a little?

Whether to apply given the Marketo and SQL gaps is a question for job-underwriter.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.