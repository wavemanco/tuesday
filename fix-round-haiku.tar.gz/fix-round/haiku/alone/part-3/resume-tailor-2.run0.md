The must-have "3+ years data engineering" is not met by anything in your material, so the ledger below surfaces the data-engineering work you do have and does not claim the years. Every row is pending your approval, and I have not produced a tailored resume yet.

**Assumptions:** I have no resume file, only your message, so each "Current line" is the sentence as you wrote it there. The ledger's quotes come from that message.

## Coverage map

Research tier: none. This skill runs no searches.

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| 1 | 3+ years data engineering | must-have | not_evidenced | No DE years anywhere in the material. This is a length requirement, so it is graded on fit, not treated as a gate. Adjacent work is in E2, E5 and E6 (transferability, not the years). Recovery: C1 | `[grounded]` what the material says and omits |
| 2 | Production Python | important | surfaced_by_edit | E5 surfaces the scripts that run on a cron. Testing, deployment and on-call are not stated | `[grounded]` |
| 3 | Airflow or equivalent orchestration | important | not_evidenced | Only a cron and a nightly dbt job appear, and what runs the dbt job is not stated. Recovery: C2 | `[grounded]` |
| 4 | Dimensional modelling and warehouse modelling | important | surfaced_by_edit | E4 surfaces the star schema, kept as co-design. E1 and E3 surface the 25 dbt models | `[grounded]` |
| 5 | Build and own batch pipelines | important | surfaced_by_edit | Building and maintaining dbt models and cron pulls is evidence. End-to-end ownership of an ingestion pipeline is not stated, so this is partial | `[grounded]` |
| 6 | Own data quality | important | surfaced_by_edit | E2 surfaces the tests added to the nightly dbt job. Ownership of quality as a whole is not stated | `[grounded]` |
| 7 | Own SLAs | important | not_evidenced | Nothing about freshness or delivery times. Recovery: C3 | `[grounded]` |
| 8 | Partner with analytics on requirements | important | already_evidenced | Five years as Senior Data Analyst shows the analytics side on one read. No explicit stakeholder sentence is needed | `[grounded]` title and tenure |
| 9 | Streaming (Kafka; Spark named in responsibilities) | preferred | not_evidenced | You have never used Kafka or Spark. Named absence: N1 | `[grounded]` |

## Edit ledger

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Summary (new) | *(none)* | Senior Data Analyst, 5 years, retail. SQL every day on Redshift, complex window functions and CTEs. Built and maintained about 25 dbt models including the core orders mart. | `merge` | "Senior Data Analyst, 5 years, retail."; "SQL every day on Redshift, complex window functions and CTEs."; "Built and maintained about 25 dbt models including the core orders mart." | `[grounded]` cv | pending your approval |
| E2 | Experience | "I've fixed our nightly dbt job when it breaks and added tests to it." | Fixed our nightly dbt job when it breaks and added tests to it. | `reframe` | "I've fixed our nightly dbt job when it breaks and added tests to it." | `[grounded]` cv | pending your approval |
| E3 | Experience | "Built and maintained about 25 dbt models including the core orders mart." | *(unchanged, moved to lead the dbt bullets)* | `reorder` | "Built and maintained about 25 dbt models including the core orders mart." | `[grounded]` cv | pending your approval |
| E4 | Experience | "I designed the star schema for the orders mart with our then-DE." | Designed the star schema for the orders mart with our then-DE. | `reframe` | "I designed the star schema for the orders mart with our then-DE." | `[grounded]` cv | pending your approval |
| E5 | Experience | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | Wrote some scripting to pull vendor APIs on a cron. | `split` | "some scripting to pull vendor APIs on a cron" | `[grounded]` cv | pending your approval |
| E6 | Skills | "I write Python for analysis — pandas" | Python (pandas) for analysis. | `split` | "I write Python for analysis — pandas" | `[grounded]` cv | pending your approval |

E1 restores the "5 years" and "retail" details that the current lines drop. E4 keeps "with our then-DE", because the star schema was co-designed. E5 keeps "some", so the scope is not inflated.

## Recovery per gap

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | 3+ years data engineering | must-have | Analyst work with dbt and cron scripts. No pipeline ownership is stated | The years test is read on fit, so the resume has to show pipeline work, not only analyst work | A pipeline you were on-call for, a backfill you ran, or an ingestion script someone else relied on | A job config, a runbook, or a thread about a failure | `[grounded]` what the material does and does not say; `[generic]` what a years-based requirement costs on applications of this kind |
| C2 | Airflow or equivalent orchestration | important | A nightly dbt job and cron pulls. Their scheduler is not named | Orchestration is listed as a requirement, and the scheduler is the first thing a reader will ask about | A scheduler job you configured; a cron job with retries or dependencies; an Airflow DAG you read or edited | The schedule config, or a screenshot of the job list | `[grounded]` what the material omits |
| C3 | Own SLAs | important | Nothing about freshness or delivery times | SLAs are a stated responsibility, and the material has no evidence for them | A "data ready by" time you were held to; a freshness check; an escalation when a dashboard was late | A freshness alert config or a stakeholder message | `[grounded]` what the material omits |

**N1 — Streaming (Kafka, Spark), preferred: not evidenced, nothing to pull.** You have never used Kafka or Spark, and the posting lists streaming as a plus, not a requirement. Closing it would take a small project, such as consuming one public event stream with Kafka locally and loading it into Redshift, or a stint on a streaming team. For this application, closing it is not worth the time, and the cost is that the streaming half of the job is absent from your resume.

## Prohibited claims

Not written, and why:

- **"Data Engineer" as a title, or any retitle to it.** You have never held it, and the title is the claim the JD most wants.
- **"Built and owned batch pipelines" or "owned the nightly pipeline."** You fixed and tested one job. "Owned" describes ownership you have not stated.
- **"Production Python."** The material shows scripts on a cron and analysis in pandas, not production engineering.
- **"Partnered with analytics on requirements."** That is the posting's phrasing. You sat on the analytics side, and "partnered" would move which side of the table you were on.
- **"Modelled the warehouse."** You co-designed the star schema for one mart. The warehouse is larger than that.
- **"Owned data quality."** You added tests and fixed failures. "Owned" overstates it.
- **Airflow, Spark or Kafka in any line.** You said you have never used them, and tools you have not used cannot be surfaced.
- **"SLAs" or "delivery commitments."** Nothing in the material supports them.
- **"Designed the star schema" with "with our then-DE" dropped.** That would turn a joint design into your sole design.

No rows have been rejected yet.

## Parse-safety check

Your resume arrived as pasted text, not as a file. I could not check multi-column layout, tables, text boxes, headers and footers, or file type. Nothing in the plain text suggests a parse risk.

## Upgrade menu

- **Your resume file.** Unlocks the exact current lines (the ledger currently quotes your message, the only copy I have) and a real parse-safety check.
- **The dbt job config or repo.** Unlocks C2, and makes E2 checkable against an artifact rather than your word.
- **A runbook or alert history for the nightly job.** Unlocks C1 and C3.

## Questions

C1 — Before or alongside the analyst work, did you own any pipeline work that someone depended on, such as a job you were paged for, a backfill you ran, or an ingestion script others relied on?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

C2 — What schedules the nightly dbt job and the cron pulls, and did any of them have dependencies, retries or alerts that you set up?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

C3 — Did anyone hold the orders mart or the nightly job to a delivery time or freshness expectation? If so, what was it and how was it checked?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.