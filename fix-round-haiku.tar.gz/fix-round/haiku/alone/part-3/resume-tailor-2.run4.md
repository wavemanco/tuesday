I've loaded the resume-tailor skill and built the ledger from your message. Nothing is applied yet: every row below needs your approval, and the rewritten resume comes only after you approve rows. I used the text you sent as the full current resume, in the order you sent it.

The honest picture: the rewrite can make your dbt and star-schema work prominent, but it can't cover the must-have. Nothing you've described is data-engineering experience under the JD's terms, so I've marked that requirement as not evidenced rather than writing around it.

## Edit ledger

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience | "I designed the star schema for the orders mart with our then-DE." | *(unchanged, moved above the dbt bullet)* | reorder | "I designed the star schema for the orders mart with our then-DE." | `[grounded]` resume | pending your approval |
| E2 | Experience | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | "Write Python for analysis in pandas." | split | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | `[grounded]` resume | pending your approval |
| E3 | Experience | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | "Write some scripting to pull vendor APIs on a cron." | split | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | `[grounded]` resume | pending your approval |
| E4 | Experience | "I've fixed our nightly dbt job when it breaks and added tests to it." | "Added tests to our nightly dbt job." | split | "I've fixed our nightly dbt job when it breaks and added tests to it." | `[grounded]` resume | pending your approval |
| E5 | Experience | "I've fixed our nightly dbt job when it breaks and added tests to it." | "Fixed our nightly dbt job when it breaks." | split | "I've fixed our nightly dbt job when it breaks and added tests to it." | `[grounded]` resume | pending your approval |
| E6 | Skills | *(no current line)* | "Python (pandas), SQL, Redshift, dbt" | surface | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron."; "SQL every day on Redshift, complex window functions and CTEs."; "Built and maintained about 25 dbt models including the core orders mart." | `[grounded]` resume | pending your approval |

Not proposed, deliberately: "Senior Data Analyst, 5 years, retail" stays as it is. Your "never used Airflow or Spark, never touched Kafka" stays out of the resume; it belongs in the coverage map.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| 1 | 3+ years data engineering | must-have | not_evidenced | Your 5 years are as Senior Data Analyst. Nearest evidence: E1, E5. Recall R3. | `[grounded]` what the resume says |
| 2 | Production Python | important | not_evidenced | Python is analysis plus cron scripts; "production" isn't stated. Recall R1. | `[grounded]` |
| 3 | Airflow or equivalent orchestration | important | not_evidenced | Never used Airflow, in your words. Cron and the nightly job's scheduler are nearest; neither is named as orchestration. Recall R2. | `[grounded]` |
| 4 | Dimensional modelling | important | surfaced_by_edit | Star schema for the orders mart, moved up by E1. | `[grounded]` |
| 5 | Build and own batch pipelines | important | surfaced_by_edit | Batch transformation through ~25 dbt models (E6). Ingestion, orchestration and ownership aren't stated. | `[grounded]` |
| 6 | Model the warehouse | important | surfaced_by_edit | One orders mart (E1). No warehouse-wide modelling is stated. | `[grounded]` |
| 7 | Own data quality | important | surfaced_by_edit | Added tests to the nightly dbt job (E4). Ownership of data quality overall isn't stated. | `[grounded]` |
| 8 | Own SLAs | important | not_evidenced | No SLA or freshness target appears. Named absence below. | `[grounded]` |
| 9 | Partner with analytics on requirements | important | not_evidenced | Your material is analytics-side; no requirements work with stakeholders is stated. Named absence below. | `[grounded]` |
| 10 | Streaming (Kafka, Spark) | preferred | not_evidenced | Never used Spark, never touched Kafka. Named absence below. | `[grounded]` |

### Recall prompts

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| R1 | Production Python | important | Analysis in pandas, plus scripts that pull vendor APIs on a cron. | A reviewer will ask whether anything you ran was depended on. | Vendor-API cron scripts that other people or reports relied on; any retries, alerts or tests you added. | Repo, the cron config, a note on a failure you handled. | `[grounded]` what the resume says; `[generic]` what this costs on applications of this kind |
| R2 | Orchestration; SLAs | important | "Fixed our nightly dbt job when it breaks." | Airflow and SLAs both come up in this role. | The scheduler behind the nightly job or the cron scripts, even if it wasn't Airflow; a finish time someone relied on. | Schedule config, a job-failure alert, an incident note. | `[grounded]` what the resume says; `[generic]` what this costs on applications of this kind |
| R3 | 3+ years data engineering | must-have | Five years as a Senior Data Analyst, with dbt and star-schema work. | This is the must-have, and the resume doesn't show it directly. | Years where building or operating pipelines was a main part of the job, not just consuming them. | Dates on the dbt and star-schema work, a project list. | `[grounded]` what the resume says; `[generic]` what this costs on applications of this kind |

### Named absences

| Requirement | The gap | Closing path | Provenance |
|---|---|---|---|
| Own SLAs | Nothing in your material is a commitment on timeliness or availability. | Name one timing expectation for a job someone relies on, and track it for a few months. If nobody relied on the nightly job's timing, this stays a real gap for this role. | `[generic]` what closing it typically takes |
| Partner with analytics on requirements | Your material shows you on the analytics side, not gathering requirements for a pipeline. | If you scoped a pipeline change with analysts, that's a line to write. If not, the honest story is the star-schema work with your then-DE. | `[grounded]` what the resume says |
| Streaming (Kafka, Spark) | No streaming or Spark work. It's listed as preferred. | A small streaming project would take weeks, not months. Worth it only if you want streaming in an interview. | `[generic]` what closing it typically takes |

## Not written, and why

- **"Data Engineer" as a title, or "data engineering experience"**: your 5 years are analyst work, and the must-have is 3+ years of data engineering.
- **"Pipelines" for the dbt models**: that's the posting's word. Your sentence says "dbt models."
- **"Owned the nightly job" or "owned data quality"**: your sentences say you fixed it and added tests.
- **"Production Python"**: not stated anywhere in your material.
- **Airflow, Spark or Kafka in skills**: you've never used them, in your words.
- **Any streaming claim.**
- **"Warehouse modelling" or "designed the warehouse"**: you designed one mart's star schema.
- **"Partnered with analytics on requirements"**: not in your material.
- **Any SLA claim**: none in your material.

## Upgrade menu (offers, built only if you want them)

- **x:** A small repo that reruns one of your vendor-API cron scripts as an Airflow DAG with retries and a failure alert. It would give you an artifact for the orchestration and production-Python gaps.
- **x:** A summary line drafted from E1, E4 and E6, once those rows are approved.

## Questions

1. **R1:** Were the vendor-API cron scripts relied on by anyone else, and did they have retries, alerts or tests? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.
2. **R2:** What scheduled the nightly dbt job and the cron scripts (cron, dbt Cloud, Airflow, something else)? When it failed, did you own getting it back on time? Same answer options.
3. **R3:** Of the five years, roughly how much was building or operating data pipelines versus analysis? Same answer options.

Reply with which rows you approve, reject or change, and the rewritten resume follows from the approved ones.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.