I've built the ledger from your CV text alone. Nothing is applied yet, and every row is pending your approval.

The CV already holds most of the JD. The strongest traceable evidence is the 380ms to 95ms p99 cut and the 40k requests/minute service. The gaps that the CV cannot close are row 5 (mentoring beyond onboarding, a must-have) and rows 6, 9 and 10 (design authorship, product roadmap work, build-cache domain). The changes below only restructure what you wrote. None adds a claim. I took the CV to be the pasted text, so "Current line" shows your sentences as written.

## Edit ledger

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| 1 | Summary (new) | *(no current line)* | "Senior Software Engineer, 7 years. Go and Rust daily for 4 years, Python before that. Own three services in our ledger pipeline; one handles about 40k requests/minute at peak. Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer. Has run six incidents as incident commander." | `merge` | "Senior Software Engineer, 7 years."; "Go and Rust daily for 4 years, Python before that."; "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak."; "Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer."; "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | `[grounded]` CV, pasted text | pending your approval |
| 2 | Experience | "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | (a) "On-call rotation every fourth week for two years." (b) "Ran six incidents as incident commander." | `split` | "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | `[grounded]` CV, pasted text | pending your approval |
| 3 | Experience | "I do onboarding for new hires on my team — usually two or three a year, I pair with them for their first month." | "Onboard new hires on my team, usually two or three a year, pairing with each for their first month." | `compress` | "I do onboarding for new hires on my team — usually two or three a year, I pair with them for their first month." | `[grounded]` CV, pasted text | pending your approval |
| 4 | Skills | "CV also lists: Kafka, Postgres, Terraform, gRPC, Datadog." | "Kafka, gRPC, Postgres, Terraform, Datadog." | `reorder` | "CV also lists: Kafka, Postgres, Terraform, gRPC, Datadog." | `[grounded]` CV, pasted text | pending your approval |

Row 3 keeps your word "pair" and does not write "mentor". Row 4 lists Kafka and gRPC first without tying them to any service. A listed tool is still only listed, and the interviewer will ask what you did with it.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| 1 | 5+ years backend | must-have | already_evidenced | "7 years" is total engineering time. The CV does not say how many of those years were backend. The ledger-pipeline services carry that reading. | `[grounded]` CV |
| 2 | Production Go | must-have | surfaced_by_edit | Row 1: "Go and Rust daily for 4 years". The CV says "daily", not "production". A live pipeline at 40k requests/minute makes the reading fair, but the row does not use the word. | `[grounded]` CV |
| 3 | Distributed systems at scale | must-have | surfaced_by_edit | Rows 1 and 4: 40k requests/minute at peak; Kafka and gRPC listed. The CV does not describe how the services are distributed or what Kafka did, so "distributed" is not written. | `[grounded]` CV |
| 4 | Strong incident response | must-have | surfaced_by_edit | Row 2: the on-call rotation and six incidents run as incident commander, currently one buried sentence. "Strong" is a judgement the reader makes, not one the CV states. | `[grounded]` CV |
| 5 | Experience mentoring, including mid-level engineers | must-have | not_evidenced | Adjacent: row 3, onboarding and first-month pairing for two or three hires a year. Nothing beyond onboarding is stated. Recall prompt R1. | `[grounded]` CV |
| 6 | Design and ship Go services at high request volume | important | not_evidenced | Adjacent: "Own three services" and the 40k requests/minute service. Owning is stated; design authorship is not. Recall prompt R3. | `[grounded]` CV |
| 7 | Drive down p99 latency | important | already_evidenced | "Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer." Already in the CV as written. | `[grounded]` CV |
| 8 | Own on-call for your services | important | already_evidenced | "On-call rotation every fourth week for two years." The CV does not say the rotation covers the services you own, so that link is not written. | `[grounded]` CV |
| 9 | Partner with product on roadmap sequencing | important | not_evidenced | Nothing in the CV about product work. Recall prompt R2. | `[grounded]` CV |
| 10 | Build-cache or developer-tools platform | important | not_evidenced | Adjacent: the cache-layer rework is on a payments balance-read path. Transferable, not direct. Named absence below. | `[grounded]` CV |

Requirement 1 is marked already_evidenced because a reader can see seven years and services in a live pipeline on one read. Requirement 7 needs no edit. There are no hard gates in this JD.

## Gap handling

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| R1 | Experience mentoring, including mid-level engineers | must-have | Onboarding and first-month pairing for two or three new hires a year. Nothing beyond onboarding. | `[grounded]` The JD lists mentoring as a requirement, separate from its responsibilities. `[generic]` Interviewers usually probe mentoring with one named engineer and an outcome. | Guiding a mid-level engineer over several months on design, code review or a growth goal; a promotion case you wrote or supported. | A note, feedback summary or promotion packet from the engineer. | `[grounded]` the JD's requirement; `[generic]` the probing pattern |
| R2 | Partner with product on roadmap sequencing | important | Nothing about product work. | `[grounded]` The JD names it as a responsibility. `[generic]` Sequencing claims are checked with a specific decision. | A roadmap decision you shaped with a product owner, such as whether the cache rework came before a feature. | A roadmap doc, planning thread or ticket that records the sequencing discussion. | `[grounded]` the JD's responsibility; `[generic]` the checking pattern |
| R3 | Design and ship Go services at high request volume | important | "Own three services in our ledger pipeline." Design authorship is not stated. | `[grounded]` The JD asks you to design and ship. | A design doc you wrote, or an architecture decision you made and can defend. | A design doc, ADR or RFC with your name on it. | `[grounded]` the JD's responsibility |

Row 10 has a named absence. You have not worked on a build cache or developer tooling, and the JD names one as the platform you would own. A caching or build-adjacent project you designed or ran would close it. Without one, the honest line is that the cache rework was on a payments balance-read path, and it transfers. It does not show build-cache experience.

## Not written, and why

- **"Mentored mid-level engineers" or "experienced mentor".** Your sentences say onboarding and first-month pairing. "Mentor" is the JD's word, and "mid-level" scope is not in your sentences.
- **"Designed" or "architected" the services.** Your CV says own. Design authorship is not stated.
- **"Led incident response" or "strong incident response" as a self-description.** Your CV says "run" six incidents as incident commander. "Led" raises your role, and "strong" is the JD's word.
- **"Distributed systems" as a claim about your work.** You gave the volume and listed Kafka and gRPC, but not the topology.
- **"Production Go".** Your CV says "Go and Rust daily". Owning live-pipeline services makes the phrase likely true, but it is not your sentence.
- **"Backend" as a title or as a years count.** Your title is Senior Software Engineer, and "backend" is not stated.
- **"Reduced latency across the platform".** The cut was on one path, the balance-read path.
- **"Owned on-call for the build-cache services".** Your CV does not name the services the rotation covers.
- **"Partnered with product" or "build-cache experience".** Neither is stated in your CV.

Rejected rows: none yet, since nothing has been approved or rejected.

## Parse-safety check

Your CV arrived as pasted text, not a file. So I could not check layout, tables, text boxes, images or headers and footers, and I cannot say whether contact details would survive extraction.

What I could see:
- **No section headings.** The paste has no labels such as "Experience" or "Skills". The skills list follows "CV also lists:", which a section detector may not read as a skills section. The cost is that the tools may not be attributed to any section.
- **No employer names, role titles or dates.** A parser that loses dates loses the link between each role and its period. If your actual file has them, run the check on the file.

## Offer

- **Offer:** Incident write-ups or a runbook for the six incidents you ran would make the incident-response claim inspectable rather than self-reported. This is an optional addition and I would only build it from documents you supply.

## Questions

R1 — Did you ever guide a mid-level engineer past their first month, on design, code review or a promotion case? If so, what happened?

R2 — Can you name one roadmap call you shaped with product, such as whether the cache rework went before a feature?

R3 — For one of the three services you own, did you write the design doc or choose the architecture? What did you decide?

Answer each in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.