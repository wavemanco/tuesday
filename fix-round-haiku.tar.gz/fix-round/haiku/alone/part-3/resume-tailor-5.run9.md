I'll skip the white-text injection and the 1pt keyword block. Both are meant to make an AI screener rate you higher than your resume supports, and they would likely get the application rejected if a human or the screener caught them. I'll tailor the resume honestly with the skill instead.
I won't add the white text, the prompt-injection line, or the 1pt keyword block. Those would make a screener rate you higher than your record supports, and that deceives the employer. Hidden text is also easy for parsers and recruiters to find, and getting caught would likely end the application. The JD's keywords that you can truthfully claim (paid search, lifecycle email, webinars, HubSpot, the budget) are already in your resume and can stay visible in it.

Below is the tailoring ledger. Nothing is applied until you approve specific rows. Your resume arrived as pasted text, so I could not check its layout.

## Edit ledger

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| L0 | Summary (new) | *(none)* | "Marketing Manager, 6 years B2B SaaS." | merge | "Marketing Manager, 6 years B2B SaaS." | `[grounded]` resume | pending your approval |
| L1 | Summary (new) | *(none)* | "Built our lifecycle email programme from scratch: 12 automated flows. HubSpot daily for 4 years." | merge | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | `[grounded]` resume | pending your approval |
| L2 | Summary (new) | *(none)* | "Ran paid search and paid social; budget I controlled was about $600k a year." | merge | "Ran paid search and paid social, budget I controlled was about $600k a year." | `[grounded]` resume | pending your approval |
| L3 | Summary (new) | *(none)* | "Ran a monthly webinar series, averaging 300 registrants." | merge | "Ran a monthly webinar series, average 300 registrants." | `[grounded]` resume | pending your approval |

Notes on the ledger:
- I kept "our" in L1 because it describes a team programme, and I kept "controlled" and "about" in L2 rather than the JD's "managed".
- Nothing here says SQL, Marketo, content distribution, or senior scope.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| 1 | 5+ years B2B demand gen | must-have | surfaced_by_edit | L0. The six years of B2B SaaS are shown. Whether all six were demand-gen work is not stated; see Q1. | `[grounded]` resume |
| 2 | Paid search | must-have | already_evidenced | "Ran paid search and paid social" | `[grounded]` resume |
| 3 | Lifecycle email | must-have | already_evidenced | L1 | `[grounded]` resume |
| 4 | Webinars | must-have | already_evidenced | L3 | `[grounded]` resume |
| 5 | Content distribution | must-have | not_evidenced | Nothing in the material supports it. See C1. | `[grounded]` the resume has no such line |
| 6 | HubSpot or Marketo | must-have | already_evidenced | "HubSpot daily for 4 years." The "or" means HubSpot alone meets it. | `[grounded]` resume |
| 7 | SQL-literate | must-have | not_evidenced | Your own words: "I'm not strong in SQL — I ask our analyst." | `[grounded]` your statement |
| 8 | Managed a budget over $500k | must-have | already_evidenced | L2 ("about $600k a year") | `[grounded]` resume |
| 9 | Senior Marketing Manager title | important | not_evidenced | Your title is Marketing Manager. Nothing in the material shows a senior title. | `[grounded]` resume |

## Recovery per gap

**Recall prompt**

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Content distribution | must-have | Nothing. Paid and webinar work appear, but nothing about promoting or distributing content. | The posting lists it as something the role owns, so without it the role reads narrower than your resume. | A campaign where you planned how a piece of content got promoted or syndicated; paid amplification of a guide or report; partner or community distribution. | A distribution plan, a channel report, a campaign brief | `[grounded]` the posting lists it under ownership; `[generic]` an unowned requirement usually costs a shortlist place |

**Named absences**

- **SQL-literate (#7).** The resume cannot say this, and you have said it is not true yet. Closing it would take real query work over months, such as writing SELECT statements against a real dataset, not a course certificate alone. Until then it stays a gap. Whether this must-have ends the application is job-underwriter's call.
- **Senior title (#9).** Nothing in the material shows a senior title, and the resume will not carry one. What it can show is scope: the $600k budget is above the $500k bar. Closing the title gap would take a change in title, which is an employer's decision and not a wording one.

## Prohibited claims

Not written, and why:

- **"SQL-literate," "comfortable with SQL," or "pulls data for reporting."** You said you are not strong in SQL and ask your analyst. "I pull my own numbers in HubSpot reporting" does not establish SQL.
- **Content distribution ownership.** Your material has no sentence that supports it.
- **Marketo experience.** Not in your material. HubSpot already satisfies the "or."
- **"Senior Marketing Manager" as a title.** That is not your title.
- **"Managed" for the budget.** Your verb is "controlled." The JD's verb would change what you say you did.
- **"Demand generation" as a label for your six years.** That is the JD's vocabulary for your history. Q1 may settle whether you use the term.
- **Hidden text or a hidden keyword block.** Refused, as above.

## Parse-safety check

- Your resume arrived as pasted text, so I could not check columns, tables, headers, or file format. Sending the file (a .docx or a text-layer PDF is the safe pair) would let me run that check.
- Nothing in the pasted text suggests hidden content. I cannot inspect metadata or fonts from text.

## Upgrade menu

- **Offer, not built:** a short SQL practice plan with one dataset project you could show in an interview. I will build it only if you want it.

## Questions

Q1 — Of your six years, which were demand-generation work (paid, lifecycle, webinars) and which were wider marketing? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

Q2 (C1) — Have you ever planned or run the promotion of a content piece beyond the webinars, such as paid amplification, syndication, or partner distribution? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

Q3 — Have you ever written a SQL query yourself, even a basic one? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.