I won't add the hidden white text or the 1pt keyword block. Both are meant to deceive the screener, and a recruiter who finds them will likely reject you. I'll tailor the resume from your real experience, using the skill for that.
I won't add the white text or the 1pt keyword block. Screeners and recruiters can see both, and hidden text aimed at an automated screener is the kind of thing that gets candidates rejected or flagged. Everything below is built only from what you wrote. Nothing is applied until you approve specific rows.

## Edit ledger

Your resume arrived as one paragraph of pasted text, so each row quotes that paragraph.

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| R1 | Experience | "Ran paid search and paid social, budget I controlled was about $600k a year." | "Ran paid search and paid social." | `split` | "Ran paid search and paid social, budget I controlled was about $600k a year." | `[grounded]` resume | pending your approval |
| R2 | Experience | (same sentence as R1) | "Budget I controlled: about $600k a year." | `split` | "budget I controlled was about $600k a year" | `[grounded]` resume | pending your approval |
| R3 | Experience | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | "Built our lifecycle email programme from scratch: 12 automated flows." | `split` | "built our lifecycle email programme from scratch, 12 automated flows" | `[grounded]` resume | pending your approval |
| R4 | Experience | (same sentence as R3) | "Used HubSpot daily for 4 years." | `split` | "HubSpot daily for 4 years" | `[grounded]` resume | pending your approval |
| R5 | Experience | "I pull my own numbers in HubSpot reporting but I'm not strong in SQL — I ask our analyst." | *(cut)* | `cut` | "I pull my own numbers in HubSpot reporting but I'm not strong in SQL — I ask our analyst." | `[grounded]` resume | pending your approval |

Notes on the rows:
- R1 and R2 separate the paid-channel fact from the budget fact. The budget line keeps "controlled" and does not become "managed". The resume doesn't say the $600k covered only paid channels, so I haven't attached it to them.
- R3 gives the lifecycle work its own line. The resume doesn't say what the 12 flows did, so nothing is added.
- R5 removes the SQL disclaimer. That is a presentation choice, not a claim. The gap stays on the coverage map and in your interview prep.

No summary line is proposed. Any summary would need content the resume doesn't yet support.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| 1 | 5+ years B2B demand gen | must-have | already_evidenced | "6 years B2B SaaS" plus paid, lifecycle and webinar work. Whether that counts as demand-gen ownership is open (Q2). | `[grounded]` resume |
| 2 | HubSpot or Marketo | must-have | already_evidenced | "HubSpot daily for 4 years" (R4) | `[grounded]` resume |
| 3 | SQL-literate | must-have | not_evidenced | Named absence below | `[grounded]` resume, which says "not strong in SQL" |
| 4 | Managed a budget over $500k | must-have | surfaced_by_edit | R2 | `[grounded]` resume |
| 5 | Paid search | important | surfaced_by_edit | R1 | `[grounded]` resume |
| 6 | Lifecycle email | important | surfaced_by_edit | R3 | `[grounded]` resume |
| 7 | Webinars | important | already_evidenced | "Ran a monthly webinar series, average 300 registrants." (unchanged) | `[grounded]` resume |
| 8 | Content distribution | important | not_evidenced | Recall prompt C1 below | `[grounded]` resume, which doesn't mention it |

## Gap handling

**Content distribution (C1, recall prompt).** The resume doesn't show this. Did any of your six years involve distributing content such as guides, case studies or recordings through paid social, email or webinar promotion? Anything like that could go on the resume, but only as you describe it.

**SQL-literate (named absence).** The resume says you are not strong in SQL and rely on your analyst. Closing this gap would mean writing queries yourself, for example against HubSpot exports or a warehouse, and being able to describe what you pulled and why. Until then, leave it off the resume. If the job requires it, be ready to say what you can do without writing queries yourself.

## Not written, and why

- **Hidden white text or a 1pt keyword block.** Refused, for the reason above.
- **"SQL-literate" or "SQL experience".** Your resume says you are not strong in SQL.
- **"Owned demand generation" or "owned the demand-gen plan".** The resume shows paid, lifecycle and webinar work, not ownership of the plan. Q2 asks about this.
- **"Content distribution".** Not evidenced yet (C1).
- **"Marketo".** Not in your resume. You don't need it, since the JD accepts HubSpot.
- **"Managed a budget over $500k".** Your line is "budget I controlled was about $600k a year". I kept "controlled" to avoid a verb upgrade.
- **"300 attendees" or "300 leads".** The resume says 300 registrants, and the number stays with that noun.
- **"Analytics" or "data-driven" as a skill.** You pull your own numbers in HubSpot reporting, which is not the same as owning analytics.

## Parse safety

The resume came in as pasted text, so I couldn't check its layout or any file format. Pasted text has no column, table or header issues. If you send the file, I can check it for multi-column layout, text boxes, header contact details and unusual section headings.

## Possible addition (offered, not built)

- A two-line summary built only from R1 to R4, with the trace quoted beside each line. I'd build it only if you approve it.

## Questions

1. **Q2:** Across your six years, did you own the demand-gen plan and its targets, or did you run paid, lifecycle and webinar channels inside someone else's plan?
2. **Q3:** Have you ever written a query yourself, even in HubSpot's report builder or a spreadsheet export?
3. **C1:** Did any of your six years involve distributing content such as guides, case studies or recordings through paid social, email or webinar promotion? Answer in text or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.