I built the ledger from the facts in your message, since the full CV text wasn't pasted. The "Current line" column is marked not seen for that reason. If you paste the CV, I can show the real before-and-after and run the parse-safety check on its layout.

**Coverage map**

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| 1 | 5+ years backend | must-have | surfaced_by_edit | E1 (7 years). The word "backend" isn't in your material, so no row writes it. | [grounded] |
| 2 | Production Go | must-have | surfaced_by_edit | E1 (Go daily for 4 years). Whether the ledger services are Go is open (Q3). | [grounded] |
| 3 | Design and ship Go services at high request volume | must-have | surfaced_by_edit | E2 (three services, about 40k requests/minute at peak). Go attaches here only if Q3 confirms it. | [grounded] |
| 4 | Distributed systems at scale | must-have | not_evidenced | Nothing describes distributed work. E2 gives scale only. Recall prompt C1. | [grounded] |
| 5 | Drive down p99 latency | must-have | surfaced_by_edit | E3 | [grounded] |
| 6 | Own on-call for your services | must-have | surfaced_by_edit | E4 (rotation every fourth week for two years) | [grounded] |
| 7 | Strong incident response | must-have | surfaced_by_edit | E4 (six incidents as incident commander). "Strong" is not writable; the count is the evidence. | [grounded] |
| 8 | Experience mentoring | must-have | surfaced_by_edit | E5 (onboarding, pairing for the first month) | [grounded] |
| 9 | Mentor mid-level engineers | important | not_evidenced | Onboarding is not mentoring mid-level engineers. Recall prompt C2. | [grounded] |
| 10 | Own services in the build-cache platform | must-have | not_evidenced | Nothing in your material. Adjacent: the cache-layer rework in E3. Named absence below. | [grounded] |
| 11 | Partner with product on roadmap sequencing | important | not_evidenced | Nothing in your material. Named absence below. | [grounded] |

No requirement is already_evidenced as written, because I haven't seen your current lines.

**Edit ledger** (all rows pending your approval)

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Summary (new) | (no current line) | "Senior Software Engineer, 7 years. Currently at a payments company. Go and Rust daily for 4 years, Python before that." | merge | "Senior Software Engineer, 7 years."; "Currently at a payments company."; "Go and Rust daily for 4 years, Python before that." | [grounded] | pending your approval |
| E2 | Experience, ledger pipeline | (not seen) | "Own three services in our ledger pipeline; one handles about 40k requests/minute at peak." | surface | "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak." | [grounded] | pending your approval |
| E3 | Experience, performance | (not seen) | "Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer." | surface | "Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer." | [grounded] | pending your approval |
| E4 | Experience, on-call | (not seen) | "On-call rotation every fourth week for two years; ran six incidents as incident commander." | surface | "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | [grounded] | pending your approval |
| E5 | Experience, onboarding | (not seen) | "Onboard new hires on my team — usually two or three a year — and pair with each for their first month." | compress | "I do onboarding for new hires on my team — usually two or three a year, I pair with them for their first month." | [grounded] | pending your approval |

To approve, reply with the row numbers, for example "Approved: E1, E2, E3" with any rejections and their reasons. The Kafka, Postgres, Terraform, gRPC and Datadog list gets no row. Those tools stay in the list and are not attached to any service.

**Gap handling**

Recall prompts (the questions are in the closing block):

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Distributed systems at scale | must-have | A 40k requests/minute peak, and Kafka and gRPC listed by name, with no account of distributed work | The first systems requirement in the JD | A failure where one service's behavior depended on another's: consumer lag, a gRPC timeout, a retry storm, a consistency problem between ledger services | A design doc, an incident write-up, a Datadog dashboard | [grounded] for what the resume shows; [generic] for the claim that a scale number alone rarely establishes distributed work to a reader |
| C2 | Mentor mid-level engineers | important | Onboarding of two or three new hires a year, paired for a first month | The JD names mid-level mentoring as the job; onboarding is a different act | A mid-level engineer you coached over months toward a goal; a growth plan or feedback you wrote for someone | A 1:1 plan, a note, a promotion case you wrote | [grounded] for what the resume shows; [generic] for what this costs on applications of this kind |

Named absences:

- **Build-cache platform.** Nothing in your material is a build cache or CI cache. The cache-layer rework in E3 is a read-path cache in payments, not the same system. Closing this takes real time on a build or CI cache system, several months at least. It is not closable by rewording, and I won't write around it.
- **Roadmap sequencing with product.** Nothing in your material shows you setting scope or order with product. Closing it means a shipped feature where you negotiated what went in and when, written up with dates.

**Not written, and why**

- "Backend engineer" for your seven years. The word is the JD's, not yours. E1 states the years and the work.
- "Built" or "designed" the cache layer. You reworked it, and the verb stays "reworked."
- "Strong incident response." The six incidents are the evidence. "Strong" is a judgement you would be asked to defend.
- "Owned on-call," or "led" or "mentored mid-level engineers." You did the rotation. Onboarding is not mentoring mid-level engineers.
- "Partnered with product on roadmap sequencing." Nothing in your material supports it.
- "Distributed systems at scale" as a heading. The number and the tool names are what you have.
- Any tool attached to a named service or task. A listed tool is not a tool you owned.
- Dropping "usually" from onboarding. That would turn a typical pattern into a fixed one. E5 keeps it.
- "About" and "at peak" stay in E2. The 40k figure is not presented as a sustained rate.

**Parse-safety check**

Not run. Nothing was supplied as a file, so I cannot see layout, columns, headers or tables. The proposed lines are plain text. Send the CV as a .docx or a text-layer PDF and I'll run the six checks.

**Upgrade menu**

- **Your current CV file or pasted text.** Replaces the "not seen" lines with real diffs and checks the layout for parse risks.
- **A design doc, incident write-up or dashboard for the p99 work (E3).** Makes that row inspectable, which makes it stronger in an interview.

**Questions**

C1: Think of a case where one of your ledger services failed or slowed because another service did, through Kafka, gRPC or a retry. What happened, and what did you change?

C2: Have you coached a specific mid-level engineer over several months toward a goal, such as a promotion or a stronger area of ownership? What did you do, and what changed?

Q3: Are the three ledger services written in Go?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.