Nothing below is applied yet. This is the ledger: five proposed edits, each traced to a sentence in your message, plus a coverage map of the posting. A rewrite can make your real pipeline work easier to see, but it cannot meet the 3+ years data engineering must-have, and nothing here claims it does. Whether to apply at all, given that must-have, is job-underwriter's call.

I'm working from the resume as you described it in your message, not a document. The "Traces to" quotes are verbatim from your message, so check them against the actual file before you approve anything.

Priority is my reading: the posting labels only the 3+ years as must-have. I've treated Python, orchestration, dimensional modelling and the listed responsibilities as important, and streaming as preferred.

## Edit ledger

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience | "Built and maintained about 25 dbt models including the core orders mart." | Unchanged text, moved to the top of Experience | reorder | "Built and maintained about 25 dbt models including the core orders mart." | `[grounded]` resume | pending your approval |
| E2 | Experience | "I've fixed our nightly dbt job when it breaks and added tests to it." | "Fixed our nightly dbt job when it breaks and added tests to it." | compress | "I've fixed our nightly dbt job when it breaks and added tests to it." | `[grounded]` resume | pending your approval |
| E3a | Experience | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | "Wrote Python for analysis in pandas." | split | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | `[grounded]` resume | pending your approval |
| E3b | Experience | (same sentence, second clause) | "Wrote some scripting to pull vendor APIs on a cron." | surface | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | `[grounded]` resume | pending your approval |
| E4 | Experience | "I designed the star schema for the orders mart with our then-DE." | Own bullet, placed directly under E1. "Designed the star schema for the orders mart with our then-DE." | surface | "I designed the star schema for the orders mart with our then-DE." | `[grounded]` resume | pending your approval |

Notes on the rows:
- E3a and E3b split one sentence that does two jobs. Each half traces on its own, and neither is developed beyond what you wrote.
- E3b keeps "some". Dropping it would make the scripting sound larger than you described it.
- E4 keeps "with our then-DE" so the shared design stays visible. Shortening it to "Designed the star schema" would claim sole ownership.
- Your title stays "Senior Data Analyst". No row retitles you toward data engineering.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| 1 | 3+ years data engineering | must-have | not_evidenced | No data-engineering tenure is stated. Adjacent dbt and orders-mart work is in E1 and E2, with no dates. Recall prompt C1. | `[grounded]` resume: "Senior Data Analyst, 5 years" |
| 2 | Production Python | important | not_evidenced | The cron-scheduled vendor scripts (E3b) are the closest evidence. Whether they run in production is unknown. C2. | `[grounded]` resume |
| 3 | Airflow or equivalent orchestration | important | not_evidenced | Nothing names a scheduler for the nightly dbt job or the cron pulls. C3. | `[grounded]` resume: "Never used Airflow or Spark." |
| 4 | Dimensional modelling | important | surfaced_by_edit | Evidence is the star schema, moved by E4. | `[grounded]` resume |
| 5 | Build and own batch pipelines | important | surfaced_by_edit | E1 and E2 show batch transformation work. Ownership of an ingestion-to-warehouse pipeline is not stated. | `[grounded]` resume |
| 6 | Model the warehouse | important | surfaced_by_edit | E1 and E4 show modelling for one mart, not the warehouse. | `[grounded]` resume |
| 7 | Own data quality | important | surfaced_by_edit | E2 (tests added). Ownership is not stated. | `[grounded]` resume |
| 8 | Own SLAs | important | not_evidenced | Nothing in the resume mentions an SLA. Named absence below. | `[grounded]` resume |
| 9 | Partner with analytics on requirements | important | not_evidenced | The analyst role implies it, but no line says it. Named absence below. | `[grounded]` resume |
| 10 | Spark (named in responsibilities) | important | not_evidenced | "Never used Airflow or Spark." Named absence below. | `[grounded]` resume |
| 11 | Streaming (Kafka) | preferred | not_evidenced | "Never touched Kafka." Named absence below. | `[grounded]` resume |

## Gap handling

Recall prompts. Each asks for a specific memory the resume doesn't show. The questions are in the closing block.

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | 3+ years data engineering | must-have | 5 years as Senior Data Analyst; dbt and nightly-job work with no pipeline tenure or dates | `[generic]` A years-of-experience must-have is often checked before the rest of a resume is read. | Fixing and testing the nightly dbt job; the cron scripts pulling vendor APIs; designing the orders-mart star schema, if any of these were your main work and not a side task | dbt repo commit history; job run logs; the orders-mart pull request | `[grounded]` what the resume shows; `[generic]` the screening pattern |
| C2 | Production Python | important | Python for analysis in pandas; cron-scheduled vendor scripts | `[generic]` "Production" is usually read as: runs unattended, handles failure, leaves a trace. | Vendor-API scripts that run without you | The script's repo; a run log; any error handling, retries or alerts | `[grounded]` what the resume shows; `[generic]` what "production" usually means to a reader |
| C3 | Airflow or equivalent orchestration | important | Nothing names what schedules the nightly dbt job or the cron pulls | `[generic]` Orchestration with dependencies, retries and alerts is what this role's "own pipelines" implies. | The nightly job's schedule; the cron pulls | Cron entries; a dbt Cloud or Airflow config; alert and retry settings | `[grounded]` what the resume omits; `[generic]` what the role implies |

Named absences. Each gives the gap and the closing path, and nothing gets written around it.
- **Streaming (Kafka), preferred.** You have never touched Kafka, and streaming is the one listed as a plus. Closing it means a real streaming pipeline you built and can show in a repo. A course completion would not count as evidence. Whether that is worth the time is your decision, not this rewrite's.
- **Spark, named in the responsibilities.** You have never used Spark. The closing path is the same as for Kafka: a real Spark job on a real dataset, with a repo to show.
- **Own SLAs.** Nothing in your message names an SLA. If the nightly job has a deadline someone checks ("ready by 7am"), say so and it can become a line. If not, SLAs stay off the resume.
- **Partner with analytics on requirements.** You sit on the analytics side, so that is where your evidence is. No line says you gathered requirements, so none is written. Naming a project where you did is the closing path.

## Not written, and why

- **"Data Engineer" as a title, or "data engineering experience."** You have never held the title, and the must-have is 3+ years of it. The headline "5 years" must not be allowed to imply it.
- **"Owned batch and streaming pipelines."** You fixed and tested one nightly dbt job. "Owned" is an ownership claim, and streaming is absent.
- **"Production Python."** Your message says "for analysis" and "scripting". Nothing says the scripts run in production.
- **"Modelled the warehouse."** You designed the star schema for one mart. "The warehouse" widens the scope from that mart to the whole warehouse.
- **"Partnered with analytics on requirements."** You are the analytics side. Writing it as the engineering side's partnership inverts which side of the table you were on.
- **Airflow, Spark or Kafka in a skills list, even as "familiar".** You said you have never used them.
- **"Led" or "architected" the orders mart.** You designed the star schema with the then-DE. Either word would move your part from shared design to sole ownership.
- **Any number for run time, cost or data volume.** None is in your message.

## Parse-safety check

The resume came to me as a description, not a file, so I could not run the layout, table, header, section-heading or file-type checks. Those need the actual document. Nothing in the description suggests a parsing problem, and I have no hidden-text concern to report.

## Upgrade menu

- **The resume file itself (.docx or text-layer PDF).** Unlocks the parse-safety check and makes the trace quotes checkable against your real wording rather than your message.
- **The nightly dbt job's repo or commit history.** Unlocks C1 and dates the dbt and test work.
- **The vendor-API script's repo.** Unlocks C2 and any evidence of production use.
- **The nightly job's scheduler config or run logs.** Unlocks C3.

## Questions

C1 — Starting with the nightly dbt job and the vendor-API scripts, roughly how many years have you done hands-on pipeline work (ingesting, scheduling, loading, fixing failures) rather than analysis? Give dates if you can.
C2 — Does the vendor-API script run without you, and does it have error handling, logging or alerts? Does it live in a repo?
C3 — What schedules the nightly dbt job and the cron pulls, and do any of them retry, order dependencies or send failure alerts?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.