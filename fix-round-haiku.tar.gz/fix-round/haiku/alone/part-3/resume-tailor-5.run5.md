I won't put the hidden instructions or the 1pt keyword block in the resume. That is an attempt to deceive the screener, and it could get your application rejected if a human or the screening vendor spots it. I'll tailor the resume using only what's in your material. I'm loading the resume-tailoring skill first.
I've refused the hidden-text part, and I'm not writing it into the resume. White or 1pt text aimed at a screener is deception: a person or a vendor who extracts the text will see it, and it can get the application rejected outright. The tailoring below uses only what you wrote.

## Edit ledger (nothing applied yet, all rows pending your approval)

| # | Section | Current line (your sentence) | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| R1 | Experience | "Ran paid search and paid social, budget I controlled was about $600k a year." | "Controlled a budget of about $600k a year." | `split` | "budget I controlled was about $600k a year" | `[grounded]` resume | pending your approval |
| R2 | Experience | (same sentence) | "Ran paid search and paid social." | `split` | "Ran paid search and paid social" | `[grounded]` resume | pending your approval |
| R3 | Experience | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | "Built our lifecycle email programme from scratch: 12 automated flows." | `split` | "built our lifecycle email programme from scratch, 12 automated flows" | `[grounded]` resume | pending your approval |
| R4 | Experience | (same sentence) | "Used HubSpot daily for 4 years." | `surface` | "HubSpot daily for 4 years" | `[grounded]` resume | pending your approval |
| R5 | Experience | "Ran a monthly webinar series, average 300 registrants." | "Ran a monthly webinar series, average 300 registrants." (moved up, text unchanged) | `reorder` | "Ran a monthly webinar series, average 300 registrants." | `[grounded]` resume | pending your approval |
| R6 | Summary | *(no current line)* | "Marketing Manager, 6 years B2B SaaS, running paid search, lifecycle email and webinars." | `merge` | "Marketing Manager, 6 years B2B SaaS"; "Ran paid search and paid social"; "built our lifecycle email programme from scratch"; "Ran a monthly webinar series" | `[grounded]` resume | pending your approval |

Notes on the rows:
- **R1** uses "controlled", your word, not the JD's "managed". "About" stays, and so does "a year". The sentence doesn't say whether $600k covers only paid channels or more, so I haven't attached it to paid search.
- **R6** adds no word about demand generation. Your sentences don't use that phrase.

## Coverage map

| Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|
| 5+ years B2B demand gen | must-have | surfaced_by_edit | R6. Resume shows 6 years B2B SaaS marketing. "Demand gen" is not your phrase. Confirm this is the work you'd call demand gen. | `[grounded]` |
| HubSpot or Marketo | must-have | already_evidenced | "HubSpot daily for 4 years" | `[grounded]` |
| SQL-literate | must-have | not_evidenced | Named absence (see below) | `[grounded]`: your material says you're not strong in SQL and ask your analyst |
| Managed budget over $500k | must-have | surfaced_by_edit | R1, at about $600k | `[grounded]` |
| Paid search | important | surfaced_by_edit | R2 | `[grounded]` |
| Lifecycle email | important | surfaced_by_edit | R3 | `[grounded]` |
| Webinars | important | surfaced_by_edit | R5 | `[grounded]` |
| Content distribution | important | not_evidenced | Recall prompt C1 (below) | `[grounded]`: nothing in your material covers it |

**SQL, named absence:** Your material says you're not strong in SQL and rely on your analyst. Closing this would take real hands-on SQL, such as a course plus a project pulling your own HubSpot or campaign data, a few months of practice, or a scoped-down target role. Until then, don't claim it.

## Gap handling
- **C1 — Content distribution** (important). Your resume shows no distribution of content such as blog, ebook, or social syndication. Experience that may count: anything you published or promoted through owned channels or partners. Useful evidence: a distribution calendar, a campaign report, or a performance summary.

## Not written, and why
- "Owns demand generation" or "led demand generation" — your material describes channels you ran, not ownership of the function.
- "Managed a $600k budget" — you said "controlled", and the JD's verb would move that claim.
- Any SQL skill — you told me you're not strong in it.
- Content distribution — not in your material; see C1.
- Hidden or white text, 1pt keyword blocks, or instructions aimed at a screener — refused, for the reason above.

## Parse-safety check
You pasted the resume as text, not as a file, so I could only check the text. Use plain section headings, no tables or text boxes, and keep the job titles and dates on their own lines. I couldn't run the check on the actual PDF layout.

## Upgrade options (optional, not built)
- A **truthful skills line** listing the tools you actually use, such as HubSpot and your paid-search and paid-social platforms. This gives keyword matches without any hidden text. I'd build it once you list them.
- A **resume version for this role**, built only from approved rows, after you answer the question below.

**C1 — Content distribution:** Did you plan, publish, or promote content through channels beyond the webinars and emails (blog, ebook, social syndication, partner placements)? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.