I'll read the skill's reference files before building the ledger, and check whether the full dossier file is in the working directory.
The dossier file isn't in the working directory, so I'll use the excerpt you pasted. Next I'll read the parse-safety reference, which the skill requires before that check.
Nothing is applied yet. Every row below is pending your approval, and I'll produce the tailored resume only from the rows you approve.

**Inputs:** `tuesday-dossier.md` wasn't in the working directory, so I used the excerpt you pasted. I also worked from the CV summary you pasted, not a resume file, so the "Current line" column shows the CV sentences. The parse-safety check below is limited for the same reason.

## The edit ledger

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| L1 | Summary (new) | *(no summary line)* | "7 years solutions engineer / implementation lead at an enterprise software vendor. Led 30+ client integrations of our REST APIs end to end." | `merge` | "7 years solutions engineer / implementation lead at an enterprise software vendor."; "Led 30+ client integrations of our REST APIs end to end." | `[grounded]` CV | pending your approval |
| L2 | Experience | "Wrote the internal integration playbook the whole team uses." | "Wrote the internal integration playbook the whole team uses." (own bullet, not buried in prose) | `surface` | "Wrote the internal integration playbook the whole team uses." | `[grounded]` CV; dossier E1 | pending your approval |
| L3 | Experience | "Led 30+ client integrations of our REST APIs end to end." | "Led 30+ client integrations of our REST APIs end to end." (moved to first bullet) | `reorder` | "Led 30+ client integrations of our REST APIs end to end." | `[grounded]` CV | pending your approval |
| L4 | Experience | "Ran quarterly roadmap-input sessions collecting client feedback for product." | "Ran quarterly roadmap-input sessions collecting client feedback for product." (moved below L2) | `reorder` | "Ran quarterly roadmap-input sessions collecting client feedback for product." | `[grounded]` CV | pending your approval |
| L5 | Technical (surfaced from tools list) | "Comfortable in Postman, SQL, OpenAPI specs." | "Comfortable in Postman, SQL, OpenAPI specs." (own section above Experience) | `surface` | "Comfortable in Postman, SQL, OpenAPI specs." | `[grounded]` CV | pending your approval |

L2 is the dossier's pending edit E1, so it went through the audit like any other row. L1 keeps "7 years" as a numeral, because spelling it out would change the number's form and risk drifting the figure.

## Coverage map

Only the 3+ years PM requirement is marked must-have in the posting. I've set the rest as important. No requirement is `already_evidenced`: nothing in the CV reads as a PM requirement on one pass.

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| Q1 | 3+ yrs PM | must-have | not_evidenced | No PM title or PM years. Adjacent: L3, L4. Dossier R1: transferability gap. | `[grounded]` CV: "Never held a PM title." |
| Q2 | Shipped API or platform products | important | not_evidenced | Integrated the vendor's REST APIs for clients (L3). Did not ship them as far as the CV says. Dossier R2: adjacent. | `[grounded]` CV |
| Q3 | Technical fluency | important | surfaced_by_edit | L5 brings Postman, SQL and OpenAPI forward; L3 shows REST integration work. | `[grounded]` CV |
| Q4 | Stakeholder management | important | not_evidenced | Client-facing work is visible (L3, L4), but no stakeholder-management line exists. | `[grounded]` CV |
| Q5 | Own the roadmap | important | not_evidenced | L4 is input collection for product, not ownership or prioritisation authority. Dossier R1 nuance. | `[grounded]` CV |
| Q6 | Run discovery with integration partners | important | not_evidenced | L4 is the nearest match: client feedback in quarterly sessions. It isn't discovery with partners. | `[grounded]` CV |
| Q7 | Write specs and drive delivery with two engineering squads | important | not_evidenced | No engineering-team delivery in the CV. "Comfortable in OpenAPI specs" (L5) is tooling, not authorship. | `[grounded]` CV |
| Q8 | Define adoption metrics | important | not_evidenced | Nothing in the CV. | `[grounded]` CV |

## Gap handling

**Q1, 3+ years PM (named absence).** The CV says you have never held a PM title, and the posting makes three years a must-have. No edit can close that. What would close it is about six months or more in a role where you own a defined product area, with your name on its priorities and decisions. Or target roles that don't require three years of PM.

**Q2, shipped products (recall prompt C1).**

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Shipped API or platform products | important | Integration work on the vendor's REST APIs, not shipped product work | The posting asks for shipped products, and this is the requirement a screener is most likely to test | A spec or endpoint change that reached all customers; a versioning decision; a feature a client's integration drove | Release notes, changelog entries, spec pull requests | `[grounded]` what the CV says and doesn't say |

**Q8, adoption metrics (recall prompt C2).**

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C2 | Define adoption metrics | important | Nothing | The posting names adoption metrics as an outcome you'd own | Any number you tracked across the 30+ integrations, such as time to first successful call, or integrations completed per quarter | A tracker, dashboard, or QBR deck | `[grounded]` what the CV says and doesn't say |

**Q5, roadmap ownership (recall prompt C3).**

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C3 | Own the roadmap | important | Feedback collection for product in L4 | Ownership is a different job from collecting input, and an interviewer will test the difference | A quarterly decision where you chose between client requests and the call held | Input-session notes, a prioritised output list | `[grounded]` what the CV says and doesn't say |

## Prohibited claims

Not written, and why:

- **"Product Manager," any PM title, or "product management experience."** You have never held a PM title.
- **"Owned the roadmap" or "prioritisation authority."** The dossier marks these not evidenced. L4 is input collection.
- **"Shipped API products" or "platform products."** The dossier marks these adjacent. You integrated REST APIs; the CV doesn't say you shipped them.
- **"Discovery with integration partners" or "partner."** "Discovery" is the posting's word. Your counterparties were clients, and "partner" would move which side of the table you sat on.
- **"Wrote the OpenAPI specs" or "drove delivery with engineering squads."** The CV says you're comfortable in OpenAPI specs, not that you wrote them or led engineers.
- **"Defined adoption metrics."** Nothing in the CV supports it.
- **"Platform APIs" as your self-description.** That's the posting's phrase for the team's work, not your history.
- **"Built an internal request-triage tool."** From the dossier's rejected inferences: you could not confirm ownership.
- **"Has been the customer of a partner API platform."** From the dossier's rejected inferences: you worked vendor-side.

## Parse-safety check

Could not run: layout, tables, text boxes, headers and footers, and file type. The resume arrived as a pasted summary, not a file. Send the file and I'll run those checks.

## Upgrades I can offer (not built)

- **The resume file itself** (.docx or a text-layer PDF). It would replace the CV summary with exact current lines and let me run the parse-safety check.
- **The integration playbook or a roadmap-input summary.** Either would turn L2 and L4 from self-report into an inspectable artifact.

## Questions

**C1 — Did any integration change you specified or verified reach every customer, such as a new endpoint, a version change, or a spec revision?** Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**C2 — For the 30+ integrations, did you track any number, such as time to first successful call or integrations completed per quarter?** Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**C3 — When client requests conflicted in the quarterly input sessions, who decided what went into the roadmap, and did your recommendation hold?** Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

Reply with approved and rejected row IDs (for example, "Approved: L1, L2, L3, L4, L5"), and answer whichever recall prompts you can.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.