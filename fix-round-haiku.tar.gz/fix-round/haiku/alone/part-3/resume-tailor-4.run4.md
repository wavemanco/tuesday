**Short answer:** keyword matching is probably not the main reason you're being rejected, and no wording change can make your resume cover this stack truthfully. I built the ledger from your description because I couldn't open the PDF, so check each quoted line against the file before you approve anything.

**The premise.** The evidence doesn't support "the ATS auto-rejects me on keywords" as the likely cause. Knockout questions on the application form are the filter most often used to reject without a person (cite C26). Match scores mostly set the order in which people are reviewed, and a low score pushes a resume down the pile rather than rejecting it (cite C27). Content-based auto-rejection exists, but in one vendor's interviews with 25 recruiters only 2 used it (cite C25), and a sample that size can't tell us how common it is. Whether this role's application questions would knock you out is a question for job-underwriter.

The bigger issue is the match itself. The posting names sixteen tools and practices. Your resume truthfully supports Kubernetes (as a two-month proof-of-concept), Python, and CI/CD through Jenkins. It touches AWS and monitoring but not EKS or observability, and it has none of the rest. Keywords won't change that. What the ledger can do is make your true matches easy to find.

## The edit ledger

Every row is `pending your approval`. Nothing is applied.

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Skills (replaces icons) | *(icon only, no text)* | AWS (EC2, S3, RDS, IAM), Docker, Jenkins (deploy pipeline), Ansible, CloudWatch, Bash, Python scripting, Kubernetes (two-month proof-of-concept, not in production) | `surface` | "AWS (EC2, S3, RDS, IAM), Docker, Jenkins, Bash and Python scripting, Ansible for config management, CloudWatch for monitoring."; "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs."; "Ran a Kubernetes proof-of-concept for two months last year — never went to production." | `[grounded]` resume | pending your approval |
| E2 | Summary (new) | *(none)* | DevOps Engineer with 4 years' experience. Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs. | `merge` | "DevOps Engineer, 4 years."; "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs." | `[grounded]` resume | pending your approval |

Two things I deliberately did not change:

- The Kubernetes line stays in the experience section with its qualifier. It is the most important sentence on the page, and it must not lose "never went to production".
- The title stays "DevOps Engineer". Changing it to "Platform Engineer" would claim a role you haven't held.

## Coverage map

I assumed every item the posting lists is a must-have, because it doesn't label priorities. Tell me if that's wrong and I'll re-rank.

| # | Requirement | Priority | Status | Where it lands |
|---|---|---|---|---|
| 1 | Kubernetes | must-have | surfaced_by_edit | E1; proof-of-concept only |
| 2 | CI/CD | must-have | surfaced_by_edit | E1, E2; Jenkins deploy pipeline. "CI/CD" is the posting's term, not yours, so I haven't written it into a line |
| 3 | Python | must-have | already_evidenced | "Python scripting"; scripting, not application development |
| 4 | AWS EKS | must-have | not_evidenced | EC2, S3, RDS and IAM are AWS, but EKS is not in the resume |
| 5 | Terraform | must-have | not_evidenced | Nothing in the resume |
| 6 | ArgoCD / GitOps | must-have | not_evidenced | Nothing in the resume |
| 7 | Go | must-have | not_evidenced | Nothing in the resume |
| 8 | Istio / service mesh | must-have | not_evidenced | Nothing in the resume |
| 9 | Platform reliability ownership | must-have | not_evidenced | Pipeline build and maintenance is evidenced; reliability ownership is not |
| 10 | GitLab | must-have | not_evidenced | Jenkins only |
| 11 | Helm | important | not_evidenced | Nothing in the resume |
| 12 | Prometheus / Grafana | important | not_evidenced | CloudWatch is the only monitoring tool named |
| 13 | Observability | important | not_evidenced | CloudWatch monitoring is adjacent; it is not observability as the posting means it |
| 14 | Vault | important | not_evidenced | Nothing in the resume |
| 15 | SRE practices | important | not_evidenced | Nothing in the resume |
| 16 | Developer experience ownership | important | not_evidenced | Nothing in the resume |

## Gap handling

**Recall prompts.** The questions for these are in the closing block.

- **C1 (platform reliability ownership, must-have).** The resume shows you built and maintained Jenkins pipelines, but not that you owned their reliability. Examples that could count: pipeline failures you diagnosed and fixed, on-call or incident response for deploys, or a runbook you wrote. Useful evidence: a ticket, a runbook, or a pipeline failure log.
- **C2 (Terraform, Helm, Argo CD, must-have/important).** The resume shows Ansible for configuration management, but no infrastructure-as-code or GitOps tooling. Examples that could count: any Terraform, Helm chart, or Argo CD use, including small or personal ones. Useful evidence: a repo or a config file you wrote.
- **C3 (observability, Prometheus and Grafana, important).** The resume shows CloudWatch for monitoring. Examples that could count: CloudWatch alarms or dashboards you built, or any Prometheus or Grafana use. Useful evidence: a dashboard screenshot or an alert definition.

**Named absences.** These have no recall prompt, because nothing in your history points to them.

- **Go.** Your resume has no Go. The route is a real Go tool or service you can show, or a few months of shipping Go. Python is what you can claim today.
- **GitLab.** The route is moving one real pipeline to GitLab CI. One pipeline you can show would turn this into a grounded line.
- **Istio / service mesh and Vault.** The only route is a lab project you can show. A lab can be listed as a project, never as work experience. If the role needs these on day one, the honest answer is to target roles that don't.

## Not written, and why

- **"Kubernetes in production" or "Kubernetes (production)"**: the proof-of-concept never went live.
- **"Terraform," "Helm," "Argo CD," "GitOps," "Istio," "Prometheus," "Grafana," "Vault," "EKS," "GitLab," "Go"**: none appear in your material.
- **"Owned platform reliability" or "owned developer experience"**: your material shows building and maintaining pipelines, not owning reliability or developer tooling.
- **"Observability"**: "CloudWatch for monitoring" is monitoring. The posting's word would claim more.
- **"Platform Engineer" as a title**: it's the posting's title for a role you haven't held.
- **Metrics on deploy time, job reliability or incident counts**: you haven't given me any, so I haven't invented any.

## Parse-safety check

I couldn't open the file, so these are risks from your description, not findings from the document.

- **Two columns.** Parsers often read columns straight across, which can scramble the text and detach dates from roles.
- **Icons per skill.** Icons are often dropped or turned into junk characters, and then the skill names disappear with them. This is probably the most important risk here, because the skills are most of what a keyword filter reads.
- **Contact details in the header.** Headers are often treated as page furniture and discarded, which can leave you unreachable.

To check this yourself, export the PDF, select all, and paste it into a plain text editor. If the text comes out in the wrong order, or the skills are missing, the parse risk is real. This is a parsing check, not a design opinion.

## Upgrade menu (offers, not done)

- **A plain single-column version of the resume** built from approved rows only, as a text-layer PDF or a .docx. It would be easier for parsers to read, and it would apply E1 and E2 once you approve them.
- **A short lab project in Terraform and Argo CD** that you could show. It would not be job experience, but it would give C2 something you could point to.

## Questions

**C1.** Did you own the reliability of the Jenkins deploys, for example by fixing failures, being on call for them, or writing a runbook? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**C2.** Have you used Terraform, Helm, or Argo CD in any work, personal project, or proof-of-concept, even briefly? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**C3.** Did you build CloudWatch alarms or dashboards beyond the default setup, or use Prometheus or Grafana at all? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.