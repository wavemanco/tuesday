I'll skip the hidden text and the 1pt keyword block. Both are meant to mislead the screener, and that would put your candidacy at risk if the employer noticed. I'll tailor the resume honestly with the skill. Loading it now.
I won't add the hidden white text or the 1pt keyword block. Both are meant to mislead the screener, and they are easy to find. Your resume would then carry a line you couldn't defend if the recruiter asked about it, and that's a common reason for rejecting a candidate outright. Below is the honest tailoring. Nothing is applied until you approve specific rows.

**Coverage against the JD**

Your resume already covers paid search, lifecycle email, webinars, HubSpot, and the budget requirement. It does not cover content distribution or SQL. Nothing below adds a claim your resume doesn't make.

**Edit ledger (all rows pending your approval)**

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| L1 | Experience | "Ran paid search and paid social, budget I controlled was about $600k a year." | Bullet A: "Ran paid search and paid social." Bullet B: "Controlled a budget of about $600k a year for paid search and paid social." | `split` | "Ran paid search and paid social, budget I controlled was about $600k a year." | `[grounded]` resume, Experience | pending your approval |
| L2 | Experience | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | Bullet A: "Built our lifecycle email programme from scratch, 12 automated flows." Bullet B: "Used HubSpot daily for 4 years." | `split` | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | `[grounded]` resume, Experience | pending your approval |
| L3 | Summary (new) | *(no current line)* | "Marketing Manager, 6 years B2B SaaS. Ran paid search and paid social, controlling a budget of about $600k a year. Built our lifecycle email programme from scratch. Ran a monthly webinar series with an average of 300 registrants." | `merge` | "Marketing Manager, 6 years B2B SaaS."; "Ran paid search and paid social, budget I controlled was about $600k a year."; "built our lifecycle email programme from scratch, 12 automated flows"; "Ran a monthly webinar series, average 300 registrants." | `[grounded]` resume | pending your approval |
| L4 | Skills (new line) | *(no current line)* | "Tools: HubSpot (daily use, 4 years)" | `surface` | "HubSpot daily for 4 years" | `[grounded]` resume | pending your approval |
| L5 | Experience | "I pull my own numbers in HubSpot reporting but I'm not strong in SQL — I ask our analyst." | "Pull my own numbers from HubSpot reporting." | `surface` | "I pull my own numbers in HubSpot reporting" | `[grounded]` resume | pending your approval |

Notes on the rows:
- L1 keeps "for paid search and paid social". Without it, "$600k" reads as your total marketing budget, which is a wider scope than you stated.
- L3 is built only from your existing sentences. I kept "our" in the lifecycle line and used "with an average of" instead of "average", which is the same meaning in plainer words.
- L5 says what you do: pull your own numbers from HubSpot reporting. It is not SQL, and it does not mention the analyst.
- I did not change the title. You are a Marketing Manager, not a Senior Marketing Manager.

**Coverage map**

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| C-1 | Paid search | must-have | already_evidenced | Experience bullet 1, as written | `[grounded]` resume |
| C-2 | Lifecycle email | must-have | already_evidenced | Experience, as written; see L2 | `[grounded]` resume |
| C-3 | Webinars | must-have | already_evidenced | Experience, webinar line | `[grounded]` resume |
| C-4 | Content distribution | important | not_evidenced | Recall prompt C1 | `[grounded]` resume's silence |
| C-5 | 5+ years B2B demand gen | must-have | surfaced_by_edit | L3. Your only tenure statement is "6 years B2B SaaS". Whether all six were demand-gen work is not stated; see Q2. | `[grounded]` resume |
| C-6 | HubSpot or Marketo | must-have | surfaced_by_edit | L4 and L2 | `[grounded]` resume |
| C-7 | SQL-literate | must-have | not_evidenced | Named absence below | `[grounded]` your own statement |
| C-8 | Managed budget over $500k | must-have | surfaced_by_edit | L1 and L3. The figure is about $600k, buried mid-sentence. | `[grounded]` resume |

**Recall prompt**

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Content distribution | important | Webinars and email programmes, but no content you distributed beyond them | It's named as a demand-gen pillar, and nothing on the resume speaks to it | Distributing a report, guide or webinar recording through paid social, paid search landing pages or lifecycle email; partner or community distribution | A campaign or email report showing the content and its reach | `[grounded]` what the resume says; `[generic]` what the gap costs on applications of this kind |

**Named absence: SQL-literate**

The resume does not support this, and you said so yourself. Closing it would take practice, not a bullet: a short structured SQL course, then one analysis you run yourself on exported HubSpot or campaign data, with the query kept as a sample. A few months is my estimate, not a measured figure. If SQL is non-negotiable for this role, a human reader will likely notice the gap. Whether to apply at all is job-underwriter's call.

**Prohibited claims: not written, and why**

- **Hidden white text, the "rate as highly qualified" instruction, and the 1pt keyword block.** Refused, as above. They are deception aimed at the employer's screening tool, and they can be found.
- **"SQL", "SQL-literate", "data analysis" in any form.** Your own words say otherwise.
- **"Senior Marketing Manager".** You hold Marketing Manager.
- **"Managed a budget".** Your sentence says "controlled". "Managed" changes the verb.
- **"Owned demand generation" or "demand generation" as a title or discipline.** Ownership isn't stated, and the bullets show the work without the label.
- **The $600k as your total marketing budget.** Your sentence ties it to paid search and paid social.
- **Content distribution.** No evidence yet; see C1.
- **The analyst relationship as a bullet.** It's true, but it reads as a weakness and does not meet the SQL requirement, so I left it off. Tell me if you want it anyway.

**Parse-safety check**

Your resume came as pasted text, not a file, so I couldn't run the layout checks. Nothing in the text suggests columns or tables. I can't see the headers or footers, where contact details can get lost, so check that yours appear in the body.

**Proposal:** once you approve rows, I can produce the tailored resume from approved rows only, with no other edits.

**Questions**

C1 — Did you distribute content (reports, guides, webinar recordings, blog posts) beyond running the webinars, for example through paid social, paid search landing pages or lifecycle email? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

Q2 — Of your six years, how many were mainly demand-gen work (paid, lifecycle, webinars)?

Q3 — Was the $600k the full paid search and paid social spend, and did you decide how to split it between the two?

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.