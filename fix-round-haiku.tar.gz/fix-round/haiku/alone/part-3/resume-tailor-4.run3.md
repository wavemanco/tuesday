Keyword matching is probably not the main cause of the rejections. Content-based auto-rejection was configured for only 2 of 25 recruiters in one vendor's interviews (cite C25). Where automated filters are used, they are almost always knockout questions on the application form (cite C26), and no edit to the resume changes those. Match scores mostly order who gets read first, and a low score is not an automatic rejection (cite C27). The resume can still fix two things: its text has to parse, and its truthful terms should sit where a reader finds them. It cannot add tools you haven't used. Most of the named stack is absent, which is the likeliest reason a person passes on you, and no wording changes that. Whether a knockout question would stop you is what job-underwriter checks before you invest in tailoring.

The posting doesn't rank its requirements. I've treated the named tools as must-have or important as marked below. The upgrade menu says what would correct that.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| 1 | Kubernetes | must-have | surfaced_by_edit | E1. Proof-of-concept only, so it does not establish running Kubernetes in production. | `[grounded]` what the resume says: "Ran a Kubernetes proof-of-concept for two months last year — never went to production." |
| 2 | AWS | must-have | already_evidenced | EC2, S3, RDS and IAM are named in the skills line. | `[grounded]` resume |
| 3 | AWS EKS | must-have | not_evidenced | EKS is not named. Whether the proof-of-concept ran on it is unknown. RP1. | `[grounded]` what the resume does not say |
| 4 | Terraform | must-have | not_evidenced | Not named. Nearest is Ansible for config management. RP2. | `[grounded]` what the resume does not say |
| 5 | ArgoCD and GitOps | must-have | not_evidenced | No git-driven deployment is described. The only deploy pipeline named is Jenkins. Named absence below. | `[grounded]` what the resume does not say |
| 6 | CI/CD pipelines | must-have | already_evidenced | "Built our deploy pipeline in Jenkins" is a pipeline, though not on GitLab. | `[grounded]` resume |
| 7 | GitLab | important | not_evidenced | Not named. Named absence below. | `[grounded]` what the resume does not say |
| 8 | Python | important | already_evidenced | "Bash and Python scripting" is named. | `[grounded]` resume |
| 9 | Go | important | not_evidenced | Not named. Named absence below. | `[grounded]` what the resume does not say |
| 10 | Helm | important | not_evidenced | Not named. RP1 asks whether the proof-of-concept used it. | `[grounded]` what the resume does not say |
| 11 | Istio and service mesh | important | not_evidenced | Not named. Named absence below. | `[grounded]` what the resume does not say |
| 12 | Prometheus, Grafana, observability | important | not_evidenced | "CloudWatch for monitoring" is the nearest. No metrics, alerting or dashboards are described. Named absence below. | `[grounded]` what the resume does not say |
| 13 | Vault | important | not_evidenced | Not named. Named absence below. | `[grounded]` what the resume does not say |
| 14 | SRE practices and platform reliability | must-have | not_evidenced | No on-call, incident or reliability-target work is described. RP3. | `[grounded]` what the resume does not say |
| 15 | Developer experience | important | not_evidenced | "about 30 Jenkins jobs" shows volume, not who they served or how they shipped code. RP3. | `[grounded]` what the resume does not say |

## Edit ledger

Everything else in your resume already says what it can. I propose no other changes.

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Summary (new) | *(no current line)* | DevOps Engineer, 4 years. Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs. Ran a Kubernetes proof-of-concept for two months last year — never went to production. | `merge` | "DevOps Engineer, 4 years"; "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs."; "Ran a Kubernetes proof-of-concept for two months last year — never went to production." | `[grounded]` resume | pending your approval |

E1 uses only your sentences. It puts the Kubernetes line near the top where a reader sees it, and keeps "never went to production" in full.

## Recovery per gap

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| RP1 | AWS EKS; Helm | must-have | A two-month Kubernetes proof-of-concept, not in production. | The posting names EKS as a must-have, and a reader scanning for it will not find it. | A proof-of-concept cluster on EKS; a Helm chart you deployed to it. | The proof-of-concept repo or manifests. | `[grounded]` what the resume says; `[generic]` a reader scanning for named tools looks for the term |
| RP2 | Terraform | must-have | Ansible for config management; AWS resources named without any provisioning method. | Terraform is a must-have, and Ansible is not the same tool. | Terraform or CloudFormation for the EC2, S3, RDS or IAM resources you already run; Ansible playbooks that created infrastructure. | Terraform or Ansible files in a repo. | `[grounded]` what the resume does and does not say |
| RP3 | SRE practices and platform reliability; developer experience | must-have | Jenkins deploy pipeline and about 30 jobs; no reliability or support work. | The posting says you will own reliability and developer experience. | Carrying an on-call rotation for the deploy pipeline; a reliability target you set; a self-service change for the teams using the pipeline. | Runbooks, incident notes, or a pipeline template used by other teams. | `[grounded]` what the resume does and does not say |

**Named absences**, with what closing each would take:

- **ArgoCD and GitOps:** Sync one application from a git repo in a sandbox cluster. `[generic]` a sandbox project is the usual route.
- **GitLab:** Move one project's pipeline to GitLab CI. `[generic]` cheap to close.
- **Istio and service mesh:** Install a mesh in a sandbox cluster and write up what it did. `[generic]` needs a cluster.
- **Prometheus, Grafana, observability:** Build one dashboard and one alert for a service you run. `[generic]`
- **Vault:** Move one credential out of a Jenkins job or a repo into a secrets store. `[generic]`
- **Go:** Write one small tool in Go. Otherwise this is a gap for this role. `[generic]`

## Prohibited claims

Not written, and why:

- **"Terraform," "EKS," "ArgoCD," "GitOps," "Istio," "service mesh," "Prometheus," "Grafana," "Vault," "Helm," "GitLab" or "Go" anywhere on the resume:** none of these is in what you described.
- **"Production Kubernetes" or "Kubernetes experience" without the proof-of-concept qualifier:** your own sentence says it never went to production.
- **"Owned platform reliability" or "owned developer experience":** the posting's role, not your history. Your material describes building and maintaining Jenkins jobs.
- **"Led" or "managed" the deploy pipeline:** you built and maintain it. Leadership is not stated.
- **Team counts, user counts, or any metric** for the pipeline: none was given.
- **"SRE" anywhere on the resume:** no SRE work is described.

## Parse-safety check

I have only your description of the PDF, not the file, so checks marked "described" are your account, not something I could see.

| Check | Observed? | Finding | What it costs |
|---|---|---|---|
| Two-column layout | Described | Two columns | Parsers read across rows, so role titles, dates and bullets can interleave. |
| Icons instead of skill names | Described | An icon for each skill | An icon carries no text. A skill shown only as an icon is absent to a parser. |
| Contact details in the header | Described | Contact block at the top | If the header is a page-header region or a text box, a parser can drop it, and the recruiter cannot reach you. |
| Tables and text boxes | Could not check | Canva layouts often use text boxes | Box contents can reorder or disappear. |
| Text layer | Could not check | Unknown | A PDF exported as an image yields no text at all. |
| Section headings | Could not check | Unknown | A non-standard heading may not be recognised as Experience. |

A test you can run yourself: open the PDF, select all, and paste into a plain-text editor. If the lines come out interleaved, or your name, phone or email are missing, that is roughly what a parser sees. A .docx or a PDF with a text layer is the safer format.

## Upgrade menu

- **The resume file itself (the PDF, or a .docx export):** lets the parse check run on the real file instead of your description.
- **The Kubernetes proof-of-concept repo, Jenkinsfiles, or Ansible roles:** artifacts that could ground rows RP1 and RP2 beyond a single bullet.
- **The posting's own must-have section, if it labels one:** would confirm or correct the priorities I assumed above.

## Questions

**RP1:** Did the two-month Kubernetes proof-of-concept run on AWS EKS, and did you deploy anything onto it with Helm or from a git repo?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**RP2:** Did you provision any AWS resources (EC2, S3, RDS, IAM) from code, with Terraform, CloudFormation or Ansible playbooks, and whose definitions were they?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**RP3:** Who relied on your Jenkins deploy pipeline, and did you ever own an incident or a reliability target for it?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

To approve, reply with the row numbers, for example "Approved: E1". Nothing has been applied yet, and I will produce the resume only from rows you approve.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.