**Short answer:** keyword matching is part of it, but the bigger problem is that most of this JD's stack isn't on your resume. Keywords can make real experience easier to find. They can't make the other requirements appear without it being false. The Canva layout may also be costing you matches, and I can't check that until I see the file.

Two limits on this run. I worked from your description, not the PDF, so the parse check below is a risk list, not a test of the file. The JD gives no priority labels, so I assigned them: must-have for the core stack and the reliability/DX ownership, important for the rest, preferred for Go. Nothing is applied until you approve it.

## Edit ledger (pending your approval)

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Summary (new) | *(no current line)* | "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs. Bash and Python scripting; AWS (EC2, S3, RDS, IAM)." | `merge` | "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs."; "AWS (EC2, S3, RDS, IAM), Docker, Jenkins, Bash and Python scripting, Ansible for config management, CloudWatch for monitoring" | `[grounded]` resume | pending your approval |
| E2 | Experience | "Ran a Kubernetes proof-of-concept for two months last year — never went to production." | "Ran a two-month Kubernetes proof-of-concept last year; it never went to production." | `compress` | "Ran a Kubernetes proof-of-concept for two months last year — never went to production." | `[grounded]` resume, Experience | pending your approval |
| E3 | Skills | "AWS (EC2, S3, RDS, IAM), Docker, Jenkins, Bash and Python scripting, Ansible for config management, CloudWatch for monitoring" | Same line, plus: "Kubernetes (proof-of-concept, never in production)" | `surface` | "Ran a Kubernetes proof-of-concept for two months last year — never went to production." | `[grounded]` resume, Experience | pending your approval |

E2 keeps the "never went to production" qualifier, which is the honest part. E3 puts Kubernetes into the keyword-scanned skills list only with that qualifier attached.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| 1 | Kubernetes | must-have | surfaced_by_edit | Two-month proof-of-concept, never production; E2, E3 | `[grounded]` resume, Experience |
| 2 | AWS EKS | must-have | not_evidenced | Not stated; C1 asks what the PoC ran on | `[grounded]` resume does not mention EKS |
| 3 | Terraform | must-have | not_evidenced | Ansible is configuration management, not provisioning; C3 | `[grounded]` resume |
| 4 | ArgoCD and GitOps | must-have | not_evidenced | Jenkins deploys are not GitOps as stated; named absence | `[grounded]` resume |
| 5 | CI/CD pipelines | must-have | already_evidenced | "Built our deploy pipeline in Jenkins" | `[grounded]` resume |
| 6 | Observability (monitoring) | must-have | already_evidenced | CloudWatch monitoring only; no alerting or dashboards stated | `[grounded]` resume |
| 7 | SRE practices and platform reliability | must-have | not_evidenced | No reliability ownership stated; named absence | `[grounded]` resume |
| 8 | Developer experience | important | not_evidenced | Who used the pipeline is not stated; C2 | `[grounded]` resume |
| 9 | Prometheus and Grafana | important | not_evidenced | Named absence | `[grounded]` resume |
| 10 | Helm | important | not_evidenced | Named absence, unless C1 shows the PoC used it | `[grounded]` resume |
| 11 | Istio and service mesh | important | not_evidenced | Named absence | `[grounded]` resume |
| 12 | Vault | important | not_evidenced | Named absence; IAM is AWS access control, not secrets management | `[grounded]` resume |
| 13 | GitLab CI | important | not_evidenced | Named absence; Jenkins is not GitLab CI | `[grounded]` resume |
| 14 | Python | important | already_evidenced | "Bash and Python scripting" | `[grounded]` resume |
| 15 | Go | preferred | not_evidenced | Named absence | `[grounded]` resume |

Six of the 15 are must-have and not evidenced: EKS, Terraform, GitOps/ArgoCD, SRE practices, plus Kubernetes in production (row 1 is only surfaced). That is most of the JD's core.

## Gap handling

**Recall prompts** (answers may move a row; the questions are in the closing block):

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | AWS EKS | must-have | A Kubernetes PoC, never production; cluster type not stated | The JD names EKS, and a reader will ask | The PoC itself, and any manifests or charts you wrote for it | Repo, manifests, PoC write-up | `[grounded]` resume; `[generic]` EKS is AWS's managed Kubernetes service |
| C2 | Developer experience | important | Pipeline built and maintained; no users or outcomes stated | The JD makes DX part of the job, and a reader will ask who used it | Rolling the pipeline out to teams; onboarding others to Jenkins jobs | A Jenkinsfile, a team note, a ticket | `[grounded]` resume; `[generic]` platform roles usually judge DX by who uses the platform |
| C3 | Terraform | must-have | No infrastructure-as-code stated; Ansible configures servers | Listed as must-have | Any AWS resource (EC2, S3, RDS, IAM) created from code | Repo, module, pull request | `[grounded]` resume |

**Named absences** (no evidence on record; what closing it would take):
- **ArgoCD and GitOps:** deploy one app from a Git repo to a test cluster with ArgoCD, in a public repo.
- **Istio and service mesh:** install Istio on a test cluster and route traffic between two services.
- **Vault:** one setup that stores and reads a secret through Vault.
- **Prometheus and Grafana:** scrape a sample app, build one dashboard and one alert.
- **Go:** one small service or CLI in Go.
- **GitLab CI:** one pipeline in a GitLab project.
- **SRE practices:** a defined SLO for a service you run, or a sustained move onto a team that owns reliability.
- **Helm:** covered by C1 if the PoC used it; otherwise a named absence.

Closing these is weeks of project work each. A public repo with a README is the kind of artifact that later becomes grounded evidence.

## Not written, and why

- **"Platform Engineer" as your title or self-description.** You have held DevOps Engineer; the JD's title is not yours.
- **"Kubernetes in production" or "ran clusters."** The PoC never went to production.
- **EKS, Terraform, ArgoCD, GitOps, Istio, Vault, Helm, Prometheus, Grafana, Go, GitLab CI in your skills.** None appear in your material. Listing them would claim tools you have not used. Jenkins is not GitLab CI.
- **"Owned the deploy pipeline" or "owned reliability."** Your sentences say built and maintain. "Owned" is not in them.
- **Deploy-frequency, uptime, or time-saved figures.** None are in your material, so I invented none.

## Parse-safety check

Run on your description, since I have not seen the file.

| Check | What your description shows | What it costs |
|---|---|---|
| Multi-column layout | Two columns | Parsers read across columns; dates can separate from their roles. High risk. |
| Icons per skill | An icon for each skill | Skill names can be dropped or come through as garbage characters. These are the terms a keyword scan looks for. High risk. |
| Contact details in header | Yes | Header text is often treated as page furniture and discarded, so you can end up unreachable. Check. |
| Text boxes or tables | Canva often uses them | Cell contents can be reordered or dropped. Possible. |
| Section headings | Not described | Parsers look for "Experience", "Skills", "Education". Check. |
| File type | PDF | Safe only with a real text layer. |

To check the text layer, open the PDF, select all, and paste into a plain text editor. If you get your skills and roles in order, the text is there. If you get nothing, or it comes out scrambled, the parser sees the same thing.

The safe pair is a .docx or a text-layer PDF, with contact details in the body and skills as plain text. Send me the file or the pasted text and I can run the check on what it actually contains.

**Offers (not built unless you approve):**
- A plain-text-layer version of the resume built from approved rows only, so the parse check runs on the real output.
- Once you answer C1–C3 or finish a named-absence project, new rows drawn from that answer or artifact.
- job-underwriter can check whether this role is worth applying to, including the application's knockout questions, which most often reject candidates without a person reading the resume.

**Questions:**
- **C1:** What did the Kubernetes proof-of-concept run on: EKS, a self-managed cluster, or a local one such as kind?
- **C2:** Which teams used the Jenkins pipeline, and what did they stop doing by hand because of it?
- **C3:** Have you ever created AWS resources (EC2, S3, RDS, IAM) from code rather than the console? If so, with what tool?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.