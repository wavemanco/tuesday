Nadia, the honest read is that this resume can make your integration work easier to find, but it cannot make it a product management record. The posting's must-have is 3+ years of PM, and you have never held that title. Every edit below is a re-presentation of lines you wrote, and nothing is applied until you approve it.

**What I worked from.** The dossier excerpt you pasted (I don't have the file itself, and it is dated from Tuesday, so I'm using its judgments as written). Your CV as the prose description you gave me, which I treat as self-report. I did not have the document's actual line wording, so the "Current line" column uses your sentences as you wrote them. The dossier's rejected inferences (the request-triage tool and the "customer of a partner API platform" framing) are carried into the prohibited list unchanged.

## Edit ledger

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience | Inside the role description, not its own line | "Wrote the internal integration playbook the whole team uses." | `surface` | "Wrote the internal integration playbook the whole team uses." | `[grounded]` self-report; inherited from dossier E1, re-audited | pending your approval |
| E2 | Experience | "Ran quarterly roadmap-input sessions collecting client feedback for product." | Same wording, moved up beneath E1 | `reorder` | "Ran quarterly roadmap-input sessions collecting client feedback for product." | `[grounded]` self-report | pending your approval |
| E3 | Experience | "Led 30+ client integrations of our REST APIs end to end." | Same wording, moved to the first bullet | `reorder` | "Led 30+ client integrations of our REST APIs end to end." | `[grounded]` self-report | pending your approval |
| E4 | Skills | "Comfortable in Postman, SQL, OpenAPI specs." | Same wording, moved up into the tools line | `surface` | "Comfortable in Postman, SQL, OpenAPI specs." | `[grounded]` self-report | pending your approval |
| E5 | Summary | *(no current line)* | "Seven years as solutions engineer / implementation lead at an enterprise software vendor. Led 30+ client integrations of our REST APIs end to end." | `merge` | "7 years solutions engineer / implementation lead at an enterprise software vendor"; "Led 30+ client integrations of our REST APIs end to end." | `[grounded]` self-report | pending your approval |

Notes on the rows:
- E5 is two sentences, not one clause, so the integrations stay separate from the tenure. It says nothing about product, roadmap or PM. The slash in your title is kept as you wrote it; if one of those titles is the real one, tell me and I'll change the row.
- E2 keeps "for product" and "client", not "partner" or "discovery". You collected feedback at scheduled sessions. You did not run discovery as an owner.
- E4 keeps "Comfortable in". It does not become "wrote OpenAPI specs."

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| 1 | 3+ yrs PM | must-have | not_evidenced | Adjacent only: E5, E2. No PM title held. | `[grounded]` self-report; dossier R1 adjacent, medium |
| 2 | Shipped API or platform products | important | not_evidenced | Shipped client integrations on the vendor's REST APIs; you did not own or ship the product. Dossier R2 adjacent, medium. | `[grounded]` self-report |
| 3 | Technical fluency | important | surfaced_by_edit | E3, E4 | `[grounded]` self-report |
| 4 | Stakeholder management | important | surfaced_by_edit | E3, E5, E1. Client-facing evidence only. Nothing you have described covers internal product or engineering stakeholders. | `[grounded]` self-report |
| 5 | Own the roadmap | important | not_evidenced | Roadmap input only (E2). Recovery: C1. | `[grounded]` self-report |
| 6 | Discovery with integration partners | important | surfaced_by_edit | E2, input collection from clients only | `[grounded]` self-report |
| 7 | Write specs and drive delivery with two engineering squads | important | not_evidenced | Nothing in the material. E1 is internal guidance, not a product spec. Recovery: C2. | `[grounded]` self-report |
| 8 | Define adoption metrics | important | not_evidenced | Nothing in the material. Recovery: C3. | `[grounded]` self-report |

The JD only labels requirement 1 as must-have, so the others are marked important.

## Gap handling

**Requirement 1 (3+ years PM): named absence.** No edit closes this, and no recall prompt can produce a PM title you never held. The adjacent work is real and the ledger shows it. Closing it would take a stretch in which you owned a roadmap or prioritisation decisions for a year or more, or a target role that does not set the 3-year bar. Whether this role is worth that is your call. The dossier's conditional decision already reflects this gap.

**Requirement 2 (shipped API products): named absence.** Closing it would take owning a shipped API surface or feature end to end, from scope through release. Your integrations are the nearest evidence, but you did not ship the product.

**Requirements 5, 7, 8: recall prompts.** The questions are in the closing block, tagged C1–C3.

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Own the roadmap | important | Roadmap input collection (E2). It does not show ownership of what gets built. | Roadmap ownership is the first thing a platform PM screen checks [generic] | Any roadmap call you made, even a small one; a prioritisation you pushed through | Session agendas or notes; a roadmap doc you contributed to | `[grounded]` self-report; `[generic]` screening weight |
| C2 | Write specs and drive delivery with two engineering squads | important | Nothing. The playbook is internal guidance, not a product spec. | Delivery through engineering teams is a stated responsibility [generic] | Any spec you wrote for a product or integration feature; any engineering team you directed | A spec, a ticket trail, a release note | `[grounded]` self-report; `[generic]` screening weight |
| C3 | Define adoption metrics | important | Nothing. "30+ integrations" is a count, not an adoption measure. | Adoption measurement is named as a job duty [generic] | Any integration-completion or time-to-first-call figure; who tracked it | A dashboard, a report, a QBR slide | `[grounded]` self-report; `[generic]` screening weight |

## Not written, and why

- **"3+ years product management" or any PM title.** You have never held one, and the JD makes it a must-have. Adjacent work is in E2 and E5, and the gap is named above.
- **"Owned the API roadmap."** You ran input sessions for product. Owning a roadmap is a different job, and an interviewer will know within one question.
- **"Ran discovery with integration partners."** "Discovery" is the posting's word, and "partners" is its word for your clients. You collected client feedback.
- **"Shipped API products" or "shipped the platform."** You implemented integrations on a product someone else shipped.
- **"Wrote OpenAPI specs" or "drove delivery with engineering squads."** Your sentence says comfortable in OpenAPI and does not mention engineering squads.
- **"Defined adoption metrics."** Not in the material.
- **"Built an internal request-triage tool."** A dossier rejected inference. You could not confirm ownership.
- **"Was a customer of a partner API platform."** A dossier rejected inference. You worked on the vendor side, and that is the side your summary states.

## Parse-safety check

I could not run it. You sent the description as pasted text, not a file, so I cannot check layout, tables, headers and footers, icons, or section headings. If the resume is a `.docx` or a text-layer PDF, send it and I'll run the check.

## Optional next steps (proposals, not built)

- **x: A parse check on the actual file.** This adds the one check I couldn't run, and it changes nothing in the ledger.
- **x: One artifact per recall prompt.** A session agenda, a spec, or an adoption report would move C1–C3 from prompts to grounded rows, each re-audited before it enters the ledger.

**Questions**

C1 — When you ran the quarterly roadmap-input sessions, did you ever decide what went on the roadmap or in what order, or did you only collect what clients asked for?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

C2 — Did you ever write specs or direct engineers' delivery for a product or feature, or was that always someone else's job?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

C3 — Did you ever track how many clients finished their integrations, how long it took, or any adoption figure? If so, who tracked it?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.