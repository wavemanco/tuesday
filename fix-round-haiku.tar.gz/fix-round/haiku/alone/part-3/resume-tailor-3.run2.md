I built this from your background sentences, the dossier excerpt, and the posting. I didn't have a resume file, so the "current line" column uses your background sentences. I treated the three requirements the JD doesn't tier (shipped API products, technical fluency, stakeholder management) as important. The dossier's `conditional_go` still holds, but nothing below closes the must-have: the 3+ years of PM.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| 1 | 3+ years product management | must-have | not_evidenced | Named absence N1 | `[grounded]` "Never held a PM title."; dossier R1, adjacent, medium |
| 2 | Shipped API or platform products | important | not_evidenced | Recall prompt C1 | `[grounded]` dossier R2, adjacent, medium; "Led 30+ client integrations of our REST APIs end to end." (vendor-side) |
| 3 | Technical fluency | important | surfaced_by_edit | E4 | `[grounded]` "Comfortable in Postman, SQL, OpenAPI specs." (self-reported) |
| 4 | Stakeholder management | important | surfaced_by_edit | E2, E3. Nuance: client and product-side coordination; no internal stakeholder breadth is stated | `[grounded]` "Ran quarterly roadmap-input sessions collecting client feedback for product." |
| 5 | Own the roadmap for a partner-facing API platform | important | not_evidenced | Recall prompt C2 | `[grounded]` dossier R1: "roadmap ownership and prioritisation authority not evidenced" |
| 6 | Run discovery with integration partners | important | surfaced_by_edit | E2. Nuance: adjacent. Your sessions collected client feedback; no partner discovery is stated | `[grounded]` "Ran quarterly roadmap-input sessions collecting client feedback for product." |
| 7 | Write specs | important | not_evidenced | Named absence N2 | `[grounded]` "Wrote the internal integration playbook the whole team uses." A playbook is not a product spec |
| 8 | Drive delivery with two engineering squads | important | not_evidenced | Named absence N3 | `[grounded]` "Led 30+ client integrations of our REST APIs end to end." No squads are stated |
| 9 | Define adoption metrics | important | not_evidenced | Recall prompt C3 | `[grounded]` no adoption or usage measure appears in your background |

## Edit ledger

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience | *(in background, not its own line)* | Wrote the internal integration playbook the whole team uses. | surface | "Wrote the internal integration playbook the whole team uses." | `[grounded]` self-report | pending your approval |
| E2 | Experience | *(in background, not its own line)* | Ran quarterly roadmap-input sessions collecting client feedback for product. | surface | "Ran quarterly roadmap-input sessions collecting client feedback for product." | `[grounded]` self-report | pending your approval |
| E3 | Summary | *(no current line)* | 7 years solutions engineer / implementation lead at an enterprise software vendor. Led 30+ client integrations of our REST APIs end to end. | merge | "7 years solutions engineer / implementation lead at an enterprise software vendor."; "Led 30+ client integrations of our REST APIs end to end." | `[grounded]` self-report | pending your approval |
| E4 | Skills | *(in background, not its own line)* | Comfortable in Postman, SQL, OpenAPI specs. | surface | "Comfortable in Postman, SQL, OpenAPI specs." | `[grounded]` self-report | pending your approval |

Audit: every quote is verbatim. No row claims a title, a product, a squad, or a metric. "Client" stays "client," "Led" is not upgraded, and "comfortable" stays "comfortable." E3 keeps your two sentences separate, and the slash in "solutions engineer / implementation lead" stays a slash, so I don't claim a progression between the two roles. E1 and E2 are the dossier's pending edit E1, re-audited against your current wording.

## Gap handling

**Recall prompts.** Each prompt is a row here. Its question is asked once, in the closing block.

| # | Requirement | Priority | What your resume shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Shipped API or platform products | important | Integration delivery on the vendor's REST APIs. No product you owned is stated | The integrations were work on someone else's platform, which is a different claim from shipping one | An API, SDK, developer portal, or integration template you owned and put in front of users | Release notes, a doc set, a repo, a launch note | `[grounded]` your background sentences; `[generic]` how screeners tend to read ownership of a shipped product |
| C2 | Roadmap and prioritisation authority | important | Quarterly sessions collected client input for product. No decision you made is stated | Input to a roadmap and ownership of one are different roles, and the dossier already marks the second as not evidenced | A call about what shipped next that held, even at small scope; a backlog you ranked | A roadmap, a prioritisation note, a review record | `[grounded]` dossier R1 |
| C3 | Adoption metrics | important | No usage or adoption measure is stated for integrations or the playbook | The JD asks you to define them, so the work has to have been measured | A usage count, uptake after a playbook rollout, time-to-first-integration you measured | A dashboard, a report, a query from your SQL work | `[grounded]` your background sentences |

**Named absences.**

- **N1, 3+ years PM (must-have).** You have never held a PM title, and no wording closes this. What would close it is a documented stretch owning priorities for a product, with a backlog or roadmap call you can name and date. Without that, the honest target is a role that doesn't require it, or a title scoped to integration or platform delivery.
- **N2, Write specs.** No product spec you wrote is stated. Closing it means a spec an engineering team built from, with your name on it, such as an OpenAPI or integration requirements document. The playbook and your OpenAPI familiarity are adjacent, not this.
- **N3, Drive delivery with two engineering squads.** Your delivery work ran through client integrations, not engineering squads. Closing it means one delivery you drove across engineering teams, with dates and the teams named.

## Prohibited claims

Not written, and why:

- **"Product manager," "product management experience," "3+ years PM."** You have never held the title, and the dossier marks the adjacent work as adjacent.
- **"Owned the API roadmap," "set priorities."** Your roadmap-input sessions collected input for product. They didn't set the roadmap.
- **"Shipped API products," "built an API platform."** Your work was integration delivery on the vendor's APIs.
- **"Partner" in place of "client."** Your word is "client." The posting's word would move which side of the table you sat on.
- **"Discovery."** It's the JD's word for work you did not describe. Your sessions were roadmap-input collection.
- **"Managed two engineering squads," "drove delivery with engineering."** Not stated.
- **"Defined adoption metrics," "drove adoption."** Not stated.
- **"Specs" for the playbook.** It's a playbook.
- **"Expert" in Postman, SQL, or OpenAPI.** Your word is "comfortable."
- **"Progressed from solutions engineer to implementation lead."** Your line gives a slash, not an order.
- **Rejected inference: "Built an internal request-triage tool."** You could not confirm ownership.
- **Rejected inference: "Was a customer of a partner API platform."** You were vendor-side.

No rows have been rejected yet.

## Parse-safety check

Not run. The background came as pasted text, not a file, so I can't check layout, tables, headers, or hidden text. If you send the resume as a `.docx` or a text-layer PDF, I'll run the check.

## Offers, not built

- **Offer:** If you can share the playbook itself, or a roadmap-input summary, I can check the ledger's traces against an inspectable artifact rather than your sentences. That would firm up the evidence behind E1 and E2.
- **Offer:** A version aimed at an integration or platform delivery title, which the evidence supports more directly than a PM title. This would be a different target, so I'd build it only on your say-so.

## Questions

C1 — Did you ever own and ship something that was an API, SDK, or developer-facing component, even a small one?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

C2 — Did you ever make a call about what product work went next, where your choice held, even at small scope?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

C3 — Did you ever measure whether something you built or wrote was actually used, such as integration rollout counts or playbook uptake?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

Approve by row ID (E1–E4), and reject any row you don't want. Nothing is applied until you do.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.