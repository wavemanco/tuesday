I won't add the hidden white text or the 1pt keyword block. That's a manipulation of the screening step, and it would put your application at risk if the recruiter sees it. I'll tailor the resume honestly from your material. Loading the tailoring skill first.
The skill's reference files set the ledger format and audit rules, so I'm reading them before drafting.
I won't add the white text or the 1pt keyword block. Hidden text aimed at a screener is deception of the employer. Recruiters' tools can detect it, and if it's found, the line is one you didn't write and couldn't defend in an interview. The legitimate version gets you the same benefit: keywords where your experience supports them, the strongest evidence first, and a file that parses cleanly.

Below is the tailoring from your material only. Nothing is applied until you approve the rows.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| 1 | 5+ years B2B demand gen | must-have | already_evidenced | Header shows 6 years in B2B SaaS, and the bullets show demand programmes. The source doesn't say how many of the six years were demand work. See Q2. | `[grounded]` |
| 2 | HubSpot or Marketo | must-have | already_evidenced | HubSpot, 4 years daily (L2b). Marketo is not claimed. | `[grounded]` |
| 3 | SQL-literate | must-have | not_evidenced | Nothing in the source. You said you're not strong in SQL. Adjacent: HubSpot self-serve reporting (L3). See the named absence below. | `[grounded]` |
| 4 | Managed a budget over $500k | must-have | surfaced_by_edit | Your $600k figure is buried in the paid-channels sentence. Fixed by L1. | `[grounded]` |
| 5 | Own paid search | important | already_evidenced | "Ran paid search" | `[grounded]` |
| 6 | Own lifecycle email | important | already_evidenced | Built from scratch, 12 flows (L2a) | `[grounded]` |
| 7 | Own webinars | important | already_evidenced | Monthly series, 300 average registrants | `[grounded]` |
| 8 | Content distribution | important | not_evidenced | Not in your material. Recall prompt C1. | `[grounded]` |

## Edit ledger (all pending your approval)

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| L1 | Experience | Ran paid search and paid social, budget I controlled was about $600k a year. | Ran paid search and paid social. / Budget I controlled: about $600k a year. | `split` | "Ran paid search and paid social, budget I controlled was about $600k a year." | `[grounded]` resume | pending your approval |
| L2a | Experience | HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows. | Built our lifecycle email programme from scratch: 12 automated flows. | `split` | "built our lifecycle email programme from scratch, 12 automated flows." | `[grounded]` resume | pending your approval |
| L2b | Experience | (same line as L2a) | Used HubSpot daily for 4 years. | `split` | "HubSpot daily for 4 years" | `[grounded]` resume | pending your approval |
| L3 | Skills / Experience | (none) | Pull my own performance numbers from HubSpot reporting. | `surface` | "I pull my own numbers in HubSpot reporting" | `[grounded]` your note | pending your approval |

The L2b line says "used", where the source says "HubSpot daily". That's a change of wording, so you should check it against what you'd say in an interview. The "from scratch" in L2a is in your source; it's not an added claim.

## Gap handling

**C1: Content distribution (important, not evidenced)**

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Own content distribution | important | Nothing. Webinars are the only content work in your material. | The posting names it as a responsibility, so a screener checking for it finds no match. | Promotion of gated assets; promotion of webinar recordings or blog posts; partner or newsletter placements | A campaign calendar, HubSpot email or social reports, or a launch note | `[grounded]` what the resume does and does not say; `[generic]` postings of this kind weight distribution heavily |

**SQL-literate (must-have, not evidenced): named absence.** The resume can't claim SQL, and it shouldn't. Closing it would take focused practice on your own HubSpot exports, such as a few real joins and aggregations, and one analysis you can walk through in an interview. `[generic]` A plausible timeline is six to eight weeks. The posting lists SQL as a must-have, so until you close it, treat this role as a stretch on that point.

## Not written, and why

- **"Marketo"**: not in your material. The posting accepts HubSpot, so you don't need it.
- **"SQL" or "SQL-literate"**: you said you're not strong in SQL. An interviewer will ask a query question.
- **"Owned demand generation"**: the posting's phrase. Your source says you ran paid search, paid social, lifecycle and webinars. Owning the whole function is a bigger claim than that.
- **Content distribution ownership**: not in your material. Recall prompt C1 covers it.
- **"$600k across paid search and paid social"**: your sentence doesn't say the $600k covers both channels, so the ledger keeps "budget I controlled."
- **"Attendees" for "registrants"**: the 300 is registrants, so the line keeps that word.

## Parse-safety check

Could not run. Your resume arrived as pasted text, so I can't check layout, columns, tables, headers or footers, or file type. When you send the file, a `.docx` or a text-layer PDF is the safest pair. I'll run those checks then, and I'll flag any white or tiny text from a template or earlier tool.

**Offered, not applied (proposal):** I can draft a cover-letter paragraph built the same way, with every clause traced to a sentence you wrote. Say the word and I'll do it.

**Questions**

C1 — Did you do any content distribution: promoting gated assets, webinar recordings or blog posts, or partner or newsletter placements? If so, what did you own?

Q2 — Of your six years, how many were demand work (paid, lifecycle, webinars), and how many were something else?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.