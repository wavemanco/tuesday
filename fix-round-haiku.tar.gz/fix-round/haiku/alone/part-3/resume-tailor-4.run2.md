I worked from your description of the resume, not the PDF, so the quoted "Traces to" lines use your message's wording. Check them against the PDF before you approve anything.

**The keyword theory is only partly right.** Match scores mostly decide who gets reviewed first. Content-based auto-rejection exists, but in a vendor's survey of 25 recruiters, 2 used it (cite C25). That sample is small and the vendor sells resume builders, so it can't size the problem. The filters that most often reject without a person are knockout questions: "yes/no eligibility checks (work authorization, required license, location)" (cite C26). Those sit on the application form, so check them first. Whether this role is worth applying to, given those, is job-underwriter's question.

The likelier explanation is the coverage map below. Most of the stack the posting lists is not on your resume, and no keyword placement fixes that without inventing experience.

## Edit ledger

Nothing here is applied. Every row is pending your approval.

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Summary (new) | *(none as described)* | "DevOps Engineer with four years' experience. Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs. Ran a Kubernetes proof-of-concept for two months last year — never went to production." | `merge` | "DevOps Engineer, 4 years."; "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs."; "Ran a Kubernetes proof-of-concept for two months last year — never went to production." | `[grounded]` resume | pending your approval |
| E2 | Skills | "AWS (EC2, S3, RDS, IAM), Docker, Jenkins, Bash and Python scripting, Ansible for config management, CloudWatch for monitoring" | "Python and Bash scripting, AWS (EC2, S3, RDS, IAM), Docker, Jenkins, Ansible for config management, CloudWatch for monitoring" | `reorder` | "AWS (EC2, S3, RDS, IAM), Docker, Jenkins, Bash and Python scripting, Ansible for config management, CloudWatch for monitoring" | `[grounded]` resume | pending your approval |

E1 keeps "two months" and "never went to production" in the sentence. Those qualifiers are the honest part, so I haven't compressed them away. E2 changes only order, which puts Python where a screener reads first.

To approve, reply with the row numbers, for example "Approved: E1, E2". Rejected rows go on a list so they aren't re-proposed.

## Coverage map

The posting doesn't label priority tiers, so I've treated every listed item as must-have.

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| 1 | Kubernetes | must-have | surfaced_by_edit | E1. Proof-of-concept only, not production. | `[grounded]` resume |
| 2 | Terraform | must-have | not_evidenced | Nearest is Ansible config management. Recall R3. | `[grounded]` resume |
| 3 | ArgoCD | must-have | not_evidenced | Nothing on the resume. Named absence below. | `[grounded]` resume |
| 4 | GitOps | must-have | not_evidenced | Jenkins pipelines are not GitOps. Named absence below. | `[grounded]` resume |
| 5 | Helm | must-have | not_evidenced | Unknown whether the proof-of-concept used it. Recall R1. | `[grounded]` resume |
| 6 | AWS EKS | must-have | not_evidenced | AWS EC2, S3, RDS and IAM only. Recall R1. | `[grounded]` resume |
| 7 | Istio / service mesh | must-have | not_evidenced | Nothing on the resume. Named absence below. | `[grounded]` resume |
| 8 | Prometheus / Grafana | must-have | not_evidenced | Nothing on the resume. Named absence below. | `[grounded]` resume |
| 9 | Observability | must-have | not_evidenced | CloudWatch monitoring is the nearest. Recall R2. | `[grounded]` resume |
| 10 | Vault | must-have | not_evidenced | Nothing on the resume. Named absence below. | `[grounded]` resume |
| 11 | SRE practices / platform reliability | must-have | not_evidenced | Nothing on the resume about on-call or incidents. Recall R2. | `[grounded]` resume |
| 12 | CI/CD (GitLab) | must-have | surfaced_by_edit | E1 and E2. Jenkins deploy pipeline, not GitLab. | `[grounded]` resume |
| 13 | Developer experience | must-have | not_evidenced | The resume doesn't say who used the pipeline. Recall R2. | `[grounded]` resume |
| 14 | Python | must-have | already_evidenced | "Bash and Python scripting" in the skills list; E2 moves it first. | `[grounded]` resume |
| 15 | Go | must-have | not_evidenced | Nothing on the resume. Named absence below. | `[grounded]` resume |

## Gap handling

**Named absences.** Each one says what closing it would take:
- **Terraform, ArgoCD, GitOps, Helm, Istio, Prometheus/Grafana, Vault, Go:** a small project you build and can explain in detail, for example an S3 bucket and IAM roles in your own AWS account in Terraform, or ArgoCD syncing a repo to a cluster you run. [generic] A project like that shows you can use the tool. It won't match a team's production use, and an interviewer will test the difference.
- **Developer experience and SRE practices:** if R2 turns up on-call or incident work, that becomes its own row. Otherwise these stay absent.

## Not written, and why

- **"Terraform / ArgoCD / Istio / Vault / Helm / Prometheus / Grafana / GitLab / Go / EKS experience"** — the posting lists them and the resume doesn't show them. They are the first claims an interviewer tests.
- **"Ran Kubernetes in production"** — it was a two-month proof-of-concept that never went to production. That qualifier is the line an interviewer will ask about.
- **"Owned platform reliability"** — you ran pipelines. Owning reliability is a different job, with a wider scope.
- **"CI/CD" as your label for the Jenkins work** — the posting's word. Your sentence already says "deploy pipeline", and swapping in the posting's term would change how you describe your own work.
- **"Observability" as a claim about your monitoring** — CloudWatch monitoring is what the resume says. The posting's word covers more.

## Parse-safety check

I could not run this on the PDF. It is based on your description, so treat each row as a likely risk until you check it.

| Check | What breaks | What it costs |
|---|---|---|
| Two-column layout | Parsers read across the columns | Dates can detach from the roles they belong to. Likely. |
| Icons per skill | Icons come out as garbage characters or are skipped | The skill names can vanish. Likely. |
| Contact details in the header | Header content is treated as page furniture and can be dropped | You could be unreachable. Could not check. |
| Section headings | Parsers look for conventional labels | Confirm the headings read Experience, Skills and Education. Could not check. |
| File type | Canva PDFs usually have a text layer, but not always | Test by selecting text in the PDF. If you can't select it, a parser can't read it either. |

## Upgrade menu (optional, not in the spec)

- **Run the parse check on the real text.** Paste the text you get from copying out of the PDF and I'll check that instead of your description.
- **Build a small public project for one named absence.** For example, a Helm chart deployed by ArgoCD to a local cluster. Once you've built it, it becomes evidence you can cite.
- **Rebuild as single-column after approval.** A plain-text layout removes the two-column and icon risks, and I'd rebuild it only from approved rows.

## Questions

**R1** — Was your Kubernetes proof-of-concept on AWS EKS or a cluster you set up yourself, and did you deploy with Helm charts, raw manifests, or something else?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**R2** — Have you been on call for the deploy pipeline or the services it shipped, or built CloudWatch alarms or dashboards that other people relied on?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**R3** — Did you provision any AWS resources (IAM, S3, RDS, EC2) as code, through CloudFormation, Terraform or Ansible playbooks?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.