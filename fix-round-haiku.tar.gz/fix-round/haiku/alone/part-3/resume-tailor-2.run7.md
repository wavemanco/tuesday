## Dev — Bellhaven Logistics, Data Engineer

I worked from the resume sentences as you wrote them. Three readings I took: "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron" means the scripting is Python; "our then-DE" is a data-engineer colleague; and the dbt work is on Redshift only if you say so. I have not seen the document's layout.

Whether to apply at all, given the three-year must-have, is job-underwriter's call, not this skill's.

Nothing is applied. Every row is pending your approval.

### The edit ledger

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Summary (new) | *(none)* | "Senior Data Analyst, 5 years in retail. Built and maintained about 25 dbt models, including the core orders mart, and designed its star schema with our then-data-engineer." | `merge` | "Senior Data Analyst, 5 years, retail."; "Built and maintained about 25 dbt models including the core orders mart."; "I designed the star schema for the orders mart with our then-DE." | `[grounded]` resume | pending your approval |
| E2 | Experience | "Built and maintained about 25 dbt models including the core orders mart." | *(unchanged, moved to the top of Experience)* | `reorder` | "Built and maintained about 25 dbt models including the core orders mart." | `[grounded]` resume | pending your approval |
| E3 | Experience | "I designed the star schema for the orders mart with our then-DE." | "Designed the star schema for the orders mart with our then-data-engineer." | `reframe` | "I designed the star schema for the orders mart with our then-DE." | `[grounded]` resume | pending your approval |
| E4 | Experience | "I've fixed our nightly dbt job when it breaks and added tests to it." | "Fixed our nightly dbt job when it breaks and added tests to it." | `compress` | "I've fixed our nightly dbt job when it breaks and added tests to it." | `[grounded]` resume | pending your approval |
| E5 | Experience | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | "Wrote scripts that pull vendor APIs on a cron." | `split` | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | `[grounded]` resume | pending your approval |
| E6 | Experience | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | "Wrote Python for analysis, using pandas." | `split` | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | `[grounded]` resume | pending your approval |

E1 is a summary built only from your sentences, kept as three clauses. E2 moves your strongest data-engineering line up. E5 and E6 split one line that does two jobs, so each half traces on its own.

### Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| 1 | 3+ years data engineering | must-have | not_evidenced | Adjacent work is in E1–E6. The three-year span is not established, and your title is Senior Data Analyst. | `[grounded]` resume |
| 2 | Production Python | important | surfaced_by_edit | E5, E6. Partial: the scripts run on a cron, but the resume does not describe them as production, and this skill does not add that word. | `[grounded]` resume |
| 3 | Airflow or equivalent orchestration | important | not_evidenced | The resume does not say what scheduled the nightly dbt job. Cron is the only scheduler it names. | `[grounded]` resume |
| 4 | Dimensional modelling, and modelling the warehouse | important | already_evidenced | "I designed the star schema for the orders mart with our then-DE." Stands as written; E3 only spells out "DE". | `[grounded]` resume |
| 5 | Build and own batch pipelines | important | surfaced_by_edit | E2, E4. Partial: you built the dbt models and fixed the nightly job; "own" is not stated. | `[grounded]` resume |
| 6 | Streaming pipelines (Kafka, Spark) | preferred | not_evidenced | The posting also lists streaming in the responsibilities. You have never used Kafka or Spark. | `[grounded]` your statement, "Never touched Kafka." |
| 7 | Own data quality | important | surfaced_by_edit | E4. Partial: tests were added to the nightly job; "own" is not stated. | `[grounded]` resume |
| 8 | Own SLAs | important | not_evidenced | Nothing in the resume mentions deadlines or freshness targets. | `[grounded]` resume |
| 9 | Partner with analytics on requirements | important | not_evidenced | The resume places you on the analytics side, but does not show a requirements conversation. | `[grounded]` resume |

### Gap handling

**Row 1 — 3+ years data engineering (must-have)**
- *What the resume shows:* about five years in analytics, with dbt, schema and job work inside it and no dates on that work.
- *Why it matters here:* `[generic]` a must-have is usually screened as a years figure, so undated adjacent work may not be read as the span the posting asks for.
- *Experience that may count:* the dbt models, the orders-mart schema, fixing the nightly job, and the cron scripts.
- *Useful evidence:* the dbt repo's commit history, or a dated project note.

**Row 3 — Airflow or equivalent orchestration**
- *What the resume shows:* a nightly dbt job with no scheduler named.
- *Why it matters here:* `[generic]` "equivalent" usually means dependencies, retries and alerts, not just a timed trigger.
- *Experience that may count:* the nightly job's scheduler, if it had dependencies, retries or alerts.
- *Useful evidence:* the scheduler config, a run log, or an alert channel.

**Row 8 — Own SLAs**
- *What the resume shows:* no deadline or freshness language.
- *Why it matters here:* `[generic]` SLA ownership is usually read as a stated target that someone checked against.
- *Experience that may count:* a deadline for the nightly job, or a stakeholder waiting on it.
- *Useful evidence:* an alert threshold, or a message from someone who depended on the data.

**Row 6 — Streaming (named absence).** You have no event-stream work on the resume. `[generic]` Closing it would take a small project you can show: a consumer that loads a public event stream into a table you own, run for several weeks and linked from a repo. The other option is to target roles where batch is the whole job.

**Row 9 — Partner with analytics on requirements (named absence).** The resume does not show a requirements conversation. Closing it takes one specific example, in your own words, of a data change you scoped with an analyst or stakeholder before building it. If you have one, it becomes a new row.

### Not written, and why

- **"3+ years data engineering" or a data-engineer title.** You have never held either, and the must-have is not met on this resume.
- **"Airflow," "Spark," "Kafka," or "familiar with" any of them.** You have never used them, and "familiar with" is still a claim.
- **"Streaming pipelines."** None built.
- **"Owned" the warehouse, the dbt job, data quality or SLAs.** You designed the star schema with a colleague, and you fixed and tested the job. "Owned" is the posting's verb.
- **"Production Python."** The cron scripts are not described as production. That is the posting's word.
- **"Data pipelines" for the dbt models.** The posting's word. What you built was dbt models.
- **"On Redshift" attached to the dbt models.** You run SQL on Redshift daily. The resume does not say where dbt runs.
- **"Partnered with engineering on requirements."** The posting's word. Your seat is the analytics side.

### Parse-safety check

You sent pasted text, not a file, so I could not run the layout checks: multi-column layout, tables and text boxes, headers and footers, and icons. Send the file as a `.docx` or a text-layer PDF and I will run them.

### Upgrade menu

- **The resume as a file** (`.docx` or text-layer PDF): runs the parse-safety check on what a screener actually reads.
- **A link to the dbt repo, or to the vendor-API scripts**, if you can share them: makes the dbt and cron claims inspectable, which bears on rows 1, 2 and 5.
- **The orders-mart design doc or star-schema DDL:** backs the dimensional-modelling line in row 4.
- **The nightly job's scheduler config or a run log:** answers the question for row 3.
- **A prior resume version:** may hold data-engineering lines this version dropped.
- **Dated role or project spans:** makes the three-year claim checkable for row 1.

### Questions

**Row 1 —** When did the dbt and vendor-API work start, and roughly how many months of it were you the person fixing loads when they broke?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Row 3 —** What scheduled the nightly dbt job, and did you configure its dependencies, retries or failure alerts?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Row 8 —** Did the nightly job have a deadline or freshness target someone held you to, and what happened when it missed?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.