I tailored the CV as a pending ledger. Nothing is applied yet, and nothing in it adds a claim.

**What I worked from:** Your CV as you wrote it in this message, treated as self-report. No resume file was supplied, so there are no current lines and the section names are my assumption. `tuesday-dossier.md` was not in the working directory, so I used the excerpt you pasted: its evidence map, pending edit E1, rejected inferences and decision (conditional_go). Its role_profile was not in the excerpt, so I used the JD directly. The dossier's medium confidence on R1 and R2 carries over unchanged.

## Edit ledger

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience | (none) | Wrote the internal integration playbook the whole team uses. | surface | "Wrote the internal integration playbook the whole team uses." | `[grounded]` self-report; dossier pending edit | pending your approval |
| E2 | Experience | (none) | (unchanged, moved to the top of Experience) | reorder | "Led 30+ client integrations of our REST APIs end to end." | `[grounded]` self-report; dossier R2 | pending your approval |
| E3 | Experience | (none) | Ran quarterly roadmap-input sessions collecting client feedback for product. | surface | "Ran quarterly roadmap-input sessions collecting client feedback for product." | `[grounded]` self-report | pending your approval |
| E4 | Skills | (none) | Comfortable in Postman, SQL, OpenAPI specs. | surface | "Comfortable in Postman, SQL, OpenAPI specs." | `[grounded]` self-report | pending your approval |
| E5 | Summary | (none) | 7 years solutions engineer / implementation lead at an enterprise software vendor. Led 30+ client integrations of our REST APIs end to end. | merge | "7 years solutions engineer / implementation lead at an enterprise software vendor." and "Led 30+ client integrations of our REST APIs end to end." | `[grounded]` self-report | pending your approval |

All five rows are pending your approval. Approve by row, for example "Approved: E1, E2, E3, E4, E5."

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 3+ years in product management | must-have | not_evidenced | No PM title or PM work in the material. Adjacent: 7 years of implementation and solutions work (E5). Dossier rates this adjacent, transferability, medium. | `[grounded]` dossier R1; "Never held a PM title." |
| R2 | Shipped API or platform products | important | not_evidenced | Adjacent: E2, client integrations of your REST APIs, vendor-side. No product you owned shipping. Dossier R2, adjacent, medium. | `[grounded]` dossier R2; self-report |
| R3 | Technical fluency | important | surfaced_by_edit | E4 surfaces the tools line; E2 carries the API work. | `[grounded]` self-report |
| R4 | Stakeholder management | important | surfaced_by_edit | E2 and E3: client-facing integration and feedback work. No internal stakeholder example appears. | `[grounded]` self-report |
| R5 | Own the roadmap for the partner-facing API platform | important | not_evidenced | E3 shows you collected input for product. Roadmap ownership and prioritisation authority are not evidenced (dossier). | `[grounded]` dossier; self-report |
| R6 | Run discovery with integration partners | important | surfaced_by_edit | E3 is the nearest match. Partial: "client" is your word, and the partner side and discovery method are not evidenced. | `[grounded]` self-report |
| R7 | Write specs and drive delivery with two engineering squads | important | not_evidenced | E1 is an internal integration playbook, not product specs. No engineering squad appears. | `[grounded]` self-report |
| R8 | Define adoption metrics | important | not_evidenced | Nothing in the material measures adoption. | `[grounded]` self-report |

Priorities for R2 to R4 are my assumption: the JD labels only the 3+ years requirement as must-have.

## Gap handling

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Roadmap ownership and prioritisation (R5); 3+ years PM (R1) | must-have | Quarterly sessions collecting client feedback for product (E3). Nothing shows you ranked or decided. | The first responsibility in the posting is owning the roadmap, and prioritisation is the usual test. | A call where you ranked or cut client requests and product acted on it; a roadmap or backlog decision with your name on it | A backlog, roadmap doc or product review notes showing your call | `[grounded]` the resume shows input collection only; `[generic]` roadmap ownership is what this posting's first responsibility tests |
| C2 | Shipped products and specs (R2, R7) | important | Vendor-side integrations of your REST APIs (E2) and the playbook (E1). No product you owned shipping. | The posting asks for shipped API products and specs engineering builds from. | An SDK, sandbox, certification or API version release you specified; requirements your engineers built against | A spec you wrote, release notes, a playbook page | `[grounded]` the resume shows integration work only; `[generic]` specs are a stated responsibility here |
| C3 | Adoption metrics (R8) | important | No measurement of adoption appears. | Adoption metrics are a stated responsibility, so an absence is visible to a screener. | Post-go-live tracking across the 30+ integrations, such as time to first successful call or drop-off | A dashboard, a report, or a number you presented | `[grounded]` nothing measured in the material; `[generic]` adoption metrics are a stated responsibility here |

**Named absence for R1:** If C1 comes back empty, the 3+ years requirement stays open. The closing path is about six months in a role where you own a roadmap and its decisions are on record. A retitled CV line does not close it.

## Not written, and why

- **"Product manager" or any PM title,** including a retitle to "Product Manager, Platform APIs". You have never held the title.
- **"Owned the roadmap" or "set priorities".** You ran input sessions for product. The material does not show the decisions were yours.
- **"Discovery".** That is the posting's word. Your sessions were "roadmap-input sessions collecting client feedback".
- **"Partner" for your clients.** That is the posting's word; yours is "client". The change would move which side of the table you sat on.
- **"Wrote specs" or "drove delivery with engineering squads".** You wrote an integration playbook and ran client integrations. No squads appear.
- **"Defined adoption metrics" or any adoption figure.** None appear in the material.
- **"Shipped API products".** You integrated clients onto APIs. You did not ship a product.
- **"Expert in OpenAPI" or "wrote OpenAPI specs".** You wrote "Comfortable in ... OpenAPI specs", and E4 keeps that wording.
- **Dossier rejected inferences, unaltered:** "built an internal request-triage tool — memory lead, candidate could not confirm ownership" and "has been the customer of a partner API platform — candidate worked vendor-side". Neither appears in any phrasing.

## Parse safety

With no resume file, the checks ran on your pasted prose only. It is plain text with no hidden content. I could not check the layout, fonts or section structure of the real document.

## Upgrade menu (proposals, not started)

- **Send the resume as a file.** I would then use real current lines for each row and run the parse-safety check on the actual document.
- **Add a spec, release note or adoption number if you have one.** It would turn C2 or C3 into a `[grounded]` row.

## Questions

C1 — In the roadmap-input sessions, did you ever rank or cut client requests, and did product act on your ranking? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

C2 — Did you ever write a spec for a client-facing product or release that engineers built against? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

C3 — Did you track anything across the 30+ integrations after go-live, and did you ever present a number? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.