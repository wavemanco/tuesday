The ledger is below. Nothing is applied yet; every row waits for your approval.

**What I worked from:** your message is the only CV I have, so "Current line" means your sentence as you wrote it. Where the JD asks for something your CV doesn't show, I marked it as a gap rather than writing it in. I also assumed the seven years were mostly server-side work. Tell me if that's wrong, because it changes row 1 of the coverage map.

## Coverage map

Counted against the JD's requirements and responsibilities. The JD lists no preferred requirements.

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| 1 | 5+ years backend | must-have | already_evidenced | "Senior Software Engineer, 7 years" (E1). The word "backend" is not in your CV; server-side work shows in the services and the Kafka/Postgres/gRPC list. | `[grounded]` cv for the years and services; `[inferred]` that the years were server-side |
| 2 | Production Go | must-have | already_evidenced | "Go and Rust daily for 4 years" (E1), with owned services and on-call (E3, E4) | `[grounded]` cv |
| 3 | Distributed systems at scale | must-have | surfaced_by_edit | E2 and E3 move the cache rework and the 40k/min figure to the top. Your CV never describes the system's distribution, so "distributed" is the reader's inference. | `[grounded]` cv for the figures; `[inferred]` that they make a distributed system |
| 4 | Own and ship Go services handling high request volume | must-have | already_evidenced | "I own three services… 40k requests/minute at peak" (E3). "Design" is not claimed. | `[grounded]` cv |
| 5 | Drive down p99 latency | must-have | already_evidenced | "Cut p99… from 380ms to 95ms" (E2) | `[grounded]` cv |
| 6 | Own on-call for your services | must-have | already_evidenced | "On-call rotation every fourth week for two years" (E4) | `[grounded]` cv |
| 7 | Strong incident response | must-have | already_evidenced | "run six incidents as incident commander" (E4) | `[grounded]` cv |
| 8 | Mentor mid-level engineers | must-have | not_evidenced | Nearest is onboarding (E5). Onboarding new hires is not mentoring mid-level engineers. Recovery: C1. | `[grounded]` cv for what it shows |
| 9 | Partner with product on roadmap sequencing | important | not_evidenced | Nothing in the CV. Recovery: C2. | `[grounded]` cv for what it does not say |
| 10 | Build-cache platform or developer-tools work | important | not_evidenced | Nearest is the cache-layer rework (E2), on a payments read path, not a build system. Recovery: C3. | `[grounded]` cv for what it does not say |

## Edit ledger

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Summary | *(no current line)* | "Senior Software Engineer, 7 years. Go and Rust daily for 4 years, Python before that." | `merge` | "Senior Software Engineer, 7 years. Currently at a payments company."; "Go and Rust daily for 4 years, Python before that." | `[grounded]` cv | pending your approval |
| E2 | Experience | "Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer." | Same line, moved to the first bullet | `reorder` | "Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer." | `[grounded]` cv | pending your approval |
| E3 | Experience | "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak." | Same line, moved to the second bullet | `reorder` | "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak." | `[grounded]` cv | pending your approval |
| E4 | Experience | "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | "On-call rotation every fourth week for two years. Ran six incidents as incident commander." | `split` | "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | `[grounded]` cv | pending your approval |
| E5 | Experience | "I do onboarding for new hires on my team — usually two or three a year, I pair with them for their first month." | "Onboard new hires on my team, usually two or three a year, pairing with them for their first month." | `compress` | "I do onboarding for new hires on my team — usually two or three a year, I pair with them for their first month." | `[grounded]` cv | pending your approval |

E4 keeps "six incidents as incident commander" intact. E5 keeps "usually two or three a year" as the qualifier. The skills line (Kafka, Postgres, Terraform, gRPC, Datadog) gets no row: your CV doesn't say which service uses which, so placing them in bullets would be an invented claim.

## Gap handling

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Mentor mid-level engineers | must-have | Onboarding and first-month pairing for two or three new hires a year. Nothing about mid-level engineers or feedback beyond onboarding. | `[generic]` A listed must-have gets checked by name, and onboarding is a narrower act than mentoring. | Sustained review of a mid-level engineer's design or code; a growth plan or promotion case you argued; a mentee who was not a new hire | A written review, a 1:1 note, or a message from the engineer about specific help | `[grounded]` what the CV does and does not say; `[generic]` what this costs on applications of this kind |
| C2 | Partner with product on roadmap sequencing | important | Nothing. No product or roadmap work appears. | `[generic]` Roadmap partnership is usually judged on one decision you shaped, and a reader can't find one here. | An ordering decision where you argued a product manager toward or away from work; a deferral you proposed that the team accepted | A planning thread, roadmap doc, or ticket where you proposed the order | `[grounded]` what the CV does not say; `[generic]` how roadmap partnership is usually read |
| C3 | Build-cache platform or developer-tools work | important | The cache-layer rework (E2) on a payments balance-read path. Nothing on build, artifact, or developer tooling. | `[generic]` Domain match is often read on the first pass. The cache rework is the nearest transferable piece, and the gap should be named. | Any build, CI, artifact, or dependency cache; a platform whose users were other engineers; invalidation rules for a cache several clients shared | A design doc or diagram from the cache rework | `[grounded]` what the CV does not say; `[generic]` how domain match is usually read |

## Not written, and why

- **"Senior Backend Engineer" as your title.** Your title is Senior Software Engineer. "Backend" is the posting's framing.
- **"Mentored mid-level engineers" or "mentorship."** The CV shows onboarding. "Mentor" is the posting's word.
- **"Strong incident response" or "expert on-call."** The CV gives six incidents and two years of rotation. "Strong" is a judgement only you can make.
- **"Designed and shipped high-throughput services."** Your sentences say you own services and reworked a cache layer. "Designed" and "shipped" are not in them.
- **"Distributed systems at scale."** The CV gives one peak figure and no description of distribution.
- **"40k requests/minute" without "at peak."** Dropping the qualifier turns a peak into a sustained rate.
- **"Partnered with product on roadmap."** Not in your CV.
- **Kafka, gRPC, or Postgres attached to specific bullets.** The CV lists them without saying which service uses them.
- **"Build-cache" or "developer tools" experience.** Not in your CV.

## Parse-safety check

Your CV arrived as pasted text in the message, not as a file, so most checks could not run. Not checkable here: multi-column layout, tables and text boxes, images or skill bars, headers and footers (a contact detail placed there would be invisible to me), section headings, and file type. Your text has no section headings, so whether "Experience" and "Skills" are detected depends on the file you actually upload. Run this check again on that file.

**Upgrade menu**

- **Your CV as a file (.docx or a text-layer PDF).** Unlocks exact quotes from the document instead of your message, and the parse-safety check on the real layout.
- **A dashboard export or incident write-up for the cache rework.** Unlocks the 380ms → 95ms figure and "reworking the cache layer" moving from your word to `[grounded]`. This is the strongest bullet in the ledger.
- **A design doc or ticket for the 40k/min service.** Unlocks "at peak" and the 40k figure as `[grounded]`, and settles whether the system is distributed, which row 3 currently infers.
- **A `tuesday-dossier.md` from an earlier evaluation of this role, if you have one.** Unlocks a check of this ledger against that role profile and any inferences already rejected.

**C1 — Outside onboarding, has a mid-level engineer ever relied on you for sustained feedback, such as reviewing their design or code over months, or a growth plan? One example is enough.**
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**C2 — Have you ever shaped the order of a product team's roadmap, for example by arguing a feature up or down the list with a product manager?**
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**C3 — Has any of your work been on a cache, build, or artifact system that other engineers used, or on a platform with internal users?**
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.