**Nothing is applied yet.** Every row below is pending your approval.

The must-have, 3+ years of data engineering, is not met, and no edit can meet it. What the ledger can do is make your analytics-side work visible: the dbt models, the star schema, the fixes and tests, the scripted vendor pulls. None of it is written as pipeline ownership. I worked from your description of the resume, not its text, so each "Traces to" quote is your sentence as you gave it to me. Paste the resume and I'll check every quote against it verbatim before you approve. There was no dossier, so nothing was inherited from one.

## The edit ledger

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Summary (new) | — | "Senior Data Analyst with 5 years in retail, built and maintained about 25 dbt models including the core orders mart, and designed its star schema with our then-DE." | `merge` | "Senior Data Analyst, 5 years, retail."; "Built and maintained about 25 dbt models including the core orders mart."; "I designed the star schema for the orders mart with our then-DE." | `[grounded]` resume | pending your approval |
| E2 | Experience | "I designed the star schema for the orders mart with our then-DE." | "Designed the star schema for the orders mart with our then-DE." | `surface` | "I designed the star schema for the orders mart with our then-DE." | `[grounded]` resume | pending your approval |
| E3 | Experience | "I've fixed our nightly dbt job when it breaks and added tests to it." | "Fixed failures in our nightly dbt job and added tests to it." | `compress` | "I've fixed our nightly dbt job when it breaks and added tests to it." | `[grounded]` resume | pending your approval |
| E4 | Experience | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | "Wrote Python for analysis in pandas, plus some scripting to pull vendor APIs on a cron." | `surface` | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | `[grounded]` resume | pending your approval |

E1 keeps "with our then-DE" in the summary. Dropping it would make the star schema look like your sole work. I haven't proposed a reorder row because I don't have your resume's actual bullet order. Send me the resume and I'll add one if it helps.

## Coverage map

I've treated only the 3+ years as must-have, since the posting marks only that one explicitly. The other requirements are listed as "important" and streaming as "preferred."

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| 1 | 3+ years data engineering | must-have | not_evidenced | Five years of analytics, with adjacent DE work (E1–E4). Not DE experience. Named absence A1. | `[grounded]` resume |
| 2 | Production Python | important | not_evidenced | Analysis scripting and cron-scheduled vendor pulls (E4). Whether they run as production systems isn't stated. Recall C1. | `[grounded]` resume |
| 3 | Airflow or equivalent orchestration | important | not_evidenced | A nightly dbt job and cron scripts exist; what scheduled them isn't stated. Airflow itself was never used. Recall C2. | `[grounded]` resume |
| 4 | Dimensional modelling | important | surfaced_by_edit | Star schema for the orders mart (E2). | `[grounded]` resume |
| 5 | Model the warehouse | important | surfaced_by_edit | About 25 dbt models including the core orders mart (E1). | `[grounded]` resume |
| 6 | Own data quality | important | surfaced_by_edit | Tests added to the nightly dbt job (E3). Ownership of a quality standard is not shown. | `[grounded]` resume |
| 7 | Own SLAs | important | not_evidenced | Nothing in the resume about delivery commitments. Recall C2. | `[grounded]` resume |
| 8 | Partner with analytics on requirements | important | not_evidenced | You sit on the analytics side, but the resume doesn't say you wrote requirements for the data team. Recall C3. | `[grounded]` resume |
| 9 | Streaming (Kafka, Spark) | preferred | not_evidenced | None. Named absence A2. | `[grounded]` resume |

## Recall prompts

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Production Python | important | Analysis pandas and cron-scheduled vendor pulls | A production screen asks whether code runs unattended and fails loudly | The vendor-API scripts; any retries, alerts or handoffs | Repo, cron entry, a failure you handled | `[grounded]` what the resume says; `[generic]` what screeners probe for here |
| C2 | Orchestration and SLAs | important | A nightly dbt job and cron scripts; no scheduler named | This role owns scheduling, dependencies, retries and delivery times | Changes you made to the nightly job's schedule; failure alerts; any deadline the mart met | Scheduler config, an alert, an SLA doc | `[grounded]` what the resume says; `[generic]` what this costs on applications of this kind |
| C3 | Partner with analytics on requirements | important | You as the analyst on the orders mart; not who wrote its requirements | The JD's engineer serves analytics' needs, which is your side of the table | Any mart change you specified | A ticket or spec | `[grounded]` what the resume says; `[generic]` what this costs on applications of this kind |

## Named absences

- **A1, 3+ years data engineering (must-have).** Five years of analytics, with dbt and star-schema work that is adjacent to data engineering but not a substitute for it. No edit closes this for this application. The honest options are to apply with the adjacent case stated plainly, to target analytics-engineering roles where dbt and dimensional work is the core, or to build DE-scope work over a longer period. The last takes months of real work `[generic]`.
- **A2, streaming (Kafka, Spark; preferred).** Never used. Closing it means a Kafka or Spark project you can show, which is months of work. It is not worth closing for this role alone unless you want streaming work.

## Not written, and why

- **"3+ years data engineering," or a Data Engineer title or role.** You haven't held the title, and the must-have is unmet.
- **Retitling to "Analytics Engineer" or "Data Engineer."** Neither is an equivalent of Senior Data Analyst.
- **"Built batch or streaming pipelines," or "owned pipelines."** The evidence shows fixing and testing one nightly dbt job and scripting cron pulls.
- **Airflow, Spark, Kafka, or streaming in the skills list.** You've never used them.
- **"Production Python."** Nothing in the resume establishes it. That's C1.
- **"Owned data quality" or "owned SLAs."** You added tests. The resume shows no ownership of a standard or a commitment.
- **"Led the star schema," "architected."** You designed it with your then-DE, and "led" would move the credit.
- **"Partnered with engineering on requirements," or "defined requirements for the data team."** Neither is stated. That's C3.
- **Usage counts, such as "used by X teams."** Not in your material.
- **JD vocabulary in your own history:** "warehouse modelling," "orchestration," "data quality ownership." The lines above use your words: dbt models, star schema, tests.

## Parse-safety check

The resume arrived as a description, not a file, so layout checks could not run. The text you sent shows no hidden or white-on-white text. Not checked: multi-column layout, tables, headers and footers, and file type. Send the file and I'll run those.

## Next steps (optional offers, not in the spec)

- **Small Airflow project.** Orchestrate your dbt run and one vendor pull in a public repo. It would turn the orchestration gap into something a reviewer can inspect. Your employer's code probably can't be shown.
- **Kafka consumer project.** Only worth it if you want streaming work, since streaming is preferred, not required.
- **Re-run after C1–C3.** Each answer may upgrade a row, and I'd re-audit anything that changes.

Approve by row ID, for example "Approved: E1, E2, E4; rejected: E3." Whether to apply at all, given the must-have, is job-underwriter's call, and it's worth running before you invest in tailoring.

C1 — Do the cron scripts that pull vendor APIs run unattended for others to depend on? If so, what happens when one fails, and who gets told?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

C2 — What schedules the nightly dbt job and the cron scripts today? Have you set or changed their scheduling, retries or failure alerts, and did anyone depend on the mart being ready by a set time?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

C3 — When the orders mart needed a new field or table, did you write the requirements the data team built to, or did someone else?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.