I'll check the working directory for the dossier and any CV file before drafting anything.
The working directory is empty, so the dossier excerpt and your CV are only in your message. I'll load the resume-tailoring skill to produce the edit ledger.
The skill requires reading its reference files before building the ledger. I'll load the ones it names for this step.
Nothing is applied yet. Every row below is pending your approval, and the tailored CV is produced only from the rows you approve.

**Inputs:** The dossier came as a pasted excerpt, not a file, so I worked from that excerpt. Your CV came as pasted text with no headings, so the section names are my assumption. I could not run the parse-safety check on any layout.

**Where this stands:** The two must-haves the dossier marks adjacent are still not evidenced: three years of PM work, and shipped API products. The ledger presents your integration and feedback work as adjacent, not as the thing they ask for.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R-a | 3+ yrs PM | must-have | not_evidenced | Your seven years are solutions-engineering time, not PM time, so they do not meet this bar. Closing path in C1. | `[grounded]` CV; dossier R1 adjacent, medium |
| R-b | Shipped API or platform products | must-have | not_evidenced | Integration work with clients using your REST APIs (E2). Adjacent, not shipped. Closing path in C2. | `[grounded]` CV; dossier R2 adjacent, medium |
| R-c | Technical fluency | must-have | surfaced_by_edit | Postman, SQL, OpenAPI row (E4). "Comfortable" is your own self-report. | `[grounded]` CV |
| R-d | Stakeholder management | must-have | surfaced_by_edit | Client integrations and roadmap-input sessions (E2, E3, E5). The CV shows client-facing work, not how stakeholders were managed. | `[grounded]` CV |
| R-e | Own the roadmap | important | not_evidenced | Roadmap input was collected, not owned (dossier R1). Closing path in C1. | `[grounded]` CV |
| R-f | Run discovery with integration partners | important | not_evidenced | Collecting client feedback is adjacent. Discovery is not stated. Closing path in C1. | `[grounded]` CV |
| R-g | Write specs; drive delivery with two engineering squads | important | not_evidenced | The playbook (E1) is internal process, not specs. Delivery with engineering is not stated. Closing path in C2. | `[grounded]` CV |
| R-h | Define adoption metrics | important | not_evidenced | No adoption measure appears in the CV. Closing path in C3. | `[grounded]` CV |

The posting does not tier the responsibilities, so I have marked them important.

## Edit ledger

The CV has no headings, so "Section" is my assumption.

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience (assumed) | Wrote the internal integration playbook the whole team uses. | *(unchanged, set as its own line)* | surface | "Wrote the internal integration playbook the whole team uses." | `[grounded]` CV; dossier pending edit | pending your approval |
| E2 | Experience (assumed) | Led 30+ client integrations of our REST APIs end to end. | *(unchanged, moved to the first bullet)* | reorder | "Led 30+ client integrations of our REST APIs end to end." | `[grounded]` CV | pending your approval |
| E3 | Experience (assumed) | Ran quarterly roadmap-input sessions collecting client feedback for product. | *(unchanged, moved to the second bullet)* | reorder | "Ran quarterly roadmap-input sessions collecting client feedback for product." | `[grounded]` CV | pending your approval |
| E4 | Skills (assumed) | Comfortable in Postman, SQL, OpenAPI specs. | Comfortable in Postman, SQL, OpenAPI specs. *(own line)* | surface | "Comfortable in Postman, SQL, OpenAPI specs." | `[grounded]` CV, self-report | pending your approval |
| E5 | Summary (no current line) | *(none)* | 7 years solutions engineer / implementation lead at an enterprise software vendor. | surface | "7 years solutions engineer / implementation lead at an enterprise software vendor." | `[grounded]` CV | pending your approval |

Two notes on the audit. In E5 I kept the slash, because "and" would claim both roles where your sentence allows either. E1 passes the audit as written; it is the dossier's pending edit, and I checked it against your sentence like any other row.

## Not written, and why

- **"Product Manager," or any "Product" title or headline.** You have never held a PM title.
- **"3+ years product management," or any PM years.** Your seven years are solutions engineering and implementation.
- **"Owned the roadmap," "set priorities," "prioritised the backlog."** Roadmap ownership and prioritisation authority are not evidenced (dossier R1).
- **"Shipped API products," or "shipped" of any kind.** You integrated clients onto your REST APIs. The CV does not say you shipped a product (dossier R2).
- **"Wrote OpenAPI specs," or "wrote specs."** The CV says you are comfortable in OpenAPI. Writing the playbook is a different thing.
- **"Ran discovery with partners."** The CV says you collected client feedback. Discovery is a different kind of work.
- **"Partner" in place of "client."** You sat on the vendor's side. The posting's word would change which side of the table you were on.
- **"Drove delivery with engineering squads."** Not stated.
- **Adoption figures, or "drove adoption."** The 30+ count is integrations delivered, not adoption. Attaching it to adoption changes what the number counts.
- **Rejected inferences from the dossier:** "built an internal request-triage tool" (ownership unconfirmed), and "customer of a partner API platform" (you were vendor-side).

## Recall prompts

| # | Requirement | Priority | What your resume shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | 3+ yrs PM; own roadmap; run discovery | must-have / important | Quarterly roadmap-input collection for product | `[generic]` PM bars usually test whether you decided what got built, not whether you collected input | A quarter where you chose which client requests went into the roadmap or set their order; any discovery sessions you ran rather than collected | A roadmap-input summary sent to product | `[grounded]` CV; `[generic]` what PM bars usually test |
| C2 | Shipped API products; write specs; drive delivery | must-have / important | Client integrations of your REST APIs; internal playbook | `[generic]` shipping evidence is what separates integration work from product work | An API change that shipped from feedback you collected; a spec engineering built from | A release note, spec, or ticket | `[grounded]` CV; `[generic]` what shipping evidence separates |
| C3 | Define adoption metrics | important | 30+ integrations, with no adoption measure | `[generic]` adoption metrics are usually what a PM reports on after launch | Any measure of how integrations or endpoints were used after go-live | A usage figure or adoption report | `[grounded]` CV |

## Questions

C1 — Did you ever choose which client requests went into the roadmap or set their order, or did you only collect them and pass them to product?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

C2 — Did any API change ship from feedback you collected, and did you write the spec engineering built from?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

C3 — Did you track how integrations or endpoints were used after go-live?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

## Offers beyond the spec

- **Offer: attach the playbook, redacted if needed.** It is an inspectable artifact, so it could raise E1 from medium confidence toward high. It is the nearest thing you have to a spec for this posting. I would build on it only if you approve.
- **Offer: attach one roadmap-input summary.** It would show the feedback-to-product path concretely, which is the closest evidence you have to discovery.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.