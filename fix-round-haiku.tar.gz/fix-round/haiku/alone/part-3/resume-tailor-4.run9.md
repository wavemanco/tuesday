Keyword matching is probably part of the problem, but the evidence doesn't support it as the main cause of silent rejection. Content-based auto-rejection exists, but in one vendor's interviews only 2 of 25 recruiters had it configured, and the vendor says the sample isn't representative (cite C25). Where teams use match scores, they mostly use them to order who gets read first. A low score can push you to the bottom of a high-volume pile, but it doesn't reject you outright (cite C27). What most often rejects people without a human reading is knockout questions on the application form, such as work authorization, required licence or location (cite C26). No resume edit changes those. Whether a knockout is likely to fail for you is job-underwriter's call, and worth settling before you put more into this application.

The larger issue is the posting. Most of the named tools (Terraform, ArgoCD, Istio, Prometheus, Vault, Helm, GitLab, Go) aren't in your material, so no keyword edit can add them honestly. The edits below make what you do have findable, with the proof-of-concept's limits kept intact. If the rejections are coming from a person's read, the coverage map is the likely reason.

I'm working from your description, not the file. The "current line" cells quote your sentences, and I couldn't run the parse checks on the PDF.

Research tier: L0 — no searches

## Edit ledger

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Skills | (no current line) | Kubernetes — two-month proof-of-concept, never went to production | `surface` | "Ran a Kubernetes proof-of-concept for two months last year, never went to production." | `[grounded]` cv | pending your approval |
| E2 | Skills | (no current line) | Python — scripting, alongside Bash | `surface` | "Bash and Python scripting" | `[grounded]` cv | pending your approval |
| E3 | Experience | "Ran a Kubernetes proof-of-concept for two months last year, never went to production." | *(unchanged — moved to the top of its role's bullets)* | `reorder` | "Ran a Kubernetes proof-of-concept for two months last year, never went to production." | `[grounded]` cv | pending your approval |
| E4 | Summary (new) | (no current line) | DevOps Engineer, 4 years. AWS (EC2, S3, RDS, IAM), Docker, Jenkins, Ansible, CloudWatch; Bash and Python scripting. Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs. Ran a Kubernetes proof-of-concept for two months last year, never went to production. | `merge` | "DevOps Engineer, 4 years."; "AWS (EC2, S3, RDS, IAM), Docker, Jenkins, Bash and Python scripting, Ansible for config management, CloudWatch for monitoring."; "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs."; "Ran a Kubernetes proof-of-concept for two months last year, never went to production." | `[grounded]` cv | pending your approval |

E1 and E4 both name Kubernetes, and the qualifier is kept each time. A skills entry that is only a tool name would claim more than the proof-of-concept supports. E4 keeps "DevOps Engineer, 4 years" as its own sentence, so the four years don't attach to the tools.

## Coverage map

The posting has no priority tiers, so I've ranked by its one ordering sentence ("You will own platform reliability…"). That ranking is my reading.

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | Kubernetes | must-have | surfaced_by_edit | E1, E3, E4: the proof-of-concept, with its limits stated | `[grounded]` cv |
| R2 | AWS | must-have | already_evidenced | AWS (EC2, S3, RDS, IAM) in the current resume | `[grounded]` cv |
| R3 | AWS EKS | must-have | not_evidenced | AWS is shown; EKS is not, and the proof-of-concept's platform isn't stated. Recall prompt C1 | `[grounded]` cv |
| R4 | Python | must-have | surfaced_by_edit | E2, E4 | `[grounded]` cv |
| R5 | CI/CD | must-have | already_evidenced | The Jenkins deploy pipeline is what a reader sees. The term "CI/CD" isn't written until C3 confirms it | `[grounded]` cv |
| R6 | GitLab CI | must-have | not_evidenced | Jenkins only; no GitLab. Named absence | `[grounded]` cv |
| R7 | Platform reliability | must-have | not_evidenced | No reliability ownership in your material. Named absence | `[grounded]` cv |
| R8 | Terraform | important | not_evidenced | No infrastructure-as-code is stated. Recall prompt C2 | `[grounded]` cv |
| R9 | GitOps | important | not_evidenced | Ansible is configuration management, not GitOps. Named absence | `[grounded]` cv |
| R10 | ArgoCD | important | not_evidenced | Named absence | `[grounded]` cv |
| R11 | Helm | preferred | not_evidenced | Named absence | `[grounded]` cv |
| R12 | Istio | important | not_evidenced | Named absence | `[grounded]` cv |
| R13 | Service mesh | important | not_evidenced | Named absence | `[grounded]` cv |
| R14 | Prometheus | important | not_evidenced | Named absence | `[grounded]` cv |
| R15 | Grafana | preferred | not_evidenced | Named absence | `[grounded]` cv |
| R16 | Observability | important | not_evidenced | CloudWatch monitoring is adjacent. The term isn't claimed | `[grounded]` cv |
| R17 | SRE practices | important | not_evidenced | Named absence | `[grounded]` cv |
| R18 | Vault | preferred | not_evidenced | Named absence | `[grounded]` cv |
| R19 | Go | preferred | not_evidenced | Named absence | `[grounded]` cv |
| R20 | Developer experience | important | not_evidenced | Not claimed. See the note under gap handling | `[grounded]` cv |

## Gap handling

**Recall prompts.** Each one is a question you can answer in text, a voice transcript, an attachment, a link, or "skip". The questions are in the closing block.

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | AWS EKS | must-have | The proof-of-concept, without the platform it ran on | Ridgemount names EKS. If the proof-of-concept ran on EKS, that line can be stated | The proof-of-concept's cluster and setup; what you deployed on it | A repo, a diagram, a write-up | `[grounded]` the resume does not say where it ran; `[generic]` what this costs on applications of this kind |
| C2 | Terraform | important | AWS resources listed, with no account of how they were created | The posting names Terraform. If you used it, the term is accurate | Terraform, CloudFormation, Ansible-managed resources, or console-only | A module, a repo, a pipeline file | `[grounded]` the resume does not say how resources were created |
| C3 | CI/CD | must-have | "Built our deploy pipeline in Jenkins…" with no account of the stages | The term applies only if the pipeline built, tested and deployed automatically | Build, test and deploy stages you owned | A Jenkinsfile or job configuration | `[grounded]` the resume; `[generic]` what this costs on applications of this kind |

**Named absences.** Each gap, and what closing it would take:

- **GitLab CI (R6):** You used Jenkins. Closing it means a GitLab CI pipeline you built and can link. That gives you something to show; it doesn't give you workplace experience.
- **Platform reliability and SRE practices (R7, R17):** Nothing in your material shows reliability ownership. Closing it means ownership you can describe: an on-call rotation, an incident you led, a reliability target you set. If one of those exists, it changes the coverage map. It isn't a line I can write.
- **GitOps, ArgoCD, Helm (R9–R11):** Closing them means a Kubernetes workload deployed from a Git repository with Argo CD and packaged with Helm, something you can show.
- **Istio and service mesh (R12, R13):** Closing them means a mesh you have installed and can describe.
- **Prometheus, Grafana, observability (R14–R16):** Closing them means a Prometheus and Grafana setup you built. CloudWatch is adjacent evidence, not the same thing.
- **Vault (R18):** Closing it means a secrets setup you have run. IAM doesn't count.
- **Go (R19):** Closing it means a Go program you wrote and can show. Python is what your resume supports.
- **Developer experience (R20):** Not claimed. If other engineers used the Jenkins jobs and you changed how they worked, that's a fact you'd need to confirm, and it would become a row.

## Not written, and why

- **"Production Kubernetes experience"** — you said the proof-of-concept never went to production. Dropping that qualifier is the most likely way to overclaim here.
- **"AWS EKS"** — the proof-of-concept's platform isn't stated (C1).
- **"Terraform" or "infrastructure as code"** — nothing in your material says so (C2).
- **"CI/CD"** — not written until C3 confirms the pipeline's stages.
- **"GitLab CI"** — you used Jenkins.
- **"ArgoCD," "GitOps," "Helm," "Istio," "service mesh," "Vault," "Prometheus," "Grafana," "Go"** — none appears in your material.
- **"SRE practices," "platform reliability," "owned reliability"** — no ownership is shown.
- **"Observability"** — CloudWatch monitoring is adjacent to it, not the same thing.
- **"Owned the deploy pipeline" or "led"** — you built and maintain it. Those verbs would claim more.
- **"Platform Engineer" as a title** — your title is DevOps Engineer; retitling would claim a different role.

## Parse-safety check

I didn't have the PDF, so these are checks you can run yourself on the file.

| Check | What breaks | What it costs | What I could see |
|---|---|---|---|
| Multi-column layout | Parsers read across columns, so text interleaves | Dates can detach from the roles they belong to | Described as two-column, so this is the one structural risk visible in the description |
| Tables and text boxes | Cell contents get reordered or dropped | Whole sections can disappear silently | Not visible. Check whether any section is in a box |
| Icons and skill-level graphics | Icons are read as garbage or skipped | Any skill that exists only as an icon is absent to a parser | Described: one icon per skill. Test: select all and copy the text; if skill names don't appear, that's the risk |
| Contact details in the header | Headers and footers are often discarded | You could become unreachable | Described as being in the header. Test: do your email and phone appear in the copied text? |
| Section headings | Non-standard headings may not be recognised | An unrecognised Experience heading loses the section's entries | Not visible |
| File type | Varies by parser | A PDF with a real text layer is fine. Flattened or outlined text is not | Not visible. Test: can you select and copy the text in a PDF viewer? |

## Upgrade menu

- **The PDF itself:** lets the parse checks run on the real file and replaces my reconstructed "current line" cells with exact text.
- **A write-up, repository or diagram of the proof-of-concept:** would let the Kubernetes line move from medium to high confidence, with an artifact to point to.
- **A redacted Jenkinsfile or job configuration:** would let the CI/CD line rest on an inspectable artifact, if C3 confirms the stages.

## Questions

C1 — Where did the Kubernetes proof-of-concept run, on AWS EKS or somewhere else, and what did you deploy on it?
C2 — How were the AWS resources (EC2, S3, RDS, IAM) created: by hand, by scripts, with Ansible, or with Terraform or CloudFormation?
C3 — Did the Jenkins pipeline build, test and deploy automatically, and which of those stages did you own?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

Nothing is applied yet. Tell me which of E1–E4 to approve, reject, or change, and I'll produce the tailored resume from the approved rows only.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.