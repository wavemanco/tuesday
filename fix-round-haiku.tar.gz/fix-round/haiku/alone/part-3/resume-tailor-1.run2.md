Nothing is applied yet. Every row below is pending your approval. I treated the sentences you pasted as your current CV lines, and I mapped them into Summary, Experience and Skills.

## Edit ledger

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| R1 | Summary (new) | *(no current line)* | "Senior Software Engineer, 7 years. Go and Rust daily for 4 years, Python before that. I own three services in our ledger pipeline — one handles about 40k requests/minute at peak." | `merge` | "Senior Software Engineer, 7 years."; "Go and Rust daily for 4 years, Python before that."; "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak." | `[grounded]` CV | pending your approval |
| R2 | Experience | "Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer." | *(unchanged, moved to the top of Experience)* | `reorder` | "Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer." | `[grounded]` CV | pending your approval |
| R3 | Experience | "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | *(unchanged, moved up beside the p99 line)* | `reorder` | "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | `[grounded]` CV | pending your approval |
| R4 | Experience | "I do onboarding for new hires on my team — usually two or three a year, I pair with them for their first month." | "Onboard new hires on my team — usually two or three a year, pairing with each for their first month." | `reframe` | "I do onboarding for new hires on my team — usually two or three a year, I pair with them for their first month." | `[grounded]` CV | pending your approval |

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| 1 | 5+ years backend | must-have | already_evidenced | 7 years as Senior Software Engineer. The CV doesn't say how many of those were backend. The Go service work reads as backend, but the count is yours to confirm. | `[grounded]` "Senior Software Engineer, 7 years." |
| 2 | Production Go | must-have | already_evidenced | Go daily for 4 years. R1 moves it into the summary. | `[grounded]` "Go and Rust daily for 4 years, Python before that." |
| 3 | Distributed systems at scale | must-have | surfaced_by_edit | R1 brings the 40k requests/minute figure up into the summary. The CV does not say the services are distributed, or where Kafka and gRPC sit. See question 3. | `[grounded]` "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak." |
| 4 | Strong incident response | must-have | already_evidenced | Six incidents as incident commander, on call every fourth week for two years. R3 moves it up, but the line already holds without the move. | `[grounded]` "On-call rotation every fourth week for two years, I've run six incidents as incident commander." |
| 5 | Experience mentoring (mid-level engineers) | must-have | not_evidenced | Onboarding and first-month pairing with new hires (R4). That is not mentoring of mid-level engineers, which is what the requirement names. See question 1. | `[grounded]` "I do onboarding for new hires on my team — usually two or three a year, I pair with them for their first month." |
| 6 | Design and ship Go services handling high request volume | important | already_evidenced | "Own" is the nearest verb in your sentences. "Design" and "ship" are not stated. | `[grounded]` "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak." |
| 7 | Drive down p99 latency | important | already_evidenced | 380ms to 95ms on the balance-read path. R2 moves it to the top. | `[grounded]` "Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer." |
| 8 | Own on-call for your services | important | already_evidenced | Every fourth week for two years. | `[grounded]` "On-call rotation every fourth week for two years, I've run six incidents as incident commander." |
| 9 | Partner with product on roadmap sequencing | important | not_evidenced | The CV has no product or roadmap sentence. See question 2. | `[grounded]` the CV has no sentence on product or roadmap work. |
| 10 | Build-cache platform or developer-tools work | important | not_evidenced | Everything in the CV is payments and ledger. See the named absence below. | `[grounded]` "Currently at a payments company." |

## Gap handling

Recall prompts. Each question is asked once, in the closing block.

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Experience mentoring (mid-level engineers) | must-have | Onboarding and first-month pairing with new hires (R4). Not mentoring of mid-level engineers. | A named requirement is usually checked on its own, not inferred from onboarding. | Someone you coached over months through design reviews, on-call or growth; a growth plan you wrote with someone. | A 1:1 history, a growth doc, a sentence from a review. | `[grounded]` what the CV shows; `[generic]` how postings like this are usually read |
| C2 | Partner with product on roadmap sequencing | important | Nothing: no product or roadmap sentence. | `[generic]` Postings that pair roadmap work with on-call and mentoring usually expect a senior engineer to shape the work, not only build it. | A sequencing decision you made with a PM; a launch date you negotiated; a planning doc you co-wrote. | A planning doc, a roadmap review invite, a ticket history. | `[grounded]` what the CV shows; `[generic]` the posting pattern above |

Named absence:

| # | Requirement | Priority | The gap | What closing it would take | Provenance |
|---|---|---|---|---|---|
| N1 | Build-cache platform or developer-tools work | important | Your work is payments and ledger. The posting names the build-cache platform under responsibilities, not requirements. | Hands-on work on build, cache or developer-tools infrastructure over a sustained period. Short of that, say the gap in the application rather than writing around it. | `[grounded]` the posting text; `[grounded]` "Currently at a payments company." |

## Not written, and why

- **"Mentored mid-level engineers" or "experienced mentor."** The CV shows onboarding and first-month pairing for new hires, and R4 keeps that narrower wording.
- **"Partnered with product on roadmap sequencing."** Nothing in the CV supports it.
- **"Designed" or "architected" the cache layer.** The CV says "reworking." R2 keeps that verb.
- **"Led" incident response, or "strong" incident response.** The CV says you ran six incidents as incident commander. "Strong" is the posting's word, not yours.
- **"Built and shipped" services.** The CV says you own them. Design and ship are not stated.
- **"Backend engineer for 7 years."** The CV gives 7 years as a Senior Software Engineer and does not say how many were backend.
- **Kafka, gRPC or Postgres in the ledger services.** The CV lists them but no sentence ties them to the services. Pending question 3.
- **"Three services handling 40k requests/minute."** The figure belongs to one service: "one handles about 40k requests/minute at peak."
- **Terraform and Datadog in any bullet.** No sentence connects them to work. They stay in the skills list, unchanged.
- **Build-cache or developer-tools experience.** None in the CV.

## Parse-safety check

There is no resume file, only pasted text, so I can't check layout, fonts, headers, footers or how a file would parse. The proposed text uses standard section names (Summary, Experience, Skills) and has no tables or columns. I'll run the full check on the document in the step where approved rows become a resume.

## Upgrade options

These are proposals and will not be built without your approval.

- **A write-up of the balance-read cache rework**: what was slow, what changed, how the 380ms to 95ms was measured. It would give the p99 line a source you can point to in an interview. Worth it if you want to show the work, not only state the result.
- **A second ledger pass after you answer the questions below.** Only the rows those answers touch would be regenerated.

## Questions

C1 — Have you formally mentored mid-level engineers, meaning someone you regularly coached on their work, not only onboarded? If so, who, for how long, and what changed for them?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

C2 — Have you taken part in deciding what your team builds next or in what order, with product or a PM? If so, which decision, and what part of it was yours?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

3 (coverage row 3) — Which of Kafka, gRPC or Postgres sat in the request or data path of the 40k requests/minute service, and how many instances served that load?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

Tell me which rows you approve, reject, or want changed, and I'll produce the tailored resume from the approved rows only.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.