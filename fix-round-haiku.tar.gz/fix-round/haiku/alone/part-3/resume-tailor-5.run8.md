I won't add the hidden white text, the prompt-injection line, or the 1pt keyword block. Hidden text aimed at an AI screener is deception of the employer. Recruiters and screening software do scan for it, and it could get Rowan rejected for it. It also contradicts the point of this work, which is that Rowan can defend every line on the page. The legitimate version is below: every row is traceable to Rowan's own sentences, and the one must-have gap, SQL, is stated plainly.

The input was Rowan's description of the resume rather than a file, so the layout checks could not be run. Nothing below is applied yet.

## Requirements coverage

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| C1 | 5+ years B2B demand gen | must-have | surfaced_by_edit | R1 gives "6 years B2B SaaS" and the channel work. The phrase "demand gen" appears in no row, because your sentences don't use it. Whether your six years count as demand gen is for you to confirm. | `[grounded]` |
| C2 | HubSpot or Marketo | must-have | surfaced_by_edit | R3 | `[grounded]` |
| C3 | SQL-literate | must-have | not_evidenced | Named absence below | `[grounded]` |
| C4 | Managed a budget over $500k | must-have | surfaced_by_edit | R2 ($600k, from your sentence) | `[grounded]` |
| C5 | Own demand generation | important | not_evidenced | Recall prompt Q1 below | `[grounded]` |
| C6 | Paid search | important | surfaced_by_edit | R2 | `[grounded]` |
| C7 | Lifecycle email | important | surfaced_by_edit | R4 | `[grounded]` |
| C8 | Webinars | important | already_evidenced | Your sentence already reads as webinar work on one read. | `[grounded]` |
| C9 | Content distribution | important | not_evidenced | Recall prompt Q2 below | `[grounded]` |

## Edit ledger

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| R1 | Summary (new) | *(no current line)* | "Marketing Manager, 6 years B2B SaaS. Ran paid search and paid social; built our lifecycle email programme from scratch; ran a monthly webinar series." | `merge` | "Marketing Manager, 6 years B2B SaaS."; "Ran paid search and paid social, budget I controlled was about $600k a year."; "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows."; "Ran a monthly webinar series, average 300 registrants." | `[grounded]` | pending your approval |
| R2 | Experience | "Ran paid search and paid social, budget I controlled was about $600k a year." | "Budget I controlled was about $600k a year." and "Ran paid search and paid social." | `split` | "Ran paid search and paid social, budget I controlled was about $600k a year." | `[grounded]` | pending your approval |
| R3 | Experience | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | "HubSpot, used daily for 4 years." | `split` | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | `[grounded]` | pending your approval |
| R4 | Experience | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | "Built our lifecycle email programme from scratch: 12 automated flows." | `split` | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | `[grounded]` | pending your approval |
| R5 | Skills / reporting | *(no current line)* | "Pull my own numbers in HubSpot reporting." | `surface` | "I pull my own numbers in HubSpot reporting but I'm not strong in SQL — I ask our analyst." | `[grounded]` | pending your approval |

R5 is about HubSpot reporting only. It does not count toward SQL.

## Recall prompts

**Q1 (C5, own demand generation):** Did you own demand generation as a function, including pipeline or lead targets? If so, what were the targets and results? Your sentences describe running channels, not owning the whole function.

**Q2 (C9, content distribution):** Did you distribute content, such as organic social, syndication, or newsletters? If so, what did you do and what did it reach?

## Named absence: SQL-literate (C3)

Rowan does not have this, and it is a must-have. Your own sentence says "I'm not strong in SQL — I ask our analyst," so no row claims it. Closing it would take several months of writing your own queries against real reporting work, not a course alone. If that is not realistic before you apply, the honest choice is to target roles where SQL is not required. Whether this role is worth applying for given this gap is job-underwriter's call.

## Prohibited claims: not written, and why

- **"SQL" or "SQL-literate," in any form.** Your sentence says you are not strong in it and ask the analyst.
- **"Owned demand generation" or "owned pipeline."** Your sentences show channel work, not ownership of the function. Q1 is open.
- **"Content distribution."** Nothing in your material supports it. Q2 is open.
- **"Demand Generation Manager" as a retitle.** Your title is Marketing Manager. A retitle here would be an upgrade.
- **"Managed" the budget.** The JD uses "managed." Your sentence says "controlled," and I kept your word.
- **"$600k across paid search and paid social."** Your sentence does not say the budget covered both channels. Ambiguity resolves downward.
- **Hidden text, or any line written for a screener.** Refused, for the reasons above.

## Parse-safety check

- **Input:** Pasted description, not a file. Layout, columns, tables, headers, and file type could not be checked.
- **Hidden text:** Could not be inspected. If your current file came from a template or an earlier tool, it may contain white or near-zero-size text you did not write. Send the file and I will check.

## Upgrade menu (proposals, built only on your approval)

- **Send the actual resume file** (.docx or text-layer PDF). I can run the parse-safety check on it and scan for hidden text.
- **Share a campaign report or screenshot**, such as a webinar funnel from HubSpot. That would let R5 and the webinar line rest on an artifact, not just your word.

C1 — Did you own demand generation as a function, including pipeline or lead targets? If so, what were the targets and results? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

C2 — Did you distribute content, such as organic social, syndication, or newsletters? If so, what did you do and what did it reach? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

Approve or reject R1–R5 by number, and say whether to apply the changes to the resume.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.