I've read the skill's rules and reference files. One correction before the work, because it changes what the resume can do.

**Keywords are probably not the main reason you're being rejected.** Content-based auto-rejection exists, but it's uncommon. In one vendor's interviews, two of 25 recruiters had it configured (cite C25). That sample is small and the vendor sells résumé builders. Where automated filters are used, the source says "they’re almost always knockout questions" (cite C26). Those are yes/no eligibility checks, such as work authorization, required licence or location, answered on the application form, not in the resume. Match scores mostly order who gets reviewed first: "Low score ≠ auto-reject, but in high-volume roles, it can push you to the bottom of the pile" (cite C27). Whether a knockout question would reject you is job-underwriter's check, and it's worth running before you spend more time on this resume.

The bigger problem is that the JD asks for a stack your resume doesn't show. Keyword edits can make your real experience easier to find, but they can't add Terraform or turn a proof-of-concept into production Kubernetes. The ledger below is short for that reason.

**Assumptions:** The JD doesn't mark any requirement as preferred, so I've treated all 18 rows as must-have. Your resume arrived as pasted text, so the parse check is based on your description of the layout. No dossier was in context, so the ledger is built from the resume alone.

## Edit ledger

Nothing is applied until you approve a row.

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Skills | "AWS (EC2, S3, RDS, IAM), Docker, Jenkins, Bash and Python scripting, Ansible for config management, CloudWatch for monitoring." | Add first: "Kubernetes (proof-of-concept for two months, never in production)" | `surface` | "Ran a Kubernetes proof-of-concept for two months last year — never went to production." | `[grounded]` cv | pending your approval |

Rows I did not write:
- A summary line or retitle to "Platform Engineer". You haven't held that title, so the row would claim it.
- Any row adding Terraform, EKS, GitOps, observability tools, Vault, Helm, Go or SRE work. Your resume has no line to trace them to.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| 1 | Kubernetes | must-have | surfaced_by_edit | E1. A proof-of-concept only, never in production. A reader should not take it as production experience. | `[grounded]` cv: "Ran a Kubernetes proof-of-concept for two months last year — never went to production." |
| 2 | AWS | must-have | already_evidenced | Skills line: EC2, S3, RDS, IAM | `[grounded]` cv: "AWS (EC2, S3, RDS, IAM)" |
| 3 | AWS EKS | must-have | not_evidenced | Nothing names EKS. See C2 below. | `[grounded]` cv does not name EKS |
| 4 | Terraform | must-have | not_evidenced | Absent. Ansible is config management, not Terraform. See C3 below. | `[grounded]` cv does not name Terraform |
| 5 | ArgoCD | must-have | not_evidenced | Absent. | `[grounded]` cv does not name ArgoCD |
| 6 | GitOps | must-have | not_evidenced | Absent. Your Jenkins pipeline is push-based, so it doesn't count. | `[grounded]` cv does not name GitOps |
| 7 | Istio / service mesh | must-have | not_evidenced | Absent. | `[grounded]` cv does not name Istio or a service mesh |
| 8 | Prometheus | must-have | not_evidenced | Absent. CloudWatch is the nearest. See C7 below. | `[grounded]` cv: "CloudWatch for monitoring" |
| 9 | Grafana | must-have | not_evidenced | Absent. See C7 below. | `[grounded]` cv does not name Grafana |
| 10 | Observability | must-have | not_evidenced | "CloudWatch for monitoring" is monitoring. The JD's word covers more. See C7 below. | `[grounded]` cv: "CloudWatch for monitoring" |
| 11 | Vault | must-have | not_evidenced | Absent. IAM is access control, not secrets management. | `[grounded]` cv does not name Vault |
| 12 | Helm | must-have | not_evidenced | Absent. Ask about it under C2 if the POC used it. | `[grounded]` cv does not name Helm |
| 13 | CI/CD | must-have | already_evidenced | "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs." | `[grounded]` cv |
| 14 | GitLab CI | must-have | not_evidenced | All your pipeline evidence is Jenkins. | `[grounded]` cv names Jenkins, not GitLab |
| 15 | Python | must-have | already_evidenced | "Bash and Python scripting" | `[grounded]` cv |
| 16 | Go | must-have | not_evidenced | Absent. | `[grounded]` cv does not name Go |
| 17 | SRE practices and platform reliability | must-have | not_evidenced | Maintaining 30 Jenkins jobs is operations work. The resume does not say you owned reliability. | `[grounded]` cv does not claim reliability work |
| 18 | Developer experience | must-have | not_evidenced | The resume doesn't say who uses your pipeline or what they asked for. | `[grounded]` cv does not say who uses the pipeline |

## Gap handling

**Recall prompts.** Each has a question in the closing block.

- **C2 — AWS EKS (must-have).** Your resume shows EC2, S3, RDS and IAM, not EKS. The role names EKS, so Kubernetes without it reads as local-only. Experience that may count: a cluster you created, upgraded or deployed to, including a proof-of-concept that ran on EKS. Useful evidence: a cluster config, a README, or a Terraform or eksctl file. Provenance: `[grounded]` the resume doesn't name EKS; `[generic]` EKS is usually the expected cluster service for this kind of role.
- **C3 — Terraform (must-have).** Ansible is the nearest thing you list, and it's a different tool. Experience that may count: any Terraform you've written or run, at work, in a repo, or on a side project. Useful evidence: a `.tf` file, a module, or a pull request. Provenance: `[grounded]` the resume doesn't name Terraform; `[generic]` Terraform is the usual infrastructure-as-code tool for this role family.
- **C7 — Observability: Prometheus, Grafana (must-have).** CloudWatch is monitoring. Experience that may count: Prometheus scrape configs, Grafana dashboards, or alerting rules you built. Useful evidence: a dashboard screenshot or an alert rule. Provenance: `[grounded]` the resume says "CloudWatch for monitoring"; `[generic]` this stack is what the JD names for observability.

**Named absences.** The gap, and what would close it.

| Requirement | The gap | What would close it | Provenance |
|---|---|---|---|
| ArgoCD / GitOps | No tool or workflow in the resume reconciles clusters from git. | Several months running a cluster where git manifests drive deployments. | `[generic]` closing path for this role family |
| Istio / service mesh | Nothing in the resume. | Hands-on work running a mesh, such as traffic management or mTLS, on a cluster you operated. | `[generic]` |
| Vault | Nothing in the resume. | A project moving application secrets into a secrets manager. | `[generic]` |
| Helm | Nothing in the resume. | Charts you wrote or maintained. | `[generic]` |
| GitLab CI | Your pipelines are Jenkins. | One pipeline built or migrated on GitLab CI. | `[generic]` |
| Go | Nothing in the resume. | A small Go tool in a repo you can point to. Without one, Go is not worth closing for this role. | `[generic]` |
| SRE practices / reliability | Nothing says you owned uptime, on-call or incident reviews. | An on-call rotation with written incident reviews, if you have one. If not, this is a real gap. | `[generic]` |
| Developer experience | Nothing says who uses the pipeline or what they asked for. | Documented requests from teams using your pipeline and what changed as a result. | `[generic]` |

## Not written, and why

- **"Production Kubernetes" or "Kubernetes experience"** — The proof-of-concept never went to production. E1 keeps that qualifier.
- **"AWS EKS"** — Nothing in your resume names it. See C2.
- **"Terraform" or "infrastructure as code"** — Ansible is a different tool. See C3.
- **"GitOps" or "ArgoCD"** — Jenkins push pipelines are not GitOps.
- **"Prometheus", "Grafana" or "observability stack"** — "CloudWatch for monitoring" doesn't establish them. See C7.
- **"Vault" or "secrets management"** — IAM is access control, not secrets management.
- **"Helm", "Istio", "service mesh", "Go"** — Not in your resume.
- **"SRE" or "owned platform reliability"** — Maintaining jobs is not reliability ownership.
- **"CI/CD (GitLab)"** — Your bullet says "deploy pipeline in Jenkins". The JD's label borrows its vocabulary and adds GitLab.
- **Retitling to "Platform Engineer"** — You haven't held that title.
- **Metrics such as "reduced deploy time by X%"** — Nothing in your material gives a number.
- **Keywords in hidden or white text** — Not offered. Screeners can find it, and it would be a line you can't defend in an interview.

## Parse-safety check

Your resume arrived as pasted text, so I could not inspect the PDF. The layout findings below come from your description. Rebuilding the layout is your decision; this check reports risks and does not redesign.

| Check | What it does to the file | Your file | Test you can run |
|---|---|---|---|
| Two-column layout | Parsers read across rows, so the columns interleave | Yes, per your description | Select all in the PDF and paste into a plain-text editor. If lines from the two columns alternate, that's what a parser sees. |
| Icons per skill | Icons may be skipped or come out as junk characters, and any skill name inside an icon is lost | Yes, per your description | Try to highlight a skill name. If it won't highlight, it's an image. |
| Contact details in header | Header content can be treated as page furniture and dropped | Yes, per your description | In the paste test, check whether your name, email and phone appear. If they're missing, a parser may lose them. |
| Section headings | Non-standard labels may not be recognized | Not visible in the text you pasted | Check that the headings are plain words: Experience, Skills, Education. |
| File type | Varies by parser. A text-layer PDF or a .docx is the safe pair. | PDF from Canva. Whether it has a text layer is unconfirmed. | The paste test. If you cannot select the text, the PDF is an image. |
| Hidden text | Not checked | Not checkable from pasted text | None. This is not a finding either way. |

## Upgrade menu

These go beyond the spec and are built only if you ask:

- **Attach the proof-of-concept's repo, notes or a README.** This would move the Kubernetes line from a self-report to an inspectable artifact.
- **Attach any Terraform, Helm or Prometheus file from a repo you own.** This would give C3 and C7 evidence to point to.
- **Attach a CloudWatch dashboard screenshot.** It shows monitoring, not the observability stack the JD names, so it moves C7 only partly.

## Questions

Answer each in text, paste a voice transcript, attach a document, drop a link, or say skip.

- **C2 — Did the Kubernetes proof-of-concept run on AWS EKS?**
- **C3 — Have you written or run Terraform, even on a side project or in a repo?**
- **C7 — Have you built Prometheus or Grafana dashboards or alerts, or was monitoring all CloudWatch?**

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.