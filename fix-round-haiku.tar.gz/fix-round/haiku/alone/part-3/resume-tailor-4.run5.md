**Keyword matching is probably not the main cause, and optimizing for it would not fix much.** In one vendor's interviews with 25 recruiters, two had content-based auto-rejection set up (cite C25). The more common automated rejection is knockout questions on the application form (cite C26). Match scores mostly set the order of review, and a low score pushes a resume down the pile rather than rejecting it (cite C27). Two things are more likely to be costing you. The first is parse risk: your skills may be invisible to a parser, and your contact details may be lost. The second is fit: most of the posting's stack (Terraform, Argo CD, Istio, Prometheus, Grafana, Vault, EKS, Helm, GitLab, Go) is not in your material, and Kubernetes appears only as a proof-of-concept. No honest edit makes this resume match that stack. Whether the role is worth applying for is job-underwriter's call.

No `tuesday-dossier.md` was in context, so this is built from the resume text you pasted. The posting does not rank its requirements, so I have treated the sentence about owning reliability and developer experience as must-have, the named tools as important, and Go as preferred.

## The edit ledger

Nothing is applied. Every row is pending your approval.

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| L1 | Skills (new line) | *(not in skills; appears only in experience)* | Kubernetes (two-month proof-of-concept, never in production) | `surface` | "Ran a Kubernetes proof-of-concept for two months last year — never went to production." | `[grounded]` resume, Experience | pending your approval |
| L2 | Experience | "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs." | *(unchanged, moved to the top of Experience)* | `reorder` | "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs." | `[grounded]` resume, Experience | pending your approval |
| L3 | Summary (new, optional) | *(no current line)* | DevOps Engineer, 4 years. Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs. Ran a Kubernetes proof-of-concept for two months last year — never went to production. | `merge` | "DevOps Engineer, 4 years."; "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs."; "Ran a Kubernetes proof-of-concept for two months last year — never went to production." | `[grounded]` resume | pending your approval |

Rejecting L3 does not affect L1 or L2. L3 only repeats what L1 and L2 already say, so it is there to put your honest picture first, not to add anything.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| 1 | Own platform reliability | must-have | not_evidenced | Maintaining about 30 Jenkins jobs is adjacent upkeep, not platform ownership. See N1. | `[grounded]` resume |
| 2 | Kubernetes | important | surfaced_by_edit | Currently only in an experience sentence. L1 moves it into Skills with its qualifier. | `[grounded]` resume, Experience |
| 3 | AWS EKS | important | not_evidenced | AWS is evidenced (EC2, S3, RDS, IAM). EKS is not named, and the proof-of-concept's platform is not stated. See C1. | `[grounded]` resume, Skills |
| 4 | Terraform | important | not_evidenced | No provisioning tool is named. Ansible is listed for configuration management, which is a different job. See C2. | `[grounded]` resume, Skills |
| 5 | ArgoCD and GitOps | important | not_evidenced | Your deployment work is described as a Jenkins pipeline, with no Git-driven deployment stated. See N2. | `[grounded]` resume |
| 6 | Istio and service mesh | important | not_evidenced | Nothing in the material. See N3. | `[grounded]` resume |
| 7 | Prometheus, Grafana and observability | important | not_evidenced | CloudWatch monitoring is adjacent, not an observability stack. See C3. | `[grounded]` resume, Skills |
| 8 | SRE practices | important | not_evidenced | No on-call, incident or reliability-practice work is stated. See C3. | `[grounded]` resume |
| 9 | Vault | important | not_evidenced | IAM is access control, not secrets management. See N4. | `[grounded]` resume, Skills |
| 10 | Helm | important | not_evidenced | Not named. It may count only if the proof-of-concept used it. See C1. | `[grounded]` resume |
| 11 | CI/CD pipelines | important | already_evidenced | "Built our deploy pipeline in Jenkins" is readable as CI/CD on one read. L2 moves it up; the status does not depend on the move. | `[grounded]` resume, Experience |
| 12 | GitLab CI | important | not_evidenced | Jenkins only. See N5. | `[grounded]` resume |
| 13 | Python | important | already_evidenced | "Bash and Python scripting" is on the resume as written. | `[grounded]` resume, Skills |
| 14 | Go | preferred | not_evidenced | Nothing in the material. See N6. | `[grounded]` resume |
| 15 | Developer experience | must-have | not_evidenced | The pipeline you built served your team. No developer-facing platform work is stated. See N1. | `[grounded]` resume, Experience |

## Gap handling

**Recall prompts.** These rows carry no questions. The questions are asked once, in the closing block.

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | AWS EKS, Helm, and how the Kubernetes work was deployed | important | A two-month Kubernetes proof-of-concept, never in production; no platform named | The posting names EKS and Helm, and the proof-of-concept is your only Kubernetes evidence | The proof-of-concept itself: which cluster it ran on, what was deployed and how; any Helm charts or manifests you wrote | Its repo, manifests, notes or a diagram | `[grounded]` what the resume says; `[generic]` how a posting's named tools are read against a proof-of-concept |
| C2 | Infrastructure as code (Terraform) | important | No provisioning tool named; Ansible for configuration management | Terraform is named in the posting and appears nowhere in your resume | Any AWS resources you created from code, including for the proof-of-concept or a side project: CloudFormation, Terraform, or Ansible modules that created resources | A repo or module | `[grounded]` what the resume says |
| C3 | Prometheus, Grafana, observability and SRE practice | important | CloudWatch for monitoring; about 30 Jenkins jobs maintained | The posting asks for observability and reliability practice, and neither is stated | Alerts or dashboards you built or were paged on, an on-call rotation, an incident you led the response to | A dashboard screenshot, alert rules, or an incident write-up | `[grounded]` what the resume says |

**Named absences.** Each one says what is missing and what closing it would take.

- **N1, platform reliability and developer experience ownership.** The resume does not show you owning a platform's reliability or serving developers as their platform. Closing it takes a platform-facing role or a sustained project you can point to. It is not a resume edit, and it is the row that most decides whether this role fits.
- **N2, ArgoCD and GitOps.** Closing path: a Git-driven deployment on a personal cluster, where Argo CD syncs manifests from a Git repository you can link. It would extend the proof-of-concept into a working deployment.
- **N3, Istio and service mesh.** Closing path: install a mesh on the same kind of personal cluster and route traffic through it, with the configuration linked.
- **N4, Vault.** Closing path: run Vault and use it for one application's secrets, with the configuration linked.
- **N5, GitLab CI.** Closing path: a GitLab pipeline on a personal project with a linked `.gitlab-ci.yml`. Otherwise, the resume should say plainly that your pipelines run on Jenkins.
- **N6, Go.** Preferred rather than required. Closing path: a small Go tool in a public repo. If Go is not in your plans, leave it off rather than list it.

## Not written, and why

- **"Platform Engineer" as your title.** You have not held that title, and the posting uses it.
- **Terraform, Argo CD, GitOps, Istio, Prometheus, Grafana, Vault, Helm, EKS, GitLab or Go in Skills, even with "familiar with."** A listed tool reads as a tool you own, and an interviewer will ask about it.
- **"Ran Kubernetes in production" or "managed Kubernetes clusters."** The proof-of-concept never went to production.
- **"Owned platform reliability," "SRE practices," or "observability stack."** The posting's ownership language is not your history. CloudWatch monitoring is what you did.
- **"Led the deploy pipeline."** You built it. "Built" stays.
- **Any keyword list beyond what you have done, or any hidden text.** Hidden text is deception of the employer, and it is easy to detect (cite C19). I won't write either.

## Parse-safety check

These checks ran on your description of the PDF, not on the file. Where I could not see the file, I say so.

| Check | What breaks | What it costs | Observed here |
|---|---|---|---|
| Multi-column layout | Parsers read linearly, so columns interleave | Dates detach from the roles they belong to; text becomes word salad | Described as two-column: **high risk** |
| Icons for each skill | Icons are images or are skipped | The skill names may be absent entirely | Described as icons: **high risk** |
| Contact details in the header | Headers are treated as page furniture and dropped | You can become unreachable | Described as in the header: **high risk, check first** |
| Non-standard headings | Section detection misses stylized labels | Experience may not be recognized as Experience | Unknown; check the headings |
| File type | Varies by parser; a text-layer PDF or a `.docx` is the safe pair | Parser output may be unreliable | Unknown; Canva PDFs are often text-layer, but confirm |

**The two-minute test.** Open the PDF, select all, and paste into a plain-text editor. Read the result as a parser would: are your skills there, are your name, email and phone there, and does each date sit next to the right role? If any of those fail, that is the parser's view of your resume.

## Upgrade menu

- **The resume as its original file.** This lets the parse check run on the file itself rather than on your description.
- **The paste-test output.** This lets the parse check run on what a parser actually extracts.
- **The Kubernetes proof-of-concept's repo, manifests or notes.** This makes L1 inspectable, so it can name what was actually run.
- **A sanitized Jenkinsfile or pipeline config.** This is inspectable proof for the CI/CD row and for the Jenkins claims in L2 and L3.

The questions below are C1 to C3, asked once each.

**C1: Your Kubernetes proof-of-concept.** Did it run on AWS EKS or another cluster, and did you use Helm or deploy anything to it with a GitOps tool such as Argo CD?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**C2: Infrastructure as code.** Did you ever create AWS resources from code, such as Terraform, CloudFormation or Ansible modules, including for the proof-of-concept or a side project?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**C3: Monitoring and reliability.** Beyond CloudWatch, did you build or own dashboards, alerts, or an on-call rotation, or lead the response to an incident?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.