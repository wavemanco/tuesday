I worked from the dossier excerpt and the CV text in your message. The file lookup was denied, so I didn't open `tuesday-dossier.md` itself. Nothing below is applied. Every row is pending your approval, and I'll produce the tailored resume only from the rows you approve.

## Edit ledger

Your CV text is the only source for the "current line" column, so it quotes your sentences rather than the layout of your document.

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Summary (new) | *(no current line)* | "7 years solutions engineer / implementation lead at an enterprise software vendor. Led 30+ client integrations of our REST APIs end to end." | `merge` | "7 years solutions engineer / implementation lead at an enterprise software vendor."; "Led 30+ client integrations of our REST APIs end to end." | `[grounded]` CV | pending your approval |
| E2 | Experience | "Wrote the internal integration playbook the whole team uses." | "Wrote the internal integration playbook the whole team uses." as its own line. This is the dossier's pending edit, audited here. | `surface` | "Wrote the internal integration playbook the whole team uses." | `[grounded]` CV; dossier `resume_edits_pending_approval` E1 | pending your approval |
| E3 | Experience | "Ran quarterly roadmap-input sessions collecting client feedback for product." | Same line, moved to sit directly below the integrations line | `reorder` | "Ran quarterly roadmap-input sessions collecting client feedback for product." | `[grounded]` CV | pending your approval |
| E4 | Skills | "Comfortable in Postman, SQL, OpenAPI specs." | "Comfortable in Postman, SQL, OpenAPI specs." as its own Technical line | `surface` | "Comfortable in Postman, SQL, OpenAPI specs." | `[grounded]` CV | pending your approval |

The audit passed on each row. Every verb is yours ("Led", "Wrote", "Ran", "Comfortable in"), and "client" stays "client" rather than becoming the posting's "partner." The roadmap-input line keeps "for product," and E3 does not describe those sessions as discovery or roadmap ownership.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 3+ years PM | must-have | not_evidenced | Adjacent only: integration leadership and feedback sessions. No PM title and no prioritisation authority shown (dossier R1, transferability, medium). | `[grounded]` CV; dossier evidence_map |
| R2 | Shipped API or platform products | important | not_evidenced | Adjacent only: integration delivery on your vendor's REST APIs. No product you shipped (dossier R2, medium). | `[grounded]` CV; dossier evidence_map |
| R3 | Technical fluency | important | surfaced_by_edit | E4 | `[grounded]` CV |
| R4 | Stakeholder management | important | surfaced_by_edit | E1. Client-side only. No case of managing internal or competing stakeholders is stated. | `[grounded]` CV |
| R5 | Run discovery with integration partners | important | surfaced_by_edit | E3. The sessions collected client feedback; they are not described as discovery. | `[grounded]` CV |
| R6 | Write specs and drive delivery with two engineering squads | important | not_evidenced | Client-facing delivery is shown. Working with engineering squads is not. | `[grounded]` CV |
| R7 | Define adoption metrics | important | not_evidenced | Nothing in the CV. | `[grounded]` CV |

I assumed the posting marks only the PM requirement as must-have, so the other priorities are my reading.

## Recall prompts

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | 3+ years PM, specifically prioritisation | must-have | Integration leadership and feedback sessions for product. No title, no stated authority over what gets built. | The posting makes PM years a must-have. `[generic]` Screeners and hiring managers usually check this first. | A decision on which client-requested API changes went into a release; a backlog you ordered; sign-off on API version scope | A prioritisation record, a release note you approved, a roadmap doc | `[grounded]` CV; `[generic]` screening cost |
| C2 | Shipped API or platform product | important | Integration delivery on your vendor's REST APIs | The posting asks for products shipped, not integrations delivered | A sandbox, SDK, versioning or deprecation policy you specified and launched | The spec, the launch note, the release notes | `[grounded]` CV |
| C3 | Adoption metrics | important | Nothing | The role owns adoption measurement | Time to first successful call; endpoint usage after integration; playbook adoption | Any dashboard or export you used with clients | `[grounded]` CV |

**Named absence, not a recall prompt:** R6 (engineering-squad delivery) has no evidence in the CV. Closing it would take a feature you specified and got built through an engineering team. Six months of that work would make it defensible.

## Prohibited claims

Not written, and why:

- **"Product manager" or "PM" title, or "3 years of product management"**: you have never held the title, and the posting makes the years a must-have. Adjacent work is in E1 and E3, and the gap is named in R1 rather than papered over.
- **"Owned the API roadmap" or "prioritised client requests"**: the roadmap-input sessions collected feedback for product. The dossier marks prioritisation authority as not evidenced.
- **"Shipped API products"**: you integrated the REST APIs; you did not ship a product. The dossier marks this adjacent.
- **"Ran discovery with integration partners"**: "discovery" is the posting's word, and the sessions were quarterly feedback collection.
- **"Partner integrations" in place of "client integrations"**: the posting's word. It would also move you from the vendor side of the table to the partner side.
- **"Built the internal request-triage tool"**: a rejected inference. You could not confirm ownership, so it stays off.
- **"Customer of a partner API platform"**: a rejected inference. You worked vendor-side.
- **"Defined adoption metrics," "drove delivery with two engineering squads"**: not in your CV.

## Parse-safety check

I only have your CV as pasted text, not as a file, so I can't check the actual document. On what I can see: there is no hidden text and no keyword block, and the section headers are standard. Two things to check when you lay out the file: keep the summary as plain text rather than inside a table or text box, and make sure "Never held a PM title" stays out of the resume. It is a note for you, not a line for the document.

## Upgrade options

- **Portfolio artifacts:** a copy of the integration playbook (with client names removed) or a sample roadmap-input summary would give E2 and E3 something a reader can inspect.
- **The request-triage tool:** if you can now confirm you built it, tell me in your own words. It would come back as a recall prompt, not a new row carried over from the dossier.

C1 — Did you ever have a say over what the API platform built next, even partly? For example, deciding which client-requested changes went into a release, or ordering a backlog. Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

C2 — Was there a release of the API's tooling (a sandbox, SDK, or versioning or deprecation policy) that you specified and saw through to launch? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

C3 — Did you record anything about how integrations went after clients started, such as time to first successful call or which endpoints they used? If so, what, and over what period? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.