I won't add the hidden white text or the 1pt keyword block. Hidden instructions aimed at a screener are a deception of the employer's process, and they can get the resume rejected if it's discovered. I'll tailor the resume using only what your experience supports, and the skill will show every change before anything is applied.
## Edit ledger (nothing applied; all rows pending your approval)

The resume's opening already states "Marketing Manager, 6 years B2B SaaS," so I haven't changed it. Every row below quotes your own sentence.

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience (paid) | "Ran paid search and paid social, budget I controlled was about $600k a year." | "Ran paid search and paid social." / "Controlled a budget of about $600k a year." | `split` | "Ran paid search and paid social, budget I controlled was about $600k a year." | `[grounded]` resume | pending your approval |
| E2 | Experience (HubSpot / lifecycle) | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | "Used HubSpot daily for 4 years." / "Built our lifecycle email programme from scratch: 12 automated flows." | `split` | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | `[grounded]` resume | pending your approval |
| E3 | Experience (SQL note) | "I pull my own numbers in HubSpot reporting but I'm not strong in SQL — I ask our analyst." | *(cut from resume)* | `cut` | "I pull my own numbers in HubSpot reporting but I'm not strong in SQL — I ask our analyst." | `[grounded]` resume | pending your approval |

E1 keeps "controlled" rather than "managed," since that is the word you used. E3 is a note to yourself, not resume content. If you want a candid SQL answer ready, it belongs in interviews, not on the CV.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 5+ years B2B demand gen | must-have | `already_evidenced` | "6 years B2B SaaS" plus paid, lifecycle and webinar work. The label "demand gen" is not claimed. | `[grounded]` |
| R2 | HubSpot or Marketo | must-have | `already_evidenced` | HubSpot daily for 4 years (E2) | `[grounded]` |
| R3 | SQL-literate | must-have | `not_evidenced` | Named absence below | `[grounded]` |
| R4 | Managed a budget over $500k | must-have | `surfaced_by_edit` | Budget moved to its own line (E1) | `[grounded]` |
| R5 | Paid search | important | `already_evidenced` | Existing bullet | `[grounded]` |
| R6 | Lifecycle email | important | `surfaced_by_edit` | 12 flows get their own line (E2) | `[grounded]` |
| R7 | Webinars | important | `already_evidenced` | "Ran a monthly webinar series, average 300 registrants." | `[grounded]` |
| R8 | Content distribution | important | `not_evidenced` | Recall prompt C1 below | `[grounded]` |

## Gap handling

**C1: Content distribution (`not_evidenced`, recall prompt).** The resume says nothing about distributing content. The JD names it as part of the role. Experience that may count: promoting blog posts, gated assets, newsletters or social content, or promoting the webinars beyond registrants. Useful evidence: a distribution calendar or a campaign report.

**SQL-literate (`not_evidenced`, named absence).** Your resume and your own note both say you are not strong in SQL, and the JD lists it as a must-have. I have not written any SQL claim. Closing it would take focused SQL practice and one or two analyses you run yourself, with your analyst reviewing them. That is months of work, not weeks. If it is a hard requirement for you, this role is a stretch.

## Prohibited claims (not written, and why)

- **"Senior" in the title.** Your title is Marketing Manager.
- **Any SQL skill.** You said you are not strong in it and ask your analyst.
- **Content distribution.** Nothing in your material supports it yet (see C1).
- **"Owned demand generation."** That is the JD's phrasing. Your sentences say you ran paid channels, lifecycle and webinars, not that you owned the function.
- **Hidden text or a keyword block.** Refused, as explained above.

## Parse-safety

I can only see your pasted text, not the PDF. The proposed lines are plain single-column text with no tables or text boxes. Check the PDF itself for those, and for a plain-text header and contact block.

## Questions

- **C1:** Did you ever do content distribution, such as promoting posts, gated assets, newsletters or social content? If so, what, and roughly how big?
- **Budget:** Was the ~$600k the paid media budget only, or your whole marketing budget? That changes E1's wording.

Optional, built only if you ask: a SQL learning plan you could show in interviews.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.