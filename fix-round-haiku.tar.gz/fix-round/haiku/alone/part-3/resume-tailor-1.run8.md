Nothing is applied yet. You gave me the facts in your message but not the CV file, so I can't quote your current lines. Every row below quotes your sentences from the message, and the "Current line" column says "(not supplied)" until you send the CV text.

## Coverage map

No requirement is `already_evidenced` as written, because I haven't seen your CV layout.

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| K1 | 5+ years backend | must-have | surfaced_by_edit | L1 puts "7 years" up front. "Backend" appears nowhere in your material; a reader infers it from "services" and "ledger pipeline". No row claims it. | [grounded] background prose |
| K2 | Production Go | must-have | surfaced_by_edit | L2 surfaces "Go and Rust daily for 4 years". Your sentence says "daily", not "production", so the row doesn't say production. | [grounded] background prose |
| K3 | Distributed systems at scale | must-have | surfaced_by_edit | L1 (40k requests/minute at peak), L2 (Kafka, gRPC), L3 (cache layer). No distributed-systems design is stated. 40k/minute is about 670 requests/second, [inferred] arithmetic; whether that counts as scale for Tessellate is your call. | [grounded] background prose; [inferred] the per-second figure |
| K4 | Strong incident response | must-have | surfaced_by_edit | L4 separates the on-call rotation from the six incidents you ran as incident commander. | [grounded] background prose |
| K5 | Experience mentoring | must-have | surfaced_by_edit | L5. This is onboarding and a month of pairing for new hires. It is not mentoring, and the row doesn't say more. | [grounded] background prose |
| K6 | Drive down p99 latency | must-have | surfaced_by_edit | L3 moves the 380ms to 95ms result to the top of the role. | [grounded] background prose |
| K7 | Design and ship Go services handling high request volume | important | not_evidenced | You own three services and one handles about 40k requests/minute. Your material doesn't say what language they are in, or that you designed or shipped them. Recall prompt C2. | [grounded] background prose |
| K8 | Own on-call for your services | important | surfaced_by_edit | L4. Your sentence describes rotation membership, not ownership of on-call for these services. | [grounded] background prose |
| K9 | Mentor mid-level engineers | important | not_evidenced | Nothing in your material says this. Recall prompt C1. | [grounded] background prose |
| K10 | Partner with product on roadmap sequencing | important | not_evidenced | Named absence below. | [grounded] absence in background prose |
| K11 | Build-cache platform experience | preferred | not_evidenced | You reworked a cache layer on the balance-read path (L3). No build-cache system appears in your material. | [grounded] background prose |

## Edit ledger

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| L1 | Summary (new) | (not supplied) | Senior Software Engineer, 7 years. Currently at a payments company, owning three services in our ledger pipeline, one handling about 40k requests/minute at peak. | merge | "Senior Software Engineer, 7 years."; "Currently at a payments company."; "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak." | [grounded] background prose | pending your approval |
| L2 | Skills | (not supplied) | Languages: Go and Rust daily for 4 years, Python before that. Tools: Kafka, Postgres, Terraform, gRPC, Datadog. | surface | "Go and Rust daily for 4 years, Python before that."; "CV also lists: Kafka, Postgres, Terraform, gRPC, Datadog." | [grounded] background prose | pending your approval |
| L3 | Experience, current role, first bullet | (not supplied) | Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer. | reorder | "Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer." | [grounded] background prose | pending your approval |
| L4 | Experience, current role | (not supplied) | On-call rotation every fourth week for two years. I've run six incidents as incident commander. | split | "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | [grounded] background prose | pending your approval |
| L5 | Experience, current role | "I do onboarding for new hires on my team — usually two or three a year, I pair with them for their first month." (your sentence, as supplied) | Onboard new hires on my team, usually two or three a year, and pair with them for their first month. | compress | "I do onboarding for new hires on my team — usually two or three a year, I pair with them for their first month." | [grounded] background prose | pending your approval |

L3 is a reorder only. It adds no "primary" or "led", and "reworking" stays as your word.

## Gap handling

**C1 — Mentor mid-level engineers (K9, important).** What your resume shows: onboarding and first-month pairing for new hires (L5). What it doesn't show: mentoring engineers beyond onboarding. Why it matters: "mentor" is a named requirement, and a reader scanning for it will find only onboarding. [generic] A reader checks for this word specifically. Experience that may count: a mid-level engineer you guided through a project, a code review arrangement, a promotion case, a regular career conversation. Useful evidence: a review, a note, a shared doc.

**C2 — Design and ship high-volume Go services (K7, important).** What your resume shows: you own three services, one at about 40k requests/minute at peak. What it doesn't show: the language of those services, or that you designed or shipped them. Experience that may count: designing a service's architecture or API, leading its launch, the history of the 40k service. Useful evidence: a design doc, a decision record, a launch note, a repo.

**Named absences**
- **Roadmap sequencing with product (K10).** Nothing in your material covers this. Closing it would take a real example: a roadmap decision you shaped with product, what you proposed, and what changed. If none exists, leave it out and say so if asked.
- **Build-cache platform (K11).** Resume edits can't close this. Closing it would take a project inside a cache or build system. Your adjacent cache work is named in L3 and is not presented as the same thing.

## Not written, and why

- **"Designed and shipped high-volume Go services"**: the language and the design are not in your material (K7).
- **"Mentored mid-level engineers"**: onboarding and first-month pairing is a different job (K5, K9).
- **"Production Go"**: your sentence says "daily" (K2).
- **"Backend engineer" or "5+ years backend"**: your material says 7 years of software engineering, not backend.
- **"Led" incidents or "owned on-call"**: your words are "run" and "rotation".
- **"Designed the cache layer"**: your word is "reworking". Design is a different claim.
- **"At scale" as a label**: the 40k figure speaks for itself, and the adjective is the reader's call.
- **"Partnered with product on roadmap sequencing"**: not in your material (K10).
- **Build-cache experience**: not in your material (K11).
- **A percentage improvement**: 380ms to 95ms is a 75% cut by arithmetic. It is a new figure, so it is not in any row. It is offered below.

**Parse-safety check:** Not run on a file, because you didn't send one. On the text you gave me, the sentences are plain, with one em dash, and there are no tables, symbols or columns that would break text extraction. Layout, headers, and file type could not be checked.

## Upgrade menu (offers, not applied)

- **x1: Add the percentage.** A row reading "Cut p99 latency by 75% (380ms to 95ms) on the balance-read path" would be built only on your approval, with the calculation shown.
- **x2: Rebuild with your real lines.** Once you send the CV text, I can fill the "Current line" column and check each existing bullet against the same audit.

## Questions

C1 — Have you mentored any mid-level engineers, beyond onboarding new hires? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

C2 — Which language are the three services you own written in, and did you design or ship them? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

Please paste your current CV text so the ledger can quote your existing lines instead of leaving them blank.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.