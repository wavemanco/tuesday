I won't add the hidden white text or the 1pt keyword block. Screeners that rely on hidden text are being deceived, and if it's found the application is likely rejected outright. I'll tailor the visible resume from your own material. Loading the tailoring skill first.
I won't add the white text or the 1pt keyword block. Hidden text aimed at a screener is deception of the employer, and it is detectable. Parsers and some recruiters do find it, and a candidate who was caught with it was reportedly rejected for it. The rest of the tailoring stays within what your resume and your own notes support. Nothing below is applied until you approve it.

**Screening premise:** Content-based auto-rejection exists but is less common than people assume. What most often rejects people without a human reading is the application form's yes/no knockout questions (work authorization, location, required credentials). Those are answered on the form, not the resume, so check them before investing in tailoring. Whether to apply at all is job-underwriter's call.

## Edit ledger (all `pending your approval`)

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance |
|---|---|---|---|---|---|---|
| E1 | Experience | "Ran paid search and paid social, budget I controlled was about $600k a year." | "Ran paid search and paid social. The budget I controlled was about $600k a year." | `split` | "Ran paid search and paid social, budget I controlled was about $600k a year." | `[grounded]` resume, Experience |
| E2 | Experience | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | "Used HubSpot daily for 4 years. Built our lifecycle email programme from scratch: 12 automated flows." | `split` | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | `[grounded]` resume, Experience |
| E3 | Summary (new, optional) | *(no current line)* | "Marketing Manager, 6 years B2B SaaS. Ran paid search and paid social, budget I controlled was about $600k a year. Built our lifecycle email programme from scratch, 12 automated flows. Ran a monthly webinar series, average 300 registrants." | `merge` | "Marketing Manager, 6 years B2B SaaS."; "Ran paid search and paid social, budget I controlled was about $600k a year."; "built our lifecycle email programme from scratch, 12 automated flows."; "Ran a monthly webinar series, average 300 registrants." | `[grounded]` resume |

E1 and E2 move your figures and channels out of mid-sentence clauses so a reader meets them first. E3 uses only your existing sentences, each still quoted in full. Approve it or drop it.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 5+ years B2B demand gen | must-have | surfaced_by_edit | E3. Your resume says "6 years B2B SaaS" but never uses the words "demand gen," and this ledger doesn't add them. See question 2. | `[grounded]` "Marketing Manager, 6 years B2B SaaS." |
| R2 | Paid search | important | already_evidenced | Experience, first bullet | `[grounded]` resume |
| R3 | Lifecycle email | important | surfaced_by_edit | E2, E3 | `[grounded]` resume |
| R4 | Webinars | important | already_evidenced | Experience, webinar bullet | `[grounded]` resume |
| R5 | Content distribution | important | not_evidenced | Recall prompt C1 | `[grounded]` resume has no distribution line |
| R6 | HubSpot or Marketo | must-have | already_evidenced | "HubSpot daily for 4 years." The JD says "or," so HubSpot satisfies it. | `[grounded]` resume |
| R7 | SQL-literate | must-have | not_evidenced | Named absence N1 | `[grounded]` you said you're not strong in SQL |
| R8 | Managed budget over $500k | must-have | surfaced_by_edit | E1. "About $600k" clears $500k. | `[grounded]` resume |

**Recall prompt C1 (content distribution):** The resume shows event work (webinars), not distribution. The JD names distribution as part of owning demand gen. Experience that may count: organic social, blog or newsletter promotion, or amplifying gated assets through partners. Useful evidence: a content calendar or a channel report. `[generic]` distribution is a named responsibility in this JD, so a gap here will be asked about.

**Named absence N1 (SQL):** Your resume does not support SQL, and you've said you're not strong at it. The closest true thing is that you pull your own numbers in HubSpot reporting. That supports "reporting in HubSpot." It does not support SQL. Closing it would take real practice: pull your own HubSpot exports into a query tool and answer a few questions you care about, over several weeks. A course certificate alone would not change what the resume can say. Because SQL is a must-have here, leaving it open is a real cost for this role. `[generic]`

## Prohibited claims (not written, and why)

- **SQL, SQL-literate, data analysis, analytics.** You said you aren't strong in SQL and ask your analyst. "Reporting in HubSpot" is the most you can say.
- **Marketo.** Not in your material. HubSpot covers the JD's "or."
- **"Senior" in the title.** The resume says Marketing Manager. The JD's title is an upgrade you haven't had.
- **"Owned demand generation."** The resume says "Ran," and "budget I controlled." Ownership of the whole function is not written.
- **"Managed a budget."** That is the JD's verb. Your sentence says "controlled," so the ledger keeps yours.
- **Content distribution.** Not in your material. See C1.
- **Hidden text or invisible keyword blocks.** Refused, as above.

## Parse-safety check

You pasted the resume as text, so I couldn't check layout, headers, tables, or text boxes. The text itself has no parse risks. If your current PDF came from a template or an earlier tool, check it for hidden text you didn't write. Send the file (a .docx or a text-layer PDF is safest) and I'll run the full check.

**Offer (proposal, built only on approval):** a short cover letter drafted only from approved rows.

**Questions:**
1. Did you run content distribution (organic social, blog or newsletter promotion, partner amplification)? If so, what did you own, and do you have numbers?
2. How would you describe your main job over the last six years: demand generation, marketing management, or something else?
3. For SQL, do you want to work on it before applying, or go in with the gap stated?

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.