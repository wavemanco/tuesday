Nothing is applied yet. Every row below is a proposal for you to approve or reject. The tailored document comes only after you approve rows.

**Bottom line:** No wording makes this resume read as a data engineer. The must-have, 3+ years of data engineering, is not in your history. What the resume can honestly do is show a senior analyst who already does dbt modelling, mart design and nightly-job maintenance. That is the strongest true case for the move.

**Inputs and assumptions**
- No resume file came with your message, so I treated the bullets in your message as the current resume lines. If your actual wording differs, send it and I'll re-check every trace against it.
- No `tuesday-dossier.md` was present, so the ledger is built from the resume and JD alone.
- The JD's "3+ years" is an experience-length requirement, not a legal gate, so it is graded on fit like the others.

Research tier: L0, no searches.

## The edit ledger

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| 1 | Summary | *(no current line)* | "Senior Data Analyst, 5 years, retail. Built and maintained about 25 dbt models including the core orders mart." | `merge` | "Senior Data Analyst, 5 years, retail."; "Built and maintained about 25 dbt models including the core orders mart." | `[grounded]` resume | pending your approval |
| 2 | Experience | "Built and maintained about 25 dbt models including the core orders mart." | *(unchanged, moved to first bullet)* | `reorder` | "Built and maintained about 25 dbt models including the core orders mart." | `[grounded]` resume | pending your approval |
| 3 | Experience | "I designed the star schema for the orders mart with our then-DE." | "Designed the star schema for the orders mart with our then-DE." | `reorder` | "I designed the star schema for the orders mart with our then-DE." | `[grounded]` resume | pending your approval |
| 4 | Experience | "I've fixed our nightly dbt job when it breaks and added tests to it." | "Fixed our nightly dbt job when it broke, and added tests to it." | `reframe` | "I've fixed our nightly dbt job when it breaks and added tests to it." | `[grounded]` resume | pending your approval |
| 5 | Experience | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | "Wrote Python for analysis (pandas), and scripts that pull vendor APIs on a cron." | `split` | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | `[grounded]` resume | pending your approval |
| 6 | Experience | "SQL every day on Redshift, complex window functions and CTEs." | "Wrote SQL every day on Redshift, including complex window functions and CTEs." | `reframe` | "SQL every day on Redshift, complex window functions and CTEs." | `[grounded]` resume | pending your approval |

Row 1 keeps the number and drops nothing that qualifies it. Row 3 keeps "with our then-DE", because removing it would make you the sole designer. No row changes the title, and none names Airflow, Spark, Kafka, or any pipeline ownership.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| 1 | 3+ years data engineering | must-have | not_evidenced | 5 years as an analyst. Your dbt and mart work is the closest. No data-engineering role or years stated. See named absences. | `[grounded]` resume |
| 2 | Production Python | important | not_evidenced | Cron-scheduled vendor-API scripts and analysis Python. "Production" is not stated. See C1. | `[grounded]` resume |
| 3 | Airflow or equivalent orchestration | important | not_evidenced | Nightly dbt job and cron scripts are scheduled, but no orchestrator is named. See named absences. | `[grounded]` resume |
| 4 | Dimensional modelling | important | surfaced_by_edit | Star schema for the orders mart, designed with your then-DE. One mart, not the whole warehouse. Rows 3. | `[grounded]` resume |
| 5 | Build and own batch pipelines | important | surfaced_by_edit | Transformation side only: 25 dbt models, built and maintained. No ingestion or end-to-end ownership stated. Rows 2 and 4. | `[grounded]` resume |
| 6 | Own data quality | important | surfaced_by_edit | Tests added to the nightly dbt job. Ownership beyond that is not stated. Row 4. | `[grounded]` resume |
| 7 | Own SLAs | important | not_evidenced | No freshness target, delivery commitment or alerting stated. See C2. | `[grounded]` resume |
| 8 | Streaming (Kafka, Spark) | preferred | not_evidenced | Never used. See named absences. | `[grounded]` resume |
| 9 | Partner with analytics on requirements | preferred | not_evidenced | Not stated in the resume. See C3. | `[grounded]` resume |

## Recall prompts

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Production Python | important | Cron-scheduled vendor-API scripts, described as "some scripting". | `[grounded]` The resume does not say whether they run unattended. `[generic]` Reviewers of this kind usually ask about unattended runs and failure handling. | Vendor-API pulls; any script that ran on a schedule without you watching it. | Run logs, a repo, or a README for one script. | `[grounded]` the resume; `[generic]` the reviewer pattern |
| C2 | Own SLAs | important | Fixing the nightly dbt job and adding tests. No delivery target or alert stated. | `[grounded]` The resume does not establish an SLA. `[generic]` SLA ownership is a named responsibility in this JD. | Nightly dbt job; orders mart refresh. | Alert config, a freshness check, or an incident note. | `[grounded]` the resume; `[generic]` the JD's responsibility |
| C3 | Partner with analytics on requirements | preferred | Analyst role with mart design, but no stated requirements-gathering. | `[grounded]` The resume does not say who asked for the orders mart or how its design was agreed. | Orders mart design; requests from analysts or business teams. | A spec, ticket, or thread for the mart. | `[grounded]` the resume |

## Named absences

| Requirement | The gap | Closing path | Provenance |
|---|---|---|---|
| 3+ years data engineering (must-have) | You have five years as an analyst. Data-engineering years are not in your history. | Wording cannot close it. The honest route is roles where analytics-engineering work counts, or building ownership of a pipeline in your current job. | `[grounded]` the resume |
| Airflow or equivalent | You have never used Airflow. | Convert your nightly dbt run or one cron script into a small DAG and keep it in a repo. Only claim it once it runs. | `[grounded]` your statement; `[generic]` the closing path |
| Streaming (Kafka, Spark) | Never used. Listed as a plus, not a requirement. | Building and running a small Kafka or Spark job would close it. Worth doing only if this role is worth the time. | `[grounded]` your statement; `[generic]` the closing path |

Whether to apply at all, given the must-have, is job-underwriter's call.

## Prohibited claims

```text
Not written, and why:

- "Data Engineer" as a title or a role. You have never held it, and the JD's must-have is years of data engineering.
- "Built batch pipelines" or "owned pipelines end to end". The record shows dbt transformations, not ingestion you built or owned.
- "Production Python". The record does not say the scripts ran in production.
- Airflow, Spark, or Kafka in any line. You have never used them.
- "Owned SLAs" or "owned data quality". You added tests; no SLA or ownership is stated.
- "Modelled the warehouse". You designed one mart's star schema, with a then-DE.
- "Partnered with analytics on requirements". The JD's word is "partner". Your record does not say it.
- "Led the star schema design". You designed it with your then-DE.
```

## Parse-safety check

Could not run. Only pasted text arrived, so I cannot check columns, tables, headers, text boxes, or file type. Send the resume as a .docx or a text-layer PDF and I'll run the full check.

## Upgrade menu

- **Resume file (.docx or text-layer PDF):** runs the parse-safety check on the real layout, and re-checks every trace against your actual wording.
- **Existing resume text, if it differs from the bullets above:** the traces get re-run against your real sentences.
- **Inspectable artifacts from the nightly dbt job or cron scripts** (repo, README, run log, alert config): would give rows 5 and 6 a stronger, checkable basis than your memory of them.
- **An older resume version:** may contain DE-leaning detail that was dropped.

## Questions

C1 — Did those cron scripts run unattended, and did anyone get alerted or have to fix them when one failed?
C2 — For the nightly dbt job or the orders mart, did you own a freshness or delivery target, or set up the alerts?
C3 — For the orders mart, did you gather requirements from analysts or business teams and turn them into model changes?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.