Research tier: L0, no searches. I built this from the resume summary in your message, not the PDF, so every "Traces to" quote is from that text. Check each quote against the PDF before you approve a row.

**On the keyword theory:** keywords are part of it, but the sources here point to a smaller role for them than you might expect. Teams use match scores to order review ("Many teams use match scores/filters to prioritize who gets reviewed first." (cite C27)), and a low score lowers a résumé rather than rejecting it (cite C27). Content-based auto-rejection was configured for only "2 of 25" recruiters in one vendor's interviews (cite C25). What most often rejects without a person is a knockout question: "When automated filters are used, they’re almost always knockout questions" (cite C26). Those questions sit on the application form, and nothing in a resume edit changes them. If an eligibility answer on the form doesn't match the posting, job-underwriter should check that before you spend more time tailoring.

The bigger problem is the evidence. Most of this posting names tools your material doesn't contain, and this rewrite can't add them. It can make your real experience findable.

**Priorities** below are my reading (`[inferred]`); the posting doesn't tier its list.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| 1 | Kubernetes | must-have | surfaced_by_edit | L1, L3. Proof-of-concept only, two months, never production. Say so. | `[grounded]` your PoC sentence |
| 2 | AWS | must-have | already_evidenced | "AWS (EC2, S3, RDS, IAM)" already reads as AWS experience | `[grounded]` your skills line |
| 3 | AWS EKS | must-have | not_evidenced | EKS isn't named anywhere. Recovery: C1 | `[grounded]` the resume text |
| 4 | Terraform | must-have | not_evidenced | Nothing in the material. Ansible is config management, not a substitute. Recovery: C2 | `[grounded]` the resume text; `[generic]` Ansible and Terraform are different tools |
| 5 | ArgoCD and GitOps | must-have | not_evidenced | Nothing in the material. Your Jenkins pipeline is not itself GitOps. Named absence below | `[grounded]` the resume text |
| 6 | Istio and service mesh | important | not_evidenced | Nothing in the material. Named absence below | `[grounded]` the resume text |
| 7 | Prometheus, Grafana, observability | important | not_evidenced | CloudWatch monitoring is adjacent, not the same tooling. Named absence below | `[grounded]` the resume text |
| 8 | Vault | important | not_evidenced | Nothing in the material. IAM is not a secrets manager. Named absence below | `[grounded]` the resume text |
| 9 | Helm | important | not_evidenced | Nothing in the material. C1 may surface it | `[grounded]` the resume text |
| 10 | CI/CD | must-have | surfaced_by_edit | L1: your Jenkins deploy pipeline. The row keeps your words, not "CI/CD" | `[grounded]` your pipeline sentence |
| 11 | GitLab CI | must-have | not_evidenced | Jenkins only. Named absence below | `[grounded]` the resume text |
| 12 | Python | must-have | surfaced_by_edit | L2: scripting only. No service or library work is stated | `[grounded]` your scripting phrase |
| 13 | Go | must-have | not_evidenced | Nothing in the material. Named absence below | `[grounded]` the resume text |
| 14 | SRE practices and reliability | important | not_evidenced | No on-call, SLO or incident work in the material. Recovery: C3 | `[grounded]` the resume text |
| 15 | Developer experience | preferred | not_evidenced | Maintaining about 30 Jenkins jobs is adjacent, but nothing describes it as developer-experience work | `[grounded]` your Jenkins sentence |

Rows 2 is already evidenced, rows 1, 10 and 12 are surfaced by edits, and the other eleven are not evidenced.

## Gap handling

**Recall prompts** (the questions are in the closing block):

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | AWS EKS; Helm | must-have | A Kubernetes proof-of-concept, platform not stated | Your PoC is your only Kubernetes evidence, so its platform decides whether an EKS line can be written at all | The PoC cluster; any Helm charts used | A repo, values file, or cluster screenshot | `[grounded]` resume text; `[inferred]` the PoC is the only route to EKS evidence |
| C2 | Terraform | must-have | No infrastructure-as-code tool named | Terraform is a must-have, and Ansible does not stand in for it | Any AWS resources you created as code, with any tool | A repo or module | `[grounded]` resume text; `[generic]` Ansible and Terraform differ |
| C3 | SRE practices | important | Pipeline maintenance; no reliability work named | The posting says you will own reliability, and the material shows none | On-call rotations, alerts you set, incidents you ran | A runbook, alert rule or postmortem | `[grounded]` resume text |

**Named absences** (no recall prompt, a closing path instead):
- **ArgoCD and GitOps:** nothing in your material shows a GitOps tool. The closing path is deploying one service with ArgoCD from a Git repository on a test cluster, then keeping the repo. `[generic]` Whether that counts is the employer's call.
- **Istio, Prometheus and Grafana, Vault, GitLab CI, Go:** each needs hands-on work with that tool. The closing path for GitLab CI is moving one Jenkins job to GitLab CI. For Go, it is shipping one small tool in a public repo. If you don't want the role badly enough to take either route, that is a valid answer, and it is worth saying to yourself before you apply.

## Edit ledger (nothing applied; all rows pending your approval)

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| L1 | Summary (new) | *(none)* | "DevOps Engineer, 4 years. Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs. Ran a Kubernetes proof-of-concept for two months last year — never went to production." | `merge` | "DevOps Engineer, 4 years."; "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs."; "Ran a Kubernetes proof-of-concept for two months last year — never went to production." | `[grounded]` resume text | pending your approval |
| L2 | Skills | "Bash and Python scripting" | Two entries: "Bash scripting" and "Python scripting" | `split` | "Bash and Python scripting" | `[grounded]` resume text | pending your approval |
| L3 | Skills | *(none)* | "Kubernetes (proof-of-concept, not production)" | `surface` | "Ran a Kubernetes proof-of-concept for two months last year — never went to production." | `[grounded]` resume text | pending your approval |

L1 keeps the PoC qualifier, so the summary is honest about the one thing you have. L2 splits the one line that puts Python inside another phrase, and both halves still trace. L3 gives an ATS keyword match something to find without claiming production use.

Not proposed: retitling you to "Platform Engineer" (that title is not in your history), and cutting anything. Your skills list is already short.

## Prohibited claims

Not written, and why:
- **"Platform Engineer" as your title.** You hold DevOps Engineer. The posting's title is not your history.
- **"Ran Kubernetes in production" or "managed clusters."** You ran a two-month PoC that never went to production.
- **Terraform, ArgoCD, GitOps, Istio, Vault, Helm, Prometheus, Grafana, EKS, GitLab, Go.** None appears in your material. Writing them would put tools in your mouth that you'd be asked about in the interview.
- **"Owned platform reliability and developer experience."** That is the posting's sentence about the job.
- **"CI/CD" as a label on your Jenkins work.** That is the posting's term. Your words are "deploy pipeline."
- **"Led the deploy pipeline" or "owned" the 30 jobs.** "Built" and "maintain" are your verbs, and "led" changes who made the decisions.
- **"Managed 30 CI/CD pipelines."** That changes the count, the kind of work, and the scope in one line.

## Parse-safety check

I haven't seen the PDF, so these are the risks from your description, not from the file:

- **Two-column layout.** Parsers often read straight across the columns, so dates can detach from the roles they belong to.
- **Contact details in the header.** Header text is sometimes discarded. If your name, email or phone sits there, a parser may not capture it. **Check this first:** open the PDF, select all, paste into a plain-text editor. If your contact details are missing or out of order, fix that before anything else.
- **Icons on each skill.** Icons can come through as junk characters or not at all. If the skill names live inside the icons, the paste test will show them missing.
- **Headings.** Canva templates often use decorative labels. In the paste output, check that the sections read Experience, Skills and Education.
- **File type.** A PDF is safe only if its text is a real text layer. The paste test also checks this.
- **Not checked:** whether the file contains hidden text from a template. I can't inspect the file, so this check did not run.

## Upgrade menu

- **The PDF itself, or a plain-text export of it.** This lets me check every quote against the text and run the parse check on the file rather than your description.
- **The PoC repo or cluster config, and the Jenkins pipeline config.** These could upgrade rows 1 and 10 from your sentences to something inspectable.
- **Your answers to C1–C3.** A confirmed answer can add a row; a "no" closes the requirement.

## Questions

C1 — Did the Kubernetes proof-of-concept run on AWS EKS or on a cluster you built yourself, and did you use Helm charts or any GitOps tool?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

C2 — Have you ever provisioned AWS resources as code, with Terraform, CloudFormation or Ansible modules? If so, roughly what?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

C3 — Have you been on call, set an alert or SLO, or led an incident for the pipelines or any service?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.