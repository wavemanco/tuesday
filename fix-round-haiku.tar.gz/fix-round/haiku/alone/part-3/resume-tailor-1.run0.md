I built the ledger from the CV you pasted. It has no section headings or original file, so "Summary" and "Experience" below are placeholders. Nothing is applied yet. Every row is pending your approval.

**Short read:** The CV supports Go, the p99 result, on-call, and incident command well. It does not show distributed-systems design, mentoring beyond onboarding, product sequencing, or any build-cache work. It also never uses the word "backend," so I haven't claimed it.

## Edit ledger

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Summary | "Senior Software Engineer, 7 years. Currently at a payments company." / "Go and Rust daily for 4 years, Python before that." | "Senior Software Engineer, 7 years, at a payments company. Go and Rust daily for 4 years, Python before that." | merge | "Senior Software Engineer, 7 years. Currently at a payments company." and "Go and Rust daily for 4 years, Python before that." | `[grounded]` | pending your approval |
| E2 | Experience, bullet 2 | "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak." | Same words, moved to second bullet | reorder | "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak." | `[grounded]` | pending your approval |
| E3 | Experience, bullet 1 | "Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer." | Same words, moved to first bullet | reorder | "Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer." | `[grounded]` | pending your approval |
| E4 | Skills | "CV also lists: Kafka, Postgres, Terraform, gRPC, Datadog." | Go, Rust, Python first; then gRPC, Kafka, Postgres, Terraform, Datadog | surface | "CV also lists: Kafka, Postgres, Terraform, gRPC, Datadog." and "Go and Rust daily for 4 years, Python before that." | `[grounded]` | pending your approval |

E4 lists tools only. It does not say how deeply you used them. The on-call line stays as written, so it has no row.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| 1 | 5+ years backend | must-have | surfaced_by_edit | E1 states 7 years. Backend-specific years are not stated (question 3). | `[grounded]` what the CV says; the word "backend" appears nowhere in it |
| 2 | Production Go | must-have | surfaced_by_edit | E1 and E4 put Go first | `[grounded]` |
| 3 | Distributed systems at scale | must-have | not_evidenced | Adjacent: E2's 40k/min services, Kafka and gRPC listed. No design work is stated. Recall prompt C1. | `[grounded]` |
| 4 | Strong incident response | must-have | already_evidenced | On-call every fourth week for two years; six incidents as incident commander | `[grounded]` |
| 5 | Experience mentoring | must-have | not_evidenced | Adjacent: onboarding and pairing with new hires. Recall prompt C2. | `[grounded]` |
| 6 | Design and ship Go services at high request volume | important | surfaced_by_edit | E2 | `[grounded]` |
| 7 | Drive down p99 latency | important | surfaced_by_edit | E3 | `[grounded]` |
| 8 | Own on-call for your services | important | already_evidenced | Every fourth week for two years | `[grounded]` |
| 9 | Partner with product on roadmap sequencing | important | not_evidenced | Named absence below | `[grounded]` the CV's silence |
| 10 | Build-cache platform and developer tools (context, not a listed requirement) | preferred | not_evidenced | Transferability only: the cache-layer rework on the balance-read path. No build-cache work is stated. | `[grounded]` |

## Gap handling

**C1: Distributed systems at scale (must-have)**
- **What your resume currently shows:** 40k requests/minute at peak, plus Kafka and gRPC in the list. No sentence says what distributed behavior you designed or operated.
- **Why it matters here:** It is a must-have, and a reader will look for it by name.
- **Experience that may count:** Changes to how work is split across Kafka consumers; retries, duplicate messages, or ordering problems you handled; cache behavior on the balance-read path under load.
- **Useful evidence:** A design doc or ADR, a throughput or consumer-lag dashboard, a postmortem.
- **Provenance:** `[grounded]` what the CV does and does not say. `[generic]` what a missing distributed-design line costs on backend applications.

**C2: Experience mentoring (must-have)**
- **What your resume currently shows:** Onboarding and pairing with two or three new hires a year for their first month.
- **Why it matters here:** The posting asks for mentoring mid-level engineers. Onboarding is narrower than that, and I haven't stretched it.
- **Experience that may count:** Someone you coached over months beyond their first month; a mid-level engineer you guided through a project or a promotion case.
- **Useful evidence:** A promotion packet you wrote, feedback you gave in writing, a named mentee.
- **Provenance:** `[grounded]` the onboarding line as written. `[generic]` what a missing mentoring line costs on senior applications.

**Named absence: Partner with product on roadmap sequencing (important)**
The CV shows no work with product on priorities or sequencing. Closing it takes a real case: one roadmap decision you shaped or sequenced with a product partner, written down with the tradeoff. `[grounded]` the CV's silence; `[inferred]` the closing path, as a reasonable extension of that gap.

## Not written, and why

- **"Senior Backend Engineer" as a title.** You hold "Senior Software Engineer," and "backend" is a specialization the CV never states.
- **"Mentored mid-level engineers," or a "Mentoring" heading.** The posting's word is "mentor." Your line is about onboarding.
- **"Designed and shipped Go services at high request volume."** The CV says you own three services and reworked a cache layer. It never says you designed or shipped them.
- **"Distributed systems at scale" as a claim.** Nothing in the CV states it. This is C1.
- **"Partnered with product on roadmap sequencing."** No sentence supports it. This is the named absence.
- **Build-cache or developer-tools experience.** The CV is payments only. The cache-layer rework is adjacent, and I've limited the claim to that.
- **"Scaled to 40k requests per second."** The source is per minute. Changing the unit or the noun turns it into a different number.
- **Dropping "usually" from the onboarding count.** Without it, "usually two or three a year" becomes "two or three a year," which is a firmer claim.
- **Depth or proficiency levels for Kafka, Postgres, Terraform, gRPC or Datadog.** A listed tool is not an owned one.

## Parse-safety check

The CV arrived as pasted prose, not a file. So I could not check layout, tables, text boxes, headers, footers, or hidden text. I can't say whether the original file is safe to parse. If you send the file, I can run those checks. A `.docx` or a text-layer PDF is the safe pair.

## Upgrade menu

- **Send the original CV file.** It lets the parse-safety check run on the real layout.
- **Send a design doc, dashboard, or postmortem from the ledger pipeline or the cache rework.** This is the artifact that could move C1 and E3 up to `[grounded]` with stronger proof.

**Questions**

1. C1: On the ledger pipeline, did you design or change how work is split across consumers, how retried or duplicate messages are handled, or how the balance-read cache stays correct? Describe one in your own words, or say skip.
2. C2: Apart from onboarding, have you ever coached a more junior engineer over months, or written a promotion case for someone? Describe one, or say skip.
3. Of your seven years, how many were backend or service work?

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.