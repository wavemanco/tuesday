Built from the content you pasted, not your formatted document. Every quote below is verbatim from that text. If your document words a line differently, send it and I'll redo the quotes against it. There's no dossier, so the ledger rests on the resume alone. Nothing is applied yet: every row is pending your approval.

The honest read: the resume shows an analyst who does DE-adjacent work (dbt models, a nightly job, a star schema, cron-scheduled scripts). It does not show data engineering as a job, and the 3+ years must-have is not met on what's written. Whether that's worth applying through is job-underwriter's call, not this one's.

Research tier: L0, no searches.

## Edit ledger

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience | "I've fixed our nightly dbt job when it breaks and added tests to it." | *(unchanged, moved to the top of Experience)* | reorder | "I've fixed our nightly dbt job when it breaks and added tests to it." | `[grounded]` resume | pending your approval |
| E2 | Experience | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | "Some scripting to pull vendor APIs on a cron; pandas for analysis." | reorder | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | `[grounded]` resume | pending your approval |
| E3 | Summary | *(no current line)* | "Senior Data Analyst, 5 years, retail. Built and maintained about 25 dbt models including the core orders mart; designed the star schema for the orders mart with our then-DE." | merge | "Senior Data Analyst, 5 years, retail."; "Built and maintained about 25 dbt models including the core orders mart."; "I designed the star schema for the orders mart with our then-DE." | `[grounded]` resume | pending your approval |
| E4 | Experience | "Built and maintained about 25 dbt models including the core orders mart." | *(unchanged, moved above the SQL bullet)* | reorder | "Built and maintained about 25 dbt models including the core orders mart." | `[grounded]` resume | pending your approval |

Not proposed: a retitle to "Data Engineer" (a retitle may only be equivalent, and this isn't), and any skills-list entry for Airflow, Spark or Kafka.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| 1 | 3+ years data engineering | must-have | not_evidenced | No DE title or dated DE role; the five years are as an analyst. DE-type work is adjacent (E1, E3, E4), and how much of the five years it covers is unknown (C2). | `[grounded]` the resume's title and dates |
| 2 | Production Python | important | surfaced_by_edit | E2 moves the cron-scheduled API scripts ahead of pandas. Production standards (tests, error handling, alerting) are not stated. | `[grounded]` resume |
| 3 | Airflow or equivalent orchestration | important | not_evidenced | No Airflow. The nightly dbt job's scheduler isn't named; if it was an orchestrator, this row changes (C1). | `[grounded]` the posting's "Airflow or equivalent" and the resume's silence on a scheduler |
| 4 | Dimensional modelling | important | already_evidenced | "I designed the star schema for the orders mart with our then-DE." Keep "with our then-DE": the design was shared. | `[grounded]` resume |
| 5 | Model the warehouse | important | surfaced_by_edit | E3 puts the 25 dbt models and the star schema in the summary. | `[grounded]` resume |
| 6 | Build and own batch pipelines | important | surfaced_by_edit | E3 and E4 move the dbt work up. Transformation models are shown; ingestion is cron-scheduled pulls; "own" is not stated. | `[grounded]` resume |
| 7 | Build streaming pipelines (Kafka, Spark) | preferred | not_evidenced | Never used Kafka or Spark. Named absence N1. | `[grounded]` resume |
| 8 | Own data quality | important | surfaced_by_edit | E1 surfaces the tests added to the nightly job. Ownership beyond those tests is not stated. | `[grounded]` resume |
| 9 | Own SLAs | important | not_evidenced | No freshness target, uptime commitment or response expectation is stated (C3). | `[grounded]` posting's "own data quality and SLAs" and the resume's silence |
| 10 | Partner with analytics on requirements | important | not_evidenced | The analyst title is the other side of this, but no requirements work with analytics is stated. Named absence N2. | `[grounded]` resume |

## Recovery per gap

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Airflow or equivalent orchestration | important | No scheduler is named for the nightly dbt job. | The posting names orchestration as a requirement, and a scheduler you ran may meet it. | Running the nightly dbt job; cron-scheduled vendor API pulls. | The job's schedule config or run history (a dbt Cloud schedule, an Airflow DAG, a crontab entry). | `[grounded]` the posting's wording and the resume's silence on a scheduler |
| C2 | 3+ years data engineering | must-have | A five-year analyst title. DE-type work appears but has no span of years. | The must-have counts years, and the resume gives no split between analysis and pipeline work. | dbt models across the five years; the vendor-API scripts; the star schema work. | Dated role history, or a list of pipeline work with start dates. | `[grounded]` the posting's must-have and the resume's dates |
| C3 | Own SLAs | important | No deadline, freshness target or response commitment on any job. | The posting makes SLAs an owned responsibility. | Any tracked completion time for the nightly job; any late-data incident you responded to. | An alert or incident thread, a dbt freshness check, a status page. | `[grounded]` the posting's "own data quality and SLAs" and the resume's silence |

**N1 — Streaming (Kafka, Spark), preferred.** You have never used either. The posting lists streaming as a plus, so this costs less than the must-have. Closing it would take a small streaming project you can show, such as one Kafka topic read into a table, in a public repo. It is not production streaming experience, and interview answers should say so.

**N2 — Partnering with analytics on requirements, important.** Your analyst seat is the analytics side of this, and that is real. The resume doesn't say you turned analyst needs into model changes. Closing it would take one example you can describe: a request from analysts, the model change it led to, and who built it. If no such example exists, this stays a gap and the honest answer is adjacent work.

## Prohibited claims

Not written, and why:

- "Data Engineer" as a title, or any DE tenure. Neither is in your history.
- "Production Python" as a skill label. Only cron-scheduled scripts are shown.
- Airflow, Spark or Kafka in any skills list. You have never used them.
- "Owned data quality," "owned SLAs," or "owned pipelines." The tests and the fixes are shown; "own" is not.
- "Built pipelines" or "built ingestion." The resume says you pull vendor APIs on a cron, not that you built the pipeline.
- "Partnered with analytics on requirements." Not stated.
- "Dimensional modelling" as a skills label. The resume says "star schema," and the JD's term would move the words. Removing "with our then-DE" would also turn a shared design into a solo one, so that qualifier stays.

## Parse-safety check

The resume arrived as pasted text, not a file. So the layout checks (columns, tables, headers and footers, icons, section headings, file type) could not be run, and I haven't guessed at layout. The one thing I can see in the content is that every line is plain sentences with no tables or symbols. Send the file and I'll run the full check.

## Upgrade menu

- **Your full resume file (.docx or text-layer PDF).** Unlocks quotes checked against the real document and the parse check. Right now every quote is from your message.
- **A redacted dbt model or project for the orders mart.** Makes rows 4 to 6 inspectable instead of self-reported.
- **The nightly job's schedule config or run history.** Answers C1 by showing it, not by recall.
- **Earlier resume versions.** May hold DE-adjacent lines the current version dropped.

## Questions

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

C1 — What scheduled the nightly dbt job: Airflow or another orchestrator, dbt Cloud, cron, or something else?

C2 — Of the five years, roughly how long was pipeline work (ingestion, scheduling, dbt, the star schema) versus analysis, and did you own the vendor-API scripts end to end?

C3 — Did the nightly job or the orders mart have a completion deadline anyone tracked, and were you ever paged or responsible when it missed?

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.