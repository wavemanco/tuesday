**Yes, apply, on three conditions. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Fully remote, UK location)
- `must_have` — direct: R2, R3, R4, R5, R7
- `important` — adjacent: R6 (Design and read price tests), R8 (Recommendations for underwriting and product), R10 (Pet-insurance product)
- `preferred` — direct: R9 (Insurance experience)

Items: R2, R3, R4, R5 and R7 are your core analytics and underwriting presentation, direct at `medium` confidence; R6, R8 and R10 are adjacent, each with its limit named in the map; R1 is not established because your location and right to work are not in the material.

**Opportunity ledger.** RR1 (line management) and RR3 (salary) are unknowns. RR4 is unknown because web search was refused, so the employer has not been checked. RR2 is a risk signal on pet-claims data. RR5 is a positive signal: the scope is explicit and the hiring manager is named.

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote, UK location); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) RR4 — the posting and the employer verify; (2) RR1 — line-management scope is stated; (3) R10 — the pet bridge goes out as adjacent, never as pet experience.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech with a pet-insurance product | `[grounded]` the posting you pasted; not checked online |
| Mandate | Own pricing analytics for the pet product: rating models, price tests, recommendations for underwriting and product | `[grounded]` posting |
| Reporting line | Hiring manager Odile Varga, Director of Pricing | `[grounded]` the name you gave; public footprint not checked |
| Working pattern | Fully remote, UK | `[grounded]` posting |
| Scope read | A dedicated pricing role with a named Director, but no team size, so the scope is not sized | `[inferred]` from the title and the stated responsibilities |
| Market calibration | Not run. The salary and remit searches were refused | — |
| Unknowns | Line management, salary, team size, pet-data maturity, employer stage | — |
| Contradictions | None visible, but only one source exists | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote, UK location | hard_gate | unclear | none | hard_gate | Posting sets the location; your location and right to work are not stated | `[grounded]` posting; your UK motor history is a lead, not a statement | Q3 |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | Five years in pricing analytics, last two senior; self-reported, not probed | `[grounded]` your background | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | Daily use stated; no code shown | `[grounded]` your background | Optional: an anonymised sample raises to `high` |
| R4 | GLM experience | must_have | direct | medium | none | Built and maintained a GLM rating model for a young-driver book | `[grounded]` your background | none; expect a probe on the GLM specifics |
| R5 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | Quarterly pricing review to the head of underwriting. The underwriting branch is met; the actuarial branch is not evidenced | `[grounded]` your background | none |
| R6 | Design and read price tests | important | adjacent | medium | discovery | You ran 14 tests with underwriting. "Ran" does not establish "designed", so the lower reading is taken | `[grounded]` your background; the design reading is `[inferred]` | Q1 (G2) |
| R7 | Build and monitor rating models | must_have | direct | medium | none | Built and maintained the GLM; the monitoring cadence is not stated | `[grounded]` your background | none |
| R8 | Turn results into recommendations for underwriting and product | important | adjacent | medium | transferability | Underwriting recommendations are evidenced; product recommendations are not. The limit is named | `[grounded]` the underwriting review; `[inferred]` the product adjacency | Bring one product-facing example to the loop, if you have one |
| R9 | Insurance experience (a plus) | preferred | direct | medium | none | Five years of UK motor insurance; not pet | `[grounded]` your background | none |
| R10 | Pet-insurance product knowledge (from "our pet-insurance product") | important | adjacent | medium | transferability | Motor GLM and price-testing carry over. Pet claims dynamics, vet-cost inflation and breed rating are not exercised | `[inferred]` the adjacency; `[generic]` the pet limits | G1 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pet-insurance domain (R10, important) | transferability | Motor pricing only; no pet exposure | Pet-specific pricing is the likely objection | Any rating or price-testing work on a non-motor book; a motor-to-pet comparison you wrote | A rating comparison, a pilot readout, or a reading note | `[inferred]` the bridge; `[generic]` that the objection is likely |
| G2 | Price-test design (R6, important) | discovery | Fourteen tests run with underwriting; design ownership unstated | Whether you designed the tests changes how R6 reads | Choosing test cells, sizing, or setting success criteria | A test design doc or a readout | `[grounded]` the 14 tests; `[inferred]` that design matters here |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Line management not stated | unknown | — | Posting silent on team | The role may be individual-contributor, or may carry reports the posting omits | `[inferred]` from the posting's silence | Does this role line-manage anyone, and who would I work with day to day? | unresolved |
| RR2 | Pet-claims data maturity | risk_signal | medium | "build and monitor rating models" for a pet product | A young product may have thin claims history to rate on | `[generic]` pattern for early-stage pet books; not a claim about this one | How many years of pet claims history does the rating model train on? | unresolved |
| RR3 | Salary not stated | unknown | — | Posting silent on pay | Pay may sit below the market for a senior remit | `[inferred]` from the omission | What is the budgeted salary for this role? | unresolved |
| RR4 | Employer not verified | unknown | — | "Brindlemoor (insurtech)" | Unchecked: the search was refused, so this is not a failed attribution | `[grounded]` search refused | Can you point me to the live posting on your careers site? | unresolved |
| RR5 | Scope and hiring manager named | positive_signal | — | "Own pricing analytics"; "Director of Pricing" | A dedicated pricing function with a senior sponsor | `[grounded]` posting | Who sets the pricing roadmap, and how is it decided with underwriting? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Lead with GLM ownership, price-test work and the underwriting review; state the pet bridge as adjacent | R2–R5, R10 | `[grounded]` your background; `[inferred]` the framing | pending your approval |
| A2 | Get the live posting link before investing in the application | RR4 | `[grounded]` the register | pending your approval |
| A3 | Confirm line-management scope before the first interview | RR1 | `[grounded]` the register | pending your approval |
| A4 | Prepare the pet answer: name the limits first, then the transfer | R10 | `[generic]` that pet interviews probe claims dynamics | pending your approval |

## Evidence status

Verified: none yet. Unverified leads: none beyond your intake. Rejected inferences: none.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Brindlemoor insurtech pet insurance" and "Brindlemoor Senior Pricing Analyst pet insurance"; both refused by permission. Would have moved employer existence, stage and whether the posting is live (RR4) |
| 2. Role-family sweep | unavailable | Searched "senior pricing analyst UK insurance salary GLM pricing"; refused. Would have moved the market band and the salary read (RR3) |
| 3. Hiring manager's public footprint | unavailable | Searched "Odile Varga Director of Pricing Brindlemoor"; refused. Would have moved positioning for this reader |

## Upgrade menu

- The live posting link and the Brindlemoor careers page → RR4 closes, and the employer check runs.
- Web-search permission granted → the three refused targets run on the next turn: employer footprint, pay band, and the Director's public footprint. Deeper diligence (up to 5 more searches and 2 more fetches) is available on request once search works.
- A salary figure → RR3 closes and is set against the market band.
- An anonymised SQL or Python sample → R3 moves to `high`.
- An anonymised price-test readout showing your design role → R6 moves to `high`.
- A non-motor pricing example or a motor-to-pet comparison → R10 narrows.

If you want this written up as a `tuesday-dossier.md` you can keep, I can do that. mock-interview can use it later for prep.

**Questions:**

R6 (G2) — Did you design the 14 price tests yourself, or did you run and read tests someone else designed? What did you own, and what did you decide from the results?

Q2 — Can you paste the live posting link, and the Brindlemoor careers page link if you have one?

Q3 (R1) — Are you UK-based with unrestricted right to work, and do you have a salary floor?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.