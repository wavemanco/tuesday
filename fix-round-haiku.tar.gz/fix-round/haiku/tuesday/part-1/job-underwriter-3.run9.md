**No. Don't pursue this posting as written. R1 (base pay) and R2 (on-site location) are both hard gates and both fail · `no_go`.**

## Decision snapshot

**Fit ledger.**

- `hard_gate`: `hard_gate_fail`: R1 (base compensation), R2 (on-site location)
- `must_have`: `direct`: R3, R4, R5, R6
- `important`: `unclear`: R7 (SEO and content), R8 (brand and PR), R9 (partnerships and sales ops)

Fit reads strong on the functions the posting names: R3, R4, R5 and R6 are `direct`. R7, R8 and R9 are `unclear`. The decision turns on R1 and R2, not on fit.

**Opportunity ledger.** The posting's stated terms conflict with both of your constraints (RR1, RR2). Its own language adds risk signals: scope with no team or budget (RR3), an after-hours norm (RR4), and success metrics left undefined (RR5). The Series A and "profitable since day one" claim (RR6) is the one positive signal, and it is unchecked. Whether the employer exists as described is also unchecked (RR7).

- **Hard gates:** failed: R1 (base compensation), R2 (on-site location). Candidate constraints given.
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`)
- **What would change this:** For `no_go`, the facts that would have to be different are the two stated terms. The base would need to reach your $150k floor, and the on-site requirement would need to go, both in writing from the employer. The posting says "no exceptions" on location.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Novaline, e-commerce enablement startup, Series A, "profitable since day one" | `[grounded]` posting self-description; existence not checked |
| Mandate | All revenue growth end to end: paid, SEO/content, lifecycle/CRM, brand, PR, partnerships, sales ops | `[grounded]` posting |
| Reporting | CEO, with a dotted line to the board | `[grounded]` posting |
| Working pattern | On-site in Austin, 5 days a week, "no exceptions" | `[grounded]` posting |
| Scope read | Seven functions, team of one to start, no budget or headcount stated | `[inferred]` from scope language against silence on resources |
| Pay | $70–85k base plus equity; $65k–$80k below your $150k floor | `[grounded]` posting figure against your stated floor |
| Market calibration | Not established. The role-family searches did not run, so no market band is stated. Model memory is not a source for pay. | — |
| Unknowns | Budget, headcount, success metrics, equity terms, any remote option | — |
| Contradictions | None found within the posting | `[grounded]` posting read against itself |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Base compensation at or above $150k (your floor) | hard_gate | hard_gate_fail | high | hard_gate | Your stated floor is specific and confirmed; the posting's base is $70–85k. Equity is not base. | `[grounded]` posting and your statement | none; only a written change to base would move it |
| R2 | On-site in Austin, 5 days a week (you are remote-only, Portland, not relocating) | hard_gate | hard_gate_fail | high | hard_gate | Your constraint is specific and confirmed; the posting says on-site, "no exceptions" | `[grounded]` posting and your statement | none; only a written change to on-site terms would move it |
| R3 | 8+ years growth leadership | must_have | direct | medium | none | You report 9 years, growth lead then Head of Growth. No artifact yet, so expect a probe. | `[grounded]` your statement | none |
| R4 | Paid acquisition | must_have | direct | medium | none | You owned paid at two B2C subscription companies. No artifact yet. | `[grounded]` your statement | none |
| R5 | Lifecycle and CRM | must_have | direct | medium | none | You owned lifecycle and Braze. No artifact yet. | `[grounded]` your statement | none |
| R6 | Revenue growth ownership | must_have | direct | medium | none | You scaled one company from $8M to $40M ARR over three years with a budget you controlled. No artifact yet. | `[grounded]` your statement | none |
| R7 | SEO and content | important | unclear | low | discovery | Not in your account. Could exist. | `[grounded]` absent from your description | none; not asked, since the decision does not depend on it |
| R8 | Brand and PR | important | unclear | low | discovery | Not in your account. Could exist. | `[grounded]` absent from your description | none; not asked, since the decision does not depend on it |
| R9 | Partnerships and sales ops | important | unclear | low | discovery | Not in your account. Could exist. | `[grounded]` absent from your description | none; not asked, since the decision does not depend on it |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | SEO and content (R7, important) | discovery | Not in your account | Would matter only if the decision turned on it. It does not. | Organic channel ownership, content programs, technical SEO work | Past SEO or content results | `[grounded]` absence from your description |
| G2 | Brand and PR (R8, important) | discovery | Not in your account | Same as G1 | Brand campaigns, press and earned media | A PR plan or results summary | `[grounded]` absence from your description |
| G3 | Partnerships and sales ops (R9, important) | discovery | Not in your account | Same as G1 | Channel or partner deals, sales process or CRM ops | A partner program or sales ops process | `[grounded]` absence from your description |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | On-site with no exceptions, against remote-only | red_flag | high | "On-site in our Austin office 5 days a week — no exceptions." | The stated terms exclude a remote-only candidate, and the posting gives no path around that | `[grounded]` posting quote against your stated constraint | Is any remote or hybrid arrangement possible for this role, and if not, why is on-site required? | unresolved |
| RR2 | Base below your floor | red_flag | high | "$70–85k base plus meaningful equity upside." | The base sits $65k–$80k under your floor, and equity does not change the base | `[grounded]` posting figure against your stated floor | Is the base range negotiable, and is it the approved budget for this role? | unresolved |
| RR3 | Responsibility without team or budget | risk_signal | medium | "Own all revenue growth end to end … You will be a team of one to start" | Accountability across seven functions, with no team, budget or decision rights stated | `[inferred]` from scope language against silence on resources | Which of these seven areas do you expect this role to deliver in year one, and what budget and headcount are committed? | unresolved |
| RR4 | After-hours expectation | risk_signal | medium | "evenings and weekends when it matters is just who we are" | After-hours work is a stated norm, and "when it matters" has no limit | `[inferred]` from the quote | How often does "when it matters" happen, and how is after-hours time balanced? | unresolved |
| RR5 | Success undefined on a demanding mandate | risk_signal | medium | "success metrics will evolve as we learn" | Revenue accountability with no fixed definition of success | `[inferred]` from the quote against "own all revenue growth" | What three measures will define success at the end of year one, and who sets them? | unresolved |
| RR6 | Series A, profitable since day one | positive_signal | — | "Series A, profitable since day one" | Would be a stable base if true | `[grounded]` posting claim, not checked | What are current revenue, runway and funding stage? | noted |
| RR7 | Employer and live posting not checked | unknown | — | "Novaline (e-commerce enablement startup, Series A …)" | The search could not run, so existence and liveness are unknown | `[grounded]` run status | Which team and person would I interview with, and is this posting listed on your careers page? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Don't spend application effort on this posting as written | R1 and R2 fail; the posting says "no exceptions" on location | `[grounded]` R1, R2, RR1 | your call |
| P2 | If the employer changes the terms in writing, re-run this assessment on the new posting | The decision follows the terms, not the title | `[grounded]` R1, R2 | proposed |

## Evidence status

Verified: R1 and R2 (your stated constraints, `high`); R3, R4, R5 and R6 (your stated experience, `medium`, no inspectable artifact yet). Unverified: R7, R8 and R9 (no claim made). Unchecked: Novaline's existence, funding and profitability (RR6, RR7). The employer check does not change the decision. The gates fail whether or not the employer is real.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches ("Novaline e-commerce enablement startup Austin", "Novaline Head of Growth job Austin Series A") were not permitted, so nothing returned. Would have moved the organization row and RR6/RR7. |
| 2. Role-family sweep | unavailable | One search ("Head of Growth salary Series A startup remote base salary 2026") was not permitted. Would have moved the market calibration line. |
| 3. Hiring manager's public footprint | n/a | No name was given, so no query could be formed. |

## Upgrade menu

- **WebSearch permission granted:** runs the two L1 checks, which would confirm the employer and live posting (RR7) and set a market band for the pay line. Neither changes `no_go`, since both gates are stated terms. Both would make the record more complete.
- **A written change to on-site terms:** moves R2 and RR1. The decision is re-run.
- **A written base at or above $150k:** moves R1 and RR2. The decision is re-run.

I can write this up as a `tuesday-dossier.md` if you want a file to keep.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.