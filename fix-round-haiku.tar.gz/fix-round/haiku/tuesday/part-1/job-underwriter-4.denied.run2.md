**Yes, apply, on conditions: `conditional_go`.** Your core experience matches the JD's core asks. The two real gaps are pet insurance and an unknown people-management scope. Web research was refused in this session, so the employer is unverified; I have not confirmed that Brindlemoor exists or that this posting is live.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Every search was refused, so the employer and the live posting are unverified. |
| 2. Role-family sweep | unavailable | No salary or scope band was obtained. Nothing below is calibrated against the market. |
| 3. Hiring manager's public footprint | unavailable | Odile Varga's name was given, but the search was refused. |

**Fit ledger** (evidence map, all rows built from your message; confidence is `medium` throughout because nothing is inspectable yet)

- `hard_gate` — unclear: R1 (UK-based, fully remote, right to work)
- `must_have` — direct: R2 (4+ years pricing analytics), R3 (SQL and Python), R4 (GLM build and maintenance), R5 (presenting to underwriting leads)
- `important` — direct: R6 (designing and reading price tests), R7 (monitoring rating models) · adjacent: R8 (pet-insurance product knowledge)
- `preferred` — direct: R9 (insurance experience)

**Hard gates:** unconfirmed: R1 (UK-based, fully remote, right to work); candidate constraints not given — checks against them unknown.

**Opportunity ledger:** The employer is unverified (RR1). The role's people and decision scope, and its pay and contract basis, are unstated (RR2, RR4). The role's scope is concrete and matches your work (RR5).

- **Severe red flags:** none found.
- **Conditions for go:** (1) RR1 verifies, meaning the posting is live on Brindlemoor's own careers page; (2) R1 is confirmed by you; (3) RR2 answers cleanly on whether you would line-manage; (4) R8 is presented as transferable, with its limits named.

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech; stage and size not established | Unverified: research refused |
| Mandate | Own pricing analytics for a pet-insurance product: rating models, price tests, recommendations to underwriting and product | `[grounded]` JD |
| Working pattern | Fully remote, UK | `[grounded]` JD |
| Scope read | Concrete and in line with a senior analyst role | `[inferred]` from the JD's responsibilities against your described work |
| Market calibration | Not available: the salary sweep was refused | — |
| Unknowns | Reporting line and any people scope; pay and contract basis; team size; whether the role sets prices alone or with sign-off | — |
| Contradictions | None found between the JD and your message | `[grounded]` |

**Evidence map** (condensed; full rows in the notes)

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance |
|---|---|---|---|---|---|---|---|
| R1 | UK-based, fully remote, right to work | hard_gate | unclear | — | hard_gate | Not stated in your message | `[grounded]` JD; gate not established |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | Five years, two as senior analyst; no artifact | `[grounded]` your message |
| R3 | Strong SQL and Python | must_have | direct | medium | none | Daily use; no artifact | `[grounded]` your message |
| R4 | GLM experience | must_have | direct | medium | none | Built and maintained the young-driver GLM | `[grounded]` your message |
| R5 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | Quarterly pricing review to the head of underwriting | `[grounded]` your message |
| R6 | Designing and reading price tests | important | direct | medium | none | 14 tests last year with underwriting | `[grounded]` your message |
| R7 | Building and monitoring rating models | important | direct | medium | none | Maintained a live model | `[grounded]` your message |
| R8 | Pet-insurance product knowledge (implied by "our pet-insurance product") | important | adjacent | medium | transferability | Motor pricing transfers; pet claim behaviour is untested for you | `[inferred]` from the JD's product against your motor work; `[generic]` that pet claims behave differently from motor |
| R9 | Insurance experience (a plus) | preferred | direct | medium | none | Motor insurer | `[grounded]` your message |

Note that R6 and R7 are responsibilities the JD lists, not stated requirements, so I have tiered them `important`.

**Gap recovery queue** (no questions here; each one is asked in the closing block)

| # | Gap | Type | What would close it |
|---|---|---|---|
| G1 | Pet-insurance knowledge (R8) | transferability | A case showing you understand where pet pricing differs from motor, such as annual versus lifetime cover, vet-cost inflation, or multi-pet households. The limit to state: you have not priced pet. |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer and posting unverified | risk_signal | medium | "Brindlemoor (insurtech)" | The posting may be stale, aggregated, or not from a live hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | "Can you point me to this role on Brindlemoor's own careers page, and who would I be interviewing with?" | unresolved |
| RR2 | People and decision scope unstated | unknown | — | "Own pricing analytics" | The role may carry line management or decision rights you have not held | `[inferred]` from the JD's silence on reporting line | "Does this role line-manage analysts, and which pricing decisions does it make without underwriting sign-off?" | unresolved |
| RR3 | Pay and contract basis not stated | unknown | — | (not in JD) | Pay may sit outside your expectations | `[inferred]` from the JD's silence | "What is the budgeted base salary, and is the role permanent?" | unresolved |
| RR4 | Scope concrete and matches your work | positive_signal | — | "build and monitor rating models; design and read price tests" | The role is defined, which makes it easier to evaluate | `[grounded]` JD | "Which team does this sit in, and who is on it?" | noted |

Your "never managed anyone" is not a JD requirement, so it is not in the map. It matters only if RR2 turns out to be line management.

**Application plan** (every row is proposed; nothing is applied)

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Verify the posting on Brindlemoor's careers page before investing effort | RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Ask RR2 and RR3 verbatim with the recruiter | Both are unknown | `[grounded]` register | pending your approval |
| A3 | Lead positioning with the GLM build and the price tests with underwriting, and state motor as motor | R4, R6; R8 limits | `[grounded]` your message; the wording stays yours to approve | pending your approval |

**Evidence status**

Verified: R2, R3, R4, R5, R6, R7 and R9 claims, from your message. Each is specific, but none has an inspectable artifact yet, so each is `medium`.
Unverified leads: none.
Rejected inferences: none.

**Upgrade menu**

- An anonymised GLM documentation page or model-monitoring pack → R4 and R7 move to `high`.
- An anonymised price-test readout → R6 moves to `high`.
- The live posting link, or the recruiter's email domain → RR1 closes or escalates.
- The budgeted salary → RR3 closes.
- Retrying the three research targets, if web search is enabled for this session → the market band and the employer check run.

If you want this kept as a file, I can emit it as `tuesday-dossier.md`; say the word.

**Questions**

1. R1: Are you UK-based with right to work, and is fully remote working workable for you?
2. RR3: Do you have a floor on salary, contract type or notice period I should check the role against?
3. G1 / R8: Have you worked on any product where claims behave differently from motor, such as annual versus lifetime cover, or vet-cost inflation?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.