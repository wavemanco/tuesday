**Yes, it's worth applying, on three checks you can run first.** Status: `conditional_go`.

**Fit ledger.**

- `hard_gate`: unclear: R1 (remote US or Denver office), R2 (pay $148,000–$166,000 plus equity)
- `must_have`: direct: R3 (5+ years data engineering), R4 (strong SQL and Python), R5 (dbt and a cloud warehouse), R6 (orchestration with Airflow or similar), R7 (data quality testing)
- `important`: adjacent: R8 (BigQuery warehouse); unclear: R9 (ingestion from app and CRM), R10 (data contracts analysts depend on)
- `preferred`: none stated

R8 is a bridge with its limit named. R9 and R10 are responsibilities the posting names but your intake doesn't evidence yet.

**Opportunity ledger.** The posting is specific: a named stack, a stated pay band, and a concrete scope. The employer is not verified. My lookup was refused, so the company facts you pasted are unconfirmed (RR1, `severity: medium`). The scope spans four areas, which is wider than a typical single-domain role (RR2, `severity: low`).

- **Hard gates:** none failed; unconfirmed: R1 (remote US or Denver office), R2 (pay $148,000–$166,000 plus equity). Candidate constraints were not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) R1 and R2 both come back met against your location, work authorization and pay floor; (2) RR1 clears, meaning the role is live on the company's careers page and the employer matches the description; (3) BigQuery is framed as a bridge from Snowflake, never as experience.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 states, founded 2016, Denver, 264 staff, Series C ($52M, Feb 2026) | `[grounded]` your paste of the About page; not verified (lookup refused) |
| Mandate | Pipelines behind tutoring reporting: app and CRM ingestion, dbt warehouse on BigQuery, data contracts | `[grounded]` JD |
| Scope read | Four areas, not one domain | `[inferred]` from the JD list against the norm below |
| Market calibration | Senior DE at Series B–D: base median $151,000, IQR $139,000–$163,500; typical 5–8 years; one domain, no direct reports | `[generic]` Datawright 2026 report, as you quoted it (n=2,310) |
| Pay position | Posted band sits inside the IQR; midpoint $157,000 is slightly above median; equity unquantified | `[grounded]` JD against `[generic]` band |
| Seniority fit | Six years is inside the 5–8 norm | `[grounded]` your intake against `[generic]` norm |
| Unknowns | Hiring manager, team, equity amount, contract type, your location, your pay floor | — |
| Contradictions | None visible in the pasted text; careers page not checked | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | No location or authorization constraint given. Remote-US implies an eligibility check the posting doesn't spell out. | `[grounded]` JD | Ask Q1 |
| R2 | Pay $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | Band is stated; your floor is not given. | `[grounded]` JD | Ask Q2 |
| R3 | 5+ years data engineering | must_have | direct | medium | none | Six years at a B2B payroll company. Intake prose, not probed. Experience length is graded, not gated. | `[grounded]` intake | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | Daily use in intake; no artifact inspected. | `[grounded]` intake | none |
| R5 | dbt and a cloud warehouse | must_have | direct | medium | none | 180-model dbt project on Snowflake. Snowflake meets "cloud warehouse"; BigQuery is R8. | `[grounded]` intake | none |
| R6 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow in intake. | `[grounded]` intake | none |
| R7 | Experience with data quality testing | must_have | direct | medium | none | Set up a Great Expectations suite; not inspected. | `[grounded]` intake | Upgrade: a sanitized suite excerpt would raise to high |
| R8 | BigQuery warehouse (named in the role, not the requirement list) | important | adjacent | medium | transferability | dbt modeling and testing carry over. Limit: no BigQuery operation, so partitioning, clustering and cost model are unexercised. | `[inferred]` bridge from R5; `[generic]` that BigQuery's cost and partitioning model differ from Snowflake's | G1 |
| R9 | Ingestion from app and CRM | important | unclear | low | discovery | Intake describes pipelines and warehouse, not source ingestion. | `[inferred]` from JD responsibilities; intake silent | G2 |
| R10 | Data contracts analysts depend on | important | unclear | low | discovery | Intake silent on contracts with downstream consumers. | `[inferred]` from JD responsibilities; intake silent | G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R8, important) | transferability | Snowflake dbt work; no BigQuery | The role names BigQuery; a clear bridge narrows the objection | A dbt project or warehouse migration on any cloud warehouse; cost or partitioning work | A BigQuery sandbox dbt project, or a note on the differences you already know | `[inferred]` bridge; `[generic]` that this is the likeliest objection |
| G2 | Ingestion and data contracts (R9, R10, important) | discovery | Nothing in intake on source ingestion or consumer contracts | Two of four scope areas; decides whether the scope read is a fit | Pulling feeds from operational systems; schema-change agreements with reporting teams; contract or interface docs | A pipeline diagram, a contract doc, or a source-onboarding runbook | `[grounded]` intake silence; `[inferred]` that these areas are central to the role |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources (standing entry) | risk_signal | medium | "Pellucid Learning runs live online tutoring for K-12 schools in 31 US states … Series C ($52M, February 2026)." | Unconfirmed because the lookup was refused, not because the company is shown to be absent. Companies this size are often simply small. | `[grounded]` lookup refused; `[generic]` pattern for companies of this size | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Scope spans four areas | risk_signal | low | "ingestion from our app and CRM, a dbt-modelled warehouse in BigQuery, and the data contracts our analysts depend on" | May be a platform role with shared ownership, or a bundle of roles under one title | `[inferred]` from the JD's list against the `[generic]` one-domain norm | Which of these four areas would I own alone, and which are shared with other teams? | unresolved |
| RR3 | Hiring manager not named | unknown | — | (none; the posting names no hiring manager) | Absence alone is not a signal; the team's reporting line is unknown | `[inferred]` from absence | Who is the hiring manager, and what team do they lead? | unresolved |
| RR4 | Equity unquantified | unknown | — | "plus equity" | Equity could be worth little or a lot; the posting gives no size, vesting or strike | `[inferred]` from the posting's silence | What is the equity grant, as shares or percentage, with vesting and strike? | unresolved |
| RR5 | Stated pay within market band | positive_signal | — | "$148,000–$166,000" | The band sits inside the IQR; the midpoint is slightly above median | `[grounded]` JD against `[generic]` band | How is this band set for this level? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Verify the employer and that the role is live before investing application effort | RR1 | `[grounded]` lookup refused; `[generic]` pattern | yours to do |
| P2 | Ask the recruiter for the location and authorization terms, pay floor, equity size, hiring manager and team | R1, R2, RR3, RR4 | `[grounded]` register | pending your approval |
| P3 | Proposed line for BigQuery: "Built a dbt project of about 180 models on Snowflake; have not worked in BigQuery yet." | R8; the reframing audit passes: "built" matches your intake, and the BigQuery gap is stated | `[grounded]` intake | pending your approval |
| P4 | Lead the stack with dbt, Airflow and Great Expectations, using "set up" for the test suite as you wrote it | R5, R6, R7 | `[grounded]` intake | pending your approval |

## Evidence status

Verified: none yet. Intake claims stay at `medium` until probed.

Research tier: L1 — searches 1 of 5, fetches 1 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Fetch of the careers page and a company search were both refused for lack of permission. Would have moved RR1 (employer exists as described) and whether the posting is live. |
| 2. Role-family sweep | skipped | The Datawright figures are in hand as you quoted them, which fixes the market calibration line and RR5 |
| 3. Hiring manager's public footprint | n/a | No name given, so there was no query to form |

Dossier: I can save this as `tuesday-dossier.md` for interview prep later.

## Upgrade menu

- Granting web-search access → runs target 1 (employer, live posting, source for the pay band), up to 5 searches and 2 fetches; resolves RR1.
- Your location, work authorization and pay floor → R1 and R2 move from unclear to met or failed; a failed gate would make this `no_go`.
- Equity figures → RR4 closes.
- The hiring manager's name → RR2 and RR3 sharpen, and the scope read gets a basis.
- A BigQuery project or sample → R8 narrows its limit.
- Deeper diligence on the company (funding, leadership changes, reports from candidates), up to 5 more searches and 2 more fetches, once web access is granted. Say the word and it runs.

## Questions

Q1 (R1): Does the remote-US-or-Denver location fit where you live, and do you have US work authorization for a remote US role?

Q2 (R2): Is $148,000 to $166,000 plus equity above your pay floor?

Q3 (R9, R10): Have you built ingestion from operational systems like an app or CRM, or owned contracts analysts depended on? Give one example, even a partial one.

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.