**Your fit is strong, but hold off applying until the location is settled: `hold_pending_answers`.** R3 to R6 (your four must-haves) are all direct, and the one real gap is pet insurance. But the JD you pasted says "Fully remote (UK)", and the company's careers page says "Leeds office four days a week." Location is a hard gate, and R1 is unresolved.

**Decision snapshot**

- **Fit ledger** (read off the evidence map):
  - `hard_gate`: unclear: R1 (fully remote UK vs Leeds four days a week)
  - `must_have`: direct: R3 (4+ years pricing analytics), R4 (strong SQL and Python), R5 (GLM experience), R6 (presenting to underwriting leads)
  - `important`: direct: R7 (design and read price tests), R8 (build and monitor rating models) · adjacent: R9 (pet-insurance product)
  - `preferred`: direct: R10 (insurance experience)
  - R1 and R9 are the only rows below `direct`. R1 decides whether the rest matters; R9 is the pet gap an interviewer will probe.
- **Opportunity ledger:** The role is sound but its terms are unclear. RR1 is the location contradiction, RR2 is that decision rights and direct reports are unstated, and RR3 is that no salary is posted. RR4 runs the other way: the hiring manager has a public pricing record.
- **Hard gates:** none failed; unconfirmed: R1 (fully remote UK vs Leeds four days a week); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **What would change this:** If the role is remote from the UK as the JD says, the status moves to `conditional_go`, with RR2 and RR3 as the conditions. If it is Leeds four days a week and that doesn't work for you, it becomes `no_go` on the gate.

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech with a pet-insurance product | `[grounded]` JD and careers page |
| Mandate | Own pricing analytics for the pet product; build and monitor rating models; design and read price tests; turn results into recommendations | `[grounded]` JD |
| Reporting line | Reports to the Director of Pricing (Odile Varga) | `[grounded]` careers page and profile search |
| Working pattern | Contradictory: "fully remote (UK)" in the JD, "Leeds office four days a week" on the careers page | `[grounded]` both sources |
| Scope read | A senior analyst owning one product's analytics; no direct reports stated | `[inferred]` from silence on management |
| Market calibration | Pricewell 2026 survey (n=612, UK insurers and insurtechs): median £58,400, interquartile range £52,100 to £64,900. Not pet-specific, and not this employer's offer | `[generic]` role-family sweep |
| Unknowns | Location, direct reports, pricing decision rights, salary, contract type, start date | — |
| Contradictions | Location (JD vs careers page) | `[grounded]` both sources |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Work location (fully remote UK vs Leeds four days a week) | hard_gate | unclear | none | hard_gate | The two sources disagree and no location constraint was given, so the gate is not established | `[grounded]` JD and careers page | Recruiter answer (RR1); your answer (Q1) |
| R3 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | Five years, last two as senior analyst; self-reported, no artifact yet | `[grounded]` your background | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | Daily use; no artifact yet | `[grounded]` your background | none |
| R5 | GLM experience | must_have | direct | medium | none | Built and maintained the young-driver GLM; no artifact yet | `[grounded]` your background | Sanitized model documentation would raise it to `high` |
| R6 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | Presents the quarterly pricing review to the head of underwriting | `[grounded]` your background | none |
| R7 | Design and read price tests | important | direct | medium | none | Ran 14 tests last year with underwriting; no measured results at intake | `[grounded]` your background | Q3 |
| R8 | Build and monitor rating models | important | direct | medium | none | Built and maintained one GLM; monitoring cadence not described | `[grounded]` your background; `[inferred]` that maintenance counts toward monitoring | Q3 |
| R9 | Pet-insurance product pricing (the product this role owns) | important | adjacent | medium | transferability | Credible adjacency: GLM pricing of personal-lines motor. Limit: no pet work, no pet risk factors or claims data | `[inferred]` requirement from the JD's product line; `[grounded]` your statement that you haven't worked on pet | Name the bridge and its limit in the application (P4) |
| R10 | Insurance experience | preferred | direct | medium | none | Five years at a UK motor insurer | `[grounded]` your background | none |

**Gap recovery queue**

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pet-insurance product (R9, important) | transferability | Motor pricing with GLMs; no pet work | This role's product is pet; the bridge is the line most likely to be probed | Pricing any personal-lines product with a GLM; claims-frequency or severity work outside motor, if you've done it | Nothing new needed; state the limit | `[inferred]` bridge from your CV; `[generic]` that a pet-product interviewer will probe it |
| G2 | Work location (R1, hard_gate) | hard_gate | Two sources disagree; your constraint is unstated | The gate decides whether the rest of the analysis matters | None; only the employer's answer or your own constraint closes it | Recruiter reply, or the live posting | `[grounded]` JD and careers page |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Location contradicts the JD | risk_signal | medium | JD: "Fully remote (UK)"; careers: "Leeds office four days a week" | One source is stale, or the location term is not yet settled | `[inferred]` from setting the two sources side by side | Is this role fully remote from the UK, or based in Leeds four days a week, and does that apply to the whole team? | unresolved |
| RR2 | Direct reports and decision rights unstated | unknown | — | "Own pricing analytics for our pet-insurance product" | The role may own analysis without pricing authority or a team | `[inferred]` from the posting's silence | Does this role have direct reports, and which pricing decisions does it make alone? | unresolved |
| RR3 | Salary not posted | unknown | — | No salary in the JD or the careers page | The figure may sit outside the band in role reality, or the company may not publish salaries | `[inferred]` from the posting's silence, against the `[generic]` band | What is the base salary for this role, and how is it banded? | unresolved |
| RR4 | Hiring manager has a public pricing record | positive_signal | — | Search snippet: Director of Pricing at Brindlemoor, previously head of pricing analytics at Calloway Re for six years; 2025 talk "Small Books, Loud Errors" on monitoring rating models in small books | A pricing-literate reporting line whose talk topic overlaps the monitoring side of the role | `[grounded]` the profile search snippet; I did not read the full profile | Which signals tell you a rating model needs rebuilding? | noted |
| RR5 | Company footprint thin beyond its careers page | risk_signal | low | Broad company search returned nothing; the careers page is the only company page found | Thin footprints are common at this size and are not evidence of a problem | `[generic]` pattern for companies of this size, not a claim about this one | What is the company's registered name, and who is on the pricing team? | unresolved |

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Ask the recruiter where the role is based, and whether Leeds four days a week is current | R1, RR1 | `[grounded]` | pending your approval |
| P2 | Ask whether the role has direct reports and which pricing decisions it makes alone | RR2 | `[grounded]` | pending your approval |
| P3 | Lead with R5 and R6 as your own work: "built and maintained" the GLM, "presented" the quarterly review. Avoid "owned the strategy" | R5, R6 | `[grounded]` your background | pending your approval |
| P4 | State the pet bridge with its limit: "I've priced motor with GLMs; I haven't priced pet, and my data was motor" | R9 | `[grounded]` R9 row | pending your approval |
| P5 | Read the talk slides for "Small Books, Loud Errors" if you can find them, before any interview with Odile Varga | RR4 | `[grounded]` the talk title from the search snippet; the content is unread | pending your approval |

**Evidence status**

Verified: none yet. Your background is self-report at intake, so every claim is a lead until you answer a probe.

Research tier: L1 — searches 4 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Brindlemoor insurtech pet insurance" (no results) and "Brindlemoor Senior Pricing Analyst pet insurance careers" (returned the careers page). Fetched "Senior Pricing Analyst — Brindlemoor careers" (brindlemoor.co.uk/careers/senior-pricing-analyst). Confirmed the posting is live and moved RR1: it contradicts the JD on location. |
| 2. Role-family sweep | yes | Searched "senior pricing analyst pet insurance UK GLM salary"; returned the Pricewell 2026 UK Pricing and Actuarial Analytics Pay Survey (pricewell.example/2026-uk-pricing-analytics-pay-survey). Set the market calibration band. |
| 3. Hiring manager's public footprint | yes | Searched "Odile Varga Director of Pricing insurance"; returned a profile snippet (linkedin.example/in/odile-varga). Moved RR4 and the positioning in P5. Snippet only; the profile was not fetched. |

**Dossier offer:** If you want, I can save this as `tuesday-dossier.md` so the open location question travels with the analysis.

**Upgrade menu**

- A location answer from the recruiter or from you closes R1. The status moves to `conditional_go` if the role is remote, or `no_go` if it is Leeds four days a week and that doesn't work for you.
- Your constraints (salary floor, contract type, start date, location) would let the hard-gate line run real checks instead of reporting them unknown.
- One price test or monitoring result with a measured outcome would move R7 and R8 to `high`.
- Sanitized GLM model documentation would move R5 to `high`.
- Any pet or companion-animal pricing, claims, or loss-ratio work would close R9. None is known from what you've given me.
- The talk slides or recording would show what Odile Varga actually argues about monitoring, which would test RR4.
- A deeper research pass on Brindlemoor (funding, leadership changes, reviews; up to 5 more searches and 2 more fetches). Say the word and it runs.

**Questions**

Q1 (R1, the gate): Where are you based, and is Leeds four days a week workable for you?

Q2 (constraints): Do you have a salary floor, a contract-type requirement, or a start date you won't move?

Q3 (R7, R8): Can you describe one price test or rating-model monitoring result, with its measured outcome, even roughly?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.