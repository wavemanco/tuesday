**Short answer: probably yes on the requirements, but hold until one term is settled.** Status: `hold_pending_answers`.

**Fit ledger.**
- `hard_gate`: unclear: R1 (fully remote, UK)
- `must_have`: direct: R2, R3, R4, R5
- `important`: direct: R6; absent: R8 (pet-insurance product knowledge)
- `preferred`: direct: R7 (insurance experience)

Your stated history meets all four must-haves on paper. R8 is the only absent row, and the JD never asks for pet experience.

**Opportunity ledger.** RR1 is the open conflict: the JD says fully remote, but the employer's careers page says Leeds four days a week. RR2 is positive: the employer and posting are attributable. RR3 (salary withheld) and RR4 (line management unstated) are unknowns.

- **Hard gates:** none failed; unconfirmed: R1 (fully remote, UK); candidate constraints not given, so checks against your location, salary floor and contract terms are unknown.
- **Severe red flags:** none found.
- **What would change this:** a recruiter confirming the role is fully remote from the UK moves this toward `go`. Confirmation that it needs Leeds attendance moves it to `no_go` for you unless you can work from Leeds. Your answer to the location question is the one that decides it.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, pet-insurance product pricing; reports to the Director of Pricing | `[grounded]` JD and careers page |
| Scope | Rating models, price tests, recommendations to underwriting and product | `[grounded]` JD |
| Working pattern | JD: fully remote, UK. Careers page: Leeds office four days a week | `[grounded]` both sources, in conflict |
| Compensation | Withheld on the posting. Market band for a senior pricing analyst: median £58,400, IQR £52,100–£64,900 | `[generic]` Pricewell 2026 UK pay survey (snippet only, not read in full) |
| Unknowns | Location terms, salary, line management, contract basis | — |
| Contradictions | Remote (JD) vs Leeds four days (careers page) | `[grounded]` |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote (UK) | hard_gate | unclear | none | hard_gate | Not established: the JD and careers page disagree, and your location isn't given | `[grounded]` both sources | Q1 |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | 5 years pricing analytics, last 2 as senior analyst | `[grounded]` your intake; not yet verified | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | SQL and Python daily | `[grounded]` your intake | none |
| R4 | GLM experience | must_have | direct | medium | none | Built and maintained the young-driver GLM (motor) | `[grounded]` your intake | none |
| R5 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | Quarterly pricing review to the head of underwriting | `[grounded]` your intake | none |
| R6 | Design and read price tests (JD responsibility) | important | direct | medium | none | 14 price tests last year with underwriting | `[grounded]` your intake | none |
| R7 | Insurance experience | preferred | direct | medium | none | UK motor insurer, 5 years | `[grounded]` your intake | none |
| R8 | Pet-insurance product knowledge (inferred from product scope) | important | absent | none | transferability | No pet work. Motor GLM and price-testing methods carry over; pet claims behave differently from motor | `[inferred]` from the product scope against your motor history; `[generic]` that pet and motor books differ | G1 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pet-insurance knowledge (R8, important) | transferability | Motor pricing only; nothing on a non-motor line | Likely the first interview probe; the limit has to be stated, not hidden | Any non-motor pricing or rating analysis, even a side piece; any product-level price test you designed | A sample rating or test write-up on any non-motor line | `[inferred]` bridge from your motor work; `[generic]` that pet probes come up |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Remote terms contradict the careers page | risk_signal | medium | JD: "Fully remote (UK)"; careers page: "Leeds office four days a week" | Either the careers page is stale or the JD is wrong; the role may need Leeds attendance | `[inferred]` from the two sources disagreeing | Is this role fully remote from the UK, or is it expected in the Leeds office four days a week? | unresolved |
| RR2 | Employer and posting attributable | positive_signal | — | Careers page: "Senior Pricing Analyst … reports to the Director of Pricing" | The role exists on the employer's own careers site with the same product and reporting line | `[grounded]` careers page | Is the role still open, and who would I be interviewing with? | noted |
| RR3 | Salary withheld | unknown | — | JD gives no figure | The budget may sit near the survey band, or the employer may not publish salaries | `[generic]` survey band; `[inferred]` from the withholding | What base salary is budgeted for this role? | unresolved |
| RR4 | Line management unstated | unknown | — | JD silent; title is "Senior" | The role may or may not manage people; you have never managed anyone | `[inferred]` from silence against the title | Does this role line-manage anyone, now or in its first year? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Ask the recruiter to confirm the location terms before applying | see R1, RR1 | `[grounded]` the two sources disagree | pending your approval |
| A2 | Ask for the budgeted base salary and whether the role manages people | see RR3, RR4 | `[grounded]` register | pending your approval |
| A3 | Lead with your own sentences: "Built and maintained the GLM rating model for a young-driver book"; "Ran 14 price tests last year with the underwriting team"; "Presents the quarterly pricing review to the head of underwriting" | see R4, R6, R5 | `[grounded]` your sentences; no clause beyond them | pending your approval |
| A4 | State pet as new, and name where motor transfers, rather than implying pet experience | see R8 | `[grounded]` the absence; `[generic]` that employers probe this | pending your approval |
| A5 | Hiring manager: Odile Varga's public talk "Small Books, Loud Errors" (2025 Insurance Pricing Forum) is on monitoring rating models in small books. Read it before referring to it in any outreach | Public professional footprint only | `[grounded]` search result | pending your approval |

## Evidence status

Verified: none yet. Your background is intake prose, so every claim sits at `medium` until you confirm it with specifics.

Research tier: L1 — searches 4 of 5, fetches 1 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Brindlemoor careers Senior Pricing Analyst" and "Brindlemoor insurtech pet insurance" (no results); fetched "Senior Pricing Analyst — Brindlemoor careers" (brindlemoor.co.uk/careers/senior-pricing-analyst). The fetch returned only the short summary the search showed, so the full posting text was not read. Moved the working-pattern contradiction (RR1) and the employer attribution (RR2) |
| 2. Role-family sweep | yes | Searched "senior pricing analyst pet insurance UK salary GLM", which returned "Pricewell 2026 UK Pricing and Actuarial Analytics Pay Survey" (pricewell.example). Market calibration `[generic]`; moved RR3 |
| 3. Hiring manager's public footprint | yes | Searched "Odile Varga Director of Pricing", which returned her public profile (linkedin.example/in/odile-varga). Moved application plan row A5 |

## Upgrade menu

- Your location, and the role's real terms (fully remote or Leeds): R1 closes, and the decision moves to `go` or `no_go`.
- Any non-motor pricing or rating work, even a side piece: R8 moves from absent toward adjacent.
- The recruiter's answer on salary: RR3 closes against the band.
- A deeper research pass on Brindlemoor (funding, leadership changes, staff reviews; up to 5 more searches and 2 more fetches). Say the word and it runs.

I can also save this assessment as a `tuesday-dossier.md` for a later interview round.

1. R1 (remote terms): Would you be able to work from where you live under either version, fully remote in the UK or Leeds four days a week?
2. G1 (R8, pet knowledge): Have you done any pricing or rating work on a non-motor product, even a side analysis? What did you own?
3. RR3 (salary and constraints): Do you have a base-salary floor, or any non-negotiable on location, contract type or start date?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.