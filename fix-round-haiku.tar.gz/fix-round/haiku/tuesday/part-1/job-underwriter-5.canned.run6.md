**Probably yes. Your stack and six years match nearly every requirement, but the two gates that decide whether you can take this job at all are unchecked, so `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Remote US or Denver office), R2 (base $148,000–$166,000 plus equity)
- `must_have`: direct: R3 (5+ years data engineering), R4 (strong SQL and Python), R5 (dbt and a cloud warehouse), R6 (Airflow or similar orchestration), R7 (data quality testing)
- `important`: adjacent: R8 (BigQuery as the warehouse); unclear: R9 (ingestion from app and CRM), R10 (data contracts analysts depend on)

R3 to R7 are the five must-haves, all `direct` at `medium`, because your background is self-report until a probe confirms it. R8 is the one named tool you haven't used. R9 and R10 are duties the posting describes that your background doesn't yet cover.

**Opportunity ledger.** The posting is sound and well scoped. The salary is stated and sits inside the market interquartile range (RR1), and the one-domain scope fits the title (RR5). Three things are unknown: the hiring manager (RR2), the equity size (RR3), and the Series C figure, which rests on the company's own about page (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Remote US or Denver office), R2 (base $148,000–$166,000 plus equity); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **Conditions for go:** (1) your location fits R1, meaning US-based and able to work remote or from Denver; (2) your base-pay floor is at or below $148,000 (R2); (3) the BigQuery gap is presented as transferable Snowflake experience (R8), never as BigQuery experience.
- **What would change this:** a failed location or pay gate means `no_go`. If the gap is pay and the band might flex, it becomes `hold_pending_answers` instead.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online K-12 tutoring in 31 states, founded 2016, 264 employees, Series C ($52M, February 2026) | `[grounded]` company about page, fetched; the Series C figure is the company's own claim |
| Mandate | Build and run reporting pipelines: app and CRM ingestion, a dbt-modelled BigQuery warehouse, data contracts | `[grounded]` JD and careers page, fetched |
| Working pattern | Remote (US) or Denver office | `[grounded]` JD |
| Scope read | One domain (reporting) with ingestion, warehouse and contracts in one post, no direct reports stated | `[inferred]` from the JD's single-domain wording; `[generic]` that this is the usual title scope |
| Market calibration | Senior Data Engineer at Series B–D: base median $151,000, IQR $139,000–$163,500. Posted range $148,000–$166,000 sits inside the IQR, midpoint $157,000 above the median. This is what to expect, not this employer's offer | `[generic]` the Datawright 2026 report you pasted (one source, n=2,310); `[grounded]` the posted range |
| Seniority norm | "Senior" typically means 5–8 years; you have 6 | `[generic]` the same report |
| Unknowns | Hiring manager, equity size, contract type | `[grounded]` posting silence |
| Contradictions | None: the fetched careers page matches the JD you pasted | `[grounded]` careers page, fetched |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | Your location wasn't given, so the constraint is unstated | `[grounded]` JD | Q1 |
| R2 | Base $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | Your pay floor wasn't given | `[grounded]` JD | Confirm floor |
| R3 | 5+ years data engineering | must_have | direct | medium | none | Six years at a B2B payroll company, self-reported at intake; medium is the intake ceiling | `[grounded]` your background | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | Daily use, self-reported | `[grounded]` your background | none |
| R5 | dbt and a cloud warehouse | must_have | direct | medium | none | dbt project of about 180 models on Snowflake, which is a cloud warehouse | `[grounded]` your background | none |
| R6 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow orchestration, self-reported | `[grounded]` your background | none |
| R7 | Data quality testing | must_have | direct | medium | none | Set up a Great Expectations suite, self-reported; scope of ownership unstated | `[grounded]` your background | none |
| R8 | dbt-modelled warehouse in BigQuery | important | adjacent | medium | transferability | Snowflake and dbt carry over; BigQuery itself is unused. Limit named wherever the bridge is used | `[inferred]` from the Snowflake work | G1 |
| R9 | Ingestion from app and CRM | important | unclear | low | discovery | Not in your background; a lead to pull, not a claim | `[grounded]` JD; `[inferred]` as a duty | Q2 |
| R10 | Data contracts analysts depend on | important | unclear | low | discovery | Quality tests are nearby, but contracts with consumers aren't stated | `[grounded]` JD; `[inferred]` as a duty | Q3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R8) | transferability | Snowflake and dbt at scale; no BigQuery | The JD names BigQuery in its duties, so the probe is likely. Limit: BigQuery's cost and partition model, GCP tooling | Snowflake modelling, dbt conventions and testing that carry over directly | A small public dbt project on BigQuery, or a sandbox build | `[inferred]` bridge from the Snowflake work; `[generic]` that a probe is likely |
| G2 | Ingestion from app and CRM (R9) | discovery | Ingestion is not described in your background | A posted duty, so it affects positioning | Any pipeline that pulled from a product database, event stream or third-party API | A pipeline diagram or repo | `[grounded]` JD; `[inferred]` the gap |
| G3 | Data contracts (R10) | discovery | Quality testing is described; consumer-facing contracts aren't | A posted duty and the phrase "analysts depend on" makes it an interview topic | Schema or freshness agreements with analysts; breaking-change handling | A contract doc or a sanitized spec | `[grounded]` JD; `[inferred]` the gap |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Salary stated and inside market band | positive_signal | — | "$148,000–$166,000 plus equity" | Pay is competitive for this title and stage | `[grounded]` JD; `[generic]` band | Is $148,000–$166,000 the approved band for this requisition? | noted |
| RR2 | Hiring manager not named | unknown | — | (posting names no manager) | Could be a recruiter-led process or a team without a visible lead | `[grounded]` posting silence | Who would I report to, and who would I pair with on the warehouse? | unresolved |
| RR3 | Equity size unstated | unknown | — | "plus equity" | Equity is standard at this stage but its value is unknown | `[grounded]` JD | What is the equity grant and vesting schedule at this level? | unresolved |
| RR4 | Series C figure is self-reported | unknown | — | "Series C ($52M, February 2026)" | The figure is accurate, but the only source is the company's own page | `[grounded]` about page; no independent source checked | Can you confirm the Series C close and the runway for this team's roadmap? | unresolved |
| RR5 | One domain, bounded scope | positive_signal | — | "Build and run the pipelines behind our tutoring platform's reporting" | Ownership is defined and matches the usual Senior remit | `[inferred]` from the JD; `[generic]` typical scope | Which contracts and pipelines would I own, and which stay with analytics? | noted |

No `severity: high` entries, so no severe red flags.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Check R1 and R2 against your own constraints before investing in the application | Gates the decision | `[grounded]` posting | pending your approval |
| A2 | Build a small public dbt project on BigQuery, then link it on the application | Gives R8 an inspectable artifact | `[inferred]` from G1; `[generic]` that a free-tier sandbox is enough | pending your approval |
| A3 | Ask the recruiter for the hiring manager, equity grant and contract type | Closes RR2, RR3 | `[grounded]` RR2, RR3 | pending your approval |

Do not put BigQuery anywhere on your CV. If you need to talk about it, say "Snowflake, with BigQuery not yet used."

## Evidence status

Verified: none yet. Your background is intake self-report until a probe confirms it.

Research tier: L1 — searches 0 of 5, fetches 2 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Fetched pellucidlearning.com/careers/senior-data-engineer ("Senior Data Engineer — Pellucid Learning careers", "Accepting applications"; text matches the JD you pasted). Fetched pellucidlearning.com/about (text matches the About page you pasted). Moved: the employer exists as described, the posting is live, no contradictions. The Series C figure is still self-reported (RR4) |
| 2. Role-family sweep | skipped | The pasted Datawright 2026 report already fixes the market calibration: Senior Data Engineer, Series B–D, median $151,000, IQR $139,000–$163,500. A search would add a second source, not change the line |
| 3. Hiring manager's public footprint | n/a | No name in the posting or your message, so there was no query to form |

Standing entry "Employer not established" is not triggered: the company's own site confirms the entity.

**Upgrade menu**

- Your location and pay floor → R1 and R2 move from unconfirmed to `direct`, and the status moves to `go` or `no_go`.
- An inspectable BigQuery artifact (a public repo or sandbox build) → R8 moves from `medium` toward `high`, and the transferability case gets a concrete strengthener.
- An answer on ingestion or contracts → R9 and R10 leave `discovery`.
- Deeper research on Pellucid (funding confirmation, leadership changes, public employee reports): up to 5 more searches and 2 more fetches. Say the word and it runs.

If you want this saved as a `tuesday-dossier.md` for later use, say so and I'll emit it.

**Questions**

R1 — Are you based in the US, and would remote or the Denver office work for you?

R9 — Have you built ingestion from a product app or a CRM into a warehouse? If so, which sources, how often did they load, and who consumed them?

R10 — Have you defined data contracts with analysts or product teams, meaning written schema or freshness agreements they relied on? Or did quality tests stand in for that?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.