**Snapshot: not yet. Status: `hold_pending_answers`.** Apply if the Bristol hybrid pattern and the £61,500 floor work for you, and be ready to defend the billing and forecast gaps.

- **Fit ledger.**
  - `hard_gate`: unclear: R1 (Bristol, two office days a week), R2 (£61,500–£67,000 pay)
  - `must_have`: direct: R3 (4+ years), R5a (SQL), R6 (Salesforce admin); adjacent: R4 (B2B software company), R5b (spreadsheet modelling), R7 (owning a forecast); unclear: R8b (working with finance on revenue data); absent: R8a (billing data)
  - `important`: direct: R9 (pipeline and renewal reporting)
- **Opportunity ledger.** The posting's scope is bundled: CRM and billing ownership, pipeline reporting and a CFO-level forecast sit in one title (RR2), and who signs the forecast is unclear (RR1). The pay is stated and transparent (RR3, RR4).
- **Hard gates:** none failed; unconfirmed: R1 (Bristol, two office days a week), R2 (£61,500–£67,000 pay); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:** a yes to G1 (Bristol and the pay work) moves this toward `conditional_go`. A clear answer on G2 (any billing or finance revenue work) and G3 (forecast ownership) decides whether the two must-have gaps are recoverable.

Read the posting as a bundled role with a hiring-side gap: it asks for a RevOps lead who also owns billing data and the CFO forecast. Your strongest evidence is pipeline, renewal reporting and Salesforce. Your weakest is billing and forecast ownership.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quillfield, an invoicing software company, Bristol | `[grounded]` posting and your description |
| Mandate | Own CRM and billing data; build pipeline and renewal reporting; run the quarterly revenue forecast with the CFO | `[grounded]` posting |
| Working pattern | Hybrid, two office days a week | `[grounded]` posting |
| Pay | £61,500–£67,000 plus share options | `[grounded]` posting |
| Scope read | Three roles in one title (RevOps, billing systems, FP&A-style forecasting) | `[inferred]` from the scope list |
| Market calibration | Not run at this research tier | — |
| Unknowns | Forecast sign-off versus finance; where the billing team's boundary sits; the hiring manager's background | — |
| Contradictions | None visible; the posting is the only source read | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Bristol, two office days a week | hard_gate | unclear | none | hard_gate | No candidate statement of location or commute to test | `[grounded]` posting | G1 |
| R2 | £61,500–£67,000 plus share options | hard_gate | unclear | none | hard_gate | No candidate pay floor given | `[grounded]` posting | G1 |
| R3 | 4+ years in RevOps, sales ops or analytics | must_have | direct | medium | none | 5 years in sales ops, 2 running RevOps; intake claim with no artifact yet | `[grounded]` your background | none |
| R4 | At a B2B software company | must_have | adjacent | medium | transferability | B2B payments company; whether it counts as software is not settled | `[grounded]` background; `[inferred]` adjacency | Name the product line in your CV |
| R5a | Strong SQL | must_have | direct | medium | none | SQL weekly | `[grounded]` background | none |
| R5b | Spreadsheet modelling | must_have | adjacent | medium | transferability | Excel daily; no model-building stated | `[grounded]` background | G3 |
| R6 | HubSpot or Salesforce administration | must_have | direct | medium | none | Salesforce admin certified; certificate not inspected | `[grounded]` background | Upgrade menu |
| R7 | Experience owning a forecast | must_have | adjacent | medium | transferability | Run the monthly pipeline review; you never owned the company forecast, and finance did | `[grounded]` background; `[inferred]` that pipeline review is a forecast input | G3 |
| R8a | Billing data | must_have | absent | none | transferability | You've never worked on billing data; payments transaction data is the nearest adjacent work | `[grounded]` background; `[inferred]` adjacency | G2 |
| R8b | Working with finance on billing or revenue data | must_have | unclear | none | discovery | Revenue dashboards are yours; a finance working relationship is not stated | `[grounded]` background | G2 |
| R9 | Build pipeline and renewal reporting | important | direct | medium | none | Rebuilt pipeline and renewal dashboards | `[grounded]` background | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Bristol and pay (R1, R2) | hard_gate | Posting terms are clear; your constraints are not | Decides whether this can be a `go` at all | Your commute and current pay | None needed; your answer is the input | `[grounded]` posting |
| G2 | Billing and finance data (R8a, R8b) | discovery | No billing work and no stated finance partnership | Two must-haves are the weakest part of the case | Reconciling bookings to invoices; collections or churn reporting; a finance-owned revenue report you used | A report, dashboard or dataset you touched | `[grounded]` background; `[generic]` that billing is a common gap in RevOps roles |
| G3 | Forecast ownership and modelling (R5b, R7) | discovery | Pipeline review is your input to a forecast; you did not own it | A must-have, and the CFO forecast is in the job's core | Forecast categories or commit numbers you set; a pipeline-weighted model you built; a forecast you presented | A pipeline review pack or a forecast model | `[grounded]` background |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Forecast accountability with finance unclear | unknown | — | "run the quarterly revenue forecast with the CFO" | The role may own the model while finance owns the number, or the reverse | `[inferred]` from the scope against silence on sign-off | Who signs off the quarterly forecast, and which parts does this role own versus finance? | unresolved |
| RR2 | Bundled responsibilities | risk_signal | medium | "own our CRM and billing data … and run the quarterly revenue forecast with the CFO" | Three roles may sit in one title | `[inferred]` from the scope list | Which of these three areas would I own day to day, and which would sit with finance or a billing team? | unresolved |
| RR3 | Pay stated, market not calibrated | unknown | — | "£61,500–£67,000 plus share options" | The band may be fair or low for this scope; not tested at this tier | `[grounded]` posting for the figure; calibration not run | How was this band set against the scope, and how do the share options vest? | unresolved |
| RR4 | Clear outcomes and transparent pay | positive_signal | — | "build the pipeline and renewal reporting our sales and finance teams run on" | Scope is defined and pay is published | `[grounded]` posting | What does success look like at the end of year one? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Lead with the pipeline and renewal dashboard rebuild and the Salesforce certification | Your strongest verified-in-intake evidence | `[grounded]` R6, R9 | pending your approval |
| P2 | State your forecast work as pipeline-review input, not forecast ownership | Keeps the claim the same as the evidence | `[grounded]` R7 | pending your approval |
| P3 | Ask the forecast and billing questions (RR1, RR2) in the first interview | They decide the role | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Everything above rests on your own description, which is CV-equivalent until you confirm specifics.

Research tier: L0 — no searches; user links read 1

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Not run at L0. Would confirm Quillfield exists as described and that the posting is live. Until then, the employer is unverified |
| 2. Role-family sweep | unavailable | Not run at L0. Would calibrate the £61,500–£67,000 band (RR3) |
| 3. Hiring manager's public footprint | unavailable | Not run at L0. Tamsin Achebe was named, so a query could be formed. Would inform positioning (P1) |

## Dossier offer

If you want, I can save this as `tuesday-dossier.md` so the analysis carries into interview prep.

## Upgrade menu

- Your answers to G1 → R1 and R2 move from unclear to direct or hard_gate_fail, and the status can move.
- A billing or revenue-data artifact (a report or dataset you touched) → R8a and R8b move up.
- Your Salesforce certificate → R6 moves from medium to high.
- An L1 research pass (up to 5 searches and 2 fetches) → confirms Quillfield, calibrates the pay (RR3), and checks the hiring manager's public footprint.

## Questions

1. **G1 (R1, R2):** Are two office days a week in Bristol workable for you, and is £61,500 the lowest you would accept?
2. **G2 (R8a, R8b):** Have you ever worked with billing or invoice data, such as reconciling bookings to invoices, collections, or revenue reporting a finance team owned?
3. **G3 (R5b, R7):** When you ran the monthly pipeline review, did your numbers feed a forecast that someone else signed off, and did you ever set forecast categories or a commit number?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.