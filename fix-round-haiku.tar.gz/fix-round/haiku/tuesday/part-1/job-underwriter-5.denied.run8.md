### Decision snapshot

**Probably worth applying to, once two things you haven't given me are checked: where you'd work from, and your pay floor. R1 and R2 are unknown, not failed. Status: `hold_pending_answers`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (remote US or Denver office), R2 (salary $148,000–$166,000 plus equity)
- `must_have`: direct: R3, R4, R5, R6, R7
- `important`: adjacent: R8 (dbt-modelled warehouse in BigQuery); unclear: R9 (ingestion from our app and CRM), R10 (data contracts our analysts depend on)

R1, R2: the gates, not yet checked. R8: BigQuery, which you have not used. R9, R10: the ingestion and contracts work your background does not show.

**Opportunity ledger.** The pay band sits above the market median on the figures you gave (RR4, positive). Open items: team scope (RR1), equity terms (RR3), no hiring manager named (RR2), and an employer and posting check I could not run (RR5).

- **Hard gates:** none failed; unconfirmed: R1 (remote US or Denver office), R2 (salary band plus equity); candidate constraints not given. Checks against them are unknown.
- **Severe red flags:** none found.
- **What would change this:** If your location and pay floor clear, the status moves to `conditional_go`, with the scope answer on RR1 as the condition. If either gate fails, it becomes `no_go`.

### Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Live online tutoring for K-12 schools in 31 states; founded 2016, Denver; 264 employees; Series C, $52M, February 2026 | `[grounded]` your pasted About text; not checked externally |
| Role | Build and run reporting pipelines: app and CRM ingestion, a dbt-modelled BigQuery warehouse, data contracts for analysts | `[grounded]` posting |
| Scope read | Broader than the report's typical scope. The report's norm is one domain's pipelines; this posting spans two source systems, the warehouse and contracts, with no team named | `[inferred]` from posting silence on team; `[generic]` norm from Datawright |
| Seniority fit | "Senior" typically means 5–8 years; the posting asks for 5+; your six years sit inside that | `[generic]` Datawright 2026, n=2,310, as you pasted it |
| Pay calibration | Datawright Senior at Series B–D: median $151,000, IQR $139,000–$163,500. Posted midpoint $157,000 sits above the median and inside the IQR. Equity is unpriced | `[generic]` band; `[grounded]` posted range |
| Hiring manager | Not named | `[grounded]` posting |
| Unknowns | Team size, manager, equity terms, location eligibility, whether ingestion is yours or inherited | — |
| Contradictions | None between the posting and the About text you pasted | `[grounded]` paste comparison only |

### Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | Your location isn't in what you gave me, so the gate is not established | `[grounded]` posting | Location question |
| R2 | $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | No pay floor given | `[grounded]` posting; `[generic]` band | Pay-floor question |
| R3 | 5+ years data engineering | must_have | direct | medium | none | Six years at a B2B payroll company; self-reported at intake | `[grounded]` your background | None; expect a probe on dates |
| R4 | Strong SQL and Python | must_have | direct | medium | none | "Python and SQL daily"; no artifact yet | `[grounded]` your background | A code sample would raise to high |
| R5 | dbt and a cloud warehouse | must_have | direct | medium | none | 180 dbt models on Snowflake; self-reported | `[grounded]` your background | A sanitized model would raise to high |
| R6 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow; self-reported | `[grounded]` your background | None |
| R7 | Data quality testing | must_have | direct | medium | none | Set up a Great Expectations suite; self-reported | `[grounded]` your background | A suite excerpt would raise to high |
| R8 | Warehouse in BigQuery (role description) | important | adjacent | medium | transferability | Snowflake dbt work carries over; BigQuery itself never used, so the limit is named | `[inferred]` adjacency from your Snowflake work | G1 |
| R9 | Ingestion from our app and CRM | important | unclear | none | discovery | Background names no ingestion sources | `[grounded]` background silence | G2 |
| R10 | Data contracts analysts depend on | important | unclear | none | discovery | Background names no contracts | `[grounded]` background silence | G3 |

### Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R8, important) | transferability | Snowflake dbt work; no BigQuery | The posting names BigQuery as the warehouse | Snowflake-to-warehouse moves; dbt model work that carries over; cost tuning | A small BigQuery or dbt-on-BigQuery project | `[grounded]` background; `[generic]` that BigQuery's cost model differs from Snowflake's |
| G2 | Ingestion from app and CRM (R9, important) | discovery | Airflow orchestration; no sources named | Ingestion is the first thing the posting lists | Extracts from an app database; a CRM API connector you built or ran | A DAG outline or source list | `[grounded]` background silence |
| G3 | Data contracts (R10, important) | discovery | No contracts named; GE suite named | Analysts depend on these | Agreed schemas with consumers; checks the analysts signed off on | A contract doc or agreed check list | `[grounded]` background silence |

### Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Scope spans four areas, no team named | risk_signal | low | "Build and run the pipelines behind our tutoring platform's reporting" | You may own ingestion from two systems, the warehouse and contracts alone | `[inferred]` from posting silence on team; `[generic]` single-owner pattern | How many data engineers are on the team, and who owns the app and CRM sources? | unresolved |
| RR2 | No hiring manager named | unknown | — | (none given) | Could be a recruiter-led intake; not a warning on its own | `[grounded]` posting silence; `[generic]` intake pattern | Who would I report to, and what did the team build before me? | unresolved |
| RR3 | Equity offered without terms | unknown | — | "plus equity" | Equity could matter materially to total pay | `[grounded]` posting | What is the grant size, vesting schedule, and last round's price? | unresolved |
| RR4 | Pay band sits above the market median | positive_signal | — | "$148,000–$166,000" | Midpoint $157,000 is above the $151,000 median and inside the IQR; a range, not an offer | `[grounded]` posted range; `[generic]` Datawright band | Is this range the budgeted figure for the seat? | noted |
| RR5 | Employer and live posting not checked | unknown | — | the posting's own URL | Facts about Pellucid rest on your paste; the posting may not be live | `[grounded]` the search and fetch were refused | Is this role open on your careers site now? | unresolved |

### Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Ask the recruiter about location and pay floor before investing in interviews | Gates R1, R2 | `[grounded]` R1, R2 | pending your approval |
| P2 | Describe BigQuery as adjacent: Snowflake dbt work, new to BigQuery | R8's limit; no claim of platform experience you don't have | `[grounded]` R8 | pending your approval |
| P3 | Ask in the first call whether ingestion and contracts are yours or inherited | RR1, G2, G3 | `[grounded]` RR1 | pending your approval |
| P4 | Confirm the posting is live on the careers site before applying | RR5 | `[grounded]` RR5 | pending your approval |

### Evidence status

Verified: none yet. Your background is self-report at intake, so confidence stays at medium. Unverified leads: none. Rejected inferences: none.

Research tier: L1 — searches 1 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | One search and one page fetch were both refused by permission. Would have checked that the posting is live, that the employer exists as described, and the stated size and funding |
| 2. Role-family sweep | skipped | Inputs already fix it: the Datawright figures you pasted supply the pay band and scope norm |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

### Upgrade menu

- Your location and pay floor → R1 and R2 leave `unclear`, and the status moves to `conditional_go`, `go` or `no_go`.
- Permission for one search and one page fetch in this session → target 1 runs; RR5 closes or becomes an employer-not-established entry.
- A sanitized dbt model or Great Expectations suite excerpt → R5 and R7 move to `high`.
- A small BigQuery project → R8 moves toward `direct`.
- The hiring manager's name → RR2 closes and the positioning can be tailored to that reader.

I can write this up as `tuesday-dossier.md` so it carries into later steps. Say the word.

1. **R1:** Where are you based, and is remote-US workable, or would you need the Denver office?
2. **R2:** What is your pay floor, and does the $148,000–$166,000 range clear it?
3. **G2/G3:** Have you built ingestion from an app database or a CRM, or owned a data contract analysts relied on? Describe the closest one.

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.