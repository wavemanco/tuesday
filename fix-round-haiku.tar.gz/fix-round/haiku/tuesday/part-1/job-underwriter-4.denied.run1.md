**Yes, apply, but as a conditional go.** Your motor pricing record covers the analytical core of this JD. The gaps are pet-specific experience, a line-management question the posting doesn't answer, and an employer I could not check, because the web searches were refused.

- **Status: `conditional_go`**

**Fit ledger.**

- `hard_gate`: unclear: R1 (UK location and right to work)
- `must_have`: direct: R2, R3, R4, R5, R6
- `important`: direct: R7 · adjacent: R8 (pet-insurance product knowledge)
- `preferred`: direct: R9

R2, R3, R4, R5, R6 and R7 are direct on your motor record. R8 is the one adjacent row, the pet bridge. R1 is the gate, not yet established. R9 is direct, insurance in general.

**Opportunity ledger.** The role is clearly scoped: the remit to design tests and turn results into recommendations is one you already do (RR4). Three things are unknown: whether it line-manages (RR1), the pay and what the post owns (RR3), and whether the employer is real and the posting live (RR2, a risk signal, medium).

- **Hard gates:** none failed (R1 `unclear`); unconfirmed: R1 (UK location and right to work for a fully remote UK role); candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) RR2: the live posting exists and matches the JD; (2) RR1: the line-management scope is stated; (3) R1: you confirm UK base and right to work.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, insurtech; pet-insurance product | `[grounded]` your JD text |
| Mandate | Own pricing analytics; build and monitor rating models; design and read price tests; recommend to underwriting and product | `[grounded]` JD |
| Working pattern | Fully remote, UK | `[grounded]` JD |
| Pay | Not in the JD text you pasted | `[grounded]` JD; band not checked |
| Market calibration | Not run; the role-family sweep was refused | — |
| Unknowns | Direct reports; pet-product ownership; pay | — |
| Contradictions | None visible in what you gave me; the live posting was not checked | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | UK location and right to work (fully remote UK) | hard_gate | unclear | none | hard_gate | Not in what you gave me, so not settled either way | `[grounded]` JD | Q1 below |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | Five years, last two senior; your statement, no artifact yet | `[grounded]` your message | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | Daily use; self-report | `[grounded]` your message | none |
| R4 | GLM experience | must_have | direct | medium | none | Built and maintained the young-driver motor GLM | `[grounded]` your message | none |
| R5 | Design and read price tests | must_have | direct | medium | none | Ran 14 price tests with underwriting last year | `[grounded]` your message | none |
| R6 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | Quarterly pricing review to the head of underwriting | `[grounded]` your message | none |
| R7 | Build and monitor rating models | important | direct | medium | none | Built and maintained; "monitor" is close to that but not stated | `[grounded]` your message | confirm in interview |
| R8 | Pet-insurance product knowledge | important | adjacent | medium | transferability | Motor pricing is the adjacent work; no pet work in your record. Limit: none of it is pet | `[inferred]` requirement from the JD's product line; `[generic]` that pet pricing has its own rating and claims drivers | G1 |
| R9 | Insurance experience | preferred | direct | medium | none | UK motor insurer, five years | `[grounded]` your message | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pet-insurance product knowledge (R8, important) | transferability | Motor pricing only; no pet, or any non-motor, rating work in what you gave me | The posting names this product, so interviewers will probe the adjacency first | Any non-motor rating or benchmark; a price test on a new segment; claims-cost work on a product with different cost drivers | A pricing-review slide, a price-test readout, or a GLM documentation page | `[inferred]` requirement from JD; `[generic]` that interviewers probe this first |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Line-management scope not stated | unknown | — | "Own pricing analytics" | The role may carry direct reports; you have never managed anyone | `[inferred]` from the duties' silence on people | Does this role line-manage anyone, now or within a year? | unresolved |
| RR2 | Employer and posting not verified | risk_signal | medium | "Brindlemoor (insurtech)" | Unverified, not disproven: the search was refused. Small insurtechs often have thin public footprints | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the live role on your careers site, and who would I be interviewing with? | unresolved |
| RR3 | Pay and product ownership not stated | unknown | — | (no pay figure in the JD you pasted) | Pay may sit below the market band; the post may own more products than the duties say | `[inferred]` from the JD's silence | What is budgeted for this post, and which products does it own? | unresolved |
| RR4 | Clear scope with a test-to-recommendation remit | positive_signal | — | "design and read price tests … turn the results into recommendations" | The role asks for what you already do | `[grounded]` JD | Which pricing recommendations from this team changed a decision last year? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Apply; lead with the GLM, the price tests and the underwriting review | see R2–R6 | `[grounded]` your message | pending your approval |
| A2 | Proposed opener: "I built and maintained a GLM rating model for a young-driver motor book, ran 14 price tests with underwriting last year, and present the quarterly pricing review to the head of underwriting." | Every clause traces to your message. The pet bridge is not in it. | `[grounded]` your message | pending your approval |
| A3 | Ask RR1 and RR3 early in the recruiter call | The register doubles as interview prep | `[grounded]` RR1, RR3 | pending your approval |
| A4 | Confirm the live posting before much effort | see RR2 | `[grounded]` RR2 | pending your approval |

## Evidence status

Verified: none yet. Unverified leads: none. Rejected inferences: none.

Research tier: L1 — searches 4 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches sent for Brindlemoor and the posting; every call was refused by a permission prompt. Would have moved RR2 and the posting's consistency with the JD |
| 2. Role-family sweep | unavailable | One search sent for pay and scope; refused. Would have moved the market calibration line and RR3 |
| 3. Hiring manager's public footprint | unavailable | One search sent for Odile Varga; refused. Would have moved which story to lead with for this reader |

## Dossier offer

I can write this up as a `tuesday-dossier.md` for reuse in interview prep whenever you want it.

## Upgrade menu

- Allow web search, or paste the live posting link. That closes RR2 and the employer check, and sets RR3's pay band. A pasted link counts as a read, not research.
- Any inspectable artifact from the motor work, such as the GLM documentation or a price-test readout, would move R2–R6 from `medium` toward `high`.
- A non-motor artifact or example would close or narrow R8.

## Questions

R1: Are you based in the UK, with the right to work for this role?

R8: Have you done any pricing work outside motor, such as a pet, home or other non-motor product, even a benchmark or a pilot? If not, what is the closest thing you owned?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.