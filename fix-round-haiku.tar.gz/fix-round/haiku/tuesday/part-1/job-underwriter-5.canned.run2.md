**Yes, apply. Status: `conditional_go`.** Your CV-level evidence meets every stated requirement except the cloud warehouse, which is BigQuery in the description but only "a cloud warehouse" in the requirements. The conditions are the BigQuery transfer and the three things the inputs left open: location, pay floor and employer verification.

**Fit ledger.**

- `hard_gate`: unclear: R1 (remote US or Denver), R2 (salary floor)
- `must_have`: direct: R3 (5+ years data engineering), R4 (strong SQL and Python), R5 (dbt and a cloud warehouse), R6 (Airflow orchestration), R7 (data quality testing)
- `important`: adjacent: R8 (BigQuery as the warehouse in the description) · unclear: R9 (data contracts analysts depend on), R10 (ingestion from app and CRM)

R5 and R8 are where the BigQuery question lives. Your dbt and Snowflake work carries over, but you have not run BigQuery.

**Opportunity ledger.** The posting is transparent: it gives the salary, the location options and the stack, and the live page matches the text you pasted (RR4, positive). The $148k–$166k range sits at or above the Datawright Series B–D senior median of $151k (IQR $139k–$163.5k), before equity. The company's own careers page is confirmed, but my search found no third-party footprint for Pellucid Learning (RR1). The posting names no hiring manager and does not say what "data contracts" covers (RR2, RR3).

- **Hard gates:** none failed; unconfirmed: R1 (remote US or Denver), R2 (salary floor); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **Conditions for go:** (1) you can speak to BigQuery as a transfer from Snowflake, not as experience (R8); (2) location and authorization fit (R1) and your pay floor sits under the range (R2); (3) the employer checks out through the recruiter or a named hiring manager (RR1, RR2).

**Research tier: L1 — searches 1 of 5, fetches 1 of 2; user links read 0**

| Target | Status | What it moved |
|---|---|---|
| 1. Official site and careers page | yes | Fetched pellucidlearning.com/careers/senior-data-engineer: live, text matches your paste. Searched "Pellucid Learning live online tutoring K-12 Denver": no results, so no third-party footprint was found. Moved RR1 and the contradictions row (none) |
| 2. Role-family sweep | skipped | The Datawright figures you pasted fix the market band already |
| 3. Hiring manager's public footprint | n/a | No name was given |

**Evidence map (confidence is capped at `medium`: your claims are CV-level self-report, not inspected).**

| # | Requirement | Priority | Fit | Confidence | Gap | Next action |
|---|---|---|---|---|---|---|
| R1 | Remote US or Denver | hard_gate | unclear | — | hard_gate | Confirm location and authorization |
| R2 | Pay floor vs $148k–$166k | hard_gate | unclear | — | hard_gate | Confirm your floor |
| R3 | 5+ years data engineering | must_have | direct | medium | none | none |
| R4 | SQL and Python | must_have | direct | medium | none | none |
| R5 | dbt and a cloud warehouse | must_have | direct | medium | none | none |
| R6 | Airflow orchestration | must_have | direct | medium | none | none |
| R7 | Data quality testing (Great Expectations) | must_have | direct | medium | none | none |
| R8 | BigQuery warehouse | important | adjacent | medium | transferability | Name the limit: no BigQuery use |
| R9 | Data contracts | important | unclear | low | discovery | Ask about your contract experience |
| R10 | App and CRM ingestion | important | unclear | low | discovery | Ask about source ingestion |

The R8 cell is `[inferred]` that dbt and SQL transfer to BigQuery, and `[generic]` that the dialect and cost model differ. Your Snowflake experience is `[grounded]` in your background.

**Opportunity risk register.**

| # | Signal | Class | Severity | Verification question | Status |
|---|---|---|---|---|---|
| RR1 | Employer footprint not found outside its careers page | risk_signal | medium | Who would I interview with, and can you point me to the team's public material? | unresolved |
| RR2 | No hiring manager named | unknown | — | Who is the hiring manager, and which team does this role sit in? | unresolved |
| RR3 | "Data contracts" scope unspecified | unknown | — | Which analyst teams consume the contracts, and who owns them? | unresolved |
| RR4 | Pay and location stated | positive_signal | — | none needed | noted |

RR1 is `[generic]`: a pattern for companies of this size, not a finding about this one. It caps the decision at `conditional_go`.

**Application plan (all proposed, pending your approval).**
- Before applying, spend a few hours on BigQuery (datasets, partitioning, the dbt-bigquery adapter, cost) and describe it as transfer from Snowflake.
- Confirm location, authorization and your pay floor before investing in the loop.
- Ask the recruiter for the hiring manager and the scope of "data contracts."

**Dossier offer.** I can save this as `tuesday-dossier.md` on request.

**Upgrade menu.**
- Your location and authorization answers move R1 to `direct` or `hard_gate_fail`. This is the biggest swing.
- Your pay floor closes R2.
- A BigQuery project or dbt-bigquery sample would raise R8 from transfer to a verifiable claim.
- A short description of contract or ingestion work you have done would resolve R9 and R10.
- A deeper company pass (up to 5 more searches and 2 more fetches) would test RR1; say the word and it runs.

Questions, one per row:

R1 — Are you based in the US, and do you need sponsorship to work here?
R2 — What base-pay floor should I hold this against?
R9 — Have you designed data contracts (schemas, SLAs, versioning) between producers and downstream analysts? Which tools?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.