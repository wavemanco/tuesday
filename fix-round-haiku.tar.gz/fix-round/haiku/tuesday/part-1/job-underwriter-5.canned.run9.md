**Yes, it's worth applying, but check two things first. Status: `conditional_go`.** The must-haves match your background closely. The open items are whether the employer is verifiable beyond its own site, and whether the pay and location terms clear your own constraints, which I don't have.

Research tier: L1 — searches 1 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Pellucid Learning live online tutoring K-12 Denver" (no results). Fetched pellucidlearning.com/careers/senior-data-engineer: live, and the text matches the posting you pasted. Moved RR1. |
| 2. Role-family sweep | skipped | The pasted Datawright 2026 report already sets the band, so no search was needed. |
| 3. Hiring manager's public footprint | n/a | No name was given. |

**Decision snapshot**

- **Fit ledger.**
  - `hard_gate` — unclear: R1 (remote US or Denver location), R2 (base pay against $148,000–$166,000)
  - `must_have` — direct: R4 (5+ years data engineering), R5 (strong SQL and Python), R6 (dbt), R7a (cloud warehouse), R8 (Airflow orchestration), R9 (data quality testing); adjacent: R7b (BigQuery)
  - `important` — unclear: R10 (ingestion from app and CRM), R11 (data contracts analysts rely on)

  R7a and R7b are one requirement split in two. Snowflake covers R7a. You have never used BigQuery, so R7b is adjacent at best.
- **Opportunity ledger.** The posted band and scope look normal for the title and seniority: RR2 is positive. The employer's footprint is unverified (RR1), and equity and the hiring manager are unknown (RR3, RR4).
- **Hard gates:** none failed; unconfirmed: R1 (remote US or Denver location), R2 (base pay against $148,000–$166,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) RR1 clears, meaning you can confirm the recruiter's email domain or the hiring manager; (2) your own pay floor and location clear R1 and R2; (3) you describe BigQuery as new, not as experience.

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Posting | Senior DE, build and run reporting pipelines, dbt warehouse in BigQuery, data contracts, remote US or Denver; $148,000–$166,000 plus equity | `[grounded]` posting, live on the company's careers page |
| Company | Founded 2016, Denver, 264 employees, Series C $52M (February 2026), live tutoring for K-12 in 31 states | `[grounded]` company's own about page; one search found no independent corroboration |
| Market band | Senior DE at Series B–D: base median $151,000, IQR $139,000–$163,500. The posted range sits around the median; its top is above the IQR | `[grounded]` the pasted pay report; `[generic]` that this band is typical for the title |
| Scope and seniority | Six years is inside the typical 5–8 for "Senior." Ownership of one domain's pipelines with no direct reports is the typical scope, and the posting's description is consistent with it | `[generic]` role-family norm; `[inferred]` the match to this posting |
| Contradictions | None between the pasted posting and the live careers page | `[grounded]` the fetch |

**Evidence map** (candidate claims are your prose, so confidence is capped at `medium`)

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning |
|---|---|---|---|---|---|---|
| R1 | Remote US or Denver location | hard_gate | unclear | none | hard_gate | No location given |
| R2 | Base pay against your floor | hard_gate | unclear | none | hard_gate | No floor given; posted figure `[grounded]` |
| R4 | 5+ years data engineering | must_have | direct | medium | none | Six years, stated |
| R5 | Strong SQL and Python | must_have | direct | medium | none | Daily use, stated |
| R6 | dbt | must_have | direct | medium | none | ~180-model project, stated |
| R7a | Cloud warehouse | must_have | direct | medium | none | Snowflake, stated |
| R7b | BigQuery | must_have | adjacent | medium | transferability | Never used it; Snowflake dbt modelling carries over; BigQuery's cost and partitioning model and dialect are untested |
| R8 | Airflow orchestration | must_have | direct | medium | none | Daily, stated |
| R9 | Data quality testing | must_have | direct | medium | none | Set up a Great Expectations suite, stated |
| R10 | Ingestion from app and CRM | important | unclear | none | discovery | Not in your background yet |
| R11 | Data contracts analysts rely on | important | unclear | none | discovery | Not in your background yet |

**Gap recovery queue**

- **G-R7b** (transferability): The adjacent case is Snowflake dbt modelling and query tuning. The limit is BigQuery-specific work. A short BigQuery sandbox dbt model would narrow that limit. Do not claim BigQuery experience.
- **R10 and R11** have their questions in the closing block below.

**Opportunity risk register**

| # | Signal | Class | Severity | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|
| RR1 | Employer footprint not independently established | risk_signal | low | The company may be too young or too small for press coverage; most small companies are simply small | `[generic]` pattern for companies of this size, not a claim about this one | "Can you confirm the recruiter's email is on pellucidlearning.com, and who I'd work with day to day?" | unresolved |
| RR2 | Posted band against market | positive_signal | — | Pay sits in the reported range, with equity on top | `[grounded]` posting and pasted report | "Is $148,000–$166,000 the budgeted range for this seat?" | noted |
| RR3 | Equity terms unstated | unknown | — | Equity could be a large part of total pay | `[inferred]` from the posting's "plus equity" with no terms | "What's the equity grant size and vesting schedule?" | unresolved |
| RR4 | Hiring manager and reporting line unnamed | unknown | — | Ownership of the pipelines may be shared | `[inferred]` from the posting's silence | "Who's the hiring manager, and do I own these pipelines alone or with another team?" | unresolved |

**Severe red flags:** none found.

**Application plan**

- Confirm RR1 before you spend effort on the application.
- Lead with dbt on Snowflake, the Great Expectations suite and Airflow. Describe BigQuery as new. `[grounded]` in your background.
- If you owned ingestion or data contracts, prepare specific examples. The closing questions will tell me what to include.

**Evidence status**

Verified: none yet. Every candidate claim is your own prose and has not been probed.

Research tier line and target table are above.

**Dossier offer:** I can write this up as a `tuesday-dossier.md` you can carry into an interview-prep run, if that would be useful.

**Upgrade menu**

- The recruiter's email domain or the hiring manager's name → RR1 closes, and the hiring manager's public footprint can be checked.
- Your pay floor and location → R1 and R2 move from unclear to direct or failed. A failed gate would change the decision.
- A work sample, such as a dbt model or a data-contract doc you own (sanitized) → raises R4, R6 and R10/R11 from `medium` toward `high`.
- A BigQuery sandbox project → narrows R7b.
- A deeper pass on Pellucid (funding, leadership changes, news; up to 5 more searches and 2 more fetches). Say the word and it runs.

**Questions**

- **R1, R2:** Does the posted $148,000–$166,000 base clear your floor, and can you work remotely from the US or from the Denver office?
- **R10:** Which past pipelines took data from a product app and a CRM, and what did the output feed?
- **R11:** Did you own data contracts or schema agreements that analysts relied on? If so, what did they cover, and who enforced them?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.