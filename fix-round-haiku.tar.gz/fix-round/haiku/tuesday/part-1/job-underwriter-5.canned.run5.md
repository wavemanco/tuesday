**Decision snapshot**

Yes, it's worth applying to, on conditions. Status: `conditional_go`.

- **Fit ledger.**
  - `hard_gate`: unclear: R1, R2, R3
  - `must_have`: direct: R4, R5, R6, R7, R8, R9 · unclear: R11
  - `important`: adjacent: R10 · unclear: R12

  R10 (BigQuery) is a bridge with its limit named. R11 (ingestion from the app and CRM) and R12 (data contracts) have no evidence yet, and R12 is an unknown to test in the first call.

- **Opportunity ledger.** The role is sound on what the posting states: pay is disclosed and sits in the upper-middle of the market band (RR1, positive). Team, equity, on-call and domain are open (RR2, RR3, RR4, RR6). The employer footprint is unverified (RR5, standing entry).

- **Hard gates:** none failed; unconfirmed: R1 (remote US or Denver location), R2 (US work authorization without sponsorship), R3 (base pay $148,000–$166,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) your location and US work authorization are confirmed against R1 and R2; (2) your base-pay floor is at or below $148,000 (R3); (3) BigQuery is presented as new, not as experience (R10); (4) RR2 and RR5 check out in the first recruiter call.
- **What would change this:** a failed R1, R2 or R3 would make it `no_go`. Confirmed gates plus a clean RR5 would move it toward `go`.

Research tier: L1 — searches 1 of 5, fetches 0 of 2; user links read 1

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Pellucid Learning live online tutoring K-12 Denver": no results. Read the posting at pellucidlearning.com/careers/senior-data-engineer (your link); its text matches what you pasted. The company's independent footprint is unconfirmed (RR5). |
| 2. Role-family sweep | skipped | The Datawright 2026 pay report you pasted already fixes the market band (role reality, RR1). |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form. |

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning, live online tutoring for K-12 schools in 31 states; founded 2016, Denver; 264 employees; Series C ($52M, February 2026) | `[grounded]` your copy of the company page; not independently confirmed (RR5) |
| Mandate | Build and run reporting pipelines: app and CRM ingestion, a dbt-modelled BigQuery warehouse, data contracts for analysts | `[grounded]` JD |
| Scope read | One domain's pipelines, no direct reports named | `[inferred]` from the JD's wording against the survey's typical senior scope, which is `[generic]` |
| Market calibration | Senior data engineers at Series B–D companies: median $151,000, IQR $139,000–$163,500 (n=2,310, 2026). The posted $148,000–$166,000 sits in the upper-middle of that IQR | `[generic]` Datawright 2026; `[grounded]` posted range |
| Working pattern | Remote (US) or Denver office | `[grounded]` JD |
| Unknowns | Team and reporting line, equity, on-call, your location and work authorization | — |
| Contradictions | None between the pasted posting and the live careers page | `[grounded]` careers page read |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver location | hard_gate | unclear | none | hard_gate | Your location not given | `[grounded]` JD | Q1 |
| R2 | US work authorization without sponsorship | hard_gate | unclear | none | hard_gate | Not stated by you or the posting | `[inferred]` from "Remote (US)" | Q1 |
| R3 | Base pay $148,000–$166,000 | hard_gate | unclear | none | hard_gate | Your pay floor not given | `[grounded]` JD | Q2 |
| R4 | 5+ years data engineering | must_have | direct | medium | none | Six years at a B2B payroll company; self-report, no artifact yet | `[grounded]` your background | none |
| R5 | Strong SQL and Python | must_have | direct | medium | none | Daily use; no artifact yet | `[grounded]` your background | none |
| R6 | dbt | must_have | direct | medium | none | Built a 180-model dbt project | `[grounded]` your background | none |
| R7 | Cloud warehouse | must_have | direct | medium | none | Snowflake | `[grounded]` your background | none |
| R8 | Airflow or similar orchestration | must_have | direct | medium | none | Airflow in production | `[grounded]` your background | none |
| R9 | Data quality testing | must_have | direct | medium | none | Set up a Great Expectations suite; inspectable if you share it | `[grounded]` your background | upgrade menu |
| R10 | BigQuery warehouse (in the posting's responsibilities, not its requirements) | important | adjacent | medium | transferability | Cloud warehouse and dbt carry over; no BigQuery use, so the limit is named | `[grounded]` Snowflake claim; `[generic]` that BigQuery differences are learnable inside a dbt project | G1 |
| R11 | Ingestion from the app and CRM | must_have | unclear | low | discovery | Not in your background; sources unknown | `[inferred]` from JD responsibilities | Q3 |
| R12 | Data contracts analysts depend on | important | unclear | low | discovery | Quality tests are not contracts; unknown | `[inferred]` from JD responsibilities | Q3 |

**Gap recovery queue** (questions are in the closing block)

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R10) | transferability | Snowflake and dbt in production; no BigQuery | A stronger bridge narrows the most likely objection | A dbt project on any warehouse where you tuned partitioning, clustering or query cost; a migration between warehouses | A short repo, a cost-tuning note, or a sandbox project on BigQuery | `[generic]` that BigQuery differences are learnable inside a dbt project; `[inferred]` that this is the likeliest objection |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay disclosed and near the market middle | positive_signal | — | "Salary $148,000–$166,000 plus equity" | Transparent pay in a plausible band | `[grounded]` JD; `[generic]` band | How is this band set, and does it include equity? | noted |
| RR2 | No hiring manager, team or reporting line named | unknown | — | (posting silent) | The team may be small, or the role may be the first data hire | `[grounded]` posting silence | Who would I report to, and how many engineers work on this pipeline today? | unresolved |
| RR3 | Equity unquantified | unknown | — | "plus equity" | The grant may be small or of an unstated type | `[grounded]` posting silence | What equity comes with this role: type, grant size, vesting schedule? | unresolved |
| RR4 | "Build and run" with on-call unstated | risk_signal | `severity: low` | "Build and run the pipelines" | The role may carry on-call for reporting pipelines | `[inferred]` from "run" | What is the on-call rotation and incident load for these pipelines? | unresolved |
| RR5 | Employer footprint not independently confirmed | risk_signal | `severity: medium` | "Series C ($52M, February 2026)" | The company may be real but under-indexed, or the page may be stale | `[generic]` pattern for companies of this size, not a claim about this one | Which hiring manager and recruiter will I speak with, and where is the Series C announced publicly? | unresolved |
| RR6 | Domain shift from B2B payroll to K-12 tutoring reporting | risk_signal | `severity: low` | "our tutoring platform's reporting" | Domain switches typically add ramp time | `[generic]` pattern, not a claim about this employer | What do analysts most often ask the reporting pipelines for, and where does data quality fail today? | unresolved |

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm location and work authorization before applying | see R1, R2 | `[grounded]` JD | Q1 |
| A2 | Ask RR2–RR6 verbatim in the first recruiter call | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A3 | Describe BigQuery as not yet used; do not list it as a skill. Proposed wording: "Production dbt on Snowflake; new to BigQuery, ramping with a sandbox project." | see R10 | `[grounded]` R10 | pending your approval |

**Evidence status**

Verified: R4, R5, R6, R7, R8, R9 — your statements in this message, at `medium` with no artifact yet. Unverified: R1, R2, R3 (not given); R10's BigQuery element (no experience); R11 and R12 (no evidence). Verified is about the claim, not the fit.

Dossier offer: If you want, I can write this assessment to `tuesday-dossier.md` so it can carry into later prep.

**Upgrade menu**

- Your location and US work-authorization status → R1 and R2 move off `unclear`; the status may change.
- Your base-pay floor → R3 closes.
- A sanitized dbt model or a Great Expectations suite excerpt → R9 moves to `high`.
- A brief description of any app or CRM ingestion, or of contracts you have owned → R11 and R12 move.
- A named hiring manager and a public Series C announcement → RR5 closes.
- A deeper research pass on the company (leadership changes, hiring patterns, recent news; up to 5 more searches and 2 more fetches) — say the word and it runs.

If you apply, the mock-interview module can prepare you for the BigQuery and data-contracts questions.

**Questions**

Q1 (R1, R2): Where are you based, and are you authorized to work in the US without sponsorship?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

Q2 (R3): What is your base-pay floor?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

Q3 (R11, R12): Have you built ingestion from a product app or a CRM, and have you owned data contracts with the people who consume them? Name what you built and who used it.
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.