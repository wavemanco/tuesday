**Yes, worth applying, on conditions. Status: `conditional_go`.** Your stack matches the posting's requirements almost line for line. The real gaps are BigQuery and two responsibilities your background doesn't cover, and the posting itself is only partly verified.

**Fit ledger.**

- `hard_gate` — unclear: R1 (Remote US or Denver office)
- `must_have` — direct: R2 (5+ years data engineering), R3 (strong SQL and Python), R4 (dbt and a cloud warehouse), R5 (orchestration with Airflow or similar), R6 (data quality testing)
- `important` — adjacent: R7 (BigQuery, the named warehouse); unclear: R8 (ingestion from app and CRM), R9 (data contracts analysts depend on)
- `preferred` — none stated

R2–R6 are the must-haves your background shows. R7 is the BigQuery gap, which is transferable. R8 and R9 are responsibilities nothing you've given me settles.

**Opportunity ledger.** The scope is well defined: a senior, domain-owning role with no direct reports, which is the typical shape of the title in the pay report (RR3, positive). The salary range ($148k–$166k) sits in the upper half of the report's interquartile range, with a midpoint of about $157k against a $151k median. The hiring manager, team size and equity value are unknown (RR2, RR4). The posting's facts come only from the page you pasted, because my research did not run (RR1).

- **Hard gates:** none failed; unconfirmed: R1 (Remote US or Denver office); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the posting is live on pellucidlearning.com, confirmed through your recruiter's email domain or a link (RR1); (2) you can speak credibly to BigQuery within a few days of prep, framed as transferable from Snowflake and not as existing expertise (R7); (3) your location and US work authorization fit the remote-US or Denver terms (R1).

**Research tier: L1 — searches 1 of 5, fetches 1 of 2; user links read 0.** Both calls were refused by the environment's permission setting, so no web checks ran.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Every call was refused. It would confirm the posting is live and the company's facts, which are currently only your pasted text. |
| 2. Role-family sweep | skipped | The Datawright 2026 figures you pasted already fix the market band and the scope norm. |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form. |

**Evidence map.** Confidence is capped at `medium` on all of your claims, because intake prose can't reach `high` until it is probed.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning |
|---|---|---|---|---|---|---|
| R1 | Remote US or Denver office | hard_gate | unclear | — | hard_gate | Your location and work authorization weren't given. Not established either way. |
| R2 | 5+ years data engineering | must_have | direct | medium | none | 6 years at a B2B payroll company. `[grounded]` your intake description. |
| R3 | Strong SQL and Python | must_have | direct | medium | none | Daily use of both. `[grounded]` your intake description. |
| R4 | dbt and a cloud warehouse | must_have | direct | medium | none | dbt project on Snowflake, about 180 models. Snowflake is a cloud warehouse. |
| R5 | Airflow or similar orchestration | must_have | direct | medium | none | Airflow in production. |
| R6 | Data quality testing | must_have | direct | medium | none | You set up the Great Expectations suite. |
| R7 | BigQuery (named in the responsibilities) | important | adjacent | medium | transferability | The dbt and SQL work carries over. BigQuery's partitioning, clustering and cost controls are untested. `[inferred]` from your Snowflake work. |
| R8 | Ingestion from app and CRM | important | unclear | low | discovery | Your material doesn't say what sources you ingested. `[grounded]` silence. |
| R9 | Data contracts analysts depend on | important | unclear | low | discovery | Not in your material. Adjacent to your dbt and test work, but unestablished. `[inferred]` adjacency. |

**Gap recovery queue.**

- **G1 (R7, transferability).** Bridge: your dbt and SQL depth carries over; the limit is that you haven't used BigQuery's partitioning, clustering or cost controls. Strengthener: a short BigQuery sandbox project, or a dbt-bigquery adapter run, that you can describe. `[inferred]` bridge; `[generic]` that this is the likeliest technical probe.
- **G2 (R8, discovery).** What would close it: a pipeline you built or owned that pulled from a product database or a CRM, with the sources named.
- **G3 (R9, discovery).** What would close it: a schema or contract agreement with a downstream team, even an informal one.

**Opportunity risk register.**

| # | Signal | Class | Severity | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|
| RR1 | Posting and employer not independently verified in this run | unknown | — | The posting may be stale or aggregated. | `[grounded]` research refused | Can you point me to this role on your own careers page, and who would I interview with? | unresolved |
| RR2 | Hiring manager, team and interview process unnamed | unknown | — | Ownership may be shared with an analytics team. | `[grounded]` posting silence | Who would I report to, and how many engineers are on the data team? | unresolved |
| RR3 | Scope defined: domain pipelines, no direct reports | positive_signal | — | The role is a genuine senior IC scope. | `[grounded]` JD; `[generic]` the title norm | Which pipelines would I own in the first 90 days? | noted |
| RR4 | Equity unpriced | unknown | — | Equity value is unknown and may not offset the base. | `[grounded]` JD "plus equity" | What is the grant size and vesting schedule? | unresolved |

**Application plan.** All three are proposals, pending your approval.

| # | Action | Why | Provenance |
|---|---|---|---|
| P1 | Confirm the posting through your recruiter before investing in the application | RR1 | `[grounded]` RR1 |
| P2 | Spend a few days on BigQuery: a sandbox project and a dbt-bigquery run | G1, R7 | `[inferred]` from the G1 bridge |
| P3 | Lead with the Snowflake dbt scale and the Great Expectations work, stated as what you built | R4, R6 | `[grounded]` your intake |

**Verified: none yet.** Your intake claims are self-report until probed.

I can also write this up as a `tuesday-dossier.md` file that a later mock-interview run could read. Say the word and I'll emit it.

**What would move the decision.** Confirming the posting and employer (RR1) and your location and authorization (R1) would move this to `go`. If the posting is stale, or the location terms don't fit, it becomes `no_go`.

**Upgrade menu.**

- Research checks of the careers page and the company (L1 target 1): confirms the posting is live and the company's facts, currently unverified.
- A BigQuery sandbox or project you can describe: R7 moves from `adjacent` toward `direct`.
- A pipeline or contract example for ingestion and data contracts: R8 and R9 move from `unclear`.
- A hiring manager's name: RR2 and the interview-prep angle.
- The salary and equity grant: RR4.

**Questions.**

R1 — Are you authorized to work in the US, and would remote-US or Denver work for you? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

R7 — Have you touched BigQuery at all: a sandbox, a side project, or a teammate's work you reviewed? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

R8/R9 — Did you own ingestion from a product database or CRM, or agreements with downstream teams about schemas? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.