**Hold. Don't spend application time until one question is answered.** Status: `hold_pending_answers`. Renata, your fit on the stated requirements is strong. The problem is that the posting you pasted and Brindlemoor's own careers page disagree on location, and location is a hard gate.

**Fit ledger.**

- `hard_gate` — unclear: H1 (UK-based, fully remote as posted)
- `must_have` — direct: R1, R2, R3, R4
- `important` — direct: R5, R6a · adjacent: R7 (pet-insurance product knowledge) · unclear: R6b (product recommendations)
- `preferred` — direct: R8

Below `direct`: H1 is location and right to work, which your message didn't state. R6b is product-facing recommendations, which you didn't describe. R7 is pet-specific risk knowledge, bridged from motor. The four must-haves R1, R2, R3 and R4 are all `direct`.

- **Hard gates:** none failed; unconfirmed: H1 (UK-based, fully remote as posted); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **Opportunity ledger:** The employer is real and the posting is live (RR4 is a positive: the remit is concrete). Two things are open. The location conflict is RR1. Line management is unstated, and you've never managed anyone, which is RR2. Pay is not stated in the posting (RR3).
- **What would change this:** If you can work from Leeds four days a week and have UK right to work, H1 clears and the status moves to `conditional_go`, with the conditions being RR1 confirmed in writing and RR2 answered. If you can't, the gate fails and the status is `no_go`.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, insurtech; live posting on its own careers page | `[grounded]` careers page fetched |
| Mandate | Own pricing analytics for the pet-insurance product: rating models, price tests, recommendations | `[grounded]` JD |
| Working pattern | Pasted JD: "Fully remote (UK)". Careers page: "Leeds office four days a week" | `[grounded]` both sources, in conflict |
| Reporting line | Reports to the Director of Pricing; no direct reports stated | `[grounded]` careers page |
| Scope read | Owns the models, the tests and the recommendations end to end, from the verbs alone | `[inferred]` from the JD's three responsibilities |
| Market calibration | Median base £58,400; interquartile range £52,100–£64,900 for senior pricing analysts at UK insurers and insurtechs. Posting withholds pay, so this is what to expect, not this employer's offer | `[generic]` Pricewell 2026 survey (snippet only, not fetched) |
| Unknowns | Actual location requirement; reports; pay; whether product decisions sit with this role | — |
| Contradictions | Location (above) | `[grounded]` |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| H1 | UK-based, fully remote as posted (careers page says Leeds four days a week) | hard_gate | unclear | none | hard_gate | No location or right-to-work claim from you yet; the sources conflict | `[grounded]` JD vs careers page | Q1 |
| R1 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | 5 years, last 2 senior; self-reported, not yet inspected | `[grounded]` your message | none |
| R2 | Strong SQL and Python | must_have | direct | medium | none | Daily use stated; no artifact yet | `[grounded]` your message | none |
| R3 | GLM experience; build and monitor rating models | must_have | direct | medium | none | Built and maintained the young-driver GLM | `[grounded]` your message | none |
| R4 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | Quarterly pricing review to the head of underwriting | `[grounded]` your message | none |
| R5 | Design and read price tests | important | direct | medium | none | 14 tests last year with underwriting | `[grounded]` your message | none |
| R6a | Recommendations for underwriting | important | direct | medium | none | Follows from the quarterly review | `[grounded]` your message | none |
| R6b | Recommendations for product | important | unclear | none | discovery | Nothing in what you gave me on product decisions | `[grounded]` absence in your message | Q2 |
| R7 | Pet-insurance product knowledge (inferred from "our pet-insurance product") | important | adjacent | medium | transferability | Motor GLM and price-testing carry over; no pet-specific risk experience | `[inferred]` bridge from motor; `[generic]` that pet risk differs in ways that matter | A3 |
| R8 | Insurance experience (a plus) | preferred | direct | medium | none | 5 years at a UK motor insurer | `[grounded]` your message | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Product recommendations (R6b) | discovery | Price-test work ends at underwriting; product is not mentioned | Decides whether the "product" half of the remit is covered | A cover-limit or excess change from a test; a launch price; a benefit change you proposed | A proposal deck or test readout that went to product | `[grounded]` absence in your message |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Location conflict between JD and careers page | risk_signal | medium | "Fully remote (UK)" vs "Leeds office four days a week" | The careers page may be the current requirement, or the pasted JD may be stale | `[grounded]` both sources | Is this role fully remote, or Leeds four days a week, and which text is current? | unresolved |
| RR2 | Line management unstated | unknown | — | "Senior Pricing Analyst"; "reports to the Director of Pricing" | The role may or may not carry reports; you have never managed anyone | `[inferred]` from the title and the silence on reports | Does this role line-manage anyone now or in its first year? | unresolved |
| RR3 | Pay not stated | unknown | — | (no salary in posting) | Pay may sit outside the market band in role reality | `[inferred]` from the posting's silence | What base salary is budgeted for this post? | unresolved |
| RR4 | Remit concrete | positive_signal | — | "Own pricing analytics for our pet-insurance product" | Deliverables are named, so success is checkable | `[grounded]` JD | Which of the three responsibilities has the most open work today? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Answer Q1 before anything else; if Leeds four days a week is out, stop | H1, RR1 | `[grounded]` | your decision |
| A2 | Ask the recruiter to confirm the working pattern and reporting line in writing | RR1, RR2 | `[grounded]` | your action |
| A3 | Pet-insurance bridge, proposed wording: "Motor GLM and price-test work carry over; I have no pet-specific risk experience yet." Each clause traces to your message | R7 | `[grounded]` your message; `[generic]` on pet risk | pending your approval |
| A4 | Lead with rating-model maintenance. Odile Varga's public talk, "Small Books, Loud Errors" (2025 Insurance Pricing Forum), is about monitoring rating models in small books | Positioning for this reader | `[grounded]` profile; `[inferred]` that it matters to them | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Brindlemoor insurtech pet insurance" (no results) and "Brindlemoor Senior Pricing Analyst pet insurance careers" (returned brindlemoor.co.uk/careers/senior-pricing-analyst); fetched that page. Moved: employer and posting confirmed; location conflict → H1, RR1 |
| 2. Role-family sweep | yes | Searched "senior pricing analyst insurance UK salary remote", which returned the Pricewell 2026 UK Pricing and Actuarial Analytics Pay Survey (not fetched; snippet only). Moved: market calibration, RR3 |
| 3. Hiring manager's public footprint | yes | Searched "Odile Varga Director of Pricing insurance", which returned a professional profile (linkedin.example/in/odile-varga; not fetched). Moved: A4 |

Upgrade menu:

- Your answer to Q1 → H1 closes and the status moves to `conditional_go` or `no_go`.
- The recruiter's written answer on location and reports → RR1 and RR2 close.
- The budgeted base → RR3 closes against the band in role reality.
- A product-facing example, such as a change you proposed from a price test → R6b moves toward `adjacent` or `direct`.
- A deeper pass on Brindlemoor (leadership, hiring history, public reviews), up to 5 more searches and 2 more fetches. Say the word and it runs.

If you want, I can write this up as a `tuesday-dossier.md` you can keep and reuse.

**Q1 (H1):** Could you work from Leeds four days a week, and are you based in the UK with the right to work there without sponsorship?

**Q2 (R6b):** Have you ever turned a price-test result into a product decision (a cover-limit, excess, benefit or launch-price change), and what did you own in it?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.