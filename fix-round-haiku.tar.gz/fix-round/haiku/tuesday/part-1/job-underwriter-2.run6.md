**Not a waste of time, but a stretch: `conditional_go`.** The one must-have your resume answers with a no is titled product-management experience (R1b, absent). The case has to rest on R1a, R2 and R10, and R10 is still unclear. Apply only if the first question below turns up a product decision you owned or shaped.

**Fit ledger**

- `must_have`: direct: R3, R4a · adjacent: R1a (3+ years product management), R2 (shipped API or platform products), R9 (write specs and drive delivery with two engineering squads) · unclear: R4b (stakeholder management across sales), R5 (agile delivery), R10 (own the roadmap for our partner-facing API platform) · absent: R1b (3+ years product management experience)
- `important`: adjacent: R7 (run discovery with integration partners), R8 (coordinate launches with sales and support) · unclear: R6 (define and track adoption metrics)

R1b is the titled years, which R1a and R2 have to carry; R10 is roadmap ownership, asked in Q1; R3 and R4a are the direct rows.

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Opportunity ledger:** RR1 (roadmap authority) and RR2 (squad authority) are unknowns and a risk signal; RR3 (employer not established) stays open because research was refused; RR4 (no pay stated) is an unknown; RR5 (adoption metrics named) is a positive signal.
- **Conditions for go:** (1) Q1 yields a product decision you made or shaped (R10, R1a); (2) the posting checks out as live and the employer exists (RR3); (3) the triage tool in Q2 is real, or you drop it from your pitch.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline, B2B logistics-tech, about 150 people, Series B | `[grounded]` posting header; not verified, research refused |
| Mandate | Own the partner API roadmap, run partner discovery, write specs, drive two squads, define adoption metrics, coordinate launches | `[grounded]` posting |
| Scope read | Partner-facing platform with two squads and its own metrics is a senior product scope for a company this size | `[inferred]` from scope against company size |
| Market calibration | Not run: the role-family search was refused, so there is no band | — |
| Compensation | Not stated in the posting | — |
| Unknowns | Roadmap decision rights; squad reporting lines; sales involvement; who owns metrics today; pay; contract type | — |
| Contradictions | None between the posting and your CV; no other source was checked | `[grounded]` |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1a | 3+ years product management, counted as adjacent work | must_have | adjacent | medium | transferability | Requirements, roadmap-input and go-live work is product-adjacent. Limit: it is input and delivery, not a product role. Self-reported, unprobed. | `[grounded]` your CV; `[inferred]` that it carries over | Q1 |
| R1b | 3+ years product management, titled | must_have | absent | medium | transferability | You hold no PM title. Titled years are graded on fit, not treated as a gate. | `[grounded]` your statement | Carried by R1a and R2 |
| R2 | Shipped API or platform products | must_have | adjacent | medium | transferability | 30+ integrations taken end to end, but the products were built by others. Limit: no build or release ownership stated. The triage-tool note is a memory lead and is not counted. | `[grounded]` your CV | Q2 |
| R3 | Technical fluency: API docs, schemas | must_have | direct | medium | none | OpenAPI, Postman, SQL and integration architecture are named. "Discussing schemas" is implied, not stated. | `[grounded]` your CV; `[inferred]` the schema link | None |
| R4a | Stakeholder management: engineering and customers | must_have | direct | medium | none | Coordinated vendor engineers, client engineers and PMs; ran scoping workshops and UAT. | `[grounded]` your CV | None |
| R4b | Stakeholder management: sales | must_have | unclear | low | discovery | Your CV is silent on sales; the work was implementation-side. | `[grounded]` CV silence | Upgrade menu |
| R5 | Agile delivery | must_have | unclear | low | discovery | No sprint, backlog or cadence named. Could be true inside the squads; not established. | `[grounded]` CV silence | Q3 |
| R9 | Write specs and drive delivery with two squads | must_have | adjacent | medium | transferability | Requirements documents and coordinating engineers on custom builds. Limit: no squad leadership or sprint ownership. | `[grounded]` your CV; `[inferred]` adjacency | Q3 |
| R10 | Own the roadmap for the partner API platform | must_have | unclear | low | discovery | You gathered roadmap input; ownership is not stated. This is the key open question. | `[grounded]` CV silence on ownership | Q1 |
| R6 | Define and track adoption metrics | important | unclear | low | discovery | SQL is the one lead; no metric ownership stated. | `[grounded]` CV; `[inferred]` SQL as a route | Upgrade menu |
| R7 | Run discovery with integration partners | important | adjacent | medium | transferability | Roadmap-input sessions collected client feedback. Limit: input, not discovery you led end to end. | `[grounded]` your CV | Q1 |
| R8 | Coordinate launches with sales and support | important | adjacent | medium | transferability | Go-live and UAT with clients. Sales and support coordination not named. | `[grounded]` CV; `[inferred]` go-live adjacency | Upgrade menu |

## Gap recovery queue

| # | Gap (req) | Type | What I see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Roadmap ownership (R10, R1a) | discovery | Input gathered; no decisions owned | Decides whether the must-have is adjacent or unclear | Any priority or scope call you shaped on the platform or a client build | A decision log, roadmap, or the prioritisation you fed into | `[grounded]` CV silence; `[inferred]` that it moves the decision |
| G2 | Titled years (R1b) | transferability | No PM title | Must-have at absent; adjacent work has to carry it | Product-adjacent roles where you made calls | A reference who saw you make product calls | `[grounded]` your statement |
| G3 | Shipped product (R2) | discovery | Integrations shipped; products not yours | Could move R2 toward direct | The triage tool, if real | Adoption figures or a release note | `[grounded]` CV; memory lead not counted |
| G4 | Agile delivery (R5) | discovery | Not named | Must-have at unclear | Sprint or release work with your engineering teams | Team process doc or sprint board | `[grounded]` CV silence |
| G5 | Sales (R4b) | discovery | Not named | Must-have at unclear | Deal, renewal or pricing input you gave | A deal or renewal you helped close | `[grounded]` CV silence |
| G6 | Adoption metrics (R6) | discovery | SQL only | Important at unclear | A usage query, report or dashboard you built | The query or dashboard | `[grounded]` CV; `[inferred]` SQL as a route |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Roadmap authority not stated | unknown | — | "Own the roadmap for our partner-facing API platform" | The role may carry roadmap accountability without decision rights over build | `[inferred]` from ownership language against silence on authority | Which roadmap decisions does this role make alone, and which go to leadership or the squads? | unresolved |
| RR2 | Two squads with no reporting line | risk_signal | medium | "drive delivery with two engineering squads" | The role may drive delivery without line authority over the squads | `[generic]` pattern for PM roles of this shape, not a claim about this employer | Do the squads report to this role, and who sets their sprint priorities? | unresolved |
| RR3 | Employer not established | risk_signal | medium | "Quartzline (B2B logistics-tech, ~150 people, Series B)" | The posting may be stale or aggregated, or the company may be smaller or newer than described | `[generic]` pattern for companies of this size, not a claim about this one; research refused, so unverified rather than failed | Can you confirm the role on your careers page, and who would I interview with? | unresolved |
| RR4 | No pay stated | unknown | — | (posting silent on pay) | Pay may sit outside the market band, or may simply be withheld | `[inferred]` from the posting's silence; band not run | What is the base range for this role? | unresolved |
| RR5 | Adoption metrics named | positive_signal | — | "define and track adoption metrics" | Success is at least partly defined | `[grounded]` posting | What adoption figure would you call a good first year? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Lead with your sentence: "Led roadmap-input sessions collecting client feedback for product." | Nearest product-facing line you have (R7, R10) | `[grounded]` your CV, quoted | Pending your approval |
| A2 | Describe the work as "implemented 30+ client integrations of the vendor's REST APIs end to end." Do not describe it as owning the product. | R2 and R1b: keeps the claim at adjacent | `[grounded]` your CV, quoted | Pending your approval |
| A3 | Do not put "product manager" or "product owner" in your title or summary. | R1b: the title is absent | `[inferred]` from the posting's titled requirement | Pending your approval |
| A4 | Paste the live posting link before you apply. | RR3: verifies the employer and posting | `[generic]` pattern for postings at companies of this size | Pending your approval |

## Evidence status

Verified: none yet. Your CV claims are self-reported and unprobed. Unverified lead: a memory note that you built an internal request-triage tool that support agents adopted. It is not counted as evidence and prompts Q2 only. Rejected inferences: none.

Research tier: L1 — searches 3 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches for Quartzline and its posting; search permission was not granted, so nothing returned. Would have moved RR3 and the contradictions row. |
| 2. Role-family sweep | unavailable | One search for partner-API product roles, for scope and pay; permission not granted. Would have moved the market calibration and RR4. |
| 3. Hiring manager's public footprint | n/a | No name given, so there was no query to form. |

I did not retry the searches or switch to another tool after the refusal.

## Upgrade menu

- Permission to run the remaining L1 searches (2 searches, 2 fetches left in budget). They would settle RR3 and give a pay band. Alternatively, paste the live posting link: a link you give me is read without charge and checks the posting directly.
- An answer to Q1 moves R10 and R1a.
- An answer to Q2, with adoption evidence, could move R2 toward direct.
- Pay range, location, contract type and start date. These are the gate inputs; without them the hard-gates line stays unknown.
- A sales-side deal or renewal you helped with (R4b), and a usage query or dashboard you built (R6).

If you want this kept, I can write it out as `tuesday-dossier.md` with the full structured record.

1. **R10 and R1a:** Describe one product decision on an API platform or client build that you shaped. What did you decide yourself, what did the product owner or leadership decide, and what happened after?
2. **R2:** I have an unconfirmed note that you built an internal request-triage tool that support agents adopted. Is that accurate? If so, who used it, what did you own, and how do you know they used it?
3. **R5:** Which delivery cadence did your engineering teams run, and what did you own in it: backlog, sprint planning, or release decisions?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.