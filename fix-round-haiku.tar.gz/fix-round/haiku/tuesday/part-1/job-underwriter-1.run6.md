**Yes, apply, but verify the posting first. You fit the core of this role. The gaps are healthcare and two responsibilities the material doesn't cover. Status: `conditional_go`.**

**Fit ledger.**

- `must_have`: direct: R1, R2, R3, R4, R5
- `important`: direct: R7 · unclear: R6 (metrics layer ownership), R9 (mentoring junior analysts) · adjacent: R8 (clinician partnership) · absent: R11 (care-navigation domain)
- `preferred`: adjacent: R10 (HIPAA or healthcare data)

R1, R2, R3, R4 and R5 are your stated core and rest on self-report, so each will be probed. R6 and R9 are the two open answers. R10 is the bridge, and its limit is named. R11 is the real gap.

**Opportunity ledger.** The scope is concrete (RR2). The unknowns are pay, location, contract type and whether the employer is verifiable (RR1, RR3). I found no red flags.

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the posting is confirmed live on Harborlight's own careers site (RR3); (2) R6 and R9 come back as owned, or at least don't collapse under questioning; (3) you present R10 and R11 as the limited bridge they are, never as healthcare experience.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, digital-health scale-up, ~400 people, Series C | `[grounded]` posting header; existence not established (see Evidence status) |
| Product | Care-navigation app | `[grounded]` posting |
| Mandate | Own product analytics: metrics layer, A/B tests, Looker dashboards, partnering with PMs and clinicians, mentoring two junior analysts | `[grounded]` posting |
| Scope read | Coherent senior-IC remit with mentoring added, not a bundle of roles | `[inferred]` from the responsibility list |
| Market calibration | Not established. No role-family search ran, so there is no pay band | — |
| Compensation, location, contract type | Absent from the posting | `[grounded]` absence |
| Unknowns | Pay, location, contract type, employer verification, how mature the existing metrics layer is, how much clinicians are involved | — |
| Contradictions | None visible within the posting | `[grounded]` |

## Evidence map

Confidence is capped at `medium` for every row drawn from your intake, since intake prose is self-report. Your claims are specific but have no inspectable artifact yet.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | Six years at one consumer-subscription company, stated at intake | `[grounded]` your background | none |
| R2 | Expert SQL | must_have | direct | medium | none | Daily SQL on Snowflake. "Expert" is the claim to probe | `[grounded]` your background | Share one sanitized query a stakeholder relied on |
| R3 | Experiment design and analysis at scale | must_have | direct | medium | none | 30+ tests a year, including the pricing test behind an 11% retention lift. The scale is consumer, not clinical | `[grounded]` your background | A sanitized test design or readout raises this to high |
| R4 | Looker or similar BI tool; self-serve dashboards | must_have | direct | medium | none | Built the company's Looker instance from scratch; 40+ governed dashboards | `[grounded]` your background | A dashboard screenshot raises this to high |
| R5 | Strong written communication to non-technical stakeholders | must_have | direct | medium | none | You write the monthly metrics memo the exec team reads and present it to the VP Product monthly | `[grounded]` your background | A redacted memo excerpt raises this to high |
| R6 | Define and maintain the metrics layer | important | unclear | low | discovery | Dashboards and a memo imply definitions, but nothing says you owned canonical ones. Left `unclear` rather than `adjacent` until answered | `[inferred]` from dashboards and memo | G1 |
| R7 | Partner with PMs and leadership on roadmap decisions | important | direct | medium | none | Monthly presentation to the VP Product. No roadmap decision is named as an outcome yet | `[grounded]` your background | Name one roadmap decision your analysis changed |
| R8 | Partner with clinicians | important | adjacent | low | transferability | Cross-functional work with PMs and execs carries over. No clinician work, and no clinical context | `[inferred]` from R5 and R7 | G3 |
| R9 | Mentor two junior analysts | important | unclear | none | discovery | Nothing in the material | — | G2 |
| R10 | HIPAA or healthcare data experience | preferred | adjacent | medium | transferability | Consent-state model and GDPR/CCPA PII handling are the same governance work HIPAA requires. The limit: HIPAA's PHI and covered-entity rules, which you haven't worked under. The bridge is governance, not HIPAA | `[inferred]` adjacency from your consent work; HIPAA specifics `[generic]` | G4 |
| R11 | Care-navigation and clinical domain knowledge | important | absent | medium | capability | You state you have never worked in healthcare. The gap is firm because the evidence is an explicit statement, not an inconclusive search. Requirement inferred from "care-navigation app" and the clinician partnership | `[grounded]` your statement; closure path `[generic]` | G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Metrics layer (R6, important) | discovery | Governed dashboards and a metrics memo; no mention of owning canonical definitions | The JD centers the metrics layer. Ownership decides whether R6 is direct | Defining the retention or conversion metrics the exec memo reports; a metric dictionary or semantic-layer model; settling a definition dispute | A metric glossary, a LookML model excerpt, or the memo's definitions section | `[grounded]` absence at intake; `[inferred]` that the layer is central |
| G2 | Mentoring (R9, important) | discovery | Nothing | A stated responsibility with no evidence either way | Onboarding an analyst; reviewing someone's SQL; running a team analysis review | An onboarding plan or a review note | `[grounded]` absence |
| G3 | Clinician partnership (R8, important) | transferability | Cross-functional work with PMs and execs; no clinicians | The limit is the point: the stakeholder group changes | Shaping an analysis with operations, legal, support or another regulated team | A project brief where a non-analytics expert changed the analysis | `[inferred]` bridge from R5 and R7 |
| G4 | Healthcare data and domain (R10 preferred, R11 important) | transferability / capability | Consent and PII governance; no PHI, no clinical work | Preferred for R10; the domain gap in R11 is real and will come up in the first year | Any sensitive-data access control or privacy review; the consent-state model's access and deletion rules | Those control definitions; a short domain ramp | `[grounded]` your statements; `[generic]` that healthcare hiring probes this |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay, location and contract type absent | unknown | — | Posting has no compensation, location or contract terms | The terms may come at a recruiter screen, or the employer may withhold them | `[generic]` pattern that postings often omit pay until screening | What is the base salary range, location and contract type for this role? | unresolved |
| RR2 | Scope and outcomes are concrete | positive_signal | — | "define and maintain the metrics layer … mentor two junior analysts" | Authority over the metrics layer is the question, not the scope | `[grounded]` posting | Which metrics-layer decisions does this role make alone, and which go to product or leadership? | noted |
| RR3 | Employer not established | risk_signal | medium | "Harborlight Health (digital-health scale-up, ~400 people, Series C)" | The employer and posting are unchecked. This is not a finding of fraud; the search was refused | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on Harborlight's own careers site, and who would I be interviewing with? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Verify the posting on Harborlight's careers site before tailoring | RR3 | `[grounded]` RR3 | pending your approval |
| E2 | Resume line: "Built the company's Looker instance from scratch, with 40+ governed dashboards." | R4 | `[grounded]` your sentence, trimmed | resume_edits_pending_approval |
| E3 | Resume line: "Designed and ran the experimentation program: 30+ A/B tests a year, including the pricing test behind an 11% retention lift." | R3 | `[grounded]` your sentence | resume_edits_pending_approval |
| E4 | Resume line: "Built the consent-state model for the warehouse and handled GDPR and CCPA consumer PII." | R10 | `[grounded]` your sentence | resume_edits_pending_approval |
| E5 | Positioning: lead the cover note with the monthly exec memo, the strongest evidence for R5 | R5, R7 | `[grounded]` your background | pending your approval |
| E6 | Do not claim, until G1 to G4 answer: "healthcare experience", "clinical", "HIPAA", or "owned the metrics layer" | R6, R10, R11 | `[grounded]` rows above | guidance, no approval needed |

## Evidence status

Verified: none yet. Every claim is self-reported at intake. Unverified leads: none. Rejected inferences: none.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Web search was refused in this session (3 calls). Employer existence and posting liveness are not established. Moves RR3 |
| 2. Role-family sweep | unavailable | Same refusals. Would have set the market calibration and the comparison for RR1. No pay band is given here, because model memory is not a source for market values |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

If you want this kept, I can write it up as a `tuesday-dossier.md` file.

## Upgrade menu

- The posting link from Harborlight's careers site → RR3 closes, and the decision can move toward `go`.
- A pay band, location and contract type, from the posting or a recruiter → RR1 closes, and the hard-gate line can check them.
- Your own constraints (pay floor, location, contract type, schedule) → the hard-gate line checks them. Right now those checks are unknown.
- Permission to web search, or a page you name → targets 1 and 2 run, which moves RR3 and the market calibration.
- A sanitized SQL query, test readout, dashboard screenshot or memo excerpt → raises R2, R3, R4 and R5 to high.

## Questions

G1 — Did you own the canonical metric definitions behind the exec memo, or did you use definitions someone else set? If you wrote or signed one, name it and who approved it.

G2 — Have you managed or mentored junior analysts? What did you do with them, and over what period?

RR3 — Can you paste the posting link from Harborlight's careers site, and the name of the recruiter or hiring manager if you have it?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.