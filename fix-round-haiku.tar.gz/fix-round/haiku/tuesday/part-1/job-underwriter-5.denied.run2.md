**Yes, worth applying, once two things check out. Status: `conditional_go`.** The must-haves match your background closely. Two posting terms, location and pay, can't be checked until you tell me your constraints. The employer itself is unverified because my search was refused.

**Fit ledger.**

- `hard_gate` — unclear: R1 (remote US or Denver), R2 (pay $148,000–$166,000)
- `must_have` — direct: R3 (5+ years data engineering), R4 (strong SQL and Python), R5 (dbt and a cloud warehouse), R6 (orchestration with Airflow or similar), R7 (data quality testing)
- `important` — adjacent: R10 (BigQuery); unclear: R8 (ingestion from our app and CRM), R9 (data contracts our analysts depend on)

R8 and R9 are the rows to close first. R10 is the one to frame honestly as transfer, not as experience. R1 and R2 turn on constraints you haven't given me.

**Opportunity ledger.** Mostly sound. The salary range sits near the market median to the top of the interquartile range (RR2, positive). The employer is not verified externally (RR1, standing entry). BigQuery appears in the role description rather than the requirements list, so it may or may not be a real requirement (RR3).

- **Hard gates:** none failed; unconfirmed: R1 (remote US or Denver), R2 ($148,000–$166,000); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **Conditions for go:** (1) the posting is live on Pellucid's own careers page and the employer checks out (RR1); (2) your location and pay floor fit R1 and R2; (3) the BigQuery gap is stated plainly as transfer from Snowflake (R10).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 states; founded 2016, Denver; 264 employees; Series C, $52M, February 2026 | `[grounded]` the company page you pasted; not checked against an outside source |
| Mandate | Build and run ingestion from the app and CRM, a dbt-modelled warehouse in BigQuery, and data contracts for analysts | `[grounded]` JD |
| Scope read | Ownership of reporting pipelines and contracts; no direct reports stated | `[inferred]` from the JD; consistent with the scope norm below |
| Market calibration | Base median $151,000; interquartile range $139,000–$163,500. The posting's $148,000–$166,000 spans roughly the median to the top of that range | `[generic]` Datawright 2026 report you supplied (n=2,310, Series B–D) |
| Seniority | "Senior" typically means 5–8 years in that report; the posting asks for 5+ | `[generic]` same report |
| Unknowns | Equity value and vesting; whether BigQuery is required; whether the ingestion and contract work is owned or shared; team size; no hiring manager named | — |
| Contradictions | None between the JD and the company page as pasted | `[grounded]` both pasted; not checked live |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote US or Denver office | hard_gate | unclear | none | hard_gate | Your location and work setup weren't given | `[grounded]` JD | Confirm (Q3) |
| R2 | Pay $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | Your pay floor wasn't given; the band is near market median | `[grounded]` JD; `[generic]` band | Give your floor (Q3) |
| R3 | 5+ years data engineering | must_have | direct | medium | none | Six years at a B2B payroll company; prose background, no artifact | `[grounded]` your background | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | Daily use stated; no artifact | `[grounded]` your background | Attach a sample query or repo to reach high |
| R5 | dbt and a cloud warehouse | must_have | direct | medium | none | ~180-model dbt project on Snowflake | `[grounded]` your background | none |
| R6 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow stated | `[grounded]` your background | none |
| R7 | Data quality testing | must_have | direct | medium | none | Great Expectations suite set up; scope of ownership not stated | `[grounded]` your background | Ask G1-style: what it covered, who relied on it |
| R8 | Ingestion from app and CRM | important | unclear | low | discovery | Not in your background | `[inferred]` from the JD's ingestion requirement | Q1 |
| R9 | Data contracts analysts depend on | important | unclear | low | discovery | Not in your background | `[inferred]` from the JD | Q2 |
| R10 | BigQuery (named in the role description) | important | adjacent | medium | transferability | Snowflake in production; BigQuery never used. The limit is no BigQuery exercise, and the dialect and tooling differ; SQL and dbt carry over | `[inferred]` adjacency from your Snowflake and dbt work; `[generic]` that dbt is warehouse-portable | G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Ingestion from app and CRM (R8) | discovery | No ingestion work in your background | Named in the first duty of the role | Pipelines from a product database or a CRM, or payroll-data syncs into a warehouse | A pipeline diagram, DAG list, or config excerpt | `[inferred]` from the JD |
| G2 | Data contracts (R9) | discovery | No contracts or consumer agreements mentioned | Named as what analysts depend on | Schema agreements, versioned tables, breaking-change handling | A contract doc, schema-change review, or incident note | `[inferred]` from the JD |
| G3 | BigQuery (R10) | transferability | Snowflake production work; no BigQuery | Named in the role description | A small BigQuery project or a dbt model ported to it | One model on BigQuery, or a dialect-migration note | `[generic]` that the move is mostly dialect and tooling |

The queue has no questions. The questions for G1 and G2 are in the closing block.

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer and posting not verified externally | risk_signal | medium | "Senior Data Engineer — Pellucid Learning" | The check was not run; searches were refused. This is not evidence of absence | `[generic]` pattern for companies of this size, not a claim about this one | "Is this role open now on your careers site, and who would I interview with?" | unresolved |
| RR2 | Salary range near market median to top of IQR | positive_signal | — | "$148,000–$166,000 plus equity" | Pay is credible for the seniority; equity value unknown | `[generic]` Datawright band | "Is $148,000–$166,000 the approved budget for this level?" | noted |
| RR3 | BigQuery in role description, not requirements | unknown | — | "a dbt-modelled warehouse in BigQuery" | May be a hard requirement or just the current stack | `[inferred]` from the JD's split between description and requirements | "Is BigQuery experience required, or is Snowflake experience with a move to BigQuery acceptable?" | unresolved |
| RR4 | Equity unquantified | unknown | — | "plus equity" | Value unknown; could be a meaningful part of pay | `[inferred]` | "What is the equity grant, vesting schedule, and valuation basis?" | unresolved |
| RR5 | No hiring manager or team named | unknown | — | (none) | Team size and ownership unclear | `[generic]` | "Who owns these pipelines day to day, and how large is the team?" | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm the role is live on Pellucid's careers site before applying | RR1 | `[grounded]` | pending your approval |
| A2 | Cover-letter line on BigQuery, proposed: "I haven't run BigQuery in production. My dbt and SQL work is on Snowflake, and I'd expect the move to be mostly dialect and tooling." | R10 | `[inferred]` from your Snowflake work; the expectation is your view | pending your approval |
| A3 | Keep "set up our Great Expectations test suite" as written. Don't upgrade it to "owned data quality" unless you can say what you owned | R7; reframing audit | `[grounded]` | pending your approval |
| A4 | Ask the RR3 and RR4 questions in the recruiter screen | RR3, RR4 | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Both searches were refused by the permission gate, so nothing returned. The employer is unverified, which is RR1 |
| 2. Role-family sweep | skipped | The Datawright report you supplied already fixes the band, the seniority norm and the scope norm |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

## Upgrade menu

- A link to the live posting or the careers page → RR1 closes, and target 1 can run.
- Your location, pay floor, and any other non-negotiables → R1 and R2 close.
- Concrete examples of ingestion or data contracts → R8 and R9 move from unclear.
- A sample dbt model, query, or repo, on Snowflake or BigQuery → R4, R5 and R10 move toward high.
- A retry of the employer check (two searches, if search permission is granted) → target 1 runs.

If you want the analysis carried into interview prep, I can emit it as `tuesday-dossier.md`; say the word.

**Questions:**

G1 — Have you built ingestion from an application database or a CRM into a warehouse? Which sources and tools, and what did you own end to end?

G2 — Have you defined data contracts (schemas, freshness commitments, versioned interfaces) that analysts or product teams depended on? What broke, and how did you handle changes?

Q3 — Are you based in the US, and are remote-US or Denver work and a $148,000–$166,000 range (plus equity) compatible with your constraints? Is any of that non-negotiable, and what is your pay floor?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.