## Decision snapshot

**Yes, apply, on conditions. Status: `conditional_go`.** Your operational core matches what the posting asks for. The two things you have not done, owning the forecast and working with billing data, are must-haves, but neither is a hard gate. You can show your way through them in the process rather than treat them as reasons to stop.

**Fit ledger.**
- `hard_gate`: unclear: R10 (Bristol, two days a week in office), R11 (salary £61,500–£67,000 plus share options)
- `must_have`: direct: R1 (4+ years in revenue or sales operations), R3 (HubSpot or Salesforce administration), R4 (strong SQL); adjacent: R2 (B2B software company), R6 (owning a forecast); unclear: R5 (spreadsheet modelling), R7 (working with finance on revenue data); absent: R8 (billing data)
- `important`: direct: R9 (building pipeline and renewal reporting)

R6 is `medium`: the monthly pipeline review is adjacent input to a forecast, not ownership of one. R8 is `none`: there is no billing-data work to point to.

**Opportunity ledger.** The salary is stated and sits near the market median (RR3, positive). The scope bundles RevOps, billing data and the forecast into one role (RR1). The reporting line is not given (RR2). I have not confirmed the role on Quillfield's own careers page (RR4).

- **Hard gates:** none failed; unconfirmed: R10 (Bristol, two days a week in office), R11 (salary £61,500–£67,000 plus share options); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) R6 and RR1: the forecast is at least shared with finance, and you can explain how your pipeline review feeds the number. (2) R8: billing data is set up as something you learn with finance, not something you are expected to already know. (3) R10 and R11 work for you. (4) You do not claim forecasting or billing experience you don't have.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quillfield: invoicing and payments software for UK builders' merchants, Bristol, founded 2018, 96 employees, £11M Series A in April 2025 | `[grounded]` company about page (search snippet, not opened) |
| Mandate | Own CRM and billing data; build pipeline and renewal reporting; run the quarterly revenue forecast with the CFO | `[grounded]` posting |
| Working pattern | Bristol hybrid, two days a week in the office | `[grounded]` posting |
| Pay | £61,500–£67,000 plus share options | `[grounded]` posting |
| Market calibration | UK revenue operations lead, B2B software (n=438): median £64,200, interquartile range £57,800–£70,400 | `[generic]` Ledgerline 2026 pay guide; a band, not this employer's offer |
| Scope read | The role combines revenue operations, finance-side billing data and forecasting | `[inferred]` from the posting's scope |
| Hiring manager | Tamsin Achebe, Head of Revenue Operations at Quillfield; previously sales operations manager at Corvane Payments for four years | `[grounded]` profile search snippet (not opened) |
| Unknowns | Reporting line; who signs off the forecast; billing system in use; value of share options | — |
| Contradictions | None found among the sources read | `[grounded]` posting and company about page |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 4+ years in revenue, sales operations or analytics | must_have | direct | medium | none | Five years in sales operations, last two running UK revenue operations; self-reported | `[grounded]` your account | none |
| R2 | Experience at a B2B software company | must_have | adjacent | medium | transferability | Five years at a B2B payments company. Quillfield also sells payments, so the overlap is real, but payments is not software | `[inferred]` from both companies' descriptions | Describe your company's product area exactly as it was |
| R3 | HubSpot or Salesforce administration | must_have | direct | medium | none | Salesforce admin certified | `[grounded]` your account | Certificate copy would raise to high |
| R4 | Strong SQL | must_have | direct | medium | none | SQL weekly | `[grounded]` your account | A redacted query or dashboard would raise to high |
| R5 | Spreadsheet modelling | must_have | unclear | low | discovery | Excel daily, but no modelling is described | `[grounded]` your account; gap is `[inferred]` | Q3 below |
| R6 | Owning a forecast | must_have | adjacent | medium | transferability | You run the monthly pipeline review with your sales director, but have never owned the company forecast. Limit: no forecast ownership and no finance sign-off | `[grounded]` your account; adjacency `[inferred]` | Explain the pipeline review as input, never as ownership |
| R7 | Working with finance on revenue data | must_have | unclear | low | discovery | Renewal dashboards are revenue-adjacent; no finance collaboration is described | `[grounded]` your account | Q2 below |
| R8 | Billing data | must_have | absent | none | capability | No billing-data work, as you stated | `[grounded]` your account | Closure path in the queue |
| R9 | Building pipeline and renewal reporting | important | direct | medium | none | You rebuilt both dashboards | `[grounded]` your account | none |
| R10 | Bristol hybrid, two days a week in office | hard_gate | unclear | none | hard_gate | Your location and constraints were not given | `[grounded]` posting | Q1 below |
| R11 | Salary £61,500–£67,000 plus share options | hard_gate | unclear | none | hard_gate | Your floor was not given. The band is `[generic]` against median £64,200 | `[grounded]` posting | Q1 below |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | What would close it | Provenance |
|---|---|---|---|---|---|
| G1 | Spreadsheet modelling (R5) | discovery | Excel used daily; no model described | An example model, even an unofficial one | `[grounded]` your account |
| G2 | Owning a forecast (R6) | transferability | Pipeline review with the sales director; no forecast ownership | A description of how a pipeline call reached a number, and who used it | `[grounded]` your account; `[inferred]` that this is the closest bridge |
| G3 | Revenue data with finance (R7) | discovery | Renewal dashboards exist; no finance work described | Any reconciliation or revenue-reporting work | `[grounded]` your account |
| G4 | Billing data (R8) | capability | None | A realistic path: learn the billing data model with finance in the first months, and say so plainly | `[grounded]` your account; path `[generic]` |
| G5 | B2B software experience (R2) | transferability | Payments company; Quillfield sells payments too | State the product area accurately | `[inferred]` |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Bundled scope: RevOps, billing data and the forecast in one role | risk_signal | medium | "own our CRM and billing data … run the quarterly revenue forecast with the CFO" | The role may blend RevOps with finance-systems and planning work | `[inferred]` from the posting's scope | Which parts of the forecast does this role own outright, and which does finance sign off? | unresolved |
| RR2 | Reporting line not stated | unknown | — | "Revenue Operations Lead" (no reporting line given) | The role may report into revenue operations or into finance | `[inferred]` from the posting's silence | Who does this role report to day to day? | unresolved |
| RR3 | Salary stated and near the median | positive_signal | — | "£61,500–£67,000 plus share options" | The posted range sits within the interquartile band | `[generic]` one pay guide | Is this band fixed, and how do share options vest? | noted |
| RR4 | Careers page not checked for this live posting | unknown | — | Posting is on a third-party board | The employer is real (about page) but the role is unconfirmed on its own site | `[grounded]` search results | Is this role live on your careers site, and is this the same job description? | unresolved |

## Application plan (proposed, pending your approval)

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Lead with the pipeline and renewal dashboards and the Salesforce certification | Direct evidence; R3, R9 | `[grounded]` your account | pending your approval |
| A2 | Describe the pipeline review as input to forecasting, not as forecasting | R6 is adjacent, not owned | `[grounded]` your account | pending your approval |
| A3 | Ask the recruiter the RR1, RR2 and RR4 questions before the first interview | Those answers could move the decision | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Everything above rests on your account and on what I read.

Research tier: L1 — searches 3 of 5, fetches 0 of 2; user links read 1

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Quillfield invoicing software company Bristol"; the result was quillfield.co.uk/about (not opened). Confirms the employer exists as described. The live role on its careers page was not checked |
| 2. Role-family sweep | yes | Searched "revenue operations lead salary UK B2B software £60,000 £70,000"; the result was the Ledgerline 2026 UK Revenue Operations Pay Guide (not opened). Moved market calibration in role reality |
| 3. Hiring manager's public footprint | yes | Searched "Tamsin Achebe Quillfield"; the result was her profile snippet (not opened). Moved the positioning: her profile shows a path from sales operations at a payments company into revenue operations, the same shape as yours `[inferred]` |

## Upgrade menu

- A Salesforce certificate copy, or a redacted dashboard screenshot: R3 to `high`.
- A redacted SQL query or dashboard you built: R4 to `high`.
- Any spreadsheet model you built, even an unofficial one: R5 moves.
- The recruiter's answer on forecast sign-off: R6 and RR1 close.
- The recruiter's answer on the billing system and first-months plan: R8 and RR2 move.
- The live careers-page listing: RR4 closes.
- A deeper research pass on Quillfield (funding and leadership changes, past postings, public candidate reports; up to 5 more searches and 2 more fetches). Say the word and it runs.

If you want to reuse this across rounds, I can write it up as a `tuesday-dossier.md`.

**Questions** (tagged to their rows):

- Q1 (R10, R11): Can you work in Bristol two days a week, and is £61,500–£67,000 above your floor?
- Q2 (R7, R8): Have you touched any revenue data finance used, such as renewal values checked against invoices, or payment and collection reporting? Describe what you did, not the title. Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.
- Q3 (R5): Have you built a spreadsheet model with inputs and assumptions, such as a pipeline-to-revenue scenario or a renewal forecast, even one that was never official? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.