**Yes, worth applying, with two quick checks first.** Status: `conditional_go`.

**Decision snapshot**

- **Fit ledger.**
  - `hard_gate`: unclear: R1 (remote US or Denver location), R10 (salary band against your floor)
  - `must_have`: direct: R2, R3, R4, R6, R7
  - `important`: adjacent: R5 (BigQuery, the warehouse the job runs on) · unclear: R8 (ingestion from app and CRM), R9 (data contracts analysts depend on)

  The five must-haves R2, R3, R4, R6 and R7 are all `direct` at `medium`, because your background is intake prose and nothing has been inspected yet. R5 is the one adjacent row. R8 and R9 are the two unknowns in the scope.
- **Opportunity ledger.** Sound but under-specified. The posting states pay and a clear stack (RR4). The employer and posting are unverified this session (RR1), and the team shape is unstated (RR2). No red flags.
- **Hard gates:** none failed; unconfirmed: R1 (remote US or Denver location), R10 (salary $148,000–$166,000 against your floor); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) location and salary floor confirmed (R1, R10); (2) posting confirmed live on the company's own careers page (RR1); (3) ingestion and contracts answered in interview (R8, R9, RR2).

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning, live online tutoring for K-12 in 31 states, Series C | `[grounded]` the about page you pasted; not verified (see RR1) |
| Scope | Build and run ingestion, a dbt warehouse on BigQuery, and data contracts | `[grounded]` posting |
| Pay | $148,000–$166,000 plus equity; midpoint $157,000 | `[grounded]` posting |
| Market | Base median $151,000; IQR $139,000–$163,500 | `[generic]` Datawright report you pasted, n=2,310 |
| Unknowns | Team size, reporting line, hiring manager, equity terms | — |
| Contradictions | None between the posting and the about page | `[grounded]` both pasted |

The posting's range sits inside the market IQR, and its midpoint is above the median. The range is in line with the market; it is not a premium.

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote US or Denver location | hard_gate | unclear | none | hard_gate | Your location is not in the material | `[grounded]` posting | Q1 |
| R2 | 5+ years data engineering | must_have | direct | medium | none | Six years, self-reported | `[grounded]` intake | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | Daily use, self-reported | `[grounded]` intake | none |
| R4 | dbt and a cloud warehouse | must_have | direct | medium | none | dbt on Snowflake, about 180 models | `[grounded]` intake | none |
| R5 | BigQuery warehouse (in the responsibilities) | important | adjacent | medium | transferability | Warehouse-platform work carries over from Snowflake; you have never used BigQuery | `[inferred]` from R4 | G1 |
| R6 | Airflow or similar orchestration | must_have | direct | medium | none | Airflow orchestration, self-reported | `[grounded]` intake | none |
| R7 | Data quality testing | must_have | direct | medium | none | Set up a Great Expectations suite, self-reported | `[grounded]` intake | none |
| R8 | Ingestion from app and CRM | important | unclear | low | discovery | Not in your background | `[grounded]` absence | Q3 |
| R9 | Data contracts analysts depend on | important | unclear | low | discovery | Not in your background | `[grounded]` absence | Q3 |
| R10 | Salary band | hard_gate | unclear | none | hard_gate | Your floor is not given | `[grounded]` posting | Q2 |

**Gap recovery queue**

- **G1** (R5, transferability): Snowflake and dbt carry over. Your limit is that you have never run BigQuery in production. Say that plainly, and the bridge holds. A short BigQuery project would narrow the limit. Do not describe it as BigQuery experience.

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer and posting not verified this session | unknown | — | "Series C ($52M, February 2026)" | Web search was refused, so attribution is unconfirmed, not failed | `[grounded]` search refused | "Is this role still open, and is it on your careers page?" | unresolved |
| RR2 | No hiring manager, team size or reporting line | unknown | — | Posting names no hiring manager | Could be a one-person data function | `[inferred]` from the posting's silence | "Who would I report to, and how many people run these pipelines today?" | unresolved |
| RR3 | Build-and-run scope with no stated headcount | risk_signal | low | "Build and run the pipelines" | If the function is small, on-call and sole ownership follow | `[inferred]` from the posting's scope | "Is this the only data engineer, and what is the on-call expectation?" | unresolved |
| RR4 | Pay stated and in line with market | positive_signal | — | "$148,000–$166,000 plus equity" | Pay is in line with the band | `[generic]` band against `[grounded]` figure | "How is equity valued, and what is the vesting schedule?" | noted |

**Application plan** (all proposed, pending your approval)

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Open the careers page yourself and confirm the posting is live | see RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Frame BigQuery as adjacent: "Snowflake and dbt, not BigQuery yet" | see R5 | `[grounded]` R5 | pending your approval |

**Evidence status**

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Both searches were refused, so employer existence and posting liveness are unconfirmed (RR1) |
| 2. Role-family sweep | skipped | The Datawright figures you pasted fix the band, so no call was sent |
| 3. Hiring manager's public footprint | n/a | No name was given |

Verified: none yet.

**Dossier offer:** I can write this up as a `tuesday-dossier.md` for your prep files if you want it.

**Upgrade menu**

- Web search access: would verify the employer and posting (RR1), the single most useful unlock.
- Your location and pay floor: R1 and R10 close.
- A BigQuery project or course: R5 moves from adjacent toward direct.
- Ingestion or data-contract examples: R8 and R9 close.

**Questions**

- **Q1 (R1):** Is your location compatible with remote US work or the Denver office? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.
- **Q2 (R10):** Is $148,000 base within your floor? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.
- **Q3 (R8, R9):** Have you built ingestion from an application database or CRM, or owned data contracts with consumers? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.