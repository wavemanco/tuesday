**Not a waste of time, but a stretch: `conditional_go`, and the condition sits on R1a, your missing product-manager title.**

**Fit ledger.**

- `must_have`: direct: R3, R4a · adjacent: R1b (product decisions), R2 (platform or API products) · unclear: R4b (sales), R5 (agile delivery) · absent: R1a (3+ years product management)
- `important`: direct: R6 · adjacent: R8 (launch coordination), R9 (written specs) · unclear: R7 (adoption metrics)

R1a is the literal years line. R2 is client-side delivery, not platform ownership. R4b and R5 are unknown, not weak. R7 rests only on an unconfirmed note from a past conversation.

**Opportunity ledger.** The scope is concrete: two engineering squads and adoption metrics named as a deliverable (RR3). Who sets priorities is unknown (RR2). The posting's literal years line is a screen risk (RR1).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the employer confirms equivalent product-scope experience counts against R1a (RR1); (2) R5 gets a concrete answer on delivery cadence; (3) R7 is confirmed in specifics before you use it anywhere.
- **What would change this:** a recruiter saying the 3-year line is a hard filter with no equivalence path turns this into `no_go` for this posting. Confirmed R7 evidence moves R7 up and strengthens R1b.

**Research tier: L0 — no searches this pass.** I have not verified that Quartzline exists or that the posting is live. The employer check is therefore open, not cleared.

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline, B2B logistics-tech, ~150 people, Series B | `[grounded]` your paste |
| Mandate | Own the roadmap for the partner-facing API platform; two engineering squads | `[grounded]` JD |
| Scope read | Normal for a platform PM at this stage | `[generic]` role-family pattern, not checked by search |
| Compensation | Not in the posting as pasted | — |
| Unknowns | Decision rights over priorities; whether this is a first PM on the platform; pay | — |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1a | 3+ years product management | must_have | absent | medium | transferability | No PM title held; self-reported in the CV | `[grounded]` CV | Ask recruiter whether equivalence counts (RR1) |
| R1b | Product decisions: roadmap input, requirements, delivery coordination | must_have | adjacent | medium | transferability | Ran roadmap-input sessions and wrote requirements. Limit: the record does not show you set priorities or owned outcomes | `[grounded]` CV, `[inferred]` adjacency | Q1 |
| R2 | Shipped API or platform products | must_have | adjacent | medium | transferability | 30+ REST integrations taken to go-live. Limit: you shipped client integrations, not a platform product | `[grounded]` CV | Frame as client-side delivery |
| R3 | Technical fluency: API docs, schemas | must_have | direct | medium | none | Postman, SQL, OpenAPI; integration architecture. Expect a schema walkthrough probe | `[grounded]` CV | Prepare a schema example |
| R4a | Stakeholder management: engineering and customers | must_have | direct | medium | none | Coordinated your engineers, client engineers and PMs on custom builds | `[grounded]` CV | none |
| R4b | Stakeholder management: sales | must_have | unclear | low | discovery | CV is silent on sales | `[grounded]` CV silence | Q3 |
| R5 | Agile delivery | must_have | unclear | low | discovery | CV is silent on cadence or ceremonies | `[grounded]` CV silence | Q2 |
| R6 | Discovery with integration partners | important | direct | medium | presentation | Scoping workshops and requirements with client teams; the CV buries them | `[grounded]` CV | Reword as partner discovery, pending your approval |
| R7 | Define and track adoption metrics | important | unclear | low | discovery | Only a memory lead about a triage tool adopted by support agents. Unverified | `memory_lead` | Q1 |
| R8 | Launch coordination with sales and support | important | adjacent | medium | transferability | Go-live coordination and UAT with client teams. No internal sales or support launch shown | `[grounded]` CV | none |
| R9 | Write specs and drive delivery with engineering squads | important | adjacent | medium | transferability | Wrote requirements and integration architecture for client builds, not internal product specs | `[grounded]` CV | none |

**Gap recovery queue**

- **G1 (R1a):** the years are a fact, so the gap is about how the screen reads them. Closes only if the employer accepts equivalent scope.
- **G2 (R1b, R7):** the one question that could move the decision, since it is the only possible evidence of ownership.
- **G3 (R5):** closes with a concrete delivery-cadence answer.
- **G4 (R4b):** closes with any sales-side coordination example.

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Literal years screen | risk_signal | medium | "3+ years product management experience (must-have)" | A screen may filter on titled years before equivalence is considered | `[generic]` pattern for must-have year lines | "Does product-scope experience from integration work count against the 3-year requirement, and what would you need to see?" | unresolved |
| RR2 | Priority authority unstated | unknown | — | "Own the roadmap" | You may own the roadmap without deciding priorities across the two squads | `[inferred]` from the JD's scope against its silence on decision rights | "Who sets platform priorities, and how much of the roadmap is mine to decide?" | unresolved |
| RR3 | Adoption metrics named as a deliverable | positive_signal | — | "define and track adoption metrics" | The role has a measurable mandate | `[grounded]` JD | "Which adoption metrics already exist, and what is the baseline?" | noted |

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Ask a recruiter or hiring manager whether equivalent product experience counts | RR1, R1a | `[generic]` pattern | pending your approval |
| A2 | Confirm the triage-tool facts before using them anywhere | R7 | `memory_lead` | pending your confirmation |
| A3 | Do not use "product manager" or "owned the roadmap" unless the answers support them. Describe the roadmap-input work as what it was. When you want the resume reshaped for this posting, resume-tailor can do it | R1b | `[grounded]` CV | advice |
| A4 | Seek a referral or warm conversation before applying cold | Cold applications to a literal years line rarely clear the screen | `[generic]` pattern | pending your approval |

If the answer to A1 is "no equivalence," the better move is a PM-adjacent title (integrations or platform PM), where R1b, R2 and R3 fit without a stretch. That is a pattern for solutions and implementation people, not a claim about this employer.

**Evidence status.** Verified: none yet. Unverified lead: the triage tool (R7), which prompts Q1 only.

**Upgrade menu**

- **Employer check (L1 target 1):** confirms Quartzline exists and the posting is live. This clears or triggers the employer check.
- **Market band (L1 target 2):** calibrates the normal years and pay for this title.
- **Pay:** not in the posting you pasted. Paste the full posting if it has pay.
- **Any product artifact** (a prioritized backlog, a roadmap you input to, a playbook section) would raise R1b to high.
- **Triage-tool evidence** (usage numbers, the spec, a before-and-after) would raise R7 and strengthen R1b.
- **Your constraints** (pay floor, location, contract type): if you give them, the hard-gate checks run.

The full first-pass dossier can be saved as a `tuesday-dossier.md` if you want it for later.

**Questions**

- **Q1 (R7, R1b):** Did you build the triage tool your earlier note mentions, or something similar that others adopted? If so, what did it need to do, who used it, and how did you know it worked?
- **Q2 (R5):** How did your integration projects run day to day: sprints, a backlog, a planning cadence? Who owned it?
- **Q3 (R4b):** Have you worked with sales on a customer's scope or go-live, such as commitments or pricing for custom builds? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.