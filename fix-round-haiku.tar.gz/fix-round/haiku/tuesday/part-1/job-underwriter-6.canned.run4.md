**Yes, apply, on conditions. Status: `conditional_go`.** You fit the tooling and the pipeline and renewal side of the role. The forecast and the billing data are where you're weakest, and the posting leads with both, so the application has to be honest about them.

**Fit ledger.**

- `hard_gate`: unclear: R1 (Bristol, two office days a week), R2 (salary £61,500–£67,000)
- `must_have`: direct: R4 (Salesforce admin), R5a (SQL); adjacent: R3 (B2B software experience); unclear: R5b (spreadsheet modelling), R6 (owning a forecast); absent: R7 (billing or revenue data with finance)
- `important`: direct: R9 (pipeline and renewal reporting)

R6 and R7 are the two must-haves you can't claim directly. R3 is adjacent because your employer is a payments company and Quillfield sells invoicing software.

**Opportunity ledger.** The role is clearly scoped and the pay sits mid-band, but the forecast split with finance is unclear (RR1), and the company's billing data is undescribed (RR2). The role is not on Quillfield's own careers page in search results (RR3).

- **Hard gates:** none failed; unconfirmed: R1 (Bristol hybrid, two office days a week), R2 (salary £61,500–£67,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) Quillfield's answer on RR1 shows you would share the forecast with finance, and you can describe your pipeline review as forecast input, not as a forecast you owned; (2) your payments work touched transaction or settlement data close enough to billing that R7 is at least transferable; (3) you can work Bristol two days a week and the salary clears your floor. I don't know your location or floor, so I couldn't check (3).

**Research tier: L1 — searches 4 of 5, fetches 0 of 2; user links read 1**

| Target | Status | What it moved |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Quillfield invoicing software company", which returned quillfield.co.uk/about: invoicing and payments software for UK builders' merchants, Bristol, 96 staff, £11M Series A in April 2025. The employer is established. Searching "Quillfield Revenue Operations Lead job Bristol" returned nothing, so the posting is not confirmed on the company's own site (RR3). |
| 2. Role-family sweep | yes | Searched the scope and pay query, which returned the Ledgerline 2026 UK RevOps pay guide: UK B2B software RevOps lead, median £64,200, interquartile range £57,800–£70,400 (n=438). Market calibration `[generic]`. |
| 3. Hiring manager's public footprint | yes | Searched "Tamsin Achebe Quillfield", which returned a LinkedIn profile for Tamsin Achebe, Head of Revenue Operations at Quillfield. One hit, matched on name and company; not confirmed as the same person beyond that. |

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quillfield, invoicing and payments software for UK builders' merchants, Bristol | `[grounded]` quillfield.co.uk/about; the posting |
| Mandate | Own CRM and billing data; build pipeline and renewal reporting; run the quarterly revenue forecast with the CFO | `[grounded]` the posting |
| Working pattern | Hybrid, two days a week in Bristol | `[grounded]` the posting |
| Pay | £61,500–£67,000 plus share options | `[grounded]` the posting |
| Market calibration | Median £64,200 for UK B2B software RevOps leads; the posted range sits mid-band | `[generic]` Ledgerline 2026 pay guide |
| Hiring manager | Head of Revenue Operations at Quillfield, per one public profile | `[grounded]` LinkedIn result, one hit |
| Unknowns | Where the forecast ownership sits against finance; what billing data the role owns; whether the role is on the company's careers page | — |
| Contradictions | None between the posting and the company's about page | `[grounded]` both fetched or searched |

**Evidence map** (your claims are self-reported; intake ceiling is `medium`)

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Bristol, two office days a week | hard_gate | unclear | none | hard_gate | Your location and commute are not in the material | `[grounded]` posting | Q3 |
| R2 | Salary £61,500–£67,000 plus share options | hard_gate | unclear | none | hard_gate | Your floor is not in the material | `[grounded]` posting | Q3 |
| R3 | 4+ years RevOps or sales ops at a B2B software company | must_have | adjacent | medium | transferability | Five years in sales ops and RevOps at a B2B payments company. Payments is not software, and that difference is the limit | `[grounded]` your intake | Name the limit in the application |
| R4 | HubSpot or Salesforce administration | must_have | direct | medium | none | Salesforce admin certified; the certificate is not inspected | `[grounded]` your intake | Attach the certificate if you want it raised to `high` |
| R5a | Strong SQL | must_have | direct | medium | none | SQL weekly | `[grounded]` your intake | none |
| R5b | Spreadsheet modelling | must_have | unclear | low | discovery | Excel daily; modelling depth is not described | `[grounded]` your intake | Q1 covers the model you built |
| R6 | Owning a forecast | must_have | unclear | low | discovery | You run the monthly pipeline review with the sales director; you have never owned the company forecast | `[grounded]` your intake; `[inferred]` that pipeline review is forecast input | Q1 |
| R7 | Billing or revenue data, working with finance | must_have | absent | none | transferability | You have never worked on billing data. The nearest work is payments data at a payments company | `[grounded]` your intake; `[inferred]` adjacency | Q2 |
| R9 | Pipeline and renewal reporting | important | direct | medium | none | You rebuilt the pipeline and renewal dashboards | `[grounded]` your intake | Attach a dashboard screenshot if you can |

**Gap recovery queue**

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Forecast ownership (R6, must_have) | discovery | Pipeline review with the sales director; no forecast ownership | Decides whether the role's forecast duty is a stretch or a stop | Commit calls in the pipeline review; reconciling pipeline to bookings; any forecast you challenged with finance | A forecast sheet or pipeline-to-actuals reconciliation, anonymised | `[grounded]` intake; `[inferred]` that the pipeline review feeds forecasting |
| G2 | Billing data (R7, must_have) | transferability | Payments company work; no billing | The forecast needs revenue data that finance owns | Settlement or transaction reports; reconciling payments to invoices; renewal data that depends on billing | A sanitised reconciliation or data dictionary | `[inferred]` adjacency between payments and billing data |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Forecast ownership split with finance | unknown | — | "run the quarterly revenue forecast with the CFO" | The lead may co-own the forecast with finance, or may own the number outright | `[inferred]` from the posting's "with the CFO" | Which parts of the quarterly forecast does this role own outright, and which does finance sign off? | unresolved |
| RR2 | Billing data ownership undescribed | unknown | — | "own our CRM and billing data" | The data may be messy, or owned by finance | `[inferred]` from the posting's silence on data quality | What state is the billing data in today, and who maintains the invoicing data model? | unresolved |
| RR3 | Role not found on the company's careers page | risk_signal | low | "Revenue Operations Lead" posted on tallyboard.example | Recruiter-led posting; the company's own page may lag | `[generic]` pattern for job boards and recruiters; not a claim about this company | Can you send the link to this role on Quillfield's own careers page? | unresolved |
| RR4 | Pay mid-band | positive_signal | — | "£61,500–£67,000 plus share options" | Pay is in line with the UK B2B software band | `[generic]` Ledgerline band against the posted range | Is the range fixed, and what do the share options vest into? | noted |

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Describe the pipeline review as forecast input, with the limit stated: you have not owned the company number | see R6, G1 | `[grounded]` R6 | pending your approval |
| E2 | Describe the payments work as adjacent to billing, not as billing | see R7, G2 | `[grounded]` R7 | pending your approval |
| A1 | Ask the recruiter for the careers-page link and the forecast split | see RR1, RR3 | `[grounded]` register | pending your approval |

**Evidence status**

Verified: none yet. Your intake claims are unconfirmed until you answer the questions below.

**Upgrade menu**

- Your answer to Q1 (forecast) → R6 moves from `low` toward `medium`, and RR1 can close.
- Your answer to Q2 (billing) → R7 moves from `absent` toward `adjacent`, and G2 closes.
- Your location and floor (Q3) → R1 and R2 close, and the status can move from `conditional_go` to `go` or `no_go`.
- A Salesforce certificate or dashboard screenshot → R4 and R9 move to `high`.
- Quillfield's careers-page link → RR3 closes.

I could go further with a deeper pass on Quillfield (leadership changes, funding, staff reports; up to 5 more searches and 2 more fetches). Say the word and it runs.

If you want the full dossier saved as a file, I can write `tuesday-dossier.md`.

Three questions. Answer each in text, or say skip.

1. **Forecast (G1, R6):** In your monthly pipeline review, do you produce or challenge a commit or forecast number that goes to the sales director? How close did it land to what finance reported?
2. **Billing (G2, R7):** At the payments company, did you work with invoice, billing, settlement or collections data, or reconcile it to revenue? If so, which?
3. **Gates (R1, R2):** Can you work in Bristol two days a week, and is £61,500 above your floor?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.