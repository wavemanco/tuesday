## Decision snapshot

**Yes, apply, on conditions. Status: `conditional_go`.** R2, R3 and R6 are the core of this job and you already hold them. R4 (forecast) and R5 (billing and finance data) are where Tamsin Achebe will probe, and those are the honest gaps.

**Fit ledger.**

- `hard_gate` — unclear: R7 (Bristol, two days a week in the office), R8 (£61,500–£67,000 salary)
- `must_have` — direct: R2 (Salesforce admin), R3 (SQL and spreadsheet modelling) · adjacent: R1 (B2B software experience), R4 (owning a forecast) · unclear: R5 (finance work on billing or revenue data)
- `important` — direct: R6 (pipeline and renewal reporting)

R1 and R4 are adjacent with their limits named in the map. R5 is the one must-have with nothing on your CV. R7 and R8 are unchecked against your constraints.

**Opportunity ledger.** The employer checks out: Quillfield is a real Bristol company of 96 people (RR3, RR4 positive). The posting itself is not confirmed on the company's own careers page (RR1, low).

- **Hard gates:** none failed; unconfirmed: R7 (Bristol, two days a week in the office), R8 (£61,500–£67,000 salary); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the posting is confirmed live on Quillfield's careers page (RR1); (2) Bristol attendance and the salary work for you (R7, R8); (3) you can give a concrete answer on finance or billing data (R5), and you describe the pipeline review as what it was, not as forecast ownership (R4).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quillfield: invoicing and payments software for UK builders' merchants; Bristol; 96 employees; £11M Series A, April 2025 | `[grounded]` quillfield.co.uk/about |
| Hiring manager | Tamsin Achebe, Head of Revenue Operations; previously sales operations manager at Corvane Payments for four years | `[grounded]` public profile snippet (linkedin.example/in/tamsin-achebe) |
| Reporting line | Unknown. The "Head of" title suggests this role may sit under Tamsin | `[inferred]` from the two titles |
| Scope | Own CRM and billing data; build pipeline and renewal reporting; run the quarterly revenue forecast with the CFO | `[grounded]` JD |
| Working pattern | Hybrid, two days a week in Bristol | `[grounded]` JD |
| Market calibration | Posted £61,500–£67,000 sits inside the band (median £64,200; interquartile £57,800–£70,400; n=438, UK B2B software RevOps leads) | `[generic]` Ledgerline 2026 pay guide; `[grounded]` JD for the posted figure |
| Unknowns | Forecast scope versus finance; billing-data ownership; reporting line; whether the role is live on the company site | — |
| Contradictions | None between the JD and the company's public description | `[grounded]` |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 4+ years in RevOps, sales ops or analytics at a B2B software company | must_have | adjacent | medium | transferability | Five years in sales ops, two in RevOps, but at a B2B payments company, not software. Years meet the bar; the sector is near | `[grounded]` your background; `[inferred]` sector match | Name the sector difference yourself, before they do |
| R2 | HubSpot or Salesforce administration | must_have | direct | medium | none | Salesforce admin certified. Certificate not yet inspected | `[grounded]` your background | none |
| R3 | Strong SQL and spreadsheet modelling | must_have | direct | medium | none | SQL weekly, Excel daily. "Modelling" not yet described in your terms | `[grounded]` your background | Expect a probe on modelling |
| R4 | Experience owning a forecast | must_have | adjacent | medium | transferability | You ran the monthly pipeline review with the sales director. You never owned the company forecast; finance did | `[grounded]` your background | G2 |
| R5 | Working with finance on billing or revenue data | must_have | unclear | low | discovery | You have never worked on billing data. Revenue-data exposure through payments work is not established | `[grounded]` your background | G1 |
| R6 | Pipeline and renewal reporting | important | direct | medium | none | Rebuilt the pipeline and renewal dashboards | `[grounded]` your background | none |
| R7 | Bristol, hybrid, two days a week in the office | hard_gate | unclear | none | hard_gate | Your constraint was not given, so the gate is not established | `[grounded]` JD | Q2 |
| R8 | Salary £61,500–£67,000 plus share options | hard_gate | unclear | none | hard_gate | Your floor was not given. Posted figure sits inside the market band | `[grounded]` JD; `[generic]` band | Q2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | What would close it | Provenance |
|---|---|---|---|---|---|---|
| G1 | Finance work on billing or revenue data (R5, must_have) | discovery | Nothing on your CV covers billing or invoice-level data | This is the must-have most likely to move the decision | Any reconciliation or revenue-figure work with finance, including at the payments company | `[grounded]` CV silence; `[inferred]` that it moves the status |
| G2 | Forecast ownership (R4, must_have) | transferability | Pipeline review is the nearest work; no forecast owned | The JD names the forecast as an owned responsibility | A forecast contribution, even a model built for a finance review; or a clear statement of what the forecast process looked like | `[inferred]` bridge from the pipeline review |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posting not confirmed on the company's own careers page | risk_signal | low | "Revenue Operations Lead — Quillfield \| Tallyboard Jobs" | The role may be a copy on a job board and may be stale or filled | `[inferred]` from a company search that returned the About page but no role | "Is this role live on Quillfield's careers page, and is Tamsin Achebe the hiring manager?" | unresolved |
| RR2 | Forecast and billing data expected of one hire | unknown | — | "run the quarterly revenue forecast with the CFO"; "own our CRM and billing data" | Scope may be wider than a support role: the post names forecast and billing as owned | `[inferred]` from JD scope language | "Which parts of the forecast does this role own, and which stay with finance?" | unresolved |
| RR3 | Scope and outputs stated | positive_signal | — | "the pipeline and renewal reporting our sales and finance teams run on" | Outputs are named and measurable | `[grounded]` JD | noted | noted |
| RR4 | Salary inside the market band | positive_signal | — | "£61,500–£67,000 plus share options" | The posted range sits around the middle of the band | `[generic]` Ledgerline band | noted | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm the role is live on Quillfield's careers page and ask whether it reports to Tamsin Achebe | RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Ask the recruiter what the forecast owner does versus finance | RR2, R4 | `[grounded]` RR2 | pending your approval |
| A3 | Describe the pipeline review as what it was: you ran it, you did not own the company forecast | R4 | `[grounded]` your background | pending your approval |
| A4 | Ask the recruiter about the in-office days and the salary before a full application | R7, R8 | `[grounded]` JD | pending your approval |

## Evidence status

Verified: none yet. Your background is intake prose, so every claim is a lead until you confirm it in detail.

Research tier: L1 — searches 4 of 5, fetches 0 of 2; user links read 1

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Quillfield invoicing software company" (returned quillfield.co.uk/about: Bristol, 96 employees, Series A) and "Quillfield Revenue Operations Lead Bristol job" (no results). Employer established; posting unconfirmed (RR1) |
| 2. Role-family sweep | yes | Searched "revenue operations lead salary UK B2B software Bristol" (returned Ledgerline 2026 UK Revenue Operations Pay Guide: median £64,200, interquartile £57,800–£70,400, n=438). Market calibration in role reality; RR4 |
| 3. Hiring manager's public footprint | yes | Searched "Tamsin Achebe Quillfield" (returned linkedin.example/in/tamsin-achebe: Head of Revenue Operations; previously sales operations manager at Corvane Payments). Reporting-line inference; positioning for this reader |

The user-linked posting was read as an input and is not charged to the budget.

## Upgrade menu

- Your Bristol attendance and salary floor → R7 and R8 close; the decision moves to `go` or `no_go`.
- Any reconciliation or revenue-figure work with finance, or invoice-level data → R5 moves up from `low`, or closes.
- A forecast contribution, or a description of the finance forecast process → R4's bridge strengthens.
- Your Salesforce certificate, inspected → R2 moves to `high`.
- Deeper research on Quillfield (funding, leadership changes, hiring pattern; up to 5 more searches and 2 more fetches): say the word and I'll run it.

I can also save this analysis as a `tuesday-dossier.md` for later. Say so when you want it.

Two questions, both answerable in a sentence or skipped:

**Q1 (R5):** Have you ever reconciled revenue or billing figures with finance, or worked from invoice-level data, even at the payments company? What did you do with it, and who owned the numbers?

**Q2 (R7, R8):** Can you work in Bristol two days a week, and what is your base-salary floor?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.