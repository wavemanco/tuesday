## Decision snapshot

**Recommendation: conditional go.** Apply, and position yourself as a strong operator who is stepping up into forecasting and billing data. Don't present yourself as someone who already owns a forecast.

- **Fit:** Strong on the core RevOps work (Salesforce, SQL, pipeline and renewal reporting, the monthly pipeline review). Gaps on forecast ownership and billing data, and the forecast is the centre of this role.
- **Hard gates:** None confirmed. Location is a constraint to check: Bristol, two days a week in the office. Your location and salary floor are not in what you've given me, so both are unknown.
- **Research tier:** L0. I read the posting you linked and ran no searches, so company facts and market pay are not checked. Anything about Quillfield or Tamsin Achebe is unverified.

## What the posting asks for [grounded]

Bristol, hybrid (2 days in office). £61,500–£67,000 plus share options. The role owns CRM and billing data, builds pipeline and renewal reporting, and **runs the quarterly revenue forecast with the CFO**.

Requirements: 4+ years in RevOps, sales ops or similar at a B2B software company; HubSpot or Salesforce admin; strong SQL and spreadsheet modelling; **experience owning a forecast**; **experience working with finance on billing or revenue data**.

## Evidence map

| Requirement | Your evidence | Read |
|---|---|---|
| 4+ years RevOps / sales ops | 5 years sales ops, last 2 running RevOps for UK | Strong. "B2B payments" vs "B2B software" is close enough to raise, not a blocker [inferred] |
| Salesforce admin | Certified admin | Strong |
| SQL and spreadsheet modelling | SQL weekly, Excel daily | Strong |
| Pipeline and renewal reporting | Rebuilt both dashboards | Strong |
| Owning a forecast | Monthly pipeline review with sales director; never owned the company forecast | Gap, partly adjacent |
| Billing or revenue data with finance | Never worked on billing data | Gap |

## Gap recovery

- **G1: forecast ownership.** Closed by evidence of any forecast contribution: inputs, commit calls, pipeline-to-forecast reconciliation, or working with finance on the number even if they owned it.
- **G2: billing data.** Closed by any exposure to bookings-to-invoice reconciliation, renewal billing, or churn and revenue data from a subscription system.

## Risks and open points

- **Scope jump.** "Lead" plus forecasting with the CFO and ownership of billing data is larger than a pipeline-reporting remit. Find out whether the forecast is moving from finance to RevOps or staying with finance.
- **Unverified employer.** I haven't confirmed Quillfield exists as described. Verify with the company's own careers page or the recruiter's email domain before you invest in interviews.
- **Pay.** £61.5–67k is grounded in the posting. I can't say whether that's market-normal without research.

## Application plan

Lead with pipeline and renewal reporting, the monthly pipeline review, and the Salesforce build. Put forecast-adjacent work first in your story. Name the forecast and billing gaps yourself before an interviewer does, and say what you'd do to close them. Make no claim of forecast ownership or billing experience.

## Dossier offer

If you want, I can save this assessment as `tuesday-dossier.md` so the next session starts from it.

## Upgrade menu

- **Company and role research (L1):** up to 5 searches and 2 page fetches. It would verify Quillfield's existence and stage, check the role against market norms for pay and scope, and look at public information on Tamsin Achebe's background. Say yes if you want it.
- **Your CV or a prior resume:** would firm up the evidence map rows, especially any forecast or finance-facing work not in your summary.

## Questions

1. Have you contributed to a forecast in any way, such as supplying pipeline inputs, making commit calls, or reconciling pipeline to the number, even if finance owned the final figure?
2. Have you had any exposure to billing or invoicing data, such as bookings-to-invoice reconciliation or renewal billing?
3. Where are you based, and can you do two office days a week in Bristol? What's your salary floor?

*Response modes: reply to any of these, or say "skip" to any one of them.*

**Watch-out:** A summary line here can contradict the evidence table. Before you act on a count, an "only" or an all-clear, check it against the table's rows.