**Yes, it's worth applying, but the forecast and billing-data gaps are what you'd be interviewed on. Status: `conditional_go`.**

**Fit ledger.**
- `hard_gate`: unclear: R1 (Bristol, two office days a week)
- `must_have`: direct: R2, R3, R4 · adjacent: R5 (owning a revenue forecast) · unclear: R6 (billing or revenue data with finance)
- `important`: direct: R7

R5 and R6 are the two must-haves you flagged yourself. The rest of the posting matches your CRM, Salesforce, SQL and reporting work closely.

**Opportunity ledger.** The employer is real and the pay is in range, but the posting leaves forecast ownership unclear (RR2) and was found on a job board rather than Quillfield's own careers page (RR3). Tamsin Achebe's public background is close to yours (RR5).

- **Hard gates:** none failed; unconfirmed: R1 (Bristol, two office days a week); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) you can show a concrete forecast-adjacent example and the role's forecast ownership holds up in interview (R5, RR2); (2) you can credibly bridge from payments or transaction data to billing (R6); (3) the role is confirmed on Quillfield's careers page (RR3).

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance |
|---|---|---|---|---|---|---|---|
| R1 | Bristol hybrid, two office days a week | hard_gate | unclear | low | hard_gate | Your location and constraints weren't given | `[grounded]` posting |
| R2 | 4+ years RevOps, sales ops or analytics at a B2B software company | must_have | direct | medium | none | Five years in sales ops at a B2B payments company; "software" versus "payments" is the one label to address | `[grounded]` CV |
| R3 | Salesforce or HubSpot administration | must_have | direct | high | none | Salesforce admin certified | `[grounded]` CV, certification |
| R4 | Strong SQL and spreadsheet modelling | must_have | direct | medium | none | SQL weekly, Excel daily; model complexity unknown | `[grounded]` CV |
| R5 | Owning a revenue forecast, run quarterly with the CFO | must_have | adjacent | low | transferability | You run the monthly pipeline review but have never owned the company forecast (finance did). Limit: pipeline inspection isn't forecast accountability. | `[grounded]` your account; `[inferred]` adjacency |
| R6 | Working with finance on billing or revenue data | must_have | unclear | low | discovery | No billing data so far. Payments and renewal data may be close enough to count. | `[inferred]` from your background |
| R7 | Pipeline and renewal reporting | important | direct | high | none | You rebuilt the pipeline and renewal dashboards | `[grounded]` CV |

**Risk register**

| # | Signal | Class | Severity | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|
| RR1 | Salary stated: £61,500–£67,000 plus share options | positive_signal | — | In the middle of the market band (median £64,200, interquartile range £57,800–£70,400) | `[generic]` Ledgerline 2026 pay guide, n=438; `[grounded]` posting | — | noted |
| RR2 | Forecast ownership is unclear: "run the quarterly revenue forecast with the CFO" | unknown | — | The role may own the forecast outright, or only prepare it for finance | `[inferred]` from the posting's wording | Who signs off the forecast after this hire, and what does finance still own? | unresolved |
| RR3 | Posting found on a job board, not on Quillfield's careers page | risk_signal | low | Aggregator reposts are common, and the careers-page search returned nothing | `[generic]` job-board pattern | Is this role open on your own careers page, and is it the same role the recruiter described? | unresolved |
| RR4 | Employer is real and established | positive_signal | — | Bristol, founded 2018, 96 staff, £11M Series A in April 2025 | `[grounded]` quillfield.co.uk/about | — | noted |
| RR5 | Hiring manager is Head of Revenue Operations and came from sales ops at a payments company | positive_signal | — | Her path resembles yours, so she'll probably probe forecasting and billing hardest | `[grounded]` public LinkedIn snippet | What would a strong first six months look like on forecast ownership? | unresolved |

**Evidence status**

Research tier: L1 — searches 4 of 5, fetches 0 of 2; user links read 1

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Quillfield invoicing software company Bristol" → quillfield.co.uk/about (RR4). Searched "quillfield.co.uk careers revenue operations lead" → no results, so the posting isn't confirmed on the careers page (RR3). |
| 2. Role-family sweep | yes | Searched "Revenue Operations Lead salary UK B2B software £60,000" → Ledgerline 2026 UK Revenue Operations Pay Guide (RR1 and the market calibration) |
| 3. Hiring manager's public footprint | yes | Searched "Tamsin Achebe Quillfield" → LinkedIn profile snippet (RR5) |

**Dossier offer:** I can write this up as a `tuesday-dossier.md` file if you want to keep it.

**Upgrade menu**
- A forecast-adjacent example, such as a pipeline roll-up or a commit call that finance used, even if you didn't sign off the number → R5 moves toward medium.
- A billing, invoice or reconciliation example from the payments company → R6 can move up.
- The recruiter's answer on forecast ownership and the careers-page link → RR2 and RR3 close.
- Your location and constraints → R1 closes.
- Deeper research on Quillfield (funding, leadership changes, past hiring; up to 5 more searches and 2 more fetches): say the word and I'll run it.

**Questions**

R5: Have you ever produced a forecast number, or a commit or best-case view, that finance or a sales director used, even if you didn't sign it off? What did you own, and how was it checked against actuals?

R6: At the payments company, did you work with transaction, invoice or settlement data that finance reconciled? Who owned the join, and what did you do with it?

R1: Is two office days a week in Bristol workable for you, and are there other constraints I should check against this role?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.