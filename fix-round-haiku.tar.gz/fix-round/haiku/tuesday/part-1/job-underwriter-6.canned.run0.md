**Hold: `hold_pending_answers`.** This is not a no. Your reporting and CRM background matches the core of the role, but forecast ownership and billing data are headline asks, and the location and pay gates haven't been checked against you yet.

- **Hard gates:** none failed; unconfirmed: R1 (Bristol, two days in office), R2 (£61,500–£67,000 plus options); candidate constraints not given, so checks against them are unknown.
- **Fit ledger:**
  - `hard_gate`: unclear: R1 (office days in Bristol), R2 (salary and share options)
  - `must_have`: direct: R3 (4+ years in RevOps or sales ops), R4 (Salesforce or HubSpot admin), R5a (SQL); unclear: R5b (spreadsheet modelling); adjacent: R6 (owning a forecast), R7 (working with finance on billing or revenue data)
  - `important`: direct: R10 (pipeline and renewal reporting); absent: R8 (owning billing data)
  - R5b, R6 and R7 are the three must-haves below `direct`. R8 is the billing ownership the JD's first sentence names.
- **Opportunity ledger:** Sound on the surface. The salary sits inside the market band (RR3), and the scope is specific. The risks are a bundled scope (RR1) and an unclear forecast sign-off (RR2). The share options are unvalued (RR4). The employer checks out (RR6 reduced).
- **Severe red flags:** none found.
- **What would change this:** Likely `conditional_go` if both gates clear and you've touched forecast inputs or billing-adjacent data. If a gate fails outright, the status becomes `no_go` with that gate as the reason.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quillfield: invoicing and payments software for UK builders' merchants; founded 2018 in Bristol; 96 staff; £11M Series A (April 2025) | `[grounded]` quillfield.co.uk/about |
| Mandate | Own CRM and billing data; build pipeline and renewal reporting for sales and finance; run the quarterly revenue forecast with the CFO | `[grounded]` JD |
| Working pattern | Hybrid, two days a week in the Bristol office | `[grounded]` JD |
| Pay | £61,500–£67,000 plus share options | `[grounded]` JD |
| Market calibration | Median base £64,200, interquartile range £57,800–£70,400 (n=438, one source). The JD's range sits in the middle of that band. | `[generic]` Ledgerline 2026 guide; `[grounded]` JD figure |
| Scope read | One lead covering CRM admin, billing data, reporting and forecasting is a bundled scope, more than one role's work | `[inferred]` from the JD's four verbs |
| Unknowns | Who signs off the forecast number; whether this role owns billing data or only reports on it; team size; share-option value | — |
| Contradictions | None between the JD and Quillfield's About page. The live posting on Quillfield's careers page was not checked. | `[grounded]` About page |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Bristol, two days a week in office | hard_gate | unclear | none | hard_gate | Your location and office constraints weren't given | `[grounded]` JD | Q3 |
| R2 | Salary £61.5k–£67k plus options | hard_gate | unclear | none | hard_gate | Your pay floor wasn't given. The range is inside the market band. | `[grounded]` JD; band `[generic]` | Q3 |
| R3 | 4+ years in RevOps, sales ops or analytics at a B2B software company | must_have | direct | medium | none | Five years in sales ops, last two running RevOps. The company is B2B payments, not software. | `[grounded]` intake prose | none |
| R4 | Salesforce or HubSpot administration | must_have | direct | medium | none | Salesforce admin certified; the certificate hasn't been inspected | `[grounded]` intake prose | optional: certificate |
| R5a | Strong SQL | must_have | direct | medium | none | SQL weekly | `[grounded]` intake prose | none |
| R5b | Spreadsheet modelling | must_have | unclear | low | discovery | Excel daily is stated; modelling depth isn't | `[inferred]` | Q1 |
| R6 | Experience owning a forecast | must_have | adjacent | medium | transferability | Runs the monthly pipeline review with the sales director, but never owned a company forecast; finance did it. The JD's CFO-led forecast is the gap. | `[grounded]` intake; `[inferred]` adjacency | G1, Q1 |
| R7 | Working with finance on billing or revenue data | must_have | adjacent | medium | transferability | Renewal and pipeline revenue data, sales-side. No billing data, no finance collaboration stated. | `[grounded]` intake | G2, Q2 |
| R8 | Owning billing data (JD responsibility) | important | absent | none | discovery | Never worked on billing data. The payments company may have touched it; not stated. | `[grounded]` intake; `[inferred]` from JD | G2, Q2 |
| R10 | Pipeline and renewal reporting for sales and finance | important | direct | medium | none | Rebuilt the pipeline and renewal dashboards. This is the strongest match in the JD. | `[grounded]` intake prose | optional: dashboard screenshot |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Owning a forecast (R6, must_have) | transferability | Monthly pipeline review with the sales director; no company forecast ownership | Forecast is in the JD's responsibilities and must-have list | Any forecast you built for a team, including pipeline-weighted or quarter-end calls, even if finance reviewed it | A forecast model or deck; a quarter-end pack | `[inferred]` adjacency; `[generic]` that the CFO split is the likely objection |
| G2 | Billing or revenue data with finance (R7, R8) | discovery | Renewal and pipeline data on the sales side; billing never touched | The first sentence of the JD names billing data | Invoice or payment-collection reporting; reconciling bookings against invoices; payments-side data from your company | A billing report or reconciliation sheet, even redacted | `[grounded]` intake; `[inferred]` from JD |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Bundled scope | risk_signal | medium | "You will own our CRM and billing data, build the pipeline and renewal reporting … and run the quarterly revenue forecast" | One lead may be covering three roles' work | `[inferred]` from the JD's four verbs; `[generic]` bundling pattern | Which of these four areas would this role own alone, and which would it support someone else on? | unresolved |
| RR2 | Forecast sign-off | risk_signal | medium | "run the quarterly revenue forecast with the CFO" | The role may own pipeline inputs while the CFO owns the number | `[inferred]` from the JD's wording | Who signs off the forecast number, and does this role own the model or only the inputs? | unresolved |
| RR3 | Salary inside the market band | positive_signal | — | "£61,500–£67,000 plus share options" | The range is realistic for this scope | `[generic]` Ledgerline median; `[grounded]` JD | Is the range fixed, or set by the level you're hired at? | noted |
| RR4 | Share options unvalued | unknown | — | "plus share options" | The equity may be worth little or a lot | `[inferred]` from the JD's silence on terms | What is the share-option scheme, and what does this grant represent? | unresolved |
| RR6 | Employer existence and live posting | risk_signal | low | "Revenue Operations Lead — Quillfield" | The role may be stale or aggregated; the employer exists | `[grounded]` About page for existence; posting liveness not checked | Can you confirm this role is open on Quillfield's own careers page? | reduced |
| RR7 | Hiring manager's background | positive_signal | — | Public profile snippet: Head of Revenue Operations; previously sales operations manager at Corvane Payments | Tamsin Achebe has your background shape, so the role is likely to be scored on pipeline and CRM work | `[grounded]` profile snippet; `[inferred]` that the role reports to her | How does this role split its work between your team and finance? | noted |

Severity is blank on the `positive_signal` and `unknown` rows, because it doesn't apply to them.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Answer the three questions below | They are the only inputs that move R1, R2, R6 and R8 | `[grounded]` gap queue and evidence map | your answers |
| P2 | Ask the recruiter RR2, RR4 and RR6 verbatim | They resolve the forecast split, equity and posting status before you invest | `[grounded]` register | pending your approval |
| P3 | If you proceed, lead with the pipeline and renewal dashboards (R10); describe forecasting as pipeline review, not forecast ownership | Avoids overclaiming the one must-have you can't evidence yet | `[inferred]` from R6's limit | pending your approval; any wording needs your sign-off |

## Evidence status

Verified: none yet. Everything you've told me is intake prose, not yet probed.

Unverified leads: none.

Rejected inferences: none.

Research tier: L1 — searches 3 of 5, fetches 0 of 2; user links read 1

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Quillfield invoicing software company Bristol" and read the result quillfield.co.uk/about. The entity exists as described. The careers page wasn't fetched, so the live posting is unverified. Moved RR6 from medium to reduced. |
| 2. Role-family sweep | yes | Searched "revenue operations lead salary UK B2B software Bristol" and read Ledgerline 2026 UK Revenue Operations Pay Guide. Median £64,200, interquartile range £57,800–£70,400. Moved RR3 and the market calibration line. |
| 3. Hiring manager's public footprint | yes | Searched "Quillfield Tamsin Achebe". The result is a public profile snippet (Head of Revenue Operations; four years in sales operations at Corvane Payments). The page wasn't fetched. Moved RR7 and the positioning line. |

## Upgrade menu

- Your answers to Q1–Q3 → R1, R2, R6 and R8 move, and the decision reruns.
- Quillfield's careers-page listing or a link to it → RR6 closes fully.
- A Salesforce certificate or a redacted dashboard screenshot → R4 and R10 would rise in confidence.
- The hiring manager's profile page, fetched → RR7 and the positioning line.
- A deeper Quillfield pass (leadership changes, funding news, past postings; up to 5 more searches and 2 more fetches) → say the word and it runs.

Want me to write this up as a `tuesday-dossier.md`, so the verification questions carry into your interview prep?

**Questions:**

- **Q1 (R6, R5b):** Have you built or owned a revenue forecast, even a pipeline-weighted one, that finance or leadership used? What spreadsheet model sat behind it, and what did you own?
- **Q2 (R7, R8):** Has any of your work touched billing, invoice or payment-collection data, including through the payments company's own reporting? Who owned that data?
- **Q3 (R1, R2):** Can you work from Bristol two days a week, and is £61,500 plus options above your floor?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.