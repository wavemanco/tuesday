**Probably yes, but not yet.** Your method experience matches the four must-haves closely. The posting contradicts itself on where the job is, though, and that decides it. Status: `hold_pending_answers`.

Research tier: L1 — searches 4 of 5, fetches 1 of 2; user links read 0

## Decision snapshot

**Probably worth applying to, once the location is settled. Status: `hold_pending_answers`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (work location: fully remote or Leeds four days a week)
- `must_have` — direct: R2, R3, R4, R5
- `important` — direct: R6, R7, R8 · unclear: R9 (product-facing recommendations) · absent: R11 (pet-insurance pricing)
- `preferred` — direct: R10

R1 decides the status, and it is the only row that can move it to `no_go`. R2–R5 are direct on the method the role asks for, each at `medium` because your background is intake prose and nothing is inspected yet. R11 is the honest gap: motor pricing carries over, pet-specific drivers do not.

**Opportunity ledger.** The posting is live on Brindlemoor's own careers page, but I found no independent footprint for the company or the pet product (RR3). The pasted JD states no salary (RR4). The location conflict is the open question (RR1). In the positive column, the hiring manager's published talk is on monitoring rating models in small books, which is close to the role's brief (RR5).

- **Hard gates:** none failed; unconfirmed: R1 (work location: fully remote or Leeds four days a week); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:** If the role is confirmed fully remote, the status moves to `conditional_go`, with the pet-domain gap (R11) and pay as conditions. If it is Leeds four days a week and that does not work for you, it is `no_go`, and no reframing changes that.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, insurtech, pet-insurance product | `[grounded]` pasted JD; careers page |
| Reporting line | Reports to the Director of Pricing (Odile Varga) | `[grounded]` careers page |
| Working pattern | JD says fully remote (UK); careers page says Leeds office four days a week | `[grounded]` both sources, in conflict |
| Scope | Own pricing analytics for one product: build and monitor rating models, design and read price tests, recommend to underwriting and product | `[grounded]` JD |
| Market calibration | Senior pricing analyst, UK insurers and insurtechs: median £58,400, interquartile range £52,100–£64,900 | `[generic]` Pricewell 2026 pay survey (search snippet, not fetched) |
| Unknowns | Actual location; salary; whether the role owns product decisions or only recommends; whether it has any line-management | — |
| Contradictions | Location (JD vs careers page) | `[grounded]` both sources |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Work location: fully remote (JD) vs Leeds four days a week (careers page) | hard_gate | unclear | none | hard_gate | Two sources disagree and you have not stated a location constraint, so nothing settles it | `[grounded]` both sources; no candidate statement | Q1 below |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | Five years at a UK motor insurer, last two senior; intake prose, not probed | `[grounded]` your background | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | Used daily; no artifact yet | `[grounded]` your background | none |
| R4 | GLM experience | must_have | direct | medium | none | Built and maintained the young-driver GLM; motor, not pet, but the requirement is the method | `[grounded]` your background | probe in interview |
| R5 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | Presents the quarterly pricing review to the head of underwriting | `[grounded]` your background | none |
| R6 | Design and read price tests | important | direct | medium | none | Ran 14 price tests with the underwriting team last year | `[grounded]` your background | none |
| R7 | Build and monitor rating models | important | direct | medium | none | Built and maintained a GLM; "maintained" is close to "monitor" but not the same | `[grounded]` your background; `[inferred]` that maintenance covers monitoring | probe in interview |
| R8 | Recommendations to underwriting | important | direct | medium | none | The quarterly review is this, to underwriting | `[grounded]` your background | none |
| R9 | Recommendations to product | important | unclear | none | discovery | Nothing in your background covers product-facing work | `[grounded]` absence in your background | ask in interview |
| R10 | Insurance experience (a plus) | preferred | direct | medium | none | Five years in UK motor insurance | `[grounded]` your background | none |
| R11 | Pet-insurance pricing (implied by "our pet-insurance product") | important | absent | none | transferability | No pet experience. Transfers: GLM method, price-test design, claims-driven pricing. Limits: pet claim patterns, vet-fee drivers, lifetime cover | `[inferred]` from the JD's product line; limit is `[generic]` for pet pricing | Q3 below |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Location (R1, hard_gate) | hard_gate | Two sources disagree; you have not said what you can do | It decides the status, and nothing about your background changes it | Not applicable; this is a term, not an experience | The live posting or the recruiter's confirmation | `[grounded]` both sources |
| G2 | Pet-insurance pricing (R11, important) | transferability | Motor only | This is the question an interviewer is most likely to ask | Any pet-adjacent or vet-fee analysis; any product you priced that had lifetime or renewal dynamics | A pricing note or model summary, if any | `[inferred]` the likeliest objection; `[generic]` for pet pricing |
| G3 | Product recommendations (R9, important) | discovery | Not in your background | Affects whether the role is analytical or owns decisions | Recommendations you made to a product or proposition owner | A product review or deck, if any | `[grounded]` absence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Location contradiction | risk_signal | medium | JD: "Fully remote (UK)"; careers page: "Leeds office four days a week" | The JD may be a summary or out of date; the careers page may reflect a later decision | `[inferred]` from two sources that disagree | Is this role fully remote, or does it require four days a week in the Leeds office? | unresolved |
| RR2 | Pet product domain | unknown | — | "Our pet-insurance product" | The role may expect pet-specific pricing knowledge that you would need to learn on the job | `[inferred]` from product line against your background | What would a good first six months on the pet book look like for someone coming from motor? | unresolved |
| RR3 | Thin independent footprint | risk_signal | low | Careers page is live; search for the company returned no independent results | Brindlemoor may be young or small, which is common for insurtechs | `[generic]` pattern for companies of this size; not a claim about this one | Could you tell me about the pet product's launch date and the size of the pricing team? | unresolved |
| RR4 | Pay not stated | unknown | — | JD states no salary | The budget may sit inside the band, or the company may not publish pay | `[generic]` band; the withholding is `[grounded]` | What is the base salary range for this role? | unresolved |
| RR5 | Hiring manager's public interest | positive_signal | — | 2025 Insurance Pricing Forum talk "Small Books, Loud Errors" on monitoring rating models in small books | Your model-maintenance work is the same subject, so it is a natural opening | `[grounded]` talk title from search snippet | (Asked of you, not the employer:) Have you written about monitoring a rating model over time? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Ask the recruiter in writing whether the role is remote or Leeds four days a week before you apply | RR1, R1 | `[grounded]` careers page vs JD | pending your approval |
| A2 | Prepare a plain answer on pet pricing: "I have not priced a pet book; here is the motor method that carries over, and here is where I would need to learn." | R11, RR2 | `[grounded]` your background; no claim beyond it | pending your approval |
| A3 | Ask the company about launch date and team size before accepting any interview | RR3 | `[generic]` pattern | pending your approval |

## Evidence status

Verified: none yet. Your background is intake prose and has not been probed, so every row is at its intake band.

Research tier: L1 — searches 4 of 5, fetches 1 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Brindlemoor careers Senior Pricing Analyst" and "Brindlemoor insurtech pet insurance" (no results); fetched brindlemoor.co.uk/careers/senior-pricing-analyst. Moved R1 and RR1: the careers page places the role in Leeds four days a week, against the JD's "fully remote". Also confirms the role is live. |
| 2. Role-family sweep | yes | Searched "Senior Pricing Analyst pet insurance UK salary"; result pricewell.example/2026-uk-pricing-analytics-pay-survey (snippet only). Moved the market calibration and RR4. |
| 3. Hiring manager's public footprint | yes | Searched "Odile Varga Director of Pricing"; result linkedin.example/in/odile-varga (snippet only). Moved RR5, the positioning hook. Public professional footprint only. |

## Upgrade menu

- Your CV or resume → raises R2–R8 from `medium` toward `high`, and lets me check the wording against the JD.
- A pricing note, model summary or any pet-adjacent analysis → R11 narrows; this is the single most useful artifact for the pet objection.
- The live posting link, or the recruiter's reply on location → R1 closes, and the status can move.
- Your salary floor → checks the pay side of the hard-gate line, which is currently unknown.
- A deeper pass on Brindlemoor (funding, leadership, product launch, staff reports; up to 5 more searches and 2 more fetches) — say the word and it runs.

If you want, I can also write this up as a `tuesday-dossier.md` you can keep and reuse.

**Questions** (tagged to their rows):

**Q1 (R1):** Is in-office attendance a constraint for you? Can you work from Leeds four days a week, or is remote the only option? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Q2 (hard gate, pay):** What base salary would you need, as a floor? Answer in text, or say skip.

**Q3 (R11):** Have you ever priced, reviewed or analysed any pet product, or any product with vet-fee or lifetime-cover dynamics? What did you own, and what happened? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.