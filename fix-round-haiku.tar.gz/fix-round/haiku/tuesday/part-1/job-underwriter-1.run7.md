**Yes, apply: `conditional_go`.** On the core analytics requirements, your history matches directly. The open gaps are the clinician and mentoring parts of the job, plus the metrics-layer ownership question. Healthcare data is preferred-tier, so it doesn't gate the decision.

**Fit ledger.**
- `must_have`: direct: R1 (5+ years product analytics), R2 (expert SQL), R3 (experiment design at scale), R4 (Looker or similar BI tool), R5 (written communication with non-technical stakeholders) · unclear: R6 (define and maintain the metrics layer)
- `important`: direct: R7 (self-serve Looker dashboards), R8 (partner with PMs on roadmap decisions) · unclear: R9 (partner with clinicians), R10 (mentor two junior analysts)
- `preferred`: adjacent: R11 (HIPAA / healthcare data)

What matters: R1, R2, R3, R4, R5 — the core analytics requirements; R6 — metrics-layer ownership, the one must-have not established; R9, R10 — clinician work and mentoring, the open important rows; R11 — healthcare data, preferred.

**Opportunity ledger.** The posting is specific about outcomes and scope (RR4 positive). It withholds pay and location (RR2) and reads broad for one seat (RR3). Nothing about the employer is verified yet (RR1).

- **Hard gates:** none stated in the JD; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this (conditions for go):** (1) the role is live on Harborlight's own careers page, and pay and location are acceptable (RR1, RR2); (2) you owned the metric definitions, not only the dashboards on top of them (G1); (3) the mentoring and clinician scope is something you'd take on (R9, R10, RR3).

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, digital-health scale-up, ~400 people, Series C | `[grounded]` JD header; not checked externally |
| Product | Care-navigation app | `[grounded]` JD |
| Mandate | Owns product analytics: metrics layer, A/B tests, self-serve Looker, PM and clinician partnership, mentoring two juniors | `[grounded]` JD |
| Scope read | One senior analyst owning the full analytics function plus two direct reports | `[inferred]` from the listed duties |
| Market calibration | Not run; the role-family search was declined, so no pay band is offered | — |
| Compensation, location, schedule, contract | Not stated | `[grounded]` JD silence |
| Unknowns | Pay, location, contract basis, whether a metrics layer already exists, clinical governance | — |
| Contradictions | None found within the posting | `[grounded]` JD |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | Six years at a consumer-subscription company; stated, not yet inspectable, so expect a probe | `[grounded]` your intake | none |
| R2 | Expert SQL | must_have | direct | medium | none | Daily SQL on Snowflake; self-reported, no query sample yet | `[grounded]` your intake | none |
| R3 | Experiment design at scale | must_have | direct | medium | none | 30+ A/B tests a year; the 11% retention lift is a stated outcome, not inspected. Expect a probe on what you designed versus ran | `[grounded]` your intake | upgrade menu: test readout |
| R4 | Looker or similar BI tool | must_have | direct | medium | none | Built the Looker instance and 40+ governed dashboards; self-reported | `[grounded]` your intake | none |
| R5 | Written communication with non-technical stakeholders | must_have | direct | medium | none | Writes the monthly exec metrics memo and presents it to the VP Product | `[grounded]` your intake | none |
| R6 | Define and maintain the metrics layer | must_have | unclear | low | discovery | Governed dashboards suggest managed definitions, but ownership of canonical definitions isn't stated. Low, not none, because there's a thread to pull | `[grounded]` intake silence; `[inferred]` that dashboard governance implies a definition layer | G1 |
| R7 | Build self-serve dashboards in Looker | important | direct | medium | none | Built 40+ governed dashboards; whether consumers used them self-serve isn't stated | `[grounded]` your intake | none |
| R8 | Partner with PMs on roadmap decisions | important | direct | medium | none | The exec memo and VP presentation are roadmap-facing; PM partnership itself isn't described | `[grounded]` your intake; `[inferred]` that the memo feeds roadmap | none |
| R9 | Partner with clinicians | important | unclear | low | discovery | Nothing in the intake about clinical stakeholders | `[grounded]` intake silence | G2 |
| R10 | Mentor two junior analysts | important | unclear | low | discovery | Nothing in the intake about mentoring; informal mentoring may exist | `[grounded]` intake silence | G3 |
| R11 | HIPAA / healthcare data experience | preferred | adjacent | medium | transferability | GDPR/CCPA consumer PII and a consent-state model are the closest work. No PHI, no HIPAA. Limit: consumer data, not clinical | `[grounded]` your intake; `[generic]` that HIPAA scope differs from GDPR/CCPA | G4 |

**Gap recovery queue**

| # | Gap (req) | Type | What I see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Metrics-layer ownership (R6, must_have) | discovery | Dashboards are governed; definition ownership isn't described | A must-have; the answer alone could move the decision | Writing or signing off metric definitions (retention, active subscribers); a metric spec or semantic-layer doc you maintained; resolving definition disputes between teams | A metrics doc, a LookML or dbt model excerpt, a definitions sign-off thread | `[grounded]` intake silence; `[inferred]` that it would move the status |
| G2 | Clinician partnership (R9, important) | discovery | No clinical or care-team stakeholders described | The clinician side of the job is the largest domain shift | Analysis for ops, care or support teams; working with domain experts who set the questions; a regulated or safety-sensitive analysis | A stakeholder brief, a readout to a non-product audience | `[grounded]` intake silence; `[generic]` that clinical stakeholders set different questions |
| G3 | Mentoring (R10, important) | discovery | No mentoring or people leadership described | An explicit responsibility; a yes or no shifts the role's fit | Onboarding or reviewing analysts' work; leading a small analytics pod; informal coaching of colleagues | A review or onboarding plan, a team charter | `[grounded]` intake silence |
| G4 | Healthcare data (R11, preferred) | transferability | Consent and privacy work on consumer data; no health data | Preferred, so a minor risk; the bridge needs its limit stated | Consent-state logic, data-minimization decisions, privacy reviews on sensitive fields | A privacy review or consent spec (sanitized) | `[grounded]` intake; `[generic]` that clinical data adds controls consumer data doesn't have |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer and posting not verified | unknown | — | "Harborlight Health (digital-health scale-up, ~400 people, Series C)" | Employer and posting are unconfirmed; web search was declined, so nothing was checked | n/a: nothing verified in this run | Is this role open now on your careers site, and who would I be interviewing with? | unresolved |
| RR2 | Pay and location withheld | unknown | — | JD gives no pay, location or schedule | The role may carry a location requirement or be remote-restricted, and pay is undisclosed | `[inferred]` from the posting's silence | What is the base salary range for this level, and is the role remote, hybrid or on-site? | unresolved |
| RR3 | Scope breadth for one seat | risk_signal | low | "Own product analytics … and mentor two junior analysts" | Owning the full analytics function, two reports and clinician partnership may exceed one senior seat | `[inferred]` from the listed duties | How many analysts are on this team today, who owns data engineering, and what would I own versus share? | unresolved |
| RR4 | Existing experimentation practice | positive_signal | — | "design and analyze A/B tests"; "experiment design at scale" | A testing program already runs, so the role starts from a working base | `[inferred]` from the JD's wording | How many experiments ran last year, and who decides what ships from a result? | noted |

**Application plan** (every row proposed; nothing applied)

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Lead with the experimentation program you designed and ran and the Looker build you did | Strongest direct matches (R3, R4) | `[grounded]` your intake | pending your approval |
| A2 | Describe the consent-state and GDPR/CCPA work as privacy work on consumer data; don't call it healthcare or HIPAA experience | R11 | `[grounded]` your intake; reframing audit: no healthcare claim | pending your approval |
| A3 | Don't claim mentoring or clinician work until you confirm it | R9, R10 | `[grounded]` intake silence | pending your approval |
| A4 | Prepare the 11% lift answer: what you designed, what you ran, what the team decided | Interviewers probe attribution on headline numbers | `[generic]` pattern for headline metrics in interviews | pending your approval |
| A5 | Get pay, location and the live posting from the employer before investing in the application | RR1, RR2 | `[inferred]` from the posting's silence | pending your approval |

**Evidence status**

Verified: none yet. Your claims are intake statements, not yet probed, so every band sits at `medium` or below.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Search was declined, so the posting wasn't checked against the company's careers page. Would have moved RR1 and the contradictions row |
| 2. Role-family sweep | unavailable | Same refusal. Would have set the market calibration and pay band |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

**Dossier offer:** I can write this up as `tuesday-dossier.md` so mock-interview can use it for prep later; say the word.

**Upgrade menu**
- Permission to run web search (up to 5 searches and 2 page fetches) would verify RR1 and set a pay band for RR2. I won't retry the search without your go-ahead. Pasting the careers-page link also works, since reading a link you give me isn't research.
- An anonymized A/B test readout would raise R3 toward `high`. A sanitized metrics-definition doc or a dashboard screenshot would move R4 and R6.
- The employer's pay range closes RR2.
- Answers to G1–G4 can move R6, R9, R10 and R11.
- A hiring manager's name would sharpen the scope read and the positioning for R8.

**Questions**

G1 — Did you own the canonical metric definitions behind your Looker layer, such as how retention and active subscribers are defined and signed off? Or did you build dashboards on definitions someone else set?

G2 — Have you worked directly with clinicians, care staff, or other non-product domain experts on analysis? If so, what did you change, and who was in the room?

Structural — What are your non-negotiables for this search: minimum base pay, location or remote terms, and whether you'd take fixed-term or contract work?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.