**Yes, apply, on three conditions.** Your must-haves are a strong match. The pet-insurance gap is real, but it's the kind you can name honestly in the application. Status: `conditional_go`.

**Fit ledger.**

- `hard_gate`: unclear: R1 (UK-based, fully remote)
- `must_have`: direct: R2 (4+ years pricing analytics), R3 (SQL and Python), R4 (GLM experience), R5 (build and monitor rating models), R6 (design and read price tests), R7 (presenting to underwriting or actuarial leads)
- `important`: adjacent: R9 (pet-insurance product knowledge)
- `preferred`: direct: R8 (insurance experience)

R9 (medium): motor pricing transfers in method, not product knowledge. R5 (medium): "built and maintained" covers much of it, but your monitoring cadence isn't stated.

**Opportunity ledger.** No severe red flags. Open questions are employer attribution (RR1), decision rights (RR2), line management (RR3) and salary (RR4). The concrete scope with named outputs is a positive signal (RR5).

- **Hard gates:** none failed; unconfirmed: R1 (UK-based, fully remote); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) RR1: the role is live on Brindlemoor's own careers site, and you know which entity employs it. (2) R1: UK-based fully remote work is confirmed as yours. (3) R9: the application names the pet gap plainly and doesn't bridge it into product knowledge.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech; pet-insurance product | `[grounded]` your posting |
| Mandate | Own pricing analytics; build and monitor rating models; design and read price tests; recommend to underwriting and product | `[grounded]` posting |
| Working pattern | Fully remote, UK | `[grounded]` posting |
| Hiring manager | Odile Varga, Director of Pricing | `[grounded]` your message |
| Scope read | Individual-contributor scope; the posting names no reports | `[inferred]` from silence on people management |
| Market calibration | Unavailable: the search tool was refused, so no salary or role-norm band was checked | — |
| Unknowns | Employer attribution; salary; decision rights; line management | — |
| Contradictions | None visible; the posting is the only source | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | UK-based, fully remote | hard_gate | unclear | low | hard_gate | Your background gives a UK employer, not your residence. Not established | `[grounded]` posting; `[inferred]` that residence is unstated | Q2 below |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | Five years, last two senior. Self-reported, no artifact | `[grounded]` your background | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | Daily use. No artifact | `[grounded]` your background | Optional: a sanitized query would raise to high |
| R4 | GLM experience | must_have | direct | medium | none | Built and maintained the young-driver GLM | `[grounded]` your background | none |
| R5 | Build and monitor rating models | must_have | direct | medium | presentation | Built and maintained is stated; monitoring cadence isn't | `[grounded]` your background | Edit P1 below, if the cadence is true |
| R6 | Design and read price tests | must_have | direct | medium | none | 14 price tests last year with underwriting | `[grounded]` your background | none |
| R7 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | Quarterly pricing review to the head of underwriting | `[grounded]` your background | none |
| R8 | Insurance experience | preferred | direct | medium | none | Five years at a UK motor insurer | `[grounded]` your background | none |
| R9 | Pet-insurance product knowledge | important | adjacent | medium | transferability | Motor pricing carries over. Limit: no pet claims, loss-cost or lifetime-value work | `[inferred]` requirement from "our pet-insurance product"; `[grounded]` your statement | G1 below |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pet-insurance product knowledge (R9, important) | transferability | Motor pricing only | This is the objection most likely to come up | Any non-motor line (home, travel, accident and health); a pet pilot; claims-data reviews outside motor | A pricing note or segmentation paper from any line | `[inferred]` bridge from motor work; `[generic]` that pet cost drivers (breed, age, vet-fee inflation) differ from motor |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established | unknown | — | "Brindlemoor (insurtech)" | The posting may be stale, aggregated, or from an entity with no footprint. Research could not run, so this is unverified, not disproved | `[generic]` pattern for companies of this size, not a claim about this one | Which legal entity employs this role, and is it live on your own careers site? | unresolved |
| RR2 | Decision rights unclear | unknown | — | "recommendations for underwriting and product" | The role may recommend rating changes rather than decide them | `[inferred]` from the posting's scope against its silence on authority | Which rating changes does this role decide itself, and which go to underwriting sign-off? | unresolved |
| RR3 | Line management not stated | unknown | — | "Senior Pricing Analyst" | The role may carry no reports, or may be expected to take some within a year | `[inferred]` from silence on people management | Does this role line-manage anyone now, or is that expected within a year? | unresolved |
| RR4 | Salary not in the posting | unknown | — | (none given) | The band is unknown until checked | `[inferred]` from the posting you shared | What base salary range is budgeted for this post? | unresolved |
| RR5 | Concrete scope and named outputs | positive_signal | — | "build and monitor rating models… design and read price tests" | The role's outputs are defined and measurable | `[grounded]` posting | What would a strong first six months look like here? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Lead with "the GLM rating model I built and maintained for the young-driver book" and "14 price tests run with the underwriting team." Don't write "owned" or "led" | R4, R6; audit keeps the verb and scope as stated | `[grounded]` your background | pending your approval |
| P2 | State the gap in one line: "No pet-insurance experience yet; my motor rating and price-testing work transfers in method, not product knowledge." | R9; avoids the relationship and kind drift the audit names | `[grounded]` your background | pending your approval |
| P3 | Confirm the posting is live on Brindlemoor's careers site before applying | RR1 | `[grounded]` posting | pending your approval |
| P4 | Ask the RR2 and RR4 questions in the first call | RR2, RR4 | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Your background is self-reported in this conversation, so every claim sits at `medium` or below.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches (Brindlemoor pet insurance; Brindlemoor careers listing) were refused. Employer attribution stays unverified (RR1) |
| 2. Role-family sweep | unavailable | One search (UK pet-insurance pricing analyst salary) was refused. The salary band and role norms are unset (RR4) |
| 3. Hiring manager's public footprint | unavailable | One search for Odile Varga was refused. Nothing on the role's scope or the positioning for this reader |

The search tool isn't permitted in this session, so none of the three targets returned anything.

**Dossier offer:** I can write this up as a `tuesday-dossier.md` you can keep and reuse in later modules.

## Upgrade menu

- The live posting link or Brindlemoor's careers page → RR1 closes and the decision can move to `go`.
- A sanitized SQL query or notebook → R3 to `high`.
- The price-test readout or the pricing review deck you presented → R6 and R7 to `high`.
- Any non-motor or pet artifact, even a pilot → R9 moves from `adjacent` toward `direct`.
- Granting search permission → I can run the three L1 targets (up to 5 searches, 2 fetches) to verify the employer and check the salary band.

## Questions

G1 (R9): Have you touched any non-motor line (home, travel, accident and health), a pet pilot, or claims data outside motor? If so, what did you own?

HG (R1): Are you UK-based, and is fully remote UK working a requirement for you?

RR2: When you ran the 14 price tests, did you decide the rating change, or recommend it for underwriting to sign off?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.