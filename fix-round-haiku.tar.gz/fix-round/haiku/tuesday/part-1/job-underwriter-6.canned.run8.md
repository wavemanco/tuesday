**Worth applying, but hold until two facts are in. Status: `hold_pending_answers`.** On what you've told me, the fit is strong: the years, the Salesforce admin, the SQL and the pipeline and renewal reporting all line up. The two things that could flip this are where you're based and whether the pay works for you. The forecast and billing requirements are the real gaps. Neither is a hard gate, but both will come up in interview.

- **Fit ledger.**
  - `hard_gate`: unclear: R1 (Bristol hybrid, two days a week in the office), R2 (£61,500–£67,000 plus share options)
  - `must_have`: direct: R3 (4+ years in revenue or sales ops at a B2B software company), R4 (HubSpot or Salesforce administration), R5a (strong SQL); adjacent: R5b (spreadsheet modelling), R6 (owning a forecast); unclear: R7 (working with finance on billing or revenue data)
  - `important`: direct: R8 (building pipeline and renewal reporting)
- **Opportunity ledger.** The role reads as a broad remit across CRM, billing, forecasting and reporting (RR1, RR2), and it is partly finance-shaped. The employer checks out (RR3), and the salary is stated and sits inside the role-family band (RR4).
- **Hard gates:** none failed (R1 `unclear`, R2 `unclear`); unconfirmed: R1 (Bristol hybrid, two days a week in the office), R2 (£61,500–£67,000 plus share options); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:** the status moves to `go` if you're in or near Bristol and the pay works, and to `no_go` if either fails. R7 decides how hard you'd need to argue the forecast and billing points.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quillfield, invoicing and payments software for UK builders' merchants; Bristol; 96 employees; Series A (£11M) in April 2025 | `[grounded]` quillfield.co.uk/about, found by search |
| Mandate | Own the CRM and billing data; build pipeline and renewal reporting; run the quarterly revenue forecast with the CFO | `[grounded]` posting |
| Pay | £61,500–£67,000 plus share options | `[grounded]` posting |
| Market calibration | Median £64,200, interquartile range £57,800–£70,400, for revenue operations leads in UK B2B software (n=438) | `[generic]` Ledgerline 2026 pay guide; not a claim about Quillfield's offer |
| Location | Bristol, hybrid, two days a week in the office | `[grounded]` posting |
| Unknowns | Where you're based; your pay floor; how much billing and forecast ownership sits with finance; whether the role is live on Quillfield's own careers page | `[inferred]` from the posting's silence |
| Contradictions | None found between the posting and the company's About page | `[grounded]` |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Bristol hybrid, two days a week in the office | hard_gate | unclear | none | hard_gate | Your location isn't stated, so the gate isn't settled | `[grounded]` posting; no candidate statement | G3 (R1) |
| R2 | Pay £61,500–£67,000 plus share options | hard_gate | unclear | none | hard_gate | Posted range is inside the market band; your floor isn't stated | `[grounded]` posting; `[generic]` band | G3 (R2) |
| R3 | 4+ years in revenue or sales ops at a B2B software company | must_have | direct | medium | none | Five years in sales ops, last two running RevOps. Your company is B2B payments, not software; counted direct on function and named here | `[grounded]` your background, self-reported | none |
| R4 | HubSpot or Salesforce administration | must_have | direct | medium | none | Salesforce admin certified; the certificate hasn't been inspected | `[grounded]` your background | upgrade menu |
| R5a | Strong SQL | must_have | direct | medium | none | SQL weekly | `[grounded]` your background | none |
| R5b | Spreadsheet modelling | must_have | adjacent | medium | transferability | Excel daily, but modelling isn't described; limit: no forecast models named | `[inferred]` from daily Excel use | upgrade menu |
| R6 | Owning a forecast; quarterly forecast with the CFO | must_have | adjacent | medium | transferability | You run the monthly pipeline review with the sales director but never owned the company forecast; finance did | `[grounded]` your background; `[inferred]` adjacency | G1 (R6) |
| R7 | Working with finance on billing or revenue data | must_have | unclear | none | discovery | You've never worked on billing data; finance collaboration is undescribed | `[grounded]` your statement | G2 (R7) |
| R8 | Building pipeline and renewal reporting | important | direct | medium | none | You rebuilt the pipeline and renewal dashboards | `[grounded]` your background | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Forecast ownership (R6, must_have) | transferability | Pipeline review with the sales director; no company forecast | The forecast is named in the posting and is the most likely interview probe | Any input you gave to a quarterly or annual number: pipeline-to-forecast bridges, commit calls, scenario work | A pipeline-to-forecast example, sanitized | `[grounded]` your background; `[generic]` that forecasting is probed hard in this role family |
| G2 | Finance on billing or revenue data (R7, must_have) | discovery | No billing work stated; finance work undescribed | Named in the posting; stated absence on billing | Reconciling pipeline to invoiced amounts; supplying inputs to a monthly close; any renewal-value work agreed with finance | A reconciliation example or a finance-side brief | `[grounded]` your statement |
| G3 | Location and pay (R1, R2) | hard_gate | Neither is stated against you | These are the gates | none — surfaced, not worked around | none — answer the question | `[grounded]` posting |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Scope spans RevOps, billing and forecasting | risk_signal | medium | "own our CRM and billing data … run the quarterly revenue forecast with the CFO" | The role may sit partly in finance, with billing and forecast authority held there | `[inferred]` from the posting's scope against its silence on decision rights | Which parts of billing and the forecast does this role own outright, and which stay with finance? | unresolved |
| RR2 | Requirements lean finance-side | risk_signal | low | "experience owning a forecast"; "experience working with finance on billing or revenue data" | The brief may want finance-side experience a RevOps background doesn't cover | `[inferred]` from the requirement list | Would you consider someone who has run pipeline forecasting but not company revenue forecasting, and what would they own in the first 90 days? | unresolved |
| RR3 | Employer established | positive_signal | — | "invoicing software" | The employer is real, Bristol-based, and Series A funded | `[grounded]` quillfield.co.uk/about | What is the hiring team's plan for the billing data in the first year? | noted |
| RR4 | Salary stated, inside band | positive_signal | — | "£61,500–£67,000 plus share options" | Posted pay is transparent and near the middle of the band | `[generic]` band; `[grounded]` posting | none needed | noted |
| RR5 | Live posting on the company's own site unconfirmed | unknown | — | Posting is on a job aggregator | The posting may be stale or not on Quillfield's careers page | `[inferred]` from where the posting was found | Is this role live on your own careers page, and who does it report to? | reduced |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Answer G3 (R1, R2) before applying | Only these can move the status to `go` or `no_go` | `[grounded]` R1, R2 rows | for you |
| A2 | Describe the pipeline review as input to the forecast, not ownership | Keeps R6 at adjacent | `[grounded]` R6 row | pending your approval |
| A3 | Check Quillfield's careers page for the live role and reporting line | Closes RR5 | `[grounded]` RR5 | for you |
| A4 | Lead with the sales-ops-to-RevOps path from a payments company | Matches the closest public parallel in the hiring manager's profile | `[inferred]` from the public profile | pending your approval |

If you want to rehearse the forecast and billing questions, the mock-interview module handles that.

## Evidence status

Verified: none yet. Your background is self-report, so every claim sits at `medium` or below until a probe confirms it. Unverified leads: none. Rejected inferences: none.

Research tier: L1 — searches 3 of 5, fetches 0 of 2; user links read 1

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Quillfield invoicing software company Bristol", which returned quillfield.co.uk/about: invoicing and payments software, founded 2018 in Bristol, 96 employees, Series A (£11M) in April 2025. The careers page wasn't fetched, so the live posting is unconfirmed. Moved RR3 and RR5 |
| 2. Role-family sweep | yes | Searched "Revenue Operations Lead salary UK B2B software Bristol", which returned the Ledgerline 2026 UK Revenue Operations Pay Guide (ledgerline.example/2026-uk-revenue-operations-pay-guide): median £64,200, interquartile range £57,800–£70,400, n=438. Moved the market calibration and RR4 |
| 3. Hiring manager's public footprint | yes | Searched "Tamsin Achebe Quillfield", which returned a public profile (linkedin.example/in/tamsin-achebe): Head of Revenue Operations at Quillfield, previously sales operations manager at a payments company for four years. Moved A4. Nothing personal was used |

## Upgrade menu

- Your base location, and whether Bristol two days a week works → R1 closes, and the status moves to `go` or `no_go`.
- Your pay floor → R2 closes against the posted range.
- A Salesforce certificate, or a sanitized pipeline-to-forecast example → R4 and R6 can rise.
- An example of finance-side work, such as reconciling pipeline to invoices → R7 moves from discovery.
- Quillfield's own careers page → RR5 closes.
- A deeper pass on Quillfield (funding, leadership changes, hiring patterns; up to 5 more searches and 2 more fetches). Say the word and it runs.

If you want this kept for later, I can save it as a `tuesday-dossier.md`.

Questions:

G3 (R1): Where are you based, and could you be in the Bristol office two days a week?

G3 (R2): What's your base-pay floor, and does the share-option value count toward it?

G2 (R7): Have you ever worked with finance on billing or revenue numbers, even indirectly, such as reconciling pipeline to invoiced amounts or feeding a monthly close?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.