## Decision snapshot

Yes, apply, on two checks first: confirm the UK fully-remote gate, and confirm Brindlemoor and the live posting are real. Core fit is strong. Pet insurance is the stretch. **Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (fully remote, UK-based)
- `must_have`: direct: R2, R3, R4, R5, R6, R7
- `important`: adjacent: R8 (pet-insurance product knowledge)
- `preferred`: direct: R9 (insurance experience)

R2, R3, R4, R5, R6 and R7 are the must-haves, all `direct`. R8 is the pet-product gap, `adjacent` through motor pricing. R1 is the UK remote gate, unconfirmed because you have not stated your location or right to work. R9 is insurance experience, `direct`.

**Opportunity ledger.** RR1 pay and contract basis are unstated. RR4 reporting line is unstated. RR3 sign-off authority is unclear. RR2 the employer is unverified (`severity: medium`), because web research was refused this session. RR5 the scope is concrete, which is a positive signal.

- **Hard gates:** none failed; unconfirmed: R1 (fully remote, UK-based); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **Conditions for go:** (1) R1 confirmed: you are UK-based with right to work and can work fully remote; (2) RR2 verified: Brindlemoor exists and the post is live; (3) R8 framed as learning a new domain, not as pet experience.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech with a pet-insurance product | `[grounded]` JD header; not verified (RR2) |
| Mandate | Own pricing analytics for one product: rating models, price tests, recommendations for underwriting and product | `[grounded]` JD |
| Working pattern | Fully remote, UK | `[grounded]` JD |
| Scope read | One product, three named activities, no stated team size | `[inferred]` from the JD's scope language |
| Seniority and reports | The JD names no direct reports and no people management | `[inferred]` from the JD's silence (RR4) |
| Market calibration | Not established: the role-family search was refused, so no pay band is given | — |
| Unknowns | Pay, contract basis, sign-off authority, reporting line, team size | — |
| Contradictions | None visible. Only one source (the pasted JD) was available to compare | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote, UK-based (JD: "Fully remote (UK)") | hard_gate | unclear | none | hard_gate | No location or right-to-work statement from you, so the gate is not settled either way. Your UK motor-insurer history is context, not proof. | `[grounded]` JD term; `[inferred]` that location is unestablished | Q1 in the closing block |
| R2 | Pricing or actuarial analytics, 4+ years | must_have | direct | medium | none | Five years in pricing analytics, two as senior analyst. Self-report with no artifact yet, so medium. | `[grounded]` your intake | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | Daily use stated. "Strong" is your own word and has not been probed. | `[grounded]` your intake | A code sample would raise it to high |
| R4 | GLM experience | must_have | direct | medium | none | Built and maintained the GLM rating model for the young-driver book. It is motor, not pet, but the technique is what the row asks for. | `[grounded]` your intake; `[generic]` that GLM technique transfers across lines | none |
| R5 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | Quarterly pricing review to the head of underwriting. | `[grounded]` your intake | none |
| R6 | Design and read price tests | must_have | direct | medium | none | Ran 14 price tests with underwriting last year. Your design role is not stated. | `[grounded]` your intake | Q3 (G2) |
| R7 | Build and monitor rating models | must_have | direct | medium | none | Built and maintained a GLM. Monitoring is implied by "maintained" but not described. | `[grounded]` your intake; `[inferred]` that maintenance includes monitoring | A monitoring pack would raise it to high |
| R8 | Pet-insurance product knowledge (inferred from "our pet-insurance product") | important | adjacent | medium | transferability | Carries over: rating-factor work, GLMs, claims-cost analysis, commercial trade-offs. Limit: no pet cover, rating drivers or claims dynamics. | `[inferred]` adjacency from your motor work; `[generic]` that pet pricing is driven by species, breed and age | Q2 (G1) |
| R9 | Insurance experience (JD: "a plus") | preferred | direct | medium | none | Five years in motor insurance. | `[grounded]` your intake | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pet-insurance product knowledge (R8, important) | transferability | Motor pricing and underwriting work; nothing on pet cover | This is the one domain gap. The interview will test whether you can learn a new rating structure, not whether you already know pet | Any pet or companion-animal rating or claims work; a pet-market benchmark or product review; a claims-cost analysis on a product with a different loss pattern | A product or pricing review, a benchmark you built, a short pet-market note | `[grounded]` absence on intake; `[generic]` that pet rating turns on species, breed and age |
| G2 | Design of price tests (R6, must_have) | discovery | "Ran 14 tests with underwriting"; who designed them is not stated | The posting says "design and read". If you only ran others' designs, the CV claim has to say so | Hypotheses you set, test cells you chose, success criteria you agreed | A test plan or a read-out deck | `[grounded]` intake wording |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay and contract basis not stated | unknown | — | JD gives no salary or contract type | The pay may sit away from your expectation, and the contract may be fixed-term | `[inferred]` from the JD's silence | What is the base salary band, and is the role permanent? | unresolved |
| RR2 | Employer not established from attributable sources (standing entry) | risk_signal | medium | "Brindlemoor (insurtech)" | The company may be too new or small for a public footprint, or the posting may be stale or aggregated | `[generic]` pattern for companies of this size, not a claim about this one | Which team would this role sit in, and who would I be interviewing with? | unresolved; research refused this session |
| RR3 | Sign-off authority unclear | unknown | — | "turn the results into recommendations for underwriting and product" | The role may recommend while sign-off sits with underwriting or product | `[inferred]` from the verb "recommendations" against silence on sign-off | Who signs off final rates after this role's recommendation? | unresolved |
| RR4 | Reporting line not stated | unknown | — | JD names no direct reports | The role may be individual-contributor, which matches your history | `[inferred]` from the JD's silence on reports | Does this role line-manage anyone now or within a year? | unresolved |
| RR5 | Concrete scope with named outputs | positive_signal | — | "build and monitor rating models, design and read price tests" | The three activities map directly onto your current work | `[grounded]` JD | What would I own in the first six months? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Find the live posting and the team on Brindlemoor's own careers site before you apply | RR2 | `[grounded]` RR2 | pending your approval |
| P2 | Lead with motor pricing craft: GLM build and maintenance, 14 price tests, quarterly review to underwriting. Keep "ran" as "ran" until G2 is answered | R4, R5, R6 | `[grounded]` your intake; `[generic]` that GLM craft transfers across lines | pending your approval |
| P3 | Name pet as the domain you are learning, not as experience, e.g. "motor pricing now, pet to learn" | R8 | `[grounded]` G1 | pending your approval |
| P4 | Ask for the pay band and contract type before the first interview | RR1 | `[grounded]` RR1 | pending your approval |
| P5 | Prepare answers on sign-off authority and reporting line | RR3, RR4 | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Your background is prose intake, which is self-report, so every claim is at most `medium`. Unverified leads: none. Rejected inferences: none.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Search "Brindlemoor insurtech pet insurance" was refused by the permission setting. Would have confirmed the employer exists and the post is live (RR2) |
| 2. Role-family sweep | unavailable | Search "senior pricing analyst pet insurance UK salary GLM" was refused. Would have set the market pay band (RR1) and the scope norm |
| 3. Hiring manager's public footprint | unavailable | Search "Odile Varga Director of Pricing Brindlemoor" was refused. Would have shown Odile's public background for positioning |

## Dossier offer

If you want, I can save this as a `tuesday-dossier.md` that mock-interview can pick up later.

## Upgrade menu

- A link to the live posting or Brindlemoor's careers page → RR2 closes or stays open, and pay appears if stated.
- One sentence on your location and right to work → R1 moves to `direct` or `hard_gate_fail`.
- A code sample or a model-monitoring note → R3 and R7 move to high.
- Any pet, companion-animal or non-motor pricing exposure → R8 moves toward `direct`.
- Re-running the three refused checks once search permission is granted: the company check, the pay band, and Odile's public background.

## Questions

R1 — Are you based in the UK with the right to work, and is fully remote working workable for you?

G1 — Have you had any exposure to pet or companion-animal pricing, claims or benchmarking, even a side project, a product review or a competitor analysis?

G2 — For the 14 price tests, did you set the hypotheses and test design, or did you run tests others designed? What did you own?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.