**Status: `conditional_go`.** Yes, apply, on conditions. R1, R2, R3, R4 and R5 are direct, and R6 is the open must-have.

**Fit ledger.**

- `must_have`: direct: R1, R2, R3, R4, R5 · unclear: R6 (define and maintain the metrics layer)
- `important`: adjacent: R8 (partner with PMs and clinicians) · unclear: R7 (mentor two junior analysts)
- `preferred`: adjacent: R9 (healthcare data, HIPAA)

R6: who owned metric definitions decides it. R7: mentoring is not in your background. R8: stakeholder work is adjacent, clinician work is not evidenced. R9: a stated plus, not a gate.

**Hard gates:** none stated; candidate constraints not given — checks against them unknown.

**Severe red flags:** none found.

**Opportunity ledger.** An ordinary senior role on paper. The employer and posting were not checked, because the web searches were refused (RR1). Location, pay and contract type are missing (RR2), and PHI exposure is unknown (RR4). One listed mandate is broad for a single role (RR3). The experimentation program is in the duties (RR5), which is your strongest area.

**Conditions for go:**
1. R6: you can show you owned or co-owned metric definitions.
2. RR1: the role is live on Harborlight's own careers site.
3. RR2: the location, pay and contract type work for you.

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, digital-health scale-up, ~400 people, Series C, care-navigation app | `[grounded]` your JD paste; not verified (RR1) |
| Mandate | Product analytics: metrics layer, A/B tests, self-serve Looker, PM and clinician partnership, mentoring two juniors | `[grounded]` JD |
| Scope read | Lead-level analytics scope in one role, with two juniors below | `[inferred]` from duty count against title |
| Market calibration | Not run; the role-family search was refused, so there is no salary or scope band | — |
| Unknowns | Location, pay, contract type, PHI access, data-engineering support | — |
| Contradictions | None visible in the JD text you pasted | `[grounded]` JD |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | Six years stated; self-report, no artifact yet | `[grounded]` your intake | expect a probe on scope |
| R2 | Expert SQL | must_have | direct | medium | none | Daily SQL on Snowflake stated; "expert" is what a probe tests | `[grounded]` your intake | none |
| R3 | Experiment design at scale | must_have | direct | medium | none | 30+ tests a year and an 11% retention-lift pricing test stated; healthcare cohorts and slower outcomes not exercised | `[grounded]` intake; `[inferred]` the healthcare limit | pricing-test readout (upgrade menu) |
| R4 | Looker or similar BI | must_have | direct | medium | none | Built the Looker instance and 40+ governed dashboards, stated | `[grounded]` your intake | none |
| R5 | Written communication to non-technical stakeholders | must_have | direct | medium | none | Monthly exec memo and VP Product readouts; clinicians not yet a stated audience | `[grounded]` your intake | none |
| R6 | Define and maintain metrics layer | must_have | unclear | low | discovery | "Governed" dashboards imply definitions; ownership not stated | `[inferred]` from "governed" | G1 |
| R7 | Mentor two junior analysts | important | unclear | low | discovery | Nothing in intake on managing or mentoring | `[grounded]` silence | G2 |
| R8 | Partner with PMs and clinicians | important | adjacent | low | transferability | Exec and VP work is evidenced; PM and clinician partnership is not; low taken for the row | `[inferred]` from stakeholder work described | G3 |
| R9 | Healthcare data, HIPAA (a plus) | preferred | adjacent | medium | transferability | Consent-state model for consumer PII under GDPR and CCPA; no PHI, no HIPAA controls | `[grounded]` intake; `[inferred]` adjacency | G4 |

**Gap recovery queue**

| # | Gap (req) | Type | What I see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Metrics layer (R6, must_have) | discovery | Governed dashboards stated; who defined and signed off metrics is not | Must-have; resolves the row either way | Metric specs you wrote, a definitions review you led, a semantic-layer project | A metric dictionary or definitions doc | `[grounded]` silence; `[inferred]` that it resolves the row |
| G2 | Mentoring (R7, important) | discovery | Nothing stated on managing or mentoring | Explicit in the posting | Onboarding an analyst, reviewing SQL, a hiring loop, a training session | An onboarding plan or review example | `[grounded]` silence |
| G3 | Clinician partnership (R8, important) | transferability | Executive and VP stakeholder work; no clinician or PM partnership stated | Bridge: translating analysis for non-analysts carries over. Limit: clinical workflows not exercised | Co-designing a dashboard with a non-analyst owner; a readout that changed a decision | A redacted one-pager | `[inferred]` bridge; `[generic]` clinicians are a different audience |
| G4 | Healthcare data (R9, preferred) | transferability | Consent and PII governance is the nearest work; PHI is not | Limit: HIPAA controls, minimum-necessary, BAAs not exercised | Anything touching PHI, de-identification, audit trails | A consent-model design doc with PII fields redacted | `[inferred]` bridge; `[generic]` HIPAA and GDPR differ in consent and PHI handling |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer and posting unverified | unknown | — | JD paste, no link | The posting may be stale, aggregated, or not from this employer | `[generic]` pattern for postings without a link | "Is this role live on your careers site, and who would I interview with?" | unresolved |
| RR2 | Location, pay, contract type unstated | unknown | — | Nothing in the JD | Role may be on-site, below band, or fixed-term | `[grounded]` JD silence | "Where is this based, what is the base range, and is the role permanent?" | unresolved |
| RR3 | Breadth of mandate for one role | risk_signal | low | "define and maintain the metrics layer… build self-serve dashboards… mentor two junior analysts" | One analyst may also be carrying data engineering | `[inferred]` from duty count against title; `[generic]` broad mandates often lack pipeline support | "Who owns the warehouse pipelines, and how many data engineers support this team?" | unresolved |
| RR4 | PHI access and HIPAA environment | unknown | — | "healthcare data experience (HIPAA) a plus" | Daily work may involve PHI under controls you have not used | `[grounded]` JD; `[generic]` PHI access controls differ from consumer PII | "What data would I work with day to day, and what approvals and training come first?" | unresolved |
| RR5 | Experimentation program in scope | positive_signal | — | "design and analyze A/B tests" | The role owns testing, your strongest area | `[grounded]` JD | "How many experiments ran last year, and who decides what ships?" | noted |

Severe red flags: none found.

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Get the posting link from their careers site before applying | RR1 | `[grounded]` RR1 | for you to do |
| P2 | Lead with experimentation and Looker ownership | R3, R4 | `[grounded]` intake | pending your approval |
| P3 | Describe consent-state work as consumer-PII governance under GDPR and CCPA | R9 | `[grounded]` intake | pending your approval |
| P4 | Prepare one redacted artifact: the pricing-test readout or a governed dashboard, no subscriber data | R3, R4 | `[grounded]` R3, R4 | pending your approval |

Language cautions, pending your approval: say "built the consent-state model for the warehouse", not "HIPAA-compliant data". Say "my memo goes to the exec team", not "drove exec decisions", since the intake does not show that effect. Call the 11% a lift you measured, not a causal effect, unless the readout says causal.

**Evidence status**

Verified: none yet. Your intake is self-report, so no claim is verified until an artifact or a probe confirms it.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Both search calls were refused by the host, so the employer's existence and the posting's live status are unchecked (RR1) |
| 2. Role-family sweep | unavailable | Same refusal; no salary or scope band, so market calibration is empty |
| 3. Hiring manager's public footprint | n/a | No name given, so there is no query to form |

If you want to keep this, I can write it up as a `tuesday-dossier.md` you can reuse.

**Upgrade menu**

- A metric-definition doc or semantic-layer excerpt → R6 moves from low toward high.
- A redacted dashboard screenshot or Looker governance note → R4 to high.
- The pricing-test readout (design, power, guardrails) → R3 to high, and it tests the 11% claim.
- Mentoring evidence, such as an onboarding plan or review example → R7.
- Search access → targets 1 and 2 run, checking RR1 and the salary band behind RR2.

**Questions**

G1 (R6): Did you own the metric definitions, meaning who wrote them and who signed off, or did you use definitions someone else set?

G2 (R7): Have you formally managed or mentored junior analysts? How many, for how long, and what did you own: reviews, hiring, plans?

RR2: Do you have non-negotiables on location, pay floor or contract type?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.