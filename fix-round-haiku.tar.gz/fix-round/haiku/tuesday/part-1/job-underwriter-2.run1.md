**Not a waste of time, but a stretch on the title: `conditional_go`.** Your delivery and requirements work maps well to this role. The posting's first must-have is 3+ years of product management, which you don't have as a title, so expect that to be the first screen.

**Fit ledger.**

- `must_have` — direct: R3, R4, R8 · adjacent: R1 (3+ years PM experience), R2 (shipped API or platform products), R7 (own partner-API roadmap), R9 (specs and delivery with two squads) · unclear: R5 (sales and support launch coordination), R6 (agile delivery)
- `important` — unclear: R10 (adoption metrics)

R3, R4 and R8 are your strongest evidence. R1, R2, R7 and R9 are real but carry limits. R5, R6 and R10 are open questions you can answer.

**Opportunity ledger.** Unverified and under-specified, not red: RR1 (employer not checked), RR2 (decision rights unstated), RR3 (pay, location and contract type not posted). RR4 runs the other way: the scope and the metric are explicit.

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) RR2: roadmap decisions you would make verify as yours in interviews, not just input you gave; (2) R6: you can name specific agile delivery you ran; (3) RR1: the role is confirmed on Quartzline's own careers page before you invest application effort.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline, B2B logistics-tech, ~150 people, Series B | `[grounded]` JD header, unverified externally |
| Mandate | Own the roadmap for the partner-facing API platform, with two engineering squads | `[grounded]` JD |
| Scope read | A full PM remit: roadmap, discovery, specs, delivery, metrics and launches in one role | `[inferred]` from the responsibility list |
| Market calibration | Not run. Searches were refused, so no scope or pay norms are asserted | — |
| Unknowns | Decision rights, pay, location, contract type, sales and support reporting lines | — |
| Contradictions | None visible from the JD alone | `[grounded]` JD |

## Evidence map

Requirements are the JD's listed items. The JD explicitly marks only the 3+ years as "must-have", so I tiered the rest as must_have too. That is my call, and you can push back on it.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 3+ years product management | must_have | adjacent | medium | transferability | No titled PM years. Length requirement, not a legal gate, so graded on fit | `[grounded]` CV, unprobed | G1 |
| R2 | Shipped API or platform products | must_have | adjacent | medium | transferability | 30+ client integrations went live on a REST platform. You did not make the platform's product calls | `[grounded]` CV | G2 |
| R3 | Technical fluency: API docs, schemas | must_have | direct | medium | none | Postman, SQL, OpenAPI and integration architecture on CV | `[grounded]` CV, unprobed | none |
| R4 | Stakeholder management: engineering, customers | must_have | direct | medium | none | Coordinated your engineers, client engineers and PMs across custom builds | `[grounded]` CV, unprobed | none |
| R5 | Launch coordination with sales and support | must_have | unclear | low | discovery | CV is silent on sales. Support appears only as an unconfirmed prior-conversation lead | `[grounded]` CV silence | G3, Q3 |
| R6 | Agile delivery experience | must_have | unclear | low | discovery | CV names no sprints, backlog or ceremonies | `[grounded]` CV silence | G4, Q2 |
| R7 | Own the partner-API roadmap | must_have | adjacent | medium | transferability | Ran quarterly client roadmap-input sessions. Decision rights not stated | `[grounded]` CV | Q1 |
| R8 | Discovery with integration partners | must_have | direct | medium | presentation | Scoping workshops and requirements documents are discovery work. The CV files them under implementation | `[grounded]` CV; `[inferred]` reframing | A1 |
| R9 | Specs and delivery with two engineering squads | must_have | adjacent | medium | transferability | Wrote requirements documents and coordinated engineers. Did not run squad delivery | `[grounded]` CV | Q2 |
| R10 | Define and track adoption metrics | important | unclear | low | discovery | No metric on CV. SQL is a tool, not evidence of a defined measure | `[grounded]` CV silence | G5, Q3 |

## Gap recovery queue

| # | Gap (req) | Type | What I see | What would close it | Provenance |
|---|---|---|---|---|---|
| G1 | 3+ years PM (R1) | transferability | Requirements and implementation work, no titled PM | Evidence you chose what shipped, not only shaped it | `[inferred]` bridge from the CV; `[generic]` that screens often read years literally |
| G2 | Shipped platform products (R2) | transferability | Live client integrations, built on someone else's platform | A feature or API change you drove into the product because of client work | `[grounded]` CV |
| G3 | Sales and support launch (R5) | discovery | Go-live and UAT on CV; no sales or support role named | A launch plan, pre-sales scoping, or escalations you handled | `[grounded]` CV silence |
| G4 | Agile delivery (R6) | discovery | Engineering coordination without sprint vocabulary | A backlog, sprint board or ceremony you ran | `[grounded]` CV silence |
| G5 | Adoption metrics (R10) | discovery | SQL and Postman, no defined measure | A usage metric you defined and the query behind it | `[grounded]` CV silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer and posting not verified | unknown | — | "Quartzline (B2B logistics-tech, ~150 people, Series B)" | The posting may be stale or not match the company's careers page | `[generic]` pattern for postings with no checked footprint; not a claim about Quartzline | Is this role open on your careers page, and who signs off the partner-API roadmap? | unresolved |
| RR2 | Decision rights unstated | risk_signal | medium | "Own the roadmap for our partner-facing API platform" | Accountability may outrun authority, with squad priorities set elsewhere | `[inferred]` from the ownership language against its silence on authority | Which roadmap calls does this role make alone, and which go to engineering or sales leadership? | unresolved |
| RR3 | Pay, location, contract type not posted | unknown | — | Posting silent on all three | Terms may be withheld until interview | `[generic]` pattern for postings of this kind | What is the base range, where is the role based, and is it permanent? | unresolved |
| RR4 | Scope and metric explicit | positive_signal | — | "Define and track adoption metrics" | Success is defined and measurable | `[grounded]` JD | What adoption metric is this role accountable for in year one? | noted |

## Application plan

Every row is a proposal. Nothing goes into a CV or outreach without your approval.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Describe your input sessions as the feedback loop from clients into product decisions, in your own words | R7, R8 | `[grounded]` CV roadmap-input sessions | pending your approval |
| A2 | Do not use "product manager" or "owned the roadmap" for past roles; use "ran the input sessions" | R1, R7 | Reframing audit against your CV sentences | pending your approval |
| A3 | Confirm the posting on Quartzline's careers page before investing time | RR1 | `[grounded]` RR1 | pending your approval |
| A4 | Ask the recruiter RR2 and RR3 before applying | RR2, RR3 | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Unverified lead: a prior-conversation mention of an internal request-triage tool that support agents adopted. It is a lead only, used in Q3, and is not evidence.

Research tier: L1 — searches 2 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two Quartzline searches were refused by the host's search permission, and I did not retry. Would have checked RR1 and the posting's consistency |
| 2. Role-family sweep | unavailable | Same refusal. Would have calibrated scope and any pay band; none is asserted here |
| 3. Hiring manager's public footprint | n/a | No name given, so no query to form |

I have not verified that Quartzline exists as described. Treat RR1 as open.

Dossier offer: I can write this up as a `tuesday-dossier.md` you can reuse for interview prep later.

## Upgrade menu

- A live posting link or careers-page URL → RR1 closes, and the decision can move to `go` or `no_go`.
- Pay, location and contract type → RR3 closes and the hard-gate checks can run.
- Your own non-negotiables (pay floor, location, contract, start date) → hard-gate checks run against them; the snapshot line changes.
- Permission to rerun the two refused searches → RR1 and the scope and pay calibration run.
- One sprint artifact, such as a backlog export or sprint note → R6 moves up.
- One metric you defined, with the query behind it → R10 moves up.

## Questions

Q1 (RR2, R7): Think of a client-facing integration where you pushed for a roadmap change. Did you decide what shipped, or recommend it while someone else decided? Who held the call?

Q2 (R6, R9): Describe one delivery cycle you ran with engineers. Did you set the backlog and acceptance criteria, or hand requirements to a team that did? What was the cadence?

Q3 (R5, R10): A prior conversation mentions an internal request-triage tool that support agents adopted. Is that accurate? If so, what adoption measure did you track, and how did you know it was used?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.