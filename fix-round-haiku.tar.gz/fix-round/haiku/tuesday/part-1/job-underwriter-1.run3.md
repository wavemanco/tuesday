**Yes, apply, but first confirm the posting is real. Status: `conditional_go`.** On the analytics core you are a direct fit (R1, R2, R3, R4, R5). The gaps are mentoring, clinician work and HIPAA, and the posting leaves pay, location and contract type unstated. I could not check the employer: the two web searches were refused, so nothing about Harborlight Health is verified.

**Fit ledger.**

- `must_have`: direct: R1, R2, R3, R4, R5 · adjacent: R6 (Define and maintain the metrics layer)
- `important`: direct: R7a (Partner with product managers) · unclear: R8 (Mentor two junior analysts) · absent: R7b (Partner with clinicians)
- `preferred`: adjacent: R9 (Healthcare data, HIPAA)

R3 (`medium`) is confirmed but unprobed; the 11% lift's definition is not yet stated. R6 turns on whether you owned metric definitions or used ones others maintained (G2).

**Opportunity ledger.** The deliverables are concrete (RR4). The employer is unverified (RR1), the scope bundles several jobs into one title (RR2), and pay, location and contract are unstated (RR5).

- **Hard gates:** none stated in the posting; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) RR1: the posting is live on Harborlight's own careers site and the employer is as described; (2) R6 and R8: the metric-layer and mentoring scope are confirmed in the first call; (3) R9: the healthcare gap is framed as consumer-privacy adjacency, never as HIPAA experience.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, digital-health scale-up, ~400 people, Series C | `[grounded]` your posting text; not verified |
| Mandate | Own product analytics for the care-navigation app: metrics layer, A/B tests, Looker self-serve, clinician and PM partnership, two junior analysts | `[grounded]` posting |
| Scope read | Senior IC plus informal lead to two juniors, in a clinical product | `[inferred]` from the responsibility list |
| Market calibration | Not established: the role-family search was refused, so no pay band | — |
| Unknowns | Pay, location, contract type, clinical data access, how much metric ownership sits with this role | — |
| Contradictions | None found within the posting | `[grounded]` posting text |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Expert SQL | must_have | direct | medium | none | Daily SQL on Snowflake for six years; "expert" is a judgment, unprobed | `[grounded]` your statement | Be ready to walk through one real query |
| R2 | 5+ years product analytics | must_have | direct | medium | none | Six years, consumer-subscription product analytics | `[grounded]` your statement | none |
| R3 | Experiment design at scale | must_have | direct | medium | none | 30+ tests a year, program designed and run, pricing test with an 11% retention lift. Relative or absolute, and over what window, is unstated, so the ceiling is medium | `[grounded]` your statement | State the lift's definition before using it anywhere |
| R4 | Looker or similar BI tool | must_have | direct | medium | none | Built the Looker instance; 40+ governed dashboards | `[grounded]` your statement | none |
| R5 | Written communication to non-technical stakeholders | must_have | direct | medium | none | Monthly metrics memo read by the exec team; monthly VP Product presentation | `[grounded]` your statement | none |
| R6 | Define and maintain the metrics layer | must_have | adjacent | medium | transferability | Governed dashboards are the nearest work; definition ownership is unstated | `[inferred]` adjacency from governed-dashboard work | G2 |
| R7a | Partner with product managers | important | direct | medium | none | Monthly presentations to VP Product | `[grounded]` your statement | none |
| R7b | Partner with clinicians | important | absent | none | discovery | No clinical or care-team stakeholders in your background | `[grounded]` silence | G3 |
| R8 | Mentor two junior analysts | important | unclear | low | discovery | Nothing stated either way | `[grounded]` silence | G1 |
| R9 | Healthcare data experience (HIPAA) | preferred | adjacent | medium | transferability | GDPR/CCPA consumer PII and a consent-state model in the warehouse; no PHI or HIPAA work | `[inferred]` adjacency from consent-model work | Frame as consumer-privacy work, not healthcare |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Mentoring junior analysts (R8) | discovery | Nothing in your background either way | Named in the role; an important row at unclear | Onboarding a new analyst, reviewing their SQL, owning a junior's project | A mentoring plan or a before/after on a mentee's work | `[grounded]` silence; `[generic]` that mentoring weighs heavily at this seniority |
| G2 | Metrics layer ownership (R6) | transferability | Governed dashboards and metric memos, not stated definition ownership | Decides whether R6 becomes direct | Defining a metric in a semantic layer, resolving metric disputes, deprecating a metric | A metric-definition doc or a LookML/dbt snippet | `[inferred]` adjacency; `[inferred]` that this row moves the decision |
| G3 | Clinician partnership (R7b) | discovery | No clinical stakeholders stated | Named in the role; no closing path yet | Any work with care-team, ops or support leads on product decisions | A stakeholder map or a project brief | `[grounded]` silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established: research unavailable, not failed | risk_signal | low | "Harborlight Health (digital-health scale-up, ~400 people, Series C)" | The posting may be stale or aggregated, or the company may be smaller than described | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your careers site, and who would I be interviewing with? | unresolved |
| RR2 | Bundled scope: metrics owner, experimentation, mentoring, clinician partner in one title | unknown | — | "Own product analytics… and mentor two junior analysts" | The role may be a platform owner plus people manager, or a shared scope with a data team | `[inferred]` from the responsibility list | Which of these five duties is this role's own, and which sit with a data platform or analytics-engineering team? | unresolved |
| RR3 | Clinical data and HIPAA handling unstated | unknown | — | "healthcare data experience (HIPAA) a plus" | The role may touch PHI, which would require a different data-access process | `[inferred]` from the healthcare preference | Which datasets contain PHI, and who approves analyst access to them? | unresolved |
| RR4 | Concrete deliverables stated | positive_signal | — | "build self-serve dashboards in Looker" | Scope is defined and measurable | `[grounded]` posting | Which dashboards or metrics must exist in the first six months? | noted |
| RR5 | Pay, location and contract type not stated | unknown | — | (none in the posting) | The terms may be set later in the process | `[grounded]` absence in the posting | What is the pay band, location and employment type for this role? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm the posting on Harborlight's careers site and note the recruiter's domain before applying | see RR1 | `[grounded]` RR1 | pending your approval |
| E1 | Add the scope line: "Designed and ran the experimentation program: 30+ A/B tests a year" | Your own sentence, unchanged; supports R3 | `[grounded]` your statement | pending your approval |
| E2 | Write "daily SQL on Snowflake", not "expert SQL", unless you can name a query you'd defend | Keeps R1 at the confidence the evidence supports | `[grounded]` R1 | pending your approval |
| E3 | Describe the consent model as "built a consent-state model for consumer PII under GDPR and CCPA" | Frames R9 as adjacent, never as HIPAA | `[grounded]` R9 | pending your approval |

Nothing above is approved. Each proposed line goes to you as-is.

## Evidence status

Verified: none yet. Every claim so far is your own statement, not yet probed.

Research tier: L1 — searches 3 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Both searches were refused (permission not granted). Would have moved RR1 and the conditional status |
| 2. Role-family sweep | unavailable | The search was refused. Would have set the market band for R2 and RR5 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

## Upgrade menu

- Permission for the two refused searches → RR1 verified or failed, and a pay band set against RR5.
- The posting link, or the recruiter's email domain → RR1 and RR5 close or narrow.
- A pay band, location and employment type → RR5 closes.
- The 11% lift's definition and window → R3 moves to `high` once stated and checked.
- A metric-definition doc or a sanitized experiment readout → R3 and R6 move toward `high`.
- The hiring manager's name → target 3 and the positioning for that reader.

If you want, I can save this as `tuesday-dossier.md` for interview prep later.

**Two questions:**

G1 — Have you formally mentored or managed junior analysts? If so, how many, for how long, and what did you own in their development?

G2 — In your Looker and Snowflake setup, did you own the metric definitions (the metrics layer), or did you consume definitions others maintained?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.