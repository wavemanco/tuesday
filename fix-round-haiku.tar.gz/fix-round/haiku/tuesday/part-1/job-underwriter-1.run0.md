**Worth applying to, on conditions. Status: `conditional_go`.** You fit the core of this job on what you've told me. The gap is healthcare data, which the posting itself calls "a plus."

**Fit ledger.**

- `must_have`: direct: R1–R5
- `important`: adjacent: R7b (partner with clinicians) · unclear: R6 (define and maintain the metrics layer), R7a (partner with PMs on roadmap decisions), R8 (mentor two junior analysts)
- `preferred`: adjacent: R9 (healthcare data, HIPAA)

R1–R5 carry the case: all five must-haves read `direct`. R6, R7a and R8 are the unclear rows that could move the status. R9 is a transferable bridge with its limit named.

- **Opportunity ledger:** Scope is defined, and a junior team exists to mentor (RR4). Three entries are open: who sets metric definitions (RR1), the PHI and access environment (RR2), and pay and location (RR3).
- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) R6 and R8 resolve as direct or adjacent when you're asked about them (RR1 and the mentoring question); (2) the posting is live on Harborlight's own careers page (not checked at this research tier); (3) pay and location fit your constraints (RR3).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, a digital-health scale-up, ~400 people, Series C, care-navigation app | `[grounded]` your description; not verified |
| Mandate | Own product analytics: metrics layer, A/B tests, self-serve Looker, PM and clinician partnership, mentoring two juniors | `[grounded]` JD |
| First-year outcomes | Not stated | — |
| Scope read | A senior IC title that also carries a two-person team to mentor | `[inferred]` from the mentoring line against the title |
| Compensation and location | Not stated in the posting | `[grounded]` JD silence |
| Market calibration | Not run at this tier | — |
| Unknowns | Pay; location and work model; reporting line; who owns metric definitions; what PHI access analysts have | — |
| Contradictions | None visible; one source | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | Six years at one consumer-subscription company; self-report, no artifact | `[grounded]` your background | none |
| R2 | Expert SQL | must_have | direct | medium | none | Daily SQL on Snowflake for six years; self-report | `[grounded]` your background | A sanitized query or repo snippet raises to high |
| R3 | Experiment design at scale | must_have | direct | medium | none | 30+ tests a year and a pricing test behind an 11% retention lift. Confirm whether 11% is the test's measured effect or a later retention figure before using it in writing | `[grounded]` your background | A sanitized test design or readout raises to high |
| R4 | Looker or similar BI; self-serve dashboards | must_have | direct | medium | none | Built the company's Looker instance; 40+ governed dashboards | `[grounded]` your background | A dashboard screenshot raises to high |
| R5 | Written communication to non-technical stakeholders | must_have | direct | medium | none | Writes the monthly exec metrics memo; presents monthly to VP Product | `[grounded]` your background | A sanitized memo excerpt raises to high |
| R6 | Define and maintain the metrics layer | important | unclear | low | discovery | Governed dashboards imply definitions, but the CV doesn't say you set canonical definitions | `[inferred]` from "governed" | Question G1 |
| R7a | Partner with PMs on roadmap decisions | important | unclear | low | discovery | Monthly work with VP Product and experiments imply product-team work; partners and roadmap effect aren't named | `[inferred]` | Question G1 covers ownership; partners not yet asked |
| R7b | Partner with clinicians | important | adjacent | medium | transferability | Credible bridge: regular work with senior non-technical audiences. Limit: no clinical staff or clinical workflow | `[inferred]` from the exec-audience work | Gap G4 |
| R8 | Mentor two junior analysts | important | unclear | low | discovery | Nothing in the material | `[grounded]` silence | Question G2 |
| R9 | Healthcare data experience (HIPAA) | preferred | adjacent | medium | transferability | Consumer PII under GDPR/CCPA and a consent-state model. Limit: no PHI, HIPAA controls or BAAs | `[inferred]` adjacency | Gap G5 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Metrics layer ownership (R6) | discovery | Governed dashboards; no statement of setting canonical definitions | A must-have-sized duty in the JD; if you set definitions, R6 moves to `direct` | Defining a north-star or retention metric; a metric dictionary; a sign-off process for definitions | A metric definitions page or dictionary entry | `[grounded]` CV silence; `[inferred]` that it moves the row |
| G2 | Mentoring (R8) | discovery | Nothing on mentoring | Named in the posting; a direct question at interview | Onboarding or reviewing a junior analyst's SQL or analysis; running a team's analysis review | Feedback notes or a development plan (sanitized) | `[grounded]` silence |
| G4 | Clinician partnership (R7b) | transferability | Exec and VP-facing work, nothing clinical | The likely interview objection | Working with ops or support leads on a metric they used; a clinical-adjacent stakeholder | Stakeholder-facing example | `[inferred]` bridge; `[generic]` that clinicians are the likeliest objection |
| G5 | Healthcare data (R9) | transferability | Consumer privacy work, no PHI | "A plus" in the posting; a probe on the difference | Consent handling, data minimization, access controls on personal data | A consent-model summary (sanitized) | `[grounded]` intake; `[generic]` that PHI rules differ from GDPR/CCPA |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Metric-definition authority not stated | unknown | — | "define and maintain the metrics layer" | The role may maintain definitions that a central team sets | `[inferred]` from the JD's silence on who ratifies definitions | Who owns the canonical metric definitions today, and does this role change them or only consume them? | unresolved |
| RR2 | PHI and analyst access constraints | risk_signal | medium | "healthcare data experience (HIPAA) a plus" | Analysts here may face PHI access limits that slow self-serve work. `[generic]` pattern for regulated health data, not a claim about this employer | `[generic]` | What access does a product analyst have to care-navigation data, and how is PHI separated from product analytics? | unresolved |
| RR3 | Pay and location withheld | unknown | — | Not stated in the posting | Fit to your constraints is unchecked until these are known | `[grounded]` posting silence | What is the base range for this role, and where is it based? | unresolved |
| RR4 | Defined scope with a junior team | positive_signal | — | "Mentor two junior analysts" | Analytics here is a function with reports, not a solo seat | `[inferred]` from the mentoring line | What does the analytics team look like today, and how many people sit under this role? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Lead with the experiment program and the Looker build | R3, R4 are your strongest direct rows | `[grounded]` R3, R4 | pending your approval |
| A2 | Describe the consent-state work as consumer privacy under GDPR/CCPA. Don't call it healthcare data handling or HIPAA-adjacent | R9 limit; a claim here would be tested in interview | `[grounded]` intake; the reframing audit applies | pending your approval |
| A3 | Confirm the basis of the 11% figure before it appears in any written material | R3 ambiguity | `[grounded]` intake | pending your approval |
| A4 | Prepare a sanitized memo excerpt and one dashboard screenshot as work samples | Would raise R4 and R5 to high | `[generic]` that analyst panels often ask for samples | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L0 — no searches

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Research not run; L0 chosen for this pass. Would have checked that Harborlight Health exists as described and that the posting is live |
| 2. Role-family sweep | unavailable | Research not run. Would have set scope and pay norms for market calibration |
| 3. Hiring manager's public footprint | n/a | No name was given, so there is no query to form |

Dossier offer: I can save this as `tuesday-dossier.md` so the analysis carries into later work.

**Upgrade menu**

- A sanitized memo excerpt or metric definition page → R5 to high; R6 gets a reference point.
- A sanitized experiment design doc or readout → R3 to high, and settles the 11% basis.
- A sanitized dashboard screenshot → R4 to high.
- Your hard limits (location, work authorization, pay floor, start date) → adds gate rows; until then the gate line stays unchecked.
- An L1 research pass (up to 5 searches and 2 fetches): checks that Harborlight Health exists as described, that the posting is live, and sets role-family pay and scope norms. Say the word and it runs.

**Questions**

G1 — When you built the Looker instance and its 40+ dashboards, did you set the canonical metric definitions yourself, or build on definitions someone else owned? Name one metric you defined and who signed off on it.

G2 — Have you formally mentored junior analysts? How many, for how long, and what did it involve?

Constraints — Which of these are hard limits for you: work location or remote, work authorization, a pay floor, or a start date? Name the ones that apply, and the number if it's pay.

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.