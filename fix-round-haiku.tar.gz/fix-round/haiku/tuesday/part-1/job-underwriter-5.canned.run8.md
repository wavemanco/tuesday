Research tier: L1 — searches 1 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Pellucid Learning tutoring Denver Series C", which returned pellucidlearning.com/about. Fetched "Senior Data Engineer — Pellucid Learning careers" (pellucidlearning.com/careers/senior-data-engineer). The company description matches, the posting is live, and the posted text matches your pasted copy. No contradictions; the failed-attribution entry is not triggered. |
| 2. Role-family sweep | skipped | The pasted Datawright 2026 report already fixes the market band and the pay calibration it feeds. A search would re-find the same figures. |
| 3. Hiring manager's public footprint | n/a | No name was given, so there is no query to form. |

## Decision snapshot

**Yes, worth applying — `conditional_go`.** Apply if you are authorized to work in the US, can work remotely from the US or from Denver, and the pay range clears your floor (R1, R2). Your dbt, Airflow, Python and data-quality rows (R3–R7) are direct on your own account. R9 (BigQuery) is the gap that is a tool you have not used.

**Fit ledger.**

- `hard_gate` — unclear: R1 (US location and work authorization), R2 (pay against your floor)
- `must_have` — direct: R3 (5+ years data engineering), R4 (strong SQL and Python), R5 (dbt and a cloud warehouse), R6 (orchestration with Airflow or similar), R7 (experience with data quality testing) · unclear: R8 (ingestion from the app and CRM)
- `important` — adjacent: R9 (dbt-modelled warehouse in BigQuery) · unclear: R10 (data contracts analysts depend on)

R9 is the BigQuery gap, a tool you have not used. R8 and R10 are open questions about ingestion and contracts. R1 and R2 are gates that only you can settle.

**Opportunity ledger.** Sound, with open items. RR1 (pay at market) and RR3 (employer verified) are positive. RR2 (no hiring manager named) and RR4 (equity unquantified) are unknowns.

- **Hard gates:** none failed; unconfirmed: R1 (US location and work authorization), R2 (pay against your floor); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:** for `conditional_go`, the conditions are (1) R1 and R2 confirmed by you; (2) R8 and R10 hold up in the first conversations; (3) R9 is presented as Snowflake-to-BigQuery transfer, not as BigQuery experience. If R1 or R2 fails, the status becomes `no_go` with that gate as the reason.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 states, founded 2016, Denver, 264 employees, Series C ($52M, February 2026) | `[grounded]` company About page |
| Mandate | Build and run ingestion from the app and CRM, a dbt-modelled warehouse, and the data contracts analysts depend on | `[grounded]` JD |
| Stack | BigQuery is named in the role description, not in the requirements list | `[grounded]` JD text |
| Scope read | Domain ownership of the reporting pipelines, with a stated contract surface | `[inferred]` from the JD's three responsibilities |
| Market calibration | Base median $151,000, interquartile range $139,000–$163,500, for Senior Data Engineers at Series B–D companies. The posted $148,000–$166,000 straddles the median and reaches past the upper quartile. "Plus equity" is unquantified. | `[generic]` Datawright 2026 report, US, n=2,310; `[grounded]` JD figure |
| Seniority fit | Senior is typically 5–8 years in that report; your 6 years sits inside it | `[generic]` Datawright 2026 report; `[grounded]` your background |
| Unknowns | Hiring manager, equity terms, whether BigQuery is already in production | — |
| Contradictions | None between the JD and the company's careers page | `[grounded]` careers page fetched |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | US location and work authorization (Remote US or Denver) | hard_gate | unclear | none | hard_gate | Your location and authorization were not given, and nothing in the material settles them | `[grounded]` JD; candidate constraint not given | Q-R1 below |
| R2 | Pay: $148,000–$166,000 plus equity against your floor | hard_gate | unclear | none | hard_gate | Your pay floor was not given; the band itself is calibrated in role reality | `[grounded]` JD; candidate constraint not given | Q-R1 below |
| R3 | 5+ years data engineering | must_have | direct | medium | none | Six years at a B2B payroll company, self-reported, not yet inspected | `[grounded]` your background | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | Both used daily; self-reported | `[grounded]` your background | none |
| R5 | dbt and a cloud warehouse | must_have | direct | medium | none | About 180 dbt models on Snowflake, self-reported; Snowflake is a cloud warehouse | `[grounded]` your background | none |
| R6 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow orchestration, self-reported | `[grounded]` your background | none |
| R7 | Experience with data quality testing | must_have | direct | medium | none | Set up a Great Expectations suite, self-reported | `[grounded]` your background | none |
| R8 | Ingestion from the app and CRM | must_have | unclear | none | discovery | No ingestion from a product database or CRM is in your background | `[grounded]` absence from your background | G2 below |
| R9 | dbt-modelled warehouse in BigQuery | important | adjacent | medium | transferability | dbt and warehouse work carry over; the BigQuery-specific part is untested | `[grounded]` "never used BigQuery"; `[inferred]` adjacency from Snowflake dbt work | G1 below |
| R10 | Data contracts analysts depend on | important | unclear | none | discovery | Contracts are not named in your background | `[grounded]` absence from your background | G3 below |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R9, important) | transferability | Snowflake dbt work, no BigQuery. Limit: BigQuery's cost model (partitioning and clustering), its SQL dialect, and GCP IAM are untested. | This is the one tool gap, and the posting names it | Porting or building dbt models on any warehouse; cost work on a cloud warehouse | A small BigQuery dbt project or sandbox run | `[inferred]` bridge from your Snowflake work; `[generic]` that these three areas are where BigQuery differs |
| G2 | Ingestion from app and CRM (R8, must_have) | discovery | Your background shows warehouse and dbt work; the sources are not named | First responsibility in the JD | Pipelines from a product database, a SaaS CRM, or an API into a warehouse | A sanitized ingestion design or DAG | `[grounded]` absence from your background |
| G3 | Data contracts (R10, important) | discovery | Schema or consumer contracts are not named | The JD ties reporting to contracts analysts rely on | Published schemas, breaking-change process, consumer sign-off | A sanitized contract or schema-change example | `[grounded]` absence from your background |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay at market | positive_signal | — | "Salary $148,000–$166,000 plus equity" | Stated pay sits around the role-family median, not below it | `[generic]` Datawright band; `[grounded]` JD figure | — | noted |
| RR2 | Hiring manager not named | unknown | — | Posting names no hiring manager | The reporting line and pipeline ownership are not stated | `[inferred]` from the posting's silence | Who would I report to, and which team owns the warehouse and reporting pipelines today? | unresolved |
| RR3 | Employer verified | positive_signal | — | "Build and run the pipelines behind our tutoring platform's reporting" | The posting is live and consistent with the company's own site | `[grounded]` careers and About pages fetched | How far along is the BigQuery warehouse, and is it already in production? | noted |
| RR4 | Equity unquantified | unknown | — | "plus equity" | Equity may be a material or a nominal part of total pay | `[inferred]` from the missing terms | What is the equity grant size, vesting schedule, and latest valuation? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Confirm R1 and R2 for yourself before applying | Both gates are open, and they cap the decision | `[grounded]` decision rule | your call |
| P2 | Describe BigQuery as Snowflake-to-BigQuery transfer; claim no BigQuery work | R9 is adjacent, not direct | `[grounded]` R9 | pending your approval |
| P3 | Put RR2 and RR4 to the recruiter in the first call | Both are unknowns the posting leaves open | `[grounded]` RR2, RR4 | pending your approval |

## Evidence status

Verified: none yet. Your background is self-report, so every row sits at `medium` or `none`, and no claim is verified.

Research tier: L1 — searches 1 of 5, fetches 1 of 2

The tier line above, and the target table in the section that follows, count every call made. The pasted pay report stands in for the role-family sweep.

## Upgrade menu

- A small BigQuery dbt project or sandbox run gives R9 an artifact to point to.
- A sanitized example of ingestion from a product database or CRM moves R8 off `discovery`.
- A sanitized data-contract or schema-change example moves R10 off `discovery`.
- Your pay floor and location settle R1 and R2.
- The hiring manager's name would let RR2 and the positioning be checked against that reader.
- A deeper research pass on Pellucid (funding, leadership changes, past postings; up to 5 more searches and 2 more fetches). Say the word and it runs.

I can write `tuesday-dossier.md` for this role so resume-tailor and mock-interview can read it later.

## Questions

**R1, R2** — Are you authorized to work in the US, and can you work remotely from the US or from Denver? Is $148,000–$166,000 plus equity above your pay floor?

**R8** — Have you built ingestion from a product database or a CRM into a warehouse? Which tools did you use, and who owned it?

**R10** — Did analysts or other teams depend on schemas you published as contracts? Was there a breaking-change process, and who approved changes?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.