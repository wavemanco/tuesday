**Decision: `hold_pending_answers`.** Apply only if the two hard gates (Bristol hybrid and the salary range) work for you and the employer checks out. Then it becomes a `conditional_go`. Your strongest material is the Salesforce, SQL and renewal/pipeline work. The two real gaps are owning a forecast and billing data, and the posting makes both central.

**Decision snapshot**

- **Fit ledger:**
  - hard_gate, unclear: R1, R2
  - must_have, direct: R3a, R4, R5
  - must_have, adjacent: R6, R7
  - must_have, unclear: R3b
- **Hard gates:** none failed. R1 (Bristol, 2 days a week) and R2 (£61,500–£67,000) are both `unclear` because you haven't told me your location limits or pay floor.
- **Opportunity:** the employer is not verified (see risk register). Scope steps up toward forecast ownership with the CFO.

Research tier: L0, no searches. The one link was read (user links read 1). I didn't search without your go-ahead, so nothing about Quillfield beyond this posting is verified.

**Role reality**

- Revenue Operations Lead, Quillfield (invoicing software), Bristol, hybrid two days a week in the office. `[grounded]`
- Salary £61,500–£67,000 plus share options. `[grounded]` Not calibrated against the market; that needs research. `[generic]`
- Responsibilities: own CRM and billing data, build pipeline and renewal reporting, run the quarterly revenue forecast with the CFO. `[grounded]`
- Some of these responsibilities are new to you: forecast ownership sits with finance in your current role, and billing data is new. `[inferred]` from your background against the posting.
- The posting doesn't separate must-have from preferred, so I've treated every requirement as must-have. `[inferred]`

**Evidence map**

| # | Requirement | Tier | Fit | Confidence | Gap | Reasoning | Next action |
|---|---|---|---|---|---|---|---|
| R1 | Bristol, hybrid 2 days/week | hard_gate | unclear | none | hard_gate | Your location constraint isn't stated. `[grounded]` posting term | Confirm you can commit to Bristol two days a week |
| R2 | £61.5k–£67k | hard_gate | unclear | none | hard_gate | Your pay floor isn't stated. `[grounded]` posting term | Give me your floor |
| R3a | 4+ years RevOps/sales ops/analytics | must_have | direct | medium | none | Five years in sales ops, two running RevOps. Your self-report, not yet probed | none |
| R3b | At a B2B software company | must_have | unclear | low | discovery | Your employer is B2B payments. Whether that counts as software is a judgement the employer will make. `[inferred]` | Ask how they'd read payments |
| R4 | HubSpot or Salesforce admin | must_have | direct | medium | none | Salesforce admin certified. Certification not inspected | none |
| R5 | Strong SQL and spreadsheet modelling | must_have | direct | medium | none | SQL weekly and Excel daily are confirmed. Daily use doesn't by itself show forecast-grade modelling | none |
| R6 | Experience owning a forecast | must_have | adjacent | medium | transferability | You run the monthly pipeline review, a forecast input, but finance owned the company forecast | Ask what the pipeline review fed |
| R7 | Working with finance on billing or revenue data | must_have | adjacent | low | transferability | You've never worked on billing data. Revenue data at a payments company is adjacent | Ask about finance touchpoints |

**Gap recovery queue** (no questions here; the closing questions carry them)

- R1 and R2 are the gates. They are closed by your answers, not by wording.
- R6 closes if you can show specifics of the pipeline review feeding a number finance used.
- R7 closes only through real revenue or billing work. It can't be argued into existence.

**Opportunity risk register**

- **Failed attribution (standing entry):** the posting sits on a job board, not on a Quillfield domain, and I haven't confirmed the role is live on their site. `[generic]` Pattern for postings of this kind, not a claim about this one. This caps the decision at `conditional_go` until verified.
- **Scope mismatch:** the forecast-with-CFO responsibility is a step beyond the ops-and-dashboards role you run now. `[inferred]` from the posting.
- **Sector ambiguity:** "B2B software" against your payments background (see R3b).
- **Interview probe risk:** expect forecast ownership and billing data to be probed hardest. `[generic]` How this kind of role is usually interviewed.

**Application plan (as far as evidence allows)**

- Lead with the Salesforce certification, the pipeline and renewal dashboards you rebuilt, and the SQL and Excel work. These are direct matches.
- Describe the monthly pipeline review as a forecast input you run with the sales director. Don't call it forecast ownership. Only say what your review actually fed.
- Don't claim billing or revenue-data experience you don't have. Frame the gap plainly and name how you'd close it.
- Tamsin Achebe's public footprint wasn't researched at L0, so I can't suggest positioning for her.

**Evidence status**

| Target | Status | Reason |
|---|---|---|
| 1. Quillfield careers page and live posting | unavailable | L0 run, research not yet consented |
| 2. Role-family sweep (scope, title, pay) | unavailable | L0 run, research not yet consented |
| 3. Hiring manager's public footprint | unavailable | L0 run, research not yet consented |

**Dossier offer:** I can write a `tuesday-dossier.md` to carry this analysis into interview prep if you decide to apply.

**Upgrade menu**

- **Quillfield's own careers page or the recruiter's email domain** unlocks the failed-attribution check, which is the only thing standing between `hold_pending_answers` and `conditional_go`.
- **A search of the company and role-family pay** (L1, up to 5 searches and 2 fetches) unlocks the market calibration for the £61.5k–£67k range and a check on whether the role is live.
- **Your Salesforce certification** (a copy or the credential ID) raises R4 from medium to high.

**Questions** (answer in text, or say skip)

1. Can you commit to Bristol two days a week, and what's your pay floor relative to £61.5k–£67k?
2. Can you send the recruiter's email domain or the Quillfield careers link so I can confirm the role is live?
3. Did your monthly pipeline review ever feed a forecast number that finance or the CFO used, even if you didn't own it?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.