**No, not as posted.** Your fit on the capability side is strong, but the posting fails two of your hard constraints, so it's `no_go` regardless of fit.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

## Decision snapshot

**Not worth applying to. Status: `no_go`.** Both failures are terms, not fit: the posted base ($70–85k) sits $65–80k under your $150k floor, and the role is on-site in Austin five days a week, "no exceptions," against your remote-only, Portland constraint.

**Fit ledger.**

- `hard_gate` — `hard_gate_fail`: R1 (base salary at least $150k), R2 (on-site Austin 5 days)
- `must_have` — `direct`: R3 (8+ years growth leadership), R4 (paid acquisition and lifecycle), R5 (revenue ownership at scale, $8M to $40M ARR)
- `important` — `unclear`: R6 (SEO and content), R7 (brand, PR, partnerships, sales ops), R8 (merchant-facing selling)

Read as a list: R1 and R2 are the gates; R3, R4 and R5 are the fit that holds; R6, R7 and R8 are scope your intake doesn't cover yet.

- **Hard gates:** failed: R1 (base salary at least $150k), R2 (on-site Austin 5 days); met: none.
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`).
- **Opportunity ledger:** RR1 and RR2 are red flags for you specifically; RR3 (evenings and weekends) and RR4 (seven functions, one person) are risk signals; RR5 (employer unverified) stays open.
- **What would change this:** both gates would have to move. The posting says "no exceptions" on location and states a salary range, so there is no factual path to wait on.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Novaline, e-commerce enablement, Series A, "profitable since day one" | `[grounded]` posting; unverified, see RR5 |
| Mandate | Own all revenue growth across paid, SEO/content, lifecycle, brand, PR, partnerships, sales ops; "team of one to start" | `[grounded]` posting |
| Reporting | CEO, dotted line to board | `[grounded]` posting |
| Working pattern | Austin on-site five days; evenings and weekends "when it matters" | `[grounded]` posting |
| Compensation | $70–85k base plus equity | `[grounded]` posting |
| Market calibration | Not run; the role-family search was refused | — |
| Unknowns | Whether the entity exists, equity terms, how success is measured | — |
| Contradictions | None found within the posting itself | `[grounded]` posting read |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Base at least $150k (your constraint; posting states $70–85k) | hard_gate | hard_gate_fail | high | hard_gate | Your own specific, stated floor; the posted range is below it | `[grounded]` posting pay line; `[grounded]` your stated floor | none |
| R2 | On-site Austin 5 days vs remote-only, Portland | hard_gate | hard_gate_fail | high | hard_gate | Your stated constraint; posting says "no exceptions" | `[grounded]` posting; `[grounded]` your constraint | none |
| R3 | 8+ years growth leadership | must_have | direct | medium | none | Nine years, growth lead then head at two companies; not yet checked against dates | `[grounded]` your intake | none |
| R4 | Paid acquisition and lifecycle/CRM | must_have | direct | medium | none | Owned both as head of growth | `[grounded]` your intake | none |
| R5 | Revenue ownership at scale with budget control | must_have | direct | medium | presentation | $8M to $40M ARR over three years with budget you controlled; the posting's "all revenue growth" is broader | `[grounded]` your intake | none |
| R6 | SEO and content | important | unclear | low | discovery | Not in your intake; may exist | `[grounded]` absence in intake | none this turn |
| R7 | Brand, PR, partnerships, sales ops | important | unclear | low | discovery | Not in your intake; may exist | `[grounded]` absence in intake | none this turn |
| R8 | Selling to merchants (B2B) | important | unclear | low | discovery | Your background is consumer subscription; "e-commerce enablement" suggests a merchant buyer | `[inferred]` from the company line | none this turn |

## Gap recovery queue

- **G1 (R6, R7):** Discovery. Your intake is silent on SEO, brand, PR, partnerships and sales ops. Closing this would not change the decision, since both gates fail.
- **G2 (R8):** Discovery. Closing this would also not change the decision.

## Opportunity risk register

| # | Signal | Class | Severity | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|
| RR1 | Base pay withheld as a range far below your floor | red_flag | high | Compensation is set for a different seniority than the mandate describes (see R1) | `[grounded]` posting range against your floor | What base salary is budgeted for this role? | unresolved |
| RR2 | On-site five days, "no exceptions" (see R2) | red_flag | high | The company will not flex location for this role | `[grounded]` posting language | Is any part of this role remote, and under what terms? | unresolved |
| RR3 | Evenings and weekends "just who we are" | risk_signal | medium | Expectations may run beyond a normal schedule | `[inferred]` from the posting's phrasing | In a typical quarter, how often does this role work evenings or weekends, and what was the last time? | unresolved |
| RR4 | Seven functions owned by one person from day one | risk_signal | medium | The mandate may outrun the budget and headcount | `[inferred]` from scope against "team of one" | Which budget, headcount and decision rights does this role start with in year one? | unresolved |
| RR5 | Employer not established from attributable sources | risk_signal | medium | Entity may be too new to have a footprint, or the posting may be stale | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR6 | "Series A, profitable since day one" | unknown | — | Stated fact, not checked | `[grounded]` posting claim | What is current runway, and when did profitability start? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Do not apply | R1 and R2 fail; no wording changes that | `[grounded]` R1, R2 | recommended |
| A2 | If you want to test it, ask the recruiter in writing for the base range and location terms | Only a change to both would reopen this | `[grounded]` RR1, RR2 | optional, pending your approval |

## Evidence status

Verified: R1 and R2 (your own stated constraints, specific and confirmed). Your experience rows (R3 to R5) are intake prose and remain unverified; they are not needed for this decision.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Both searches for Novaline were refused, so the employer is unchecked. Would have moved RR5 and the contradictions row |
| 2. Role-family sweep | unavailable | Search was refused. Would have moved the market calibration of $70–85k |
| 3. Hiring manager's public footprint | n/a | No name was given |

## Upgrade menu

- A careers-page link or the live posting → RR5 closes or stays open; does not change `no_go`.
- Permission for the role-family search → the market calibration line; would show whether $70–85k is low for this scope.
- A deeper research pass on Novaline (funding, leadership churn, reports from candidates; up to 5 more searches and 2 more fetches) — say the word and it runs.

No open question would change this status, so I'm not asking one this turn.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.