**Yes, probably worth applying, but hold until two gate questions are answered: `hold_pending_answers`.** Your must-haves match the posting closely and the posted pay sits mid-market. I could not verify the employer or the live posting, and I don't know your location or pay floor.

Research tier: L1 — searches 1 of 5, fetches 1 of 2

Both research calls were refused for lack of permission, so no employer check ran. I did not retry.

- **Hard gates:** none failed; unconfirmed: R1 (Remote (US) or Denver office), R2 (Salary $148,000–$166,000 plus equity); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **Fit ledger:**
  - `hard_gate`: unclear: R1, R2
  - `must_have`: direct: R3, R4, R5, R6, R7
  - `important`: adjacent: R8 (dbt-modelled warehouse in BigQuery); unclear: R9, R10
- **Opportunity ledger:** The posted pay sits inside the market band (RR2). The employer is unverified and the check was refused (RR1). Scope may be broader than typical (RR3).
- **What would change this:** Your answers to G1 and G2 decide the gates. If both pass and the employer verifies, this moves to `go`. A failed gate means `no_go`.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Live online K-12 tutoring, 31 states, founded 2016, Denver, 264 staff, Series C ($52M, Feb 2026) | `[grounded]` your pasted About text; not verified |
| Mandate | Build and run reporting pipelines: app and CRM ingestion, dbt warehouse on BigQuery, analyst data contracts | `[grounded]` JD |
| Scope read | One reporting domain with end-to-end ownership; no reports stated | `[inferred]` from the JD's listed responsibilities |
| Market calibration | Posted $148k–$166k (midpoint $157k) against a $151k median and $139k–$163.5k IQR | `[generic]` band from your recruiter's report, not checked; `[grounded]` posted range |
| Unknowns | Equity value; hiring manager; whether data contracts are owned or shared; location eligibility | — |
| Contradictions | None between the JD and the careers-page text you pasted | `[grounded]` pasted text |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | Your location was not given; the gate cannot be settled from the material | `[grounded]` JD | G1 |
| R2 | Salary $148,000–$166,000 | hard_gate | unclear | none | hard_gate | Your pay floor was not given | `[grounded]` JD | G2 |
| R3 | 5+ years data engineering | must_have | direct | medium | none | Six years, self-reported; no artifact inspected | `[grounded]` your background | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | Daily use, self-reported | `[grounded]` your background | none |
| R5 | dbt and a cloud warehouse | must_have | direct | medium | none | dbt on Snowflake, ~180 models, self-reported | `[grounded]` your background | none |
| R6 | Airflow or similar orchestration | must_have | direct | medium | none | Airflow in production, self-reported | `[grounded]` your background | none |
| R7 | Data quality testing | must_have | direct | medium | none | Great Expectations suite set up by you, self-reported | `[grounded]` your background | none |
| R8 | BigQuery warehouse (stack line, not a listed requirement) | important | adjacent | low | transferability | Snowflake transfers; BigQuery itself is unused. Low, because the adjacency is unproven | `[inferred]` from the JD's stack line | Bridge case, see gap queue |
| R9 | Data contracts analysts depend on | important | unclear | none | discovery | Not in your background | `[grounded]` JD; `[generic]` that contracts are often owned by the data team | G3 |
| R10 | Ingestion from app and CRM | important | unclear | none | discovery | Not in your background | `[grounded]` JD | G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G-R8 | BigQuery (R8) | transferability | Snowflake and dbt, no BigQuery | Likely the first technical objection | Any cloud-warehouse migration or cost work; any BigQuery sandbox or course | A sanitized Snowflake-to-other migration note, or a BigQuery project | `[inferred]` bridge from Snowflake work; `[generic]` that this is the likeliest objection |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer and live posting unverified | risk_signal | medium | "Pellucid Learning runs live online tutoring…" | The entity may be real but unverified here, or the posting may be stale. The Series C and headcount are unchecked | `[generic]` pattern for companies of this size, not a claim about this one | Is this role open now on your careers site, and who would I interview with? | unresolved |
| RR2 | Pay sits inside the market band | positive_signal | — | "Salary $148,000–$166,000 plus equity" | Posting is in line with the median; the equity value is unknown | `[generic]` band from the pasted report; `[grounded]` posted range | What is the base range's basis, and how is equity valued? | unresolved |
| RR3 | Scope may be broader than one domain | unknown | — | "Build and run the pipelines…"; "the data contracts our analysts depend on" | Ownership may span ingestion, warehouse and contracts, which is wider than the typical single-domain scope | `[inferred]` from the JD's responsibilities against the report's norm | Does this role own the whole data platform, or one reporting domain, and who else is on the team? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Answer G1 and G2 before spending effort | They decide the gates | `[grounded]` R1, R2 | pending your answers |
| A2 | Verify the live posting and employer before applying | RR1 | `[generic]` pattern | pending your approval |
| A3 | In any screen, say you have not used BigQuery and bridge from Snowflake | R8 | `[grounded]` your background | pending your approval |
| A4 | Ask RR1–RR3 verbatim in the first conversation | Register doubles as interview prep | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Your claims are specific but self-reported, so they stay `medium`.

## Upgrade menu

- Your location and pay floor → R1 and R2 close; the status moves to `go` or `no_go`.
- The live posting link or the recruiter's email domain → RR1 closes.
- A sanitized dbt project, README, or Great Expectations suite → R3–R7 rise from `medium` to `high`.
- Permission for web search → I can run the employer check (up to 5 searches and 2 fetches), which would settle RR1 and check the Series C claim.

I can also write this up as a `tuesday-dossier.md` you can carry into the mock-interview module later.

**G1 — Are you based in the US, and is remote (US) or Denver workable for you?**
**G2 — Is a base of $148,000 above your floor, and does equity change your decision?**
**G3 — Have you owned data contracts with analyst consumers, or ingestion from a product app or CRM? Name the closest example.**

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.