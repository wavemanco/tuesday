**Yes, worth applying, once one question is answered: where the job is based.** The JD says fully remote UK, but the careers page says Leeds four days a week. `conditional_go`

**Fit ledger.**

- `hard_gate`: unclear: R1 (fully remote UK, as the JD states it)
- `must_have`: direct: R2 (4+ years pricing analytics), R3 (SQL and Python), R4 (GLM), R5 (presenting to underwriting or actuarial leads)
- `important`: direct: R6 (price tests), R7 (rating-model build and monitor) · adjacent: R8 (pet-insurance product)
- `preferred`: direct: R9 (general insurance)

R1 (unclear): location, see RR1; R8 (adjacent): no pet-insurance work on record, see G1.

**Opportunity ledger.** RR1 (medium) is a location conflict between the two posting sources. RR2 and RR4 (both unknown) cover the salary and contract basis, neither stated. RR3 (positive) is the hiring manager's public talk on monitoring rating models, which matches the monitoring scope.

- **Hard gates:** none failed; unconfirmed: R1 (fully remote UK, as the JD states it); candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) R1 resolves to fully remote UK, or you confirm you can work from Leeds four days a week; (2) you present pet insurance as adjacent, not as experience you have (R8); (3) salary and contract basis are confirmed before the loop (RR2, RR4).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, insurtech, pet-insurance product | `[grounded]` JD and careers page |
| Mandate | Own pricing analytics for the pet product; build and monitor rating models; design and read price tests; recommend to underwriting and product | `[grounded]` JD |
| Reporting line | Reports to the Director of Pricing; no direct reports stated | `[grounded]` careers page; neither source mentions reports |
| Working pattern | Contradiction: fully remote UK (JD) vs Leeds office four days a week (careers page) | `[grounded]` both sources |
| Salary | Not stated in the posting as pasted | `[grounded]` posting |
| Market calibration | Senior pricing analysts at UK insurers and insurtechs: median £58,400, interquartile range £52,100 to £64,900 (Pricewell 2026, n=612). Your salary floor is not known, and this is not the employer's offer | `[generic]` role-family pay survey |
| Scope read | One product, one reporting line, two named responsibilities: normal for a senior analyst | `[inferred]` from the JD and reporting line |
| Unknowns | Location, salary, contract basis, team size | — |
| Contradictions | Location, as above | `[grounded]` |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote UK (JD); Leeds four days a week (careers page) | hard_gate | unclear | none | hard_gate | Sources conflict; no location constraint from you, so nothing settles it | `[grounded]` both sources | Recruiter check; your answer (Q1) |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | Five years pricing analytics, last two as senior analyst; self-reported, no artifact yet | `[grounded]` your intake | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | Daily use stated; no artifact yet | `[grounded]` your intake | none |
| R4 | GLM experience | must_have | direct | medium | none | Built and maintained the young-driver GLM; motor, not pet | `[grounded]` your intake | none |
| R5 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | Quarterly pricing review to the head of underwriting | `[grounded]` your intake | none |
| R6 | Designing and reading price tests | important | direct | medium | none | Fourteen tests last year with underwriting; the reading and recommendation are not yet described in detail | `[grounded]` your intake | Walk through one test in the loop |
| R7 | Building and monitoring rating models | important | direct | medium | none | Built and maintained the GLM; monitoring is named by the JD, not by you | `[grounded]` build and maintenance; `[inferred]` that maintenance covers monitoring | Confirm monitoring cadence in the loop |
| R8 | Pet-insurance product pricing | important | adjacent | medium | transferability | Motor rating, GLM and test design carry over; pet claim behaviour is not exercised | `[grounded]` motor work; `[generic]` what pet pricing differs on | G1 |
| R9 | Insurance experience | preferred | direct | medium | none | Five years at a UK motor insurer | `[grounded]` your intake | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pet-insurance product pricing (R8, important) | transferability | Motor pricing, GLM and price testing; no pet work on record | The role owns the pet product, so the bridge decides whether this reads as adjacent or as a gap | Any work on claim frequency, renewal behaviour or rate adequacy, even on motor | A sanitized note on how you would price a pet book; a motor analysis you can show | `[grounded]` motor work; `[generic]` that pet pricing differs on claim frequency and renewal behaviour, the usual objection |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Location conflict across posting sources | risk_signal | medium | "fully remote" (JD); "Leeds office four days a week" (careers page) | The careers page may be stale, or the JD may be a template; either way the hard gate is open | `[inferred]` from the two sources' wording | Is this role fully remote within the UK, or does it need you in the Leeds office four days a week? | unresolved |
| RR2 | Salary not stated | unknown | — | (none in the posting as pasted) | Budget is unknown; the band is what to expect, not an offer | `[generic]` pay survey band; `[grounded]` posting silence | What base salary is budgeted for this role? | unresolved |
| RR3 | Hiring manager's public work fits the monitoring scope | positive_signal | — | "Small Books, Loud Errors", 2025 Insurance Pricing Forum talk on monitoring rating models in small books | Monitoring is a stated duty and the manager has spoken about it publicly | `[grounded]` search result for the public talk | What would success on rating-model monitoring look like after year one? | noted |
| RR4 | Contract basis not stated | unknown | — | (none in the posting as pasted) | Permanent or fixed-term is unknown | `[inferred]` from silence | Is this a permanent post, and is there a probation period? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Ask the recruiter where the role is based before you apply | RR1, R1 | `[grounded]` posting conflict | pending your approval |
| A2 | Lead with the GLM you built and maintained and the fourteen price tests, in your own words; do not describe motor work as pet work | R4, R6, R8 | `[grounded]` your intake; reframing audit applies | pending your approval |
| A3 | Ask about monitoring success measures in the loop | RR3 | `[grounded]` public talk | pending your approval |
| A4 | Learn pet-pricing basics (claim frequency, renewal behaviour) before the first interview, so the adjacency answer holds | R8 | `[generic]` | pending your approval |

## Evidence status

Verified: none yet. Your background is intake prose, so every claim sits at `medium` until you confirm it with a specific answer. Unverified leads: none. Rejected inferences: none.

Research tier: L1 — searches 4 of 5, fetches 1 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Brindlemoor "Senior Pricing Analyst" pet insurance careers" and "Brindlemoor insurtech pet insurance" (no results); fetched "Senior Pricing Analyst — Brindlemoor careers" (brindlemoor.co.uk/careers/senior-pricing-analyst). Moved the contradiction row (Leeds vs remote) and confirmed the posting is live. The employer is established by its careers page, but one search found no coverage beyond it, so the footprint is thin |
| 2. Role-family sweep | yes | Searched "senior pricing analyst pet insurance UK salary"; returned the Pricewell 2026 UK Pricing and Actuarial Analytics Pay Survey (pricewell.example/2026-uk-pricing-analytics-pay-survey). Moved the market calibration band. The remit half of the sweep was not run; the scope read is inferred |
| 3. Hiring manager's public footprint | yes | Searched "Odile Varga Director of Pricing Brindlemoor"; returned a public profile (Director of Pricing at Brindlemoor; previously head of pricing analytics at Calloway Re for six years) and the 2025 forum talk. Moved RR3 and the positioning in A2 |

## Upgrade menu

- A recruiter answer on location and salary closes R1, RR1 and RR2; the decision then becomes `go` or `no_go`.
- A sanitized pet-pricing note, or a motor analysis you can show, moves R8's bridge and raises R4 and R6 to inspectable `high`.
- Your location and any non-negotiables on contract type or pay make the hard-gate checks real. Right now they are unknown.
- A deeper research pass on Brindlemoor (funding, leadership changes, hiring history; up to 5 more searches and 2 more fetches). Say the word and it runs.

I can also emit a `tuesday-dossier.md` for this engagement if you want a file to carry into later rounds.

1. R1: Where are you based, and could you work from Leeds four days a week if that is what the role really is?
2. G1: Have you priced or tested anything on pet insurance, even briefly, or on a product with similar claim frequency or renewal behaviour?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.