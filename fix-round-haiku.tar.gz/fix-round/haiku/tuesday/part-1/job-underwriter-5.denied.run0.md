**Yes, it's worth applying to, on conditions. Status: `conditional_go`.** Your core stack matches the posting's must-haves. The gaps are BigQuery, CRM ingestion and data contracts, and the employer hasn't been checked yet.

**Fit ledger.**

- `hard_gate` — unclear: R1 (Remote (US) or our Denver office), R10 (Pay $148,000–$166,000 plus equity)
- `must_have` — direct: R2 (5+ years data engineering), R3 (strong SQL and Python), R4 (dbt and a cloud warehouse), R5 (Airflow orchestration), R6 (data quality testing)
- `important` — adjacent: R7 (BigQuery, named in the role description); unclear: R8 (ingestion from app and CRM), R9 (data contracts analysts depend on)

R2–R6 are the must-haves, all direct on your stated experience. R7 is the BigQuery gap, adjacent with its limit named. R8 and R9 are the job's ingestion and contract work, with nothing in what you've given me so far. R1 and R10 can't be checked without your location and pay floor.

**Opportunity ledger.** RR1 leaves the employer unverified in this run, which caps the decision at `conditional_go`. RR4 says the stated salary sits inside the market band. RR2 and RR3 say equity is unquantified and the hiring manager is unnamed.

- **Hard gates:** failed: none; unconfirmed: R1 (Remote (US) or our Denver office), R10 (Pay $148,000–$166,000 plus equity); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) the employer and live posting verify (RR1); (2) your location and pay floor clear R1 and R10; (3) your answer on ingestion and contracts (R8, R9) holds up in a screen.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 states; founded 2016, Denver; 264 employees; Series C, $52M, February 2026 | `[grounded]` your pasted About page, not checked in this run |
| Scope | Build and run reporting pipelines: app and CRM ingestion, a dbt warehouse on BigQuery, data contracts | `[grounded]` JD |
| Scope read | One domain's pipelines with no direct reports is the usual senior scope | `[generic]` Datawright norm; `[grounded]` JD |
| Market calibration | Senior data engineers at Series B–D: median $151,000, IQR $139,000–$163,500, 5–8 years typical. Your six years fall inside that norm | `[generic]` from the Datawright 2026 report you pasted (n=2,310); a pattern, not this employer's offer |
| Stated pay | $148,000–$166,000 plus equity; the range straddles the median and sits inside the IQR | `[grounded]` JD; comparison `[generic]` |
| Unknowns | Equity size and vesting; hiring manager; which team owns ingestion and contracts; how much BigQuery the team actually runs | — |
| Contradictions | None between the posting and your pasted About page | `[grounded]` side-by-side read of your two pastes |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | No location given, so the gate can't be settled | `[grounded]` JD | Q1 |
| R2 | 5+ years data engineering | must_have | direct | medium | none | Six years at a B2B payroll company; self-reported, no artifact yet | `[grounded]` your intake | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | Daily use, self-reported; a code sample would make it inspectable | `[grounded]` your intake | none |
| R4 | dbt and a cloud warehouse | must_have | direct | medium | none | ~180-model dbt project on Snowflake, self-reported; Snowflake meets "cloud warehouse" as written | `[grounded]` your intake; the Snowflake reading `[inferred]` | none |
| R5 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow for orchestration, self-reported | `[grounded]` your intake | none |
| R6 | Data quality testing | must_have | direct | medium | none | Set up the Great Expectations suite, self-reported | `[grounded]` your intake | none |
| R7 | BigQuery warehouse (in the role description, not a listed requirement) | important | adjacent | medium | transferability | Snowflake dbt work carries over; no BigQuery use; limits are its tooling and cost model | `[inferred]` adjacency from the Snowflake work; `[grounded]` never used BigQuery | G1 |
| R8 | Ingestion from app and CRM | important | unclear | none | discovery | Nothing in your intake on CRM or app-event ingestion | `[grounded]` silence in intake | Q2 |
| R9 | Data contracts analysts depend on | important | unclear | none | discovery | Nothing in your intake on published contracts | `[grounded]` silence in intake | Q2 |
| R10 | Pay $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | Your pay floor isn't given; the range sits in band | `[grounded]` JD; band `[generic]` | Q1 |

## Gap recovery queue

| # | Gap (req) | Type | What I see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R7, important) | transferability | Snowflake dbt work; no BigQuery | The posting names BigQuery as the warehouse, so it's the likeliest objection | Snowflake dbt patterns that port directly: sources, incremental models, tests | A sanitized model, or a short note on how you'd port one | `[inferred]` bridge from the Snowflake work; `[generic]` that this is the likeliest objection |
| G2 | Ingestion and contracts (R8, R9, important) | discovery | Nothing in intake | These are the job's core responsibilities | CRM or app-event pipelines; schema contracts with consumers | A pipeline diagram or a contract doc, sanitized | `[grounded]` silence in intake |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer and posting unverified in this run | risk_signal | medium | "Pellucid Learning runs live online tutoring…" (your paste) | The page may be stale, or the company may be smaller than presented | `[generic]` pattern for companies of this size, not a claim about this one | Which team owns this role, and is it posted on your careers site? | unresolved |
| RR2 | Equity unquantified | unknown | — | "plus equity" | Equity could be small or unrated, so total pay is unknown | `[inferred]` from the posting's silence on grant size | What is the equity grant, its vesting schedule, and the latest valuation? | unresolved |
| RR3 | Hiring manager and team unnamed | unknown | — | (no hiring manager named) | Ownership of ingestion and contracts may be shared | `[inferred]` from the posting's silence | Who would I work with day to day, and which pipelines would be mine to own? | unresolved |
| RR4 | Stated pay sits in the market band | positive_signal | — | "$148,000–$166,000" | The range is competitive for this seniority | `[grounded]` JD range; `[generic]` band | Is $148,000–$166,000 the budgeted range, and how does it move by level? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm the posting is live on the careers page before investing in an application | RR1 | `[inferred]` from RR1 | proposed |
| A2 | Screen line on the stack: "I built a dbt project of about 180 models on Snowflake. I've never used BigQuery." | R4, R7 | `[grounded]` your sentences; each clause traces to intake | pending your approval |
| A3 | Don't claim CRM or data-contract ownership unless Q2 confirms it | R8, R9 | cut-or-ask rule (reframing audit) | pending your approval |
| A4 | Ask RR1–RR3 verbatim in the first screen | the register doubles as prep | `[grounded]` register | proposed |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 1 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | One search and one fetch were refused by the tool permission prompt, and I didn't retry. The employer and live-posting checks are not done, so RR1 stays open |
| 2. Role-family sweep | skipped | Your pasted Datawright figures (median, IQR, the 5–8-year and scope norms) already fix the market calibration row |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

I can save this assessment as `tuesday-dossier.md` so mock-interview can use it later, if you want it.

## Upgrade menu

- Grant WebSearch and WebFetch and I'll rerun target 1 (up to 5 searches, 2 fetches). If the employer and posting verify, RR1 closes and the decision moves toward `go`.
- A sanitized dbt model, a Great Expectations suite excerpt, or a repo link would move R4 and R6 from medium to high.
- Any BigQuery exposure (a sandbox, a migration spike, a course project) would move R7 up from adjacent.
- The hiring manager's name would sharpen RR3 and the positioning for that reader.

**Questions**

Q1 (R1, R10): Is your location within the US, and is there a pay floor or any other non-negotiable I should check this role against?

Q2 (R8, R9): Have you built CRM or app-event ingestion, or published data contracts that analysts depended on? If so, what did you own?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.