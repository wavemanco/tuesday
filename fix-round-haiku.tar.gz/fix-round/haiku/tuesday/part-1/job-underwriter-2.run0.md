**Not a waste of time, but it's a stretch on the title, and that's the part to decide on. Status: `conditional_go`.** Apply, once the employer checks out and you can show decision-making work you actually owned.

**Fit ledger.** Your evidence is strong on the technical and customer-facing sides and adjacent on the product-ownership side, which is what the posting leads with.

- `must_have` — direct: R3, R4a, R6 · adjacent: R1 (3+ years product management), R2 (shipped API or platform products), R5 (write specs and drive delivery with two engineering squads) · unclear: R4b (stakeholder management with sales)
- `important` — direct: R9 · unclear: R7 (agile delivery), R8 (adoption metrics)
- `preferred` — none stated in the posting

**Opportunity ledger.** The posting is clear about scope and names measurable outcomes (RR4). Three things are missing: the employer is unverified (RR1, research did not run), decision rights are unstated (RR2), and pay, location and contract type are absent (RR3).

- **Hard gates:** none stated in the posting; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the role is confirmed live on Quartzline's own careers page (RR1); (2) you can answer the decision-rights and roadmap-ownership questions with specifics (RR2, R1, R2); (3) you present the product work as adjacent, never as a PM title you haven't held.
- **What would change this:** a confirmed employer and a clear answer that you personally set priorities on the integrations you led moves this toward `go`. If the employer doesn't verify, it stays at `conditional_go` with the employer as the blocker.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline, B2B logistics tech, ~150 people, Series B | `[grounded]` the JD header only; not verified |
| Mandate | Own the roadmap for a partner-facing API platform; partner discovery; specs and delivery with two engineering squads; adoption metrics; launch coordination | `[grounded]` JD |
| Scope read | A platform PM role with real delivery responsibility, not an advisory one | `[inferred]` from two squads plus partner discovery plus named metrics |
| Market calibration | Not run; pay and title norms for this role are unknown | — (research unavailable, see Evidence status) |
| Unknowns | Pay, location, contract type, decision rights against the engineering leads, whether this is a titled PM role | — |
| Contradictions | None visible in the text you pasted; the careers page was not checked | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 3+ years product management | must_have | adjacent | medium | transferability | No titled PM years. Roadmap-input sessions, specs and the playbook are PM-adjacent work. This is a years requirement, not a gate, so it is graded on fit. Titled-years requirements are often screened literally `[generic]`, so this row is where the application most likely fails | `[grounded]` CV; `[inferred]` adjacency | Q3 and A2 below |
| R2 | Shipped API or platform products | must_have | adjacent | medium | transferability | You shipped 30+ client integrations of REST APIs. You did not own the platform's roadmap, versioning or deprecation decisions, and the CV does not say you did | `[grounded]` CV; limits `[inferred]` | Q1 and A2 below |
| R3 | Technical fluency: API docs, schemas | must_have | direct | medium | none | Postman, SQL, OpenAPI reading, and 30+ integration architectures. Self-reported, so expect a probe | `[grounded]` CV | none |
| R4a | Stakeholder management: engineering and customers | must_have | direct | medium | none | Coordinated the vendor's engineers, client engineers and PMs on custom builds; scoping and UAT with customers | `[grounded]` CV | none |
| R4b | Stakeholder management: sales | must_have | unclear | low | discovery | The CV does not mention working with sales | `[grounded]` CV silence | Q2 |
| R5 | Write specs; drive delivery with two engineering squads | must_have | adjacent | medium | transferability | Requirements documents and engineering coordination on custom builds. Owning a squad's backlog is not stated | `[inferred]` adjacency from `[grounded]` CV | A2 |
| R6 | Discovery with integration partners | must_have | direct | medium | presentation | Quarterly roadmap-input sessions collecting client feedback for product. This is in one line of the CV and should be more visible | `[grounded]` CV | E1 |
| R7 | Agile delivery | important | unclear | low | discovery | Not mentioned | `[grounded]` CV silence | Q3 |
| R8 | Define and track adoption metrics | important | unclear | low | discovery | No metrics work in the CV; SQL suggests the ability | `[grounded]` CV silence | Q1 |
| R9 | Coordinate launches | important | direct | medium | none | 30+ go-lives coordinated end to end with clients. Sales and support sides are not shown here (see R4b) | `[grounded]` CV | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | No titled PM years (R1, must_have) | transferability | Seven years of adjacent work, no PM title; the playbook and roadmap-input sessions are the closest | R1 is the requirement most likely to decide the screen | Any decision you made about what an integration or feature included, or which client request won, and why | A spec you wrote that shipped, a roadmap excerpt, or the playbook section about prioritization (sanitized) | `[inferred]` bridge from the CV; `[generic]` that titled-years screens are common |
| G2 | Adoption metrics (R8, important) | discovery | Nothing in the CV | An explicit posting responsibility | Integration go-live counts, time to first successful call, usage of tools you built | A metrics view, a launch review, or a dashboard you used | `[grounded]` CV silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Quartzline (B2B logistics-tech, ~150 people, Series B)" | The posting may be stale or aggregated, or the company may be too new for a footprint | `[generic]` pattern for companies of this size, not a claim about this one | Can you confirm this role is live on your careers page, and who would I be interviewing with? | unresolved |
| RR2 | Decision rights unstated | unknown | — | "Own the roadmap … drive delivery with two engineering squads" | The PM may own scope without owning engineering priority | `[inferred]` from "own the roadmap" against "drive delivery with two squads" | Which roadmap decisions does this role make alone, and which go to the engineering leads? | unresolved |
| RR3 | Pay, location and contract type not stated | unknown | — | The posting is silent on all three | Could be a normal omission or a term that changes the calculation | `[inferred]` from the posting's silence | What is the base range, where is the role based, and is it a permanent position? | unresolved |
| RR4 | Measurable mandate named | positive_signal | — | "define and track adoption metrics" | Success is defined, which makes the role easier to assess | `[grounded]` JD | What adoption numbers would you hold this role to in year one? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Proposed resume lines, drawn only from your own sentences: "Led 30+ client integrations of REST APIs end to end, from scoping workshops through go-live." "Collected client feedback for the product team in quarterly roadmap-input sessions." "Wrote the internal integration playbook the whole team uses." These avoid "product manager", "owned the roadmap" and "set priorities", which the CV does not say | R2, R6 | `[grounded]` your CV | `resume_edits_pending_approval` |
| A1 | Verify the posting on Quartzline's careers page before investing effort in an application | RR1 | `[generic]` cheapest loss in the process | pending your approval |
| A2 | Choose one sanitized artifact to show: a spec, a roadmap input, or a playbook section | R1, R2, R5 | `[grounded]` gap queue | pending your approval |

Every row above is proposed. Nothing goes into a resume or outreach until you approve it.

## Evidence status

Verified: none yet. Every claim here is your CV's self-report, which is `medium` at best until you confirm specifics and show an artifact.

Unverified lead (memory, not evidence): a possible internal request-triage tool that support agents adopted. It is not used in any row above. If it is real, ask about it (Q2).

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | The three search calls were refused, so the employer is not verified. This is the main gap in the decision. It would have moved RR1 and the `conditional_go` cap |
| 2. Role-family sweep | unavailable | The same refusal covers it. It would have set the market band and the norm for PM scope (role reality) |
| 3. Hiring manager's public footprint | n/a | No name was given |

## Upgrade menu

- The live posting link or Quartzline's careers-page listing → closes RR1, and the decision could move to `go`.
- Pay range, location and contract type → closes RR3 and tells you whether any hard gate applies. Your own constraints were not given, so those checks are unknown.
- One sanitized product artifact (spec, roadmap input, or playbook section about prioritization) → R1 and R2 move from adjacent toward direct.
- Research when it's available: the employer check and the role-family pay band, both unavailable this run.

If you want this saved as a `tuesday-dossier.md`, say so and I'll write it.

**Questions**

Q1 (R8): Have you ever defined or tracked adoption numbers for an integration or feature, such as integrations live per quarter or time to first successful API call? What did you own, and where did the numbers live?

Q2 (R4b): Have you worked with sales on an integration deal, a pricing question or a launch commitment? If so, what did you handle directly?

Q3 (R1, R7): On the integrations you led, who set priorities between your engineering team and the client's, and did you hold any decision rights? Also, did you work in a sprint cadence with engineering?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.