**Yes, apply, but as a `conditional_go`.** On what you've told me, all four must-have rows (R1 to R4) are `direct`, and the open items are checks I could not run, your location, and the pet-insurance gap.

Web research was declined, so I could not check that Brindlemoor exists or that the posting is live. That caps the decision at `conditional_go`.

## Decision snapshot

**Status: `conditional_go`**

- **Fit ledger.**
  - `hard_gate`: unclear: H1 (Fully remote UK)
  - `must_have`: direct: R1 (4+ years pricing analytics), R2 (SQL and Python), R3 (GLM experience), R4 (presenting to underwriting leads)
  - `important`: direct: R5 (build and monitor rating models), R6 (price tests), R7a (underwriting recommendations) · adjacent: R9 (pet-insurance product) · unclear: R7b (product recommendations)
  - `preferred`: direct: R8 (insurance experience)
- **Opportunity ledger.** The posting is sound as written, but the employer is unverified (RR1), product decision rights are unstated (RR2), and management expectations are unstated (RR3).
- **Hard gates:** none failed; unconfirmed: H1 (Fully remote UK); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:**
  1. The role is confirmed live on Brindlemoor's own careers site (RR1).
  2. You confirm you can work fully remote from the UK (H1).
  3. The pet gap is presented as a transfer of motor method with its limit named, not as pet expertise (R9).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, insurtech, pet insurance | [grounded] your message; not verified (RR1) |
| Mandate | Own pricing analytics for the pet product: rating models, price tests, recommendations to underwriting and product | [grounded] JD |
| Working pattern | Fully remote, UK | [grounded] JD |
| Reporting line | Hiring manager is Odile Varga, Director of Pricing | [grounded] your message |
| Pay | Not stated in the JD you shared | [grounded] JD silence |
| Market calibration | Not run; research declined | — |
| Contradictions | None found within what you pasted | [grounded] |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| H1 | Fully remote, UK | hard_gate | unclear | none | hard_gate | No location or right-to-work statement from you yet | [grounded] JD | Question 1 |
| R1 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | Five years, last two as senior analyst; your statement, not yet inspected | [grounded] your background | none |
| R2 | Strong SQL and Python | must_have | direct | medium | none | Daily use; no code sample seen | [grounded] your background | none |
| R3 | GLM experience | must_have | direct | medium | none | Built and maintained a GLM for the young-driver book; GLMs are the standard UK motor rating model | [grounded] your background; [generic] GLM norm | none |
| R4 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | Presents the quarterly pricing review to the head of underwriting | [grounded] your background | none |
| R5 | Build and monitor rating models | important | direct | medium | none | Maintenance is stated; monitoring is not named separately | [grounded] your background; [inferred] that maintenance covers monitoring | none |
| R6 | Design and read price tests | important | direct | medium | none | Ran 14 tests last year with underwriting | [grounded] your background | none |
| R7a | Recommendations for underwriting | important | direct | medium | none | Your quarterly review goes to underwriting | [grounded] your background | none |
| R7b | Recommendations for product | important | unclear | low | discovery | No product-side recommendation stated | [grounded] silence in your background | Question 2 |
| R8 | Insurance experience | preferred | direct | medium | none | Five years at a UK motor insurer | [grounded] your background | none |
| R9 | Pet-insurance product knowledge (implied by "our pet-insurance product") | important | adjacent | medium | transferability | Motor pricing method transfers; you have no pet exposure | [grounded] your statement; [generic] pet cover and claims differ from motor | Question 3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pet-insurance product (R9, important) | transferability | Motor pricing and GLM work; no pet exposure | This is the objection most likely to come up; naming its limit protects you | Pricing or claims analysis in any personal line; any dataset with health or vet-cost variables | A short note on what changes for pet, or a motor model write-up you can reference | [grounded] your statement; [generic] the likely objection |
| G2 | Product recommendations (R7b, important) | discovery | Recommendations go to underwriting; product role not described | Decides whether you can own the product side the JD names | A product change (excess, cover limits, add-ons, eligibility) that a product lead acted on | A product-change paper or review slide | [grounded] JD; silence in your background |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established | risk_signal | medium | "Brindlemoor (insurtech)" | Unverified because the search was declined, not because the company was found absent | [generic] pattern for companies of this kind | Can you confirm this role is live on Brindlemoor's own careers site, and who I would interview with? | unresolved |
| RR2 | Product decision rights unstated | unknown | — | "turn the results into recommendations for … product" | The role may recommend on product without deciding | [inferred] from the JD's wording against its silence on decision rights | Which product decisions does this role make itself, and which go to committee? | unresolved |
| RR3 | Management expectation unstated | unknown | — | "Senior Pricing Analyst" | The senior title may carry people leadership; the posting is silent | [inferred] from the title against the JD's silence | Does this role have direct reports now or planned, and would it lead other analysts? | unresolved |
| RR4 | Pay not stated | unknown | — | none quoted | Band unknown; no market check was possible | [grounded] JD silence | What is the budgeted base salary for this role? | unresolved |
| RR5 | Specific mandate and named manager | positive_signal | — | "Director of Pricing" | Reporting line and responsibilities are concrete | [grounded] your message | What would success look like in the first six months? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Verify the posting on the careers site before spending application effort | RR1 | [generic] pattern for companies of this kind | pending your approval |
| A2 | Lead with the GLM and price-test work; name pet as a transfer with its limit | R3, R6, R9 | [grounded] rows | pending your approval |
| A3 | Describe the underwriting review as a quarterly review you presented, not as a decision you made | R4 | [grounded] your background | pending your approval |
| A4 | Ask the RR2 to RR4 questions at first contact | RR2–RR4 | [grounded] register | pending your approval |

## Evidence status

Verified: none yet. Your background is intake prose, so it stands at `medium` until a CV or an artifact is seen.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searches for the careers page were declined; the posting's liveness and the company's existence are unchecked (RR1) |
| 2. Role-family sweep | unavailable | Pay and remit benchmark for this title not checked; no market calibration line |
| 3. Hiring manager's public footprint | unavailable | Search on Odile Varga's name was declined; no public background checked |

## Dossier offer

If you want, I can save this as a `tuesday-dossier.md` so the verification questions travel with it.

## Upgrade menu

- A CV, or one model write-up or anonymised price-test readout → R1 to R6 move from `medium` toward `high`.
- The careers-page link to the live posting → RR1 closes.
- A pay figure → RR4 closes.
- Permission to web-search (up to 5 searches and 2 fetches) → RR1 is checked, the pay band is set, and the hiring manager's scope is read.

## Questions

1. **H1:** Are you based in the UK with the right to work there, and can you take a fully remote UK role?
2. **G2:** Have you ever proposed a product change (pricing structure, cover, eligibility) that a product lead acted on? What did you own?
3. **G1:** Have you done any pricing or claims analysis outside motor, such as home, travel or another personal line?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.