**No, don't pursue it.** Your sense that something is off is right: base pay (R1) and location (R2) both fail your stated constraints, and the posting states both as fixed · `no_go`

- **Fit ledger (your side):**
  - `hard_gate` — hard_gate_fail: R1 (base pay), R2 (location)
  - `must_have` — direct: R3 (growth leadership), R4 (paid acquisition), R5 (lifecycle/CRM), R6 (revenue ownership with a budget)
  - `important` — unclear: R7 (SEO and content), R8 (brand and PR), R9 (partnerships and sales ops)
- **Opportunity ledger:** RR1 (base below your floor) and RR2 (on-site, "no exceptions") are the severe red flags. RR3 (always-on) and RR4 (seven functions, one person) are risk signals. RR5 (employer not checked) is open. RR6 (Series A, profitable) is the only positive signal, and it is the employer's own claim.
- **Hard gates:** failed: R1 (base pay), R2 (remote-only location).
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`).
- **What would change this:** the posted terms would have to move to a base at or above $150k and a remote arrangement. Research could not clear either gate, and the posting already rules out the office term. Your floor and remote-only rule are yours to revise. I have not assumed either moves.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Novaline, e-commerce enablement, Series A, "profitable since day one" | `[grounded]` JD; the employer's own claim, not checked |
| Mandate | All revenue growth: paid, SEO/content, lifecycle/CRM, brand, PR, partnerships, sales ops | `[grounded]` JD |
| Team and reporting | "A team of one to start"; reports to the CEO, dotted line to the board | `[grounded]` JD |
| Working pattern | On-site in Austin five days a week, "no exceptions"; evenings and weekends "when it matters" | `[grounded]` JD |
| Scope read | Seven growth functions for one person is a broad remit with no stated budget | `[inferred]` from the function count against "team of one" |
| Pay against your floor | Posted $70–85k base is $65k short of your $150k at the top of the range and $80k short at the bottom | `[grounded]` JD and your stated floor; arithmetic only |
| Market calibration | Not run. The search was refused, so I have no source for what this title pays. The posted band is the only figure in hand and is not a market reading | — |
| Unknowns | Whether the company sells to brands or to shoppers; equity size; whether the Series A and profitability claims are current | — |
| Contradictions | None between sources. Tension: a seven-function mandate staffed as "a team of one" | `[inferred]` |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Base pay (your $150k floor) | hard_gate | hard_gate_fail | high | hard_gate | Your own specific constraint. Posted base is $70–85k | `[grounded]` JD; your statement | none; the gate stands |
| R2 | Remote-only, Portland, no relocation | hard_gate | hard_gate_fail | high | hard_gate | Your own constraint. Posting requires on-site Austin, five days, "no exceptions" | `[grounded]` JD; your statement | none; the gate stands |
| R3 | 8+ years growth leadership | must_have | direct | medium | none | Nine years, growth lead then Head of Growth at two companies. Intake prose, so no inspectable artifact yet | `[grounded]` your description | none |
| R4 | Paid acquisition | must_have | direct | medium | none | You owned paid at both companies | `[grounded]` your description | none |
| R5 | Lifecycle/CRM | must_have | direct | medium | none | Owned lifecycle; Braze in use | `[grounded]` your description | none |
| R6 | Revenue ownership end to end | must_have | direct | medium | none | Scaled one company from $8M to $40M ARR over three years with a budget you controlled | `[grounded]` your description | none |
| R7 | SEO and content | important | unclear | none | discovery | Not in your background as stated | `[grounded]` absence from your background | none while the gates stand |
| R8 | Brand and PR | important | unclear | none | discovery | Not in your background as stated | `[grounded]` absence from your background | none while the gates stand |
| R9 | Partnerships and sales ops | important | unclear | none | discovery | Not in your background as stated | `[grounded]` absence from your background | none while the gates stand |

## Gap recovery queue

Empty for decision purposes. R7–R9 are unclear, but no recovery of them would change `no_go`, so nothing is queued.

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Base pay below your stated floor | red_flag | high | "$70–85k base plus meaningful equity upside" | At every point of the range the base sits well below your floor; equity does not change the base test | `[grounded]` JD against your stated floor | "Is $70–85k the full base range for this role, or is there a higher band for this scope?" | unresolved |
| RR2 | On-site five days, no exceptions | red_flag | high | "On-site in our Austin office 5 days a week — no exceptions." | The posting states an office term that conflicts with your remote-only constraint | `[grounded]` JD against your stated constraint | "Is any Novaline role fully remote today, and is that written into offers?" | unresolved |
| RR3 | Always-on expectation | risk_signal | medium | "evenings and weekends when it matters is just who we are" | Off-hours work is described as the norm rather than an exception | `[inferred]` from the JD's wording | "What does a normal month look like for this role on evenings and weekends?" | unresolved |
| RR4 | Responsibility without staff | risk_signal | medium | "a team of one to start… players who don't need a bench" | Seven functions with no stated team, budget or decision rights | `[inferred]` from scope against silence on budget | "What budget and headcount are committed to this role in year one, and which functions have an owner today?" | unresolved |
| RR5 | Employer not checked | risk_signal | medium | "Novaline (e-commerce enablement startup, Series A…)" | The company could not be verified; the search was refused. This is a gap in checking, not a finding against the company | `[generic]` pattern for companies of this size, not a claim about this one | "Who led the Series A, and where is this role posted on your own careers site?" | unresolved |
| RR6 | Stated profitability and Series A | positive_signal | — | "profitable since day one" | If accurate, the company is not dependent on raising to pay its bills | `[grounded]` the posting's own claim, unchecked | "Can you share current revenue and runway at a level you can share?" | noted |

## Application plan

No plan is proposed. With two hard gates failed, the recommendation is not to apply to this role. Nothing is drafted, so no resume edits or outreach are pending.

## Evidence status

Verified: R1 and R2 (your stated constraints, which the posting does not meet). Unverified, at the intake ceiling: R3–R6, from your description with no inspectable artifact yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches sent ("Novaline e-commerce enablement startup Series A"; "Novaline careers Head of Growth Austin"). Both refused because WebSearch permission was not granted. Would have checked that Novaline exists as described and that the posting is live (RR5) |
| 2. Role-family sweep | unavailable | One search sent ("Head of Growth salary Series A startup base compensation range 2026"). Refused. Would have set a market band and scope norm; no market calibration is given |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

The decision does not depend on the refused checks. R1 and R2 come from the posting and your own constraints.

## Dossier offer

If you want this kept, I can write it to `tuesday-dossier.md` for the other modules to read.

## Upgrade menu

- Allowing web search would check RR5 (that Novaline exists and the posting is live) and set a market band for the scope and pay read. The decision would not change, because no search result can clear R1 or R2.

No questions this turn. Nothing you could answer changes `no_go`, and I'm not looking for a workaround to either gate.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.