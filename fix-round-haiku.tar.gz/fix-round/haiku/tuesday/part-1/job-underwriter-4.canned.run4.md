**Yes on the fit. Not yet on the terms: hold until you've confirmed the location.** `hold_pending_answers`

**Fit ledger.**

- `hard_gate`: unclear: R1 (fully remote UK, or Leeds four days a week)
- `must_have`: direct: R2 (4+ years pricing analytics), R3 (SQL and Python), R4 (GLM), R5 (presenting to underwriting leads), R6 (designing and reading price tests)
- `important`: direct: R7 (building and monitoring rating models) · adjacent: R8 (pet-insurance pricing)
- `preferred`: direct: R9 (insurance experience)

Your methods match this JD closely; the open questions are location and the pet-insurance transfer. R8 is `adjacent` with the limit named, not `direct`. Every `direct` row sits at `medium` because your background is self-report and nothing has been inspected yet.

**Opportunity ledger.** The posting contradicts itself on location (RR1, `severity: high`), and the employer has a thin public footprint (RR2). The hiring manager's public talk on monitoring rating models in small books lines up with the role's remit (RR5, positive).

- **Hard gates:** none failed; unconfirmed: R1 (fully remote UK vs Leeds four days a week); candidate constraints not given — checks against them unknown
- **Severe red flags:** RR1 (`severity: high`)
- **What would change this:** If the role is genuinely remote UK, the status moves to `conditional_go`, conditional on RR2 verifying and the pay band being acceptable. If Leeds four days a week is the real term and you can't do it, it's `no_go`.

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, insurtech; pet-insurance product | `[grounded]` JD and brindlemoor.co.uk careers page |
| Role | Senior Pricing Analyst, owns pricing analytics, reports to the Director of Pricing | `[grounded]` JD and careers page |
| Working pattern | **Contradiction:** JD says "Fully remote (UK)"; careers page says "Leeds office four days a week" | `[grounded]` both sources |
| Hiring manager | Odile Varga, Director of Pricing. Public talk at the 2025 Insurance Pricing Forum, "Small Books, Loud Errors", on monitoring rating models in small books. Previously head of pricing analytics at Calloway Re for six years | `[grounded]` search snippets, not fetched; matched on name and title |
| Pay | Not in the JD you pasted, and not on the careers page | — |
| Market calibration | Median base £58,400; interquartile range £52,100–£64,900 for senior pricing analysts at UK insurers and insurtechs (n=612) | `[generic]` Pricewell 2026 pay survey, search snippet, not fetched |
| Unknowns | Location; pay; whether the role line-manages anyone (not stated; you have never managed) | — |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Location: fully remote UK (JD) vs Leeds four days a week (careers page) | hard_gate | unclear | none | hard_gate | No location constraint given by you; the posting contradicts itself, so the gate isn't settled | `[grounded]` both sources | Q1 below; ask recruiter which is correct |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | 5 years, last 2 senior; self-reported | `[grounded]` your background | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | Daily use; self-reported | `[grounded]` your background | none |
| R4 | GLM experience | must_have | direct | medium | none | Built and maintained the young-driver GLM (motor) | `[grounded]` your background | none |
| R5 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | Quarterly pricing review to the head of underwriting | `[grounded]` your background | none |
| R6 | Designing and reading price tests | must_have | direct | medium | none | 14 tests last year with the underwriting team | `[grounded]` your background | none |
| R7 | Building and monitoring rating models | important | direct | medium | none | Built and maintained the GLM; monitoring is part of that | `[grounded]` your background | none |
| R8 | Pet-insurance pricing (implied by "our pet-insurance product") | important | adjacent | medium | transferability | General pricing and GLM method carry over; no pet-specific data, pricing structure or claims experience | `[inferred]` from the JD's product line against your motor work | G1 below |
| R9 | Insurance experience | preferred | direct | medium | none | UK motor insurer | `[grounded]` your background | none |

**Gap recovery queue**

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pet-insurance pricing (R8, important) | transferability | Motor pricing only; no pet data or pet product | Bridge: the method (GLM, price tests, monitoring) carries over; the limit is pet-specific risk drivers and claims behaviour, which you haven't exercised | Any rating-factor work where the risk drivers were unfamiliar; any price test run on a new product or segment | A sanitized price-test write-up or model monitoring pack, presented as method | `[inferred]` bridge from your motor work; `[generic]` that pet risk drivers differ from motor |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Location contradicts itself across the two sources | red_flag | high | "Fully remote (UK)" vs "Leeds office four days a week" | The careers page may be current and the JD you have may be out of date, or the reverse | `[inferred]` from the two sources' wording | Is this role fully remote from the UK, or is it Leeds four days a week? | unresolved |
| RR2 | Employer has a thin public footprint | risk_signal | medium | "Accepting applications" (careers page only) | A small or new company; the careers page is the only attributable source found | `[generic]` pattern for companies of this size, not a claim about this one | Can you confirm the team size and how long the pet product has been live? | unresolved |
| RR3 | Pay not shown | unknown | — | (absent from the JD and the careers page) | The role may sit below the band in the market calibration, or the company may not publish pay | `[inferred]` from the withheld figure, against the `[generic]` band | What is the budgeted salary for this role? | unresolved |
| RR4 | Line-management scope not stated | unknown | — | "Own pricing analytics" (no reports mentioned) | The role may be an individual contributor, or may include direct reports you haven't been told about | `[inferred]` from the JD's silence | Does this role line-manage anyone, now or planned? | unresolved |
| RR5 | Hiring manager's public work aligns with the role's monitoring remit | positive_signal | — | Talk title: "Small Books, Loud Errors" | Monitoring rating models in small books is central to this role; the monitoring experience you have is the story to lead with for this reader | `[grounded]` talk title from search snippet | — | noted |

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Ask the recruiter whether the role is remote or Leeds four days a week before investing in an application | see RR1, R1 | `[grounded]` RR1 | pending your approval |
| A2 | Verify the employer exists beyond the careers page: ask for the team size and the product's launch date | see RR2 | `[generic]` pattern for companies of this size | pending your approval |
| A3 | Once the location is confirmed, lead with the monitoring and price-test work for this reader | see RR5, R6, R7 | `[inferred]` from RR5 | pending your approval |

**Evidence status**

Verified: none yet. Every claim above is your self-report, held at `medium`.

Research tier: L1 — searches 4 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Brindlemoor pet insurance insurtech" (no results) and "Brindlemoor Senior Pricing Analyst pet insurance careers", which returned the careers page; fetched "Senior Pricing Analyst — Brindlemoor careers" (brindlemoor.co.uk/careers/senior-pricing-analyst). Moved RR1 (location contradiction) and RR2 (thin footprint) |
| 2. Role-family sweep | yes | Searched "senior pricing analyst pet insurance UK salary GLM", which returned "Pricewell 2026 UK Pricing and Actuarial Analytics Pay Survey" (pricewell.example). Moved the market calibration line and RR3 |
| 3. Hiring manager's public footprint | yes | Searched "Odile Varga Director of Pricing Brindlemoor", which returned a professional profile with the 2025 talk and prior role. Moved RR5 and the positioning in A3 |

**Upgrade menu**

- Confirmed location (remote, or Leeds four days) → R1 closes; the status moves to `conditional_go` or `no_go`.
- A pay figure or band from the recruiter → RR3 closes and is set against the market band.
- A sanitized price-test write-up or monitoring pack → R8's bridge strengthens, and R6 and R7 move to a higher confidence band.
- A deeper research pass on Brindlemoor (funding, leadership, recent news; up to 5 more searches and 2 more fetches) → RR2 resolves one way or the other. Say the word and it runs.

If you'd like, I can write this up as a `tuesday-dossier.md` to carry into the application.

**Questions**

R1 — Can you work from Leeds four days a week? Is fully remote a requirement for you?
RR3 — What is your pay floor for this role?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.