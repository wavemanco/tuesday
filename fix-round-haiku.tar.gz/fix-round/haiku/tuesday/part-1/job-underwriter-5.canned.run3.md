**Yes, it's worth applying, once two checks clear.** Your background matches most of the posting, and the pay is at market. Two things only you can answer come first: your pay floor and your location. Status: `hold_pending_answers`.

**Fit ledger.**

- `hard_gate`: unclear: R1 (remote US or Denver office), R2 (base pay $148,000–$166,000)
- `must_have`: direct: R4 (5+ years data engineering), R5 (SQL and Python), R6 (dbt and a cloud warehouse), R7 (Airflow or similar), R8 (data quality testing)
- `important`: direct: R12 (one domain's pipelines, no direct reports) · adjacent: R9 (warehouse modelled in BigQuery) · unclear: R10 (app and CRM ingestion), R11 (data contracts)

What matters:

- R1 and R2: the two checks before you apply
- R9: BigQuery is a transfer from Snowflake, with a limit
- R10 and R11: ingestion and data contracts, which your background does not show

**Opportunity ledger.** The posting is live and matches what you sent. Its pay sits in the market band (RR4). The employer is real on its own pages, but I found no independent source for it (RR1). Equity is unstated (RR2) and no hiring manager is named (RR3).

- **Hard gates:** unconfirmed: R1 (remote US or Denver office), R2 (base pay $148,000–$166,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:** if your pay floor is at or below $166,000 and your location fits, the status moves to `conditional_go`. Conditions: state the BigQuery bridge with its limit (R9), show CRM or contract work in the screen (R10, R11), and check the Series C and headcount outside the company's own site (RR1).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online K-12 tutoring in 31 US states; founded 2016 in Denver; 264 employees; Series C, $52M, February 2026 | `[grounded]` company About page, fetched |
| Role | Build and run tutoring-reporting pipelines; app and CRM ingestion; dbt warehouse in BigQuery; data contracts | `[grounded]` posting, fetched; live and accepting applications |
| Scope read | One domain's pipelines, no direct reports | `[inferred]` from the posting's responsibilities |
| Market calibration | Senior Data Engineer at Series B–D: base median $151,000; interquartile range $139,000–$163,500. Posted range $148,000–$166,000, midpoint $157,000 | `[generic]` Datawright 2026 report (n=2,310; the same figures as your recruiter's copy). The posted range is `[grounded]` |
| Stage | Evaluating (assumed; you did not say) | `[inferred]` from your message |
| Unknowns | Equity amount, hiring manager, your pay floor and location, interview process | — |
| Contradictions | None between the posting you sent and the live careers page | `[grounded]` both read |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote US or Denver office | hard_gate | unclear | none | hard_gate | No location constraint given, so the gate is not established | `[grounded]` posting | Q1 |
| R2 | Base pay $148,000–$166,000 | hard_gate | unclear | none | hard_gate | No pay floor given | `[grounded]` posting | Q1 |
| R4 | 5+ years data engineering | must_have | direct | medium | none | Six years at a B2B payroll company; self-reported, so `medium` is the ceiling at intake | `[grounded]` your background | none |
| R5 | Strong SQL and Python | must_have | direct | medium | none | Daily use; self-reported | `[grounded]` your background | none |
| R6 | dbt and a cloud warehouse | must_have | direct | medium | none | About 180 dbt models on Snowflake, a cloud warehouse | `[grounded]` your background | none |
| R7 | Airflow or similar orchestration | must_have | direct | medium | none | Airflow orchestration; self-reported | `[grounded]` your background | none |
| R8 | Data quality testing | must_have | direct | medium | none | Set up a Great Expectations suite; self-reported | `[grounded]` your background | none |
| R9 | Warehouse modelled in BigQuery | important | adjacent | medium | transferability | dbt modelling carries over; BigQuery-specific work is not exercised, and that is the limit | `[inferred]` adjacency from R6; `[grounded]` that you have not used BigQuery | RG1 |
| R10 | Ingestion from app and CRM | important | unclear | low | discovery | Your background does not name app or CRM ingestion | `[grounded]` silence in your background | Q2 |
| R11 | Data contracts analysts depend on | important | unclear | low | discovery | Not named in your background | `[grounded]` silence in your background | Q2 |
| R12 | Own one domain's pipelines | important | direct | medium | none | Payroll pipeline ownership matches the posted scope | `[inferred]` scope read against the posting | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| RG1 | BigQuery (R9) | transferability | dbt modelling on Snowflake; no BigQuery work | The posting names BigQuery; the limit is partitioning, clustering, cost, and the SQL dialect | Any warehouse cost or partitioning decision; a dbt project you moved between platforms | A short BigQuery project, or a cost or partitioning note | `[inferred]` bridge from R6; `[generic]` that BigQuery cost work is the likely probe |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Independent footprint not found | risk_signal | low | "live online tutoring for K-12 schools in 31 US states" | The entity is real on its own pages, but one independent search returned nothing | `[generic]` pattern for companies of this size, not a claim about this one | Can you share the February 2026 Series C announcement, or a source for the 264 headcount outside your own site? | unresolved |
| RR2 | Equity amount unstated | unknown | — | "plus equity" | Equity could be small relative to base | `[inferred]` from posting silence | What is the equity grant for this role, in shares or percent, and what is the vesting schedule? | unresolved |
| RR3 | Hiring manager unnamed | unknown | — | (posting names none) | Team and manager are not visible | `[grounded]` posting | Which team would this role join, and who owns the analyst data contracts today? | unresolved |
| RR4 | Posted pay in the market band | positive_signal | — | "$148,000–$166,000" | The range sits within the Series B–D band | `[generic]` band; `[grounded]` posted range | Is this range the budgeted figure for this level? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm your pay floor and location against R1 and R2 before applying | Decides the hold | `[grounded]` posting | pending your approval |
| A2 | Draft a BigQuery bridge: dbt modelling carries over from Snowflake; state plainly what you have not done on BigQuery | see R9 | `[inferred]` from R6 and R9 | pending your approval |
| A3 | Ask RR1–RR3 in the first screen | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Your background is intake prose, so it is self-report at the `medium` ceiling. No claim is user-confirmed.

Research tier: L1 — searches 3 of 5, fetches 2 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Pellucid Learning careers senior data engineer" and fetched the careers page (pellucidlearning.com/careers/senior-data-engineer), which is live and matches your copy, and the About page (pellucidlearning.com/about), which gives the 31 states, 264 employees and Series C. Searched "Pellucid Learning live online tutoring K-12 Denver": no results, so no independent source was found. Moved: contradictions row (none), RR1 |
| 2. Role-family sweep | yes | Searched "senior data engineer base salary median 2026 Series B to D", which returned the Datawright 2026 Data Engineering Pay Report (datawright.example/2026-data-engineering-pay-report). Moved: market calibration |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form. The upgrade menu names what a name would unlock |

## Upgrade menu

- Your pay floor and location → R1 and R2 resolve, and the hold becomes a go or a no-go.
- A short BigQuery project or cost note → R9 moves toward `direct`.
- A repo, design doc, or contract spec showing CRM ingestion or data contracts → R10 and R11 move off `discovery`.
- The Series C announcement, or any source outside the company's own site → RR1 closes.
- The hiring manager's name → RR3 closes, and research target 3 can run.
- A deeper pass on Pellucid (leadership changes, hiring patterns, recent news; up to 5 more searches and 2 more fetches). Say the word and it runs.

If you want, I can save this assessment as `tuesday-dossier.md` so mock-interview can reuse it.

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Q1 (R1, R2):** What is your base-pay floor, and can you work remote in the US or from the Denver office?

**Q2 (R10, R11):** Have you owned ingestion from a product app or a CRM, or set data contracts with analysts? What did you own, and what broke?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.