**Yes, apply, once the posting checks out.** On the core analytics requirements you're a strong fit: SQL, experimentation, Looker, and exec-facing writing are all direct, and the gaps are healthcare data and clinician partnership. Research didn't run, so the employer is unverified and that caps this at a conditional go.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

**Decision snapshot**

**Apply, once Harborlight Health and this posting are verified. Status: `conditional_go`.**

**Fit ledger.**
- `hard_gate` — none stated in the posting.
- `must_have` — direct: R1, R2, R3, R4, R5 · adjacent: R6
- `important` — adjacent: R7 · unclear: R8
- `preferred` — adjacent: R9 (HIPAA / healthcare data)

R1 (5+ years) through R5 rest on your own statements at `medium`, since nothing inspectable has been shown yet. R6 is the one must-have where the work sits next to the requirement rather than on it.

**Opportunity ledger.** The posting is specific about the role's scope, but the employer is unverified (RR1, `severity: medium`), and salary (RR2), location and contract terms (RR3) are withheld.

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) RR1 clears: the live posting or the company's own careers page confirms the role exists as described; (2) RR2 and RR3 get answers you can accept; (3) in every application, you claim the healthcare gap as a gap, not as experience.

**What would change this:** a clean employer check plus acceptable pay and location moves it to `go`. A failed check means `hold` or `no_go`.

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, digital-health scale-up, ~400 people, Series C, care-navigation app | `[grounded]` your JD and message; not verified |
| Mandate | Own product analytics: metrics layer, A/B tests, Looker self-serve, PM and clinician partnership, mentoring two juniors | `[grounded]` JD |
| Scope read | Senior IC plus informal mentoring; reasonable for the title | `[inferred]` from the responsibility list |
| Market calibration | Not established: the salary sweep was refused, so there is no band to set against | — |
| Unknowns | Salary, location/remote, contract type, team structure, whether the two juniors are direct reports | — |
| Contradictions | None visible in the posting itself | `[grounded]` JD |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | Six years stated; no artifact yet | `[grounded]` your statement | none |
| R2 | Expert SQL | must_have | direct | medium | none | Daily SQL on Snowflake, stated | `[grounded]` your statement | none |
| R3 | Experiment design at scale | must_have | direct | medium | none | 30+ tests a year and the pricing test are stated; the 11% lift has no artifact | `[grounded]` your statement | Have the test readout ready |
| R4 | Looker or similar BI | must_have | direct | medium | none | Built the instance and 40+ dashboards, stated | `[grounded]` your statement | none |
| R5 | Written communication to non-technical stakeholders | must_have | direct | medium | none | Monthly exec memo and VP presentations, stated | `[grounded]` your statement | none |
| R6 | Define and maintain the metrics layer | must_have | adjacent | medium | transferability | You built governed dashboards, but a maintained metric catalogue is not stated | `[inferred]` from "governed dashboards" | Ask who owned metric definitions (G1) |
| R7 | Partner with PMs and clinicians on roadmap | important | adjacent | low | transferability | PM partnership is stated; clinician work is not | `[grounded]` your statement; `[inferred]` on the clinician side | Ask about clinical stakeholders (G2) |
| R8 | Mentor two junior analysts | important | unclear | low | discovery | Not mentioned | — | Ask (G3) |
| R9 | Healthcare data / HIPAA | preferred | adjacent | medium | transferability | GDPR/CCPA consumer PII and a consent-state model are adjacent, not HIPAA | `[grounded]` your statement | none |

**Gap recovery queue**

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Metrics layer ownership (R6, must_have) | transferability | Governed dashboards, no stated metric catalogue | A must-have at `adjacent`; a catalogue would move it to direct | Metric dictionary, semantic-layer definitions, a metric review process | A metrics doc or dashboard-governance spec | `[inferred]` from your dashboards |
| G2 | Clinician partnership (R7) | transferability | PM work stated; clinician work not | Clinicians are named in the JD and are a likely interview probe | Work with ops, care, or customer-support teams that shaped a product decision | Any stakeholder brief from that work | `[generic]` that this role family is probed on clinical stakeholders |
| G3 | Mentoring (R8) | discovery | Not mentioned | Named in the JD; no evidence either way | Onboarding, reviewing SQL, running analyst reviews | Onboarding plan or review notes | `[grounded]` JD |
| G4 | HIPAA / PHI (R9) | transferability | Consent and PII work only | Preferred, but a common question for this employer type | Any work touching regulated or health-adjacent data | Data-handling policy you worked under | `[generic]` for health-data employers |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Harborlight Health" (JD header) | The company may be too new or small to have a footprint, or the posting may be stale | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the live posting on your careers site, and who would I be interviewing with? | unresolved |
| RR2 | Salary withheld | unknown | — | (not stated) | Band unknown; may be below your expectations | `[inferred]` from the absent figure | What is the budgeted salary range for this role? | unresolved |
| RR3 | Location and contract terms unstated | unknown | — | (not stated) | Remote or hybrid policy and contract type unknown | `[inferred]` from the JD's silence | Is this role remote, and is it permanent? | unresolved |

The register is in the same structure as the rest of the document. RR1 caps the decision at `conditional_go`.

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm the live posting on the company's careers page before writing anything | RR1 | `[grounded]` the register | pending your approval |
| A2 | Ask RR2 and RR3 verbatim with the recruiter before a loop | Pay and location are cheap to ask early | `[grounded]` RR2, RR3 | pending your approval |
| A3 | Prepare the 11% lift story: the hypothesis, your ownership, what you didn't decide | The lift is a probe line, not yet an artifact | `[grounded]` R3 at `medium` | pending your approval |
| A4 | Use the healthcare gap plainly in outreach: consumer PII and consent work, not HIPAA | Avoids claiming a regulated-data experience you don't have | `[grounded]` R9 | pending your approval |

**Evidence status**

Verified: none yet. Your background is self-report, so every claim above is at `medium` or lower until you confirm specifics. Rejected inferences: none.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Search calls were refused (permission not granted). This would have checked the employer exists, its stage and size, and that the posting is live (RR1) |
| 2. Role-family sweep | unavailable | Search call was refused. This would have set the salary and scope norm for a senior product analyst in digital health (the market calibration and RR2) |
| 3. Hiring manager's public footprint | n/a | No name was given |

**Upgrade menu**
- A link to the live posting or the company's careers page → resolves RR1; the decision can move to `go`.
- A research pass with search permission on → fills the market band and the employer check. Up to 5 searches and 2 fetches; say the word and it runs.
- A metrics doc or dashboard-governance spec → R6 to `direct`, `medium` at minimum.
- A stakeholder brief from a clinical or ops-facing project → R7 to `direct`.
- If you're open to a deeper pass on the company (funding, leadership churn, reviews), that's the L2 option, with up to 5 more searches and 2 more fetches.

I can also put this full analysis in a `tuesday-dossier.md` file you can keep and reuse for interview prep. Want it?

**Questions**

G1 — Who owned metric definitions at your company, and did you maintain a catalogue or a semantic layer? If so, what did it cover?
G2 — Have you worked directly with clinicians, care teams or ops staff who shaped product decisions? If yes, what was the decision and what was your part?
G3 — Did you ever mentor or review the work of junior analysts? If yes, how many, and for how long?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.