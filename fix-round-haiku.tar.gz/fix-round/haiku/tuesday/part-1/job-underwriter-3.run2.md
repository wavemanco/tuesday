**Not worth pursuing. Status: `no_go`.** Both hard constraints fail on the posting's own terms, so no application effort is justified.

**Fit ledger.**

- `hard_gate` — `hard_gate_fail`: R1 (Compensation: $70–85k base), R2 (On-site in our Austin office 5 days a week)
- `must_have` — `direct`: R3 (8+ years growth leadership), R4 (Paid acquisition), R5 (Lifecycle/CRM) · `adjacent`: R6 (Must thrive on ambiguity) · `unclear`: R7 (SEO/content)
- `important` — `unclear`: R8 (Brand), R9 (PR), R10 (Partnerships), R11 (Sales ops)

R3, R4 and R5 are your evidenced strengths. R6 is a bridge from your scale history, with the ambiguity itself undescribed. R7 through R11 are channels your material does not mention.

**Opportunity ledger.** The role has a real mandate but is badly specified: seven functions, one person to start, metrics that "will evolve," and evenings and weekends as the norm. Its pay sits well below what its own requirements describe (RR2, a red flag). The employer could not be verified (RR1). The reporting line is clear (RR6).

- **Hard gates:** failed: R1 (Compensation: $70–85k base), R2 (On-site in our Austin office 5 days a week)
- **Severe red flags:** RR2 (`severity: high`)
- **What would change this:** the posted terms would need to move to a base at or above $150k and a remote arrangement. The posting says "no exceptions" on location, so that second part is unlikely. Changing your own floor or location would also change the result, but that is your call.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Novaline, e-commerce enablement startup, Series A, "profitable since day one" | `[grounded]` JD; not externally verified (RR1) |
| Mandate | All revenue growth end to end: paid, SEO/content, lifecycle/CRM, brand, PR, partnerships, sales ops | `[grounded]` JD |
| Team and reporting | Team of one to start; reports to the CEO, dotted line to the board | `[grounded]` JD |
| Pay | $70–85k base plus "meaningful equity upside" (equity terms not given) | `[grounded]` JD |
| Hours and location | Evenings and weekends "when it matters"; Austin on-site 5 days a week, "no exceptions" | `[grounded]` JD |
| Market calibration | Not established: the salary and scope search was refused, so no market band is stated | — |
| Unknowns | Whether the role is live; equity terms; which functions get budget; what success is measured by | — |
| Contradictions | None inside the posting's own text; the tension between scope and pay is in RR2 | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Compensation: $70–85k base plus equity | hard_gate | hard_gate_fail | high | hard_gate | Posted base tops out $65k below your $150k floor; equity does not change base. Confidence grades your floor, which is your own specific statement | `[grounded]` JD pay line; your stated floor | none; surfaced in snapshot |
| R2 | On-site in Austin 5 days a week, "no exceptions" | hard_gate | hard_gate_fail | high | hard_gate | Conflicts with remote-only from Portland. The posting rules out exceptions, so it offers no path on its own terms | `[grounded]` JD; your stated constraint | none; surfaced in snapshot |
| R3 | 8+ years growth leadership | must_have | direct | medium | none | Nine years, growth lead then Head of Growth. Self-reported in intake prose and unprobed, so medium at most | `[grounded]` your intake statement | none for fit; a CV would move this toward high |
| R4 | Paid acquisition | must_have | direct | medium | none | Owned paid acquisition at two subscription companies; no channel-level detail given | `[grounded]` your intake statement | none |
| R5 | Lifecycle/CRM | must_have | direct | medium | none | Owned lifecycle; Braze named as a tool | `[grounded]` your intake statement | none |
| R6 | Must thrive on ambiguity; metrics will evolve | must_have | adjacent | low | transferability | Scaling $8M to $40M ARR with a budget you controlled is adjacent evidence. Ambiguity itself is not described, so low | `[inferred]` from your scale history | G2 |
| R7 | SEO/content | must_have | unclear | none | discovery | Not in your material; may exist, not established | `[grounded]` JD lists it; your material is silent | G1 |
| R8 | Brand | important | unclear | none | discovery | Not in your material | `[grounded]` JD; your material is silent | G1 |
| R9 | PR | important | unclear | none | discovery | Not in your material | `[grounded]` JD; your material is silent | G1 |
| R10 | Partnerships | important | unclear | none | discovery | Not in your material | `[grounded]` JD; your material is silent | G1 |
| R11 | Sales ops | important | unclear | none | discovery | Not in your material | `[grounded]` JD; your material is silent | G1 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Useful evidence | Provenance |
|---|---|---|---|---|---|---|
| G1 | SEO/content, brand, PR, partnerships, sales ops (R7, R8, R9, R10, R11) | discovery | Your material covers paid, lifecycle and experimentation, not these functions | Together they are most of the mandate's scope. Results you owned would move them off unclear | Channel results, a content or PR plan, a partner program you ran | `[grounded]` JD scope against your material |
| G2 | Ambiguity and undefined metrics (R6) | transferability | Scale history with a budget you controlled; no description of building under undefined success metrics | This is the candidate's likeliest objection and the one most relevant to this role | A case where you set the metrics yourself | `[inferred]` from the scale history |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Novaline (e-commerce enablement startup, Series A, profitable since day one)" | The posting may be stale, aggregated, or not from a real hiring employer. Most small companies are simply small, so this is not treated as fraud | `[generic]` pattern for companies of this size, not a claim about this one | Can you confirm this role is live on Novaline's careers page, and who the hiring manager is? | unresolved |
| RR2 | Seniority-compensation mismatch: 8+ years and seven functions against $70–85k | red_flag | high | "8+ years growth leadership required" beside "$70–85k base" | Pay sits well below what the scope and experience requirement describe, and it conflicts with your floor (see R1) | `[inferred]` from the posting's own requirements against its own pay; market band not checked | How was the $70–85k base set for a role requiring 8+ years and owning seven functions, and is that figure fixed? | unresolved |
| RR3 | Team of one with a seven-function mandate | risk_signal | medium | "You will be a team of one to start" beside "Own all revenue growth end to end" | Accountability spans bundled specializations with no stated resourcing | `[inferred]` from scope language against team size | Which of these functions will have an owner or budget in year one, and which are expected to be handled by you alone? | unresolved |
| RR4 | Always-on expectations | risk_signal | medium | "evenings and weekends when it matters is just who we are" | The expectation may be routine rather than occasional | `[inferred]` from the posting's wording | In a typical month, how often are evenings and weekends expected? | unresolved |
| RR5 | Success metrics undefined on a demanding mandate | risk_signal | medium | "success metrics will evolve as we learn" | Accountability may be assessed on criteria not yet set | `[inferred]` from the posting's wording | What would success look like at six and twelve months, in numbers? | unresolved |
| RR6 | Clear reporting line | positive_signal | — | "Report to the CEO with a dotted line to the board" | Authority over the role is at least structured | `[grounded]` JD | — | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Do not spend application effort on this posting | R1 and R2 are hard-gate failures | `[grounded]` R1, R2 | recommendation |
| A2 | If you want the employer checked for future comparison, look for the live role on Novaline's own careers page | RR1 is unresolved | `[generic]` pattern | optional |

## Evidence status

Verified: R1 and R2 (your own constraints, stated specifically). Unverified: R3 through R11. Your background is intake prose, with no CV or artifact provided.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches for Novaline (company and posting) were refused, so the employer and the posting's liveness are not established. Would have moved RR1 |
| 2. Role-family sweep | unavailable | The salary and scope search was refused, so no market band is stated. Would have set RR2's comparison |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

The searches were refused in this session and I have not retried them.

If you want, I can write a `tuesday-dossier.md` capturing this assessment so a later role can be checked against it.

## Upgrade menu

- The live posting link or Novaline's careers page → RR1 closes or escalates.
- Permission to run the employer and salary searches → RR1 is checked, and RR2's market comparison runs.
- A CV or any inspectable artifact → R3, R4 and R5 move from medium toward high.
- Examples of SEO, brand, PR, partnerships or sales-ops work → R7 through R11 leave `unclear`.

**Question, for RR1:** Where did you see this posting: Novaline's careers page, a job board, or a recruiter's email? If it was a recruiter, which email domain did it come from?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.