**Yes, apply: `conditional_go`.** On the evidence you've given me, you fit the core of this role. The conditions are that the posting checks out and that three responsibilities the JD describes (R6, R8b, R9) turn out to be what the posting says.

**Research tier: L1 — searches 2 of 5, fetches 0 of 2.** Both web searches were refused by the host's permission prompt, so no company or market facts were checked. Everything about Harborlight below is from your JD paste and is unverified.

**Decision snapshot**
- **Status:** `conditional_go`. Apply once the posting is confirmed on Harborlight's own careers page.
- **Fit ledger:**
  - *must_have:* R1, R2, R3, R4 and R5 are all `direct`.
  - *important:* R7 is `direct`; R8a is `adjacent` (PM partnership, not stated); R6 (metrics layer ownership), R8b (clinician partnership) and R9 (mentoring) are `unclear`.
  - *preferred:* R10 (healthcare data / HIPAA) is `adjacent`, through your consent and privacy work.
  - Your clinician and mentoring experience is the open item in the fit, and the metrics-layer question is second.
- **Opportunity ledger:** RR1 (pay and location not stated) and RR4 (employer unverified) are unknowns. RR2 and RR3 are low and medium risk signals about authority and clinician access. RR5 is a positive signal: the mandate is concrete and includes experimentation and mentoring.
- **Hard gates:** none stated; candidate constraints not given — checks against them unknown. The JD states no gate; HIPAA is listed as "a plus."
- **Severe red flags:** none found.
- **What would change this:** the posting not verifying (RR4) moves this to `hold_pending_answers`. Pay or location that conflicts with your constraints (RR1) would need a fresh look. If R8b or R9 turn out to be marginal responsibilities, the fit weakens but the decision probably holds.

**Role reality**
- **Role:** Senior Product Analyst, Harborlight Health, care-navigation app. The JD describes a digital-health scale-up of about 400 people at Series C `[grounded]` (claimed in the JD, not verified).
- **Scope in the JD:** owns the metrics layer, runs A/B tests, builds self-serve Looker dashboards, partners with PMs and clinicians, mentors two junior analysts `[grounded]`.
- **Not stated:** compensation, location or remote policy, reporting line, whether a data-platform team exists, how clinicians are involved.
- **Contradictions:** none found in the JD text.
- **Market calibration:** not run; the search was refused.

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance |
|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | Six years stated; self-report, no artifact yet | `[grounded]` intake |
| R2 | Expert SQL | must_have | direct | medium | none | Daily SQL on Snowflake, stated | `[grounded]` intake |
| R3 | Experiment design at scale | must_have | direct | medium | presentation | 30+ tests a year, including the pricing test with the 11% retention lift; a readout would make it inspectable | `[grounded]` intake |
| R4 | Looker or similar BI | must_have | direct | medium | none | Built the Looker instance; 40+ governed dashboards | `[grounded]` intake |
| R5 | Written communication to non-technical stakeholders | must_have | direct | medium | presentation | Monthly exec metrics memo and monthly VP Product presentation | `[grounded]` intake |
| R6 | Define and maintain the metrics layer | important | unclear | low | discovery | Dashboards and governance are stated; a metrics layer as an owned thing is not | `[grounded]` silence in intake |
| R7 | Self-serve dashboards | important | direct | medium | none | 40+ governed dashboards; self-serve use itself unconfirmed | `[grounded]` intake |
| R8a | Partner with PMs on roadmap decisions | important | adjacent | medium | transferability | Monthly exec and VP Product work; PM-level partnership not stated | `[grounded]` intake |
| R8b | Partner with clinicians on roadmap decisions | important | unclear | none | discovery | No clinical or care-team stakeholder in the record | `[grounded]` silence |
| R9 | Mentor two junior analysts | important | unclear | none | discovery | No mentoring stated | `[grounded]` silence |
| R10 | Healthcare data (HIPAA) | preferred | adjacent | medium | transferability | Consumer PII under GDPR/CCPA and a consent-state model transfer to consent and privacy controls; no PHI, no HIPAA controls, no clinical data | `[grounded]` the work; `[generic]` that HIPAA and GDPR/CCPA differ in scope |

**Gap recovery queue**

| # | Gap | Type | What I see | Why it matters | What would close it |
|---|---|---|---|---|---|
| G1 | Mentoring (R9) | discovery | Nothing stated | A JD responsibility; affects the decision | Your answer to question 1 |
| G2 | Clinician partnership (R8b) | discovery | No clinical stakeholder | The JD's most domain-specific responsibility | Your answer to question 2 |
| G3 | Metrics-layer ownership (R6) | discovery | Governed dashboards, no owned metrics layer | An "own and maintain" responsibility | Your answer to question 3 |
| G4 | Healthcare data (R10) | transferability | Consent and privacy work, no regulated health data | Preferred, not a gate | A description of the consent-state model |
| G5 | Proof for R3 and R5 | presentation | Strong claims, no artifact | Would raise confidence from medium | One redacted readout and one memo |

**Opportunity risk register**

| ID | Class | Severity | Signal | Verification question for the employer | Provenance |
|---|---|---|---|---|---|
| RR1 | unknown | — | Pay and location not stated | What is the base range, and is the role remote, hybrid or on-site? | `[generic]` pattern: senior analyst postings often withhold pay |
| RR2 | risk_signal | low | "Own" analytics and the metrics layer alongside mentoring two juniors may leave decision rights unclear | Which roadmap decisions does this role make itself, and which go through PMs? | `[inferred]` from JD scope language |
| RR3 | risk_signal | medium | Clinician partnership in a regulated setting may depend on access and time you don't control | How much time do clinicians have for analyst work, and who sets priorities? | `[generic]` pattern for clinical partnerships |
| RR4 | unknown | — | Employer not verified (search refused) | Can you point me to this posting on your careers site, and who would I interview with? | Not checked; the entry stays open until verified |
| RR5 | positive_signal | — | Concrete mandate covering experimentation, metrics and mentoring | — | `[grounded]` JD text |

**Application plan**
- Lead with R3 (the 11% pricing test), R4 (the Looker build) and R5 (the monthly memo). These answer the JD's core directly.
- Present the consent-state work as privacy engineering on consumer data under GDPR/CCPA. Do not describe it as healthcare experience or imply HIPAA work. `[grounded]` for the work; `[generic]` that panels probe this distinction.
- Prepare candid answers on clinicians and mentoring: what you have done, not what the title implies. `[generic]`
- No CV edits are proposed yet. Any language will come to you for approval first.

**Evidence status**

| Target | Status | Reason |
|---|---|---|
| 1. Company site and careers page | unavailable | Web search refused by the host's permission prompt |
| 2. Role-family sweep (scope, title, pay band) | unavailable | Same |
| 3. Hiring manager's public footprint | skipped | No hiring-manager name given |

Research tier: L1 — searches 2 of 5, fetches 0 of 2. Two searches were attempted and refused; neither page was read.

Dossier offer: I can save this assessment as `tuesday-dossier.md`, which mock-interview can pick up later for prep.

**Upgrade menu**
- **Posting link or Harborlight's careers page:** verifies the employer and clears RR4.
- **Pay range and location policy:** checks RR1 against your constraints. You haven't given me those, so I can't yet check the posting against them.
- **One redacted A/B readout (ideally the 11% test) and the monthly memo:** moves R3 and R5 toward high confidence.
- **A Looker screenshot of a governed dashboard:** moves R4 and R7.
- **A short description of the consent-state model:** sharpens R10 for the healthcare question.
- **Web search permission:** would let me check the employer and run a pay-band sweep, which would replace the `[generic]` labels in RR1 with checked figures.

Three questions, one per gap, with answers in text, a voice transcript, a document or a link, or "skip":

**G1 (R9):** Have you mentored or managed junior analysts? What did you own, and how did you know it worked?

**G2 (R8b):** Have you worked directly with clinical, care-team or other non-product stakeholders on an analysis? What decision did it change?

**G3 (R6):** Did you own the canonical metric definitions in Looker or Snowflake, and how were changes governed?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.