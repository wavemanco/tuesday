**Yes, it's worth applying, on three conditions. Status: `conditional_go`.** You meet the five items under the posting's Requirements heading (R2, R3, R4, R5, R9). The gaps are pet insurance (R10), whether you designed the price tests (R6a), and product-facing recommendations (R8b). The posting doesn't list people management, so that is a question to ask (RR3), not a gap you already have.

**Fit ledger.**

- `hard_gate`: unclear: R1 (fully remote from the UK)
- `must_have`: direct: R2, R3, R4, R5, R6b, R7, R8a · unclear: R6a (designing price tests)
- `important`: adjacent: R10 (pet insurance product) · unclear: R8b (recommendations to product)
- `preferred`: direct: R9 (insurance experience)

**Opportunity ledger.** RR1 (employer and live posting unverified), RR2 (pay not stated) and RR3 (direct reports and decision rights unstated) are unknowns, not red flags. RR4 is positive: the scope names concrete work you have already done.

- **Hard gates:** none failed; unconfirmed: R1 (fully remote from the UK); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) RR1: the live posting and the employer are confirmed. (2) R1: you can work fully remote from the UK. (3) R10 is framed as a transferability case with its limit named, never as pet expertise.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech with a pet-insurance product | `[grounded]` your JD excerpt; not checked (see Evidence status) |
| Mandate | Own pricing analytics: build and monitor rating models, design and read price tests, turn results into recommendations | `[grounded]` JD |
| Working pattern | Fully remote, UK | `[grounded]` JD |
| Scope read | Concrete and measurable through test results; "own" and "senior" with no stated reports | `[inferred]` from the JD's verbs against its silence on reports |
| Market calibration | Not run. The role-family search was refused, so no pay band is given here, and none is taken from memory | — |
| Unknowns | Pay, direct reports, decision rights over recommendations, employer and posting status, the hiring manager's background | — |
| Contradictions | None visible; the JD excerpt is the only source in hand | `[grounded]` |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote, UK-based role | hard_gate | unclear | none | hard_gate | No statement from you on location or right to work in the material, so the gate cannot be checked | `[grounded]` JD; no candidate statement | Q1 |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | Five years in pricing analytics, last two as senior analyst; self-report, so it is probed | `[grounded]` your background | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | Daily use; no artifact to inspect yet | `[grounded]` your background | Offer a sanitized query (would raise to high) |
| R4 | GLM experience | must_have | direct | medium | none | Built and maintained a GLM rating model for the young-driver book. The technique is direct; pet-specific GLM work is not evidenced | `[grounded]` your background; `[inferred]` that the technique carries over | Offer a sanitized model summary (would raise to high) |
| R5 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | Presents the quarterly pricing review to the head of underwriting | `[grounded]` your background | none |
| R6a | Design price tests | must_have | unclear | none | discovery | "Ran 14 price tests" does not establish who designed them | `[inferred]` from the verb "ran" against "design" | G3 / Q3 |
| R6b | Run and read price tests with underwriting | must_have | direct | medium | none | Ran 14 tests last year with the underwriting team | `[grounded]` your background | none |
| R7 | Build and monitor rating models | must_have | direct | medium | none | Built and maintained the GLM; the monitoring cadence is a probe | `[grounded]` your background | none |
| R8a | Turn results into recommendations for underwriting | must_have | direct | medium | none | The quarterly review goes to underwriting | `[grounded]` your background | none |
| R8b | Turn results into recommendations for product | important | unclear | none | discovery | No product-facing evidence in the material | `[grounded]` absence | G2 |
| R9 | Insurance experience (a plus) | preferred | direct | medium | none | Five years of UK motor insurance | `[grounded]` your background | none |
| R10 | Pet insurance product knowledge | important | adjacent | medium | transferability | Motor pricing is the same discipline on a different risk. Limit: no pet claims, pet-specific rating factors, or lifetime-cover pricing exercised | `[inferred]` requirement from "our pet-insurance product"; `[inferred]` adjacency; `[generic]` that pet cover differs in lifetime premiums and vet-cost trend | G1 / Q2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pet insurance product (R10) | transferability | Motor work only; no pet-specific pricing or claims | The product is pet; the bridge needs its limit stated to hold up | Any pet-related pricing, claims or product work, even a side project; any work on renewal-style or lifetime cover; claims-trend work on high-frequency, low-severity cover | A sanitized note on what carried over and what did not | `[inferred]` bridge from motor work; `[generic]` that pet cover differs |
| G2 | Product recommendations (R8b) | discovery | Recommendations to underwriting are evidenced; to product, nothing | The posting names product as a recipient | Any product change you proposed from test results, or a pricing decision that product signed off | A product brief, a test readout sent to product, or a launch note | `[grounded]` absence |
| G3 | Designing price tests (R6a) | discovery | "Ran 14 tests" with underwriting | "Design and read" is a must-have; the design share decides it | Tests you set up: the hypothesis, the cells, the success measure | A test plan or design doc from one of the 14 | `[grounded]` the verb "ran"; `[inferred]` that design authorship is what the requirement means |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer and live posting not verified | unknown | — | "Brindlemoor (insurtech)"; the excerpt is the only source | The posting may be stale, aggregated, or not a live Brindlemoor role; nothing here confirms it | `[inferred]` from the single source in hand; no entity check ran | Which page on your careers site carries this role, and who would I interview with? | unresolved |
| RR2 | Pay not stated | unknown | — | No pay line in the excerpt | Pay may sit below the band for this seniority, or be set later | `[inferred]` from the absence of a pay line; no band checked | What is the base salary range for this role? | unresolved |
| RR3 | Direct reports and decision rights unstated | unknown | — | "Own pricing analytics" | The role may include people leadership, or may only recommend rate changes that others approve | `[inferred]` from "own" and "senior" against silence on reports | Does this role line-manage anyone now or in the next year, and who signs off a rate change it recommends? | unresolved |
| RR4 | Concrete scope | positive_signal | — | "build and monitor rating models; design and read price tests" | Scope is specific and measurable, and it matches your evidence | `[grounded]` JD scope language | Which rating model would I own in the first six months, and which price test is next? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Get the live posting link and the careers-page listing before spending application effort | RR1 | `[inferred]` from the unverified source | pending your approval |
| P2 | Prepare the pet answer in two parts: what motor carries over (GLM, price tests), then the limit (no pet claims, no lifetime-cover pricing) | R10 | `[grounded]` R10 row; `[generic]` that pet cover differs | pending your approval |
| P3 | If asked about managing people, say plainly that you have not managed anyone, then describe what you have done: presenting the quarterly review and running 14 tests. Claim no leadership title or team | RR3 | `[grounded]` your background | pending your approval |

## Evidence status

Verified: none yet. Unverified leads: none. Rejected inferences: none.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Three searches were refused by permission, so nothing came back. Would have moved whether Brindlemoor exists as described and the posting is live (RR1) |
| 2. Role-family sweep | unavailable | Refused with the others. Would have set the pay band and scope norm (RR2, role reality) |
| 3. Hiring manager's public footprint | unavailable | You named Odile Varga, so the query could be formed; the search was refused. Would have moved the scope read and the positioning |

Because the employer search never ran, the standing "employer not established" entry is not filed. RR1 holds the gap until the check runs.

Dossier offer: I can write this analysis to a `tuesday-dossier.md` file you keep for later rounds.

## Upgrade menu

- A live posting link or the careers-page listing → RR1 closes and the employer check can run.
- Permission to use web search → I can re-run the two checks that matter most, the employer and the pay band. Three refused calls count against the L1 budget, so two searches remain, which is not enough for all three targets.
- The base salary range → RR2 closes and is set against the band.
- A sanitized SQL query or GLM validation summary → R3 or R4 moves to `high`.
- Any pet-related pricing or claims exposure, even a side project → R10's bridge narrows.

Q1 (R1): Do you have the right to work in the UK, and can you work fully remote from a UK base?

Q2 (G1, R10): Has any of your motor work touched a pet-like feature, such as renewal-style or lifetime cover, vet-cost inflation, or high-frequency, low-severity claims? Describe what you did and any artifact you have.

Q3 (G3, R6a): Of the 14 price tests, which did you design yourself (the hypothesis, the cells, the read), and which did you run from a design someone else set?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.