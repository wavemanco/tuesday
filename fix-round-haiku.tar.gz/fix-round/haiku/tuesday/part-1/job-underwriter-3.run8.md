**No. As posted, this isn't worth pursuing, and your sense that something is off is right. The posting fails both of your hard constraints, and neither is a near miss.**

**Decision snapshot**

**Not worth applying to on these terms. Status: `no_go`.** R1 and R2, both hard gates, fail.

**Fit ledger.**

- `hard_gate`: failed: R1 (base compensation), R2 (on-site office attendance)
- `must_have`: direct: R3 (8+ years growth leadership), R4 (paid, lifecycle, experimentation) · adjacent: R5 (sole owner across all revenue functions)
- `important`: unclear: R6 (SEO/content, brand, PR, partnerships, sales ops), R7 (ambiguity, metrics that will evolve)

Your fit is strong on the functions you've run. The posting fails on terms, so the fit ledger doesn't change the answer.

**Opportunity ledger.** The scope is bundled and the time expectation is stated: RR1 (seven functions, one person) and RR2 (evenings and weekends as the norm) are risk signals. RR3 is a pay-to-scope risk signal that I could not check against market data. RR4 is an unverified employer. RR5 is the company's own profitability claim, a positive signal I could not verify.

- **Hard gates:** failed: R1 (base compensation), R2 (on-site office attendance)
- **Severe red flags:** none found. The hard gates carry the decision.
- **What would change this:** R1 would need a base at or above your $150k floor, about $65k above the top of the posted $70–85k range. R2 would need remote eligibility from Portland, which the posting rules out with "no exceptions." Only the employer changing those terms reopens this. A revised posting would need a fresh underwrite.

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Novaline, e-commerce enablement, Series A, "profitable since day one" | `[grounded]` the posting's own claim; not verified |
| Mandate | Head of Growth, owning all revenue growth across seven named functions | `[grounded]` posting |
| Team | "Team of one to start" | `[grounded]` posting |
| Reporting | CEO, dotted line to the board | `[grounded]` posting |
| Working pattern | Austin on-site 5 days/week, "no exceptions"; evenings and weekends "just who we are" | `[grounded]` posting |
| Compensation | $70–85k base, plus equity that is unquantified | `[grounded]` posting; equity size unknown |
| Scope read | Seven functions for one person at Head level is a bundled scope | `[inferred]` from the function count against the team of one |
| Market calibration | Not established. The role-family search was refused, so I have no market band | — |
| Unknowns | Equity size, budget, success metrics, team plan | — |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Base pay at your $150k floor (posted $70–85k) | hard_gate | hard_gate_fail | high | hard_gate | Your stated floor is specific and yours; the posted range tops out about $65k short | `[grounded]` posting and your stated constraint | none; only the employer changing the range resolves it |
| R2 | Remote-only from Portland (posted: on-site Austin 5 days/week, "no exceptions") | hard_gate | hard_gate_fail | high | hard_gate | Your stated constraint is specific and yours; the posting rules out remote explicitly | `[grounded]` posting and your stated constraint | none; only the employer changing the terms resolves it |
| R3 | 8+ years growth leadership | must_have | direct | medium | none | Nine years, growth lead then Head of Growth at two companies. Intake prose, so it stays unverified | `[grounded]` your intake prose | none |
| R4 | Paid acquisition, lifecycle/CRM, experimentation | must_have | direct | medium | none | You owned all three at one company | `[grounded]` your intake prose | none |
| R5 | Sole owner of all revenue growth, no bench | must_have | adjacent | medium | transferability | You scaled $8M to $40M ARR with a budget and a team of 3–7. You have not described working solo. Limit: solo execution across functions is not in your evidence | `[inferred]` from your team-building history | a question, if the role were pursued |
| R6 | SEO/content, brand, PR, partnerships, sales ops | important | unclear | low | discovery | Your evidence doesn't cover these five functions | `[grounded]` absence in your intake prose | a question, if the role were pursued |
| R7 | Thriving in ambiguity; metrics that will evolve | important | unclear | low | discovery | Experimentation is adjacent, but you have not described operating without defined metrics | `[grounded]` absence in your intake prose | a question, if the role were pursued |

**Gap recovery queue**

No gap needs a question this turn. R5, R6, and R7 would matter only if you pursued this role, and R1 and R2 are closed by the posting itself.

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Bundled scope: seven functions for one person | risk_signal | medium | "Own all revenue growth end to end … and sales ops. You will be a team of one to start" | Several roles are folded into one, and the team may not follow | `[inferred]` from the posting's scope against its team size; the bundling pattern is `[generic]` | Which of these seven functions have budget and people committed today, and which would I build from nothing? | unresolved |
| RR2 | Always-on expectation | risk_signal | medium | "evenings and weekends when it matters is just who we are" | Off-hours work may be routine rather than occasional | `[grounded]` posting; the reading is `[inferred]` | What did evenings and weekends look like for this role over the last quarter, and how often did they happen? | unresolved |
| RR3 | Seniority-pay mismatch: 8+ years, Head title, $70–85k base | risk_signal | medium | "8+ years growth leadership required … $70–85k base" | The band may sit below market for this scope. I could not check, because the role-family search was refused | `[grounded]` posting figures; market norm not checked | How was the $70–85k band set for a role with this scope, and what is budgeted for it? | unresolved |
| RR4 | Employer not established | unknown | — | "Novaline (e-commerce enablement startup, Series A …)" | Unverified, because research was refused. This is not a finding that the company is absent | `[generic]` for early-stage companies; this entity is not checked | Which products and which investors sit behind this role, and who would I interview with? | unresolved |
| RR5 | Stated profitability since day one | positive_signal | — | "profitable since day one" | If true, the company has runway discipline | `[grounded]` posting; not verified | How is profitability measured, and what is the runway? | noted |

**Application plan**

Do not apply on these terms. No language is proposed, so there is nothing for you to approve.

**Evidence status**

Verified: R1 and R2, which are your own stated constraints. Everything else is intake prose and unverified.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches ("Novaline e-commerce enablement startup Austin" and "Novaline Head of Growth job Austin Series A") were refused because WebSearch permission was not granted. Would have checked that the company exists as described and that the posting is live (RR4) |
| 2. Role-family sweep | unavailable | One search ("Head of Growth salary Series A e-commerce startup base salary range 2026") was refused. Would have set the market band for RR3 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

**Upgrade menu**

- Granting web search permission would let me check the employer and set a market band for RR3. Neither can change `no_go`, because both gates fail on the posting's own words.
- A written confirmation from the recruiter of the base range and the location policy is the only input that could change the read. A revised posting would be re-underwritten from scratch.

One sentence on the dossier: I can save this as `tuesday-dossier.md` so the verification questions travel with it.

**Questions:** none this turn. A question would not change the decision.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.