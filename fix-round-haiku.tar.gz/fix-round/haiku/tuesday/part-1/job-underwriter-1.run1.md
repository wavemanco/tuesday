**Yes, apply, once the employer and posting check out.** Your background covers the core of this role. Status: `conditional_go`.

**Fit ledger.**
- `must_have`: direct R1, R2, R3, R4, R6 · adjacent R5 (metrics layer)
- `important`: adjacent R7a (PM partnership) · absent R7b (clinician partnership), R8 (mentoring junior analysts)
- `preferred`: adjacent R9 (HIPAA or healthcare data)

R5 is the must-have where your evidence doesn't yet show you owned metric definitions. R7b and R8 have no evidence either way yet. R9 is where your consent work carries over but HIPAA itself does not.

**Opportunity ledger.** Mostly unknowns: the employer and posting are unverified in this run (RR1), the posting is silent on pay, location and contract basis (RR4), and who owns metric definitions is unstated (RR2). The named responsibilities and tools read as realistic scope (RR5, positive).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) RR1: the employer and live posting verify on Harborlight's own careers page; (2) RR4: pay band, location and permanence fit your constraints; (3) RR2: metrics-layer ownership is concrete (R5).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, digital-health scale-up, ~400 people, Series C, care-navigation app | `[grounded]` JD header; not verified this run |
| Mandate | Own product analytics: metrics layer, A/B tests, self-serve Looker, PM and clinician partnership, mentoring two junior analysts | `[grounded]` JD |
| Scope read | A senior individual-contributor role with lead duties over one product area, not a team head | `[inferred]` from the responsibility list |
| Market calibration | Not established. The pay search was refused this run, so I have no band and won't supply one from memory | — |
| Unknowns | Location, pay, contract basis, the team beneath the role, who sets metric definitions | — |
| Contradictions | None found within the JD text | `[grounded]` JD |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | Six years at one consumer-subscription company. Specific and self-reported, not yet probed | `[grounded]` your intake | none |
| R2 | Expert SQL | must_have | direct | medium | none | Daily SQL on Snowflake is the claim. "Expert" is a level no artifact shows; expect a live SQL probe | `[grounded]` your intake | G-sample: a redacted query would raise to high |
| R3 | Experiment design at scale | must_have | direct | medium | none | 30+ A/B tests a year and the pricing test behind an 11% retention lift. Expect probes on design and how the lift was measured | `[grounded]` your intake | a redacted test readout would raise to high |
| R4 | Looker or similar BI; self-serve dashboards | must_have | direct | medium | none | Built the Looker instance from scratch, 40+ governed dashboards. Self-serve use by others isn't stated | `[grounded]` your intake | confirm self-serve use in one line |
| R5 | Define and maintain the metrics layer | must_have | adjacent | low | discovery | Governed dashboards and the consent-state model are adjacent. Nothing says you defined or owned shared metric definitions | `[inferred]` adjacency from governed dashboards | G1 |
| R6 | Strong written communication for non-technical stakeholders | must_have | direct | medium | none | You write the monthly exec metrics memo and present to the VP Product monthly | `[grounded]` your intake | a redacted memo would raise to high |
| R7a | Partner with PMs on roadmap decisions | important | adjacent | medium | transferability | Exec and VP Product partnership is stated. PM-level work is inferred from it, not described | `[grounded]` intake; `[inferred]` the PM extension | G2 |
| R7b | Partner with clinicians | important | absent | none | discovery | Nothing in your intake on clinical stakeholders | `[grounded]` intake silence | G2 |
| R8 | Mentor two junior analysts | important | absent | none | discovery | Nothing in your intake on mentoring | `[grounded]` intake silence | G2 |
| R9 | Healthcare data experience (HIPAA) | preferred | adjacent | medium | transferability | GDPR and CCPA PII handling and consent-state modelling are real. HIPAA is not claimed; no healthcare employer | `[grounded]` intake; `[generic]` that the rule sets differ | G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Metric definitions (R5, must_have) | discovery | Governed dashboards; no statement you set shared definitions | Moves R5 toward direct; the first responsibility in the JD | A metrics dictionary, certified metrics, a semantic-layer or dbt metrics file, deciding which definition the exec memo used | A metrics dictionary or model excerpt | `[grounded]` JD's first responsibility; `[generic]` that this is the likeliest probe |
| G2 | Clinician work and mentoring (R7a, R7b, R8) | discovery | Exec and VP-level partnership only; nothing on clinicians or junior analysts | Two important rows at no evidence, one at adjacent | Analysis with clinical, ops or support leads; onboarding or reviewing analysts | Onboarding plan, review notes, a clinician-facing deck | `[grounded]` intake silence |
| G3 | HIPAA-specific work (R9) | transferability | Consent-state and PII work under GDPR and CCPA; no HIPAA-covered data | Preferred, but interviewers may probe the difference | Access rules for the consent model; how access was audited | A design note for the consent model | `[generic]` that the HIPAA–GDPR distinction gets probed |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer and posting not verified this run | risk_signal | medium | "digital-health scale-up, ~400 people, Series C" | The posting may be stale, aggregated, or not a live hiring entity | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Team and authority behind the metrics layer | unknown | — | "Own product analytics … define and maintain the metrics layer" | The role may set definitions alone, or sit on a data team | `[inferred]` from the responsibility against the silence on team | Who maintains the warehouse models under the metrics layer, and does this role set definitions alone or with a committee? | unresolved |
| RR3 | Clinician sign-off on metrics | unknown | — | "partner with product managers and clinicians" | Metrics touching care decisions may need clinical review before use | `[generic]` clinical-facing analytics commonly sits under clinical review; not a finding about this employer | How are clinician-facing metrics reviewed, and who signs off on one that touches care? | unresolved |
| RR4 | Pay, location, contract basis unstated | unknown | — | JD silent on all three | Terms may only surface on the first call | `[inferred]` from posting silence | What is the base range, where is the role based, and is it permanent? | unresolved |
| RR5 | Concrete responsibilities and tools | positive_signal | — | "design and analyze A/B tests, build self-serve dashboards in Looker" | Scope is specific and maps onto your stated work | `[grounded]` JD | What would success look like at six months for the metrics layer? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Lead with experimentation (30+ tests a year, the pricing test) and Looker governance (40+ dashboards), in your own verbs: designed and ran, built | Strongest match to R3 and R4 | `[grounded]` your intake | pending your approval |
| P2 | Don't claim metrics-layer ownership or HIPAA experience unless G1 or G3 confirm it; describe the consent-state model by what it did | R5 and R9 are not yet evidenced | `[grounded]` R5, R9 | pending your approval |
| P3 | Check the posting on Harborlight's careers site before applying | RR1 | `[generic]` pattern | pending your approval |
| P4 | Ask the recruiter for pay band, location and contract basis before the loop | RR4 | `[grounded]` RR4 | pending your approval |

## Evidence status

Verified: none yet. Every claim rests on your intake, not on answers you've confirmed. Unverified leads: none. Rejected inferences: none.

Research tier: L1 — searches 3 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches for the company and posting were refused, so nothing came back. Would have checked the employer exists as described and the posting is live (RR1) |
| 2. Role-family sweep | unavailable | The pay and scope search was refused. Would have set the market calibration in role reality; no band is given here |
| 3. Hiring manager's public footprint | n/a | No name was given |

## Upgrade menu

- Grant search permission and I'll rerun targets 1 and 2 with what's left of the L1 budget (2 searches, 2 fetches; the three refused calls count against the cap). Or paste the live posting link. Either one moves RR1.
- A redacted query or test readout → R2 and R3 to `high`.
- A redacted exec memo → R6 to `high`.
- Your non-negotiables on location, pay floor and contract type → the hard-gates line can be checked.

I can save this as `tuesday-dossier.md` if you want it kept, and mock-interview can read it later.

## Questions

G1 (R5): Did you define or maintain shared metric definitions (a metrics dictionary, a semantic layer, or certified metrics), or did you use definitions others set? If you did, which one, and what did you own?

G2 (R7b, R8): Have you mentored or onboarded junior analysts, or worked directly with clinical, operations or support leads on analysis? One example of each would do.

Constraints (no row yet): What are your non-negotiables on location, pay floor, and permanent versus fixed-term?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.