**Not worth pursuing as posted. Status: `no_go`.** R1 and R2, both hard gates, fail: the posted base is $65k–$80k under your $150k floor, and on-site five days a week in Austin conflicts with your remote-only requirement. Both are stated as firm in the posting.

**Fit ledger.**

- `hard_gate`: failed: R1 (Base compensation $70–85k), R2 (On-site, Austin, five days a week)
- `must_have`: direct: R3 (Paid acquisition), R4 (Lifecycle and CRM), R9 (8+ years growth leadership), R10 (Own revenue growth end to end) · unclear: R5 (SEO and content), R6 (Brand and PR), R7 (Partnerships and sales ops), R8 (Thrives on ambiguity)
- `important`: adjacent: R11 (E-commerce enablement sector)

On paper you match the experience requirements. R1 and R2 are the reasons to stop, and R5 through R8 would only matter if the gates were open.

**Opportunity ledger.** The posting is a single generalist mandate across seven functions, with one person, no stated budget, undefined success metrics, and an always-on expectation (RR1, RR2, RR3). Equity is undefined (RR4), and the employer is not verified (RR5).

- **Hard gates:** failed: R1 (Base compensation $70–85k), R2 (On-site, Austin, five days a week); met: none; candidate constraints given (your floor and remote-only), so the checks ran.
- **Severe red flags:** none found. The strongest entries are `medium`.
- **What would change this:** both terms would have to change, and the posting says on-site is "no exceptions." Only the employer moving or you revising a stated constraint would reopen it, and the second is your call.

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Novaline, e-commerce enablement, Series A, profitable since day one | `[grounded]` JD claim, unverified |
| Mandate | All revenue growth across seven functions | `[grounded]` JD |
| Team and reporting | One person to start; reports to the CEO, dotted line to the board | `[grounded]` JD |
| Working pattern | On-site Austin, five days; evenings and weekends "when it matters" | `[grounded]` JD |
| Compensation | $70–85k base plus "meaningful equity" with no terms | `[grounded]` JD |
| Unknowns | Budget, success metrics, equity terms, whether pay is flexible | — |
| Contradictions | None visible from the posting alone | — |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Base $70–85k vs. your $150k floor | hard_gate | hard_gate_fail | high | hard_gate | Top of the range is $65k under your floor; your statement is specific and confirmed | `[grounded]` JD and your statement | None; only the employer changing the range resolves it |
| R2 | On-site Austin, 5 days vs. remote-only | hard_gate | hard_gate_fail | high | hard_gate | "No exceptions" in the posting; you are not relocating | `[grounded]` JD and your statement | None; only the employer changing terms resolves it |
| R3 | Paid acquisition | must_have | direct | medium | none | Owned paid; no artifact yet, so expect a probe | `[grounded]` your statement | None |
| R4 | Lifecycle and CRM | must_have | direct | medium | none | Owned lifecycle; Braze named | `[grounded]` your statement | None |
| R5 | SEO and content | must_have | unclear | none | discovery | Not in your background | — | None; does not change the decision |
| R6 | Brand and PR | must_have | unclear | none | discovery | Not in your background | — | None; does not change the decision |
| R7 | Partnerships and sales ops | must_have | unclear | none | discovery | Sales ops is B2B; your background is subscription lifecycle | — | None; does not change the decision |
| R8 | Thrives on ambiguity, metrics to evolve | must_have | unclear | low | discovery | Scale-up experience is evidence of growth, not of this ambiguity | `[inferred]` | None; does not change the decision |
| R9 | 8+ years growth leadership | must_have | direct | medium | none | Nine years; Head of Growth at two companies. Years of experience are not a gate | `[grounded]` your statement | None |
| R10 | Own revenue growth end to end | must_have | direct | medium | none | $8M to $40M ARR with a budget you controlled; expect a probe on attribution | `[grounded]` your statement | None |
| R11 | E-commerce enablement (B2B) | important | adjacent | medium | transferability | B2C subscription growth carries over; B2B enablement is not exercised | `[inferred]` from your two B2C roles | None |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Always-on expectation | risk_signal | medium | "evenings and weekends when it matters is just who we are" | Off-hours work may be routine rather than occasional | `[inferred]` from the wording | How many evenings or weekends did the last person in this role work in a typical month? | unresolved |
| RR2 | Bundled scope, one-person team | risk_signal | medium | "team of one to start" beside seven functions | Accountable for all seven with no team or budget committed | `[generic]` pattern for folded roles | Which of these functions have budget and headcount committed on day one? | unresolved |
| RR3 | Undefined success metrics | risk_signal | medium | "success metrics will evolve as we learn" | Accountability may be set against targets not yet written | `[inferred]` from JD silence | What revenue target will this role be measured against at six and twelve months? | unresolved |
| RR4 | Equity terms absent | unknown | — | "meaningful equity upside" | Equity may be thin or unspecified | `[inferred]` from JD silence | What share count and vesting schedule apply to this role? | unresolved |
| RR5 | Employer not established | risk_signal | medium | "Novaline (e-commerce enablement startup, Series A…)" | Employer not verified; both searches were refused | `[generic]` pattern for companies this size, not a claim about this one | Can you point me at this role on Novaline's own careers site, and who would I be interviewing with? | unresolved |
| RR6 | Pay likely below role norms | risk_signal | medium | "$70–85k base" | Posted pay may sit below what this title and scope usually command; no market band was checked | `[generic]`, no band searched | Is $70–85k the budgeted base for this role, or is there room? | unresolved; see R1 |

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Do not apply on the posted terms | R1, R2 | `[grounded]` | Recommendation, for your decision |
| A2 | If you want to test it, one written question to the recruiter: are base and location negotiable? | Only route to reopening the gates | `[inferred]` | Pending your approval |

**Evidence status.** Verified: R1 and R2, your own stated constraints, specific and confirmed. Everything else rests on your intake statements, which stay at medium and are unverified. Verified: none of the employer's claims.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Both search calls were refused by the host (permission not granted). Would have checked whether Novaline exists as described and whether the posting is live (RR5) |
| 2. Role-family sweep | unavailable | Same refusal. Would have set a market band for the pay row (RR6); the decision does not depend on it |
| 3. Hiring manager's public footprint | n/a | No name given |

**Dossier offer.** I can write this up as a `tuesday-dossier.md` file if you want to keep it or share it.

**Upgrade menu**

- Permission for web search, which would run the two L1 checks: confirm Novaline exists and is hiring for this role, and calibrate the pay row against a market band.
- The live posting link or Novaline's careers page, which checks that the posting is current.
- A written answer from the recruiter on pay and on-site. This is the only input that could move R1 or R2.

I have no questions for you: the decision holds whichever way they are answered.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.