**Worth applying to, probably, but hold until one term is confirmed.** The role is a close fit for your motor pricing background. The posting contradicts itself on location, and that is the one thing that could decide it. Status: `hold_pending_answers`.

## Decision snapshot

**Status: `hold_pending_answers`.** Yes if the role is genuinely fully remote. The hold waits on the location answer in RR1 and on your own location constraint (R1), which you haven't given me.

**Fit ledger.**

- `hard_gate` — unclear: R1 (fully remote, UK)
- `must_have` — direct: R2, R3, R4, R5, R6
- `important` — direct: R8a · adjacent: R7 (pet-insurance product) · unclear: R8b (product recommendations)
- `preferred` — direct: R9

R1 is the only row that can change the status. R7 and R8b are the two gaps an interviewer will probe.

**Opportunity ledger.** The posting is live and the careers page matches it, with the same reporting line to the Director of Pricing (RR4, positive). The JD says fully remote UK, but the careers page says Leeds four days a week (RR1, medium). The salary is withheld (RR2) and decision rights are unstated (RR5).

- **Hard gates:** none failed; unconfirmed: R1 (fully remote, UK); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **What would change this:** confirmation that the role is fully remote, and a check that you can meet any office requirement. If both hold, the status moves to `go`, or `conditional_go` if the pet-insurance gap stays open.

## Research tier

Research tier: L1 — searches 4 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Brindlemoor insurtech pet insurance" (no results) and "Brindlemoor Senior Pricing Analyst jobs" (returned the careers page). Fetched brindlemoor.co.uk/careers/senior-pricing-analyst. Moved the contradiction row and RR1. The company search came back empty, so RR3 stands. |
| 2. Role-family sweep | yes | Searched "Senior Pricing Analyst insurance UK salary GLM". Returned the Pricewell 2026 UK pricing pay survey. I read the search snippet only; the page was not fetched. Moved the market calibration and RR2. |
| 3. Hiring manager's public footprint | yes | Searched "Odile Varga Director of Pricing". Returned a public professional profile. Moved the scope read in role reality. |

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech; pet-insurance product | `[grounded]` JD; careers page |
| Mandate | Own pricing analytics for the pet-insurance product; build and monitor rating models; design and read price tests; recommend to underwriting and product | `[grounded]` JD |
| Reporting line | Reports to the Director of Pricing | `[grounded]` JD and careers page agree |
| Working pattern | Contradicted: "fully remote (UK)" in the JD; "Leeds office four days a week" on the careers page | `[grounded]` both sources |
| Scope read | A normal senior analyst scope, with the manager's public work on the same topic | `[inferred]` from the JD's verbs against the title |
| Manager's public footprint | Director of Pricing at Brindlemoor. Spoke at the 2025 Insurance Pricing Forum on monitoring rating models in small books. Previously head of pricing analytics at Calloway Re for six years. | `[grounded]` public profile search result |
| Market calibration | Pricewell 2026 snippet: senior pricing analyst median base £58,400, interquartile range £52,100–£64,900 (n=612) | `[generic]` role-family sweep; not this employer's offer |
| Unknowns | Salary; whether the role has direct reports (the JD doesn't say, and you have never managed anyone); decision rights over rating changes; whether the pet product is the first non-motor book you would work on | — |
| Contradictions | Location (above) | `[grounded]` |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote (UK) | hard_gate | unclear | none | hard_gate | No candidate constraint given, and the posting contradicts itself. Not established either way. | `[grounded]` JD vs careers page | Confirm the location term with the recruiter; state your own constraint |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | Five years in pricing analytics at a UK motor insurer, self-reported. Intake ceiling is medium until inspected. | `[grounded]` your background | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | Daily use, self-reported | `[grounded]` your background | none |
| R4 | GLM experience | must_have | direct | medium | none | Built and maintained the young-driver GLM. Motor, not pet. | `[grounded]` your background | none |
| R5 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | Presents the quarterly pricing review to the head of underwriting | `[grounded]` your background | none |
| R6 | Design and read price tests | must_have | direct | medium | none | Ran 14 price tests last year with underwriting | `[grounded]` your background | none |
| R7 | Pet-insurance product knowledge (implied by "for our pet-insurance product") | important | adjacent | medium | transferability | Motor rating and pricing carry over. Pet claims behaviour, pricing and lifetime-value dynamics are not exercised. | `[inferred]` from the JD's product name against your motor work | Bridge case below |
| R8a | Recommendations to underwriting | important | direct | medium | none | Quarterly review to the head of underwriting | `[grounded]` your background | none |
| R8b | Recommendations to product | important | unclear | low | discovery | No product-facing example stated | `[grounded]` absence in your background | Recall question below |
| R9 | Insurance experience | preferred | direct | medium | none | Five years in UK motor insurance | `[grounded]` your background | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pet-insurance domain (R7, important) | transferability | Motor pricing and GLM work; nothing on pet | The main objection an interviewer will raise. The bridge: motor rating mechanics transfer; the limit is that pet claims and lifetime pricing were not exercised. | Any non-motor pricing or claims work; a small-book review; a rating project on a low-frequency product | A sanitised pricing note, a model card, or a book comparison | `[inferred]` bridge from R4; `[generic]` that pet is the likeliest objection |
| G2 | Product recommendations (R8b, important) | discovery | Underwriting-facing recommendations only | "Recommendations for underwriting and product" is in the JD | A price change or rating decision that went to product or to a commercial team | A sanitised recommendation memo | `[grounded]` JD and background |
| G3 | Location (R1, hard_gate) | hard_gate | JD and careers page disagree | Decides whether the role is open to you | Not applicable: this is a term, not experience | The recruiter's written answer | `[grounded]` both sources |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Location contradiction | risk_signal | medium | JD: "Fully remote (UK)". Careers page: "Leeds office four days a week" | The posting carries a stale or contested term; a Leeds requirement would fail a remote need | `[inferred]` from the two sources disagreeing | "Is this role fully remote from the UK? If not, which days in the Leeds office are required, and from when?" | unresolved |
| RR2 | Salary withheld | unknown | — | No figure in the JD or on the careers page | The budget may sit below the band in role reality; the company may simply not publish salaries | `[inferred]` from the withheld figure against the `[generic]` band | "What base salary is budgeted for this post?" | unresolved |
| RR3 | Employer footprint thin beyond the posting | risk_signal | low | Company search returned nothing; careers page is the only attributable source | Small or new companies often have thin footprints; this is not evidence of a problem | `[generic]` pattern for companies of this size, not a claim about this one | "Which legal entity employs this role, and what is the product's regulatory name?" | reduced: the posting is attributable |
| RR4 | Reporting line consistent across sources | positive_signal | — | Careers page: "reports to the Director of Pricing" | Role clarity: the manager named in the posting is the one whose public work matches it | `[grounded]` careers page and public profile | "What decisions does the Director of Pricing reserve for themselves, and what is yours?" | noted |
| RR5 | Decision rights unstated | unknown | — | "turn the results into recommendations" | The role may recommend rather than decide rating changes | `[inferred]` from the verb "recommendations" against silence on approval | "Which rating or price changes does this role approve itself, and which go through underwriting or product sign-off? Does the role have direct reports?" | unresolved |

**Severe red flags:** none found.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Ask the recruiter in writing whether the role is fully remote, and what the Leeds requirement is if not | RR1, R1 | `[grounded]` RR1 | pending your approval |
| A2 | Lead with the GLM, the price tests and the underwriting review. Present the pet-insurance work as adjacent, with its limit named, and do not describe it as pet experience | R4, R6, R7 | `[inferred]` from the fit rows | pending your approval |
| A3 | Prepare a sanitised example for G1 and G2 before applying | G1, G2 | `[generic]` role-family pattern | pending your approval |

Every row above is a proposal. Nothing here has been sent or finalised, and the wording in A2 needs your approval before you use it.

## Evidence status

Verified: none yet. Everything you have told me is self-report, so the ceiling is medium.

Unverified leads: none.

Rejected inferences: none.

## Upgrade menu

- Your location constraint, plus a written answer on the remote term → R1 resolves and the status moves to `go` or `conditional_go`.
- A non-motor pricing example, even a side project → R7 moves from adjacent toward direct.
- A product-facing recommendation example → R8b moves from unclear.
- A sanitised price-test readout or GLM documentation → R2 to R6 move from medium to high.
- The budgeted salary → RR2 closes against the `[generic]` band of £52,100–£64,900.
- A deeper research pass on Brindlemoor (funding, leadership, past hires; up to 5 more searches and 2 more fetches). Say the word and it runs.

If you want this saved as a file, I can write a `tuesday-dossier.md` for it.

**Questions**

R1 — Can you work fully remote from the UK? If the role needs the Leeds office four days a week, is that workable for you?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

R8b — Have you ever shaped a price or rating recommendation that went to product, not only to underwriting? What did you own, and what happened?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

G1 — Have you done any pricing or data work on a non-motor product, pet or otherwise, even a side project or a small-book review?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.