**Snapshot: worth applying, as `conditional_go`.** Your experience matches all five must-haves on what you told me. The open items are BigQuery, three scope items the posting names that your background doesn't yet cover, and the employer, which I could not check independently because web access was refused.

- **Fit ledger**
  - `hard_gate`: unclear: R1 (Remote (US) or Denver office)
  - `must_have`: direct: R2, R3, R4, R5, R6
  - `important`: adjacent: R7 (BigQuery warehouse); unclear: R8 (Ingestion from app and CRM), R9 (Data contracts analysts depend on)
  - R2–R6 are stated experience you have already given me. R7 transfers from Snowflake, but BigQuery itself is new to you. R8 and R9 are unconfirmed.
- **Opportunity ledger:** The posting shows no red flags in its own text. Base pay is inside the market band (RR4). Three things are open: the employer is unverified (RR1), no hiring manager is named (RR2), and equity is unquantified (RR3). RR5 covers unstated team and on-call scope.
- **Hard gates:** none failed; unconfirmed: R1 (Remote (US) or Denver office); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **Conditions for go:** (1) RR1 clears: the posting is live on their careers page and the Series C is confirmed in an outside source, which you can check yourself; (2) R8 and R9 hold up in your answers to Q2; (3) R1 fits your location and pay floor (Q1, Q3); (4) BigQuery is described as the platform you would learn, not as experience.
- **What would change this:** a confirmed severe flag, such as the post turning out to be fixed-term or a location requirement you cannot meet, would move it to `hold_pending_answers` or `no_go`. Clean answers on R8 and R9 would move it toward `go`.

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Live online K-12 tutoring in 31 US states; founded 2016, Denver; 264 employees | `[grounded]` employer's About page as you pasted it; not independently verified |
| Stage | Series C, $52M, February 2026 | `[grounded]` employer's own statement; not verified |
| Scope | Ingestion from app and CRM, a dbt warehouse on BigQuery, data contracts for analysts | `[grounded]` JD |
| Seniority read | "Senior" fits 5–8 years and ownership of one domain's pipelines with no reports | `[generic]` pay report pattern; the JD states no reports |
| Market calibration | Senior data engineer at Series B–D: median $151k, IQR $139k–$163.5k | `[generic]` applied from the Datawright report your recruiter sent, a provided document |
| Stated comp | $148k–$166k base, midpoint $157k; equity unstated | `[grounded]` JD |
| Unknowns | Hiring manager, team size, equity terms, ingestion ownership, on-call, Denver office days | — |
| Contradictions | None between the JD and the About page as pasted | — |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | No location or constraint given | — | Q1 |
| R2 | 5+ years data engineering | must_have | direct | medium | none | Six years at a B2B payroll company; unprobed prose | `[grounded]` your message | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | Daily use; no artifact yet | `[grounded]` your message | none |
| R4 | dbt and a cloud warehouse | must_have | direct | medium | none | dbt project of about 180 models on Snowflake | `[grounded]` your message | none |
| R5 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow in use; you set up orchestration | `[grounded]` your message | none |
| R6 | Data quality testing | must_have | direct | medium | none | Set up the Great Expectations suite | `[grounded]` your message | none |
| R7 | dbt-modelled warehouse in BigQuery | important | adjacent | medium | transferability | Snowflake and dbt carry over. Not exercised: BigQuery's cost model, partitioning, IAM. BigQuery itself: none | `[inferred]` adjacency from R4 | G1 |
| R8 | Ingestion from app and CRM | important | unclear | low | discovery | Not in your message | — | Q2 |
| R9 | Data contracts analysts depend on | important | unclear | low | discovery | Not in your message; nearest is R6 | `[inferred]` from R6 | Q2 |

**Gap recovery queue**

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R7) | transferability | Snowflake and dbt at scale; no BigQuery | The posting names it in the warehouse sentence | Any warehouse migration, cost tuning or partitioning work | A BigQuery sandbox or dbt profile you have run | `[inferred]` bridge from R4; `[generic]` that BigQuery's cost model is the usual objection |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Pellucid Learning runs live online tutoring" | The employer may be real and small, or the posting may be stale; I could not confirm either | `[generic]` pattern for companies of this size, not a claim about this one | "Can you point me at this role on your own careers site, and who would I be interviewing with?" | unresolved |
| RR2 | No hiring manager named | unknown | — | "Senior Data Engineer" header only | Could be a recruiter-led requisition | `[inferred]` from the posting's silence | "Who is the hiring manager, and who owns these pipelines today?" | unresolved |
| RR3 | Equity unquantified | unknown | — | "plus equity" | Equity could be small or heavily back-loaded | `[inferred]` from the posting's silence on terms | "What is the equity grant, vesting schedule and valuation basis?" | unresolved |
| RR4 | Base pay inside the market band | positive_signal | — | "$148,000–$166,000" | Midpoint is about $6k above the median | `[grounded]` JD against `[generic]` band | "Is this the approved range for the level, and how is the level defined?" | noted |
| RR5 | Ownership scope unstated | unknown | — | "Build and run the pipelines" | May be a one-person function or a shared team | `[inferred]` from the posting's silence on team and on-call | "Who else works on these pipelines, and what does on-call look like?" | unresolved |

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm the posting is live and the Series C in an outside source before you apply | RR1 | `[generic]` pattern; the check is yours to run | suggested |
| A2 | Lead with dbt on Snowflake at about 180 models, Airflow, and Great Expectations; name Snowflake explicitly | R2–R6 | `[grounded]` your message | pending your approval |
| A3 | Describe BigQuery as the platform you are learning, not as experience | R7 | Reframing audit: Kind and Verb axes | pending your approval |

**Evidence status**

Verified: none yet. Your claims are intake prose, which caps them at `medium`.

Research tier: L1 — searches 2 of 5, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Fetches of the careers page and the About page were refused (web permission not granted). Would have checked: the posting is live, stage and size match, and the employer exists |
| 2. Role-family sweep | unavailable | Search for the Datawright report and senior data engineer pay was refused. Would have checked the `[generic]` band behind the market calibration |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

**Upgrade menu**

- Web access granted → rerun targets 1 and 2 to check the employer and the pay band's source; RR1 closes or stays open.
- An ingestion or data-contract example you owned → R8 and R9 move off `unclear`.
- A BigQuery sandbox or repo → R7 moves toward `high` for transfer evidence.
- The hiring manager's name → unlocks target 3 and the scope read.

I can also write this up as a `tuesday-dossier.md` you can carry into interview prep.

1. **Q1 (R1):** Are you based in the US, and can you work remote or from Denver? Without this, the location gate is unchecked.
2. **Q2 (R8, R9):** Have you built ingestion from an app or CRM, or owned data contracts with consumers? Give one example: what you owned, what broke, and how you knew.
3. **Q3 (constraints):** What base floor and equity expectation do you have? I can compare them against the posted range.

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.