**Yes, apply, on three conditions. Status: `conditional_go`.** Your GLM work, price testing and underwriting presentations match the must-haves on the evidence you gave me. The open items are the UK location and right-to-work check, whether the role manages people, and whether Brindlemoor is verifiable, since I could not run the search.

**Fit ledger.**

- `hard_gate`: unclear: R1 (UK location and right to work)
- `must_have`: direct: R2, R3, R4, R5
- `important`: direct: R6 · adjacent: R7 (pet-insurance product)
- `preferred`: direct: R8 (insurance experience)

R2, R3, R4 and R5 are all `direct` at `medium`, because the claims are your own statements and nothing has been inspected yet. R7 is the only row below `direct` apart from R1.

**Opportunity ledger.** The scope is concrete (RR4), but three items are open: the reporting line (RR1), the withheld salary (RR3), and the employer footprint, which I could not check (RR2).

- **Hard gates:** none failed; unconfirmed: R1 (UK location and right to work); candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) R1 confirmed; (2) RR2 cleared, meaning the live posting and the employer are confirmed before you invest in the application; (3) RR1 answered, so you know whether this role manages anyone.

## Role reality

I have the JD only as you summarised it, not the posting text, so every row below is read from your summary.

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech with a pet-insurance product | `[grounded]` your summary of the JD |
| Mandate | Own pricing analytics: build and monitor rating models, design and read price tests, turn results into recommendations for underwriting and product | `[grounded]` your summary |
| Working pattern | Fully remote, UK | `[grounded]` your summary |
| Scope read | Senior IC-shaped scope: the listed responsibilities are all analytical and advisory, with no team mentioned | `[inferred]` from the responsibility list and its silence on reports |
| Market calibration | Not run. The role-family search was refused, so there is no band | none, no search ran |
| Compensation | Not stated in your summary | — |
| Unknowns | Reporting line and direct reports; salary; whether the pet product has enough data for rating work; employer footprint | — |
| Contradictions | None found within what you gave me | `[grounded]` your summary |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | UK location and right to work (fully remote, UK) | hard_gate | unclear | low | hard_gate | No candidate statement yet. UK motor employment shows UK work history but not current eligibility | `[inferred]` from UK employer history | Confirm your current location and right to work |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | Five years in pricing analytics, last two senior. Self-reported, not inspected | `[grounded]` your background | Expect a probe on how the years are counted |
| R3 | Strong SQL and Python | must_have | direct | medium | none | Daily use of both. Self-reported, no artifact | `[grounded]` your background | none |
| R4 | GLM experience | must_have | direct | medium | none | Built and maintained the GLM rating model for the young-driver book. Motor, not pet | `[grounded]` your background | none |
| R5 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | Presents the quarterly pricing review to the head of underwriting | `[grounded]` your background | none |
| R6 | Designing and reading price tests | important | direct | medium | none | Ran 14 price tests last year with the underwriting team | `[grounded]` your background | none |
| R7 | Pet-insurance product context | important | adjacent | medium | transferability | Motor pricing carries over. You have no pet work, and pet-specific drivers are not exercised | `[inferred]` from motor work; `[generic]` that pet books differ from motor in ways that matter for rating | G1 |
| R8 | Insurance experience (a plus) | preferred | direct | medium | none | Five years at a UK motor insurer | `[grounded]` your background | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pet-insurance product context (R7, important) | transferability | Motor pricing and price testing, with no pet work | This is the objection most likely to come up in an interview for a pet product | Any pricing work outside motor, including a small project in home or travel; any work where you chose which risk drivers to use; any review of a product's claims behaviour | Anonymised model documentation, or a price-test readout from a non-motor line | `[inferred]` bridge from motor work; `[generic]` that pet is the likeliest objection |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Whether the role manages people is not stated | unknown | — | "Own pricing analytics for our pet-insurance product" | The role may be a senior IC, or may carry reports that the summary does not mention | `[inferred]` from "own" against the silence on reports | Does this role have direct reports, and who would I report to? | unresolved |
| RR2 | Employer not established | risk_signal | medium | "Brindlemoor (insurtech)" | The employer may be too new or small to have a public footprint, or the posting may be stale | `[generic]` pattern for companies of this size, not a claim about this one | Where is this role on Brindlemoor's careers site, and who would I be interviewing with? | unresolved |
| RR3 | Salary not stated | unknown | — | Not in your summary | The budget may sit below your expectation, or salaries may not be published | `[inferred]` from the withheld figure | What is the budgeted salary for this post? | unresolved |
| RR4 | Scope is concrete | positive_signal | — | Rating models, price tests, recommendations to underwriting and product | The responsibilities match your track record and are clearly defined | `[grounded]` the JD's responsibility list | Which pricing decisions does this role own alone, and which go through underwriting or product sign-off? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Confirm your location and right to work with the recruiter before you invest in the application | see R1 | `[grounded]` R1 row | pending your approval |
| P2 | Check that the live posting is on Brindlemoor's own careers site | see RR2 | `[grounded]` RR2 row | pending your approval |
| P3 | Ask the recruiter RR1 and RR3 | The answers change the role's level and pay | `[grounded]` RR1 and RR3 rows | pending your approval |
| P4 | Lead with the GLM, price-testing and underwriting-presentation work, as motor work. Name pet as new territory and claim no pet experience | Keeps every claim within what you can show | `[grounded]` R4, R5, R6, R7 rows | pending your approval. No wording is proposed yet |
| P5 | Prepare an honest answer on the move from motor to pet | The pet-context probe is the one most likely to come up | `[generic]` that interviewers for a new product area tend to ask about domain transfer | pending your approval |

## Evidence status

Verified: none yet. Your background is self-report at the intake ceiling of `medium`. Unverified leads: none. Rejected inferences: none.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches for Brindlemoor and its pricing-analyst posting were refused permission in this session. Would have moved RR2 and the posting check |
| 2. Role-family sweep | unavailable | One search for senior pricing-analyst pay and scope was refused. Would have set the market band behind RR3 |
| 3. Hiring manager's public footprint | unavailable | One search for Odile Varga was refused. Would have moved the positioning in P4 |

## Upgrade menu

- Permission to run web search → RR2 closes or escalates, the market band for RR3 is set, and the hiring manager's public background informs P4. Up to 5 more searches and 2 fetches; say the word and I'll retry.
- Confirmation of your location and right to work → R1 moves to `direct`, which clears the one unconfirmed gate.
- The posting text, pasted or linked → RR1 and RR3 are checkable against the posting's own wording.
- An anonymised model document or price-test readout → R2–R6 move from `medium` toward `high`.
- Any non-motor pricing work, even a small one → R7 moves toward `direct`.

I can also write this up as a `tuesday-dossier.md`, so the map and register carry into a later mock interview.

1. R1: Are you based in the UK, with the right to work here, and is that settled?
2. R7: Have you priced any non-motor product, even a small project in home, travel or another line?
3. RR1: Do you know yet whether this role has direct reports?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.