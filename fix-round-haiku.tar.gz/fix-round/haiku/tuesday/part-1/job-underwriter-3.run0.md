**No. The role fails both of your hard constraints on the employer's own stated terms. Status: `no_go`.**

**Fit ledger**

- `hard_gate`: hard_gate_fail: R1 (on-site in Austin, five days a week), R2 (base salary)
- `must_have`: direct: R3, R4, R5 · unclear: R6 (owning revenue end to end, including sales ops)
- `important`: direct: R10 · unclear: R7 (SEO and content), R8 (brand and PR), R9 (partnerships)

R1 and R2 are both hard gates and both fail. R3, R4 and R5 (8+ years, paid acquisition, lifecycle/CRM) match what you described `[grounded]`, at `medium` because nothing has been inspected yet. R6 to R9 are unknown from your material, not absent. R10 is `[inferred]` from the posting's emphasis on measured growth.

- **Hard gates:** failed: R1 (on-site in Austin, five days a week), R2 (base salary).
- **Severe red flags:** none in the register. The two failed gates carry the weight.
- **Opportunity ledger:** the terms conflict with both of your constraints (R1, R2). An always-on expectation (RR1) and a team-of-one mandate with no stated budget (RR2) sit on top of that. Success metrics are unstated (RR3), the pay range has no market check yet (RR4), and the profitability and Series A claims are unverified (RR5).
- **What would change this:** the employer would have to move both the on-site requirement and the pay, and the posting rules out the first in writing ("no exceptions"). The pay range is $65–80k below your $150k floor, which is 43–53% under it. No question I could ask changes either gate, so I'm asking none.

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Novaline, e-commerce enablement, Series A, profitable since day one | `[grounded]` posting; not verified (see Evidence status) |
| Mandate | All revenue growth end to end, team of one to start, reports to CEO with a dotted line to the board | `[grounded]` posting |
| Pay | $70–85k base plus equity, against your $150k floor | `[grounded]` posting and your constraint; the gap is arithmetic |
| Market calibration | Not run. The role-family sweep was refused, so I have no market band and claim none | — |
| Contradictions | None checked. No jobs page was fetched | — |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance |
|---|---|---|---|---|---|---|---|
| R1 | On-site Austin, five days a week | hard_gate | hard_gate_fail | high | hard_gate | Your constraint is remote-only, not relocating. The posting says "no exceptions" | `[grounded]` your intake and posting |
| R2 | Base salary at or above $150k | hard_gate | hard_gate_fail | high | hard_gate | Posting is $70–85k base. Your floor is $150k | `[grounded]` posting and your intake |
| R3 | 8+ years growth leadership | must_have | direct | medium | none | Nine years, growth lead then Head of Growth. No artifact yet | `[grounded]` your intake |
| R4 | Paid acquisition | must_have | direct | medium | none | You owned paid acquisition at two B2C subscription companies | `[grounded]` your intake |
| R5 | Lifecycle and CRM | must_have | direct | medium | none | Owned lifecycle; deep in Braze | `[grounded]` your intake |
| R6 | Owns revenue end to end, including sales ops | must_have | unclear | low | discovery | Your material is silent on sales ops | `[grounded]` silence in your material |
| R7 | SEO and content | important | unclear | low | discovery | Not mentioned in your material | `[grounded]` silence |
| R8 | Brand and PR | important | unclear | low | discovery | Not mentioned in your material | `[grounded]` silence |
| R9 | Partnerships | important | unclear | low | discovery | Not mentioned in your material | `[grounded]` silence |
| R10 | Analytics and measurement | important | direct | medium | none | SQL and GA4, described by you | `[inferred]` requirement from the posting's measured-growth emphasis |

**Gap recovery queue**

| # | Gap (req) | Type | What I currently see | What would close it |
|---|---|---|---|---|
| G1 | Sales ops and end-to-end revenue ownership (R6) | discovery | Silent in your material | A past role where you ran sales handoff, pipeline reporting or a revenue target |
| G2 | SEO, brand, PR, partnerships (R7–R9) | discovery | Silent in your material | Any owned program in these areas, even if run alongside another team |

These rows carry no questions. The gate failures would not change even if these rows all closed.

**Opportunity risk register**

| # | Signal | Class | Severity | Hypothesis | Provenance | Verification question (ask the employer) | Status |
|---|---|---|---|---|---|---|---|
| RR1 | "Evenings and weekends when it matters is just who we are" | risk_signal | medium | Off-hours work is the default, not the exception | `[inferred]` from the posting's own wording | "In a typical month, how much of this role's work falls outside business hours, and how is that recognized?" | unresolved |
| RR2 | Team of one, with all revenue and sales ops, no budget stated | unknown | — | Accountable for the whole revenue line without stated budget or decision rights | `[inferred]` from the scope against the silence on budget | "What budget and decision rights does this role hold on day one, and who runs sales ops today?" | unresolved |
| RR3 | "Success metrics will evolve as we learn" on an 8+ year mandate | risk_signal | medium | Accountability with no fixed definition of success | `[generic]` pattern for early-stage growth roles, not a claim about this company | "What two or three metrics would I be measured on at 6 and 12 months, and who sets them?" | unresolved |
| RR4 | Pay range $70–85k base, equity described as "meaningful" | risk_signal | medium | Pay sits well below what this scope usually commands; no market check yet | `[generic]` pattern; market sweep not run | "Is $70–85k the budgeted number for this role, and what is the equity grant in percent, vesting and strike?" | unresolved |
| RR5 | Profitable since day one; Series A | positive_signal | — | Stated stage and profitability, unverified | `[grounded]` posting, not verified | "Can you share the most recent financials or a link to the Series A announcement?" | noted |

**Application plan**

Don't apply on these terms. I'm proposing no CV edits and no outreach. If the employer changed both terms in writing, the register's questions would be the ones to put to them.

**Evidence status**

Verified: R1 and R2 (your own constraints, `high`), and R3, R4, R5, R10 (your statements, `medium`). R6 to R9 are unverified because you haven't addressed them. Web search was refused in this session, so I did not run it and did not retry.

Research tier: L1 — searches 3 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Search was refused. Would have checked that Novaline exists as described and that the posting is live |
| 2. Role-family sweep | unavailable | Search was refused. Would have set a market pay band for this scope, which would calibrate RR4 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

**Upgrade menu**

- Grant search permission and I'll run targets 1 and 2. That verifies the employer and sets a market band for RR4. Neither changes a gate.
- Tell me your history in SEO, brand, PR, partnerships or sales ops, and R6 to R9 move off `unclear`.
- A past growth plan, a dashboard, or a P&L from a past role would raise R3 to R5 and R10 to `high`.

Do you want this saved as `tuesday-dossier.md`? It's the same analysis in a file you can keep.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.