Yes, probably worth applying, but not before two quick checks: confirm the employer exists independently, and confirm your location and pay floor. Status: `conditional_go`.

**Decision snapshot**

**Worth applying to — conditional on the checks below. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (remote US or Denver office), R2 (base pay $148,000–$166,000)
- `must_have` — direct: R3 (5+ years data engineering), R4 (strong SQL and Python), R5 (dbt), R6 (cloud warehouse), R7 (Airflow or similar), R8 (data quality testing)
- `important` — adjacent: R9 (BigQuery, named in the responsibilities); unclear: R10 (ingestion from app and CRM), R11 (data contracts for analysts)

R9 — Snowflake work transfers, BigQuery itself is unused; R10, R11 — not yet in your background, so unknown rather than missing.

**Opportunity ledger.** RR1 (the employer's independent footprint is not established) caps this at `conditional_go`. RR4 (pay is disclosed, and the range sits above the band's median) runs the other way. RR2 (on-call for "build and run") and RR3 (equity unquantified) are unknowns, not red flags.

- **Hard gates:** none failed; unconfirmed: R1 (remote US or Denver office), R2 (base pay $148,000–$166,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) RR1 clears: an independent source confirms the company and its Series C; (2) R1 and R2 confirmed against your location and floor; (3) R10 and R11 confirmed in your own words; (4) BigQuery is framed as adjacent, never as direct experience.

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning, live online tutoring for K-12 schools in 31 states, founded 2016, Denver, 264 employees, Series C ($52M, Feb 2026) | `[grounded]` company About page, fetched; headcount and funding are the company's own claims |
| Mandate | Build and run the reporting pipelines: app and CRM ingestion, a dbt-modelled BigQuery warehouse, data contracts for analysts | `[grounded]` JD |
| Scope read | One domain's reporting pipelines, owned end to end | `[inferred]` from the JD's responsibilities, which name no team, budget, or decision rights |
| Market calibration | Posting midpoint $157,000 sits above the $151,000 median and inside the $139,000–$163,500 interquartile range; the top of the posting ($166,000) is above that range. Your six years is at the low end of the report's 5–8 year senior norm | `[generic]` Datawright 2026 pay report as pasted, not independently checked; `[grounded]` the posting's figures |
| Unknowns | On-call ownership, equity value, hiring manager, team size, your location against R1 | — |
| Contradictions | None between the JD and the company's careers page | `[grounded]` careers page, via search |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | Your location was not given, so the gate is not settled | `[grounded]` JD; no candidate statement | Q1 below |
| R2 | Base pay $148,000–$166,000 | hard_gate | unclear | none | hard_gate | Your floor was not given; the range is at or above the band's median | `[grounded]` JD; `[generic]` band | Q3 below |
| R3 | 5+ years data engineering | must_have | direct | medium | none | Six years at a B2B payroll company, self-reported; no artifact yet | `[grounded]` your intake; expect a probe | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | Daily use, self-reported | `[grounded]` your intake; expect a probe | none |
| R5 | dbt | must_have | direct | medium | none | Built the dbt project, about 180 models | `[grounded]` your intake; expect a probe | none |
| R6 | A cloud warehouse | must_have | direct | medium | none | Snowflake is a cloud warehouse; the requirement does not name a vendor | `[grounded]` your intake; expect a probe | none |
| R7 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow, self-reported | `[grounded]` your intake; expect a probe | none |
| R8 | Data quality testing | must_have | direct | medium | none | Set up the Great Expectations suite | `[grounded]` your intake; expect a probe | none |
| R9 | BigQuery warehouse, dbt-modelled | important | adjacent | medium | transferability | dbt and warehouse modelling carry over; BigQuery-specific work (partitioning, cost control) is absent. Limit: no BigQuery. | `[grounded]` intake; `[inferred]` transfer from Snowflake | G1 |
| R10 | Ingestion from app and CRM | important | unclear | low | discovery | Pipeline work is described, but these sources are not named | `[grounded]` absence in intake | G2 |
| R11 | Data contracts for analysts | important | unclear | low | discovery | Not mentioned in intake | `[grounded]` absence in intake | G3 |

**Gap recovery queue**

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R9, important) | transferability | Snowflake and dbt at about 180 models; no BigQuery | Likely interview probe; the bridge narrows it | Any warehouse cost or partition work on Snowflake; any BigQuery exposure in a sandbox or course | A dbt docs page, a sandbox project, a short write-up of the Snowflake cost work | `[inferred]` bridge from your Snowflake work; `[generic]` that BigQuery is the likeliest probe |
| G2 | App and CRM ingestion (R10, important) | discovery | Pipelines are described; sources are not | Decides whether the core of the mandate is covered | Event ingestion from an application; CRM API pulls | A pipeline diagram, a source list | `[grounded]` absence in intake |
| G3 | Data contracts (R11, important) | discovery | Not mentioned | Analysts' dependence on contracts is named in the JD | Schema agreements with downstream consumers; breaking-change process | A contract doc, a schema test set | `[grounded]` absence in intake |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer footprint not established independently | risk_signal | medium | "Series C ($52M, February 2026)" | Two searches found only the company's own site and posting; no press or investor mention. The company may be small and private. | `[grounded]` search results; `[generic]` pattern for companies of this size, not a claim about this one | Which investors led the February 2026 Series C, and who would I be interviewing with? | unresolved |
| RR2 | On-call and run ownership unstated | unknown | — | "Build and run the pipelines" | "Run" may mean on-call for reporting pipelines. | `[inferred]` from the JD's "build and run" against its silence on on-call | What is the on-call and incident load for the reporting pipelines, and who shares it? | unresolved |
| RR3 | Equity unquantified | unknown | — | "plus equity" | The equity value cannot be weighed from the posting. | `[inferred]` from the JD's wording | What is the equity grant size, vesting schedule, and strike price? | unresolved |
| RR4 | Pay disclosed | positive_signal | — | "$148,000–$166,000" | The disclosed range sits around the band's median, with the top above the upper quartile. | `[grounded]` the posting; `[generic]` the band | Is this range the approved budget, and how is level decided? | noted |
| RR5 | Hiring manager unnamed | unknown | — | (none named in JD) | Reporting line and remit may sit with a central analytics lead. | `[generic]` pattern for postings without a named manager | Who would I report to, and how many people are on the data team? | unresolved |

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Summary line: "Built our dbt project on Snowflake (about 180 models), with Airflow orchestration and a Great Expectations test suite." Your own sentences; no BigQuery line. | Leads with R5, R6, R7, R8 | `[grounded]` intake. Audit: scope kept at "our"; no added ownership | resume_edits_pending_approval |
| P2 | Interview framing for BigQuery: "I haven't run BigQuery in production. The dbt and testing work carries over, and I'd expect to ramp on partitioning and cost controls." | R9 and RR1 | `[grounded]` G1; `[generic]` the ramp areas | pending your approval |
| P3 | Ask the recruiter: hiring manager, Series C investors, equity terms, on-call load | RR1, RR2, RR3, RR5 | `[grounded]` the register | pending your approval |
| P4 | Check the employer independently before investing in the application | RR1 caps the decision | `[grounded]` search results | pending your approval |

**Evidence status**

Verified: none yet. Your intake claims are self-reported (R3–R8) and carry the `medium` caveat until you give an artifact or a specific answer.

Research tier: L1 — searches 2 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Pellucid Learning live online tutoring Denver" (no results) and "\"Pellucid Learning\" careers Senior Data Engineer" (returned the careers posting, same text as pasted). Fetched pellucidlearning.com/about (matches the pasted About copy). Moved: the posting is live on the company's domain; no independent footprint found. RR1 and the failed-attribution entry. |
| 2. Role-family sweep | skipped | The Datawright 2026 report is already in hand, and its band is what the market calibration line reads. A search would only repeat it. |
| 3. Hiring manager's public footprint | n/a | No name was given. |

Dossier offer: Want me to write this up as `tuesday-dossier.md`, so a later interview-prep run can read it?

**Upgrade menu**

- A repo, dbt docs page, or sanitized Great Expectations suite → R3–R8 move from `medium` to `high`.
- Describing the app and CRM sources you ingested → R10 resolves or moves.
- Describing any data-contract ownership → R11 resolves or moves.
- Any BigQuery sandbox or course work → R9 gets a closure path.
- The hiring manager's name → positioning for the interview.
- A deeper research pass on Pellucid (funding, leadership, news; up to 5 more searches and 2 more fetches). Say the word and it runs.

**Questions**

R1 — Are you based in the US, and could you work remotely or from the Denver office?

R10 and R11 — Have you built ingestion from application or CRM sources, or owned data contracts that analysts depended on? Name the source, what you owned, and how it was checked.

R2 — Is $148,000 base above your floor, and would base alone meet it?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.