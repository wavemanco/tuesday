**Decision: `conditional_go`.** It isn't a waste of time, but it's a stretch. The must-have "3+ years product management" is the requirement a screen will check literally, and the role is worth applying to only as an upstream-product candidate, not as a PM with a track record.

**Fit ledger.**

- `must_have`: direct: R3, R4a · adjacent: R1, R2, R7 · unclear: R4b, R8
- `important`: adjacent: R5, R6a, R9 · unclear: R6b

R1 (3+ years PM, adjacent, medium) and R2 (shipped API or platform products, adjacent, medium) are the two must-haves that a literal screen would test. R8 (adoption metrics, unclear, low) has no evidence on the CV yet.

**Opportunity ledger.** The JD is clear on outcomes but thin on decision rights: RR1 asks who sets sequencing across two squads, and RR2 flags a wide remit for one title. The employer is unverified (RR3) because web search was refused, and pay is absent from what was pasted (RR4).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) you can name one product decision you owned that shipped (R7, G1); (2) the live posting verifies and matches the JD (RR3); (3) the application frames your work as the upstream half of product, not as PM years (R1).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline, B2B logistics tech, ~150 people, Series B, as you described it | `[grounded]` your request; not verified |
| Mandate | Own the roadmap for a partner-facing API platform; run partner discovery; write specs and drive delivery with two squads; define and track adoption metrics; coordinate launches with sales and support | `[grounded]` JD |
| Scope read | Five outcome-bearing responsibilities plus two engineering squads under one title is broad for a first PM role | `[inferred]` from the count of responsibilities against one title |
| Market calibration | Not run; the role-family sweep was refused, so there is no pay or scope band | — |
| Unknowns | Decision rights across the squads; pay; level; who owns adoption metrics today | — |
| Contradictions | None visible in what was pasted; no second source was readable | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 3+ years product management experience | must_have | adjacent | medium | transferability | No PM title and no owned roadmap; seven years of work upstream of product. Self-reported on the CV, specific, no artifact | `[grounded]` CV | G1 |
| R2 | Shipped API or platform products | must_have | adjacent | medium | transferability | Led 30+ REST API integrations end to end. You delivered on the platform, not its design or versioning | `[grounded]` CV | G2 |
| R3 | Technical fluency: API docs, schemas | must_have | direct | medium | none | Postman, SQL, OpenAPI reading, and integration architecture on the CV. Stated, not inspected | `[grounded]` CV | none |
| R4a | Stakeholder management: engineering and customers | must_have | direct | medium | none | Coordinated your engineers, client engineers and PMs through UAT and go-live | `[grounded]` CV | none |
| R4b | Stakeholder management: sales | must_have | unclear | low | discovery | The CV is silent on sales | `[grounded]` CV silence | G4 |
| R5 | Run discovery with integration partners | important | adjacent | medium | transferability | Quarterly roadmap-input sessions collecting client feedback for product. Limit: that was input-gathering, not discovery you led | `[grounded]` CV; `[inferred]` that it is the nearest equivalent | G1 |
| R6a | Write specs and drive delivery with engineering squads | important | adjacent | medium | transferability | Requirements documents and coordinated engineers. Limit: no spec ownership stated | `[grounded]` CV | none yet |
| R6b | Agile delivery experience | important | unclear | low | discovery | No sprint or agile role stated | `[grounded]` CV silence | G5 |
| R7 | Own the roadmap | must_have | adjacent | medium | transferability | Upstream input, not prioritisation. The strongest counter-case would be a decision you owned | `[grounded]` CV | G1 |
| R8 | Define and track adoption metrics | must_have | unclear | low | discovery | No metric ownership on the CV. The triage-tool note is unconfirmed and not counted | `[grounded]` CV silence | G3 |
| R9 | Coordinate launches with sales and support | important | adjacent | medium | transferability | Go-live coordination with clients. Limit: internal sales and support launch work not stated | `[grounded]` CV | G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Owned product decision (R1, R5, R7) | transferability | Upstream input from roadmap sessions; no owned prioritisation | R1 and R7 are must-haves at adjacent; an owned decision is the strongest counter | A feature or integration request you pushed up or down the list; a spec you wrote that changed what shipped | A roadmap item, spec or launch note with your name on the decision | `[grounded]` CV; `[inferred]` that an owned decision is the strongest counter |
| G2 | Shipped platform (R2) | transferability | Integrations delivered end to end on the implementation side | R2 is a must-have at adjacent; the limit is design and versioning | Integration-architecture choices that changed the API or its docs; API change requests you raised | An integration-architecture document; a change request | `[grounded]` CV |
| G3 | Adoption metrics (R8) | discovery | No metric ownership on the CV | A tracked-adoption example would move R8 | Any internal tool, playbook or script others adopted, with usage counted | Usage notes, a before-and-after count, a dashboard | `[grounded]` CV silence; `[generic]` that interviewers probe metric ownership for this title |
| G4 | Sales and support launch work (R4b, R9) | discovery | Customer-facing launch work only | Both are must-have or important, and the JD names sales and support | A launch or renewal you coordinated with sales or support | A launch checklist; a support handoff note | `[grounded]` CV silence |
| G5 | Agile delivery (R6b) | discovery | Coordinated engineers; no sprint role | Named in the JD's requirements | Sprint planning, backlog ownership, release planning | A sprint review deck; a backlog sample | `[grounded]` CV silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Roadmap ownership asserted, decision rights not evidenced | unknown | — | "Own the roadmap for our partner-facing API platform" | The role may own roadmap content while sequencing sits with engineering leadership or sales | `[inferred]` from the JD's scope against its silence on decision rights | Which roadmap decisions does this role make alone, and which need engineering or sales sign-off? | unresolved |
| RR2 | Wide remit under one title | risk_signal | low | "run discovery … write specs and drive delivery with two engineering squads" | One PM may be expected to do five things in parallel with no named first priority | `[inferred]` from the count of responsibilities against one title | What should this person deliver in the first two quarters, and what would you cut first? | unresolved |
| RR3 | Employer and posting not verified | unknown | — | "Product Manager, Platform APIs — Quartzline" | Not a finding: the check could not run, so the posting's live status and the company's footprint are open | `[generic]` pattern for unverified postings; no claim about this employer | Can you confirm this role is live on Quartzline's careers site, and who the hiring manager is? | unresolved |
| RR4 | Pay absent | unknown | — | none quoted; no pay line in the pasted JD | Pay may appear in the live posting, or may be withheld | `[grounded]` absence in the pasted JD | What is the base range and level for this role? | unresolved |

**Severe red flags:** none found.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Summary line, proposed: "Implementation lead for 30+ client integrations of REST APIs, from scoping workshops through UAT to go-live; ran quarterly roadmap-input sessions collecting client feedback for product." | Puts the JD's integration and stakeholder language on your own facts | `[grounded]` CV sentences, each clause traced | `resume_edits_pending_your_approval` |
| P2 | Bridge line for the cover note or the screen: "I haven't held a PM title. My product work has been the upstream half: quarterly roadmap-input sessions with client teams, taking their feedback to product. I haven't owned prioritisation, and I'd like to show how I'd approach it." | Frames the gap honestly before the screen does | `[grounded]` CV; the "haven't owned prioritisation" clause needs your confirmation before use | pending your approval |
| P3 | Verify the posting and check the pay before spending application effort | Opens RR3 and RR4 | `[grounded]` RR3, RR4 | pending your approval |
| P4 | Pick one shipped decision for G1 | The one thing that most moves R1 and R7 | `[inferred]` from G1 | pending your approval |

## Evidence status

Verified: none yet. Your CV claims are self-reported leads until you confirm them with specifics or artifacts.

Unverified lead: an earlier conversation noted you built an internal request-triage tool that support agents adopted. It is unconfirmed, so it is not counted as evidence. It is the basis for question 2 below.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Both searches were refused by permission. It would have checked that Quartzline exists as described and the posting is live (RR3) |
| 2. Role-family sweep | unavailable | Same refusal. It would have set the title, scope and pay band against role-family norms |
| 3. Hiring manager's public footprint | n/a | No name was given |

If you want this kept for later, I can write it up as `tuesday-dossier.md`.

## Upgrade menu

- Allow web search and the L1 pass runs: it confirms the employer and the live posting (RR3), and it sets the title and pay against role-family norms.
- The live posting link: RR3 closes, and I can check it against the JD for contradictions.
- One product decision you shaped that shipped, as a spec, roadmap item or launch note: R7 and R1 can move up a band.
- The budgeted pay or level: RR4 closes.

1. **G1 (R1, R7):** Is there a product decision you owned, such as what to build or which integration request to prioritise, that shipped? What did you decide, who else was involved, and what happened?
2. **G3 (R8):** Did you ever build or own something internal teams adopted, such as a tool, playbook or script? How did you know it was used?
3. **RR3:** Paste the live posting link from Quartzline's careers site, and tell me who the recruiter is.

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.