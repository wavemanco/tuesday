**Short answer: probably yes, but hold off applying until you answer three questions.** Your background matches the core stack. Two constraints I can't check (location and pay floor) are what keep this at `hold_pending_answers`.

## Decision snapshot

**Status: `hold_pending_answers`.** Your background matches the core stack, and R1 and R2 are the gates holding the decision.

**Fit ledger.**

- `hard_gate`: unclear: R1 (Remote US or Denver office), R2 (salary $148,000–$166,000 against your floor)
- `must_have`: direct: R3 (5+ years data engineering), R4 (strong SQL and Python), R5 (dbt), R6 (a cloud warehouse), R8 (orchestration with Airflow or similar), R9 (data quality testing)
- `important`: absent: R7 (BigQuery, named in the responsibilities); unclear: R10 (data contracts analysts depend on), R11 (ingestion from app and CRM)

R1 and R2 are gates you can answer. R7 is the one absent row, and it is a transferable gap. R10 and R11 are responsibilities your inputs don't cover. R3, R4, R5, R6, R8 and R9 are the direct rows.

**Opportunity ledger.** RR1 is a standing entry: the posting is live on the company's own site, but independent search found no footprint for the company. RR2 is unstated ownership of contracts and ingestion. RR3 is a positive: the salary is disclosed and sits around the market median.

- **Hard gates:** none failed; unconfirmed: R1 (Remote US or Denver office), R2 ($148,000–$166,000 salary). Candidate constraints not given; checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:** Answering Q1 and Q2 with a yes on location and a floor at or below $166,000 moves this to `conditional_go`. The conditions would be RR1 verifying cleanly and R7 being framed honestly as a bridge.

## Research tier

Research tier: L1 — searches 1 of 5, fetches 1 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Fetched pellucidlearning.com/careers/senior-data-engineer: posting live ("Accepting applications"), text matches your paste. Searched "Pellucid Learning live online tutoring K-12 Denver": no results, so the company is not independently established (RR1) |
| 2. Role-family sweep | skipped | Your inputs already fix it: the Datawright figures you supplied are the calibration; a second sweep would not change it |
| 3. Hiring manager's footprint | n/a | No name given |

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Live online K-12 tutoring, Denver, 264 employees, Series C ($52M, Feb 2026) | `[grounded]` your paste; not independently confirmed (RR1) |
| Mandate | Build and run reporting pipelines; dbt warehouse in BigQuery; data contracts | `[grounded]` careers page, matches your paste |
| Scope read | Senior ownership of one domain's pipelines, no reports stated | `[inferred]` from the responsibilities against the report's typical scope |
| Market calibration | Report median $151,000, IQR $139,000–$163,500. Posted $148,000–$166,000 sits around the median, with the top above the IQR | `[grounded]` the report figures you supplied; `[generic]` that they reflect the market |
| Seniority | Report says Senior typically means 5–8 years; you have 6 | `[grounded]` your background; `[generic]` the norm |
| Contradictions | None between your paste and the live page | `[grounded]` |
| Unknowns | Location eligibility, your pay floor, contract and ingestion ownership, team shape | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | Your location not given; can't be settled from inputs | `[grounded]` JD | Q1 |
| R2 | Salary $148,000–$166,000 | hard_gate | unclear | none | hard_gate | Your pay floor not given. Band sits near market median | `[grounded]` JD and report | Q2 |
| R3 | 5+ years data engineering | must_have | direct | medium | none | 6 years, stated at intake; no inspectable artifact yet | `[grounded]` your background | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | Daily use, stated; no artifact | `[grounded]` your background | none |
| R5 | dbt | must_have | direct | medium | none | About 180 models on dbt, on Snowflake | `[grounded]` your background | none |
| R6 | A cloud warehouse | must_have | direct | medium | none | Snowflake is a cloud warehouse; BigQuery is R7 | `[grounded]` your background | none |
| R7 | BigQuery (named in responsibilities) | important | absent | high | transferability | You have never used BigQuery (your statement). Snowflake, dbt and SQL carry over. BigQuery-specific cost and partitioning are unexercised | `[grounded]` your statement; `[inferred]` transfer | Bridge in interview; a small BigQuery project would narrow it |
| R8 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow orchestration, daily | `[grounded]` your background | none |
| R9 | Data quality testing | must_have | direct | medium | none | Set up a Great Expectations suite | `[grounded]` your background | none |
| R10 | Data contracts analysts depend on | important | unclear | low | discovery | Not in your inputs | `[grounded]` JD silence | Q3 |
| R11 | Ingestion from app and CRM | important | unclear | low | discovery | Not in your inputs | `[grounded]` JD silence | Q3 |

## Gap recovery queue

- **G1 (R10, R11), discovery.** Closed by: what you personally owned in analyst-facing contracts or app/CRM ingestion.
- **G2 (R7), transferability.** Closed in part by: a small BigQuery project, or a stated limit you can name without hedging.

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer footprint not independently established | risk_signal | low | "Senior Data Engineer — Pellucid Learning" (live on the company's domain) | Small company with a thin public footprint. Posting is live on its own site, so low, not medium | `[generic]` pattern for companies of this size, not a claim about this one | Who would I interview with, and which public source covers the Series C and the 31-state footprint? | unresolved |
| RR2 | Contract and ingestion ownership unstated | unknown | — | "data contracts our analysts depend on" | Ownership of analyst-facing contracts may be shared or unclear | `[inferred]` from the responsibilities against silence on sign-off | Which teams agree and enforce the data contracts, and which ingestion would I own myself? | unresolved |
| RR3 | Pay disclosed, at market | positive_signal | — | "$148,000–$166,000 plus equity" | Salary is disclosed and sits around the report's median | `[grounded]` JD and report | What equity and vesting come with the role? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Answer Q1–Q3, then decide | Gates first | `[grounded]` R1, R2 | your call |
| A2 | Resume: name Snowflake exactly; do not list BigQuery | Avoid a BigQuery claim you can't back | `[grounded]` your statement | pending your approval |
| A3 | Interview framing for R7: "I've built dbt on Snowflake and haven't run BigQuery; here's what I'd check first" | Honest bridge with a stated limit | `[inferred]` from R7 | pending your approval |
| A4 | Ask RR1–RR3 verbatim on the first recruiter call | The register doubles as prep | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Your intake statements are self-report until you confirm them specifically.

Research tier line and target table above.

## Dossier offer

At the end of this engagement I can write this out as a `tuesday-dossier.md`.

## Upgrade menu

- Your location and pay floor → R1 and R2 close; status moves to `conditional_go` or `no_go`.
- A small BigQuery project or any inspectable work → R7 moves up from absent.
- A dbt repository or a sanitized model and test sample → R5 and R9 move from medium toward high.
- The team's data-contract docs or the recruiter's answer → R10 and R11 resolve.
- A deeper pass on Pellucid (funding, leadership, past reports; up to 5 more searches and 2 more fetches) — say the word and it runs.

## Questions

**Q1 (R1):** Are you based in the US, and is remote-only work OK, or does the Denver office matter to you?

**Q2 (R2):** What base-salary floor would you accept?

**Q3 (R10, R11):** Have you owned analyst-facing data contracts or app/CRM ingestion? If so, what did you personally own?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.