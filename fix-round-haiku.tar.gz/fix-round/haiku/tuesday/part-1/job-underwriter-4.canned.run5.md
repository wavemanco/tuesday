**Yes, probably, but answer one question first.** On paper you clear the four must-haves, but the posting contradicts itself on location and I can't clear that gate without your answer. Status: `hold_pending_answers`.

- **Fit ledger.**
  - `hard_gate`: unclear: R1 (location: fully remote or Leeds four days a week)
  - `must_have`: direct: R2, R3, R4, R5 · adjacent: R6 (own pricing analytics for a pet-insurance product)
  - `important`: direct: R7, R8
  - `preferred`: direct: R9 (insurance experience)
- **Opportunity ledger.** The role is live and clearly scoped (RR3). The location terms conflict (RR1), and the salary is withheld (RR2).
- **Hard gates:** none failed; unconfirmed: R1 (location: fully remote or Leeds four days a week); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:** if you can work from Leeds four days a week, or the role is confirmed fully remote, the status moves to `conditional_go` (the pet gap and the salary remain). If you can't, it becomes `no_go` on R1.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, insurtech; pet-insurance product | `[grounded]` your message; careers page |
| Mandate | Own pricing analytics for the pet product; reports to the Director of Pricing | `[grounded]` careers page |
| Working pattern | JD says fully remote (UK); careers page says Leeds office four days a week | `[grounded]` both sources, contradictory |
| Salary | Withheld ("on application") | `[grounded]` careers page |
| Market calibration | Median base £58,400; interquartile range £52,100–£64,900 (n=612, one 2026 UK pay survey, snippet only) | `[generic]` role-family band; the posting's own figure is withheld, so this is not this employer's offer |
| Scope read | Ordinary for the title: one product, one reporting line | `[inferred]` from the careers page |
| Unknowns | Location terms; budgeted salary; company size and stage (not found in search); whether pet-book rating models are built the same way as motor | — |
| Contradictions | JD location vs careers-page location | `[grounded]` |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Location: fully remote or Leeds four days a week | hard_gate | unclear | none | hard_gate | Your location constraint wasn't given, and the posting's terms conflict | `[grounded]` both sources | Q1 |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | Five years at a motor insurer, two as senior analyst; self-reported, not yet probed | `[grounded]` your message | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | Daily use; self-reported | `[grounded]` your message | none |
| R4 | GLM experience | must_have | direct | medium | none | Built and maintained the young-driver GLM; motor, not pet | `[grounded]` your message | none |
| R5 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | Quarterly pricing review to the head of underwriting | `[grounded]` your message | none |
| R6 | Own pricing analytics for a pet-insurance product | must_have | adjacent | medium | transferability | Same pricing mechanics as motor; no pet work | `[inferred]` from the JD's product and your motor history | G1 |
| R7 | Design and read price tests | important | direct | medium | none | Ran 14 tests last year with underwriting | `[grounded]` your message | none |
| R8 | Build and monitor rating models | important | direct | medium | none | Built and maintained the young-driver model | `[grounded]` your message | none |
| R9 | Insurance experience (plus) | preferred | direct | medium | none | Motor insurer | `[grounded]` your message | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pet-insurance product (R6, must_have) | transferability | Five years of motor pricing; no pet work | R6 is the one must-have without direct experience | Any non-motor product you priced; any segmentation work beyond motor; any pet or companion-animal data you've seen | A model review pack or methodology note from any product | `[grounded]` CV; `[generic]` that pet pricing usually has different rating factors and claim patterns from motor |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Location terms conflict | risk_signal | medium | "Fully remote (UK)" vs "Leeds office four days a week" | The JD may be out of date, or the hire may be expected in Leeds | `[inferred]` from the two sources | Is this role fully remote as the posting says, or Leeds four days a week as the careers page says, and which applies to this hire? | unresolved |
| RR2 | Salary withheld | unknown | — | "salary on application" | The budget may sit below band, or the company may not publish pay | `[inferred]` from the withheld figure, against the `[generic]` band | What base salary is budgeted for this role? | unresolved |
| RR3 | Clear scope and reporting line | positive_signal | — | "reports to the Director of Pricing" | Scope is defined; you'd own the pet product's pricing analytics | `[grounded]` careers page | Which rating models would I own outright, and which go through you? | noted |
| RR4 | Hiring manager publishes on this work | positive_signal | — | Odile Varga's 2025 talk "Small Books, Loud Errors", on monitoring rating models in small books | Her interests overlap with R8 and the monitoring side of the role | `[grounded]` search snippet | Is the pet book's monitoring built on the same GLM setup as motor, or a different one? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Get the location answer from the recruiter before applying | RR1, R1 | `[grounded]` RR1 | pending your approval |
| A2 | Ask for the budgeted base before investing in the loop | RR2 | `[grounded]` RR2 | pending your approval |
| A3 | Frame the pet gap as transferability, naming the limit, not as pet experience | R6 | `[grounded]` R6 row | pending your approval |
| A4 | Read Odile Varga's 2025 talk before any interview | RR4 | `[grounded]` search snippet | pending your approval |

## Evidence status

Verified: none yet. Every claim in the map is your self-report and hasn't been probed.

Research tier: L1 — searches 4 of 5, fetches 1 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Brindlemoor insurtech pet insurance" (no results) and "Brindlemoor Senior Pricing Analyst jobs"; fetched "Senior Pricing Analyst — Brindlemoor careers" (brindlemoor.co.uk/careers/senior-pricing-analyst). Moved RR1 and RR3. Company size and stage were not found |
| 2. Role-family sweep | yes | Searched "senior pricing analyst insurance UK salary"; returned "Pricewell 2026 UK Pricing and Actuarial Analytics Pay Survey" (pricewell.example/2026-uk-pricing-analytics-pay-survey), read as a snippet only. Moved the market calibration line. The remit sweep was not run |
| 3. Hiring manager's public footprint | yes | Searched "Odile Varga Director of Pricing"; returned a profile (linkedin.example/in/odile-varga), read as a snippet only. Moved RR4 and the positioning in A4 |

## Upgrade menu

- Any non-motor pricing or pet data you've worked with → R6 moves up from `adjacent`.
- The recruiter's answer on location (RR1) → R1 resolves; the status likely becomes `conditional_go` or `no_go`.
- A budgeted salary (RR2) → set against the band in role reality.
- Your base-pay floor and contract preference → the hard-gate checks run, which they can't yet.
- Pasting the posting text directly, or a CV → confirms the claims and probes R2 to R9 for `high`.

Want me to write this up as `tuesday-dossier.md` so it can be reused for interview prep?

**Questions**
1. **R1:** Can you work from Leeds four days a week, or do you need the fully remote version? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.
2. **G1:** Have you priced any non-motor product, or worked with pet or companion-animal data at all? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.
3. **Constraints:** What base-pay floor do you need, and must the role be permanent rather than fixed-term? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.