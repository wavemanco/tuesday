## Job Underwriting: Head of Growth at Novaline

*First pass, 2026-11-11. Web search was refused this turn, so the employer and market checks are open (see Research tier below).*

## Decision snapshot

No. On the terms Novaline posted, you can't take this role, even though the rest of it fits you well. R1 and R2, both hard gates, fail · `no_go`.

**Fit ledger.**

- `hard_gate` — hard_gate_fail: R1 (on-site in Austin, 5 days a week), R2 (base pay, $70–85k)
- `must_have` — direct: R3 (8+ years growth leadership), R4 (paid acquisition), R5 (lifecycle and CRM)
- `important` — unclear: R6 (SEO/content, brand, PR), R7 (partnerships, sales ops)

R1 and R2 are the two gates that fail; R3, R4 and R5 are the must-haves that match your record; R6 and R7 are scope you haven't shown evidence for.

**Opportunity ledger.** The posting shows a bundled-specialization pattern and an always-on expectation (RR1, RR2), with a base well below the seniority it asks for (RR3). The employer is unverified (RR4), and the equity is undefined (RR5). The Series A and profitability claim (RR6) is the posting's own statement. Your sense that something is off matches RR1 and RR2.

- **Hard gates:** failed: R1 (on-site in Austin, 5 days a week), R2 (base pay, $70–85k against your $150k floor).
- **Severe red flags:** RR1 (`severity: high`)
- **What would change this:** Novaline would have to change both gates in writing, the on-site requirement and the base pay. Nothing else on the map changes the status.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Novaline, e-commerce enablement, Series A, "profitable since day one" | `[grounded]` posting; employer not verified this turn |
| Mandate | All revenue growth end to end: paid, SEO/content, lifecycle, brand, PR, partnerships, sales ops | `[grounded]` posting |
| Reporting | CEO, with a dotted line to the board | `[grounded]` posting |
| Working pattern | On-site in Austin 5 days a week, "no exceptions"; evenings and weekends "when it matters" | `[grounded]` posting |
| Scope read | Seven revenue functions for a team of one at the start | `[inferred]` from the posting's scope list against its headcount |
| Market calibration | Not established. The role-family search was refused this turn, so no band is confirmed | not established |
| Unknowns | Equity size and terms; which of the seven functions has budget and an owner; whether the base is approved | — |
| Contradictions | None found in the posting text | `[grounded]` posting |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | On-site in Austin, 5 days a week | hard_gate | hard_gate_fail | high | hard_gate | Your remote-only constraint is your own, specific and confirmed, so it grades high. The posting rules out exceptions, so the gate fails. Nothing in the material suggests it would flex | `[grounded]` posting quote; user-stated constraint | None on your side; the employer changing the term is the one thing that resolves it |
| R2 | Base pay at or above your floor | hard_gate | hard_gate_fail | high | hard_gate | Your $150k floor is your own confirmed number. The posted $70–85k sits well below it, even at the top of the range | `[grounded]` posting; user-stated constraint | None on your side; a revised base is the one thing that resolves it |
| R3 | 8+ years growth leadership | must_have | direct | medium | none | Nine years, growth lead then Head of Growth at two B2C subscription companies. CV self-report with no inspectable artifact yet, so expect a probe | `[grounded]` CV | None |
| R4 | Paid acquisition, owned end to end | must_have | direct | medium | none | Owned paid at both companies; the $8M to $40M ARR run had a budget you controlled | `[grounded]` CV | None |
| R5 | Lifecycle and CRM | must_have | direct | medium | none | Owned lifecycle; deep in Braze | `[grounded]` CV | None |
| R6 | SEO/content, brand, PR | important | unclear | none | discovery | Nothing in the material either way | `[grounded]` CV silence | See G1 |
| R7 | Partnerships, sales ops | important | unclear | none | discovery | Nothing in the material either way | `[grounded]` CV silence | See G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | SEO/content, brand, PR (R6) | discovery | Nothing in the material | Doesn't move the status while R1 and R2 fail | An SEO program, a brand campaign, a PR cycle you ran or managed | A content plan, a campaign deck, a dashboard | `[grounded]` CV silence; `[inferred]` that it doesn't move the status |
| G2 | Partnerships, sales ops (R7) | discovery | Nothing in the material | As G1 | Partner deals, affiliate programs, a sales-ops process you built | A partner agreement, a pipeline report | `[grounded]` CV silence; `[inferred]` as G1 |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Bundled specialization: seven revenue functions for one person | risk_signal | high | "Own all revenue growth end to end… You will be a team of one to start" | The role may be several full jobs folded into one title on a single-hire budget | `[generic]` pattern for postings with this scope list, not a claim about Novaline | Which of these seven functions has budget and a named owner in year one, and which would you deprioritize first? | unresolved |
| RR2 | Always-on expectation | risk_signal | medium | "evenings and weekends when it matters is just who we are" | Evenings and weekends may be routine rather than occasional | `[grounded]` quote; `[generic]` that this phrasing usually signals routine after-hours work | How many weekends did the last person in this role work in a typical quarter? | unresolved |
| RR3 | Seniority-compensation mismatch | risk_signal | medium | "8+ years growth leadership required" against "$70–85k base" | The base may sit well below what eight-plus years of leadership commands; the market band is not confirmed this turn | `[grounded]` both figures; the market comparison is not established | How was the $70–85k base set for a leader with eight-plus years, and is it the approved budget for this role? | unresolved |
| RR4 | Employer not established from attributable sources | risk_signal | medium | "Novaline (e-commerce enablement startup, Series A…)" | Not checked: the existence search was refused this turn. The posting may be stale, aggregated or unrepresentative | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me to this role on Novaline's own careers page, and who would I be interviewing with? | unresolved |
| RR5 | Equity undefined | unknown | — | "meaningful equity upside" | Size and vesting could matter more than base here, and neither is stated | `[grounded]` quote | What is the grant as a percentage of fully diluted shares, with strike price and vesting schedule? | unresolved |
| RR6 | Stated Series A and profitability | positive_signal | — | "Series A, profitable since day one" | If true, budget pressure is lower than the scope suggests. The claim is the posting's own and unverified | `[grounded]` posting statement | What are the current revenue and runway figures, or the latest board-level plan? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Don't apply on the posted terms | see R1, R2 | `[grounded]` posting gates | Recommended; your call |
| P2 | If you want to test it anyway, ask Novaline in writing whether Austin on-site and the base can change | see R1, R2, RR4 | `[grounded]` posting "no exceptions" | Pending your approval |

## Evidence status

Verified: R1 and R2 (your stated constraints, confirmed in this conversation). R3, R4 and R5 are CV claims and are not yet verified.
Unverified leads: none.
Rejected inferences: none.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches for Novaline's site, careers page and existence were refused permission this turn. I did not retry. Would have settled whether the posting is live and the employer exists as described (RR4) |
| 2. Role-family sweep | unavailable | Two searches for Head of Growth pay and scope were refused. Would have set the market band behind RR3 and the scope norm behind the scope read |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

A deep dive on Novaline's funding and leadership history is also possible if you want it. Dossier offer: I can save this as a `tuesday-dossier.md` you can keep and carry into mock-interview later if you ever pursue the role.

## Upgrade menu

- Permission to retry the web searches, or the live posting link plus Novaline's careers page → runs the employer check (RR4) and the role-family band behind RR3.
- A recruiter's written base band → RR3 closes, and the posted figure is set against it.
- The equity grant terms → RR5 closes.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.