**Decision snapshot: conditional go.** Apply, but treat it as a stretch, and check two things first.

- **Hard gates:** Nothing has failed, but two are unverified. The role is Bristol hybrid, two office days a week. Your location and willingness for that are unknown to me. The salary is £61,500–£67,000 plus share options; I don't know your floor.
- **Fit:** Strong on pipeline and renewal reporting and CRM admin. Partial on years and sector, and on SQL/spreadsheet modelling. Gaps on forecast ownership and billing data. Fit is shown per requirement below, not as a score.
- **Opportunity:** The posting puts CRM ownership, billing data and a quarterly forecast with the CFO into one role. That is a broad scope, possibly a thin team [inferred]. I could not verify that Quillfield exists as described, because I ran no searches.

**Role reality**
- Revenue Operations Lead, Quillfield (invoicing software), Bristol hybrid [grounded].
- Duties: own CRM and billing data; build pipeline and renewal reporting for sales and finance; run the quarterly revenue forecast with the CFO [grounded].
- Stated requirements: 4+ years in RevOps, sales ops or analytics at a B2B software company; HubSpot or Salesforce admin; strong SQL and spreadsheet modelling; experience owning a forecast; experience working with finance on billing or revenue data [grounded]. The posting doesn't separate must-haves from preferences, so I treat all five as stated.
- Forecast and billing are headline duties, not side notes [grounded].
- Market calibration and pay comparison: not run. I have no sourced UK band, so I can't say whether £61.5–67k is high or low.
- Hiring manager Tamsin Achebe: public footprint not checked.

**Evidence map**

| # | Requirement | Fit | Confidence | Evidence |
|---|---|---|---|---|
| 1 | 4+ yrs RevOps / sales ops / analytics at B2B software | Met on years; partial on sector | High | 5 yrs sales ops at a B2B payments company, last 2 running UK revenue ops. Describe it as payments, not software, unless the product was software. |
| 2 | HubSpot or Salesforce admin | Met | High | Salesforce admin certified. |
| 3 | Strong SQL and spreadsheet modelling | Met on SQL; partial on modelling | Medium | SQL weekly, Excel daily. No modelling work described. |
| 4 | Experience owning a forecast | Gap | n/a | Finance owned the company forecast. Your monthly pipeline review is adjacent, not ownership. |
| 5 | Experience with finance on billing or revenue data | Gap on billing; partial on revenue | Low | No billing work. Renewal dashboards touch revenue, but whether finance was your counterpart is unknown. |
| D1 | Pipeline and renewal reporting for sales and finance (duty) | Met | High | Your strongest match: you rebuilt both dashboards. |

**Gap recovery queue** (what each gap is and what would close it)
- **G1, forecast:** Closed by evidence that you supplied pipeline, renewal or bookings inputs to a forecast, or reconciled them with finance. Reframing won't close it.
- **G2, billing data:** Closed by any work with invoices, billing exports or finance reconciliations, even read-only.
- **G3, location and hybrid:** Closed by your answer on location and the two office days.
- **G4, pay:** Closed by your floor, compared against the band.

**Risk register**
- **Employer unverified** [inferred from the job board link]. Resolve by checking Quillfield's own careers page and the recruiter's email domain. This is why the decision is conditional.
- **Scope may be broad** [inferred]. Ask in the first interview who else is on the team and who owns the forecast day to day.
- **Pay unbenchmarked.** Not yet compared with any band.
- **Forecast will be probed.** It's a headline duty, so expect questions on it.

**Application plan**
- Lead with pipeline and renewal reporting, Salesforce admin, and running the monthly pipeline review with a sales director.
- Don't claim forecast ownership or billing experience. Say what you did, and name what you'd need to learn on billing.
- Use "modelling" only if you've built models.
- Before applying: confirm the employer, your location, and your pay floor.

**Evidence status**
Research tier: L0, no searches; user links read 1

| Target | Status | Reason |
|---|---|---|
| Company site and careers page | skipped | L0, no searches |
| Role-family sweep (scope, title, pay) | skipped | L0, no searches |
| Hiring manager public footprint | skipped | L0, no searches |

I worked from the playbook's core rules and did not open its full reference set, so the table layout is close to the spec rather than exact.

**Upgrade menu:** A light research pass (L1) would verify the employer, benchmark the pay band, and check Tamsin Achebe's public footprint so you can pitch to her. Sharing your CV would let me check each claim above against the wording you actually use.

If you want, I can save this as `tuesday-dossier.md` so the mock-interview module can reuse it later.

**Questions** (answer any, skip any)
1. **(G3)** Where are you based, and can you do two days a week in Bristol?
2. **(G1, G2)** Have you ever given pipeline, renewal or bookings numbers to finance for their forecast, or reconciled them against invoices or revenue, even informally?
3. **(G4)** What's your pay floor, and does £61.5–67k plus options clear it?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.