**Yes, it's worth applying, on three conditions.** Status: `conditional_go`. Your must-haves all look direct. Two hard-gate terms (location and pay) are unconfirmed because you haven't stated your constraints, and one important requirement (BigQuery) is a real but bridgeable gap.

- **Fit ledger.**
  - `hard_gate` — unclear: R1, R2
  - `must_have` — direct: R3, R4, R5, R6, R7, R8
  - `important` — adjacent: R9 · unclear: R10, R11
  - R9 is a bridge: your Snowflake dbt work carries over, but BigQuery's specifics are unexercised.
- **Opportunity ledger.** Mostly sound. The posted salary sits near the market median (RR5), but the hiring manager, on-call load and equity are unstated (RR1–RR3), and the company's funding claims rest only on its own site (RR4).
- **Hard gates:** none failed; unconfirmed: R1 (remote US or Denver location), R2 (pay against your floor); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:** (1) R1 confirmed met; (2) R2 confirmed at or above your floor; (3) RR1 and RR2 answered cleanly by the recruiter or in a first conversation. Frame R9 as adjacent Snowflake experience, never as BigQuery experience.

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning, live online K-12 tutoring, Denver, founded 2016 | `[grounded]` company About page, fetched |
| Posting | Live on the careers page; text matches the JD you pasted | `[grounded]` careers page, fetched |
| Scope | Build and run reporting pipelines; own dbt warehouse and data contracts | `[grounded]` JD |
| Market calibration | Senior DE base median $151k, IQR $139k–$163.5k; the posted $148k–$166k sits around the median with a midpoint near $157k | `[generic]` the Datawright figures you pasted; `[grounded]` posted range |
| Contradictions | None between the JD and the careers page | `[grounded]` |

**Evidence map** (confidence is capped at `medium` for everything you've told me in prose, since nothing has been inspected yet)

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote US or Denver location | hard_gate | unclear | none | hard_gate | Your location and work authorization weren't given | `[grounded]` JD | Q1 |
| R2 | Pay at $148k–$166k against your floor | hard_gate | unclear | none | hard_gate | Your floor wasn't given | `[grounded]` JD | Q2 |
| R3 | 5+ years data engineering | must_have | direct | medium | none | Six years, confirmed in prose | `[grounded]` your background | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | Daily use, stated | `[grounded]` your background | none |
| R5 | dbt | must_have | direct | medium | none | 180-model dbt project on Snowflake | `[grounded]` your background | none |
| R6 | A cloud warehouse | must_have | direct | medium | none | Snowflake is a cloud warehouse | `[grounded]` your background | none |
| R7 | Airflow or similar orchestration | must_have | direct | medium | none | Airflow, stated | `[grounded]` your background | none |
| R8 | Data quality testing | must_have | direct | medium | none | Set up a Great Expectations suite, stated | `[grounded]` your background | none |
| R9 | BigQuery warehouse | important | adjacent | medium | transferability | Snowflake dbt work carries over; BigQuery never used. Limit: its partitioning, clustering and pricing model | `[inferred]` bridge from Snowflake work | G1 |
| R10 | Ingestion from the app and CRM | important | unclear | none | discovery | Not mentioned in your background | `[grounded]` absence in your background | upgrade menu |
| R11 | Data contracts analysts depend on | important | unclear | none | discovery | Not mentioned in your background | `[grounded]` absence in your background | Q3 |

**Gap recovery queue**

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R9, important) | transferability | Snowflake dbt work on 180 models; no BigQuery | The posting names it, and it is the most likely interview probe | Any cloud-warehouse migration, a GCP side project, or a sandbox you ran queries in | A sanitized Snowflake-to-BigQuery design note, or a short sandbox write-up | `[inferred]` bridge; `[generic]` that BigQuery specifics are the likeliest probe |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Hiring manager and team not named | unknown | — | (no manager named) | You may own this domain alone, or the team may be larger | `[inferred]` from the posting's silence | Who would I report to, and do I own the reporting pipelines alone or with others? | unresolved |
| RR2 | Operational load unstated | unknown | — | "Build and run the pipelines" | "Run" may mean on-call for live tutoring reporting | `[inferred]` from "run" against silence on on-call | What does on-call look like, and how often does it page? | unresolved |
| RR3 | Equity unquantified | unknown | — | "plus equity" | The equity may be worth far less or more than the salary suggests | `[grounded]` posting | What is the grant size, vesting schedule, and valuation basis? | unresolved |
| RR4 | Funding and size rest on the company's own site | risk_signal | low | "Series C ($52M, February 2026)" | The figures may be accurate but are unconfirmed; two searches found no independent coverage | `[generic]` pattern for private companies of this size; `[grounded]` search results | Who led the Series C, and what is the data team's budget through its next year? | unresolved |
| RR5 | Posted salary near market median | positive_signal | — | "$148,000–$166,000" | Pay is competitive for the title and level | `[generic]` Datawright band, pasted by you | What is the budgeted level for this role? | noted |

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead the resume with the 180-model dbt project and the Great Expectations suite, naming Snowflake explicitly | R5, R8 | `[grounded]` your background | pending your approval |
| E2 | Do not list BigQuery; frame R9 only as Snowflake experience and a stated learning plan | R9 | `[grounded]` your background | pending your approval |
| E3 | Put RR1–RR3 to the recruiter before investing in the loop | RR1–RR3 | `[grounded]` register | pending your approval |

**Evidence status**

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 2 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Fetched pellucidlearning.com/careers/senior-data-engineer (posting live, text matches the JD) and pellucidlearning.com/about (company facts match your paste). Searched "Pellucid Learning live online tutoring K-12 Denver" (no results) and "Pellucid Learning" Series C funding (returned only the About page). Moved role reality's organization row and RR4 |
| 2. Role-family sweep | skipped | The Datawright figures you pasted fix the market calibration and compensation band (RR5, role reality) |
| 3. Hiring manager's public footprint | n/a | No name was given |

Dossier offer: I can save this assessment as a `tuesday-dossier.md`, so your interview prep can start from the same evidence.

Upgrade menu:
- Your location and work-authorization status → R1 resolves, and the decision moves to `go` or `no_go`.
- Your pay floor → R2 resolves against the posted range.
- A sanitized Snowflake-to-BigQuery note or sandbox write-up → R9 moves toward `direct`.
- A redacted dbt model or data-contract doc → R5 and R11 move to `high`.
- The recruiter's answers on on-call and equity → RR2 and RR3 close.
- The hiring manager's name → RR1 closes, and the application plan can be tailored to that reader.
- A deeper pass on Pellucid's funding and leadership (up to 5 more searches and 2 more fetches) — say the word and it runs.

Questions (answer in text, paste a voice transcript, attach a document, drop a link, or say skip):

1. **R1** — Are you authorized to work in the US, and are you based in the US or willing to work from Denver?
2. **R2** — Is $148,000 at or above your floor, before equity?
3. **R11** — Have you owned data contracts, meaning a published schema or SLA that analysts build against? If so, what did the contract cover, and who enforced it?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.