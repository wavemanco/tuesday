**Yes, it's worth an application, with two checks first. Status: `conditional_go`.** The stack and seniority match closely. Pay and location are the open items, and they depend on constraints you haven't given me.

**Fit ledger.**

- `hard_gate` — unclear: R1 (remote US or Denver office), R2 (salary $148,000–$166,000)
- `must_have` — direct: R3–R7 (5+ years data engineering through data quality testing)
- `important` — adjacent: R8 (BigQuery warehouse) · unclear: R9 (ingestion from app and CRM), R10 (data contracts for analysts)

R3–R7 are direct on your own account, not yet on an artifact. R8 is the one real stack gap. R1 and R2 can't be checked until you tell me your constraints.

**Opportunity ledger.** Sound, with open items: the hiring manager and team are unnamed (RR1), equity is unquantified (RR2), and it's unclear whether the warehouse is already on BigQuery or being migrated (RR3). The concrete mandate is a positive signal (RR4). The posting and employer are unverified because my checks were refused (RR5).

- **Hard gates:** none failed; unconfirmed: R1 (remote US or Denver office), R2 (salary $148,000–$166,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) your pay floor and location are met by R1 and R2; (2) the posting is live and the employer checks out (RR5); (3) the BigQuery gap (R8) is presented as adjacent, never as experience, and RR1 is answered.

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 states; founded 2016, Denver; 264 employees; Series C, $52M, February 2026 | `[grounded]` your pasted about page; not checked online (RR5) |
| Mandate | Build and run ingestion from the app and CRM, a dbt-modelled BigQuery warehouse, and analyst data contracts | `[grounded]` JD |
| Scope read | Senior IC ownership of pipelines, with no direct reports stated | `[inferred]` from the JD's responsibilities, silent on reports |
| Market calibration | Posting range sits inside the report's interquartile range ($139,000–$163,500), near the $151,000 median at the bottom and above it at the top. The report's stage group (Series B–D) matches Pellucid's Series C | `[generic]` Datawright 2026 report you shared (n=2,310) |
| Unknowns | Hiring manager, team size, equity grant and vesting, contract type, BigQuery state, pay floor | — |
| Contradictions | None found within the pasted material | `[grounded]` JD and about text |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | No location constraint given, so the gate can't be settled | `[grounded]` JD; no candidate statement | Q1 |
| R2 | Salary $148,000–$166,000 | hard_gate | unclear | none | hard_gate | No pay floor given; the figure sits in the market band | `[grounded]` JD; `[generic]` band | Q1 |
| R3 | 5+ years data engineering | must_have | direct | medium | none | Six years stated at intake, a self-report with no artifact yet | `[grounded]` your intake | Confirm dates in your CV |
| R4 | Strong SQL and Python | must_have | direct | medium | none | Daily use stated; "strong" is self-assessed | `[grounded]` your intake | Show one query or pipeline sample |
| R5 | dbt and a cloud warehouse | must_have | direct | medium | none | ~180 dbt models on Snowflake, a cloud warehouse | `[grounded]` your intake | Name Snowflake explicitly in the application |
| R6 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow stated | `[grounded]` your intake | DAG sample if you can share one |
| R7 | Data quality testing | must_have | direct | medium | none | You set up a Great Expectations suite | `[grounded]` your intake | Suite summary or screenshot |
| R8 | BigQuery warehouse (named in the posting's mandate) | important | adjacent | medium | transferability | Snowflake dbt work carries over; BigQuery itself is unused | `[inferred]` the requirement from the mandate; `[generic]` that dbt runs across warehouses | P3 |
| R9 | Ingestion from app and CRM | important | unclear | low | discovery | Not in your intake; the mandate names it | `[inferred]` from the JD's responsibilities | Q2 |
| R10 | Data contracts analysts depend on | important | unclear | none | discovery | No evidence in the intake | `[inferred]` from the JD's responsibilities | Q3 |

**Gap recovery queue.** Each gap's question is asked once, in the closing block.

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R8) | transferability | Snowflake dbt, no BigQuery | Likely first objection; a bridge with its limit stated answers it | A dbt project on any warehouse you migrated or re-platformed; any cloud SQL warehouse work | A small dbt-on-BigQuery project, or a migration note | `[inferred]` bridge from your Snowflake work; `[generic]` that this is the likeliest objection |
| G2 | Ingestion (R9) | discovery | Not stated | The posting names it as core scope | Pipelines from a production app database; CRM API or export pipelines | Pipeline diagram or DAG sample | `[inferred]` from the JD |
| G3 | Data contracts (R10) | discovery | Not stated | A named responsibility, and a common interview probe | Schema agreements with analysts; freshness or breakage alerts | A contract doc or an alert example | `[inferred]` from the JD; `[generic]` that contracts get probed |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Hiring manager and team unnamed | unknown | — | "Build and run the pipelines" | The role may sit alone or in a small team | `[inferred]` from the posting's silence | Who would I report to, and how many engineers own these pipelines today? | unresolved |
| RR2 | Equity unquantified | unknown | — | "plus equity" | Equity may be small or back-weighted | `[inferred]` from the withheld terms | What is the equity grant, its vesting schedule, and the valuation it's based on? | unresolved |
| RR3 | Warehouse state unclear | unknown | — | "a dbt-modelled warehouse in BigQuery" | The warehouse may be mid-migration, which changes your ramp | `[inferred]` from the mandate's wording | Is the warehouse already on BigQuery with a dbt project, or is it being migrated? | unresolved |
| RR4 | Concrete mandate | positive_signal | — | "ingestion ... reporting ... data contracts" | Scope and outputs are defined | `[grounded]` JD | Who consumes the contracts, and who owns breakages? | noted |
| RR5 | Posting and employer unverified | unknown | — | Pasted JD and about text | Both may be accurate; neither is confirmed | `[grounded]` the checks were refused | — (next action P4) | unresolved |

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Get your pay floor and location answered before applying | R1, R2 | `[grounded]` JD | pending your answer |
| P2 | Lead with the Snowflake dbt project and the Great Expectations suite; name Snowflake, never imply BigQuery | R5, R7 | `[grounded]` intake | pending your approval |
| P3 | Before applying, close G1 with a small dbt-on-BigQuery project, and claim it only once it's built | R8 | `[generic]` that a sandbox project is a feasible closure path | pending your approval |
| P4 | Confirm the posting is live and the employer exists before any application effort | RR5 | `[grounded]` RR5 | pending your approval |
| P5 | Ask the recruiter about the hiring manager, team size, equity and warehouse state | RR1–RR3 | `[grounded]` register | pending your approval |

**Evidence status**

Verified: none yet. Your intake is self-report, so every claim sits at `medium` until a probe or artifact confirms it. Unverified leads: none. Rejected inferences: none.

Research tier: L1 — searches 1 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | One fetch of the posting and one search for the company were both refused permission. The posting's liveness and Pellucid's funding and headcount stay as your pasted text. This would have moved role reality's organization row and RR5 |
| 2. Role-family sweep | skipped | The Datawright 2026 figures were in your request, so the band is already in hand |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

If you grant web permission, target 1 can run and would check RR5 and the Pellucid facts.

If you want this as a file, I can write it up as a `tuesday-dossier.md` for you to keep, and mock-interview can pick it up later.

**Upgrade menu**

- Your pay floor and the location you can work from → R1 and R2 move to met or failed, and the status moves to `go` or `no_go`.
- A posting link you opened yourself, or the recruiter's email domain → RR5 clears.
- Web permission → the posting, Pellucid's funding news, and whether their stack is on BigQuery (RR3) get checked.
- A dbt-on-BigQuery project or migration note → R8 moves toward direct.
- A repo, dbt docs, or the Great Expectations suite → R3–R7 move from `medium` to `high`.

**Questions**

Q1 (R1, R2): What's your pay floor, and can you work from the Denver office or remote US? Are there any limits on either?

Q2 (R9, G2): Have you built ingestion from a production app database or a CRM API, and owned those pipelines end to end? Which system, and what did you own?

Q3 (R10, G3): Have you defined data contracts with analysts as the consumers, covering schema, freshness or breakage alerts? What did you own?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.