**Not yet: hold until the location is settled.** The posting says fully remote, but Brindlemoor's careers page says Leeds four days a week. Status: `hold_pending_answers`.

- **Hard gates:** none failed; unconfirmed: R1 (fully remote, UK), R2 (salary not stated); candidate constraints not given — checks against them unknown.

**Fit ledger.**

- `hard_gate` — unclear: R1 (fully remote, UK), R2 (salary not stated)
- `must_have` — direct: R3, R4, R5, R6
- `important` — direct: R7a, R8 · unclear: R7b (recommendations to product)
- `preferred` — direct: R9 · adjacent: R10 (pet-insurance product)

R1 and R2 are the gates the posting leaves open. R3, R4, R5 and R6 are every must-have, all direct. R7b and R10 are the two rows below direct outside the gates.

**Opportunity ledger.** The remote term is in conflict between two sources (RR1), the salary is withheld (RR2), and the company's wider footprint is thin in search (RR3). One entry runs the other way: the hiring manager has published on the monitoring side of the role (RR4).

- **Severe red flags:** RR1 (`severity: high`)
- **What would change this:** the awaited answers are (1) whether the role is fully remote as posted (R1, RR1), (2) your own location and remote requirement (R1), and (3) your base floor against the band (R2, RR2). If remote is confirmed and your floor sits inside the band, this moves to `go`. If the role is a four-day Leeds office role and you can't do that, it becomes `no_go` on R1.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech; the posting is live on its own careers site | `[grounded]` careers page fetched |
| Mandate | Own pricing analytics for the pet-insurance product; build and monitor rating models; design and read price tests; turn results into recommendations for underwriting and product | `[grounded]` JD |
| Reporting line | Reports to the Director of Pricing | `[grounded]` careers page |
| Working pattern | Contradiction: JD says "Fully remote (UK)"; careers page says "Leeds office four days a week" | `[grounded]` both sources |
| Scope read | One product's pricing analytics, with recommendations going to two functions | `[inferred]` from the mandate's two named audiences |
| Market calibration | Senior pricing analysts at UK insurers and insurtechs: median £58,400, interquartile range £52,100–£64,900 (survey of 612). The posting withholds salary, so this is what to expect, not this employer's offer | `[generic]` Pricewell 2026 pay survey, snippet only; `[grounded]` JD for the withheld salary |
| Unknowns | Salary; whether the role has direct reports (JD is silent); pet-book size; team size; how far product recommendations go | — |
| Contradictions | Remote versus Leeds four days a week (RR1) | `[grounded]` both sources |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote (UK) | hard_gate | unclear | none | hard_gate | The posting and careers page disagree. Your own location and remote requirement are not in the material, so there is no statement to grade | `[grounded]` both sources | Q1 below |
| R2 | Salary (not stated) | hard_gate | unclear | none | hard_gate | Posting states no pay. Your floor is not in the material | `[grounded]` JD silence | Q2 below |
| R3 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | Five years in UK motor pricing analytics, two as senior analyst. Self-reported intake, so medium at most | `[grounded]` your intake | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | Daily use. Self-reported; no artifact yet | `[grounded]` your intake | none |
| R5 | GLM experience | must_have | direct | medium | none | Built and maintained the young-driver GLM. Motor, not pet | `[grounded]` your intake | none |
| R6 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | Quarterly pricing review to the head of underwriting | `[grounded]` your intake | none |
| R7a | Design and read price tests | important | direct | medium | none | Ran 14 price tests last year with underwriting | `[grounded]` your intake | none |
| R7b | Turn results into recommendations for product, not only underwriting | important | unclear | low | discovery | Your account covers underwriting recommendations only. Product is not in the material | `[grounded]` silence on product | Ask whether you have taken test results to product teams |
| R8 | Build and monitor rating models | important | direct | medium | none | "Built and maintained" covers build. Monitoring is a reading of "maintained", so make that specific in interview | `[grounded]` intake; `[inferred]` monitoring reading | none |
| R9 | Insurance experience | preferred | direct | medium | none | UK motor insurer, five years | `[grounded]` your intake | none |
| R10 | Pet-insurance product knowledge | preferred | adjacent | medium | transferability | Motor pricing carries over. Limit: no pet claims, pet rating factors, or pet-book pricing. Do not claim pet experience | `[inferred]` adjacency from motor pricing; `[grounded]` your statement you have never worked on pet | Bridge case, see upgrade menu |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Product recommendations (R7b) | discovery | Underwriting recommendations are in your account; product is not | Product-facing recommendations are half the mandate | Any test result that changed a product's pricing, eligibility or proposition; a deck or memo to a product lead | A product-facing deck, a memo, or a launch note | `[grounded]` silence on product |
| G2 | Pet-insurance bridge (R10) | transferability | Motor pricing only | Preferred, but the most likely objection | A small or noisy motor segment where rating decisions turned on thin data | A sanitised segment review or a pricing note | `[inferred]` bridge from motor |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Remote term in conflict between JD and careers page | risk_signal | high | "Fully remote (UK)" vs "Leeds office four days a week" | Either the JD or the careers page is out of date; either way the term is not settled | `[inferred]` from two sources disagreeing on one term | Is this role fully remote as the posting says, or a Leeds office four days a week as the careers page says? | unresolved |
| RR2 | Salary withheld | unknown | — | Posting is silent on pay | The figure may sit below the band, or the company may not publish pay | `[inferred]` from silence against the `[generic]` band | What base salary is budgeted for this role? | unresolved |
| RR3 | Thin public footprint for the company | unknown | — | Search "Brindlemoor insurtech pet insurance" returned nothing; the careers page is the only attributable source | Small companies often have thin footprints; not a claim about this one | `[generic]` pattern for companies of this size | How many people sit in pricing, and how many policies does the pet product carry? | unresolved |
| RR4 | Hiring manager has published on the role's core work | positive_signal | — | Talk "Small Books, Loud Errors" on monitoring rating models in small books | The role's monitoring focus is one the hiring manager has spoken on | `[grounded]` talk listing (search snippet, not opened) | What does good monitoring look like for a small book, and what would you want changed in the first six months? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Ask the recruiter to confirm the location in writing before applying | see RR1, R1 | `[grounded]` RR1 | pending your approval |
| A2 | Ask for the budgeted base before investing in the loop | see RR2, R2 | `[grounded]` RR2 | pending your approval |
| A3 | Lead with R5 and R6 as you wrote them: "built and maintained" the young-driver GLM, and presenting the quarterly review to the head of underwriting | Strongest traceable match | `[grounded]` your intake sentences | pending your approval |
| A4 | Do not claim pet experience or "monitoring" as a separate credential until you confirm both | Reframing audit: neither is in your sentences | `[grounded]` your intake | pending your approval |

## Evidence status

Verified: none yet. Unverified leads: none.

Research tier: L1 — searches 4 of 5, fetches 1 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Brindlemoor careers Senior Pricing Analyst pet insurance", which returned the careers page; fetched "Senior Pricing Analyst — Brindlemoor careers" (brindlemoor.co.uk/careers/senior-pricing-analyst). Moved RR1 and confirmed the posting is live. A second search, "Brindlemoor insurtech pet insurance", returned nothing (moved RR3) |
| 2. Role-family sweep | yes | Searched "senior pricing analyst UK general insurance salary GLM", which returned "Pricewell 2026 UK Pricing and Actuarial Analytics Pay Survey" (pricewell.example/2026-uk-pricing-analytics-pay-survey). Read from the search snippet only; not opened. Moved the market calibration line |
| 3. Hiring manager's public footprint | yes | Searched "Odile Varga Director of Pricing insurance", which returned a profile (linkedin.example/in/odile-varga) and a talk listing. Read from snippets only. Moved RR4 and the application plan's positioning |

## Upgrade menu

- A written confirmation of the location, from the recruiter or a corrected posting → R1 and RR1 close, and the decision can move to `go` or `no_go`.
- Your own location and remote requirement → R1 closes.
- The budgeted base, or your own floor → R2 and RR2 close, and the figure is set against the band.
- A product-facing example from your work → R7b moves from `unclear`.
- A sanitised segment review from motor where thin data drove a rating decision → R10 moves from `adjacent` toward `direct` for the monitoring side of the role.
- A deeper research pass on Brindlemoor (funding, team size, product, recent news; up to 5 more searches and 2 more fetches) — say the word and it runs.

Want me to save this as `tuesday-dossier.md`? Say the word and I'll write it.

**Questions**

Q1 (R1, RR1): Could you work from a Leeds office four days a week, or does the role have to be fully remote?

Q2 (R2): What base salary floor do you need, so I can set it against the band?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.