**Not a waste of time, but not a clean fit either: `conditional_go`.** Apply if the recruiter confirms that the 3+ years of product management bar can be met by implementation and requirements work. Your strongest true pitch is technical product work done from the implementation seat, not a product management track record.

- **Fit ledger:**
  - `must_have`: `direct`: R3 (technical fluency with API docs and schemas), R4a (stakeholder management across engineering and customers). `adjacent`: R1 (3+ years of product management), R2 (shipped API or platform products), R6 (own the partner-facing API roadmap).
  - `important`: `adjacent`: R8 (launch coordination with sales and support). `unclear`: R4b (stakeholder management with sales), R5 (agile delivery), R7 (define and track adoption metrics).
  - R1, R2 and R6 are the three must-haves below `direct`. R5 and R7 are silent in your CV rather than weak in it.
- **Hard gates:** none stated; candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **Opportunity ledger:** The posting is coherent. It names a real mandate: one partner-facing platform, two squads, adoption metrics (OR-P1, positive). Open items are compensation, which is not stated (OR-U1), and whether roadmap calls are yours or shared with sales (OR-R2).
- **What would change this:** The `conditional_go` holds on two conditions. First, R1: the recruiter confirms implementation work counts toward the 3-year bar (OR-R3). Second, OR-R2: the role makes roadmap calls on its own. If the answer is that titled product management years are required, I would drop this to `no_go` for this posting. R1, R2 and R6 would then move from adjacent to absent.

**Role reality**
- Title and organization: Product Manager, Platform APIs, Quartzline (B2B logistics-tech, ~150 people, Series B). Taken from the posting you gave; not verified.
- Scope: owns the partner-facing API roadmap, runs partner discovery, leads two engineering squads, defines adoption metrics, coordinates launches [grounded, posting].
- Compensation: not stated [grounded, posting]. No market band: research has not run [generic].

**Evidence map**

| # | Requirement | Priority | Fit | Gap | Confidence | Basis |
|---|---|---|---|---|---|---|
| R1 | 3+ years product management | must_have | adjacent | transferability | medium | [grounded] 7 years of requirements docs, roadmap-input sessions, and implementation lead work. No product title. [inferred] that the bar is titled. |
| R2 | Shipped API or platform products | must_have | adjacent | transferability | medium | [grounded] 30+ integrations of your company's REST APIs. You delivered them; you did not own the API product. |
| R3 | Technical fluency (docs, schemas) | must_have | direct | none | medium | [grounded] Postman, SQL, OpenAPI. Self-reported. |
| R4a | Stakeholders: engineering, customers | must_have | direct | none | medium | [grounded] Coordinated vendor engineers, client engineers, and PMs. |
| R4b | Stakeholders: sales | important | unclear | discovery | low | Not in your CV. |
| R5 | Agile delivery | important | unclear | discovery | none | Not in your CV. |
| R6 | Own partner-facing API roadmap | must_have | adjacent | transferability | medium | [grounded] Quarterly roadmap-input sessions. Input, not ownership. |
| R7 | Define and track adoption metrics | important | unclear | discovery | low | Not in your CV. Possibly inferable from go-live counts; not stated. |
| R8 | Launch coordination with sales and support | important | adjacent | transferability | medium | [grounded] Go-live and UAT coordination with clients. Support not stated. |

**Gap recovery queue.** R1, R2 and R6 are transferability gaps: the limit is that the work was delivery and input, not ownership. R7 and R5 are discovery gaps: you may have the evidence, but the CV does not show it. Questions for these are in the closing block.

**Opportunity risk register**
- **OR-P1** (positive, [grounded] posting): named scope with two squads and adoption metrics reads as a real mandate.
- **OR-U1** (unknown): compensation withheld. Verification question: "What is the base range for this role, and how is it banded for product manager level?"
- **OR-R2** (risk signal, medium; [inferred] from scope language against silence on shared prioritization): "Own the roadmap" sits beside "coordinate launches with sales." Verification question: "Which prioritization decisions does this role make alone, and which need sales or engineering sign-off?"
- **OR-R3** (risk signal, medium; [generic] pattern, not a claim about this employer): screens for product management roles often filter on titled years. Verification question: "Would you weigh implementation and requirements work toward the 3-year requirement, and what would you need to see from me?"

**Application plan** (positioning advice, [inferred] from the evidence above)
- Lead with the integration lifecycle: scoping, requirements, architecture, UAT, go-live across 30+ integrations, plus the playbook. This is your most checkable proof.
- Name the missing title in your own words before the screen does. Don't leave the gap for the interviewer to find.
- Make your roadmap-input sessions your strongest product proof. Be ready to say what changed in the roadmap because of them.
- Any change to your resume wording is proposed language and needs your approval before use.

**Evidence status**

Research tier: L0 — no searches

| Target | Status | Reason |
|---|---|---|
| Company site and careers page | skipped | Research has not run; available at L1 on your consent |
| Role-family sweep (scope, title, pay) | skipped | Same |
| Hiring manager's public footprint | n/a | No name given |

I haven't checked that Quartzline exists as described or that the posting is live.

I can save this assessment as `tuesday-dossier.md` so a later mock-interview run can use it.

**What would sharpen this**
- Your constraints (location, schedule, pay floor, travel). These let the hard-gate checks run.
- The posted pay range, or confirmation that it is withheld.
- Consent to run L1 research: up to 5 searches and 2 page fetches. This checks that Quartzline is as described, that the posting is live, and what the market pays, which would also test the 3-year bar.
- Any artifact of product work: a roadmap, a spec, an adoption dashboard, or the integration playbook. These would raise R1, R2 and R6 from medium toward high.

**Questions**

R7 — Did you track adoption for anything you rolled out to clients: integrations live, time from scoping to go-live, which endpoints were used? If so, what did you measure, and who used the numbers?

G4 — From earlier context, not yet confirmed: did you build an internal request-triage tool that support agents adopted? If so, what was yours, who decided what it did, and what was adoption?

R6 — On custom builds, who decided priorities: you, the vendor's product managers, or the client? Give one example where your input changed what got built.

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.