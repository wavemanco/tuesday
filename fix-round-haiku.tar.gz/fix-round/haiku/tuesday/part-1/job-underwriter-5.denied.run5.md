**Yes, it's worth applying, on conditions.** Your stack matches the must-haves closely and the pay sits at market. Status: `conditional_go`.

**Fit ledger**

- `hard_gate`: unclear: R1 (Remote US or Denver office), R2 (base pay $148,000–$166,000)
- `must_have`: direct: R3, R4, R5, R6, R7, R8
- `important`: adjacent: R11 (BigQuery); unclear: R9 (ingestion from app and CRM), R10 (data contracts for analysts)
- `preferred`: adjacent: R12 (K-12 tutoring reporting)

- R9 and R10: your material doesn't show them. R11: Snowflake dbt work, not BigQuery. R1 and R2: your location and pay floor weren't given to me.

**Opportunity ledger.** Pay and scope read positive: RR4 (pay at market) and RR5 (concrete scope). RR1 (employer and live posting not verified), RR2 (hiring manager and team unnamed) and RR3 (equity unquantified) are unknowns, not red flags.

- **Hard gates:** none failed; unconfirmed: R1 (Remote US or Denver office), R2 (base pay $148,000–$166,000); candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) RR1: the role is open and the employer details hold up; (2) R1 and R2: your location and pay floor fit (a failed gate makes this `no_go`); (3) R9 and R10: your history includes ingestion and contracts work you can describe concretely; (4) R11 is framed as adjacent, never as BigQuery experience.

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Live online K-12 tutoring in 31 states; founded 2016; 264 employees; $52M Series C, Feb 2026 | `[grounded]` About page as you pasted it; not checked online |
| Mandate | Build and run ingestion from app and CRM, a dbt warehouse on BigQuery, and data contracts for analysts | `[grounded]` JD |
| Working pattern | Remote (US) or Denver office | `[grounded]` JD |
| Scope read | One domain (tutoring reporting) with no reports named, which is the usual senior scope | `[generic]` pay report's scope description, matched to the JD |
| Market calibration | Posted $148,000–$166,000 against a median of $151,000 and IQR of $139,000–$163,500. The range sits at market, its top just above the IQR. Your 6 years is inside the 5–8 year "senior" band. Pellucid's Series C is inside the report's Series B–D sample | `[generic]` role-family band; `[grounded]` posted range and report figures as you supplied them |
| Unknowns | Hiring manager, team size, equity grant and vesting, whether the role is open now, ingestion sources | — |
| Contradictions | None between the JD and the About page. The careers page was not checked | — |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | Your location wasn't given, so the gate isn't settled | `[grounded]` JD | G1 |
| R2 | Base pay $148,000–$166,000 | hard_gate | unclear | none | hard_gate | Your pay floor wasn't given | `[grounded]` JD | G1 |
| R3 | 5+ years data engineering | must_have | direct | medium | none | Six years at a B2B payroll company, self-reported; no artifact | `[grounded]` your intake | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | Daily use, self-reported | `[grounded]` your intake | none |
| R5 | dbt | must_have | direct | medium | none | About 180 models on Snowflake, self-reported | `[grounded]` your intake | offer: sanitized dbt overview |
| R6 | Cloud warehouse | must_have | direct | medium | none | Snowflake satisfies the literal requirement; BigQuery is R11 | `[grounded]` your intake | none |
| R7 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow, self-reported | `[grounded]` your intake | none |
| R8 | Data quality testing | must_have | direct | medium | none | You set up a Great Expectations suite, self-reported | `[grounded]` your intake | offer: suite summary |
| R9 | Ingestion from app and CRM | important | unclear | low | discovery | Nothing in your material covers product-database or CRM sources | `[grounded]` silence in your intake | G2 |
| R10 | Data contracts for analysts | important | unclear | low | discovery | Nothing in your material on contracts; the GE suite is adjacent | `[grounded]` silence in your intake | G2 |
| R11 | BigQuery (JD body: "warehouse in BigQuery") | important | adjacent | medium | transferability | Snowflake dbt and warehouse work carries over; no BigQuery use | `[inferred]` transfer from R5/R6; `[generic]` that BigQuery's cost model and partitioning differ from Snowflake's | G3 |
| R12 | K-12 tutoring reporting domain | preferred | adjacent | medium | transferability | B2B reporting pipelines carry over; no education domain | `[inferred]` from the JD's domain | none |

**Gap recovery queue**

| # | Gap (req) | Type | What I see | What would close it | Provenance |
|---|---|---|---|---|---|
| G1 | Gates (R1, R2) | hard_gate | Your location and pay floor aren't in the material | A yes or no on whether each gate is met | `[grounded]` intake silence |
| G2 | Ingestion and contracts (R9, R10) | discovery | Nothing on product or CRM ingestion, or on contracts with producers and consumers | Concrete examples: sources, scale, and any schema agreements | `[grounded]` intake silence |
| G3 | BigQuery (R11) | transferability | Snowflake dbt work; no BigQuery. Limit: no BigQuery-specific tuning or cost work | A small BigQuery project or sample, which narrows the limit | `[inferred]` bridge; `[generic]` that BigQuery's cost model differs |

**Opportunity risk register**

| # | Signal | Class | Severity | Hypothesis | Provenance | Verification question |
|---|---|---|---|---|---|---|
| RR1 | Employer and live posting not verified by search | unknown | — | The posting may be stale or copied; the employer details are unconfirmed | `[generic]` pattern for unverified postings, not a claim about this employer | Is this role open now on your careers page, and who would I interview with? |
| RR2 | Hiring manager and team unnamed | unknown | — | Team size and data ownership may differ from "build and run" | `[inferred]` from the JD's silence on team | Who would I work with day to day, and how many engineers own these pipelines? |
| RR3 | Equity unquantified | unknown | — | Equity value can't be judged without grant size and terms | `[inferred]` from "plus equity" with no figures | What are the grant size, vesting schedule, and strike price for this level? |
| RR4 | Stated pay at market | positive_signal | — | The posted range fits the report's band | `[grounded]` posted range against `[generic]` band | — |
| RR5 | Concrete scope and named stack | positive_signal | — | Scope is defined and measurable | `[grounded]` JD | Which of these pipelines are new, and which are being migrated? |

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Ask your recruiter whether the role is open, who the hiring manager is, whether it's US-remote or Denver-only, and the equity terms | RR1, RR2, RR3, R1, R2 | `[grounded]` register rows | pending your approval |
| A2 | Keep BigQuery framed as Snowflake dbt experience, not BigQuery experience | R11 | `[grounded]` intake and R11 row | pending your approval |
| A3 | If you go ahead, drill the ingestion and contracts questions with mock-interview | R9, R10 | `[grounded]` rows R9, R10 | pending your approval |

**Evidence status**

Verified: none yet. Every candidate claim here is your intake, self-reported.

Web search was refused in this session, so I could not check the company, the live posting or the pay report. The company facts come from the About page you pasted.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Refused. Would have checked that the posting is live and the About-page facts (RR1) |
| 2. Role-family sweep | unavailable | Refused. Would have checked the pay report's band (R2 calibration) |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

A dossier can be written up as `tuesday-dossier.md` to keep and reuse; say the word.

**Upgrade menu**

- Search access: lets the company page, posting, and pay report checks run, which settles RR1 and the calibration.
- A hiring manager's name: lets the public-footprint check run, and sets which verified story to lead with.
- A sanitized dbt overview (README or lineage screenshot): R5 to `high`.
- A Great Expectations suite summary: R8 to `high`.
- An example of ingestion from a product database or CRM: R9 moves.

**Questions**

G1 — Are you based in the US, and is a base salary of $148,000 above your floor? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

G2 — Have you built ingestion from a product database or a CRM, or set data contracts with the teams that produce or consume data? If so, what sources, what scale, and what agreements? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.