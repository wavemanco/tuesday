**Not a waste of your time. The core of this role matches your work. R10a, the 3+ years of titled PM experience, is the real obstacle. Status: `conditional_go`, meaning apply once the conditions below hold.**

**Fit ledger.**
- `must_have`: direct: R2, R6, R7a · adjacent: R1, R3, R5 · unclear: R4, R8 · absent: R7b, R10a
- `important`: adjacent: R9

R2, R6 and R7a are where you are strongest. R1, R3 and R5 are real product-side work that the CV presents as implementation. R10a is the titled-years line. R4 and R8 are not in the CV at all, so they are open questions, not gaps you have confirmed.

**Opportunity ledger.** The scope is concrete and measurable (RR4 is positive). Three entries stay open: the employer is unverified (RR1), the titled-years line may be read literally (RR2), and decision rights are unstated (RR3).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **Conditions for go:** (1) the recruiter says whether product-scope work counts toward the three years (RR2, R10a); (2) the posting is confirmed live on Quartzline's own careers page (RR1); (3) your answers to Q1 and Q2 show agile delivery and metric-tracking in your history (R8, R4). If both of those come back no, this becomes a stretch application.

**Research tier: L1 — searches 3 of 5, fetches 0 of 2**

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline, B2B logistics technology, ~150 people, Series B | `[grounded]` your statement; not checked |
| Mandate | Own the partner-facing API platform roadmap, discovery, specs, two engineering squads, adoption metrics, launches | `[grounded]` JD |
| Scope read | A full product remit across discovery, delivery and measurement | `[inferred]` from the responsibility list |
| Market calibration | Not run: search was refused, so there is no market band or titled-years norm | — |
| Unknowns | Salary, location, contract type, decision rights (RR3), whether a PM team sits around this role | — |
| Contradictions | None found in what was provided | `[grounded]` |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Own the roadmap for the partner-facing API platform | must_have | adjacent | medium | transferability | Ran quarterly roadmap-input sessions for product. That is input into the roadmap, not ownership of it | `[grounded]` CV | G1 |
| R2 | Run discovery with integration partners | must_have | direct | medium | none | Scoping workshops with client integrators are discovery in substance, under a different name | `[grounded]` CV | none |
| R3 | Write specs and drive delivery with two engineering squads | must_have | adjacent | medium | transferability | Requirements documents and coordinating engineers on custom builds. No squad-level delivery shown | `[grounded]` CV | G2 |
| R4 | Define and track adoption metrics | must_have | unclear | low | discovery | No metric work in the CV. SQL is a tool, not a measure | `[grounded]` CV silence | Q2 |
| R5 | Shipped API or platform products | must_have | adjacent | medium | transferability | Shipped client-side REST integrations, not a product you owned after launch | `[grounded]` CV | G3 |
| R6 | Strong technical fluency: API docs, schemas | must_have | direct | medium | none | Postman, SQL and OpenAPI are named. "Comfortable" is self-report | `[grounded]` CV | none |
| R7a | Stakeholder management: engineering and customers | must_have | direct | medium | none | Coordinated your engineers, client engineers and PMs on custom builds | `[grounded]` CV | none |
| R7b | Stakeholder management: sales | must_have | absent | none | discovery | No sales-side work in the CV | `[grounded]` CV silence | G8 |
| R8 | Agile delivery experience | must_have | unclear | low | discovery | Not in the CV, and the JD asks for it | `[grounded]` CV silence | Q1 |
| R9 | Coordinate launches with sales and support | important | adjacent | medium | transferability | Go-live coordination with clients. No sales or support launch work shown | `[grounded]` CV | G6 |
| R10a | Three or more years as a titled PM | must_have | absent | none | transferability | No PM title. This is a length-of-experience requirement, not a gate, so the adjacent work (R1, R3, R5) is graded rather than cut | `[grounded]` CV | G7 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Roadmap ownership (R1) | transferability | Roadmap input, not roadmap decisions | Owning the roadmap is the first line of the JD | A prioritization call where your input changed what got built | A roadmap or priority doc you helped set | `[inferred]` bridge from the roadmap-input bullet |
| G2 | Squad delivery (R3) | transferability | Requirements documents and cross-team coordination | Specs plus delivery to two squads is the core job | A spec engineers built from, with acceptance criteria | The spec, sanitized | `[inferred]` bridge from the CV's requirements bullets |
| G3 | Product after launch (R5) | transferability | Client integrations shipped, with no post-launch ownership shown | Shipping an API product is a must-have | The integration architecture or playbook you maintained | The playbook's structure, sanitized | `[inferred]` bridge from the playbook and integration bullets |
| G6 | Sales and support launches (R9) | transferability | Client go-live coordination | Launch coordination is in the JD | A launch checklist you ran with support | The checklist, sanitized | `[inferred]` bridge from the go-live bullet |
| G7 | Titled years (R10a) | transferability | No PM title; seven years of adjacent work | A recruiter may screen on the literal line | The recruiter's answer on whether product scope counts | The recruiter's reply | `[grounded]` CV; the bridge is the taxonomy's rule |
| G8 | Sales-side stakeholders (R7b) | discovery | Nothing shown on sales | Sales is named in the must-have | Any account, pricing or deal-support work with sales | None needed to close | `[grounded]` CV silence |

R4 and R8 have their questions in the closing block, not in this queue. The queue says what would close each gap; the questions come below.

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established (standing) | risk_signal | medium | "Own the roadmap for our partner-facing API platform" | Nothing could be attributed either way, because web search was refused. This is not a finding that the company is absent | `[generic]` pattern for companies of this size, not a claim about this one | Which team and manager is this role on, and is the posting live on your careers page? | unresolved |
| RR2 | Titled-years requirement may be read literally | risk_signal | medium | "3+ years product management experience (must-have)" | The posting's own words may be screened literally, so adjacent work may not count | `[generic]` pattern for titled-years must-haves at product roles | Would product-scope ownership from a solutions or implementation role count toward the three years? | unresolved |
| RR3 | Decision rights not stated | unknown | — | "Own the roadmap … drive delivery with two engineering squads" | The role may be accountable for delivery without deciding scope | `[inferred]` from the ownership language against silence on decision rights | Which roadmap decisions does this role make alone, and which go to the squads or leadership? | unresolved |
| RR4 | Scope is specified | positive_signal | — | "define and track adoption metrics"; "coordinate launches with sales and support" | Concrete, measurable responsibilities are a positive sign for an accountable role | `[inferred]` from the JD's listed responsibilities | What adoption number would make this role a success in its first year? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Summary line: "Seven years leading end-to-end client integrations of REST APIs: scoping workshops, requirements documents, integration architecture, UAT and go-live." | Leads with R2 and R6, which the CV already supports | `[grounded]` CV bullets. Audit: every clause traces to your CV; "partner-facing" from the JD is deliberately not borrowed | `resume_edits_pending_approval` |
| P2 | Keep the roadmap bullet as written: "Ran quarterly roadmap-input sessions collecting client feedback for product." | Do not upgrade it to ownership unless Q3 says so | `[grounded]` CV | no edit proposed; pending your approval |
| P3 | Interview framing for R1 and RR3: "My role has been bringing client needs to product and leading the integrations that came out of them. I'd want to understand how roadmap decisions get made here." | Frames the gap honestly and asks the RR3 question in the room | `[grounded]` CV. Audit: no clause claims ownership you have not stated | pending your approval |
| P4 | Ask the recruiter the RR2 question before investing in the loop | Settles the titled-years line early | `[grounded]` RR2 | pending your approval |
| P5 | Confirm the posting is live on Quartzline's careers page | Closes RR1 | `[grounded]` RR1 | pending your approval |

## Evidence status

Verified: none yet. Everything above rests on your CV, which is self-report at intake. Unverified lead: a prior-context note about a request-triage tool that support agents adopted. It is unconfirmed, so it is not in the map; it is raised as Q3.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches were sent ("Quartzline logistics technology company Series B" and "Quartzline careers Product Manager Platform APIs"). Web search was refused by this session's permission setting. It would have checked RR1 and the posting's consistency |
| 2. Role-family sweep | unavailable | One search was sent ("product manager platform APIs job requirements 3+ years product management integration partners role profile"). It was refused. It would have set the market calibration and the titled-years norm behind RR2 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

## Dossier offer

If you want this as a file, I can write it out as `tuesday-dossier.md`, which mock-interview can read later.

## Upgrade menu

- Your answers to Q1–Q3 → R4, R8, R1 and RR3 move. The decision could move to `go` or `hold_pending_answers`.
- A sanitized spec, requirements doc or integration playbook section you wrote → R3 from `medium` to `high`.
- The live posting or the careers page, pasted → RR1 closes.
- Permission to run web search (up to 5 searches and 2 fetches) → checks Quartzline itself and calibrates whether "3+ years" is read literally at this stage. The calibration would be `[generic]`.

## Questions

**Q1 (R8):** Have you worked inside an agile delivery loop with an engineering team, such as sprints, a backlog you prioritized, or standups you ran? If so, what was your part?

**Q2 (R4):** Have you defined how success was measured for an integration, a rollout or a playbook, such as go-live time, error rates or client adoption? Who tracked it?

**Q3 (R1, RR3):** Have you ever owned a product decision, meaning deciding what got built or prioritized rather than only collecting input? A prior note mentions a request-triage tool that support agents adopted. I have not counted it. Did you specify it, and who decided its scope?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.