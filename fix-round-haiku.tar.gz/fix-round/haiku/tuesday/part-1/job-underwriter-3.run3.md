## Decision snapshot

**No, not as posted: R1 and R2, both hard gates, fail · `no_go`.**

**Fit ledger.**

- `hard_gate`: failed: R1 (On-site in Austin, 5 days a week); R2 (Base pay $70–85k)
- `must_have`: direct: R3 (8+ years growth leadership); R4 (Paid acquisition); R6 (Lifecycle/CRM)
- `important`: adjacent: R9 (E-commerce enablement context); unclear: R5 (SEO/content), R7 (Brand, PR, partnerships), R8 (Sales ops)

R1 and R2 fail your two constraints. R3, R4 and R6 meet the must-haves. R9 is a bridge with a limit. R5, R7 and R8 have no evidence in what you gave me.

**Opportunity ledger.** Scope is bundled onto a team of one (RR2), hours are open-ended (RR3), and success is undefined (RR4). The posting's own terms are the severe flag (RR1). The employer is unverified (RR5). Stated Series A and profitability are positive if true (RR6).

- **Hard gates:** failed: R1 (On-site in Austin, 5 days a week), R2 (Base pay $70–85k).
- **Severe red flags:** RR1 (`severity: high`).
- **What would change this:** the status changes only if the facts behind R1 and R2 are different. R1 needs a remote version of the role, and R2 needs a base at or above $150k.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Novaline, e-commerce enablement, Series A, "profitable since day one" | `[grounded]` posting's own claim; not verified |
| Mandate | All revenue growth: paid, SEO/content, lifecycle/CRM, brand, PR, partnerships, sales ops | `[grounded]` posting |
| Team and reporting | Team of one to start; reports to CEO, dotted line to board | `[grounded]` posting |
| Working pattern | On-site Austin 5 days a week, "no exceptions"; evenings and weekends "when it matters" | `[grounded]` posting |
| Pay | $70–85k base plus equity; equity terms not given | `[grounded]` posting |
| Market calibration | Not run. The salary search was refused, so I state no band. | none |
| Unknowns | Equity terms; success metrics; which disciplines get budget or headcount | none |
| Tension | Title, reporting line and "8+ years required" against a $70–85k base and a team of one | `[inferred]` from the posting's own terms |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | On-site Austin, 5 days a week | hard_gate | hard_gate_fail | high | hard_gate | Your constraint is remote-only and not relocating; posting says "no exceptions" | `[grounded]` posting and your stated constraint | none; only changed posted terms resolve it |
| R2 | Base pay $70–85k | hard_gate | hard_gate_fail | high | hard_gate | Top of range is $65k below your $150k floor | `[grounded]` posting and your stated floor | none; only changed posted terms resolve it |
| R3 | 8+ years growth leadership | must_have | direct | medium | none | 9 years; growth lead then head at two B2C subscription companies; no artifact inspected | `[grounded]` your statement | none |
| R4 | Paid acquisition | must_have | direct | medium | none | Owned paid at both companies | `[grounded]` your statement | none |
| R6 | Lifecycle/CRM | must_have | direct | medium | none | Owned lifecycle; works in Braze | `[grounded]` your statement | none |
| R9 | E-commerce enablement (merchant-facing) | important | adjacent | medium | transferability | B2C subscription growth carries over; merchant-facing enablement is not in your history | `[inferred]` from the posting's description and your history | name the limit if pursued |
| R5 | SEO/content | important | unclear | none | discovery | Not in your statement | `[grounded]` silence | ask whether you have owned it (not asked this turn) |
| R7 | Brand, PR, partnerships | important | unclear | none | discovery | Not in your statement | `[grounded]` silence | ask whether you have owned it (not asked this turn) |
| R8 | Sales ops | important | unclear | none | discovery | Not in your statement | `[grounded]` silence | ask whether you have owned it (not asked this turn) |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | SEO/content, brand, PR, partnerships, sales ops (R5, R7, R8) | discovery | Nothing in your statement covers these | Would matter only if the gates were met | Any SEO, editorial, PR or partner work you ran or shared | Campaign or program summaries | `[grounded]` silence |

No recovery question is asked this turn, since R1 and R2 are settled by your own constraints.

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Location and pay conflict with your constraints (see R1, R2) | red_flag | high | "On-site in our Austin office 5 days a week — no exceptions." | The role cannot be done on your terms as published | `[grounded]` posting against your constraints | Is there any remote version of this role, and a base of at least $150k? If not, what is the on-site requirement based on? | unresolved |
| RR2 | Seven disciplines on a team of one | risk_signal | medium | "Own all revenue growth end to end: paid acquisition, SEO/content, lifecycle/CRM, brand, PR, partnerships, and sales ops… team of one to start" | Scope may exceed one person; the title may cover several roles | `[inferred]` from the posting's list against its team-of-one line; `[generic]` that bundled scope like this is a common pattern | Which of these get budget and headcount in year one, and which would I be expected to hand off or stop? | unresolved |
| RR3 | Always-on expectation | risk_signal | medium | "evenings and weekends when it matters is just who we are" | Hours beyond the stated schedule are expected | `[grounded]` quote; `[generic]` that open-ended "when it matters" periods are a common pattern | How often has a "when it matters" period happened in the last year, and how is that time recognized? | unresolved |
| RR4 | Success metrics undefined | risk_signal | medium | "success metrics will evolve as we learn" | Accountability without a fixed definition of success | `[inferred]` from the posting's own wording | What three numbers define success at six and twelve months, and who signs off on them? | unresolved |
| RR5 | Employer unverified | unknown | — | "Novaline (e-commerce enablement startup, Series A, profitable since day one)" | Nothing attributable confirms the company or the posting; research did not run | `[generic]` pattern for companies of this size; no claim about this one | Can you point me at the live posting on Novaline's own careers site, and who would I be interviewing with? | unresolved |
| RR6 | Stated stage and profitability | positive_signal | — | "Series A, profitable since day one" | If accurate, runway is less of a risk | `[grounded]` employer's own claim, unverified | What revenue and runway figures sit behind "profitable since day one"? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Do not submit on the posted terms | R1 and R2 fail | `[grounded]` R1, R2 | pending your approval |
| P2 | If you want to test it, put RR1's question to the recruiter before any application effort | Only a changed term could move the status | `[grounded]` RR1 | pending your approval |

## Evidence status

Verified: R1 and R2 (your own constraints, `high`); R3, R4 and R6 (your statements, `medium`, no artifact inspected). Unverified leads: none. Rejected inferences: none.

Research tier: L1 — searches 3 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches for Novaline and its careers page were refused, so nothing came back. Would have checked whether the company exists as described and whether the posting is live (RR5). |
| 2. Role-family sweep | unavailable | One search for Head of Growth pay at Series A was refused. Would have set the market calibration line. |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form. |

## Dossier offer

If you want it, I can write this up as `tuesday-dossier.md`, so the verification questions travel with you into any later talk with Novaline.

## Upgrade menu

- Permission for web search: targets 1 and 2 would run (up to 5 searches and 2 fetches at L1). That would verify the employer (RR5) and set a market pay band. It cannot clear R1 or R2, because those are the posting's own terms.
- The live posting link: shows the terms as published on the careers page. It could differ from the terms in the email you received.

## Questions

None this turn. Your constraints already settle both gates, so no answer would change the status.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.