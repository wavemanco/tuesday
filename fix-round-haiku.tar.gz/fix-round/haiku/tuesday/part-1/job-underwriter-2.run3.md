**Short answer: you're not wasting your time, but expect a title screen.** The must-have "3+ years product management" is literal, and your CV has no PM title. Your substance maps well onto most of the rest. I'd apply on conditions, not as a sure thing.

**Research note:** Web search was refused in this session, so I couldn't verify Quartzline or check market pay for this title. Those checks are still open (see Evidence status).

## Decision snapshot

Worth applying to, on conditions. Status: `conditional_go`.

**Fit ledger.**
- `must_have`: direct: R3, R4 · adjacent: R1 (3+ years PM experience), R2 (shipped API or platform products) · unclear: R5 (agile delivery)
- `important`: direct: R7, R10 · adjacent: R6 (discovery with integration partners), R8 (drive delivery with two squads) · unclear: R9 (adoption metrics)

R1 and R2 are the two literal must-have bars, and both are adjacent, not direct. R3 and R4 are direct. R5 is unclear and a question you can answer.

**Opportunity ledger.** The role is well defined: partner-facing platform, two squads, named adoption metrics (RR3). Two things are unknown: the employer is unverified (RR1), and pay and decision rights are not stated (RR2, RR4).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **Conditions for go:** (1) Quartzline is confirmed as a real employer with a live posting before you spend application effort (RR1); (2) you can name a specific decision you made about what got built and in what order, in any role (G1); (3) the bridge is framed as adjacent, never as PM experience you don't have (R1, R2).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline, B2B logistics tech, ~150 people, Series B | `[grounded]` the JD you pasted |
| Mandate | Own the partner-facing API platform roadmap; lead two engineering squads; define adoption metrics | `[grounded]` JD |
| Scope read | Coherent for a platform PM; ownership is stated, decision rights are not | `[inferred]` from the JD's scope language |
| Market calibration | Not run: pay for this title and seniority is not checked | — (search refused) |
| Unknowns | Pay, reporting line, whether sales requests set roadmap order | — |
| Contradictions | None found in the text you pasted; no careers page checked | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 3+ years product management | must_have | adjacent | medium | transferability | Seven years of requirements, scoping and roadmap-input work, with no PM title or PM-owned roadmap on the CV. Limit: you were not the one deciding the roadmap. | `[grounded]` CV; `[inferred]` adjacency | G1 |
| R2 | Shipped API or platform products | must_have | adjacent | medium | transferability | Led 30+ REST integrations end to end and wrote the playbook. Limit: you implemented the platform, you did not ship it. | `[grounded]` CV; `[inferred]` | G2 |
| R3 | Technical fluency: API docs, schemas | must_have | direct | medium | none | Integration architecture, OpenAPI, Postman, SQL on the CV. Self-reported, no artifact. | `[grounded]` CV | none |
| R4 | Stakeholder management: engineering, sales, customers | must_have | direct | medium | none | Coordinated your engineers, client engineers and PMs on custom builds. | `[grounded]` CV | none |
| R5 | Agile delivery | must_have | unclear | low | discovery | CV does not name a delivery method or cadence. | `[grounded]` CV silence | G3 |
| R6 | Discovery with integration partners | important | adjacent | medium | transferability | Scoping workshops and quarterly client feedback sessions. Limit: that was implementation discovery, not product discovery. | `[grounded]` CV; `[inferred]` | G4 |
| R7 | Specs and requirements | important | direct | medium | none | Requirements documents and integration architecture on the CV. | `[grounded]` CV | none |
| R8 | Drive delivery with two engineering squads | important | adjacent | medium | transferability | Coordinated engineers on builds; no squad backlog ownership on the CV. | `[grounded]` CV; `[inferred]` | G5 |
| R9 | Define and track adoption metrics | important | unclear | low | discovery | CV has go-live and UAT milestones, but no adoption metric. | `[grounded]` CV silence | G6 |
| R10 | Launch coordination with sales and support | important | direct | medium | none | Go-live and UAT coordination on the CV. | `[grounded]` CV | none |

## Gap recovery queue

| # | Gap (req) | Type | What I see | What would close it | Provenance |
|---|---|---|---|---|---|
| G1 | PM experience (R1) | transferability | Roadmap-input work, but no decision you made about sequencing | A specific prioritization decision you owned, with who signed off | `[grounded]` CV |
| G2 | Shipped products (R2) | transferability | Platform implementation, not product release | Evidence you owned a release: the request-triage tool, if it's real | `[grounded]` CV; memory lead, unverified |
| G3 | Agile delivery (R5) | discovery | No method named | The cadence and ceremonies you ran | `[grounded]` CV silence |
| G4 | Partner discovery (R6) | transferability | Discovery in implementation form | A product-discovery example: a feature you scoped from partner input | `[inferred]` |
| G5 | Two squads (R8) | transferability | Coordination without backlog ownership | Who prioritized the work for the teams you coordinated | `[inferred]` |
| G6 | Adoption metrics (R9) | discovery | None on the CV | Any integration metric you tracked: time to go-live, active partners, error rates | `[grounded]` CV silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established | risk_signal | medium | "Quartzline (B2B logistics-tech, ~150 people, Series B)" | The employer may be real and small. This is unverified, not negative. | `[generic]` pattern for companies of this size, not a claim about this one | Where is this role on your careers site, and who would I interview with? | unresolved |
| RR2 | Pay and reporting line not stated | unknown | — | (not in the pasted JD) | Pay may sit below the PM band, or simply be withheld. | `[inferred]` from the posting's silence | What is the base range for this role, and who does it report to? | unresolved |
| RR3 | Scope and metrics defined | positive_signal | — | "Own the roadmap for our partner-facing API platform" | Ownership is explicit, which is rarer than it sounds. | `[grounded]` JD | Which roadmap decisions does this role make alone? | noted |
| RR4 | Sales-driven roadmap risk | risk_signal | medium | "coordinate launches with sales and support" | The role may be accountable for the roadmap while sales requests set its order. | `[generic]` pattern for B2B platform PM roles | When sales asks for a partner-specific feature, who decides its place in the sequence? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Ask the recruiter whether this is a PM role with roadmap decision rights, and at what level | RR2, RR4 | `[grounded]` register | pending your approval |
| A2 | Keep the resume free of PM titles and "owned the roadmap" language; lead with roadmap-input sessions and the playbook | R1; the reframing audit rules out PM-ownership claims you can't back | `[grounded]` CV | pending your approval |
| A3 | Verify Quartzline's posting before applying | RR1 | `[generic]` | pending your approval |
| A4 | Consider parallel applications to integrations or technical PM roles, where your implementation background counts more directly | R1 is the screen risk | `[generic]` role-family pattern | pending your approval |

## Evidence status

Verified: none yet. Every claim so far is from your CV or the JD. Unverified lead: the request-triage tool from a prior conversation. It is a memory lead, not evidence, and it only prompts G2.

Research tier: L1 — searches 3 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Refused: web search was not permitted. Would have settled RR1 and checked the posting is live. |
| 2. Role-family sweep | unavailable | Refused: same. Would have set the market band for R1 and RR2. |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form. |

## Upgrade menu

- Permission to run web search → confirms Quartzline (RR1) and the market pay band (RR2)
- The live posting link → confirms the role is open and matches the JD
- Answers to G1–G3 → R1, R2, R5 and R9 move, and the decision may firm up
- A pay figure → RR2 closes, and the figure is set against the band
- The hiring manager's name → positioning for that reader; I'd only use public professional information

If you want, I can write this up as a `tuesday-dossier.md` you can keep and reuse.

## Questions

G1 (R1): Have you ever owned prioritization for a product, platform, or integration program, deciding what got built and in what order, even informally? If yes, what was it, for how long, and who signed off?

G2 (R2): Did you build the internal request-triage tool that support agents adopted? What did you own, what changed, and how did you know it worked?

G3 (R5, R9): How did you run delivery with engineering (cadence, backlog, ceremonies), and did you define or track any adoption metric for the integrations you led?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.