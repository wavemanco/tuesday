**Yes, worth applying, with two things to check first.** Your location against "Remote (US) or Denver" (R1), and your base-pay floor against $148,000 (R2), are not in what you gave me. Status: `conditional_go`.

**Fit ledger**
- `hard_gate`: unclear: R1 (remote-US or Denver location), R2 (base-pay floor)
- `must_have`: direct: R3 (5+ years data engineering), R4 (strong SQL and Python), R5 (dbt and a cloud warehouse), R7 (Airflow or similar orchestration), R8 (data quality testing)
- `important`: adjacent: R6 (BigQuery warehouse)

R3, R4, R5, R7 and R8 read `direct` at `medium`, because they rest on your statement with nothing inspected yet. R6 is the one `adjacent` row: Snowflake and dbt carry over, but you have not used BigQuery. R1 and R2 are the two gates, and neither is answered yet.

**Opportunity ledger.** The employer checks out on its own careers page. RR1 (team and ownership unstated), RR2 (the Series C is the company's own claim, not yet independently checked), RR3 (no hiring manager named) and RR4 (equity unquantified) are open. No register entry is a red flag.

- **Hard gates:** none failed; unconfirmed: R1 (remote-US or Denver location), R2 (base-pay floor); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **What would change this:** if R1 and R2 both check out, the status moves to `go`. If either fails, it becomes `no_go` with that gate as the reason. BigQuery being required on day one would not change the status, but it would need an honest answer in the interview.

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Live online tutoring for K-12 schools in 31 states; founded 2016, Denver; 264 employees | `[grounded]` company About page; Series C is self-reported only |
| Mandate | Build and run ingestion, a dbt-modelled BigQuery warehouse, and data contracts | `[grounded]` posting, fetched |
| Scope read | Senior individual-contributor ownership of pipelines; no direct reports mentioned | `[inferred]` from the posting's silence on reports; `[generic]` typical scope for the title |
| Market calibration | Quoted Datawright report: base median $151k, IQR $139k–$163.5k. The posted $148k–$166k straddles the median and runs past the top of the IQR | `[generic]` role-family band from the quoted report, not this employer's offer; `[grounded]` posted range |
| Unknowns | Team size and who else owns the pipelines; equity; hiring manager; BigQuery requirement; your location and pay floor | — |
| Contradictions | None between the posting you pasted and the live careers page | `[grounded]` fetched page |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | Your location is not in the material, so the gate is not settled | `[grounded]` posting | Closing question 1 |
| R2 | Base pay $148k–$166k against your floor | hard_gate | unclear | none | hard_gate | No floor given | `[grounded]` posting | Closing question 1 |
| R3 | 5+ years data engineering | must_have | direct | medium | none | Six years at a B2B payroll company; years are graded on fit, not as a gate | `[grounded]` your intake statement | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | Daily use stated; no artifact yet | `[grounded]` your intake statement | none |
| R5 | dbt and a cloud warehouse | must_have | direct | medium | none | About 180 dbt models on Snowflake; Snowflake is a cloud warehouse | `[grounded]` your intake statement | none |
| R6 | BigQuery warehouse (named in the work, not in the requirement list) | important | adjacent | medium | transferability | Snowflake and dbt carry over; no BigQuery experience | `[inferred]` posting's named stack against its requirement list | G1 |
| R7 | Airflow or similar orchestration | must_have | direct | medium | none | Airflow used for orchestration | `[grounded]` your intake statement | none |
| R8 | Data quality testing | must_have | direct | medium | none | Set up a Great Expectations suite; not yet inspected | `[grounded]` your intake statement | none |

**Gap recovery queue**

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery warehouse (R6, important) | transferability | Snowflake and dbt work; no BigQuery | The posting names BigQuery in the work, so it is the likeliest interview objection. Limit: no BigQuery SQL dialect, cost model or access-control experience | Any cross-platform warehouse move, Snowflake cost or clustering decisions you made | A sanitized model, or the recruiter's stack note | `[inferred]` bridge from your stack; `[generic]` that this is the likeliest objection |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Team and ownership not stated | unknown | — | "Build and run the pipelines" | You may be the only owner of the pipelines and warehouse | `[inferred]` from posting silence on team | Who else owns the pipelines and warehouse today, and how is on-call handled? | unresolved |
| RR2 | Series C is the company's own claim | unknown | — | "Series C ($52M, February 2026)" | Company statement; one search returned only its own page | `[grounded]` company About page; `[generic]` pattern for companies of this age | Who led the round, and how is this role funded in the current plan? | unresolved |
| RR3 | Hiring manager not named | unknown | — | (none named) | Hiring manager unknown; affects who you would work with | `[grounded]` posting | Who is the hiring manager, and who would I work with most closely? | unresolved |
| RR4 | Equity unquantified | unknown | — | "plus equity" | Value cannot be assessed | `[grounded]` posting | What is the grant size, vesting schedule and valuation basis? | unresolved |

**Application plan** (every row proposed, none applied)

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Lead with Snowflake, dbt, Airflow and Great Expectations | Matches the requirement list | `[grounded]` your intake | pending your approval |
| P2 | Say plainly you have not used BigQuery; do not claim it | R6 | `[grounded]` your intake | pending your approval |
| P3 | Proposed line: "I built a dbt project of about 180 models on Snowflake, orchestrated it with Airflow, and set up a Great Expectations test suite." Every clause traces to your sentences | Reframing audit | `[grounded]` your intake | pending your approval |
| P4 | Ask the recruiter about BigQuery, team, and equity before applying | G1, RR1, RR4 | `[grounded]` register | pending your approval |

**Evidence status.** Verified: none yet. Your intake is the stated background, which is capped at `medium` until probed. Rejected inferences: none. The standing "employer not established" check is resolved: the posting is live and the About page matches what you pasted.

**Research tier:** L1 — searches 1 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Fetched pellucidlearning.com/careers/senior-data-engineer: posting live ("Accepting applications") and matches your paste. Searched "Pellucid Learning live online tutoring K-12 Denver Series C": the only result was pellucidlearning.com/about, matching the pasted facts. Moved the entity check and the live-posting check. The Series C figure is still self-reported |
| 2. Role-family sweep | skipped | Market calibration and the pay check use the Datawright figures as you quoted them from the recruiter's report, so no search was needed. The report itself is not in hand |
| 3. Hiring manager's public footprint | n/a | No name was given |

**Dossier offer.** I can write this up as a `tuesday-dossier.md` if you want it kept.

**Upgrade menu**
- Your location and pay floor → R1 and R2 close, and the status moves to `go` or `no_go`.
- The recruiter's answer on BigQuery → R6 and G1 firm up.
- An inspectable artifact, such as a sanitized dbt model or the Great Expectations suite's README → R3 to R8 move from `medium` toward `high`.
- Answers on team and equity → RR1 and RR4 close.
- A deeper pass on Pellucid (funding, leadership changes, public employee reports, up to 5 more searches and 2 more fetches). Say the word and it runs.

**Questions**
1. R1, R2: Are you authorized to work in the US, and can you work remote or from Denver? What is your base-salary floor?
2. G1: Did the recruiter say whether BigQuery is required on day one, or is it the stack you would be expected to learn?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.