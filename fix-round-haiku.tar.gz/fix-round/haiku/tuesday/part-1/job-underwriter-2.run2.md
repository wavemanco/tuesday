**Worth applying to, with a real caveat on the title. Status: `conditional_go`.** You aren't wasting your time, but the apply case depends on a product-ownership story you haven't told yet. The must-have "3+ years of product management" is the one requirement with no titled evidence on your resume.

**Fit ledger.**

- `must_have`: absent: R1a (titled product-management years), R10 (define and track adoption metrics) · adjacent: R1b (product-adjacent work), R2 (shipped API or platform products), R6 (own the platform roadmap), R7 (discovery with integration partners)
- `important`: direct: R3 (API docs and schemas), R4a (engineering and customer stakeholders), R8 (writing specs) · adjacent: R9 (delivery with two squads), R11 (launch coordination) · unclear: R5 (agile delivery) · absent: R4b (sales stakeholders)

The weakest rows are R1a and R10. The bridge rows R2, R6 and R7 each carry a stated limit.

**Opportunity ledger.** Two unknowns: RR1 (whether this role has decision rights over the roadmap) and RR2 (pay, level and contract basis, none of which the posting gives). RR3 is a positive signal: two named engineering squads and a defined platform scope. RR4 (undefined adoption success) is also an unknown.

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) you can name a product decision you owned or shaped, with its outcome (R1b, R6, R7); (2) you can answer how adoption was measured for anything you built (R10); (3) RR2 comes back consistent with your constraints.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline, B2B logistics-tech, about 150 people, Series B | `[grounded]` the JD as you pasted it |
| Mandate | Own the roadmap for a partner-facing API platform; drive delivery with two engineering squads | `[grounded]` JD |
| Scope read | A platform owner role with a named team of two squads; the squad count is a resource signal, not a guarantee of authority | `[inferred]` from the squad count and the roadmap language |
| Market calibration | Not established. Every search was refused, so there is no pay or title band. Model memory is not a source for these | — |
| Unknowns | Roadmap decision rights; pay, level, contract basis; who owns adoption data; whether a PM team already exists | — |
| Contradictions | None visible in the text you provided. Only one source was available, so nothing was cross-checked | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1a | Titled product-management years | must_have | absent | none | discovery | No PM title in seven years on the CV. A PM-type duty could sit inside another title, so this is not yet capability | `[grounded]` CV titles | G1 |
| R1b | Product-adjacent work | must_have | adjacent | medium | transferability | Ran quarterly roadmap-input sessions and wrote requirements documents. Limit: the CV shows input gathering for product, not setting priorities or owning outcomes | `[grounded]` CV; `[inferred]` that this is PM-adjacent | G1 |
| R2 | Shipped API or platform products | must_have | adjacent | medium | transferability | Led 30+ integrations of the vendor's REST APIs from the consumer side. Limit: no evidence of owning an API product's design, versioning or developer experience | `[grounded]` CV; `[inferred]` consumer-side work as adjacent | G3 |
| R3 | API docs and schemas | important | direct | medium | presentation | Postman, SQL and OpenAPI reading are on the CV. Schema discussion itself is not named | `[grounded]` CV | E1, only if true |
| R4a | Stakeholders: engineering and customers | important | direct | medium | none | Coordinated your engineers, client engineers and PMs on custom builds; ran client feedback sessions | `[grounded]` CV | none |
| R4b | Stakeholders: sales | important | absent | none | discovery | The CV does not mention sales | `[grounded]` CV silence | G6 |
| R5 | Agile delivery | important | unclear | none | discovery | No frameworks, sprints or ceremonies named. "Delivery" appears only as go-live | `[grounded]` CV silence | G5 |
| R6 | Own the platform roadmap | must_have | adjacent | medium | transferability | Input gathering, not ownership. Limit: the CV does not show you set or defended priorities | `[grounded]` CV | G4 |
| R7 | Discovery with integration partners | must_have | adjacent | medium | transferability | Scoping workshops and requirements with clients for individual integrations. Limit: this is requirement discovery for one client's build, not product discovery to decide what to build | `[grounded]` CV | write up one example |
| R8 | Write specs | important | direct | medium | presentation | Wrote requirements documents and integration architecture for client integrations. The CV's wording is the vendor's, and the evidence is CV-only | `[grounded]` CV | E1 |
| R9 | Drive delivery with two engineering squads | important | adjacent | medium | transferability | Coordinated engineers across vendor and client on custom builds. Not standing squad delivery | `[grounded]` CV | G5 |
| R10 | Define and track adoption metrics | must_have | absent | none | discovery | Nothing on the CV about measuring adoption. An unconfirmed note from an earlier conversation points at a tool support adopted. That is a question, not evidence | `[grounded]` CV silence; the earlier note is a `memory_lead` | G2 |
| R11 | Launch coordination with sales and support | important | adjacent | medium | transferability | Ran UAT and go-live with clients. Sales and support are not named | `[grounded]` CV | none beyond R4b |

## Gap recovery queue

| # | Gap (req) | Type | What I see | What would close it | Provenance |
|---|---|---|---|---|---|
| G1 | Titled PM years, product-adjacent work (R1a, R1b) | discovery, then transferability | No titled PM years; adjacent work exists | One product decision you owned or shaped, with its outcome | `[grounded]` CV |
| G2 | Adoption metrics (R10) | discovery | Nothing measured on the CV | One thing you built where adoption was measured, and how | `[grounded]` CV silence |
| G3 | Shipped API or platform products (R2) | transferability | Consumer-side integration work only | A spec, changelog or design you authored for an API you did not consume | `[inferred]` bridge |
| G4 | Roadmap ownership (R6, R7) | transferability | Input gathering and requirements | A client request that became a roadmap item, and what happened after | `[inferred]` bridge |
| G5 | Agile delivery (R5, R9) | discovery | No framework named | What cadence the squads you coordinated actually ran on | `[grounded]` CV silence |
| G6 | Sales stakeholders (R4b) | discovery | Not on the CV | Any work with sales on deal-level or account-level decisions | `[grounded]` CV silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Roadmap decision rights unstated | unknown | — | "Own the roadmap for our partner-facing API platform" | The role may own the roadmap's content while priorities are set above it | `[inferred]` from the JD's silence on approval | Who approves the platform roadmap, and which priorities can this role set without sign-off? | unresolved |
| RR2 | Pay, level and contract basis unstated | unknown | — | (not in the posting you pasted) | Pay may be omitted from the posting, or the paste may be incomplete | `[inferred]` from the paste; market band not established | What is the base range and level for this role, and is the contract permanent? | unresolved |
| RR3 | Two engineering squads and a defined platform scope | positive_signal | — | "two engineering squads" | Resourcing and scope look real, not a title with no team behind it | `[grounded]` JD | Who are the two squads' leads, and how are they organized? | noted |
| RR4 | Adoption success not defined | unknown | — | "define and track adoption metrics" | Success may be undefined at launch | `[inferred]` from the JD asking for definition without targets | What adoption outcome is this role accountable for in year one, and what usage data exists today? | unresolved |

Employer verification was not run, because the searches were refused. No failed-attribution entry is recorded. That is an unknown, not a finding.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Rephrase the CV's requirements and architecture bullet with the same verbs and nouns, e.g. "wrote requirements documents and integration architecture for 30+ client integrations." Keep "led" and "client." Do not use "partner" or "specs" unless they describe what you did | R3, R8 | `[grounded]` CV | resume_edits_pending_approval |
| E2 | Move the roadmap-input sessions under a product-facing heading, worded as they were | R1b, R6 | `[grounded]` CV | resume_edits_pending_approval |
| P1 | Prepare one true story: a client request that became a roadmap item, what you did, what changed. Say "client," not "partner," since the JD's word is not your history | R6, R7, RR1 | `[inferred]` that one concrete example is what moves a hiring manager | proposed; needs your real example |
| A1 | Confirm the posting is live on the company's careers page before you spend effort on the application | RR2 and the unchecked employer | `[generic]` pattern: postings can go stale or be aggregated | proposed |

Reframing audit: the scope of "scoping workshops for one client's integration" must not grow into "product discovery." The kind of work differs, and an interviewer will test that.

## Evidence status

Verified: none yet. The CV claims are leads until you confirm them with specifics. The earlier note about an internal request-triage tool is an unverified lead and appears only as question Q2.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Every search was refused, so the employer and posting are unchecked. Would have moved the organization row in role reality and the failed-attribution check |
| 2. Role-family sweep | unavailable | Every search was refused. Would have set the market band for title, scope and pay, and the market calibration row |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

## Upgrade menu

- A product-owned example, such as a client request that became a shipped roadmap item or a requirements document whose scope you set → R1b, R6 and R7 strengthen.
- How adoption was measured for the request-triage tool, if it exists → R10 and possibly R1b move.
- The live posting link or the company's careers page → verifies the employer and the posting.
- Permission to search → runs targets 1 and 2 (the employer, and a role-family band for title and pay), up to 5 searches and 2 fetches.

I can write this up as a `tuesday-dossier.md` file to carry into your applications, if that would help.

1. **R1a (discovery):** Did any of your seven years include owning a product decision, such as a prioritization call, a backlog you ran, or a roadmap you were accountable for? Name one and what happened.
2. **R10 (discovery):** Have you measured whether something you built was adopted? I have an unconfirmed note from an earlier conversation about an internal request-triage tool that support agents used. Is that accurate, and how was use measured?
3. **Constraints (structural):** What are your constraints (pay floor, location, contract type, start date)? I need them to run the hard-gate checks.

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.