**Yes, apply, on conditions.** On the analytics core you're a credible fit: the SQL, Looker, experimentation and exec-communication requirements each have a specific match in your background. The real gaps are healthcare, clinician work and mentoring, and two of those are unknown rather than missing. Status: `conditional_go`.

- **Fit ledger.** `must_have`: direct R1, R2, R3, R4, R6 · adjacent R5. `important`: adjacent R7 · unclear R8, R9. `preferred`: adjacent R10. Below-direct rows: R5 (metrics layer), R7 (PM roadmap partnership), R8 (clinicians), R9 (mentoring), R10 (healthcare data). The governed Looker work is the nearest evidence for R5; R8 and R9 have no evidence either way; R10's consent model transfers, but HIPAA itself isn't held.
- **Opportunity ledger.** The scope is concrete and well defined (RR6). The employer is unverified because web search was refused in this session (RR1). Clinician and mentoring scope are unknown (RR2, RR3). The HIPAA learning curve is a low risk signal (RR4).
- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the posting is confirmed live on Harborlight's own careers site (RR1), which caps this at `conditional_go` until it is; (2) RR2 and RR3 check out in the first conversation; (3) pay (RR5) is disclosed and sits in a range you accept.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, digital-health scale-up, ~400 people, Series C | `[grounded]` your posting excerpt; not verified (RR1) |
| Mandate | Own product analytics for one care-navigation app: metrics layer, A/B tests, self-serve Looker dashboards, PM and clinician partnership, two junior analysts | `[grounded]` posting |
| Scope read | Senior IC with a mentoring component; one product, so the scope is bounded | `[inferred]` from the responsibility list |
| Market calibration | Not run; no salary or scope band was checked | — |
| Unknowns | Compensation, contract type, location, clinician involvement, mentoring load, metric-definition ownership | — |
| Contradictions | None visible from the posting alone | `[grounded]` posting |

## Evidence map

Your claims are self-report from this conversation, so each `direct` row is `medium` at most, with a probe expected.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | Six years stated; not yet probed. Length of experience is graded, not a gate | `[grounded]` your message | none |
| R2 | Expert SQL | must_have | direct | medium | none | Daily SQL on Snowflake is the evidence. "Expert" is your word and is what a SQL probe will test | `[grounded]` your message | Offer a sanitized query sample to raise to high |
| R3 | Experiment design at scale | must_have | direct | medium | none | 30+ tests a year and a pricing test with an 11% retention lift. Relative or percentage-point lift is unstated | `[grounded]` your message | Clarify the lift basis before writing it |
| R4 | Looker or similar BI, self-serve dashboards | must_have | direct | medium | none | Built the instance and 40+ governed dashboards | `[grounded]` your message | none |
| R5 | Define and maintain the metrics layer | must_have | adjacent | medium | transferability | Governed dashboards and the monthly metrics memo are the nearest evidence. Ownership of metric definitions isn't stated | `[inferred]` from the dashboard work | G1 |
| R6 | Written communication with non-technical stakeholders | must_have | direct | medium | none | Monthly exec memo and monthly VP Product presentation | `[grounded]` your message | none |
| R7 | Partner with PMs to turn analysis into roadmap decisions | important | adjacent | medium | transferability | The VP Product presentation shows influence. Day-to-day PM partnership isn't stated | `[inferred]` | Cover in the interview framing |
| R8 | Partner with clinicians | important | unclear | low | discovery | No mention of clinical or care-ops partners | `[grounded]` absence in your message | G2 |
| R9 | Mentor two junior analysts | important | unclear | low | discovery | No mention of mentoring | `[grounded]` absence in your message | G3 |
| R10 | Healthcare data, HIPAA (a plus) | preferred | adjacent | medium | transferability | GDPR/CCPA consent-state model transfers. HIPAA-specific rules (PHI, BAAs, minimum necessary) are not held, and no healthcare work is claimed | `[inferred]`; `[generic]` on HIPAA's specifics | G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Metrics-layer ownership (R5) | transferability | Governed dashboards exist; metric-definition ownership is not stated | This is the first thing a metrics-layer owner gets asked | Defining a metric used in the exec memo; a metric-dictionary or governance decision you made | A metric definitions doc or the memo's metric glossary | `[inferred]` from the dashboard work |
| G2 | Clinician partnership (R8) | discovery | Nothing about clinical or care-ops partners | A named responsibility, and the one most likely to be probed | Analysis for care-ops, support or ops leads that changed a decision | Any sanitized readout written for a non-product team | `[grounded]` absence |
| G3 | Mentoring (R9) | discovery | Nothing about junior analysts | Named responsibility; this is a senior role with reports | Onboarding, reviewing SQL, running a team's analysis review | A mentoring plan or review feedback you gave | `[grounded]` absence |
| G4 | Healthcare data (R10) | transferability | Consent model and PII handling, no regulated health data | Preferred, but it shapes how a hiring panel reads the consent work | Any HIPAA or regulated-data training, or PHI-adjacent analysis | A training certificate or a data-governance summary | `[generic]` on HIPAA's specifics |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not verified (research refused) | unknown | — | "Harborlight Health (digital-health scale-up, ~400 people, Series C)" | Unverified, not failed. The posting may be stale or aggregated, or the company may be small | `[generic]` pattern for companies of this size; no claim about this one | What does the team look like today, and who would I be working with day to day? | unresolved |
| RR2 | Clinician work is unscoped | unknown | — | "partner with ... clinicians" | Clinicians may be a frequent stakeholder or an occasional one | `[inferred]` from the responsibility list | How often does this role work directly with clinicians, and which decisions have analytics informed in the past year? | unresolved |
| RR3 | Mentoring load and level are unscoped | unknown | — | "mentor two junior analysts" | The reports may be early-career and need hands-on review | `[inferred]` from the responsibility list | What level are the two analysts, and what does mentoring look like in practice? | unresolved |
| RR4 | Regulated data environment | risk_signal | low | "healthcare data experience (HIPAA) a plus" | Access rules and review steps add ramp time for a consumer-analytics background | `[generic]` pattern for HIPAA-regulated analytics | Which datasets fall under HIPAA, and how is analyst access governed? | unresolved |
| RR5 | Compensation not stated | unknown | — | (none in posting excerpt) | The figure may be budgeted in a range you'd want to know before investing time | `[grounded]` posting omits pay | What is the budgeted base range for this level? | unresolved |
| RR6 | Concrete, bounded scope | positive_signal | — | "Own product analytics for our care-navigation app" | One product, defined responsibilities, a clear decision surface | `[grounded]` posting | Which product metrics does the team treat as its north star? | noted |

**Severe red flags:** none found.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm the posting on Harborlight's own careers site before applying | RR1 | `[grounded]` RR1 | pending your approval |
| P1 | Lead with the experimentation program (30+ tests a year, pricing test) and the Looker build (40+ governed dashboards) | Strongest direct matches (R3, R4). Use your words: "designed and ran an experimentation program"; "built the Looker instance from scratch" | `[grounded]` your message | pending your approval |
| P2 | State the 11% retention lift exactly as you measured it, relative or percentage points | Ambiguity resolves downward; an interviewer will ask | `[grounded]` R3 | pending your approval |
| P3 | Describe the consent-state model as privacy engineering under GDPR/CCPA, not as healthcare experience | Keeps R10 at adjacent | `[grounded]` your message; `[generic]` on HIPAA | pending your approval |
| P4 | Prepare an honest answer on clinicians and mentoring; if you have no example, say so | Avoids claiming R8 or R9 | `[grounded]` R8, R9 | pending your approval |

## Evidence status

**Verified:** none yet. Your claims are the intake self-report that this assessment rests on.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Three search calls were refused by permission in this session, so no page was checked. It would have settled RR1 |
| 2. Role-family sweep | unavailable | Same refusal. It would have set the market calibration and the RR5 band |
| 3. Hiring manager's public footprint | n/a | No name was given, so there is no query to form |

Upgrade menu below covers what allowing search would add.

Dossier offer: Want me to save this as `tuesday-dossier.md`, so the analysis carries into interview prep if you get a call?

## Upgrade menu

- **Allow web search for this session, or paste the posting link and the careers-page link** → RR1 verifies or fails, and RR5 gets a market band. A pasted link is read without using the research budget.
- **The posted pay range, or a recruiter's answer on it** → RR5 closes.
- **A sanitized metric-definitions doc or the memo's glossary** → R5 moves to direct.
- **A sanitized experiment readout** → R3 and R1 go from medium to high.
- **Any regulated-data training or PHI-adjacent work** → R10 moves from adjacent.

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

1. **R8 / RR2:** Have you worked directly with clinicians, care-ops or another non-product group on analysis that changed a decision? What did you own, and what happened?
2. **R9 / RR3:** Have you mentored or managed junior analysts? What did that look like, and what did you own?
3. **G1 / R5:** Who set the metric definitions in your warehouse: did you own them, or were they defined elsewhere?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.