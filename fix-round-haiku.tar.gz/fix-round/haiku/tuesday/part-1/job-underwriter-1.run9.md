**Yes on the core analyst work, thinner on healthcare and clinician work. Status: `conditional_go`. Apply once the posting verifies.** R1, R2, R3 and R4 read `direct` against your record. R9 and R7b are where you are thinner.

**Fit ledger.**

- `must_have`: direct: R1, R2, R3, R4 (medium confidence on R3, since the 11% lift is self-reported and no write-up has been inspected)
- `important`: direct: R6 · adjacent: R7a (partnering with PMs on roadmap decisions) · unclear: R5 (defining the metrics layer), R7b (partnering with clinicians), R8 (mentoring two junior analysts)
- `preferred`: adjacent: R9 (healthcare data, HIPAA)

R5, R8 and R9 could move the status. R5 and R8 are open questions, and R9 is a stated gap.

**Opportunity ledger.** The scope is concrete but the terms are under-specified. Pay is not stated (RR2), decision rights are not stated (RR3), and data governance is not described (RR4). The employer is unverified because web search was declined this session (RR1). RR5 is a positive: the deliverables and tools are named.

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:** conditions for go are (1) RR1 verifies, meaning the employer and the live posting can be confirmed; (2) G1 and G4 come back as direct, or at least credible; (3) R9 is framed as consumer PII and consent governance, never as healthcare or HIPAA experience.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, a digital-health scale-up, about 400 people, Series C | `[grounded]` JD text, unverified |
| Mandate | Own product analytics for the care-navigation app: metrics layer, A/B tests, Looker dashboards, PM and clinician partnership, mentor two junior analysts | `[grounded]` JD |
| First-year outcomes | Not stated | — |
| Working pattern | Location, schedule and contract type not stated | — |
| Scope read | Senior ownership across the analytics stack, plus people development | `[inferred]` from the mandate's breadth |
| Market calibration | Not run. The role-family pay and scope check was declined with the search | — |
| Unknowns | Pay, location, contract type, decision rights, data governance, what "clinician partnership" involves day to day | — |
| Contradictions | None visible in the JD text itself | `[grounded]` JD; not checked against the employer's site |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | Six years in consumer-subscription product analytics; self-reported, no artifact inspected | `[grounded]` your intake | none |
| R2 | Expert SQL | must_have | direct | medium | none | Daily SQL on a Snowflake warehouse; self-reported | `[grounded]` your intake | none |
| R3 | Experiment design and analysis at scale | must_have | direct | medium | none | 30+ tests a year and a pricing test with an 11% retention lift; the lift is one test's number | `[grounded]` your intake | An inspectable test write-up would raise this to high |
| R4 | Looker or similar BI; self-serve dashboards | must_have | direct | medium | none | Built the Looker instance from scratch; 40+ governed dashboards | `[grounded]` your intake | A sanitized list of dashboards would raise this to high |
| R5 | Define and maintain the metrics layer | important | unclear | low | discovery | Governed dashboards imply metric definitions, but you did not say you owned canonical definitions or their sign-off | `[inferred]` from dashboard governance | G1 |
| R6 | Written communication with non-technical stakeholders | important | direct | medium | none | Monthly metrics memo read by the exec team; monthly presentation to the VP Product | `[grounded]` your intake | none |
| R7a | Partner with PMs to turn analysis into roadmap decisions | important | adjacent | medium | transferability | Senior stakeholder presentations are close to this; PM partnership is not described | `[inferred]` from the presentation cadence | G2 |
| R7b | Partner with clinicians | important | unclear | none | discovery | Clinicians do not appear anywhere in your record | `[grounded]` absence from intake | G3 |
| R8 | Mentor two junior analysts | important | unclear | none | discovery | Mentoring is not mentioned in your record | `[grounded]` absence from intake | G4 |
| R9 | Healthcare data, HIPAA | preferred | adjacent | medium | transferability | GDPR/CCPA consumer PII handling and the consent-state model are real; PHI and HIPAA rules are not in your record | `[inferred]` adjacency from the consent-model work | G5 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Metric definition ownership (R5, important) | discovery | Dashboards are governed, but ownership of definitions is unstated | Decides whether the metrics-layer requirement is direct | Owning a semantic layer, dbt models, or agreed definitions for revenue or retention | A metric-definitions doc or a sanitized explore list | `[inferred]` that this decides the R5 call |
| G2 | PM partnership (R7a, important) | transferability | Presentations to the VP Product; PM work not described | Partnership is the day-to-day of this role | Roadmap calls you shaped with a PM | A sanitized roadmap memo | `[inferred]` from the presentation cadence |
| G3 | Clinician or regulated-domain partnership (R7b, important) | discovery | Nothing in the record | Clinicians are named in the mandate | Any work with care teams, compliance, or regulated stakeholders | An example of a decision shaped by such a team | `[grounded]` absence; `[generic]` that clinical input is central in care-navigation products |
| G4 | Mentoring (R8, important) | discovery | Not mentioned | Two direct reports are named in the mandate | Formal or informal mentoring of analysts | Feedback from a junior you developed | `[grounded]` absence |
| G5 | Healthcare data (R9, preferred) | transferability | Consumer PII and consent work only | Preferred, not a gate | Any PHI or BAA exposure; the consent model's governance review | A consent-model design doc | `[inferred]` bridge from the consent work |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer and posting not verified | unknown | — | "digital-health scale-up, ~400 people, Series C" | The employer may exist as described; this session could not check | `[inferred]` from no research results | "Where is this role published on your careers site, and who would I be working with?" | unresolved |
| RR2 | Pay withheld | unknown | — | (no pay in the posting text) | Pay may sit below your floor, or pay may not be published | `[inferred]` from the posting's silence; no market band run | "What base salary range is budgeted for this role?" | unresolved |
| RR3 | Decision rights unstated | risk_signal | low | "define and maintain the metrics layer … turn analysis into roadmap decisions" | You may define metrics and inform the roadmap without signing off on either | `[inferred]` from the scope verbs against the silence on sign-off | "Who signs off on metric definitions, and does this role set roadmap priorities or inform them?" | unresolved |
| RR4 | Data governance undescribed | unknown | — | "healthcare data experience (HIPAA) a plus" | The warehouse may hold PHI under a BAA with access rules unlike consumer PII | `[generic]` pattern for healthcare analytics; not a claim about this employer | "What data does the analytics warehouse hold, is any of it PHI, and what access rules apply to analysts?" | unresolved |
| RR5 | Concrete scope and tooling | positive_signal | — | "Looker", "A/B tests", "two junior analysts" | Scope is defined enough to plan against | `[grounded]` JD | "Which of these deliverables must be running in the first year?" | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Get the posting link and the recruiter's email domain, and verify before investing effort | RR1 | `[grounded]` RR1 | pending your approval |
| P2 | Ask for the pay range before the first interview | RR2 | `[grounded]` RR2 | pending your approval |
| P3 | Position healthcare as: "I handled GDPR/CCPA consumer PII and built the consent-state model for our warehouse." Do not claim healthcare or HIPAA experience | R9 | `[grounded]` your intake; the proposed sentence uses only your words | pending your approval |
| P4 | Prepare one honest example each for G1 and G4 before any loop. Do not claim mentoring you have not done | G1, G4 | `[grounded]` gap queue | pending your approval |

## Evidence status

Verified: none yet. Every claim above is your intake, not yet confirmed through a probe.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two web searches were declined in this session. The check would have confirmed that Harborlight exists as described and that the role is live (RR1) |
| 2. Role-family sweep | unavailable | Would have set the market calibration for pay and scope (Role reality; RR2) |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

## Upgrade menu

- A posting link or the recruiter's email domain → RR1 verifies. The employer check did not run this session.
- A pay range, or your pay floor → RR2 closes, and the figure can be compared against a band if you allow the pay check.
- Your non-negotiables (pay floor, location, contract type, schedule) → the hard-gate checks run. None have been given.
- An inspectable artifact: a sanitized test write-up or a metric-definitions doc → R3 and R5 can move.
- Permission for web search → the employer and pay checks can run. I won't retry without your say.

I can write this up as a `tuesday-dossier.md` for a later prep step if you want it.

**Questions**

G1 — Did you define the canonical metric definitions the dashboards run on, whether in a semantic layer, dbt models or Looker explores? Who signed them off?

G3 — Have you worked alongside clinicians, care teams or another regulated-domain group to shape a product decision? What did you own?

G4 — Have you mentored or formally managed junior analysts? How many, for how long, and what did you own in their development?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.