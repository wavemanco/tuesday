**No, not on these terms. The posting fails both of your hard constraints, so `no_go`.** Your sense that something is off is right: the posting's own terms conflict with your floor and your remote-only requirement.

## Decision snapshot

**No: R1 and R2, both hard gates, fail on the posting's own terms. Status: `no_go`.**

**Fit ledger.**

- `hard_gate` — hard_gate_fail: R1 (base compensation at or above $150k), R2 (on-site Austin five days a week)
- `must_have` — direct: R3a, R4, R5 · unclear: R3b (SEO/content, brand, PR, partnerships, sales ops)
- `important` — unclear: R6 (thrive on ambiguity), R7 (evenings and weekends)

R1 and R2 — failed gates; R3b — unclear must-have, silent in your account; R6 and R7 — unclear, not yet tested. Your must-have experience (R3a, R4, R5) fits well; that ledger is separate from the opportunity ledger below.

**Opportunity ledger.** The posting carries pay below your floor (RR2), an end-to-end scope with no stated budget or headcount (RR3), an always-on expectation (RR4), and success metrics left undefined (RR5). RR1 restates the on-site conflict, and RR6 means the employer and live posting are unverified. RR7 is the positive signal, Series A and profitable, and it is self-reported in the posting.

- **Hard gates:** failed: R1 (base compensation at or above $150k), R2 (on-site Austin five days a week); met: none.
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`).
- **What would change this:** both R1 and R2 would have to change, each confirmed by the employer: a base at or above $150k and a remote arrangement. The posting currently says neither will move ("no exceptions").

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Novaline, e-commerce enablement, Series A, "profitable since day one" | `[grounded]` posting; not verified (see Evidence status) |
| Mandate | Own all revenue growth end to end across seven channels; report to CEO, dotted line to board | `[grounded]` posting |
| Working pattern | On-site Austin, five days a week, "no exceptions"; evenings and weekends "when it matters" | `[grounded]` posting |
| Compensation | $70–85k base plus unquantified equity | `[grounded]` posting |
| Market calibration | Not established this turn: the role-family search was refused, so I state no market band | — |
| Scope read | Head of title, 8+ years required, but "a team of one to start" and no budget stated | `[inferred]` from the posting's title and resourcing language |
| Unknowns | Budget, headcount, success metrics, schedule expectations, whether the role is live | — |
| Contradictions | "Head of" and "8+ years" against "team of one" and "players who don't need a bench" | `[inferred]` from the posting text |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Base compensation at or above $150k (your floor) | hard_gate | hard_gate_fail | high | hard_gate | The floor is your own specific, stated constraint. The posting's top figure is $65k below it. | `[grounded]` posting range; your stated constraint | none; only the employer changing the band resolves it |
| R2 | On-site Austin five days a week vs. remote-only (Portland) | hard_gate | hard_gate_fail | high | hard_gate | "No exceptions" is stated; the posting offers no remote path | `[grounded]` posting; your stated constraint | none; only a change to the on-site term resolves it |
| R3a | Paid acquisition, lifecycle/CRM, experimentation ownership | must_have | direct | medium | none | Your account is specific ($8M to $40M ARR with a budget you controlled) and names the channels. It is self-reported, so medium is the ceiling. | `[grounded]` your account | none |
| R3b | SEO/content, brand, PR, partnerships, sales ops | must_have | unclear | low | discovery | Your account is silent on these. Silence is not absence, so I do not count it as a gap in your record. | `[grounded]` your account is silent | G1 |
| R4 | Lead a growing team | must_have | direct | medium | none | You built and managed teams of 3–7; this role starts at one. | `[grounded]` your account | none |
| R5 | 8+ years growth leadership | must_have | direct | medium | none | Nine years, with Growth lead then Head of Growth at two companies. Length of experience is not a gate, so it is graded like any requirement. | `[grounded]` your account | none |
| R6 | Thrive on ambiguity; metrics will evolve | important | unclear | low | discovery | The posting says metrics "will evolve"; your account does not describe working without defined targets. | `[grounded]` posting language; your account is silent | G2 |
| R7 | Evenings and weekends "when it matters" | important | unclear | low | discovery | Your account states no limit or experience on this, and the posting treats it as normal. | `[grounded]` posting language | none, unless you proceed against this recommendation |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | SEO/content, brand, PR, partnerships, sales ops (R3b, must_have) | discovery | Your account names paid, lifecycle and experimentation; the other channels are silent | This would narrow the scope objection, but it does not change the no_go, which rests on R1 and R2 | Any SEO, PR, partnership or sales-ops process you ran or shared ownership of | A program brief, content calendar, or partner list | `[grounded]` your account |
| G2 | Defining success metrics from scratch (R6, important) | discovery | Your account covers scaling a known metric set to $40M ARR, not building the metrics from undefined starting points | Would clarify R6, which is not decision-changing here | A plan where you set the targets yourself with no prior benchmark | A metrics doc or planning deck | `[grounded]` your account is silent |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Remote-only conflicts with on-site terms | red_flag | high | "On-site in our Austin office 5 days a week — no exceptions." | The role is not open to remote work at any level | `[grounded]` posting language | Is there any remote or hybrid arrangement for this role? | unresolved |
| RR2 | Stated base is $65k–$80k below your floor | red_flag | high | "$70–85k base plus meaningful equity upside" | Pay may be set for a lower level than the scope describes, with equity standing in for base | `[inferred]` from the stated range against the 8+ years and end-to-end scope; the market comparison is not established | Is $70–85k the approved band for this role, and is there room to move toward $150k base? | unresolved |
| RR3 | End-to-end scope with no stated budget or headcount | risk_signal | medium | "Own all revenue growth end to end… You will be a team of one to start" | You could be accountable for all revenue growth without committed resources | `[inferred]` from scope language against the posting's silence on budget | What paid-media budget and headcount are committed to this role in year one? | unresolved |
| RR4 | Always-on expectation | risk_signal | medium | "evenings and weekends when it matters is just who we are" | Hours beyond the posted schedule are the norm, not the exception | `[grounded]` quote; the pattern is `[generic]` for phrasing of this kind | How often did the growth function work evenings or weekends last quarter, and how is that recognized? | unresolved |
| RR5 | Success metrics undefined on a demanding mandate | risk_signal | medium | "success metrics will evolve as we learn" | You may be assessed on criteria set after you start | `[grounded]` quote; `[generic]` pattern for this phrasing | What three metrics will this role be measured on at six months, and who sets them? | unresolved |
| RR6 | Employer and live posting not verified | unknown | — | "Novaline (e-commerce enablement startup, Series A, profitable since day one)" | The employer and posting are unconfirmed, because the search was refused | `[grounded]` the posting's own identifying language; the check was not run | Is this role live on Novaline's careers page, and who would I interview with? | unresolved |
| RR7 | Stated stage and profitability | positive_signal | — | "Series A, profitable since day one" | Financial footing may be stable; self-reported and unverified | `[grounded]` posting; unverified | What is the revenue trajectory behind "profitable since day one"? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Do not apply on the posted terms | R1 and R2 both fail; effort spent here is decided by the terms | `[grounded]` R1, R2 | pending your approval |
| A2 | If you want to test before dropping it, send one written question to the recruiter: is remote possible, and is the base band at or above $150k? | Those two answers are the only facts that could move R1 or R2 | `[grounded]` RR1, RR2 | pending your approval; outward-facing, so only with your go-ahead |
| A3 | Use RR1 to RR5 as interview questions only if you proceed against this recommendation | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: R1 and R2, your own stated constraints. R3a, R4 and R5 rest on your own account and are unverified.

Research tier: L1 — searches 3 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Novaline e-commerce enablement startup Austin" and "Novaline 'Head of Growth' careers Austin"; both were refused permission, so nothing returned. Would have moved RR6 and RR7: employer existence and whether the posting is live |
| 2. Role-family sweep | unavailable | Searched "Head of Growth base salary range Series A startup 2026 United States"; refused. Would have set the market band for RR2. The posting's own range is still checked against your floor, which needs no search |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

Dossier offer: I can write `tuesday-dossier.md` for this role if you want the register kept for later.

## Upgrade menu

- A live posting link or Novaline's careers page → RR6 and RR7 move from unverified to checked; the decision holds unless the terms differ.
- Written confirmation from the employer of the base band and the remote terms → R1 and R2 could change, and the status would move to `hold_pending_answers`.
- Permission for web search (refused this session) → the sweep would set a `[generic]` market band for this title and stage, so RR2 has a reference beyond your floor, and the employer check in RR6 would run.

No questions this turn: nothing I could ask would change a decision that the posting's own terms already settle.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.