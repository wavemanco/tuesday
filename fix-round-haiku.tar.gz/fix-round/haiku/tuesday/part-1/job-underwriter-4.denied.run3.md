**Yes, apply, on three conditions. Status: `conditional_go`.** You meet the stated requirements on evidence you already have. The open items are whether this employer is real and live, what the role pays, and whether it manages people.

**Fit ledger.**

- `hard_gate` — unclear: G1 (Fully remote, UK)
- `must_have` — direct: R1, R2, R3, R4, R5, R7; adjacent: R6 (Monitor rating models); unclear: R8 (Recommendations for product)
- `important` — adjacent: R10 (Pet-insurance product knowledge)
- `preferred` — direct: R9 (Insurance experience)

What matters: G1, remote-UK eligibility, is unconfirmed; R8, product-side recommendations, has no evidence yet; R6 and R10 are adjacent bridges, with limits named below.

**Opportunity ledger.** The scope is concrete: RR5 is a positive signal, since the posting names specific outputs. Four items are unresolved: RR1, the employer is unverified; RR2, decision rights over recommendations are unstated; RR3, pay is not in the text you pasted; RR4, whether the role has reports is not stated.

- **Hard gates:** none failed; unconfirmed: G1 (Fully remote, UK); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **Conditions for go:** (1) the posting is confirmed live on Brindlemoor's own careers site (RR1); (2) a pay range is known before you invest in the loop (RR3); (3) reports are answered (RR4); and the pet bridge is framed as adjacent, never as pet experience (R10).

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, insurtech, pet-insurance product | `[grounded]` JD; existence unverified (RR1) |
| Mandate | Pricing analytics for the pet product: build and monitor rating models, design and read price tests, recommend to underwriting and product | `[grounded]` JD |
| Hiring manager | Odile Varga, Director of Pricing | `[grounded]` your brief; public footprint not checked |
| Working pattern | Fully remote, UK | `[grounded]` JD |
| Pay | Not stated in the text you pasted | `[grounded]` absence |
| Market calibration | Not run; the salary search was refused, so no band is stated | — |
| Unknowns | Pay, reports, decision rights, contract basis, start date | — |
| Contradictions | None within the pasted text | `[grounded]` |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | Five years in pricing analytics, last two senior | `[grounded]` your background (self-report) | none |
| R2 | Strong SQL and Python | must_have | direct | medium | none | Both used daily | `[grounded]` your background | none |
| R3 | GLM experience | must_have | direct | medium | none | Built and maintained a GLM rating model (motor, young-driver book) | `[grounded]` your background | none |
| R4 | Design and read price tests | must_have | direct | medium | none | Ran 14 price tests last year with underwriting | `[grounded]` your background | none |
| R5 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | Presents the quarterly pricing review to the head of underwriting | `[grounded]` your background | none |
| R6 | Monitor rating models | must_have | adjacent | medium | transferability | "Maintained" is the nearest evidence; a monitoring routine is not described. Limit: no ongoing-monitoring cadence stated | `[inferred]` from "maintained" | Bring one monitoring pack you have run |
| R7 | Recommendations for underwriting | must_have | direct | medium | none | Quarterly review goes to underwriting leadership | `[grounded]` your background | none |
| R8 | Recommendations for product | must_have | unclear | low | discovery | No product-side work stated | `[grounded]` absence | Question RR2 covers the route |
| R9 | Insurance experience | preferred | direct | medium | none | UK motor insurer | `[grounded]` your background | none |
| R10 | Pet-insurance product knowledge | important | adjacent | medium | transferability | Motor pricing transfers; pet risk drivers and claims behaviour are not exercised. Not a listed requirement; the role's product | `[inferred]` from "our pet-insurance product"; `[generic]` that pet risk drivers differ from motor | See gap queue |
| G1 | Fully remote, UK (gate) | hard_gate | unclear | low | hard_gate | UK employment history suggests it, but location and right to work are not stated | `[grounded]` absence | Question below |

**Gap recovery queue**

| # | Gap (req) | Type | What I see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Fully remote, UK (gate) | hard_gate | Not stated | Wording cannot solve it; the answer decides eligibility | — | — | `[grounded]` |
| R6 | Monitor rating models | transferability | Built and maintained; no monitoring routine described | Interviewers ask how you know a model is still right | Any drift or performance checks you ran on the young-driver model | A monitoring pack or dashboard you have used | `[inferred]` |
| R8 | Recommendations for product | discovery | No product-side work stated | The role recommends to product, not only underwriting | Any price-change advice you gave product, even informally | A product-facing price memo | `[grounded]` absence |
| R10 | Pet-insurance knowledge | transferability | Motor only | The likeliest objection: "you have never priced pets" | Claims-cost trend or severity-inflation work in motor; data-scope work on a new line | A short note on how you would approach pet rating factors | `[inferred]`; `[generic]` for the likely objection |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not yet verified | risk_signal | medium | "Brindlemoor (insurtech)" | The posting may be stale or aggregated; the employer may be real and simply unsearched | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Decision rights unstated | unknown | — | "turn the results into recommendations" | The role may recommend while a committee signs off the rate | `[inferred]` from "recommendations" against silence on sign-off | Who approves a rate change this role recommends, and what is the route to a live price? | unresolved |
| RR3 | Pay not stated | unknown | — | (no pay term in the text) | The budget may sit below your senior band | `[grounded]` absence | What is the budgeted salary range for this post? | unresolved |
| RR4 | Reports not stated | unknown | — | (no reporting line in the text) | If the role line-manages, your "never managed anyone" becomes a real gap | `[inferred]` from silence | Does this role have direct reports, now or in the next year? | unresolved |
| RR5 | Concrete outputs named | positive_signal | — | "build and monitor rating models, design and read price tests" | Scope is defined, and it matches your work | `[grounded]` JD | — | noted |

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Lead your CV with the GLM build, the 14 price tests and the quarterly review to underwriting | Those are the three direct matches | `[grounded]` R3, R4, R5 | pending your approval |
| A2 | If pet comes up, say: "I have priced motor, not pet; here is what transfers and what I have not done" | Keeps R10 at adjacent | `[grounded]` R10 | pending your approval |
| A3 | Ask RR1 to RR4 in the first recruiter call | The register doubles as interview prep | `[grounded]` register | pending your approval |

Audit note: every line above traces to your own sentences. Nothing says you owned pet pricing, managed people, or owned product recommendations.

**Evidence status**

Verified: none yet. Everything above is your self-report at intake.

Research tier: L1 — searches 5 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches ("Brindlemoor insurtech pet insurance", "Brindlemoor careers Senior Pricing Analyst") were refused by a permission denial and returned nothing. Would have set RR1 and confirmed the posting |
| 2. Role-family sweep | unavailable | Two searches ("senior pricing analyst pet insurance UK salary", "pricing analyst GLM rating model insurance UK role profile") were refused. Would have set the market calibration and RR3 |
| 3. Hiring manager's public footprint | unavailable | One search ("Odile Varga Director of Pricing Brindlemoor") was refused. Would have shown her scope and background |

**Upgrade menu**

- The live posting link, or the recruiter's name and email domain → RR1 closes or stays open.
- A salary range from the recruiter → RR3 closes, and it is set against the role-family band once search runs.
- A monitoring pack or a price-test readout you can share, anonymised → R6 and R4 move toward `high`.
- A short note on how you would approach pet rating → R10's limit narrows.
- If search permission is granted, I can rerun the three targets and update the market calibration and the employer check.

If you want this kept for later rounds, I can write it to a `tuesday-dossier.md` file.

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

1. RR1: Do you have the live posting link, or the recruiter's name and email domain?
2. RR4: Does this role have direct reports, now or planned?
3. RR3: Has a salary range come up, with the recruiter or on the posting?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.