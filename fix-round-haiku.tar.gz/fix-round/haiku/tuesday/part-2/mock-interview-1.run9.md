Priya's prep pack is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-tuesday-part-2-rooms-case-1-denied-4e011820/5c93c8cc-186d-4dc4-9464-fc8f258310bf/scratchpad/Northwind_Data_senior-gtm-strategy-lead-emerging-products_interview_pack.md`. It is also attached above.

**What's in it:** 19 questions across six personas, weighted for a peer round. The Data-Driven Prober gets 5, the Peer Evaluator 4, Case/Strategist 3, Skeptic 3, Pressure 2 and Conversational 2. Each question has a type tag, a provenance column, answer guidance and a rationale. The pack also covers a fit snapshot with a requirement-coverage table, a read of Dan, five reverse questions and a prohibited-claims list.

**Highest-ROI prep:** D1, the absence of sales-ops and quota-setting experience. It's in Priya's own sentence and sits in the core of a sales-strategy seat. The guidance is to say the gap plainly, bridge only to "annual volume targets set with cross-org consensus," and concede a specific limit. Don't claim quota ownership.

**Things to know:**
- **No research ran.** The host refused all three web searches (Northwind values, the interview process, Dan's public footprint), so the pack rests on your inputs. The loop structure is unverified, so the persona weights rest on the peer relationship and Dan's profile.
- **Your JD input was highlights, not full text.** Requirement rows quote your summary, not the posting. Pasting the full JD would turn those into exact quotes.
- **Your research note is undated.** The strategy questions (C2, C3) use only its three priorities and the bundling threat, and state nothing beyond them.
- **No values section.** No values-style round is documented, so there's no values cheat sheet or VAL questions.
- **Two things would firm up the pack:** Dan's public talks or writing, and a recruiter email confirming the round format.

I didn't ask any questions, since you said you had everything needed. Deeper research is available if search permission is granted.

Drill offer: I can play Dan on D1 and push back on the quota answer for a live rehearsal.

Dossier offer: I can save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Northwind_Data_senior-gtm-strategy-lead-emerging-products_interview_pack.md -----
# Interview prep pack: Senior GTM Strategy Lead, Emerging Products, Northwind Data

**Role:** Senior GTM Strategy Lead, Emerging Products
**Company:** Northwind Data
**Candidate:** Priya
**Round:** One 60-minute conversation
**Interviewer:** Dan Kovac, Director of Sales Strategy. Relationship: **peer**, both reporting to the same VP.

No prior version to change. No research ran this session: every search was refused by the host, so the pack rests on your inputs and on the relationship prior. See Sources.

---

## How to use this pack

- **Personas** describe how a question is asked. **Types** describe what is being scored.
- Type key:
  - **EXP**: work-experience deep-dive. Tests whether your claims survive scrutiny and what you actually did.
  - **JD**: role-driven. Tests whether you can do the listed job, gaps included.
  - **CO**: company and strategy knowledge. Tests altitude and homework depth.
  - **CASE**: live problem from the role, reasoned out loud.
  - **VAL**: values. Not used here, because no values-style round is detected.
- Guidance is scaffolding, not a script. Say it in your own words. Each answer should land in 90 to 120 seconds.
- Provenance column: `[grounded]` traces to your inputs. `[inferred]` is a derivation this pack made. `[generic]` is a pattern with no claim about you or Northwind.
- **Answer slot:** an instruction for the interview, not a question for this chat. Answer it from your own experience, or say plainly that the practice was not yours.

---

## Fit snapshot

Requirements come from your JD highlights, quoted as you summarised them. There is no full JD text, so every requirement row is a highlight, not a posting line. No gate rows: the highlights name no eligibility term (location, work authorisation, pay, travel), so no `hard_gate` row and no gate question.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" (JD highlights) | "proposed a store-surface change credited with a ~$400M ARR uplift" (your message) | medium | [grounded] | transferability | Adjacent work. Your material says a product change credited with an uplift, not a go-to-market plan for a product line. Keep it at that scope: "I proposed a store-surface change credited with a ~$400M ARR uplift." Answer slot: the requirement makes a probe on what you have sequenced yourself likely. If you set a launch or GTM sequence, say which parts and how you decided. If you did not, say so and say what you would sequence first. |
| F2 | "identify whitespace across land/adopt/expand/renew" (JD highlights) | "built a partner-level revenue model used in carrier negotiations" (your message) | medium | [grounded] | transferability | The model is adjacent to whitespace. It does not show whitespace across the four lifecycle stages. Bridge: "I built a partner-level revenue model used in carrier negotiations." Answer slot: if you have sized whitespace on any of the four stages, say which and how. If you have not, say what the model would show. |
| F3 | "run independent analysis in SQL and Tableau" (JD highlights) | "skilled in SQL/Tableau" (your message) | low | [inferred] | discovery | A self-stated skill with no artifact, so it cannot be asserted as an analysis you ran. Answer slot: name the last analysis you ran end to end in SQL or Tableau, the question it answered and what changed. If you have not run one end to end, say so and say how you would start. |
| F4 | "partner-motion design experience required" (JD highlights) | "built a partner-level revenue model used in carrier negotiations" (your message) | medium | [grounded] | transferability | Partner-facing revenue modelling is adjacent to designing a partner motion. Say the carrier work at its own scope. Answer slot: if you designed any part of a partner motion (terms, incentives, enablement), say which. If you did not, say so and say what you would design first. |
| F5 | "strong cross-functional influence" (JD highlights) | "set annual volume targets with cross-org consensus" (your message) | medium | [grounded] | none | The quote reaches the requirement in role terms. Caveat: one sentence with limited inspectable proof, so expect a probe. Lead with the consensus in your words: "I set annual volume targets with cross-org consensus." |
| F6 | "AI experience a plus" (JD highlights) | "uses AI tools daily" (your message) | low | [inferred] | transferability | Usage is adjacent to building. Say usage plainly and do not extend it. Answer slot: if you have built anything on top of a model, say what. If you use tools only, say that. |
| F7 | Quota-setting and sales-ops work, expected of a sales-strategy seat (role-family expectation, not a JD highlight) | "No classic sales-ops or quota-setting experience" (your message) | none | [grounded] | capability | You stated the absence, so the words come from your own negative. Plain acknowledgement: "I haven't done classic sales-ops or quota-setting work." Then the nearest thing your material carries, at its own scope: annual volume targets set with cross-org consensus (F5). Do not stretch that into quota ownership. |

**Requirement coverage**

| Requirement | Covered by |
|---|---|
| own GTM strategy for two new product lines | B2, C1, D2 |
| identify whitespace across land/adopt/expand/renew | A5 |
| run independent analysis in SQL and Tableau | A3 |
| partner-motion design experience required | D2, A1 |
| strong cross-functional influence | B1, B4 |
| AI experience a plus | G2 |
| Quota and sales-ops absence (your stated gap) | D1, D3 |
| Research note: enterprise expansion, Compass, profitability | C2 |
| Research note: bundling threat | C3 |

---

## Reading the interviewer

Public footprint only, drawn from the profile you gave. No further research ran.

- **Career pattern:** pricing and monetization is his spine, with one early-stage startup chapter. Now Director of Sales Strategy.
- **Self-described style:** "relentlessly data-driven."
- **Implications:**
  1. Every number you give will be walked back to its inputs. Know which figures you can defend and which you cannot.
  2. Case questions will lean toward pricing, packaging and unit economics. That is his native ground, so do not treat it as a side topic.
  3. The startup chapter makes builder stories land. Expect a scrappiness probe on how someone from a large company moves fast.
- **Mirror opportunities:** shared vocabulary of revenue modelling and monetisation. Your "partner-level revenue model" (F2) is the closest point of contact.
- **Shared jump:** none offered. The material shows no matching career path, so no jump is quoted as common ground.

---

## Persona table

Relationship prior: **peer**. Peer Evaluator and Data-Driven Prober lead. The signals from his profile push the Prober higher.

No loop source establishes the loop, so these weights rest on the peer prior and his profile, not on a documented process.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy | Qs |
|---|---|---|---|---|
| Data-Driven Prober | Walks each CV number back to counting method, inputs and denominators; probes the SQL/Tableau line | High. Peer prior plus a self-described "relentlessly data-driven" profile raises it | Know how each figure was counted, or say you do not. Name your weakest assumption before he does | 5 (A1 to A5) |
| Peer Evaluator | Seam questions between GTM and sales strategy; credit-sharing; what you would need from him | High. Peer prior: he is pricing what the hire adds to his own work | Reciprocity framing. Propose seam principles rather than inventing a seam. Tell a disagreement story only where the material carries one | 4 (B1 to B4) |
| Case/Strategist | A live GTM plan for a new line; pricing against a bundle | Medium. The GTM-ownership line and his pricing spine tilt cases toward pricing and unit economics | Clarify, then structure, then answer. Name the pricing angle early | 3 (C1 to C3) |
| Skeptic | Quota and sales-ops absence; partner-motion design | Medium. The fit gaps are this persona's material | Rehearse the single predictable objection until it is plain. Bridge only from evidence you stated | 3 (D1 to D3) |
| Pressure / Stress | "Why trust a product person with a sales seat?"; "how much of that was you?" | Low to medium. Peer rounds rarely stress, but a time-boxed probe on the headline figure is plausible | Pause, restate, hold through two follow-ups, then concede a specific limit | 2 (E1 to E2) |
| Conversational / Rapport | "Walk me through the journey"; a casual AI question | Medium. Casual openers are still scored | A 90-second arc with no invented beats. Answer the AI question from what you use | 2 (G1 to G2) |

Total: 19 questions, within the 18 to 26 range. Depth follows weight: 5 for the top persona, 4 for the second, 3 for mid, 2 for low.

---

## Question banks

### A. Data-Driven Prober (weight: top, 5 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how the partner-level revenue model was built, and what you would defend least about it." | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" (your message) | Story-mapped on that sentence: the model, and its use in carrier negotiations. Tell it in your words. Answer slot: if you set the model's structure, say which parts and how you decided. If its structure was set by others, say so plainly and describe your part. Name one input you would re-check first. | F2 and F4 rest on this sentence. A prober starts with the model's inputs. |
| A2 | "That $400M figure: how was it counted, and what part of it was yours?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (your message) | Hold to "I proposed the change, and the uplift is credited to it." Defend the number in four parts: how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. Answer slot: if you did the attribution, say how. If the attribution was done by others, or never done, say so plainly. Name the weakest assumption before he does. | F1's headline figure, and the most probed sentence in your material. A figure raises the defend-the-number slots, and only those. |
| A3 | "Tell me about the last analysis you ran end to end in SQL or Tableau." | JD | [grounded] "run independent analysis in SQL and Tableau" (JD highlights); [inferred] "skilled in SQL/Tableau" (your message) | Open prompt. Answer slot: if you ran one, give the question, the data, the output and what changed. If you have not run one end to end, say so and describe how you would start. Do not claim an analysis your material does not show. | F3 is low confidence. This is the requirement's direct test, asked as a prompt so the honest answer is ready. |
| A4 | "Walk me through how an annual volume target was set, and what it assumed." | EXP | [grounded] "set annual volume targets with cross-org consensus" (your message) | Story-mapped on that sentence: the target, and the consensus behind it. Answer slot: if you set the figure, say which inputs were yours. If the figure came from elsewhere and you took part in agreeing it, say so plainly. Never describe an assumption you cannot recall. | F5 and F7. The sentence is about volume targets, not quotas, so answer at that scope. |
| A5 | "Which data source would you trust least for sizing whitespace across land, adopt, expand and renew, and why?" | JD | [grounded] "identify whitespace across land/adopt/expand/renew" (JD highlights) | A live method question. Structure: which data, how you would validate it, and which assumption you would test first. Name the weakest source honestly. Asserts nothing about your past. | The whitespace requirement, asked as a method question so the reasoning is visible. |

### B. Peer Evaluator (weight: top, 4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our teams sit side by side. Where is the seam between product GTM and sales strategy, and what happens when we disagree?" | JD | [grounded] "strong cross-functional influence" (JD highlights); [generic] peer seam stem (persona stem) | Open prompt. Propose seam principles: who decides pricing, who owns the account motion, how disagreement is settled. Do not pretend to know his team's seam. Story selection: pick a time you disagreed with a peer over a number. If none comes to mind, say so plainly, then give the nearest thing your material carries. | Peer prior: this is how a peer probes turf and disagreement style. |
| B2 | "What would you need from my team to make two new product lines work?" | JD | [grounded] "own GTM strategy for two new product lines" (JD highlights) | Name specific asks in principle: pricing input, deal data, sales capacity for pilots. Pair each ask with what you would bring his team. | Reciprocity in peer rounds. The reverse-question bank uses the same reciprocity beat. |
| B3 | "On the new lines, how do pricing and sales strategy split between your team and product?" | CO | [grounded] "own GTM strategy for two new product lines" (JD highlights) | Propose a clear decision-rights split, and say what you would need to confirm before deciding. Ask him where his own view sits. Asserts nothing about your history. | His pricing spine makes this his favourite terrain. It tests whether you think about decision rights, not only plans. |
| B4 | "How do you handle credit when work spans teams?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (your message); [generic] credit-sharing stem (persona stem) | Open prompt. Story-mapped on that sentence: you proposed, and the uplift is credited to the change. Say who did what, in your words. Answer slot: if others did the rest of the work, say so. | The credit-sharing probe is a peer test. Your own sentence already states the attribution, so the answer should match it exactly. |

### C. Case/Strategist (weight: mid, 3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A new product line has no price book yet, and a partner wants a volume commitment in six weeks. How do you structure the GTM plan?" | CASE | [grounded] "own GTM strategy for two new product lines" (JD highlights) | Clarify first: what the partner is committing to, what is known about price, what the six weeks are for. Then objective, segmentation, approach, metrics, risks. Name one pricing assumption you would test before committing. Asserts nothing about your history. | A live problem from the role. His pricing background makes the pricing and unit-economics angle the one to lead with. |
| C2 | "Northwind's stated priorities are enterprise expansion, the Compass copilot launch and reaching profitability. Which one would you sequence an emerging product's GTM around, and what would you give up?" | CO | [grounded] "enterprise expansion", "an AI copilot launch ('Compass')", "reaching profitability" (your research note) | Pick one priority, say why, and name what you would give up. Use only the note's three priorities. Do not assert current facts about Northwind beyond the note. | Strategy altitude. The note is undated, so keep the framing to what it states. |
| C3 | "Bundling by a much larger platform vendor is the main threat. How would you price against a bundle?" | CO | [grounded] "main competitive threat is bundling by a much larger platform vendor" (your research note) | Clarify whether the bundle is priced in or free, which segments buy it, and what unit-economics test decides it. Name the test before the price. | His pricing and monetisation spine is native to this question. The threat comes straight from your note. |

### D. Skeptic (weight: mid, 3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You have not run classic sales-ops or quota-setting. Why should I trust your numbers on a sales team?" | JD | [grounded] "No classic sales-ops or quota-setting experience" (your message) | Hold the plain acknowledgement first: "I haven't done classic sales-ops or quota-setting work." Then the nearest thing your material carries, at its own scope: "I set annual volume targets with cross-org consensus." Concede the limit specifically: you would learn the sales-ops mechanics first, and say how. Hold through two follow-ups by returning to the stated evidence. Do not claim quota ownership. | **Highest-ROI prep in this pack.** The absence is in your own sentence and it sits in the seat's core area. Expect it in some form. Deepest rehearsal here. |
| D2 | "The role needs partner-motion design experience. Have you designed one?" | JD | [grounded] "partner-motion design experience required" (JD highlights); "built a partner-level revenue model used in carrier negotiations" (your message) | Answer slot: if you designed any part of a partner motion, say which parts and how you decided. If you did not, say so plainly, then bridge at the scope of the revenue model you built for carrier negotiations. | F4. The requirement's direct test. The second branch allows that the practice was never yours. |
| D3 | "What would you get wrong on day one in this role?" | JD | [generic] weakest-day-one stem (persona stem); [grounded] "No classic sales-ops or quota-setting experience" (your message) | Name the sales-ops mechanics as the weakest area, honestly. Then a ramp plan: what you would learn first, from whom, and by when. Do not pick a weakness you can bluff. | The Skeptic's question. A calibrated, self-named gap scores better than a defended one. |

### E. Pressure / Stress (weight: low, 2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why should a product-strategy background be trusted with a sales-strategy seat?" | JD | [grounded] "9 at a large consumer-tech company in product strategy & ops" (your message); [generic] time-boxed "why you" stem (persona stem) | Pause, then restate. Hold: you bring the revenue model and the cross-org target work. Concede: you have not run quota-setting, and you would close that gap first. Hold the first position through two follow-ups. | Composure test. Hold-then-concede. |
| E2 | "That $400M figure. How much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (your message); [generic] "how much was you" stem (persona stem) | Hold: "I proposed the change. The uplift is credited to it." Concede a specific limit: you cannot give the attribution split from memory, and here is what you would check. Do not restate the figure with more confidence than your sentence carries. | A time-boxed version of A2. Practise holding the sentence, not expanding it. |

### G. Conversational / Rapport (weight: low, 2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm" and "9 at a large consumer-tech company in product strategy & ops" (your message) | A 90-second arc on those two sentences, then the revenue model. Use no beats your inputs do not state. | Casual openers are scored. The arc should match your CV exactly. |
| G2 | "What are you actually playing with in AI these days?" | JD | [grounded] "AI experience a plus" (JD highlights); "uses AI tools daily" (your message) | Name the tools you use daily and what you use them for. Answer slot: if you have built anything on top of a model, say what. If you use tools only, say that plainly. | F6. The casual register hides a scored plus. |

---

## Requirement-coverage line

Each JD highlight maps to question IDs above. See the coverage table in the Fit snapshot section.

---

## Reverse questions

Each one: why it lands.

| # | Question | Why it lands |
|---|---|---|
| R1 | "You came up through pricing and monetisation before sales strategy. Which pricing decision changed how you think about GTM?" | Ties to his own path. It turns an interrogation into a peer conversation and shows you researched him. |
| R2 | "What could a new person do in their first month that would genuinely help your team?" | Reciprocity question for a peer. It signals you are thinking about his load, not only your own. |
| R3 | "Where does the line sit between pricing decisions and the sales-strategy seat on the new lines?" | Tests the seam from C3 and B3 in his own terms. |
| R4 | "How is the Compass copilot launch changing how the emerging lines are sequenced?" | Draws on your research note. Asks rather than asserts, so it stays true whatever the answer. |
| R5 | "When a bundle comes up in a deal, how often does sales make the price case alone?" | Puts the bundling threat from your note to the person who sees it in deals. |

---

## Prohibited claims

Built locally from the fit snapshot. These are the claims this pack will not coach, and why.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned GTM strategy for two product lines | Inflated form of F1 | F1's quote at its own scope. The material says a product change credited with an uplift, not a GTM plan. |
| Led the store-surface change, or drove the $400M | Inflated verb and attribution of the quoted sentence | "I proposed a store-surface change credited with a ~$400M ARR uplift." "Proposed" and "credited" stay as written. |
| Built the whitespace analysis across the four lifecycle stages | Inflated form of F2 | "I built a partner-level revenue model used in carrier negotiations." |
| Designed a partner motion | Inflated form of F4 | The carrier-negotiation model at its own scope. The partner-motion practice is an answer slot, not a claim. |
| Set quotas, or ran sales ops | Negative you stated in F7 | "I haven't done classic sales-ops or quota-setting work." No slot. |
| Expert in SQL or Tableau | Inflated form of F3 | "Skilled in SQL/Tableau," at that scope, with no analysis implied. |
| Built AI products | Inflated form of F6 | "I use AI tools daily." |

---

## Sources

- **Provided documents:** your message. It contains the JD highlights, your candidate summary, the interviewer profile, and the research note on Northwind's priorities and threat. No CV text, no full JD, no dossier.
- **Dossier:** none present.
- **Searches and fetches:** three searches were sent, for Northwind values, the Northwind interview process, and Dan Kovac's public footprint. The host refused all three ("permission not granted"). No fetch ran.

**Research tier: L1 — searches 3 of 6, fetches 0 of 2 (all three refused by the host); user links read 0**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Northwind Data values | unavailable | Refused. Would have supplied official value names. Section 10 stays out regardless, because no values-style round is detected. |
| 2. Northwind interview process, sales strategy | unavailable | Refused. Would have named the loop. Without it, persona weights rest on the peer prior and his profile. |
| 3. Northwind strategy / recent news | unavailable | Not sent after the first refusals. Would have checked whether the research note is current, which feeds C2 and C3. |
| 4. Dan Kovac, Northwind Data | unavailable | Refused. Would have added public talks and writing, feeding the interviewer read and reverse questions. |
| 5. Representative JD | skipped | Your JD highlights fix the fit snapshot and the JD-tagged questions. |

L2 was not run and was not offered before this point. Its offer is in the upgrade menu.

---

## Upgrade menu

- Full JD text → the six highlight rows become quoted posting lines, and any requirement the highlights omitted gets a question.
- Your research note's date and source → C2 and C3 can be checked for currency, and their framing can be stated as current.
- The Northwind values page, pasted or fetched → a values-style round can be detected if a loop source documents one, which adds a values section and VAL questions.
- The recruiter's process email → establishes the loop, which firms up the persona weights.
- Dan Kovac's public talks or writing, pasted → the interviewer read gains his recurring themes, and R1 can tie to something he has published.
- The last SQL or Tableau analysis you ran, in your own words → answers A3 and F3, and can upgrade F3 from low.
- Which inputs you set for the annual volume targets, in your own words → answers A4, and can upgrade F5.
- Whether you have designed any part of a partner motion → answers D2 and can upgrade F4.
- Deeper research (L2): up to 6 more searches and 2 more fetches, several minutes. Adds a strategy brief, interviewer talks, loop reports, and recent org context. Available if search permission is granted.
- A `tuesday-dossier.md` from job-underwriter → verified evidence and a prohibited-claims list, both binding on this pack's wording.
