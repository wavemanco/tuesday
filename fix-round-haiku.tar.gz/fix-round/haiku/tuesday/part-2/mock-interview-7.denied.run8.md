Your prep pack is saved as `saltmarsh_live-operations-producer_interview_pack.md`, and I've attached it above. I built it for a hiring-manager round, since you describe Tobias as Head of Live Operations and the JD is for the role he'd lead. No outside research ran: the host refused the three web searches, so the company values, strategy, and Tobias's background are missing and the pack says so.

The pack's centre of gravity is one question. Tobias will most likely ask how you'd get design, art and engineering to commit to an update date when you've never led a team. That's question A1, and it's the one to rehearse first. The honest shape of the answer is: "I haven't led a team," then the nearest thing you did (the release checklist QA still uses), then a concrete plan for how you'd start. Don't reach for "I coordinated" unless you can name the team, the update, and how the date was agreed.

Three other things to get straight before Friday:

- **Keep your claims at the size you stated them.** You "presented" the retention numbers and "wrote" the checklist. You didn't say you owned the post-event review, the KPIs, or the QA process, so don't say you did. The pack lists those inflated versions as things not to say.
- **Two gaps weren't in the JD, but expect them.** Team leadership and in-app purchases are both likely probes at a mobile studio. Say each absence plainly, once, and move on.
- **Know your retention numbers.** You don't have a figure in your message. If Tobias asks what the numbers measured or which assumption you'd defend least, answer only from what you actually did.

Two things would make the pack sharper: whether the puzzle game kept receiving content after launch, and whether Friday is with Tobias directly or a different round. If you can paste Tobias's public profile or a recruiter's note on the round's focus areas, I can add a section on him and tailor the reverse questions.

Would you like me to play Tobias as the Skeptic on A1 so you can rehearse it live?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh_live-operations-producer_interview_pack.md -----
# Interview prep pack: Live Operations Producer, Saltmarsh Games

Interviewer: Tobias Wrenfield, Head of Live Operations. Round: hiring-manager round, 60 minutes, Friday. Built from the job description and your background message. No outside research ran this session (see Sources), so the company-specific layers are missing and marked as such.

## How to use this pack

Personas describe how a question will be asked. Types describe what it is scoring:

- **JD**: a stated responsibility or qualification, including its gaps
- **EXP**: a claim from your own experience, checked for precise attribution
- **CASE**: a live problem from the role, scored on structure and reasoning
- **CO**: company and strategy knowledge (not covered this session)
- **VAL**: behavior against the company's published values (not covered this session)

The guidance is scaffolding for a spoken answer, not a script. Rehearse only what you actually did, in your own words. Every line about your past is either a sentence you wrote, quoted in the fit snapshot, or an answer slot that asks you to say what was yours.

## Fit snapshot

Requirements come from the job description (quoted). Evidence comes only from your message (quoted). Confidence grades your evidence. Provenance grades this pack's statement. Gap type says what kind of gap this is.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | transferability | Your material says weekly content drops for one main title, not live events across two titles. Words: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: if you have planned events for more than one title, say which and how; if you have not, say so plainly and say how you would start on the second. |
| F2 | "coordinate design, art, engineering and community teams on each update" (JD) | "Wrote the release checklist our QA team still uses." (your message) | low | [inferred] | discovery | The material shows only QA, and it is silent on design, art, engineering and community. Answer slot: if you coordinated any of those teams on an update, name the team, the update and how the date was agreed, in your own words; if you did not, say so plainly and say how you would start. |
| F3 | "own the post-event review and the KPIs it reports" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | medium | [grounded] | transferability | Your material says you presented retention to the studio head. It does not show that you owned the review or chose the KPIs. Words: "I presented the monthly retention numbers to the studio head." Answer slot: if you chose which KPIs a review reported, say which and how you decided; if you did not, say so and say what you presented. |
| F4 | "manage the release checklist with QA" (JD) | "Wrote the release checklist our QA team still uses." (your message) | medium | [grounded] | none | The quote reaches the requirement in role-relevant terms. Words: "I wrote the release checklist our QA team still uses." Expect a probe on whether you still maintain it. |
| F5 | "3+ years producing live-service games or apps" (JD) | "4 years as an associate producer at a puzzle-game studio." (your message); "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | discovery | Four years clears the length bar. Your message does not say whether the puzzle title was live-service; weekly content drops point that way but do not establish it. Answer slot: say whether the title kept receiving content after launch, and how, in your own words. |
| F6 | "experience running a content calendar" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | none | The quote reaches the requirement directly. Words: "I ran the weekly content-drop calendar for our main title for the last two years." Be ready to describe the cadence and how a drop was planned. |
| F7 | "comfortable with player-retention metrics" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | medium | [grounded] | presentation | The quote reaches the requirement in other terms: you worked with retention figures at leadership level. It does not show how they were built. Words: "I presented the monthly retention numbers to the studio head." Answer slot: say what the figures measured and how they were produced; if you did not produce them, say so. |
| F8 | "clear written communication" (JD) | "Wrote the release checklist our QA team still uses." (your message) | medium | [grounded] | none | One written artifact is in use; no writing sample has been inspected. Upgrade: a writing sample would raise this (see upgrade menu). |
| F9 | Team leadership, not in the JD, but a likely probe for a role that coordinates teams ([generic]) | "Never led a team, and never worked on a game with in-app purchases." (your message) | high | [grounded] | capability | This is your own stated absence. Words: "I haven't led a team." Then how you would learn to lead a team, said as a plan and never as a past. |
| F10 | In-app purchase monetization on the two titles, not in the JD, but a likely probe at a mobile studio ([generic]) | "Never led a team, and never worked on a game with in-app purchases." (your message) | high | [grounded] | capability | Your own stated absence. Words: "I haven't worked on a game with in-app purchases." Then how you would learn the monetization model, said as a plan and never as a past. |

## Prohibited claims

Each entry is a claim this pack will not coach, with its basis and its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the live-events calendar across two titles | Inflated form of F1 | "I ran the weekly content-drop calendar for our main title for the last two years." Observation for you, not words to say: your material describes one main title, not two. |
| Owned the post-event review and the KPIs | Inflated form of F3 | "I presented the monthly retention numbers to the studio head." |
| Led design, art and engineering on updates; led cross-functional teams | Negative you stated (F9) | "I haven't led a team." No answer slot. |
| Owned the QA release process | Inflated form of F4 | "I wrote the release checklist our QA team still uses." |
| Built the retention model or defined how retention is measured | Inflated form of F7 | "I presented the monthly retention numbers to the studio head." Who built the figures is an answer slot (C2). |
| Has shipped a game with in-app purchases | Negative you stated (F10) | "I haven't worked on a game with in-app purchases." No answer slot. |

## Persona weights

Relationship prior for a hiring-manager round: Case/Strategist and Skeptic dominate (`personas.md`). There is no interviewer profile, so there are no signal adjustments.

| Persona | How it shows up | Likelihood | Counter-strategy |
|---|---|---|---|
| Skeptic (top weight, 5 questions) | "You've never led a team": a probe on your two stated gaps and the cross-team requirement | High. The gaps are the most visible part of the fit snapshot. | Rehear the objection until it is plain. Say the absence, then the nearest thing your material shows, then how you would start. |
| Case/Strategist (5 questions) | Live planning and diagnosis problems on a live-events calendar | High. This is how a hiring manager tests whether you can do the job. | Clarify before structuring. Name what you need to know first. |
| Data-Driven Prober (3 questions) | Questions about how retention was counted and what you can defend | Medium. You have a retention line on your message, and probers go to figures. | Know what you can and cannot say about the figures. Name the weakest assumption you know before it is named for you. |
| Pressure (3 questions) | Time-boxed challenges to your motive and your fit | Medium. Common when a hiring manager is testing composure against a gap. | Pause, restate, anchor in what you stated. Hold a position through two follow-ups before conceding anything real. |
| Conversational (2 questions) | A friendly opener, and a casual question about the mobile landscape | Low to medium. Casual questions are still scored. | A 90-second arc for the opener. Treat the casual question as scored. |

## Question banks

### A. Skeptic (weight: top, 5 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've never led a team. How would you get design, art and engineering to commit to an update date when none of them report to you?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." (your message) | **Highest-ROI prep in this pack.** Hold: "I haven't led a team." Then the nearest thing your material carries: "I wrote the release checklist our QA team still uses." Answer slot: if you have agreed a date with design, art or engineering on an update, say which team, which update and how it was agreed, in your own words; if you have not, say so plainly, and say how you would start: the drop calendar and the release checklist as the dates everyone works to. Hold through two follow-ups by returning to what you did, never by adding to it. | Most predictable objection. It is the JD's cross-team line (F2) meeting your stated absence (F9). The honest answer is a clear concession plus a plan. |
| A2 | "The role runs two titles. Your calendar was for your main title. What would you need to learn about the second before you planned its first month?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | Story-mapped on F1: one main title, two years, weekly drops. The beats are the ones the quote states. The second title is new ground: name what you would ask first (its update cadence, its KPIs, who owns its community) as questions, not as experience. | F1 is the two-title requirement, and the question presses on it. It presupposes only the scope the quote carries. |
| A3 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." (your message) | Name the area in your own words, then the nearest thing you have, quoted. Your stated absences are F9 and F10; the team-coordination requirement is F2. Do not add a third area to look more complete. | An open prompt. Calibrated candor here scores better than a bluff. |
| A4 | "You've said you were comfortable with retention figures. What did the monthly numbers you presented actually measure?" | JD | [grounded] "Presented the monthly retention numbers to the studio head." (your message) | Story-mapped on F7: the figures went to the studio head, and that is the beat the quote states. Answer slot: say what the figures measured in your own words; if you did not produce the calculation, say so and say whose it was. | F7 is the retention requirement and the sentence is short, so the probe goes straight at what it contains. |
| A5 | "Why should a studio with two live titles bet on someone who has run one content calendar and never led a team?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." (your message); "Never led a team, and never worked on a game with in-app purchases." (your message) | Hold the record: "For the last two years I ran the weekly content-drop calendar for our main title." Concede specifically: "I haven't led a team." Then the first 90 days, stated as a plan. | The closing version of A1, asked as a verdict. It tests whether you can hold a fact and concede a gap in the same breath. |

### B. Case/Strategist (weight: high, 5 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Sketch a live-events plan for a mobile title whose retention is falling week over week. What do you need to know first?" | CASE | [generic] | Clarify first: what the retention drop is measured against, what the title's current update cadence is, and what the studio wants from the next three events. Then the objective, the segments that matter, the approach, the metrics you would watch, and the risks. Say the structure aloud. Make no claim about your past. | A live problem from the role's core job. The candidate-side guidance makes no claim about the candidate, so it carries no provenance quote. |
| B2 | "Retention rose on the drop day and fell back within a week. Diagnose it." | CASE | [generic] | Name two or three hypotheses before you analyze: the drop content itself, a concurrent change, a difference between players who came back and players who did not. Say which data would separate them. | A standard live-ops diagnosis. Structure matters more than the answer. |
| B3 | "Two updates land in the same week, one from design and one from engineering, and QA has flagged a blocker on one. How do you decide?" | CASE | [grounded] "I wrote the release checklist our QA team still uses." (your message) | Decide by the release checklist and the blocker's severity, then say who you would need in the room and what you would tell the studio head. You may refer to the checklist as a tool. Do not claim how it was used in a past incident. | Tests the JD's release-checklist line in a live setting. The quote supports only that you wrote the checklist. |
| B4 | "A community team reports a backlash over a limited-time item. What happens in the next 24 hours?" | CASE | [inferred] "coordinate design, art, engineering and community teams on each update" (JD) | Name the first call, the owner of each response, what you would pull, and what you would say publicly and to whom. The JD's community line is the raising source. Keep it to the first day. | Tests cross-team coordination (F2) under pressure. The guidance says what to do, not what you did. |
| B5 | "What is the one KPI you would put in front of the studio head for a live event, and what would make you change it?" | JD | [grounded] "Presented the monthly retention numbers to the studio head." (your message) | Name one KPI and the event it judges. Then the condition that would make you change it. Answer slot: say which KPIs you have reported before and whether you chose them; if you did not, say so. | The JD's post-event KPI line (F3). The answer shows judgment, not only recall. |

### C. Data-Driven Prober (weight: medium, 3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the weekly content drops were measured. What was the denominator?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | Answer slot: if you measured the drops' performance, say what you counted and what it was divided by; if you only scheduled them and tracked them, say that plainly. | A premised question on F6. Scheduling a calendar and measuring drop performance are different things, and the second branch lets the honest answer be the first. |
| C2 | "Which assumption behind the retention figure you presented would you defend least?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." (your message) | The weakest-assumption move. Name the assumption you know of in your own words, before it is named for you. If you did not build the figure, say so, and say whose it was. | F7. No figure is in your message, so this is a slot, not a number to defend. |
| C3 | "Which part of the calendar did you change, and which did you inherit?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | Name what you changed and what came to you already set. If all of it came to you set, say so; the honest answer is not a credential. | Tests attribution, which is what probers check first. |

### D. Pressure (weight: medium, 3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why should we hire you over someone who has led a team?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." (your message) | Pause. Restate the question. Hold: "I haven't led a team." Then the record: "I ran the weekly content-drop calendar for our main title for the last two years." Hold through two follow-ups. Concede specifically, never fold on the core claim. | A hold-then-concede drill. The hold is the record, not a stronger claim. |
| D2 | "That retention number. How much of it was actually you?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." (your message) | Hold what you did: you presented it. Concede what you did not do, specifically, in your own words. Do not claim the figure as yours beyond the presentation. | Tests attribution under pressure. |
| D3 | "We need someone who can make a studio move, not someone who writes checklists. Convince me." | JD | [grounded] "Wrote the release checklist our QA team still uses." (your message) | Hold: the checklist is in use by QA, and that is a fact. Do not argue against the framing; answer the requirement underneath it (the release checklist with QA) and say what you would add to it to move the studio. | Pressure on F4. Do not escalate or grandstand. |

### E. Conversational (weight: low, 2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." (your message) | A 90-second arc, using only the sentences in your message: four years at a puzzle-game studio, the weekly content-drop calendar, the release checklist, the retention numbers you presented. Stop at the present. | A rapport opener that is still scored. The arc must not add a story your message does not carry. |
| E2 | "What are you actually playing on mobile these days, and what would you change about how it is run live?" | CASE | [generic] | Name one game you actually play, and one thing you would change about its live operations, stated as a question you would ask the team. Make no claim about a title you have not worked on. | A casual question on a JD topic (live operations), scored as one. |

## Requirement coverage

| JD requirement | Questions | Notes |
|---|---|---|
| Plan and run the live-events calendar for two of our mobile titles | B1, A2, A5 | |
| Coordinate design, art, engineering and community teams on each update | A1, B4, A3 | |
| Own the post-event review and the KPIs it reports | B5, C2, D2 | |
| Manage the release checklist with QA | B3, D3 | |
| 3+ years producing live-service games or apps | A5, E1 | F5 is a discovery gap; see answer slot. |
| Experience running a content calendar | C3, E1, C1 | |
| Comfortable with player-retention metrics | A4, C2, D2 | |
| Clear written communication | none, and why: the only written artifact in the material is the checklist, and there is no writing sample to test. | Covered by the upgrade menu (writing sample). |

## Reverse questions

Each has a line on why it lands. No interviewer profile exists, so none is tied to Tobias's own career path; there is no peer round, so no reciprocity question is needed.

1. "What does the first 90 days look like for whoever takes on the second title?" Why it lands: it turns a gap into a plan, and it shows you are thinking about the work, not only the job.
2. "How do design, art and engineering agree an update date today?" Why it lands: it asks how the coordination works now, before you say how you would do it.
3. "Which KPI is a post-event review judged on, and what changed after the last one?" Why it lands: it names the requirement (F3) in the interviewer's own terms.
4. "Where does the live-ops producer sit when QA says no on a release?" Why it lands: it asks about the seam your release checklist work sits on.
5. "What would make a first year here a clear success for you?" Why it lands: it lets the interviewer set the bar, which you can then meet.

## Sections dropped

- Values cheat sheet: no values were researched, so no published values exist in this pack.
- Grounding brief and company strategy: no research ran.
- Reading the interviewer: no public information about Tobias was gathered.
- Graded deliverables and delivery coaching: none were declared or provided.
- Prep triage: prep time was not stated.

## Sources

- Provided documents: the job description (pasted) and your background message.
- Searches sent this session: "Saltmarsh Games mobile studio", "Saltmarsh Games company values", "Tobias Wrenfield Head of Live Operations". The host refused permission for all three, so none returned results.

**Research tier:** L1 requested by default; searches 0 of 6 returned results, 3 refused by the host; fetches 0 of 2.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | unavailable | Values cheat sheet (section 10), omitted. The search was refused. |
| 2. Interview process for this role family | unavailable | Loop structure; persona weights follow named rounds. No call was made, because the host refused search. |
| 3. Company strategy and recent news | unavailable | Company and strategy bank (CO questions), omitted. No call was made. |
| 4. Tobias Wrenfield, Saltmarsh Games | unavailable | Reading the interviewer, and a path-tied reverse question. The search was refused. |
| 5. Representative JD for this title | skipped | The job description you supplied fixes the fit snapshot and the JD questions. |

## Upgrade menu

- Permission to search, or a pasted copy of Saltmarsh Games' values page or a recent strategy article → values cheat sheet and current-strategy questions in the company bank (CO)
- Tobias's public profile, talks or posts, or a pasted copy of his LinkedIn summary → reading the interviewer, and a reverse question tied to his own path
- Whether the two titles use in-app purchases → sharper answers on F10 and a monetization question
- Whether the puzzle title kept receiving content after launch → F5 moves from discovery to a grounded answer
- A writing sample, such as a post-event note or the release checklist → F8 moves from medium to high
- The retention figure you presented, with its definition → the defend-the-number slots (C2, D2) become specific
- Your prep time before Friday → a prioritized prep schedule
- Your recruiter's note on the round's focus areas → coverage and round structure fitted to them
