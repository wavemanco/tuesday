Your prep pack is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-tuesday-part-2-rooms-case-1-denied-04f154c3/3306eb66-9ec1-426c-a636-346b9690acb9/scratchpad/Northwind_Senior-GTM-Strategy-Lead_interview_pack.md`. I built it for a peer conversation with Dan, as your note describes.

It has 20 questions across six personas, weighted toward the Prober and the Peer. Each question has a type tag, answer guidance, and a rationale. It also includes a fit snapshot, a prohibited-claims list, reverse questions, and a requirement-coverage table.

The pack is built from your summary, not Priya's CV, so every quoted line is your wording. She should confirm each one in her own words before she rehearses it.

The highest-ROI prep is D1: the sales-strategy credibility question. Dan's home turf is quota and compensation design, and Priya has volume targets but no quota work. The pack has her hold the volume-target work and concede the quota gap specifically, with a ramp plan.

Two things to check before the round:
- The enterprise framing (D3) and the Compass and bundling questions come from your research note, which is undated. If the round never raises enterprise, move D3 to the reverse bank.
- Only one question covers the whitespace requirement (B2). If the full JD adds a whitespace case, that gap is worth closing.

I didn't run any searches; you said you had everything needed.

Could you paste Priya's CV and the full JD text? The pack is usable without them, but her own words would let me upgrade the medium-confidence rows.

I can also run a live drill on D1, or save a `tuesday-dossier.md` recording the gaps this prep exposed. A deeper research pass would add a current strategy brief and Dan's public talks, if you want it. A Word version is available on request.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Northwind_Senior-GTM-Strategy-Lead_interview_pack.md -----
# Interview prep pack: Senior GTM Strategy Lead, Emerging Products, Northwind Data

**Candidate:** Priya. **Interviewer:** Dan Kovac, Director of Sales Strategy. Peer, same VP. **Round:** one 60-minute conversation.

Built from your message only. No CV text and no full JD were supplied, so every evidence quote below is your summary of Priya's background, not her own words. Before rehearsing, she should confirm each quoted line in her own words. Until then, treat each row as medium confidence at most.

## How to use + type key

- **Personas** describe how a question arrives: the delivery style. **Types** describe what is being scored.
- **Guidance is scaffolding, not a script.** Rehearse the beats in your own words. Do not memorise lines.
- Type tags:
  - **EXP**: work-experience deep-dive. Tests whether what she did survives scrutiny.
  - **JD**: role-driven. Tests whether she can do the listed job, gaps included.
  - **CO**: company and strategy knowledge. Tests whether she thinks at the company's altitude.
  - **CASE**: live problem. Tests structure and reasoning.
  - **VAL**: not used. No values-style round is detected for this conversation (see Sources).

## Fit snapshot

Requirements are quoted from your JD highlights, not the full JD. Your research note is quoted as your message. No gate rows: the highlights name no location, work authorization, pay or credential term. The full JD may contain one, and if it does, it will be surfaced as a gate row.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" (your message, JD highlights) | "9 at a large consumer-tech company in product strategy & ops" (your message) | medium | [grounded] | transferability | Adjacent work, not the requirement. The material shows product strategy and ops at a consumer-tech company, not a go-to-market plan for a new line. Say the adjacent work at its own scope, then name the limit. Answer slot: if she set the go-to-market for any launch, say what she decided; if not, say so plainly and say what she did own in product strategy. |
| F2 | "identify whitespace across land/adopt/expand/renew" (your message, JD highlights) | "proposed a store-surface change credited with a ~$400M ARR uplift" (your message) | medium | [grounded] | transferability | The material shows one proposed change and a credited uplift. It does not show a whitespace method across the four stages. Keep "proposed" and "credited with" at their own scope. Answer slot: if she mapped where growth was missing across land, adopt, expand or renew, say how; if the change came from a different kind of analysis, say that. |
| F3 | "run independent analysis in SQL and Tableau" (your message, JD highlights) | "skilled in SQL/Tableau" (your message) | medium | [grounded] | none | Reaches the requirement in role terms, as a self-description with no artifact behind it. Words: "I'm skilled in SQL and Tableau." Expect a probe for a specific analysis. A5 holds it. |
| F4 | "partner-motion design experience required" (your message, JD highlights) | "built a partner-level revenue model used in carrier negotiations" (your message) | medium | [grounded] | transferability | The material shows a revenue model used in negotiations with carriers, which are partner counterparties. It does not show designing a partner motion: terms, incentives or the operating steps that run one. Say the model at its own scope. Answer slot: if she designed partner terms, incentives or operating steps, say which and how she decided; if the work stopped at the model, say so. |
| F5 | "strong cross-functional influence" (your message, JD highlights) | "set annual volume targets with cross-org consensus" (your message) | medium | [grounded] | none | Reaches influence across organizations in role terms. Words: "I set annual volume targets with cross-org consensus." Expect a probe on which organizations agreed and what was contested. Answer slot, see B4. |
| F6 | sales-strategy fluency, inferred from the peer's role title, not a JD line (your message) | "set annual volume targets with cross-org consensus" (your message) | medium | [inferred] | transferability | Volume targets are adjacent to quota and sales-compensation design, which the material does not show. Your message also says there is no classic sales-ops or quota-setting experience. Treat that as the limit to confirm with her. Say the targets at their scope; the quota question is an answer slot (D1). |
| F7 | "AI experience a plus" (your message, JD highlights) | "uses AI tools daily" (your message) | medium | [grounded] | transferability | Daily use is adjacent to building AI features, which the material does not show. Words: "I use AI tools every day." The limit is the pack's observation: use, not product work. Answer slot: if she has shaped an AI feature, evaluated model output for a product, or scoped AI work with engineers, say which; if not, say so and say what she would want to learn about copilot work. |
| F8 | "enterprise expansion" (your message, research note, a company priority and not a JD line) | "built a partner-level revenue model used in carrier negotiations" (your message), which touches enterprise selling without showing it | low | [grounded] | discovery | The material shows no enterprise customer work. Carrier negotiation is the nearest counterpart, and its reach to enterprise selling is unknown. Answer slot only, see D3. |

The gap types follow the routing rule in `output-template.md`: transferability where a quote carries adjacent work, none where a quote already reaches the requirement, discovery where the material is silent. None is `capability`, because she has not stated an absence herself.

## Prohibited claims

Built locally from the fit snapshot. Nothing here is a dossier item. These are the claims the pack will not coach, and each entry gives its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| "I owned GTM strategy for a product line" | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: the material says product strategy and ops, not a launch plan. |
| "I set quotas" or "I ran the sales targets" | Inflated form of F5 and F6 | "I set annual volume targets with cross-org consensus" at its scope. The quota question is an answer slot, D1. |
| "I designed the partner motion" | Inflated form of F4 | The carrier model quote at its scope, with the answer slot in F4. |
| "I drove the $400M" or "I owned the $400M" | Inflated form of F2 | "Proposed" and "credited with", kept as written. Attribution is handled in A1, A2 and E2. |
| "I built AI products" or "I shipped AI features" | Inflated form of F7 | "I use AI tools every day." |

## Reading the interviewer

Public profile only. Career pattern as summarised by you: pricing and monetization roles, then sales strategy, with one early-stage startup chapter. Self-description, quoted from your message: "relentlessly data-driven".

- **Expect the Prober to be up.** Every number she names will be taken back to its assumptions. Have the denominator and the weakest assumption ready for each figure, or say you do not know how it was counted.
- **Pricing is his native language.** Case questions will tilt to pricing, packaging and unit economics. Her carrier-negotiation model is the closest thing to that language, so it is her best entry point.
- **The startup chapter means builder stories will land, and scrappiness will be probed.** Expect "how did you move without process" in some form.
- **Mirror opportunity, shared professional domain only.** Both have worked close to monetization. Pair his pricing background with her carrier-model sentence: "built a partner-level revenue model used in carrier negotiations" (your message, F4). Do not build rapport on shared identity.
- **No shared career jump is claimed.** Her move from consulting to consumer tech is not similar to his path, so the pack does not offer it as a mirror.

## Persona table

| Persona | How it shows up in this round | Likelihood, with reasoning | Counter-strategy | Depth |
|---|---|---|---|---|
| Data-Driven Prober | Asks for denominators, assumptions and the mechanics of the headline figure | High. His self-described "relentlessly data-driven" and her $400M headline together make this the top persona | Know what you can and cannot say about how each figure was counted. Name the weakest assumption before he does | 5 (A1 to A5) |
| Peer Evaluator | Seam-splitting between GTM strategy and sales strategy, credit-sharing, "what would you need from me" | High. A peer round is the prior, and the relationship is the same VP | Reciprocity framing: what she brings his side. Propose seam principles, not a made-up map of his team's work | 5 (B1 to B5) |
| Case / Strategist | Live problems: a bundling threat, a profitability lever, a copilot launch | Medium. His pricing spine tilts cases to pricing and packaging, and the research note supplies live problems | Clarify, objective, segmentation, approach, metrics, risks. Think aloud. Challenge one premise | 3 (C1 to C3) |
| Skeptic | The sales-strategy credibility gap, the partner-motion requirement, enterprise | Medium. The F-rows with gaps are the likely material, and a sales-strategy director is the person most likely to test quota credibility | Rehearse the most predictable objection until it is boring. Concede only what is true | 3 (D1 to D3) |
| Pressure / Stress | Time-boxed challenge on the headline figure and the "why you" question | Low to medium. A peer round rarely time-boxes, but a composure check is possible | Pause, restate the question, hold a position through two follow-ups before conceding anything real | 2 (E1, E2) |
| Conversational / Rapport | Friendly opener and a casual AI question that is scored | Low to medium. Casual questions still score, and the reverse-question slot is weighted | Pre-scripted 90-second arc. Treat the AI question as scored | 2 (R1, R2) |
| Values / Behavioral | Not weighted. No values-style round is detected, and a peer conversation is not a plausible values round | Not plausible for this round. Peer stems in B cover credit and disagreement | None | 0 |

Totals: 20 questions, within the 18 to 26 range.

## Question banks

Question IDs are lettered by persona: A Prober, B Peer, C Case, D Skeptic, E Pressure, R Conversational.

### A. Data-Driven Prober (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how the ~$400M ARR uplift was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (your message) | Defend the number, in her own words. Beats the quote states: the change she proposed, and the uplift as credited to it. Answer slot, how it was counted: if she knows the counting method, describe it; if not, say so plainly and name who owns the number. Weakest-assumption move: name the one she would defend least before he does. Which part was hers: she proposed the change; anything after the proposal only if she did it. | F2 is the headline figure. A prober asks how it was counted first. EXP because it tests attribution. |
| A2 | "Which assumption behind that number would you defend least?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (your message) | Pure weakest-assumption slot. Answer slot: name one assumption she knows of. If she knows none, say she does not know how it was counted and what she would check first. Do not offer a new counting method. | Follow-up to A1 from the Prober persona stem. It converts a gotcha into a credibility gain. |
| A3 | "Walk me through the partner-level revenue model you built for carrier negotiations. How was it built, and which input moved the answer most?" | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" (your message) | Beats the quote states: the model, built by her, used in carrier negotiations. Answer slot, sensitivity: if she can name the input that moved the answer, name it; if she cannot, say so. If she did not own the inputs, say whose they were. | F4 is the closest evidence to his pricing domain. The Prober wants inputs and sensitivity. |
| A4 | "You set annual volume targets with cross-org consensus. What was the baseline, and how did you check it was achievable?" | EXP | [grounded] "set annual volume targets with cross-org consensus" (your message) | Answer slots, baseline and achievability: if she set the baseline, say what it was and where it came from; if it came from elsewhere, say so; if there was no separate check, say so plainly. The premise, that there was a baseline and a check, is held only as a slot with its false branch. | F5 and F6. A target is a figure, so the defend-the-number slots apply. The answer is hers to give, not a quota claim. |
| A5 | "When have you used SQL or Tableau to test a claim someone else was making?" | JD | [grounded] "skilled in SQL/Tableau" (your message) | Open prompt. Theme from the JD line "run independent analysis in SQL and Tableau". If an instance exists, walk through the question, the data, the check and what she handed off. If none, say so plainly and describe how she would test a whitespace claim today. Do not name a dataset she did not use. | F3. The Prober's follow-up will be "show me the query". She should describe the logic, and reproduce a query only if she truly can. |

### B. Peer Evaluator (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our teams sit side by side. Where would you draw the seam between GTM strategy and sales strategy, and what happens when we disagree?" | JD | [grounded] "strong cross-functional influence" (your message, JD highlights) | Propose seam principles, not a map of his team's work. Say what she would take off his plate and what she would leave with him. Answer slot, disagreement: if she has disagreed with a peer team, say how she handled it; if not, say so and say how she would settle a disagreement over a whitespace call. | F5. Seam-splitting between adjacent teams is the peer's core probe. |
| B2 | "How would you split the whitespace work with my team, so the two of us don't run the same analysis twice?" | JD | [grounded] "identify whitespace across land/adopt/expand/renew" (your message, JD highlights) | Reciprocity framing: what her analysis gives his team, such as shared inputs rather than a duplicated model. Name the handoff. Make no claim about his team's current work; he will correct her if she guesses. | The only JD-tagged question on whitespace, so it covers the whitespace requirement. The seam is the peer's home ground. |
| B3 | "What would you need from my team in the first ninety days?" | JD | [generic] | Name the data and the decisions she would need, not favours. Offer what she would bring. Claim nothing about her past. | Classic peer probe. Her answer shows whether she reduces his load or adds to it. |
| B4 | "How do you handle credit when work spans teams?" | EXP | [grounded] "set annual volume targets with cross-org consensus" (your message) | "We" for the consensus, "I" for what she did. If she built the consensus, say so. If she was one voice among several, say that. Do not claim the consensus as hers alone. | Persona stem on credit-sharing. The consensus sentence is the only cross-team evidence in the material. |
| B5 | "Tell me about a time a peer team overruled a recommendation of yours. What did you do next?" | JD | [grounded] "strong cross-functional influence" (your message, JD highlights) | Open prompt. Pick an instance of disagreement with equals, and show spine and tact together. Answer slot: if no instance comes to mind, say so plainly, then give the nearest case her material carries, or how she would handle it. | Peer Evaluator stem on disagreement with equals. The theme comes from the JD line. |

### C. Case / Strategist (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Suppose a much larger platform vendor bundled a competing data product into its suite. How would you respond over the next two quarters?" | CASE | [grounded] "bundling by a much larger platform vendor" (your research note, in your message) | Clarify, objective, segmentation, approach, metrics, risks. Pricing tilt: packaging and unit economics. Challenge one premise, for example whether bundled buyers are the same as her buyers. Name no vendor. Claims nothing about her past. | The main threat in your research note. The question is hypothetical, so it presupposes nothing. Pricing is his native case language. |
| C2 | "Reaching profitability is one of the company's priorities. Which go-to-market lever would you pull first, and which would you leave alone?" | CASE | [grounded] "reaching profitability" (your research note, in your message) | Clarify the profitability target and the time frame. Segment. Name the lever and the cost she would accept. Name one lever she would not touch, and why. Claims nothing about her past. | Unit-economics tilt. "What would you not touch" tests judgment, not just structure. |
| C3 | "The company is launching an AI copilot. How would you position a new product for accounts that already buy the core product?" | CO | [grounded] "an AI copilot launch ('Compass')" (your research note, in your message) | Structure: who buys the copilot and who buys the core, what she would test first, and what she would measure. If she mentions AI use, use only the words in F7. Do not reach past F7 into product experience. | Covers the new-product-line requirement and the AI plus-skill. The honest anchor is F7, not a claim of AI product work. |

### D. Skeptic (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | **Highest-ROI prep.** "Your volume targets were set across the organization. Were any of them tied to someone's pay or goal, and how would you learn the sales-compensation side of a sales-strategy role?" | JD | [grounded] "set annual volume targets with cross-org consensus" (your message) | Deepest rehearsal in the pack. Hold: volume targets are real, and she can describe them, as the quote says. Answer slot: if any target was tied to pay or a goal, say which; if none was, say so plainly and say what the targets did do. Limit named before it is asked: volume targets are not quotas, and the material does not show a quota. Concession: say plainly that quota and compensation design are new to her, then name the one thing she would learn first. Follow-ups to rehearse: "which target missed?", "what would you do if a quota were set too high?", "is that the same as a quota?", "why should I trust you to set one?". Hold through two, then concede only the specific gap. Do not fold to "I'm confident I'd learn it" without a ramp. | The most likely objection. He is a sales-strategy director, and quota and compensation design sit on his home turf. The coach's note is the first thing a skeptic will test. F5 and F6 are the bridge. |
| D2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "partner-motion design experience required" (your message, JD highlights) | Name one area honestly: partner-motion design is the thinnest bridge. The nearest evidence is the carrier model, at its scope (F4). Say what she would do in the first thirty days, and what she would want from his team to close it. Do not name a weakness she does not believe. | Skeptic stem. Partner-motion is the required line with the least evidence behind it. |
| D3 | "Your background is consumer tech. What would you need to learn first about enterprise buyers?" | CO | [grounded] "9 at a large consumer-tech company in product strategy & ops" (your message) | Answer slot for enterprise: if she has sold to or negotiated with enterprise buyers, say how; if not, say so and say what carrier negotiation gives her and where it stops. Do not claim enterprise sales. Say what consumer experience carries over, in her words. | F8, discovery. The enterprise framing comes from your research note, not a JD line. If the round never mentions enterprise, move this question to the reverse bank and drop it from the banks. |

### E. Pressure / Stress (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds, no preamble: why you for this role?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" (your message), "9 at a large consumer-tech company in product strategy & ops" (your message) | Hold-then-concede. Hold the positions the quotes carry: her product strategy and ops work at scale, and the carrier model. Hold through two follow-ups. Concede specifically: the go-to-market line and partner-motion are gaps, and here is how she would close each. Pause before answering. Restate the question if pressed. | Pressure stem for "why you" under time. The held position is what the material carries, not something stronger. |
| E2 | "That $400M. How much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (your message) | Hold-then-concede. Hold what the quote says: she proposed the change, and the figure is credited to it. Answer slot, the share: if she knows how the credit was split, say so; if not, say that she cannot give the share from memory. Two likely follow-ups: "who signed off?" and "what would the number be without you?". Hold through both before conceding anything. | Pressure stem on attribution. A1 covers how the figure was counted. E2 covers how much of it was hers under pressure. |

### R. Conversational / Rapport (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R1 | "So, walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" (your message) | A 90-second arc in her own words: consulting, then consumer-tech product strategy and ops, then the proposal and the carrier model, then why this role. Claim nothing beyond the quotes. | Rapport openers are scored. A pre-scripted arc keeps her from rambling into the Prober's territory. |
| R2 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" (your message) | Name two tools and what she uses each for. Stop there. The honest limit is use, not product build (F7). Answer slot: if she has shaped an AI feature, say so; if not, say what she would want to learn about copilot work. | The JD's plus-skill asked casually. Casual questions are scored, so answer it with the same discipline. |

### Requirement coverage

| Requirement | Question IDs |
|---|---|
| own GTM strategy for two new product lines | C3, E1 |
| identify whitespace across land/adopt/expand/renew | B2 |
| run independent analysis in SQL and Tableau | A5 |
| partner-motion design experience required | A3, D2 |
| strong cross-functional influence | B1, B4, B5 |
| AI experience a plus | C3, R2 |
| sales-strategy fluency (inferred, F6) | D1, A4 |
| enterprise expansion (research note) | D3 |

Only one question covers the whitespace requirement. If the full JD adds a whitespace case, that gap is worth closing.

## Reverse questions

At least five, each with a reason it lands. One is tied to Dan's own path. One is reciprocity.

| # | Question | Why it lands |
|---|---|---|
| Q1 (reciprocity) | "What could a new person do in their first month that would genuinely help your team?" | Signals she plans to add to his load, not take from it. |
| Q2 (his path) | "Your career has been in pricing and monetization, and now sales strategy. What from the pricing work do you use in whitespace calls?" | Turns an interview into a peer conversation. It shows she researched him, not only the company. |
| Q3 | "Which of the current priorities is creating the most planning tension right now?" | Shows where the role's energy goes, and asks for his view rather than a fact. |
| Q4 | "How do you and the GTM strategy group decide who owns a whitespace call?" | A seam question. It shows she thinks about the boundary before she crosses it. |
| Q5 | "How do you test a pricing change before it reaches the field?" | Lands on his strongest ground and invites him to show the rigour he is known for. |
| Q6 | "What would a strong first two quarters look like for the new product lines, from where you sit?" | Gets the success bar stated in his words, so she can be measured against it. |

Do not let the answer to "any questions for me?" be generic. Use Q1 and Q2 by default.

## Sources

- **Provided documents:** your message only. It holds four inputs: the JD highlights, the summary of Priya's background, your research note, and Dan's public profile description ("relentlessly data-driven", plus the career summary in your words). No CV, no full JD, and no dossier were supplied.
- **Searches and fetches sent:** none. Research tier is L0.
- **Values-style round:** not detected. No loop source names a values round, and no published values were supplied. Section 10 is therefore omitted.
- **Loop:** established by your own words, one 60-minute conversation with a peer. No archetype fallback was needed.
- **Dates:** the research note is undated. Its priorities are perishable, so check they are still current.

**Research tier:** L0, no searches run. You said you have everything needed.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Northwind Data values` | unavailable | L0, research declined. Would have fed section 10 only if a values round were detected, and none is, so nothing is lost. |
| 2. `Northwind Data interview process, GTM strategy` | unavailable | L0. The loop is already established by your words, so a search would not have changed the rounds. |
| 3. `Northwind Data strategy` or recent news | skipped | Your research note already gives the three priorities and the bundling threat, which feed C1 to C3. It is undated and not a strategy brief, so the CO bank is thinner than an L2 pass would make it. |
| 4. `Dan Kovac Northwind Data` | unavailable | L0. The interviewer read rests only on the profile text you gave. A public-footprint search would add talks and writing. |
| 5. representative GTM strategy lead JD | skipped | The JD highlights you supplied fix the requirements. |

## Upgrade menu

- **Priya's CV, or her own sentences about the $400M and the carrier model** → every `[grounded]` quote in the fit snapshot becomes her words instead of your summary. Rows with a real artifact behind them can move to high confidence, and the attribution slots in A1, A2 and E2 can be filled with what she actually knows.
- **The full JD text** → the requirement quotes become verbatim. It may also surface gate terms such as location, work authorization or pay, which would be added as gate rows.
- **Her confirmation of each quoted line** → the rows marked medium can be rehearsed as her own story.
- **Dan's public footprint, if you give me his name and the search is allowed** → recurring themes in his talks and writing become likely questions, and the reverse bank gets sharper.
- **A deeper research pass (L2)** → up to 6 more searches and 2 more fetches, several more minutes. It would supply a current strategy brief for the CO and CASE banks, Dan's talks, and role-family loop reports. Want it?
- **Prep time available** → a prioritized triage section, so she knows what to do first.
- **Date of the research note** → confirms whether C1 to C3 are current.
