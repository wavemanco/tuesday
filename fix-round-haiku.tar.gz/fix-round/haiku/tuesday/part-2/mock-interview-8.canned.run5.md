Your prep pack is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-tuesday-part-2-rooms-case-8-canned-eb5d9ac3/9bad75a4-afc0-4891-a019-e901bb8b75cb/scratchpad/ashgrove-credit-union_member-experience-lead_interview_pack.md`. It covers all three rounds, with a shared fit snapshot, 26 questions, and a persona table for each round.

The main things it surfaces:

- **Biggest exposure is the day-one question (R2-B1).** You have never worked in a contact centre and never presented above regional level. The pack gives you plain one-line acknowledgments for both, followed by a 90-day plan. Rehearse that answer first.
- **"Handled the complaints log" won't carry "end to end" or "regulated."** Expect probes on who decided what, and on which timescales the log followed. The pack tells you to answer from your own steps and to say plainly where a step wasn't yours.
- **The values round has no ready-made stories.** Your material doesn't show a member-side decision, a plain-words change, or holding a complaint through to resolution. Three of the four values have scaffolds, not mapped stories. Pick real examples from your branch before 20 November, and only use ones you can narrate step by step.
- **The escalation case (R3-B1) is a live problem.** The pack gives you a clarify-first structure and no claim about your past.

Things to check:

- The strategy figures (40% digital by 2028, eight branches into five hubs, small-business lending in Q1 2027) are from your summary, not the brief. Check them against the document before the panel.
- I didn't run web research. Everything comes from what you sent: the JD, values, recruiter email, and background. The pack lists the interviewers as unnamed, so there's no interviewer read yet.

Offers, not pushed:
- A live drill with me playing the Head of Member Services or a panel member, on whichever question you want first.
- A `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions.
- A Word version of the pack.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove-credit-union_member-experience-lead_interview_pack.md -----
# Ashgrove Credit Union: Member Experience Lead, interview pack (loop mode)

Prepared for Dara. Three rounds on 20 November 2026: recruiter screen (30 min), Head of Member Services (45 min, your future manager), panel of two branch managers (60 min, including a 20-minute complaint-escalation case; this is the values round).

## How to use

Personas describe how a question arrives. Types describe what is being scored: **VAL** values and behavioural, **EXP** your work-experience record, **JD** the stated role, **CO** company and strategy, **CASE** a live problem. Provenance labels: **[grounded]** traces to your material or a provided document, **[inferred]** a derivation, **[generic]** a pattern with no claim about you or Ashgrove. The guidance is scaffolding for a spoken answer, not a script.

## Fit snapshot (shared across rounds)

Sources: the JD you pasted, your message about your background, the recruiter's email, the values text and the July 2026 strategy brief as you summarised it.

No requirement in the JD is a gate (no authorisation, licence, location, schedule, pay or travel term). "4+ years" is a length-of-experience requirement and is graded like the rest.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" (JD) | "6 years in retail banking, the last 3 as a branch supervisor" (your message) | medium | [grounded] | none | No gap. Say the years and the role in those words. Expect a check on it. |
| F2 | "Own the member complaints process end to end across branches and the contact centre" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | transferability | Your material says one branch's log, not the process end to end. Words: "I handled the branch's formal complaints log." Answer slot: the JD's end-to-end line makes a probe on the stages likely. If any stage past the log was yours to set, say which and how you decided. If not, say so, and say what you would take on first. |
| F3 | "experience handling regulated complaints" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | discovery | Your material does not show whether the log ran to regulated timescales or reporting. Answer slot: the JD's "regulated" line makes a probe on the rules the log followed likely. If you worked to a regulatory or ombudsman timescale, or reported on one, say which and how you tracked it. If not, say so, and say how the formal log was run. |
| F4 | "Coach branch supervisors on escalations" (JD) | "trained new tellers on our escalation script" (your message) | medium | [grounded] | transferability | Training tellers is not coaching supervisors. Words: "I trained new tellers on our escalation script." Answer slot: if you coached anyone other than tellers on escalations, say whom and how. If not, say so, and say how you would approach supervisors. |
| F5 | "report monthly on complaint volumes and resolution times" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | medium | [grounded] | discovery | Monthly reporting is shown. Whether the spreadsheet carried volumes and resolution times is not. Answer slot: the JD's resolution-times line makes a probe on the figures likely. If the spreadsheet carried resolution times, say how they were counted. If not, say so, and say what you would add. Medium because the spreadsheet exists and has not been inspected. |
| F6 | "comfortable with Excel reporting" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | medium | [grounded] | presentation | The quote reaches the requirement in other terms: a spreadsheet, not named as Excel. Bridge rewords only that quote: "I built the monthly complaints spreadsheet our regional manager uses." Name the tool only if it was Excel. Add no functions or pivots you did not use. |
| F7 | "Work with digital teams on self-service journeys" (JD) | none given | none | [grounded] | discovery | Nothing in your material touches it. Answer slot: the JD raises it. If you worked with a digital or app team on a member journey, say what you did. If not, say so, and say how you would learn it first. |
| F8 | "confident presenting to senior leaders" (JD) | "I've never presented to anyone above regional level." (your message) | none | [grounded] | capability | A stated absence. Words: "I've never presented to anyone above regional level." Then how you would learn it, as a plan and not a past. Add nothing to make it feel smaller. |
| F9 | "the member complaints process ... across branches and the contact centre" (JD) | "Never worked in a contact centre" (your message) | none | [grounded] | capability | A stated absence. Words: "I have never worked in a contact centre." Then a plan for the contact-centre side of the role. No claim to contact-centre work. |

Gap types follow the routing rule in `references/output-template.md`: F2, F3, F4 and F6 are rows where a quote touches the requirement; F8 and F9 are the absences you stated.

## Prohibited claims (not to be coached)

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end across branches and the contact centre | Inflated form of F2 | F2's quote at its own scope. The limit is the pack's observation: your material says the branch's log, not the process end to end. The slots in R1-C1 and R2-A2 stay inside the log. |
| Handled regulated complaints | Inflated form of F3 | F3's quote at its own scope. The pack's observation: your material says the formal log, not regulated complaints. |
| Coached branch supervisors on escalations | Inflated form of F4 | F4's quote. The pack's observation: tellers, not supervisors. |
| Built the regional complaints reporting | Inflated form of F5 and F6 | The quote at its own scope: a spreadsheet your regional manager uses. |
| Has presented to senior leaders | Negative you stated, F8 | "I've never presented to anyone above regional level." No slot on senior presentation. |
| Has contact-centre experience | Negative you stated, F9 | "I have never worked in a contact centre." |

## Grounding brief (strategy)

Source: the July 2026 strategy brief, as you summarised it. The figures below are your summary, so check them against the brief before the screen.

- 40% of member service moves to digital channels by 2028 [grounded].
- Eight branches consolidate into five hubs over 2027 [grounded]. This is the line that touches complaints most directly, since members of closing branches carry open cases.
- A small-business lending product launches in Q1 2027 [grounded].
- The main competitive pressure is app-only banks [grounded].

Do not coach claims about Ashgrove's plans beyond these lines, and do not speculate about which branches close.

---

## Round 1: Recruiter screen (30 minutes)

Relationship: recruiter. Prior: Conversational plus light Skeptic. Weights: Conversational 4 (A1 to A4), Skeptic 3 (B1 to B3), light probe 1 (C1). No interviewer profile exists, so the prior stands.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R1-A1 | "Walk me through your journey to today." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" (your message) | A 90-second arc: six years in retail banking, the last three as a branch supervisor, the formal complaints log, then why this role. Say only what that sentence states. | Opening question in a screen, scored on economy. F1 is the evidence. |
| R1-A2 | "What do you know about Ashgrove?" | CO | [grounded] the values text and the July 2026 strategy brief, as provided | Name the four values by their words, and the three lines of the brief: digital by 2028, eight branches to five hubs in 2027, small-business lending in Q1 2027. Present them as what you read, not as what you know Ashgrove will do. | The screen is where the CO answer is first heard. |
| R1-A3 | "Why are you looking to move on from branch supervision?" | JD | [generic] | Say what you want more of, in your own words. Do not use the consolidation as the reason unless you can say it without speculating about a branch's future. | Motivation consistency is scored in a screen. No sentence of yours says why, so the guidance makes no claim. |
| R1-A4 | "Have you worked in a contact centre?" | JD | [grounded] "Never worked in a contact centre" (your message) | Plain acknowledgment: "I have never worked in a contact centre." Then say what you did handle, in the log's terms. | F9. The screen checks it early. Short, no spin. |
| R1-B1 | "Your background is branch-based. What makes a role across branches and the contact centre the next step?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" (your message) | Hold the branch experience. Concede the contact centre plainly, once. Do not fold on the link between the two. | Skeptic in a screen: the motivation-consistency check. |
| R1-B2 | "Senior leaders are part of this role. What is the most senior audience you have presented to?" | JD | [grounded] "I've never presented to anyone above regional level." (your message) | Plain acknowledgment: "I've never presented to anyone above regional level." Then name the most senior audience you did present to, and what you covered. The question presumes a presentation at some level, and your quote does not say there was one, so if you have not presented at all, say so. | F8. The second branch is allowed by the premise rule. |
| R1-B3 | "What does the monthly complaints spreadsheet report, and who reads it?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" (your message) | Say what it reports and who uses it, in those words. Answer slot: if it carried resolution times, say how they were counted. If it did not, say so. | F5 and F6. Probers ask this on any reporting line. |
| R1-C1 | "Tell me about the hardest complaint you took from the formal log, from first contact to close." | EXP | [grounded] "I handled the branch's formal complaints log" (your message) | Open prompt: pick one complaint you can narrate step by step. Use "I" for your steps and "we" for the branch's. Answer slot: if a step was someone else's, say whose. If you cannot name a hard one, say so and give the nearest. | F2. The end-to-end requirement starts with the log, so this is the first attribution check. |

Persona table, round 1:

| Persona | Shows up as | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational | Friendly opener, journey question, Ashgrove question | High. Screens open this way, and the risk is treating it as unscored. | Pre-scripted 90-second arc. Treat the casual questions as scored. |
| Skeptic | Motivation and knockout checks | High. The screen's real job is the check on the branch-to-role link and the two absences. | Hold the branch record, concede the absences once, and move on. |
| Light probe | Spreadsheet and log questions | Medium. Reporting is in the JD. | Say what the spreadsheet does, not what it means. |

Reverse questions, round 1:
- "What does a strong first 90 days look like for this role?" Why it lands: you plan in their terms.
- "How is complaints performance reported to leaders today?" Why it lands: a neutral way to learn the reporting shape before round two.

---

## Round 2: Head of Member Services, your future manager (45 minutes, mostly behavioural)

Relationship: hiring manager. Prior: Case/Strategist plus Skeptic. The recruiter says the round is mostly behavioural, so the prior moves toward Values and Skeptic, and there is no case here. Weights: Values/Behavioural 4 (A1 to A4), Skeptic 2 (B1, B2), Pressure 2 (C1, C2).

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R2-A1 | "Tell me about a complaint outcome a member did not want, and how you delivered it." | VAL | [grounded] "I handled the branch's formal complaints log" (your message) | Open prompt: pick one outcome you delivered from the log. Build the story on that sentence. Use "I" for your part. Answer slot: if the decision was not yours, say whose it was and what you did with the member. | Members First, the hard-truth delivery. |
| R2-A2 | "Tell me about a complaint you kept hold of until it was actually resolved." | VAL | [grounded] "I handled the branch's formal complaints log" (your message) | Own the Fix. The quote gives a log, not ownership through to a resolution, so do not describe holding a case to resolution unless you can narrate it. If you cannot, say you handled the log's cases and describe the nearest case you followed through. | "Handled" does not carry "kept hold until solved". This is the value the material does not show. |
| R2-A3 | "When did a decision you made weigh on a branch's place in its town?" | VAL | [generic] | Scaffold: pick a time a local or community effect changed what you did. If none comes to mind, say so, then give the nearest thing a member would notice. | Neighbours, Not Numbers. No sentence of yours carries it, so no story is supplied. |
| R2-A4 | "Tell me about a time you explained a complaint decision in plain words to someone who was upset." | VAL | [generic] | Scaffold: name the decision, the words you used, and what they did next. If you have not had to explain one, say so, then say how you would. | Plain Words. Nothing you wrote carries it. The upgrade menu asks for the story. |
| R2-B1 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Own the member complaints process end to end across branches and the contact centre" (JD); "confident presenting to senior leaders" (JD); "Never worked in a contact centre" (your message); "I've never presented to anyone above regional level." (your message) | Name the contact centre and senior presentation, each as a plain acknowledgment: "I have never worked in a contact centre." "I've never presented to anyone above regional level." Then a 90-day plan for each. Do not pick a third. | Highest-ROI prep in this pack. The two stated gaps are the most likely objection, and a rehearsed, non-defensive answer changes the round. |
| R2-B2 | "You have spent six years in branches. What would you start from on day one in the contact centre?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" (your message); "Never worked in a contact centre" (your message) | Hold the branch years in their own terms. Name what transfers as sentences you have said: the formal log and the escalation script. Concede the contact centre plainly. Answer slot: any member-contact practice the log shows. | F1, F2 and F9. Tests the six years against the contact-centre absence. |
| R2-C1 | "What would you say to a branch supervisor who escalates every complaint to you?" | JD | [grounded] "Coach branch supervisors on escalations" (JD) | Hold that coaching supervisors is the job. Name the one thing you would teach first. Concede plainly that you have trained tellers, not supervisors. | F4. Pressure on the coaching requirement. |
| R2-C2 | "Walk me through who decided what on that formal complaints log, and which rules it ran to." | JD | [grounded] "I handled the branch's formal complaints log" (your message) | Hold: say what you decided, in your own words, and which rules you worked to. If others decided parts, say so. Do not turn "handled" into "decided" or "owned". Answer slot: if no timescale or rule applied beyond the branch process, say so. | The attribution probe and the regulated-complaints check, asked under pressure. Concede specifically. Never fold on what you decided. |

Persona table, round 2:

| Persona | Shows up as | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioural | Scenario questions, STAR-shaped asks | High. Recruiter says the round is mostly behavioural. | One story per value where your sentences carry one; a scaffold where none does. |
| Skeptic | Day-one weakness, transfer question | High. The two absences are in the fit snapshot. | Plain acknowledgment, then the plan. |
| Pressure | Attribution and coaching probes | Medium. Manager-level probes on what you decided. | Hold through two follow-ups. Concede the specific gap. |

Reverse questions, round 2:
- "How do you want this role to handle the branch-to-hub move during 2027?" Why it lands: shows you read the strategy brief, and it is the question a manager wants to answer.
- "Which of the four values do you see most often missing in complaint handling today?" Why it lands: shows you score against the values, and invites an honest read you can use.

---

## Round 3: Panel of two branch managers (60 minutes, incl. 20-minute case; values round)

Relationship: panel of two peers in branch management. Blend of Values/Behavioural (the round is scored against the four values), Case/Strategist (the escalation case) and Peer Evaluator (branch managers are your peers). Weights: Values 4 (A1 to A4), Case 3 (B1 to B3), Peer 3 (C1 to C3).

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R3-A1 | "Tell me about a time you put a member's view ahead of an internal target." | VAL | [generic] | Scaffold: pick a time a member's view changed a decision you took against a target. Name the target and the decision, and say what you gave up. If none comes to mind, say so, then give the nearest thing your log carries. | Members First. No sentence of yours carries a member-over-target decision, so no story is mapped. |
| R3-A2 | "Tell me about something you made easier for a member to follow." | VAL | [generic] | Scaffold: pick a letter, form or script line you changed so a member understood it, and what the member did next. If you have not changed one, say so and name the nearest thing your material carries: the escalation script you trained tellers on. Do not claim the script was plain. | Plain Words. Nothing you wrote carries a plain-words act. |
| R3-A3 | "Tell me about a decision that changed how a branch served its town." | VAL | [generic] | Scaffold: name the town and the decision. If none, say so, then give the nearest. Do not claim community ties you have not described. | Neighbours, Not Numbers, scored by the panel. An honest "not me" is acceptable. |
| R3-A4 | "Tell me about a problem you found that was not yours to fix, and what you did." | VAL | [generic] | Scaffold: name the problem, who owned it, and what you did next. If the nearest case is a complaint you handled, say which part was yours to fix. | Own the Fix. No sentence shows you held anything to resolution, so the scaffold is the honest form. |
| R3-B1 | (CASE, 20 minutes) "A member's complaint about a charge has sat in a branch for three weeks. It has been escalated once. You take it over today. Walk me through what you do, in order." | CASE | [generic] | Clarify first: what the member is owed, what the escalation said, which timescale your firm's policy applies, who holds the file. Then objective, segments (member, branch, the record), approach, metrics and risks. Think aloud. Challenge one premise respectfully. Do not name a deadline you cannot cite. | The panel's case. A live problem with no claim about your past. Structure before answer. |
| R3-B2 | "A branch closes next year and its members move to a hub. Complaints from the closing branch rise in the first month. What do you do in that month?" | CASE | [grounded] Ashgrove strategy brief (July 2026), as you summarised it: "eight branches into five hubs over 2027" | Clarify which complaints move and which stay open. Objective: no complaint lost in the move. Segments: open cases, members who travel, staff who hold cases. Metrics: age of open cases, repeat contacts. Risk: the hand-off. Do not speculate about which branch. | Ties the case to the company's stated direction without asserting a branch plan. |
| R3-B3 | "Branch staff and the contact centre give members different answers to the same complaint. How would you close that gap?" | CASE | [grounded] "across branches and the contact centre" (JD) | Clarify where the answers differ and why. Propose one owner for the answer and one case record. Metrics: repeat contacts, variance in answers. Do not claim you have run a contact centre. | The JD's seam is the raising source. The case is a live problem. |
| R3-C1 | "Our branches and the contact centre sit side by side. Where is the seam, and what happens when we disagree about a complaint?" | JD | [grounded] "across branches and the contact centre" (JD) | Propose seam principles, not facts about their teams: one owner per complaint, one case record. Say what you would bring their branches, not only what you need. Disagreement: scaffold, pick one time you settled a disagreement and say how. | Peer Evaluator. Reciprocity framing, no claim about your past. |
| R3-C2 | "When work on a complaint spans two teams, how do you handle the credit?" | JD | [generic] | Scaffold: name a shared case, who did what, and how credit was shown. If you have not had a shared case, say so and say how you would split it. | Peer credit probe. No sentence of yours speaks to it. |
| R3-C3 | "Walk me through how the monthly complaints spreadsheet counts a complaint as resolved." | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" (your message) | The question presumes a count of resolution, which your quote does not state, so the guidance is an answer slot with an honest second branch. If the spreadsheet counted resolution, say how and what it is sensitive to. If it did not, say so. Name the assumption you would defend least. | F5 and F6 under peer scrutiny on the reporting the JD names. |

Values cheat sheet (round 3, the values round):

| Value (official name) | Working meaning | Mapped story or scaffold |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | No sentence of yours carries a member-side decision. Scaffold: R3-A1, with its honest branch. |
| Plain Words | If a member needs it explained twice, it was written wrong | Scaffold: R3-A2. Nothing carries a plain-words act. |
| Neighbours, Not Numbers | Each branch is part of its town | Scaffold: R3-A3. |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | Scaffold: R3-A4. Do not map "handled" (F2) onto ownership through to a solution. |

Persona table, round 3:

| Persona | Shows up as | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioural | Four value questions, scored | High. The recruiter says the panel is the values round. | One story per value where you have one; a scaffold with its honest branch where you do not. |
| Case/Strategist | The 20-minute escalation case, and the hub and seam cases | High. The panel is weighted to the case. | Clarify, objective, segments, approach, metrics, risks. Think aloud. |
| Peer Evaluator | Seam and credit questions from peers | Medium. Branch managers are your peers and will test what you take from them. | Reciprocity framing. Name seam principles rather than facts about their teams. |

Reverse questions, round 3:
- "What could a new person do in their first month that would genuinely help your branches?" Why it lands: peer reciprocity, and it shows you are asking about their work, not just the job.
- "Where do complaints most often get stuck between a branch and the contact centre?" Why it lands: it shows you understand the seam, and invites an answer you can use.

---

## Requirement coverage

| JD requirement | Questions | Note |
|---|---|---|
| 4+ years in financial-services customer operations | R1-A1, R2-B2 | JD-tagged question R2-B2 |
| Own the member complaints process end to end across branches and the contact centre | R1-C1, R2-A2, R2-B1, R3-C1 | |
| Experience handling regulated complaints | R2-C2 | Detail carried by F3's answer slot |
| Coach branch supervisors on escalations | R2-C1 | Carried by F4's answer slot |
| Confident presenting to senior leaders | R1-B2, R2-B1 | |
| Comfortable with Excel reporting | R1-B3, R3-C3 | |
| Report monthly on complaint volumes and resolution times | R1-B3, R3-C3 | |
| Work with digital teams on self-service journeys | none, and why | No sentence of yours touches it. F7 carries an answer slot, and the upgrade menu asks for a story. |
| Values (four) | R2-A1 to A4, R3-A1 to A4 | Each value has a VAL question in round 2 and round 3 |

## Upgrade menu

- The Head of Member Services' name and the two branch managers' names: persona weights and a tailored reverse question for each round, from their public footprint.
- One complaint from your log told step by step, with who decided each step: turns R2-A1, R2-A2 and R3-A4 from scaffold into story-mapped answers, and tests F2.
- Any regulatory timescale or reporting you worked to: moves F3 from discovery to grounded.
- The monthly spreadsheet, inspected: moves F5 and F6 to high confidence, and names the figures you can defend.
- Any presentation you gave above branch level, or to the regional manager, and what it covered: sharpens R1-B2 and the F8 bridge.
- A member-side decision or a plain-words change you made: turns R2-A3, R2-A4, R3-A1 and R3-A2 from scaffold into story.
- The strategy brief itself, rather than your summary: checks the four grounding lines.
- Deep research (L2), offered once: adds interviewer public talks and writing, role-family loop reports and recent news. Caps: six more searches and two more fetches. I can run it on your say-so.

---

## Sources and target accounting

Provided documents: the JD (pasted); your message about your background; the recruiter's email (pasted); the Ashgrove values text (pasted, copied 11 November 2026 from ashgrovecu.org/about/values); the July 2026 strategy brief, as your summary, not the document itself.

Research tier: L1, searches 0 of 6, fetches 0 of 2. No search or fetch was sent.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | The values text is in your message, so section 10 is fixed by input |
| 2. Interview process, role family | skipped | The recruiter's email fixes the three rounds, their lengths and their formats |
| 3. Strategy and recent news | skipped | Your summary of the July 2026 brief fixes the grounding lines. The figures still need checking against the brief |
| 4. Interviewer name and company | n/a | No names given, so there was no query to form. The interviewer read is absent |
| 5. Representative JD | skipped | The JD you pasted fixes the fit snapshot |

Sections omitted: the interviewer read (no names), delivery coaching (no assessment), and the prep triage (no prep time given). Loop mode applies because three rounds are on the calendar.
