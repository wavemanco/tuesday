Your prep pack is saved as /tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-tuesday-part-2-rooms-case-4-denied-124a9d58/6be4e078-4d58-488d-acf6-b09de05de50f/scratchpad/quartzline_product-manager-platform-apis_interview_pack.md. I built it for a hiring-manager round, which is what you described. The interviewer's name isn't in it.

Two things to know before you rely on it:

- **The dossier is three months old.** It's dated 2026-08-14. Check the posting against its requirements before Thursday.
- **The dossier doesn't grade R2 ("shipped API or platform products").** It's a must-have, but it isn't in the weak-areas list. The evidence you have is integration work, not shipping a platform, so I graded R2 as a transferability gap myself. The underwriter should confirm or correct that.

Web research didn't run. The one search I attempted was refused because permission to use WebSearch wasn't granted, so the pack has no company-specific values, interview-process, or strategy questions.

Offers, not pushed:
- I can play the Skeptic on A1, the question the pack names as your highest-value prep: "You have never held the PM title or owned a roadmap — why should we hire you into one?"
- I can save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
- If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quartzline_product-manager-platform-apis_interview_pack.md -----
# Interview prep pack: Product Manager, Platform APIs at Quartzline

Round: hiring-manager conversation, 45 minutes, Thursday 2026-11-12. Interviewer name not given. Built from the underwriting dossier (conditional_go, dated 2026-08-14). Research did not run; see Sources.

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what it scores.
- Type key: **EXP** = your past work, checked for attribution. **JD** = a stated responsibility or requirement. **CASE** = a live problem from the role, no claim about your past.
- Guidance is scaffolding, not a script. Say it in your own words, and say only what your quotes carry.

## Fit snapshot

Requirements come from the dossier's role_profile, which stands as the supplied JD. Evidence is quoted from the dossier's verified_candidate_evidence and uncertain_or_weak_areas. The grading is the pack's, from those entries.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| R1 | "3+ years product management experience" (dossier role_profile, must_have) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier row); "Ran quarterly roadmap-input sessions feeding client evidence to product" (dossier row) | low | [inferred] | transferability | Your material shows integration work and input to product, not PM years. Bridge, with the limit named: "I led 30+ end-to-end client integrations of the vendor's REST APIs. I ran quarterly roadmap-input sessions that fed client evidence to product. I haven't held a product manager title or role." The last sentence is the plain acknowledgment, sourced to the dossier's prohibited_claims. Bridge follows the dossier's allowed strategy: bridge. |
| R1b | Owning a roadmap and prioritization authority (dossier uncertain_or_weak_areas, R1 sub-claim) | none given; the roadmap-input quote feeds product and does not show ownership (dossier row) | none | [grounded] | capability | Plain acknowledgment, sourced to the dossier's prohibited_claims and uncertain_or_weak_areas (acknowledge_gap): "I haven't owned a product roadmap, and I haven't set prioritization for an engineering squad." Then a ramp plan, said as a plan and never as a past. No bridge here. |
| R2 | "Shipped API or platform products" (dossier role_profile, must_have) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier row) | high | [inferred] | transferability | Limit observed in analysis: the material shows integrations of the vendor's REST APIs, not a shipped platform product. The dossier does not grade R2; this grading is the pack's. Words: "I led 30+ end-to-end client integrations of the vendor's REST APIs." Then stay inside that quote's scope. |
| R3 | "Technical fluency: API docs, schemas" (dossier role_profile, important) | none given; "Wrote the internal integration playbook her team uses" (dossier row) does not show whether it covered API docs or schemas | low | [grounded] | discovery | Answer slot: if you read or wrote API docs or schemas as part of the integrations, say which and what you checked. If you did not, say so plainly and say how you would check a schema before a partner goes live. |
| R4 | "Stakeholder management across engineering, sales, customers" (dossier role_profile, important) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier row); "Ran quarterly roadmap-input sessions feeding client evidence to product" (dossier row) | medium | [grounded] | discovery | The quotes reach clients and product. Engineering and sales are not shown. Caveat for the roadmap sessions: limited inspectable proof, so expect a probe. Answer slot: if you worked with an engineering lead or sales on an integration, say what the disagreement was and how it resolved. If you did not, say so plainly and stay with clients and product. |
| R5 | "Agile delivery experience" (dossier role_profile, preferred) | none given. No verified entry speaks to this requirement. | low | [grounded] | discovery | Clarify. Answer: if you have delivered work with an engineering team in this way, say how. If not, say so plainly and say what you would want to confirm about how this team defines agile delivery. |

## Persona table

| Persona | How it shows up in this round | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Probes the must-haves: R1 transfer, R2 shipped product, the roadmap gap | High. Hiring managers buy derisking (relationship prior), and the dossier names the objection | Rehearse A1 until it is boring. Bridge only from quoted entries. Plain acknowledgment, then a ramp plan |
| Case/Strategist | Live problems on partner API adoption, squad sequencing, partner feature requests | High. Hiring managers test on their actual roadmap (relationship prior) | Clarify before structuring. Ask for the baseline. No claims about past ownership |
| Data-Driven Prober | Counts the 30-plus integrations and what the roadmap sessions changed | Medium. The record carries two numbers a prober will test | Defend-the-number answer slots. Name the weakest assumption before it is named for you |
| Pressure | "How much of that was actually you?" | Medium. Time-boxing is plausible in 45 minutes | Hold the quoted claim through two follow-ups. Concede specifics, not the core |
| Conversational | Opens with a walk-through; casual questions on API docs and stakeholders | Medium. A 45-minute round usually opens this way | 90-second arc. Treat casual questions on JD topics as scored |
| Peer Evaluator, Values/Behavioral | Not banked | Not plausible for a hiring-manager round, and no values round is detected | None |

Weights: Skeptic 4 questions, Case/Strategist 5, Data-Driven Prober 3, Pressure 3, Conversational 3. Total 18.

## Question banks

### A. Skeptic (4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier row); "Ran quarterly roadmap-input sessions feeding client evidence to product" (dossier row); the question is the dossier's likely_interviewer_objections, which the underwriter named; the negatives are sourced to the dossier's prohibited_claims | Highest-ROI rehearsal in this pack. Open with the plain acknowledgment: "I haven't held a product manager title or owned a product roadmap." Then the strongest quote at its own scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs." Name the limit yourself: those are not PM years. Then a plan, not a past: in the first 90 days, learn the decision split with the two squad leads, agree the adoption baseline before setting any target, and run one partner discovery cycle end to end. Hold through two follow-ups by returning to the integrations and the limit. Concede exactly what is missing. Never argue that integrations equal PM years. | The underwriter named this objection, and it tests R1. The negatives are sourced, so the question is asked as the dossier wrote it. |
| A2 | "Which roadmap decisions would you make alone on this platform, and which would you take to the squad leads?" | JD | [grounded] "Own the roadmap for the partner-facing API platform" (JD, dossier role_profile); the decision-authority unknown (dossier unknowns) | Hypothetical about the role, so there is no past claim to quote. Give a principled split: what you would decide (for example, timing of partner-facing changes), and what goes to the squad leads (sequencing across the two squads). Say you would confirm the split with the leads before committing to it. A proposed split is not an authority you already hold. | Tests the decision-authority risk that the JD asserts without evidence. The answer is the most important unknown in the role. |
| A3 | "Walk me through how you'd run delivery with two engineering squads that report to their own leads." | JD | [grounded] "Write specs and drive delivery with two engineering squads" (JD, dossier role_profile) | Answer slot: if you have delivered work with an engineering team, say how, in your own words. If you have not, say so plainly and say what you would do first. | Covers R5 through the clarify strategy. The second branch allows that the practice never existed. |
| A4 | "Tell me about an API or platform product you've shipped, end to end." | JD | [grounded] "Shipped API or platform products" (JD, dossier role_profile R2); nearest instance, [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier row) | Open prompt, so you choose the instance. The nearest honest instance is the integrations, at their own scope, through the stages in the quote. Answer slot: which decisions within those integrations were yours, in your own words. If no such product comes to mind, say so plainly, then give the integrations. Do not describe an API product as shipped. | R2 is a must-have that the dossier does not grade (see Sources). This is where the interviewer tests it. |

### B. Case/Strategist (5 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Sketch the first 90 days on partner API adoption. What do you need to know first?" | CASE | [grounded] "Define and track adoption metrics" (JD, dossier role_profile) | Clarify first: the current baseline and how adoption is measured today, both unknown in the dossier. Then objective, segments, approach, metrics, and risks. No claim about your past. | Adoption is a stated responsibility. Asking for the baseline scores on structure. |
| B2 | "Partner API adoption has been flat for a quarter. How would you diagnose it?" | CASE | [grounded] "Define and track adoption metrics" (JD, dossier role_profile); "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier row) | Segment partners by where their integrations stall, using the stages in your quote at their own scope. Name two hypotheses before choosing one, and say what data would separate them. | Your integration stages are the one place your material has a sequence to reason from. |
| B3 | "Two engineering squads disagree on sequencing a partner-facing deprecation. How do you decide?" | CASE | [grounded] "Write specs and drive delivery with two engineering squads" (JD, dossier role_profile) | Clarify who owns the sequencing call. Propose a decision rule (partner impact, squad capacity, deadline), then say who you would take it to. Do not claim to have decided this before. | Decision authority is unknown. The answer shows judgment without asserting authority. |
| B4 | "A partner asks for a feature that would take a squad a full quarter. What do you do?" | CASE | [grounded] "Run discovery with integration partners" (JD, dossier role_profile) | Separate the need from the feature. Test the need with two or three other partners. Bring a recommendation to the roadmap owner, and say who that is on this team. | Discovery with partners is a stated responsibility. This tests the authority gap live. |
| B5 | "Which partner-facing API metric would you put on the roadmap first, and what would it be blind to?" | CASE | [grounded] "Define and track adoption metrics" (JD, dossier role_profile) | Name one metric with its denominator, then what it misses. The blind spot is your weakest assumption, named before the interviewer names it. | Forces a metric with a denominator, and tests whether you name its limits. |

### C. Data-Driven Prober (3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the 30-plus integrations were counted." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier row) | Answer slot. Say how it was counted, in your own words, and what the count is sensitive to. If you do not know how it was counted, say so. The pack does not supply a counting method. | Headline number, so it gets the defend-the-number slot. Only the count is asked. |
| C2 | "Which assumption behind that count would you defend least?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier row) | Name it in your own words before the interviewer does. Nothing in your material names an assumption, so this is an answer slot: if you can name one, say it. If you cannot, say so and what would check it. | The weakest-assumption move turns a gotcha into a credibility gain. |
| C3 | "The roadmap-input sessions fed client evidence to product. What did product do with it, and how would you know it worked?" | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" (dossier row; medium confidence, limited inspectable proof) | Name the caveat first: you ran the sessions, and your proof of what product did with them is limited. Answer slot: if you know what product did with the evidence, say what, and how you know. If you do not, say so plainly. Do not say the sessions shaped a decision unless you know they did. | Medium confidence, and the dossier says to expect a probe. Volunteer the limit before it is extracted. |

### D. Pressure (3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "That 30-plus number — how much of it was actually you?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier row) | Hold: "I led them" is the quote's claim, and you can stand on it. Hold through two follow-ups before any concession. Concede specifically: name which stage decisions were yours and which were set by others. Answer slot: if you decided scope or architecture on an integration, say which. If others set them, say so plainly and say what you led. | Tests whether the hold rests only on what the quote carries. |
| D2 | "What, if anything, did you decide in the roadmap-input sessions?" | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" (dossier row) | Hold the distinction: you ran the input sessions, and input is not a decision. Answer slot: if you decided something in them, say what. If you did not, say so plainly, and say what the sessions did do. | Separates input from authority under pressure. |
| D3 | "You haven't owned a roadmap. Convince me you can own one in two minutes." | JD | [grounded] plain acknowledgment sourced to the dossier's prohibited_claims item "Having owned a product roadmap" | Do not argue for ownership. Say the plain acknowledgment once. Then the 90-day plan, said as a plan. Concede the specific gap: decision rights and prioritization you have not held. | The question asks for a claim the record does not carry. The honest hold is the limit. |

### E. Conversational (3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So — walk me through the journey to here." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier row); "Wrote the internal integration playbook her team uses" (dossier row); "Ran quarterly roadmap-input sessions feeding client evidence to product" (dossier row) | A 90-second arc: the integrations (first quote), the playbook (second), the roadmap-input sessions (third), then what you want next. The arc makes no ownership claim. | The opener is scored. |
| E2 | "What are you playing with in API docs and schemas these days?" | JD | [grounded] "Technical fluency: API docs, schemas" (JD, dossier role_profile R3) | Answer slot: if you have worked in API docs or schemas, name the work in your own words. If not, say so plainly and what you would read first. | R3 is important, and no verified entry speaks to it. The casual register is still scored. |
| E3 | "Tell me about a time a customer and an engineering lead wanted different things from an integration." | JD | [grounded] "Stakeholder management across engineering, sales, customers" (JD, dossier role_profile R4); nearest instance, [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier row) | Open prompt, so choose a real instance. If it involves an engineering lead, say what they wanted, what the customer wanted, and what you did. If none involves engineering, say so plainly and give the customer-facing instance. Do not invent a disagreement. | R4's engineering and sales side is untested in the record. |

## Requirement coverage

| Requirement | Questions |
|---|---|
| R1, 3+ years PM experience | A1, A2, D1, D3 |
| R1b, roadmap and prioritization authority | A1, A2, D3 |
| R2, shipped API or platform products | A4 |
| R3, API docs and schemas | E2 |
| R4, stakeholders across engineering, sales, customers | C3, E3 |
| R5, agile delivery | A3 |
| JD responsibilities: partner discovery | B4 |
| JD responsibilities: squads | A3, B3 |
| JD responsibilities: adoption metrics | B1, B2, B5 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| RQ1 | "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" | Tests the decision-authority risk the JD asserts without evidence. This is the most important unknown. |
| RQ2 | "How is partner API adoption measured today, and what is the current baseline?" | The JD names adoption as a responsibility and states no baseline. Asking reads as diligence. |
| RQ3 | "What would make this hire a clear success at 90 days?" | The JD does not state success criteria. The answer tells you what you are being hired to fix. |
| RQ4 | "How does partner discovery run today, and who is in the room?" | Discovery with partners is a stated responsibility. The answer shows how the work is really done. |
| RQ5 | "What does the delivery rhythm between the PM and the two squads look like right now?" | Tests R5 from the other side. It shows what agile delivery means in this team. |

No interviewer profile exists, so no reverse question ties to the interviewer's path. This is a hiring-manager round, not a peer round, so no reciprocity question is included.

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | Sourced: dossier prohibited_claims | "I haven't held a product manager title or role." The quote at its own scope sits beside it. No slot |
| Having owned a product roadmap | Sourced: dossier prohibited_claims and uncertain_or_weak_areas (acknowledge_gap) | "I haven't owned a product roadmap." The roadmap-input quote stays at its own scope: input to product, not ownership |
| Having set prioritization for an engineering squad | Sourced: dossier prohibited_claims | "I haven't set prioritization for an engineering squad." No slot |
| Shipped API or platform products | Inflated form of the integrations quote | The integrations quote at its own scope. The limit is the pack's observation: the material shows integrations, not a shipped product. A4's slot stays inside the quote |
| Owned the adoption outcomes of those integrations | Inflated form of the integrations quote; the outcome is not in any quote | The integrations quote at its own scope. C1 asks only how the count was made |

## Sources

- **Provided documents:** tuesday-dossier.md, dossier_version 1.1, generated 2026-08-14 by job-underwriter. Sections consumed: role_profile (as the supplied JD), handoff_to_mock_interview (verified evidence, weak areas, objection, risks, employer questions, prohibited claims), and decision (context only). Not present: evidence_map, risk_register, evidence_state, candidate_constraints. Grading in the fit snapshot therefore comes from the handoff's entries.
- **Dossier age:** the dossier is about three months old and the JD may have changed. Check the posting against the requirements before Thursday.
- **Discrepancy:** the dossier lists R2, shipped API or platform products, as a must-have. It does not grade R2 in uncertain_or_weak_areas, and its verified evidence does not speak to shipping. The pack grades R2 as transferability, labeled [inferred], and the underwriter should confirm or correct that.
- **Not used:** the dossier's decision prose mentions seven years of integration leadership. No quoted entry carries that number, so no guidance uses it.
- **Research tier:** L1, searches 1 of 6, fetches 0 of 2. One search was sent: "Quartzline Product Manager Platform APIs interview process". It was refused because permission to use WebSearch was not granted. Nothing was fetched.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quartzline values | unavailable | Values cheat sheet, section 10. Not triggered: no values round is detected, so this would not have moved the pack |
| 2. Quartzline interview process | unavailable | The one search sent; refused. Would have moved loop structure and persona weights. The pack assumes a single hiring-manager round, since none is stated otherwise |
| 3. Quartzline strategy and recent news | unavailable | CO bank. Not present, so the pack has no company-specific questions |
| 4. Interviewer name | n/a | No name was given, so there is no query. The interviewer read is absent |
| 5. Representative JD | skipped | The dossier's role_profile fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The interviewer's name → an interviewer read, persona weights from their public footprint, and a reverse question tied to their career path.
- Permission to search (WebSearch) → the company's values, interview process, and current strategy. That would also check whether the posting still matches the dossier.
- The current JD text → confirms the requirements in the fit snapshot. The dossier is three months old.
- Your CV → A4 and E3 would be grounded in more than the integrations line. R3 would upgrade from discovery if the CV names API docs or schema work.
- What product did with the roadmap-input sessions → R1b's plan and C3's caveat become grounded, if you can name an outcome you inspected.
- Prep time before Thursday → a prioritized prep schedule, with the most important questions first.
