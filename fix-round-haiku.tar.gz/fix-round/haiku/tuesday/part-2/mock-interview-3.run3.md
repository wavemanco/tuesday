Your prep pack is saved as /tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-tuesday-part-2-rooms-case-3-denied-fc7367f8/54a08803-595f-4ed3-9949-f58b0ace6735/scratchpad/stripe_product-operations-manager_interview_pack.md. I built it for a final round, since your note didn't say who you're meeting or how many sessions there are.

The pack is generic for now. I had no job description, CV, or round details, and web search was refused (the permission wasn't granted), so I couldn't check Stripe's values, interview loop, or recent strategy. Everything is labeled `[generic]`. The pack has 18 questions across seven interviewer styles, a fit snapshot built from six typical Product Operations requirements, a reverse-questions list, and a coverage map. The highest-value prep is question B2, "Walk me through an operating process you designed from scratch. What part of it was yours?" Interviewers at this level often press on exactly that, so rehearse the honest version of your answer.

Three things would make it specific:

1. Who are you meeting in the final, and is it one session or several?
2. Can you paste the job description and a CV or a few bullets about your work?
3. Does the posting list any hard requirements, such as location, work authorization, or a certification?

If you grant search permission, I can re-run the research and pull Stripe's published values, the interview loop, and recent strategy into the pack.

Happy to run a live drill on B2 next, or save a `tuesday-dossier.md` to carry the gaps this prep exposed into later sessions. I can also convert the pack to Word.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: stripe_product-operations-manager_interview_pack.md -----
# Stripe: Product Operations Manager, final round: interview prep pack

**Built without:** a job description, a CV, the round's format, or the interviewer's name. Web research was refused (search permission not granted), so Stripe's values, loop and strategy are not established here. Everything below is labeled `[generic]` and should be checked against the real posting and Stripe's own pages before you rely on it.

## How to use

- **Personas** are how a question is asked. **Types** are what is being scored: VAL (values), EXP (your experience), JD (the role), CO (company knowledge), CASE (live problem).
- Guidance is scaffolding, not a script. Rehearse the shape out loud, in your own words.
- Answer slots (sentences with "if you did X…, if not, say so") are instructions for the interview, not questions to answer here.

## Fit snapshot (worksheet variant: no CV, no JD)

Requirements are role-family requirements written from no source, so they are plain `[generic]` prose and raise no answer slot. Every evidence cell is `none given`.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Lead work across functions without formal authority (role family) | none given | none | [generic] | discovery | Strong evidence: one cross-team effort you drove, with the teams, the decision, and what you did yourself. Selection scaffold: pick a time you moved a project across two or more teams that did not report to you. If no such time comes to mind, say so plainly, then give the nearest thing you did and how you handled it. |
| F2 | Design and scale operating processes as a company grows (role family) | none given | none | [generic] | discovery | Strong evidence: a process you created or changed, what it replaced, and how you know it helped. Selection scaffold: pick a process you designed or materially changed. If you did not design one, say so plainly and describe the nearest process you ran or improved. |
| F3 | Define and track operating metrics, and explain them to leadership (role family) | none given | none | [generic] | discovery | Strong evidence: a metric you chose, how it was counted, and a decision it informed. Selection scaffold: pick a metric you reported on regularly. If you did not choose it or did not report on it, say so and describe your actual reporting. |
| F4 | Write and present decisions, tradeoffs and status to senior leaders (role family) | none given | none | [generic] | discovery | Strong evidence: a memo or review you wrote or presented, and what was decided. Selection scaffold: pick a recommendation you put in front of senior leaders. If none, say so and describe the nearest written or verbal update you owned. |
| F5 | Judge when to build internal tooling or workflow versus buying or asking another team (role family) | none given | none | [generic] | discovery | Strong evidence: a build-or-buy call you made and why. Selection scaffold: pick a tool or workflow decision you were part of. If you were not part of one, say so and describe how you would decide. |
| F6 | Take an unscoped problem and define it before solving it (role family) | none given | none | [generic] | discovery | Strong evidence: a vague problem you turned into a scoped one, and what you cut. Selection scaffold: pick a problem that arrived without a clear owner or definition. If none comes to mind, say so and describe the nearest one. |

## Prohibited claims

No candidate sentence exists yet, so no inflated form can be listed. The standing rule for this pack: do not claim a process, metric, owner role or outcome you cannot describe in full, meaning who was involved, what you did, and how it was measured. If you cannot, use the honest branch in the answer slot.

## Persona weights

Round type and relationship are unknown, and the final round's schedule is unknown, so this is a session-mode pack with blended weights. Each persona is included because a final round may contain several interviewers.

| Persona | Weight | Why | Counter-strategy |
|---|---|---|---|
| Case / Strategist | Highest | Product ops finals usually test how you would run a live problem. Hiring-manager and skip-level rounds lean this way. | Clarify, then structure, then answer. Name one premise you would challenge. |
| Skeptic | High | Finals press the gap between the role and your history, which is where the most predictable objection lives. | Rehearse the single most predictable objection until it is plain. Concede the gap precisely. |
| Values / Behavioral | Mid | Many final loops include a scored behavioral conversation. Stripe's values are not verified here. | STAR-shaped stories, "we" for context and "I" for your part. |
| Data-Driven Prober | Low-mid | Any metric on your CV or in your answers will be probed. | Say how each number was counted, and name its weakest assumption. |
| Peer Evaluator | Low-mid | If a peer is in the loop, the question is what the hire adds to their load. | Reciprocity: what you bring to their team. |
| Pressure / Stress | Low | Used by some skip-level interviewers. | Pause, restate the question, hold a position through two follow-ups. |
| Conversational | Low | Opens and closes can be scored. | Prepare a 90-second arc and a real answer to "any questions?" |

Depth follows weight: 4 Case questions, 3 Skeptic, 3 Values, 2 each for the rest. Total: 18.

## Requirement coverage

| Requirement | Covered by | Note |
|---|---|---|
| F1 cross-functional leadership | A2, C1 | |
| F2 process design and scale | A2, A3 | |
| F3 metrics and reporting | D1, D2 | |
| F4 senior communication | A2, P2 | |
| F5 build versus buy | none, and why | No tooling detail is in hand to rehearse. Adds when the JD arrives. |
| F6 unscoped problems | A1, B1 | |

## Question banks

### A. Case / Strategist (weight: highest, 4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Support tickets about a payment flow rose 30% last month. How would you work out what's happening?" | CASE | [generic] | Clarify the metric and time window. Segment by region, product and customer type. State two or three hypotheses, the data that would separate them, and who you would ask. Propose an owner for the fix. Speak in about 2 minutes. | Live problem typical of operations roles. The scenario is invented and asserts nothing about your past. |
| A2 | "You have six weeks to stand up an operating review for a launch that involves engineering, finance and legal. What is in it?" | CASE | [generic] | Structure: purpose, owners, cadence, the three to five metrics, the decision rights, and the escalation path. Name what you would confirm with each function first. | Tests F1, F2 and F4 in one scenario. |
| A3 | "Two teams disagree on a process change. One wants a weekly review and one wants async updates. How do you decide?" | CASE | [generic] | Ask what the process is for and what each team is optimizing for. Propose a time-boxed test with a measure both teams accept. Say who makes the call if the test is inconclusive. | Tests F2 and F5 as a decision, not a record. |
| A4 | "What would you do in your first 30 days in this role?" | JD | [generic] | Listen, map the current processes and owners, find the two or three most painful handoffs, and agree on what success means with your manager. Do not promise a redesign. | Standard hiring-manager opener, and it checks whether you understand the role's scope. |

### B. Skeptic (weight: high, 3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this job would you be weakest at on day one?" | JD | [generic] | Name one real area, not a humble-sounding strength. Explain how you would close it within the first quarter. Do not claim experience you cannot describe. | Calibrated candor. Interviewers distrust answers with no weakness. |
| B2 | "Walk me through an operating process you designed from scratch. What part of it was yours?" | EXP | [generic] | Highest-ROI prep in this pack. Pick the process, the problem it solved, the people you worked with, the decision you made, and what happened. Answer slot: if you designed it, say which decisions were yours and how you made them. If you did not design it from scratch, say so plainly, then describe the process you did change or run. Hold through two follow-ups by returning to what you did, not by adding detail. | This is the most predictable objection: the product ops role is about designing things other people run, and the attribution question tests that directly. It is pressed hardest where no CV line has been checked yet. |
| B3 | "Why leave where you are, and why this role?" | EXP | [generic] | Give a reason about the work, not about the employer's reputation. Make it consistent with your answer on what you want next. Keep it under 90 seconds. | Motivation consistency. Skeptics probe whether the story holds together. |

### C. Values / Behavioral (weight: mid, 3 questions)

Stripe's published values are not verified in this pack. These questions are generic and will be retuned when the values are pulled from Stripe's own pages.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you pushed back on a decision from someone senior." | VAL | [generic] | Open prompt. Pick a case where the stakes were real and you did not fold. Give the context briefly, what you argued, what you did next, and how the relationship ended. Answer slot: if no such time comes to mind, say so plainly, then describe the nearest disagreement you handled. | Scored behavioral conversation. The honest branch is part of the answer. |
| C2 | "Tell me about a process you owned that failed. What happened?" | VAL | [generic] | Open prompt. Say what failed, what you missed, what you changed, and how you know the change worked. Answer slot: if nothing you owned failed, say so, and describe a failure you were close to. | Tests honest self-assessment. Interviewers listen for ownership without blame-shifting. |
| C3 | "When did you put a customer or user ahead of an internal metric?" | VAL | [generic] | Open prompt. Name the metric, the customer impact, the decision, and the result. Answer slot: if you have not faced this trade-off, say so and describe how you would weigh it. | Tests customer-first thinking, which is common across values lists. |

### D. Data-Driven Prober (weight: low-mid, 2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Pick a metric you're proud of. How was it counted?" | EXP | [generic] | Say what the metric measured, the data source, the time window, and what was excluded. Name the weakest assumption before the interviewer does. Answer slot: if you chose the metric, say how; if you did not, say so and say who did. | Probers test whether a number survives its method. |
| D2 | "How would you know an operating change you made actually worked?" | JD | [generic] | Name a leading and a lagging indicator, a baseline, and what would count as no effect. Say what you would do if the metric moved for an unrelated reason. | Tests F3 without asking for a past result. |

### E. Peer Evaluator (weight: low-mid, 2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Our finance and product operations overlap on launch readiness. Where is the seam, and what happens when we disagree?" | CASE | [generic] | Propose a seam principle, not a fixed boundary: who owns the decision, who owns the data, and how disagreement goes to a decision-maker. Do not claim to know their team's workflow. | Peer probes come collegially. The answer shows you respect the seam. |
| E2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Name the people, what each contributed, and how you made sure the credit was accurate. Keep it short. | Peer probe on fairness and turf. |

### P. Pressure / Stress (weight: low, 2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Sixty seconds: why you over someone who has already done this exact job?" | EXP | [generic] | Pause, then answer in three parts: the specific strength you bring, what you would learn fastest, and why that trade-off is worth it. Hold the first position through two follow-ups. Concede a gap precisely, and do not fold on the core claim. | Tests composure under a time box, not content. |
| P2 | "That process sounds like it mostly slows people down. Convince me otherwise." | JD | [generic] | Do not defend the process by reflex. Say what it protects, what it costs, and what you would measure to decide whether to keep it. Hold the core claim, concede the cost. | Tests whether you can defend a position without becoming defensive. |

### G. Conversational (weight: low, 2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through your journey." | EXP | [generic] | A 90-second arc: where you started, the one or two turns that shaped your work, and where you are going. Stay in the first person and keep it verifiable. | Casual openers are still scored. |
| G2 | "What are you reading or working on lately that's relevant to how companies run their operations?" | CO | [generic] | Name one or two real things, with one sentence on what you took from them. Do not name anything you have not read. | Casual register, but a scored question about your homework. |

## Reverse questions

Each question has a reason it lands. Check each one against Stripe's own pages before you ask it.

1. "What would a strong first six months in this role look like, and what would make it go badly?" Lands because it shows you plan to be measured against the role's real success conditions.
2. "Which operating problem is most urgent for this team right now?" Lands because it shows you want to work on the real problem, not a generic one.
3. "How does the team decide between building a process and asking another team to own it?" Lands because it signals you understand the build-versus-own tension that product ops lives in.
4. "How do you measure whether product operations is working?" Lands because it shows you think about the function's own metrics, not just the work it supports.
5. "What has been the hardest handoff between this team and the teams it supports?" Lands because it invites a candid answer and shows you care about the seams.
6. If the interviewer is a peer: "What could a new person do in their first month that would genuinely help your team?" Lands because it turns the conversation to shared work.

## Values / principles cheat sheet

Not included. It needs Stripe's published values, which were not retrieved. A values-style round is also not established by any loop source, so this section's condition is not met.

## Delivery coaching

Not included. No working-style assessment was provided.

## Sources

- Provided documents: none. The user provided no job description, CV, or round details.
- Searches: three sent (Stripe values; Stripe interview process for Product Operations; Stripe news and strategy). All three were refused because search permission was not granted. None returned results. No pages were fetched.
- Loop structure: not established by any loop source. Persona weights above are a blended prior for a final round, not Stripe's documented process.

Research tier: L1 requested, searches 0 of 6 completed (3 refused), fetches 0 of 2.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Stripe values | unavailable | Values cheat sheet (section 10), and the VAL questions' mapped stories. Query "Stripe company values operating principles" refused. |
| 2. Stripe interview process, Product Operations | unavailable | Loop structure and persona weights. Query "Stripe interview process Product Operations final round" refused. |
| 3. Stripe strategy and recent news | unavailable | CO and CASE grounding, and the grounding brief. Query "Stripe news strategy 2026" refused. |
| 4. Interviewer name and Stripe | n/a | No interviewer name was given, so there was no query to form. |
| 5. Representative Product Operations Manager JD | unavailable | Fit snapshot requirements, which are `[generic]` here. No search was sent. |

## Upgrade menu

- Your job description → the six `[generic]` requirement rows become `[grounded]` quotes, and the JD-tagged questions and the F5 coverage gap get rebuilt.
- Your CV or a few bullets → the fit snapshot's evidence cells get verbatim quotes, and the defend-the-number questions and the attribution slot get your actual sentences.
- The round's format and who you are meeting → the persona weights and the reverse questions get retuned to the interviewer.
- Grant search permission and I will re-run research → Stripe's published values (values cheat sheet, C1 to C3 retuned), the loop structure (persona weights), and recent strategy (CO questions and a grounding brief).
- Any hard requirements in the posting, such as location, work authorization or certification → gate rows in the fit snapshot.
