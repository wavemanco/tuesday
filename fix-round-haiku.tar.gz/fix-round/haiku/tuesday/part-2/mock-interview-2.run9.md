Your prep pack is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-tuesday-part-2-rooms-case-2-denied-746224c3/be15a675-7f27-44f2-93d0-f3f9b3a9a105/scratchpad/atlas-freight_operations-manager_interview_pack.md`. I built it for a hiring-manager round, since your note didn't say who you're meeting.

The main thing to prepare: the team is 3 supervisors today, and the role is 12. Question B1 covers it, and it's where I'd spend the most time. The other real gaps are the 5+ years of leadership (B2, which depends on how many of your seven years were spent leading people) and Power BI (B3, which you should answer with a plan, not a past).

Two things I couldn't do. Web search was refused in this session, so the pack says nothing about Atlas Freight's values, interview loop or strategy. If you can allow search, I can add those. And the persona weights are a general prior, not a read of this company.

Say the word and I'll play the Skeptic on B1, the question the pack names as its highest-ROI prep. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

Is the person you're meeting your future manager, or a peer on the team? The answer reweights every bank.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: atlas-freight_operations-manager_interview_pack.md -----
# Interview prep pack: Operations Manager, Atlas Freight

**Built on:** a hiring-manager round (assumed, since your note doesn't say who you're meeting). Persona weights are a prior, not a read of this company. Research was refused in this session (see Sources), so nothing below is about Atlas Freight's values, loop or strategy.

## How to use

- **Personas** describe how a question is asked. **Types** describe what is being scored: CASE (live problem), EXP (your past, checked closely), JD (the posting's own requirements), VAL (values; none detected here).
- Guidance is scaffolding, not a script. Speak each answer in your own words, in 90 to 120 seconds.

## Fit snapshot

Requirements are quoted from the JD you pasted. Evidence is quoted from your message, the only background you gave.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" (JD) | "7 years in warehouse and distribution ops" – your message; "currently a senior shift manager over 3 supervisors" – your message | medium | [grounded] | transferability | Your material shows seven years in the field and a shift role over three supervisors. It does not show a daily plan owned across four sites. Words: "I've spent 7 years in warehouse and distribution ops, and I'm currently a senior shift manager over 3 supervisors." Answer slot: if you have been accountable for more than one site, name the sites and what you were accountable for; if your work has been one site, say so and say how you would learn the others. |
| F2 | "lead a team of 12 supervisors" (JD) | "currently a senior shift manager over 3 supervisors" – your message | medium | [grounded] | transferability | Same quote, at its own scope: three supervisors. Words: "I'm currently a senior shift manager over 3 supervisors." The step to twelve is an answer slot in B1, not a claim here. |
| F3 | "5+ years operations leadership required" (JD) | "7 years in warehouse and distribution ops" – your message | medium | [grounded] | discovery | Seven years of operations is stated. Years of leading people are not. Answer slot: how many of those years were spent leading people, as opposed to working alongside them. If the leadership figure is under five, say the number plainly and say what you would bring in its place. |
| F4 | "drive on-time performance and cost-per-shipment down" (JD) | "cut mis-pick rate 40% by redesigning the pick path" – your message | medium | [grounded] | transferability | The quote is an accuracy result at its own scope. Your material does not show on-time or cost. Words: "I cut the mis-pick rate 40% by redesigning the pick path." Answer slot: if the pick-path change moved on-time or cost, say how; if it measured only mis-picks, say so and say what you would track first. |
| F5 | "build reporting in Excel/Power BI" (JD, Excel) | "solid Excel" – your message | low | [grounded] | discovery | Excel is named. A report you built is not. Answer slot: name one report you built in Excel, what it tracked and who read it. If your Excel work was analysis without a standing report, say that. |
| F6 | "build reporting in Excel/Power BI" (JD, Power BI) | "never used Power BI" – your message | none | [grounded] | capability | A gap you stated yourself. Words: "I haven't used Power BI." Then how you would learn it, said as a plan, never as a past. |
| F7 | "Lean/Six Sigma a plus" (JD) | "green belt certified" – your message | medium | [grounded] | none | Credential named. A certificate on hand would raise this to high. Words: "I'm green belt certified." The pick-path redesign is the story for Lean in A5. |

**Gates:** none. "5+ years operations leadership required" is a length of experience, so it is graded like any other requirement, not treated as a gate.

## Prohibited list

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the daily plan across four sites | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: your material shows one shift over three supervisors. |
| Led a multi-site team of twelve | Inflated form of F2 | "I'm currently a senior shift manager over 3 supervisors." |
| Improved on-time performance or cost-per-shipment | Inflated form of F4 | "I cut the mis-pick rate 40% by redesigning the pick path." Its limit is named in F4. |
| Built Power BI reporting | Negative you stated (F6) | "I haven't used Power BI." No slot. |

## Persona weights

| Persona | Weight | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|---|
| Case / Strategist | 5 questions | Live ops problems from the posting (on-time, cost, four sites) | High. A hiring manager buys capability on the actual job. | Clarify, then structure, then metrics. Say the assumption you'd test first. |
| Skeptic | 4 questions | The scale gap (3 supervisors against 12), the leadership-years gap, Power BI | High. The posting's headline numbers sit above your evidence. | Rehearse the biggest objection until it is plain. Concede precisely, then give a ramp plan. |
| Data-Driven Prober | 3 questions | The 40% figure, the Excel report, the surge plan's measures | Medium-high. Reporting is in the JD and a prober will check your numbers. | Say how each number was counted, and say plainly where you don't know. |
| Pressure | 2 questions | "Sixty seconds" on why you over someone who has led larger teams | Medium. Used as a stress check on the scale gap. | Pause, restate, hold two follow-ups, then concede the specific point. |
| Values / Behavioral | 2 questions | Generic leadership stories | Low. No values round is detected: research was refused, so the loop is unknown. | Story from your own material, or a selection scaffold with its honest branch. |
| Conversational | 2 questions | Opening walk-through; a casual Excel question | Medium. Casual questions are still scored. | A 90-second arc drawn from your quotes. |

## Question banks

### A. Case / Strategist (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You're taking over daily operations across four sites. What do you look at in the first week?" | CASE | [generic] (raising source: JD "Own daily terminal operations across 4 sites") | Clarify what "on-time" and "cost-per-shipment" are measured against. Then segment by site. Name the first two data sources you would pull. | Framed as a decision, not a record. Makes no claim about your past. |
| A2 | "On-time performance dropped six points at one of the four sites last month. Diagnose it." | CASE | [generic] (raising source: JD "drive on-time performance and cost-per-shipment down") | Structure: volume, labour, dock timing, carrier cut-offs. Say the one hypothesis you would test first. Make no claim about any site you have run. | Tests structure under pressure. The JD's own metrics are the raising source. |
| A3 | "How would you bring cost-per-shipment down without costing on-time performance?" | CASE | [generic] (raising source: JD, both metrics named together) | Name the trade-off first. Then the levers you would check, and the one you would not pull. | Scores reasoning about a trade-off, not a number. |
| A4 | "Tell me about a time you changed how work moved through a site." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" – your message | Story-mapped on F4: the pick path was redesigned, and the mis-pick rate fell 40%. Tell it in those terms. Answer slot: the JD's on-time and cost lines make a probe on whether the change touched either likely. If it did, say how. If it measured only mis-picks, say so plainly. | F4 is the nearest evidence for the on-time requirement, and the likeliest place to be probed. |
| A5 | "You're green belt certified. Walk me through a problem you ran with that method." | EXP | [grounded] "green belt certified" – your message; [grounded] "cut mis-pick rate 40% by redesigning the pick path" – your message | Answer slot: if the pick-path redesign was run with the green belt method, say which steps you used and in what order. If the green belt project was something else, or you can't map the method onto the work, say so and name what it was. | F7 is the credential; the pick-path redesign is the most likely project. Don't assume it was. |

### B. Skeptic (4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | **Highest-ROI prep.** "You run three supervisors today. Why would you lead twelve across four sites?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" – your message; JD "lead a team of 12 supervisors" | Hold: "I'm currently a senior shift manager over 3 supervisors." Then the answer slot: if you have led more people than three, or run a structure that spans shifts, say what it was. If not, say so plainly, and set out how you would build a structure for twelve. Hold through two follow-ups by returning to three, not by adding to it. | F2 is the largest gap in the pack, and this objection will come in some form. Deepest rehearsal here. |
| B2 | "The role requires five years of operations leadership. Where do your leadership years sit?" | JD | [grounded] "7 years in warehouse and distribution ops" – your message | Answer slot: say how many of your seven years were spent leading people. If that is under five, say the number plainly, then what you would bring in its place. | F3 is discovery. The answer is a number, and the number should come from you. |
| B3 | "Power BI is in the job. What have you built in it?" | JD | [grounded] "never used Power BI" – your message | Plain acknowledgment: "I haven't used Power BI." Then how you would learn it, as a plan. Nothing about your past in Power BI. | F6 is a stated gap. A plan answer is the honest one. |
| B4 | "Your number is mis-picks. This role is on-time and cost. What's the link?" | JD | [grounded] "cut mis-pick rate 40% by redesigning the pick path" – your message | Hold: "I cut the mis-pick rate 40% by redesigning the pick path." Then the limit, in your own words: what you measured and what you did not. Answer slot as in F4. | Tests whether you can stay within what you measured. |

### C. Data-Driven Prober (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the 40% mis-pick reduction was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" – your message | Say how the rate was counted: the base, the period, what was in and out. Name the assumption you would defend least, before they ask. Say which part of the result was yours. Answer slot: if you cannot say how it was counted, say so. | Every headline number gets a defend-the-number question. The pack does not supply a method. |
| C2 | "The posting says build reporting in Excel. Show me a report you built." | JD | [grounded] "solid Excel" – your message; JD "build reporting in Excel/Power BI" | Answer slot: name one report you built, what it tracked, and who read it. If your Excel work was analysis without a standing report, say so plainly. | F5 is discovery. Excel is the part of this requirement you can speak to. |
| C3 | "Your peak-season plan ran two years. What did you measure to know it worked?" | EXP | [grounded] "ran the site's peak-season surge plan two years running" – your message | Story-mapped: the plan ran two years. Answer slot: if you measured its results, name the measure and what it showed. If you did not measure them, say so and say how you would measure next time. | The surge plan is your closest evidence of running a peak. Its measures are not in your message. |

### D. Pressure (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why should we hire you over someone who already leads a larger team?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" – your message; JD "lead a team of 12 supervisors" | Pause. Restate the question. Anchor in what you lead now. Hold through two follow-ups. Concede the scale point specifically, then give your first ninety days. | Tests composure on the B1 gap. Hold-then-concede. |
| D2 | "That 40%. How much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" – your message | Answer slot: say which part was yours, in your own words. If the redesign was a team's, say so. | A probe on attribution. Answer honestly and keep it short. |

### E. Values / Behavioral (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Tell me about a time you had to tell a senior leader something they did not want to hear." | VAL | [generic] | Selection scaffold: pick a time you disagreed with someone senior and it cost you something. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. | An open prompt, not a claim. No values were published or researched. |
| E2 | "Tell me about a time you led people through a peak period." | EXP | [grounded] "ran the site's peak-season surge plan two years running" – your message | Story-mapped: the surge plan ran two years. Answer slot: what you did with the people on it, in your own words. | The surge plan is your strongest people-leadership story in the material. |

### F. Conversational (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F-a | "So, walk me through the journey." | JD | [grounded] "7 years in warehouse and distribution ops" – your message; "currently a senior shift manager over 3 supervisors" – your message; "green belt certified" – your message | A 90-second arc in this order: seven years in the field, the shift role, the green belt. Stop there. | The opener is scored too. Keep it short. |
| F-b | "What are you playing with in Excel these days?" | JD | [grounded] "solid Excel" – your message; "never used Power BI" – your message | Say what you use Excel for now. Then say plainly you have not used Power BI, and how you would learn it. | A casual question about the posting's reporting tools. |

## Requirement coverage

| JD requirement | Questions |
|---|---|
| Own daily terminal operations across 4 sites | A1, B1 |
| Drive on-time performance and cost-per-shipment down | A2, A3, A4, B4 |
| Lead a team of 12 supervisors | B1, D1 |
| Build reporting in Excel/Power BI | C2, B3, F-b |
| 5+ years operations leadership required | B2, E2 |
| Lean/Six Sigma a plus | A5 |
| Company values | none, and why: no values were researched, and no values round was detected |

## Reverse questions

Each one, with why it lands:

1. "What does on-time performance look like on a bad week, and who sees it first?" Lands because it shows you are thinking about the number, not the title.
2. "What cost-per-shipment target has the team been given for the coming year?" Lands because it asks for the number you will be held to.
3. "Which of the four sites is furthest from target today, and what is behind it?" Lands because it shows you have read the posting closely.
4. "What reporting exists now, and what is it missing?" Lands because it opens the Excel and Power BI gap in the interviewer's own terms.
5. "What would a good first ninety days look like for someone coming from a three-supervisor team?" Lands because it names the scale gap yourself, before they do, and asks how to close it.

## Sources

- Provided: the JD and background you pasted in your message. No CV or other document was given.
- Research tier: L1 — searches 3 of 6, fetches 0 of 2.
- Target 1, `Atlas Freight values`: **unavailable.** The search call was refused (permission not granted). Would have moved the values cheat sheet; no values round is detected, so none is in the pack.
- Target 2, `Atlas Freight interview process operations manager`: **unavailable.** The search call was refused. Would have moved the loop structure and the persona weights, which therefore rest on the hiring-manager prior.
- Target 3, `Atlas Freight logistics company news strategy`: **unavailable.** The search call was refused. Would have moved the CO questions; none are in the pack.
- Target 4, interviewer name: **n/a.** No name was given.
- Target 5, representative JD: **skipped.** You supplied the JD.

## Upgrade menu

- The interviewer's name → persona weights from their public footprint, and a tailored reverse question.
- The round type, and whether it is one session or several → the persona weights are checked against the actual round.
- The recruiter's prep email → any pre-declared deliverable or focus area.
- Allowing web search → the company research this pack lacks: values, loop structure and recent strategy. Three searches were refused this session.
- A copy of the green belt certificate → F7 moves from medium to high.
- A sample Excel report you built → F5 moves from low to medium, and C2 gets a real artifact to speak to.
