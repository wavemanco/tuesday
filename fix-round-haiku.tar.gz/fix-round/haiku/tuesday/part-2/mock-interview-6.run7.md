Your prep pack for all three rounds is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-tuesday-part-2-rooms-case-6-denied-bcac33b3/8efdf360-e56f-4fdd-892d-567081553aae/scratchpad/larkfield_engineering_manager_interview_pack.md`.

I could not research Larkfield. The web search permission was refused, so the pack has no company values, loop or strategy in it. Round 3 uses selection scaffolds instead of mapped values stories, and the strategy questions are labelled generic.

What matters most across the three rounds:

- **The hardware-adjacent roadmap is the gap they will press on.** It comes up in Round 1 (A1) and again from a peer seat in Round 2 (B5). Rehearse the plain line, "I haven't owned a hardware-adjacent roadmap," then a concrete plan for learning it. Don't stretch the reliability quarter to cover it.
- **Your 60% result is your strongest story, and it will be probed.** Round 2's staff engineers and Round 1's Director will both ask how the figure was counted (A6, B2). Be ready to say what was counted, over what period, and which assumption you would defend least. If you don't know how it was counted, say so.
- **Keep the squads and growth claims as plans, not pasts.** You led one team of six, not two squads. Growth of 11 engineers isn't in your material, so answer it with what you would do in the first 90 days (A4, C5).
- **Round 3 is about leadership philosophy.** The VP will likely ask about managing managers (C3). Say "I haven't managed managers," then how you would work with the squad leads.

Question for you: do you know the names or roles of the two staff engineers and the PM? Knowing them would let me weight each panelist's questions to their likely focus.

Drill offer: I can run a live drill on A1 with the Director persona. Dossier offer: I can save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: larkfield_engineering_manager_interview_pack.md -----
# Larkfield Systems, Engineering Manager: loop prep pack (three rounds)

Role: Engineering Manager, Larkfield Systems (industrial IoT, ~600 people). Candidate: Yusuf.
Loop mode: three scheduled rounds. Shared fit snapshot first, then one mini-pack per round.
Changelog: first version. Built from your message and the role text you pasted; no company research ran (see Sources).

## How to use + type key

- **Personas** = how the question is asked. **Types** = what is being scored.
- Types: **VAL** behavioral/values · **EXP** your experience, deep-dive · **JD** role requirement · **CO** company/strategy · **CASE** live problem.
- Guidance is scaffolding, not a script. Speak it in your own words.
- Question IDs: A = Round 1 (Director, hiring manager), B = Round 2 (panel), C = Round 3 (VP Engineering). Answer slots are instructions for the interview, not questions to me.

## Sources

- Provided: your message (the candidate facts, the three rounds, the role description); the role text you pasted.
- Research: **none ran.** Three company searches (values, interview process, strategy/news) were each refused: the web search permission was not granted in this session. Nothing about Larkfield's values, loop or strategy below comes from research or memory.

Research tier: L1, requested. Searches 0 of 6 (all refused). Fetches 0 of 2.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Larkfield values | unavailable | Values cheat sheet (section 10) cannot be built; round 3 uses selection scaffolds. Refused: "Larkfield Systems values" |
| 2. Larkfield interview process, engineering manager | unavailable | Loop is already established by your own and the recruiter's words, so no archetype fallback is needed. Refused: "Larkfield Systems interview process engineering manager" |
| 3. Larkfield strategy / recent news | unavailable | CO questions are generic and labelled `[generic]`. Refused: "Larkfield Systems industrial IoT strategy news" |
| 4. Interviewer name + company | n/a | No names given. Interviewer read absent; upgrade menu says what names would add |
| 5. Representative JD | skipped | Role text supplied; fit snapshot rests on it |

## Fit snapshot

Requirements are quoted from the role text you pasted (source: role text). Evidence is quoted from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" (role text) | "3 as a team lead of 6" (your message) | medium | [grounded] | transferability | Your material says one team of six, not two squads. Say the team of six in those words, then carry it: "For three years I led a team of six." Answer slot: if you ever coordinated work across two groups, say how; if not, say so and say how you would set up two squads. |
| F2 | "own delivery, hiring and growth for 11 engineers" (role text), hiring part | "I run our hiring loop for backend roles — about 40 interviews last year." (your message) | medium | [grounded] | presentation | Reword only: "I run our hiring loop for backend roles, and about 40 interviews ran through it last year." The hiring is backend, not device; say so if asked. |
| F3 | "own delivery, hiring and growth for 11 engineers" (role text), delivery part | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." (your message) | medium | [grounded] | transferability | A reliability quarter is adjacent to delivery of 11 engineers' output, which the material does not show. Answer slot: how delivery was tracked across the team; if you tracked it, say how; if not, say so. |
| F4 | "own delivery, hiring and growth for 11 engineers" (role text), growth part | none given | none | [grounded] | discovery | Your material does not show growth work: no development plans, promotions or feedback cycles are mentioned. Answer slot: if you have run any of these, say what they were; if not, say so and describe how you would start in the first 90 days. |
| F5 | "partner with hardware and product on roadmap" (role text), hardware part | "I've never owned a hardware-adjacent roadmap." (your message) | none | [grounded] | capability | Plain acknowledgment: "I haven't owned a hardware-adjacent roadmap." Then how you would learn it, said as a plan and never as a past. |
| F6 | "partner with hardware and product on roadmap" (role text), product part | "pushed a reliability quarter through against roadmap pressure" (your message) | low | [inferred] | transferability | Roadmap pressure shows you held a line against a roadmap; it does not show a partnership with product or hardware on one. The bridge must stay at that scope. Answer slot: who applied the pressure and how you worked with them. |

Constraints the snapshot enforces:
- "Managed managers" is not in the role text. Your message says "I've never managed managers." It is a stated absence, but no requirement quotes it, so it gets no row. Prepare it only if an interviewer raises it (see C3).
- "device-management services" appears in the role text, and no quote in your material touches device-management technology. Silence, not a gap you stated, so it is not listed here. The pack does not invent experience with it.

## Prohibited claims

Built locally from the snapshot. None of these may be said, implied or coached.

| Not coached | Basis | Honest form |
|---|---|---|
| "Led two squads" | Inflated form of F1 | "For three years I led a team of six." The limit is the pack's own observation: your material says one team, not two. |
| "Owned a hardware roadmap" or any hardware-roadmap ownership | Negative you stated (F5) | "I haven't owned a hardware-adjacent roadmap." No slot on the ownership itself. |
| "Managed managers" | Negative you stated | "I've never managed managers." |
| "Ran delivery for 11 engineers" | Inflated form of F3 | "I pushed a reliability quarter through against roadmap pressure," and the 60% sentence, at its own scope. |
| "Designed the hiring loop" | Inflated form of F2 | "I run our hiring loop for backend roles." Running is the sentence; designing is not in it. |

## Shared requirement coverage

| Requirement (role text) | Question IDs | Note |
|---|---|---|
| Lead two squads | A7, B3 | |
| Device-management services | none, and why: no quote in your material touches device-management technology, so the pack does not invent a question on it | Upgrade menu |
| Own delivery | A5, A6, B1 | |
| Own hiring | A3 | |
| Own growth | A4, C5 | |
| Partner with hardware | A1, A2, B5 | |
| Partner with product on roadmap | B4, B7 | |

## Persona weights per round

| Round | Who | Weights | Why |
|---|---|---|---|
| 1, Director of Engineering (hiring manager) | Case/Strategist, Skeptic, then Prober, Conversational low | Case and Skeptic dominant | Hiring managers buy capability and derisk gaps; expect a live problem on their real roadmap |
| 2, panel: two staff engineers + PM | Prober and Peer Evaluator (staff engineers), Case and Peer Evaluator (PM), Skeptic low | Blend of the top two personas per member, per the panel rule. Panelist names unknown, so no per-member assignment | Staff engineers test depth and collegiality; the PM tests roadmap trade-offs |
| 3, VP Engineering ("values and leadership philosophy") | Values/Behavioral dominant, Pressure, Case (altitude) low | Your recruiter's words establish a values round, so VAL questions are guaranteed | Scored leadership conversation at altitude |

Values cheat sheet: not built. A values-style round is detected by the recruiter's words, but no published Larkfield values are in hand, so section 10 cannot be built. Round 3 uses selection scaffolds with their honest branch.

## Highest-ROI prep

**A1** is the single most likely objection: the hardware-adjacent roadmap. It will come up in some form in Round 1, and in Round 2 as B5. Rehearse the plain acknowledgment and the plan for learning, two follow-ups deep. Do not stretch F1 or F6 to cover it.

## Round 1: Director of Engineering (hiring manager), 45 min

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "What would you be weakest at on day one in this role?" | JD | [grounded] "I've never owned a hardware-adjacent roadmap." | Plain acknowledgment: "I haven't owned a hardware-adjacent roadmap." Then what you would do first: learn the hardware team's release process and constraints from the people who run them. Said as a plan. Hold through two follow-ups by returning to the plan | F5 is the gap this role most directly presses on. Highest-ROI prep |
| A2 | "Two squads and the hardware team disagree on a release date. How do you run it?" | CASE | [generic] | Clarify: what the dates depend on, who decides, what hardware can and cannot move. Then options, the decision and who you tell. No claim about your past | Live problem from the role's partnering line; asks nothing about your history |
| A3 | "Walk me through how you run the backend hiring loop. Who does what, and what do you track?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Story-mapped on F2: you run the loop, about 40 interviews last year. Answer slot: if you tracked any loop metric, name it and its figure; if you did not, say so | F2 is your strongest direct evidence and the interviewer will test whether it is real |
| A4 | "How would you grow the engineers on your team over the next year?" | JD | [grounded] role text: "own delivery, hiring and growth for 11 engineers" | Answer slot (F4): if you have run development plans, promotion cases or feedback cycles, say what they were; if not, say so and give a 90-day start | F4 is silence in your material; the question is aimed at it |
| A5 | "Your best delivery story is a reliability quarter. Why would I trust you with a roadmap that hardware depends on?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Hold the quote: the quarter, the pressure, the 60%. Concede explicitly where it does not carry over: a reliability quarter is not hardware roadmap delivery. Hold, then concede the specific gap, never the whole claim | Pressure element; tests whether the quote is held without inflation (F3) |
| A6 | "How was that 60% counted?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Answer slot: say how you know it was 60%, in your own words: what was counted, over what period, and the assumption you would defend least. If you do not know how it was counted, say so plainly. Which part was yours: the quarter, or the team's work? | Prober move on a figure you gave; the weakest-assumption move converts a gotcha into credibility |
| A7 | "Two squads, one team of six today. What would you do in your first 60 days?" | JD | [grounded] "3 as a team lead of 6" | Story-mapped on F1: you have led one team of six for three years. The plan for two squads is a plan, not a past. Keep the team of six as the fact | F1 is the squads gap; the plan must be framed as a plan |
| A8 | "Tell me about your path to this point." | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." | 90-second arc from the sentence: nine years, three as a team lead, now at a payments company. Keep it to what that sentence says | Low-weight opener; rapport check, scored lightly |

Reverse questions (Round 1):
- "What did the last person in this role do that worked, and what fell short?" Why it lands: shows you want the real shape of the job.
- "Where does the roadmap disagreement with hardware usually start?" Why it lands: turns A1 into a conversation about the gap.
- "What would make the first six months a success from your seat?" Why it lands: asks for the scorecard in their words.
- "What do you wish the previous manager had handled earlier?" Why it lands: surfaces the real problem.
- "What would you want me to decide without asking you first?" Why it lands: maps decision rights, which matters for a squad lead partnering with hardware.

## Round 2: Panel (two staff engineers + PM), 60 min

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Walk me through the reliability quarter: what was in scope, and what was not?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Story-mapped on F3: the quarter, the pressure, the 60%. Answer slot: if you chose the scope, say how; if you did not, say so | Prober move on the quote; scope is where probing starts |
| B2 | "How was the 60% counted?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Same slot as A6: how you know the figure, the assumption you would defend least, which part was yours. "I don't know how it was counted" is an honest branch | Staff engineers will check the figure too; one consistent answer across rounds matters |
| B3 | "Where do you draw the seam between your squads and the platform team? What happens when you disagree?" | JD | [grounded] role text: "Lead two squads building device-management services" | Propose seam principles, not facts about a seam you have not seen. No claim about your past | Peer Evaluator probe on the squads requirement |
| B4 | "The PM wants a Q3 feature the squads estimate at twice the time. What do you do?" | CASE | [generic] | Clarify what the deadline protects and what the feature is for. Options, trade-offs, decision rights, and what you would say to the PM. Name a trade-off you would not accept | Live roadmap trade-off from the PM's seat; asks nothing about your past |
| B5 | "You have never owned a hardware-adjacent roadmap. Where does your current work come closest, and where does it stop?" | JD | [grounded] "I've never owned a hardware-adjacent roadmap." | Plain acknowledgment: "I haven't owned a hardware-adjacent roadmap." Then the closest thing you have done, at its own scope: the reliability quarter against roadmap pressure, which is roadmap work without hardware. Where it stops: hardware constraints | Prober on the same gap as A1, from a peer seat; hold it the same way |
| B6 | "How do you handle credit when work spans teams?" | JD | [generic] | Open prompt: pick a time work spanned teams and say whose credit it was. If none comes to mind, say so plainly, then give how you would share credit | Peer Evaluator stem. No raising source in your material, so the guidance is a scaffold |
| B7 | "What do you expect from a PM you'd find hard to work with?" | JD | [grounded] role text: "partner with hardware and product on roadmap" | Reciprocity: what you bring to the PM's team, and one thing you would ask the PM to do for you | Peer Evaluator probe on the product partnership |

Reverse questions (Round 2):
- Staff engineer: "Where does reliability work sit in the roadmap today, and who owns it?" Why it lands: shows you already think about the platform side.
- PM: "How do you decide what the squads build next quarter?" Why it lands: asks for the decision process directly.
- PM: "What would make you say no to a roadmap request from hardware?" Why it lands: tests decision rights.
- Reciprocity (PM): "What could a new engineering manager do in the first month that would genuinely help your team?" Why it lands: the peer question the panel rewards.

## Round 3: VP Engineering, 30 min ("values and leadership philosophy")

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "pushed a reliability quarter through against roadmap pressure" (your message) | Open prompt. Nearest thing your material carries: the reliability quarter, which pushed against roadmap pressure. If that is not an unpopular truth, say so, and say what it was | Values round, the recruiter's words; no published values in hand, so this is a selection scaffold |
| C2 | "In the reliability quarter, what exactly did you push back on, and who was asking?" | VAL | [grounded] "pushed a reliability quarter through against roadmap pressure" (your message) | Premised on what the quote carries: pushing against roadmap pressure. Answer: the pressure, who applied it, and how you held the position. Hold through two follow-ups; concede only what you did not do | Premised question; asks no more than the quote says |
| C3 | "You have never managed managers. Why would you lead two squads and their leads?" | VAL | [grounded] "I've never managed managers." (your message) | Plain acknowledgment: "I haven't managed managers." Then how you would work with the leads in the squads, as a plan. Hold two follow-ups | Pressure on the altitude jump; the only stated negative about leadership. A raising source is the VP's own framing |
| C4 | "What's your leadership philosophy in one sentence, and where did you learn it?" | VAL | [grounded] role text: "values and leadership philosophy" (recruiter) | Selection scaffold: one principle you have acted on, from a real decision. Use the reliability quarter if it is the decision you mean. If no decision carries it, say so | Recruiter's own words name the round |
| C5 | "How do you grow people who report to you?" | VAL | [grounded] role text: "own delivery, hiring and growth for 11 engineers" | Answer slot (F4): if you have run development plans, promotion cases or feedback cycles, say what they were; if not, say so and give the 90-day start | Same silence as A4, asked at altitude |
| C6 | "A squad lead tells you the team is burning out because the roadmap came first. How would you have seen that coming?" | CASE | [generic] | Signals you would watch, what you would ask first, what you would change, and how you would tell the PM | Live problem about reliability versus roadmap; asks no past |
| C7 | "What should the device-management roadmap prioritise next year?" | CO | [generic] | Say what you can see from the role text, and what you do not know. Strategy research did not run, so do not claim the company's strategy | Altitude test; the honest answer is labelled uncertainty |
| C8 | "When a squad lead and the PM disagree on a decision that is yours, what do you do?" | VAL | [generic] | Structure: what you ask each of them first, how you decide, how you record it, and how you tell both. No claim about your past | Values scenario from a leadership seat |

Reverse questions (Round 3):
- "How do you measure whether this org's leadership is working?" Why it lands: shows you want to be held to something.
- "What did the trade-off between delivery and reliability cost here over the last two years?" Why it lands: asks about the real tension without naming it as a flaw.
- "What would you need from me in the first 90 days?" Why it lands: asks for the expectation in their words.
- "What is a value you'd hold a manager to that is hard to measure?" Why it lands: the values question turned back on them.
- "How would you want a manager to disagree with you in a planning meeting?" Why it lands: maps their tolerance for pushback.

## Upgrade menu

- Full JD text → turns the role-text rows F1 to F6 from summary into `[grounded]` requirements, and firms up the JD questions
- Panelists' names (and their roles) → personas per member, and reverse questions tied to their paths
- Larkfield's published values page, pasted or sent by the recruiter → values cheat sheet, and round 3's VAL questions gain mapped stories
- Recruiter's email on the loop and any strategy material → CO questions move from `[generic]` to grounded (C7 most)
- The 60% count, in your words (what was measured, over what period) → answer slots A6 and B2 get a real answer to rehearse
- Any device, hardware or product-partnership work, even small → rows F5 and F6 gain a quote to bridge from
- Your evidence on growth (promotions, development plans) → row F4, and questions A4 and C5, get an answer
- A dossier from the job-underwriter, if you run one → adds `prohibited_claims` and the underwriter's evidence grading
