Your pack is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-tuesday-part-2-rooms-case-7-canned-eb635c64/b42d0a13-4b7d-48db-9955-32952bfb7558/scratchpad/saltmarsh_live-operations-producer_interview_pack.md`.

**What matters most:** Saltmarsh's careers page describes the 60 minutes as the "Outage Hour": a live-incident tabletop on a simulated outage during a live event, then a values conversation. So you should rehearse a live incident, not a generic interview. The three things to prepare, in order:

1. **Two titles and team leadership (C1).** The question "which part of this JD would you be weakest at on day one?" is the most likely objection. Your honest answer is that you ran one title's calendar, not two, and you haven't led a team. Rehearse the answer with a ramp plan, and don't bluff.
2. **The live-incident tabletop (A1, A2).** Structure it as clarify, decide pause or continue, tell players what's known, then set a next-update time you can keep. Your "Ship the Patch Not the Promise" answer should be to announce what's built, not what's hoped.
3. **Values.** Your checklist maps to "Leave the Build Greener" (B3). You have no story for "Players Before Plans" or "Ship the Patch Not the Promise." For those, the pack gives a selection scaffold with an honest branch. Use it. Don't invent a story.

**Something to bring up:** Saltmarsh's September 2026 news announces Project Larkspur. Tidepool Tactics and Lantern Row move to a season-pass model with one shared events calendar from February 2027, under a single live-ops group. That fits your calendar experience. Use CO1 and reverse question 3 to show you read it.

**Caveats:**
- I read the careers and values pages in full. The GDC talk by Tobias Wrenfield and the Larkspur news were seen only as search snippets. Check both before Friday.
- I treated Tobias as the hiring manager, based on the careers page. I haven't confirmed that.
- I had no CV, so the evidence comes only from what you wrote to me.

**One question:** Is Friday's 60-minute session the Outage Hour, with Tobias as the hiring manager? If it's a different format, the case bank changes.

I can also run a live drill where I play the Skeptic on C1, or save a `tuesday-dossier.md` with the gaps this prep exposed. A Word version of the pack is available if you want one.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh_live-operations-producer_interview_pack.md -----
# Saltmarsh Games — Live Operations Producer: Interview Prep Pack

**Role:** Live Operations Producer · **Company:** Saltmarsh Games (~350 people, mobile)
**Interviewer:** Tobias Wrenfield, Head of Live Operations (treated as the hiring manager; see Sources)
**Round:** 60-minute "Outage Hour" per Saltmarsh's careers page: a live-incident tabletop on a simulated outage during a live event, then a values conversation. No take-home.
**Changelog:** first version.

## How to use + type key

Personas = how a question is asked. Types = what is being scored.

- **VAL**: behavioral / values alignment — past behavior against the three published values
- **EXP**: work-experience deep-dive — whether your CV claims survive scrutiny
- **JD**: role-driven — stated responsibilities and qualifications, gaps included
- **CO**: company and strategy knowledge — the Larkspur announcement and what it changes
- **CASE**: live problem — structure and reasoning on a problem from the role

**Guidance is scaffolding, not a script.** Say only what you did, in your own words.

## Fit snapshot

Requirements are quoted from the JD. Evidence is quoted from your own message. "Your message" means the text you sent me; no CV was supplied.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | transferability | Your material shows one title, not two. Say it that way: "For two years I ran the weekly content-drop calendar for our main title." Answer slot: if you have planned more than one title's calendar at once, say how; if you have not, say so and say how you would plan two. |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | none given | none | [grounded] | discovery | Your material does not show coordinating these teams on an update. Answer slot: if you did, name the teams and what you did; if you did not, say so and describe how you would run those handoffs. |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head" — your message | low | [grounded] | discovery | Your material says you presented numbers. It does not show that you owned the numbers or ran a post-event review. Answer slot: if you produced or interpreted those numbers, say what you did with them; if you did not, say so and say how you would own a post-event review. |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses" — your message | medium | [grounded] | presentation | Reword only what the quote says: you wrote the checklist and QA still uses it. Expect a probe on the word "manage." Describe the day-to-day only if you did it. |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio" — your message | low | [grounded] | discovery | Four years is in your material. Whether the title was live-service is not. Answer slot: say how the title was run after launch, and whether it had regular content updates; if it did not, say so and say what you would bring. |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | none | No gap. This is the row the calendar story rests on (see A4). |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | presentation | Reword only what the quote says: you presented monthly retention numbers to the studio head. Depth is the probe (see D1), not the presence. |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses" — your message | medium | [grounded] | presentation | The checklist is the written artifact. Lead with what it is, not with an adjective about your writing. |

**Gaps you stated yourself** (not JD lines, but likely probes): "Never led a team, and never worked on a game with in-app purchases" — your message. These are carried in the Skeptic bank (C2, C3) as plain acknowledgments. The JD asks you to *coordinate* teams, not to lead them. Saltmarsh's season-pass move (see Sources) makes the in-app purchase gap more visible than it looks in the JD.

**Analysis (the pack's own observation, not words for you):** Your material is strong on the calendar, the checklist and retention reporting. It is silent on cross-team coordination and on owning a post-event review. Those two are where the Outage Hour will press.

## Prohibited claims

Things this pack will not coach. Each has a basis, and each has an honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Ran calendars for two titles | Inflated form of F1 | F1's quote at its own scope. The material says one main title. |
| Owned the post-event review | Inflated form of F3 | F3's quote. The material says you presented the numbers. |
| Ran live-service operations | Inflated form of F5 | F5's quote. The material says four years at a puzzle-game studio, plus the content-drop calendar in F1. |
| Led a team | Negative you stated | "I haven't led a team." No slot. |
| Built in-app purchase work | Negative you stated | "I haven't worked on a game with in-app purchases." No slot. |

## Reading the interviewer

Public footprint only.

- **Career pattern:** Head of Live Operations at Saltmarsh. A search snippet describes him as previously a QA lead at a console studio. I saw only the snippet, not the page.
- **Published argument:** a GDC 2026 talk, *Patch Notes Are a Promise*. His argument, per the snippet: a live team is judged by how often its patch notes describe what actually shipped. That is the company's "Ship the Patch Not the Promise" value in his own words.
- **Practical implications:**
  1. Expect the value to be tested with a concrete example, not a slogan.
  2. Expect the release checklist and the QA handoff to get attention, because of his QA background.
  3. Expect post-event reporting to be judged on whether it matched what shipped.
  4. Use his talk's own words in a reverse question (see reverse questions).
- **Mirror opportunity:** the checklist (F4) is your closest point of contact with his QA background. It is a mirror, not a shared career jump. Do not claim a jump you did not make.

## Persona table

The hiring-manager relationship prior is Case/Strategist plus Skeptic. The Outage Hour adds a values conversation, so Values/Behavioral is also weighted. The loop source establishes the round, so no archetype fallback applies.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist | Live tabletop on a simulated outage | **Highest.** The careers page names the tabletop as the core of the hour. Weight 5. | Clarify, then decide, then communicate. Think aloud. |
| Values/Behavioral | Values conversation after the tabletop | **High.** The careers page names it. Weight 3. | Map each value to one story, or give a selection scaffold with its honest branch. |
| Skeptic | Probes the gaps: team leadership, in-app purchases, two titles | **High.** These are the gaps the material shows. Weight 3. | Plain acknowledgment, then a plan (not a past claim). |
| Data-Driven Prober | Asks how the retention figures were counted | **Medium.** Retention and KPIs are in the JD. Weight 3. | Say what you know about how the figures were counted. Say plainly when you do not. |
| Pressure | Interrupts during the tabletop | **Lower.** Not named by the source. Weight 2 (within the case). | Pause, restate, hold through two follow-ups before conceding. |
| Conversational | Opening "walk me through" | **Medium.** Often the first question. Weight 2. | 90-second arc built only from your quotes. |
| Peer | — | Not applicable: the hiring manager is the interviewer. | — |

## Question banks

Ordered by weight. Provenance comes first; it carries every quote the guidance rests on.

### Case/Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how you would run a live incident during a live event, from the first player report." | CASE | [generic] | Structure: clarify scope and severity; decide pause or continue; tell players what is known and what is not; name owners for engineering and QA; set the next update time you can keep. Say the order aloud. | The careers page names a live-incident tabletop. Generic because the simulated scenario is not known. |
| A2 | "Your first update says the fix ships tomorrow, but QA is not finished. What do you do?" | CASE | [generic] | Hold the update to what is built. Announce the status, not the hope. Name the QA gate you would ask for. | Tests the "Ship the Patch Not the Promise" value under time pressure. Generic: a pattern for the problem, not a fact about Saltmarsh. |
| A3 | "Two events on two titles are in the same week, and engineering asks for a freeze. How do you plan?" | CASE | [grounded] "Plan and run the live-events calendar for two of our mobile titles" (JD) | Clarify which titles and which teams. Sequence the freeze against the calendar. Name the player impact of each choice. | Raised directly by the JD's two-title line. Presupposes nothing about your past. |
| A4 | "Walk me through how you ran the weekly content-drop calendar." | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Tell the calendar in your own words: the weekly cadence, the main title, two years. Answer slot: the JD says two titles, so expect a probe on scope. If you planned more than one title at once, say how; if not, say so and return to the main title. | F1 and F6 are the evidence. Premised on your own quote. |
| A5 | "What does a good post-event review tell you that the calendar does not?" | JD | [grounded] "own the post-event review and the KPIs it reports" (JD) | Name the question a review answers: did the event do what it was for. Name one KPI you would check first and the assumption behind it. | Tests R3 against your F3 gap. No claim about past reviews. |

### Company and strategy (weight 3, from research)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| CO1 | "Tidepool Tactics and Lantern Row move to one shared events calendar. What breaks first?" | CO | [grounded] "moves Tidepool Tactics and Lantern Row to a season-pass model with one shared events calendar from February 2027" (Saltmarsh news, search snippet) | Name the likely failure: two title teams with different cadences, one calendar. Propose one check you would run in the first month. | Strategy-level question, grounded in Project Larkspur. Based on a search snippet; verify on the page before the interview. |
| CO2 | "Season passes change content cadence. How would you plan around that?" | CO | [grounded] "season-pass model" (Saltmarsh news, search snippet) | Name what a season pass changes for the calendar: fixed pacing, a content commitment. Say what you do not know about their pricing. | Monetization is the gap in your background (see C3); answer from the calendar side, not the pricing side. |

### Values/Behavioral (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time you put players ahead of a plan." | VAL | [grounded] "when the calendar and the players disagree, the players win" (Saltmarsh values page) | No quoted sentence of yours carries a player-facing story. Selection scaffold: pick a time a schedule and a player need disagreed, and what you chose. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. | Values round. The value is published; no story of yours is mapped to it. |
| B2 | "Tell me about a time you announced something before it was built." | VAL | [grounded] "we announce what is built, not what is hoped" (Saltmarsh values page) | Selection scaffold: pick a time you were tempted to promise, and what you said instead. If none comes to mind, say so plainly. Do not claim one. | Tests the value Tobias publishes about. No quoted story of yours carries it. |
| B3 | "Tell me about a release that left the process better than you found it." | VAL | [grounded] "Wrote the release checklist our QA team still uses" — your message | Story-mapped on F4: you wrote the checklist, and QA still uses it. Answer slot: if you can say what changed after you wrote it, say so; if not, say so. | Maps to "every release leaves ... the checklist better than it found them" (values page). |

### Skeptic (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Plan and run the live-events calendar for two of our mobile titles" (JD); [grounded] "Ran the weekly content-drop calendar" is F1 | Name the two-title scope as the limit, using F1's words. Give a ramp plan: what you would learn first, and from whom. Do not bluff. | The most predictable objection, and the highest-ROI prep (see below). |
| C2 | "You've not led a team. How would you coordinate design, art, engineering and community without authority?" | JD | [grounded] "I haven't led a team." (your message, plain acknowledgment) | Say the plain acknowledgment first. Then describe how you would coordinate: a plan, not a past claim. | JD asks for coordination; the interviewer may read it as leadership. |
| C3 | "Your background has no in-app purchase work. How would you handle a monetization-driven update?" | JD | [grounded] "I haven't worked on a game with in-app purchases." (your message, plain acknowledgment) | Say the plain acknowledgment first. Then describe how you would learn the monetization side, and who you would ask. | Season-pass news makes this probe likely. |

**Highest-ROI prep:** C1 (the "weakest on day one" question) and A4 (the calendar story). C1 is where the two-title scope gap and the team-leadership gap meet. Rehearse the honest branch until it is boring.

### Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how the monthly retention numbers you presented were counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head" — your message | Answer slot: if you know how they were counted, say how, in your own words. If you did not own the method, say so plainly. Name the assumption you would defend least. | F7's presence is a fact; its depth is the probe. A figure raises the defend-the-number slot. |
| D2 | "Which KPI would you check first after an event, and how would you know the event caused the move?" | JD | [grounded] "own the post-event review and the KPIs it reports" (JD) | Name one KPI and the assumption it rests on. Say how you would separate the event from other changes. | Scores R3 on the reasoning, not on past reviews. |
| D3 | "Did you own a post-event review for any event? What did it report?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" — your message | Answer slot: if you ran or owned a review, say what it reported. If you presented numbers and did not run a review, say so. | Premised on R3; the second branch allows that no review was yours. |

### Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So — walk me through the journey." | VAL | [grounded] "4 years as an associate producer at a puzzle-game studio" — your message; [grounded] "Wrote the release checklist our QA team still uses" — your message | 90-second arc built only from your quotes: four years at a puzzle-game studio, the content-drop calendar, the checklist, the retention presentation. Stop there. | Opening question. Every beat is a quote. |
| E2 | "What live-service games do you play, and what happens after launch?" | CO | [generic] | Name a title you actually play, and one thing it does after launch that you noticed. Do not claim more than you play. | Rapport-style, but scored. Casual questions about hot JD topics count. |

**Coverage line:** R1 → A3, A4, C1 · R2 → C2 · R3 → A5, D2, D3 · R4 → B3, F4 · R5 → C1 · R6 → A4 · R7 → D1 · R8 → none, and why: the Outage Hour is spoken, with no written test; the checklist (F8) carries the written evidence.

## Values / principles cheat sheet

The values page is fetched, and the Outage Hour's values conversation is documented on the careers page, so this section applies.

| Value (official name) | Working meaning (paraphrased) | Candidate's mapped story |
|---|---|---|
| Players Before Plans | When the calendar and the players disagree, the players win. | No quoted sentence carries it. Scaffold: B1, with its honest branch. |
| Ship the Patch Not the Promise | Announce what is built, not what is hoped. | No quoted sentence carries it. Scaffold: B2, with its honest branch. |
| Leave the Build Greener | Every release leaves the codebase and the checklist better than it found them. | "Wrote the release checklist our QA team still uses" — your message. See B3. |

## Reverse questions

Each one has a reason it lands.

1. "What would you need from me in the first 30 days to make the next event go well?" — Shows you are planning for the job, not for the interview.
2. "In your GDC talk you argue a live team is judged by how often its patch notes describe what shipped. How would you measure that here today?" — Ties to his own published argument. Verify the talk page before you use his words.
3. "With Larkspur moving two titles to one calendar, which decisions move to the single live-ops group first?" — Shows you read the announcement, and tests the scope of the role.
4. "How does the post-event review feed back into the next calendar?" — Tests whether the review is real, and shows you care about the loop.
5. "What would make this role a success in six months, in one number?" — Forces a clear answer on what he is scoring.

## Sources

**Provided documents:** your message (the background, the JD text, the stated gaps).

**Research queries and results:**

- "Saltmarsh Games values" → saltmarshgames.com/values (fetched).
- "Saltmarsh Games interview process Live Operations Producer" → saltmarshgames.com/careers/interviewing (fetched).
- "Tobias Wrenfield Saltmarsh Games" → a GDC 2026 talk page, talks.gdconf.example/2026/patch-notes-are-a-promise. Only the search snippet was read, not the page.
- "Saltmarsh Games live games 2026 news" → saltmarshgames.com/news/project-larkspur. Only the search snippet was read, not the page.

**Research tier:** L1 — searches 4 of 6, fetches 2 of 2.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | yes | Values cheat sheet (section above), values scaffolds B1–B2, reverse question 2. |
| 2. `Saltmarsh Games interview process Live Operations Producer` | yes | Round structure: the Outage Hour. Persona weights and the CASE bank follow it. |
| 3. `Saltmarsh Games strategy` / recent news | yes | Project Larkspur: CO1, CO2, reverse question 3. |
| 4. `Tobias Wrenfield Saltmarsh Games` | yes | Interviewer read; reverse question 2. The talk was seen as a snippet only. |
| 5. Representative JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions. |

**Confidence on the research:** the careers page and the values page are official and were read. The Larkspur news and the GDC talk were seen as search snippets. Verify both before the interview.

## Upgrade menu

- The full Larkspur announcement page → confirms the exact timing and the "single live-ops group" wording, which CO1 and reverse question 3 rest on.
- The GDC talk page, read in full → confirms or corrects the interviewer read (his QA background and his argument).
- Your CV → turns F1, F5 and F7 from quote-only into inspectable claims, and may surface evidence for F2 and F3.
- The title's launch and monetization history (if you know it) → sharpens F5 (live-service) and C3 (in-app purchases).
- Any example of a coordinated update across design, art, engineering and community → could move F2 from discovery to presentation. Only if you did it.
- Deeper research pass (L2): up to 6 more searches and 2 more fetches, several more minutes, for the strategy brief, his talks and writing, and recent org changes → want it?
- The dossier: I can save a `tuesday-dossier.md` recording the gaps this prep exposed (team leadership, in-app purchases, two titles, post-event review), for later sessions.
