Your prep pack for all three rounds is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-tuesday-part-2-rooms-case-6-denied-91988789/f6ecc22e-0be2-4f7f-be1a-f5ed907f2dde/scratchpad/larkfield_engineering-manager_interview_pack.md`. It has one shared fit snapshot and a mini-pack per round, with 8 questions each.

Web search was refused in this session, so I could not check Larkfield's values or how its loop is run. The values round is built from the recruiter's words, "values and leadership philosophy", not from a published list.

The most important prep is the hardware and roadmap gap (question A2). You've said you've never owned a hardware-adjacent roadmap, and the role asks you to partner with hardware on it. Start with that plain acknowledgment, then the reliability quarter, and don't stretch the quarter to cover hardware.

Say the word and I'll play the Director on A2, the question the pack names as highest-return prep.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Two things would change the pack:
1. Can you paste the full job posting? The role text you gave is a summary, so the rows can't yet quote the employer's own words. The posting would also show whether the two squads have team leads you'd manage, which is your manager-of-managers gap.
2. Is the role on-site or hybrid, and is your location and right to work already settled? If not, that's an open gate I can't assess from here.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: larkfield_engineering-manager_interview_pack.md -----
# Interview prep pack: Engineering Manager, Larkfield Systems

**Role:** Engineering Manager (industrial IoT, ~600 people). Lead two squads building device-management services; own delivery, hiring and growth for 11 engineers; partner with hardware and product on roadmap.
**Candidate:** Yusuf.
**Mode:** Loop mode, three scheduled rounds, one shared fit snapshot and a mini-pack per round.

| Round | Who | Length | Relationship |
|---|---|---|---|
| Round 1 (Tuesday) | Director of Engineering, hiring manager | 45 min | Your would-be boss |
| Round 2 (Thursday, the week after) | Two staff engineers and a product manager | 60 min | Peers and a cross-functional partner |
| Round 3 (following Monday) | VP Engineering | 30 min | Skip-level; the recruiter describes it as "values and leadership philosophy" |

Names of the panel members and the VP are not in hand, so no interviewer read is included.

## 1. How to use this pack and the type key

Personas describe how a question is asked. Types describe what is being scored.

- **JD:** can you do the listed job, including its gaps
- **EXP:** do your past claims survive scrutiny, and what did you actually do
- **VAL:** does past behaviour show the company's values or leadership principles
- **CO:** company and strategy knowledge (none in this pack, because research did not run)
- **CASE:** structure and reasoning on a live problem

Guidance is scaffolding, not a script. Say it in your own words, and stop where your own experience stops.

## 2. Prep triage

Prep time is about two weeks, with three rounds in order.

1. **Before Tuesday.** A2 is the highest-return rehearsal in the pack: the hardware and roadmap gap, which is a stated responsibility and a gap you have already named. Then A1 (your weakest part), A8 (defend the 60%), and A4 (the scale jump). Say the plain acknowledgments in your own voice until they are boring.
2. **Before Thursday.** B1 (the seam and disagreement), B4 (defend the 40 interviews), B5 (growth, the half of F3 your material does not show), and B6 (saying no to product).
3. **Before Monday.** C5 (hold on the hardware gap without folding), C6 (the 60% attribution), C1 (the unpopular-truth story from the reliability quarter), and C8 (your 90-second walk-through).

Everything else is insurance.

## 3. Fit snapshot (shared across all rounds)

Your message is the only source of candidate evidence. The role text quoted below is the summary you gave, not a posting. Quotes are verbatim from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" — your message | "9 years engineering, 3 as a team lead of 6, currently at a payments company" — your message | medium | [grounded] | transferability | Your material says three years as a team lead of six, not two squads. Words: "For three years I was a team lead of six." Keep to the number and the years; the scale of two squads is the role's and your material does not hold it. Answer slot: how the six were organised, and which decisions were yours and which were set for you. |
| F2 | "own delivery, hiring and growth for 11 engineers" — your message | "I run our hiring loop for backend roles — about 40 interviews last year." — your message | medium | [grounded] | presentation | Hiring is covered in your own terms: you run the hiring loop, for backend roles, about 40 interviews last year. Say it in those terms. The scope stays backend. No practice or figure is added. |
| F3 | "own delivery, hiring and growth for 11 engineers" — your message | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | medium | [grounded] | transferability | Delivery is covered in your words: you pushed a reliability quarter through for your team. Growth is not in your material at all; its answer slot is B5. The 60% is a figure you stated, with nothing inspected behind it, so expect a probe (A8). |
| F4 | "partner with hardware and product on roadmap" — your message | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | medium | [grounded] | transferability | The sentence shows roadmap pressure and a decision to push. It does not show partnering with product or with hardware. Words: "I pushed a reliability quarter through against roadmap pressure." The product side is for B6. Do not extend the sentence to hardware. |
| F5 | "partner with hardware and product on roadmap" — your message | "I've never managed managers and never owned a hardware-adjacent roadmap." — your message | none | [grounded] | discovery | Partnering is not owning, so this row is discovery, not capability. Your material shows no work with hardware teams and states that you have not owned a hardware-adjacent roadmap. Words: "I haven't owned a hardware-adjacent roadmap." Answer slot: if you have worked with a hardware or firmware team in any capacity, say how, in your own words. If not, say so plainly and say how you would learn the constraints before you set roadmap order. |
| F6 | Managing managers, if the two squads have leads (not in the role text you gave) — plain prose | "I've never managed managers" — your message | none | [grounded] | capability | Your own negative, so the words are yours: "I haven't managed managers." The requirement applies only if the squads have leads, which the role text does not say. The question in the message settles whether this row is live. If it is, this is the hardest row in the pack, and A1 is its rehearsal. Any plan for it is a plan, never a past. |
| F7 | Location and on-site schedule (not in the role text you gave) — plain prose | none given | none | [generic] | hard_gate | Your material does not establish it: the role text says nothing about location, travel or on-site hours. Surfaced, not bridged. The one question in the message asks whether the gate is met. No bank question addresses it. |

## 4. Prohibited claims (built locally from the fit snapshot)

These are claims a candidate reaches for under pressure. None is coached anywhere in this pack.

| Not coached | Basis | Honest form |
|---|---|---|
| Led eleven engineers | Inflated form of F1 and F3 | The quote at its own scope: three years as a team lead of six. Your material says six. A4's slot stays inside the six. |
| Owned a hardware-adjacent roadmap | Negative you stated (F5) | "I've never owned a hardware-adjacent roadmap." No slot. |
| Managed managers | Negative you stated (F6) | "I've never managed managers." No slot. |
| Drove the 60% drop alone | Inflated form of the reliability-quarter sentence | The quote at its scope: "I pushed a reliability quarter through against roadmap pressure." The share of the drop is A8's slot. |
| Ran hiring across the company | Inflated form of F2 | "I run our hiring loop for backend roles." The scope stays backend. |
| Set the roadmap with hardware | Inflated form of F4 | The quote at its scope: pushing roadmap work through against pressure. Hardware is A2's slot. |

## 5. Question banks

### Round 1: Director of Engineering (hiring manager), 45 min

**Persona table**

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Probes gaps: managing managers, hardware roadmap, scale, motivation | High (top weight, 4 questions). A hiring-manager prior is Case plus Skeptic, and the role names hardware and product partnering, where two of your gaps sit | Plain acknowledgment, then a plan, then the nearest quoted sentence. Hold on the quote |
| Case/Strategist | Live problems from the role | Medium (2 questions). The hiring-manager prior, and 45 minutes leaves room for two live problems | Clarify, structure, then one metric |
| Prober | Asks how figures were counted | Medium (2 questions). Two headline figures in your message: 60% and about 40 interviews | Four-slot answer for each figure |
| Pressure | Interrupts, holds | Low: no stress signal. A2's hold-then-concede covers the structure | Pause, restate, hold through two follow-ups |
| Conversational | Friendly opener | Not weighted for a 45-minute hiring-manager round | Not a bank item; C8's arc is the same material |

**Bank**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've led teams of six. Which part of this role would you be weakest at on day one?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company"; [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | Name the weakest part in your own words, using one of the two negatives you have already stated: you have never managed managers, or you have never owned a hardware-adjacent roadmap. Say it once, plainly. Then say your first move on it, as a plan and not a past. Claim nothing wider. | F6 and F5 are the weak rows, and this is the Skeptic's standard opener. The negatives are yours to say. |
| A2 | "This role partners with hardware on the roadmap. When have you planned work with a team outside software, and what did their constraints change?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap."; [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | The highest-return rehearsal in this pack. Open with the plain acknowledgment: "I haven't owned a hardware-adjacent roadmap." Then the nearest thing your material carries: the reliability quarter you pushed through against roadmap pressure, in your own words: what you asked for and whom you had to persuade. Hold through two follow-ups by returning to that quarter, never by stretching it to hardware. Answer slot: if you have worked with a hardware or firmware team in any capacity, say how. If not, say so plainly, then say how you would learn the constraints before setting roadmap order. | F5 and F4 are the gap. The Director is the person most likely to press it. The hold is on the quarter you can name; the concession is on hardware. |
| A3 | "Why this role, and why now, coming from a payments company?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | Your material gives the company and nothing about motive, so there is no story to map. Say what draws you to industrial device management, in your own words. Do not invent a reason the material does not hold. Answer slot: if the pull was the hardware, the scale or the product, say which and why. | Skeptics test motivation consistency. The sentence in Provenance supplies only the employer. |
| A4 | "You led a team of six for three years, and this is two squads and eleven engineers. Where would it break first?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company"; your message: "own delivery, hiring and growth for 11 engineers" | The scale is the role's and the team size is yours. Say the structure you would set up in the first month and what you would check first. Do not claim you have run eleven. Answer slot: if you have run anything larger than six in any form, say how. If not, say so, then say what you would measure first. | F1 and F3 are the scale rows. A standard Skeptic probe on size. |
| A5 | "A squad's delivery is slipping, and the hardware team says a firmware release moves a week. What do you do in the first week?" | CASE | [generic] | Structure it: what you would confirm with each team first, what you would tell product today, what you would change in the plan and what you would leave alone. | A live problem from the partnering line (F4, F5). The question needs no claim about your past. |
| A6 | "Two squads, one device-management service. How would you size the hiring for the next two quarters?" | CASE | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Structure first: which roles, what load, what the loop can absorb. Then the nearest thing you have: you run the loop for backend roles, and you have run about 40 interviews in a year. Say what that tells you about the loop's capacity in your words, and where that experience stops, since hardware roles are not in the quote. Do not state a hire count you did not track. | F2's presentation row, and hiring is the requirement you can speak to most credibly. CASE because the answer is a plan. |
| A7 | "That 60% on on-call burden. How much of it was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Hold the position the sentence carries: you pushed the reliability quarter through. Concede specifically on the team's share: the on-call drop was the team's result, and your part is the decision to push and what you did to hold it. Hold through two follow-ups; never fold on the push itself. | Attribution probe on F3 and F4. The Prober persona wants your exact share, and the hold is the rehearsal. |
| A8 | "Walk me through how the 60% was counted." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Answer slot, the four a figure raises, in your own words: how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. If you did not count it in a way you can explain, say so plainly and say what you did track. The pack does not supply a method. | Every headline figure gets a defend-the-number question. The rehearsal is precise attribution, not a better number. |

**Reverse questions (Round 1)**

| # | Question | Why it lands |
|---|---|---|
| R1 | "What would the first 90 days need to look like for this role to be working?" | Shows you plan against outcomes, not activity. |
| R2 | "Which roadmap decision will the two squads face first, and who makes it?" | Ties to the hardware and product partnering in the role. |
| R3 | "How much hardware work do the squads touch today, and where does it show up in delivery?" | Shows you have read the role as a hardware role. |
| R4 | "Is this a new seat or a replacement, and what did the previous holder leave behind?" | Surfaces the scope of the job and the state of the team. |
| R5 | "What do you need from this hire that you cannot get from the current team?" | Asks for the real hiring need. |

Interviewer-path reverse question: not included, because no profile is in hand. The upgrade menu says what a name would unlock.

### Round 2: Two staff engineers and a product manager (panel), 60 min

Panel members are not named, so personas are assigned by role: each staff engineer gets Peer plus Prober, and the PM gets Peer plus Skeptic (roadmap).

**Persona table**

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Peer Evaluator | Seam questions, disagreement, credit, what the hire needs from them | High (3 questions, the top weight). A peer prior, and the panel is mostly peers | Reciprocity framing. Propose seam principles, not claimed knowledge of their seam |
| Data-Driven Prober | Asks how figures were counted, and what they are sensitive to | Medium (2 questions). Two figures in your message | Four-slot answer for each figure |
| Skeptic (roadmap) | Tests the roadmap side of the partnering line | Medium (2 questions). The PM's likely angle | Hold the quoted position, concede specifically |
| Case/Strategist | One live problem on the device roadmap | Low (1 question). The panel is not a case loop by prior | Clarify, structure, then the commitment you would refuse |

**Bank**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Where would you draw the seam between your squads and the rest of engineering, and what happens when you disagree with a peer team?" | JD | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Propose seam principles, such as who owns an interface, who gets paged and who decides on a breaking change. Do not claim to know their seam. For disagreement, use the quarter if it fits: say what the disagreement was, with whom, and how it ended. If the quarter was not a disagreement with a peer team, say so and say what it was. Answer slot: if you have disagreed with a peer team and held a position, say what it was and how it ended. | The partnering line in the role. Peer panelists test seams and disagreement. |
| B2 | "Which number do you use to judge whether a squad is healthy, and which assumption behind it would you defend least?" | EXP | [generic] | Name one number you use and its weakest assumption. If you do not use a number for squad health, say so plainly and name what you use instead. Do not borrow the 60% unless it is one you use. The four figure slots apply to whatever you name. | A Prober stem. Generic because the theme comes from a persona stem, not from your material. |
| B3 | "What would you need from my team to make your first quarter work, and what would you bring to it?" | JD | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Reciprocity first: name what you would bring to their teams before what you would need. The one thing your material carries is the hiring loop. Offering interviewer calibration or a loop review is a plan you can make, not a claim about past help. | Peer reciprocity question, which a peer round needs. It scores whether the hire adds to their load. |
| B4 | "What did you count across those 40 interviews, and what would you not trust about the count?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Answer slot, the four figure slots applied to the 40: what you counted, what it is sensitive to, the assumption you would defend least, and which part of the loop you ran. If you did not count the 40 in a way you can explain, say so and say what you did track. Do not extend the loop beyond backend roles. | Defend-the-number applied to the second headline figure. Staff-level panelists tend to test calibration; that is a pattern, not a fact about this panel. |
| B5 | "Tell me about someone on your team whose growth you drove." | JD | [grounded] "own delivery, hiring and growth for 11 engineers" — your message | Selection scaffold: pick one engineer whose growth moved in a way you can describe. Say what you did and what they did, in your words. If the growth was theirs and you only made room, say so. Answer slot: if you cannot name one, say so plainly, then say what you would do first for growth in the two squads. | The growth half of F3 has no evidence in your material. The honest branch is the rehearsal. |
| B6 | "Tell me about a time you said no to product." | JD | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Open prompt: pick a time you held a position against product. The quarter may be the scene: you pushed it through against roadmap pressure. Say what you refused, why, and what you offered in its place. Hold through two follow-ups; concede specifically where product was right. Answer slot: if you did not refuse product scope, say so, and say how you did handle the conflict. | The PM is the natural person to test the roadmap side of F4. |
| B7 | "A device date is set by hardware and product before the firmware is tested. What would you need to see before you commit a squad to it?" | CASE | [generic] | Structure it: what you need from hardware (test status, known failure modes), what product needs to hear, what you would commit and what you would not. Claim nothing about your past. | The live version of F5 that a PM would ask. |
| B8 | "Two squads, one service. What would you tell product in the first two weeks?" | CASE | [generic] | Clarify what product is asking for. Say what you know and what you do not. Then the next two weeks of listening, the one commitment you would make, and the one you would refuse. | Case shape for the staff engineers and PM. Generic because it is a role pattern. |

**Reverse questions (Round 2)**

| # | Question | Why it lands |
|---|---|---|
| R1 | "What could a new engineering manager do in their first month that would genuinely help your teams?" | Reciprocity, which a peer panel expects. |
| R2 | "Where do you see the biggest delivery risk in the next two quarters?" | Shows you are thinking about the work, not the title. |
| R3 | "How do product and hardware decide roadmap order today, and who has the last word?" | Ties directly to the partnering line. |
| R4 | "What is the hardest architecture call the squads have made this year, and how was it made?" | Shows you care about how decisions get made. |
| R5 | "When engineering and product disagree on scope, what happens next?" | Surfaces the working relationship you are joining. |

### Round 3: VP Engineering, 30 min

The recruiter described this round as "values and leadership philosophy". That is a loop source naming a values part, so the round is treated as values-led. No published values are in hand, so no values cheat sheet is built. Every VAL question below uses the recruiter's words as its raising source, and where no story exists, it gives a selection scaffold with an honest branch.

**Persona table**

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral | Scenario probes on leadership and judgment | High (4 questions, the top weight). The recruiter's own words name the round as values-led | Map the story to what the quotes carry. Honest branch where none exists |
| Pressure | Time-boxed challenge on fit and attribution | Medium (2 questions). A skip-level prior, in 30 minutes | Hold the quoted position through two follow-ups, concede exactly |
| Case/Strategist | One altitude question about change | Low (1 question). No strategy brief in hand, so CO is absent | Clarify, then one change and what would change your mind |
| Conversational | Opening walk-through | Low (1 question). The opener is the biography | 90-second arc from the quoted sentences only |

**Bank**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "values and leadership philosophy" — your message (the recruiter's words); [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Story-mapped on the reliability quarter. The beats the quote states are: roadmap pressure, the quarter, the push, and the team's on-call drop. The "unpopular truth" is what your material does not state. If the quarter was taken to product or leadership as a hard truth, say who you told and what they said. If it was a team decision and nobody was told, say so and tell it as that. Answer slot: state the stake and the outcome in your own words. | The VP round is values-led by the recruiter's words, and this is the one story your material carries under that theme. |
| C2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold, not a story: pick a time you chose a customer's outcome over a team number, with a named stake and what you gave up. If no such time comes to mind, say so plainly, then give the nearest thing your material carries: the reliability quarter, whose number was on-call burden, an internal figure and not a customer one. | Customer-first is the standard values test. Nothing in the material shows a customer metric, so the honest branch is required. |
| C3 | "What is your leadership philosophy, in a sentence, and where did it come from?" | VAL | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | Say the sentence in your own words. Then tie it to the three years as a team lead of six: one decision from those years that shows it. Do not name a mentor, book or model you cannot speak to from your own experience. Answer slot: where the view came from, if you can say so truthfully. If not, say that instead. | The VP asks for a philosophy. The content has to come from your experience. |
| C4 | "Tell me about a hiring decision that turned out wrong." | VAL | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Answer slot: if a hire or a rejection you made turned out wrong, say what you decided, what you learned and what you changed in the loop. If none turned out wrong that you can name, say so plainly, then give the nearest decision you would make differently now and why. Do not invent a failed hire. | Hiring is a leadership act the VP can test for judgment. The theme comes from F2. |
| C5 | "Sixty seconds: why should we hire you, given that you've never owned a hardware-adjacent roadmap?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | Hold: name the strengths your quotes carry: three years as a team lead of six, the hiring loop, and the reliability quarter you pushed through. Do not argue the roadmap gap away. Concede: the hardware roadmap is a real gap; say how you would close it in the first months. Hold through two follow-ups. Never claim hardware work to win the point. | Pressure: tests composure and whether you concede without folding. The question uses the negative you stated, so it presupposes nothing you have not said. |
| C6 | "Why should I believe the reliability quarter was your push, and not the team's?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Hold: the push was yours; you pushed it through. Concede specifically: the drop was the team's result, and what you can claim is what you did. Hold through two follow-ups. Answer slot: the four figure slots only if pressed on the number. | Pressure on attribution. The hold is on the decision, the concession on the outcome. |
| C7 | "If you had to change one thing about how engineering is run here in your first six months, what would it be and why?" | CASE | [generic] | Pick one change. Say what you would learn first and what would change your mind. Do not describe how engineering is run here; you do not know yet, and say so if asked. | An altitude question that tests judgment without knowledge of the company. |
| C8 | "So, walk me through the last three years." | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | A 90-second arc from the quoted sentence only: nine years in engineering, three as a team lead of six, now at a payments company. Then the hiring loop and the reliability quarter. Do not add a year, team or title the sentence does not carry. | The conversational opener. The arc is the one place the figures come up first. |

**Reverse questions (Round 3)**

| # | Question | Why it lands |
|---|---|---|
| R1 | "How do you decide when a leadership principle should override a roadmap date?" | Tests the values at altitude. |
| R2 | "What does the VP want the new manager's first 90 days to change?" | Shows you are aiming at the right target. |
| R3 | "Which of the company's values do you see the teams living best, and which least?" | Works without the published list, and shows you want the real answer. |
| R4 | "How does the company develop managers into the next level?" | Opens your own growth path, which the role depends on. |
| R5 | "What would make the Director of Engineering's job easier in the first quarter?" | Connects this round to Round 1. |

## 6. Requirement coverage

| Requirement | Questions | Notes |
|---|---|---|
| Lead two squads building device-management services (F1) | A1, A4, B8 | |
| Delivery for 11 engineers (F3) | A4, A5, A7 | |
| Hiring for 11 engineers (F2) | A6, B3, B4, C4 | |
| Growth for 11 engineers (F3) | B5 | The material shows none; the honest branch is the rehearsal |
| Partner with product on roadmap (F4) | B1, B6, C6 | |
| Partner with hardware on roadmap (F5) | A2, B7, C5 | Highest-return prep: A2 |
| Managing managers (F6) | A1 | No bank question presupposes leads; the message asks whether they exist |
| Location and on-site schedule (F7) | none, and why | The material says nothing about it, and no bank question can answer it; the message asks whether the gate is met |

## 7. Sources and research accounting

Provided documents: your message (the role summary, your background, the recruiter's words "values and leadership philosophy"). No CV, no full posting and no interviewer names were supplied.

Searches sent (both refused by the host, which had not granted search permission):
- "Larkfield Systems values industrial IoT company": refused
- "Larkfield Systems engineering manager interview process": refused

Research tier: L1 — searches 2 of 6, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `{company} values` | unavailable | Both calls were refused. Would have moved the values cheat sheet (section 10), which is therefore not built. The VAL questions rest on the recruiter's words and selection scaffolds |
| 2. `{company} interview process {role family}` | unavailable | Refused. Would have confirmed the loop's rounds beyond the schedule you gave; the three rounds here are built from that schedule and persona weights follow it |
| 3. `{company} strategy` / recent news | unavailable | No search was sent after the first two were refused. Would have moved the CO bank; this pack has no CO questions, so the strategy grounding is absent |
| 4. `{interviewer name} {company}` | n/a | No interviewer names were given, so there was no query to form |
| 5. representative `{role title}` JD | unavailable | No full posting was supplied. A search would have grounded JD-tagged rows as [inferred]; the rows here rest on your message instead |

Degraded sections: reading the interviewer (no profile), grounding brief (no L2), delivery coaching (no assessment), graded deliverables (none declared), values cheat sheet (no published values in hand). Each is dropped rather than filled.

## 8. Upgrade menu

- Full posting text → F1 to F6 quote the employer's own words instead of your summary, and the JD-tagged questions are checked against every requirement in it
- Whether the two squads have team leads you would manage → F6 either becomes a live rehearsal in A1 or drops out
- Location, on-site schedule and right to work for the role → F7 is resolved, one way or the other
- The recruiter's list of published values (names only) → a values cheat sheet, and C1 to C4 get mapped stories where your quotes carry them
- Web search permission for this session → targets 1 to 3 re-run; a deeper research pass (up to six more searches and two more fetches, several minutes) is offered once you have it
- Names of the panel members → per-member persona assignments in Round 2, and a tailored reverse question for each
- Name of the Director and of the VP → a reverse question on their own career path, and persona weights read from public footprint
