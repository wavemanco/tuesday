Your prep pack is saved as `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-tuesday-part-2-rooms-case-2-denied-5bb1cde2/0b8fa4bd-7789-4079-9492-e0222b748221/scratchpad/atlas-freight_operations-manager_interview_pack.md`. It has the fit snapshot, 18 questions across four personas, the prohibited-claims list and the upgrade menu. I built it for a hiring-manager round, since you didn't say who you're meeting. No company research has run yet.

**The three things to rehearse most:**

1. **The five-year leadership gate (A2).** Your material shows 7 years in ops and 3 supervisors now, but not how long you've led people. Know your start date for a first people-leadership role before the round.
2. **The 40% figure (A3, C1, C3).** Expect the denominator, the time window, and whose redesign it was. Only say what you can back.
3. **Scope jumps (A1, A4, D2).** Four sites, 12 supervisors, and on-time and cost-per-shipment are not in your record yet. Answer with what you did, then a concrete plan for the step.

**Power BI:** say "I haven't used Power BI," then Excel and a learning plan. Don't imply dashboard work.

**Lean/Six Sigma** is covered by your green belt. Name it early.

Two questions so I can sharpen the pack:
- Who are you meeting, and what's the round? Hiring manager, ops director, or HR? Is any presentation or case assigned?
- Do you have five years of leading people, not just working in ops? If so, when did your first leadership role start?

If you'd like, I can also run Atlas Freight research (values, interview loop, recent news) and add a values cheat sheet and a current-strategy section.

I can play the Skeptic on A2, the question the pack names as the highest-ROI prep. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for your later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: atlas-freight_operations-manager_interview_pack.md -----
# Interview prep pack: Operations Manager, Atlas Freight

Built on: the JD summary and background you pasted. Assumption: a hiring-manager round, since you didn't say who you're meeting. No company research has been run yet (see Sources).

## How to use + type key

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and only what you actually did.

- **JD**: can you do the listed job, including its gaps
- **EXP**: do your claims survive scrutiny; what exactly was yours
- **CASE**: structure and reasoning on a live problem from this role
- **VAL**: values alignment (none detected here)
- **CO**: company and strategy knowledge (none researched yet)

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" (JD) | "7 years in warehouse and distribution ops" (your message) | medium | [grounded] | transferability | Your material shows one site's operations, not four terminals. Words: "I have 7 years in warehouse and distribution ops." The four-site scope is the bridge you have to build in the room, as a plan. |
| F2 | "drive on-time performance and cost-per-shipment down" (JD) | "cut mis-pick rate 40% by redesigning the pick path" (your message) | medium | [grounded] | transferability | Your material shows accuracy work, not on-time or cost-per-shipment. Words: "I cut mis-pick rate 40% by redesigning the pick path." Answer slot: if you have moved on-time or cost figures, say which and how. If not, say so, and say how you would measure them first. |
| F3 | "lead a team of 12 supervisors" (JD) | "currently a senior shift manager over 3 supervisors" (your message) | medium | [grounded] | transferability | You lead 3 supervisors now. Words: "I'm currently a senior shift manager over 3 supervisors." The step to 12 is not in your material; say it as a plan. |
| F4 | "5+ years operations leadership required" (JD) | "7 years in warehouse and distribution ops" (your message); "currently a senior shift manager over 3 supervisors" (your message) | low | [grounded] | hard_gate | Your material does not establish five years of leadership. The 7 years is operations work, and the start of your people-leadership role is not in it. The gate is not met by the material as it stands. Question (d) below asks it. |
| F5 | "build reporting in Excel/Power BI" (JD) | "never used Power BI" (your message) | none | [grounded] | capability | A gap you stated. Words: "I haven't used Power BI." Then how you would learn it, said as a plan, never as a past. |
| F6 | "build reporting in Excel/Power BI" (JD) | "solid Excel" (your message) | medium | [grounded] | transferability | Excel is self-rated; the material does not show reporting built in it. Words: "I'm solid in Excel." Answer slot: name one report you have built or maintained, if any. If none, say so and describe how you would build one. |
| F7 | "Lean/Six Sigma a plus" (JD) | "green belt certified" (your message) | medium | [grounded] | none | Your certification reaches the requirement. Lead with it by name: "I'm green belt certified." |

## Persona table

Weights for a hiring-manager round: Case/Strategist and Skeptic dominate, with Prober and Pressure behind them. Every plausible persona is touched so that none is met for the first time live.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (weight 5) | Probes scope and gaps: four sites, 12 supervisors, Power BI | High. The hiring manager is buying capability and derisking gaps (F1, F3, F4, F5) | Hold to what you did, concede the gap in one sentence, then give your plan |
| Case/Strategist (weight 4) | Live problems from this role: a bad week at a site, cost up in peak | High. Hiring managers test on their own roadmap | Structure out loud: what you check first, who you ask, what you decide |
| Data-Driven Prober (weight 4) | Asks for the denominator, the window, how the 40% was counted | Medium-high. The 40% is the most quotable figure you gave | Answer the four slots of the figure in your words, and say when you do not know |
| Pressure (weight 2) | Challenges the Power BI gap and the scope jump | Medium. A hiring manager may test composure on the weakest point | Hold the position you can back, then concede specifically |
| Conversational (weight 2) | Warm-up: motivation, the peak plan | Medium. Opens most rounds | Tell the story in your own words, short |

## Question banks

### Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've got seven years in warehouse and distribution. Why would you run four terminals at once?" | JD | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors" | Open with the seven years, then the shift you run now, in those words. Answer slot: the JD asks about four sites. If you have run anything across more than one location, say what and how, in your own words. If not, say so plainly and describe how you would run the daily cadence across four sites, as a plan. | F1 is the largest scope gap and the first thing a skeptic tests. JD because it scores the stated requirement |
| A2 | "The role needs five years leading operations. How long have you actually led people?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" | Answer with a year, not a feeling: the year your first role with people under you started, and what it was. Answer slot: if it is under five years, say the number plainly, then say what you bring from the years you have. | F4 is a gate the material does not establish. This is the question the gate exists to test |
| A3 | "Your mis-pick rate fell 40 percent. How was that counted, and what would make the number wrong?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Answer slot: this figure raises four slots: how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. Answer each in your own words. If you know the counting, say it. If you do not, say plainly that you would check it before defending it | F2 is the figure most likely to be probed. EXP because it tests what you actually did |
| A4 | "The targets here are on-time performance and cost per shipment. What have you moved on either?" | JD | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Start with the mis-pick work in its own terms. Answer slot: if you have moved on-time or cost figures, name them and how. If not, say so, say what you would measure first, and say where you see the pick-path work touching either, if you do | F2's gap, rehearsed so the honest answer is ready before the probe |
| A5 | "Our reporting runs in Excel and Power BI. Which can you run today?" | JD | [grounded] "solid Excel"; "never used Power BI" | Plain acknowledgment: "I haven't used Power BI." Then Excel, in your words, and a plan for learning Power BI. Do not say you have built dashboards | F5 is a stated gap and F6 is self-rated Excel; the honest answer is ready before the probe |

### Case/Strategist (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "On-time performance at one of your terminals dropped six points in three weeks. Walk me through your first week." | CASE | [generic] | Structure: pull the daily data first, then go to the floor and ask the supervisors what changed, then isolate by shift, lane and volume. Name what you contain now and what you decide once you have the cause. No claim about your past | A live problem from the JD's on-time requirement (F2). Presupposes nothing about you |
| B2 | "You inherit 12 supervisors across four sites with no shared KPI definitions. What do you standardize first?" | CASE | [generic] | Structure: definitions first, one owner per metric, one weekly review, then the supervisors who disagree. The raising source is the JD's "lead a team of 12 supervisors" | A live problem from F3's scope step. Generic because it is a pattern, not a fact about this employer |
| B3 | "Cost per shipment is up eight percent in peak. What levers do you look at, and what do you protect?" | CASE | [grounded] "ran the site's peak-season surge plan two years running" | Levers: scheduling against volume, overtime, mix, dock use. Name what you protect, such as safety staffing. Answer slot: if you want to draw on your peak plan, name one thing in it you would keep, and say how you would know it worked | A cost question the JD raises. The peak plan is the one thing in your material that touches it |
| B4 | "How would you build one report that your site leads and your director both trust?" | JD | [grounded] "solid Excel" | Definitions, one owner, one cadence, then the layout. Say you would build the first version in Excel, since that is what you are solid in, and plan the Power BI version after. Do not promise a Power BI build | The JD's reporting line (F5, F6). Answer the Excel part as you have it |
| B5 | "Four sites, one manager. How do you split your time?" | CASE | [generic] | Structure: the sites with the weakest numbers get the most time, a fixed visit rhythm, and the supervisors run the day. Say what you would not do, such as sit in one site all week | F1's scope step as a live problem. Generic |

### Data-Driven Prober (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Forty percent over what period, and per what: per pick, per order, per line?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Answer slot: the period and the unit. If you know them, say them. If not, say plainly that you would pull them before you quote the figure | The denominator is what a prober checks first. Distinct from A3's method question |
| C2 | "How did you know the peak plan was working? What did you measure?" | EXP | [grounded] "ran the site's peak-season surge plan two years running" | Answer with what you tracked and how often. Answer slot: if you ran it without a measure, say so and say what you would track next time | A probe for a plan you ran two years, which is the kind of claim that gets probed |
| C3 | "Which decisions on the pick-path redesign did you make alone, and which went to others?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Name the decision you made and the one you took to others. Answer slot: if the redesign was a team's work, say which part you led. Do not give the team's part as yours | Attribution. The redesign is the claim, and whose it was is the probe |
| C4 | "What would you do differently in the mis-pick work?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | One thing you would change, in your words, with a reason. Do not invent a regret for the interview | A reflective probe on the same work. Shows whether you know the weak point of your own result |

### Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Seven years in warehouses and you've never run Power BI. Why not hire someone who has?" | JD | [grounded] "never used Power BI"; "solid Excel" | Hold: "I haven't used Power BI, and I'm solid in Excel, so the first reporting I'd own is in Excel." Concede specifically on the Power BI gap, and state the learning plan. Hold through two follow-ups by returning to Excel and the plan | F5 pressed hard. The hold is only what you can back |
| D2 | "Your 40 percent is good, but you lead 3 people, not 12. Why would I trust the step?" | JD | [grounded] "currently a senior shift manager over 3 supervisors"; "cut mis-pick rate 40% by redesigning the pick path" | Hold the facts: 3 supervisors now, and the 40 percent came from the redesign you did. Concede the scope jump in one sentence, then say what you would do to test it in the first 90 days | F3 pressed. Hold what you did; concede the scale without inflating it |

### Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Tell me about the peak season plan you ran." | EXP | [grounded] "ran the site's peak-season surge plan two years running" | Story: what the plan was, why it ran two years, and what you would keep. Answer slot: name one part you would change | An open prompt. The peak plan is the story your material carries |
| E2 | "What made you want to move into operations management?" | EXP | [grounded] "currently a senior shift manager over 3 supervisors" | Motivation in your words, tied to what you already do: the people you lead now and the scope you want next. Do not invent a story | A warm-up that tests consistency between motivation and record |

**Coverage:**

| JD requirement | Question IDs |
|---|---|
| Own daily terminal operations across 4 sites | A1, B5 |
| Drive on-time performance and cost-per-shipment down | A4, B3 |
| Lead a team of 12 supervisors | B2, D2 |
| Build reporting in Excel/Power BI | A5, B4, D1 |
| 5+ years operations leadership required | A2 (and question (d) below) |
| Lean/Six Sigma a plus | none, and why: F7's quote already reaches the requirement, so it gets no separate question |

**Highest-ROI prep: A2 and A3.** The five-year leadership gate and the 40 percent figure are the two places a hiring manager is most likely to push. Rehearse both aloud before the round.

## Prohibited claims

Built locally from the fit snapshot. These are the claims a candidate reaches for under pressure. No guidance above asserts or implies them.

| Not coached | Basis | Honest form |
|---|---|---|
| Ran daily terminal operations across four sites | Inflated form of F1 | "7 years in warehouse and distribution ops." The material shows one site's operations, not four terminals |
| Drove on-time performance and cost per shipment down | Inflated form of F2 | "I cut mis-pick rate 40% by redesigning the pick path." The material shows accuracy work |
| Leads a team of 12 supervisors | Inflated form of F3 | "I'm currently a senior shift manager over 3 supervisors." |
| Built Power BI reporting | Negative you stated (F5) | "I haven't used Power BI." |
| Five years of people leadership | Gate the material does not establish (F4) | No claim. Answer slot in A2: the year your leadership started, in your words |

## Sources

- **Provided documents:** your message (the JD summary, and your background).
- **Searches and fetches:** none. The pack is built at L0.
- **Research tier:** L0 (no search run; see the upgrade menu).

| Target | Status | What it would have moved |
|---|---|---|
| 1. Atlas Freight values | unavailable | Values cheat sheet (not in this pack) |
| 2. Atlas Freight interview process, operations | unavailable | Loop structure and persona weights |
| 3. Atlas Freight strategy and recent news | unavailable | Grounding brief and CO questions |
| 4. Interviewer name and company | n/a | No interviewer named, so no query could be formed |
| 5. Representative JD | skipped | The JD you supplied fixes the fit snapshot |

## Upgrade menu

- The round type and who you are meeting → reweights the personas, and tells us whether a hiring manager or a peer dominates the banks
- Five years of leadership, with the start date of your first people-leadership role → resolves gate F4, and sharpens A2 into a grounded answer
- Atlas Freight research, at the default depth → a values cheat sheet, the interview loop structure, and current strategy for CO questions. Say yes and I'll run it
- Any presentation or case the recruiter assigned → a build section for each deliverable
- Your figures for on-time and cost per shipment, if you have them → upgrades F2 from transferability and lets A4 answer from your record
