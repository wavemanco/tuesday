Your prep pack is saved as /tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-tuesday-part-2-rooms-case-8-denied-bc75e1ba/e563da01-5e27-4385-a5bd-a8f7f70b5ea6/scratchpad/ashgrove_member_experience_lead_interview_pack.md and attached here. I built it as one fit snapshot shared across the three 20 November rounds, with a separate question bank for each round.

Three things to know first:

- **Presenting to senior leaders is the gap to prepare hardest.** It's a JD requirement and something you've said you haven't done above regional level. Question B6 is the highest-ROI prep. The pack has you state that plainly, then give a plan, and it doesn't coach a presentation you haven't made.
- **Contact-centre experience is also a stated gap** (F5, questions A5 and B7). It gets the same treatment.
- **Your evidence is thin.** Most answers rest on four sentences from your message: the complaints log, the escalation training, the spreadsheet, and six years in retail banking. The values round will want a specific decision for each value. The values sheet shows which ones you can't yet back with a story.

Research was provided documents only. I didn't search. I used the JD, the values text, the recruiter's email and your summary of the strategy brief. The strategy questions rest on your summary, not the full brief.

Two things would help me tighten it:

- Is the 20-minute case sent before 20 November, or given on the day? If it's sent, the panel bank changes.
- How many hours can you give this before the 20th? I'll size a prep schedule to that.

Say the word and I'll play the Head of Member Services on B6, the question the pack names as highest-ROI prep. I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove_member_experience_lead_interview_pack.md -----
# Interview prep pack: Member Experience Lead, Ashgrove Credit Union

**Candidate:** Dara
**Company:** Ashgrove Credit Union (member-owned, about 900 staff)
**Format:** Loop. Three rounds on 20 November 2026: recruiter (30 min), Head of Member Services (45 min, your future manager, mostly behavioural), panel of two branch managers (60 min, including a 20-minute complaint-escalation case, scored against the four values).
**Prepared:** 11 November 2026. First version, so no changelog.

---

## How to use this pack

- **Personas** describe how a question is asked. **Types** describe what is being scored.
- **Type key:** VAL = behavioural, scored against a published value. EXP = a deep-dive on your own experience. JD = a requirement from the job description. CO = company and strategy knowledge. CASE = a live problem from the role.
- **Guidance is scaffolding, not a script.** Say the sentences in your own words. Where a guidance cell says "answer slot", it means the honest answer depends on what you actually did, and the pack cannot supply it.
- **Provenance** shows which of your sentences a guidance cell rests on. A `[generic]` label means a pattern with no claim about you.

---

## Fit snapshot

Requirements are quoted from the JD you sent. Evidence is quoted from your own message. Nothing here is a summary of what you did.

**Gate check:** no requirement in the JD is a gate (authorisation, licence, location, schedule, pay, travel or a legal credential). All eight rows below are graded on fit and gap type.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" (JD) | "6 years in retail banking, the last 3 as branch supervisor" (your message) | medium | [grounded] | presentation | Your material says retail banking and branch supervisor, not customer operations by name. Keep the words: "I have six years in retail banking, the last three as a branch supervisor." Add no function name the material doesn't carry. |
| F2 | "experience handling regulated complaints" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | discovery | "Formal" is not the same as "regulated", and the material does not show which rules the log was kept to. Answer slot: if the log ran to a regulatory standard, say which and what you did to meet it, in your own words. If it ran to branch practice, say so plainly and stay with the log you handled. |
| F3 | "confident presenting to senior leaders" (JD) | "I've never presented to anyone above regional level." (your message) | none | [grounded] | capability | You stated this absence yourself, so the words can be given back: "I haven't presented to anyone above regional level." Then your plan for building the skill, said as a plan and never as a past. |
| F4 | "comfortable with Excel reporting" (JD) | "I built the monthly complaints spreadsheet our regional manager uses." (your message) | medium | [grounded] | none | The sentence reaches the requirement in role terms. It says spreadsheet, not Excel, so name the tool only as you used it. |
| F5 | "Own the member complaints process end to end across branches and the contact centre" (JD) | "Never worked in a contact centre" (your message) | none | [grounded] | capability | The contact-centre part is a stated absence: "I haven't worked in a contact centre." The branch part is covered at its own scope by F2. Do not join the two into end-to-end ownership. |
| F6 | "coach branch supervisors on escalations" (JD) | "trained new tellers on our escalation script" (your message) and "the last 3 as branch supervisor" (your message) | medium | [grounded] | transferability | Teller training is adjacent to supervisor coaching, not the same audience. State the adjacency and its limit. Answer slot: if you coached a supervisor on an escalation, say what and how. If not, say so and say what you would do first. |
| F7 | "work with digital teams on self-service journeys" (JD) | none given | none | [grounded] | discovery | The material is silent on digital work. Answer slot: if you worked with a digital or self-service team, say what it was in your own words. If not, say so, and say what you would bring to that team first. |
| F8 | "report monthly on complaint volumes and resolution times" (JD) | "I built the monthly complaints spreadsheet our regional manager uses." (your message) | medium | [grounded] | discovery | The sentence reaches monthly reporting but says nothing about resolution times. Answer slot: if you tracked resolution times, say which and how. If not, say so and say how you would measure them first. |

**Requirement grading, in one line:** F1, F4 are close to met. F2, F6, F8 need a rehearsed limit. F3, F5 are stated gaps and need a plain acknowledgment plus a plan. F7 is unevidenced.

---

## Grounding brief

**Source:** your summary of the strategy brief Ashgrove published in July 2026. The full brief was not in the material, so every fact below is as you summarised it. Check the wording against the brief before you quote it in the room.

- Move 40% of member service to digital channels by 2028.
- Consolidate eight branches into five hubs over 2027.
- Launch a small-business lending product in Q1 2027.
- The main competitive pressure is app-only banks.

Note for the room: the questions that rest on these facts are CO-tagged in the banks below. The pack does not coach you to correct the interviewer on any of them.

---

## Prohibited claims

Each entry names its basis and its honest form. These lines are built from the fit snapshot above: a claim you might reach for under pressure, and the form you can say instead.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process across branches and the contact centre | Inflated form of F2 and F5. Scope widened from a branch log to end-to-end | "I handled the branch's formal complaints log." The limit is the pack's observation: the material says the branch log, not the process. |
| Ran complaints to a regulatory standard | Inflated form of F2 | "I handled the branch's formal complaints log." The slot in F2 asks which rules applied, and the second branch lets that be none. |
| Wrote or set the escalation script | Inflated form of "trained new tellers on our escalation script" (F6) | "trained new tellers on our escalation script" at its own scope |
| Coached branch supervisors on escalations | Inflated form of F6 | "trained new tellers on our escalation script," with the supervisor gap stated as an answer slot |
| Presented complaints reporting to senior leaders | Inflated form of F4, and contradicted by F3 | "I haven't presented to anyone above regional level." |
| Worked in a contact centre | Negative you stated (F5) | "I haven't worked in a contact centre." |
| Advanced Excel modelling | Inflated form of F4. The sentence says spreadsheet | "I built the monthly complaints spreadsheet our regional manager uses." Name features only as you used them. |

---

## Round 1: Recruiter (30 min)

**Relationship:** recruiter. **Persona weights:** Conversational (top, 4 questions), Skeptic (light, 2), Data-Driven Prober (1). Reasoning: the recruiter screen is friendly in register and scored on logistics and motivation consistency. The risk is treating it as unscored. Light skeptic probes on the two stated gaps (F5 and F3) are likely, and one prober question sits on the spreadsheet because it is the only artefact you have.

**Persona table, this round**

| Persona | How it shows up | Likelihood | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport Builder | An unstructured opener, then casual questions about JD topics | High. Recruiter screens are unstructured | 90-second arc for the opening. Treat casual questions about the JD as scored |
| Skeptic | Probes the contact-centre gap and the regulated-complaints depth | Medium. Light, not a stress round | Plain acknowledgment, then plan. Don't bluff a capability you lack |
| Data-Driven Prober | One question on the spreadsheet | Low to medium. One question only | Name the counting method only as you know it. Name the weakest assumption in your own words |

**Question bank: Round 1**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So — walk me through the journey." | EXP | [grounded] "6 years in retail banking, the last 3 as branch supervisor" (your message) | Story-mapped on F1. Six years, the last three as a branch supervisor. Those are the beats the sentence states, in your own words, in about 90 seconds. Don't add a function name or a team size. | F1 is the arc a conversational opener starts from. Economy of language is what the persona scores. |
| A2 | "What draws you to a member-owned credit union?" | VAL | [grounded] "Members First, Always — we decide from the member's side of the counter" (values page, your paste) | Answer about the work, and about what a member-owned body does for members. Keep it to about 60 seconds. Anchor in the company's own sentence, not in a claim about your past. | A motivation probe the recruiter uses to test consistency. The provenance is the company's sentence alone, because nothing about you is asserted. |
| A3 | "Tell me about the most useful thing you've done with a complaint." | EXP | [grounded] "I handled the branch's formal complaints log" (your message) | Open prompt. Pick one instance. Story-mapped on the log: the beats are the log and your handling of it. Answer slot: if you changed how the log was kept or closed, say what and why. If you did not, say so and describe what you did with it. | An open prompt whose theme comes from the JD's complaints-process line. The answer slot keeps the claim inside the sentence. |
| A4 | "What are you playing with in Excel these days?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." (your message) | Casual register, scored. Name the spreadsheet in its own words. Answer slot: if you used particular Excel features, say which and what they did. If it was not Excel, say which tool. | F4 is the only evidence, and the material says spreadsheet. A casual question about a hot JD topic is still scored. |
| A5 | "I don't see a contact centre in your background — how would you handle that in this role?" | JD | [grounded] "Never worked in a contact centre" (your message) | Plain acknowledgment: "I haven't worked in a contact centre." Then a plan, said as a plan: what you would learn first and from whom. Hold through one follow-up by returning to the complaints work the log carries. Concede plainly what you don't yet know about contact-centre tools. | F5 is a stated gap. This is the skeptic's likeliest opener. At this round it is a probe, not a trap. |
| A6 | "What did the complaints log you handled have to meet?" | EXP | [grounded] "I handled the branch's formal complaints log" (your message) | Premised question. It presupposes the log had a standard, which the sentence does not state. Answer slot: if it ran to a regulatory standard, say which and what you did to meet it, in your own words. If it ran to branch practice, say so plainly and stay with the log you handled. | F2 is discovery. The premise comes from the JD's regulated-complaints line, so the second branch allows the premise to be false. |
| A7 | "Walk me through how the monthly spreadsheet counted complaints." | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." (your message) | Defend-the-number, in your own words: how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. Answer slot: if you did this, say how. If there was no such step, or it was not yours, say so plainly and describe what the spreadsheet did. | The spreadsheet is your only artefact, so it draws the prober's questions. The counting method is not in the material, so the guidance supplies none. |
| A8 | "Tell me about a time you coached someone on a complaint." | JD | [grounded] "trained new tellers on our escalation script" (your message) | Open prompt on the coaching line. Story-mapped on the sentence: you trained tellers on the script. Answer slot: if you coached a supervisor on an escalation, say what and how. If teller training is the nearest thing, say so and say what you would do with supervisors. | F6 is transferability. The open prompt's theme is the JD's coaching line; the slot keeps the claim at tellers. |

---

## Round 2: Head of Member Services (45 min)

**Relationship:** hiring manager, and your future manager. **Persona weights:** Values/Behavioural (top, 5 questions), Skeptic (3), Case/Strategist (light, 1). Reasoning: a hiring manager's prior is Case plus Skeptic, but the round is announced as mostly behavioural. That moves the top weight to Values/Behavioural, and the Skeptic keeps the highest-ROI objection. The Case persona is held at one question because no case is announced for this round.

**Highest-ROI prep in the pack: B6.** Presenting to senior leaders is a JD requirement and a stated capability gap (F3). It is the most likely objection in this round, and a hedged answer costs more than any other.

**Persona table, this round**

| Persona | How it shows up | Likelihood | Counter-strategy |
|---|---|---|---|
| Values / Behavioural | Scenario probes mapped to the four values, expecting STAR-shaped stories | High. Announced as the round's shape | One story per value where a sentence carries one. A selection scaffold with its honest branch where none does |
| Skeptic | Probes the presenting gap, the contact-centre gap and the reporting depth | High for B6 and B7. The round is their interview to decide | Plain acknowledgment, then plan. Hold through two follow-ups. Concede specifically |
| Case / Strategist | One live problem on the report or the seam | Low to medium | Clarify, then structure, then answer. Name one premise respectfully |

**Question bank: Round 2**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time you decided something from the member's side of the counter." | VAL | [grounded] "I handled the branch's formal complaints log" (your message) | Open prompt. Choose one decision, not the log as a whole. The sentence says handled. Answer slot: say the decision and what the member's side of it was, in your own words. If none comes to mind, say so plainly, then give the nearest thing the log carries. | Members First, Always is scored in both the manager round and the panel. This sentence is the only candidate evidence on the complaint side. |
| B2 | "When did you rewrite something a member had to hear twice?" | VAL | [grounded] "trained new tellers on our escalation script" (your message) | Open prompt on Plain Words. The sentence carries training, not rewriting. Answer slot: did you change the script's wording, and why? If you did, say the change. If not, say so and say what you would change first. | Plain Words is the value the escalation script touches. The material does not show a rewrite, so the slot keeps it there. |
| B3 | "Tell me about a branch's local situation that changed what you'd do." | VAL | [grounded] "6 years in retail banking, the last 3 as branch supervisor" (your message) | Open prompt. Story-mapped on the sentence: the role and the time spent in it. Answer slot: if a local situation changed a decision you made, say what it was. If you can't name one, say so and describe how you would learn a town's situation. | Neighbours, Not Numbers. The material shows where you worked, not how you worked with the town. |
| B4 | "Tell me about a complaint you kept hold of until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log" (your message) | Open prompt. The sentence says handled, not solved. Answer slot: say what you did from first contact to close, in your own words. If you did not see one through to solved, say so and say what you did when it went elsewhere. | Own the Fix. "Handled" is the nearest verb. "Until solved" is the claim not to borrow. |
| B5 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time you had to tell someone senior something they did not want to hear. It needs a named stake and an intact relationship at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it. | A persona stem for a scored values probe. None of your sentences carries this, so the guidance gives selection criteria, not a story. |
| B6 | "The role presents to senior leaders. What's your experience of that?" | JD | [grounded] "I've never presented to anyone above regional level." (your message) | The highest-ROI rehearsal in the pack. Hold: "I haven't presented to anyone above regional level." Then your plan, as a plan: how you would prepare for the first time, and whom you would practise with. Expect two follow-ups: "Who would your audience be?" and "What would you say in the first two minutes?" Answer both from the plan, not from a past. Concede specifically: you don't yet know what a senior audience expects. Never claim a presentation you have not made. | F3 is the one capability gap you stated, and the JD names it. A skeptic presses hardest the moment an answer hedges. |
| B7 | "I don't see a contact centre in your background. Why should I trust you with that side?" | JD | [grounded] "Never worked in a contact centre" (your message) | Plain acknowledgment: "I haven't worked in a contact centre." Then the plan, and what you would bring from complaints work: the log you handled. Concede plainly what you would need the contact-centre team to teach you. | F5 is the stated gap. The question is aimed at the requirement, not a claim that you failed at it. |
| B8 | "How would you run the monthly complaints report, including resolution times?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." (your message) | Answer slot on resolution times: if you tracked them, say which and how. If not, say so and say how you would measure them first. Keep to the monthly report the sentence gives. | F8 is discovery. The JD names resolution times; the material does not. |
| B9 | "Where would you start on a self-service journey for members?" | JD | [generic] | Answer slot: if you worked with a digital or self-service team, say what it was in your own words. If not, say so, and say what you would take to the digital team first. | F7 has no evidence. The material is silent on digital work, so the guidance makes no claim about it. |

---

## Round 3: Panel of two branch managers (60 min)

**Relationship:** panel. **Persona weights:** Values/Behavioural (top, 4 questions, because the panel scores against the four values), Case/Strategist (3, because the 20-minute escalation case sits here), Peer Evaluator (2, because branch managers are peers across branches). Reasoning: a panel blends the top two personas of each member's relationship. Without names, the blend is set by the round description.

**Persona table, this round**

| Persona | How it shows up | Likelihood | Counter-strategy |
|---|---|---|---|
| Values / Behavioural | Four scored values probes, plus the case's values content | High. The panel is the values round | One story per value where the sentences carry one. Selection scaffold where none does |
| Case / Strategist | The 20-minute escalation case, probably with a challenge to one premise | High. The case is announced | Clarify, then objective, then options, then decision, then what you'd change and measure. Name the weakest assumption |
| Peer Evaluator | Seam questions between branch and contact centre, and a credit-sharing probe | Medium. Branch managers are peers | Propose seam principles rather than pretending to know the seam. Offer what the branch managers would gain |

**Question bank: Round 3**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "What did you do when a member's need and a branch target pulled in different directions?" | VAL | [generic] | Selection scaffold. Pick a time a number pulled against a member. Name the stake and the decision you made. If none comes to mind, say so plainly, then give the nearest thing your material carries: the complaints log you handled. | Members First, Always, asked as a conflict. None of your sentences carries a conflict, so the guidance gives criteria. |
| C2 | "Tell me about a time you explained something so a member only needed to hear it once." | VAL | [grounded] "trained new tellers on our escalation script" (your message) | Story-mapped on the sentence: you trained tellers on the script. Answer slot: did you change the wording so a member needed it once? If you did, say how. If not, say so and say what you would change. | Plain Words. The sentence carries training. The result for members is not in the material. |
| C3 | "When did a branch's place in its town change your decision?" | VAL | [grounded] "the last 3 as branch supervisor" (your message) | Story-mapped on the sentence: three years as a branch supervisor. Answer slot: name a decision it changed, if one did. If none did, say so, and say how you would find out what the town needs. | Neighbours, Not Numbers. The material shows the time, not a decision made in the town. |
| C4 | "Tell me about a time you kept responsibility for a complaint after it moved to someone else." | VAL | [grounded] "I handled the branch's formal complaints log" (your message) | Open prompt. Answer slot: say what you kept hold of and what you did after the complaint moved. If it left and you let it go, say so plainly and say what you would do now. | Own the Fix. The panel will test the phrase "until it is solved" against your answer. Say only what the sentence supports. |
| C5 | CASE: "A member has complained three times about the same fee. The branch says it's closed. The member escalates to you. What do you do?" | CASE | [generic] | Structure, speakable in about two minutes. Clarify the three contacts and what each promised. Objective: answer the member's question in plain words, and check the branch's closure. Triage: who holds the file today, and the next contact date. Options: refund, explain, or escalate. Decision. What you tell the member. What you change for the branch. What you measure on the monthly report. Name your weakest assumption before they do. Where you don't know the regulatory timeline, say so and say how you would check it. | A live problem written as a pattern for the panel's escalation case. The real case will differ. It asks for no claim about your past. |
| C6 | CASE: "A branch supervisor tells you she can't clear her escalations backlog this month. What do you do?" | CASE | [generic] | Structure. Clarify volume, age and cause. Separate the stuck from the urgent. Coach her on the two or three she should close first. Decide what you will take off her desk. Measure next month. Hold the coaching, not the outcome. | Tests the coaching line in live form. No sentence of yours carries a backlog, so nothing about you is asserted. |
| C7 | CASE: "The digital team wants complaints handled in the app, and two branch managers object. Who decides, and how?" | CASE | [grounded] "move 40% of member service to digital channels by 2028" (your summary of the strategy brief) | Structure. Clarify what the app would handle and what it would hand off. Who can't use it. Who decides. A pilot measured on the monthly report. Name the strategy as the brief states it: 40% by 2028, not that complaints move to the app. | Strategy fluency under case pressure, tied to the digital line. The provenance sits on the company's stated target, not on anything you did. |
| C8 | "Our teams sit side by side. Where's the seam between branch and contact centre, and what happens when you disagree?" | JD | [generic] | Propose seam principles, not a seam you have never seen. Who owns the complaint at each handover. Who can reopen it. How a disagreement is settled, and by when. Reciprocity: say what the branch managers would gain from you, not only what you need from them. | The JD names branches and the contact centre, so the question raises a line the panel wrote. Peer Evaluator probe on the seam. |
| C9 | "How do you handle credit when work spans teams?" | JD | [generic] | Selection scaffold. Pick a time work crossed a team line and say who got credit and why. If none comes to mind, say so plainly, then give the nearest case your material carries, or how you would handle it. | A peer's credit probe. None of your sentences carries shared credit. |

---

## Values / principles cheat sheet

Detected: the panel round is the values round, scored against the four values below. Working meanings are paraphrased from the published text.

| Value (official name) | Working meaning | Your mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | Selection scaffold, honest branch. Your B1 answer rests on "I handled the branch's formal complaints log" (F2). The decision and the member's side of it are yours to name. If none, say so. |
| Plain Words | If a member needs it explained twice, the wording was wrong | "trained new tellers on our escalation script" (F6). The beats are training on the script. Whether you changed its wording is an answer slot. |
| Neighbours, Not Numbers | Every branch is part of its town | Selection scaffold, honest branch. Your sentences show three years as a branch supervisor (F1), not a decision made with the town. C3 rests on that and no more. |
| Own the Fix | Keep hold of a problem until it is solved | "I handled the branch's formal complaints log" (F2). "Handled" is what the sentence says. "Until solved" is the claim to avoid borrowing. |

**Gap in the values sheet:** you have one real sentence per value at most, and two values have none. The panel will want a specific decision for each. The upgrade menu says how to get them.

---

## Reverse questions

Each question has a "why it lands" line. The panel is the only round with peers present, so the reciprocity question is asked there. No interviewer profiles were supplied, so no question is tied to an interviewer's own career path.

1. **Recruiter:** "What does the panel score highest in the case?" Why it lands: it signals you are preparing for the scored parts, not the story.
2. **Head of Member Services:** "What would the team want from this role at day 90?" Why it lands: it asks for the manager's standard, and the answer tells you how much the presenting gap matters to them.
3. **Head of Member Services:** "Which of the complaints numbers do you most want to see move in the first six months?" Why it lands: it shows you think in outcomes, and it sets up B8 on resolution times.
4. **Head of Member Services:** "How will complaint handling change as branches consolidate into hubs?" Why it lands: it uses the eight-to-five consolidation in the strategy summary. It reads as diligence on the actual job.
5. **Panel:** "Which escalation decisions do branch managers make alone today, and which go up?" Why it lands: it maps the coaching role, and it tells you where the seam sits before C8 asks.
6. **Panel (reciprocity):** "What could a new person do in their first month that would genuinely help your branch?" Why it lands: a peer reciprocity question. It turns the panel from judges into people with a stake in the hire.

---

## Requirement coverage

| JD requirement | Question IDs | Notes |
|---|---|---|
| 4+ years in financial-services customer operations | A1 | F1 |
| experience handling regulated complaints | A6, B4 | F2, discovery. The answer is a limit, not a claim |
| confident presenting to senior leaders | B6 | F3, capability. Highest-ROI prep |
| comfortable with Excel reporting | A4, A7 | F4 |
| Own the member complaints process end to end across branches and the contact centre | A3, A5, B7, C4, C5, C8 | F2, F5 |
| report monthly on complaint volumes and resolution times | A7, B8 | F8, discovery |
| coach branch supervisors on escalations | A8, C6 | F6, transferability |
| work with digital teams on self-service journeys | B9, C7 | F7, discovery. No evidence |

Every requirement has at least one question. None is uncovered.

---

## Sources

- **Provided documents:** the JD (your message); the Ashgrove values text, from ashgrovecu.org/about/values, copied 11 November 2026 (your paste); the recruiter's email on the process; your summary of the July 2026 strategy brief; your background (your message).
- **Document not in the material:** the full strategy brief. The grounding brief uses your summary.
- **Dossier:** none present. The pack is built from raw inputs.

**Research tier:** L0, provided documents only.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | The values text you pasted fixes the values cheat sheet. No search was needed. |
| 2. Ashgrove interview process | skipped | The recruiter's email fixes the three rounds and their shape. |
| 3. Ashgrove strategy and recent news | skipped | Your summary of the strategy brief fixes the grounding brief and the CO-tagged questions. The full brief would sharpen them (upgrade menu). |
| 4. Interviewer names | n/a | No names were given, so there was no query to form. |
| 5. Representative JD for the title | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions. |

---

## Upgrade menu

- **Full strategy brief text.** Turns the grounding brief from your summary into quotable wording, and lets C7 and the reverse questions quote the brief directly.
- **Interviewers' names.** For the Head of Member Services and the two branch managers, a read of their public professional footprint gives persona weights, and a reverse question tied to their career path. Public footprint only: no contact details, nothing personal.
- **The 20-minute case brief, if sent in advance.** Turns C5 and C6 into grounded cases instead of the generic pattern, and it may add a pre-declared deliverable section.
- **Hours available before 20 November.** Adds a prep triage schedule sized to the time you have, and a drill order.
- **Which rules the complaints log was kept to, and whether you tracked resolution times.** Upgrades F2 and F8 from answer slots to grounded answers, and sharpens A6, B8 and C5.
- **Any contact-centre, digital or supervisor-coaching work, even informal.** Upgrades F5, F6 and F7. Covering a phone queue or coaching a colleague on a complaint would each count.
- **One real decision per value.** Each specific decision you made, in your own words, upgrades a values row from scaffold to story. Panel bank C has the most to gain.
- **Deep research (L2), offered once.** Would add the full strategy brief, interviewer footprints where named, and role-family loop reports. Cost: up to six further searches and two further fetches, a few extra minutes.
- **Dossier.** A tuesday-dossier.md, if you carry one, would add a verified evidence list and the objections this prep exposed.
