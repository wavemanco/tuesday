The prep pack is saved as `northwind-data_senior-gtm-strategy-lead_interview_pack.md` in your scratchpad, and I've attached it.

It covers 20 questions across six personas, weighted for a peer round. Peer Evaluator and Data-Driven Prober get five questions each, because Dan calls himself "relentlessly data-driven." Case/Strategist and Skeptic get three each, and Pressure and Conversational get two each. Each question has a type tag, a provenance label, answer guidance, and a rationale. The pack also includes a requirement-coverage table, a prohibited-claims list, and five reverse questions. One of them ties to Dan's startup chapter, and one is a reciprocity question.

Things you should know:

- **Highest-ROI prep is D1,** "I don't see quota-setting or sales ops in your background." It's the gap your notes flag, and it sits in Dan's own domain. The guidance has her hold, concede specifically, then give a ramp plan. She should not claim quota experience.
- **The $400M figure gets the deepest defend-the-number work** (B1, B2, E2). Your notes don't say how it was counted, so the pack leaves those as answer slots and doesn't supply a method.
- **Web search was refused** (permission not granted), so nothing about Northwind's strategy or Dan's public footprint is verified. Strategy comes only from your research note, which is undated. Confirm the Compass and bundling framing before quoting any numbers from it.
- **Your inputs were enough to build the pack,** so I asked no clarifying questions. The upgrade menu lists what would sharpen it, mainly the full JD text, the full CV, and a recruiter note on the round format.
- Evidence is quoted from your notes as you summarized them, not from a CV. Check each quoted sentence against your real record before you rehearse it.

Want a 15-minute drill on B1, the number-counting question? I can play Dan as the Prober and give feedback against the question's guidance. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, or convert the pack to Word.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: northwind-data_senior-gtm-strategy-lead_interview_pack.md -----
# Northwind Data — Senior GTM Strategy Lead, Emerging Products: interview prep pack

**Round:** single 60-minute conversation, peer round
**Interviewer:** Dan Kovac, Director of Sales Strategy (peer; both report to the same VP)
**Candidate:** you (Priya)
**Built from:** the JD highlights, your background notes, the interviewer profile summary, and your research note. No full JD or CV text was supplied, and web search was not granted (see Sources).

First version, so no changelog.

---

## 1. How to use this pack

- **Personas** describe how a question arrives (tone, style, what the person is checking). **Types** describe what is being scored.
- **Type key:** **JD** = a stated responsibility or qualification; **EXP** = a claim from your past that has to survive scrutiny; **CO** = company and strategy knowledge; **CASE** = a live problem with no past claim inside it; **VAL** = behavior tied to published values (none detected for this round).
- **Provenance:** `[grounded]` traces to a document you gave me or a sentence you wrote; `[inferred]` is my derivation and the derivation is named; `[generic]` is a role or persona pattern with no claim about you or the company.
- Guidance is scaffolding for a spoken answer, not a script. Where guidance says "answer slot," it means your own account goes there, and either honest branch is a valid answer.

---

## 2. Fit snapshot

Requirements are the JD highlights you gave, quoted as you wrote them. Evidence is quoted from your background notes (labelled "coach's notes" below, because you gave them to me in summary form). Nothing else goes in the evidence column.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" (JD highlights) | "proposed a store-surface change credited with a ~$400M ARR uplift" (coach's notes) | medium | [grounded] | transferability | Your notes show product strategy that moved a large ARR figure, not go-to-market ownership of new product lines. Bridge at the quote's own scope: "I proposed a store-surface change, credited with a ~$400M ARR uplift." Answer slot: if you set any go-to-market decision for a product, say which and how you decided; if you did not, say so and describe what you did own. |
| F2 | "identify whitespace across land/adopt/expand/renew" (JD highlights) | "built a partner-level revenue model used in carrier negotiations" (coach's notes) | medium | [grounded] | transferability | A revenue model is adjacent work, not a whitespace map across the four lifecycle stages. Words at scope: "I built a partner-level revenue model used in carrier negotiations." Answer slot: if you mapped any of land, adopt, expand or renew in that model, say which and how; if you did not, say so and say what the model did show. |
| F3 | "run independent analysis in SQL and Tableau" (JD highlights) | "skilled in SQL/Tableau" (coach's notes) | low | [inferred] | discovery | Your notes show a skill, not an analysis you ran from raw data to a decision. Bridge stays with the skill claim; do not describe an analysis you have not named. Answer slot: if you have an analysis you ran end to end, say what it was and what it changed; if not, say so and say what you would walk through first. |
| F4 | "partner-motion design experience required" (JD highlights) | "built a partner-level revenue model used in carrier negotiations" (coach's notes) | medium | [grounded] | transferability | The closest adjacent work is partner-facing revenue modelling. Design of a partner motion (how partners are routed, incentivized or supported) is not in your notes. Bridge at scope: the model, and where it was used. Answer slot: if you designed any part of how a partner was engaged, say what and how you decided; if not, say so. |
| F5 | "strong cross-functional influence" (JD highlights) | "set annual volume targets with cross-org consensus" (coach's notes) | medium | [grounded] | presentation | The quote already reaches cross-org influence in other terms. Bridge rewords only that quote and adds no practice: "I set annual volume targets with cross-org consensus." |
| F6 | "AI experience a plus" (JD highlights) | "uses AI tools daily" (coach's notes) | low | [inferred] | transferability | Daily use is adjacent to AI experience, not the same thing. Words at scope: "I use AI tools daily." Pack observation, not words for you: your notes say use, not building. |
| F7 | Quota-setting and sales-ops background (not in the JD highlights; a role-family expectation for a sales-strategy peer) | "No classic sales-ops or quota-setting experience" (coach's notes) | none | [grounded] | capability | A stated absence, so no bridge can close it. Plain acknowledgment, if this is accurate for you: "I haven't run sales operations or set quotas." Then the nearest thing your notes carry, at its own scope: F5's "set annual volume targets with cross-org consensus." Never describe quota work you have not done. |

**Gate check:** the JD highlights list no term gates (location, work authorization, schedule). The full JD may contain some; see the upgrade menu.

---

## 3. Grounding brief (from your research note)

Your research note is the strategy input for this pack. Web search was not granted, so the note is the only source for current strategy. Its date is not stated, so treat it as unverified for currency.

- Stated priorities: "enterprise expansion, an AI copilot launch ('Compass'), and reaching profitability" (your research note).
- Main competitive threat: "bundling by a much larger platform vendor" (your research note).
- Vocabulary to use: enterprise expansion, Compass, profitability, bundling. Confirm the framing before you quote any figure from the note.
- If the interviewer's framing differs from the note, follow the interviewer's framing. Do not coach yourself to correct them.

---

## 4. Reading the interviewer

Source: your interviewer profile summary (public professional self-description only). No web footprint was retrieved.

- **Career pattern:** pricing and monetization roles, with one early-stage startup chapter.
- **Self-description:** "relentlessly data-driven."

Practical implications:

1. Every number you give will be taken back to its assumptions. Name your weakest assumption before Dan asks.
2. Case questions will likely lean toward pricing, packaging and unit economics. That is their native language, so use its terms without over-explaining.
3. The startup chapter makes builder-style and scrappiness probes likely. Your notes show no early-stage chapter, so answer in your own words and do not borrow theirs.
4. **Mirror opportunities:** none offered. Your notes do not show a professional path that matches Dan's startup chapter, and a shared identity is not a strategy.

---

## 5. Persona table

Relationship prior for a peer round: Peer Evaluator and Data-Driven Prober dominate. Interviewer signals raise the Prober further. The round is a single session, so no loop adjustment applies. Values/Behavioral is not weighted: no values round is detected, and the peer prior does not include it.

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy | Questions |
|---|---|---|---|---|
| Peer Evaluator | Seam-splitting, "what would you need from me," credit probes | High (5): peer prior dominant; Dan prices what the hire adds to their own work | Reciprocity first: what you bring to their team. Propose seam principles, not a seam you have not seen | A1, A2, A3 |
| Data-Driven Prober | Asks for denominators, assumptions, "how was that counted" | High (5): self-described "relentlessly data-driven" raises this above the peer prior | Name the weakest assumption before being asked. Say plainly when you do not know how a figure was counted | B1 to B5 |
| Case / Strategist | Live whitespace, packaging or competitive problems | Mid (3): pricing-career spine tilts cases toward pricing and unit economics | Clarify, then structure, then answer. Use pricing vocabulary | C1 to C3 |
| Skeptic | "Where is the quota work?" and "why should I trust you with this" | Mid (3): your largest gap is the most predictable objection, and it sits in Dan's own domain | Hold the plain acknowledgment, bridge only from quoted adjacent work, state a ramp plan as a plan | D1 to D3 |
| Pressure / Stress | Time-boxed challenges to a single claim | Low (2): not in the peer prior; probed only if Dan slips into a stress register | Pause, restate, hold through two follow-ups, concede specifically | E1, E2 |
| Conversational / Rapport | Warm opener, casual check on the AI topic | Low (2): a friendly opener is still scored | A 90-second arc from your own sentences; treat casual AI questions as scored | F1, F2 |

**Highest-ROI prep:** D1. It is the objection the fit snapshot exposes most directly (F7), and it is in the domain Dan runs. It gets the deepest rehearsal.

---

## 6. Question banks

### Requirement coverage

| JD requirement (or flagged gap) | Question IDs |
|---|---|
| "own GTM strategy for two new product lines" | C3, D2 |
| "identify whitespace across land/adopt/expand/renew" | B5, C3 |
| "run independent analysis in SQL and Tableau" | B3 |
| "partner-motion design experience required" | B4, D2 |
| "strong cross-functional influence" | A1, A3 |
| "AI experience a plus" | F2, C2 |
| Quota-setting and sales-ops (F7; not a JD line) | D1, E1 |
| Headline figure: ~$400M ARR (defend-the-number slots) | B1, B2, E2 |

### Peer Evaluator (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Our teams sit side by side. Where's the seam between your work and mine, and what happens when we disagree?" | JD | [generic] persona stem | Propose seam principles, not a seam you have not seen: one rule for who owns a number, one for who owns a customer conversation. For disagreement, pick a time you disagreed with a peer on a call. It needs a named disagreement, what you did, and how it ended. If none comes to mind, say so plainly, then give the nearest thing your notes carry: [grounded] "set annual volume targets with cross-org consensus" (F5). | Peer prior puts the seam question first. F5 supplies the only quoted cross-org decision; the disagreement story is an answer slot because none is quoted. |
| A2 | "How do you handle credit when work spans teams?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Say what you did in your own words, and name who else was on the change. Answer slot: if others contributed, name them and what they did; if you were the only one, say so plainly. Never claim the full credit the number carries. | Credit probes are common in peer rounds. F1 is the only quoted credit, so the answer must stay at its scope. |
| A3 | "What would you need from my side that you don't get today?" | JD | [generic] persona stem | Reciprocity first: say what you would give their team before asking for anything. Keep the ask specific and small. | Tests cross-functional influence (F5) in a collegial frame, and gives the reciprocity signal peers weight. |

### Data-Driven Prober (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Walk me through how the $400M number was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Defend-the-number slots, in your own words. (a) How it was counted: if you did this, say how; if you did not count it, say so plainly. (b) What it is sensitive to. (c) The assumption you would defend least. (d) Which part was yours: the proposal, not the outcome. Your notes do not say how the figure was built, so do not supply a method. | Headline figure, so it draws the four defend-the-number slots. The honest answer is "I don't know how it was counted," which is allowed. |
| B2 | "Which assumption behind that number would you defend least?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Name the weakest assumption before Dan does, in your own words. If you do not know the assumptions, say that plainly and say what would tell you. Do not name an assumption you cannot back. | Prober follow-up to B1. Naming your own weak point converts a gotcha into a credibility gain. |
| B3 | "Tell me about an analysis you ran in SQL or Tableau, from raw data to a decision." | JD | [inferred] "skilled in SQL/Tableau" (low confidence; coaching note only) | Open prompt. Answer slot: if you have an analysis you ran end to end, say what the question was, what you pulled, and what changed. If not, say so plainly and say what you would walk through first. Never describe an analysis you have not named. | F3 is low confidence, so the guidance is a clarify note, not a story. The question's theme comes from the JD's "run independent analysis" line. |
| B4 | "Walk me through the partner-level revenue model. What were its inputs, and how would you design the partner motion that uses it?" | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" | Describe the model at its own scope: what it was built to do and where it was used. Answer slot on the design half: if you designed any part of how a partner was engaged, say what and how you decided; if you did not, say so and give the design principles you would start from. | Premised on F2 and F4. The design half is forward-looking and presupposes nothing about your past. |
| B5 | "Define whitespace the way you'd use it in a land, adopt, expand, renew plan. How would you count it?" | JD | [grounded] "identify whitespace across land/adopt/expand/renew" (JD highlights) | Define whitespace as an uncaptured share of a customer's need at a given stage. Say what denominator you would use and why. This is a concept question, so no past claim belongs in it. | Scores the JD's whitespace requirement directly, with no claim about your history. |

### Case / Strategist (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A much larger platform vendor starts bundling a data product into its suite at no extra charge. How would you size our exposure?" | CO, CASE | [grounded] "bundling by a much larger platform vendor" (your research note) | Clarify (which customers, which products), then objective, segmentation, approach, metrics, risks. Use packaging and unit-economics language. Challenge one premise respectfully, for example that bundling hits every segment equally. Name the framing as your reading of the note. | The note names bundling as the main threat, and Dan's pricing career makes this a native question. No past claim is made. |
| C2 | "We're launching Compass, an AI copilot. Where does it change the land-to-expand motion for a customer already on the platform?" | CO, CASE | [grounded] "an AI copilot launch ('Compass')" (your research note) | Structure the answer around the customer's lifecycle stages. Say which assumption about Compass's uptake you would test first. Note that the note is undated, so do not quote its figures. | The note's AI launch is a stated priority, and the JD lists AI as a plus. This tests whether you can connect the two. |
| C3 | "Pick one of the two new product lines and tell me the first whitespace question you'd answer." | JD, CASE | [grounded] "own GTM strategy for two new product lines" (JD highlights) | Ask first: who buys it, and what do they already buy. Then name one whitespace question and how you would answer it. Make no claim about having done this before. | Tests the headline JD requirement as a live problem. A case about the role itself presupposes nothing about your past. |

### Skeptic (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "I don't see quota-setting or sales ops in your background. How would you handle that in this role?" | JD | [grounded] "No classic sales-ops or quota-setting experience" (coach's notes) | **Highest-ROI rehearsal.** Hold, then concede, then plan. (1) Open with the plain acknowledgment: "I haven't run sales operations or set quotas." (2) Bridge only from quoted work, at scope: "I set annual volume targets with cross-org consensus." (3) First follow-up, "What's the difference between a volume target and a quota?": concede the difference specifically, and do not claim quota knowledge you cannot back. (4) Second follow-up, "Then why would your targets hold?": hold by naming the consensus step only as far as you ran it; if you did not run the step, say so. (5) Concession and ramp, as a plan: "I'd spend the first weeks with the current quota model and your sales ops before proposing any change." | F7 is the largest gap and the most predictable objection. The rubric's deepest rehearsal goes here because this question will be asked in some form. The question names only a negative from your notes, so it presupposes nothing else. |
| D2 | "Which part of this JD would you be weakest at on day one?" | JD | [generic] persona stem | Pick the requirement your notes show least evidence for and say so plainly. Your notes show least for SQL/Tableau independent analysis (F3) and partner-motion design (F4). Give the ramp you would use. | A calibrated-candor probe. Naming a weak point with a ramp scores better than a bluff. |
| D3 | "Why leave consumer tech for enterprise data infrastructure?" | CO | [grounded] "9 at a large consumer-tech company in product strategy & ops" | Your notes give no motivation, so this is an answer slot: say what drew you, in your own words. Do not borrow a reason from the role. | Motivation is a scored probe for a peer. The notes carry the consumer-tech years but no reason for the move. |

### Pressure / Stress (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who has run a quota?" | JD | [grounded] "No classic sales-ops or quota-setting experience" (coach's notes); [grounded] "built a partner-level revenue model used in carrier negotiations" (coach's notes) | Pause, restate the question, then answer. Hold the case on the quoted work: the revenue model used in carrier negotiations, and the volume targets set with cross-org consensus. Concede specifically: "I haven't carried a quota." Do not fold on the core claim. | A time-boxed challenge to one claim. The hold is only what your notes carry. |
| E2 | "That result, how much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Hold: "I proposed the change." Concede what you do not know: how the credit was split, and whether the uplift would have come without it. Do not claim the full figure. | Attribution test for the headline number. The concession must be specific, or it reads as a fold. |

### Conversational / Rapport (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm"; [grounded] "9 at a large consumer-tech company in product strategy & ops" (coach's notes) | A 90-second arc that uses only these two sentences: consulting, then consumer tech in product strategy and operations, then why you are here (answer slot, in your words). Do not add titles, teams or scope. | Friendly openers are scored. A pre-scripted arc keeps the biography tight and within what your notes carry. |
| F2 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" (coach's notes); JD highlights: "AI experience a plus" | Name the tools you use daily, in your words. Do not describe building anything. | A casual form of the JD's plus-skill question. Scored like any other. |

---

## 7. Reverse questions

At least five, each with why it lands. Use them at the end of the conversation, not as a list.

| # | Question | Why it lands |
|---|---|---|
| R1 | "Your career has been pricing and monetization, with one startup chapter. What from that chapter still shapes how you set a price?" | Ties to Dan's own path. It turns the interview into a peer conversation and shows you researched them, not only the company. |
| R2 | "What could a new person do in their first month that would genuinely help your team?" | Reciprocity question for a peer. It signals that you are thinking about their load, not only your own. |
| R3 | "If a platform bundle hit the market, which part of Northwind's pricing would it test first?" | Uses the competitive threat from your research note. It invites Dan's pricing view, the topic where they are strongest. |
| R4 | "How do sales strategy and Emerging Products divide the whitespace work today?" | Surfaces the seam directly. The answer tells you where you would sit. |
| R5 | "What would make Compass a success for sales strategy in its first two quarters?" | Uses the AI copilot priority from your note. It shows you have connected the priorities, and it gets the answer you need on the AI plus. |

---

## 8. Prohibited claims

Built locally from the fit snapshot, since no dossier was supplied. Each entry names its basis, and the honest form is the quote at its own scope.

| Not coached | Basis | Honest form |
|---|---|---|
| Negotiated with carriers | Inflated form of F2 and F4: "used in carrier negotiations" widened to "I ran the negotiations" | F2's quote at scope. Pack observation, not words for you: the notes say the model was used in negotiations, not that you led them |
| Drove or delivered the ~$400M ARR | Inflated form of F1: "credited with" widened to "I delivered" | "I proposed a store-surface change, credited with a ~$400M ARR uplift." |
| Owned quota or sales-target setting, or ran sales ops | Inflated form of F5 and F7: "set annual volume targets" widened to quota ownership | F5's quote at scope, with F7's plain acknowledgment |
| Designed partner motions | Inflated form of F4: a revenue model widened to partner design | F4's quote at scope, and the answer slot in B4 |
| Built AI features or AI products | Inflated form of F6: "uses AI tools daily" widened to building | "I use AI tools daily." |
| Ran independent SQL/Tableau analysis at scale | Inflated form of F3: "skilled in" widened to a track record | "skilled in SQL/Tableau," plus the answer slot in B3 |
| Mapped whitespace across land, adopt, expand and renew | Inflated form of F2: a revenue model widened to a lifecycle map | F2's quote at scope, and the answer slot in B5 |

---

## 9. Sources

- **Provided documents:** your message (JD highlights; your background notes, which I treat as coach's notes; the interviewer profile summary; the research note).
- **Searches sent:**
  1. "Northwind Data B2B data infrastructure company strategy news": refused (web search permission not granted).
  2. "Dan Kovac Director of Sales Strategy Northwind Data": refused (web search permission not granted).
- **Fetches:** none.

**Research tier: L1 — searches 2 of 6, fetches 0 of 2**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Northwind Data values` | unavailable | No values round is detected for this peer session, so no values section is built. No search was sent, and no values page was provided. |
| 2. `Northwind Data interview process` | skipped | Your description of a single 60-minute peer conversation establishes the session structure; the search would only have added rounds from a wider loop |
| 3. `Northwind Data strategy` / recent news | unavailable | Query 1 was refused. The search would have checked the currency of your research note and added recent moves to the grounding brief |
| 4. `Dan Kovac Northwind Data` | unavailable | Query 2 was refused. The interviewer read rests on your profile summary only; the search would have added public talks or posts for persona weights and the reverse questions |
| 5. Representative JD | skipped | The JD highlights you supplied fix the fit snapshot and the JD questions |

---

## 10. Upgrade menu

- **Full JD text** → the six requirement rows become quoted and grounded, and the gate check can see any term gates (location, work authorization, schedule).
- **Full CV text** → the evidence column quotes your CV directly. The rows currently sourced to coach's notes move to CV-grounded.
- **Your own account of how the ~$400M was counted, and which part was yours** → B1, B2 and E2 move from answer slots to grounded guidance.
- **Web search permission granted** → runs the two refused searches and the strategy currency check. Dan's public talks and posts would sharpen the persona weights and the reverse questions.
- **A recruiter email on the round format** → tells us whether the 60 minutes includes a case or a pre-read, which would reweight the Case persona.
- **A sentence about an analysis you ran in SQL or Tableau** → F3 moves from low confidence to grounded, and B3 gets a story map.
- **A deeper research pass (offered once)** → up to 6 more searches and 2 more fetches, several more minutes, for a company strategy brief to strengthen the Case bank.

