Your prep pack is saved as `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-tuesday-part-2-rooms-case-2-denied-ccfa3f94/bc6db436-95f2-4657-9247-1ca4a7d6a416/scratchpad/atlas-freight_operations-manager_interview_pack.md`, and I've attached it here. I built it for a hiring-manager round, since your note didn't say who you're meeting. Company research didn't run because web search was refused in this session, so the pack has no Atlas-specific values, process or strategy.

The main thing to prepare is scale. Your material shows three supervisors at one site, and the JD asks for twelve across four sites. Question A1 in the pack is the most likely hard question, and it's where the material is thinnest, so rehearse it until your answer is plain and doesn't claim more than you ran. Power BI is the other clear gap: say "I haven't used Power BI" and give a plan for learning it, not a past.

Say the word and I'll play the Skeptic on A1 as a live drill.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Is the person you're meeting your future manager, or a peer on the team? The answer reweights every bank.
Can you work the four sites and the shift pattern the role needs, including travel between sites? The JD doesn't say, and your material doesn't either, so I've flagged it as a gate in the pack.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: atlas-freight_operations-manager_interview_pack.md -----
# Interview prep pack: Operations Manager, Atlas Freight

**Role:** Operations Manager, daily terminal operations across 4 sites, 12 supervisors
**Company:** Atlas Freight (regional logistics, 800 employees)
**Interviewer:** not named
**Round:** not stated. Built for a hiring-manager round with flat weights (see Persona table).

## 1. How to use this pack

- **Personas** describe how a question is asked. **Types** describe what is being scored.
- Type key: **JD** = a stated requirement of the role. **EXP** = your own past work, checked for attribution. **CASE** = a live problem from the role. **CO** = company knowledge (none included, because company research did not run). **VAL** = values (none included, because no values round is documented).
- Guidance is scaffolding, not a script. Say only what your own words can stand behind.

## 2. Fit snapshot

Requirements are quoted from the JD. Your evidence is quoted from your message. Nothing outside those quotes is treated as something you did.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" (JD) | "7 years in warehouse and distribution ops" (your message); "currently a senior shift manager over 3 supervisors" (your message) | medium | [grounded] | transferability | Your material shows seven years in warehouse and distribution operations, and a shift-manager role over three supervisors. It does not show ownership of terminal operations across four sites. Answer slot: if you have owned daily operations at more than one site, say which and how, in your own words. If your ownership was one site or one shift pattern, say that plainly and describe its scope. |
| F2 | "drive on-time performance and cost-per-shipment down" (JD) | "cut mis-pick rate 40% by redesigning the pick path" (your message) | medium | [grounded] | transferability | Your material shows an accuracy result: mis-pick rate. It does not show on-time performance or cost per shipment. The bridge stays at that quote's scope. Answer slot: if you tracked on-time or cost per shipment in any role, say the figure and how it was counted. If you did not track either, say so and say what you did track. |
| F3 | "lead a team of 12 supervisors" (JD) | "currently a senior shift manager over 3 supervisors" (your message) | medium | [grounded] | transferability | Your material shows three supervisors. The JD asks for twelve. Answer slot: if you have led a larger group of supervisors or managers, say what that was. If your team was three supervisors, say so and describe how you led them. |
| F4 | "5+ years operations leadership required" (JD) | "7 years in warehouse and distribution ops" (your message); "currently a senior shift manager over 3 supervisors" (your message) | medium | [grounded] | transferability | Seven years of operations work is in your material. Your material does not show how many of those years were in a leadership role. Answer slot: say how many years you held a leadership role, and the title and scope of each, in your own words. |
| F5 | "build reporting in Excel/Power BI" (JD), Excel half | "solid Excel" (your message) | low | [inferred] | discovery | Your material says Excel skill, but it does not say what you built in Excel or who used it. Answer slot: if you have built reports others relied on, name the report, its audience and what it measured. If you have not, say so and say what you would build first. |
| F6 | "build reporting in Excel/Power BI" (JD), Power BI half | "never used Power BI" (your message) | none | [grounded] | capability | Your message states the absence. Words: "I haven't used Power BI." Then how you would learn it, said as a plan and never as a past. |
| F7 | "Lean/Six Sigma a plus" (JD) | "green belt certified" (your message) | medium | [grounded] | none | The quote reaches the requirement in its own terms. The caveat is that a certificate is limited proof, so expect a probe on what you applied it to. Lead with the belt in those terms. |
| F8 | "Own daily terminal operations across 4 sites" (JD), on-site and shift terms | none given | none | [inferred] | hard_gate | Your material does not establish location, shift pattern or travel across the four sites. This is surfaced, not bridged. The pack will not script a workaround. Step 1 asks whether it is met. |

## 3. Prohibited claims

Claims this pack will not coach, and why. These are built locally from the fit snapshot, because no dossier was supplied.

| Not coached | Basis | Honest form |
|---|---|---|
| Owns terminal operations across four sites | Inflated form of F1 | Your material shows a shift-manager role over three supervisors. The limit is the pack's observation, not words for you. |
| Led twelve supervisors | Inflated form of F3 | Your material shows three supervisors. |
| Has used Power BI, or has built Power BI reporting | Negative you stated, F6 | "I haven't used Power BI." No slot. |
| Improved on-time performance or cost per shipment | Inflated form of F2 | The mis-pick result, at its own scope. |
| Five years of operations leadership | Inflated form of F4 | Seven years of operations work, and the leadership years you state. |
| Expert in Excel reporting | Inflated form of F5 | "solid Excel" at its own scope. |

## 4. Persona table

Round type and relationship were not stated, so the weights use a hiring-manager prior. Interviewer signals are absent, and no loop source was read, so the weights are flat and say so.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (top) | Quiet probing of scope: three supervisors against twelve, one site against four | Highest. A hiring manager buying capability will test the scale gap first. F1, F3 and F4 are the gaps. | Rehearse the scale objection until it is plain. Bridge only from what you stated. Concede the gap; do not bluff it. |
| Case / Strategist (high) | Live problems from the role: a site diagnosis, a surge, a cost rise | High. The JD's daily-operations and cost language invites live problems. | Clarify, then structure, then state metrics and risks. Think aloud. |
| Data-Driven Prober (mid) | Asks how the 40 percent figure was counted and where your Excel reports are | Mid to high. Your message carries one headline figure and one Excel claim. | Know what you can and cannot say about how the figure was counted. Name the weakest assumption before they do. |
| Pressure (mid) | Time-boxed challenge to how much of the result was yours | Mid. Common in hiring-manager rounds. | Hold a position through two follow-ups. Concede specifically. Do not fold on what you did. |
| Conversational (low) | An open "walk me through" and a casual question about Power BI | Low to mid. Casual questions are still scored. | A 90-second arc in your words. Answer the Power BI question with the plain acknowledgment. |
| Peer Evaluator (not weighted) | Seam questions between teams | Not weighted. Would rise if the round is a peer round. | Reciprocity framing if a peer round is confirmed. |

## 5. Question banks

Provenance comes first. Every candidate sentence a row's guidance rests on is quoted in that row.

### Skeptic (weight: top, 5 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You manage three supervisors today, and this role leads twelve across four sites. What makes you credible for that step?" | JD | [grounded] "currently a senior shift manager over 3 supervisors"; [grounded] "7 years in warehouse and distribution ops" | **Highest-ROI prep in this pack.** Hold: "I'm a senior shift manager over three supervisors, with seven years in warehouse and distribution operations. The step up is scale, and here is how I would approach it." Concede plainly: twelve supervisors across four sites is not something your material shows you have run. Answer slot: if you have led through more people or sites than your material shows, say which, in your own words. If not, say so and say what you would do in the first ninety days. Hold through two follow-ups by returning to the three you led. Never add a number. | F3 and F4 are the scale gaps this question presses. The JD line is its premise. Deepest rehearsal because this is where the material is thinnest. |
| A2 | "Your mis-pick result is a good one. Why should we expect the same on on-time performance and cost per shipment?" | JD | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Hold the pick-path result in your own words: what you changed, and what it moved. Concede that on-time and cost per shipment are different measures. Answer slot: if you tracked either, say the figure and how you counted it. If you did not, say so and say how you would find the levers first. | F2 is where the JD's outcome requirement presses. The premise that the result carries over is the interviewer's, and the guidance does not adopt it. |
| A3 | "Power BI is in the job. Where have you built reporting that someone relies on?" | JD | [grounded] "never used Power BI"; [grounded] "solid Excel" | Plain acknowledgment: "I haven't used Power BI." Then Excel: answer slot. If you built reports others used, name the report, its users and what it measured. If you did not, say so. For Power BI, give a plan: how and how fast you would learn it. | F5 and F6. Power BI is a stated absence, so the answer is a plan, never a past. |
| A4 | "Lean and Six Sigma are a plus here. What did you do with your green belt?" | JD | [grounded] "green belt certified"; JD "Lean/Six Sigma a plus" | Hold: name the project or tool you applied it to, in your words. The certificate alone is not the answer. Answer slot: if you ran a project under the belt, say what it was and what you measured. If the belt was training without a project of yours, say so. | F7. A certificate is limited proof, so this probe is likely. |
| A5 | "Why leave a senior shift manager role now?" | JD | [generic] | Say what the new role offers that your current one does not, in terms of scope. Make no claim you do not have. | A Skeptic motivation probe. The guidance rests on no past claim. |

### Case / Strategist (weight: high, 4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Your first month: one of the four sites is missing on-time targets. Walk me through how you would diagnose it." | CASE | [generic] | Clarify first: which site, which lanes, missing against what target, for how long. Then objective, segmentation (dock, sortation, departures, labour, data), approach, metrics, risks. Think aloud. | A live problem from the daily-operations line. It presupposes nothing about your past. |
| B2 | "Peak season is six weeks out and volume is climbing. What is your surge plan?" | CASE | [grounded] "ran the site's peak-season surge plan two years running" | Lead with the surge plan you ran, in those words. Then tell its beats only as you held them. Answer slot: if the plan's contents or its result were yours to set, say which and what. If not, say so and describe what you would do here. | Your surge experience is the strongest sentence in the material for a live surge problem. |
| B3 | "Cost per shipment has risen this quarter with volume flat. Where do you look first?" | CASE | [generic] | Clarify the definition and the period. Break cost into labour, transport, rework and accessorials. Name the figure you would defend and the one you would not trust. Name risks. | A cost live problem. It makes no claim about your past. |
| B4 | "How would you decide whether to standardise a process across four sites or leave each site to run its own?" | CASE | [generic] | Criteria: variation in results, cost of change, site differences. Propose a pilot, and name the concession, which is that some sites differ for good reasons. | A judgement case for a four-site role. It makes no claim about your past. |

### Data-Driven Prober (weight: mid, 4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the forty percent mis-pick reduction was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Defend-the-number slots, in your words: how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. If you did not count it yourself, say so and say what you know. Never explain a method you cannot repeat under a second question. | Every headline number gets a defend-the-number question. |
| C2 | "Which assumption behind that figure would you defend least?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Weakest-assumption move: name it before they do. If you do not know how the baseline was set, say so plainly. | The Prober's standard follow-up on a figure. |
| C3 | "Show me the Excel report you would rebuild first, and what you would change." | EXP | [grounded] "solid Excel" | Answer slot: name a report you built, its users and what it measured. If you have not built one, say so, and name the first report you would build for this role and the measure it would carry. | F5 is where the JD's reporting requirement is thinnest in your material. |
| C4 | "On-time performance: what is the definition, and where does the data come from?" | JD | [generic] | Structure: the cut-off, the scan or timestamp events, and the accuracy checks. Do not claim you own the data. | A JD-tagged data question. It makes no claim about your past. |

### Pressure (weight: mid, 3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why should we hire you over someone who runs four sites today?" | JD | [grounded] "7 years in warehouse and distribution ops"; [grounded] "currently a senior shift manager over 3 supervisors" | Hold: state what you have run and what you would bring. Concede the scale gap. Do not fold. | A time-boxed challenge to F1 and F3. |
| D2 | "That mis-pick result: how much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Hold-then-concede: say what you did and who else was involved. If the redesign was a team's, say so and what your part was, in your words. Do not fold on what you did. | Attribution honesty under pressure. |
| D3 | "A supervisor disagrees with a decision you have already made. What do you do?" | JD | [generic] | Hold the decision. Ask what they have seen. Concede where the supervisor is right. Describe the process, not an outcome you do not have. | A people-leadership probe. The guidance makes no claim about your past. |

### Conversational (weight: low, 2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | JD | [grounded] "7 years in warehouse and distribution ops" | A 90-second arc in your words: where you started, the pick path, the surge plan, the shift role. Claim nothing beyond your quotes. | A casual opener that is still scored. |
| E2 | "What is your take on Power BI these days?" | JD | [grounded] "never used Power BI" | Plain acknowledgment: "I haven't used Power BI." Then your plan to learn it. | A casual question about a stated gap. Casual questions are still scored. |

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| Own daily terminal operations across 4 sites | A1, B1, D1 |
| Drive on-time performance and cost-per-shipment down | A2, B3, C4 |
| Lead a team of 12 supervisors | A1, D3 |
| Build reporting in Excel/Power BI | A3, C3, E2 |
| 5+ years operations leadership required | A1, A5 |
| Lean/Six Sigma a plus | A4 |

## 6. Reverse questions

Each has a "why it lands."

1. "What does the first ninety days look like for whoever takes this role, and which site concerns you most?" Why it lands: it shows you are thinking about the four-site scope.
2. "How is on-time performance measured across the four sites today, and who owns that data?" Why it lands: it goes straight at the reporting requirement.
3. "What reporting does the team use now, and who reads it?" Why it lands: it shows you want to know what Power BI would replace or extend.
4. "What did the last person in this role do well, and what would they change?" Why it lands: it asks for the role's real job.
5. "Which cost-per-shipment lever is the team working on right now?" Why it lands: it shows you are already thinking about the outcome.

No interviewer profile exists, so no reverse question ties to the interviewer's path.

## 7. Sources

- **Provided documents:** the JD text, and your message (the background summary).
- **Searches:** two were sent. Both were refused ("Claude requested permissions to use WebSearch"), so no company research ran. Nothing about Atlas Freight's values, interview process or strategy is in this pack.

**Research tier:** L1, searches 0 of 6 returned results, fetches 0 of 2.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Atlas Freight values | unavailable | Values cheat sheet absent. Query "Atlas Freight values interview process operations manager" refused. |
| 2. Atlas Freight interview process | unavailable | Loop structure unknown, so persona weights are flat. Same refused query. |
| 3. Atlas Freight strategy / recent news | unavailable | CO questions absent. Query "Atlas Freight regional logistics company operations" refused. |
| 4. Interviewer name + company | n/a | No name given. |
| 5. Representative operations manager JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions. |

## 8. Upgrade menu

- Paste Atlas Freight's values page, or a recruiter email on the process → a values cheat sheet, the loop structure, and persona weights that rest on the company's own process.
- The interviewer's name → a tailored reverse question, and persona weights read from their public footprint.
- Enabling web search for this session → company strategy and recent news, for CO questions.
- Your round type and who you are meeting → reweights every bank.
- Your CV as a file → fuller quotes for F1 to F4, with their context.
