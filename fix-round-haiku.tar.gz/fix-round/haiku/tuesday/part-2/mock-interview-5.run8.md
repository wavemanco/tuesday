Your prep pack is saved as `kelverton-rail_senior-partnerships-manager_interview_pack.md` in my scratchpad, and I've sent it to you as a file. I built it for a panel round, using only what you gave me. I ran no research, so the Kelverton-specific content is thin.

**Where to spend the four hours:**
1. **The POV, about 90 minutes.** Pick one of the three theses in section 5, and say it aloud for about 12 minutes, recording it. Ross is the one who will probe it, so the concession has to be sharp.
2. **Ross's pressure points, about 60 minutes.** Expect "how was the £4M counted?" and "you've never carried a quota." Answer both in your own words, and concede the quota gap plainly rather than arguing that influenced revenue is the same thing.
3. **Deepa's Skeptic questions, about 30 minutes.** The likely ones are why you're moving from payments to rail, and what you'd be weakest at on day one.

Two things in the pack you should check against your own memory:
- **"I know the operator world from the other side."** Your sentence places you on the consulting side. The pack never lets you say you've worked inside an operator, or that you've worked with operators at all.
- **The ISV playbook.** I've framed it as a hypothesis that won't transfer to operators, not as a fact. If you have a better read on how operators buy, use it.

The pack has nine questions, under the usual target, because I don't have the job description, the market report, or any profiles for Deepa or Ross. The report matters most: its consensus answer is what your POV should depart from, and I can't name it until you paste its headline claims.

Would you paste the job description and the report's headline findings? Also, has the recruiter said how the POV will be scored, or whether there's a written follow-up?

If you want to drill, I can play Ross on R1 and push on the figure until you hit a wall. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: kelverton-rail_senior-partnerships-manager_interview_pack.md -----
# Interview prep pack: Senior Partnerships Manager, Kelverton Rail

**Round:** Second round, panel, 60 minutes. First 15 minutes: spoken POV, no slides. Remaining time: Q&A, with commercial pressure from Ross.
**Panel:** Deepa (VP Partnerships, future manager). Ross (Commercial Director).
**Research tier:** L0. Provided documents only. No searches or fetches were run for this pack. Kelverton-specific content comes only from your message and the recruiter's email quotes.
**Built without:** a job description, the strategy team's market report, and interviewer profiles. Each is in the upgrade menu.

## 1. How to use this pack and type key

Personas describe how a question will arrive. Types describe what is being scored. Guidance is scaffolding, not a script. Rehearse out loud, in your own words.

| Tag | Meaning |
|---|---|
| VAL | Behavioural or values alignment. Not expected in this round. |
| EXP | Your past work, tested for attribution and honesty. |
| JD | The role's stated responsibilities. Limited here, because there is no JD. |
| CO | Company and strategy knowledge. Limited here, because there is no research. |
| CASE | A live problem, reasoned aloud. |

## 2. Prep triage (about 4 hours)

1. **POV build, about 90 minutes.** Section 5. Write three theses, each with its concession. Pick one. Say it aloud for 15 minutes and record it. This is the only part of the round that is graded before Q&A starts.
2. **Pressure drills on R1 and R2, about 60 minutes.** The £4M figure and the quota gap. These are the most likely points for Ross to lose you.
3. **Skeptic drill on D2 and D3, about 30 minutes.** Why rail, and what you would be weakest at on day one.
4. **Reverse questions and a full read-through, about 30 minutes.** Section 11.
5. **Everything else is insurance.**

## 3. Fit snapshot

Requirements come from the recruiter's email, quoted, which is grounded. Where a row is marked `[generic]`, the requirement comes from a role-family pattern, not from a source you gave me.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "where you'd take our operator partnerships over the next 18 months" (recruiter email) | "took it from 6 partners to 40, roughly £4M of influenced revenue" (your message); "running the ISV channel" (your message) | medium | [grounded] | transferability | Your material shows partner-channel growth at a payments company, not operator partnerships in rail. Bridge: "At the payments company I ran the ISV channel, and took it from 6 partners to 40." Answer slot: if you ran any relationship with buyers or gatekeepers comparable to operators, say what it was and how you handled it. If there was no such relationship, say so and say how you would approach train operating companies. |
| F2 | "Please land on what it means for the operators themselves" (recruiter email) | "bus and light rail network planning, so I know the operator world from the other side" (your message) | medium | [grounded] | transferability | Your material places you on the consulting side of transport, not inside an operator. Bridge: "I spent five years in transport consulting on bus and light rail network planning." Answer slot: name one operator decision you saw shaped by planning work, in your own words. If you did not see one, say so. |
| F3 | "Ross will push on commercials" (recruiter email) | "roughly £4M of influenced revenue" (your message); "only influenced revenue" (your message) | medium | [grounded] | transferability | The figure is influenced revenue, not a quota you carried. Bridge: "The figure I can give you is influenced revenue." The figure needs the defend-the-number slots in section 9. |
| F4 | Commercial ownership of a partnership revenue target (no source; role-family pattern) | "never carried a direct quota" (your message) | none | [generic] | capability | This is a stated absence. Words: "I haven't carried a direct quota." Then a plan for how you would learn quota ownership. Never a claim to quota work. |
| F5 | Experience selling into the rail operator market (no source; role-family pattern) | "Never sold into rail specifically" (your message) | none | [generic] | capability | This is a stated absence. Words: "I haven't sold into rail." Then how you would approach the first six months. |

**Routing note.** F4 and F5 are `capability` because you stated the absence. They are not `discovery`, because the material does not leave it open.

## 4. Prohibited claims

These are the claims the pack will not coach. Each has a basis and an honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| "I owned £4M of revenue" | Inflated form of F3, which says "influenced" | "roughly £4M of influenced revenue." The limit is the pack's observation: your material says influenced, not owned. |
| "I recruited all 40 partners myself" | Inflated form of F1. Your sentence says the channel went from 6 to 40 while you ran it, not who signed each one. | "took it from 6 partners to 40." The slot in D4 covers which part was yours. |
| "I know operators from the inside" or "I've worked with operators" | Relationship inversion of F2. Your sentence places you on the consulting side. | "I know the operator world from the other side," in your words, or the F2 bridge. |
| "I've sold into rail" or "I've carried a quota" | Stated absence, F4 and F5 | "I haven't sold into rail." "I haven't carried a direct quota." Plain acknowledgment, no slot. |

## 5. Graded deliverable: the 15-minute POV

The recruiter asked for a short POV on where to take operator partnerships over 18 months. She asked that it land on what it means for the operators themselves. She did not name a format. No slides.

**Facts to build on (grounded).**
- F1: "took it from 6 partners to 40, roughly £4M of influenced revenue" (your message)
- F2: "bus and light rail network planning, so I know the operator world from the other side" (your message)

**Consensus answer warning.** The strategy team's market report was circulated internally, and the candidates saw it. Any prepared candidate will lean on its shortlist. Do not recite it. I cannot yet tell you what its consensus is, because I have not seen it. Paste its headline claims into the session (upgrade menu) and I will name the consensus and the divergence.

**Thesis options.** Each is a hypothesis to test against the report. The market claims inside them are `[generic]` until the report or a source grounds them.

- **Thesis A: Operators as co-designers, not referral sources.** Treat train operating companies as partners in the scheduling roadmap, not as buyers to be sold to.
  - Concession: operator procurement is slow, and operators' attention goes to franchise and regulatory obligations first. Co-design costs time and may slow the sales motion.
  - Differentiation: the ISV playbook is a channel playbook. Operators will not buy that way. Say it as a hypothesis, not a fact.
- **Thesis B: Work through the people who already do operator planning.** Partner with the consultancies and planning teams that shape operator decisions. You know that work from the consulting side (F2).
  - Concession: those intermediaries may also be competitors, or may own the relationship. You give up margin and control of the account.
  - Differentiation: most partnership pitches go straight to the operator. This goes through the planners.
- **Thesis C: Tie commercial terms to operator outcomes.** Price partner-led deals against punctuality or performance results.
  - Concession: Kelverton carries the revenue risk. This is the thesis Ross will test hardest, so prepare the numbers behind it.
  - Differentiation: this moves the partnership conversation from features to results.

**Anti-pick.** Do not pick a marketplace of many integrations. That is the ISV playbook you ran, and an operator buyer will not read it as a rail answer.

**Requested close.** End on the operators: what changes for a train operating company's planners and commercial team if you are right. Land it in one sentence before Q&A.

**Rehearsal note.** Choose one thesis. Do not present all three. Deliver it in about 12 minutes, leaving room for the panel.

## 6. Persona table

Panel rule: blend the top two personas for each member's relationship. No interviewer profiles were supplied, so the weights are relationship priors only.

| Panel member | Dominant persona | Secondary persona | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|---|
| Deepa, future manager | Case / Strategist | Skeptic | High. A hiring manager is buying capability and testing the gaps she can see in the CV. | Clarify before structuring. Name the gaps yourself before she does. |
| Ross, Commercial Director | Pressure | Data-Driven Prober | High. He has said he will push on commercials, so this is a stated intent, not a guess. | Hold a position through two follow-ups. Know how each figure was counted. |

## 7. Requirement coverage

| Stated requirement or topic | Question IDs | Note |
|---|---|---|
| POV on operator partnerships over 18 months | D1, section 5 | |
| What it means for the operators themselves | D5, section 5 | |
| Commercials, which Ross will push on | R1, R2, R3, R4 | |
| Future manager's view of the role | D2, D3 | |
| Specific JD requirements | none | No JD supplied. See upgrade menu. |

Totals: 9 questions. The pack is under the 18 to 26 target. The gap is from having no JD and no interviewer profiles.

## 8. Question banks

### Deepa: Case / Strategist and Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Where would you take our operator partnerships over the next 18 months?" | CASE | [grounded] "where you'd take our operator partnerships over the next 18 months" (recruiter email) | Clarify first: what the operators already buy, and what the panel means by partnership. Then structure from section 5. This question makes no claim about your past. | This is the POV in question form. Deepa may ask it to test whether the POV holds up outside the prepared version. |
| D2 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "running the ISV channel" (your message); [grounded] "Never sold into rail specifically" (your message) | Name the rail operator sales gap in your own words: "I haven't sold into rail." Then a ramp plan for the first six months. Answer slot: if your ISV work involved a comparable buyer relationship, say what it was. If it did not, say so. | F5 is the likeliest answer to this question. A rehearsed, calm answer changes the room. |
| D3 | "Why leave payments for rail?" | VAL | [generic] | Answer slot, asked as an open prompt: give the reason in your own words, tied to what you have seen. The material does not state your motivation, so the pack does not supply one. | Motivation is a Skeptic probe for any cross-sector move. The pack cannot write your reason for you. |
| D4 | "Walk me through how the channel went from 6 partners to 40." | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" (your message) | Story-mapped on F1. The beats are the ones the sentence states: the start at 6, the end at 40, the period you ran it. Tell them in your own words. Answer slot: which part of the growth was yours to set, such as which partners you signed, which you designed the model for, or which the team did. If a part was not yours, say so plainly. | A premised question: it names the channel growth as yours. Deepa will test the attribution. |
| D5 | "If operators told you they would not co-design, what would you drop from your POV?" | CASE | [generic] | Name the thesis you would drop first, and which concession you would keep. Do not change the core claim to please the panel. | Tests whether your POV is a position or a list. Links to the concession in section 5. |

### Ross: Pressure and Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R1 | "The £4M. How was that counted?" | EXP | [grounded] "roughly £4M of influenced revenue" (your message) | Defend-the-number slots. Answer in your own words: how the figure was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. If you do not know how it was counted, say so. | The most likely single probe in the commercial section. A figure you cannot explain under a second question is worse than none. |
| R2 | "You've never carried a quota. Why should we trust you with our commercial targets?" | EXP | [grounded] "never carried a direct quota, only influenced revenue" (your message) | Pressure, hold-then-concede. Hold on what you can show: the growth and the influenced figure. Concede plainly: "I haven't carried a direct quota." Then give how you would learn it, as a plan. Do not argue that influenced revenue is the same as a quota. | Ross is testing whether you fold under pressure or defend a claim you cannot back. |
| R3 | "Sixty seconds: what is the commercial model for operator partnerships?" | CASE | [generic] | Structure, don't recite. Name the revenue model options (licence, revenue share, outcome-linked), and the risk each one moves. This is where Thesis C sits. | No claim about your past. It tests whether you can think at the commercial level. |
| R4 | "What would you measure in year one to know operator partnerships are paying?" | CO | [generic] | Name two or three measures, and say what each one would miss. Answer slot: if you have measured a partnership outcome before, say what it was. If you have not, say so. | Tests the measurement instinct without asking you to claim a metric you did not own. |
| R5 | "That £4M. How much of it was actually you?" | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" (your message) | Pressure. Name the part that was yours, using the words of F1. Hold the claim, then concede the rest. | A stress probe on attribution. Same slot as R1, delivered as a challenge. |

## 9. Reverse questions

At least five, each with why it lands.

1. "What did the last person in this role get right, and what did they miss?" Why it lands: it signals you are planning to do the job, not to win the interview.
2. "How do train operating companies typically decide on a scheduling vendor, and who signs?" Why it lands: it shows you are thinking about the operator's buying process, which is the point of the POV.
3. "Which operator relationship would you most want protected in the first year?" Why it lands: it turns the conversation to the account level, where Deepa will be your manager.
4. "How does the strategy team's market report get used: as input to targets, or as a positioning document?" Why it lands: it tells you whether the POV should agree with the report or depart from it.
5. "How is partnership success measured here: revenue, retention, or operator outcomes?" Why it lands: it sets up Thesis C without arguing for it.

## 10. Delivery notes

- Speak the POV without notes. Use one sentence per thesis, and state the concession in the same breath.
- When Ross challenges a figure, pause before you answer. Restate the question in your own words. Then answer.
- In Q&A, prefer "I haven't" over a hedge. A stated gap is easier to recover from than a vague claim.

## 11. Sources

- Provided: your message, which contains your background and the quoted recruiter email. The strategy team's market report was not supplied to this session.
- Searches and fetches: none run.

**Research tier:** L0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Kelverton values | unavailable | Would have moved a values cheat sheet, but this round is not values-style. L0: no research run. |
| 2. Interview process, partnerships role family | unavailable | Would have set loop weights. L0: no research run. |
| 3. Kelverton strategy and recent news | unavailable | Would have moved the POV's market claims and the consensus answer. The market report is the strongest substitute, once pasted. |
| 4. Deepa and Ross, with Kelverton Rail | unavailable | Would have moved the interviewer read and the persona weights. L0: no research run. |
| 5. Representative partnerships JD | unavailable | Would have produced JD-tagged questions. No JD supplied. |

## 12. Upgrade menu

- The job description text → recruiter's topics become JD-grounded rows, and the JD-tagged questions appear
- The market report's headline claims pasted → the consensus answer named, and the POV's divergence tested against it (section 5)
- Public profiles for Deepa and Ross → personas weighted by career pattern, and reverse questions tied to their paths
- Level 1 research (up to 6 searches, 2 page fetches) → current Kelverton strategy and values, plus the loop structure
- Level 2 deep research, offered once, with its time cost: interviewer writing, role loop reports, recent news
- Your notes on how the POV will be scored, if the recruiter has said → coverage of any written follow-up
