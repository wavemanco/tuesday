Your prep pack is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-tuesday-part-2-rooms-case-1-denied-b412a3bf/59206f6e-d08e-4d1f-89b0-ab72739b15e5/scratchpad/Northwind_Data_Senior_GTM_Strategy_Lead_interview_pack.md`. It has 22 questions across seven personas, weighted toward a data-driven prober and a peer evaluator, which matches a peer round with Dan.

Web search was refused by permission, so the pack runs on your message alone. Company values, the interview process and Dan's public footprint are not in it.

Three things to know:
- **The pack's highest-ROI prep is D2**, the sales-ops objection: Priya has no quota-setting or sales-ops experience, and Dan's role is sales strategy. Say the word and I'll play Dan as the Skeptic on that question.
- **Quotes come from your summary, not her CV.** Every evidence quote is a sentence from your message. Her CV and the full JD would let the pack quote her own words.
- **Confirm the sales-ops line with Priya.** "No classic sales-ops or quota-setting experience" is from your note. She should say it in her own words before she uses it in the room.

I can also save a `tuesday-dossier.md` recording the gaps this prep exposed for later sessions, and I can convert the pack to Word if you'd like.

Three questions that would change the pack:
1. Did the recruiter announce a deliverable, focus areas or a format for the 60 minutes?
2. Can you paste the full JD and Priya's CV?
3. Does the JD list location, travel, pay or work-authorization terms? I can't see those, and they are the gates the pack can't check.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Northwind_Data_Senior_GTM_Strategy_Lead_interview_pack.md -----
# Interview prep pack: Senior GTM Strategy Lead, Emerging Products, Northwind Data

**Candidate:** Priya
**Interviewer:** Dan Kovac, Director of Sales Strategy. Peer: same VP, same level.
**Round:** One 60-minute conversation with Dan. Session mode.
**Version:** First version. No changelog yet.
**Evidence base:** Your message only (role highlights, candidate summary, interviewer profile, research note). No CV, no full JD text, no outside research. See Sources.

---

## 2. How to use this pack

- **Personas** describe how a question arrives: the delivery style.
- **Types** describe what is being scored:
  - **VAL**: behavioral and values alignment
  - **EXP**: deep-dive on her own experience, and whether her claims survive scrutiny
  - **JD**: the role's stated responsibilities and qualifications, including gaps
  - **CO**: company and strategy knowledge
  - **CASE**: a live problem, solved aloud
- Guidance is scaffolding, not a script. Every answer should be in her own words, and every claim about her past should be one she can repeat under a second follow-up.
- Answer slots (marked "Answer slot") are instructions for her answer in the room. They are not questions for you.

---

## 4. Fit snapshot

Requirements are quoted from your JD highlights, which are your summary of the posting, not its exact text. Evidence is quoted from your message. Both are the only sources the pack uses about her past.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" (your message, JD highlights) | "proposed a store-surface change credited with a ~$400M ARR uplift" (your message); "built a partner-level revenue model used in carrier negotiations" (your message) | medium | [grounded] | transferability | Her material shows a product change she proposed and a revenue model she built. It does not show a GTM strategy she owned for a launch, so the words stay at that scope: "I proposed a store-surface change, and I built a partner-level revenue model used in carrier negotiations." Answer slot: the JD's own-the-strategy line makes a probe on who set the launch plan likely. If she set any part of the plan, say which part and how she decided, in your own words. If she did not, or it was not hers, say so plainly and return to the change she proposed. |
| F2 | "identify whitespace across land/adopt/expand/renew" (your message, JD highlights) | none given | discovery | [grounded] | discovery | Nothing in the material shows work across these lifecycle stages. Answer slot: if you have sized opportunity in any of these stages, say what you sized and how. If you have not, say so, and say how you would find the whitespace first. |
| F3 | "run independent analysis in SQL and Tableau" (your message, JD highlights) | "skilled in SQL/Tableau" (your message) | medium | [grounded] | none | The tools are covered in role-relevant terms. The word "independent" is not in her material, so expect a probe on what she ran alone. The rehearsal is in A4. |
| F4 | "partner-motion design experience required" (your message, JD highlights) | "built a partner-level revenue model used in carrier negotiations" (your message) | medium | [grounded] | transferability | Carrier negotiations are partner-facing economics. The material does not show a partner motion designed, meaning channels, incentives or enablement. Words stay at the quote's scope. Answer slot: if she designed any part of how partners were brought in or paid, say what and how she decided. If not, say so, and say what she would look at first in a partner motion. |
| F5 | "strong cross-functional influence" (your message, JD highlights) | "set annual volume targets with cross-org consensus" (your message) | medium | [grounded] | presentation | The quote already reaches cross-org work in its own terms, so the bridge only rewords it: "I set annual volume targets with cross-org consensus." It adds no practice. Limit: the material says volume targets, not quotas. |
| F6 | "AI experience a plus" (your message, JD highlights) | "uses AI tools daily" (your message) | medium | [grounded] | transferability | Daily use is not building AI features. Say which tools she uses and what for, in her words. Answer slot: if she has built or shipped anything with AI, say what. If not, say so. |
| F7 | [generic] Sales-side fluency: quota setting and sales-ops. Role-family requirement; not a line in your JD highlights. | "No classic sales-ops or quota-setting experience" (your message) | medium | [grounded] | capability | This is the stated absence, and it is the pack's most likely objection. Words, once she confirms the line in her own words: "I haven't done classic sales-ops or quota-setting." Then how she would learn it, said as a plan and never as a past. Never a claim to that work. |

**Gap-type routing notes**
- F7 is `capability` on your note alone. Ask her to confirm it before she says it aloud (see Upgrade menu).
- F1, F4 and F6 are `transferability`: adjacent work that does not reach the requirement.

---

## 6. Company context (from your research note only)

No outside research ran. Everything here is from your note, so it is `[grounded]` to that note and unverified.

| Item | Source | Provenance | Use in the room |
|---|---|---|---|
| Three stated priorities: "enterprise expansion, an AI copilot launch ('Compass'), and reaching profitability" | your research note | [grounded] | Use in C1 and C2, and in reverse questions. Do not recite it back as her research. |
| Main competitive threat: "bundling by a much larger platform vendor" | your research note | [grounded] | C2. Name a view, not the consensus. |
| Current segmentation vocabulary, values, loop structure | not available | [generic] | Not used. Do not guess these in the room. |

---

## 7. Reading the interviewer

Public professional signals only, from the profile you gave. No outside research ran on Dan.

- **Career pattern:** "career spine is pricing and monetization roles, with one early-stage-startup chapter."
- **Self-described style:** "relentlessly data-driven."

**Implications**
1. Every metric she offers will be probed to its assumptions. Prepare A1 to A5 first.
2. Case questions will tilt toward pricing, packaging and unit economics. That is his native language. See C2.
3. The startup chapter suggests builder stories will land, and that he may probe pace and scrappiness. Her material has no startup chapter. Do not claim one, and do not claim big-company pace as a virtue or a flaw.
4. **Mirror opportunity (shared domain, not a shared jump):** her revenue-model work sits in monetization, which is his career spine. The quote is in F4. Use it as a point of contact, not as a claim of kinship.

Shared identity or background is not a strategy. None is listed here.

---

## 8. Persona table

| Persona | Weight and depth | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|---|
| Data-Driven Prober | Top, 5 questions | Follows every number to its inputs and denominators; two levels deep | High. Peer prior plus "relentlessly data-driven" in his own profile | Know what you can and cannot say about how each number was counted. Name the weakest assumption before he does. Say plainly when you do not know. |
| Peer Evaluator | High, 4 questions | Seam-splitting between teams; "what would you need from me"; credit and disagreement | High. Peer prior, same VP | Lead with what you bring his team, not only what you need. Propose seam principles rather than pretending to know the seam. |
| Case / Strategist | Mid, 3 questions | Live problems on whitespace, packaging and launch | Medium. Pricing background tilts cases toward pricing and unit economics | Clarify, then structure: clarify, objective, segmentation, approach, metrics, risks. Think aloud. Challenge one premise per case. |
| Skeptic | Mid, 3 questions | Quiet probing of sales-side fluency and the gap between her revenue work and a partner motion | Medium-high on the sales-side objection (F7); the sales-ops gap is the likeliest one he will probe | Rehearse the sales-ops objection until it is boring. Say the plain acknowledgment only once she has confirmed it. Bridge from the quotes, not from things she has not said. |
| Pressure / Stress | Low, 2 questions | Interrupts, time-boxes, "how much of that was actually you" | Low-medium. Peer register makes it less likely, but the attribution probe is worth rehearsing | Pause, restate, anchor in what she actually stated. Hold a challenged position through two follow-ups before conceding anything real. |
| Conversational / Rapport | Low, 2 questions | Friendly opener; the biography question; casual questions about AI | Medium on the opener. Casual questions are still scored | Pre-script the 90-second arc. Treat casual AI questions as scored. |
| Values / Behavioral | Low, 2 questions | Scenario probes for unpopular truths and customer-first decisions | Low-medium. No published company values were available, so no values cheat sheet exists | Choose a story where the hard truth actually landed. Where her material shows none, say so and give the selection scaffold's honest branch. |

---

## 9. Question banks

Scoring: A=Prober (5), B=Peer (4), C=Case (3), D=Skeptic (3), E=Pressure (2), S=Rapport (2), V=Values (2). Total 22.

### A. Data-Driven Prober (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how the $400M figure was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (your message) | Defend-the-number slots, in your own words. (1) How it was counted: if you know, say so; if not, say "I don't know how that figure was counted." (2) What it is sensitive to. (3) The assumption you would defend least, named before he does. (4) Which part was yours: "I proposed the change" is the quote's scope. Answer slot: if you did any step to count it, say how. If there was no such step, or it was not yours, say so plainly and return to the change you proposed. | F1 carries the headline figure. A1 is the defend-the-number set the figure raises. EXP because it tests attribution, which is what this persona scores. |
| A2 | "What would you check before repeating that $400M claim?" | EXP | [grounded] "credited with a ~$400M ARR uplift" (your message) | "Credited with" means the uplift is attributed to the change, not authored by you. Name the one assumption you would test first, in your own words. Answer slot: if you know how the uplift was split among causes, say how. If you do not, say so. | F1 is the figure, and "credited with" sets its scope. A2 goes at the weakest assumption in one sentence. |
| A3 | "Name the three inputs in the carrier revenue model that move the answer most." | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" (your message) | Name only inputs you can state. Say which input moved the answer and by how much, if you know. Answer slot: if you cannot recall which inputs moved the answer, say so and name what you would re-run. Do not claim the model's outcome in negotiations beyond the quote's "used in". | F4's model is the strongest artifact she has. A3 tests whether she knows her own assumptions. |
| A4 | "Pick an analysis you ran yourself in SQL and Tableau. Walk me through the data, the joins, and the check you trust least." | JD | [grounded] "skilled in SQL/Tableau" (your message); raising source: "run independent analysis in SQL and Tableau" (your message, JD highlights) | Open prompt. Pick one analysis. Go through the data source, the steps in order, and the check you trust least. Honest branch: your material names no specific analysis. If none comes to mind, say so plainly and say how you would build one. | F3 has the tools but not the independence. A4 is the rehearsal for the independence probe. JD because it scores a stated requirement. |
| A5 | "Tell me about a time two numbers you trusted disagreed. What did you check first?" | EXP | [generic] | Selection scaffold: pick a time two sources disagreed. Say your first check, where you stopped, and what changed. If no such time comes to mind, say so plainly, then say how you would handle it. | Persona stem. It tests method, not a claim about her past. |

### B. Peer Evaluator (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our teams sit side by side. Where is the seam between your GTM for the two new lines and our roadmap, and what happens when we disagree?" | JD | [generic] | Propose seam principles, not a seam you have seen. Disagreement: open prompt. Pick one disagreement with a peer team: what each side needed, what you conceded, what held. If none comes to mind, say so plainly, then say how you would handle one. | J5 (cross-functional influence) is the requirement. The seam probe is the peer persona's standard form. |
| B2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Give one example of shared work: how credit was split, with "we" for the team and "I" for your share. If no example fits, say so plainly and say how you would handle it. | F1's "credited with" makes credit a likely topic. The question is a peer-persona stem and claims nothing. |
| B3 | "What would you need from my team to make a revenue model like that work for these lines?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" (your message) | Reciprocity framing. Name the inputs you would need as asks: deal-level data, metric definitions, the pricing decisions that sit with his team. Do not say you have had access to these before. | The reciprocity move a peer scores. Ties the model to his team's load, not only to her needs. |
| B4 | "How would you decide which partners get a motion built for them, and which stay direct?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" (your message); raising source: "partner-motion design experience required" (your message, JD highlights) | Reason from partner economics: use the model's logic to decide which partners are worth a motion. Say what the model can and cannot decide. Answer slot: if you designed any part of a partner motion, say which part and how you decided. If not, say so, and name the first thing you would measure. | F4 is the requirement. B4 is the design question the requirement raises. |

### C. Case / Strategist (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "The company's priorities are enterprise expansion, the Compass launch, and reaching profitability. Where is the whitespace across land, adopt, expand and renew for the two new lines, and where do you start?" | CASE | [grounded] "enterprise expansion, an AI copilot launch ('Compass'), and reaching profitability" (your research note); raising source: "identify whitespace across land/adopt/expand/renew" (your message, JD highlights) | Clarify the objective, then segment by lifecycle stage (land, adopt, expand, renew). Choose an approach, name the metric for each stage, and state the risks. Think aloud. Challenge one premise respectfully. No claim about your past, so no answer slot. | F2 has no story, so this case is where the whitespace requirement gets tested. CASE because it is live. Also CO-adjacent. |
| C2 | "Compass is the copilot launch, and the main threat is a larger platform bundling its product in. How would you price or package against that?" | CO | [grounded] "main competitive threat is bundling by a much larger platform vendor" (your research note); "an AI copilot launch ('Compass')" (your research note) | Use a pricing and packaging lens with unit economics: what the bundle costs the customer, where a standalone product keeps value, what you would match and what you would not. State a thesis. Concede what you cannot see about competitor pricing. No claim about your past. | His native territory. Pricing and packaging are the register he will score. |
| C3 | "Expansion bookings dropped 20% in the first month after a launch. Diagnose it." | CASE | [generic] | Clarify the definitions first. Split by segment and by lifecycle stage. Check the launch timing and any bundle effect. Name the one metric you would check first. | Metric stem from the case persona. It tests structure and reasoning, not facts about her. |

### D. Skeptic (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "No classic sales-ops or quota-setting experience" (your message); raising source: "partner-motion design experience required" (your message, JD highlights) | Name the two honest areas: sales-ops and quota-setting, and designing a partner motion. The sales-ops line is a plain acknowledgment only once you have confirmed it: "I haven't done classic sales-ops or quota-setting." Then the learning plan, said as a plan. Do not claim partner-motion design from the revenue model. | F7 and F4 name both gaps. D1 is the open-ended form of the most likely objection. |
| D2 | "Sales-ops and quota-setting sit next to this role. How would you work with the people who own them?" | JD | [grounded] "No classic sales-ops or quota-setting experience" (your message) | **Highest-ROI prep in this pack.** Hold: you bring partner economics and consensus on volume targets, both quoted in F4 and F5. Follow-up 1 ("you have never set a quota"): acknowledge plainly, once confirmed, then return to the quote: "I set annual volume targets with cross-org consensus." Follow-up 2 ("why would a sales team trust you on targets?"): hold the quote, then concede a specific limit: "I can't speak to how quotas land with reps. I would learn that from your team." Never fold on the claim that you can work with them. | F7 is the gap a sales-strategy peer will test. The highest-ROI objection is aimed exactly where the material is thinnest, so the held position is only what the quotes carry. |
| D3 | "What did cross-org consensus on targets look like: who had to agree, and who could block it?" | JD | [grounded] "set annual volume targets with cross-org consensus" (your message); raising source: "strong cross-functional influence" (your message, JD highlights) | Answer slot: if you proposed or set the number, say what you decided. If others set it, say who and what you contributed. Hold the scope of the quote: consensus was the process, not sole decision. | F5 is the influence requirement, presented in the quote's own terms. D3 tests it honestly. |

### E. Pressure / Stress (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why should this seat go to you over someone who has run sales strategy for years?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" (your message) | Pause, restate the question, then hold: "I built a partner-level revenue model used in carrier negotiations, and that is the work I would bring to the two lines." Hold through two follow-ups. Concede specifically: "On sales-ops and quota-setting, I have not done it, and I would learn it from your team." Give the concession only once confirmed. Never fold on the model. | Persona stem. The held position is the quoted line. Adding a sales-strategy claim would be the inflation this probe exists to catch. |
| E2 | "That result: how much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (your message) | Hold, then concede. "I proposed the change. The uplift is credited to it, and here is what I can and cannot claim." Hold through two follow-ups. Concede the attribution share, not the proposal. Answer slot: if you did more than propose, say what, in your own words. If not, say so. | Pressure on attribution. A1 and A2 cover the numbers; E2 covers the stance under challenge. |

### S. Conversational / Rapport (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| S1 | "So, walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm"; "9 at a large consumer-tech company in product strategy & ops"; "built a partner-level revenue model used in carrier negotiations" (your message) | Pre-script a 90-second arc with four beats: two years in strategy consulting; nine in consumer-tech product strategy and ops; the partner-level revenue model; the store-surface change you proposed. Each beat is a quote. Add no role, no title, no outcome. | Casual on the surface, scored in practice. The beats are the quotes, so the arc cannot drift. |
| S2 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" (your message); raising source: "AI experience a plus" (your message, JD highlights) | Name the tools you use and what you use them for, in your words. Answer slot: if you have built anything with AI, say what. If not, say so plainly. Do not use the word "built" for tool use. | The plus-skill, asked casually, is scored. F6 is the honest version. |

### V. Values / Behavioral (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time you told senior people something they did not want to hear. Name the stake, the moment you did not fold, and how it landed. If none comes to mind, say so plainly, then say how you would handle it. | Persona stem. No published company values were available, so there is no values cheat sheet. |
| V2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Same scaffold: pick a time a customer outcome beat an internal number. Name the stake and the decision. If none comes to mind, say so plainly, then give the honest branch. | Persona stem. Tests judgment, not slogans. |

### Requirement coverage

| Requirement (JD highlight) | Covered by |
|---|---|
| J1: own GTM strategy for two new product lines | A1, C1 |
| J2: identify whitespace across land/adopt/expand/renew | C1 (F2 is discovery) |
| J3: run independent analysis in SQL and Tableau | A4, A3 |
| J4: partner-motion design experience required | B3, B4, D1 |
| J5: strong cross-functional influence | B1, B2, D3 |
| J6: AI experience a plus | S2 |
| Not a JD line: sales-side fluency (quota-setting, sales-ops) | D2, D1, E1 |
| Headline figure ($400M) | A1, A2, E2 |

Session total: 22 questions.

---

## 11. Reverse questions

Each is a question Priya asks Dan. Why it lands is one line.

| # | Question | Why it lands |
|---|---|---|
| R1 | "You came up through pricing and monetization. What is one pricing call on this team you would want to re-examine for the two new lines?" | Ties to his own career path, and turns the conversation into a peer exchange. |
| R2 | "What did the early-stage chapter teach you about pricing that a larger organization does not let you try?" | Ties to the startup chapter on his profile. It invites him to talk about his own path. |
| R3 | "What could a new person do in their first month that would genuinely help your team?" | Reciprocity, which a peer weighs heavily. |
| R4 | "Which expansion number do you check first every week, and what would make you change it?" | Speaks his language. It shows she is thinking about the same metrics he is. |
| R5 | "When Compass and a platform bundle collide in one deal, who makes the packaging call today?" | Uses the research note's priorities and threat. It shows she knows the company without reciting a report. |
| R6 | "Where is the seam between partner and direct motions on your side today?" | Opens the partner-motion conversation the JD raises, on his terms. |

---

## 13. Prohibited claims

Built locally from the fit snapshot. No dossier was provided. Each entry names its basis and its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Set sales quotas or sales targets for a field team | Inflated form of F5 ("set annual volume targets") | F5's quote at its own scope. Pack's observation: the material says volume targets, not quotas. D3 stays inside the consensus process. |
| Designed the partner motion | Inflated form of F4 ("built a partner-level revenue model") | F4's quote at its own scope. The material shows a model, not a motion. |
| Owned the ~$400M result | Inflated form of F1 and the "credited with" scope in A2 | The quote at its own scope: "credited with." The limit is the pack's observation. A1 and E2 keep the attribution slot inside her part. |
| Ran the GTM for a launch | Inflated form of F1 ("proposed a store-surface change") | F1's quote at its own scope. A1 slot asks who set the plan. |
| Built AI products or features | Inflated form of F6 ("uses AI tools daily") | F6's quote at its own scope. S2 slot asks what, if anything, was built. |
| Ran independent analyses end to end with no help | Inflated form of F3 ("skilled in SQL/Tableau") | F3's quote at its own scope. A4 asks for one named analysis and an honest branch. |
| "I have sales-ops or quota-setting experience" | Stated negative, F7 ("No classic sales-ops or quota-setting experience") | Plain acknowledgment, once she confirms it: "I haven't done classic sales-ops or quota-setting." No slot. |

---

## 14. Sources

**Provided documents:** Your message. It holds the role highlights (JD highlights, not the full posting), the candidate summary, the interviewer profile and your research note. No CV, no full JD and no dossier was provided.

**Research tier: L1 requested. Searches 0 of 6 completed (3 refused by permission). Fetches 0 of 2.** No outside research ran. All company and interviewer statements come from your message.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Northwind Data company values` | unavailable | Values cheat sheet. Refused, so no values were established. No values cheat sheet is included. |
| 2. `Northwind Data interview process, senior GTM role` | unavailable | Loop structure and persona weights. Not queried: search permission was refused for this session. This round is one 60-minute conversation, so weights use the relationship prior. |
| 3. `Northwind Data strategy` / recent news | skipped | Your research note already gives the three priorities and the threat, so the strategy inputs are in hand. |
| 4. `Dan Kovac Director of Sales Strategy Northwind Data` | unavailable | Public footprint for persona weights and reverse questions. Refused. The interviewer read uses only your profile text. |
| 5. Representative senior GTM JD | skipped | The JD highlights you supplied fix the fit snapshot and the JD-tagged questions. |

**Un-numbered search outside the declared targets**

| Query | Status | What it would have moved |
|---|---|---|
| `Northwind Data Compass AI copilot launch` | refused | Would have checked the launch name and timing. C1 and C2 use only your note's wording. |

---

## 15. Upgrade menu

- **Full JD text** → every J-row becomes an exact posting quote (currently your highlights), and the gate check for location, pay, travel and work authorization runs.
- **Priya's CV** → the evidence quotes come from her own sentences rather than your summary, and A1 to A4 can be rehearsed on her actual figures.
- **Priya confirms "No classic sales-ops or quota-setting experience" in her own words** → F7 becomes a confirmed negative. D1, D2 and E1 can then use the plain acknowledgment.
- **The recruiter's note on focus areas or a deliverable** → a build section for any declared deliverable, and a rebalanced bank if the focus shifts.
- **Permission for web search** → L1 research (values, interview process, Dan's public footprint), about six searches and two fetches. Updates the persona weights, the S-bank and the reverse questions.
- **L2 deep research** (strategy brief, interviewer talks and writing, loop reports) → six further searches and two further fetches, on your approval only.
- **Prep time available** → a sized triage schedule with the highest-ROI questions first.
