Your prep pack is saved as `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-tuesday-part-2-rooms-case-2-denied-04eadcb4/58ede125-a413-48d2-8be0-9db36d717601/scratchpad/atlas-freight_operations-manager_interview_pack.md`. I built it for a hiring-manager round, since your note didn't say who you're meeting. It has no company research, because web search wasn't permitted in this session. Everything about Atlas comes from the job description you pasted.

The three gaps the interviewer will most likely press on:

- **Scale:** the JD says 4 sites and 12 supervisors; you have one shift over 3 supervisors. This is the top rehearsal (A1).
- **Your 40% figure:** expect a probe on how it was counted and how much was yours (B1, B2). It measures mis-picks, not on-time performance or cost per shipment, so don't let it stand in for those.
- **Power BI:** say "I've never used Power BI," then give a plan with a date (A5). Don't describe it as experience.

I can run a drill on A1 whenever you want to rehearse it. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.

If you'd like the pack as a Word document, say so and I'll convert it.

Is the person you're meeting your future manager, or a peer on the team? The answer reweights every bank. If the recruiter has said what they'll focus on, or whether there's a case or presentation, send that too.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: atlas-freight_operations-manager_interview_pack.md -----
# Interview prep pack: Operations Manager, Atlas Freight

Role: Operations Manager (regional logistics, 800 employees, four sites)
Company: Atlas Freight
Interviewer: not given. Relationship: not given. Built for a hiring-manager round, the most likely fit for this role.
Research: not run. Web search was not permitted in this session, so no company values, loop structure or strategy are in this pack. Everything about the company comes from the job description you pasted.

## How to use this pack

Personas are how a question arrives: the same point can come as a challenge, a data probe, or a friendly aside. Types are what is being scored:

- **VAL**: behavioral / values alignment
- **EXP**: a deep-dive on something on your record
- **JD**: the role's stated responsibilities and qualifications
- **CO**: company and strategy knowledge (not covered; no research ran)
- **CASE**: a live problem from the role, solved aloud

Guidance is scaffolding, not a script. Say it in your own words. Each guidance cell is speakable in about 90 seconds.

## Fit snapshot

Requirements are quoted from the job description as you pasted it. Evidence is quoted from your message, the only source so far. There is no CV in this session.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" (JD) | "7 years in warehouse and distribution ops" (your message); "currently a senior shift manager over 3 supervisors" (your message) | low | [grounded] | transferability | Your material shows one shift and warehouse and distribution work, not terminal operations across four sites. Words you can stand behind: "I've spent 7 years in warehouse and distribution ops, and I'm a senior shift manager over 3 supervisors." Answer slot: the JD names four sites, so expect a probe on how you would control daily operations across them. If you have run work across more than one site or a terminal, say which and how, in your own words; if you have not, say so plainly and say how you would set up daily control across four sites. |
| F2 | "drive on-time performance and cost-per-shipment down" (JD) | "cut mis-pick rate 40% by redesigning the pick path" (your message) | medium | [grounded] | transferability | Your material shows a pick-accuracy result. It does not show on-time performance or cost per shipment. Say the 40% at its own scope, as the mis-pick rate. Answer slot: the JD names on-time and cost, so expect a probe on whether you have moved either. If you have, say which, how it was measured and what it moved; if you have not, say so and name the first measure you would define. |
| F3 | "lead a team of 12 supervisors" (JD) | "currently a senior shift manager over 3 supervisors" (your message) | medium | [grounded] | transferability | Your material shows 3 supervisors, not 12. Say the number first: "I'm a senior shift manager over 3 supervisors." Answer slot: expect a probe on how you would lead twelve. If you have led more supervisors or more people than three, say how many and how, in your own words; if you have not, say so plainly and say how you would structure a team of 12 across four sites. |
| F4 | "5+ years operations leadership required" (JD) | "7 years in warehouse and distribution ops" (your message); "currently a senior shift manager over 3 supervisors" (your message) | low | [grounded] | discovery | Seven years of operations is in your material. How many of those years were leadership is not. Answer slot: count your years leading people and say that number in your own words. If it is fewer than five, say so and name the years your material does show. |
| F5 | "build reporting in Excel/Power BI" (JD) | "solid Excel" (your message) | low | [grounded] | discovery | Your material says Excel skill, not reporting built. "Solid" is self-rated and carries no artifact. Answer slot: if you have built reporting in Excel, name the output, who read it and what it drove; if you have not, say so and say what you would build first. |
| F6 | "build reporting in Excel/Power BI" (JD) | "never used Power BI" (your message) | none | [grounded] | capability | Plain acknowledgment, since you stated it: "I've never used Power BI." Then how you would learn it, as a plan with a date, never as past experience. |
| F7 | "Lean/Six Sigma a plus" (JD) | "green belt certified" (your message) | medium | [grounded] | none | The quote already reaches the requirement. Expect a probe on what the green belt covered and where you applied it. Lead with the certification in your own words. |

Confidence and provenance are separate axes. Confidence grades your evidence; provenance grades what this pack wrote about it. The only evidence available is your own notes, so no row is above medium.

## Prohibited claims

These are the claims this pack will not coach. Each has its basis and its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| "Ran terminal operations across four sites" | Inflated form of F1 | F1's quotes at their own scope. The pack's observation: your material shows one shift over 3 supervisors, not four sites. |
| "Led a team of 12" | Inflated form of F3 | "currently a senior shift manager over 3 supervisors" |
| "Improved on-time performance or cost per shipment" | Inflated form of F2 | "cut mis-pick rate 40% by redesigning the pick path", at its own scope. The pack's observation: your material says mis-pick rate, not on-time or cost. |
| Any Power BI experience, or "built Power BI reports" | Negative you stated (F6) | Plain acknowledgment: "I've never used Power BI." No slot. |
| "Five years of operations leadership" | Inflated form of F4 | "7 years in warehouse and distribution ops". Leadership years are not established. |
| "Designed the peak-season surge plan" | Inflated form of "ran the site's peak-season surge plan two years running" | "ran the site's peak-season surge plan two years running", at its own scope |
| "I redesigned the pick path myself" | Inflated form of "by redesigning the pick path" (verb axis) | The quote at its own scope, with B2's attribution slot |

## Persona table

No interviewer is named, and the round type is not known. The weights below are the hiring-manager priors for a role this size. They are the starting point, and they change once you tell me the round.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy | Weight and depth |
|---|---|---|---|---|
| Skeptic | Quiet probing of gaps: scale from one shift to four sites, team from 3 to 12 | High. The JD sets 4 sites and 12 supervisors against your 3, and a hiring manager is buying derisked capability. F1 and F3 are the largest gaps. | Rehearse the single most predictable objection until it is plain. Bridge only from what you stated, and name the limit plainly. | 5 questions (A1 to A5) |
| Data-Driven Prober | Follows the 40% figure down to its counting. Asks for denominators on cost-per-shipment. | High. The JD names cost-per-shipment, and your one headline number is a metric. | Know what you can and cannot say about how each figure was counted. Name the assumption you would defend least before they do. | 4 questions (B1 to B4) |
| Case / Strategist | Live problems from the role: a 90-day plan, a site falling behind, peak season | Medium-high. Hiring managers run live problems on their actual roadmap. | Clarify, then structure, then answer. Challenge one premise per case. | 3 questions (C1 to C3) |
| Pressure / Stress | Time-boxed, interrupting, challenges motives: why you over someone with four sites | Medium. Common in hiring-manager rounds and most dangerous on the Skeptic's topics. | Pause, restate, hold a position through two follow-ups before conceding anything. | 3 questions (D1 to D3) |
| Conversational / Rapport | Friendly opener, casual questions about Lean and the job's tools | Medium. Feels safe, and casual questions are scored. | A 90-second arc for the biography question. Treat casual questions on JD topics as scored. | 2 questions (E1 to E2) |
| Peer Evaluator | Seams between teams, credit-sharing, how you handle disagreement | Low for a hiring-manager round. Kept for coverage, since peers often sit on panels. | Reciprocity framing. Propose seam principles rather than pretending to know their seam. | 2 questions (F1 to F2) |

Session total: 19 questions, inside the 18 to 26 range.

## Question banks

Provenance comes first in each row. A row whose guidance says nothing about your past carries its label alone.

### A. Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You run 3 supervisors today, and this role leads 12 across four sites. Why would that stretch work?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" (your message) | Hold on the sentence and say the number first. Answer slot: if you have led more than three supervisors or people, say how many and how, in your own words; if not, say so plainly and say how you would set up 12 supervisors across four sites: what you would put in place first and what you would check at each site in the first 30 days. Hold through two follow-ups by returning to the 3, never by adding to it. Concede in one line: "The step from 3 to 12 is the part I would need to prove, and here is how I'd do it." | F3 and F1 are the largest gaps and the most predictable objection, so this is the highest-ROI rehearsal in the pack. The question presupposes only the JD's 12 and 4. |
| A2 | "Which part of this role would you be least ready for on day one?" | JD | [grounded] "Own daily terminal operations across 4 sites" (JD) | Name the part you would be least ready for, in your own words. If it is the move from one shift to four sites, say that and how you would close it first. Do not name a gap the material does not show. | Skeptic's stem. The honest answer points at F1, and the candidate chooses the words. |
| A3 | "You have 7 years in warehouse and distribution. How many of those years have you led people?" | JD | [grounded] "7 years in warehouse and distribution ops" (your message); "currently a senior shift manager over 3 supervisors" (your message) | Count the years in your own words. Answer slot: if you can give a number of years leading people, say it; if it is fewer than five, say so and name the years your material shows. | F4 is a discovery gap. The 5+ years requirement is graded, not a gate, so the number has to be ready. |
| A4 | "What reporting have you built in Excel, and what did it drive?" | JD | [grounded] "solid Excel" (your message) | Open prompt, with the theme from the JD's "build reporting in Excel/Power BI". Describe what you built and who read it. Answer slot: if you have built reporting, name the output and the reader; if you have not, say so plainly, say you use Excel, and say what you would build first. | F5. The question does not presume a report exists, so the honest branch is allowed. |
| A5 | "You've never used Power BI. What will you do about it?" | JD | [grounded] "never used Power BI" (your message) | Plain acknowledgment: "I've never used Power BI." Then a plan with a date, for example what you would build first and by when. Never describe Power BI work as past experience. | F6 is a stated negative, so the plain acknowledgment is allowed and nothing more. |

### B. Data-Driven Prober (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "How was the 40% mis-pick reduction counted?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Answer slot, using the figure's own slots: how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. Say each in your own words. If you know how it was counted, say the period and the volume it was measured on. If you do not know, say so plainly. | The one headline metric. Naming the weakest assumption before they do turns a gotcha into a credibility gain. |
| B2 | "Of the 40%, which part was your decision and which part was the team's?" | EXP | [grounded] "by redesigning the pick path" (your message) | Attribution slot. Say which part was yours in your own words. If the redesign was a team decision, say so and say what your part in it was. If the redesign was not yours, say so plainly and stay with what you did in it. | Attribution honesty. This is the probe the reframing audit was written for. |
| B3 | "On-time performance and cost per shipment are what this role owns. Which have you tracked, and how?" | JD | [grounded] "drive on-time performance and cost-per-shipment down" (JD) | Answer slot. If you have tracked either, name it, its source and what it moved. If not, say so plainly and name the first measure you would define. Do not substitute the 40% mis-pick figure for either measure. | F2. The 40% figure is a different measure. Swapping it in is prohibited. |
| B4 | "Before you compare two sites on cost per shipment, what do you check first?" | CASE | [generic] | Name the denominator: shipments, volumes, and which cost lines are in. Define one of them before any comparison. | Tests the reasoning under a metric, with no claim about your past. |

### C. Case / Strategist (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Sketch a 90-day plan across four sites. What do you need to know first?" | CASE | [generic] | Clarify, then baseline each site, then segment, then approach, then the three measures (on-time, cost per shipment, mis-pick), then risks. | The JD's four-site scope, asked as a live problem. |
| C2 | "On-time performance at one of your four sites drops eight points in a week. Diagnose it." | CASE | [generic] | Check the data is right first. Then shift coverage and staffing, a volume change, arrival timing, and carrier performance. Name what you would look at first. | Structure and reasoning, not a right answer. |
| C3 | "Peak season is three weeks away and forecast volume is up 30%. What do you change?" | CASE | [grounded] "ran the site's peak-season surge plan two years running" (your message) | Structure first: labor, dock capacity, carrier, and the error in the forecast itself. If you draw on past peaks, use only that sentence, and say which parts of the surge plan you set and which you ran. Answer slot: if you did not set a part, say so. | Your strongest CASE material. The question asks about no past, so the guidance may draw on the quoted sentence only. |

### D. Pressure / Stress (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why should we hire someone with three supervisors over someone who already runs four sites?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" (your message); "7 years in warehouse and distribution ops" (your message) | Hold: name your seven years and the one result you can stand behind: "cut mis-pick rate 40% by redesigning the pick path." Concede precisely: the four-site scale is the part you would need to prove, and say how. Hold through two follow-ups, never by claiming a scale you have not run. | Pressure framing of F1 and F3. Hold-then-concede is the structure. |
| D2 | "That 40% — how much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Hold the result as real and the sentence as yours. Answer slot: say which part was yours, in your own words. If the redesign was a team's, say so and what your part was. Concede exactly what you cannot claim, and nothing more. | Same figure as B2, under time pressure. |
| D3 | "Rate your Excel against what daily reporting across four sites needs." | JD | [grounded] "solid Excel" (your message); "never used Power BI" (your message) | Hold a self-rating only in the terms you can show: name the Excel work you have done. Concede Power BI plainly: "I've never used Power BI," then the plan. | Tests self-assessment under pressure, with the stated negative held. |

### E. Conversational / Rapport (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So — walk me through the journey." | JD | [grounded] "7 years in warehouse and distribution ops" (your message); "currently a senior shift manager over 3 supervisors" (your message); "green belt certified" (your message) | A 90-second arc in order: where you started, the seven years, the shift manager role, the pick redesign, peak season, the green belt, and why this role. Add no claim the quotes do not carry. | Casual openers are scored. Say it once in advance until it is smooth. |
| E2 | "What are you actually doing with Lean these days?" | JD | [grounded] "green belt certified" (your message) | Say what the green belt covered and where you applied it. Answer slot: name one place you applied a Lean tool and what you measured; if the green belt has not been applied, say so. | F7. The JD lists Lean as a plus, asked casually. |

### F. Peer Evaluator (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Our teams sit side by side. Where's the seam, and what happens when we disagree?" | JD | [generic] | Propose seam principles: who owns the daily exception, how escalations travel, who decides when two sites disagree. Do not pretend to know their seam. | Peer probes come collegially. This is the question an operations peer would ask. |
| F2 | "How do you handle credit when work spans teams?" | VAL | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Give one example only if you can say whose part was whose. If the pick redesign was shared, say so and say your part. If no example fits, say how you would handle it. | Credit-sharing is a common peer probe. The example rests on B2's attribution. |

## Requirement coverage

| JD requirement | Question IDs |
|---|---|
| Own daily terminal operations across 4 sites | A1, A2, C1 |
| Drive on-time performance and cost-per-shipment down | B3, B4, C2 |
| Lead a team of 12 supervisors | A1, D1 |
| Build reporting in Excel/Power BI | A4, A5, D3 |
| 5+ years operations leadership required | A3 |
| Lean/Six Sigma a plus | E2 |

Headline metric, not a JD requirement: B1, B2, D2 (the 40% figure). Peak season: C3.

## Reverse questions

Each has a reason it lands. No interviewer profile exists, so none ties to a career path.

1. "What does a typical day look like across the four sites, and who has the call when two sites disagree?" Why it lands: it shows you are thinking at terminal level, not at one shift.
2. "Which site is furthest from target on on-time performance right now, and what's the working theory?" Why it lands: it asks for the hard number and shows you want to own it.
3. "How is reporting produced today, which tools, and who builds it?" Why it lands: it tests the Power BI gap honestly, and their answer tells you how much build work sits on this role.
4. "What did the last person in this role not get to?" Why it lands: it finds the real priority behind the job description.
5. "What would a strong first 90 days look like to you?" Why it lands: it lets you commit to measures in their terms.
6. "What's the biggest concern about the 12-supervisor team right now?" Why it lands: it names the team as a real problem and asks for a view on it.

## Sources

- Provided documents: the job description as pasted (Atlas Freight, Operations Manager, six requirements) and your message (background and notes). No CV was provided.
- Research tier: L1 requested. Searches 0 of 6 and fetches 0 of 2, because the search tool was not permitted in this session.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Atlas Freight values | unavailable | Values cheat sheet. Not included, since no values round was detected. Query "Atlas Freight regional logistics operations manager" was refused. |
| 2. Atlas Freight interview process, operations management | unavailable | Loop structure and persona weights. The weights above are priors, not loop data. Query refused. |
| 3. Atlas Freight strategy / recent news | skipped | Would have moved the CO questions. Not run, since the JD fixes the fit snapshot and the CO questions depend on research that did not run. |
| 4. Interviewer name and Atlas Freight | n/a | No name was given, so there was no query to form. |
| 5. Representative operations manager JD | skipped | The JD you supplied fixes the fit snapshot and the JD questions. |

## Upgrade menu

- The round type and who you are meeting → persona weights reordered and the reverse questions retuned to that person
- Your CV or resume → each quote in the fit snapshot becomes checkable, not just your notes
- Your green belt certificate → F7 can move from medium to high confidence, because the certificate is inspectable
- How the 40% mis-pick figure was counted, in your own words (period, volume, baseline) → B1 and D2 can be rehearsed on a counted answer rather than an answer slot
- How many years you have led people → F4 becomes a number, not a slot
- Any reporting you have built in Excel, with the reader and the purpose → F5 becomes grounded, and A4 has a real answer to rehearse
- The interviewer's name → a tailored reverse question, and persona weights from their public footprint
- Web search permission for this session → company values, loop structure and strategy, which would add the CO questions and the values cheat sheet
