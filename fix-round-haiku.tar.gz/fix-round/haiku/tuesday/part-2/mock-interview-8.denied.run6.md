Your prep pack is saved as `ashgrove-credit-union_member-experience-lead_interview_pack.md`. I built it in loop mode, one mini-pack per round, since you have three rounds on 20 November. Interviewer names aren't known yet, so the persona weights come from each round's format.

**The three things to rehearse first**

1. **No contact-centre experience (B5, and A5 and C5 in other rounds).** The JD asks you to own complaints "across branches and the contact centre", and you've never worked in one. Say "I've never worked in a contact centre" plainly, then your plan. Don't argue that you'd be fine. Hold through two follow-ups, then name the specific parts you haven't done.
2. **Presenting above regional level (A6, C9).** Same shape: state it, hold the claim you can back (the complaints log you handled), concede the gap, then give your plan for presenting to leaders.
3. **Resolution times (B8, F6).** The JD asks for monthly reporting on resolution times. Your material shows the volume spreadsheet but not resolution times. If you reported them, say how they were measured. If you didn't, say so and say what you'd add first.

**The panel round**

The 20-minute escalation case (C5) is a practice version I wrote, not the panel's real file. The pack asks for the recruiter's case format, so you can rehearse the real one. Your values answers are mostly scaffolds, because none of your sentences yet carries a story for the four values. Where you don't have a real example, the pack tells you to say so and give the nearest thing you did. Don't invent a story to fill a value.

**What I did and didn't check**

I ran no web searches. Your JD, the values text, the recruiter's round details and your summary of the strategy brief were enough. I didn't check whether anything at Ashgrove has changed since July, so if an interviewer cites a newer plan, treat it as new. The brief itself isn't in this conversation, so the strategy wording is from your summary.

**Upgrades that would help most**

- A redacted copy of your monthly complaints spreadsheet. It would move your reporting evidence from medium to high confidence.
- The recruiter's format for the escalation case.
- Whether you used Excel functions in that spreadsheet. The JD says Excel, and your message says spreadsheet, so the pack doesn't say Excel.

I can run a live drill of the Skeptic on B5 if you want to practise it out loud. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove-credit-union_member-experience-lead_interview_pack.md -----
# Ashgrove Credit Union: Member Experience Lead interview pack

**Role:** Member Experience Lead, Ashgrove Credit Union
**Rounds, 20 November 2026:** recruiter screen (30 min); Head of Member Services, your future manager (45 min); panel of two branch managers (60 min, including a 20-minute complaint-escalation case; the panel also scores the four values)
**Prepared:** 11 November 2026, from the material in this conversation. Interviewer names are not known yet.
**Mode:** loop. One shared fit snapshot and sources, then a mini-pack per round.
**Changes:** first version.

## How to use

Personas describe how a question arrives. Types describe what is being scored.

| Tag | Name | What it scores |
|---|---|---|
| VAL | Values and behaviour | Whether past behaviour shows the four published values |
| EXP | Your own past work | Whether what you did survives follow-up, with attribution exact |
| JD | Job requirement | Whether you can do what the posting lists, gaps included |
| CO | Company and strategy | Whether you know the 2027 plan well enough to talk about it |
| CASE | Live problem | Structure and reasoning on a problem from this role |

Guidance is scaffolding, not a script. Where a cell says answer slot, answer from what you actually did, or say plainly that you did not. Rehearse a practice the pack names only if it was yours.

## Fit snapshot

The JD's requirements, quoted, against your evidence, quoted. No requirement in the JD is a gate: "4+ years" is a length of experience, so it is read on fit like the others.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" (JD) | "6 years in retail banking, the last 3 as a branch supervisor" (your message) | medium | [grounded] | none | Your material already reaches this. Say it in your words: "six years in retail banking, the last three as a branch supervisor." Do not relabel the branch as customer operations. |
| F2 | "experience handling regulated complaints" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | presentation | Your material says formal, not regulated. The bridge is the quote itself, with nothing added. Answer slot: the JD raises regulated complaints. If the log carried regulatory deadlines or regulator-reportable outcomes, say which and how you tracked them. If it did not, say so and stay with the formal log. |
| F3 | "Own the member complaints process end to end across branches" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | transferability | Credible adjacent work at one branch's scope. Do not say end to end or across branches. Answer slot: if you took a complaint from first contact to close, say which steps were yours. If another desk held any part of it, say so. |
| F4 | "and the contact centre" (JD) | "Never worked in a contact centre" (your message) | none | [grounded] | capability | A stated absence. The words are yours: "I've never worked in a contact centre." Then a plan for learning it, said as a plan and never as a past. Nothing is added to make the gap smaller. |
| F5 | "report monthly on complaint volumes" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | medium | [grounded] | none | Your material already reaches monthly volume reporting. Say "spreadsheet", as you did. It is an inspectable artifact: a redacted copy would move this row to high. |
| F6 | "resolution times" (JD) | none given | none | [grounded] | discovery | Your material does not show whether resolution times were reported. Answer slot: if they were, say how they were measured. If not, say so and say what you would add first. |
| F7 | "coach branch supervisors on escalations" (JD) | "trained new tellers on our escalation script" (your message); "the last 3 as a branch supervisor" (your message) | medium | [grounded] | transferability | Credible adjacent work. You trained tellers on an escalation script, and you held the supervisor role. Neither is coaching supervisors, so say the tellers as tellers. Answer slot: if you ever coached a supervisor on an escalation, say what you did. If not, say so. |
| F8 | "work with digital teams on self-service journeys" (JD) | none given | none | [grounded] | discovery | Your material does not show this. Answer slot: if you have worked with a digital team or on a self-service journey, say which and what you did. If not, say so plainly and say how you would find out what the digital team has built. |
| F9 | "confident presenting to senior leaders" (JD) | "I've never presented to anyone above regional level" (your message) | none | [grounded] | capability | A stated absence. The words are yours: "I've never presented to anyone above regional level." Then a plan for a leadership presentation, given as a plan. |
| F10 | "comfortable with Excel reporting" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | medium | [grounded] | presentation | The quote reaches reporting but says spreadsheet, not Excel. Say spreadsheet. Name Excel only if you can name what you did in it. |

The strongest evidence is the six years and the complaints log. The three gaps the panel is most likely to find are the contact centre (F4), presenting above regional level (F9) and resolution times (F6).

## Prohibited list

Claims this pack will not coach, each with its basis and its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end across branches | Inflated form of F3 | The quote at its own scope: "I handled the branch's formal complaints log." Your material says one branch's log, not the process across branches. A3 stays inside the log. |
| Has contact-centre experience | Negative you stated, F4 | "I've never worked in a contact centre." No slot. |
| Has presented to senior leaders | Negative you stated, F9 | "I've never presented to anyone above regional level." No slot. |
| Handled regulated complaints | Inflated form of F2 | "I handled the branch's formal complaints log," as quoted. |
| Coached branch supervisors on escalations | Inflated form of F7 | "trained new tellers on our escalation script," at the tellers' scope. |
| Has used Excel for reporting | Inflated form of F10 | "spreadsheet," as quoted. |

## Grounding brief

From your summary of Ashgrove's July 2026 strategy brief. The brief itself is not in this conversation, so the wording below is your summary's.

- **Digital:** "move 40% of member service to digital channels by 2028." Expect this in questions about where complaints go.
- **Branches:** "consolidate eight branches into five hubs over 2027." Expect this in questions about who owns a complaint when a branch closes.
- **Lending:** "launch a small-business lending product in Q1 2027." You do not need to prepare on lending for this role, but know it is coming.
- **Competition:** "the main competitive pressure is app-only banks." Use it when you talk about digital, not as a point about the banks.

The brief dates from July 2026. Nothing here is confirmed newer. If an interviewer cites a more recent plan, treat it as new information.

---

## Round 1: Recruiter screen (30 minutes)

| Persona (weight) | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Conversational and rapport (4) | "Walk me through the journey." Friendly, unstructured. | Highest. A recruiter screen is logistics, motivation and knockout checks in a friendly register, and casual questions are still scored. | A 90-second arc: six years in order, ending on the complaints work. |
| Skeptic (3) | "Just checking" questions on the contact centre and presenting. | High. The recruiter decides whether to advance you, so gaps surface here first. | Plain acknowledgment, then your plan. Not a defence. |
| Values, light (1) | One question on complaints as a value. | Low. The recruiter does not score values; the panel does. | One ready story. |

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, walk me through the journey to here." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "I handled the branch's formal complaints log" | Tell the six years in order: retail banking, then the last three as a branch supervisor, then the complaints log. Under 90 seconds, in your own words. | The opener is scored for economy. Every clause rests on a quote above, so nothing extends the record. |
| A2 | "What have you been playing with in digital lately?" | JD | [grounded] "work with digital teams on self-service journeys" (JD) | Answer slot: if you have worked with a digital team or on a self-service journey, say which and what you did. If not, say so plainly and say how you would learn what the team has built. | A light version of the JD line, which the JD raises. The honest branch is the rehearsal. |
| A3 | "Why leave branch work for this?" | VAL | [grounded] "I handled the branch's formal complaints log" | Give your real reason in your own words. The pack does not supply one. Say what the complaints log taught you that the role needs. | The motivation probe is the most common screen question. Only the log is quoted, so the reason stays yours. |
| A4 | "What did you actually do when you trained the new tellers?" | EXP | [grounded] "trained new tellers on our escalation script" | Say how you taught the script and how you checked it landed. Answer slot: if you checked whether tellers used it, say how. If you did not, say so. | The training is the nearest evidence to coaching, and this question tests what was yours to design versus deliver. |
| A5 | "Have you worked in a contact centre? If not, how would you run complaints across one?" | JD | [grounded] "Never worked in a contact centre" (your message); "and the contact centre" (JD) | Say it plainly: "I've never worked in a contact centre." Then the nearest thing you have, the complaints work from the branch side, and what you would learn first. Do not describe contact-centre work. | The screen's knockout check. Your first sentence settles it; the rest is the plan. |
| A6 | "What part of this job would you be weakest at on day one?" | JD | [grounded] "confident presenting to senior leaders" (JD); "I've never presented to anyone above regional level" (your message) | Name presenting in one sentence: "I've never presented to anyone above regional level." Then your plan for building that, said as a plan. | The skeptic's stem. The answer names the gap and then turns to a plan. |
| A7 | "This role coaches branch supervisors on escalations. What is your basis for that?" | JD | [grounded] "trained new tellers on our escalation script"; "the last 3 as a branch supervisor" | Say the tellers as tellers. Say the three supervisor years as the years you held the role. Answer slot: if you ever coached a supervisor on an escalation, say what you did. If not, say so and say what the teller training taught you about coaching. | F7. The basis is the teller training and the supervisor years, not coaching you have not done. |
| A8 | "Tell me about a time you kept hold of a complaint until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log" | Selection scaffold: pick a complaint you kept hold of until it closed. It needs a named stake, the point where the first answer failed, and how it ended. If none comes to mind, say so plainly, then give the nearest thing your material carries: the log, and how you handled it. | Maps to Own the Fix, the value your material is closest to. The log is a process, not a story with an ending, so the honest branch may be the answer. |

**Round 1 reverse questions**

1. "What would make the first month in this role a good one?" Why it lands: it makes you the person planning the role, not only interviewing for it.
2. "What has made complaints hardest to resolve across branches so far?" Why it lands: it uses the JD's own words and shows you are thinking about the real problem.

---

## Round 2: Head of Member Services, your future manager (45 minutes)

| Persona (weight) | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values and behavioural (4) | STAR-shaped probes on the four values, from your future manager. | Highest. The recruiter says this round is "mostly behavioural", which moves weight from the usual hiring-manager tilt toward case. | One story per value where your material can carry one; a scaffold where it cannot. |
| Skeptic (2) | Gap probes: "why here, why now", the contact centre. | High. A manager is buying a hire with no gap. | Plain acknowledgment, then the plan. |
| Data-driven prober (2) | "How was that counted?" about the spreadsheet. | Medium. The spreadsheet is on your CV and your manager will read it. | Name the assumption you would defend least. |
| Case and strategist (1) | A live question on the digital shift or branch hubs. | Medium. The manager owns the work the 2027 plan changes. | Clarify, then structure. |

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time a member needed something explained to them twice." | VAL | [grounded] "trained new tellers on our escalation script" (nearest quote) | Selection scaffold: pick a time a member came back for the same explanation, and what you changed in how you explained it. If none comes to mind, say so, then give the nearest thing your material carries: how you taught the script. | Maps to Plain Words: "if a member needs it explained twice, we wrote it wrong." The training quote is the nearest; it carries no member story. |
| B2 | "When has a rule been right on paper and wrong for the member in front of you?" | VAL | [generic] | Selection scaffold: pick a time a rule and a member's need pulled apart, what you did, and who you told. If none comes to mind, say so. Do not invent a rule conflict. | Maps to Members First. No quote of yours carries this, so the honest branch is the rehearsal. |
| B3 | "Tell me about a time something local to a branch's town changed how you handled a case." | VAL | [generic] | Selection scaffold: pick a case where the branch's town, its customers or its local context changed the decision. If none, say so plainly. | Maps to Neighbours, Not Numbers. None of your sentences carries it. |
| B4 | "Tell me about a time a target and a member's problem pulled in different directions." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" (nearest quote) | Selection scaffold: pick a time a figure you were measured on pulled against a member's case, and what you did. If the spreadsheet is where you saw it, say how. If there was no such time, say so and say what the spreadsheet measured. | The spreadsheet is the nearest number your CV carries, so the question tests whether it ever pulled against a member. |
| B5 | "You've never worked in a contact centre. Why should we hire you over someone who has?" | JD | [grounded] "Never worked in a contact centre" (your message); "across branches and the contact centre" (JD) | Hold: "I've never worked in a contact centre." Then the nearest case, the complaints you handled from the branch side, and what you would bring across. Hold through two follow-ups by returning to the plan, not by adding to the past. Concede the specific part: name which parts of a contact centre you have not done. | Highest-ROI prep in this pack. It is the gap the panel will find in every round and the one a skeptic will push hardest. A plain answer, rehearsed, changes the interview. |
| B6 | "Our plan consolidates eight branches into five hubs over 2027. What happens to the complaints you own when a branch closes?" | CO | [grounded] "I handled the branch's formal complaints log" (your message); "consolidate eight branches into five hubs over 2027" (your summary of the brief) | Clarify before structuring: which complaints move, and to whom. Structure: the open log, its owner, the handoff, and the member's route back. Answer slot: if you have been through a closure or merger, say what you did. If not, say so and say what you would protect first. | The 2027 plan is the likeliest reason for this question. The answer is a process, not a claim about your history. |
| B7 | "How was the monthly complaints spreadsheet counted? Which figure would you defend least?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Weakest-assumption move: name, in your own words, the assumption behind the figure you would defend least, before they do. Answer slot: how the volumes were counted, what they were sensitive to, and which part was yours. If you cannot say how a figure was counted, say so. | The spreadsheet is your only numeric artifact, and a data-driven prober will go to it. Only the fact that you built it is quoted, so the pack names no method. |
| B8 | "Which measures did your monthly spreadsheet carry?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses"; "report monthly on complaint volumes and resolution times" (JD) | Answer slot: list the measures you can name. If resolution time was one, say how it was measured. If not, say so and say what you would add first. | The JD asks for resolution times and your quotes do not show them. The honest branch is the answer. |
| B9 | "Our plan moves 40% of member service to digital by 2028. Where do complaints go in that world, and who owns them?" | CASE | [grounded] "move 40% of member service to digital channels by 2028" (your summary of the brief) | Clarify first: what counts as a complaint and what is only a query. Then structure: the channel, the owner, the handoff to a person, and the member's route back. The structure is the pack's own; it makes no claim about your past. | Your manager may use the plan's own numbers. A structured answer beats a memorised one. |

**Round 2 reverse questions**

1. "Where do branch supervisors get stuck on escalations today, and what has been tried?" Why it lands: it names your future team's pain point from the JD.
2. "What would success on complaints look like at the end of the first year, and how would it be measured?" Why it lands: it shows you think in measures, and it invites your manager to name the report.
3. "What would you want the digital team to build first for complaints, and why?" Why it lands: it ties to the JD's self-service line and shows you have thought about the channel.

---

## Round 3: Panel of two branch managers (60 minutes, including a 20-minute case)

The recruiter's wording is that the panel "is also the values round" and scores against the four values. The values cheat sheet lives here.

| Persona (weight) | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values and behavioural (4) | Scenario probes on the four values, each scored. | Highest. The recruiter names the panel as the values round. | One answer per value; scaffolds where no quote carries a story. |
| Case and strategist (3) | The 20-minute escalation case. | High. The recruiter names it. | Clarify, contain, decide who holds it, explain, record. |
| Peer evaluator (2) | Seams between branch and complaints work; credit; disagreement. | Medium. Branch managers are the people you would work alongside and coach. | Seam principles, not claims to know their seam. |
| Pressure (1) | Holds you to one answer. | Low to medium. A two-person panel is usually calmer; keep one hold ready. | Hold, then concede specifically. |

**Values cheat sheet.** Values are the official names from the text copied from ashgrovecu.org this morning. No quoted sentence of yours carries a story for any of the four, so each row is a selection scaffold with its honest branch.

| Value | Working meaning | Your story |
|---|---|---|
| Members First, Always | "we decide from the member's side of the counter" | Pick a decision you made from the member's side and what it cost you. If none comes to mind, say so, then give the nearest thing your material carries: the complaints log you handled. |
| Plain Words | "if a member needs it explained twice, we wrote it wrong" | Pick a letter or explanation you rewrote so a member could follow it. If none, say so, then give the teller script you trained. |
| Neighbours, Not Numbers | "every branch is part of its town" | Pick a time your branch's place in its town changed a decision. If none, say so plainly. No sentence of yours carries this yet. |
| Own the Fix | "whoever finds the problem keeps hold of it until it is solved" | Pick a complaint you kept hold of until it closed, the point where it stalled, and how it ended. If none, say so, then give the complaints log you handled. |

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell us about a time you decided a case from the member's side of the counter." | VAL | [grounded] "I handled the branch's formal complaints log" (nearest quote) | Selection scaffold: a decision you made for the member, what it cost, and how it landed. If none comes to mind, say so, then describe how you handled the log. | Value one, scored by all four panel members. |
| C2 | "Tell us about a letter or explanation you rewrote so a member could follow it." | VAL | [generic] | Selection scaffold: pick a letter or explanation you rewrote, what was wrong with the first version, and what you changed. If none, say so. | Value two. None of your sentences carries it, so there is no story to map. |
| C3 | "Tell us about a time your branch's place in its town shaped how you handled a case." | VAL | [generic] | Selection scaffold: a case where the local context changed what you did. If none, say so plainly. | Value three. Same reason as C2. |
| C4 | "Walk us through a complaint you kept hold of until it was solved, including where it stalled." | VAL | [grounded] "I handled the branch's formal complaints log" (nearest quote) | Selection scaffold: the complaint, where it stalled, and who you kept it with until it closed. If none, say so, then describe the log and how you held cases in it. | Value four. This is the one most likely to be followed up, so the honest branch needs to be ready. |
| C5 | Case: "A member has escalated the same complaint twice. Your supervisor says it is closed; the member says it is not, and has mentioned the external route. You have an hour. Walk us through it." | CASE | [generic] | Clarify what is in the file and what the member asked for. Check the facts and the deadlines your firm uses; this pack does not assert any regulator's timelines. Decide who holds the complaint now. Write the member's explanation in plain words. Record what you decided and why, and tell the supervisor what changes. | The 20-minute case is an escalation problem from this role. The scenario is a practice version, not the panel's real file. Ask the recruiter for the case format (upgrade menu). |
| C6 | "A branch supervisor disagrees with your escalation decision in front of you. What do you do?" | CASE | [generic] | Ask what they know that you do not. Restate your decision and its basis. Agree the parts you can. Hold the parts the member needs. Say who decides if you cannot agree. | A live disagreement with a peer, so it tests the peer and pressure styles together. |
| C7 | "Our teams sit side by side. Where is the seam between a branch and complaints work, and what happens when you disagree?" | VAL | [generic] | Name seam principles: who holds the complaint, who speaks to the member, who can close it. Do not claim to know their seam; ask them. Disagreement: a scaffold with its honest branch. | Peer stem. The principles answer shows you would work with them, not over them. |
| C8 | "When a complaint fix spans two branches, how do you handle credit?" | VAL | [generic] | Scaffold: who did what, and whether you name the people. If you have not had a case spanning branches, say so. | Peer stem about credit, which panels use to test turf. |
| C9 | "You've never presented above regional level. Why should we trust you in front of our leadership?" | JD | [grounded] "I've never presented to anyone above regional level" (your message); "confident presenting to senior leaders" (JD) | Plain acknowledgment: "I've never presented to anyone above regional level." Hold the claim you can back: you handled the complaints log. Concede the gap: you have not presented above regional level. Do not argue that you would be fine. Then the plan for a leadership presentation. | Pressure stem on a stated gap. Hold once, concede specifically, then move to the plan. |
| C10 | "Which of your figures would a branch manager challenge first?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Answer slot: name the figure you would expect to be challenged and the assumption behind it, in your own words. If you cannot say how it was counted, say so. | Branch managers know the numbers they report against. This is the prober's question in peer form. |

**Round 3 reverse questions**

1. "What could a new Member Experience Lead do in the first month that would genuinely help your branch?" Why it lands: it is peer reciprocity. It asks what they get from the hire, not only what you need.
2. "When a complaint crosses two branches, who holds it until it is solved?" Why it lands: it uses Own the Fix in the panel's own terms.
3. "What does a branch manager need from complaints work that they do not get today?" Why it lands: it asks the panel for the seam, and lets you name what you would change.

---

## Requirement coverage

| JD requirement | Question IDs |
|---|---|
| 4+ years in financial-services customer operations | A1 |
| Experience handling regulated complaints | A8, C4, C5. The case tests the regulated part; the pack cannot assert the regulation. |
| Own the member complaints process end to end across branches and the contact centre | A5, B5, B6, C5 |
| Report monthly on complaint volumes and resolution times | B7, B8, C10 |
| Coach branch supervisors on escalations | A7, C6 |
| Work with digital teams on self-service journeys | A2, B9 |
| Confident presenting to senior leaders | A6, C9 |
| Comfortable with Excel reporting | B7, on the spreadsheet only. Excel is not confirmed; see the upgrade menu. |

## Sources

**Provided documents**

- The job description, as pasted in your message.
- Ashgrove's values, as pasted from ashgrovecu.org (copied this morning).
- The recruiter's email on rounds, length and scoring, as pasted.
- Your summary of the July 2026 strategy brief. The brief itself is not in this conversation.
- Your background, from your message.

**Searches and fetches:** none sent.

**Research tier:** L1, searches 0 of 6, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | The values cheat sheet in round 3. The values text is pasted from ashgrovecu.org, so the inputs fix it. |
| 2. Ashgrove interview process | skipped | Round structure and persona weights. The recruiter's email fixes the rounds, lengths and scoring. |
| 3. Ashgrove strategy and recent news | skipped | The grounding brief and B6, B9. Your summary fixes the current priorities. Recent news was not searched; if an interviewer cites a newer plan, this pack will not know it. |
| 4. Interviewer name and company | n/a | No names given, so there was no query to form. The interviewer read is absent. |
| 5. Representative Member Experience Lead JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions. |

## Upgrade menu

- Interviewer names for rounds 2 and 3 → persona weights from their public footprints, and a reverse question tied to their own career path.
- The recruiter's format for the 20-minute case, such as a written file or a verbal brief → C5 rehearsed in the real format.
- A redacted copy of the monthly complaints spreadsheet → F5 moves from medium to high, because it is an inspectable artifact.
- Whether you used Excel functions or pivot tables in it → F10 can name them, in your words.
- The full strategy brief → the grounding brief checked against the document rather than your summary.
- Any regulated-complaint details you worked to, such as the timescale → F2 and A8 can hold stated facts instead of slots.
- Your prep time before 20 November → a prioritised triage section for what to rehearse first.
- Deep research (L2), offered once: up to six more searches and two more fetches on the strategy brief, interviewer footprints, loop reports and recent news. It adds a few minutes. Say yes and it runs.
- With no dossier present: a `tuesday-dossier.md` from an earlier job-underwriter run would add that run's verified evidence and prohibited claims to this pack.
