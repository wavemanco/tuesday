Your prep pack is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-tuesday-part-2-rooms-case-6-denied-f88b3b7f/962f8239-3cbc-494e-b436-b80c282778bf/scratchpad/Larkfield_engineering-manager_interview_pack.md`. It's in loop mode, with a shared fit snapshot and one mini-pack per round.

The web search was refused, so the pack has nothing on Larkfield's values, interview loop or strategy. Those parts are labeled generic, and the file's Sources section lists the refused calls.

The biggest prep item is the manager-of-managers objection (1S4). Say the word and I'll play the Director on it, with follow-ups.

I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

Does the role need on-site days at a hardware site, travel, or a particular location? The role text doesn't say, and for a hardware-adjacent role that can decide whether the offer is on the table.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Larkfield_engineering-manager_interview_pack.md -----
# Larkfield Systems, Engineering Manager: prep for three rounds

Loop mode. One shared fit snapshot and source block, then one mini-pack per round, then a shared upgrade menu.

- **Round 1:** Hiring manager, Director of Engineering (your would-be boss). 45 minutes. Name not given.
- **Round 2:** Panel. Two staff engineers and a product manager. 60 minutes. Names not given.
- **Round 3:** VP Engineering. 30 minutes. The recruiter describes it as "values and leadership philosophy."

## How to use this pack, and the type key

Personas describe how a question arrives. Types describe what is being scored. Guidance is scaffolding, not a script. Rehearse what you actually did, in your own words.

| Type | Meaning |
|---|---|
| JD | The role's stated responsibilities, including the gaps |
| EXP | Your own record: what you did, and how the numbers were counted |
| CASE | A live problem from the role. It asks about no past |
| VAL | Leadership and values, scored through past behavior |
| CO | Company strategy. None in this pack, because the company search was refused (see Sources) |

Provenance labels: **[grounded]** traces to your message or the role text; **[inferred]** is a derivation; **[generic]** is a role-family pattern with no claim about you or Larkfield.

## Fit snapshot

Shared across all three rounds. Each evidence cell holds your own words, quoted from your message, or `none given`. Requirement quotes come from the role description you pasted.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" — role description | "9 years engineering, 3 as a team lead of 6, currently at a payments company." — your message | medium | [grounded] | transferability | Your material shows a team lead of 6 for 3 years at a payments company. It does not show two squads or device-management services, so the bridge stays at the team: "I was a team lead of 6 for 3 years." The device side is a plan, said as a plan. Answer slot: the role names two squads, so expect a probe on whether you have led more than one group. If you have, say which and how, in your own words. If not, say so plainly. |
| F2 | "own delivery, hiring and growth for 11 engineers" — role description | "I run our hiring loop for backend roles — about 40 interviews last year." — your message | medium | [grounded] | presentation | The quote already reaches the hiring part in its own terms. Say it as written: "I run our hiring loop for backend roles, about 40 interviews last year." It adds no practice, figure or event. Limit: the quote says backend roles, and says nothing about the 11 engineers. |
| F3 | "own delivery, hiring and growth for 11 engineers" — role description | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | medium | [grounded] | transferability | The quote is delivery work under roadmap pressure, for a team of six, measured as on-call burden. It does not reach delivery across 11 engineers. Bridge at the quote's own scope: "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." Answer slot: the 60% is a figure, so expect probes on how it was counted. If you counted it, say how. If someone else did, say so. Name the assumption you would defend least, and say which part was yours. |
| F4 | "own delivery, hiring and growth for 11 engineers" — role description | none given | none | [grounded] | discovery | Your material does not show growth of the people you led, and the material is silent on it, which is not the same as a stated absence. Answer slot: if you grew engineers, say what happened to them, in your own words. If you did not track it, say so plainly. |
| F5 | "partner with hardware and product on roadmap" — role description | "I pushed a reliability quarter through against roadmap pressure." — your message | medium | [grounded] | transferability | The quote shows roadmap pressure, not partnership with product. Bridge at its own scope: "I pushed a reliability quarter through against roadmap pressure." Answer slot: if you worked with product on that call, say how, in your own words. If you did not, say so. |
| F6 | "partner with hardware and product on roadmap" — role description | "I've never managed managers and never owned a hardware-adjacent roadmap." — your message | none | [grounded] | capability | A stated absence. Words: "I've never owned a hardware-adjacent roadmap." Then how you would learn the hardware constraints, said as a plan. No claim to hardware roadmap work. |
| F7 | Managing managers: not in the role text. Raised by you | "I've never managed managers and never owned a hardware-adjacent roadmap." — your message | none | [grounded] | capability | A stated absence. Words: "I've never managed managers." Then the plan for learning it, said as a plan. Whether the two squads have leads under them is not in the material. The Director can answer it (upgrade menu). |
| G1 | On-site days, travel, or location for a hardware-adjacent role: not in the role text | none given | none | [generic] | hard_gate | Your material does not establish whether the role needs on-site days at a hardware site, travel, or a particular location. Surfaced, not bridged. The one question in this message asks it. |

## Prohibited claims

Built from the fit snapshot before any question was written. The language below is not to be coached, and each entry says why.

| Not coached | Basis | Honest form |
|---|---|---|
| Led two squads | Inflated form of F1 | "I was a team lead of 6 for 3 years." The limit is this pack's observation: your material shows one team of six. |
| Ran the hiring loop for 11 engineers | Inflated form of F2 | "I run our hiring loop for backend roles, about 40 interviews last year." |
| Delivered across 11 engineers | Inflated form of F3 | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." |
| Cut on-call by 60% | Inflated form of F3. Drops "my team's" and the sequence, and makes you the sole cause | The same quote, at its own scope. |
| Managed managers | Negative you stated, F7 | "I've never managed managers." Plain acknowledgment, no slot. |
| Owned a hardware-adjacent roadmap | Negative you stated, F6 | "I've never owned a hardware-adjacent roadmap." Plain acknowledgment, no slot. |

## Round 1: Hiring manager (Director of Engineering), 45 minutes

**Weights.** Skeptic 4, Case/Strategist 4, Data-Driven Prober 2, Pressure 2. Twelve questions, inside the loop bank range of 8 to 12. Conversational is not banked here: a hiring-manager round carries a low prior for it, and the opener is covered by the fit rows.

**Highest-ROI prep in the whole pack: 1S4.** You have never managed managers, and the Director is buying capability for a role whose first job is leading two squads. The objection will come in some form. Rehearse the plain acknowledgment, then the plan, through three follow-ups, until it is boring.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | "You haven't managed managers" and "you've never run hardware work" | High. A hiring manager buys capability and checks gaps. These two are the gaps the role names that you can least show | Acknowledge the negative in your words, then give the plan. Calibrated candour over bluffing |
| Case/Strategist | Live problems on the two squads and a hardware release date | High. The Director is buying judgement on their roadmap | Clarify, objective, segmentation, approach, metrics, risks. Think aloud |
| Data-Driven Prober | The 60% | Medium. Your strongest number is the one most likely to be probed | Say what you can and cannot say about how it was counted |
| Pressure | A short challenge on how much of the result was yours | Low to medium. A 45-minute round with the boss-to-be is not a stress panel, but a short challenge is plausible | Pause, restate, hold through two follow-ups before any concession |

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 1S1 | "Who leads the two squads today, and how would that change with me in the role?" | JD | [grounded] "Lead two squads building device-management services" — role description. [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." — your message | Start with the plan: what you would look at in the first month to see how the squads are led and where decisions sit. Plain acknowledgment only if they ask about your past: "I've never managed managers." Hold by returning to the plan. | F7 and F1 meet here. The question asks about the squads, not about your history |
| 1S2 | "Your team is six people. What would you spend your week on managing eleven across two squads?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." — your message | Start from the quote: six is the team you have run. Say what you would spend the week on, framed as a plan. Do not describe a week of managing managers you have not had | F1 is the evidence, and the answer is a plan, which the pack can help shape |
| 1S3 | "Hardware releases and software roadmaps run on different clocks. How would you plan across that?" | JD | [grounded] "partner with hardware and product on roadmap" — role description | A plan: ask hardware what constrains the date, ask product what the date is for, then name the trade-off. If they ask about your past: "I've never owned a hardware-adjacent roadmap." Then the adjacent quote, at its own scope: "I pushed a reliability quarter through against roadmap pressure." | F6 is the second gap. The question asks for a plan, so the pack writes no past for you |
| 1S4 | "You haven't managed managers. How would you know, six months in, that you were ready to run a second layer?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." — your message | Plain acknowledgment: "I haven't managed managers." Then the plan: what you would want to see, from whom, by when. Hold through two follow-ups by returning to the plan. Concede specifically if pushed on whether you can do it now: "I can't show it yet. Here is how I'd find out." | Highest-ROI item in the pack. F7's acknowledgment is the one line the candidate has given the pack, so the plan is the answer |
| 1K1 | "Two squads, a reliability backlog, and a hardware release in six weeks. What do you do this quarter?" | CASE | [generic] | Clarify what counts as release-ready and who owns the backlog. State the objective, segment the backlog, lay out an approach, name metrics and risks. Think aloud | A live problem from the role. No claim about your past |
| 1K2 | "You run the backend hiring loop. How would you change it for device-management engineers?" | JD | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." — your message | Start with the quote: you run the loop for backend roles. Say what you would keep, and what you would test for on device work, as a plan. Do not say you have hired device engineers | F2 is presentation: the answer is the quote and a plan |
| 1K3 | "A device fleet reports a spike in failed updates two weeks after a release. Walk me through your first hour." | CASE | [generic] | Scope it: stop the spread, define the affected fleet, decide on rollback, decide who to tell. Name the trade-off between speed and certainty | Device management is the product. A live problem, not a claim about you |
| 1K4 | "A product lead wants a feature that adds load to the reliability backlog. Which way do you go?" | CASE | [generic] | Name the decision criteria before the answer. Say what you would need from product and from the squads. State the risk you accept either way | A trade-off the role will meet monthly |
| 1P1 | "Walk me through how the 60% on-call drop was counted." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | Answer slot: if you counted it, say how, in your own words. If someone else did, say so. If you did not count it, say so plainly. Do not supply a baseline or a method you cannot repeat | F3's figure raises the defend-the-number slots, and only those |
| 1P2 | "Which assumption behind that drop would you defend least?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | Name the weakest assumption you know, in your own words. If you do not know one, say that. The pack does not name it for you | The weakest-assumption move converts a gotcha into a credibility gain |
| 1U1 | "Sixty seconds: why you, for this role, given what we've just discussed?" | VAL | [generic] | Pause. Restate. Anchor on the two facts you can defend: the team lead years, and the reliability quarter. Hold through two follow-ups | A pressure open prompt. It makes no claim about other candidates |
| 1U2 | "That result — how much of it was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | Hold: "I pushed the quarter through, and that is in the quote." Concede specifically: if you cannot separate the quarter's effect from other changes, say so and say what you would check | Hold-then-concede. Do not claim the whole 60%; the quote says your team's burden dropped |

**Reverse questions, round 1**

- "Who leads the two squads today?" Lands because it tests the manager-of-managers gap and shows you have read the org shape.
- "What would make the first ninety days look like a clear success to you?" Lands because it turns an interview into a planning conversation.
- "Which of the two squads has the harder reliability problem right now, and why?" Lands because it shows you think about the work.
- "How are hardware release dates set, and who gets a say when one moves?" Lands because it shows partnership intent on the hardware side.
- "What did the last person in this role get wrong that you'd want the next one to avoid?" Lands because it invites candour, and the answer tells you what the Director has been burned by.

## Round 2: Panel (two staff engineers and a product manager), 60 minutes

**Weights.** Peer Evaluator 4, Data-Driven Prober 3, Case/Strategist 2, Values/Behavioral 2. Eleven questions. The staff engineers are peers, so each gets the peer and prober personas. The product manager gets the cross-functional values persona and the roadmap case. Skeptic and Pressure are not banked here: the Skeptic objections are in Round 1, and the panel is a collegial room.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Peer Evaluator | Seam questions between their stack and yours. "What would you need from me?" | High. Peers price what a hire does to their load | Propose seam principles, not a map you have not seen. Offer reciprocity: what you bring their team |
| Data-Driven Prober | How the reliability number was counted, and what healthy looks like for a device service | High for the staff engineers. They read the CV closely, and the 60% is in it | As for 1P1 and 1P2 |
| Values/Behavioral | A disagreement with product about what ships | Medium. The cross-functional prior puts values with the product manager | No quote carries a disagreement story, so use the selection scaffold and its honest branch |
| Case/Strategist | A roadmap trade-off with a hardware date | Medium. Roadmap trade-offs are the product manager's native ground | Clarify, state the trade-off, name the risk |

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 2E1 | "Our two teams sit side by side on the device stack. Where does your service end and ours start?" | JD | [grounded] "Lead two squads building device-management services" — role description | Seam principles, not a map: who owns the contract, who gets paged, who decides when a change crosses it. Do not pretend to know their boundary | Peer seam. The raising source is the role's own wording |
| 2E2 | "Tell me about a time you were overruled on a technical call." | VAL | [generic] | Selection scaffold: pick a time a peer or senior engineer overruled you, or you overruled them, and a decision had to be made. If none comes to mind, say so plainly, then give the nearest thing your material carries, in its own words | An open prompt. No quote carries an overruling story, and the pack will not supply one |
| 2E3 | "How do you handle credit when work spans two teams?" | VAL | [generic] | Selection scaffold: "we" for the context, "I" only for what you did, in your own words. If you have no example, say so and say how you would handle it | A common peer probe. Nothing in your material answers it, so the honest branch is the answer |
| 2E4 | "If you and I disagreed on a roadmap item, what would you want from me?" | VAL | [generic] | Reciprocity: what you would bring to their team, and what you would need. Propose principles for disagreement, not a story you have not told | A peer question about partnership. A plan, not a past |
| 2C1 | "Walk me through how the on-call number was counted." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | Answer slot: if you counted it, say how. If someone else did, say so. If you did not count it, say so plainly | The same figure as 1P1, from a staff engineer's angle |
| 2C2 | "Which metric would tell you a device-management service is healthy, and what would make that metric lie?" | JD | [generic] | Name a metric and its weakest assumption in your own words. If you know a metric you have used, say what it counted. Do not claim a metric from your history you cannot repeat | A design question about the role's product. No past |
| 2C3 | "Which assumption in your reliability quarter would you defend least?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | Name the one assumption you know, in your own words. If you do not know one, say so | The weakest-assumption move, from the second staff engineer |
| 2K1 | "A hardware release slips six weeks and the roadmap is built on it. What do you do with the next quarter?" | CASE | [generic] | Clarify what is committed, objective, approach, risks. Name the trade-off aloud | A product-and-hardware case. No claim about your past |
| 2K2 | "Two requests from product, both urgent, one of them reliability. How do you choose?" | CASE | [generic] | Set the criteria first. Say what you would take to product, and what you would take to the squads | A roadmap trade-off. No past |
| 2V1 | "Tell me about a time you disagreed with product about what ships." | VAL | [generic] | Selection scaffold: pick a time you disagreed with product about a release. If none comes to mind, say so, then give the nearest thing your material carries: the reliability quarter, pushed through against roadmap pressure, in those words | An open prompt. No quote carries a product disagreement |
| 2V2 | "What do you do when product and engineering both say they're right?" | VAL | [generic] | Name what each side is right about, and the decision rule you would use. Say what you would tell each of them. Do not describe an instance you have not had | A values-in-practice scenario. Generic |

**Reverse questions, round 2**

- To staff engineer one: "Where does your service's responsibility end and the device gateway's begin?" Lands because it is the seam question, asked by someone who owns it.
- To staff engineer two: "What does an on-call week look like for the device squads?" Lands because it shows you care about the burden you are inheriting.
- To the product manager: "How are roadmap calls made when a hardware date moves?" Lands because it names the role's hardest partnership.
- To the panel, reciprocity: "What could a new EM do in the first month that would genuinely help your team?" Lands because it asks what they need, not what you need.
- To the panel: "What is the thing you haven't asked me that you'd want the next EM to understand?" Lands because it invites candour, and it leaves the panel talking.

## Round 3: VP Engineering, 30 minutes, values and leadership philosophy

**Values cheat sheet: not included.** It needs Larkfield's published values in hand, and none are. The search that would have fetched them was refused. The questions below run on the recruiter's words, which name the round and no values.

**Weights.** Values/Behavioral 5, Pressure 3, Case/Strategist 2. Ten questions, inside the bank range. Skeptic is not banked: the round 1 rehearsal covers it, and the VP will ask it only if round 1 has not closed it.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral | "What does leadership philosophy mean to you, in practice?" | Very high. The recruiter named this round as values and leadership philosophy | Open prompts. "I" for contribution, "we" for context. Selection scaffolds where your material has no story |
| Pressure | Thirty seconds, then a challenge on whether you should run a layer above team leads | Medium. Executive altitude, short time | Hold through two follow-ups. Concede only what is true |
| Case/Strategist | Where engineering leadership should be in two years | Low to medium. Thirty minutes leaves little room for a case, but executives score altitude | Say the structure in one breath, then say what you would learn first |

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 3V1 | "What does leadership philosophy mean to you, in practice?" | VAL | [grounded] "values and leadership philosophy" — recruiter, via your message | One belief, and one decision that shows it. Selection scaffold: pick the decision that shows it best. If you cannot name one, say so, then give the nearest thing your material carries | The recruiter's words raise the theme. The answer is a belief and an example |
| 3V2 | "Tell me about a time you held a delivery date and a reliability bar against each other." | VAL | [grounded] "I pushed a reliability quarter through against roadmap pressure." — your message | Map to the quote: the quarter, the roadmap pressure, and the result in the quote's words. Answer slot: what you did to get it through, in your own words. If there was no such step, say so plainly. The 60% is in the quote, so expect a how-counted probe | A strong story if the material carries it. The pack adds no step you did not state |
| 3V3 | "When did you put a person ahead of a metric?" | VAL | [generic] | Selection scaffold: pick a time a person's need changed a number you were tracking. If none comes to mind, say so, then give the nearest thing your material carries | An open prompt with no quote carrying the story |
| 3V4 | "What do you do with a strong engineer who has stopped growing?" | VAL | [generic] | Selection scaffold: pick a time you dealt with an engineer's growth, and what you did. If you have no example, say so and say how you would approach it | Covers the growth requirement in the role text. F4 is discovery, so the honest branch is the answer |
| 3V5 | "What is one leadership habit you would want the next person in this role to keep?" | VAL | [generic] | A habit, and why it matters, framed as your view. No claim to having kept it yourself unless your material says so | A values question about the role. It asks for a view, not a past |
| 3U1 | "Thirty seconds: why this role, now, for you?" | VAL | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." — your message | Pause. Anchor the answer in the role's own words: two squads, eleven engineers. Hold through two follow-ups | A pressure open prompt. The quote gives you your starting point |
| 3U2 | "You've never managed managers. Why should I believe you can run a layer above a team lead?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." — your message | Plain acknowledgment: "I've never managed managers." Then the plan: what you would do first, and how you would know it is working. Hold through two follow-ups. Concede specifically: "I can't show it yet. Here is how I'd find out" | The second round of the highest-ROI objection. Same words as 1S4 |
| 3U3 | "What, if anything, did that quarter cost you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | Answer from your own record. If the quarter cost something, say what. If it cost nothing you can name, say so. Do not invent a cost | A pressure question. The "if anything" lets you answer honestly either way |
| 3K1 | "Where should engineering leadership here be two years from now, and what would you do in the first six months to move it there?" | CASE | [generic] | Say the structure in one breath. Say what you would learn first, and what you would do with it. Do not claim knowledge of Larkfield's current strategy, because none was researched | Executive altitude. Generic, since no strategy source was checked |
| 3K2 | "The two squads have different risk profiles. How would you set their priorities?" | JD | [grounded] "Lead two squads building device-management services" — role description | Clarify what the risk profiles are. State the priority rule. Name one thing you would check before you change any priority | A roadmap question about the role's own structure. No claim about your past |

**Reverse questions, round 3**

- "What does a good leadership decision look like here, and which one from last quarter shows it best?" Lands because it asks for values in practice, the thing the round is scoring.
- "Where do you think engineering leadership is weakest today?" Lands because a VP who answers it candidly tells you what the job is.
- "How do you define a good manager of managers here?" Lands because it asks directly about the gap, and the answer tells you whether the bar is one you can reach.
- "What would make you regret this hire in a year?" Lands because it invites the honest answer, and it tells you what the VP is afraid of.
- "What is the trade-off you think about most in this job?" Lands because it shows you want the job's real weight, not its title.

## Requirement coverage

| Requirement | Question IDs |
|---|---|
| Lead two squads building device-management services | 1S1, 1S2, 2E1, 3K2 |
| Own delivery for 11 engineers | 1P1, 1P2, 3V2 |
| Own hiring for 11 engineers | 1K2 |
| Own growth for 11 engineers | 3V4. F4 is discovery, so the answer is your own record or the honest branch |
| Partner with hardware on roadmap | 1S3, 1K1, 1K4 |
| Partner with product on roadmap | 2K1, 2K2, 2V1, 2V2 |
| Managing managers (raised by you, not in the role text) | 1S1, 1S4, 3U2. F7 is the capability gap |

## Sources

Provided documents: your message, including the role description and the recruiter's wording about round 3.

Research tier: L1 — searches 3 of 6, fetches 0 of 2; user links read 0.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Larkfield Systems values | unavailable | The values cheat sheet, which needs published values in hand. Every call was refused, so round 3 runs on the recruiter's words alone |
| 2. Larkfield Systems interview process, engineering manager | unavailable | Loop structure. Your message and the recruiter's wording establish three rounds, so the persona weights rest on them. Nothing from this company's documented loop was checked |
| 3. Larkfield Systems strategy and recent news | unavailable | Current priorities for round 2 and 3 case questions and the CO bank. None was checked, so those questions are [generic] |
| 4. Interviewer names | n/a | No names were given for the Director, the staff engineers, the product manager or the VP |
| 5. Representative engineering manager JD | skipped | The role description you pasted fixes the fit snapshot's requirement rows |

Queries sent, each refused by a permission prompt. No retry was made:

- "Larkfield Systems values": refused
- "Larkfield Systems interview process engineering manager": refused
- "Larkfield Systems industrial IoT device management strategy news": refused

## Upgrade menu

- Larkfield's published values page, pasted → a values cheat sheet for round 3, and VAL questions mapped to real values in place of the open prompts
- The names of the Director, the two staff engineers, the product manager and the VP → personas weighted by their public footprint, and reverse questions tied to their own paths
- The full job posting, if there is one → fit rows quote the posting directly, and each hard requirement gets its own JD question
- Your answer on on-site days, travel and location → G1 is resolved either way
- Whether the two squads have leads under them (ask the Director) → F7 and 1S1 get their real shape
- The recruiter's note on panel composition and format → round 2 weights rebalance, for example if the product manager is on hardware
- Company research, offered once: a deeper pass of up to 6 more searches and 2 more fetches, several minutes. It needs the search permission this session refused → a strategy brief for the round 3 case questions, and CO questions in place of the [generic] ones
