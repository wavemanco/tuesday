Your prep pack is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-tuesday-part-2-rooms-case-8-canned-4e020d3e/1c1f5322-7fd6-44ad-9cc8-fe5512a840b2/scratchpad/ashgrove_member-experience-lead_interview_pack.md`. I built it as a three-round loop with a shared fit snapshot, since the rounds are on one day. The panel gets the values cheat sheet and the escalation case.

The highest-return prep is S2 in Round 2: "Your experience is one branch's complaints log. This job owns the process across branches and the contact centre. What would you do to close that gap?" Your honest answer is the one-branch scope plus a plan for the contact-centre side. Don't add scope to it.

Two limits on the pack:
- I ran no research. Your values and the four strategy lines you quoted were enough, so I haven't checked anything Ashgrove published after July 2026.
- I have not seen the full strategy brief, only the lines you quoted.

I can also play the escalation-case panel on K1 with follow-ups, and save a `tuesday-dossier.md` recording the gaps this prep exposed (F3, F4 and F10) for later sessions. I can convert the pack to Word too if you want it.

Is the escalation case a written brief you read beforehand, or a live discussion?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove_member-experience-lead_interview_pack.md -----
# Interview prep: Member Experience Lead, Ashgrove Credit Union

**Rounds:** three on 20 November 2026 (recruiter, 30 min; Head of Member Services, 45 min; panel of two branch managers, 60 min)
**Built:** 11 November 2026, first version
**Interviewers:** names not yet given. Round 1 is the recruiter. Round 2 is the Head of Member Services, who would be your manager. Round 3 is two branch managers, who also score the values.

Built from the JD text, values page, and recruiter email you pasted, plus the four strategy lines you quoted. I have not seen the full strategy brief.

## How to use this pack

This is a loop: one shared fit snapshot, then a mini-pack for each round. Each mini-pack has its own persona weights, question bank and reverse questions.

- **Personas** describe how a question is asked: friendly, skeptical, time-boxed, and so on.
- **Types** describe what is being scored:
  - **VAL**: whether past behaviour shows Ashgrove's published values.
  - **EXP**: whether your CV claims hold up under questions about what you did.
  - **JD**: whether you can do the job as listed, including its gaps.
  - **CO**: whether you know the company's strategy and can think at its level.
  - **CASE**: how you structure a live problem from the role.

The guidance is scaffolding, not a script. Where guidance says "answer slot", you give your own honest answer in the interview. The pack never supplies the answer.

## Fit snapshot (shared across all three rounds)

Gate check: none of the JD's requirements is a gate under the evidence definitions. The length-of-experience line is graded on fit like the rest.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" (JD) | "6 years in retail banking, the last 3 as a branch supervisor" (your message) | medium | [grounded] | none | No gap on the years. Say them as your message does. Expect a probe on whether retail banking counts as financial-services customer operations; answer it in your own words. |
| F2 | "experience handling regulated complaints" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | presentation | Your material says formal complaints, not regulated ones. Keep the wording: "I handled the branch's formal complaints log." Answer slot: if any step of that log was set by a rule or timescale you had to meet, say which and how you applied it. If the log ran without one you can name, say so plainly. |
| F3 | "Own the member complaints process end to end across branches and the contact centre" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | transferability | This is adjacent work: one branch's log, not the whole process across branches and a contact centre. Say the scope first, in the quote's terms. Answer slot: if you set how a complaint moved from first contact to close, say which steps and how you decided. If you did not, say so and describe the log you kept. |
| F4 | "across branches and the contact centre" (JD) | "Never worked in a contact centre" (your message) | none | [grounded] | capability | Words: "I've never worked in a contact centre." Then how you would learn that side, said as a plan and never as a past. Nothing added to make the gap feel smaller. |
| F5 | "report monthly on complaint volumes and resolution times" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | medium | [grounded] | presentation | The quote reaches monthly reporting in other terms. Describe it as it is: a monthly complaints spreadsheet your regional manager uses. Answer slot: if it holds complaint volumes, say which; if it does not, say so. |
| F6 | "resolution times" (JD) | none given | none | [grounded] | discovery | The material is silent on timings. Answer slot: if the spreadsheet or the log ever recorded how long a complaint took, say what it measured. If not, say so, and say how you would measure resolution times first. |
| F7 | "comfortable with Excel reporting" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | medium | [grounded] | none | The quote reaches the requirement already: you built a reporting spreadsheet that is in use. Do not describe more Excel skill than that. If asked about a specific function, say which one you used. |
| F8 | "coach branch supervisors on escalations" (JD) | "trained new tellers on our escalation script" (your message) | medium | [grounded] | transferability | This is adjacent work: teaching tellers a script, not coaching supervisors through escalations. Say the teller training in those terms. Answer slot: if you have coached another supervisor through an escalation, say what you did. If not, say so. |
| F9 | "work with digital teams on self-service journeys" (JD) | none given | none | [grounded] | discovery | The material is silent on digital work. Answer slot: if you have worked with a digital or app team on a member journey, say what you did in it. If not, say so and say how you would find out where members get stuck in an app. |
| F10 | "confident presenting to senior leaders" (JD) | "I've never presented to anyone above regional level" (your message) | none | [grounded] | capability | Words: "I haven't presented to anyone above regional level." Then how you would prepare, as a plan: a dry run with your regional manager, a one-page view, feedback before the real thing. Nothing that makes the gap feel smaller. |

## Prohibited list

These claims are not coached anywhere in this pack. Each is the wording a candidate reaches for under pressure, and each has a basis.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end across branches and the contact centre | Inflated form of F3 | "I handled the branch's formal complaints log," at its own scope. The pack's own observation: your material says one branch's log. |
| Ran the complaints reporting for the region | Inflated form of F5 | "I built the monthly complaints spreadsheet our regional manager uses." |
| Coached supervisors on escalations | Inflated form of F8 | "trained new tellers on our escalation script," at its own scope. |
| Worked in a contact centre | Negative you stated (F4) | "I've never worked in a contact centre." |
| Presented to senior leaders | Negative you stated (F10) | "I haven't presented to anyone above regional level." |

## Grounding brief

Vocabulary the company uses, from the four strategy lines you quoted:

- **Members and channels:** member service, digital channels, self-service journeys, app-only banks.
- **Structure:** branches, consolidating into hubs.
- **Products:** small-business lending.

Headline commitments:

- "move 40% of member service to digital channels by 2028"
- "consolidate eight branches into five hubs over 2027"
- "launch a small-business lending product in Q1 2027"
- "the main competitive pressure is app-only banks"

Stale framings: none flagged, but I have seen only the lines above, not the full July 2026 brief. I have not checked anything published after July 2026.

Generic pattern, not a claim about Ashgrove: new products usually bring new kinds of complaint, so the small-business launch may change what the complaints team handles.

## Sources

**Provided documents**

- The JD text, as pasted in your message.
- Ashgrove's values, as pasted from ashgrovecu.org/about/values, copied 11 November 2026.
- The recruiter's email on the process, as summarised in your message.
- The 2026 strategy brief: I have only the four quoted lines in your message.
- Your background, as written in your message.

**Research tier:** L1. Searches 0 of 6, fetches 0 of 2. No search or fetch was sent.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | Values cheat sheet: the pasted values page fixes all four values by name |
| 2. Ashgrove interview process, member services | skipped | Loop structure: the recruiter's email sets three rounds and their relationships to you |
| 3. Ashgrove strategy and recent news | skipped | Grounding brief: the July 2026 lines set the current priorities. Not checked: anything after July 2026, which could change the CO questions |
| 4. Interviewer names and Ashgrove | n/a | No names given, so no query could be formed. The interviewer reads are absent |
| 5. Representative Member Experience Lead JD | skipped | The JD you supplied fixes the fit snapshot |

## Round 1: recruiter screen (30 min)

**Persona weights.** Relationship prior for a recruiter screen is Conversational plus light Skeptic. Conversational gets weight 4 (four questions). Skeptic gets weight 2 (two questions), for the knockout checks. The risk is treating this round as unscored.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational | Friendly walk-through, motivation, a casual question on a JD topic | High. Recruiter screens lean on this register, and casual questions on the JD's plus-skills are still scored | 90-second arc for the biography. Treat casual JD questions as scored |
| Skeptic, light | Checks the knockouts: contact-centre work, the strategy | Medium. Your CV visibly lacks contact-centre work, so a knockout check is likely | Say the gap plainly, then the plan |

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, walk me through the journey." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" (your message); [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script" (your message) | A 90-second arc: six years in retail banking, the last three as a branch supervisor, then the complaints log and the teller training, in the words of your message. Stop there. Do not add a promotion or scope the material does not carry. | F1, F3 and F8 all sit in this answer. The biography is the top-weight question for this persona. |
| C2 | "What do you actually do in Excel these days?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" (your message) | Describe what the spreadsheet reports and who uses it, then stop. Answer slot: if you have built anything else in Excel, say what. If not, say so. | F7 is the plus-skill, asked casually. |
| C3 | "Why this, and why a member-owned credit union?" | VAL | [generic] | Speak to what draws you: the member-owned model, and complaints work done well. Do not name the hub plan as a reason to leave your branch, and do not criticise your current employer. Keep it to 60 to 90 seconds. | Motivation consistency is what a screen checks. This question has no candidate claim to hold up, so the guidance makes none. |
| C4 | "What's your read on the app-only banks as our main competition?" | CO | [grounded] "the main competitive pressure is app-only banks" (strategy brief, as quoted in your message) | Speak to what keeps a member with a credit union: a complaint handled well is one reason. Answer slot: if you have worked with a digital or app team on a member journey, say what you did. If not, say so and say how you would find out where members get stuck in an app. | F9 is a discovery gap, and this is the screen's casual route to it. |
| S1 | "I don't see contact-centre work in your background. How would you handle that side of this role?" | JD | [grounded] "Never worked in a contact centre" (your message) | Words: "I've never worked in a contact centre." Then the plan: how you would learn the contact-centre side, as a plan and not a past. | F4 is the knockout the recruiter will note. The question's premise is the negative you stated, so it can be asked as written. |
| S2 | "Ashgrove plans to consolidate eight branches into five hubs over 2027. What's your read, and what would it mean for the complaints work?" | CO | [grounded] "consolidate eight branches into five hubs over 2027" (strategy brief, as quoted in your message) | Speak to the members in a town that loses its branch: where they go, and what they lose. Do not comment on colleagues' jobs. Say what you would want to protect in the complaints work. | Tests whether you read the strategy at the company's altitude. Neighbours, Not Numbers is the value under test. |

**Reverse questions (Round 1)**

- "How will the move to five hubs change what this role owns?" Why it lands: it shows you read the brief and want the altitude. It also sets up the Round 2 conversation.
- "What does a member complaint look like on a good day here?" Why it lands: it signals member focus, which the first value asks for, rather than a metric.

## Round 2: Head of Member Services, your future manager (45 min, mostly behavioural)

**Persona weights.** The hiring-manager prior is Case plus Skeptic. Because the round is mostly behavioural, Values/Behavioral moves up. Skeptic gets weight 4, the top weight (four questions), because the stated gaps are where a manager will test you. Values/Behavioral gets 3, Case 2, Prober 2.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Probes the gaps: contact centre, senior presentation, the one-branch scope | High. A hiring manager buys capability and derisks gaps, and F3, F4 and F10 are the gaps they will test | Rehearse the highest-return question (S2) until it is plain. Hold, then concede |
| Values/Behavioral | Scenario and STAR-shaped questions on Members First and Own the Fix | High. The round is mostly behavioural, and the values are the mandate's own words | One story per value where a quote carries one. Where none does, say so |
| Case/Strategist | Live complaint problems on the roadmap | Medium. Hiring managers test live problems, and monthly reporting is in the JD | Clarify before structuring. Think aloud |
| Data-Driven Prober | Asks how the spreadsheet counts, and which assumption you would defend least | Medium. Monthly reporting is in the JD, and your spreadsheet is the artefact they can check | Describe what it holds. Name the weakest assumption before they do |

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| S1 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre" (your message) | Name contact-centre work first: "I've never worked in a contact centre." Then how you would learn it, as a plan: spend time on the contact-centre floor, sit in on complaint calls, ask the team what branch staff tend to misunderstand. Keep to two items. | F4 is the stated gap this question opens. The plan is what the manager tests. |
| S2 | "Your experience is one branch's complaints log. This job owns the process across branches and the contact centre. What would you do to close that gap?" | JD | [grounded] "I handled the branch's formal complaints log" (your message); [grounded] "Never worked in a contact centre" (your message) | Hold: the log is one branch's, and that is the part you have run. Then the plan: which parts of the contact-centre side you would learn first, and from whom. Answer slot: if you set how complaints moved across branches or into the contact centre, say which steps and how you decided. If you did not, say so. Hold through two follow-ups by returning to the log and the plan, not by adding scope. | **Highest-return rehearsal in this pack.** F3 and F4 are the two gaps the JD's headline line presses on, and a manager will open here. |
| S3 | "You trained tellers. What makes you ready to coach supervisors?" | JD | [grounded] "trained new tellers on our escalation script" (your message) | Say what the teller training taught you that carries over, in the quote's terms: a script, and teaching it to people new to it. Then name the gap: coaching supervisors is a different job. Answer slot: if you have coached another supervisor, say what you did. If not, say so. | F8 is a transfer probe. Teaching tellers is adjacent to the coaching line, not the same work. |
| S4 | "You've not presented above regional level. How would you present a complaints trend to our executive team?" | JD | [grounded] "I've never presented to anyone above regional level" (your message) | Plain acknowledgment: "I haven't presented to anyone above regional level." Then the plan: a one-page view of the trend, a dry run with your regional manager, and one question to the team about what they need to decide. A plan, not a past. | F10 is the senior-presentation line. The honest answer is the plan. |
| V1 | "Tell me about a time you had to deliver an unpopular truth to someone above you." | VAL | [generic] | Pick a time you disagreed with someone senior: name the stake, what you said, and how it ended. If none comes to mind, say so plainly, then say how you would raise a hard truth with a manager. | This is the persona's stem, asked as an open prompt. Members First is the value it tests. No candidate claim, so none is made. |
| V2 | "Tell me about a time a complaint came back after you thought it was closed." | VAL | [grounded] "I handled the branch's formal complaints log" (your message) | If one came back, say what happened and what you changed. If none did, say so, then say how you would know a case was truly fixed. Answer slot: do not describe a return you did not handle. | Own the Fix turns on "until it is solved." The log is the nearest evidence, and it does not show a fix that held. |
| V3 | "Tell me about a time a number and a member's outcome pointed in different directions." | VAL | [generic] | Pick a case where a target and a member's need conflicted. Say which way you went, why, and what happened to the member. If none comes to mind, say so, then say how you would weigh a target against a member's outcome. | Neighbours, Not Numbers, and Members First. No candidate claim, so none is made. |
| K1 | "A branch's complaint count doubles in a month. What do you do first?" | CASE | [generic] | Clarify: is it one branch, one product, one week, or a change in how complaints get logged? Objective: the member's outcome and an accurate count. Segment before any fix. Then the approach and the metric you would check first. Think aloud, and challenge one premise: what counted as a complaint. | A live problem from the reporting line. No candidate claim, so the guidance makes none. |
| K2 | "The plan moves branch service into five hubs in 2027. One town loses its branch. What would you need to know about its complaints before changing how they're handled?" | CO | [grounded] "consolidate eight branches into five hubs over 2027" (strategy brief, as quoted in your message) | Name what you would need to know: where that town's members go, which complaints are branch-specific, and what members lose without the counter. Name the people you would talk to. | Ties the case to the company's own plan. The answer carries no claim about your past. |
| P1 | "Walk me through what the monthly complaints spreadsheet holds and who uses it." | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" (your message) | Describe what it holds and who reads it, in your own words. Answer slot: if any figure in it counts or times complaints, say how that figure is counted. If someone else set the counting, say so. If you have a figure from it, name the assumption behind it you would defend least. | Defend-the-number for the spreadsheet your manager will check. F5 and F6 both draw on it. |
| P2 | "If someone checked one number on a monthly complaints report, which would be hardest to defend, and why?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" (your message) | Answer in terms of a figure you have actually used. If you have one, name the weakest assumption behind it, then the part you built. If you do not know how a figure was counted, say that plainly. Do not reconstruct a method. | Tests whether you know your own numbers. The honest branch for a figure you cannot explain is a plain "I don't know." |

**Reverse questions (Round 2)**

- "What would a good first 90 days look like, and what would you need me to have fixed by then?" Why it lands: it shows you want the manager's expectations in writing, and it gives you the answer to the Skeptic's question directly.
- "Which numbers from the monthly report do you read first, and what do they tell you?" Why it lands: it shows you know the reporting is the job's output, and it tells you what the monthly bar really is.

## Round 3: panel of two branch managers (60 min, including a 20-minute case)

**Persona weights.** The recruiter says this panel is the values round, scored against the four values. The panel format blends the top two personas of each member's relationship. Values/Behavioral gets weight 4 (four questions, one for each value). Case/Strategist gets 3, for the 20-minute escalation case. Peer Evaluator gets 2, because branch managers judge whether a new hire adds to or takes work off their plates. Pressure gets 2, because branch managers time-box.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral | Scored against the four published values | High. The recruiter names this round as the values round | One story per value where a quote carries one. Where none does, the honest branch |
| Case/Strategist | The 20-minute complaint escalation | High. The case is confirmed in the recruiter's email | Clarify, then act on the member today, then find the root cause |
| Peer Evaluator | Seams between branch and contact centre, credit, disagreement | Medium. Branch managers test whether you would take work off them | Reciprocity framing: what you bring to their branch |
| Pressure | Time-boxed challenges to your scope | Medium. Branch managers can time-box | Hold, then concede |

### Values cheat sheet

Each published value, a working meaning, and the story you would tell. Where a quoted sentence carries a story, it is cited. Where none does, the cell is a selection scaffold with its honest branch.

| Value (official name) | Working meaning | Mapped story, or scaffold |
|---|---|---|
| Members First, Always | "we decide from the member's side of the counter" | Scaffold. No quote shows a decision made from the member's side. Pick a complaint where the member's need and the process pointed different ways. If none comes to mind, say so plainly, then give the nearest thing your material carries: the complaints log, and how you would handle the next one from the member's side. |
| Plain Words | "if a member needs it explained twice, we wrote it wrong" | Scaffold. The quote "trained new tellers on our escalation script" shows teaching, not rewriting. If you ever reworded the script or a member letter, say what changed and how you knew. If not, say so, and say how you would test whether a wording works: ask someone to explain it back. |
| Neighbours, Not Numbers | "every branch is part of its town" | Scaffold. No quote shows work in a town's context. Pick a decision that changed what a town could get from its branch. If none comes to mind, say so, then say how you would weigh a move to a hub against what a town loses. Do not answer with numbers alone. |
| Own the Fix | "whoever finds the problem keeps hold of it until it is solved" | Mapped to F3 at its own scope: "I handled the branch's formal complaints log." The part about holding on until a fix holds is not in the material. Answer slot: if you followed one complaint until the fix held, say which, what the fix was, and how you knew it held. If the log closed cases on something narrower than a fix, say that. |

### Panel bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V1 | "Tell me about a time you decided something from the member's side of the counter." | VAL | [grounded] "I handled the branch's formal complaints log" (your message) | Pick a complaint where what the member needed and what the process said pointed different ways. Say what the member needed, what you decided, and what happened to the member. If none comes to mind, say so plainly, then give the nearest thing your material carries and how you would handle the next one from the member's side. | Members First is the value the panel scores first. F3 is the only quote in the material that touches complaints. |
| V2 | "Tell me about a time something you wrote or said had to be explained twice. What did you change?" | VAL | [grounded] "trained new tellers on our escalation script" (your message) | The material shows teaching, not rewriting. If you ever reworded the script or a member letter so people understood it first time, say what changed and how you knew. If you did not, say so, and say how you would test a wording. | Plain Words. No quote shows a wording change, so the guidance does not supply one. |
| V3 | "Tell me about a decision that affected one of the towns you served. How did you think about it?" | VAL | [generic] | Pick a decision that changed what a town could get from its branch: hours, a service, a queue. Name the people it touched and what you did for them. If none comes to mind, say so plainly, then describe how you would weigh a change like a branch moving to a hub against what a town loses. | Neighbours, Not Numbers. No candidate claim, so none is made. |
| V4 | "Tell me about a problem you found and kept hold of until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log" (your message) | Map the log to "handled," at its own scope. The "until it was solved" part is not in the material. Answer slot: if you followed one complaint until the fix held, say which, and how you knew it held. If the log closed cases on something narrower than a fix, say that and say how you would test a fix. | Own the Fix. F3 is the nearest evidence, and it does not show a fix held. |
| K1 | The 20-minute escalation case: "A member has complained three times about the same fee, at two branches. The third complaint went to the contact centre, which closed it, saying the fee was refunded. The member says it was not. A branch manager asks what you would do in the next week." | CASE | [generic] | Clarify: is the refund on the account, what does "closed" mean on the contact-centre side, who holds the record? Objective: the member gets the right outcome, and there is no fourth complaint. Segment: is this one member or a process fault, and how many others could it touch? Approach: act on this case first (confirm, put it right, call the member), then find the root cause across the handoff between branch and contact centre. Metrics: repeat complaints and whether the member confirms the fix. Risks: the member escalates outside the bank, and staff close cases quickly to clear a queue. Think aloud. | The panel's 20-minute case is an escalation, and escalation is the core of the JD. The scenario is invented, not a claim about Ashgrove, and it needs no claim about your past. |
| K2 | "A supervisor in one of your branches is stuck on an escalation, and the member wants the branch manager. How do you coach them through it?" | JD | [grounded] "trained new tellers on our escalation script" (your message) | Say what the teller training taught you about the script and about handing a case up. The supervisor is a different level. Answer slot: if you have coached a supervisor through an escalation, say what you did. If not, say so, and say what you would coach first: the handover, what to say to the member, and when to bring the manager in. | F8, the coaching line. Your branch-manager panel will test this against their own supervisors. |
| K3 | "How would you know the complaints process is working across a branch and the contact centre?" | CASE | [generic] | Name three measures: volume, resolution time and repeat complaints. Say what each misses. Add one quality check: a sample of closed cases read against the member's outcome. Say what you would report monthly, and to whom. | F5 and F6, the reporting line, asked as a decision. No candidate claim, so none is made. |
| PE1 | "Branch teams and the contact centre see the same complaint differently. Where's the seam, and what do you do when you disagree with a branch manager?" | JD | [generic] | Propose seam principles before you know the seam: one owner per case, one shared record, and a call to the branch before a case moves. Then the disagreement. Answer slot: if you have disagreed with a peer and held a view, say what you said and how it ended. If not, say so, and say how you would raise it. | Peer Evaluator. The panel will judge whether you add to or take work off their branches. |
| PE2 | "When a complaint is resolved by two teams, how do you handle credit?" | VAL | [generic] | Say who did which step, and name them. If you have shared credit on a resolution, say how. If not, say how you would decide it. | A collegial credit probe. No candidate claim, so none is made. |
| PR1 | "You've run one branch's log. What makes you think you can hold the whole process?" | JD | [grounded] "I handled the branch's formal complaints log" (your message) | Hold: the log is the part you have run, and you say so. Hold through two follow-ups by returning to the log, not by adding scope. Concede: the cross-branch and contact-centre scope is new to you. Say what you would do first. Do not fold on the log. | F3 is the premise this panel presses. Hold, then concede. |
| PR2 | "Sixty seconds: why you over someone who's worked in a contact centre?" | JD | [grounded] "Never worked in a contact centre" (your message) | Start with the stated gap: "I haven't worked in a contact centre." Then the branch work the material does carry, in its own words: the complaints log and the escalation training. Do not argue that you are better. Hold for one follow-up, and concede the contact-centre side plainly. | F4 under time pressure. The honest answer is the stated gap plus what you do carry. |

**Reverse questions (Round 3)**

- "What could someone new in this role do in their first month that would genuinely help your branch?" Why it lands: it is the reciprocity question a peer panel expects, and it shows you think about their load.
- "When a branch and the contact centre disagree about a complaint, who decides, and how would you like that to change?" Why it lands: it names the seam, and it shows you take the fix as your own problem.
- "What does a branch manager do with the monthly complaints numbers?" Why it lands: it links the reporting to Neighbours, Not Numbers, and the answer tells you what the role has to produce.

## Upgrade menu

- Names of the Head of Member Services and the two branch managers: persona weights from their public footprint, and a reverse question tied to their career paths. Interviewer reads are absent until then.
- The full strategy brief, not just the four lines you quoted: checks the grounding brief for stale framings and makes the CO questions more exact.
- Any Ashgrove news since July 2026: a search at L1 would move the CO questions. None was run.
- Where this role sits (hub, branch or head office), and whether it involves travel or relocation: checks whether a location gate row applies. None applies on what the material shows.
- What your complaints spreadsheet holds, and whether it times anything: F5 and F6 move from presentation and discovery to specifics you can state.
- A complaint you followed to a fix that held: V4 and the Own the Fix slot become a grounded story.
- Any work with a digital or app team: F9 and the C4 slot.
- Any coaching of another supervisor: F8, K2 and the S3 slot.
- A `tuesday-dossier.md` from job-underwriter would add verified evidence and prohibited claims. One line, not a prerequisite.
