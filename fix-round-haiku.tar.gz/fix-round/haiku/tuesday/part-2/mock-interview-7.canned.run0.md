Your prep pack is saved as `saltmarsh_live_operations_producer_interview_pack.md` (sent above). I built it for the Outage Hour, the single 60-minute session with the hiring manager that Saltmarsh's careers page describes. That page also says the session includes a values conversation, so the pack covers the three published values.

Three things to focus on:

- **The two-title gap is the main objection.** Your quote is one title and weekly content drops. The JD asks for live events across two titles. Rehearse B1 until you can hold "For two years I ran the weekly content-drop calendar for our main title" through two follow-ups.
- **The tabletop is a live-incident problem.** A1 and A2 cover it. Clarify who is affected, name the players first, and say the trade-off aloud.
- **Don't claim leadership or in-app purchase experience.** You've never led a team and never worked on an IAP game. Acknowledge both plainly if asked.

Research notes: the Project Larkspur announcement (one shared events calendar for two titles from February 2027) and Tobias Wrenfield's GDC 2026 talk are from search results, not fetched pages. Check the Larkspur detail before you quote it in the room. The values and interview pages were fetched.

Would you like me to run a drill as Tobias on B1, the two-title question? I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, or convert the pack to a Word document.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh_live_operations_producer_interview_pack.md -----
# Interview pack: Live Operations Producer, Saltmarsh Games

Interviewer: Tobias Wrenfield, Head of Live Operations (hiring manager for this round)
Round: the Outage Hour, one 60-minute interview: a live-incident tabletop on a simulated outage during a live event, then a values conversation. This is the only session you prepare for.

## How to use this pack

- Personas are how a question will be asked. Types are what it scores.
- Type key: **CASE** live problem from the role · **JD** the job description's own requirement · **EXP** your own past work, probed for what was really yours · **VAL** the published values · **CO** company knowledge.
- Guidance is scaffolding, not a script. Say it in your own words, in 90 to 120 seconds.

## 1. Fit snapshot

Sources for the requirements: the JD you pasted, quoted. Your evidence is quoted from your message, and no CV was supplied.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | transferability | Your material says one title and weekly content drops, not two titles and live events. Keep it at that scope: "For two years I ran the weekly content-drop calendar for our main title." Answer slot: the two-title, live-events scope makes a probe on how a second title would sit beside the first likely. If you planned anything across more than one title, say how; if you did not, say so and describe how you would plan two. |
| F2 | "experience running a content calendar" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | none | The quote reaches the requirement in role terms. Lead with it in your own words: a weekly content drop, one title, two years. Confidence stays medium because nothing has been shown to an interviewer; a redacted calendar would change that. |
| F3 | "3+ years producing live-service games or apps" (JD) | "4 years as an associate producer at a puzzle-game studio" (your message); "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | presentation | Four years and a producer-side role are there, and the weekly drops are the closest live-service work. Your title was associate producer, so do not say "producer" as a title. The bridge rewords only the quotes and adds no practice. |
| F4 | "comfortable with player-retention metrics" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | medium | [grounded] | none | The quote reaches the requirement. Say what you presented, to whom and how often. The material shows presenting the numbers, not computing or defining them. |
| F5 | "own the post-event review and the KPIs it reports" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | low | [inferred] | discovery | Presenting numbers is not owning a review or the KPIs it reports, and the bridge should not be stretched. Answer slot: if you chose which numbers went into those reports, or ran a review after an event, say so in your own words; if not, say so plainly and say what you would put in a post-event review first. |
| F6 | "manage the release checklist with QA" (JD) | "Wrote the release checklist our QA team still uses." (your message) | medium | [grounded] | presentation | The quote reaches the requirement in other terms: you wrote the checklist, and QA still uses it. Reword only that. Do not describe running the release cycle with QA. |
| F7 | "coordinate design, art, engineering and community teams on each update" (JD) | none given | none | [grounded] | discovery | Your material is silent on coordination with those four teams. Answer slot: if you coordinated with any of them on a release or event, name the team and the update; if you did not, say so and describe how you would set that coordination up. |
| F8 | "clear written communication" (JD) | "Wrote the release checklist our QA team still uses." (your message) | medium | [grounded] | presentation | The checklist is a written artifact another team depends on. Point to it only if your old employer allows you to share it, and ask before you do. |

Your own negatives are not in the table as requirements, because the JD does not list them. They sit in the prohibited list and the Skeptic bank: you said "Never led a team" and "never worked on a game with in-app purchases."

## 2. Prohibited claims

Built locally from the fit snapshot. These are the claims you will be tempted to reach for, and none of them will be coached.

| Not coached | Basis | Honest form |
|---|---|---|
| Led a team | Your own negative, "Never led a team" | Plain acknowledgment: "I haven't led a team." No slot. |
| Worked on in-app purchase games or monetization | Your own negative, "never worked on a game with in-app purchases" | Plain acknowledgment: "I haven't worked on a game with in-app purchases." No slot. |
| Owned the post-event review or the KPI definitions | Inflated form of F5 | The quote at its own scope: "Presented the monthly retention numbers to the studio head." The limit is the pack's observation: your material says presenting, not owning. |
| Ran the release process with QA | Inflated form of F6 | The quote at its own scope: "Wrote the release checklist our QA team still uses." |
| Ran live events across two titles | Inflated form of F1 | The quote at its own scope: one title, weekly content drops. |

## 3. Reading the interviewer

Public footprint only.

- **Career pattern:** a GDC 2026 talk page, "Patch Notes Are a Promise", describes Tobias Wrenfield as Head of Live Operations at Saltmarsh Games, previously a QA lead at a console studio. This is from the search result, not a fetched page.
- **Stated view:** the talk argues that a live team is judged by how often its patch notes describe what actually shipped.
- **Implications:**
  1. Expect the values conversation to test "Ship the Patch Not the Promise" against what you have actually shipped.
  2. The release checklist you wrote is the closest thing you have to that argument. Tell it as what the checklist does, in your words.
  3. Do not offer a shared career jump. Their move from QA into live ops is not one you have made, and no quote of yours carries it.
- **Mirror opportunity:** the release checklist and the QA team it serves, which is shared professional territory, not a shared jump.

## 4. Persona table

Relationship prior: hiring manager, which starts at Case/Strategist and Skeptic. The loop source (the Outage Hour page) establishes a single 60-minute session with the hiring manager, so the loop is known and not archetype-based. It also documents a values conversation, so a values-style round is detected.

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist | The live-incident tabletop: a simulated outage during a live event | Highest. The Outage Hour's first half is a tabletop, and it scores structure. Depth 5. | Clarify who is affected and how badly before proposing a fix. Name players first. Say the trade-off aloud. |
| Skeptic | Probes F1, F5, F7 and the two-title scope | High. The JD's headline asks outrun your quotes. Depth 4. | Hold the one quoted position through two follow-ups. Concede specifically, never on the core claim. |
| Values/Behavioral | The three published values, plus a story about a hard truth | High. The values conversation is in the loop source. Depth 4. | Map a story to a value only where a quote carries one. Otherwise use the selection scaffold and its honest branch. |
| Data-Driven Prober | Retention numbers and the release checklist | Medium. Your headline numbers will be counted. Depth 3. | Know what you can say about how each number was counted, and say plainly when you do not know. |
| Conversational | The opener and the "journey" question | Low but live. Casual questions are still scored. Depth 2. | Keep a 90-second arc ready. Treat the closing question as scored. |

Total: 19 questions. Depth follows weight: 5, 4, 4, 3, 2.

## 5. Values / principles cheat sheet

Published values from the Saltmarsh values page (fetched):

| Value | Working meaning (paraphrased) | Your mapped story |
|---|---|---|
| Players Before Plans | When the calendar and the players disagree, the players win. | No quote carries a story here. Selection scaffold, question C1: pick a time a planned drop collided with something that hurt players. If none comes to mind, say so plainly, then give the nearest thing your material carries: the weekly content-drop calendar, and how you would decide. |
| Ship the Patch Not the Promise | Announce what is built, not what is hoped. | "Wrote the release checklist our QA team still uses." Question C2, tell it as what the checklist does. |
| Leave the Build Greener | Every release leaves the codebase and the checklist better than it found them. | No quote shows the checklist improving. Selection scaffold, question C3. If nothing changed after release, say so, then give what the material does carry: the checklist is still in use. |

## 6. Question banks

### A. Case/Strategist (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A live event is ten minutes in and a reward claim fails for part of the player base. Walk me through your first fifteen minutes." | CASE | [grounded] the Outage Hour format (interviewing page) | Clarify scope, who is affected and what they lose. Name the players first, then the calendar. Say what you would tell the studio and what you would tell players, and when. You make no claim about your past here. | This is the tabletop named in the Outage Hour. It presupposes nothing about you. |
| A2 | "A fix is ready, but QA wants another hour. What do you tell the studio, and what do you tell players?" | CASE | [grounded] "Ship the Patch Not the Promise: we announce what is built, not what is hoped." (values page) | State the trade-off aloud. Announce only what is built. Name who decides and by when. | The value sits in the question, so the answer has to show it. |
| A3 | "Tidepool Tactics and Lantern Row are moving to one shared events calendar. How would you run the first quarter?" | CO | [grounded] "Project Larkspur moves Tidepool Tactics and Lantern Row to a season-pass model with one shared events calendar from February 2027, and retires per-title event teams in favour of a single live-ops group." (search result, not fetched); [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | Name the first thing you would put on the shared calendar and why. Use your one-title calendar as the nearest experience, in those words. Do not describe running two titles. | This is company news from the search result. Confirm the detail before you quote it in the room. |
| A4 | "Your posting says two titles. What would you need to see in the first week to know the calendar works?" | JD | [grounded] "Plan and run the live-events calendar for two of our mobile titles" (JD) | Name the signals you would watch: content delivered on time, and what players reported back. Name the assumption you would test first. | Covers the headline JD mandate with a forward question. |
| A5 | "How would you split a live event's calendar between design, art, engineering and community?" | JD | [grounded] "coordinate design, art, engineering and community teams on each update" (JD) | Propose the split and who owns each handoff. Name the decision that would need to move quickly. | F7's gap is answered as a plan, not as a record. |

### B. Skeptic (4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "I don't see live-events planning across two titles in your background. How would you handle that on day one?" | JD | [grounded] "Plan and run the live-events calendar for two of our mobile titles" (JD); "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | This is the most predictable objection, so it gets the deepest rehearsal. Hold: "For two years I ran the weekly content-drop calendar for our main title." Answer slot: if you planned any event beyond content drops, say what and how you decided; if not, say so plainly and describe how you would start on two titles. Hold through two follow-ups by returning to the calendar you ran. | F1's transferability gap. This is the highest-ROI rehearsal in the pack. |
| B2 | "You have never led a team. Why would we give you the calendar for two titles?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." (your message) | Plain acknowledgment: "I haven't led a team." Then point to what you did run: the content calendar and the release checklist, in their own terms. Do not describe leadership you did not have. | The negative is yours, so it can be acknowledged plainly. |
| B3 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "coordinate design, art, engineering and community teams on each update" (JD) | Answer slot: if you have coordinated with any of those four teams on an update, name the team and the update. If you have not, say so and give your ramp plan for that coordination. | F7 has no quote. Silence is not a negative, so the cell asks for your answer, not a confession. |
| B4 | "You presented monthly retention numbers to the studio head. Which of them did you think was least solid?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." (your message) | Weakest-assumption move: if you know how the figures were counted, say how in your own words and name the assumption you would defend least. If you do not know, say so plainly. | Figure-based defend-the-number question. The pack supplies no method. |

### C. Values/Behavioral (4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time the calendar and the players disagreed. Which won?" | VAL | [grounded] "Players Before Plans: when the calendar and the players disagree, the players win." (values page); no candidate quote carries a story | Selection scaffold: pick a time a planned drop collided with something that hurt players, and say what the calendar decision was and what changed for them. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, the weekly content-drop calendar, and how you would decide. | No quote carries this value, so the honest branch is part of the answer. |
| C2 | "Tell me about a release that went out as you had promised it." | VAL | [grounded] "Wrote the release checklist our QA team still uses." (your message) | Tell it as what the checklist does: what it checks, why you wrote it, how QA uses it. Answer slot: if a release went wrong and shaped the checklist, say what and how; if no release did, do not supply one. | The checklist is the only quote that carries this value. |
| C3 | "Tell me about a process you left better for the next release." | VAL | [grounded] "Leave the Build Greener: every release leaves the codebase and the checklist better than it found them." (values page); [grounded] "Wrote the release checklist our QA team still uses." (your message) | Selection scaffold: pick a time you changed a process for a later release. If the checklist changed after release, say what changed. If nothing did, say so, then give what your material carries: the checklist is still in use. | No quote shows the checklist improving, so the scaffold ends in its honest branch. |
| C4 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] persona stem (personas file) | Open prompt. If the retention presentation carried bad news, that is your story: what the number said and who you told. If it did not, say so and give the nearest thing you did. | Presented the retention numbers to the studio head. |

### D. Data-Driven Prober (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how the monthly retention figure was counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head." (your message) | Defend-the-number slot. Say how it was counted in your own words. Name the weakest assumption before they do. If you do not know how it was counted, say so. | Retention is the JD's metric, and the prober will go there first. |
| D2 | "What does the release checklist check, and what has it caught, if you know?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." (your message) | Answer slot: say what it checks, in your words. Only say what it caught if you have the record. | Tests whether the checklist is yours and how well you know it. |
| D3 | "Which retention lever would you test first on the next title?" | JD | [grounded] "comfortable with player-retention metrics" (JD) | Name the metric, the assumption behind it, and how you would read the result. Make no claim about a lever you have tested. | The JD names retention; this asks for a method, not a record. |

### E. Conversational (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | JD | [grounded] "4 years as an associate producer at a puzzle-game studio" (your message) | A 90-second arc: the puzzle studio and your title, the calendar for the main title, the checklist QA still uses, the retention presentations. Add nothing. | A casual opener is scored. |
| E2 | "What are you actually playing at the moment?" | CO | [generic] | Name one live game you play and what its update rhythm looks like to you. Do not claim expertise in these titles. | Tests whether you know the category. |

### Requirement coverage

| JD requirement | Questions |
|---|---|
| Plan and run the live-events calendar for two of our mobile titles | A3, A4, B1 |
| Coordinate design, art, engineering and community teams on each update | A5, B3 |
| Own the post-event review and the KPIs it reports | B4, D1 |
| Manage the release checklist with QA | C2, D2 |
| 3+ years producing live-service games or apps | E1, and F3 in the snapshot; no dedicated question, because E1 covers the arc and the snapshot covers the years |
| Experience running a content calendar | A3, B1 |
| Comfortable with player-retention metrics | D1, D3 |
| Clear written communication | D2, and F8 in the snapshot |

## 7. Reverse questions

Each one has a reason it lands.

1. "How do you check that patch notes match what shipped?" Lands because it proves you read the values page.
2. "Your talk argues that a live team is judged by how often its patch notes describe what shipped. You came up through QA before live ops. What did that change about how you want a producer to work with QA?" Lands because it ties to their public path and turns the interview into a peer conversation.
3. "With Project Larkspur moving two titles to one shared calendar, what does a producer own on that calendar that the title team used to?" Lands because it shows you read the company's own news.
4. "What would make the first ninety days a success for whoever takes this role?" Lands because it asks for the scoring sheet.
5. "How is post-event review run today, and who reads the KPI report?" Lands because it tests whether the review is owned, which F5 has to answer.

## 8. Delivery notes

No working-style assessment was provided, so there is no delivery-coaching section.

## 9. Sources

Research tier: L1 — searches 4 of 6, fetches 2 of 2; user links read 0

Provided documents: the JD and your background, both in your message. No CV was supplied.

Searches and fetches:

- "Saltmarsh Games values" → saltmarshgames.com/values (fetched)
- "Saltmarsh Games interview process live operations producer" → saltmarshgames.com/careers/interviewing (fetched)
- "Tobias Wrenfield Saltmarsh Games Head of Live Operations" → talks.gdconf.example/2026/patch-notes-are-a-promise (search result only, not fetched)
- "Saltmarsh Games live service strategy news 2026" → saltmarshgames.com/news/project-larkspur (search result only, not fetched)

Target accounting:

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. saltmarsh values | yes | Values cheat sheet, section 5: three values by name from the fetched page |
| 2. saltmarsh interview process | yes | Loop established: one 60-minute hiring-manager Outage Hour. Persona weights, section 4 |
| 3. saltmarsh strategy / recent news | yes | Search returned the Project Larkspur announcement (September 2026). Moved question A3 and reverse question 3. Search result only, not fetched |
| 4. Tobias Wrenfield Saltmarsh Games | yes | Search returned a GDC 2026 talk page. Moved the interviewer read, section 3, and reverse question 2. Search result only, not fetched |
| 5. representative JD | skipped | The JD you pasted fixes the fit snapshot and the JD-tagged questions |

## 10. Upgrade menu

- A redacted content calendar or the release checklist, if your old employer permits sharing → F2 and F8 become inspectable proof and the medium bands can rise
- Whether you ever coordinated with design, art, engineering or community on an update → F7 and B3 change from answer slots to stories
- Whether any post-event review or KPI report was yours → F5 and B1 change
- Whether the puzzle game had ongoing updates after launch → F3 gets its live-service evidence directly
- The Outage Hour's format from the recruiter: whether the tabletop uses a fixed scenario or a live incident → A1 and A2 get their real structure
- The full Project Larkspur announcement, fetched → A3 and reverse question 3 carry the confirmed detail
- A deeper research pass, up to six more searches and two more fetches, several more minutes → Tobias Wrenfield's talks and writing, and the company's strategy brief
