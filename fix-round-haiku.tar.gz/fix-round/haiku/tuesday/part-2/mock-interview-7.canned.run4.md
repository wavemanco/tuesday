Your prep pack is saved as `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-tuesday-part-2-rooms-case-7-canned-836c076d/79905f08-604a-4da5-8639-ca8325548dae/scratchpad/saltmarsh_live-operations-producer_interview_pack.md`.

Three things shape it:

- **The round is not a general fit interview.** Saltmarsh's careers page says the 60 minutes are an "Outage Hour": a live-incident tabletop on a simulated outage during a live event, then a values conversation. So the case and values questions carry the most weight. Your material has no incident experience, so the tabletop is the place to rehearse most.
- **Saltmarsh has a strategy change you should know about.** A September 2026 announcement, "Project Larkspur," moves the two titles to one shared events calendar under a single live-ops group from February 2027. That fits the JD's "two titles" line, and it's a good reverse question. I only saw the search snippet, not the full page.
- **Your highest-risk answer is KPI ownership.** The JD says "own the post-event review and the KPIs it reports." Your material shows you presented retention numbers, which is not the same. Rehearse S2 until you can say plainly what you defined and what you only presented.

Two of the sources are weaker than the rest. Tobias's QA background and the GDC talk come from a search snippet, so check them before you mention them in the room. The talk's argument that patch notes should match what shipped is worth reading before Friday.

One question, which the pack needs to finish its gate row: was the puzzle game's content calendar live-service, meaning ongoing drops with no fixed end? If yes, F6 becomes a strong quote. If no, the "3+ years live-service" requirement is your biggest gap, and I'd rework the opening.

Other offers, one line each:
- **Drill:** I can play the Outage Hour tabletop with you, or the Skeptic on S2, and give feedback against each question's own guidance.
- **Dossier:** I can save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions.
- **Word:** I can convert the pack to .docx if you want it.

Is the Friday round the same person as the hiring manager on the posting, or someone else in the loop?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh_live-operations-producer_interview_pack.md -----
# Interview pack: Live Operations Producer, Saltmarsh Games

**Round:** Outage Hour, 60 minutes, with the hiring manager, Tobias Wrenfield (Head of Live Operations). Format per the company's interviewing page: a live-incident tabletop on a simulated outage during a live event, then a values conversation. No take-home.
**Changed from a generic plan:** the round is a tabletop plus a values conversation, not a general fit interview, so the case and values banks carry the most weight.

## How to use

- **Personas** describe how a question arrives. **Types** describe what is being scored: VAL (values), EXP (your past work), JD (role requirements), CO (company knowledge), CASE (live problem).
- Guidance is scaffolding, not a script. Each guidance cell is meant to be spoken in 90 to 120 seconds, in your own words.

## Fit snapshot

Sources: "your message" = what you told me in this conversation. "JD" = the job description you pasted. "careers page" = saltmarshgames.com/careers/interviewing (search snippet, see Sources).

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | transferability | Your material says one title and weekly content drops, not two titles or live events. Words: "For two years I ran the weekly content-drop calendar for our main title." Answer slot: if you planned for a second title or for events beyond weekly drops, say which and how; if not, say so and say how you would carry the process across. |
| F2 | "coordinate design, art, engineering and community teams on each update" (JD) | none given | none given | [grounded] | discovery | Your material does not show who you had to align for a drop. Answer slot: describe one drop where you got design, engineering or QA to a shared date, in your own words. If the coordination was done by someone else, say so. |
| F3 | "manage the release checklist with QA" (JD) | "Wrote the release checklist our QA team still uses." (your message) | high | [grounded] | presentation | Your sentence already reaches the requirement in other terms. Words: "I wrote the release checklist our QA team still uses." Do not add how the QA team works with it day to day unless you did that work. |
| F4 | "own the post-event review and the KPIs it reports" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | medium | [grounded] | transferability | Presenting numbers is not owning the KPIs or the post-event review. Words: "I presented the monthly retention numbers to the studio head." Answer slot: if you defined any of the metrics, say which; if you presented numbers someone else set, say so; if you have not run a post-event review, say so. |
| F5 | "comfortable with player-retention metrics" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | medium | [grounded] | presentation | Your sentence reaches the requirement: you have worked with retention data at studio-head level. Words: as F4. |
| F6 | "3+ years producing live-service games or apps" (JD) | "4 years as an associate producer at a puzzle-game studio." (your message) | medium | [grounded] | hard_gate | Your material shows four years in games but does not establish that the work was live-service. It is a gate, so it is surfaced, not bridged. Asked in the message that presents this pack (SKILL Step 1 item d). |
| F7 | "experience running a content calendar" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | high | [grounded] | none | The quote reaches the requirement directly. Lead with it. |
| F8 | "clear written communication" (JD) | "Wrote the release checklist our QA team still uses." (your message) | medium | [grounded] | presentation | A checklist that a team still uses is written evidence, but your material does not show other writing. Words: as F3. Expect a probe; have one example of a written document you owned, ready. |
| F9 | Run a live-incident tabletop during a live event (careers page, Outage Hour) | none given | none given | [grounded] | discovery | No incident or outage experience appears in your material. This is the round's central exercise. Answer slot: if you have handled a live incident, say what happened and what was yours; if not, say so and walk through how you would structure the response (see Case bank). |
| F10 | Team leadership (not a JD line; your stated gap) | "Never led a team" (your message) | none | [grounded] | capability | A gap you stated. Words: "I haven't led a team." Then how you coordinate without line authority, as a plan or as a described past, never as an added claim. |
| F11 | Games with in-app purchases (not a JD line; your stated gap) | "never worked on a game with in-app purchases" (your message) | none | [grounded] | capability | A gap you stated. Words: "I haven't worked on a game with in-app purchases." Then what you would learn first. The JD does not list this, so do not volunteer it as a requirement. |

## The prohibited list

Claims this pack will not coach, with the basis for each.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the live-events calendar for two titles | Inflated form of F1 | F1's quote at its own scope: one title, weekly content drops. The limit is the pack's observation: your material says one title. |
| Owned the post-event review and KPIs | Inflated form of F4 | F4's quote at its own scope. |
| Managed the release checklist with QA | Inflated form of F3 | "I wrote the release checklist our QA team still uses." |
| Led a team | Negative you stated, F10 | "I haven't led a team." No slot about having led one. |
| Built in-app-purchase or monetisation experience | Negative you stated, F11 | "I haven't worked on a game with in-app purchases." |
| Led an incident response | Silence in F9, not a stated negative | Not listed. F9 is an answer slot only. |

## Reading the interviewer

Public footprint only, from a search for the name and the company.

- **Career pattern (public):** Head of Live Operations at Saltmarsh Games; previously a QA lead at a console studio (from the talk's bio, a search snippet, not a fetched profile).
- **Published talk:** "Patch Notes Are a Promise" (GDC 2026). Argument: a live team is judged by how often its patch notes describe what actually shipped.
- **Practical implications:**
  1. Expect probes on whether what gets announced is what was built. A release checklist you wrote and QA still uses is the nearest thing in your material to that concern (F3).
  2. Do not claim a QA background. You have a QA-facing artifact, not QA experience.
  3. Keep answers about what shipped, and when, to what you can name. This interviewer's own talk makes that the test.
- **Mirror opportunity:** the release checklist (F3) is a shared-process touchpoint with the QA side of the talk's argument. It is a professional overlap, not a shared jump, and only F3's quote supports it.

## Persona table

| Persona | How it shows up in this round | Weight | Reasoning | Counter-strategy |
|---|---|---|---|---|
| Values / Behavioral | The values conversation, the second half of the hour; company values by name | Top | The careers page makes the values conversation a fixed part of the round | Map each value to a story only where your quotes carry one; otherwise a selection scaffold ending in the honest branch |
| Case / Strategist | The outage tabletop, the first half; live problems from the role | Top | The careers page names a live-incident tabletop | Clarify, then contain, then communicate, then decide; think aloud |
| Skeptic | "Why you, with no team lead and no IAP games?" | Mid | Your stated gaps (F10, F11) and the JD requirements with no quote (F2, F9) | Rehearse the objection until it is boring; say the gap plainly; then the ramp plan |
| Data-Driven Prober | Follow-ups on retention numbers and KPIs | Mid | The JD makes KPIs part of the role; the interviewer's talk stresses checking what was announced | Say what you did and did not define; no figure you cannot defend |
| Pressure / Stress | Time-boxed challenge on a stated gap | Low | The round is structured; the careers page does not mention stress | Hold a position through two follow-ups; concede specifically |
| Conversational / Rapport | Opening and closing small talk | Low | Hiring-manager round | Pre-scripted 90-second arc from your quotes |
| Peer Evaluator | Not weighted | None | The interviewer is the hiring manager, not a peer | n/a |

## Question banks

### Values / Behavioral (top weight, 4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V1 | "When the calendar and the players disagree, which one gives way? Tell me about a time it came up." | VAL | [inferred] no quote carries a story; the raising source is the company value "Players Before Plans" (values page) | Selection scaffold: pick a time a date or drop had to change because of player feedback. Answer slot: if you have one, tell it in your own words, with what you did and what you did not decide. If none comes to mind, say so plainly, then give the nearest thing your material carries: the content-drop calendar (F7). | Values round; the value is named on the company's page. No quote carries a story here, so this is a scaffold |
| V2 | "Tell me about a time you announced something before it was ready. What happened?" | VAL | [inferred] raising source is the company value "Ship the Patch Not the Promise" (values page) | Selection scaffold: a time you described something as done, or promised a date, and the result. Answer slot: if you did this, say what you said and what happened; if you did not, say so and tell the nearest case where you kept an announcement to what was built. | The value is named on the page; your material does not carry a story |
| V3 | "Tell me about a time you left a process better than you found it." | VAL | [grounded] "Wrote the release checklist our QA team still uses." (your message) | Story-mapped on F3: the beats the quote states are that you wrote the checklist, and that QA still uses it. Tell those in your own words. Answer slot: what was in the process before, and what you changed, in your own words. If the checklist was a team effort, say so. | Maps the company value "Leave the Build Greener" to F3's sentence |
| V4 | "Tell me about a time you had to say something unpopular to someone senior." | VAL | [inferred] open prompt; no raising source names it, so this is a persona stem | Selection scaffold: a time you disagreed with someone senior about a date, a metric or a decision, and held your position with evidence. If none comes to mind, say so plainly, then describe how you would handle it. | Personas stem: Values interviewers look for unpopular truths; your material does not carry one |

### Case / Strategist (top weight, 4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | Live-incident tabletop: "A live event is running. Players report a reward granting double what was intended, and the fix is not ready. What do you do in the first 15 minutes?" | CASE | [generic] | Structure: clarify scope (how many players, which rewards, is the bug still live). Contain: decide whether to pause the reward or the event. Communicate: what you tell players now, and what you do not promise. Decide: rollback versus hotfix, and who signs off. Record: what goes in the post-event review. Say the framework aloud first. | F9's gap, the central exercise. The question is a generic pattern for the tabletop, not a claim about your past. Scenario details are a stand-in; the real tabletop may differ |
| C2 | "A drop is due in 48 hours and the build is not ready. What do you do?" | CASE | [generic] | Clarify what is not ready and what players were told. Options: move the drop, ship a reduced drop, or ship on time and say what was cut. Name the tradeoff, then the one you would take and why. | Tests the same value as V2 in a live setting |
| C3 | "How would you plan the live-events calendar for two titles that share one events team?" | JD | [generic] | Clarify what the two titles share and where they differ. Propose one calendar owner, a shared checklist, and how the two titles' drops are sequenced. Name the first thing you would check. | JD line on two titles (F1) with no claim about your past; the premise is the JD's and the answer slot is in F1 |
| C4 | "What do you measure in the first 72 hours after an event, and what do you do with the answer?" | JD | [generic] | Name the measures you would look at first, the owner for each, and what would make you change the next event. Answer slot: say which of these you have measured yourself, in your own words. | JD line "own the post-event review and the KPIs it reports" (F4). Generic method; the answer slot keeps the claim where your material puts it |

### Skeptic (mid weight, 3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| S1 | "You haven't led a team. How do you coordinate design, art, engineering and community without that?" | JD | [grounded] "Never led a team" (your message) | Plain acknowledgment: "I haven't led a team." Then the coordination you did, in your own words, from F2's answer slot. If you have not coordinated across functions, say what you would do first, as a plan. | F10 and F2: your stated gap, asked as the interviewer will ask it |
| S2 | "You presented retention numbers. Did you define the KPIs, or did you present what someone else set?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." (your message) | Answer slot: if you defined any metric, say which and how you decided. If you presented numbers someone else set, say so plainly. Do not claim ownership of the KPIs. | F4. This is the highest-ROI rehearsal: the JD asks you to own KPIs, and your material shows presenting them. The objection is likely in some form |
| S3 | "You haven't worked on a game with in-app purchases. What would you need to learn first?" | JD | [grounded] "never worked on a game with in-app purchases" (your message) | Plain acknowledgment: "I haven't worked on a game with in-app purchases." Then what you would learn first and from whom. No claim of monetisation experience. | F11. Keep it short. The JD does not list this |

### Prober (mid weight, 3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "How do you know a patch note describes what actually shipped?" | JD | [generic] | Name the check: a checklist item for it, who verifies, and what you do when the note and the build disagree. Say the check you would run, not one you have run unless you have. | The interviewer's talk theme; a generic question |
| P2 | "Which retention number have you tracked, and how was it counted?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." (your message) | Answer slot: if you know how the number was counted, say so in your own words; if you did not count it, say so plainly. Name the assumption you would defend least, if you know one. | F5. Defend-the-number slot; no figure was given, so the answer is a method, not a number |
| P3 | "Show me how you would check a KPI after an event before you report it." | CASE | [generic] | Name the source data, the cut you would check first, and the one assumption to test. Say what you would not report until it is checked. | F4 pressure through method, not past work |

### Pressure / Stress (low weight, 2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| PR1 | "Sixty seconds: why should we hire someone who has never led a team, for this role?" | JD | [grounded] "Never led a team" (your message) | Pause. Restate: "You're asking why I'm the right fit without team leadership." Hold: say what you have run end to end (F1, F3), then concede specifically: "I haven't led a team." Hold through two follow-ups; do not fold on the core claim. | F10 under time pressure |
| PR2 | "That presentation, how much of the retention work was actually you?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." (your message) | Answer slot: say what you did (presented, and anything you analysed yourself), and what you did not do. | F5 attribution under pressure |

### Conversational / Rapport (low weight, 2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R1 | "So, walk me through your path into live games." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." and "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | 90-second arc: the studio and the role, then the content-drop calendar, then the checklist QA uses. Say the arc in your own words. | Opening question; delivery, not new content |
| R2 | "What's the part of live ops you find hardest?" | CO | [generic] | Name one real difficulty you have met (F1 or F3), and what you did about it. Do not invent difficulty. | Rapport question scored for honesty |

## Values cheat sheet

Source: careers and values pages (fetched). Values by official name:

| Value | Working meaning (paraphrase) | Your story | Honest branch |
|---|---|---|---|
| Players Before Plans | When the calendar and the players disagree, the players win | No quoted sentence carries a story | V1 scaffold; the nearest thing is the content-drop calendar (F7) |
| Ship the Patch Not the Promise | Announce what is built, not what is hoped | No quoted sentence carries a story | V2 scaffold |
| Leave the Build Greener | Every release leaves the codebase and checklist better | F3: "Wrote the release checklist our QA team still uses." | V3 story-mapped on F3 |

## Reverse questions

Each one, with why it lands.

1. "Your GDC 2026 talk argued that patch notes are a promise. What changed in how the team checks notes against builds after that?" Why it lands: it shows you read the talk, and it turns the interview into a conversation about the work.
2. "What did the last outage handled well look like?" Why it lands: it asks for a standard, and it shows you think about incidents as a process.
3. "What would the first 30 days look like, and what would you want me to have done by day 30?" Why it lands: it signals you plan to be measured against outcomes.
4. "Which live event is the team most worried about in the next quarter?" Why it lands: it asks about real pressure, and you can use the answer in the next conversation.
5. "How does a live event get delayed, and who can say no to it?" Why it lands: it asks where decision rights sit, which is the question a live-ops producer needs answered.

## Sources

Provided documents: your message and the JD you pasted.

Research tier: L1, searches 4 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | yes | Values cheat sheet: three values by name, from the fetched values page (saltmarshgames.com/values) |
| 2. `Saltmarsh Games interview process live operations producer` | yes | Round structure: the Outage Hour, from the fetched careers page (saltmarshgames.com/careers/interviewing). This establishes the loop: one 60-minute session, with the hiring manager, a tabletop then values. Values round detected |
| 3. `Saltmarsh Games strategy news 2026` | yes | CO bank (R2 context) and the two titles and shared calendar in F1 and C3. Search snippet from saltmarshgames.com/news/project-larkspur (September 2026; not fetched, so details are from the snippet) |
| 4. `Tobias Wrenfield Saltmarsh Games Head of Live Operations` | yes | Interviewer read: the GDC 2026 talk and career note. Search snippet only, from talks.gdconf.example; not fetched and not verified against a live page |
| 5. representative JD | skipped | The JD you supplied fixes the fit snapshot and JD-tagged questions |

Calls sent, with results:

- `Saltmarsh Games values`: one result, the values page
- `Saltmarsh Games interview process live operations producer`: one result, the careers page
- `Tobias Wrenfield Saltmarsh Games Head of Live Operations`: one result, the GDC talk
- `Saltmarsh Games strategy news 2026`: one result, Project Larkspur announcement
- Fetches: saltmarshgames.com/careers/interviewing, saltmarshgames.com/values

Not established: the talk's bio and the interviewer's QA background come from a search snippet. Verify before relying on them in the room.

## Upgrade menu

- A JD line on monetisation or live-service products, if any → sharpens F6 and F11 with a quote instead of a gap
- Your own sentence about the live-service nature of the puzzle game's content calendar → resolves the F6 gate
- A description of a live incident you handled, or one you watched → converts F9 from an answer slot to a story
- The post-event review format you used, if any → gives F4 a quote to stand on
- A deeper research pass (L2: up to 6 more searches and 2 more fetches, several minutes) on Project Larkspur and the interviewer's other talks → sharpens C3 and the reverse questions
