Your prep pack is saved as `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-tuesday-part-2-rooms-case-8-canned-8204980b/77fbec95-1bb6-46cd-933b-51b8c2fe911b/scratchpad/ashgrove-credit-union_member-experience-lead_interview_pack.md`. I built it as a loop across the three rounds, with a shared fit snapshot and a mini-pack for each round.

Your CV wasn't provided, so the only quotes about your history are four sentences from your message. Most answers are slots you fill in your own words.

The highest-return prep is question B5, the objection that you've never worked in a contact centre and never presented above regional level. Both are gaps you stated, so the pack gives you plain words for them. The rehearsal is to hold on the complaints log and the spreadsheet, then concede both gaps specifically and move to your plan. The same objection returns as C7 in the panel round.

Two things to know before you use it:
- The strategy figures are from your summary of the brief. Check them against the brief before you quote them in the room.
- The panel's 20-minute case is an invented escalation scenario, and its guidance makes no claim about your past.

Would you like a drill on B5, the Skeptic persona? I can also save a `tuesday-dossier.md` that records the gaps this prep exposed, and I can convert the pack to Word if you want it.

Is your current branch one of the eight moving into hubs? If so, B7 and B8 can use your own branch as the example.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove-credit-union_member-experience-lead_interview_pack.md -----
# Interview prep pack: Member Experience Lead, Ashgrove Credit Union

**Role:** Member Experience Lead, Ashgrove Credit Union (member-owned, about 900 staff)
**Loop (three rounds, 20 November 2026):**
- Round 1: recruiter screen, 30 minutes. Name not given.
- Round 2: Head of Member Services, 45 minutes, mostly behavioural. This is your future manager. Name not given.
- Round 3: panel of two branch managers, 60 minutes, including a 20-minute complaint-escalation case. The panel scores you against the four values. Names not given.

**Built from:** the job description, the four values (copied 11 November 2026), the recruiter's email, your summary of the July 2026 strategy brief, and your background. No web searches were run. The interviewers' public footprints are not in the pack because no names were given.

**Limit to know first:** your CV was not provided. Every sentence in quotation marks about your history is one you wrote to me, and there are only four of them. Most answers below are therefore slots you fill in your own words, not stories the pack has already written for you.

---

## How to use this pack

- **Personas** describe how a question arrives (friendly, sceptical, behavioural, peer, pressure). **Types** describe what is being scored:
  - **VAL**: values and behaviour
  - **EXP**: your own work, asked in depth
  - **JD**: a requirement from the job description
  - **CO**: the company's strategy
  - **CASE**: a live problem
- **Guidance is scaffolding, not a script.** Say it in your own words.
- **Answer slots** end with two branches: "if you did this, say how; if not, say so plainly." Give whichever branch is true. Never fill a slot with a practice you did not do.
- **Plain acknowledgments** are the two gaps you have stated (F7, F8). The pack gives you the words for them because you said them first. Say them once, plainly, then move to your plan.

---

## 1. Fit snapshot (shared across all three rounds)

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches and the contact centre" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | transferability | Your material says the branch's log, not the end-to-end process across branches. Words: "I handled the branch's formal complaints log." Answer slot: if you set how a complaint moved from intake to closure, or decided when one escalated, say which and how, in your own words. If you did not, say so and stay with the log. |
| F2 | "report monthly on complaint volumes and resolution times" (JD) | "I built the monthly complaints spreadsheet our regional manager uses." (your message) | medium | [grounded] | presentation | The sentence reaches monthly reporting, but not which measures it holds. Words: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: say what it counted. If it tracked resolution times, say how they were measured. If it did not, say so and say what you would add. |
| F3 | "comfortable with Excel reporting" (JD) | "I built the monthly complaints spreadsheet our regional manager uses." (your message) | medium | [grounded] | discovery | The sentence does not name the tool. Answer slot: say what you built it in and what you did in it. If it was not Excel, say what it was. |
| F4 | "coach branch supervisors on escalations" (JD) | "trained new tellers on our escalation script" (your message) | low | [inferred] | transferability | Training tellers is adjacent to coaching supervisors, not the same thing. Words: "I trained new tellers on our escalation script." Answer slot: if you coached a supervisor or a teller on an escalation decision, say what you did and what changed. If not, say so, and say how you would coach supervisors on escalations. |
| F5 | "work with digital teams on self-service journeys" (JD) | none given | none | [grounded] | discovery | Your material says nothing about digital or self-service work. Answer slot: if you have worked on a self-service change with a digital or product team, say what it was. If not, say so and say how you would learn it. |
| F6 | "experience handling regulated complaints" (JD) | "I handled the branch's formal complaints log" (your message) | low | [inferred] | discovery | "Formal" is adjacent to regulated, but your material does not show a regulatory timescale or external review. Words: "I handled the branch's formal complaints log." Answer slot: if the log ran to a timescale or external review, say which and how you tracked it. If not, say so, and say what "formal" meant on your branch. |
| F7 | "confident presenting to senior leaders" (JD) | "I've never presented to anyone above regional level." (your message) | none | [grounded] | capability | A gap you have stated, and the pack cannot close it. Words: "I haven't presented to anyone above regional level." Then how you would prepare to present to senior leaders, said as a plan, never as past experience. Do not add anything to make the gap sound smaller. |
| F8 | "across branches and the contact centre" (JD) | "Never worked in a contact centre" (your message) | none | [grounded] | capability | A gap you have stated. Words: "I haven't worked in a contact centre." Then how you would learn the contact-centre side of complaints, said as a plan. |
| F9 | "4+ years in financial-services customer operations" (JD) | "6 years in retail banking, the last 3 as a branch supervisor." (your message) | medium | [grounded] | none | The quote already reaches the requirement. Lead with the six years and the three as a branch supervisor. Do not add customer-operations years you have not stated. |

**Gate rows:** none. Nothing in the job description or your material is a term you do or do not meet, such as a location, licence or schedule. If the role carries one, see the upgrade menu.

---

## 2. Grounding brief (shared)

Learn these terms. Check the exact figures against the brief itself before you quote them in the room. The pack has only your summary.

- **Digital:** the plan moves 40% of member service to digital channels by 2028.
- **Hubs:** eight branches consolidate into five hubs during 2027.
- **Small business:** a small-business lending product launches in Q1 2027.
- **Competition:** the main pressure is app-only banks.
- **Values, as published:**
  - Members First, Always: "we decide from the member's side of the counter."
  - Plain Words: "if a member needs it explained twice, we wrote it wrong."
  - Neighbours, Not Numbers: "every branch is part of its town."
  - Own the Fix: "whoever finds the problem keeps hold of it until it is solved."

No stale framings were found in what you provided.

---

## 3. Round 1: recruiter screen (30 minutes)

### Persona weights

| Persona | Weight | Reasoning | How it shows up | Counter-strategy |
|---|---|---|---|---|
| Conversational / rapport | 4 (top) | Recruiter screens are friendly and still scored, on logistics, motivation and the job check | A1 to A4 | A 90-second arc for your background. Treat casual questions as scored. |
| Skeptic | 3 | Why this move, and the two stated gaps | A5, A6, A8 | Say the two gaps once, plainly, then your plan |
| Data-driven prober | 1 | The spreadsheet is the only figure-adjacent item, and no figure is in your material | A7 | Say what the spreadsheet holds. Do not name a number you do not have. |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through your background in two minutes." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." (your message); "I handled the branch's formal complaints log and trained new tellers on our escalation script." (your message) | Roughly 90 seconds. Six years in retail banking, the last three as a branch supervisor. Then the complaints log. Then the tellers' escalation training. Stop there and let A2 carry the motivation. | Opener. F9 and F1 are the material. The recruiter scores brevity as well as content. |
| A2 | "Why this role?" | JD | [generic] | Answer in your own words, from what you want the job to do. The pack has no basis for your reason, so the answer has to come from you. Do not rest it on the contact centre or the hubs unless you can say what draws you to them. | Screeners check that motivation matches the job. The pack cannot write your reason for you. |
| A3 | "Tell me about the formal complaints work on your branch." | EXP, JD | [grounded] "I handled the branch's formal complaints log" (your message) | Say what the log was and what you did with each complaint, in those words. Answer slot: if the log ran to a regulatory timescale or an external review, say which and how you tracked it. If not, say so and say what "formal" meant on your branch. | F1 and F6. The regulated-complaints requirement is likely to come up here. |
| A4 | "You have six years in retail banking. Which part of that was customer operations?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." (your message) | Say which part of the six years was customer-facing, in your own words. The material places the last three as branch supervisor. Do not stretch that to cover any other role. | F9. The JD asks for four years of customer operations, which the material meets, so the answer should be short and specific. |
| A5 | "Tell me about a complaint you owned from start to finish." | JD | [grounded] "I handled the branch's formal complaints log" (your message) | Open prompt. Story map from the log: the log you handled. Answer slot: if you changed something because of a complaint, say what and who decided. If a complaint was handed on before the end, say where and why. If you cannot name one, say so and give the nearest log case. | F1. Raised by the JD's "end to end" wording. |
| A6 | "Which of this job's requirements would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." (your message) | Name the two in your own words: "I haven't worked in a contact centre," and "I haven't presented to anyone above regional level." Then your plan for the first month on each. Do not add a partial claim such as "I've had some exposure." | F7 and F8, the two plain acknowledgments. |
| A7 | "What does the monthly complaints spreadsheet hold, and how is it counted?" | EXP, JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." (your message) | Say what it holds, in your words. If it has volumes, say how a complaint was counted. If it has resolution times, say how the time was measured and which assumption you would defend least. If it holds neither, say so and say what you would add. No figure is in your material, so do not name one. | F2 and F3. The defend-the-number slots only apply once a figure exists. |
| A8 | "Why leave a branch after six years in retail banking?" | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." (your message) | Your reason, in your own words. Name the work you want more of. Do not criticise the branch or the bank. | Motivation probe. The material gives no reason, so the answer must come from you. |

---

## 4. Round 2: Head of Member Services (45 minutes, your future manager)

### Persona weights

| Persona | Weight | Reasoning | How it shows up | Counter-strategy |
|---|---|---|---|---|
| Values / behavioural | 4 (top) | The recruiter's email says this round is mostly behavioural | B1 to B4 | Tell stories from your log. Hold only what the quotes carry. Give an honest branch where none fits. |
| Skeptic | 3 | Your two stated gaps are the manager's to carry, and the manager will test whether you know them | B5 to B7 | Hold, then concede specifically (B5). Plans for gaps, not past claims. |
| Case / strategist | 2 | The hub plan and the digital target come from the brief | B8, B9 | Clarify, then objective, segment, approach, metrics, risks |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time a complaint had to go beyond the branch." | VAL, JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." (your message) | Open prompt. Story map from the material: the log you handled, and the escalation script you trained tellers on. Answer slot: if a complaint went beyond the branch and you handled that step, say what you did and who else was involved. If the branch never sent one beyond itself, say so and tell the nearest escalation you did handle. | The JD's "across branches and the contact centre" is the raising source. F1. |
| B2 | "Tell me about a complaint you kept hold of until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log" (your message) | Name a case from the log. Say what you did at each step you handled. Answer slot: did the case stay yours until it closed? If yes, say what closed it. If it was handed on, say to whom and why. If you cannot name one, say so and give the nearest log case. | Own the Fix is a published value, so the manager will probe it. F1. |
| B3 | "When have you made a decision from the member's side of the counter?" | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." (your message) | Pick a decision where the member's outcome came first. If none comes to mind, say so plainly, then give the nearest thing the material carries: a complaint from the log, and what you did with it, in those words. | Members First. The honest branch is the answer. |
| B4 | "Tell me about a time a member did not follow a decision the first time you explained it." | VAL | [grounded] "trained new tellers on our escalation script" (your message) | Story map: the script you trained tellers on. Answer slot: if you changed the script's wording because members did not follow it, say what you changed and why. If you did not, say so, and say how you would check that it works for members. | Plain Words is published as "if a member needs it explained twice, we wrote it wrong." |
| B5 | "You've never worked in a contact centre, and never presented above regional level. Why should we hire you for this job?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." (your message) | **Hold, then concede.** Hold for two follow-ups on the work the material does carry: the complaints log you handled, and the monthly spreadsheet your regional manager uses. Then concede specifically: "I haven't worked in a contact centre. I haven't presented above regional level." Then give the plan. The limit: do not claim contact-centre knowledge, and do not say you are confident presenting to senior leaders, because nothing in your material says so. | The highest-ROI prep in this pack. The objection is the JD's two requirements, and both are stated gaps, so the concession is sourced. Holding on the log is allowed; holding on a senior-presentation claim is not. |
| B6 | "What would you do in your first 90 days about the contact-centre side of complaints?" | JD | [grounded] "Never worked in a contact centre" (your message) | A plan, not a past. Name three first steps: how complaints enter the contact centre; who on that team you would learn from; where its complaints differ from the branch's. | F8. The plan answers the gap without claiming experience. |
| B7 | "The plan moves eight branches into five hubs during 2027. Which part would you need the most support on?" | CO | [grounded] "I've never presented to anyone above regional level." (your message) | Name one support need, as a plan. Do not claim experience of consolidation; none is in your material. If you name presenting the hub plan to senior leaders, say that you would want support on it, which is true to your material. | Raised by the strategy brief. Connects to the F7 gap. |
| B8 | "Eight branches become five hubs during 2027. How would you keep complaint handling consistent through that?" | CO, CASE | [generic] | Clarify what happens to open cases at a branch that closes. Objective: no member explains a complaint twice. Segment by complaint type. Approach: move ownership with the case, not with the building. Metrics: volume and resolution time by hub. Risk: cases lost in handover. If you use the log as an example, quote it exactly, and it stays at its own scope. | The CO requirement, from the brief. Guidance is structure, so it needs no claim about your past. |
| B9 | "The plan has digital taking 40% of member service by 2028. Which complaints should never move to self-service?" | JD, CASE | [generic] | Define a complaint against a service request first. Then segment by complaint type and by when a member needs a person. Name the decision point where a person must own the fix. Do not claim digital or self-service experience. None is in your material. | Covers the digital-teams requirement (F5), in the form of a plan. |

---

## 5. Round 3: panel of two branch managers (60 minutes, values scoring, 20-minute case)

### Persona weights

| Persona | Weight | Reasoning | How it shows up | Counter-strategy |
|---|---|---|---|---|
| Values / behavioural | 4 (top) | The panel scores the four values, so this is the round's scoring axis | C1, C2, C3, C9 | A mapped story or a scaffold, with the honest branch, for each value (see the values sheet below) |
| Peer evaluator | 3 | Two branch managers, testing the seam between their branches and yours, and how credit and disagreement are handled | C5, C6, C8 | Propose seam principles. Do not claim knowledge of their branches. |
| Case / strategist | 1 | The 20-minute escalation case. Weight counts questions, not minutes, so this is one question with deep follow-ups. | C4 | Clarify before acting. Name who owns the file. Write the plain-words letter. |
| Pressure | 1 | Low weight, but the contact-centre gap is the obvious thing for this panel to test | C7 | Pause, restate, hold two follow-ups, concede specifically |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you put a member ahead of an internal target." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." (your message) | Pick a time a member's outcome came before a target. If none comes to mind, say so plainly, then give the nearest thing in the material: a log case, and what you did with it. | Members First. The honest branch is the answer. |
| C2 | "Tell me about a time a branch's local context changed how you handled something." | VAL | [grounded] "I handled the branch's formal complaints log" (your message) | Pick a time local knowledge changed a decision. If none comes to mind, say so and give the nearest log case, with the local factor you knew about or did not. | Neighbours, Not Numbers. Nothing in the material is about local context, so the scaffold is the honest form. |
| C3 | "Show us how you would tell a member their complaint was not upheld." | VAL | [generic] | Say the decision first. Give the reason in one sentence. Give the next step. Say what the member can do if they disagree. Do not use a past case as the example. | Plain Words. A role-play, so it needs no claim about your past. |
| C4 | Live case (20 minutes): "A member's complaint about a declined loan has been with your branch for six weeks. The member has now written asking for it to go higher. Their branch manager tells you the case is with the team. You have the file. What do you do?" | CASE | [generic] | Clarify first: who owns the file, what "with the team" means, and the member's deadline. Then take ownership of the file today. Set the applicable timescales. Write to the member in plain words: the decision, the reason, the next step. Decide the fix, or escalate with a named owner. Record the cause, so the branch manager can be coached. Follow-ups: if they say it is the team's backlog, hold the member's timescale. If they say you cannot reverse the decline, escalate with the file, not with a promise. | The escalation case the panel scores. Covers the coaching requirement too. The scenario is invented and the guidance makes no claim about your past. |
| C5 | "Our branches handle complaints a little differently. Where is the seam between your branch and ours, and what happens when we disagree?" | VAL | [grounded] "I handled the branch's formal complaints log" (your message) | Propose a seam principle, not a fact about their branches, such as one log and one owner per case. Disagreement: pick a time you disagreed with a peer. If none comes to mind, say so and say how you would settle a disagreement about one complaint between two branches. | Peer evaluation. The seam question asks for a principle the panel can test. |
| C6 | "How do you handle credit when a complaint fix spans two branches?" | VAL | [grounded] "I handled the branch's formal complaints log" (your message) | Say whose name stayed on the case, if you can. If none, say so and say how you would share it. | Credit-sharing probe. The honest form is the nearest case you handled. |
| C7 | "Sixty seconds: why should we give complaints across a contact centre to someone who has never worked in one?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." (your message) | **Pause, restate, then hold.** Hold for two follow-ups on the complaints work you did on the branch side. Then concede: "I haven't worked in a contact centre." Then the plan. The limit: do not claim contact-centre knowledge you do not have. | Pressure persona. The question is sourced in the candidate's stated negative. |
| C8 | "Tell me how you would coach a branch supervisor who keeps escalating cases the branch could close." | JD | [grounded] "trained new tellers on our escalation script" (your message) | If you have coached a supervisor, say how. If you have only trained tellers, say so, then describe how you would coach: review the cases together, agree a test for when to escalate, check the outcome afterwards. | F4. The JD's coaching requirement. Transferability: tellers, not supervisors. |
| C9 | "When have you had to give a member an answer they did not want, and stand behind it?" | VAL | [grounded] "I handled the branch's formal complaints log" (your message) | Pick a time you gave an unwelcome answer. If none comes to mind, say so and give the nearest log case. Do not rewrite the outcome. | Members First under pressure. The panel tests whether the hard truth actually landed. |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| Own the complaints process end to end across branches and the contact centre | A5, B1, C4 |
| Contact centre | B5, B6, C7 (the stated gap, with its plan) |
| Monthly reporting on volumes and resolution times | A7 |
| Comfortable with Excel reporting | A7 |
| Coach branch supervisors on escalations | C8, C4 (the coaching angle) |
| Work with digital teams on self-service journeys | B9 |
| Experience handling regulated complaints | A3, C4 (the timescale slot) |
| Confident presenting to senior leaders | B5, B7 |
| 4+ years in financial-services customer operations | A1, A4 |

**Highest-ROI prep:** B5. It is the objection most likely to come up in some form in round 2, and possibly in round 3 as C7. Rehearse the hold on the log and the concession, in your own words, until the concession is not difficult to say.

### Values cheat sheet (sits in round 3, the values-style round)

| Value | Working meaning | Your story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | F1. Scaffold for C1, C9, B3: pick a decision where the member's outcome came first. If none, say so, then the log case in your own words. |
| Plain Words | If a member needs it explained twice, the wording was wrong | F4. Beat: the script you trained tellers on. Answer slot: if you changed the wording because members did not follow it, say what and why. If not, say so and say how you would check it works for members. |
| Neighbours, Not Numbers | Each branch is part of its town | None in your material. Scaffold for C2: pick a time local context changed a decision. If none, say so and give the nearest log case. |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | F1. Beat: the log, and each step you handled. Answer slot: did the case stay yours until it closed? If it was handed on, say to whom and why. |

### Reverse questions

Ask these at the end of each round. The "why it lands" is for you, not the interviewer.

**Round 1 (recruiter):**
1. "What would a good first 90 days look like in this role?" Why it lands: it shows you are thinking about the job, not only the offer.
2. "Which part of this role is hardest to hire for?" Why it lands: the recruiter knows where the bar is, and asking shows you want to meet it.

**Round 2 (Head of Member Services):**
1. "How will this role's success be measured through the 2027 hub changes?" Why it lands: it ties your question to the strategy, and the answer shows you what the manager is scored on.
2. "What would make the contact-centre side of this role easiest to learn?" Why it lands: it turns your stated gap into a question the manager can help with, which is a peer conversation rather than an interview.

**Round 3 (panel, peers; includes reciprocity):**
1. "What would a new person do in their first month that would genuinely help your branches?" Why it lands: this is the reciprocity question. It asks what you bring, not only what you need.
2. "Where does complaint handling sit between your branches and the contact centre today, and where does it fall between them?" Why it lands: it shows you have thought about the seam, and it gives you the panel's own view of it.

---

## 6. Prohibited claims

Built from the fit snapshot before the banks were written. None of these may appear in an answer, a slot, or a hold.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end across branches and the contact centre | Inflated form of F1 and F8 | F1's quote at its own scope: "I handled the branch's formal complaints log." The pack's observation, in its own analysis: your material says the branch's log, and nothing about the contact centre. |
| Set the reporting measures for the regional team | Inflated form of F2 ("built the spreadsheet") | F2's quote at its own scope. A7's slot asks only what the spreadsheet holds. |
| Has experience with regulated-complaint timescales | Inflated form of F6 ("formal") | F6's quote at its own scope, with the slot in A3. |
| Coached branch supervisors on escalations | Inflated form of F4 ("trained new tellers") | F4's quote at its own scope, with the slot in C8. |
| Has presented to senior leaders | Negative you stated, F7 | Plain acknowledgment: "I haven't presented to anyone above regional level." No slot on this point; only the plan. |
| Has worked in a contact centre | Negative you stated, F8 | Plain acknowledgment: "I haven't worked in a contact centre." Then the plan. |

---

## 7. Sources

- **Provided, in hand:**
  - The job description, as pasted.
  - The four values, as copied from the company's values page on 11 November 2026.
  - The recruiter's email on the process.
  - Your summary of the July 2026 strategy brief. The brief itself was not provided, so its exact wording is not in the pack.
  - Your background, from your message.
- **Dossier:** none provided.
- **Assessment:** none provided.

**Research tier: L1, searches 0 of 6, fetches 0 of 2; user links read 0.** No search or fetch was sent, because the inputs already fix every output the research targets feed.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | The values sheet and the grounding brief. The values text is in hand, pasted from the company's page. |
| 2. Interview process | skipped | The loop structure and the persona weights. The recruiter's email names the three rounds. |
| 3. Strategy / recent news | skipped | The grounding brief and the CO questions. Your summary of the July 2026 brief supplies current priorities. |
| 4. Interviewer names | n/a | No names were given, so there was no query to form. The interviewer read is absent. The upgrade menu says what a name would unlock. |
| 5. Representative JD | skipped | The job description you supplied fixes the fit snapshot and the JD-tagged questions. |

---

## 8. Upgrade menu

- **The brief itself**, not your summary → verifies the exact figures for B7, B8 and B9, and lets the grounding brief quote the brief's own words.
- **The Head of Member Services' name and the two branch managers' names** → an interviewer read, and per-person persona weights in rounds 2 and 3. A check of their public footprint, which is research at the default tier.
- **Whether your branch is one of the eight moving into hubs** → B7 and B8 can use your own branch as the example, instead of general structure.
- **Your CV, as a document** → more quoted sentences for F3, F5 and F6, and a stronger A1.
- **Any figure from the complaints log or spreadsheet**, such as volumes or times → turns A7 into a defend-the-number rehearsal, with the weakest-assumption move.
- **Any digital, self-service or contact-centre work, even partial** → F5 and F8 move from discovery and capability to something you can speak to.
- **Job-description logistics, such as location or schedule** → checks for gate rows. None apply on the current material.
- **Deep research (L2), offered once:** it would add the strategy brief itself, the interviewers' public footprints if names are given, and recent Ashgrove news. Cost: up to 6 more searches and 2 more fetches, at your word.
- **A `tuesday-dossier.md`**, if you save one, would add verified evidence and prohibited claims to future packs.
