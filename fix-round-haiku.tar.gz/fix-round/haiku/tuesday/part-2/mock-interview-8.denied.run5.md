Your prep pack is saved as `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-tuesday-part-2-rooms-case-8-denied-68119139/6cf0a2fd-0a01-4aa8-ad4b-01c26c1f51d3/scratchpad/ashgrove_member-experience-lead_interview_pack.md`. It covers all three rounds, with separate question banks for each.

The two things to spend your time on:

- **R2-S1 is the most important question in the pack.** Your manager is likely to press on the two gaps you named: no contact-centre work and nothing above regional level. The rehearsed answer is to say each gap in your own words, hold on what the log and spreadsheet show, then give a concrete plan for each gap. Don't claim presenting experience to fill the gap.
- **Round 3's 20-minute case (R3-K1) and the values scoring.** The case is a fee complaint escalated by a member threatening to leave. Clarify before you answer, and name the rules that govern it if you know them. The values cheat sheet shows which of your sentences carries each value and where you'll need to say "no story here."

I ran no web searches. Everything in the pack comes from what you sent. The values and strategy brief are your copies, and the strategy brief is your paraphrase, so check the exact wording before you quote it to anyone. The panel and the Head of Member Services aren't named yet, so Round 2 and 3 persona assignments are by role.

Would you like me to play the Skeptic on R2-S1 as a live drill?

I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions. And if you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove_member-experience-lead_interview_pack.md -----
# Ashgrove Credit Union: Member Experience Lead interview pack

**Loop mode.** Three rounds on 20 November 2026, one pack, per-round mini-packs.

| Round | Who | Length | Shape |
|---|---|---|---|
| 1 | Recruiter | 30 min | Screen: background, motivation, logistics |
| 2 | Head of Member Services (your manager) | 45 min | Mostly behavioural |
| 3 | Panel of two branch managers | 60 min | Includes a 20-minute complaint-escalation case; the panel scores the four values |

Panel names are not known yet. Round 3 persona assignments are per role until they are.

## How to use this pack

- **Personas** describe how a question is asked. **Types** describe what is being scored: VAL (behavioural, values), EXP (your own experience, probed), JD (the job's stated requirements), CO (company and strategy), CASE (a live problem).
- Guidance is scaffolding, not a script. Each guidance cell should be speakable in 90 to 120 seconds, in your own words.
- Where a cell says **answer slot**, the interviewer is probing a practice the job raises. Answer it from your own experience in one of two honest ways: say how you did it, or say plainly that it was not yours or did not happen. The pack will never supply the answer for you.
- **Plain acknowledgment** means words you have already said yourself, reused exactly. Use them when a gap comes up.

---

## 1. Fit snapshot

Each row is one requirement from the JD, the evidence from your own sentences (quoted exactly), and how to handle the gap. Evidence sources: "your message" is what you wrote for this prep; "your CV" would be the CV, which I have not seen.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | none | The quote reaches it. Say the years and the role as you wrote them. Expect one probe on the supervisor years; they are the strongest part of your record. |
| F2 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | presentation | The quote reaches the requirement in other terms: a formal log is complaints work, but "regulated" is not in it. Say it as you wrote it: "I handled the branch's formal complaints log." Answer slot: the JD's "regulated" makes a probe on which rules governed the log likely. If you worked to specific rules, name them and how you applied them. If the log ran without them, or they were not yours to apply, say so and stay with the log. |
| F3 | "Own the member complaints process end to end across branches" — JD | "I handled the branch's formal complaints log" — your message | low | [grounded] | transferability | Adjacent work: one branch's log, not the process end to end across branches. Pack observation: your material does not show the steps before or after the log. Words: "I handled the branch's formal complaints log." Answer slot: which steps of a complaint, from logging to closing, were yours to run? If others ran some, say which. |
| F4 | "across branches and the contact centre" — JD | "Never worked in a contact centre" — your message | none | [grounded] | capability | A stated absence, and the gap is real. Plain acknowledgment: "I've never worked in a contact centre." Then how you would learn it, said as a plan, never as a past. Claim no contact-centre work. |
| F5 | "coach branch supervisors on escalations" — JD | "trained new tellers on our escalation script" — your message | medium | [grounded] | transferability | Adjacent work: you trained tellers, not supervisors. Words: "I trained new tellers on our escalation script." Answer slot: if you coached other supervisors on escalations, say how. If not, say so and say what the tellers' training covered. |
| F6 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | presentation | The quote reaches monthly complaint reporting in other terms. Resolution times are not in it. Words: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: did the spreadsheet track resolution times? If yes, say how they were counted. If not, say so. |
| F7 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | low | [grounded] | discovery | The quote touches reporting but does not show the tool. Answer slot: what the spreadsheet was built in, and what you did in it yourself. If it was Excel, name the functions you used. If it was not, say what it was. |
| F8 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A stated absence above regional level. Plain acknowledgment: "I've never presented to anyone above regional level." Then the plan. Do not describe regional presentations as senior-leader presentations. |
| F9 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | No quote. Answer slot: if you have worked with any team on a change to how members serve themselves, say what and your part. If not, say so and say how you would start. |

**Reading the gap types.** Silence in your material is *discovery*, not *capability*. Only F4 and F8 are *capability*, because you stated those absences yourself.

### 1a. The two gaps you named, handled

**Gap 1: contact centre (F4).** Say it first, in your words: "I've never worked in a contact centre." Then the adjacent work, quoted: you handled the branch's formal complaints log, and you trained tellers on the escalation script. Then a plan [generic]: ask to sit with a contact-centre queue for a fortnight; learn what their complaints data looks like; name the one thing you would check in the first 30 days. Do not say the branch log is "contact centre" work. The interviewer knows the difference in one sentence.

**Gap 2: presenting above regional level (F8).** Say it first: "I've never presented to anyone above regional level." Then what you do have, quoted: you built the monthly complaints spreadsheet your regional manager uses. Then a plan [generic]: ask to present the spreadsheet's findings at a regional review first, then to a wider audience. Do not describe anything as a senior-leader presentation. A gap you name calmly scores better than one an interviewer finds.

---

## 2. Prohibited claims

The pack will not coach these, under any question, in any round. Each has a basis and an honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end across branches | Inflated form of F3 | F3's quote at its own scope. Pack observation: your material shows one branch's log. |
| Ran complaints handling in a contact centre | Negative you stated, F4 | "I've never worked in a contact centre." No answer slot. |
| Presented to senior leaders | Negative you stated, F8 | "I've never presented to anyone above regional level." No answer slot. |
| Coached branch supervisors on escalations | Inflated form of F5 | F5's quote at its scope: trained tellers on the script. |
| Reported on resolution times | Inflated form of F6 | F6's quote. The spreadsheet's contents are not stated in your material. |
| Built the reports in Excel | Inflated form of F7 | F7's quote, without the tool named. |

---

## 3. Grounding brief: what Ashgrove has published (as relayed)

These come from your note of the July 2026 strategy brief and the values page you copied on 11 November 2026. Your note paraphrases the brief, so check the exact wording before you quote it back to an interviewer.

- Move 40% of member service to digital channels by 2028. [grounded] (your note of the brief)
- Consolidate eight branches into five hubs over 2027. [grounded] (your note of the brief)
- Launch a small-business lending product in Q1 2027. [grounded] (your note of the brief)
- Main competitive pressure: app-only banks. [grounded] (your note of the brief)
- Values, as copied: Members First, Always; Plain Words; Neighbours, Not Numbers; Own the Fix. [grounded] (values page, copied 11 November 2026)

**Why this matters for the rounds.** The hub consolidation and the digital target both change who handles complaints, so both are fair game in rounds 2 and 3. Your material has nothing on either, so the answers are plans, not history.

---

## 4. Persona weights, by round

Relationship priors set the starting point, the loop adjusts them, and the reasoning is shown.

| Round | Prior | Loop adjustment | Weights |
|---|---|---|---|
| 1 Recruiter, 30 min | Conversational + light Skeptic | Recruiter's stated purpose is logistics and motivation consistency, so the Conversational persona leads. The Pressure persona is kept at light weight because the screen can still test composure. | Conversational 4 (C1 to C4), Skeptic 3 (S1 to S3), Pressure 2 (P1 to P2) |
| 2 Head of Member Services, 45 min | Case/Strategist + Skeptic | The recruiter says "mostly behavioural", which moves Values/Behavioral to the top. The Case work is folded into round 3's case, and the Prober covers the Excel and reporting requirements. | Values/Behavioral 4 (V1 to V4), Skeptic 3 (S1 to S3), Data-Driven Prober 2 (D1 to D2) |
| 3 Panel of two branch managers, 60 min | Blend of each member's top two: Peer Evaluator and Case/Strategist, plus Values, which the panel scores | The 20-minute case is the largest single block. Values is scored by the panel, so it is weighted above Peer. | Case/Strategist 3 (K1 to K3; K1 carries the 20-minute case), Values/Behavioral 3 (V1 to V3), Peer Evaluator 2 (E1 to E2) |

---

## 5. Round 1 bank: recruiter screen (30 min)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R1-C1 | "Walk me through your background, the short version." | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor."; "I handled the branch's formal complaints log"; "trained new tellers on our escalation script" | Story-mapped from the three quoted sentences, in those words: six years in retail banking, the last three as a branch supervisor; then the complaints log; then the tellers' training. Finish in under 60 seconds. | Opener for a conversational screen. Its only content is the three quoted sentences, which carry F1, F2 and F5. |
| R1-C2 | "What is it about this role that made you apply?" | JD | [generic] | Name the part of the role you most want, using the JD's own words. Say why in your own words. Do not claim a reason about Ashgrove's branch plans, because you have not been told them. | Motivation consistency is what the screen checks. The answer makes no past claim, so it needs no quote. |
| R1-C3 | "Tell me about the spreadsheet you built. Who uses it?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Story-mapped: you built it, and your regional manager uses it. Answer slot: what it tracks. If resolution times are in it, say how they are counted. If not, say so. | F6 and F7. The spreadsheet is the nearest thing to the reporting requirement, and the likeliest place a screener checks for Excel. |
| R1-C4 | "What are you playing with in digital at the moment?" | JD | [generic] Raising source: "work with digital teams on self-service journeys" (JD) | Answer slot: if you have worked on any change to how members serve themselves, say what and your part. If not, say so and say how you would start. | A casual phrasing of a JD line (F9). Treat it as scored, not small talk. |
| R1-S1 | "Your background is branch-based, and this role runs a contact centre too. What's your answer to that?" | JD | [grounded] "Never worked in a contact centre" | Plain acknowledgment: "I've never worked in a contact centre." Then one example of how you would learn it, in the future tense. Do not reach for the complaints log as contact-centre work. | F4, the largest gap. The screen version is short; R2-S1 is the deep version. |
| R1-S2 | "What does handling a regulated complaint mean to you, in practice?" | JD | [generic] Raising source: "experience handling regulated complaints" (JD) | Open prompt. Answer from your own log: what it required of you, in your own words. If you cannot name the rules that applied, say so and say how you would find out. | An open prompt on the JD's "regulated" line (F2). Asked as a definition, so a bluff has nowhere to hide. |
| R1-S3 | "You're moving from branch work to a role across branches and the contact centre. What do you expect to miss?" | VAL | [generic] | Name one thing from branch work you would honestly miss, then what you would keep. Make no claim about members that your material does not state. | Tests whether the move is considered, not a flight from branch work. No claim about your past is needed. |
| R1-P1 | "Sixty seconds: why should we hire you over someone who has run a contact centre?" | JD | [generic] | Hold: name what you bring that is quoted (the log, the tellers' training, the spreadsheet), and say plainly what you do not have. Hold through two follow-ups, and do not fold on the log. Concede the contact centre specifically: "I've never worked in one." | Pressure on F4 in its shortest form. Composure matters more than content here. |
| R1-P2 | "How much of the complaints work was yours to decide, and how much was set for you?" | EXP | [grounded] "I handled the branch's formal complaints log" | Answer slot: say which decisions were yours and which followed a set procedure. If none were yours to decide, say so. | An attribution probe. A screener is checking whether "handled" meant "decided". |

---

## 6. Round 2 bank: Head of Member Services (45 min, manager, mostly behavioural)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R2-V1 | "Tell me about a formal complaint you handled that you would handle differently now." | VAL | [grounded] "I handled the branch's formal complaints log" | Selection scaffold: pick one complaint from the log that you would change. Say the decision you made, what the member got, and what you would change. If none comes to mind, say so plainly, then give the nearest one the log carries. | Members First. An open prompt on F2 and F3, with its theme from the JD's "own the complaints process". |
| R2-V2 | "Tell me about a time you had to tell someone senior something they didn't want to hear." | VAL | [generic] Persona stem | Selection scaffold: name the person and their level exactly. If it was your regional manager, say so. Do not stretch the moment upward, because F8 is the gap. Say the hard truth you told and what happened next. If none comes to mind, say so. | Own the Fix, and the upward-presenting gap. The interviewer will check the level you name. |
| R2-V3 | "A branch team tells you a complaint process is too slow. What do you do?" | CASE | [generic] | Structure: what you would check before agreeing, whose problem it is, what you would fix first, and how you would keep hold of it until it is solved. Speak to Own the Fix. | A live problem from the JD's ownership and coaching lines. It is asked as a decision, so it presupposes nothing about your past. |
| R2-V4 | "What does your regional manager do with the spreadsheet each month?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Answer slot: if you know what it changed for them, say what. If you don't, say so. Do not guess at a decision it drove. | F6. The question's premise is the sentence itself, so it asks about use, not outcome. Monthly reporting is the JD's requirement. |
| R2-S1 | "You've handled a branch's formal complaints log, but you've never worked in a contact centre and never presented above regional level. Why should we trust the plan for both?" | JD | [grounded] "Never worked in a contact centre"; "I've never presented to anyone above regional level." | **The deepest rehearsal in the pack.** Plain acknowledgment for each gap, in your words: "I've never worked in a contact centre." and "I've never presented to anyone above regional level." Hold by returning to what you can stand behind: the log, the tellers' training, the spreadsheet, and what you did with each. Concede each gap specifically, then give the plan for each [generic]: sit with a contact-centre queue for a fortnight; present the spreadsheet's findings at a regional review before anything wider. Two follow-ups, then the plan. Do not claim presenting experience to fill the gap. | This is the highest-return prep in the pack. The JD's two hardest asks are the two gaps, and a manager will press on them. A rehearsed answer that acknowledges, then plans, survives the second follow-up. A bluff does not. |
| R2-S2 | "How would you coach a branch supervisor whose escalations keep going to the wrong place?" | JD | [generic] Raising source: "coach branch supervisors on escalations" (JD) | Hypothetical, so no past claim. Structure: diagnose, check the script, talk it through with the supervisor, agree one measure. If you cite your supervisor years, use only "the last 3 as a branch supervisor." | Tests the coaching requirement (F5) without asking for a past you may not have. |
| R2-S3 | "What would your own supervisor say you didn't do in your three years as a branch supervisor?" | VAL | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Give one specific, honest limit from what you know. Do not invent a fault to sound candid. Keep the answer consistent with F4 and F8, which are your material's own limits. | Self-assessment probe. An answer that contradicts F4 or F8 fails at once. |
| R2-D1 | "How did you tell a formal complaint from an informal one on that log?" | EXP | [grounded] "I handled the branch's formal complaints log" | Answer slot: if you know the definition the log used, say it. If the log did not define it, or you did not set it, say so. | Prober. "Formal" presupposes a distinction, so the answer slot asks for your words, not an invented definition. |
| R2-D2 | "Does your spreadsheet show how long complaints took to resolve? If so, how was that counted?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Answer slot: if resolution time was tracked, say how it was counted and what it is sensitive to. Name the assumption you would defend least. If it was not tracked, say so and say what you would add first. Name only what you can repeat. | F6. Resolution time is the JD's stated figure, so the slot may name it. |

---

## 7. Round 3 bank: panel of two branch managers (60 min, including a 20-minute case)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R3-K1 | "A member's fee complaint has been escalated to you. They say they'll move their account if it isn't sorted this week. Talk us through the next 20 minutes." | CASE | [generic] | Structure: clarify first (what the complaint is, what has been done, any deadline, whether it is regulated). Then the objective (the member's outcome, and the process rule). Then segment (fee error, process failure, misunderstanding), approach, the metrics you would watch (time to resolution, reopen rate), and the risks (a missed timescale, the member leaves, blame falls on the branch team). Ask one clarifying question before you answer. Name the rules that govern it if you know them; if not, say how you would find out. Follow-ups to rehearse: (a) "What do you tell the branch?" (b) "The fee was correct. What now?" (c) "How do you report this next month?" | The 20-minute case the recruiter flagged. A case scores clarification and structure before the answer. The regulated element comes from the JD, so the rules question is a probe you should expect. |
| R3-K2 | "Complaints in one branch are up 30% month on month. Diagnose it." | CASE | [generic] | Clarify the period, the complaint type, and whether the rise is one branch or several. Segment by cause. Check whether something changed, such as a form or a system. Say which measure you would want first. Do not claim your spreadsheet ever showed this. | Reporting and resolution times (the JD) in a live problem. It asks about no past, so it needs no quote. |
| R3-K3 | "Eight branches become five hubs during 2027. Where do open complaints go when a branch closes?" | CO | [grounded] "consolidate eight branches into five hubs over 2027" (strategy brief as relayed in your note) | Plan-level answer [generic]: each open case keeps one named owner; members are told where to go; the complaint file moves with the case; the regulated timescale does not pause. Speak to what you would check first, not to a hub design you have not seen. | A strategy question at the panel's altitude. The brief makes hub consolidation Ashgrove's own plan. Check the brief's wording, since your note paraphrases it. |
| R3-V1 | "Tell me about a problem you kept hold of until it was actually fixed." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Selection scaffold: pick a complaint or a pattern you followed until it was solved. Say what the problem was, what you did, and when it closed. If the spreadsheet is the nearest thing, say only what it was for, in your own words. If you cannot say that, say so. If none comes to mind, say so plainly. | Own the Fix. The quoted sentence carries the build, not the follow-through. The honest branch is the point. |
| R3-V2 | "Tell me about a time you explained a decision to a member in plain words." | VAL | [grounded] "trained new tellers on our escalation script" | Selection scaffold: pick an explanation a member had to hear twice, or one that landed the first time. If you changed how the script was explained to tellers so it landed, say how. If you did not, say so and give the training as it was. | Plain Words. The quote carries teaching the script, not explaining it to members. Say that, and do not stretch it. |
| R3-V3 | "Tell me about a complaint where the branch's town mattered more than the numbers." | VAL | [generic] | Selection scaffold: a case where local context changed the answer (a community, a local employer, a regular customer). If none comes to mind, say so. Do not build one. | Neighbours, Not Numbers. No quoted sentence carries it, so the honest branch is needed. |
| R3-E1 | "Our branches sit beside the contact centre. Where is the seam between us, and what happens when we disagree about a complaint?" | JD | [generic] Raising source: "across branches and the contact centre" (JD) | Propose seam principles (who owns the case, who owns the member, how a disagreement is escalated), not a seam you have not seen. Answer slot: if you have disagreed with another team over a complaint, say how it ended. If not, say so and give the principle. Reciprocity: say what branches bring the contact centre. | Peer Evaluator. Branch managers want to know who holds a case when a branch and the contact centre disagree. |
| R3-E2 | "Digital is meant to take 40% of member service by 2028. Where do complaints sit in that?" | CO | [grounded] "move 40% of member service to digital channels by 2028" (strategy brief as relayed in your note) | Plan-level [generic]: complaints that move to digital still need a route to a person; the regulated process has to survive the channel; measure what the channel actually fixed. Do not claim digital work you have not done. The honest answer for your own record is the F9 answer slot. | Digital (F9) at strategic altitude. A peer will weigh what the hire adds to their branch load. |

### 7a. Values cheat sheet (round 3 is the values round)

The panel scores against the four values. Each row maps one value to a quoted sentence, or gives a selection scaffold with its honest branch where no sentence carries it.

| Value (official name) | Working meaning (paraphrased) | Mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | F2 row: "I handled the branch's formal complaints log". Selection scaffold: a formal complaint where the member's side changed your decision. If none comes to mind, say so, then give the nearest one from the log. Questions: R2-V1, R3-V1. |
| Plain Words | If a member needs it explained twice, it was written wrong | F5 row: "trained new tellers on our escalation script". The sentence carries teaching the script to tellers, not explaining it to members. Say that. If you changed how the script was explained so it landed, say how; if not, say so. Questions: R3-V2. |
| Neighbours, Not Numbers | Every branch is part of its town | No quoted sentence carries it. Selection scaffold: a case where local context changed the answer. If none, say so; do not build one. Questions: R3-V3. |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | F6 row: "I built the monthly complaints spreadsheet our regional manager uses". The quote carries the build. Follow-through is a selection scaffold: a problem you kept hold of until it was closed, or the honest branch. Questions: R3-V1, R2-V3. |

---

## 8. Reverse questions (at least one per round, each with why it lands)

**Round 1 (recruiter)**
- "What does success look like in the first six months?" Why it lands: it shows you are thinking about delivery, not the job description.
- "What has the team tried on complaints that didn't work?" Why it lands: it opens the real problem and tells you what the team has already learned.

**Round 2 (Head of Member Services, your manager)**
- "Where do complaints most often stall between a branch and the contact centre today?" Why it lands: it is diagnostic, and it lets your manager talk about the problem you would own.
- "What would make you say in six months that the hire was right?" Why it lands: it turns the gaps into a shared measure for the first six months.

**Round 3 (panel of branch managers)**
- "What could a new head of complaints do in the first month that would genuinely help your branches?" Why it lands: a reciprocity question to peers. It signals you are thinking about their load, not only yours.
- "How will the hub consolidation change the complaint workload for your branches?" Why it lands: it uses the strategy brief at the panel's own altitude, and it invites a candid answer from people who will live with the change.

---

## 9. Requirement coverage

Each JD requirement, the questions that cover it, or a stated reason where none does.

| JD requirement | Fit row | Question IDs |
|---|---|---|
| 4+ years in financial-services customer operations | F1 | R1-C1, R2-S3 |
| Experience handling regulated complaints | F2 | R1-S2, R1-P2, R2-V1, R2-D1, R3-K1 |
| Own the member complaints process end to end across branches | F3 | R2-V1, R2-S1, R3-K1 |
| Across branches and the contact centre | F4 | R1-S1, R1-P1, R2-S1, R3-E1 |
| Coach branch supervisors on escalations | F5 | R2-S2, R1-C1 |
| Report monthly on complaint volumes and resolution times | F6 | R1-C3, R2-V4, R2-D2, R3-K2 |
| Comfortable with Excel reporting | F7 | R1-C3 only. The tool question is asked once here; repeating it elsewhere would add nothing. |
| Confident presenting to senior leaders | F8 | R2-S1, R2-V2 |
| Work with digital teams on self-service journeys | F9 | R1-C4, R3-E2 |

Company values: all four are covered in section 7a, with questions R2-V1, R3-V1, R3-V2 and R3-V3.

---

## 10. Sources

**Provided documents**
- The JD, as pasted in your message.
- The recruiter's email on the three rounds and their formats.
- The values page, copied on 11 November 2026, as pasted.
- The July 2026 strategy brief, as relayed in your note (a paraphrase, not the brief itself).
- Your background, as you described it.

**Research tier:** L0 (provided documents only). No searches sent. User links read: 0.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | The values text you pasted fixes the values cheat sheet (section 7a). |
| 2. Ashgrove interview process | skipped | The recruiter's email fixes the three rounds, their lengths and formats. |
| 3. Ashgrove strategy / recent news | skipped | The brief as relayed fixes the grounding brief (section 3). |
| 4. Interviewer names | n/a | No names given for the Head of Member Services or the two branch managers, so no query could be formed. |
| 5. Representative JD for the title | skipped | The JD you pasted fixes the fit snapshot and the JD-tagged questions. |

---

## 11. Upgrade menu

- The two branch managers' names → persona assignments for each panel member, and a tailored reverse question for each.
- The Head of Member Services' name → persona weights from their public professional footprint.
- The round 3 case format (written or verbal, and any materials) → the case bank tuned to the format.
- Any contact-centre-adjacent work, even brief (a queue you covered, phone escalations you handled), if it is real → could move F4 from capability to transferability. Only if it is true.
- A list of the spreadsheet's columns, with no figures needed → upgrades F6 and F7 from answer slots to grounded statements.
- Your answers to the answer slots, in your own words, outside a drill → the rows they draw on are regenerated.
- A one-line list of your supervisor duties → upgrades F5 and sharpens R2-S2.
- The exact wording of the strategy brief → makes section 3 and R3-K3 and R3-E2 quotable as published, not as paraphrased.
