Your prep pack is saved here: `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-tuesday-part-2-rooms-case-7-canned-ac75d956/08403f1d-ad9d-44fb-9065-2b360b7c30b4/scratchpad/femi-saltmarsh-prep-pack.md`

**The short version**

- **Your strongest material** is the content-drop calendar you ran for two years and the release checklist QA still uses. Both match JD requirements directly. Lead with the checklist: Tobias comes from QA.
- **Tobias's public angle:** I found one talk, "Patch Notes Are a Promise" (GDC 2026), where he argues a live team is judged by how often its patch notes match what actually shipped. Expect him to test accuracy and execution. Don't polish claims.
- **Your gaps:** you have never led a team and never worked on an IAP game. Name both before he does. Describe your cross-team work as influence, not leadership. Don't claim IAP or monetization experience.
- **Weakest JD areas:** coordinating design, art, engineering and community on each update, and owning the KPIs rather than presenting them. Only use a story if it really happened. If it didn't, say how you'd approach it.
- **Likely hard questions:** "Why should we trust you to coordinate four teams without leading one?", "What will you do about monetization?", and "Tell me about an update that went wrong after it shipped." The pack has a prepared answer shape for each.
- **Three reverse questions** are in the file, including one about who owns the KPI targets.

**Caveats**

- The talk page I found uses a `.example` domain, which looks like a placeholder. I couldn't find anything else about Saltmarsh Games or Tobias. Before you rely on the talk, check that it exists.
- Your background came as a summary, not a CV. The evidence rows are only as specific as what you gave me.

**Questions (two, so the pack can be sharpened)**

1. Is Friday a one-to-one with Tobias, or a panel? Is there a presentation or take-home?
2. Did you own the KPI targets for the retention numbers, or only present them to the studio head? The answer changes how you should describe the KPI requirement.

**Offers (neither pushed)**

- **Drill:** I can play Tobias and run the content-drop or checklist question with follow-ups, then give feedback against the answer guidance.
- **Dossier:** I can create `tuesday-dossier.md` with this pack's feedback so it carries into later rounds.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: femi-saltmarsh-prep-pack.md -----
# Interview Prep Pack: Live Operations Producer, Saltmarsh Games

**Round:** hiring-manager round, 60 min, with Tobias Wrenfield (Head of Live Operations)
**Built on:** the JD as pasted, your background as you summarized it, and L1 research (one talk page and one search; no company page was found)
**Assumption:** a one-to-one hiring-manager conversation. If it is a panel or includes a presentation, see Step 1 questions below.

---

## 1. Fit snapshot

| JD requirement | Your evidence (quoted from you) | Confidence | Bridge language |
|---|---|---|---|
| Plan and run the live-events calendar for two titles | "I ran the weekly content-drop calendar for our main title for the last two years." | Strong | You ran one title's calendar on a weekly cadence. Say that plainly and name the cadence. |
| Coordinate design, art, engineering and community on each update | Not stated in your summary | Partial | Ask yourself what you did to get each update out. Describe that concretely in your answer. Do not claim a coordination scope you did not run. |
| Own the post-event review and the KPIs it reports | "Presented the monthly retention numbers to the studio head." | Partial | Presenting numbers is not the same as owning the review. Be ready to say which parts you owned and which you only presented. |
| Manage the release checklist with QA | "Wrote the release checklist our QA team still uses." | Strong | This is a direct match. QA still uses it, which is evidence it survived use. |
| 3+ years producing live-service games or apps | "4 years as an associate producer at a puzzle-game studio." | Partial, pending confirmation | Your years are real. Whether a puzzle title counts as live-service depends on its update model, which you know and the interviewer may ask about. |
| Experience running a content calendar | "I ran the weekly content-drop calendar…" | Strong | Same evidence as the first row. Lead with it. |
| Comfortable with player-retention metrics | "Presented the monthly retention numbers to the studio head." | Partial to strong | Be ready to explain what the retention numbers meant and what you did with them. |
| Clear written communication | "Wrote the release checklist…" | Partial | The checklist is written evidence. Have one more written artifact ready if you can. |

**Gaps you named yourself:** "Never led a team." "Never worked on a game with in-app purchases."

Your leadership gap sits inside a role that coordinates four teams without managing them. Describe that as influence, not authority. Do not describe it as leadership.

---

## 2. Prohibited claims

Do not say or imply any of these in the interview:

- That you led a team, managed people, or were a people lead.
- That you have run monetization, IAP pricing, or store economics. You have not worked on an IAP game.
- That you owned the KPI targets, unless you did. You presented the numbers. Say which.
- That the puzzle title's team followed a cadence or process you did not run.

---

## 3. Interviewer read

**What the research found:** Tobias Wrenfield is Head of Live Operations at Saltmarsh Games. Before that he was a QA lead at a console studio. He gave a GDC 2026 talk titled "Patch Notes Are a Promise." His argument: a live team is judged by how often its patch notes describe what actually shipped.

**What this means for you:**
- He will weigh the release checklist and QA story heavily. Your strongest material is the checklist QA still uses. Lead with it.
- He will test whether what you say you shipped matches what shipped. Accuracy beats polish.
- Your puzzle-studio cadence will read as credible to him if you can describe what went out and what the post-release check showed.

Source: the GDC 2026 talk page (cite C1 in the research log). No other public material was found.

---

## 4. Persona weights

| Persona | Weight | Why |
|---|---|---|
| Hiring manager (Tobias, a QA background) | High | This is the round. He will probe execution and accuracy. |
| Skeptic (the gap-hunter) | High | Led-a-team and no-IAP are the obvious probes. Expect them early. |
| Pressure (the stress test) | Medium | Expect a "tell me about a launch that went wrong" follow-up. |

---

## 5. Question banks

### Hiring manager

**Q1. Walk me through the content-drop calendar you ran.**
- Provenance: quoted from you ("I ran the weekly content-drop calendar for our main title for the last two years.")
- Guidance: Describe the cadence, what went into each drop, how you decided what went in, and one drop that went smoothly and one that did not. Stop when he has enough.
- Rationale: Strongest evidence you have, and it matches the first JD requirement.

**Q2. How did you get each content drop out with design, art, engineering and community all involved?**
- Provenance: partial. Your summary does not describe this. Use a story only if you have one.
- Guidance: If you have a real example, tell it in order: what each team needed, where it went wrong, what you changed. If you do not, say how you would coordinate it and mark it as how you would approach it, not as something you did.
- Rationale: This is the JD's coordination requirement. Do not invent a scope.

**Q3. Tell me about the release checklist you wrote.**
- Provenance: quoted from you ("Wrote the release checklist our QA team still uses.")
- Guidance: Explain why you wrote it, what problem it solved, what you put in it, and how QA uses it today. Tobias's QA background means he will care about the details.
- Rationale: Your best match to the QA requirement, and it fits his talk's theme of accuracy.

### Skeptic

**Q4. You have never led a team. Why should we hire you to coordinate four teams?**
- Provenance: quoted from you ("Never led a team.")
- Guidance: Do not argue. Agree, then describe the coordination you did without authority. Name the difference between influence and management. Do not claim leadership.
- Rationale: Hold the gap, then reframe with evidence.

**Q5. You have never worked on a game with in-app purchases. How will you handle the monetization side?**
- Provenance: quoted from you ("never worked on a game with in-app purchases.")
- Guidance: State the gap plainly. Say what you would learn first and who you would ask. Do not claim IAP experience.
- Rationale: The honest answer is the strong answer. Overclaiming here is the risk.

**Q6. Retention is only as good as the decisions behind it. What did you do with the monthly numbers you presented?**
- Provenance: quoted from you ("Presented the monthly retention numbers to the studio head.")
- Guidance: If you changed a decision based on the numbers, say which and why. If you only presented them, say so and explain what you would do differently as the owner.
- Rationale: Tests whether you own KPIs or only report them.

### Pressure

**Q7. Tell me about an update that went wrong after it shipped.**
- Provenance: answer slot. Your summary does not include one. Pick a real example from your puzzle-studio work.
- Guidance: Describe what shipped, what went wrong, how you found out, what you changed, and what you put in the checklist afterward.
- Rationale: Tobias's talk is about what shipped versus what was promised. This question tests that directly.

---

## 6. Reverse questions

1. **"What does the post-event review look like here, and who owns the KPI targets?"** Why it lands: it tests the JD's ownership line, and it shows you read the JD closely.
2. **"Your talk argues patch notes should match what shipped. How do you check that before release?"** Why it lands: it ties to his own public argument. Ask it only if you have read the talk.
3. **"Which two titles will this role cover, and where is each in its live cycle?"** Why it lands: it shows you are planning for the work, not only the job title.

---

## 7. Delivery coaching

Not included. No working-style assessment was provided.

---

## 8. Upgrade menu

Each item below would add to the pack. Nothing here blocks you from using it now.

- **Your resume or CV:** would replace the summary with specifics (titles, dates, numbers) and confirm the evidence rows.
- **The full JD for the second title, if the posting names one:** would sharpen the calendar and KPI questions.
- **Deep research (L2, offered once):** the strategy brief on Saltmarsh, Tobias's other talks and writing, and recent company news. Caps: up to 6 more searches and 2 more page fetches. Time cost: about 10 minutes of your time to review the output.
- **A recruiter note on round format:** would confirm whether there is a presentation or take-home.
- **`tuesday-dossier.md`:** would add verified evidence and tighten the prohibited-claims list.
