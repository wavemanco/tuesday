Your prep pack is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-tuesday-part-2-rooms-case-7-canned-fc63aec9/db65ea38-5614-409c-8545-c23594e9ea6c/scratchpad/saltmarsh_live_ops_producer_interview_pack.md`.

I built it for a hiring-manager round. Saltmarsh's public careers page says the 60-minute loop is an "Outage Hour": a live-incident tabletop during a live event, then a values conversation, with no take-home.

**Where to spend your time**

1. **The in-app purchase gap (C1).** This is the likeliest objection. Hold "I haven't worked on one," then give a concrete plan for learning the monetization side. Don't imply experience you don't have.
2. **The live-event tabletop (A1).** Clarify first, then name the owners you'd pull in (engineering, live ops, community, QA), then say what you'd tell players. Make no claims about past incidents.
3. **Your checklist story (B2).** Tobias gave a GDC 2026 talk titled "Patch Notes Are a Promise," arguing that a live team is judged by how often its patch notes match what shipped. Your release checklist is the strongest bridge into that argument. Describe what it checks, not that QA uses it.
4. **The retention number (D1).** Be ready to say how it was counted and which assumption you'd defend least. If you don't know how it was counted, say so.

**Gaps the pack surfaces**

- Two JD lines have no evidence in your material: coordinating design, art, engineering and community on each update (F2), and owning the post-event review and KPIs (F3). For both, the honest answer is to describe what you did and what you didn't own.
- "Two titles" and "live-service" are stretches. Your material shows one title and a weekly content-drop calendar. The pack keeps those claims at that scope.
- Leadership and IAP are stated absences, so the pack gives you the exact plain words to use.

**Research done:** three searches and two page fetches. The company's values are Players Before Plans, Ship the Patch Not the Promise, and Leave the Build Greener. I didn't search for recent strategy or news, so the pack doesn't cover current company context.

**Offers:**
- I can run a live drill with Tobias as the Skeptic on C1, or as the Case interviewer on A1.
- I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for carrying into later sessions.

**Question:** Is Tobias the person you'd report to? If so, the persona weights stay as they are. If not, I'll reweight them.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh_live_ops_producer_interview_pack.md -----
# Interview prep pack: Live Operations Producer, Saltmarsh Games

**Round:** final round, 60 minutes, on Friday. Public loop page describes a single 60-minute "Outage Hour" with the hiring manager: a live-incident tabletop during a live event, then a values conversation.
**Interviewer:** Tobias Wrenfield, Head of Live Operations. Relationship (hiring manager or not) not yet confirmed; this pack assumes hiring manager.

## How to use this pack

- **Personas** = how a question arrives. **Types** = what is being scored.
- Types: **VAL** values/behavioral · **EXP** experience deep-dive · **JD** role-driven · **CO** company knowledge · **CASE** live problem.
- Guidance is scaffolding, not a script. Speak in your own words, and rehearse only what you actually did.

## Fit snapshot

Requirements come from the JD you pasted, quoted verbatim. Evidence is quoted from your message. Nothing here is an inflation of what you said.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | transferability | Your material says one title and a weekly content-drop calendar, not live events across two titles. Say that plainly. Answer slot: if you ever planned across more than one title, or ran events beyond drops, say what and how; if not, stay with the one calendar you ran. |
| F2 | "coordinate design, art, engineering and community teams on each update" (JD) | none given | none given | [grounded] | discovery | Your material does not show cross-discipline coordination. Answer slot: if you coordinated any of those teams on an update, say which, what you handled, and what you did not own; if you did not, say so and describe how you would set up that coordination. |
| F3 | "own the post-event review and the KPIs it reports" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | medium | [grounded] | transferability | Presenting retention numbers is adjacent to reporting KPIs. Your material does not show you owned the post-event review or defined the KPIs. Keep the claim at "presented." |
| F4 | "manage the release checklist with QA" (JD) | "Wrote the release checklist our QA team still uses." (your message) | medium | [grounded] | none | The quote already reaches this requirement. No inspectable proof has been shown yet; the checklist itself would raise this to high. |
| F5 | "3+ years producing live-service games or apps" (JD) | "4 years as an associate producer at a puzzle-game studio." (your message) | medium | [grounded] | transferability | Years are stated, but the material does not say the puzzle title was live-service. Answer slot: if the puzzle title ran ongoing content after launch, say what that looked like; if you are not sure how it is classed, say so. Do not call it live-service on the strength of content drops alone. |
| F6 | "experience running a content calendar" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | none | The quote reaches the requirement directly. A calendar artifact would raise this to high. |
| F7 | "comfortable with player-retention metrics" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | medium | [grounded] | presentation | The quote already reaches the requirement in other terms: you presented retention to the studio head monthly. Name the figures you presented; do not add a method you cannot repeat. Defend-the-number slot in D1. |
| F8 | "clear written communication" (JD) | "Wrote the release checklist our QA team still uses." (your message) | low | [inferred] | discovery | The checklist is written and in use, but no writing sample is in the material. Derivation: a checklist is one written artifact, so a sample would show more than the claim does. Answer slot: if you can share or describe a document you wrote for a wider audience, do so. |
| F9 | Expected probe: people leadership (not a stated JD line) | "Never led a team" (your message) | none | [grounded] | capability | You stated the absence. Words: "I haven't led a team." Then how you would coordinate without formal authority, as a plan and not a past. Never claim team leadership. |
| F10 | Expected probe: in-app purchase monetization (not a stated JD line) | "never worked on a game with in-app purchases" (your message) | none | [grounded] | capability | You stated the absence. Words: "I haven't worked on a game with in-app purchases." Then how you would learn the monetization side, as a plan. |

Hard gates: none. Length of experience (F5) is graded on fit, not treated as a gate.

## Prohibited claims

What this pack will not coach, and why.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the live-events calendar across two titles | Inflated form of F1 | F1's quote at its own scope: one title, a weekly content-drop calendar. The limit is this pack's observation: your material says one calendar. |
| Coordinated design, art, engineering and community on each update | Inflated form of F1 | Not claimed. F2 stays an answer slot. |
| Owned the post-event review and defined the KPIs | Inflated form of F3 | F3's quote at its own scope: you presented the monthly retention numbers. |
| Ran live-service operations | Inflated form of F5 and F1 | The puzzle-studio quote and the content-drop quote, each at its own scope. |
| Led a team | Negative you stated, F9 | "I haven't led a team." No slot. |
| Worked on a game with in-app purchases | Negative you stated, F10 | "I haven't worked on a game with in-app purchases." No slot. |

## Interviewer read

- **Public footprint:** a GDC 2026 talk, "Patch Notes Are a Promise." Its argument: a live team is judged by how often its patch notes describe what actually shipped. Previously a QA lead at a console studio (per the talk listing).
- **Implications:**
  1. Your checklist story (F4) is the strongest bridge into this interviewer's own argument. Lead with what the checklist checks, not with the fact that QA uses it.
  2. Expect questions about QA-to-release discipline. Describe what you did, not what the checklist "proves."
  3. The shared professional concern is release honesty, not a shared background.
- **Mirror opportunity:** their talk's claim and the company value "Ship the Patch Not the Promise" say the same thing. Use the company's words once, then describe your own practice.

## Persona table

| Persona | How it shows up here | Likelihood | Reasoning | Counter-strategy |
|---|---|---|---|---|
| Case / Strategist | The 60-minute Outage Hour tabletop on a live-event incident | High (about 40%) | The loop page names a live-incident tabletop as the core of the hour | Clarify, then structure, then metrics; think aloud; name one risk. See A1. |
| Values / Behavioral | The values conversation that follows the tabletop | High (about 25%) | The loop page names a values conversation; the company publishes three values | Map each value to a real decision; hard truths over harmony. See B1, B2. |
| Skeptic | Probes on the stated gaps: no team leadership, no IAP | Medium (about 20%) | Hiring-manager priors plus two stated absences | Hold the one objection; bridge only with what you stated; name the ramp plan. See C1, C2. |
| Data-Driven Prober | Asks how the retention figure was counted | Medium (about 15%) | The retention presentation is a headline claim on your CV | Say how you know, and where you do not. See D1. |

## Question banks

### A: Case / Strategist (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "It's the evening of a live event. Players in one region report that rewards are not granted. Walk me through your first thirty minutes." | CASE | [generic] | Structure: clarify scope and who is affected; decide whether to pause or hotfix; name the owners you would pull in (engineering, live ops, community, QA); say what you would tell players and when; name the post-event review you would run. Think aloud, challenge one premise. Make no claim about past incidents. | The Outage Hour's tabletop; a live problem from the role, so it presupposes nothing about your past. |
| A2 | "What would you need to know first about this event?" | CASE | [generic] | Name three facts: scope, whether rewards are virtual or tied to a store purchase, and what players were told. Ask for them before proposing fixes. | Tests clarify-before-structure, the main scored behavior in a case. |

### B: Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time the calendar and the players disagreed." | VAL | [grounded] company value "Players Before Plans: when the calendar and the players disagree, the players win." (values page) | Selection scaffold: pick a moment where a planned drop or date conflicted with what players needed; say what you chose and why. If no such moment comes to mind, say so plainly, then give the nearest thing your material carries: the weekly content-drop calendar you ran. | The open prompt's theme comes from the published value. Your material does not show the outcome, so do not supply one. |
| B2 | "Tell me about a checklist you wrote and what it was for." | EXP | [grounded] "Wrote the release checklist our QA team still uses." (your message) | Say what the checklist covers, who uses it, and what changed in how it is used. Answer slot: if it caught a specific release problem, say what it caught; if you cannot point to one, say so plainly. | Connects to "Ship the Patch Not the Promise" and to the interviewer's talk. F4 is the evidence. |

### C: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You haven't worked on a game with in-app purchases. How would you run an event where players pay for rewards?" | JD | [grounded] "I haven't worked on a game with in-app purchases." (your message) | Hold: "I haven't worked on one." Then how you would learn it: talk to the monetization owner, read the store-side rules, review how past events were priced. Concede plainly: you do not know their rewards economy yet. Hold through two follow-ups; never imply IAP experience. | F10. This is the likeliest objection; the deepest rehearsal here. |
| C2 | "You've never led a team. How do you coordinate four disciplines without authority over them?" | JD | [grounded] "I haven't led a team." (your message) | Hold the stated fact, then describe how you would coordinate: shared calendar, one owner per update, written decisions. Present it as a plan, not a past. | F9 and the JD's "coordinate" line. Do not claim team leadership. |

### D: Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "How was the retention number you presented counted, and which assumption would you defend least?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." (your message) | Weakest-assumption move: name, in your own words, the assumption you would defend least before they find it. Answer slot: if you know how the figure was counted, say how; if you do not, say so plainly and say what you would check. | F7. Never explain a counting method you cannot repeat under a second question. |

## Values cheat sheet

Company values, from the values page.

| Value (official name) | Working meaning | Mapped story |
|---|---|---|
| Players Before Plans | When the calendar and the players disagree, the players win | Selection scaffold, B1: a moment where a planned drop conflicted with players. If none, say so, then give the content-drop calendar you ran. |
| Ship the Patch Not the Promise | Announce what is built, not what is hoped | F4 evidence: "Wrote the release checklist our QA team still uses." Describe what the checklist gates, in your words. |
| Leave the Build Greener | Every release leaves the codebase and checklist better than it found them | F4 evidence, same quote. Answer slot: if you changed the checklist after a release, say what changed; if you did not, say so and say what you would change first. |

## Reverse questions

1. "How does the Outage Hour weigh the tabletop against the values conversation?" Why it lands: shows you read the loop page.
2. "How does the post-event review feed the next calendar cycle?" Why it lands: tests whether you understand the KPI ownership in the JD.
3. "What did the last live event miss, and what changed in the checklist afterward?" Why it lands: links to the company's release-honesty value.
4. "Which two titles would I own first, and what is each one's retention picture right now?" Why it lands: shows you are thinking about the actual job.
5. "In your GDC talk you argued patch notes should describe what shipped. Where does that break down on your team today?" Why it lands: ties to the interviewer's own published path.

## Requirement coverage

| JD requirement | Covered by | Note |
|---|---|---|
| Plan and run the live-events calendar for two titles | F1, A1 | Gap is transferability: one title |
| Coordinate design, art, engineering and community | F2, A1 | Discovery; answer slot |
| Own the post-event review and KPIs | F3, reverse Q2 | Transferability |
| Manage the release checklist with QA | F4, B2 | None |
| 3+ years producing live-service games or apps | F5 | Transferability; not a gate |
| Experience running a content calendar | F6 | None |
| Comfortable with player-retention metrics | F7, D1 | Presentation |
| Clear written communication | F8 | Discovery; a sample would help |

## Sources

Provided documents: your message (background, JD text as pasted, stated gaps).

| Query or fetch | Returned |
|---|---|
| Search: "Saltmarsh Games mobile studio" | No results found |
| Search: "Tobias Wrenfield Head of Live Operations" | GDC 2026 talk listing, "Patch Notes Are a Promise," Tobias Wrenfield, Head of Live Operations at Saltmarsh Games, previously a QA lead at a console studio |
| Search: "Saltmarsh Games values interview process" | saltmarshgames.com/careers/interviewing; saltmarshgames.com/values |
| Fetch: saltmarshgames.com/careers/interviewing | Loop: recruiter call, then the 60-minute Outage Hour with the hiring manager (live-incident tabletop, then values conversation); no take-home |
| Fetch: saltmarshgames.com/values | Values: Players Before Plans; Ship the Patch Not the Promise; Leave the Build Greener (with working meanings) |

Research tier: L1 — searches 3 of 6, fetches 2 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. saltmarsh values | yes | Values cheat sheet; B1, B2 anchors |
| 2. saltmarsh interview process | yes | Persona weights (Outage Hour structure); A1 format |
| 3. saltmarsh strategy / recent news | unavailable | Not searched: the budget went to targets 1, 2 and 4. Would have moved the CO bank and the reverse questions. |
| 4. Tobias Wrenfield Saltmarsh | yes | Interviewer read; reverse Q5; persona weighting |
| 5. representative JD | skipped | The JD you pasted fixes the fit snapshot and JD-tagged questions |

Not established: the first query returned no results, so company size and any other company facts are not used in this pack.

## Upgrade menu

- Confirm whether Tobias is your hiring manager → persona weights are recomputed from that relationship
- A sample of the release checklist, or a description of its gates → F4 moves from medium to high, and B2 gets a stronger story
- A piece of writing you produced for a wider audience → F8 moves from discovery to a checkable sample
- Whether the puzzle title ran post-launch content → F5 becomes grounded beyond the content drops
- The recruiter's note on focus areas → confirms or changes the tabletop and values weights
