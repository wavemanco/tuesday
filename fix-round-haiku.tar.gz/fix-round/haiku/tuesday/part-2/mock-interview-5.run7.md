Your prep pack is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-tuesday-part-2-rooms-case-5-denied-ad4c55cd/f4540637-c38a-4cf4-8a2f-82c797822148/scratchpad/kelverton-rail_senior-partnerships-manager_interview_pack.md`.

The short version: the rail gap is the thing to rehearse most. Deepa will likely ask why operators should pick you over someone who has sold into rail. Your honest answer is "I haven't sold into rail," then the ISV channel bridge, then a concrete ramp plan. Ross will likely probe how the £4M was counted. The pack gives you a plan for that: say what you know, say what you don't, and name the weakest assumption before he does.

For the 15-minute POV, I wrote three theses, each with a concession. My recommendation is "operators as users, not only buyers," or "fewer, deeper operator partners before breadth" if you're comfortable saying no to the 40-partner playbook. The pack is built around the recruiter's brief you quoted. Web research was refused in this session, so it has no company values, interview process or recent strategy. The POV's "consensus answer" can't be checked until I have the market report.

Two things would most improve the pack:

1. Can you paste the job description, or confirm there isn't one? Without it, there are no gate rows, and some requirements come from your summary of the brief.
2. Can you paste the market report, or at least its operator sections? Then I can check the POV against what everyone else will probably say.

Say the word and I'll play Ross on the £4M questions (C1 to C4), or Deepa on the rail objection (B1), which the pack names as the highest-value rehearsal. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, and convert the pack to Word if you want it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: kelverton-rail_senior-partnerships-manager_interview_pack.md -----
# Interview prep pack: Senior Partnerships Manager, Kelverton Rail

Second-round panel, Tuesday. Deepa (VP Partnerships, future manager) and Ross (Commercial Director). 60 minutes: first 15 minutes a spoken POV on operator partnerships over 18 months, no slides; rest is Q&A, with Ross pressing on commercials.

Built from: your message (background, the recruiter's brief as you quoted it). Not built from: the market report (you read it; it is not in this conversation) or a job description (none pasted). Web research was attempted and refused (see Sources).

## 1. How to use + type key

Personas describe how a question arrives; types describe what it scores.

- **EXP**: work-experience deep-dive. Tests whether your claims survive scrutiny.
- **JD**: role-driven. Tests stated responsibilities, including gaps.
- **CO**: company and strategy knowledge. Not covered here, because research did not run.
- **CASE**: live problem. Tests structure, not your past.
- **VAL**: values alignment. Not covered; see section 6.

Guidance is scaffolding, not a script. Rehearse what you actually did, in your own words.

## 2. Prep triage (about 4 hours)

In order:

1. **75 min: POV.** Pick one thesis from section 5 and write it as three spoken beats. Include the concession. Do not write it out in full.
2. **60 min: POV drill, twice, timed at 15 min.** Say it aloud, not on paper. Record one run if you can.
3. **45 min: Ross commercials bank, C1 to C4 and D2.** Know exactly how the £4M was counted, and what you cannot say.
4. **30 min: the rail gap, B1 and B2.** This is the highest-ROI rehearsal in the pack. Say the plain sentence, then the bridge, then stop.
5. **30 min: opener and reverse questions, E1 and section 9.**

Everything else is insurance.

## 3. Fit snapshot

Requirements here come from the recruiter's words as you quoted them, and from your own description of the company. No JD was supplied, so there are no gate rows, and no requirement is quoted from a JD.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "where you'd take our operator partnerships over the next 18 months" (your message) | "took it from 6 partners to 40, roughly £4M of influenced revenue" (your message) | medium | [grounded] | transferability | The adjacent work is an ISV partner channel, not operator partnerships. Say it at its own scope: "I took the ISV channel from 6 partners to 40." Answer slot: a probe on operators is likely. If any of your work involved operator-side partners, say what it was; if none did, say so and describe how you would run the first 90 days. |
| F2 | "what it means for the operators themselves" (your message) | "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" (your message) | medium | [grounded] | presentation | The line exists; only its wording needs to fit the requirement. Say: "I spent five years as a consultant planning bus and light rail networks." Limit to state aloud: that was the consultant's view of operators, not an operator's. |
| F3 | "Ross will push on commercials" (your message) | "took it from 6 partners to 40, roughly £4M of influenced revenue" (your message) | medium | [grounded] | transferability | Influenced revenue is adjacent to the commercial ownership Ross will press on, not the same thing. Answer slot: the £4M raises a defend-the-number probe; say how it was counted, and which part was yours. |
| F4 | "sell scheduling software to train operating companies" (your message, describing the company) | "Never sold into rail specifically" (your message) | none | [grounded] | capability | A gap you stated. Words: "I haven't sold into rail." Then how you would learn the buying cycle, as a plan, never as a past. |
| F5 | Carrying a direct revenue target (role-family pattern, [generic]) | "never carried a direct quota, only influenced revenue" (your message) | none | [grounded] | capability | A gap you stated. Words: "I haven't carried a direct quota." Then what you would commit to in its place. |

## 4. Prohibited claims

Each entry names its basis and its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned operator partnerships | Inflated form of F1 | F1's quote at its own scope: the ISV channel. The limit is the pack's observation, not a first-person negative: the material says ISV partners, not operators. |
| Sold into rail, or built operator relationships | Negative you stated, F4 | "I haven't sold into rail." No slot. |
| Carried or hit a quota | Negative you stated, F5 | "I haven't carried a direct quota." No slot. |
| Knows the operator world as an operator | Inflated form of F2's quote | F2's quote at its scope: a consultant's view. Never "I was on the operator side." |
| Sourced or direct £4M | Inflated form of F3 | The quote as written: influenced revenue. Any answer about how it was counted comes from you, in your words. |

## 5. Graded deliverable: the 15-minute POV

Facts to build on: F1 and F2 (quoted above). The brief asks for what it means for operators, so the close is the operator's outcome.

Consensus answer: not assessable. The market report you read is not in this conversation, so the pack cannot say what the consensus shortlist is. Paste it (section 10) and this section can be tightened against it.

**Thesis A: operators as users, not only buyers.** Partner with the people who run the timetable, not only the people who sign. Concession: "I don't yet know how much of your product runs in operators' day-to-day planning. I'd test that in the first month before I commit to a plan."

**Thesis B: fewer, deeper operator partners before breadth.** Concession: "Breadth took the ISV channel from 6 to 40. I wouldn't assume rail rewards the same, because I haven't sold into rail." Anti-pick: "I wouldn't run the 40-partner playbook here. I'd go deep with two or three operators first."

**Thesis C: make the case in the operator's own cost line.** Concession: "I don't know yet whether the operator or a wider rail body holds the budget for this. That is a first-month question."

Recommended: A or B. Use B only if you are comfortable with the anti-pick, since it is the one that says no.

Requested close: "what it means for the operators themselves." Close on the outcome a planner feels, and say how you would check it. Do not name an outcome the company has not published. The outcome is a pattern, not a claim about this company.

Suggested shape (15 minutes): 1 minute opening; 3 minutes operator-first framing; 6 minutes the three moves; 3 minutes what operators get; 2 minutes what you would need to learn first. Leave two minutes slack.

## 6. Values cheat sheet

Not included. No values-style round is established: the recruiter's brief names a POV and Q&A, not a values round, and no company values were read. Research was refused, so no published values are in hand.

## 7. Reading the interviewers

No profiles were supplied, so personas use role priors. Public footprint would sharpen both weights; see the upgrade menu.

## 8. Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist (Deepa) | Live problem on operator partnerships | High. The hiring manager prior is capability and the roadmap. | Clarify, then structure, then answer. Say the framework aloud. |
| Skeptic (Deepa) | "Why not someone who's sold into rail?" | High. The rail gap is the obvious objection, and it is in your own message. | Plain sentence, bridge from F1 and F2, then a ramp plan. |
| Data-Driven Prober (Ross) | Asks how the £4M was counted | High. Commercial directors test headline figures. | Say what you know and what you don't. Name the weakest assumption first. |
| Pressure (Ross) | Time-boxed challenge on commercials | Medium-high. Ross will push, per the brief. | Hold for two follow-ups. Concede specifically. |
| Conversational (either) | Opener: "walk me through the journey" | Medium. It is scored, even when casual. | A 90-second arc. |

## 9. Question banks

Weights: Deepa's bank is 7 (Case 4, Skeptic 3). Ross's bank is 9 (Prober 4, Pressure 3, Case 2). Plus 2 openers. Total 18.

### Deepa: Case / Strategist (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Sketch the first 90 days of operator partnerships here. What do you need to know first?" | CASE | [generic] | Clarify first: which operators, which products, what the current pipeline is. Then objective, segmentation, approach, metrics, risks. Name one premise you would test. | Case-led hiring manager; the question presupposes nothing about you. |
| A2 | "Which operator segment would you start with, and why?" | CASE | [generic] | Pick one segment, give two reasons, name the one you'd be wrong about. | Tests judgment on the operator side the brief asks about. |
| A3 | "Operator adoption has been flat for two quarters. Diagnose it." | CASE | [generic] | Split the funnel first: awareness, pilot, renewal. Name what you would ask the partners before the operators. | A live problem; asks nothing about your past. |
| A4 | "What would you tell us about operators that we can't see from the scheduling side?" | EXP | [grounded] "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | Use the consulting work only at its scope: "I planned networks; I didn't run an operator." Answer slot: say what you saw from the planning side, in your own words. | F2 is the evidence; the limit is the consultant's view, said aloud. |

### Deepa: Skeptic (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've never sold into rail. Why would operators pick you over someone who has?" | JD | [grounded] "Never sold into rail specifically" | **Highest-ROI rehearsal in this pack.** Say the plain sentence: "I haven't sold into rail." Bridge from F1: "I took the ISV channel from 6 partners to 40." Ramp: name the first thing you'd learn. Hold through two follow-ups. Concede specifically: "I can't say yet which operator would buy first." Never claim rail experience. | F4 is the rail gap, and the question will come in some form. |
| B2 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never sold into rail specifically" | Name the buying cycle, and the operator's procurement path, as the first thing to learn. Keep it to the rail gap you stated. | Skeptic stem; answers the same gap in a different form. |
| B3 | "Why leave a payments company for rail, and why now?" | EXP | [grounded] "running the ISV channel" | Give the motivation in terms of the operator-side work you have done, not a grievance. Say what you want to learn. | A motivation probe; you ran the ISV channel, and the answer should follow that. |

### Ross: Data-Driven Prober (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the £4M of influenced revenue was counted." | EXP | [grounded] "roughly £4M of influenced revenue" | Answer slot: how it was counted; what it is sensitive to; the assumption you would defend least; which part was yours. If you know, say it. If you don't, say so, plainly. | F3 is the commercial evidence; a figure raises these four probes. |
| C2 | "Which assumption behind the growth from 6 partners to 40 would you defend least?" | EXP | [grounded] "took it from 6 partners to 40" | Name the weakest assumption before he does. Use your own words. | Metric move: converts a gotcha into a credibility gain. |
| C3 | "Of the 40 partners, how many did you personally bring in?" | EXP | [grounded] "took it from 6 partners to 40" | Answer slot: what you led and what the team did. If you don't have the number, say so. | The quote says "took it"; the premise is scoped to that. |
| C4 | "Your number is influenced, not sourced. What would a sourced number look like here?" | JD | [grounded] "never carried a direct quota, only influenced revenue" | Say what you would track, and what you cannot yet commit to. Do not claim a figure. | F5 is the stated gap; the question is the commercial one. |

### Ross: Pressure (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why should we believe a payments channel result transfers to rail?" | EXP | [grounded] "took it from 6 partners to 40" | Pause. Restate the question. Hold on what the channel mechanics were. Concede: "It may not transfer. Here is what I would test first." | Pressure stem; tests composure, not content. |
| D2 | "That £4M. How much of it was actually you?" | EXP | [grounded] "roughly £4M of influenced revenue" | Hold: "I ran the channel that generated it." Concede: influenced, not sourced. Do not fold on the part you ran. | Hold-then-concede; the second follow-up is where a held position breaks. |
| D3 | "We'll want a number from you on day one. What are you committing to?" | JD | [grounded] "never carried a direct quota, only influenced revenue" | Commit to a plan with a date, not to a quota you haven't carried. | Pressure on F5; the honest hold is the plan. |

### Ross: Case / Strategist (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1Q | "Operators are cash-constrained on new tools. How would you price a partner deal?" | CASE | [generic] | Clarify the pricing model first. Name the trade-off between price and adoption. Say what you'd test. | Commercial live problem; asks nothing about your past. |
| F2Q | "A partner channel signs 20 operators and none convert to renewal. What's your first hypothesis?" | CASE | [generic] | Split the funnel into signing, deployment and renewal. Name the one you would check first. | Commercial case, framed as a diagnosis. |

### Openers (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | JD | [grounded] "9 years in partnerships"; "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)"; "took it from 6 partners to 40" | 90-second arc: consulting on the operator side, then partnerships, then the ISV channel, then why this. Each beat is one of your quoted sentences. | Scored even when casual. |
| E2 | "What's exciting you in partnerships at the moment?" | JD | [generic] | Give one real thing, not a trend. | A casual question about a hot topic; scored. |

### Coverage

| Requirement | Covered by | Note |
|---|---|---|
| Operator partnerships over 18 months | A1, A2, A3, F1Q, F2Q | Supported by F1; limit stated. |
| What it means for operators | A4, E1, POV close | F2. |
| Commercials | C1 to C4, D2, D3, F1Q, F2Q | F3 and F5. |
| Selling into train operating companies | B1, B2 | F4. |
| ISV channel scale | C2, C3, E1 | F1. |
| Mid-list requirements | none | No JD supplied, so none can be listed. |

## 10. Reverse questions

Each lands for a reason.

1. "What would success look like at six months, in terms an operator would notice?" Lands: it frames the operator outcome.
2. "Which operator relationships are strongest today, and what made them work?" Lands: it shows you want the partnership depth, not only the pipeline.
3. "How does commercial responsibility split between partner-sourced and direct revenue?" Lands: it is Ross's question, asked as a question.
4. "What have operators told you about the scheduling product that sales hasn't heard?" Lands: it goes straight to the operator view.
5. "Where has the partnership model failed before, and what did the team learn?" Lands: it signals you expect real answers.

## 11. Sources

- Provided documents: your message (background; the recruiter's brief as you quoted it). The market report was not in the conversation, so it was not used.
- Searches sent, all refused: "Kelverton Rail values"; "Kelverton Rail interview process partnerships"; "Kelverton Rail strategy news scheduling software train operators".

Research tier: L1 attempted, searches 0 of 6 returned results (3 calls refused), fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Kelverton Rail values | unavailable | Values cheat sheet (section 6). The values page would have named the principles by name. |
| 2. Kelverton Rail interview process partnerships | unavailable | Loop structure. Persona weights rest on your brief, not on a documented loop. |
| 3. Kelverton Rail strategy / recent news | unavailable | CO bank and POV differentiation. Section 5's consensus answer is not assessable. |
| 4. Interviewer names | n/a | No names were given, so there was no query to form. Deepa and Ross are named by role only. |
| 5. Representative JD | skipped | The fit snapshot's requirements come from your brief, and no JD was supplied to fix them. |

## 12. Upgrade menu

- The job description → gate rows, JD-tagged questions grounded, a real requirement-coverage line.
- The market report, or its operator sections → POV differentiation against the consensus answer, and a sharper thesis choice.
- Public professional footprints for Deepa and Ross → persona weights and a tailored reverse question.
- Permission to search (web research was refused this run) → company values, interview process and recent strategy, each of which would tighten sections 5 and 6 and the CO bank.
- Deeper research, if you want it: up to 6 more searches and 2 more fetches, several more minutes.
</content>
</invoke>
