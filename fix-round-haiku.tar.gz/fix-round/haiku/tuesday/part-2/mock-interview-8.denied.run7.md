Your prep pack is saved as `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-tuesday-part-2-rooms-case-8-denied-869f9735/4ed79443-31bd-488b-8892-68ad94c139e0/scratchpad/ashgrove_credit_union_member_experience_lead_interview_pack.md`. It covers all three rounds: 8 questions for the recruiter screen, 9 for the Head of Member Services, and 8 for the panel, including the escalation case and the values scoring. I built it from your message, the JD, the values text and the recruiter's email. I didn't run any web searches, since those inputs already covered what I needed.

The pack's main points:

- **Biggest gap: the end-to-end scope.** The JD asks you to own the complaints process across branches and the contact centre. Your material shows one branch's formal complaints log. Expect the Head of Member Services to press on this. The pack gives you the exact concession to make and a plan for your first month.
- **Two gaps you stated yourself:** presenting above regional level, and contact-centre work. The pack gives you plain acknowledgments and plans, and nothing that sounds more experienced than you are.
- **Strongest material:** six years in retail banking, the complaints log, the tellers you trained, and the monthly spreadsheet your regional manager uses. The spreadsheet is the thing to bring if you can show it. The pack doesn't say what it counted, so know the answer before round 2.
- **Values round:** your sentences don't carry a full story for any of the four values. The pack gives you the nearest sentence for each, plus an honest "I don't have one" branch. The Neighbours, Not Numbers probe is the one most likely to catch a numbers-heavy background.

Things I left out or couldn't do:

- **No prep triage.** I don't know how many hours you have. Tell me and I'll size one.
- **No interviewer read.** Names for the Head of Member Services and the two branch managers aren't set yet.
- **Regulated complaints.** The timescales and referral routes depend on the regulator where Ashgrove operates, and I don't know that. Check its rules before round 3.
- **Strategy brief.** I worked from your summary, not the brief itself. Check the exact wording before you quote any figure.

Offers, none pushed:

- **Drill:** I can play the Head of Member Services on R2-S1, the question the pack names as highest-ROI prep, and give feedback against its guidance.
- **Dossier:** I can save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions.
- **Word:** I can convert the pack to a .docx.

Watch-out: Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove_credit_union_member_experience_lead_interview_pack.md -----
# Ashgrove Credit Union: Member Experience Lead interview prep pack

**Candidate:** Dara
**Role:** Member Experience Lead, Ashgrove Credit Union (member-owned, about 900 staff)
**Format:** Loop mode, three rounds on 20 November 2026
1. Recruiter screen, 30 min
2. Head of Member Services (your future manager), 45 min, mostly behavioural
3. Panel of two branch managers, 60 min, including a 20-minute complaint-escalation case; scored against the four values

Interviewers for rounds 2 and 3 are not named yet, so there is no interviewer read.

## 1. How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored: VAL (behavioural and values), EXP (your own work, probed), JD (a stated requirement), CO (company and strategy), CASE (a live problem).
- **Guidance is scaffolding, not a script.** Say it in your own words.
- **"Answer slot"** means the honest answer has two branches: if you did it, say how; if you didn't, or it wasn't yours, say so plainly. The pack never supplies the practice itself.
- **Source labels:** "your message" is the background you gave me on 11 November; "JD" is the job description you pasted; "recruiter" is the process email; "values" is the text you copied from the values page; "brief" is your summary of the July 2026 strategy brief.

## 2. Type key

| Tag | Meaning in this pack |
|---|---|
| VAL | Behavioural / values: past behaviour against a published value |
| EXP | Your work, probed for attribution |
| JD | A requirement from the job description |
| CO | Company strategy and context |
| CASE | A live problem from the role, no claim about your past |

## 3. Fit snapshot

**The biggest gaps,** in order: the end-to-end scope the JD asks for (F1, F9), presenting above regional level (F8), and digital and self-service work (F7). The biggest strengths on paper: six years in retail banking (F3) and a reporting spreadsheet already in use (F4, F5).

Regulated complaints (F2) depend on the rules and timescales of the regulator where Ashgrove operates, which your material does not name. [generic] The regulator's rules are not in the material; check them before round 3.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches and the contact centre" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | transferability | Your material says one branch's formal complaints log, not an end-to-end process across branches and the contact centre. Words: "I handled the branch's formal complaints log." Answer slot: this is the line the panel will probe. If you carried any part of the process beyond your branch, say which part and how, in your own words; if not, say so plainly and stay with the log. |
| F2 | "experience handling regulated complaints" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | presentation | The quote reaches complaints in other terms; your material does not say "regulated." Words: "I handled the branch's formal complaints log." Answer slot: the JD raises regulated complaints, so expect a probe on timescales and referral routes. If the log ran to a regulator's timescales or a referral route, say which and how; if not, say so and describe how the log was run. |
| F3 | "4+ years in financial-services customer operations" (JD) | "6 years in retail banking, the last 3 as a branch supervisor" (your message) | medium | [grounded] | none | The quote reaches the requirement in role-relevant terms. Probe likely: whether branch work counts as customer operations. Words: "6 years in retail banking, the last 3 as a branch supervisor." |
| F4 | "report monthly on complaint volumes and resolution times" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | medium | [grounded] | presentation | The quote reaches monthly reporting in other terms; it does not say what the sheet counted. Words: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: the JD raises volumes and resolution times. If the sheet counted either, say which and how; if not, say so plainly. |
| F5 | "comfortable with Excel reporting" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | medium | [grounded] | presentation | The quote reaches reporting in other terms; no tool is named. Words: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: if you can name specific things you did in it, say them; if not, name none. |
| F6 | "coach branch supervisors on escalations" (JD) | "trained new tellers on our escalation script" (your message) | medium | [grounded] | transferability | Adjacent work: you trained tellers, not supervisors. Words: "I trained new tellers on our escalation script." Answer slot: the JD raises coaching supervisors. If you have coached a supervisor on an escalation, say how; if not, say so and describe what you did train. |
| F7 | "work with digital teams on self-service journeys" (JD) | none given | none | [grounded] | discovery | Your material does not show this. Answer slot: if you worked with anyone on digital or self-service, say what and what your part was; if not, say so plainly and say how you would start. |
| F8 | "confident presenting to senior leaders" (JD) | "I've never presented to anyone above regional level" (your message) | none | [grounded] | capability | A gap you stated. Words: "I've never presented to anyone above regional level." No answer slot. How you would build it is a plan, said in the future tense. |
| F9 | The role spans "the contact centre" (JD) | "Never worked in a contact centre" (your message) | none | [grounded] | capability | A gap you stated. Words: "I've never worked in a contact centre." How you would learn it is a plan, said in the future tense. |

**Gate rows:** none. The JD ties no legal, credential, location or schedule term to a bar.

## 4. Prohibited claims

These are not to be coached. Each one has a basis and an honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end across branches and the contact centre | Inflated form of F1 and F9 | "I handled the branch's formal complaints log," at its own scope. Your material says one branch's log; that is the limit. |
| Coached branch supervisors on escalations | Inflated form of F6 | "I trained new tellers on our escalation script." |
| Reported resolution times monthly | Inflated form of F4; the quote does not say what the sheet counted | "I built the monthly complaints spreadsheet our regional manager uses." |
| Handled regulated complaints | Inflated form of F2 | "I handled the branch's formal complaints log." |
| Presented to senior leaders | Negative you stated, F8 | "I've never presented to anyone above regional level." No slot. |
| Has worked in a contact centre | Negative you stated, F9 | "I've never worked in a contact centre." No slot. |

## 5. Grounding brief

Your summary of Ashgrove's July 2026 strategy brief, which the recruiter sent. I have not seen the brief itself, so check its exact wording before you quote any figure.

- Move 40% of member service to digital channels by 2028.
- Consolidate eight branches into five hubs over 2027.
- Launch a small-business lending product in Q1 2027.
- Main competitive pressure: app-only banks.

Use this vocabulary; don't coach yourself to correct the interviewer if they describe the plan differently.

## 6. Persona table

| Round | Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|---|
| 1 Recruiter | Conversational | Friendly opener, "walk me through," casual questions on JD topics | High. Recruiter screens use a friendly register, and the questions are still scored | Pre-scripted 90-second arc from your own sentences; treat casual JD questions as scored |
| 1 Recruiter | Skeptic (light) | "Why this role, why now," and the gaps | Medium. F8 and F9 show on the page | Plain acknowledgment, then the plan |
| 2 Head of Member Services | Skeptic | "Why would you run an end-to-end role from one branch's log?" | High. A hiring manager buys capability and derisks gaps; F1 is the biggest visible gap against the headline requirement | Hold through two follow-ups, then concede the scope exactly |
| 2 | Case / Strategist | A live problem on the hub plan or digital | Medium to high. This round is "mostly behavioural," so cases are likely brief | Clarify, objective, segmentation, approach, metrics, risks; say the framework aloud |
| 2 | Values / Behavioural | "Tell me about a time…" | Medium. Stated as mostly behavioural | STAR shape; "we" for context, "I" for your part |
| 3 Panel | Values / Behavioural | Scored against four values | High. The recruiter says the panel scores against the values | One honest story per value where your sentences carry one; a scaffold with its honest branch where they don't |
| 3 | Case / Strategist | The 20-minute escalation case | High. The recruiter named it | Clarify before solving; name who holds the complaint now |
| 3 | Pressure (light) | Challenge to the figure you built, or to the gaps | Medium. Two panellists often split: one probes, one challenges | Hold, then concede |

## 7. Round 1: recruiter screen (8 questions)

Weights: Conversational 4, Skeptic 3, Case/CO 1.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R1-A1 | "So, walk me through your background." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "I handled the branch's formal complaints log"; "trained new tellers on our escalation script"; "I built the monthly complaints spreadsheet our regional manager uses" (all your message) | A 90-second arc from those four sentences, in your own words, in that order: years and role, the complaints log, the tellers you trained, the spreadsheet. Stop there. Don't add a story to fill time. | The conversational opener is scored. Staying with these four sentences keeps the arc to what you can defend in round 2 (F3, F1, F6, F4). |
| R1-A2 | "Why this role, and why now?" | VAL | [generic] | Answer from what the role uses that you have already done: the complaints log and the monthly report. Name one value from the values page that you relate to, and say why in your words. Answer slot: if your reason is about your next step in your career, say what that step is. | A motivation check from a Skeptic-lite. The values page is a raising source. |
| R1-A3 | "Our brief says 40% of member service moves to digital by 2028. What would that mean for complaints?" | CO | [generic] | Structure aloud: which complaints move with the channel (volume, resolution time, where a member gets stuck). Then say what you would check first, starting from the monthly report. Do not claim work on digital complaints; see F7. | The brief was sent by the recruiter, so the question may presuppose the plan. Strategy fluency is the differentiator here. |
| R1-A4 | "You've never worked in a contact centre. How would you run complaints that come through one?" | JD | [grounded] "Never worked in a contact centre" (your message) | Plain acknowledgment: "I've never worked in a contact centre." Then the plan, in the future tense: how you would learn the handoffs and the complaint routes. | F9. The negative is yours to give back; the question presupposes only what you stated. |
| R1-A5 | "You haven't presented above regional level. How do you feel about senior audiences?" | JD | [grounded] "I've never presented to anyone above regional level" (your message) | Plain acknowledgment: "I've never presented to anyone above regional level." Then the plan: how you would prepare. Don't claim comfort you haven't shown. | F8. The JD names this as a requirement. |
| R1-A6 | "What are you playing with in Excel these days?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" (your message) | Say what the sheet does: what it reports each month and who uses it. Answer slot: if you can name specific features you used, name them; if not, name none. | F5. A casual question on a stated requirement is still scored. |
| R1-A7 | "Which part of complaints work do you enjoy most?" | VAL | [grounded] "I handled the branch's formal complaints log" (your message) | Pick one part of the log you handled and say why it matters to the member behind it. Keep it to what you handled. | A rapport question that tests whether your interest is in the member's outcome or the metric. |
| R1-A8 | "Is anything about this role worrying you?" | JD | [grounded] "Never worked in a contact centre"; "I've never presented to anyone above regional level" (your message) | Name the two gaps plainly, each with its plan. Don't offer a third. | Calibrated candour is what the Skeptic scores. These are the two gaps you stated. |

**Reverse questions (round 1)**

1. "How is complaints work split between the branches and the contact centre today?" Why it lands: it shows you read the end-to-end line and want the real split.
2. "What would make the first three months a success for this role?" Why it lands: it shows you think in outcomes.
3. "Which measure do leaders look at first each month: volumes or resolution times?" Why it lands: it shows you know both are in the JD, and the recruiter can answer.
4. "How does the plan to consolidate branches into hubs change complaints handling?" Why it lands: it shows you read the brief. Ask it as a question, not a claim about the plan.
5. "Who works with the digital team on self-service journeys now?" Why it lands: it shows interest in the digital requirement.

## 8. Round 2: Head of Member Services (9 questions)

Weights: Skeptic 4, Values / Behavioural 3, Case / Strategist 2. This is your manager, so the questions are about how you would do the job, not whether you are impressive.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R2-S1 | "This role owns the complaints process end to end across branches and the contact centre. Your background is one branch's log. Why would you run it?" | JD | [grounded] "I handled the branch's formal complaints log" (your message); the requirement is quoted from the JD | **Highest-ROI prep in this pack.** Hold the position you can defend: "I handled the branch's formal complaints log." Concede the scope exactly: "That was one branch, and the contact centre is new to me." Answer slot: if you carried any part of the process beyond the branch, say which and how, in your own words; if not, say so plainly, then say what you would set up first in month one. Hold through two follow-ups by returning to the log. Do not add to it. | F1 and F9 together are the biggest gap against the headline requirement, so this is the likeliest objection. The concession has to be exact. |
| R2-S2 | "Presenting to senior leaders is in this job. What's your experience of that?" | JD | [grounded] "I've never presented to anyone above regional level" (your message) | Plain acknowledgment: "I've never presented to anyone above regional level." Then the plan: for example, presenting a complaints summary to your regional manager first, then to someone higher. Don't claim comfort. | F8. The negative is yours. |
| R2-S3 | "You've been a branch supervisor for three years. Why leave that for a role across branches and a contact centre?" | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" (your message) | Answer from the role's content: the complaints work it adds, at a bigger scope. Don't speak against your current branch, and don't say you want to leave it. | A motivation-consistency check. |
| R2-S4 | "The reporting goes to senior leaders monthly. How would you make sure your numbers hold up?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" (your message) | Say what the sheet is used for, then the checks you would run on it. Answer slot: if it counted volumes or resolution times, say which and how it was counted; if it did not, say so. | F4. The Skeptic tests the one number you can defend. |
| R2-C1 | "Your brief has eight branches becoming five hubs in 2027. A member writes in angry about a closure and a complaint that has been open for six weeks. What do you do first?" | CASE | [generic] | Clarify: what the complaint is about, whether it is linked to the closure, who holds it now. Then structure: ownership, contact with the member, the branch manager, the timescale, and what gets recorded so it doesn't repeat. Say the framework aloud. | A live problem from the role, and the hub plan. No claim about your past. |
| R2-C2 | "The brief wants 40% of member service in digital by 2028. A member can't finish a self-service journey. What do you look at?" | CASE | [generic] | Clarify the journey and where it fails. Check whether the failures show up as complaints. Name the data you would need, and how you would work with the digital team. No claim about past digital work. | The JD's self-service line plus the 40% target. |
| R2-V1 | "Tell me about a time you owned a complaint from start to finish." | VAL | [grounded] "I handled the branch's formal complaints log" (your message); the value "Own the Fix" from the values page | Scaffold. The nearest thing your material carries is the log: say what came into it, what you did with one case, and how it ended. Only what you did. Answer slot: if you followed one case to a close, say what happened and what was yours; if no single case was followed through by you, say so plainly and describe the nearest one. | The JD's end-to-end line, and the value "Own the Fix." Your material carries no full story. |
| R2-V2 | "Tell me about a time you taught someone a process you were responsible for." | VAL | [grounded] "trained new tellers on our escalation script" (your message); the JD line "coach branch supervisors on escalations" | Story-mapped from the quote: the new tellers, then the escalation script. Answer slot: how you knew they could use it. If you checked, say how; if not, say so and say what you would check next time. Say "tellers," not "supervisors." | F6, the coaching requirement at its own scope. |
| R2-V3 | "How do you explain a complaint decision to a member who won't accept it?" | VAL | [generic]; the value "Plain Words" from the values page ("if a member needs it explained twice, we wrote it wrong") | Scaffold: pick a time you explained a decision and it landed. If your material doesn't carry one, say so and describe how you would explain it in plain words. | Plain Words is scored in round 3 as well. |

**Reverse questions (round 2)**

1. "What does a complaint closed well look like to you?" Why it lands: it shows you think about the member's side.
2. "Where do you most want complaints work to change in the first year?" Why it lands: it lets your manager name the priorities.
3. "How do branch supervisors bring escalations to you now?" Why it lands: it maps the coaching requirement onto the real process.
4. "As far as you can see, how will the hub plan change complaint volumes or routes?" Why it lands: it shows you read the brief, and it invites a cautious answer.
5. "What would you want the person in this role to have done by the end of month three?" Why it lands: it gives you a success measure, and it builds rapport.

## 9. Round 3: panel of two branch managers (8 questions)

Weights: Values / Behavioural 4 (values are scored), Case / Strategist 3 (the escalation case), Pressure 1.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R3-V1 | "When did you put a member ahead of an internal target?" | VAL | [generic]; the value "Members First, Always" from the values page | Scaffold: pick a time a member's outcome cost you something you could measure. If your material has no such time, say so, then give the nearest thing it does carry: the complaints log you handled. Honest branch. | The panel scores Members First. Your sentences carry no full story for it. |
| R3-V2 | "Tell me about how your branch fits into its town." | VAL | [generic]; the value "Neighbours, Not Numbers" from the values page; [grounded] "I built the monthly complaints spreadsheet our regional manager uses" (your message), which is the risk | No sentence in your material speaks to the town. Say so honestly, then describe what you actually know about your branch's customers, in your own words, if anything. Caution: a numbers-heavy background is exactly what this value tests. Don't let the spreadsheet be the whole answer. Answer slot: if you have a specific local detail, give it; if not, say so plainly. | This is the probe most likely to catch a numbers-heavy CV. A plain "I don't have one" is better than a made-up town. |
| R3-V3 | "Tell me about a time someone needed something explained twice." | VAL | [grounded] "trained new tellers on our escalation script" (your message); the value "Plain Words" from the values page | Scaffold from the teller training, which is the nearest sentence. Answer slot: if you ever changed the script or how it was taught, say what changed and why, in your own words; if not, say so plainly. | The panel scores Plain Words. |
| R3-C1 | "A member has complained twice, and both times a branch supervisor has closed it. They're still unhappy. You hold complaints across branches and the contact centre. What do you do?" | CASE | [generic]; the recruiter's "a 20-minute case on a complaint escalation" | Clarify first: what each closure said, what the member asked for, whether either decision was wrong. Then: who holds the complaint now (whoever finds the problem keeps hold of it until it's solved), what you tell the supervisor and how you would coach them, what you tell the member in plain words, what gets recorded, and how you check it is solved. Say the framework aloud. Name the regulator's timescales as a step to check. [generic] | This is the 20-minute case the recruiter named. It is scored on structure and values at once. |
| R3-C2 | "A branch manager says the monthly complaint figures are wrong. How do you check them?" | CASE | [generic] | Structure: which figure, what is counted, the definition, a sample of cases traced back to source records, and what you tell the manager. Name, in your own words, the assumption behind the figure you would defend least, before they do. If you know how a figure you built was counted, say so; if not, say that plainly. | A data-driven challenge. The weakest-assumption move is what separates a good answer. |
| R3-C3 | "How would you coach a branch supervisor who escalates everything?" | CASE | [generic] | Structure: look at the escalations and their reasons, have a conversation about which ones the supervisor can close, agree a simple rule they can use, and follow up after a month. Say the framework aloud. No claim about past coaching. | The JD's coaching line, as a live problem. |
| R3-P1 | "You've never worked in a contact centre, and you haven't presented above regional level. Why should we believe you can run this across both?" | JD | [grounded] "Never worked in a contact centre"; "I've never presented to anyone above regional level" (your message) | Hold, then concede. Hold on what you can stand behind: "I handled the branch's formal complaints log, and I built the monthly complaints spreadsheet our regional manager uses." Hold through two follow-ups. Concede plainly: "I haven't worked in a contact centre, and I haven't presented above regional level." Then the plan. Don't argue the negatives away. | F8 and F9 are the two gaps you stated. The pressure persona tests whether you can state them without folding or getting defensive. |

**Reverse questions (round 3)**

1. "What would you most want the new person to fix in the first 90 days of complaints work?" Why it lands: it lets the panel name the real problem.
2. "How do the two of you split decisions on escalations today?" Why it lands: it shows you care about who decides.
3. "What most often makes a complaint come back?" Why it lands: it shows you think about ownership, which is the Own the Fix value.
4. "How do branch managers see the complaints process working for their towns?" Why it lands: it links to Neighbours, Not Numbers.
5. "From your side, what makes an answer to the escalation case a good one?" Why it lands: it asks the panel how they score, which is useful if they're willing to say.

## 10. Values cheat sheet (round 3)

No quoted sentence carries a full story for any value. Each row names the nearest sentence and an honest branch.

| Value (official name) | Working meaning (paraphrase) | The candidate's mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | Scaffold, no quote carries a story. Nearest: "I handled the branch's formal complaints log" (F1). Honest branch: if you have no such time, say so plainly. |
| Plain Words | If a member needs it explained twice, we wrote it wrong | Scaffold. Nearest: "trained new tellers on our escalation script" (F6). Honest branch: if you have no time you changed an explanation, say so plainly. |
| Neighbours, Not Numbers | Every branch is part of its town | Scaffold, no quote speaks to the town. Honest branch: if you have no local detail, say so plainly. Don't build one. |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | Scaffold. Nearest: "I handled the branch's formal complaints log" (F1). Tie to the escalation case: who holds it, and when it's closed. |

## 11. Sources

**Provided documents:** the job description you pasted; the values text you copied on 11 November 2026 from ashgrovecu.org/about/values; the recruiter's process email (as you summarised it); your summary of the July 2026 strategy brief; your background message.

**Searches and fetches:** none. Every L1 target is fixed by provided material, so none was run.

Research tier: L1, searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove Credit Union values` | skipped | The values text you pasted already fixes section 10 |
| 2. `Ashgrove Credit Union interview process member experience` | skipped | The recruiter's email fixes the three rounds and the persona weights |
| 3. `Ashgrove Credit Union strategy` / recent news | skipped | The brief summary you gave already supplies section 5 |
| 4. Interviewer name and Ashgrove | n/a | No names given for rounds 2 or 3, so no query could be formed |
| 5. Representative Member Experience Lead JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## 12. Upgrade menu

- **Names of the Head of Member Services and the two panel branch managers** → a persona weighting for each panellist and an interviewer read from their public professional profiles. Public profiles only.
- **How many hours you have to prepare** → a prioritised prep triage sized to that time. Without it, I have built the whole pack.
- **A redacted copy of the complaints spreadsheet, or just its column headers** → raises F4 and F5 from medium toward high, and lets the pack quote what the sheet counted.
- **The country or regulator Ashgrove sits under** → names the actual complaint timescales and referral routes for F2 and R3-C1, instead of the generic step.
- **Whether the complaints log ran to a regulator's timescales or a referral route** → upgrades the answer slots in F1 and F2 and R1-A6.
- **A CV** → lets the claims carry artifacts, so the confidence bands can rise above medium.
- **Deep research (L2), offered once:** Ashgrove's latest public complaints disclosures and any published interview reports for this role family. Up to 6 further searches and 2 further fetches; a few minutes of your time for the results to read. Say yes and I'll run it.
