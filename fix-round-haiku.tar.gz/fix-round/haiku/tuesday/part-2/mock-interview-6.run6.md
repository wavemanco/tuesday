Your prep pack covers all three rounds and is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-tuesday-part-2-rooms-case-6-denied-85d43e86/61b6072f-6538-4596-98f0-75bb666a3ac1/scratchpad/larkfield_engineering_manager_interview_pack.md`.

I built it in loop mode: one shared fit snapshot, then a mini-pack per round with its own persona weights.

- **Round 1 (Director, 45 min):** Skeptic-heavy, with Case questions on rollouts, on-call sizing and hardware–product disagreements.
- **Round 2 (panel, 60 min):** Peer-style questions for the staff engineers, Prober questions on the 60% figure and design depth, and Case questions for the product manager.
- **Round 3 (VP, 30 min):** Values-heavy, with Pressure questions on your reliability push and a "why you over an internal candidate" hold.

**The three things most likely to decide it:**

1. **Managing managers.** You've never done it, and the role leads two squads. Expect this objection in round 1 and again in round 3. Rehearse the plain line, "I haven't managed managers," followed by a 90-day plan. Don't add to it.
2. **Hardware.** You've never owned a hardware-adjacent roadmap. Say that first, then how you'd learn it. Don't let a product-roadmap story stand in for hardware.
3. **The 60% on-call drop.** It's your headline number, so expect every follow-up on how it was counted and how much of it was yours. Say what you pushed, concede the share you can't attribute to yourself, and don't offer a counting method you can't repeat.

**Limits of this pack:**

- **No web research.** Every search was refused by the host, so there are no company values, no verified loop structure and no strategy. Round 3 uses the recruiter's wording only, and the strategy-specific questions are generic. If you grant search permission, I can run it and add those.
- **Built from your message only.** No CV, posting text or interviewer names. The requirements are quoted from your role summary, not the posting.

Two questions would sharpen it:

1. Do you have the full posting text? If so, the requirements can be quoted from it and checked against its full list.
2. Does any of these conflict with your situation: on-site or hardware-lab time, location, or travel? The summary doesn't say, and the pack can't assess it without knowing.

Want a drill? I can play the Skeptic on A2, the managing-managers objection, the question the pack names as highest-return prep. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: larkfield_engineering_manager_interview_pack.md -----
# Larkfield Systems — Engineering Manager: interview prep pack (three rounds)

**Role:** Engineering Manager, device-management services. **Company:** Larkfield Systems (industrial IoT, ~600 people). **Format:** loop mode. Three rounds, each with its own mini-pack and persona weights; one shared fit snapshot.

- Round 1, Tuesday, 45 min: hiring manager, Director of Engineering
- Round 2, Thursday, 60 min: panel, two staff engineers and a product manager
- Round 3, following Monday, 30 min: VP Engineering, "values and leadership philosophy"

## 1. How to use this pack

- **Personas** = how a question is asked. **Types** = what is being scored.
- Type key: **JD** role requirement · **EXP** your past work, attribution · **CASE** live problem, no claim about your past · **VAL** values and leadership behaviour · **CO** company strategy (none here: research did not run).
- Guidance is scaffolding, not a script. Each cell is about 90–120 seconds spoken.

## 2. Sources and research

Provided: your message only (the role summary, your background, the recruiter's round description). No CV, no posting text, no interviewer names.

Research tier: L1 — searches 3 of 6 (all refused by the host), fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Larkfield Systems values` | unavailable | Values cheat sheet, section 10: dropped, since no published values are in hand. Round 3 themes come from the recruiter's words only |
| 2. `Larkfield Systems interview process engineering manager` | unavailable | Loop structure. The loop comes from your own words instead (see Loop below); not checked against the company's process |
| 3. `Larkfield Systems industrial IoT device management strategy news` | unavailable | CO bank and differentiator questions. Round 3 and round 1 CASE questions are generic as a result |
| 4. `{interviewer name} Larkfield Systems` | n/a | No names given, so no query could be formed. No interviewer read |
| 5. representative `Engineering Manager` JD | unavailable | JD-tagged questions and the fit snapshot rest on your role summary only. A posting would move the requirement quotes |

Every query above was refused by the host. Nothing from the web is used in this pack. Company-specific statements below come from your message only.

**Loop.** Your own words establish the loop: three named rounds, each with its length and who runs it. Loop mode uses those rounds. No archetype fallback is used. Round 3 is a values-style round by your own description, so the VAL questions are written against the recruiter's words.

## 3. Fit snapshot

Requirements are quoted from your role summary. Evidence is quoted from your message. Every candidate-side claim in the banks below rests on one of these rows.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" — your message | "9 years engineering, 3 as a team lead of 6" — your message | medium | [grounded] | transferability | "For three years I led a team of six." The scale to two squads and to device management is not in the material. Expect a probe on it |
| F2 | "own delivery, hiring and growth for 11 engineers" — your message | "I run our hiring loop for backend roles — about 40 interviews last year." — your message | medium | [grounded] | presentation | "I run our hiring loop for backend roles, about 40 interviews last year." The quote is about backend roles, so do not extend it to device roles |
| F3 | "own delivery, hiring and growth for 11 engineers" — your message (growth) | none given | none | [grounded] | discovery | Answer slot: if you have grown engineers into bigger scope, say how, in your own words. If your material shows no such step, say so, and say what you would do first |
| F4 | "Lead two squads building device-management services" — your message | "I've never managed managers and never owned a hardware-adjacent roadmap." — your message | medium | [grounded] | transferability | "I haven't managed managers." Leading a team of six is adjacent to leading two squads, and the limit stays at that scope |
| F5 | "partner with hardware and product on roadmap" — your message | "pushed a reliability quarter through against roadmap pressure" — your message | medium | [grounded] | transferability | "I pushed a reliability quarter through against roadmap pressure." The pressure was roadmap pressure, not hardware. "I have never owned a hardware-adjacent roadmap." is the plain acknowledgment |
| F6 | none in role text (your headline metric) — your message | "My team's on-call burden dropped 60% after I pushed a reliability quarter through" — your message | medium | [grounded] | none | "On-call burden down 60% after a reliability quarter I pushed through." Quote at its own scope. The figure has no stated method, so every use needs the defend-the-number slots |

Gate rows: the role summary says nothing about location, on-site or hardware-lab time, or travel. Your material does not establish these. See the first question in Section 12.

## 4. Prohibited claims

Built locally from the fit snapshot. None of the banks, slots or rationales may assert, soften or imply these.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the hardware-adjacent roadmap | Inflated form of F5 and the stated negative | F5's quote at its own scope. The limit is the pack's own observation: the material says roadmap pressure, not hardware. Plain acknowledgment: "I have never owned a hardware-adjacent roadmap." |
| Managed managers / leads of leads | Negative you stated, F4 | "I haven't managed managers." No slot about how you would have managed them |
| Made the final hire decision in the 40 interviews | Inflated form of F2 | F2's quote. "Run the loop" is the quote's scope; decision role is an answer slot |
| Cut on-call burden 60% by yourself | Inflated form of F6 | F6's quote. Who else contributed is an answer slot, not a stated fact |
| Led 11 engineers | Inflated form of F1 | "a team lead of 6" at its own scope. The 11 is the role's scope, not yours |

## 5. Persona model per round

Relationship priors set the start. Interviewer names are absent, so panel members are blended rather than assigned.

| Round | Dominant personas (weight) | Why |
|---|---|---|
| 1 — Director, hiring manager | Skeptic (top, 4 questions), Case/Strategist (3), Data-Driven Prober (2), Conversational (1) | Hiring managers buy capability and derisk gaps. The gaps in F4 and F5 are where they will press |
| 2 — Panel | Peer Evaluator (3 questions), Case/Strategist (3, product manager's style), Data-Driven Prober (2, staff engineers' style) | Peer pricing of what the hire adds to their work; staff engineers probe depth; the PM tests roadmap reasoning |
| 3 — VP Engineering, values round | Values/Behavioral (top, 4), Pressure (3), Case/Strategist (2) | Your round description names values and leadership. Pressure tests whether a held position survives a second question |

## 6. Round 1 — Director of Engineering, hiring manager (45 min)

**Mini-pack weights:** Skeptic 3 · Case 3 · Prober 2 · Conversational 1 (9 questions). Coverage: JD 4, EXP 2, CASE 3.

**Skeptic bank**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "never owned a hardware-adjacent roadmap" — your message | Say it plainly: "I have never owned a hardware-adjacent roadmap." Then how you would learn it, as a plan, not a past. Answer slot: if you have worked alongside hardware or device teams in any form, say how; if you have not, say so | F5 is the requirement you are least able to show. The question is open enough that naming the gap yourself scores |
| A2 | "You're leading two squads, and your team has been six people. How do you see that gap?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6" — your message; [grounded] "I've never managed managers" — your message | "For three years I led a team of six. I haven't managed managers." Then: what you would do first in the first 90 days. Hold through two follow-ups by returning to the six, not by adding to it. Answer slot: if you have led people through another leader, say who and what you did; if not, say so | F4 is the single most predictable objection to this candidate. Deepest rehearsal in this pack: expect two follow-ups, and concede once, specifically |
| A3 | "Why would you leave where you are for this?" | JD | [generic] | Selection scaffold: say what you want from device-management work that the payments role does not give you, in your own words. If the material does not show that, say so and name the thing you would learn first | Motivation is always probed. The guidance cites no candidate sentence, so it makes no claim about your past |

**Case bank**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A4 | "A firmware rollout starts failing on one hardware revision. Walk me through your first week." | CASE | [generic] | Clarify first: which revisions, how many devices, is there a rollback path. Then objective, segmentation, approach, metrics, risks. Think aloud | The delivery requirement in the role summary, asked as a live problem. Asks about no past |
| A5 | "How would you size on-call load for a new device-management service before it ships?" | CASE | [generic] | Clarify the expected device population and alert sources. Propose a per-squad estimate, a stated assumption, and a check after launch | Connects to F6's reliability theme as a plan, not a claim |
| A6 | "Your product partner wants a device-side dependency the hardware team has not agreed to. What do you do?" | CASE | [generic] | Name who decides, what you would ask each side first, and what you would not commit to before both agree | Tests the hardware-and-product partnership requirement without presuming your history |

**Prober bank**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A7 | "Walk me through how the 60% on-call drop was counted." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through" — your message | Answer slots, in your own words: how the figure was counted (if you counted it, say how; if there was no method, say so); the assumption you would defend least; which part was yours. Do not offer a method for the count | F6 is your headline figure. A method you cannot repeat under a second question is worse than none |
| A8 | "Of about 40 interviews last year, how many did you run end to end, and what was your decision role?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." — your message | "I run the loop for backend roles." Answer slot: if you made the hire decision, say so; if you ran the loop and the decision sat with others, say that | F2's scope. Decision role is the most common inflation point |

**Conversational bank**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A9 | "So — walk me through the journey." | JD | [grounded] "9 years engineering, 3 as a team lead of 6" — your message; [grounded] "I run our hiring loop for backend roles" — your message; [grounded] "I pushed a reliability quarter through" — your message | A 90-second arc with the three quoted beats in order: nine years, three leading six, the backend hiring loop, the reliability quarter. Say what you did in each, in your own words. Stop at 90 seconds | Casual openers are scored. Each beat is a quoted sentence |

**Reverse questions (round 1)**

1. "What does a good first 90 days look like for the person in this role?" — shows you are planning, not asking for a job description.
2. "Which of the two squads has the harder reliability problem right now?" — opens the device-management trade-off.
3. "How does the hardware team's roadmap reach yours today?" — tests the partnership requirement directly; the answer tells you how to frame A6.
4. "What would make you say in six months that this hire was a mistake?" — invites the expectation, which you can then meet.
5. "What did the last engineering manager in this role do well, and what would you change?" — the Director's own view of the job. No profile exists, so no reverse question ties to their path.

**Requirement coverage (round 1):** "Lead two squads…" → A2, A4; "own delivery, hiring and growth for 11 engineers" → A4 (delivery), A8 (hiring), F3 growth — none in round 1; "partner with hardware and product on roadmap" → A1, A6.

## 7. Round 2 — Panel: two staff engineers and a product manager (60 min)

**Mini-pack weights:** Peer 3 · Prober 2 · Case 3 (8 questions). Coverage: JD 3, EXP 2, CASE 2, VAL 1.

**Peer bank (staff engineers)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our teams sit side by side — where's the seam, and what happens when you disagree?" | JD | [grounded] "partner with hardware and product on roadmap" — your message; [grounded] "pushed a reliability quarter through against roadmap pressure" — your message | Propose seam principles rather than claiming to know the seam. For disagreement, use the reliability quarter: the roadmap pressure, what you pushed, what you conceded. Answer slot: if other people disagreed with you, say how you handled them; if no one did, say so | Peer probes come in collegial form. The disagreement story is the one quote you have |
| B2 | "Which of the on-call pages were fixed by the reliability quarter, and which were not?" | EXP | [grounded] "pushed a reliability quarter through" — your message | Answer slot: name what the quarter fixed and what it did not, if you know. If you do not have that split, say so and say what you would measure | Staff engineers probe whether the 60% holds up in the detail |
| B6 | "How do you handle credit when work spans teams?" | JD | [generic] | Selection scaffold: pick a cross-team piece where the credit was shared; name your part and theirs, in your own words. If no such piece comes to mind, say so and give the nearest one | Peer evaluators score credit-sharing. Guidance cites no sentence of yours, so it makes no claim |

**Prober bank (staff engineers)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B3 | "Describe a design decision you would defend under load." | JD | [generic] | Selection scaffold: pick a backend design you made and owned; name the load, the trade-off and what you would change. If your decisions were in backend services only, say that | Staff engineers test depth. Device-side depth is not in your material, so the guidance does not supply it |
| B7 | "Where do you think a manager should stop making technical decisions?" | JD | [generic] | Give a view, anchored in a decision you actually made. Do not claim the device protocol as yours | Tests the lead-two-squads requirement from the technical side |

**Case bank (product manager)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B4 | "A customer wants offline device telemetry in 90 days. Hardware can't ship firmware until next quarter. How do you decide?" | CASE | [generic] | Clarify the customer's need and the firmware dependency. Lay out options with what each gives up. Name what you need from product and hardware before committing | Live partnership problem with the roadmap requirement |
| B5 | "What would you need from product to set this quarter's roadmap?" | CASE | [generic] | Name the inputs you would ask for, in order of how much they change the plan. Say how you would record decisions | Tests the roadmap-partnership requirement from the PM's side |
| B8 | "Plan a 90-day ramp into a team you didn't build." | CASE | [generic] | Structure: listen first, map people and systems, pick one reliability or delivery target, and say what you would not change in the first month | Asks about a plan, not your history |

**Reverse questions (round 2)**

1. "What is the one decision on this roadmap your team is most worried about getting wrong?" — shows you are thinking about the work, not the title.
2. "Where do the staff engineers and the product manager currently disagree on priorities?" — exposes the panel's own seam.
3. "What could a new person do in their first month that would genuinely help your team?" — reciprocity for a peer panel; it is the question that converts a panel into a working conversation.
4. "How does device telemetry get prioritised against customer-facing features today?" — makes the product-hardware trade-off concrete.
5. "What did the last hire on this team get wrong about the job, if anything?" — gives you the expectation gap in their words.

**Requirement coverage (round 2):** "Lead two squads…" → B3, B7; "partner with hardware and product on roadmap" → B1, B4, B5; "own delivery, hiring and growth for 11 engineers" → B2 (delivery, on-call), B6 (cross-team delivery). Growth — none in round 2, and why: the panel is not a growth conversation.

## 8. Round 3 — VP Engineering, values and leadership philosophy (30 min)

**Mini-pack weights:** Values/Behavioral 4 · Pressure 3 · Case 2 (9 questions). Coverage: VAL 4, EXP none, JD 1, CASE 2.

**Values bank**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "pushed a reliability quarter through against roadmap pressure" — your message | Story from the quote: the roadmap pressure, what you pushed, how it landed. Answer slot: if the truth did not reach leadership in that form, say so and give the nearest thing your material carries | The quote is the nearest thing you have. Do not supply a leadership reaction you did not see |
| C2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a time a user outcome beat a team's number. If the reliability quarter fits, say how the on-call number and the user outcome related. If no time comes to mind, say so plainly | Slogan-level values fail here. Guidance cites no sentence of yours |
| C3 | "What is your leadership philosophy, and where does it break down?" | VAL | [grounded] "values and leadership philosophy" — the recruiter's description, as relayed by you | Name two or three principles you actually act on, each with one decision behind it. Name where you have seen them fail, in your own words. Do not invent a philosophy you do not hold | The recruiter's own words set the theme. "Where it breaks down" is the honest half |
| C7 | "How do you develop an engineer who might one day lead a team?" | VAL | [grounded] "own delivery, hiring and growth for 11 engineers" — your message | Selection scaffold: one engineer you helped grow, what you did, what you watched for. Answer slot: if you have not grown an engineer into a larger scope, say so and say how you would start | F3 is the growth gap. The guidance supplies no engineer and no outcome |

**Pressure bank**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C4 | "Sixty seconds: why you over an internal candidate?" | VAL | [grounded] "9 years engineering, 3 as a team lead of 6" — your message | Hold: nine years, three leading six, and what you want from this role. Hold through two follow-ups. Concede specifically: the managing-managers gap, which you have stated, is real | Pressure asks for a position under time. You can hold the years and concede the gap |
| C5 | "You say the on-call burden dropped 60%. How much of that was actually you?" | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through" — your message | Hold-then-concede: say what you pushed, then name what you cannot attribute to yourself. Do not fold on the push. Answer slot: if others did the work that moved the number, say who | A pressure question on your headline figure. Concede the share, not the push |
| C8 | "You pushed a reliability quarter against roadmap pressure. Would you do it again, and what would you change?" | VAL | [grounded] "pushed a reliability quarter through against roadmap pressure" — your message | Hold yes only if your material supports it. Then one specific change, in your own words. Do not invent what the roadmap cost | Tests the hold on the same story from another angle |

**Case bank**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C6 | "How would you choose between two device-management priorities in a quarter?" | CASE | [generic] | Clarify the customers and the cost of delay. Set criteria before options. Name what you would stop doing | Strategic altitude, live, no claim about your past |
| C9 | "What mistake would you expect a new engineering leader here to make?" | CASE | [generic] | Name one mistake for the role type and what you would do to avoid it in the first month | Tests judgement at the VP's altitude |

**Reverse questions (round 3)**

1. "What would you want a new engineering manager to have changed in the first six months?" — shows you are taking the leadership job seriously.
2. "How do you measure whether a reliability investment was worth it?" — puts your strongest story on the VP's terms.
3. "Where do you see the company's engineering philosophy under the most pressure right now?" — the VP's own view of the company.
4. "What did you learn about leading managers that you wish you had known earlier?" — invites the VP's leadership philosophy in their words.
5. "What would make this the right decision for you, and what would make it the wrong one?" — asks the VP to name the bar.

**Requirement coverage (round 3):** "Lead two squads…" → C4 (for lead), C8; "own delivery, hiring and growth for 11 engineers" → C7 (growth); "partner with hardware and product on roadmap" → C6 (roadmap priorities).

## 9. Requirement coverage (all rounds)

| Requirement | Questions | Notes |
|---|---|---|
| "Lead two squads building device-management services" | A2, B3, B7, C4, C8 | Managing managers is not in the role text; it is covered by A2 and F4 |
| "own delivery, hiring and growth for 11 engineers" | A4, A8, B2, B6, C7 | Growth: C7 only. No growth quote exists in your material (F3) |
| "partner with hardware and product on roadmap" | A1, A6, B1, B4, B5, C6 | Hardware: A1, A6. The hardware roadmap is not in your material |

## 10. Upgrade menu

- Full posting text → the requirement quotes come from the posting, and JD-tagged questions can be checked against its whole list. Without it, this pack rests on your role summary.
- Names and roles of the two staff engineers and the product manager → personas per member and a reading of each interviewer's public footprint.
- Your CV or résumé text → inspectable detail for F1 and F6, and defend-the-number slots anchored in lines you wrote.
- Larkfield's published values page → the values cheat sheet, section 10, for round 3, with each value mapped to a story.
- Permission to retry web research → company values, the loop, and current strategy. This would move round 3 and the CO questions, and it would turn the generic CASE questions into company-specific ones.
- Recruiter's note on the round focus areas → the weights for round 3 and any pre-declared deliverable.
