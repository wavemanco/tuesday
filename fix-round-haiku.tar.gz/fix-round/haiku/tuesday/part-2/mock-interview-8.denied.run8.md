Your pack is ready. Nine days out, the main thing to know is that Round 2 is weighted toward behavioural questions, not case work, and the panel scores against the four values. Your two stated gaps (no contact-centre work, no presenting above regional level) and the one-branch scope of your complaints work will come up in every round.

Priorities for the next few days:

- **Scope (R2-S2, R2-S1):** be ready to name the gap between one branch's log and an end-to-end process, then give a plan rather than a claim.
- **Hold, then concede (R3-P1, R2-P2):** hold the complaints work you did, and concede only the specific gaps.
- **The 20-minute case (R3-K1):** run it aloud against the timings in the pack.
- **Excel and regulated complaints (R1-A5, F6, F8):** the material you gave me says "spreadsheet" and "formal", not Excel or regulated. Answer from what you actually used.

I did no web research: the values, the round structure and the strategy brief were all in your material, so there was nothing to look up. The case is a generic practice scenario, not Ashgrove's policy.

Your prep pack is saved as `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-tuesday-part-2-rooms-case-8-denied-aa69b6ef/9341951a-2478-4ac7-878a-3f51d7f395b4/scratchpad/ashgrove-credit-union_member-experience-lead_interview_pack.md`. I built it as a three-round loop because the recruiter named three rounds, each with its own persona weights and question bank.

Say the word and I'll run the 20-minute escalation case with you as a live drill, playing the panel.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

1. Will the 20-minute case come as a written brief in advance, or will it be read out in the room?
2. What rules or timescales, if any, governed your branch's formal complaints log? If none did, that's useful to know too.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove-credit-union_member-experience-lead_interview_pack.md -----
# Interview prep pack: Member Experience Lead, Ashgrove Credit Union

**Role:** Member Experience Lead · **Company:** Ashgrove Credit Union · **Dates:** 20 November 2026, three rounds · **Interviewers:** not yet named. Round 2 is the Head of Member Services, who would be your manager.

**Built on:** the JD and your background as you wrote them in your message (no CV file was supplied, so every quote from you is labelled "your message"), the recruiter's round description, the values you copied on 11 November 2026, and the July 2026 strategy brief the recruiter sent. Mode: loop, because the recruiter named three scheduled rounds. The fit snapshot and sources are shared; each round has its own mini-pack.

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is scored: VAL (values), EXP (your record), JD (the role's requirements), CO (company and strategy), CASE (a live problem).
- Guidance is scaffolding, not a script. Rehearse it aloud until you can say it in your own words.
- An **answer slot** is an instruction for the interview. Answer from what actually happened, on whichever branch is true. Never answer from the practice the slot names.

---

## Fit snapshot (shared across all rounds)

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches and the contact centre" (JD in your message) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | transferability | Your material says one branch's formal log, and the words stay there: "I handled the branch's formal complaints log." Answer slot: if you owned any step from first contact to closure, say which and how you decided it; if you did not, say so and stay with the log. |
| F2 | "report monthly on complaint volumes and resolution times" (JD in your message) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | medium | [grounded] | presentation | Reword only: "I built the monthly complaints spreadsheet." Answer slot: the JD asks for volumes and resolution times, so expect a probe on what the spreadsheet counted. If it counted them, say what and how; if not, say so, and say what you would measure first. |
| F3 | "coach branch supervisors on escalations" (JD in your message) | "trained new tellers on our escalation script" (your message) | medium | [grounded] | transferability | Your sentence says tellers, not supervisors, so keep that difference visible: "I trained new tellers on our escalation script." Answer slot: if you coached a supervisor or manager on an escalation, say what and when; if not, say so and say how you would start. |
| F4 | "work with digital teams on self-service journeys" (JD in your message) | none given | none | [grounded] | discovery | Your material is silent on digital work. Answer slot: if you worked with a digital or product team on any journey, say what it was and your part in it; if you have not, say so. |
| F5 | "4+ years in financial-services customer operations" (JD in your message) | "6 years in retail banking, the last 3 as a branch supervisor" (your message) | medium | [grounded] | presentation | Reword only: "I've spent six years in retail banking, the last three as a branch supervisor." Whether a branch counts as customer operations is for the panel to judge; state the facts. |
| F6 | "experience handling regulated complaints" (JD in your message) | "I handled the branch's formal complaints log" (your message) | low | [grounded] | discovery | Your material says "formal" and does not name any rules. Answer slot: if the log ran under rules or timescales, name them and your part in meeting them; if none applied, say so. |
| F7 | "confident presenting to senior leaders" (JD in your message) | "I've never presented to anyone above regional level" (your message) | none | [grounded] | capability | Plain acknowledgment: "I haven't presented to anyone above regional level." Then how you would learn it, said as a plan and never as a past. |
| F8 | "comfortable with Excel reporting" (JD in your message) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | low | [grounded] | discovery | Your material says "spreadsheet", not Excel. Answer slot: say which tool you built it in and which functions you used. Say Excel only if you used Excel. |
| F9 | "across branches and the contact centre" (JD in your message) | "Never worked in a contact centre" (your message) | none | [grounded] | capability | Plain acknowledgment: "I haven't worked in a contact centre." Then how you would learn the contact centre's complaint route, said as a plan. |

Notes on the table: F3 and F5 are medium because they are specific and user-confirmed but have little to inspect. F6 is low because "formal" is the only link to "regulated". F9 and F7 are capability gaps because you stated the absence yourself.

---

## Prohibited claims (built before the banks)

These are the claims this pack will not coach. Each has a basis and an honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| "I owned the complaints process end to end across branches and the contact centre" | Inflated form of F1: your sentence covers one branch's formal log | "I handled the branch's formal complaints log." The limit is the pack's observation: your material says one log, not the end-to-end process. |
| "I coached branch supervisors on escalations" | Inflated form of F3: your sentence covers tellers | "I trained new tellers on our escalation script." |
| "I wrote the escalation script" | Inflated form: your sentence says "our escalation script" | "I trained new tellers on our escalation script." |
| "I have presented to senior leaders" | Negative you stated (F7) | "I haven't presented to anyone above regional level." |
| "I have worked in a contact centre" | Negative you stated (F9) | "I haven't worked in a contact centre." |

---

## Grounding brief: the vocabulary Ashgrove uses

From the July 2026 strategy brief (provided by the recruiter, under six months old). Use these words, not a summary of them:

- "move 40% of member service to digital channels by 2028"
- "consolidate eight branches into five hubs over 2027"
- "launch a small-business lending product in Q1 2027"
- The main competitive pressure named in the brief is app-only banks.

No stale framing was found in the material. Do not say whether your own branch is among the eight; you do not know that from what you have given.

---

## Round 1: Recruiter screen, 30 minutes

**Round facts:** the recruiter's email says "30 minutes with me." It is a screen: logistics, motivation and knockouts against the JD.

**Persona weights**

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / rapport | Friendly walk-through, motivation, "tell me about yourself" | High. Recruiter-screen prior. | A 90-second arc. Treat casual questions as scored. |
| Skeptic (light) | Knockouts: contact centre, presenting above regional level, Excel | High. The JD's four requirements are checked at this stage. | Plain acknowledgment, then the bridge. |

**Question bank** (depth: Conversational 5, Skeptic 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R1-A1 | "Tell me a bit about your background." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" (your message); "I handled the branch's formal complaints log" (your message); "trained new tellers on our escalation script" (your message) | About 90 seconds: the six years and the last three as a supervisor, then the complaints log and the tellers' training. Use your words. Add no role and no result. | The opening arc puts F5, F1 and F3 in an order you can defend under follow-up. |
| R1-A2 | "Why are you leaving retail banking for a member-owned credit union?" | VAL | [generic] | Name one thing from the published values that draws you, and one thing you want from the next role. Keep the reason to what is true for you. | A motivation check. It makes no claim about your past, so the label stands alone. |
| R1-A3 | "Ashgrove plans to consolidate eight branches into five hubs over 2027. How do you see that affecting the complaints work?" | CO | [grounded] "consolidate eight branches into five hubs over 2027" (2026 strategy brief) | Think aloud about what changes for a member whose branch closes: where they complain, how they are told. No claim about your own branch. | A candidate who has read the brief sounds current. |
| R1-A4 | "Have you worked in a contact centre?" | JD | [grounded] "Never worked in a contact centre" (your message) | Plain: "I haven't worked in a contact centre." Then the bridge: "I handled the branch's formal complaints log." Stop there. | F9 is a stated gap and the screen will check it as a knockout. |
| R1-A5 | "Are you comfortable with Excel reporting?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" (your message) | Answer slot: name the tool you built it in and what it did, in your words. Say Excel only if you used Excel. | F8. The material says spreadsheet, and the JD names Excel, so the recruiter will check the word. |
| R1-B1 | "You've been a branch supervisor for three years. Why move now?" | EXP | [grounded] "the last 3 as a branch supervisor" (your message) | Say what you want from the next role and why this one, in your words. | A motivation probe on the step from supervisor to a lead role. |
| R1-B2 | "Who have you presented to, and at what level?" | JD | [grounded] "I've never presented to anyone above regional level" (your message) | Plain: "I haven't presented to anyone above regional level." If you have presented at regional level, say to whom and what you showed. | F7. The plain form is the only one your material supports. |
| R1-B3 | "Which parts of this role are you weakest on?" | JD | [grounded] "Never worked in a contact centre" and "I've never presented to anyone above regional level" (your message) | Name the two negatives plainly. Then name the one you are least sure of: regulated complaints (F6), and answer it with the rules your log ran under, if any. | Recruiters use this to test self-assessment. Naming gaps first is the stronger position. |

---

## Round 2: Head of Member Services (your future manager), 45 minutes

**Round facts:** the recruiter's email says "45 minutes with the Head of Member Services, who would be your manager, mostly behavioural."

**Persona weights**

| Persona | How it shows up | Likelihood and reasoning | Depth |
|---|---|---|---|
| Values / Behavioral | Scenario probes tied to the four values; wants STAR-shaped stories | Top. The hiring-manager prior is Case and Skeptic, but the recruiter's words say "mostly behavioural", so behavioural moves to the top. | 5 |
| Skeptic | Probes the gaps: contact centre, the one-log scope, presenting | High. A manager is buying capability and reducing risk. | 3 |
| Pressure | Time-boxed challenge on your one strongest claim | Medium. | 2 |
| Case | One digital-journey scenario, lightly | Low-medium here. The panel carries the main case. | 1 |
| Prober | How the log or the spreadsheet counted things | Low-medium. | 1 |

**Question bank**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R2-V1 | "Tell me about a time a member didn't like your answer and you still had to give it." | VAL | Open prompt, theme from the JD's complaints remit. [grounded] "trained new tellers on our escalation script" (your message) | Choose a real member conversation. Answer slot: if none from your branch years comes to mind, say so, then give how you taught tellers to explain the escalation script. Use "we" for the branch and "I" for your part. | Members First and Plain Words. The material holds no member conversation, so the honest branch is written in. |
| R2-V2 | "Describe a complaint that stayed open longer than it should have. What did you do?" | VAL | Open prompt, theme from the JD's resolution times. [grounded] "I handled the branch's formal complaints log" (your message) | Story-map on the log you handled. Answer slot: if you kept a slow complaint moving to closure, say what you did at each point. If closing it was not yours, say so and say what you did to keep it moving. | Own the Fix, and the JD measures resolution times. |
| R2-V3 | "When did you put a member ahead of a process or a target?" | VAL | Open prompt. [generic] for the theme. [grounded] "I handled the branch's formal complaints log" (your message) | Selection scaffold: pick a time a process said one thing and the member needed another. If none comes to mind, say so, and give how you handled the log. | Members First and Neighbours, Not Numbers. |
| R2-V4 | "Tell me about a letter or script you made clearer for a member." | VAL | Open prompt. [grounded] "trained new tellers on our escalation script" (your message) | Selection scaffold: pick a time you changed the wording so someone understood it first time. If you have not changed a script or letter, say so, then say how you would check a letter was plain. | Plain Words. The teller training is the nearest sentence you have. |
| R2-V5 | "Tell me about a time you had to tell your manager something they didn't want to hear." | VAL | Open prompt. [generic] for the theme. | Selection scaffold: pick a time you raised a problem upward. If none comes to mind, say so, then say how you would raise one. | Own the Fix, from the manager's side. |
| R2-S1 | "Your complaints work was the branch's log. What makes you think it carries to a contact centre?" | JD | [grounded] "I handled the branch's formal complaints log" (your message); "Never worked in a contact centre" (your message) | Plain: "I haven't worked in a contact centre." Bridge: "I handled the branch's formal complaints log." Then a plan: what you would check first about how a contact centre records a complaint. | F1 and F9: the scope gap, answered with a plan rather than a claim. |
| R2-S2 | "You would be running complaints across branches and a contact centre. Where is the gap?" | JD | [grounded] "Own the member complaints process end to end across branches and the contact centre" (JD in your message); "I handled the branch's formal complaints log" (your message) | Name the gap as scope: one log against the whole process. Then your ramp plan, labelled as a plan. Claim no step you have not taken. | F1, the largest gap, asked as a scope question. |
| R2-S3 | "You trained tellers. Why would supervisors take coaching from you?" | JD | [grounded] "trained new tellers on our escalation script" (your message); "coach branch supervisors on escalations" (JD in your message) | Hold the sentence as written: you trained tellers. Then say how you would earn a supervisor's trust, as a plan. If you have coached a supervisor, say when and on what. | F3. The JD names supervisors and your sentence names tellers. |
| R2-K1 | "A digital team wants a self-service complaints route, and the strategy is 40% digital by 2028. What do you need to know before agreeing the design?" | CO / CASE | [grounded] "move 40% of member service to digital channels by 2028" (2026 strategy brief) | Clarify first: which complaints would move, what a member could not do online, what must stay with staff. Name the decision you would make and who you would need in the room. No claims about your past. | A live problem from the brief. It asks no past, which matters because F4 is silent on digital work. |
| R2-P1 | "In sixty seconds, why should this be you?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" (your message) | Pause, restate in one sentence, anchor in the six years and the log. Hold through two follow-ups before conceding anything. | A time-boxed stress format. The hold has to rest on something you can back. |
| R2-P2 | "That complaints spreadsheet your manager uses. How much of it was actually you?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" (your message) | Hold: "I built it." Then concede specifically: if others changed it, say what they changed. Answer slot: if you built it with others, say who did which part. | The premise is your own quoted sentence. Hold the claim you made, concede only the specific part that was shared. |
| R2-D1 | "What did the log record for each complaint, and what counted as finished?" | EXP | [grounded] "I handled the branch's formal complaints log" (your message) | Answer slot: if you set or applied a rule for when a complaint counted as finished, say what it was. If the log had no such rule, or it was not yours, say so. Name the assumption you would defend least. | A prober's question. The log is where any figure would come from. |

---

## Round 3: Panel of two branch managers, 60 minutes (includes a 20-minute case)

**Round facts:** the recruiter's email says "The panel is also the values round — they score against the four values." The round includes a 20-minute case on a complaint escalation. Names are not yet known.

**Persona weights**

| Persona | How it shows up | Likelihood and reasoning | Depth |
|---|---|---|---|
| Values / Behavioral | Scored against the four published values | Guaranteed. The recruiter's words make this a values round. | 4, plus the values cheat sheet |
| Case / Strategist | The 20-minute escalation case | High. The case is the round's centre. | The case drill |
| Peer Evaluator | Seams between branch and contact centre; disagreement; what a new person brings to their teams | Medium. Branch managers would work alongside this role. The peer prior applies. | 2 |
| Pressure | A challenge on the contact-centre gap | Medium. A panel will test your weakest point. | 1 |

**Values cheat sheet (section 10 condition met: a values round is named in the loop, and the four values are in hand)**

| Value (official name) | Working meaning (paraphrased) | Mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | F1: "I handled the branch's formal complaints log" (your message). Scaffold: a decision you made from the member's side. If none comes to mind, say so. |
| Plain Words | If a member needs it explained twice, the wording was wrong | F3: "trained new tellers on our escalation script" (your message). Scaffold: a time you changed wording so it landed first time. If none, say so and say how you would test a letter. |
| Neighbours, Not Numbers | Every branch is part of its town | No quoted sentence carries a story. Scaffold: pick a time a branch's numbers and its customers pulled apart. If none, say so, then say how you would check a branch's targets against its members. |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | F1: "I handled the branch's formal complaints log" (your message). Scaffold: a complaint you kept hold of until it was solved. If none, say so. |

**Question bank**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R3-V1 | "Tell me about a time you put a member first when the process pointed the other way." | VAL | Open prompt. [grounded] "I handled the branch's formal complaints log" (your message) | Selection scaffold: pick a time a process said one thing and the member needed another. If none comes to mind, say so, then give the nearest thing: the log you handled, and what was yours in it. | Members First, scored by this panel. The material holds no such event. |
| R3-V2 | "What does plain wording mean to you in a complaint letter?" | VAL | [generic] | Define it in your words: a letter a member reads once. Then: if you have changed a letter's wording, say what and why; if not, say so, and say how you would test one. | Plain Words. The definition is generic; your own record appears only in the slot. |
| R3-V3 | "A branch's resolution times are good, and its members are angry. What would you ask the branch manager first?" | VAL / CASE | [generic], with the JD's resolution-times requirement as the raising source | Think aloud: what members are saying, what the branch is measured on, what the town needs. No claim about your past. | Neighbours, Not Numbers, tested as a decision. The question presupposes nothing about you. |
| R3-V4 | "A complaint lands with you that another team started. What do you do with it?" | VAL | [grounded] "I handled the branch's formal complaints log" (your message) | Say what you would do on day one: keep hold, name the owner, set a date you would give the member. Answer slot: if a complaint was handed to you part-way, say how you handled it. If not, say so. | Own the Fix. F1 is the nearest sentence and it stays at its own scope. |
| R3-K1 | **Case, 20 minutes:** "A member was told at a branch counter that a £40 fee would be refunded within five working days. Nine working days later it has not arrived. They have phoned the contact centre twice, and each call was passed back to the branch. They have now written a formal complaint, and the branch supervisor has escalated it to you. You have the log entry, two call notes and the letter. Walk us through what you do." | CASE | [generic]. This is a practice scenario, not Ashgrove's policy. | **Beats and timing:** (1) 2 minutes: clarify the member's ask, what was promised, and who said what. (2) 4 minutes: take hold. Name one owner and one date you would give the member, in plain words. (3) 6 minutes: find the refund across both channels. Locate the handoff where it stalled. (4) 4 minutes: fix the member's outcome. (5) 4 minutes: root cause. The two-channel handoff is the thing to coach the branch supervisor on. Say what you would log and report. Check your own firm's complaint timescales; do not assume them. | Covers Own the Fix, the JD's coaching requirement, and the contact-centre gap (F9). For the contact-centre part, describe a plan for learning that route, not a past. |
| R3-E1 | "Branch managers and the contact centre each have a complaints route. Where is the seam, and what happens when you disagree with one of them?" | JD | [generic] | Propose seam principles, not facts about their seam: who owns the case at each handoff, and what gets written down. On disagreement, say what you would do first. Answer slot: if you have disagreed with a peer or supervisor, say what happened. If not, say so. | A peer probe about turf. It makes no claim about your history. |
| R3-E2 | "What would you need from branch managers to coach their supervisors well?" | JD | [grounded] "trained new tellers on our escalation script" (your message); "coach branch supervisors on escalations" (JD in your message) | Say what you would need: access to case files, time with supervisors, a voice in how escalations are set up. Hold the sentence as written: you trained tellers. The rest is a plan. | Reciprocity. Branch managers want to know what they gain. |
| R3-P1 | "Why would a team of branch managers trust a complaints lead who has never worked in a contact centre?" | JD | [grounded] "Never worked in a contact centre" (your message); "I handled the branch's formal complaints log" (your message) | Pause and restate. Plain: "I haven't worked in a contact centre." Hold on the log you handled and the script you taught. Concede the specific gap and name the first thing you would do to close it. Do not fold on the complaints work. | Hold, then concede. The conceded point is your own negative. The held point is only what you quoted. |

---

## Reverse questions

Each one has a reason it lands. Panel members are not named yet, so the path-tied questions wait for the upgrade menu.

| # | Question | Round | Why it lands |
|---|---|---|---|
| 1 | "What are the next steps after 20 November, and who makes the decision?" | 1 | Shows you are tracking the process. |
| 2 | "What does a good first 90 days look like for whoever takes this role?" | 2 | Asks about ownership and gives you the success measure. |
| 3 | "The brief says 40% of member service moves to digital by 2028. Which complaints would you expect to move first, and which must stay with people?" | 2 | Ties to the strategy with a question, not a claim. |
| 4 | "How do you want the complaints work to look once eight branches become five hubs?" | 2 | Shows you read the brief and think about members, not just the org chart. |
| 5 | "What could a new person do in their first month that would genuinely help your teams?" | 3 | Peer reciprocity. It asks the panel what they need. |
| 6 | "What do the branch managers most want from a complaints lead that they don't get today?" | 3 | Turns the panel into a source, and the answer tells you what to lead with. |

---

## Coverage: JD requirements mapped to questions

| JD requirement | Covered by |
|---|---|
| Own the complaints process end to end across branches and the contact centre | R1-B3, R2-S1, R2-S2, R2-D1, R3-K1, R3-P1 |
| Report monthly on complaint volumes and resolution times | R1-A5, R2-V2, R2-P2, R2-D1 |
| Coach branch supervisors on escalations | R2-S3, R3-E2, R3-K1 |
| Work with digital teams on self-service journeys | R1-A3, R2-K1 (no story in your material: discovery, answered by slot) |
| 4+ years in financial-services customer operations | R1-A1, R2-P1 |
| Experience handling regulated complaints | R1-B3, R2-V2 (no rules named in your material: discovery, answered by slot) |
| Confident presenting to senior leaders | R1-B2, R3-P1 (capability gap, answered by plain acknowledgment) |
| Comfortable with Excel reporting | R1-A5, R2-P2 |

**Values coverage:** Members First, Always: R2-V1, R3-V1. Plain Words: R2-V4, R3-V2. Neighbours, Not Numbers: R2-V3, R3-V3. Own the Fix: R2-V2, R3-V4.

---

## Sources and research accounting

**Provided documents:** the JD and your background, both in your message (no CV file); the values you copied on 11 November 2026; the recruiter's email on the rounds; the July 2026 strategy brief the recruiter sent. No dossier was present.

**Research tier:** L1, searches 0 of 6, fetches 0 of 2, user links read 0. No search was sent, because the inputs fix every output a search would feed.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | The values you copied this morning fix the values cheat sheet and the values-round questions. |
| 2. Ashgrove interview process, member experience lead | skipped | The recruiter's email names three rounds, who runs each, and the values round. Loop mode is built from it. |
| 3. Ashgrove strategy / recent news | skipped | The July 2026 brief you have, under six months old, fixes current priorities and recent moves. |
| 4. Interviewer name + Ashgrove | n/a | No names were given. The interviewer read is absent; the upgrade menu says what a name would unlock. |
| 5. Representative Member Experience Lead JD | skipped | You supplied the JD. |

---

## Upgrade menu

- The names of the Head of Member Services and the two branch managers → personas per member, an interviewer read, and reverse questions tied to their career paths. Affects Rounds 2 and 3.
- Any written brief for the 20-minute case, or a sample complaint template → rehearsal on the real facts instead of the practice scenario (R3-K1).
- Your CV, not just the summary in your message → the candidate quotes in F1 to F9 come from your CV, and F6 and F8 can move from discovery if the CV names rules or tools.
- Details of the digital team's self-service journeys → F4 gets evidence, and R2-K1 gets specifics.
- The rules or timescales your branch's formal log ran under → F6 can become a grounded bridge (see question 2 below).
