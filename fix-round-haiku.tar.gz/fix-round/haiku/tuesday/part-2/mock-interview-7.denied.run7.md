Your prep pack is saved as /tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-tuesday-part-2-rooms-case-7-denied-be0e04de/604b6177-603f-485e-b6cf-610b24a96255/scratchpad/saltmarsh_live-operations-producer_interview_pack.md. I built it for a single session with Tobias as your likely hiring manager, since your note didn't confirm that.

Web search was refused in this session, so nothing about Saltmarsh or Tobias is sourced. The pack works from the JD you pasted and your background. Company values, the interview loop, strategy and his public background are missing.

**What the pack says about your fit**

- **Strongest match:** the content calendar. You ran a weekly content-drop calendar for two years, and the JD asks for exactly that.
- **Biggest gap:** the JD asks for live events across two titles. You've run one. Expect that to come up first.
- **Other gaps:** the JD says "coordinate design, art, engineering and community," and your material doesn't show that. You also said you've never led a team and never worked on a game with in-app purchases.
- **Release checklist:** you wrote the one QA still uses. That's a strong story.
- **Retention:** "presented the monthly retention numbers" is the thinnest point on the metrics requirement. Be ready to explain how those numbers were counted.

**Highest-value prep: question A1.** The Skeptic asks what in your background shows you can run two titles. Answer with the one title and two years you ran. Then give a plan for the second, labelled as a plan, not a past. If you've never done it, say so plainly.

**Other things to rehearse**
- **"Never led a team."** Say "I haven't led a team" first, then move to what you did. Don't stretch the negative to cover coordinating across teams.
- **In-app purchases.** Say "I have never worked on a game with in-app purchases," then give a plan for learning it.
- **Don't inflate.** The pack lists the wording to avoid: "owned the KPIs," "ran two titles," "live-service producer," "managed releases with QA." Each is a stretch of something you actually said.

The pack has 18 questions across six personas, with the answer guidance and the honest branch for each. It also covers a requirement-coverage map and six reverse questions for Tobias.

I'd also like to run a few mock drills on the Skeptic questions, starting with A1. Say the word and I'll play it.

Two questions so I can fit the pack to Friday:
1. Is Tobias your future manager, or does the hour cover one session or part of several? That changes how the questions are weighted.
2. How much prep time do you have before Friday?

If you give me permission for web search, I can look up Saltmarsh's values, interview process and recent news, and what Tobias has published. That would add company-specific questions and an interviewer read. I can also save a tuesday-dossier.md recording the gaps this prep exposed, and convert the pack to Word if you'd like.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh_live-operations-producer_interview_pack.md -----
# Interview prep pack: Live Operations Producer, Saltmarsh Games

Interviewer: Tobias Wrenfield, Head of Live Operations. Relationship assumed to be hiring manager (not confirmed). Format: one 60-minute session on Friday.

Research did not run. Web search was refused in this session, so nothing company-specific below is sourced. Every company fact is either the JD's own words or absent. Sections that depend on research (values, loop structure, strategy, interviewer read) are not included.

## How to use this pack

- Personas describe how a question is asked. Types describe what is being scored.
- Type key: **EXP** work-experience deep-dive (does the CV survive scrutiny). **JD** role-driven (can you do the listed job, gaps included). **CASE** live problem from the role, no past needed. **VAL** behavioral, scored against values (none published here, so used only as a persona stem). **CO** company and strategy knowledge (not built, research did not run).
- Guidance is scaffolding, not a script. Rehearse what you did, in your own words.

## Fit snapshot

Requirements are quoted from the JD you supplied. Evidence is quoted from your message. Nothing else is quoted.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | medium | [grounded] | transferability | Your material says one main title, weekly drops, two years. It does not say live events or two titles. Say it at that scope: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: the JD covers two titles, so expect a probe on the second. If you have planned work across more than one title, say what and how you decided. If you have not, say so plainly and say how you would run the second alongside the first. |
| F2 | "coordinate design, art, engineering and community teams on each update" (JD) | none given | none | [grounded] | discovery | Your material does not show coordination across design, art, engineering or community. That is a limit of what you gave me, not a finding about you. Answer slot: if you coordinated work across any of those teams on the content drops, say which team and how the handoff ran. If you did not, say so plainly and say how you would run one update across the four. |
| F3 | "own the post-event review and the KPIs it reports" (JD) | "Presented the monthly retention numbers to the studio head" (your message) | low | [inferred] | transferability | Presenting retention to the studio head is adjacent to owning a post-event review and its KPIs. The quote does not show whether you chose the measures or reviewed any event. Keep the bridge at the quote's scope: "I presented the monthly retention numbers to the studio head." Answer slot: if you chose the KPIs, or ran a review after an event, say which and what changed. If not, say so plainly and name the first measures you would set for an event review. |
| F4 | "manage the release checklist with QA" (JD) | "Wrote the release checklist our QA team still uses" (your message) | medium | [grounded] | none | The quote reaches the requirement: you wrote the checklist and QA still uses it. Day-to-day management is not shown, so expect a probe there. Say it at the quote's scope: "I wrote the release checklist our QA team still uses." Answer slot: if you ran each release through it with QA, say how. If QA ran it, say so, and say what you did own. |
| F5 | "3+ years producing live-service games or apps" (JD) | "4 years as an associate producer at a puzzle-game studio" (your message) | medium | [grounded] | presentation | The four years reach the requirement's length. Whether the title counts as live-service is the open point. Reword only the quote: four years as an associate producer on a puzzle game, whose main title ran weekly content drops for two years. Let the interviewer judge the label. |
| F6 | "experience running a content calendar" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | medium | [grounded] | none | The quote reaches the requirement directly. Caveat: no calendar has been inspected, so expect "show me one". Keep the cadence and span exactly as stated. |
| F7 | "comfortable with player-retention metrics" (JD) | "Presented the monthly retention numbers to the studio head" (your message) | medium | [grounded] | presentation | The quote shows regular, senior-facing use of retention figures. It does not show how they were built. Reword only the quote: "I presented the monthly retention numbers to the studio head." The probe is on how the numbers were counted. C1 and C2 rehearse it. |
| F8 | "clear written communication" (JD) | "Wrote the release checklist our QA team still uses" (your message) | medium | [grounded] | none | A checklist that a QA team still uses is written work other people depend on. No writing sample is in the material. Keep it at the quote's scope. |
| F9 | [generic] Working with monetized mobile titles. Not in the JD. Mobile live events often carry spend goals. | "never worked on a game with in-app purchases" (your message) | none | [grounded] | capability | This is a negative you stated, so the pack may give it back: "I have never worked on a game with in-app purchases." Then say how you would learn it, as a plan, never as a past. No claim about monetization work or knowledge you have not stated. |
| F10 | [generic] Leading a team. Not in the JD; the coordination work in F2 makes a probe likely. | "Never led a team" (your message) | none | [grounded] | capability | A negative you stated: "I haven't led a team." The negative covers leading. It does not extend to coordinating (F2), and the pack does not stretch it that way. |

Gate rows: none. The material does not raise a term-based gate (location, authorization, schedule, pay). If one exists, tell me and I will add it.

## Prohibited claims

Built locally from the fit snapshot. These are the claims a candidate reaches for under pressure. No answer, hold or rationale in this pack asserts any of them.

| Not coached | Basis | Honest form |
|---|---|---|
| Ran live events across two titles | Inflated form of F1 | F1's quote at its own scope. Your material says one main title, which is the pack's observation, not a word for you. A1 stays inside what you ran. |
| Owned the post-event review and its KPIs | Inflated form of F3 | "I presented the monthly retention numbers to the studio head." The pack observes the material does not show you chose the measures. |
| Ran release management with QA | Inflated form of F4 | "I wrote the release checklist our QA team still uses." |
| Built the retention analysis | Inflated form of F7 | "I presented the monthly retention numbers to the studio head." |
| Live-service producer | Inflated form of F5 | "4 years as an associate producer at a puzzle-game studio." |
| Any claim of leading a team | Negative you stated (F10) | "I haven't led a team." |
| Any claim of monetization work | Negative you stated (F9) | "I have never worked on a game with in-app purchases." |

## Persona weights

No loop source was read, so no loop is established. The archetype fallback is Generic, which tilts nothing and says so. Weights below follow the hiring-manager prior, which is an assumption about Tobias's role in your round.

| Persona | Weight | How it shows up | Likelihood and reasoning | Counter-strategy | Questions |
|---|---|---|---|---|---|
| Skeptic | top | Presses the gaps: two titles, live-service, leading a team | High. A hiring manager is buying capability and checking the gaps. Your material is thinnest exactly where the JD is widest. | Rehearse the most predictable objection until it is boring. Concede the stated gaps plainly, hold the calendar you ran, and give a plan rather than a past. | A1 to A5 |
| Case / Strategist | top | Live problems on the role's own work | High. Hiring managers test live problems. Equal lead with Skeptic under this prior. | Clarify, then objective, segmentation, approach, metrics, risks. Say the structure aloud. | B1 to B4 |
| Data-Driven Prober | 3 | Asks how the retention numbers were counted | Medium. The JD says "comfortable with" retention metrics, and retention is the one number-bearing line in your material. | Say what the figure measured. Name the weakest assumption before they do, or say you do not know how it was counted. | C1 to C3 |
| Pressure | 2 | Time-boxed challenges on your held position | Lower under this prior. The one held position is the leadership negative. | Pause, restate, concede the leadership point, hold the calendar. | D1 and D2 |
| Conversational | 2 | "Walk me through the journey" | Casual openers are still scored. | A 90-second arc from your own sentences only. | E1 and E2 |
| Values / Behavioral | 2 | "Tell me about a time…" | Low. No values were published or read, so this is the persona's stem, not a company value. | Selection scaffold with its honest branch. | F1 and F2 |
| Peer Evaluator | 0, dropped | n/a | Not plausible for a hiring-manager relationship. | n/a | none |

Depth: top personas get 5 and 4 questions, mid 3, low 2. Total 18.

## Question banks

Question types: EXP, JD, CASE, VAL. CO is not included because research did not run. A hypothetical figure in a CASE question is the interviewer's; none is your data.

### Skeptic (A), weight top

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "The JD asks for live events across two titles. What in your background shows you can do two?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Hold on what you ran: one main title, weekly drops, two years, in those words. Then give your own plan for the second title, labelled as a plan. Answer slot: if you have planned or run work across more than one title, say what and how you decided. If you have not, say so plainly and give your plan for the second. Hold through two follow-ups by returning to the calendar you ran, never by adding a title. | **The highest-ROI prep in this pack.** F1 is the JD's first requirement and the widest gap in the material, so this objection will arrive in some form. |
| A2 | "Four years on a puzzle game. Is that live-service work?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio"; [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Say what the title ran: weekly content drops, for two years. Let the interviewer decide the label. Do not call it live-service on your own account, and do not call yourself a producer; your title was associate producer. | F5 is a presentation gap: the years reach the requirement, the label does not. |
| A3 | "This role coordinates design, art, engineering and community on every update. You've never led a team. How does that work?" | JD | [grounded] "Never led a team" | Plain acknowledgment: "I haven't led a team." Then what you did across roles without authority, at the quote's scope. Answer slot: if you coordinated work across other disciplines on your title, say which and how the handoff ran. If you did not, say so plainly and describe how you would run one update's handoffs. Do not claim authority you did not have. | F2 is discovery and the leadership negative covers leading, not coordinating. Do not stretch the negative to cover F2. |
| A4 | "If an event's goal were purchases, how would you approach it?" | CASE | [grounded] "never worked on a game with in-app purchases" | Plain acknowledgment: "I have never worked on a game with in-app purchases." Then how you would learn it, as a plan: which numbers you would ask for first, and from whom. Do not describe monetization work or knowledge you have not stated. | Stated negative on a topic the JD does not name but mobile live events often meet. The pattern is [generic]. |
| A5 | "What would a QA lead say is unclear in the checklist you wrote?" | JD | [grounded] "Wrote the release checklist our QA team still uses" | Name the step most likely to be misread, and how you would find out from the people who use it. Answer slot: if QA has raised a change, say what and what you did. If no one has, say so plainly and say how you would ask them. | JD requirements on release control and written communication. Tests whether the document is as good as it is said to be. |

### Case / Strategist (B), weight top

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Retention on one of your two titles has fallen for three weeks. You have a week. Where do you start?" (hypothetical figures, none about you) | CASE | [generic] | Clarify what changed (build, event, content, market) and what the drop is measured against. Segment before you diagnose: new versus returning players, and event cohorts. Name the one metric you would check first and what result would make you stop. Name two risks: a change you do not know about, and a metric counted differently. | Structure and clarity score here. No claim about this studio is made. |
| B2 | "A release slips two days before a live event. Walk me through the next 48 hours with QA and design." | JD | [grounded] "Wrote the release checklist our QA team still uses" | Speak in order: what the checklist says about a slip, who decides go or no-go, what design needs to know, what the community team hears. Say which step you protect and which you move. Use the checklist as the spine, at the quote's scope: you wrote it, QA uses it. Answer slot: if you have run a slip or a go/no-go call, say what you decided. If not, say so and give your plan. | JD release requirement as a live problem. The checklist is your only release-control evidence, so it carries the story. |
| B3 | "Design wants a new reward reviewed by art and community in the same week as an engineering freeze. How do you run that week?" | JD | [generic] | Structure: the decision the week must reach, the reviews that can run in parallel, the one that cannot, and what you cut if time runs out. Say what you would write down for each team and when. No past claim. | JD coordination requirement as a live problem. [generic] because it is a pattern for the role, not this studio. |
| B4 | "Sketch a content calendar for a title that has just launched in two markets. What goes on the first quarter?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Start from the cadence you have run: weekly drops for one title. Then what changes with two markets: time zones, local events, release windows. Answer slot: if you have set a calendar across more than one market, say how. If not, say so plainly and say how you would split the first quarter. | Content calendar requirement as a live problem, anchored in the calendar you ran. |

### Prober (C), weight 3

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Those monthly retention numbers you presented. How were they counted?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Say what the figure measured, in your words. If you built the count, name the definition and the window. Answer slot: if you built it, say which definition and window. If someone else built the count, say so plainly and say what you did with it. If there was no such step, say so. Do not reconstruct a method you do not stand behind. | JD retention requirement. No figure is quoted, so there is no defend-the-number slot yet. |
| C2 | "Which assumption behind those retention figures would you defend least?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Name the weakest assumption before they do, in your words. None is in the material. Answer slot: if you know one (a cohort, a window, a platform split), name it and what it would change. If you do not know how the figure was counted, say that plainly. | The weakest-assumption move is what a Prober scores. None is quoted, so none is supplied. |
| C3 | "Take me through a post-event review you ran. What did you measure, and what changed?" | JD | [grounded] "Presented the monthly retention numbers to the studio head" | Story-mapped only as far as the quote carries: you presented monthly retention to the studio head. Answer slot: if you ran or took part in a review after a content event, say which measures you reported and what changed. If you did not run one, say so plainly and name the first two measures you would set for an event review. Never describe a review your material does not show. | JD ownership requirement. F3 is low confidence, so the answer is held to the quote. |

### Pressure (D), weight 2

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why should we hire someone who has never led a team over someone who has?" | JD | [grounded] "Never led a team"; [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Pause. Restate the question. Concede the leadership point first: "I haven't led a team." Hold the one thing your material carries: the calendar you ran for two years. Hold through two follow-ups. Concede only what is true, that you have not led people. Do not claim a leadership record. | Composure test on the one negative your material states. The hold is what the quote carries, no stronger. |
| D2 | "That checklist QA still uses. How much of it was actually you?" | JD | [grounded] "Wrote the release checklist our QA team still uses" | Hold on what you wrote. If QA changed it or others added to it, say so, in your words, and let that stand. Answer slot: if you wrote the whole checklist, say so. If others changed it, say what they changed and what remained yours. Do not add QA's input you did not see. | Attribution pressure. Hold, then concede the split rather than defending the whole. |

### Conversational (E), weight 2

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So — walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio"; [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | A 90-second arc: the puzzle studio, the title, the calendar, the checklist, the retention reporting, and why live operations on mobile, in your words. Each beat is one of your sentences. Nothing added. | Casual openers are scored. The arc draws only on sentences you gave me. |
| E2 | "What are you playing right now, and what has it taught you about live events?" | JD | [generic] | Name a mobile title you actually play and one thing it does with its events. Do not name a title you do not play. If you do not play mobile games, say so and name what you do play. | A casual question on a JD topic. [generic] because the title is yours to name. |

### Values / Behavioral (F), weight 2

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Tell me about a time you had to tell a team their date would not hold." | VAL | [grounded] "Wrote the release checklist our QA team still uses" | Selection scaffold: a time you held a release date under pressure, with a named stake, a moment you did not fold, and a relationship intact at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material carries: the checklist and how QA uses it. | Open prompt. Theme from the persona stem and the JD's release line. No company value is named. |
| F2 | "When did you choose a player's experience over a number?" | VAL | [generic] | Selection scaffold: a time you chose the player-facing fix over a metric target, what you gave up, and what happened next. If no such time comes to mind, say so plainly, then say how you weigh a retention figure against a player complaint. | Open prompt, persona stem. No claim about your past is made. |

Total: 18 questions.

## Requirement coverage

| JD requirement | Question IDs |
|---|---|
| Plan and run the live-events calendar for two of our mobile titles | A1, B4 |
| Coordinate design, art, engineering and community teams on each update | A3, B3 |
| Own the post-event review and the KPIs it reports | B1, C2, C3 |
| Manage the release checklist with QA | A5, B2, D2 |
| 3+ years producing live-service games or apps | A2 |
| Experience running a content calendar | A1, B4 |
| Comfortable with player-retention metrics | B1, C1, C2 |
| Clear written communication | A5 |
| Not in the JD, earns a question: the negatives you stated | A3, A4, D1 |

## Reverse questions

Each one is for Tobias, and each has a reason it lands.

1. "What do the next two live events on the calendar look like, and where would you want someone in this role to start?" Lands because it treats the calendar as work already in motion.
2. "After an event, how does the post-event review get written, and what happens to its KPIs afterwards?" Lands because it asks for the process on the JD's ownership line, without asking for the answer.
3. "Where does the release checklist break most often?" Lands because it shows you already treat the checklist as a living document.
4. "How do the two titles' calendars avoid colliding with each other?" Lands because it names the part of the role most likely to be hard.
5. "What would you want the person in this role to have worked out by the end of the first month?" Lands as a clear, answerable question about success.
6. "What has worked for people in this role before?" Lands because it invites a manager to describe what they value, in their own words.

## Sources

Provided documents: the job description (quoted in the fit snapshot), and your background (quoted from your message).

Searches sent, all refused by the host:

- "Saltmarsh Games values": refused
- "Saltmarsh Games interview process live operations producer": refused
- "Saltmarsh Games mobile studio news 2026": refused
- "Tobias Wrenfield Saltmarsh Games Head of Live Operations": refused

Fetches sent: none.

Research tier: L1 — searches 4 of 6, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | unavailable | Values cheat sheet, not built. No values round detected, so no VAL questions are tied to a company value. |
| 2. Saltmarsh Games interview process, live operations | unavailable | Loop structure. Persona weights are the hiring-manager prior, flagged as an assumption. |
| 3. Saltmarsh Games strategy / recent news | unavailable | CO questions, grounding brief. Without them, the CASE questions are generic. |
| 4. Tobias Wrenfield, Saltmarsh Games | unavailable | Interviewer read and reverse questions tied to his path. Reverse questions are role-generic. |
| 5. Representative live operations producer JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions. |

## Sections not included

Prep triage (prep time not stated). Graded deliverables (none declared). Grounding brief (no strategy research). Reading the interviewer (no public footprint read). Values cheat sheet (no values round detected). Delivery coaching (no assessment provided).

## Upgrade menu

- Tobias's round details, or the recruiter's note on what the hour covers → the persona weights and question mix for the real session, in place of the hiring-manager assumption.
- Saltmarsh's values page, pasted → a values cheat sheet and VAL questions named to its principles.
- Web search allowed in this session → reruns of targets 1 to 4: values, loop structure, strategy, and Tobias's public footprint. This unlocks CO questions and an interviewer read. A deeper pass (deep research) is available once, up to 6 more searches and 2 more fetches, several more minutes. Say if you want it.
- A calendar you ran, or the checklist with names removed → F4 and F6 gain inspectable proof, and "show me one" has an answer.
- A retention figure you can speak to, with its definition → C1 and C2 get a number to defend, and the defend-the-number slots open.
- An example of coordinating design, art, engineering or community → F2 moves from discovery to a quote, and A3 gets a story.
- A writing sample → F8 gets inspectable proof.
- Days you have before Friday → the prep triage section, sized to the time.
