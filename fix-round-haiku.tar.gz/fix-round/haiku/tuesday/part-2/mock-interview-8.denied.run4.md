Your prep pack is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-tuesday-part-2-rooms-case-8-denied-cec36e7b/b7d356fc-e928-4221-9c46-f629e9204d6d/scratchpad/ashgrove_member-experience-lead_interview_pack.md`. I treated the three rounds as a loop, so each round has its own persona weights and question bank, and they share one fit snapshot. I haven't run any drills yet.

# Ashgrove Credit Union: Member Experience Lead, interview pack (loop)

Prepared 11 November 2026 for Dara. Three rounds on 20 November 2026. Interviewers are not yet named, so personas are weighted by round, not by person. No dossier was present. No web search was run; every input is one you supplied.

## How to use + type key

Personas describe how a question arrives. Types describe what is being scored. Guidance is scaffolding, not a script. Rehearse only what you actually did, in your own words.

| Type | Meaning |
|---|---|
| VAL | Behaviour against Ashgrove's published values |
| EXP | What you did in your own past work, and how exactly |
| JD | Whether you can do the listed job, gaps included |
| CO | Ashgrove's strategy and where you fit it |
| CASE | A live problem from the role, delivered now |

Question IDs are per round: R1, R2 or R3, then the persona letter, then the number. Answer slots are instructions for the interview, not questions to me.

## Fit snapshot

Sources: "your message" is your background message. "JD" is the job description you pasted. The strategy brief was summarised in your message, not pasted, so quotes from it are your summary.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" (JD) | "6 years in retail banking, the last 3 as a branch supervisor" (your message) | medium | [grounded] | none | Your sentence already reaches it: "Six years in retail banking, the last three as a branch supervisor." A branch is customer-facing; how you describe it is your call. Confidence is medium because nothing inspectable backs the years yet. |
| F2 | "experience handling regulated complaints" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | discovery | Your material says formal complaints, not regulated ones, and does not show whether a regulatory standard or timescale applied. Say that as the pack's observation. Answer slot: if the complaints were held to a standard or timescale, say which and how you tracked it; if not, say so and say what the log did hold. |
| F3 | "Own the member complaints process end to end across branches and the contact centre" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | transferability | Adjacent work at one branch's log. The JD asks for end to end across branches and the contact centre. Bridge stays at the quote's scope: "I handled the branch's formal complaints log." Answer slot: what happened to a complaint after it left the log. If you saw it through, say how; if not, say so. |
| F4 | "report monthly on complaint volumes and resolution times" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | medium | [grounded] | discovery | The sheet reaches monthly complaints reporting. Your material does not show whether it held resolution times. Answer slot: if it did, say which measures and how each was counted; if not, say so and say what it did hold. |
| F5 | "comfortable with Excel reporting" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | medium | [grounded] | none | The quote reaches Excel reporting in the role's terms. Expect to be asked to show the sheet: say what it does and who uses it. |
| F6 | "coach branch supervisors on escalations" (JD) | "trained new tellers on our escalation script" (your message) | medium | [grounded] | transferability | Adjacent: you trained tellers, not supervisors. Bridge: "I trained new tellers on our escalation script." Limit: tellers. Answer slot: if you coached a supervisor or anyone through a live escalation, say what you did; if not, say so and say how you would coach a supervisor. |
| F7 | "work with digital teams on self-service journeys" (JD) | none given | none | [grounded] | discovery | Silence is not absence, so no limit is written for you. Answer slot: if you have worked on a digital or self-service change, say what it was and your part in it; if not, say so plainly and say how you would learn the journeys first. |
| F8 | "confident presenting to senior leaders" (JD) | "I've never presented to anyone above regional level" (your message) | none | [grounded] | capability | Your own stated absence. Words: "I've never presented to anyone above regional level." Then the plan, said as a plan, never as a past. |
| F9 | "the contact centre" (JD, from "across branches and the contact centre") | "Never worked in a contact centre" (your message) | none | [grounded] | capability | Your own stated absence. Words: "I haven't worked in a contact centre." Then how you would learn it, said as a plan. |
| F10 | "across branches and the contact centre" (JD). No JD line states location or travel. | none given | none | [inferred] | hard_gate | Derived from the JD's "across branches" and the strategy brief's plan to consolidate eight branches into five hubs in 2027. Your material does not establish whether you can work across the network, including travel. Surfaced here, not bridged. The one question is asked at the end of this message. |

Routing notes: F1, F5 and F7 carry the quotes that reach or touch their requirements. F8 and F9 use your own negatives, so they are plain acknowledgments, not claims. F10 is the one gate row.

## Grounding brief

From the strategy brief as you summarised it:

- Move 40% of member service to digital channels by 2028.
- Consolidate eight branches into five hubs over 2027.
- Launch a small-business lending product in Q1 2027.
- The main competitive pressure is app-only banks.

Vocabulary to use: "digital channels", "member service", "hubs". The brief was published in July 2026, so it is current; do not describe any branch's place in the consolidation unless you know it. Say "the brief" when you cite it.

## Persona table

### Round 1: recruiter screen, 30 minutes

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational | Open background ask, why Ashgrove, logistics | High, 4 questions. A recruiter screen's prior is conversational, and the screen checks logistics and motivation | A 90-second arc; treat casual JD topics as scored |
| Skeptic (light) | Contact centre and digital gaps, why leave a supervisor role | Medium-low, 2 questions. Light by prior; the email names no focus area | Plain acknowledgment, then the plan |
| Values / Behavioral (light) | One values probe | Low, 2 questions. The values are scored at the panel; a recruiter may test fit early | Story selection with the honest branch |

### Round 2: Head of Member Services (your prospective manager), 45 minutes

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | Scenario and past-behaviour questions | High, 5 questions. The recruiter wrote "mostly behavioural", which overrides the hiring-manager prior's case tilt | STAR shape: "we" for context, "I" for contribution |
| Skeptic | Gap probes: contact centre, presenting, digital | Medium, 3 questions. A manager is buying down the gaps | Name the gap first, in your words, then the plan |
| Case / Strategist | One live problem on digital or complaints | Low, 2 questions. The prior is case-heavy; "mostly behavioural" lowers it | Clarify, then segment, then the measure |

### Round 3: panel of two branch managers, 60 minutes, values-scored, 20-minute escalation case

Panel members are not named, so weights are by round, not by person.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | Four values probes, scored against the four published values | High, 4 questions. The recruiter wrote that the panel "scores against the four values" | Map each value to a story only where your material carries one; otherwise the honest branch |
| Case / Strategist | A 20-minute complaint escalation case, with a hold | High, 3 questions. The case is the largest single block of the round | Clarify the facts, structure the decision, keep hold of the member's problem |
| Peer Evaluator | The seam between branches and the contact centre | Medium, 2 questions. Branch managers work the same network; the seam is where a hire adds or lightens load | Propose seam principles, not a known seam |
| Pressure | Time-boxed challenges to a credential | Low, 2 questions. Not announced; kept because panels time-box | Pause, restate, hold, then concede the specific gap |

## Question banks

### Round 1 (recruiter screen)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R1-A1 | "Walk me through your background in a few minutes." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" (your message) | 90-second arc: six years in retail banking, the last three as a branch supervisor. Then the three things your message states: the formal complaints log, training tellers on the escalation script, the monthly spreadsheet. Each in your words. Add no figures you have not given. | F1 opens the arc; F2 to F5 supply its middle. The arc should land in 90 seconds. |
| R1-A2 | "Why Ashgrove, and why now?" | CO | [grounded] "move 40% of member service to digital channels by 2028" (the brief, as you summarised it); [grounded] "I handled the branch's formal complaints log" (your message) | Name one line from the brief that bears on complaints, then tie it to the log you handled, in those words. If your reason is different, say the real reason. | Motivation is scored against the brief. The answer should sound current, not archival. |
| R1-A3 | "What have you done with digital or self-service journeys?" | JD | [grounded] "work with digital teams on self-service journeys" (JD) | Answer slot: if you have worked on a digital or self-service change, say what it was and your part; if not, say so plainly and say how you would learn the journeys. | F7; the recruiter will hear a silence here, so the honest answer is ready before the question. |
| R1-A4 | "Can you work across the branch network, the contact centre and the hubs, including travel?" | JD | [inferred] "across branches and the contact centre" (JD), derivation: consolidation into hubs in the brief | Answer with your true position, plainly. If travel or location limits you, say so. Do not offer a workaround your material does not show. | F10: the one gate. A screen checks knockouts early. |
| R1-B1 | "Your background is branch retail. What would you find hardest about a contact centre?" | JD | [grounded] "Never worked in a contact centre" (your message) | Plain acknowledgment first: "I haven't worked in a contact centre." Then what you expect to find hard, labelled as expectation, from the branch's formal complaints log. | F9; the largest gap, so the plain acknowledgment comes first, not last. |
| R1-B2 | "Why are you leaving a branch supervisor role now?" | EXP | [grounded] "the last 3 as a branch supervisor" (your message) | Your real reason, in your words. The material gives no reason, so the pack gives you none. Scaffold: name the change you want and what in this role answers it. If one part of the reason is one you would rather not say, say the part you can stand behind. | Motivation consistency is the screen's risk; a stated reason can be checked against the JD. |
| R1-C1 | "Which of Ashgrove's values fits how you work, and why?" | VAL | [grounded] "I handled the branch's formal complaints log" (your message) | Pick one of the four published values, one line on why, then one moment from the log. If no moment comes to mind, say so plainly and give the nearest thing the log carries. | A light values probe. Do not claim a story the material does not show. |
| R1-C2 | "Tell me about a time you had to tell a member something they did not want to hear." | VAL | [generic] open prompt; theme from the published value "Plain Words" (values page) | Selection scaffold: a time you gave a member a no or a bad answer; say what you said in plain words and how it landed. If none comes to mind, say so plainly, then give the nearest thing your material carries: the log, or how you would handle it. | The guidance makes no claim about you; the story is yours to choose. |

### Round 2 (Head of Member Services)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R2-A1 | "Tell me about a time you handled a formal complaint." | EXP | [grounded] "I handled the branch's formal complaints log" (your message) | Story map: the log, handled, in the branch. Then what happened after it left the log: where it went and who decided the outcome. Answer slot: if you decided or saw it through, say how, in your own words; if not, say so plainly and describe your part. Hold through two follow-ups by returning to the log. | F3 is the end-to-end gap and the manager will test it. |
| R2-A2 | "When did you put a member ahead of an internal target or a process?" | VAL | [generic] open prompt; theme from "Members First, Always" (values page) | Selection scaffold: a time a rule or target was in the way of a member; say what you chose and what it cost. If none comes to mind, say so and give the nearest from your log. | A values probe with no claim about you. |
| R2-A3 | "Tell me about a time you had to tell your manager something unpopular." | VAL | [grounded] "the last 3 as a branch supervisor" (your message) | Selection scaffold: a time you disagreed with a manager about a complaint, a process or a number; say what you said, in what words, and what happened. Honest branch if none. | Rehearses the "hard truth landed" answer without supplying the ending. |
| R2-A4 | "How have you coached someone through an escalation?" | JD | [grounded] "trained new tellers on our escalation script" (your message); [grounded] "coach branch supervisors on escalations" (JD) | Say you trained tellers on the script, in those words. Answer slot: if you coached a supervisor or anyone through a live escalation, say what you did; if not, say so and say how you would coach a supervisor, as a plan. | F6; the transferability gap. |
| R2-A5 | "Tell me about a process problem you noticed and kept hold of until it was fixed." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" (your message); [generic] scaffold from "Own the Fix" (values page) | Scaffold: a problem you found and kept hold of. If the nearest is the spreadsheet, say what it fixed, only if you know, and whose fix it was. If you raised a problem and someone else fixed it, say that: the value is holding it, not claiming the fix. | Own the Fix is scored on holding, not on the solution. |
| R2-B1 | "Where would you be weakest on day one?" | JD | [grounded] "Never worked in a contact centre" (your message); [grounded] "I've never presented to anyone above regional level" (your message) | Name the contact centre first: "I haven't worked in a contact centre." Then a plan for the first month, stated as a plan. Name presenting only if asked: "I've never presented to anyone above regional level." | The manager's most likely probe; F8 and F9. |
| R2-B2 | "You have handled formal complaints in a branch. What changes when a complaint comes in by phone or app?" | JD | [grounded] "I handled the branch's formal complaints log" (your message); [grounded] "move 40% of member service to digital channels by 2028" (the brief, as you summarised it) | Answer from the branch side only. For phone or app, say what you would expect to change, labelled as a plan. Do not claim phone or app handling. | F7 and the strategy shift arrive in one question. |
| R2-B3 | "Have you presented to anyone senior, and to whom?" | JD | [grounded] "I've never presented to anyone above regional level" (your message) | Answer slot: if you have presented at regional level, say who and about what; if not, say so, using the words above, and say how you would prepare for a senior audience. | F8. The question allows the premise to be false; so should the answer. |
| R2-C1 | "The regional manager reads your monthly sheet. What would you change about how complaints are reported?" | CASE | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" (your message); [grounded] "report monthly on complaint volumes and resolution times" (JD) | Structure: purpose, reader, the decision the report drives, then which measure to add. Do not claim the sheet holds resolution times (F4). | A live problem on your own work, at the level of purpose, not contents. |
| R2-C2 | "Digital is meant to take 40% of member service by 2028. Where would complaints move with it, and what would you watch?" | CASE | [grounded] "move 40% of member service to digital channels by 2028" (the brief, as you summarised it); [grounded] "work with digital teams on self-service journeys" (JD) | Clarify what counts as a digital channel, segment complaints by channel, then name the measure to watch: volume and resolution time by channel. Hold the weakest assumption: that complaints move with volume. Do not claim digital experience (F7). | CO and CASE together; the manager's altitude test. |

### Round 3 (panel of two branch managers)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R3-A1 | "Tell me about a complaint you handled where the member's view and the process pointed different ways." | VAL | [grounded] "I handled the branch's formal complaints log" (your message) | Scaffold: one complaint where the rule and the member disagreed. Say which side you took and why. If none from the log comes to mind, say so and give the nearest thing, and what you did with it. | Members First. Values are scored here. |
| R3-A2 | "Tell me about an explanation you gave that did not land. What did you change?" | VAL | [grounded] "trained new tellers on our escalation script" (your message) | Scaffold: an explanation that did not land and what you did next. Answer slot: if you reworded the script so members understood it, say what and why; if not, say so and say what you would change. | Plain Words; a probe on whether you noticed the words were wrong. |
| R3-A3 | "Tell me about a time a figure you were given did not tell the whole story about a branch or its town." | VAL | [generic] open prompt; theme from "Neighbours, Not Numbers" (values page) | Scaffold: a time you looked behind a figure. Your nearest is the monthly sheet, which is figures: if you only used figures as they came, say that plainly and say what you would check first. Do not describe local knowledge the material does not show. | This is the value most at risk from your sheet. The honest answer is the strongest one here. |
| R3-A4 | "Tell me about a problem you found and kept hold of until it was solved." | VAL | [generic] open prompt; theme from "Own the Fix" (values page); [grounded] "I built the monthly complaints spreadsheet our regional manager uses" (your message) | Scaffold: a problem you found and held. If the spreadsheet is your fix, say what it fixed and how you would know. If it was your manager's request, say so and what you did next. Honest branch if none. | Own the Fix is scored on holding. |
| R3-B1 | The 20-minute case: "A member has complained twice about a charge. The branch says it is resolved; the member says it is not and asks for escalation. Talk us through the next 20 minutes." | CASE | [generic] | Run it in order: about three minutes to clarify what the record shows and what the member actually asked for; about five to structure the decision; about ten to decide and say what you would record; about two to say what you would tell the member, in plain words. Keep hold of it until it is solved. Name the internal process you would check; do not invent its steps. | The panel's largest scored block. Plain Words and Own the Fix both run through it. |
| R3-B2 | "The branch manager disagrees with your decision and says the member is being unreasonable. What now?" | CASE | [generic] | Hold the member's side in one sentence. Re-check the facts you asked for. Concede only what the record shows. Do not fold to restore harmony. | A hold-then-concede pressure inside the case. |
| R3-B3 | "Complaints from the contact centre are rising while branch complaints fall. Where do you look first?" | CASE | [grounded] "Own the member complaints process end to end across branches and the contact centre" (JD); [grounded] "Never worked in a contact centre" (your message) | Clarify whether the rise is volume or the same complaints arriving another way. Check the measure is counted the same in both places. Then say which team you would bring in. Say the plain acknowledgment: "I haven't worked in a contact centre." | F3 and F9 together. |
| R3-C1 | "How would you coach a branch supervisor who sends you every escalation?" | JD | [grounded] "coach branch supervisors on escalations" (JD); [grounded] "the last 3 as a branch supervisor" (your message) | Say what you would look for first, then how you would coach. You were a supervisor; do not claim you coached one unless you did. Answer slot: if you coached a supervisor on escalations, say how; if not, say so and give the sequence: first what the escalations had in common, then the decision talked through with them. | Peer-level coaching; F6. |
| R3-C2 | "Where is the seam between a branch and the contact centre, and what happens when we disagree about a complaint?" | JD | [grounded] "across branches and the contact centre" (JD); [grounded] "Never worked in a contact centre" (your message) | Propose seam principles rather than claiming to know the seam. Say the plain acknowledgment. Then what you would bring to the seam from the branch side. | The peer probe; it returns the contact-centre gap in collegial form. |
| R3-D1 | "Sixty seconds: why should we pick you over someone who has run a contact centre?" | JD | [grounded] "Never worked in a contact centre" (your message); [grounded] "6 years in retail banking, the last 3 as a branch supervisor" (your message) | Pause and restate. Anchor in six years, the last three as a branch supervisor, and what you handled. Then concede the gap specifically: "I haven't worked in a contact centre." Hold the branch case through two follow-ups. Never say the contact centre does not matter. | The most predictable objection to you, and the highest-return rehearsal in this pack. |
| R3-D2 | "That monthly spreadsheet: how much of it was actually you?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" (your message) | Precise attribution: what you built and what the manager does with it. Name the weakest assumption behind any figure you would defend, in your own words, if you know one. Concede where you do not know how a number was counted. | F5 and F4; a credibility probe on your own work. |

### Requirement coverage

| JD requirement | Question IDs | Notes |
|---|---|---|
| 4+ years in financial-services customer operations | R1-A1 | F1 |
| Experience handling regulated complaints | R2-A1 | Answer slot (F2) |
| Own the member complaints process end to end across branches and the contact centre | R2-A1, R3-A1, R3-B3 | F3, F9 |
| Report monthly on complaint volumes and resolution times | R2-C1 | Answer slot (F4) |
| Coach branch supervisors on escalations | R2-A4, R3-C1 | F6 |
| Work with digital teams on self-service journeys | R1-A3, R2-B2, R2-C2 | Answer slot (F7) |
| Comfortable with Excel reporting | R2-C1, R3-D2 | F5 |
| Confident presenting to senior leaders | R2-B1, R2-B3, R3-D1 | F8 |
| Across branches and the contact centre (the gate) | R1-A4 | F10 |

## Values / principles cheat sheet

Condition met: the recruiter wrote that the panel "scores against the four values", and you supplied the values text.

| Value | Working meaning (paraphrased) | Your mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | F3: "I handled the branch's formal complaints log." The log is the carrier; the decision is not in the quote. Scaffold: a complaint where the rule and the member pulled apart. Honest branch: if none, say so and give the log's nearest case. |
| Plain Words | If a member needs it explained twice, the wording was wrong | F6: "trained new tellers on our escalation script." The script is the carrier; whether you changed its words is not in the quote. Scaffold: an explanation that did not land. Honest branch: if you did not reword it, say so and say what you would change. |
| Neighbours, Not Numbers | Each branch is part of its town | No quote carries a story. The risk is F5, a numbers-led sheet. Scaffold: a time you looked behind a figure. Honest branch: say plainly if you have no local story; do not supply one. |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | F5 and the sheet: "I built the monthly complaints spreadsheet our regional manager uses." Scaffold: a problem you found and held. Honest branch: if the sheet was the manager's request, say so and what you did next. |

## Reverse questions

No interviewer profile exists, so none is tied to a career path. Each question below has a "why it lands".

1. (Round 1) "How does the shift to digital show up in the complaints you see now?" Why it lands: it shows you read the brief and connect it to complaints, not to slogans.
2. (Round 2) "What did the last person in this role leave well, and what did they leave unfinished?" Why it lands: it signals you want to take the work over, not start from zero.
3. (Round 2) "How does the team measure a complaint handled well, and where does that measure fail?" Why it lands: it tests Own the Fix and Plain Words, and invites the manager's judgment.
4. (Round 2) "What would make the first 90 days a success in your eyes?" Why it lands: you set the bar with them, and their answer becomes the test.
5. (Round 3, reciprocity for peers) "What could a new person do in their first month that would genuinely help your branches?" Why it lands: it turns a credential probe into a collegial question.
6. (Round 3) "Where does a branch most need the contact centre's help, and where does it least get it?" Why it lands: it shows you think at the seam, which is where the role lives.

## Prohibited claims

Built from the fit snapshot. None of these may be asserted, softened or implied in any answer, slot or drill.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end across branches and the contact centre | Inflated form of F3 | "I handled the branch's formal complaints log." The limit is the pack's observation: your material says one branch's log. |
| Reported on resolution times | Inflated form of F4 | F4's quote at its own scope. The material does not show resolution times. |
| Coached branch supervisors on escalations | Inflated form of F6 | "I trained new tellers on our escalation script." |
| Presented to senior leaders | Negative you stated, F8 | "I've never presented to anyone above regional level." Plain acknowledgment; no slot. |
| Worked in a contact centre | Negative you stated, F9 | "I haven't worked in a contact centre." Plain acknowledgment; no slot. |

## Prep triage

Dropped: prep time is not yet known. The closing question asks it. Once you answer, a triage section will sequence the work across the nine days.

## Sources

- Provided by you: the JD text; the values text, copied from ashgrovecu.org/about/values on 11 November 2026; your background message; the recruiter's email on rounds and the values scoring; the strategy brief, as summarised in your message. Quotes from the brief are your summary, not the brief itself.
- Searches and fetches: none.

Research tier: L1, searches 0 of 6, fetches 0 of 2.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | The values text was supplied, so the values cheat sheet is built on it. |
| 2. Interview process | skipped | The recruiter's email fixes the three rounds, their lengths and the values scoring. |
| 3. Strategy and recent news | skipped | The strategy brief, as summarised, supplies current priorities and recent moves. |
| 4. Named interviewer | n/a | No names were given for the Head of Member Services or the panel. |
| 5. Representative JD | skipped | The JD was supplied. |

## Upgrade menu

- Interviewer names (Head of Member Services and the two branch managers) → per-person persona weights, an interviewer read, and reverse questions tailored to their paths.
- Whether complaints were held to a regulatory standard or timescale, and what the monthly sheet measured (volumes, resolution times) → turns F2 and F4 from discovery into answers you can give directly.
- The monthly spreadsheet, anonymised, or your CV as a file → an inspectable artifact that can raise the confidence of F4 and F5; quotes would then cite your CV rather than your message.
- The strategy brief pasted in full → verbatim quotes in the grounding brief and the question banks, instead of your summary.
- The recruiter's prep email with any named focus areas → coverage of those areas in the banks.
- Prep days before 20 November → the prep triage section.
- Deep research (L2): Ashgrove interview reports, the loop structure, and recent news; up to 6 further searches and 2 fetches, adding a few minutes. Offered once; it runs only if you say so.
- A `tuesday-dossier.md` → carries the gaps this prep exposed into later sessions.

---

Say the word and I'll run a drill on R3-D1, the question the pack names as the highest-return prep: the "why us over someone who has run a contact centre" challenge. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

Two things I need from you:

1. Can you work across the branch network, the contact centre and the hubs, including travel, and is location or travel a limit for you?
2. How many days do you have before 20 November, so I can add the prep triage section?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove_member-experience-lead_interview_pack.md -----
# Ashgrove Credit Union: Member Experience Lead, interview pack (loop)

Prepared 11 November 2026 for Dara. Three rounds on 20 November 2026. Interviewers are not yet named, so personas are weighted by round, not by person. No dossier was present. No web search was run; every input is one you supplied.

## How to use + type key

Personas describe how a question arrives. Types describe what is being scored. Guidance is scaffolding, not a script. Rehearse only what you actually did, in your own words.

| Type | Meaning |
|---|---|
| VAL | Behaviour against Ashgrove's published values |
| EXP | What you did in your own past work, and how exactly |
| JD | Whether you can do the listed job, gaps included |
| CO | Ashgrove's strategy and where you fit it |
| CASE | A live problem from the role, delivered now |

Question IDs are per round: R1, R2 or R3, then the persona letter, then the number. Answer slots are instructions for the interview, not questions to me.

## Fit snapshot

Sources: "your message" is your background message. "JD" is the job description you pasted. The strategy brief was summarised in your message, not pasted, so quotes from it are your summary.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" (JD) | "6 years in retail banking, the last 3 as a branch supervisor" (your message) | medium | [grounded] | none | Your sentence already reaches it: "Six years in retail banking, the last three as a branch supervisor." A branch is customer-facing; how you describe it is your call. Confidence is medium because nothing inspectable backs the years yet. |
| F2 | "experience handling regulated complaints" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | discovery | Your material says formal complaints, not regulated ones, and does not show whether a regulatory standard or timescale applied. Say that as the pack's observation. Answer slot: if the complaints were held to a standard or timescale, say which and how you tracked it; if not, say so and say what the log did hold. |
| F3 | "Own the member complaints process end to end across branches and the contact centre" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | transferability | Adjacent work at one branch's log. The JD asks for end to end across branches and the contact centre. Bridge stays at the quote's scope: "I handled the branch's formal complaints log." Answer slot: what happened to a complaint after it left the log. If you saw it through, say how; if not, say so. |
| F4 | "report monthly on complaint volumes and resolution times" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | medium | [grounded] | discovery | The sheet reaches monthly complaints reporting. Your material does not show whether it held resolution times. Answer slot: if it did, say which measures and how each was counted; if not, say so and say what it did hold. |
| F5 | "comfortable with Excel reporting" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | medium | [grounded] | none | The quote reaches Excel reporting in the role's terms. Expect to be asked to show the sheet: say what it does and who uses it. |
| F6 | "coach branch supervisors on escalations" (JD) | "trained new tellers on our escalation script" (your message) | medium | [grounded] | transferability | Adjacent: you trained tellers, not supervisors. Bridge: "I trained new tellers on our escalation script." Limit: tellers. Answer slot: if you coached a supervisor or anyone through a live escalation, say what you did; if not, say so and say how you would coach a supervisor. |
| F7 | "work with digital teams on self-service journeys" (JD) | none given | none | [grounded] | discovery | Silence is not absence, so no limit is written for you. Answer slot: if you have worked on a digital or self-service change, say what it was and your part in it; if not, say so plainly and say how you would learn the journeys first. |
| F8 | "confident presenting to senior leaders" (JD) | "I've never presented to anyone above regional level" (your message) | none | [grounded] | capability | Your own stated absence. Words: "I've never presented to anyone above regional level." Then the plan, said as a plan, never as a past. |
| F9 | "the contact centre" (JD, from "across branches and the contact centre") | "Never worked in a contact centre" (your message) | none | [grounded] | capability | Your own stated absence. Words: "I haven't worked in a contact centre." Then how you would learn it, said as a plan. |
| F10 | "across branches and the contact centre" (JD). No JD line states location or travel. | none given | none | [inferred] | hard_gate | Derived from the JD's "across branches" and the strategy brief's plan to consolidate eight branches into five hubs in 2027. Your material does not establish whether you can work across the network, including travel. Surfaced here, not bridged. The one question is asked at the end of this message. |

Routing notes: F1, F5 and F7 carry the quotes that reach or touch their requirements. F8 and F9 use your own negatives, so they are plain acknowledgments, not claims. F10 is the one gate row.

## Grounding brief

From the strategy brief as you summarised it:

- Move 40% of member service to digital channels by 2028.
- Consolidate eight branches into five hubs over 2027.
- Launch a small-business lending product in Q1 2027.
- The main competitive pressure is app-only banks.

Vocabulary to use: "digital channels", "member service", "hubs". The brief was published in July 2026, so it is current; do not describe any branch's place in the consolidation unless you know it. Say "the brief" when you cite it.

## Persona table

### Round 1: recruiter screen, 30 minutes

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational | Open background ask, why Ashgrove, logistics | High, 4 questions. A recruiter screen's prior is conversational, and the screen checks logistics and motivation | A 90-second arc; treat casual JD topics as scored |
| Skeptic (light) | Contact centre and digital gaps, why leave a supervisor role | Medium-low, 2 questions. Light by prior; the email names no focus area | Plain acknowledgment, then the plan |
| Values / Behavioral (light) | One values probe | Low, 2 questions. The values are scored at the panel; a recruiter may test fit early | Story selection with the honest branch |

### Round 2: Head of Member Services (your prospective manager), 45 minutes

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | Scenario and past-behaviour questions | High, 5 questions. The recruiter wrote "mostly behavioural", which overrides the hiring-manager prior's case tilt | STAR shape: "we" for context, "I" for contribution |
| Skeptic | Gap probes: contact centre, presenting, digital | Medium, 3 questions. A manager is buying down the gaps | Name the gap first, in your words, then the plan |
| Case / Strategist | One live problem on digital or complaints | Low, 2 questions. The prior is case-heavy; "mostly behavioural" lowers it | Clarify, then segment, then the measure |

### Round 3: panel of two branch managers, 60 minutes, values-scored, 20-minute escalation case

Panel members are not named, so weights are by round, not by person.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | Four values probes, scored against the four published values | High, 4 questions. The recruiter wrote that the panel "scores against the four values" | Map each value to a story only where your material carries one; otherwise the honest branch |
| Case / Strategist | A 20-minute complaint escalation case, with a hold | High, 3 questions. The case is the largest single block of the round | Clarify the facts, structure the decision, keep hold of the member's problem |
| Peer Evaluator | The seam between branches and the contact centre | Medium, 2 questions. Branch managers work the same network; the seam is where a hire adds or lightens load | Propose seam principles, not a known seam |
| Pressure | Time-boxed challenges to a credential | Low, 2 questions. Not announced; kept because panels time-box | Pause, restate, hold, then concede the specific gap |

## Question banks

### Round 1 (recruiter screen)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R1-A1 | "Walk me through your background in a few minutes." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" (your message) | 90-second arc: six years in retail banking, the last three as a branch supervisor. Then the three things your message states: the formal complaints log, training tellers on the escalation script, the monthly spreadsheet. Each in your words. Add no figures you have not given. | F1 opens the arc; F2 to F5 supply its middle. The arc should land in 90 seconds. |
| R1-A2 | "Why Ashgrove, and why now?" | CO | [grounded] "move 40% of member service to digital channels by 2028" (the brief, as you summarised it); [grounded] "I handled the branch's formal complaints log" (your message) | Name one line from the brief that bears on complaints, then tie it to the log you handled, in those words. If your reason is different, say the real reason. | Motivation is scored against the brief. The answer should sound current, not archival. |
| R1-A3 | "What have you done with digital or self-service journeys?" | JD | [grounded] "work with digital teams on self-service journeys" (JD) | Answer slot: if you have worked on a digital or self-service change, say what it was and your part; if not, say so plainly and say how you would learn the journeys. | F7; the recruiter will hear a silence here, so the honest answer is ready before the question. |
| R1-A4 | "Can you work across the branch network, the contact centre and the hubs, including travel?" | JD | [inferred] "across branches and the contact centre" (JD), derivation: consolidation into hubs in the brief | Answer with your true position, plainly. If travel or location limits you, say so. Do not offer a workaround your material does not show. | F10: the one gate. A screen checks knockouts early. |
| R1-B1 | "Your background is branch retail. What would you find hardest about a contact centre?" | JD | [grounded] "Never worked in a contact centre" (your message) | Plain acknowledgment first: "I haven't worked in a contact centre." Then what you expect to find hard, labelled as expectation, from the branch's formal complaints log. | F9; the largest gap, so the plain acknowledgment comes first, not last. |
| R1-B2 | "Why are you leaving a branch supervisor role now?" | EXP | [grounded] "the last 3 as a branch supervisor" (your message) | Your real reason, in your words. The material gives no reason, so the pack gives you none. Scaffold: name the change you want and what in this role answers it. If one part of the reason is one you would rather not say, say the part you can stand behind. | Motivation consistency is the screen's risk; a stated reason can be checked against the JD. |
| R1-C1 | "Which of Ashgrove's values fits how you work, and why?" | VAL | [grounded] "I handled the branch's formal complaints log" (your message) | Pick one of the four published values, one line on why, then one moment from the log. If no moment comes to mind, say so plainly and give the nearest thing the log carries. | A light values probe. Do not claim a story the material does not show. |
| R1-C2 | "Tell me about a time you had to tell a member something they did not want to hear." | VAL | [generic] open prompt; theme from the published value "Plain Words" (values page) | Selection scaffold: a time you gave a member a no or a bad answer; say what you said in plain words and how it landed. If none comes to mind, say so plainly, then give the nearest thing your material carries: the log, or how you would handle it. | The guidance makes no claim about you; the story is yours to choose. |

### Round 2 (Head of Member Services)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R2-A1 | "Tell me about a time you handled a formal complaint." | EXP | [grounded] "I handled the branch's formal complaints log" (your message) | Story map: the log, handled, in the branch. Then what happened after it left the log: where it went and who decided the outcome. Answer slot: if you decided or saw it through, say how, in your own words; if not, say so plainly and describe your part. Hold through two follow-ups by returning to the log. | F3 is the end-to-end gap and the manager will test it. |
| R2-A2 | "When did you put a member ahead of an internal target or a process?" | VAL | [generic] open prompt; theme from "Members First, Always" (values page) | Selection scaffold: a time a rule or target was in the way of a member; say what you chose and what it cost. If none comes to mind, say so and give the nearest from your log. | A values probe with no claim about you. |
| R2-A3 | "Tell me about a time you had to tell your manager something unpopular." | VAL | [grounded] "the last 3 as a branch supervisor" (your message) | Selection scaffold: a time you disagreed with a manager about a complaint, a process or a number; say what you said, in what words, and what happened. Honest branch if none. | Rehearses the "hard truth landed" answer without supplying the ending. |
| R2-A4 | "How have you coached someone through an escalation?" | JD | [grounded] "trained new tellers on our escalation script" (your message); [grounded] "coach branch supervisors on escalations" (JD) | Say you trained tellers on the script, in those words. Answer slot: if you coached a supervisor or anyone through a live escalation, say what you did; if not, say so and say how you would coach a supervisor, as a plan. | F6; the transferability gap. |
| R2-A5 | "Tell me about a process problem you noticed and kept hold of until it was fixed." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" (your message); [generic] scaffold from "Own the Fix" (values page) | Scaffold: a problem you found and kept hold of. If the nearest is the spreadsheet, say what it fixed, only if you know, and whose fix it was. If you raised a problem and someone else fixed it, say that: the value is holding it, not claiming the fix. | Own the Fix is scored on holding, not on the solution. |
| R2-B1 | "Where would you be weakest on day one?" | JD | [grounded] "Never worked in a contact centre" (your message); [grounded] "I've never presented to anyone above regional level" (your message) | Name the contact centre first: "I haven't worked in a contact centre." Then a plan for the first month, stated as a plan. Name presenting only if asked: "I've never presented to anyone above regional level." | The manager's most likely probe; F8 and F9. |
| R2-B2 | "You have handled formal complaints in a branch. What changes when a complaint comes in by phone or app?" | JD | [grounded] "I handled the branch's formal complaints log" (your message); [grounded] "move 40% of member service to digital channels by 2028" (the brief, as you summarised it) | Answer from the branch side only. For phone or app, say what you would expect to change, labelled as a plan. Do not claim phone or app handling. | F7 and the strategy shift arrive in one question. |
| R2-B3 | "Have you presented to anyone senior, and to whom?" | JD | [grounded] "I've never presented to anyone above regional level" (your message) | Answer slot: if you have presented at regional level, say who and about what; if not, say so, using the words above, and say how you would prepare for a senior audience. | F8. The question allows the premise to be false; so should the answer. |
| R2-C1 | "The regional manager reads your monthly sheet. What would you change about how complaints are reported?" | CASE | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" (your message); [grounded] "report monthly on complaint volumes and resolution times" (JD) | Structure: purpose, reader, the decision the report drives, then which measure to add. Do not claim the sheet holds resolution times (F4). | A live problem on your own work, at the level of purpose, not contents. |
| R2-C2 | "Digital is meant to take 40% of member service by 2028. Where would complaints move with it, and what would you watch?" | CASE | [grounded] "move 40% of member service to digital channels by 2028" (the brief, as you summarised it); [grounded] "work with digital teams on self-service journeys" (JD) | Clarify what counts as a digital channel, segment complaints by channel, then name the measure to watch: volume and resolution time by channel. Hold the weakest assumption: that complaints move with volume. Do not claim digital experience (F7). | CO and CASE together; the manager's altitude test. |

### Round 3 (panel of two branch managers)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R3-A1 | "Tell me about a complaint you handled where the member's view and the process pointed different ways." | VAL | [grounded] "I handled the branch's formal complaints log" (your message) | Scaffold: one complaint where the rule and the member disagreed. Say which side you took and why. If none from the log comes to mind, say so and give the nearest thing, and what you did with it. | Members First. Values are scored here. |
| R3-A2 | "Tell me about an explanation you gave that did not land. What did you change?" | VAL | [grounded] "trained new tellers on our escalation script" (your message) | Scaffold: an explanation that did not land and what you did next. Answer slot: if you reworded the script so members understood it, say what and why; if not, say so and say what you would change. | Plain Words; a probe on whether you noticed the words were wrong. |
| R3-A3 | "Tell me about a time a figure you were given did not tell the whole story about a branch or its town." | VAL | [generic] open prompt; theme from "Neighbours, Not Numbers" (values page) | Scaffold: a time you looked behind a figure. Your nearest is the monthly sheet, which is figures: if you only used figures as they came, say that plainly and say what you would check first. Do not describe local knowledge the material does not show. | This is the value most at risk from your sheet. The honest answer is the strongest one here. |
| R3-A4 | "Tell me about a problem you found and kept hold of until it was solved." | VAL | [generic] open prompt; theme from "Own the Fix" (values page); [grounded] "I built the monthly complaints spreadsheet our regional manager uses" (your message) | Scaffold: a problem you found and held. If the spreadsheet is your fix, say what it fixed and how you would know. If it was your manager's request, say so and what you did next. Honest branch if none. | Own the Fix is scored on holding. |
| R3-B1 | The 20-minute case: "A member has complained twice about a charge. The branch says it is resolved; the member says it is not and asks for escalation. Talk us through the next 20 minutes." | CASE | [generic] | Run it in order: about three minutes to clarify what the record shows and what the member actually asked for; about five to structure the decision; about ten to decide and say what you would record; about two to say what you would tell the member, in plain words. Keep hold of it until it is solved. Name the internal process you would check; do not invent its steps. | The panel's largest scored block. Plain Words and Own the Fix both run through it. |
| R3-B2 | "The branch manager disagrees with your decision and says the member is being unreasonable. What now?" | CASE | [generic] | Hold the member's side in one sentence. Re-check the facts you asked for. Concede only what the record shows. Do not fold to restore harmony. | A hold-then-concede pressure inside the case. |
| R3-B3 | "Complaints from the contact centre are rising while branch complaints fall. Where do you look first?" | CASE | [grounded] "Own the member complaints process end to end across branches and the contact centre" (JD); [grounded] "Never worked in a contact centre" (your message) | Clarify whether the rise is volume or the same complaints arriving another way. Check the measure is counted the same in both places. Then say which team you would bring in. Say the plain acknowledgment: "I haven't worked in a contact centre." | F3 and F9 together. |
| R3-C1 | "How would you coach a branch supervisor who sends you every escalation?" | JD | [grounded] "coach branch supervisors on escalations" (JD); [grounded] "the last 3 as a branch supervisor" (your message) | Say what you would look for first, then how you would coach. You were a supervisor; do not claim you coached one unless you did. Answer slot: if you coached a supervisor on escalations, say how; if not, say so and give the sequence: first what the escalations had in common, then the decision talked through with them. | Peer-level coaching; F6. |
| R3-C2 | "Where is the seam between a branch and the contact centre, and what happens when we disagree about a complaint?" | JD | [grounded] "across branches and the contact centre" (JD); [grounded] "Never worked in a contact centre" (your message) | Propose seam principles rather than claiming to know the seam. Say the plain acknowledgment. Then what you would bring to the seam from the branch side. | The peer probe; it returns the contact-centre gap in collegial form. |
| R3-D1 | "Sixty seconds: why should we pick you over someone who has run a contact centre?" | JD | [grounded] "Never worked in a contact centre" (your message); [grounded] "6 years in retail banking, the last 3 as a branch supervisor" (your message) | Pause and restate. Anchor in six years, the last three as a branch supervisor, and what you handled. Then concede the gap specifically: "I haven't worked in a contact centre." Hold the branch case through two follow-ups. Never say the contact centre does not matter. | The most predictable objection to you, and the highest-return rehearsal in this pack. |
| R3-D2 | "That monthly spreadsheet: how much of it was actually you?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" (your message) | Precise attribution: what you built and what the manager does with it. Name the weakest assumption behind any figure you would defend, in your own words, if you know one. Concede where you do not know how a number was counted. | F5 and F4; a credibility probe on your own work. |

### Requirement coverage

| JD requirement | Question IDs | Notes |
|---|---|---|
| 4+ years in financial-services customer operations | R1-A1 | F1 |
| Experience handling regulated complaints | R2-A1 | Answer slot (F2) |
| Own the member complaints process end to end across branches and the contact centre | R2-A1, R3-A1, R3-B3 | F3, F9 |
| Report monthly on complaint volumes and resolution times | R2-C1 | Answer slot (F4) |
| Coach branch supervisors on escalations | R2-A4, R3-C1 | F6 |
| Work with digital teams on self-service journeys | R1-A3, R2-B2, R2-C2 | Answer slot (F7) |
| Comfortable with Excel reporting | R2-C1, R3-D2 | F5 |
| Confident presenting to senior leaders | R2-B1, R2-B3, R3-D1 | F8 |
| Across branches and the contact centre (the gate) | R1-A4 | F10 |

## Values / principles cheat sheet

Condition met: the recruiter wrote that the panel "scores against the four values", and you supplied the values text.

| Value | Working meaning (paraphrased) | Your mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | F3: "I handled the branch's formal complaints log." The log is the carrier; the decision is not in the quote. Scaffold: a complaint where the rule and the member pulled apart. Honest branch: if none, say so and give the log's nearest case. |
| Plain Words | If a member needs it explained twice, the wording was wrong | F6: "trained new tellers on our escalation script." The script is the carrier; whether you changed its words is not in the quote. Scaffold: an explanation that did not land. Honest branch: if you did not reword it, say so and say what you would change. |
| Neighbours, Not Numbers | Each branch is part of its town | No quote carries a story. The risk is F5, a numbers-led sheet. Scaffold: a time you looked behind a figure. Honest branch: say plainly if you have no local story; do not supply one. |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | F5 and the sheet: "I built the monthly complaints spreadsheet our regional manager uses." Scaffold: a problem you found and held. Honest branch: if the sheet was the manager's request, say so and what you did next. |

## Reverse questions

No interviewer profile exists, so none is tied to a career path. Each question below has a "why it lands".

1. (Round 1) "How does the shift to digital show up in the complaints you see now?" Why it lands: it shows you read the brief and connect it to complaints, not to slogans.
2. (Round 2) "What did the last person in this role leave well, and what did they leave unfinished?" Why it lands: it signals you want to take the work over, not start from zero.
3. (Round 2) "How does the team measure a complaint handled well, and where does that measure fail?" Why it lands: it tests Own the Fix and Plain Words, and invites the manager's judgment.
4. (Round 2) "What would make the first 90 days a success in your eyes?" Why it lands: you set the bar with them, and their answer becomes the test.
5. (Round 3, reciprocity for peers) "What could a new person do in their first month that would genuinely help your branches?" Why it lands: it turns a credential probe into a collegial question.
6. (Round 3) "Where does a branch most need the contact centre's help, and where does it least get it?" Why it lands: it shows you think at the seam, which is where the role lives.

## Prohibited claims

Built from the fit snapshot. None of these may be asserted, softened or implied in any answer, slot or drill.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end across branches and the contact centre | Inflated form of F3 | "I handled the branch's formal complaints log." The limit is the pack's observation: your material says one branch's log. |
| Reported on resolution times | Inflated form of F4 | F4's quote at its own scope. The material does not show resolution times. |
| Coached branch supervisors on escalations | Inflated form of F6 | "I trained new tellers on our escalation script." |
| Presented to senior leaders | Negative you stated, F8 | "I've never presented to anyone above regional level." Plain acknowledgment; no slot. |
| Worked in a contact centre | Negative you stated, F9 | "I haven't worked in a contact centre." Plain acknowledgment; no slot. |

## Prep triage

Dropped: prep time is not yet known. The closing question asks it. Once you answer, a triage section will sequence the work across the nine days.

## Sources

- Provided by you: the JD text; the values text, copied from ashgrovecu.org/about/values on 11 November 2026; your background message; the recruiter's email on rounds and the values scoring; the strategy brief, as summarised in your message. Quotes from the brief are your summary, not the brief itself.
- Searches and fetches: none.

Research tier: L1, searches 0 of 6, fetches 0 of 2.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | The values text was supplied, so the values cheat sheet is built on it. |
| 2. Interview process | skipped | The recruiter's email fixes the three rounds, their lengths and the values scoring. |
| 3. Strategy and recent news | skipped | The strategy brief, as summarised, supplies current priorities and recent moves. |
| 4. Named interviewer | n/a | No names were given for the Head of Member Services or the panel. |
| 5. Representative JD | skipped | The JD was supplied. |

## Upgrade menu

- Interviewer names (Head of Member Services and the two branch managers) → per-person persona weights, an interviewer read, and reverse questions tailored to their paths.
- Whether complaints were held to a regulatory standard or timescale, and what the monthly sheet measured (volumes, resolution times) → turns F2 and F4 from discovery into answers you can give directly.
- The monthly spreadsheet, anonymised, or your CV as a file → an inspectable artifact that can raise the confidence of F4 and F5; quotes would then cite your CV rather than your message.
- The strategy brief pasted in full → verbatim quotes in the grounding brief and the question banks, instead of your summary.
- The recruiter's prep email with any named focus areas → coverage of those areas in the banks.
- Prep days before 20 November → the prep triage section.
- Deep research (L2): Ashgrove interview reports, the loop structure, and recent news; up to 6 further searches and 2 fetches, adding a few minutes. Offered once; it runs only if you say so.
- A `tuesday-dossier.md` → carries the gaps this prep exposed into later sessions.
