Your prep pack is saved at /tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-tuesday-part-2-rooms-case-8-denied-331ec9ce/b3a42b21-f31a-4fca-bcc3-38090ebc939a/scratchpad/ashgrove_credit_union_member_experience_lead_interview_pack.md. I built it as a loop, since the recruiter named three rounds on 20 November. Round 3 carries the values cheat sheet and the escalation case, because the panel scores against the values.

The pack is built only from what you gave me. The values and strategy are your copies, not live checks, and I have not seen the strategy brief itself.

Say the word and I'll play the Skeptic on R2-B1, the question the pack names as its highest-ROI prep: the contact centre and the eight-branch scope. I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

Two questions:
1. Can you work the base and travel the role needs? Neither the JD nor the recruiter's email says where the role is based or how much travel it involves. Location is a gate the pack can't settle until you tell me.
2. How much prep time do you have before 20 November? That decides whether the pack gets a prioritised schedule.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove_credit_union_member_experience_lead_interview_pack.md -----
# Interview prep pack: Member Experience Lead, Ashgrove Credit Union

**Interviews:** 20 November 2026, three rounds (nine days from 11 November).
- Round 1: 30 min with the recruiter.
- Round 2: 45 min with the Head of Member Services, your future manager, mostly behavioural.
- Round 3: 60 min with a panel of two branch managers, including a 20-minute complaint-escalation case. The panel scores against the four values.

**Mode:** Loop. One shared fit snapshot, then a mini-pack per round.

**Interviewers beyond the roles:** not yet named. Persona weights come from round-type priors, not from interviewer profiles.

---

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored.
- **Types:**
  - **VAL**: behaviour that shows a published value.
  - **EXP**: what you actually did in your past roles.
  - **JD**: the job's stated responsibilities and requirements, including the gaps.
  - **CO**: company and strategy knowledge.
  - **CASE**: a live problem from the job, solved aloud.
- **Provenance labels:**
  - **[grounded]**: traceable to a document you gave me.
  - **[inferred]**: a derivation I made, with its basis named.
  - **[generic]**: a pattern for this kind of role or problem, with no claim about you or Ashgrove.
- **Answer slot:** an instruction for the interview with two honest branches. It is not a question to me, and it asks nothing back here. Where you have the experience, answer from it. Where you do not, say so plainly.
- **Guidance is scaffolding, not a script.** Each answer should run 90 to 120 seconds unless a case says otherwise.

---

## The fit snapshot

Requirements are quoted from your JD. Your evidence is quoted from your own message. Nothing in the evidence column is a summary.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches and the contact centre" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | transferability | Your material says one branch's formal complaints log. It does not show the process end to end, across branches or into the contact centre. Keep the words at their scope: "I handled the branch's formal complaints log." Answer slot: expect a probe on what happened beyond the branch. If you had a say in how complaints moved between branches or into the contact centre, say what it was. If you did not, say so and stay with the log. |
| F2 | "report monthly on complaint volumes and resolution times" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | medium | [grounded] | discovery | Your material shows a monthly spreadsheet. It does not show whether it counts volumes or resolution times. Answer slot: say what the spreadsheet counts, in your own words. If it does not count resolution times, say so, and say what you would add first. |
| F3 | "coach branch supervisors on escalations" (JD) | "trained new tellers on our escalation script" (your message) | medium | [grounded] | transferability | Training tellers is adjacent to coaching supervisors, and the bridge stops there. Answer slot: if you coached a supervisor on an escalation, say what happened. If you have not, say so and say how you would start. |
| F4 | "work with digital teams on self-service journeys" (JD) | none given | none | [grounded] | discovery | Your material shows no work with digital teams or self-service channels, and you have not said there was none. Answer slot: if you have worked on a digital or self-service channel, say what you did. If you have not, say so and say how you would learn the member side of a journey. |
| F5 | "4+ years in financial-services customer operations" (JD) | "6 years in retail banking, the last 3 as a branch supervisor." (your message) | medium | [grounded] | none | Met on years. Say the six years as your sentence states them. |
| F6 | "experience handling regulated complaints" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | discovery | Your material says "formal", not "regulated", and this pack does not treat the two as the same. Answer slot: expect a probe on what made the log formal. If rules set how complaints had to be run, say which. If none did, say so and say how the log was run. |
| F7 | "confident presenting to senior leaders" (JD) | "I've never presented to anyone above regional level." (your message) | none | [grounded] | capability | Your stated absence. Words: "I haven't presented to anyone above regional level." Then how you would build it, said as a plan and never as a past. |
| F8 | "comfortable with Excel reporting" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | medium | [grounded] | discovery | Your material says spreadsheet, not Excel, and does not say what it can do. Answer slot: say which functions or features you used, in your own words. If the spreadsheet was not built in Excel, say so. |
| F9 | "across branches and the contact centre" (JD) | "Never worked in a contact centre" (your message) | none | [grounded] | capability | Your stated absence. Words: "I haven't worked in a contact centre." Then what you would learn first, said as a plan. |
| G1 | Where the role is based and how much travel it involves. Neither the JD nor the recruiter's email says (plain prose, no quote) | none given | none | [generic] | hard_gate | Your material does not establish this. Location and travel are gate terms, so this is surfaced, not bridged. It is the one question in Step 1 below. |

---

## Grounding brief: the vocabulary Ashgrove uses

From your summary of the July 2026 strategy brief. I have not seen the brief itself.

- **40% of member service moving to digital channels by 2028.** Sound current by using the brief's terms: "digital channels", "member service".
- **Eight branches consolidated into five hubs over 2027.** The material gives the count, not which branches. Do not speak as if any named branch is closing.
- **A small-business lending product launching in Q1 2027.** Not in this role's scope as the JD states it. Mention only if asked.
- **App-only banks as the main competitive pressure.** The frame for any strategy question.

Provenance: [grounded] your summary of the brief.

---

## Prohibited claims

These are the claims this pack will not coach. Each is listed with its basis and its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| "Ran the complaints process end to end across branches and the contact centre" | Inflated form of F1. Your sentence covers one branch's log. | "I handled the branch's formal complaints log," at its own scope. The limit is this pack's observation: your material says the log, not the process. |
| "Coached branch supervisors on escalations" | Inflated form of F3. Your sentence is about tellers. | "trained new tellers on our escalation script." |
| "Reported monthly on complaint volumes and resolution times" | Inflated form of F2. Your sentence names a spreadsheet, not its measures. | "I built the monthly complaints spreadsheet our regional manager uses." |
| "Handled regulated complaints" | Inflated form of F6. Your sentence says "formal". | "I handled the branch's formal complaints log." |
| "Presented to senior leaders" | Your stated negative, F7. | Plain acknowledgment: "I haven't presented to anyone above regional level." No slot. |
| "Worked in a contact centre" | Your stated negative, F9. | Plain acknowledgment: "I haven't worked in a contact centre." No slot. |

---

## Persona weights by round

| Persona | Round 1: recruiter, 30 min | Round 2: Head of Member Services, 45 min | Round 3: panel, 60 min | Counter-strategy |
|---|---|---|---|---|
| Conversational | 4. Recruiter screens are friendly, and the logistics, motivation and brief questions are scored. | not weighted | not weighted | Pre-scripted 90-second opener (R1-A1). Treat the casual digital question as scored (R1-A4). |
| Skeptic | 3. A light skeptic checks the reasons for leaving branches and the Excel and presenting claims. | 3. The hiring-manager prior is Case and Skeptic. The loop source says mostly behavioural, so Skeptic stays mid. | not weighted | Rehearse the contact-centre and across-branches objection until it is boring (R2-B1). |
| Values / Behavioral | 2. The loop source puts values scoring with the panel, so the recruiter keeps a light check. | 4. "Mostly behavioural" moves this to the top. | 4. The panel scores against the four values. | Quote-or-scaffold stories for each value (cheat sheet, round 3). |
| Case / Strategist | not weighted | 2. Hiring-manager prior: a live problem. | 4. The loop source names a 20-minute escalation case. | Clarify, then structure, then one owner for the fix. |
| Pressure | not weighted | not weighted | 2. Branch managers hold escalations in their own branches and may test composure. | Hold, then concede specifically (R3-F1). |
| Peer Evaluator | not weighted | not weighted | 2. The panel sits beside this role across branches, so seam and credit questions are likely. | Principles for the seam, not claimed experience (R3-E1). |

**Panel note.** The loop source does not say how each branch manager relates to this role. The panel prior blends the top two personas of each member's relationship. The escalation case and the values scoring lift Case and Values to the top, and the panel's branch-level role gives Pressure and Peer the next weights.

---

## Round 1: recruiter, 30 minutes

Weights: Conversational 4, Skeptic 3, Values 2. Nine questions.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R1-A1 | "Walk me through your background in a couple of minutes." | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." | About 90 seconds, in this order: the years and the last role; the formal complaints log; the training; the spreadsheet. Each beat stays at the scope its sentence gives. Add nothing between them. | Casual opener, scored. These four sentences carry every claim the rest of the pack rests on (F1, F2, F3, F5). |
| R1-A2 | "Why this role, and why now?" | JD | [generic] | One reason, tied to the job's own words, in your own words. The pack has no source for your reasons and supplies none. If the honest reason is that you want out of branch work, say that. | A motivation probe asked casually. JD because it tests fit with the posting, not a fact about your past. |
| R1-A3 | "The role runs across branches and the contact centre. What do you know about working in a contact centre?" | JD | [grounded] "Never worked in a contact centre" (your message) | Plain acknowledgment: "I haven't worked in a contact centre." Then say what you would want to learn first. | F9 is your stated absence. The honest acknowledgment is the answer the recruiter screens for. |
| R1-A4 | "Forty percent of member service moving to digital by 2028: what does that change for complaints?" | CO | [grounded] your summary of the July 2026 brief: "move 40% of member service to digital channels by 2028" | Say one thing you think changes and one thing you would check before saying more. Answer slot: if you have worked on a digital or self-service channel, say what you did. If you have not, say so and say how you would learn the member side of a journey. | Strategy from your brief, and the recruiter's likely casual probe on the self-service requirement, which your material does not cover (F4). |
| R1-B1 | "What does your monthly complaints spreadsheet actually count?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Answer slot: say what it counts, in your own words. If you can say how a figure was built, say so. If you cannot, say so plainly. Do not name a method you did not use. | F2 and F8. The spreadsheet touches monthly reporting and Excel, and your material does not show what it holds. |
| R1-B2 | "Who is the most senior audience you have presented to?" | JD | [grounded] "I've never presented to anyone above regional level." | Plain acknowledgment: "I haven't presented to anyone above regional level." Then name the most senior audience you have presented to, and a plan for the next step, said as a plan. | F7 is your stated absence. The headline requirement is one the recruiter will likely check early. |
| R1-B3 | "Why would someone with six years in branches want to leave them?" | JD | [generic] | Answer with what you want to do, not what you are leaving. The pack has no source for your reasons. If the honest answer is a wider remit, say so. | Skeptic motivation probe. Its premise is only that you are changing role, which you chose. |
| R1-C1 | "Which of our four values is hardest to live by in branch work, and where have you seen it?" | VAL | [grounded] "Members First, Always — we decide from the member's side of the counter." "Plain Words — if a member needs it explained twice, we wrote it wrong." "Neighbours, Not Numbers — every branch is part of its town." "Own the Fix — whoever finds the problem keeps hold of it until it is solved." "I handled the branch's formal complaints log" (your message) | Pick one value, say why it is hard, and give one real moment. If none comes to mind, say so plainly, then give the nearest thing your material carries: the formal complaints log, at that scope. | A values question at screen stage. The honest branch is built in. |
| R1-C2 | "What would you check in a complaint letter before it goes to a member?" | VAL | [grounded] "Plain Words — if a member needs it explained twice, we wrote it wrong." | Answer with what you would check, as a plan: whether the member could act on it after one read. Your material holds no letter of yours, so do not describe one. | Plain Words, which the recruiter may test. Asked as a plan because no sentence of yours covers letters. |

**Reverse questions, round 1**

1. "What does the first ninety days look like for whoever takes this role?" Why it lands: you are asking about the job, not the title.
2. "How much complaints work sits in the contact centre today?" Why it lands: you have read the scope line.
3. "Which of the four values do panels find hardest to score?" Why it lands: you want to know how the values round works, and the recruiter can tell you.
4. "How does the move to five hubs affect this role?" Why it lands: you have read the brief. The recruiter may not know, but the question is still useful.
5. "What would make a panel recommend someone for this role?" Why it lands: you want the scoring criteria.

---

## Round 2: Head of Member Services, 45 minutes

Weights: Values / Behavioral 4, Skeptic 3, Case 2. Nine questions. This round is your future manager, so it is where the highest-ROI prep sits.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R2-C1 | "Tell me about an unpopular decision you delivered to a member or a colleague." | VAL | [grounded] "I handled the branch's formal complaints log" (your message) | Selection scaffold: pick a decision that cost you something and that you would defend today. If none comes to mind, say so plainly, then give the nearest thing your material carries: the formal complaints log you handled, at that sentence's scope. | A behavioural round. Your only candidate sentence in this area is the log, so the honest branch matters most here. |
| R2-C2 | "Tell me about a complaint you kept until it was solved, even when it was not yours to fix." | VAL | [grounded] "Own the Fix — whoever finds the problem keeps hold of it until it is solved." "I handled the branch's formal complaints log" (your message) | Selection scaffold: the complaint, your part, what you did when it stalled, and how you knew it was solved. Your material carries none of those beats, so the story has to come from you. If you have no such case, say so and give the log's nearest instance at that sentence's scope. | Own the Fix is a published value with a raising source. No sentence of yours says a complaint was kept to resolution. |
| R2-C3 | "When did you put a member ahead of an internal number?" | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." "Neighbours, Not Numbers — every branch is part of its town." | Answer slot: pick a time a member's need and a target pointed in different directions. If none comes to mind, say so. Be ready for the follow-up on your spreadsheet: what it tells you about members, and what it does not. | The value is raised by the published text. The follow-up targets the spreadsheet, which is a numbers artifact. |
| R2-C4 | "Tell me about training new tellers on the escalation script." | EXP | [grounded] "trained new tellers on our escalation script" (your message) | Two beats the sentence states: who you trained, and on what. Answer slot: if you checked whether the training landed, say how you checked. If you did not, say so. Do not invent a check. | F3. Adjacent to coaching supervisors. The question tests whether you can show coaching, or only teaching. |
| R2-B1 | "Your complaints log was the branch's. This role covers eight branches and the contact centre. What in your background shows you can carry that?" | JD | [grounded] "I handled the branch's formal complaints log" (your message). "Never worked in a contact centre" (your message). | Hold: say what you handled, at the log's scope, in the sentence's words. Then plainly: "I haven't worked in a contact centre." Concede the scope gap as this pack sees it: one branch's log against eight branches and a contact centre. Answer slot: if you had any say in how complaints moved between branches or into the contact centre, say what it was. If not, say so and say how you would start across the eight branches. Hold through two follow-ups by returning to the log, not by adding to it. | **Highest-ROI prep in this pack.** This is the most predictable objection to you, and it combines the two largest gaps (F1 and F9). Everything beyond the two quotes is either the concession or an answer slot. |
| R2-B2 | "The role asks for confidence presenting to senior leaders. You have not presented above regional level. What do you do about that?" | JD | [grounded] "I've never presented to anyone above regional level." (your message) | Plain acknowledgment: "I haven't presented to anyone above regional level." Then a plan, said as a plan: how you would learn it and which audience you would ask for first. Do not describe a senior presentation as past experience. | F7. The question presupposes only what you stated, so the honest answer is the acknowledgment and a plan. |
| R2-B3 | "Which part of your monthly complaints spreadsheet would you defend least?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Answer slot: name the part, how it was counted if you know, and the assumption behind it you would defend least, in your own words. If you do not know how a figure was counted, say so plainly. | F2 and F8. The metric move: name the weakest assumption before the interviewer does. |
| R2-D1 | "A member has been given three different answers by three branches about the same fee. What do you do in the first week?" | CASE | [generic] | Clarify first: what the member was told, by whom, and when. Then one owner for the fix, then one plain letter the member can act on, then what goes into the monthly report. Name the obligations you would check first for this complaint type, rather than reciting them, because your material does not say which apply here. | A live problem from the role. It builds in the regulated-complaints requirement (F6) and presupposes nothing about your past. |
| R2-D2 | "Which complaints would you report monthly, and which would you leave out?" | JD | [grounded] "report monthly on complaint volumes and resolution times" (JD). "I built the monthly complaints spreadsheet our regional manager uses" (your message). | Name the measures in this order: volumes, then resolution times, then how you would define "resolved." Answer slot: if your spreadsheet already counts any of these, say which and how. If not, say what you would add first. | The reporting requirement, asked as a choice. It tests what the spreadsheet holds (F2) without asserting it. |

**Reverse questions, round 2**

1. "What does the first monthly complaints report look like, from your side?" Why it lands: the role is measured on it, and you are asking for the standard.
2. "Where do branch supervisors most often get escalations wrong today?" Why it lands: coaching is the job, and this asks where the gap is.
3. "Who decides what moves to self-service, and how?" Why it lands: it is the digital requirement, and the question belongs to the role.
4. "How would you judge this role at six months?" Why it lands: it is the manager's own success measure.
5. "What did the last person in this role find hardest?" Why it lands: it is an honest question, and it shows you are ready for the real job.

---

## Round 3: panel of two branch managers, 60 minutes

Weights: Case 4, Values / Behavioral 4, Peer Evaluator 2, Pressure 2. Twelve questions. The values cheat sheet lives here, because this round is the one the loop source names as scoring the four values.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R3-D1 | "A member's complaint about a disputed charge has been passed between two branches and the contact centre for six weeks. This week the member says they will take it outside the credit union. The branch manager wants to close it with a goodwill payment. What do you do?" | CASE | [generic] | Clarify first: what the member was told, what each team did, and the date of each step. Decide from the member's side what they need, not what closes the file. Name one owner for the fix. Say what you would check before any payment, which is whether the charge was wrong. Name the rules and timings you would check for this complaint type, without reciting them. Write a plain letter the member can act on. Finish with what goes into the monthly report and what goes back to the two branches. Give the case 15 minutes and the report 5. | The loop's 20-minute escalation case. It presupposes nothing about your past, and it touches all four published values. |
| R3-D2 | "The branch supervisor says the member was wrong and wants to close it. How do you coach her?" | JD | [grounded] "coach branch supervisors on escalations" (JD). "trained new tellers on our escalation script" (your message). | Coach with questions first: what she saw, what the member said, what she would do differently. Hold the escalation standard without taking the file off her. Answer slot: if you have coached a supervisor on an escalation, say what happened. If not, say so and say how you would start. Do not describe coaching you have not done. Your sentence is about tellers. | F3. The coaching requirement, asked as a live problem. |
| R3-D3 | "The same complaint type has come back from three branches this quarter. What goes into the monthly report, and what goes back to the branches?" | JD | [grounded] "report monthly on complaint volumes and resolution times" (JD). "I built the monthly complaints spreadsheet our regional manager uses" (your message). | Volumes by branch and type, resolution times, and the repeat pattern on its own line. Then who acts on it. Answer slot: if your spreadsheet already splits by branch or type, say so. If not, say what you would add first. | F2, extended to a case on reporting. |
| R3-D4 | "The app team wants to automate the first reply to this complaint type. What do you need to know before you agree?" | JD | [grounded] "work with digital teams on self-service journeys" (JD). | Ask what the member would see, what they would do next, and which complaints the automation would close wrongly. Say you would test on a sample before agreeing. Do not claim digital delivery experience. Your material shows none. | F4. The answer should show how you would reason, not what you have done. |
| R3-C1 | "Tell me about a time you explained something to a member that they had to hear twice." | VAL | [grounded] "Plain Words — if a member needs it explained twice, we wrote it wrong." | Selection scaffold: a time an explanation had to be given twice, and what you changed. If none comes to mind, say so plainly, then say how you would make the next explanation land the first time. | Plain Words, a published value. Your material has no such sentence, so the scaffold's honest branch carries this answer. |
| R3-C2 | "When did you decide from the member's side when the rules pointed the other way?" | VAL | [grounded] "Members First, Always — we decide from the member's side of the counter." | Selection scaffold: a decision where a rule or target pointed another way, what you decided, and what the member got. If none comes to mind, say so, then say how you would decide it. Use "we" for context and "I" for what you did. | Members First. No sentence of yours carries a decision of this kind. |
| R3-C3 | "Tell me about a time a number and a town pointed in different directions." | VAL | [grounded] "Neighbours, Not Numbers — every branch is part of its town." "I built the monthly complaints spreadsheet our regional manager uses." | Answer slot: a time a branch's figures and its local situation disagreed. If none comes to mind, say so. Expect the follow-up on your spreadsheet: what it shows about a branch's town, and what it does not. | The spreadsheet is a numbers artifact, and the published value is about towns. |
| R3-C4 | "When you found a problem that was not yours, what did you do with it?" | VAL | [grounded] "Own the Fix — whoever finds the problem keeps hold of it until it is solved." | Selection scaffold: the problem, why it was not yours, what you kept hold of, and when it was solved. If none comes to mind, say so, and say how you would hold a problem that spans two branches. | Own the Fix, a published value. No sentence of yours says a problem was held to resolution. |
| R3-E1 | "Our branches sit side by side. Where is the seam between a branch escalation and a contact-centre complaint, and what happens when we disagree about who owns it?" | JD | [grounded] "Own the member complaints process end to end across branches and the contact centre" (JD). "Never worked in a contact centre" (your message). | Propose principles for the seam, not a map you cannot see: one owner per complaint, one record, a rule for the handoff. Plain acknowledgment: "I haven't worked in a contact centre." Then how you would find the seam in your first month, as a plan. | A peer probe. F9 is your stated absence, so the answer is principles, not experience. |
| R3-E2 | "How do you share credit when a fix needs two teams?" | VAL | [generic] | Give the rule you use. Then an example only from your own material. Your material has no example of shared credit, so if asked for one, say so and give the rule. | The credit-sharing peer stem. The answer should not borrow a story. |
| R3-F1 | "Sixty seconds: why should two branch managers take escalation coaching from someone who has never worked in a contact centre?" | JD | [grounded] "Never worked in a contact centre" (your message). "I handled the branch's formal complaints log and trained new tellers on our escalation script" (your message). | Pause. Restate the question in your own words. Hold the branch-side experience at its stated scope through two follow-ups. Concede specifically: you have not worked a contact-centre queue, and you will not claim its volumes or its rules. Do not fold on the escalation work you did do. | Pressure on a stated absence. Hold-then-concede. |
| R3-F2 | "That spreadsheet: how much of it was really you?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Hold "I built it" at the sentence's scope. Answer slot: if you chose what it measures, say so. If the measures were set for you, say so. Concede whichever is true. Do not fold on "built" unless the answer shows you did not build it. | F2 and F8 under pressure. The probe tests attribution, which is what the sentence claims. |

**Coverage, round 3:** Case ×4, Values ×4, Peer ×2, Pressure ×2. Round totals: 9 + 9 + 12 = 30 questions across the three rounds.

### Values cheat sheet

| Value (official name) | Working meaning (paraphrased) | Mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side. | Selection scaffold on F1. No quoted sentence carries a decision made from the member's side. Pick a decision where a rule or target pointed the other way. If none comes to mind, say so, then say how you would decide it. |
| Plain Words | If a member needs it explained twice, the writing failed. | Selection scaffold on F3. The training sentence carries teaching, not plain words. Pick a time an explanation had to be given twice. If none, say so, and say what you would do the first time. |
| Neighbours, Not Numbers | Each branch is part of its town. | Selection scaffold on F2. The spreadsheet is a numbers artifact and carries no story about a town. Pick a time figures and local circumstances disagreed. If none, say so. |
| Own the Fix | Whoever finds the problem keeps hold of it. | Selection scaffold on F1. The log sentence says handled, not kept until solved. Pick a problem you held to resolution. If none, say so, and say how you would hold one that spans two branches. |

**Reverse questions, round 3**

1. "When a complaint goes wrong across two branches, what does each of you wish had happened earlier?" Why it lands: it is the seam question, asked of the people who live with it.
2. "What does Own the Fix look like in a branch on an ordinary day?" Why it lands: it takes the value seriously and asks how it works in practice.
3. "Which complaint type comes back most often from your branches?" Why it lands: it is where the monthly report starts.
4. Reciprocity: "What would help your branches most from a complaints lead in the first month?" Why it lands: the panel are the people this role serves, and the question puts them first.
5. "Which of your branches is closest to the hub change, and what do its complaints look like?" Why it lands: it ties to the strategy, and the panel will know.

---

## Requirement coverage

| JD requirement | Covered by | Note |
|---|---|---|
| 4+ years in financial-services customer operations | R1-A1 | Met on years (F5). |
| Own the complaints process end to end across branches and the contact centre | R2-B1, R3-E1, R3-D1 | F1 and F9. |
| Report monthly on complaint volumes and resolution times | R2-D2, R3-D3 | F2. |
| Coach branch supervisors on escalations | R2-C4, R3-D2 | F3. |
| Work with digital teams on self-service journeys | R1-A4, R3-D4 | F4. No evidence in the material. |
| Experience handling regulated complaints | R2-D1, R3-D1 | F6. |
| Confident presenting to senior leaders | R1-B2, R2-B2 | F7. Stated absence. |
| Comfortable with Excel reporting | R1-B1, R2-B3, R3-F2 | F8. |
| Location and travel | none, and why: this is a gate, asked as one question before the pack, not a bank question | G1. |

---

## Prohibited claims: where they bind

The list above applies to every answer slot, hold and bridge in the three rounds. Two sourced negatives bind hardest: the contact centre (F9) and senior presentation (F7). Any answer that implies either is wrong, even if it sounds confident.

---

## Sources

**Provided documents**
1. The JD text, as you pasted it.
2. The recruiter's email: three rounds on 20 November, their lengths, who runs them, and the values scoring.
3. The values text, copied from ashgrovecu.org/about/values on 11 November 2026, as you pasted it. This is the copy you made, not a live check.
4. The strategy brief, as your summary of the July 2026 document. I have not seen the brief itself.
5. Your background message.

**Research tier:** L1, searches 0 of 6, fetches 0 of 2; user links read 0. No search or fetch was sent, because every L1 target is fixed by the inputs.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | The four values, as you pasted them, fix the cheat sheet. Not re-fetched. |
| 2. Interview process, Member Experience Lead | skipped | The recruiter's email is a loop source. It names three rounds, their lengths, and who runs them. Loop mode follows it. |
| 3. Strategy and recent news | skipped | The strategy brief you supplied, dated July 2026 and under six months old, fixes the priorities and competitive frame. |
| 4. Interviewer name and company | n/a | No names for the Head of Member Services or the two panel members. |
| 5. Representative JD | skipped | Your JD fixes the fit snapshot and the JD-tagged questions. |

---

## Upgrade menu

- **Names of the two panel members and the Head of Member Services** → persona weights from their public footprint, and tailored reverse questions for rounds 2 and 3.
- **What your monthly spreadsheet counts, whether it splits by branch, and which functions you used** → F2, F8, R2-D2 and R2-B3 move from answer slots to grounded answers.
- **A complaint you kept until it was solved, told in your own words** → R2-C2 and R3-C4 get a mapped story in place of a scaffold.
- **Your reasons for the move** → R1-A2 and R1-B3 get grounded guidance.
- **Whether any round includes a presentation or take-home** → one email to the recruiter. If one is declared, a graded-deliverable section is added.
- **Deep research (L2)**: up to 6 more searches and 2 more fetches, several minutes. Would add the current organisation context (leadership changes, the hub plan) and forum-sourced loop reports, labelled [inferred]. Offered once; say if you want it.
- **A tuesday-dossier.md from job-underwriter** would add verified evidence and any prohibited-claims list from a fit check.
