Your prep pack is saved as `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-tuesday-part-2-rooms-case-8-canned-a6c5d65a/a039a0d4-5b19-4ef7-af7f-36d05e5e93eb/scratchpad/ashgrove-credit-union_member-experience-lead_interview_pack.md`. I built it from the JD, your message, the values you copied and the recruiter's round details. I ran no web searches, because those inputs already covered what the research would have checked.

What matters most:

- **Your biggest gap is senior presenting.** The JD asks you to be "confident presenting to senior leaders," and you've said you've never presented above regional level. Question B1 is the one to rehearse hardest: hold your position, name the limit, then give a concrete plan.
- **The contact centre is your second gap.** B2 covers it.
- **The panel scores values, so the values sheet matters.** Members First and Own the Fix can be anchored in your complaints log. Plain Words and Neighbours, Not Numbers have no sentence in your material behind them, so the pack gives you a selection scaffold and tells you to say so plainly if no example comes to mind.
- **Don't say "Excel" yet.** Your message says "spreadsheet," so the pack uses that word. Confirm the tool before the interview.
- **Don't claim the resolution times.** The JD asks for monthly reporting on resolution times, and your material doesn't show you tracked them. Question D1 is about this, and the answer slot keeps it honest.

The pack is built only on sentences you wrote, so the upgrade menu at the end lists what would strengthen it. The most useful items are the Head of Member Services' name, the strategy brief pasted in full, and how many hours you have before 20 November.

Say the word and I'll play the Skeptic on B1, the question the pack names as its highest-priority prep.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove-credit-union_member-experience-lead_interview_pack.md -----
# Ashgrove Credit Union: Member Experience Lead
## Interview prep pack for Dara

**Rounds (20 November 2026):**
1. Recruiter, 30 minutes
2. Head of Member Services, 45 minutes, mostly behavioural. This is your future manager.
3. Panel of two branch managers, 60 minutes, including a 20-minute complaint-escalation case. The panel scores you against the four values.

Interviewer names are not yet known for the panel or the Head of Member Services.

---

## How to use this pack

**Personas** describe how a question is asked. **Types** describe what is being scored.

| Type | Name | What it scores |
|---|---|---|
| VAL | Values and behaviour | Whether a past action shows a published value |
| EXP | Experience deep-dive | Whether what you have written about your work survives a follow-up |
| JD | Role requirement | Whether you can do the listed job, gaps included |
| CO | Company and strategy | Whether you know where Ashgrove is going |
| CASE | Live problem | How you structure a problem from the role |

The guidance is scaffolding, not a script. Say what you actually did, in your own words.

---

## Fit snapshot

Your material for this pack is the message you sent, not a CV. Every quotation below is a sentence from that message, or the JD text you pasted. The pack makes no claim about your experience beyond those sentences.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches and the contact centre" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | transferability | Your material describes one branch's formal log, not a process run end to end across branches and a contact centre. Words: "I handled the branch's formal complaints log." Answer slot: if you had a say in how complaints moved beyond your branch, say which and how; if you did not, say so plainly and stay with the branch's log. |
| F2 | "report monthly on complaint volumes and resolution times" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | medium | [grounded] | presentation | This sentence reaches monthly reporting in other terms. It does not show resolution times, and the pack will not claim them. Words: "I built the monthly complaints spreadsheet our regional manager uses." |
| F3 | "coach branch supervisors on escalations" (JD) | "trained new tellers on our escalation script" (your message) | medium | [grounded] | transferability | Your material shows training tellers, not coaching supervisors. Words: "I trained new tellers on our escalation script." Answer slot: if you ever coached a supervisor on an escalation decision, say how; if you did not, say so and describe how you would approach it. |
| F4 | "experience handling regulated complaints" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | discovery | "Formal" is not the same as "regulated". Your material does not show whether the log worked to a regulatory timescale or to an external referral. Answer slot: if it did, say which timescale or referral and how you kept to it; if it did not, say so plainly. |
| F5 | "4+ years in financial-services customer operations" (JD) | "6 years in retail banking, the last 3 as a branch supervisor" (your message) | medium | [grounded] | none | The requirement is met on your own account. Words: "6 years in retail banking, the last 3 as a branch supervisor." |
| F6 | "confident presenting to senior leaders" (JD) | "I've never presented to anyone above regional level" (your message) | none | [grounded] | capability | This is a gap you stated yourself. Words: "I've never presented to anyone above regional level." Then say how you would build the skill, as a plan and never as a past. |
| F7 | "comfortable with Excel reporting" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | medium | [grounded] | presentation | Your message says spreadsheet. It does not say Excel, and the pack will not name the tool. Words: "I built the monthly complaints spreadsheet our regional manager uses." |
| F8 | "work with digital teams on self-service journeys" (JD) | none given | none | [grounded] | discovery | Your material does not show any work with digital teams or self-service journeys. Answer slot: if you worked with a digital or app team on a member process, say which and what you did; if you did not, say so plainly. |
| F9 | "across branches and the contact centre" (JD) | "Never worked in a contact centre" (your message) | none | [grounded] | capability | A gap you stated yourself. Words: "I've never worked in a contact centre." Then say how you would learn contact-centre operations, as a plan. |

**Hard gates:** the JD names no licence, location, schedule or pay term, so no row is a `hard_gate`. Your six years' experience is a length requirement, not a gate.

---

## Grounding brief

Research did not run (see Sources). This brief is built from the strategy summary you sent, not from the brief itself. Paste the brief to make its exact wording available.

- **Digital:** 40% of member service moves to digital channels by 2028.
- **Network:** eight branches consolidate into five hubs over 2027.
- **Lending:** a small-business lending product launches in Q1 2027.
- **Competition:** app-only banks are the main pressure.

Use the company's own words (member service, digital channels, hubs) when you talk about these. Do not correct the interviewer on any of them.

---

## Persona table

Relationship priors set the starting weights. The loop then adjusts them. Your recruiter's email documents a values-scored panel, so Values/Behavioural is guaranteed in this loop. There are no interviewer profiles, so no signal adjusts the weights.

| Persona | Weight | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|---|
| Values / Behavioural | 5 | Scenario questions mapped to the four values | High. The panel scores values, and the Head of Member Services round is mostly behavioural | Map one story to each value where your material carries one. Where it does not, use a selection scaffold and say so plainly |
| Skeptic | 4 | Probes your gaps: presenting, contact centre, scope | High. Your three stated gaps (F6, F9, F1) are the ones the JD asks for most directly | Rehearse the presenting objection until it is calm. Hold your position, name the limit, then give a plan |
| Case / Strategist | 3 | The 20-minute escalation case, and strategy questions | High for the case, which is in the panel round | Clarify first, then structure: facts, the member's need, who owns the fix, what gets logged, when to escalate |
| Data-Driven Prober | 3 | Checks your monthly spreadsheet and any numbers you use | Medium. The JD asks for monthly reporting and resolution times, and you built a monthly sheet | Say what the sheet counted, in your words. Name the assumption you would defend least. Say so when you do not know |
| Pressure | 2 | Time-boxed challenge on senior presenting and on your sheet | Medium. The senior-leader gap invites a challenge | Pause, restate the question, hold through two follow-ups, then concede the gap explicitly |
| Rapport / Conversational | 2 | Recruiter opener and a casual check on a JD topic | Medium. Recruiter rounds are friendly, and casual questions are still scored | Keep a 90-second background arc ready. Treat every casual question on the JD as scored |
| Peer Evaluator | 2 | Seams between branches and the contact centre, credit, disagreement | Medium-low. The panel are branch managers, so seam and credit questions are likely | Propose seam principles, not seams you have not seen. Keep the member owned until it is solved |

Total: 21 questions, within the 18 to 26 range.

---

## Question banks

### A. Values / Behavioural (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Tell me about a time you put a member's side of the counter ahead of what the process said." | VAL | [grounded] "I handled the branch's formal complaints log" (F1) | Pick one complaint from the log where the member's side changed what you did. If none comes to mind, say so plainly, then give the nearest case the log carries, or how you would handle one now. | Members First, Always is scored by the panel. F1 is the only sentence that places you near complaints. It does not carry a member-side decision, so this is a selection scaffold. |
| A2 | "Tell me about a time you had to rewrite an explanation because the first one did not land." | VAL | [grounded] "trained new tellers on our escalation script" (F3) | Say what the script said, and what you changed when tellers did not follow it. If you changed nothing, say so, and say what you would change now. | Plain Words is scored. F3 is the nearest sentence that involves explaining. It does not show a rewrite, so the guidance does not assume one. |
| A3 | "Tell me about a time local context changed a decision for a branch." | VAL | [generic] | Pick a time it did, if one exists. If none does, say so plainly, then say how you would learn what a town needs in your first month. | Neighbours, Not Numbers is scored. No sentence of yours covers it, so the question is answered from a selection scaffold. |
| A4 | "Tell me about a complaint you kept hold of until it was solved. Did you see it through, or hand it on?" | VAL | [grounded] "I handled the branch's formal complaints log" (F1) | Say what you handled and how it closed. If you handed a case on, say so and why; that answer is allowed. Do not describe a resolution you did not see. | Own the Fix is scored. F1 supports only the handling. The "until it is solved" part is the story you need, and the honest version may be a handover. |
| A5 | "Tell me about a time you told someone senior something they did not want to hear." | VAL | [generic] | Pick a time you did, with a named stake and a relationship intact at the end. If none comes to mind, say so plainly and say what you would do. | Honest challenge is a common panel probe. No sentence of yours covers it, so it is a selection scaffold. |

### B. Skeptic (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "This role presents monthly to senior leaders. You have told us you have never presented above regional level. Why should we believe you will be confident in that room?" | JD | [grounded] "I've never presented to anyone above regional level" (F6) | Hold, do not bluff. Say your own words: "I've never presented to anyone above regional level." Then name the plan you would use to get ready for a monthly report, in your own words. Hold through two follow-ups by returning to the plan. Concede explicitly: "I don't know yet how I'll do in that room, and I would rather find out with a rehearsal than assume." | HIGHEST-ROI PREP IN THIS PACK. The JD raises senior presenting in its headline, and F6 is the gap you stated. This objection is the most likely one, and the honest answer is the limit plus a plan. |
| B2 | "Why would you run a contact centre when you have never worked in one?" | JD | [grounded] "Never worked in a contact centre" (F9) | Say it plainly: "I've never worked in a contact centre." Then name the first three things you would do to learn its queues and escalations. Do not claim contact-centre experience. | The JD scope includes the contact centre. F9 is your stated absence, so the plain acknowledgment is the answer. |
| B3 | "You have run a branch's log. Ours is 900 staff across branches and a contact centre. How is it not just a bigger version of the same job?" | JD | [grounded] "I handled the branch's formal complaints log" (F1) | Name one thing from your log that carries to a second channel, in your own words. Then say what you have not run, using the plain acknowledgment: "I've never worked in a contact centre." | F1 is the honest scope of your work. Holding the scope, not inflating it, is the answer. |
| B4 | "Has a complaint of yours ever gone beyond your branch, to a regulator or an external referral? What happened?" | JD | [grounded] "I handled the branch's formal complaints log" (F4) | Answer slot: if one did, say what happened and what your part was, in your own words. If none did, say so plainly and say how your log would have handled it. | F4 is discovery. The JD names regulated complaints, and the material does not show whether yours ever were. |

### C. Case / Strategist (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A member says a branch told them one thing and the contact centre told them another, and they are threatening to go to the ombudsman. You have 20 minutes. Walk us through it." | CASE | [generic] | Clarify first: which complaint, what the member has been told, what timescale applies. Then structure: the member's need in plain words, who owns the fix until it is solved, what the branch and the contact centre each do, what gets logged, and when to escalate. Keep your language plain. | This is a rehearsal of the 20-minute panel case, built from the JD's scope. It makes no claim about your past. |
| C2 | "The strategy moves 40% of member service to digital by 2028. What does that do to the complaints you would handle?" | JD | [grounded] "move 40% of member service to digital channels by 2028" (your message) | Name what a digital complaint looks like: the channel, the volume, who triages it. Name the one risk you would watch first. Make no claim about your own digital work. | F8 is a gap, so the answer must not claim digital experience. The question tests whether you think at the company's altitude. |
| C3 | "Eight branches are becoming five hubs in 2027. What happens to open complaints in a branch that closes?" | CASE | [grounded] "consolidate eight branches into five hubs over 2027" (your message) | Clarify: which complaints are open, what timescales apply, what the member's contact point becomes. Then propose a handover plan. Do not speculate about hub locations. | This is a live problem from the strategy, and the question carries no claim about you. |

### D. Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "What did your monthly complaints spreadsheet count, and what did it leave out?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" (F2) | Say what the sheet counted, in your own words. Answer slot: if it held any resolution-time figure, say how it was counted; if it did not, say so plainly and say how you would measure resolution time. | F2 is the only evidence for monthly reporting. The JD asks for resolution times, so the probe is likely. The slot keeps the answer true. |
| D2 | "Which number on that sheet would you defend least?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" (F2) | Name, in your own words, the assumption behind the figure you would defend least, before the panel does. If you cannot name one, say so. | Weakest-assumption move. Naming it first turns a gotcha into a credibility gain. |
| D3 | "The role reports monthly on volumes and resolution times. What are the first three numbers you would put on the page?" | JD | [generic] | Name three numbers and the decision each one drives. Do not claim to have produced any of them before. | The JD asks for this report. The question makes no claim about your past. |

### E. Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who has presented to senior leaders for years?" | JD | [grounded] "I've never presented to anyone above regional level" (F6); [grounded] "I built the monthly complaints spreadsheet our regional manager uses" (F2) | Pause. Restate the question. Hold on what you built: "I built the monthly complaints spreadsheet our regional manager uses." Concede the senior-room gap explicitly, in your own words, and say how you would close it. | Pressure tests composure. The hold is the spreadsheet, which is a true claim. The concession is the gap, which you stated. |
| E2 | "That spreadsheet: how much of it was actually you?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" (F2) | Say what you built and who uses it, in those words. Do not add to the claim. | Attribution probe. The honest answer is the sentence itself. |

### R. Rapport / Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R1 | "So, walk me through the journey." | VAL | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" (F5) | A 90-second arc: six years in retail banking, the last three as a branch supervisor, and what the complaints log taught you. Stop there. | The recruiter round is scored, even when casual. The arc uses only F5 and F1. |
| R2 | "How would you coach a branch supervisor who escalates things they should close?" | JD | [generic] | Describe a coaching approach in your own words: what you would look at, what you would say, what you would check next time. Do not claim you have coached a supervisor. | JD requirement "coach branch supervisors on escalations" has no JD-tagged question yet; this one covers it. F3 is the nearest sentence, and it stays at its own scope. |

### P. Peer Evaluator (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Our branches and contact centre sit side by side on complaints. Where is the seam, and what happens when you disagree?" | JD | [generic] | Name a seam principle: who owns the member until the complaint is solved. Do not claim to know this team's seam. For disagreement, use a selection scaffold, and say so plainly if you have no example. | The JD scope is branches and the contact centre. Peer probes return the same objections in a collegial tone. |
| P2 | "How do you handle credit when a complaint is solved by someone else's team?" | VAL | [generic] | Keep the member owned until the fix is in. Name credit honestly, to the team that did the work. | Own the Fix, from the peer side. No claim about your past. |

**Coverage. Every JD requirement maps to at least one question:**

| JD requirement | Questions |
|---|---|
| Own complaints end to end across branches and the contact centre | A4, B3, C1, P1 |
| Report monthly on volumes and resolution times | D1, D2, D3 |
| Coach branch supervisors on escalations | R2, C1 |
| Work with digital teams on self-service journeys | C2 |
| 4+ years in financial-services customer operations | R1 |
| Experience handling regulated complaints | B4 |
| Confident presenting to senior leaders | B1, E1 |
| Comfortable with Excel reporting | D1, E2 |
| Across branches and the contact centre (scope) | B2, C1 |

No requirement is uncovered.

---

## Values / principles cheat sheet

Published values, copied from ashgrovecu.org/about/values on 11 November 2026. The panel scores against all four.

| Value (official name) | Working meaning | Mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | Selection scaffold, anchored on F1: "I handled the branch's formal complaints log." Pick a complaint where the member's side changed your decision. If none, say so plainly and give the nearest case. Question A1 |
| Plain Words | If a member needs it explained twice, the wording was wrong | Selection scaffold, anchored on F3: "trained new tellers on our escalation script." Pick a time you rewrote an explanation. If none, say so plainly. Question A2 |
| Neighbours, Not Numbers | Every branch is part of its town | Selection scaffold. No sentence of yours covers it. Pick a time local context changed a decision. If none, say so plainly and say how you would learn a town's needs. Question A3 |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | Anchored on F1: "I handled the branch's formal complaints log." Pick a complaint you kept to resolution. If you handed a case on, say so and why. Question A4 |

---

## Reverse questions

Ask at least five. Each has a reason it lands.

1. "What would a strong first 90 days look like in this role?" Why it lands: it shows you plan for the job's start, not its title.
2. "How do the branches and the contact centre agree today on who owns a complaint until it is solved?" Why it lands: it tests the Own the Fix seam and shows you read the JD's scope.
3. "How will the monthly complaints report change as eight branches become five hubs?" Why it lands: it shows you read the strategy brief and think about reporting, not just complaints.
4. "When a member starts a complaint in the app, what does it look like by the time it reaches a person?" Why it lands: it shows you have thought about the 40% digital move.
5. "Which of the four values do you see broken most often in a complaint, and what happens next?" Why it lands: it shows you know the panel scores values, and it asks where the scoring bites.
6. Reciprocity, for the branch-manager panel: "What could a new Member Experience Lead do in their first month that would genuinely help your branch?" Why it lands: the panel are branch managers, so this makes the conversation a peer one.

---

## Prohibited claims

What this pack will not coach, and why. Built here from the fit snapshot, since no dossier was provided.

| Not coached | Basis | Honest form |
|---|---|---|
| Owns the complaints process across branches and the contact centre | Inflated form of F1 | "I handled the branch's formal complaints log." The limit is the pack's observation: your material describes one branch's log. |
| Reports monthly on resolution times | Inflated form of F2 | "I built the monthly complaints spreadsheet our regional manager uses." The pack's observation: resolution times are not shown. |
| Coached branch supervisors on escalations | Inflated form of F3 | "I trained new tellers on our escalation script." |
| Handled regulated complaints | Inflated form of F4 | "I handled the branch's formal complaints log." The regulatory question stays in the answer slot in B4. |
| Works in Excel | Inflated form of F7 | "I built the monthly complaints spreadsheet our regional manager uses." |
| Has presented to senior leaders | Negative you stated, F6 | "I've never presented to anyone above regional level." |
| Has worked in a contact centre | Negative you stated, F9 | "I've never worked in a contact centre." |

---

## Sources

**Provided documents, as sent to the pack:**
- The JD text in your message.
- Your background in your message. This is not a CV.
- The four values, copied from the values page on 11 November 2026.
- The recruiter's email describing the three rounds.
- The strategy brief, as you summarised it in your message. The brief itself was not pasted.

**Research tier:** L0, no searches.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | The four values are in hand as pasted text. They fix the values cheat sheet and A1 to A4 |
| 2. Ashgrove interview process | skipped | The recruiter's email fixes the three rounds, their lengths and the values-scored panel. It sets the persona weights |
| 3. Ashgrove strategy and recent news | skipped | Your summary of the strategy brief is in hand. It fixes the grounding brief and C2, C3 and the reverse questions. The brief's exact wording is not available; see the upgrade menu |
| 4. Interviewer name and company | n/a | No names were given for the Head of Member Services or the panel, so there was no query to form |
| 5. Representative JD for this title | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

**Other sources:** none.

---

## Upgrade menu

- The Head of Member Services' name: personal public-footprint research, persona weights for that round, and a tailored reverse question.
- The strategy brief, pasted: exact vocabulary for the grounding brief, and C2, C3 and reverse question 3 use its own words.
- Deep research (L2), at your choice: up to 6 further searches and 2 further fetches, aimed at the brief, public talks by the Head of Member Services, and loop reports for this role family. This is offered once.
- Which tool the monthly spreadsheet was in: confirms or retires the Excel claim (F7).
- Whether the spreadsheet held any resolution-time figure, and how it was counted: upgrades D1 and F2 from observation to a defensible story.
- Whether any complaint of yours went to a regulator or external referral: upgrades F4 and B4 from discovery.
- Whether you have worked with a digital or app team on a member process: upgrades F8.
- How many hours you have before 20 November: adds a prep-triage section with a schedule.
- The recruiter's prep email: whether the 20-minute case uses the same four values, and what format it takes.
