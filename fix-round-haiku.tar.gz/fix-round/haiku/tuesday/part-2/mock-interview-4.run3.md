Your prep pack is saved as /tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-tuesday-part-2-rooms-case-4-denied-2e5c9016/8fdd3f20-418a-4e9c-8eff-9f6296e5d60a/scratchpad/quartzline_product-manager-platform-apis_interview_pack.md. I built it for a hiring-manager round, using your dossier as the input.

Three things to know before you open it:

- **The dossier is three months old** (generated 2026-08-14). If the posting has changed since August, the requirements and unknowns may be out of date.
- **Web research was refused.** Both searches were blocked because search permission isn't granted in this session, so the pack has no company strategy section and no interview loop structure.
- **I graded one requirement the dossier didn't flag.** "Shipped API or platform products" looks like a transferability gap to me, not a match. Your evidence is integration work on the vendor's APIs, not a product you shipped. Expect a probe on it.

Start with B1, the objection the underwriter named. Say the acknowledgment and the bridge aloud until they take under 90 seconds. Then decide in your own words which answer-slot branches are true for you (A2, D1, D2).

Say the word and I'll play the Skeptic on B1, the question the pack names as its highest-ROI prep.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quartzline_product-manager-platform-apis_interview_pack.md -----
# Quartzline: Product Manager, Platform APIs. Hiring-manager interview pack

**Round:** 45-minute conversation with the hiring manager, Thursday. Interviewer name not given.
**Built from:** `tuesday-dossier.md`, job-underwriter v1.1, generated 2026-08-14, decision `conditional_go`. No web research ran (see Sources).
**Regeneration:** none. First build.

## How to use

- **Personas** describe how a question is asked. **Types** describe what is being scored.
- **Type key:** VAL = values alignment; EXP = work-experience deep-dive; JD = role and JD-driven; CO = company and strategy knowledge (none in this pack, see Sources); CASE = live problem from the role.
- Guidance is scaffolding, not a script. Rehearse what you actually did, in your own words.

## Prep triage

Thursday is roughly one working day. In order:

1. **B1, the objection the underwriter named.** Say the plain acknowledgment and the bridge aloud until they take under 90 seconds, then rehearse holding through two follow-ups. This is the highest-return prep in the pack.
2. **Answer slots A2, D1, D2.** Before you go in, decide in your own words which branch is true for each: which stage was yours, which count, which session changed what. Write the answers down.
3. **Say the three plain acknowledgments as sentences you would say:** "I haven't held a product manager title." "I haven't owned a product roadmap." "I haven't set prioritization for an engineering squad."
4. **C2, hold then concede.** Practise holding the integration work and conceding the title.
5. **Pick three reverse questions from section 11.** Two come straight from the dossier.

Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Shipped API or platform products" (dossier role_profile R2) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier row V1) | high | [grounded] | transferability | Your material shows integration work on the vendor's REST APIs, not a shipped product. Words: "I led 30+ end-to-end integrations of the vendor's REST APIs, from scoping to go-live." The integration playbook is the inspectable proof. Answer slot: if you shipped anything that API consumers depended on, say what and what was yours; if not, say so. |
| F2 | "3+ years product management experience" (dossier role_profile R1) | "Ran quarterly roadmap-input sessions feeding client evidence to product" (dossier row V3) | medium | [grounded] | transferability | Adjacent work: input into product, not product management. Words: "I ran quarterly roadmap-input sessions that fed client evidence to product." Limit, as the pack's analysis: your material shows input, not decisions. Medium confidence means limited inspectable proof, so volunteer that limit before it is extracted. |
| F3 | "Owning a roadmap and prioritization authority" (dossier uncertain_or_weak_areas, acknowledge_gap) | none given | none | [grounded] | capability | The dossier records this absence. Words: "I haven't owned a product roadmap." No bridge. Say the ramp plan as a plan, never as a past. |
| F4 | "Agile delivery experience" (dossier role_profile R5) | none given | low | [grounded] | discovery | The material has no agile evidence either way. Answer slot: if you worked on a sprint cadence, say what that was; if not, say so and say what you would confirm about how this team runs it. |
| F5 | "Technical fluency: API docs, schemas" (dossier role_profile R3) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier row V1); "Wrote the internal integration playbook her team uses" (dossier row V2) | high | [grounded] | discovery | The material shows REST API integration work and a playbook. It does not show schema or API-doc authoring. Answer slot: if you wrote or reviewed API docs or schemas, say what; if not, say so and say what you would check first. |
| F6 | "Stakeholder management across engineering, sales, customers" (dossier role_profile R4) | "Ran quarterly roadmap-input sessions feeding client evidence to product" (dossier row V3); "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier row V1) | medium | [grounded] | discovery | Customers and product appear in the material. Engineering and sales do not. Answer slot: name any engineering or sales counterpart you worked with and what the work was; if there were none, say so. |

**Reading note (the pack's analysis, not a claim about the candidate).** The dossier flags R1 and R5 as weak but not R2. On the evidence cell, R2 is a transferability gap: the material shows integration work on the vendor's APIs, not a shipped product. Expect a probe on it.

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy | Depth |
|---|---|---|---|---|
| Case/Strategist | Live roadmap problems for the first 30 days; decision rights with the squads | High. Hiring-manager prior is capability and derisking, and the JD's "Own the roadmap" line makes a live problem likely | Clarify, then objective, segmentation, approach, metrics, risks. Name the decision-rights question aloud | 5 |
| Skeptic | "Why not a PM with three years?" and the roadmap gap | High. The dossier names this objection as the most likely one | Plain acknowledgment, then the bridge at the quote's own scope, then a concrete ramp plan | 5 |
| Data-Driven Prober | The 30+ count, the roadmap-input sessions | Medium. A headline figure and a medium-confidence line will be read closely | Know how each figure was counted; say so plainly when you don't | 3 |
| Pressure | "Why you over someone with the title?" | Medium-low. Interviewers push when a title is missing | Pause, restate, hold through two follow-ups, concede specifically | 2 |
| Conversational | The opener, and the open question about the platform | Medium. Casual openers are scored too | A 90-second arc built only from verified lines; never answer the reverse-question slot with "I think you've covered everything" | 3 |

Total: 18 questions. The 18 floor is met.

## Question banks

### Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Partner API adoption has been flat for two quarters. What would you check first, and what would you need to know before proposing a fix?" | CASE | [grounded] "Define and track adoption metrics" (role_profile responsibility) | Clarify what "adopted" means, which partners, and what a flat line can hide. Ask for the current baseline out loud before proposing anything. No claim about your past. | Tests the adoption responsibility. The missing baseline is the dossier's open risk, so the question doubles as a reverse question. |
| A2 | "You would own the roadmap for the partner-facing API platform. Sketch your first 30 days. What do you need to know first?" | JD, CASE delivery | [grounded] "Own the roadmap for the partner-facing API platform" (role_profile responsibility) | Lead with questions: who decides roadmap calls today, what the squads have committed, what partner commitments exist. Then a 30-day plan in three parts: listen, map, decide. Answer slot: if you have decided anything on a roadmap before, say what and who else was in the room; if you have not, say so and stay with the plan. | Tests the roadmap-authority gap (F3) without claiming it. This is where the decision-authority unknown gets tested. |
| A3 | "Two partners ask for conflicting changes to the same endpoint. Walk me through the decision." | CASE | [grounded] "Run discovery with integration partners" (role_profile responsibility) | Segment the partners, price each option in cost and reversibility, check whether the conflict is real, decide, and write the decision down. If you handled a conflict like this during the integration work in F1, say what you did and what was yours; if not, keep to the framework. | A live problem from the discovery responsibility. F1 is the only past that may enter, and only at its own scope. |
| A4 | "How would you agree decision rights for roadmap calls with the two squad leads?" | JD content, CASE delivery | [grounded] "Write specs and drive delivery with two engineering squads" (role_profile responsibility) | Name the decisions you would want to own, the ones the squads keep, and the forum that settles disputes. Propose the forum; do not claim you already have the authority. | Tests the dossier's top unknown live. Also covers R4 for engineering, which F6 leaves open. |
| A5 | "How would you define adoption for a partner API, and how would you know a partner had adopted it?" | CASE | [grounded] "Define and track adoption metrics" (role_profile responsibility) | Give two or three definitions and their trade-offs. Name the one you would start with, and ask for the current measure before you pick. Do not name a current figure. | The adoption measure has no stated baseline. This question is the first reverse question in practice. |

### Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've never held the PM title or owned a roadmap. Why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Having held a product manager title or role" (dossier prohibited_claims); "Owning a roadmap" (dossier uncertain_or_weak_areas, acknowledge_gap); "Ran quarterly roadmap-input sessions feeding client evidence to product" (dossier row V3) | **The highest-ROI rehearsal.** The underwriter named this objection. (1) Plain acknowledgment first, in your words: "I haven't held a product manager title, and I haven't owned a product roadmap." (2) Bridge at the quote's own scope: "I led 30+ end-to-end integrations of the vendor's REST APIs, and I ran quarterly roadmap-input sessions that fed client evidence to product." (3) Concede specifically: a PM with three years is faster on roadmap calls. Name the first thing you would ramp on. (4) Plan, not past: "In the first 90 days I would..." Hold through two follow-ups by returning to the integrations, never by adding decisions you did not make. Expect: "Name a roadmap call you made." Answer slot: if you made none, say so. | The objection lands where the material is thinnest, so the pack adds nothing here. The Question keeps the underwriter's wording because both negatives have a source. |
| B2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Own the roadmap for the partner-facing API platform" (role_profile responsibility) | Name roadmap authority and the product-org delivery cadence as the two weakest areas, in that order. Give a ramp plan for each. Do not name anything else as weak. | Persona stem. The answer draws on the gaps the dossier already grades, so it should match the pack. Also the JD-tagged question for R2 and R3. |
| B3 | "I don't see roadmap ownership in your background. How would you handle that in this role?" | JD | [grounded] "Owning a roadmap and prioritization authority" (dossier uncertain_or_weak_areas, acknowledge_gap) | Acknowledge the gap plainly, then the ramp plan. Then the adjacent input you did have: "I ran quarterly roadmap-input sessions that fed client evidence to product." Never claim roadmap ownership. | Skeptic stem. The negative is sourced by the dossier's acknowledge_gap field, so it may be asked as written. |
| B4 | "Why are you leaving where you are, and why this role now?" | JD | [generic] | Say the true reason in your own words. If the reason is the PM title, say so plainly and say what you want to build toward. Make no claim about your current employer. | Every Skeptic asks this. Generic, because the material holds no reason for leaving. |
| B5 | "Have you worked inside an agile product org? What did that look like for you?" | JD | [grounded] "Agile delivery experience" (role_profile R5) | Clarify branch. If you ran work on a sprint cadence, say what that was. If you did not work that way, say so, and say what you would want to confirm about how this team defines and runs it. Answer slot. | R5 is preferred and graded low by the dossier. The honest answer is the slot's. "What this team means by it" is the clarifying move. |

### Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how the 30+ integrations were counted." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier row V1) | Defend-the-number slots, answered in your own words: how the count was made (what counted as an integration, and who counted); what it is sensitive to; the assumption you would defend least; which of the 30+ were yours to lead. Answer slot: name the counting rule only if you know it. If you do not, say "I don't know how it was counted" and say whose record would show it. | The headline figure in the top evidence. The integration playbook is the inspectable artifact behind it. |
| D2 | "Did your roadmap-input sessions change anything product did? How would you know?" | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" (dossier row V3) | Volunteer the limit first: this line is medium confidence, so the proof is thin. Answer slot: if a session changed a product decision, name the one change and how you know; if you cannot trace one, say so and say what you would bring to show it. | The medium-confidence line will be probed. Volunteering the limit beats having it extracted. |
| D3 | "Pick one of the 30+ integrations and walk me through it from scoping to go-live." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier row V1) | Pick the one you can narrate in four minutes. Walk each stage the quote lists: scoping, requirements, architecture, UAT, go-live. At each stage say whose decision it was. Add no stage the quote does not list. | Tests R3 (architecture, schemas) and the integration side of R2 in one walk-through. |

### Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Sixty seconds: why you over a PM who has the title?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses" (dossier rows V1, V2) | Pause. Restate: "The question is why integration-led work fits this role." Answer in 60 seconds: the integrations you led (V1), the playbook your team uses (V2, inspectable), and the title gap said once, plainly. Hold through two follow-ups. Concede the title, not the work. | Pressure persona. The hold is only what V1 and V2 carry. |
| C2 | "Nobody here will count integration work as roadmap experience. Hold your position or concede it." | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier row V1) | Hold: "I agree it isn't roadmap ownership, and I haven't claimed it. What the integrations show is the scoping and go-live work on the vendor's REST APIs." Concede: say where a PM would be stronger, and what you would ramp on first. Do not fold on the work. | Hold-then-concede. The title and roadmap concessions are already acknowledged in B1, so they stay consistent. |

### Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Ran quarterly roadmap-input sessions feeding client evidence to product"; "Wrote the internal integration playbook her team uses" (dossier rows V1, V3, V2) | A 90-second arc: where you started, the integrations (V1), the playbook (V2), the roadmap-input sessions (V3) with the limit volunteered, and why this role. Stop at the reason for the move. Add nothing to the arc. | A casual opener is still scored. The arc is built only from the three verified lines. |
| E2 | "What's your first read on our partner-facing API platform?" | JD | [grounded] "Own the roadmap for the partner-facing API platform" (role_profile responsibility) | If you have used the platform, say how. If not, say what you have read and what you would want to learn first. Do not describe the platform beyond what the posting says. | A casual question on the core of the JD. The answer must not invent familiarity. |
| E3 | "What's one thing you'd want to change on the platform in your first quarter, and what would make you sure?" | CASE | [grounded] "Own the roadmap for the partner-facing API platform" (role_profile responsibility) | Name one change, the evidence you would need before committing, and the stakeholder who decides. A plan, not a past. | CASE in casual clothing. Scored like a live problem. |

**Requirement coverage**

| Requirement | Questions |
|---|---|
| R1, 3+ years PM | B1, B3, C1, E1 |
| R1 sub-claim, roadmap authority | A2, A4, B1, B3 |
| R2, shipped API or platform products | B2 (JD), D3, B1 |
| R3, technical fluency | B2, D3 |
| R4, stakeholder management | A4 (JD content), D2 |
| R5, agile delivery | B5, B2 |
| Responsibility: roadmap | A2, E2 |
| Responsibility: discovery | A3 |
| Responsibility: specs and delivery | A4 |
| Responsibility: adoption metrics | A1, A5 |

No requirement is left uncovered.

## Reverse questions

Five or more, each with why it lands. No interviewer profile exists, so none is tied to the interviewer's own path. Two of these come from the dossier's employer questions.

1. **"Which roadmap decisions does this PM make alone, and which belong to the squad leads?"** Why it lands: the dossier's top unknown. The answer tells you how much of the 30-day plan is yours to run.
2. **"How is partner API adoption measured today, and what is the current baseline?"** Why it lands: the posting names adoption as a responsibility and states no baseline. This is the dossier's risk to validate.
3. **"When the squads disagree with a partner request, who settles it, and how quickly?"** Why it lands: tests decision rights from their side, and gives you the ground A4 rehearses.
4. **"Which partner integrations are causing the most trouble right now?"** Why it lands: it points at the scoping and go-live work you can speak to, and invites them to describe the real pain.
5. **"What did the last person in this role get right, and where did they get stuck?"** Why it lands: shows you want the actual job, and gives you their real constraints.
6. **"What would you need to see at day 90 to call this hire a success?"** Why it lands: turns the objection in B1 into a shared scorecard, and closes on the outcome.

## Prohibited claims

Built from the dossier's `prohibited_claims` and `uncertain_or_weak_areas`, plus two inflated forms built locally.

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | Dossier prohibited_claims | Plain acknowledgment: "I haven't held a product manager title." No answer slot. |
| Having owned a product roadmap | Dossier prohibited_claims; uncertain_or_weak_areas (acknowledge_gap) | Plain acknowledgment: "I haven't owned a product roadmap." No answer slot. |
| Having set prioritization for an engineering squad | Dossier prohibited_claims | Plain acknowledgment: "I haven't set prioritization for an engineering squad." No answer slot. |
| Shipped API or platform products | Inflated form of F1: widens V1 from integrations on the vendor's APIs to shipped products | V1 at its own scope: "Led 30+ end-to-end client integrations of the vendor's REST APIs." The limit is the pack's analysis: your material shows integration work, not a shipped product. No first-person negative. |
| Set the product's roadmap, or decided what product built | Inflated form of F2: widens "Ran quarterly roadmap-input sessions feeding client evidence to product" into decisions | F2 at its own scope. The limit is the pack's analysis: your material shows input, not decisions. |

## Sources

- **Provided:** `tuesday-dossier.md`, job-underwriter JSON v1.1, generated 2026-08-14, decision `conditional_go`.
- **Dossier consumed.** Sections used: `role_profile` (requirements, responsibilities, unknowns), `handoff_to_mock_interview` (verified evidence, uncertain areas, likely objection, risks, employer questions, prohibited claims), and `decision` as context only. Not in the dossier: `evidence_map`, `risk_register`, `evidence_state`.
- **Dossier age.** The dossier is about three months old. If the posting has changed since August, its requirements and unknowns may be out of date.
- **Research, all refused.** Two searches were sent. Both were refused because web search permission was not granted in this session:
  - "Quartzline platform APIs partner integrations". Refused.
  - "Quartzline company strategy recent news". Refused.
- **Research tier: L1, searches 2 of 6, fetches 0 of 2.**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quartzline values` | unavailable | No call sent: search was refused in this session. Values cheat sheet not needed; no values-style round detected |
| 2. `Quartzline interview process hiring manager` | unavailable | No call sent: search refused. Loop structure unknown; persona weights rest on the hiring-manager prior |
| 3. `Quartzline strategy` / recent news | unavailable | Both calls refused. Would have fed a CO bank; the CO bank is absent |
| 4. `{interviewer name} Quartzline` | n/a | No name given |
| 5. Representative JD for the title | skipped | The dossier's `role_profile` fixes the requirements and the JD-tagged questions |

Un-numbered: the platform-partner search above was sent outside the declared targets. It was refused, and it would have fed the platform questions (E2, E3).

Dropped sections: grounding brief (no L2), values cheat sheet (no values-style round), interviewer read (no interviewer information), graded deliverables (none declared), delivery coaching (no assessment).

## Upgrade menu

- **Web search permission** → a company strategy brief, the interview loop structure, and a CO question grounded in current strategy. Two searches were refused this session.
- **Deep research (L2), if search is granted** → four more targets, up to 6 searches and 2 fetches, one time, with the cost stated before it runs.
- **Interviewer's name** → an interviewer read, persona weights from their public footprint, and a reverse question tied to their own path.
- **Current posting text** → confirms the requirements in the dossier, which is three months old.
- **Recruiter's note on the 45 minutes** → if there is a fixed format or a pre-declared exercise, its own section.
- **Your CV** → firmer F1 and F5 evidence, and defend-the-number answers backed by real counts for the 30+ figure.
- **An inspectable record of a roadmap-input session** (agenda, notes, or the list of items sent to product) → lifts F2 from medium to high.
