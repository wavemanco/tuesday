Priya's pack is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-tuesday-part-2-rooms-case-1-denied-86d8ce20/d3cd9977-1e67-4820-a621-f1cca7d1ed9d/scratchpad/northwind-data_senior-gtm-lead-emerging-products_interview_pack.md` and attached here.

I built it for a single 60-minute peer conversation with Dan, so the persona weights lean on the peer pattern and on his "relentlessly data-driven" profile:
- **Data-Driven Prober (5 questions):** Priya's $400M figure, her revenue-model assumptions, and her target-setting. Expect every number to be taken back to its assumptions.
- **Peer Evaluator (4):** the seam with sales strategy, credit across teams, and who decides when plans conflict.
- **Skeptic (3):** partner-motion design, which is the one requirement marked "required" and where her match is thinnest.
- **Case / Strategist (3):** bundling by the larger platform vendor and whitespace levers, with a pricing angle.
- **Pressure (2) and Conversational (2):** hold-then-concede on the $400M, a scripted 90-second journey, and the AI question.

**Highest-ROI prep:** the partner-motion question (C1). Her only match is a partner-level revenue model, so she should describe that at its own scope and concede the motion itself with a ramp plan. Her coach-reported lack of sales-ops and quota experience is handled as an answer slot, not a claim, until she says it herself.

**Interpretive choices to check:**
- **Research didn't run.** Web search was refused, so the pack uses only your JD highlights, research note, coach's notes and Dan's profile. No values cheat sheet is included because no values round is named in your description. Your research note is undated, so confirm the priorities are current.
- **Evidence is secondhand.** Her quotes come from your coach's notes, so each one needs her confirmation before she rehearses it.
- **Zero questions for you.** You said you had everything needed, so the pack proceeds without asking. The upgrade menu lists what would sharpen it, mainly the full JD text and a SQL/Tableau analysis she can walk through.

I can run a live drill, for example Dan as the Prober on A1 or the Skeptic on C1. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, and convert the pack to Word if you want it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: northwind-data_senior-gtm-lead-emerging-products_interview_pack.md -----
# Interview prep pack: Senior GTM Strategy Lead, Emerging Products, Northwind Data

**Interviewer:** Dan Kovac, Director of Sales Strategy. Peer: you both report to the same VP.
**Format:** one 60-minute conversation.
**Built from:** your JD highlights, your coach's notes on Priya's background, your research note on Northwind, and your profile of Dan. No full JD or CV text was supplied, and no web research ran (search was refused this session; see Sources).

## How to use this pack

- **Personas** describe how a question is asked. **Types** describe what is being scored.
- **Type key:** EXP = work-experience deep-dive. JD = role and JD-driven. CO = company and strategy. CASE = live problem. VAL = behavioral and values (not used here; see below).
- Guidance is scaffolding, not a script. Each cell is written to be said in 90 to 120 seconds, in Priya's own words.
- **Sections left out, and why:** values cheat sheet (no values-style round is named in your description, so none is detected), graded deliverables (none declared), delivery coaching (no assessment supplied), prep triage (no prep time given).

## 4. Fit snapshot

Requirements come from your JD highlights, quoted as you gave them. Evidence is quoted from your coach's notes, so each claim is secondhand and needs Priya to confirm it. Confidence: `medium` = specific but no inspectable proof yet. `low` = vague or adjacent. `none` = no support.

No gate rows. None of the highlights is a term (authorization, location, schedule, pay, travel or credential), so no gate question applies.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" — your JD highlights | "9 at a large consumer-tech company in product strategy & ops" — coach's notes | low | [inferred] | transferability | Your material shows product strategy and operations, not GTM for a new line. Words at its own scope: "I spent 9 years at a large consumer-tech company in product strategy and ops." Answer slot: if you have touched go-to-market work for a launch, say which and how you decided; if not, say so plainly. |
| F2 | "identify whitespace across land/adopt/expand/renew" — your JD highlights | "proposed a store-surface change credited with a ~$400M ARR uplift" — coach's notes | medium | [grounded] | transferability | The sentence supports proposing and credit. It does not show whitespace by lifecycle stage. Words: "I proposed a store-surface change; it was credited with a ~$400M ARR uplift." Expect a probe on the number (A1). |
| F3 | "run independent analysis in SQL and Tableau" — your JD highlights | "skilled in SQL/Tableau" — coach's notes | medium | [grounded] | none | The quote reaches the requirement. Expect a probe, because "skilled" has no artifact behind it. Bring one analysis you ran yourself (A4). |
| F4 | "partner-motion design experience required" — your JD highlights | "built a partner-level revenue model used in carrier negotiations" — coach's notes | medium | [grounded] | transferability | The model is adjacent work, not partner-motion design. Words at its own scope: "I built a partner-level revenue model used in carrier negotiations." Answer slot on the motion itself (C1). |
| F5 | "strong cross-functional influence" — your JD highlights | "set annual volume targets with cross-org consensus" — coach's notes | medium | [grounded] | none | The quote reaches the requirement in role terms. Expect a probe on how consensus was reached (A3, B1). Words: "I set annual volume targets with cross-org consensus." |
| F6 | "AI experience a plus" — your JD highlights | "uses AI tools daily" — coach's notes | low | [inferred] | transferability | Daily use is usage, not AI work. Coach usage only: "I use AI tools daily." Answer slot: what she has built or evaluated beyond use, if anything. |
| F7 | none in your JD highlights. Your coach's notes say the gap sits in the interviewer's own area (sales strategy) | "No classic sales-ops or quota-setting experience." — coach's notes | none | [grounded] | capability | This is a gap the coach reports, not one Priya has stated. Her own words are not yet on record, so the only words available are an answer slot: if she has done sales-ops or quota-setting work, say what; if not, say so in her own words (C3). The pack's observation, in analysis only: the material does not show that work. |

**Coverage of requirements:** see the coverage line after the banks.

## 6. Grounding brief

Source: your research note. The note is undated, and this run could not check it independently, so treat each item as provided, not verified.

- **Stated priorities:** enterprise expansion; an AI copilot launch ("Compass"); reaching profitability. Quoted from your note: "Northwind's three stated priorities are enterprise expansion, an AI copilot launch ('Compass'), and reaching profitability."
- **Competitive frame:** "bundling by a much larger platform vendor" is the main threat, per your note.
- **Vocabulary:** "land/adopt/expand/renew" is from your JD highlights. Use the same words he would use.
- **Stale check:** confirm the priorities are still current before the interview. Nothing here should be used to correct Dan.

## 7. Reading the interviewer

Public footprint was not researched (search refused). This read rests only on your profile of Dan.

- **Career pattern:** pricing and monetization roles, plus one early-stage startup chapter.
- **Self-described style:** "relentlessly data-driven."

**Practical implications:**
1. Every number you give will be taken back to its assumptions. Name your weakest assumption before he asks (A1, A2).
2. Cases will likely lean toward pricing, packaging and unit economics, his native language (D1, D3).
3. The startup chapter means builder stories will land, and he may test for scrappiness. Describe what you did, not how big it was (B1).
4. In a peer conversation he is pricing what a hire costs his own work. Lead with what you bring to his team, not only what you need (B3).

**Mirror opportunities:**
- **Shared vocabulary, not a shared jump:** revenue modelling. Your "built a partner-level revenue model used in carrier negotiations" (F4) sits next to his monetization background. Use this as a common language. Do not present it as a career parallel. Priya's material shows no startup chapter, so there is no shared jump to offer.

## 8. Persona table and weights

**Weighting reasoning, in three passes:**
- **Relationship prior (peer):** Peer Evaluator and Data-Driven Prober dominate.
- **Interviewer signals:** "relentlessly data-driven" raises the Prober. The pricing spine tilts cases toward pricing. The startup chapter raises builder stories and scrappiness probes.
- **Loop:** your description (one 60-minute conversation with a peer) establishes the loop, so no archetype fallback is needed. It names no values round, so values is not detected.

Depth: top personas get 5 and 4 questions, mid-weight personas 3, low-weight 2. Session total: 19 questions.

| Persona | How it shows up in this round | Likelihood, with reasoning | Counter-strategy, keyed to IDs |
|---|---|---|---|
| Data-Driven Prober | Counting method and assumptions behind the ~$400M and the revenue model | Top, 5 questions. The peer prior names it, and "relentlessly data-driven" pushes it up | Hold the attribution sentence at its scope; name the weakest assumption first (A1, A2, A4) |
| Peer Evaluator | Seams with sales strategy, credit, disagreement | Top, 4 questions. The peer prior names it; the hire touches his team's work | Reciprocity first; propose seam principles rather than claimed seams (B1 to B4) |
| Skeptic | Partner-motion design; GTM for new lines; the sales-side gap | Mid, 3 questions. Partner motion is the one item marked required, and F4 is its thinnest match. F7 sits in his area | Concede specifically and give a ramp plan (C1 to C3) |
| Case / Strategist | Bundling response; sequencing against priorities; whitespace levers | Mid, 3 questions. His pricing background tilts cases toward packaging | Clarify first; use pricing vocabulary; state no vendor facts you have not checked (D1 to D3) |
| Pressure / Stress | The ~$400M number; a 60-second "why you" | Low, 2 questions. Peer rounds are rarely time-boxed, so this is insurance on composure | Hold the proposal; concede only the part she does not know (E1, E2) |
| Conversational / Rapport | Journey opener; the AI question | Low, 2 questions. Casual openers are still scored | 90-second arc; AI as usage, not claimed building (G1, G2) |
| Values / Behavioral | Not weighted | Zero. No values-style round is named, and the loop is established without one | None |

## 9. Question banks

### A. Data-Driven Prober (top weight, 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how that ~$400M figure was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Defend the number in your own words. Answer slot: if you know how the uplift was counted, say how; if there was no such step, or you don't know, say so plainly. Then cover the other three beats: what the figure is sensitive to, the assumption you would defend least, and which part was yours. Hold to "I proposed the change; it was credited with the uplift." | F2 is the evidence. A prober goes to headline numbers first. The attribution has to survive his follow-ups. |
| A2 | "Which assumption behind your partner-level revenue model would you defend least?" | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" | Name the weakest assumption before he does, in your words. Answer slot: if you set the model's assumptions, say which and how you chose them; if they came from elsewhere, say so. Don't describe inputs you haven't mentioned. | F4 is the adjacent evidence for the required partner work. A prober tests whether it is hers. |
| A3 | "Walk me through how you set annual volume targets with cross-org consensus. What number did you propose?" | EXP | [grounded] "set annual volume targets with cross-org consensus" | Explain the process in your words. Answer slot: if you proposed a number, say what it was and how it was reached; if the target was set by others and you took part in the consensus, say which part. Don't call the targets quotas unless you use that word yourself. | F5 is the nearest target-setting in her material. It sits closest to his home area, so he will ask whether these were quotas. |
| A4 | "Tell me about an analysis you ran yourself in SQL or Tableau. What was the question, and what did it show?" | JD | [grounded] "skilled in SQL/Tableau" | Open prompt: you choose the instance. Name the question and the result, in your words. Answer slot: if no analysis you ran comes to mind, say so plainly, then name the nearest one you did run. | The JD requirement "run independent analysis in SQL and Tableau" raises the theme. F3 is "skilled" with no artifact, so this answer is where it gets tested. |
| A5 | "How would you check a whitespace estimate before you trusted it?" | JD | [generic] | No claim about your past. Answer with a method: what the denominator is, how segments are defined, what sanity check you would run against known accounts, and what result would change your view. | Covers "identify whitespace across land/adopt/expand/renew" with a method question. [generic] because it asks for a method pattern, not a fact about this company. |

### B. Peer Evaluator (top weight, 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our teams sit side by side. Where's the seam between a new-line GTM plan and sales strategy, and what happens when we disagree?" | JD | [grounded] "strong cross-functional influence" (your JD highlights) | Propose seam principles, not a history of this seam: who decides what, and how a disagreement gets settled. For the disagreement, open prompt: you choose the instance. Story map from "set annual volume targets with cross-org consensus": the consensus crossed organisations, and the part you proposed is yours to say. Answer slot: if a disagreement with a peer comes to mind, say what it was and how it ended; if not, say so and give the consensus case. | The JD line is the raising source. The seam wording is the peer-prior stem. |
| B2 | "How do you handle credit when work spans teams?" | JD | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Keep attribution at the sentence's scope: you proposed the change, and the uplift is credited to it. Answer slot: if you know how credit was shared across teams on that change, say how; if it wasn't discussed, say so. Don't present the uplift as your result alone. | The peer's credit probe. The $400M sentence is the nearest example, so its attribution has to hold. |
| B3 | "What would you need from my team to make a new line work in its first quarter?" | JD | [generic] | Reciprocity first. Name the inputs a new line needs from sales strategy, in general terms, and what you would bring to his team's work. No claim about your past. | Tests dependency awareness, which a peer is scoring. [generic] because it asks for a pattern. |
| B4 | "If a new line's launch plan and your sales plan pull in different directions, who should decide, and how?" | JD | [grounded] "own GTM strategy for two new product lines" (your JD highlights) | Propose a decision-rights principle: what you would decide, what you would ask for, and how you would escalate. Answer slot: if you have made a call that sat between product and sales, say what; if not, say so and say what you would propose. | The JD's new-line mandate meets his remit. The question assumes nothing about her past. |

### C. Skeptic (mid weight, 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | **Highest-ROI prep.** "Partner-motion design is required for this role. Which part of it would you be weakest at on day one?" | JD | [grounded] "partner-motion design experience required" (your JD highlights); [grounded] "built a partner-level revenue model used in carrier negotiations" (coach's notes) | **Deepest rehearsal.** Hold: the model is what it says, and you stop there. Answer slot: if you have designed any part of a partner motion, say which part and how you decided it; if you have not, say so plainly, and say what the revenue model did carry. Two follow-ups to rehearse: (1) "What did you build in that model?" Answer with the sentence, not more. (2) "So you haven't designed a partner program?" Concede the specific gap, name the first thing you would learn, and how, as a plan. Never fold the model into design. Name the limit before he asks: the model is revenue work, not the motion. | The one requirement marked required, and F4 is its thinnest match. The objection will come in some form, so a rehearsed, specific concession is the protection. |
| C2 | "You have strategy and product work behind you. What in owning GTM for two new lines is new to you?" | JD | [grounded] "2 years strategy consulting at a top firm"; [grounded] "9 at a large consumer-tech company in product strategy & ops" | Answer slot: if you have touched go-to-market work for a launch, say which and how you decided; if not, say so plainly and say what product strategy did carry over. Stay within the two quoted roles and name no launch. | F1. The premise is the quoted work history and the JD's new-line mandate. |
| C3 | "What part of sales-side planning would you need to learn first in this role?" | JD | [generic] | No claim about your past. Name the planning inputs you know least well and how you would learn them. If you have done sales-side planning, say what, in your own words. The pack does not supply that. | Lets her name the coach-reported gap herself. F7's words stay an answer slot until she says them. Presupposes only the role's remit. |

### D. Case / Strategist (mid weight, 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "A much larger platform vendor bundles a comparable capability into its suite. What do you need to know first, and how would you plan Northwind's response?" | CASE | [grounded] "bundling by a much larger platform vendor" (your research note) | Clarify, then objective, segmentation, approach, metrics and risks. Pricing angle: what the bundle does to deal-level price, and which accounts see it first. Name one packaging lever and what would change your mind. Don't state facts about the vendor you haven't checked. | CO/CASE on the stated threat. The pricing angle matches his background. |
| D2 | "Enterprise expansion, an AI copilot launch and reaching profitability are the stated priorities. How would you sequence GTM for a new line against them?" | CO | [grounded] "Northwind's three stated priorities are enterprise expansion, an AI copilot launch ('Compass'), and reaching profitability" (your research note) | Name the trade-off. Pick one priority to lead with and say why, then name the one metric you would watch. Don't describe internal plans you have not seen. Use "Compass" as your note gives it. | The CO bank needs one strategy question grounded in a source. The note is undated, so check it first. |
| D3 | "Pick one of the land, adopt, expand or renew stages. What pricing lever would you test first, and how would you know it worked?" | JD | [grounded] "identify whitespace across land/adopt/expand/renew" (your JD highlights) | Structure it: the stage, the lever, the metric, the risk. Make no claim about your past; state the test as a plan. | R2 with a pricing angle. Gives him a case he can score on structure. |

### E. Pressure / Stress (low weight, 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "That result. How much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | **Hold, then concede.** Hold through two follow-ups: "I proposed the change; it was credited with the uplift." Concede only the part you don't know. If you don't know how the uplift splits across the work, say so and say how you would check. Never fold on the proposal itself. Name the limit before he asks: you can claim the proposal, not the uplift as your result alone. | Tests composure on the number. The held position is the quoted sentence, so it cannot be stronger than that sentence. |
| E2 | "Sixty seconds: why you for this, over someone who has run a sales motion?" | JD | [generic] | No claim about your past. Three beats in sixty seconds: the quoted work that bears on the JD's lines, one named gap, and a ramp you can describe. Don't say you have run a sales motion. | Persona stem for pressure. The rival is hypothetical, so the answer makes no claim. |

### G. Conversational / Rapport (low weight, 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm"; [grounded] "9 at a large consumer-tech company in product strategy & ops"; [grounded] "built a partner-level revenue model used in carrier negotiations" | Pre-scripted 90 seconds: consulting, then consumer-tech product strategy and operations, then the partner revenue model, then what you want from this role. One beat per quote. Add nothing between them. | Casual openers are still scored. This is the biography, so a fixed arc. |
| G2 | "What are you actually playing with in AI these days?" | JD | [inferred] "uses AI tools daily" (coach's notes); "AI experience a plus" (your JD highlights) | Name the tools and what you use them for, in your own words. Answer slot: if you have built or evaluated anything with AI beyond using tools, say what; if you have only used them, say that. | F6 is low confidence, so the pack coaches usage only. The plus is about AI experience, which the answer must not overstate. |

**Totals:** 19 questions (A 5, B 4, C 3, D 3, E 2, G 2). Within the 18 to 26 target.

**Coverage of JD requirements:**

| Requirement (your JD highlights) | Covered by |
|---|---|
| own GTM strategy for two new product lines | C2, B4, D2 |
| identify whitespace across land/adopt/expand/renew | A5, D3 |
| run independent analysis in SQL and Tableau | A4 |
| partner-motion design experience required | C1, A2 |
| strong cross-functional influence | B1, B2, A3 |
| AI experience a plus | G2 |

No requirement is uncovered. No values or deliverable questions are included, for the reasons given under "How to use".

## 11. Reverse questions

Five questions, plus a peer reciprocity question. Each is one line in the order to ask.

| # | Question | Why it lands |
|---|---|---|
| R1 | "You spent a stretch at an early-stage company after your pricing and monetization work. What from that has carried into sales strategy here?" | Ties to his own path, from your profile of him. Turns an interrogation into a conversation between peers. |
| R2 | "What could a new person do in their first month that would genuinely help your team?" | Peer reciprocity. Shows you think about his load, not only your own role. |
| R3 | "If a new line's plan and your sales plan pull in different directions, how do you settle it today?" | Asks about the seam directly, and shows you have already thought about it. |
| R4 | "Where is the bundling threat showing up most in the deals your team sees?" | Uses the competitive frame from your research note. Signals homework on the company, not generic curiosity. |
| R5 | "What would make the first new line a clear win by month twelve, and how would you measure it?" | Ties the role to the profitability priority. Asks how success is judged, which is what a prober values. |

## 13. Prohibited claims

Each entry is a stretched wording that the pack will not coach. The honest form is the quote at its own scope.

| Not coached | Basis | Honest form |
|---|---|---|
| "I owned GTM for a product line" or "I launched" anything | Inflated form of F1 ("product strategy & ops") | F1's quote at its own scope. Pack's observation only: the material shows product strategy and operations, not a GTM launch. |
| "I set quotas" or "I ran sales-ops" | Inflated form of F5 ("set annual volume targets"), and of the coach-reported absence in F7 | F5's quote, with A3's slot asking whose number it was. |
| "I drove the ~$400M" or "the $400M was my result" | Inflated form of F2 ("credited with") | "I proposed the change; it was credited with the uplift." |
| "I designed partner programmes" or "I designed the partner motion" | Inflated form of F4 ("built a partner-level revenue model") | F4's quote at its own scope, with C1's slot asking what she has designed. |
| "I have no sales-ops or quota-setting experience" as her own statement | F7: coach's note, not stated by Priya | Not usable until she says it. Pack observation only: the material does not show that work. Words come from the answer slot in C3. |
| "I'm skilled in SQL/Tableau" as an expert claim | Inflated form of F3 ("skilled") | "skilled in SQL/Tableau," with A4 asking for one analysis she ran. |

## 14. Sources

**Provided documents:**
- Your JD highlights (six lines, quoted in the fit snapshot).
- Your coach's notes on Priya's background (quoted in the fit snapshot and the banks).
- Your research note on Northwind.
- Your profile of Dan Kovac, including his self-description "relentlessly data-driven."

**Searches sent (3), all refused (permission not granted in this session). I did not retry after the refusal:**
- "Northwind Data company values principles": refused.
- "Northwind Data interview process": refused.
- "Dan Kovac Director of Sales Strategy Northwind Data": refused.

**Fetches:** 0 of 2 used.

**Research tier: L1 — searches 3 of 6, fetches 0 of 2; user links read 0**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Northwind Data values | unavailable | Refused. Would have moved the values cheat sheet, which is left out because no values round is detected |
| 2. Northwind Data interview process | unavailable | Refused. Would have checked the loop. The loop is already established by your description, so weights don't depend on it |
| 3. Northwind strategy / recent news | skipped | Your research note fixes current priorities and the competitive frame. Undated, flagged in the grounding brief |
| 4. Dan Kovac Northwind | unavailable | Refused. Would have added his public talks and posts to the interviewer read and reverse questions |
| 5. Representative role JD | skipped | Your JD highlights fix the fit snapshot. Full JD text is still an upgrade |

## 15. Upgrade menu

- **Full JD text** → the six requirement quotes move to full scope, and "required" on partner motion gets tested as written.
- **Priya's own words on sales-ops and quota work** (what she did, or that she has not done it) → F7 gets its plain acknowledgment, or real slot content; C3 sharpens.
- **One SQL or Tableau analysis she can describe** → A4 gets a story, and F3 gains an artifact, which would raise its confidence.
- **The method behind the ~$400M, in Priya's own words** → A1's slot content, and steadier E1 composure.
- **Search permission**, or a pasted values page and a recruiter's confirmation of the round → a values check, and a sourced strategy brief for D1 and D2. Deeper research (L2) would add up to 6 searches and 2 fetches, several minutes; it is blocked until search is allowed.
- **Dan's public talks or posts, pasted as links** → a sharper interviewer read, and reverse questions tied to his writing.
- **Recruiter's note on the format** → if there is a pre-declared exercise, a build section for it.
- **A tuesday-dossier.md from the job-underwriter, if one exists** → its prohibited claims and unresolved risks would bind every cell.
