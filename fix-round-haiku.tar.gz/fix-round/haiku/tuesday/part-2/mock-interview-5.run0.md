I've read the playbook and its reference files. Next is research at the default L1 tier: six searches and two fetches, sent in one batch.
Research didn't run: all six searches were refused because WebSearch permission hasn't been granted. The pack is built from your message and the recruiter's email, so I'm saving it now with those gaps stated.
Your prep pack is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-tuesday-part-2-rooms-case-5-denied-5306f7ce/86614142-371e-4f72-a83f-2c2bf5de47e2/scratchpad/kelverton-rail_senior-partnerships-manager_interview_pack.md`.

Research didn't run. The WebSearch permission was declined, so the pack rests on your message and the recruiter's email. It has no values section, no read on Deepa or Ross, and no strategy brief, and most of the guidance is marked `[generic]`.

The highest-ROI prep is B1, "You have never sold into rail." Deepa will almost certainly ask it, and it is your own stated gap. The answer is a plain acknowledgment followed by the operator-side work you can actually point to.

Drill: I can play Deepa on B1 whenever you want to rehearse it.
Dossier: I can save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions.

1. Could you paste the key points from the strategy team's market report, its shortlist and headline numbers? Your POV has to differ from the consensus answer in that report, and I can't check that without it.
2. Could you paste the job description and your CV? Without them the requirement rows are generic, and the rail and quota probes are guesses about the posting.
3. Does the JD name any hard requirement, such as location, right to work, or rail experience as a condition? A gate you don't meet is worth knowing before Tuesday.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: kelverton-rail_senior-partnerships-manager_interview_pack.md -----
# Interview prep pack: Senior Partnerships Manager, Kelverton Rail

Second-round panel, 60 minutes. Deepa (VP Partnerships, your future manager) and Ross (Commercial Director). First 15 minutes: a short spoken point of view on operator partnerships over 18 months, no slides, landing on what it means for the operators. Then Q&A, with commercials pressed by Ross.

**Build note:** Research did not run (WebSearch permission was refused). This pack is built from your message and the recruiter's email. Values, interviewer read and grounding brief are omitted. Most guidance is `[generic]` until the upgrade items below are supplied.

## How to use

- **Personas** describe how a question is asked. **Types** describe what is being scored: VAL (values), EXP (your experience), JD (the role), CO (company), CASE (live problem).
- Guidance is scaffolding, not a script. Say it in your own words.

## Prep triage (240 minutes)

1. **75 min:** Build the POV (section 5). Pick one thesis, write its concession, write the operator-impact close. Do not write a script.
2. **45 min:** Rehearse B1, B2 and C1 until the plain acknowledgment comes out in one breath.
3. **60 min:** Rebuild the £4M. Write what you would say about how it was counted and which part was yours (D1, C2). Only write what you can document.
4. **30 min:** Two full 15-minute POV runs out loud, timed.
5. **15 min:** Reverse questions.
6. **15 min:** Buffer.

Everything else is insurance.

## 1. Fit snapshot

Requirements come from the recruiter's email (quoted by her) and from your own stated gaps. No JD was supplied, so requirement coverage cannot be mapped to a posting.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "what it means for the operators themselves" — recruiter email | "bus and light rail network planning" — your message; "I know the operator world from the other side" — your message | medium | [grounded] | presentation | Say it in those words: bus and light rail network planning, and knowing the operator world from the other side. Let the panel draw the link to what it means for operators. Adds no decision you have not stated. |
| F2 | "Ross will push on commercials" — recruiter email | "took it from 6 partners to 40, roughly £4M of influenced revenue" — your message | medium | [grounded] | transferability | Adjacent work: partner revenue in payments, not operator-facing. Bridge: "For the ISV channel, I took it from 6 partners to 40, roughly £4M of influenced revenue." Limit, as the pack's observation: your material says influenced, not closed. Answer slot: how the figure was counted (D1). |
| F3 | Rail operator selling experience — `[generic]` role-family requirement, no JD | "Never sold into rail specifically" — your message | none | [generic] | capability | Words from your stated negative: "I've never sold into rail specifically." Then the ramp as a plan, never as a past. |
| F4 | Carrying a direct quota — `[generic]` role-family requirement, no JD | "never carried a direct quota, only influenced revenue" — your message | none | [generic] | capability | Words from your stated negative: "I've never carried a direct quota." Then "I've influenced revenue," at its own scope. |
| F5 | Partnership leadership at scale — `[generic]` role-family requirement | "took it from 6 partners to 40" — your message | medium | [grounded] | transferability | Scale was in the ISV channel, not operators. Bridge: "I took it from 6 partners to 40 in the ISV channel." Limit, as the pack's observation: your material shows no operator partners. |

No hard gate is shown in the material. The JD could add one (see question 3 below).

## 2. Prohibited claims

Not coached, with basis and honest form:

| Not coached | Basis | Honest form |
|---|---|---|
| "I've sold into rail" | Negative you stated | "I've never sold into rail specifically." |
| "I carried a quota" | Negative you stated | "I've never carried a direct quota." |
| "I owned £4M of revenue" | Inflated form of "roughly £4M of influenced revenue" | "I influenced roughly £4M of revenue," at that scope. |
| "I've worked for an operator" | Stretched form of "transport consulting" and "from the other side" | "I worked in transport consulting, on bus and light rail network planning." |

## 3. Persona weights and reasoning

Panel: blend the top two personas of each member's relationship. Deepa is the hiring manager. Ross is commercial and strategy-heavy.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist (top) | Live operator and partner problems; "what does it mean for operators" | High. Deepa's prior is Case plus Skeptic; the recruiter named the operator framing as the close. | Clarify, then objective, then segmentation, then approach, then one metric, then risk. Say the framework once. |
| Skeptic (Deepa) | Probes the rail gap and the quota gap | High. Both negatives are stated in your own message, and a hiring manager will test them first. | Plain acknowledgment, then the bridge you actually have, then a ramp plan. Hold through two follow-ups. |
| Pressure (Ross) | Time-boxed commercial challenge | High. The recruiter said Ross will push on commercials. | Pause, restate, anchor in the quote, hold two follow-ups, concede the specific gap. |
| Data-Driven Prober (Ross) | Asks how the £4M was counted | Medium. A headline number invites this, but the panel has not yet shown interest in the figure. | Say what you know and what you don't, and name the weakest assumption before they do. |
| Conversational | Opener and "walk me through" | Low. Possible in the first minutes. | A 90-second arc from your own sentences. |

## 4. Question banks

Your quoted sentences sit in each Provenance cell. Guidance is speakable in 90 to 120 seconds.

### Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "What does it mean for the operators themselves?" | CASE | [grounded] "Please land on what it means for the operators themselves." — recruiter email | Clarify which operators (franchised, open access, freight, passenger) and whose decision it touches. Then one operator outcome, one partner route to it, and one measure. Use the POV theses in section 5. Hold nothing about your past here. | The recruiter named this as the close. The approach is `[generic]`. |
| A2 | "A partner has signed, but the operator's systems team cannot integrate before the timetable change. What do you do?" | CASE | [generic] | Clarify the change date and what slips if it moves. Decide whether to hold the partner, re-scope, or move the operator. Name who you would call in the first hour. Make no claim about your past. | A live problem from the partnership job. Generic, because there is no JD. |
| A3 | "What would make you walk away from an operator partnership?" | CASE | [generic] | Name one condition, the reason for it, and the trade it costs you. | Tests judgment, not a memorised answer. |
| A4 | "What is the first number you would track in your first 90 days?" | CASE | [generic] | One metric tied to the operator outcome from A1. Say what it is sensitive to. | Links the POV to the commercial questions. |

### Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You have never sold into rail. Why would an operator take a call from you?" | JD | [grounded] "Never sold into rail specifically" — your message; [grounded] "I know the operator world from the other side" — your message | Plain acknowledgment: "I've never sold into rail specifically." Then the bridge: bus and light rail network planning, and knowing the operator world from the other side. Hold through two follow-ups by returning to what you have. The ramp is a plan: shadowing a rail seller on the first operator calls. Concede the learning curve explicitly. | **Highest-ROI prep.** Near-certain from Deepa, and it is your own stated gap. |
| B2 | "You have never carried a quota. How would you be accountable for a number here?" | JD | [grounded] "never carried a direct quota, only influenced revenue" — your message | Plain acknowledgment: "I've never carried a direct quota." Then "I've influenced revenue, and I'd want the target defined in those terms." Answer slot: if any influenced figure was tracked against a target, say what. If none was, say so and say how you would agree the measure with Ross. Do not describe a quota you did not carry. | Same stated gap, asked about accountability. |

### Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Sixty seconds: why you over someone who has sold into rail?" | JD | [grounded] "Never sold into rail specifically" — your message | Pause, then restate the question. Anchor in the operator-side work. Hold through two follow-ups. Concede the gap specifically: the rail sales cycle and operator procurement. Do not fold on the operator-side credibility. | Pressure stem adapted to your gap. |
| C2 | "That's influenced revenue, not closed. Why should I count it?" | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" — your message | Answer slot: say what the influenced figure covered, in your words. If you can say how it was counted, say so. If you cannot, say so and say what you would want to measure. Hold the definition. Concede that influenced is not closed. | Ross will press commercials, and the number is the magnet. |

### Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how that £4M was counted." | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" — your message | Answer slots: how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. Each in your own words. If you do not know how it was counted, say so. | Every headline number gets this question. |

### Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "9 years in partnerships"; "5 years in transport consulting"; "last 4 at a payments company running the ISV channel" — your message | Ninety-second arc in your own words: nine years in partnerships; five before that in transport consulting, on bus and light rail network planning; the last four running the ISV channel at a payments company. | Opener. Short, but scored. |

**Requirement coverage:** No JD supplied, so no requirement can be mapped. Recruiter's stated focus: operator outcome (A1, POV); commercials (C2, D1, B2).

**Count:** 10 questions. This is below the usual session total because there is no JD to cover. The upgrade menu says what a JD would add.

## 5. Graded deliverable: the 15-minute POV

Declared by the recruiter. Spoken, no slides. Must land on what it means for the operators.

**Facts to build on:** F1 only. "bus and light rail network planning"; "I know the operator world from the other side."

**Theses** (all `[generic]`, patterns for operator partnerships, with no claim about Kelverton's product):

1. **Plan around the operator's decision calendar, not your release calendar.** *Concession:* I have not seen this operator's actual buying calendar. This is a pattern to test, and it may not hold for every operator.
2. **Partners as delivery capacity.** The operator's real bottleneck is changing the timetable, so the partnership's first job is reliable delivery. *Concession:* if partners deliver unevenly on live timetables, this becomes a risk, so set the partner quality bar before scaling.
3. **Outcomes the operator can see, such as fewer manual timetable reworks, rather than seats sold.** *Concession:* outcome-based commercials may not fit operators' contracts or how Kelverton sells. Test that with Ross first.

**Differentiation:** The consensus answer is "grow the partner count." Your CV invites it (6 to 40). Do not pitch partner count as the operator outcome. Whether this differentiates depends on the strategy team's report, which is not in this conversation. Until its key points are pasted, the consensus answer is unknown.

**Close (operator impact):** What changes for the operator's planning team in 18 months, and how they would know the partnership had worked. `[generic]`.

## 6. Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What would a good first six months look like for you in this role?" | Turns the panel's standard into a shared target. |
| R2 | "Which operator relationships do partners hold today, and which does Kelverton hold directly?" | Shows you are thinking about the operator as the buyer. |
| R3 | "How is the partnership commercial target set this year, and how is partner-sourced revenue split from direct?" | Shows you know the number will be argued over. |
| R4 | "What is the one operator outcome partnerships should move in the next 18 months?" | Asks for the answer to the POV's brief, so you can check your thesis against it. |
| R5 | "What would make you confident in a partner-influenced number?" | Puts Ross's question back to Ross. |

## 7. Sources

- **Provided:** the recruiter's email, as quoted in your message. Your background, as stated in your message. The strategy team's market report: you have read it, but its text is not in this conversation, so nothing from it is used.
- **Searches and fetches (all refused):**
  - `Kelverton Rail values`, refused (target 1)
  - `Kelverton Rail interview process partnerships`, refused (target 2)
  - `Kelverton Rail strategy news`, refused (target 3)
  - `Deepa VP Partnerships Kelverton Rail`, refused (target 4)
  - `Ross Commercial Director Kelverton Rail`, refused (target 4)
  - `Senior Partnerships Manager rail technology train operating company scheduling software job description`, refused (target 5)

Research tier: L1 — searches 6 of 6 (all refused), fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Kelverton Rail values | unavailable | Values cheat sheet (omitted). Would have set the value names. |
| 2. Interview process | unavailable | Loop structure. The panel shape comes from the recruiter's email; no loop source, so no archetype was applied. |
| 3. Strategy / recent news | unavailable | Grounding brief, CO bank, the POV's competitive frame. The strategy report would move this if pasted. |
| 4. Deepa and Ross public footprint | unavailable | Interviewer read and tailored reverse questions. |
| 5. Representative JD | unavailable | Requirement rows and requirement coverage. |

## 8. Upgrade menu

- The strategy team's market report key points (shortlist and headline numbers) → POV differentiation checked against the consensus answer; theses become `[grounded]`.
- The JD text → requirement rows become `[grounded]`; JD-tagged questions and a coverage line become possible.
- Your CV → more quoted sentences for stories and the fit snapshot.
- Permission to use search → values, interview process, strategy and the Deepa and Ross footprint can be researched.
- Any hard requirement in the JD (location, right to work, rail experience as a condition) → a gate row, surfaced first.
