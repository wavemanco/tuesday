Your prep pack is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-tuesday-part-2-rooms-case-3-denied-63486e6b/43961a1e-91fe-450b-a3b4-ecb2f669dfab/scratchpad/stripe_product_operations_manager_interview_pack.md`.

It is a generic pack for now. I had no CV, no job description, and no round details, and web search was refused in this session, so I could not check Stripe's values, interview loop, or current strategy. Every requirement and question is labeled `[generic]`, and nothing in it describes Stripe specifically. The pack includes 16 questions across six interviewer styles, six reverse questions, and a short case-style set for product operations.

Once you send the material below, I can make the pack specific to you and to Stripe:
- **Your CV, or a few bullets about what you've done.** Your real examples become the story answers, and I'll flag any claim that's stronger than what you wrote.
- **The job description.** The requirements become quoted and checkable.
- **Who you're meeting and what the round looks like.** Tell me whether it's a hiring manager, a peer, or a panel, and whether it's one session or several.

I can also run a live mock: I play the interviewer, ask one question, and give feedback against that question's guidance. And if you want, I can save a dossier file that records the gaps this prep exposed, so you can carry them into later sessions. Tell me if you'd like either.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: stripe_product_operations_manager_interview_pack.md -----
# Stripe: Product Operations Manager, final round: interview pack

Built with no CV, no job description, no round details, and no research (the web searches were not permitted in this session). Every requirement and question below is `[generic]` and marked as such. Nothing here is a claim about Stripe's values, loop, or strategy.

## How to use

- **Personas** describe how a question arrives. **Types** describe what is being scored.
- Type key: **VAL** behavioral/values · **EXP** your own experience · **JD** role requirements · **CO** company knowledge · **CASE** live problem.
- Guidance is scaffolding, not a script. Speak it in your own words.

## Fit snapshot (worksheet variant: no background supplied)

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Designs and runs operating cadences and internal processes `[generic]` | none given | none | [generic] | discovery | Answer slot: describe a process you designed or ran from start to finish. If none was yours to design, say so and describe the one you ran. |
| F2 | Builds metrics and dashboards that drive decisions `[generic]` | none given | none | [generic] | discovery | Selection scaffold: pick a metric you used to make a call. If you never used one that way, say so and say what you would track first. |
| F3 | Coordinates launches across product, engineering, finance and go-to-market `[generic]` | none given | none | [generic] | discovery | Selection scaffold: pick a launch or rollout with several functions. If none was yours to coordinate, say what your part was. |
| F4 | Diagnoses problems with data and segments `[generic]` | none given | none | [generic] | discovery | Selection scaffold: pick a time a number moved and you had to find out why. If you never did, say so and say how you would approach it. |
| F5 | Influences senior stakeholders who disagree `[generic]` | none given | none | [generic] | discovery | Selection scaffold: pick a time a senior stakeholder rejected your proposal. End with the honest branch: if none comes to mind, say so, then give the nearest one. |
| F6 | Writes clearly for executive audiences `[generic]` | none given | none | [generic] | discovery | Show a document or memo you wrote, if you have one. Without it, describe how you structure a one-page update. |

Every row says `discovery` because nothing in your material is on the page yet. None of them is a gap you have stated.

## Persona table

Relationship and round are unknown, so weights are flat and the reasoning is shown. Recalibrate when you tell me the round.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | Live problem from the role's daily work | High: a final round usually includes a live problem `[generic]` | Clarify, then structure, then answer. Say the framework aloud. |
| Data-Driven Prober | Asks how a number was counted | Medium: applies to any metric you cite | Name the weakest assumption before they do. Say plainly what you don't know. |
| Skeptic | Probes the gap, the motivation, "why now" | Medium: standard for a final round `[generic]` | Answer the one objection you expect until it's boring. Don't bluff. |
| Pressure / Stress | Interrupts, time-boxes, challenges your position | Medium: depends on the interviewer's style, unknown | Pause. Hold through two follow-ups before conceding anything real. |
| Conversational | Casual opener, scored anyway | Medium: most rounds open this way | Keep a 90-second arc for "walk me through your journey." |
| Peer Evaluator | Seams between teams, disagreement, credit | Low to medium: depends on whether the interviewer is a peer | Frame what you bring to their team, not just what you need. |

## Question banks

Depth is flat (two to three per persona) because the weights are flat. The bank is shorter than the usual 18 to 26 for the same reason. Expand it once you send the JD.

### Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A launch is two days out and the engineering lead says the rollout tooling isn't ready. What do you do?" | CASE | [generic] | Clarify what is blocking and what the launch risk is. Name the decision owner. Give two options with their costs, then recommend one. Give no past example here. | Tests judgment under a live constraint. `[generic]` because the scenario is a pattern for the role. |
| C2 | "A key metric dropped 15% week over week. Walk me through how you'd diagnose it." | CASE | [generic] | Check the definition and the data first. Then segment, and check the timing against releases and outside events. Say which one you'd check first and why. | Tests structure. Name the assumption about the data before you analyze it. |
| C3 | "You have a backlog of internal process requests and two people. How do you decide what to do first?" | CASE | [generic] | Name the criteria: impact, reach, and cost of delay. Say what you would stop doing. Say who decides when criteria conflict. | Tests prioritization. Tradeoffs out loud beat a confident list. |

### Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Pick a metric you used to make a decision. How was it counted, and which assumption would you defend least?" | EXP | [generic] | Pick one real metric. Say the definition, the data source, and the assumption you are least sure of. If you did not count it yourself, say whose it was. Answer slot: if you cannot say how it was counted, say so plainly. | Tests whether you know your own numbers. |
| P2 | "How would you know a process change worked, and not just coincided with something else?" | JD | [generic] | Name a baseline, a comparison group or time window, and one confound you'd watch for. Say what result would make you reverse the change. | Tests causal thinking without a case study. |
| P3 | "What makes an operational metric misleading?" | CO | [generic] | Give two concrete ways: gaming, and a metric that moves without the outcome moving. Give one example you have seen, only if you have seen one. | Tests judgment about measurement. Generic by design. |

### Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| S1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | Name one specific area and the ramp plan for it. Don't claim it's not a gap. Say how you'd learn it fast. | The most predictable objection to any candidate. Rehearse it until it sounds plain. |
| S2 | "Why this role, and why leave where you are now?" | JD | [generic] | Give two reasons tied to the work itself, not to the company's reputation. Keep both to one sentence each. Don't criticize your current employer. | Motivation consistency is scored. |
| S3 | "Operations at this kind of company is mostly writing docs. Why isn't that you?" | JD | [generic] | Answer with a specific example of work that changed a decision. Don't argue with the framing. Concede the part that is true. | Tests whether your story is more than process. |

### Pressure / Stress

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| X1 | "Sixty seconds: why you over someone who's done this exact job before?" | JD | [generic] | Pause. Restate the question. Give your strongest true point. Hold it through two follow-ups. Concede specifically: "I haven't done that exact job, and here's how I'd close that gap." | Tests composure and holding a position. |
| X2 | "Tell me about a time a process you proposed was rejected by a senior leader. What did you do?" | EXP | [generic] | Open prompt: pick an instance and give the stakes, what you did, and how it ended. If no such time comes to mind, say so plainly and give the nearest one you have. | Tests how you handle a no. |
| X3 | "Our operations are already fine. Why do we need this role?" | CASE | [generic] | Don't defend the premise immediately. Ask what "fine" means to them. Then name one measurable gap you'd look for first. | Tests whether you can challenge a premise respectfully. |

### Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R1 | "So, walk me through your journey." | EXP | [generic] | A 90-second arc: where you started, the two or three moves that shaped you, and why this role follows. Keep it to what you actually did. | Casual openers are scored. Pre-scripting the arc keeps it from wandering. |
| R2 | "What's a tool or workflow you've been tinkering with lately?" | JD | [generic] | Name one real thing and one thing you learned from it. Don't name something you have only read about. | Casual questions still score curiosity and honesty. |

### Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Our teams sit side by side. Where's the seam, and what happens when we disagree?" | JD | [generic] | Propose seam principles, not a seam you can't see yet. For disagreement, give a principle you use and one time it cost you something. | Tests partnership fit. Only likely if the interviewer is a peer. |
| E2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Name the default you use: credit goes to the people who did the work, named specifically. Give one example only if you have one. | Tests how you share credit. |

## Requirement coverage

No JD was supplied, so no requirement is quoted. Each role-family requirement maps to the questions that cover it:

- F1 → C3, X3
- F2 → P1, P3
- F3 → C1, E1
- F4 → C2, P2
- F5 → X1, X2
- F6 → R1, S3

## Reverse questions

1. "What does a good first quarter look like in this role?" *Why it lands:* shows you think in outcomes, not tasks.
2. "Which team's operating problem is most urgent right now, and what has already been tried?" *Why it lands:* shows you want to start where it matters.
3. "How do product ops and finance or go-to-market ops split ownership of launch readiness?" *Why it lands:* shows you know ownership is where operations work usually breaks.
4. "What decision in the last quarter would have gone differently with better operating data?" *Why it lands:* turns the metrics question around and tests how they think about data.
5. "How does the team tell whether an internal process is actually working?" *Why it lands:* shows you care about measuring whether a change worked.
6. "What could a new person do in their first month that would genuinely help your team?" *Why it lands:* the reciprocity question. Use it if the interviewer is a peer.

## Values / principles cheat sheet

Not included. No values-style round is established, and no company values were fetched. Once you have Stripe's own values page (paste it), this section can be built from it.

## Prohibited claims

Built from the fit snapshot. No candidate sentences are on file yet, so there is nothing to stretch and no entry to list. Once you paste your CV, this section will hold the claims the pack will not coach, each with its basis.

## Sources

- Provided documents: none.
- Searches attempted: `Stripe company values operating principles`, `Stripe interview process final round Product Operations Manager`, `Stripe Product Operations Manager job description`. All three were refused because search permission was not granted in this session.

Research tier: L0 (no search results were returned)

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Stripe values` | unavailable | Values cheat sheet, not included. Would have supplied the value names and definitions. |
| 2. `Stripe interview process {role family}` | unavailable | Loop structure and persona weights. Would have shown whether the final is several sessions. |
| 3. `Stripe strategy` / recent news | unavailable | CO questions. Would have grounded C3 and P3 in current priorities. |
| 4. `{interviewer name} Stripe` | n/a | No interviewer name was given. |
| 5. representative `Product Operations Manager` JD | unavailable | Fit snapshot rows, which would have become `[inferred]` quotes instead of `[generic]`. |

## Upgrade menu

- **Your CV or resume** → every worksheet row gets quoted evidence; the banks get story-mapped answers and an EXP prep list.
- **The job description** → the requirement rows become `[grounded]` quotes, and the JD-tagged questions get written against them.
- **Who you're meeting and the round format** → persona weights are recalibrated, and the reverse questions are tuned to that person.
- **If the final is several back-to-back sessions, send the schedule** → one mini-pack per session.
- **Stripe's values page, pasted** → the values cheat sheet and VAL questions are built from it.
- **The recruiter's prep email** → coverage of any exercise or presentation they announced.
