Your prep pack is saved at /tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-tuesday-part-2-rooms-case-5-denied-92d14486/43526c31-2a0b-434f-bedc-017fc027106d/scratchpad/kelverton-rail_senior-partnerships-manager_interview_pack.md. It's built from your message and the recruiter's email, without a job description. Web search was declined here, so company facts are generic. The internal market report isn't in this conversation, so the differentiation section is open until you paste its headline points.

The first thing to do is the POV, in three sentences: one thesis, its concession, and one thing an operator's planners would notice. The biggest risk is "never sold into rail" and "never carried a direct quota." Rehearse B2 and C2 before anything else.

Say the word and I'll play Deepa on B2, the question the pack names as its highest-ROI prep. I can also save a tuesday-dossier.md recording the gaps this prep exposed. If you'd like the pack as a Word document, say so and I'll convert it.

1. Can you paste the job description? If not, I'll proceed without it, and the JD-derived rows stay out.
2. Where is the role based, how much travel to operator sites is expected, and do you have the right to work in the UK? Your material and the recruiter's email don't say, and these can gate the role.
3. Do you want me to retry web research? If you allow it, I'll run the three company checks (values, interview process, recent strategy) and the pack's company facts become sourced rather than generic.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: kelverton-rail_senior-partnerships-manager_interview_pack.md -----
# Interview prep pack: Senior Partnerships Manager, Kelverton Rail, second-round panel

## 1. Title block

- **Role:** Senior Partnerships Manager
- **Company:** Kelverton Rail (UK rail-tech, about 600 staff, sells scheduling software to train operating companies), as you described it
- **Panel:** Deepa (VP Partnerships, your future manager) and Ross (Commercial Director)
- **Format:** 60 minutes. First 15 minutes: a spoken POV on operator partnerships over the next 18 months, no slides, landing on what it means for the operators themselves. Remaining time: Q&A, with Ross pressing on commercials.
- **Built on:** your message and the recruiter's email as quoted in it. No job description, no CV, no interviewer profile, no web research (see section 14).
- **Version:** first version.

## 2. How to use, and the type key

Personas describe how a question arrives. Types describe what it is scoring. The guidance is scaffolding for a spoken answer, not a script. Only rehearse what you actually did, in your own words.

| Tag | Meaning |
|---|---|
| VAL | Behavioral: whether past behavior shows the values the company asks for |
| EXP | Experience deep-dive: whether your claims survive scrutiny, and what was yours |
| JD | Role requirement: whether you can do the listed job, gaps included (none here, no JD) |
| CO | Company and strategy knowledge (none here, no research) |
| CASE | Live problem from the role, scored on structure and reasoning |

Provenance on each question: [grounded] means traceable to a quoted sentence of yours or the recruiter's; [generic] means a role-family pattern with no claim about you or the company.

## 3. Prep triage (about 4 hours)

1. **60 min: the POV.** Write it in three sentences: one thesis from section 5, its concession, and one thing an operator's planners would notice. Say it aloud twice, timed under 15 minutes.
2. **45 min: the two sharpest objections.** Rehearse B2 (rail selling) and C2 (how much of the £4M was yours), holding and conceding in the wording you would actually use.
3. **45 min: defend the number.** Work D1 and D2 in your own words. Write down what you know about how the £4M was counted and what you do not. "I don't know" is an acceptable answer if it is true.
4. **45 min: the commercial case.** Outline A3, the fee-discount request, and say the trade you would offer.
5. **30 min: questions and the opener.** Pick three reverse questions from section 11 and rehearse the 90-second arc in E1.

Everything else is insurance.

## 4. Fit snapshot

Requirements come from the recruiter's email, quoted, because no job description was supplied. Gate rows are surfaced, not bridged.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "where you'd take our operator partnerships over the next 18 months" (recruiter's email) | "took it from 6 partners to 40, roughly £4M of influenced revenue" (your message) | medium | [grounded] | transferability | Your material shows partner growth in a payments channel, not operator partnerships. Say the channel result in your own words, then answer the operator question as a plan, not as a record. The quote says the channel grew; it says nothing about operators. |
| F2 | "what it means for the operators themselves" (recruiter's email) | "5 years in transport consulting" (your message) and "bus and light rail network planning, so I know the operator world from the other side" (your message) | medium | [grounded] | transferability | Your material places you on the planning side of operator networks, as a consultant. It does not place you on the operator's side of a buying decision. Describe the planning work you did. Do not describe what operators decide as if it were your decision. |
| F3 | "Ross will push on commercials." (recruiter's email) | "never carried a direct quota, only influenced revenue" (your message) | medium | [grounded] | capability | You stated this absence. Words: "I haven't carried a direct quota. What I carried was influenced revenue." Nothing added to make the gap smaller. |
| F4 | selling into rail or transport operators (role-family, no quoted source) | "Never sold into rail specifically" (your message) | none | [grounded] | capability | You stated this absence. Words: "I haven't sold into rail." Then how you would learn it, said as a plan, never as a past. |
| F5 | location and travel to operator sites, right to work for this role (role-family, no quoted source) | none given | none | [generic] | hard_gate | Your material does not establish this. Surfaced here, not bridged. Asked in the first question of the next message. |

## 5. Graded deliverable: the 15-minute POV

The recruiter announced this as a spoken POV with no slides. Judged on judgment and altitude, and on whether the operators come first. Build on F1 and F2 only; everything about rail operators below is a hypothesis you are testing aloud, not a fact to state.

**Grounded facts to build on:** F1, F2 (quoted above). Nothing else about your history.

**Thesis options.** Pick one. Each carries a concession you must say.

- **T1. Plan partnerships on the operator's planning cycle, not ours.** Built on F2: you have watched operator network planning from the consultant's side. [generic] reasoning about how planning cycles drive what operators can adopt. Concession: I am reasoning from planning practice, not from a documented process at any operator. Some operators may run planning in-house or through other vendors, and I would need to check that first.
- **T2. Measure partnerships by an outcome the operator can see, not by partner count.** Built on F1: partner count was the metric in the channel you ran. Concession: attributing an operator outcome to one partner is hard, and an outcome metric can drift into one nobody controls. I would want to see which outcomes the operators already track before I committed to any.
- **T3. Start with one co-funded pilot with one operator before any wider commitment.** [generic] pattern from partner-led growth. Concession: pilots can stall, cost goodwill, and delay revenue, and the commercial case may stay weak until a pilot ends. Ross will press here, so have the number you would accept for a pilot.

**Differentiation.** The internal market report is not in this conversation, so I cannot name its consensus answer or show you where a thesis departs from it. Paste its headline recommendations (upgrade menu) and this section will say which of T1 to T3 depart from them, and why.

**Anti-pick (role-family, [generic]).** Name one partnership you would decline and the reason. Partnership roles usually include saying no. Rehearse this in one sentence.

**Requested close: what it means for the operators themselves.** Close on one concrete change an operator's planners would see in their first six months with the partnership. Speak it as your hypothesis, and say how you would check it with them.

**Watch:** every statement about operators, passengers, regulators or rail budgets is yours to test, not a fact. Do not say "operators are struggling with X" unless the interviewers have said it.

## 6. Grounding brief

Dropped. No strategy brief was supplied and the deeper research pass did not run.

## 7. Reading the interviewer

Dropped. You gave names and titles only. No public profile was read, so no career pattern, style or mirror opportunity is claimed. Upgrade menu covers it.

## 8. Persona table

Session mode, one round. The recruiter's email establishes the format (panel, 60 minutes, POV then Q&A), so this is not an archetype fallback.

| Interviewer | Relationship prior | Dominant personas | Why |
|---|---|---|---|
| Deepa (future manager) | Hiring manager | Case/Strategist, Skeptic | Buying capability and derisking the gaps; expect live problems on the operator roadmap |
| Ross (Commercial Director) | Cross-functional, executive | Pressure, Data-Driven Prober | Your email says he will push on commercials; commercial directors test numbers and composure |

| Persona | How it shows up | Weight | Counter-strategy |
|---|---|---|---|
| Case/Strategist (Deepa) | Live operator-partnership problems | 5 questions, top | Clarify, then structure aloud; state one hypothesis early; say what would make you wrong |
| Pressure (Ross) | Time-boxed challenges to your credibility and to the £4M | 4 questions | Pause, restate, hold a position through two follow-ups, concede precisely |
| Skeptic (Deepa) | Rail selling, motivation, why now | 4 questions | Say the gap plainly, then a plan; never bluff a rail sale |
| Data-Driven Prober (Ross) | Defend-the-number on influenced revenue | 3 questions | Say how it was counted only if you know; name the weakest assumption you know of |
| Values/Behavioral | Cross-functional stories | 2 questions | STAR-shaped, your contribution in "I", the team in "we" |
| Conversational | Openers and the biography | 2 questions | A scripted 90-second arc from your own sentences |

No interviewer-signal adjustments: no profiles.

## 9. Question banks

Every question carries its type, provenance and guidance. Provenance quotes each sentence the guidance rests on.

### Case/Strategist (Deepa), weight 5

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Sketch the plan for our operator partnerships over the next 18 months. What do you need to know first?" | CASE | [generic] | Clarify first: which operators, what they buy today, what the current partners do. State the objective, then segments, approach, metrics and risks. Say one hypothesis early and what would make you wrong. | The POV's own frame, asked as a live problem. Uses the recruiter's 18-month window (F1). |
| A2 | "An operator's planners say a scheduling change caused disruption last month, and they want a fix before renewal. What do you do first?" | CASE | [generic] | Separate facts from blame. Find who owns the change. Propose a joint review with the operator's planners. Say what you would not promise before the review. | Tests the operator-side lens the recruiter asked for (F2). Live problem, so it presupposes nothing about your past. |
| A3 | "An operator asks for a fee discount to bring a new route onto our scheduling. What do you say?" | CASE | [generic] | Structure: the value they get, the precedent it sets for other operators, what you would trade for it, what you need from finance. Name the trade you would accept, and the one you would refuse. | Ross's commercial push, in the form he is most likely to use. No claim about your past. |
| A4 | "Which operator segment would you start with, and what would make you wrong about it?" | CASE | [generic] | Pick one segment, give two reasons, and name the evidence that would change your mind. Do not pretend to know the segment sizes. | Forces a prioritized answer rather than a list. Pairs with T1 to T3 in section 5. |
| A5 | "How would you know, six months in, that the partnerships are working?" | CASE | [generic] | Give one leading indicator and one lagging one, say how you would verify each with operators, and say which you would report first to Ross. | The 18-month frame needs a checkpoint answer. |

### Skeptic (Deepa), weight 4

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this role would you be weakest at on day one?" | CASE | [grounded] "Never sold into rail specifically" | Name rail selling directly, in your own words. Then say what you would do in the first 30 days to close it: who you would learn from, what you would read, which operator conversations you would ask to sit in on. | F4 is the largest gap. Naming it first costs less than having it found. |
| B2 | "I don't see rail selling in your background. How would you handle that in this role?" | JD | [grounded] "Never sold into rail specifically" and "bus and light rail network planning, so I know the operator world from the other side" | Highest-ROI rehearsal in this pack. Words: "I haven't sold into rail." Then the planning work, described as planning work, and what you would do to build selling skill with a named plan. Hold through two follow-ups by returning to what you did in planning. Concede without folding: if she presses on whether you could close a deal, say you do not know yet and what would tell you. | The most predictable objection. Deepest rehearsal here: most follow-up levels, exact concession wording, and a limit named before she asks for it. |
| B3 | "Why leave a payments company for rail, and why now?" | CASE | [generic] | Open prompt. Answer in terms of what you want from the work, not what you dislike about where you are. Do not claim knowledge of rail you do not have. | Motivation probe, standard for a career move between sectors. |
| B4 | "What would an operator get from a partnership with us that they would not get from a plain licence?" | CASE | [generic] | State the operator outcome you would test (section 5, T2), and say what you would need from the operator to find out. | Tests whether you can make the partnership case, not just describe partners. |

### Pressure (Ross), weight 4

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Sixty seconds: why you over someone who has already sold into rail?" | CASE | [grounded] "bus and light rail network planning, so I know the operator world from the other side" and "Never sold into rail specifically" | Pause. Restate the question in your own words. Concede that the other candidate may have the rail selling you do not. Then hold: the operator-side context from planning is yours to offer, and so is a plan to learn selling fast. Hold through two follow-ups; concede the selling gap explicitly on the second. | Adapted from a standard pressure stem. The concession is the test. |
| C2 | "That £4M. How much of it was actually you?" | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" | Answer slot. If it was yours, say what you did and what was the channel's, in your own words. If the number was the channel's, say so plainly and state your part. Do not give a share you cannot back. | Premised question: the quote carries the £4M and the channel, not your share of it. |
| C3 | "Influenced revenue is a soft number. Would you stand behind it in front of our CFO?" | EXP | [grounded] "only influenced revenue" | Answer slot. Say which parts of the number you would defend and which you would not. Hold the definition you used, and concede that influenced is not sourced. | Pressure on the measure. Honest answer is precision, not defence. |
| C4 | "If none of this converts in 18 months, what do you tell me?" | CASE | [generic] | Name the leading indicator you would report at month six, and what you would do if it missed. Hold the plan through one follow-up, then concede any part you cannot yet defend. | Tests commitment to a timeline you cannot yet check. |

### Data-Driven Prober (Ross), weight 3

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how that £4M was counted." | EXP | [grounded] "roughly £4M of influenced revenue" | Answer slot, four parts, in your words: how the figure was counted; what it is sensitive to; the assumption you would defend least; which part was yours. If you do not know how it was counted, say so plainly and say where you would look. | Defend-the-number. An explanation you cannot repeat under a second question is worse than none. |
| D2 | "Which assumption behind that number would you defend least?" | EXP | [grounded] "roughly £4M of influenced revenue" | Weakest-assumption move: name one you know of before he does. If you know none, say that, and say what you would check first. | The move that turns a gotcha into a credibility point, when it is true. |
| D3 | "What is the difference between influenced and sourced revenue, and which did you report against?" | EXP | [grounded] "only influenced revenue" | Answer slot. Say which you reported against and the definition the channel used, if you know it. If you do not, say so. | Tests whether you know your own metric's definition. |

### Values/Behavioral (Ross), weight 2

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V1 | "Tell me about a time you gave a senior commercial leader a number they did not want." | VAL | [generic] | Open prompt. Pick a time you delivered news a leader did not want. It needs a named stake, the number, and what happened after. If none comes to mind, say so plainly, then give the nearest thing your material carries: "took it from 6 partners to 40, roughly £4M of influenced revenue". | Cross-functional behavioral prompt for a commercial director. The nearest quote is what the material carries. |
| V2 | "When did you put a partner's interest ahead of your own pipeline?" | VAL | [generic] | Open prompt. Pick a time you put the partner first at a cost to a metric. If no such time comes to mind, say so plainly, then give the nearest thing your material carries. | Partner-centred values probe. Do not invent the ending. |

### Conversational (Deepa), weight 2

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | CASE | [grounded] "9 years in partnerships", "running the ISV channel", "bus and light rail network planning, so I know the operator world from the other side" | A 90-second arc: nine years in partnerships; the last four running a payments channel; before that transport consulting, on the planning side of operator networks. Stop there, and invite the next question. | Casual openers are scored. The arc uses only your sentences. |
| E2 | "What are you most curious about in our operator business?" | CASE | [generic] | Pick one question from section 11 and ask it. Do not answer with a generic line about enthusiasm. | Tests whether you researched the business. Without research, your curiosity must be specific to what you know. |

**Coverage line.** The job description was not supplied, so this maps the recruiter's stated requirements instead.

| Requirement (source) | Covered by |
|---|---|
| "where you'd take our operator partnerships over the next 18 months" (recruiter) | A1, A4, A5 |
| "what it means for the operators themselves" (recruiter) | A2, A4, B4, section 5 close |
| "present a short POV" (recruiter) | Section 5 |
| "Ross will push on commercials" (recruiter) | A3, C2, C3, C4, D1, D2, D3 |
| Never sold into rail (your message) | B1, B2, C1 |
| Why now, why this move (implicit in the panel) | B3 |
| Location and travel (role-family) | none, and why: the material does not establish it, so the Step 1 question asks it |

Session total: 20 questions, within 18 to 26.

## 10. Values / principles cheat sheet

Dropped. No values round is documented, and no published company values were supplied or read. The loop is established by your recruiter's email, which names no values round.

## 11. Reverse questions

Each one has a reason it lands. None is tied to an interviewer's own path: no profile was read. There is no reciprocity question, because neither interviewer is a peer.

1. "How is partnership success measured today: operator renewal, share of an operator's network, or something else?" Lands because it asks Ross to show his commercial logic and tells Deepa you are thinking about outcomes.
2. "What have operators asked for in the last year that the team has not yet been able to offer?" Lands because it asks for the operator view, which the role is about.
3. "Which operator relationship has been hardest to keep, and what went wrong?" Lands because it asks for a real case, and shows you expect operators to be hard.
4. "How much of this role is saying no to partnership requests?" Lands because it tests the anti-pick, and signals you know partnership roles include refusing work.
5. "What would you need from me in the first 90 days that you would not expect a new partnerships manager to ask for?" Lands because it shows you plan to work with Deepa, not around her.
6. "If the market report's main recommendation is wrong, what would show that first?" Lands because it shows you read it critically, and asks Deepa to name what she is testing. Use only if you have read the report.

## 12. Requirement coverage and the POV

See the coverage line in section 9.

## 13. Prohibited claims

Not to be coached, and why. Built here from the fit snapshot, because no dossier exists.

| Not coached | Basis | Honest form |
|---|---|---|
| "I have sold into rail" or "I know rail sales" | Negative you stated (F4) | "I haven't sold into rail." No slot. |
| "I carried a quota" or "I owned the commercial number" | Negative you stated (F3) | "I haven't carried a direct quota. What I carried was influenced revenue." |
| "I know how operators buy" | Inflated form of F2. Planning work widened to the operator's buying side | F2's quote at its own scope: planning work, as a consultant. The limit is the pack's observation: the material places you on the planning side, not the buying side. |
| "I grew operator partnerships" | Inflated form of F1. The channel was payments partners | F1's quote at its own scope. |
| "The £4M was mine" or "I closed the £4M" | Inflated form of F1. "Influenced" widened to "closed" and "mine" | The quote as written, roughly £4M of influenced revenue. Your share is an answer slot (C2, D1). |
| Stated facts about operators, rail budgets or regulators | Presumed, not sourced | Offered only as hypotheses to test (section 5), never as facts. |

## 14. Sources

- **Provided:** your message (background, the recruiter's panel format as you quoted it).
- **Not in this conversation:** the internal market report, which you said you read. I have not seen its text, so nothing in this pack is drawn from it.
- **Web research:** declined here. The three calls below were refused, so no company fact was taken from the web.

**Research tier: L1, searches 3 of 6, fetches 0 of 2; user links read 0.**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Kelverton Rail values | unavailable | Refused: query "Kelverton Rail values". Would have fixed the values cheat sheet (section 10) and its condition. |
| 2. Kelverton Rail interview process, partnerships | unavailable | Refused: query "Kelverton Rail interview process partnerships". Would have confirmed the panel's loop and any values round. |
| 3. Kelverton Rail strategy and recent news | unavailable | Refused: query "Kelverton Rail strategy news scheduling software train operators". Would have fed the CO bank and the grounding brief. |
| 4. Deepa and Ross, public footprint | unavailable | No call sent: the host refused search. Would have fed the interviewer read and persona weights. |
| 5. Representative JD for this title | unavailable | No call sent: the host refused search. Would have fixed JD-derived rows and questions. |

## Upgrade menu

- **Job description text** → the recruiter's requirements become quoted JD rows, JD-tagged questions are added, and the coverage line becomes complete.
- **The market report's headline recommendations** (paste them) → section 5's differentiation becomes concrete: which thesis departs from the consensus, and why.
- **Deepa's and Ross's public profiles or talks** → the interviewer read, persona weights, and a reverse question tied to their own path.
- **Permission for web search** → the three company targets run, and the values, process and strategy facts become grounded rather than generic.
- **The role's sales target, if any** → sharper commercial questions in C and D.
