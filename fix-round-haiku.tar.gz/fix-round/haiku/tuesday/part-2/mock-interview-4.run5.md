Your prep pack is saved as /tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-tuesday-part-2-rooms-case-4-denied-9cc55b0f/dfe777f3-4647-48ba-a7db-e9c653916d6a/scratchpad/quartzline_product_manager_platform_apis_interview_pack.md. I built it for a hiring-manager round from your dossier.

Three things to know before Thursday:

- **Company research didn't run.** The web search calls were refused for lack of permission, and I didn't retry them. The pack has no verified facts about Quartzline's values, interview loop or strategy. If you grant search permission, I can fill those in.
- **Your dossier is about three months old.** It was generated 2026-08-14. Check that the posting still matches its role profile.
- **The dossier and I disagree on R2, "Shipped API or platform products."** The dossier doesn't flag it as weak, but none of your verified evidence says you shipped an API product. The pack grades it as a transferability gap. Settle which reading is right before Thursday, because the interviewer may probe it.

The highest-return prep is A1, the objection the dossier names: "You've never held the PM title or owned a roadmap." Rehearse the concession and the limit until they come out plainly. Then run the 90-second opener (E1) and say the first two reverse questions (RQ1 and RQ2) out loud. Those cover the two things the dossier couldn't settle: how much decision authority the role has over the squads, and how adoption is measured today.

I can run a live drill on A1 or any other question, or save a `tuesday-dossier.md` with this session's `pack_feedback` so the gaps carry forward.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quartzline_product_manager_platform_apis_interview_pack.md -----
# Interview prep pack: Product Manager, Platform APIs at Quartzline

**Round:** hiring-manager conversation, 45 minutes, Thursday
**Interviewer:** name not given. Relationship: hiring manager (from your note).
**Built on:** `tuesday-dossier.md` (job-underwriter v1.1, generated 2026-08-14, decision `conditional_go`). The dossier is about three months old. Check that the posting still matches its `role_profile` before Thursday.

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored: JD (a stated requirement), EXP (what you did), CASE (a live problem), CO (company), VAL (values).
- Guidance is scaffolding, not a script. Say what you did, in your own words.
- Quoted sentences in the Provenance and Evidence columns are the only things the guidance says about your past.

## Prep triage (before Thursday)

1. Rehearse **A1** aloud until the concession and the limit come out plainly. The underwriter named this objection, so it is the highest-return prep here.
2. Run **E1** (the 90-second arc) once, then say **RQ1** and **RQ2** out loud. These are the two answers you need before accepting.
3. Practise **B1** once. It tests the squad-authority unknown the dossier flags.
4. Everything else is insurance.

## Fit snapshot

E1 to E3 are the dossier's `verified_candidate_evidence` items 1 to 3, in order. Confidence is the dossier's grading. Gap type follows the routing rule in `output-template.md`.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" (dossier R1) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier E1) | low | [inferred] | transferability | Your material shows integration leadership on the vendor's REST APIs, with no PM title and no roadmap. Bridge at its own scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs." The limit stays in the open: the PM years are not in that work. Answer slot: if any of that work was product-management work, say which and how; if it was not, say so plainly and stay with the integrations. |
| F2 | "Shipped API or platform products" (dossier R2) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier E1) | low | [inferred] | transferability | E1 is the client side of a vendor's APIs. No quote says you shipped one. Bridge at its own scope, as in F1. Answer slot: if an API or platform release went out with your decisions on it, say which; if none did, say so and name the nearest thing your material carries, the integrations and the playbook. *Pack observation:* the dossier does not list R2 as a weak area, but no verified claim reaches shipping. Settle which reading is right before Thursday. |
| F3 | "Technical fluency: API docs, schemas" (dossier R3) | "Wrote the internal integration playbook her team uses" (dossier E2) | high | [grounded] | presentation | An integration playbook is documentation of how integrations run, so it reaches docs in other terms. Say it as: "I wrote the internal integration playbook my team uses." Do not stretch it to schemas. Answer slot: if you wrote or reviewed schema definitions, say which; if not, say so and say what you would read first. |
| F4 | "Stakeholder management across engineering, sales, customers" (dossier R4) | "Ran quarterly roadmap-input sessions feeding client evidence to product" (dossier E3); "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier E1) | medium | [grounded], caveat visible | transferability | Your material reaches customers and product. Engineering squads and sales are not in it. E3 is confirmed with limited inspectable proof, so volunteer the limit: say what the sessions were and what you can point to. Answer slot: if you worked with the engineering or sales side on any integration, say how; if not, say so plainly. |
| F5 | "Agile delivery experience" (dossier R5) | none given | low | [grounded] | discovery | Your material does not show agile delivery. Clarify rather than bridge. Answer slot: if you ran sprints, standups or backlog reviews with an engineering team, say what you ran; if you never worked that way, say so plainly and say how you did delivery. |
| F6 | Owning a roadmap and prioritization authority (dossier uncertain_or_weak_areas, R1 sub-claim) | none given | none | [grounded] | capability | The plain acknowledgment, from dossier `prohibited_claims`: "I haven't owned a product roadmap, and I haven't set prioritization for an engineering squad." Then how you would learn it, said as a plan, never as a past. No bridge and no slot. |

## Prohibited list

Each entry is named with its basis. Inflated-form entries are never coached as first-person negatives.

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | Dossier `prohibited_claims` | Plain acknowledgment: "I haven't held a product manager title." |
| Having owned a product roadmap | Dossier `prohibited_claims` | Plain acknowledgment: "I haven't owned a product roadmap." |
| Having set prioritization for an engineering squad | Dossier `prohibited_claims` | Plain acknowledgment: "I haven't set prioritization for an engineering squad." |
| Shipped an API or platform product | Inflated form of E1 (F2) | E1 at its own scope. Pack observation, not a negative: the material says integrations for clients, not a shipped product. |
| Set product priorities from client evidence | Inflated form of E3 (F4) | E3 at its own scope. Pack observation: the material says the sessions fed evidence to product, not that you decided what product builds. |

## Personas

Weights rest on the relationship prior for a hiring-manager round. No interviewer name was given, so there is no interviewer signal. No loop source was read, so the loop is the generic archetype, and that is said plainly: these weights are a pattern, not this company's documented process. No values-style round is detected, so there is no values section.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy | Depth |
|---|---|---|---|---|
| Skeptic | Probes the PM title, the roadmap, the gaps | High. Hiring managers are buying capability and derisking gaps, and the dossier names this objection | Rehearse A1 until it is boring. Concede precisely, then return to the quotes | 5 (A1 to A5) |
| Case / Strategist | Live problems on the squads, partners and adoption | High. Hiring-manager prior: expect problems from their actual roadmap | Clarify, then structure, and state the framework aloud | 5 (B1 to B5) |
| Data-Driven Prober | Counts behind the "30+" and the sessions | Medium. "30+" is the only figure in the material | Say how you counted, and say when you do not know | 3 (C1 to C3) |
| Pressure / Stress | Time-boxed challenges to your attribution | Medium. Composure test | Hold through two follow-ups, then concede specifically | 3 (D1 to D3) |
| Conversational / Rapport | Casual openers that are still scored | Low for a hiring manager, but casual questions on JD topics are scored | Pre-scripted 90-second arc | 2 (E1 to E2) |

## Question banks

### A. Skeptic (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've never held the PM title or owned a roadmap. Why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (E1); [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" (E3); the two negatives are from dossier `prohibited_claims`: "Having held a product manager title or role" and "Having owned a product roadmap" | Concede first, plainly: "I haven't held the title or owned a roadmap." Then the adjacent work at its own scope: you led 30+ integrations from scoping to go-live (E1), and you ran roadmap-input sessions that fed client evidence to product (E3). Name the limit: the PM years are the gap. Answer slot: if you had a say in what product prioritised after those sessions, say what it was; if not, say the sessions fed evidence to product. Ramp: name the first thing you would learn about how squad decisions get made, as a plan. Hold through two follow-ups by returning to the integrations. Concede the roadmap explicitly; never concede the integration work itself. Do not argue that you are a better hire than a PM. | The underwriter named this as the likeliest objection, so it gets the deepest rehearsal. JD tag because it scores R1. F1 and F6 are where it presses. |
| A2 | "Which parts of the partner API roadmap would you own on day one, and which would you hand to the squad leads?" | JD | [grounded] "Own the roadmap for the partner-facing API platform" (dossier role_profile responsibility) | Answer about the future, not the past: name the parts you would propose, the parts you would defer, and what you would need to confirm first. Do not claim any decision you have made. | Tests the unknown the underwriter flagged: decision authority against the two squad leads. Asking converts a risk into a diligence question. |
| A3 | "Tell me about an API or platform product you've had a hand in shipping." | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (E1) | Open prompt: choose an instance from E1, the integrations. Beats are the stages the quote states: scoping, requirements, architecture, UAT, go-live, in your own words. Answer slot: if an API release went out with your decisions on it, say which; if none did, say so and tell the integrations as they were. | Probes R2 (F2), the must-have the material meets least directly. Open prompt, because no quote names a shipped product. |
| A4 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Having owned a product roadmap" and "Having set prioritization for an engineering squad" (dossier `prohibited_claims`) | Name the acknowledged gap in those terms, then the ramp: "I haven't owned a product roadmap or set prioritization for an engineering squad. In the first month I would..." | Candour is scored. A named gap with a plan beats a bluff. |
| A5 | "How have you worked with engineering teams on delivery, and what process did you run?" | JD | [grounded] "Agile delivery experience" (dossier R5, supplied JD line) | Clarify. Answer slot: if you ran sprints, standups or backlog reviews with an engineering team, say what you ran; if you never worked that way, say so, and ask what they mean by agile delivery in this team. | R5 is preferred and the material is silent on it. The question tests whether you can ask for the definition back. |

### B. Case / Strategist (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Two squads disagree on the partner deprecation timeline, and partners are pushing back. What do you do?" | CASE | [grounded] "Write specs and drive delivery with two engineering squads" (JD responsibility) | Clarify first: who decides, what partners are asking for, what constraint each squad has. Then options and a recommendation, with one named risk. Say the decision-authority question out loud. | Hits the squad-authority unknown directly. A live problem, so it presupposes nothing about your past. |
| B2 | "Partner API adoption has stalled. How would you diagnose it?" | CASE | [grounded] "Define and track adoption metrics" (JD responsibility) | Clarify the metric and ask for the baseline. Do not invent one. Segment partners, state hypotheses, name the data you would need. | The adoption baseline is unknown. Asking for it is the move. |
| B3 | "How would you decide what partner discovery focuses on this quarter?" | CASE | [grounded] "Run discovery with integration partners" (JD responsibility) | State the framework aloud: objective, partner segments, the decision the discovery informs, how you would cut scope. | Structure is scored over the right answer. |
| B4 | "What should a partner see in the first ten minutes with a new endpoint?" | JD | [grounded] "Technical fluency: API docs, schemas" (dossier R3) | Structure from the partner's side: authentication, first call, schema, errors, versioning. No claim about your past. | R3 is important. This is its one question, and F3 is the evidence behind it. |
| B5 | "Sales wants a feature the squads haven't scheduled. What do you do?" | JD | [grounded] "Stakeholder management across engineering, sales, customers" (dossier R4) | Clarify the request and the customer behind it. State how you would weigh it against the squads' plans, and who decides. Answer slot: if you have balanced a customer request against a team's plan before, say how; if not, say so and say how you would approach it. | R4 is reached by the material only from the customer side (F4). |

### C. Data-Driven Prober (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You led 30+ integrations. How did you count them, and which assumption behind that number would you defend least?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (E1) | Defend-the-number, four slots, each in your own words: how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. Answer slot: if you counted from a list, say what the list was; if you do not know how the figure was counted, say so. | "30+" is the only figure in the material, so a prober will test it. |
| C2 | "The playbook your team uses: how do you know anyone uses it?" | EXP | [grounded] "Wrote the internal integration playbook her team uses" (dossier E2) | Answer slot: if you tracked use, say how; if you did not, say you have no measure and say what you would check. | E2 is high-confidence but has no use measure, and a prober asks about use. |
| C3 | "What did product actually change because of the roadmap-input sessions?" | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" (E3) | Answer slot: if you can point to a change, say which and what part was yours; if you cannot point to one, say so. | E3 is medium confidence. Volunteer the limit before it is extracted. |

### D. Pressure / Stress (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why should we hire you over an internal candidate?" | JD | [generic] pattern for the question, no claim about you | Pause and restate. Anchor in the integrations and the sessions, at their own scope. If an internal candidate holds the PM title, say so plainly and hold the one thing you can point to. Hold through two follow-ups. | Pressure tests composure, not content. |
| D2 | "That integration result: how much of it was actually you?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs" (E1) | Attribution: name what you led and what others did, in your words. Hold the work at the scope of "led". Concede any team-level part specifically. | Rehearses honest attribution under pressure. |
| D3 | "Did you have the authority to scope those integrations, or did the client decide?" | EXP | [grounded] "scoping, requirements, architecture, UAT, go-live" (E1) | Answer slot: say which of those stages you set, and which were the client's or the vendor's. If you set none, say so. Hold the stage list and concede specifically where others decided. | Scope authority, at the integration level. |

### E. Conversational / Rapport (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (E1); [grounded] "Wrote the internal integration playbook her team uses" (E2); [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" (E3) | 90 seconds, in this order: the integrations, the playbook, the sessions. Keep the PM limit to one sentence, offered when asked. Do not open with an apology. | Casual openers are scored. |
| E2 | "What are you actually playing with in API tooling these days?" | JD | [grounded] "Technical fluency: API docs, schemas" (dossier R3, supplied JD line) | Answer slot: name the tools you have used in integration work. If none come to mind, say so and name what you have read or built on. Do not list tools you have not used. | A casual question on a JD topic, scored as one. |

**Coverage.** R1: A1, A4 (sub-claim roadmap: A2, A4). R2: A3. R3: B4, E2. R4: B5, C3. R5: A5. Both must-haves (R1, R2) have scored questions.

## Reverse questions

Each has a reason it lands. No interviewer profile exists, so no question is tied to the interviewer's path. This is not a peer round, so no reciprocity question is required.

| # | Question | Why it lands |
|---|---|---|
| RQ1 | "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" | The decision authority is unverified. You need this answer before accepting. |
| RQ2 | "How is partner API adoption measured today, and what is the current baseline?" | The JD names adoption metrics but states no baseline. It reads as diligence and tests whether B2 is a real problem. |
| RQ3 | "When the two squads disagree on a partner commitment, how is it decided?" | Tests the squad-authority question from another angle. |
| RQ4 | "What does sales expect from this role on partner API decisions?" | R4 has no evidence from the sales side. The answer shows where you would sit. |
| RQ5 | "What would make you say in three months that this hire was the right call?" | Sets the success measure, which the adoption baseline depends on. |

## Sources

- **Provided:** `tuesday-dossier.md` (job-underwriter v1.1, generated 2026-08-14). Consumed sections: `role_profile`, `handoff_to_mock_interview`. `decision` read as context only. Your message: round type, 45 minutes, hiring manager.
- **Sections dropped by condition:** values cheat sheet (no values-style round detected), grounding brief (no L2), interviewer read (no name), graded deliverables (none declared), delivery coaching (no assessment).

**Research tier: L1, searches 3 of 6, fetches 0 of 2; user links read 0.**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quartzline values | unavailable | Refused. Would have moved whether a values-style round exists. |
| 2. Quartzline interview process | unavailable | Refused. Would have moved the loop structure. Flat weights stand in, as stated above. |
| 3. Quartzline strategy / recent news | unavailable | Refused. Would have moved the CO bank, which has no questions in this pack. |
| 4. Interviewer name + Quartzline | n/a | No name was given, so there was no query to form. |
| 5. Representative JD | skipped | The dossier's `role_profile` supplies the JD lines, which fix the fit snapshot and the JD questions. |

Queries sent, all refused by the host (search permission not granted in this session; not retried):
- "Quartzline company values": refused
- "Quartzline interview process product manager platform APIs": refused
- "Quartzline strategy news 2026": refused

No company fact in this pack comes from research. Nothing about Quartzline's values, loop or strategy is established.

## Upgrade menu

- The interviewer's name → persona weights from public footprint and a tailored reverse question (needs search permission).
- Search permission for this session → targets 1 to 3: whether a values round exists, the real loop, and CO questions.
- The current posting text → confirms the dossier's `role_profile` still matches the role (the dossier is about three months old).
- The recruiter's note on what this round covers → reweights the banks.
- A deeper research pass (L2): up to 6 more searches and 2 more fetches, several more minutes. Adds the strategy brief, interviewer footprint and loop reports. Needs search permission first.
- A CV line naming an API release you decided on → upgrades F2 from low. Add it only if it is true.
