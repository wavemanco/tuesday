Your prep pack is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-tuesday-part-2-rooms-case-4-denied-989c1448/335fe934-972b-4c76-b936-4b552cc9add0/scratchpad/Quartzline_product-manager-platform-apis_interview_pack.md`.

**The answer that matters most** is to the objection your dossier named: "You have never held the PM title or owned a roadmap — why should we hire you into one…" (A1). Open with the plain acknowledgment: "I haven't held the PM title, and I haven't owned a roadmap." Then bridge only from what you've actually done, with its limit stated: the 30+ client integrations and the integration playbook. Close with a ramp plan, labeled as a plan. If they press on the roadmap, concede it plainly rather than arguing. Don't describe roadmap or prioritization work you didn't do.

**Tomorrow, in priority order:**
1. Say A1 out loud, standing, three times.
2. For the 30+ integrations figure, know which stages were yours (C2, D1). The dossier's evidence supports "led," not "owned the product."
3. Memorize the reverse questions RQ1 (which roadmap decisions this PM makes alone) and RQ2 (how adoption is measured today, and the baseline). Those test the two things the dossier couldn't verify.

**Things to know:**
- **Research didn't run.** Web search was refused by the session's permission setting, so I couldn't check Quartzline's values, loop structure, or recent news. The pack has no values section for that reason. If you grant search permission, I can re-run that part.
- **The dossier is about three months old** (August 14). If the role was reposted or its scope changed, check with the recruiter before Thursday.
- **Persona weights are a prior, not a read.** There's no interviewer name, so the weights reflect a typical hiring-manager round. Sharing the interviewer's name would sharpen them.

Want a drill? I can play the Skeptic on A1 and push back on your answer for a few rounds. Also, I can save a `tuesday-dossier.md` recording this prep's gaps (the roadmap objection, the unverified adoption baseline, the shipped-product question) so they carry into later sessions.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Quartzline_product-manager-platform-apis_interview_pack.md -----
# Interview pack: Product Manager, Platform APIs at Quartzline

**Round:** hiring-manager conversation, 45 minutes, Thursday. Interviewer not named. Relationship: hiring manager (as you stated).
**Built from:** your `tuesday-dossier.md` (decision: conditional_go; generated 2026-08-14). The dossier is about three months old. If the role was reposted or its scope changed since August, ask the recruiter before Thursday.
**Research:** not run. Permission for web search was refused in this session, so every target is listed as unavailable in Sources.

## How to use this pack

- **Personas** describe how a question will be asked. **Types** describe what is being scored: EXP (your past work, tested), JD (the listed job), CO (company knowledge), CASE (a live problem), VAL (values).
- Guidance is scaffolding for a spoken answer, not a script. Say only what your quoted sentences say.
- **Answer slots** are instructions for the interview: they tell you what to say if the interviewer probes a point your material does not show. They are not questions to me.

## Prep triage (about one day)

1. Say the answer to **A1** out loud, standing, three times. It is the highest-return rehearsal in this pack. Learn the plain acknowledgment sentence word for word.
2. Rehearse **C2** and **D1**: for each integration figure, be ready to say which part was yours.
3. Memorize the two reverse questions **RQ1** and **RQ2**. They test the two things the dossier left unverified.
4. Everything else is insurance.

## The fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| S1 | "3+ years product management experience" (dossier role_profile R1) | "Led 30+ end-to-end client integrations of the vendor's REST APIs, scoping, requirements, architecture, UAT, go-live" (dossier verified_candidate_evidence) | high | [grounded] | transferability | The quote is integration leadership, not PM years. Say the quote at its own scope, then the limit: "I haven't held a product manager title." Wider claims are answer slots inside the quote's scope only. |
| S2 | "Shipped API or platform products" (dossier role_profile R2) | "Wrote the internal integration playbook her team uses" (dossier verified_candidate_evidence) | high | [grounded] | discovery | Your material shows client integrations and a playbook. It does not show a shipped product. Answer slot, see A5. |
| S3 | "Technical fluency: API docs, schemas" (dossier role_profile R3) | "Wrote the internal integration playbook her team uses" (dossier verified_candidate_evidence) | high | [grounded] | presentation | The playbook is the inspectable proof. Lead with it, in its own terms: you wrote it. Do not describe schema work it does not mention (see E2). |
| S4 | "Stakeholder management across engineering, sales, customers" (dossier role_profile R4) | "Ran quarterly roadmap-input sessions feeding client evidence to product" (dossier verified_candidate_evidence) | medium | [grounded] | discovery | Confirmed, limited inspectable proof: expect a probe. Your material shows clients and product. It does not show engineering or sales. Say so in the interview before it is found. Answer slot, see C3. |
| S5 | "Own the roadmap for the partner-facing API platform" (dossier role_profile responsibility) and "Owning a roadmap and prioritization authority" (dossier uncertain_or_weak_areas, acknowledge_gap) | none given | none | [grounded] | capability | The dossier records this as a gap, with confidence none. Words: "I haven't owned a product roadmap, and I haven't set priorities for an engineering squad." Then a ramp plan, labeled as a plan, never as past. No bridge. |
| S6 | "Agile delivery experience" (dossier role_profile R5, preferred) | none given | low | [inferred] | discovery | The material is silent on Agile inside a product org. Answer slot, see A2. |

**Confidence and provenance on each row:** confidence grades the evidence; provenance grades this pack's statement. S4's caveat is in the bridge, not the confidence cell.

## Prohibited claims

Not to be coached, in any form: no guidance, answer, bridge or drill feedback in this pack asserts, softens or implies these.

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | Dossier prohibited_claims | Plain acknowledgment: "I haven't held a product manager title." No slot. |
| Owning a product roadmap | Dossier prohibited_claims and uncertain_or_weak_areas (acknowledge_gap) | Plain acknowledgment from S5. No slot, no bridge. |
| Setting prioritization for an engineering squad | Dossier prohibited_claims and uncertain_or_weak_areas (acknowledge_gap) | Plain acknowledgment from S5. No slot. |
| "Ran roadmap sessions" widened to "set the roadmap" | Inflated form of S4's quote | The quote at its own scope: input sessions feeding product. The limit is this pack's observation, not words for you: the material says input, not the roadmap. |
| "Led integrations" widened to "owned the product" | Inflated form of S1's quote | The quote at its own scope. Say what you led, not what the product became. |

## Persona weights

Hiring manager prior, per `personas.md`: Case/Strategist and Skeptic dominate. No interviewer profile exists, so there is no interviewer-signal adjustment. No values-style round is detected: no loop source establishes one, and the fallback archetype is Generic, which reads `no`. So there is no Values bank.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy | Depth |
|---|---|---|---|---|
| Skeptic | Probes the PM-title and roadmap gap, and why you over a PM with the years | Top. The hiring manager's prior is buying capability and derisking the gap | Rehearse the objection until it is dull. Bridge only from quoted evidence, state the limit, then a plan | 5 |
| Case/Strategist | A live problem from the role: diagnose adoption, define a metric, handle a breaking change | Mid. The prior expects live problems on their actual roadmap | Clarify, then structure, then metrics, then risks. Think aloud | 4 |
| Pressure | Time-boxed challenges to your 3+ years and your count | Mid-low. A stress style is possible, not expected | Pause, restate, hold a position through two follow-ups, then concede the gap plainly | 3 |
| Data-Driven Prober | Asks for the denominator and the attribution of your integration count | Mid-low. Your figure is the magnet for it | Say how it was counted if you know, and the assumption you would defend least. Say plainly when you do not know | 3 |
| Conversational | Casual openers that are still scored | Low. The danger is treating it as unscored | Pre-scripted 90-second arc. Treat casual questions on the JD's topics as scored | 2 |
| Peer | Seams with engineering and credit-sharing | Low. A hiring manager sometimes plays the peer | Reciprocity. Propose seam principles, do not claim a seam you have not worked | 2 |

## Question banks

Total: 19 questions, inside the roughly 18 to 26 range. Persona depth follows the table above.

### Skeptic (A): depth 5

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs, scoping, requirements, architecture, UAT, go-live" (S1). The negatives: dossier prohibited_claims and uncertain_or_weak_areas (acknowledge_gap), named by field | Start with the acknowledgment, in your words: "I haven't held the PM title, and I haven't owned a roadmap." Then the bridge with its limit: "What I have done is the integration side: [quote]." Then a plan, labeled as one: what you would learn in your first 90 days before proposing any roadmap change (`[generic]`). Hold through two follow-ups by returning to the quoted integrations. Concede plainly on the roadmap: "That is a real gap for day one." | The underwriter named this as the highest-ROI rehearsal. It arrives in some form. Rows S1 and S5 |
| A2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Own the roadmap for the partner-facing API platform" (dossier role_profile responsibility) | Name the roadmap first, plainly. Then, for Agile: answer slot. If you ran Agile delivery with engineers, say which team and what cadence. If you did not work that way, say so, and say what you would want to confirm about how they define it | Stem from the personas file. Covers S5 and S6 |
| A3 | "Who would make the call if your roadmap and a squad lead's priorities disagreed?" | JD | [inferred] "Own the roadmap for the partner-facing API platform" and the dossier's unresolved decision-authority risk | Ask the question back: "Which decisions does this role make alone?" (RQ1). Answer slot: if you have had to get a decision made across a disagreement, say when and what your part was; if not, say so | Decision authority is asserted in the JD and not evidenced. This is the squad-authority question the dossier says must verify in interviews |
| A4 | "I don't see a roadmap in your background — how would you handle the roadmap in this role?" | JD | [grounded] the dossier's uncertain_or_weak_areas, acknowledge_gap, named by field | Plain acknowledgment: "I haven't owned a roadmap." Then the ramp plan (`[generic]`): how you would learn the roadmap process, sit in the cycles, and earn the call. Do not describe roadmap work you did not do | The stem is the Skeptic's own, with its negative sourced by the dossier's acknowledge_gap field |
| A5 | "Tell me about a platform or API you shipped that partners used." | JD | [grounded] "Wrote the internal integration playbook her team uses" (S2). No shipped product is quoted | Answer slot: if you shipped something partners used, name it and say what you did. If your work was integrations for clients on the vendor's APIs, say so, and stay with what the playbook and the integrations cover | Covers the must-have R2 (shipped API or platform products). The material is silent on shipping, so this is discovery, not a claim |

### Case/Strategist (B): depth 4

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A partner's endpoint has been live for a quarter, and its adoption is flat. How do you diagnose it?" | CASE | [generic] | Clarify what "adoption" means here, then segment partners, then the approach, then the metrics, then the risks. Think aloud. Make no claim about having diagnosed anything | A live problem from the adoption-metrics responsibility. Pure role-family pattern |
| B2 | "How would you define adoption for a partner-facing API platform?" | CASE | [inferred] "Define and track adoption metrics" (dossier role_profile responsibility) | Name the definition you would test and the baseline you would need first. Ask for the current baseline (RQ2) | The JD names adoption metrics without a baseline. The baseline is the open fact |
| B3 | "A partner needs a breaking change to a schema. How do you decide?" | CASE | [generic] | Clarify who is affected and what the contract promises. Identify the decision owner. Say what you would check before deciding | Live problem from partner discovery and schema work. Makes no claim about your past |
| B4 | "What would you do in your first 90 days before proposing a roadmap change?" | CASE | [generic] | Learn the squads' priorities, the partner backlog, and how decisions are made today. Propose nothing before the first cycle. Label the answer as a plan | The roadmap sub-claim is an acknowledged gap. The answer is a plan, not a past |

### Pressure (C): depth 3

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Sixty seconds: why you over a PM with three years?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs, scoping, requirements, architecture, UAT, go-live" (S1). Acknowledgment from S5 | Sixty seconds: the quote, the plain acknowledgment, and one line of the ramp plan. Hold: do not argue the years | R1 in its harshest form |
| C2 | "That integration count — how much of it was actually you?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs, scoping, requirements, architecture, UAT, go-live" (S1) | Answer slot: say which of those stages were yours to decide and how you decided, in your own words. If a stage was someone else's, say so. Then say what you can defend about the count | The 30+ figure is a number a prober will test. Answer slots for the count, the stages, and the part that was yours |
| C3 | "Tell me about a time you drove delivery across a team you didn't direct." | EXP | [inferred] "Write specs and drive delivery with two engineering squads" (dossier role_profile responsibility) | Open prompt. Selection scaffold: pick a time you moved work across engineers you did not manage. If none comes to mind, say so plainly, then give the nearest thing your material carries: the integrations with engineering on the client side, or how you would handle it | Covers S4's engineering gap. The quote sits in the interview's raising source, not in your sentences |

### Data-Driven Prober (D): depth 3

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Of those integrations, how many did you count as done, and by what test?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs, scoping, requirements, architecture, UAT, go-live" (S1) | Answer slot: say how you counted "done" if you know, and the assumption you would defend least. If you did not track it that way, say so plainly | The same figure as C2, probed from the denominator side |
| D2 | "Which part of the integration playbook is the weakest assumption you know of?" | EXP | [grounded] "Wrote the internal integration playbook her team uses" (S2) | Answer slot: name the weakest assumption you know of. If you did not track assumptions, say so, and say what you would check first | Assumption-naming is the Prober's signature. The playbook is inspectable, so expect a request to see it |
| D3 | "Tell me about a metric you've reported on, and how it was counted." | EXP | [inferred] "Define and track adoption metrics" (dossier role_profile responsibility) | Open prompt. Selection scaffold: pick a metric you reported. If you have none, say so, and say what you would measure first | Covers R2 and the adoption responsibility. The material shows no adoption metric, so the honest branch is ready |

### Conversational (E): depth 2

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs, scoping, requirements, architecture, UAT, go-live" and "Wrote the internal integration playbook her team uses" (S1, S2) | A 90-second arc: the integrations, the playbook, the roadmap-input sessions, and what you want to own next, labeled as a plan | Casual openers are scored. The arc must not present a PM career |
| E2 | "What are you playing with in API docs and schemas these days?" | JD | [grounded] "Wrote the internal integration playbook her team uses" (S2). Schema work is not quoted | Answer slot: if you worked with schemas, name one. If your docs work is the playbook, say so and stop there | JD R3 asked casually. Do not claim schema work the material does not show |

### Peer (F): depth 2

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Our teams sit side by side. Where's the seam with engineering, and what happens when you disagree?" | JD | [inferred] "Write specs and drive delivery with two engineering squads" (dossier role_profile responsibility) | Propose seam principles: who decides what, how disagreement is escalated, how you would raise it early. Claim no seam you have not worked | Covers S4's engineering gap in peer form |
| F2 | "How do you handle credit when work spans teams?" | CO | [generic] | Say what you did and what the client or team did, in that split. Do not take credit for the whole | Credit-sharing is a standard peer probe. No claim about your past |

### Requirement coverage

| Requirement | Questions |
|---|---|
| R1: 3+ years product management | A1, A4, C1 |
| R2: shipped API or platform products | A5, D3 |
| R3: technical fluency, API docs, schemas | B2, E2 |
| R4: stakeholder management | C3, F1, F2 |
| R5: Agile delivery (preferred) | A2 |
| Own the roadmap (responsibility) | A1, A3, A4, B4 |
| Define and track adoption metrics (responsibility) | B1, B2, D3 |
| Run discovery with partners (responsibility) | B3 |

## Reverse questions

Each carries a "why it lands." Use at least two.

| # | Question | Provenance | Why it lands |
|---|---|---|---|
| RQ1 | "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" | [grounded] dossier questions_for_employer | It tests the decision-authority risk the dossier left unverified. It reads as diligence |
| RQ2 | "How is partner API adoption measured today, and what is the current baseline?" | [grounded] dossier questions_for_employer | No baseline is stated in the JD. You need it before you can say what success is |
| RQ3 | "Which of the two squads carries the most partner-facing risk right now?" | [inferred] "Write specs and drive delivery with two engineering squads" (dossier role_profile responsibility) | It turns the two-squad line into a diligence question. The answer shows how the work is split |
| RQ4 | "What did the last person in this seat get right in the first 90 days?" | [generic] | Shows you are planning the role, not just wanting it |
| RQ5 | "What would make the first six months clearly successful from your side?" | [generic] | Gives you the success criteria to hold yourself to in the next conversation |

## Sources

- **Provided documents:** `tuesday-dossier.md` (conditional_go, dossier_version 1.1, generated 2026-08-14). Sections consumed: `role_profile`, `handoff_to_mock_interview`, `decision`. Requirement text comes from the dossier's role_profile. No full JD text was supplied, so the pack quotes the dossier's requirement lines, not the posting.
- **Research tier: L1, searches 3 of 6, fetches 0 of 2; user links read 0.** All three search calls were refused by the host's permission setting. None was retried.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quartzline values` | unavailable | Would have moved the values cheat sheet. No values round is detected, so the cheat sheet would not render regardless |
| 2. `Quartzline interview process product manager` | unavailable | Would have confirmed or named the loop. Persona weights rest on the hiring-manager prior, not on a documented loop |
| 3. `Quartzline platform APIs news strategy` | unavailable | Would have moved the CO questions and a grounding brief. None are in this pack; F2 is the only CO-tagged question, and it is generic |
| 4. `{interviewer name} Quartzline` | n/a | No interviewer name was given, so there is no query |
| 5. Representative JD for the title | skipped | The dossier's role_profile supplies the requirement lines, so the fit snapshot does not need a representative JD |

- **Queries listed, all refused:** `Quartzline values`; `Quartzline interview process product manager`; `Quartzline platform APIs news strategy`.

## Upgrade menu

- Research permission for web search, then a re-run → Quartzline's published values (a values cheat sheet, if a values round is detected) and current-strategy CO questions. The interview process would confirm or replace the hiring-manager prior.
- The interviewer's name → persona weights from their public footprint, and a reverse question tied to their own path.
- The posting's full text → the requirement quotes come from the JD itself, not the dossier's summary lines, and the JD-tagged questions tighten.
- A recruiter note on the round's format → confirms whether a values or case round sits elsewhere in the loop.
- A deeper research pass (up to 6 more searches and 2 more fetches, several minutes): one offer, want it? Say so and it runs.
- Your own CV line-by-line → the S-rows could move from `[grounded]` on the dossier's quotes to your own sentences.
