Your prep pack is saved as `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-tuesday-part-2-rooms-case-7-denied-87329b93/d2d71923-5d37-4b59-90e1-ffb5e58ba589/scratchpad/saltmarsh-games_live-operations-producer_interview_pack.md`. I built it for a hiring-manager round, since your note didn't say how Tobias fits in.

**Nothing about Saltmarsh or Tobias is in it.** Web search was refused on this host, so I couldn't check Saltmarsh's values, its interview format, its current strategy, or Tobias's background. Don't walk in assuming any of that. If you grant search permission, I can run those checks and add them.

What the pack says to focus on:

- **Highest-ROI prep:** "You haven't led a team. How do you make coordinating four teams work?" The JD asks you to coordinate design, art, engineering and community on every update, and you've never led a team. Hold to "I haven't led a team," then give a plan for the first update cycles. Don't add a team or a cross-team project to make it land.
- **Your strongest evidence:** the weekly content-drop calendar, the release checklist QA still uses, and the retention numbers you presented. Expect probes on how much of each was yours. Answer in terms of what you actually decided.
- **Overreach to avoid:** saying you ran live events for two titles, owned the KPIs, managed the checklist release by release, or worked on live-service games. Your notes support none of those as stated.
- **In-app purchases:** the JD doesn't mention them, so the pack doesn't rehearse a question on them. Have "I haven't worked on a game with in-app purchases" ready in case it comes up.
- **Reverse questions:** five are ready, including what the post-event review reports and where the release checklist sits between QA and producers.

It has 20 questions across six styles, weighted toward case problems and skeptical probes. If you'd like to rehearse, I can play the skeptic on the leadership question and push back on your answer. I can also save a `tuesday-dossier.md` with the gaps this prep exposed, or convert the pack to a Word document.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview prep pack: Live Operations Producer, Saltmarsh Games

Interviewer: Tobias Wrenfield, Head of Live Operations. Round: one 60-minute session on Friday, assumed to be a hiring-manager round (your note did not say, and nothing confirms it). First version.

**Research status:** none of it ran. Web search was refused on this host, so nothing about Saltmarsh's values, interview loop, current strategy or Tobias's public background is in this pack. Everything below rests on the job description and your background notes.

## How to use this pack

- Personas describe how a question is asked. Types describe what is being scored.
- Type key: **EXP** = whether a claim about your past survives scrutiny. **JD** = a stated responsibility, including its gaps. **CASE** = a live problem from the role, with no claim about your past. VAL and CO are not used: no values-style round was detected and no company research ran.
- Guidance is scaffolding, not a script. Speak in your own words. An answer slot is an instruction for your answer in the room, not a question to me.

## 4. Fit snapshot

Requirements are the job description's own lines. Evidence is quoted from your message, with its source named.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material shows one title and weekly content drops, not two titles and live events. Bridge: "For two years I ran the weekly content-drop calendar for our main title." Answer slot: the two-title and live-events lines make a probe on the second title, and on events beyond drops, likely. If you planned either, say what and how; if you did not, say so and stay with the one calendar you ran. |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | none given | none | [grounded] | discovery | Nothing in the material shows coordinating these four teams on an update. Answer slot: if you coordinated any of them on a release, say which, how, and which decisions were yours; if you did not, say so, and say how you would set up the first update cycle with them. |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | transferability | Your material shows presenting numbers, not owning a review or the KPIs behind it. Bridge: "I presented the monthly retention numbers to the studio head." Answer slot: if you defined the KPIs or ran post-event reviews, say which and how; if you did not, say so and say what you would put in the first review. |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | presentation | Bridge: "I wrote the release checklist our QA team still uses." That is the quote's own scope. Your material does not show how you ran the checklist release by release, so do not describe that. |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message | medium | [grounded] | transferability | Bridge: "For four years I was an associate producer at a puzzle-game studio." Limit, as this pack's observation: your material does not say the studio's game was live-service, so do not say it was. Answer slot: say in your own words what the game ran on and whether it was live; if you cannot say it was live-service, say so. |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | The quote reaches the requirement. Expect a probe on it, because a calendar is the kind of claim a prober checks. |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | none | The quote reaches the requirement in role terms. Expect a probe on how the numbers were counted. |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | none | The checklist is a written artifact other people use. Name it as that, not as proof of communication in general. |

Length of experience (F5) is not a gate: it is graded like any other requirement. No requirement in the JD is a gate, so no row is marked hard_gate.

**Stated gaps the JD does not list.** These are your own negatives. They are not JD requirements, so no question below is raised by the JD on these topics. They are here because they are the likeliest objections.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| G1 | Not in the JD: your own note | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [grounded] | capability | Words you stated: "I haven't led a team." Then how you would learn to lead, said as a plan and never as a past. Add nothing to make the gap smaller. |
| G2 | Not in the JD: your own note | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [grounded] | capability | Words you stated: "I haven't worked on a game with in-app purchases." Then how you would learn that side, as a plan. |

## 8. Persona table

Weights come from the relationship prior for a hiring manager (Case/Strategist and Skeptic dominant). No loop source established this round's structure, so the fallback is the Generic archetype, flat weights, said plainly: relationship priors drive the weights. The JD's KPI and retention lines raise the Prober. Pressure is mid because a 60-minute session with a head of function is a composure test. Peer is low because no peer is named in this round, but the coordination lines still bring it in. No values-style round was detected, so there are no VAL questions.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist (weight 5) | A live problem on the calendar and the coordination | High. A hiring manager buys capability and tests it on their own roadmap | Clarify, then objective, segmentation, approach, metrics, risks. Think aloud |
| Skeptic (weight 4) | Quiet probing of the team-leadership gap and the monetisation gap | High. Your two stated negatives are the likeliest objections | Rehearse the single most predictable objection until it is plain. Use only your stated negatives, and a plan for the rest |
| Data-Driven Prober (weight 4) | Questions about how the retention numbers were counted, and what you actually owned | Medium-high. The JD names KPIs and retention, and your evidence is a presented figure, not an owned one | Say what you can and cannot say about how each number was counted. Name the weakest assumption before they do |
| Pressure (weight 3) | Time-boxed challenges to "why you" and "how much was you" | Medium. Composure is tested in any 60-minute round | Pause, restate, anchor in what you said. Hold through two follow-ups, then concede the specific gap |
| Conversational (weight 2) | A friendly opener and a casual question about written communication | Low to medium. Casual questions are scored | Use a 90-second arc built from your own sentences |
| Peer Evaluator (weight 2) | Seam questions about design and QA | Low here. Covered by the coordination questions | Propose seam principles, not a seam you have not worked |

## 9. Question banks

**Question count:** 20 across six personas, within the 18 to 26 range. Each row carries its own provenance. Answer slots are instructions for the answer, not questions to me.

### A. Case/Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Here is the calendar: two titles, each with an update every two weeks. Title one's retention dipped after its last event. What is your first hour on that?" | CASE | [generic] | Clarify before structuring: what the dip is measured against, what changed in the last event, which players dropped. Then objective, segmentation, approach, the one metric you would check first, and the risk of acting too fast. Say the structure aloud. Do not claim you have run this on a real title. | The JD's calendar line in case form. [generic] because it is a pattern for the problem, not a fact about this studio. |
| A2 | "Plan the next event for title two. What do you need to know before you put a date on the calendar?" | CASE | [generic] | Clarify what the event is for, what it must not break, who signs off, what design, art, engineering and community each need, and the lead time QA needs. Then propose a sequence and name the decision you would escalate. | Raised by the JD's calendar and coordination lines. Tests the sequencing the role needs, without a claim about your past. |
| A3 | "Event day three is flat against plan on retention. Diagnose it." | CASE | [generic] | Structure it: is it the event, the cohort, or a release problem? Which data splits you would pull, which hypothesis you test first, and what you would tell the studio on day four. Think aloud. | Raised by the JD's line on owning the post-event review and its KPIs. A diagnosis is that review's work. |
| A4 | "Walk me through how you would sequence design, art, engineering and community on one update, from first brief to post-release check." | JD | [generic] | Structure it as stages with a named owner for each handoff. Name where community feedback re-enters the plan, and the release checklist as the gate before ship. Describe the sequence you would set, not a team you ran. | Raised by the JD's coordination line. [generic] because the sequence is the role's pattern, not a claim about this studio. |
| A5 | "Build me next quarter's calendar for both titles. What goes in, and what stays out?" | JD | [generic] | Prioritise by goal, not by what is ready. State the goal for each title, the capacity limit, what you would cut first, and the trade you would have to explain to the studio. Name the assumption each slot rests on. | Raised by the JD's two-title calendar line. Covers the two-title half of F1 without claiming you did it. |

### B. Skeptic (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this job would you be weakest at on day one?" | JD | [generic] | If it is your honest read, name the coordination side first, then give the ramp for the first two update cycles. Calibrated candour, not a bluff. Do not name anything you have not stated. | Persona stem. The answer is a plan, not a past. |
| B2 | "This role coordinates design, art, engineering and community on every update. You haven't led a team. How do you make that work?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." — your message | **Deepest rehearsal.** Hold: "I haven't led a team." Do not add a team, headcount or a cross-team project to make it land. Hold through two follow-ups by describing only the release checklist you wrote, as a written artifact, and the plan for the first cycles. Concede explicitly: "I haven't led a team, and that is the part I would need to earn." Answer slot: if you coordinated any of these teams on a release, say which and how; if you did not, say so and give the plan. | Named by this pack as the highest-ROI prep: the biggest gap in the snapshot (F2, with G1) is the one most likely to be asked in some form. The question presupposes "haven't led a team", which you stated. It presupposes no coordination you did. |
| B3 | "What would you get wrong in your first ninety days?" | JD | [generic] | Name one specific error this calendar makes likely, and how you would catch it early. Keep it to a plan. Do not confess a flaw you have not stated. | Persona stem. Tests calibrated candour. |
| B4 | "Why would a studio with live titles want someone whose work was on a puzzle game?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio." — your message | Hold: the four years and the calendar you ran are the true part of your background. The difference is the monetisation side, which you have not worked on: say so. Then say what the cadence transfers. Do not claim live-service experience. | Motivation probe. Presupposes only the puzzle-studio sentence. |

### C. Data-Driven Prober (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through where the monthly retention numbers you presented came from, and which part of that was yours." | EXP | [grounded] "Presented the monthly retention numbers to the studio head." — your message | Story-mapped on F7: the presenting, the audience, the monthly cadence. Answer slot: if you built or chose the cuts, say which and how; if you presented numbers someone else produced, say so and say what you checked. If you do not know how a figure was counted, say so plainly. Weakest assumption: name the one you would defend least, if you know it. | Tests what was actually yours. The question names only the presenting that the quote states. |
| C2 | "Tell me about a content drop you'd judge a success, or a miss. How did you know?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." — your message | Open prompt on a drop you ran: pick one, name it, say what you saw and what you did next. Answer slot: if you did not measure the drop, say so and say what you looked at afterwards; if you did measure it, say which number and how it was counted. | Raised by the JD's post-event review line. The calendar sentence is the only evidence, so the answer stays inside it. |
| C3 | "Which of the monthly retention numbers you presented would you defend least?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." — your message | Weakest-assumption move: name the assumption behind the figure you would defend least, in your own words, before they do. If you cannot name one, say you do not know how that figure was counted. Do not invent a figure to discuss. | Defend-the-number: no figure is on your CV, so the slot is about method, in your words. |
| C4 | "The role owns the KPIs a post-event review reports. Which three would you put on the first review, and why those?" | JD | [generic] | Choose KPIs that map to a goal, have a definition someone can check, and have a data source. Name what each is sensitive to. Do not name KPIs you have owned. | Raised by the JD's KPI line. A definitional probe; no claim about your past. |

### D. Pressure (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over someone who has run live operations on a shipped mobile title?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio." — your message | Hold the position through two follow-ups. Restate the question first. Say what the four years carry: the calendar you ran and the checklist QA still uses. Concede specifically: leading a team, and working on a game with in-app purchases. Do not fold on the core claim to restore harmony. | Composure. The concession wording rests on your own negatives. |
| D2 | "That content-drop calendar: how much of it was actually you?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." — your message | Answer slot: say which planning decisions were yours (what went on the calendar, and in what order) and which were set by others, in your own words. If you ran the calendar but did not decide it, say that. Until you have said which decisions were yours, claim no more than "ran". | Attribution probe. The slot separates running from deciding, using the JD's "plan and run". |
| D3 | "Tell me about a release where the checklist was challenged. What did you do?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." — your message | Open prompt: pick a release where someone challenged a checklist item. Name the item, who challenged it, what you decided and what happened. Answer slot: if no challenge comes to mind, say so plainly, then describe how you would handle one. | Raised by the JD's line on managing the release checklist with QA. Open prompt with an honest branch. |

### E. Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So — walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." — your message | A 90-second arc built from your own sentences, in this order: the puzzle studio, the calendar you ran, the checklist, the retention numbers you presented, what you want next. Add no titles or results. | Rapport openers are scored. The arc is scripted from quotes so it cannot drift. |
| E2 | "When you write up a release, what does the reader need to see first?" | JD | [grounded] "Wrote the release checklist our QA team still uses." — your message | Answer slot: if you wrote the checklist with a reader in mind, say how you ordered it. If you did not think about it that way, say how you would order a release note for QA. | Raised by the JD's "clear written communication". |

### F. Peer Evaluator (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Our designers and your QA team sit side by side. Where's the seam, and what happens when you disagree with design?" | JD | [generic] | Offer seam principles, not a seam you have not worked: who decides what ships, what gets escalated, how a disagreement gets recorded. Then show what your team gets from you, not only what you need. | Raised by the JD's coordination line, which names design and QA's neighbourhood. |
| F2 | "How do you handle credit when a content drop works across design, art and engineering?" | JD | [generic] | Name the people and their parts. Credit the drop's owner for the calendar and the others for their work. Do not claim the win. | Persona stem, low weight. Raised by the JD's cross-team line. |

## 10. Reverse questions

Five questions to ask Tobias. There is no interviewer profile and no peer reciprocity case, so none is tied to a career path.

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does the post-event review look like here today, and which KPIs does it report every time?" | Tests the JD's ownership line and shows you will own the metric, not only present it. |
| R2 | "Which of the two titles uses in-app purchases, and how does that change what a content drop has to do?" | Asks about the monetisation gap instead of claiming it. Shows you know it changes live operations. |
| R3 | "Where does the release checklist sit between QA and producers, and who signs off a release?" | Tests the manage-with-QA line and finds the decision rights you would need. |
| R4 | "What would a strong first ninety days look like in this role, and which update cycle would you judge it by?" | Turns B1 into a plan Tobias can grade. |
| R5 | "What is the calendar's biggest bottleneck right now?" | Shows you are planning, not only interviewing, and surfaces the real risk. |

## Requirement coverage

| JD requirement | Covered by |
|---|---|
| Plan and run the live-events calendar for two of our mobile titles | A1, A2, A5 |
| Coordinate design, art, engineering and community teams on each update | A4, B2, F1, F2 |
| Own the post-event review and the KPIs it reports | A3, C2, C4 |
| Manage the release checklist with QA | D3 |
| 3+ years producing live-service games or apps | B4, D1, E1 |
| Experience running a content calendar | C2, D2 |
| Comfortable with player-retention metrics | C1, C3 |
| Clear written communication | E2 |

## 13. Prohibited claims

Each entry has its basis and its honest form. These are not to be coached in any answer.

| Not coached | Basis | Honest form |
|---|---|---|
| "Led a team" | Negative you stated: "Never led a team" | "I haven't led a team." No slot about leading |
| "Worked on a game with in-app purchases" | Negative you stated | "I haven't worked on a game with in-app purchases." |
| "Ran live events for two titles" | Inflated form of F1 | F1's quote at its own scope: the calendar for one title, weekly drops. The observation that the material says one title is this pack's, not words for you |
| "Managed the release checklist with QA" | Inflated form of F4 | "I wrote the release checklist our QA team still uses." Your material says wrote, not managed release by release |
| "Owned the post-event review and the KPIs" | Inflated form of F3 | "I presented the monthly retention numbers to the studio head." C4 asks about KPIs in general, and does not claim you owned any |
| "Worked on live-service games" | Inflated form of F5 | The puzzle-game sentence at its own scope. Your material does not say the game was live-service |

Nothing is listed for the team-coordination requirement. Your material is silent on it, so it gets an answer slot (F2), not a prohibited entry.

## 14. Sources

- **Provided:** your message, with the job description text and your background notes.
- **Searches sent (4), all refused** because web search was not permitted on this host. No retries were made.
  1. "Saltmarsh Games values": refused.
  2. "Saltmarsh Games interview process live operations producer": refused.
  3. "Tobias Wrenfield Saltmarsh Games Head of Live Operations": refused.
  4. "Saltmarsh Games mobile studio news strategy": refused.
- **Fetches:** none sent.
- **Dossier:** none present.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | unavailable | Values cheat sheet (section 10) not built: no published values in hand. Would have named the values by their official names |
| 2. `Saltmarsh Games interview process` | unavailable | Loop not established, so persona weights rest on round-type priors and the Generic archetype, as said above. No values round detected |
| 3. `Saltmarsh Games` strategy / recent news | unavailable | Grounding brief and CO bank not built. No CO questions appear in this pack |
| 4. `Tobias Wrenfield` public footprint | unavailable | Interviewer read absent. Reverse questions are role-generic |
| 5. Representative JD | skipped | The JD you pasted fixes the fit snapshot and the JD questions |

## Upgrade menu

- **Web search permission** → the four unavailable targets: Saltmarsh's values, its interview loop, its current strategy, and Tobias's public footprint. Each would add a section or reweight personas.
- **The two titles' genre, and whether either uses in-app purchases** → upgrades F1 and F5, and sharpens B4 and R2.
- **Your actual retention figures and how they were counted, in your own words** → C1 and C3 gain defend-the-number slots tied to real figures.
- **A redacted copy of the release checklist** → F4 and F8 could move toward high confidence, and you would have something concrete to show.
- **The recruiter's note on whether the round includes a presentation or take-home** → adds a graded-deliverable section.
