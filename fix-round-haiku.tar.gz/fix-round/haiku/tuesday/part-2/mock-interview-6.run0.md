Your prep pack is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-tuesday-part-2-rooms-case-6-denied-6952274a/5fb81aa7-1221-4b53-90a5-bfad53159781/scratchpad/Larkfield_Systems_engineering-manager_interview_pack.md`. It covers all three rounds, with a shared fit snapshot, persona weights for each round, and 25 questions in total.

Web search was refused in this session, so the pack has nothing about Larkfield's values, interview structure or strategy. Those points are labeled generic or left out, and the upgrade menu says what each would add.

The most important prep is question A2, the hardware roadmap. Your material says you've never owned a hardware-adjacent roadmap, and the role asks you to partner with hardware on it. Answer with that fact stated plainly, then a concrete 90-day plan. Don't stretch the reliability quarter into roadmap ownership. The second priority is A3 and A6: "one team of six" against "two squads," and the 60% figure, which needs a clear account of how it was counted and what was yours.

The VP round is the recruiter's "values and leadership philosophy." Without published values, the pack uses selection scaffolds with an honest fallback rather than mapped stories. Your reliability quarter is the one story with a clear decision in it (C1).

If you want, I can play the Director on A2 for a drill. I can also save a `tuesday-dossier.md` that records the gaps this prep exposed, for carrying into later sessions.

Two questions so I can tighten the pack:
1. Can you paste the full job description? The role text you gave is a summary, and the full posting may add requirements.
2. Does the role have any hard terms, such as on-site days, location or travel, that I should treat as gates?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Larkfield_Systems_engineering-manager_interview_pack.md -----
# Larkfield Systems — Engineering Manager: interview prep pack (Yusuf)

**Role:** Engineering Manager, Larkfield Systems (industrial IoT, ~600 people)
**Rounds (loop mode, dates assumed as Tue 17, Thu 19 and Mon 23 Nov 2026 — confirm):**
1. Hiring manager, Director of Engineering, 45 min
2. Panel: two staff engineers and a product manager, 60 min
3. VP Engineering, 30 min, described by the recruiter as "values and leadership philosophy"

First version. Research did not run (web search was not permitted in this session), so company facts are absent and every such point is labeled or dropped.

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is scored: VAL behavioral and values, EXP your past work, JD role requirement, CO company knowledge, CASE a live problem.
- Guidance is scaffolding, not a script. Rehearse only what you did, in your own words.
- Every quote in a Provenance or Evidence cell is a sentence from your message or a clause from the role description you gave. Nothing else is treated as your history.

## Fit snapshot (shared across all three rounds)

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" — role description | "3 as a team lead of 6" — your message | medium | [grounded] | transferability | Your material shows one team of six, not two squads. Words: "I was a team lead of six." Answer slot: if you have set direction for more than one team at a time, say which and at what size; if you have not, say so and say how you would run two squads. |
| F2 | "own delivery, hiring and growth for 11 engineers" — role description (hiring clause) | "I run our hiring loop for backend roles — about 40 interviews last year." — your message | medium | [grounded] | none | The quote reaches hiring in role terms. Keep its exact scope: backend roles, about 40 interviews. Expect a probe on hiring decisions, which the quote does not show (see prohibited list). |
| F3 | "own delivery, hiring and growth for 11 engineers" — role description (delivery clause) | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | medium | [grounded] | transferability | That is delivery work for one team, not delivery across 11 engineers. Words: "After I pushed a reliability quarter through against roadmap pressure, my team's on-call burden dropped 60%." |
| F4 | "own delivery, hiring and growth for 11 engineers" — role description (growth clause) | none given | none | [grounded] | discovery | Your material does not show growing people. Answer slot: if you can name someone you grew and what changed for them, say so; if not, say so and say how you would start. |
| F5 | "partner with hardware and product on roadmap" — role description | "I pushed a reliability quarter through against roadmap pressure" — your message | medium | [grounded] | transferability | Adjacent: you held a roadmap line against pressure. The quote does not show partnering with product or hardware on a roadmap. Words: "I pushed a reliability quarter through against roadmap pressure." Answer slot: if you have set roadmap priorities with a product or hardware partner, say who and what you decided; if not, say so. |
| F6 | "partner with hardware and product on roadmap" — role description (hardware clause) | "I've never managed managers and never owned a hardware-adjacent roadmap." — your message (negative clause) | high | [grounded] | capability | Your own stated absence. Words: "I haven't owned a hardware-adjacent roadmap." Then how you would learn it, said as a plan, never as a past. |

Two notes on the snapshot:
- "Managing managers" is not in the role description. Your stated absence of it is a limit the Director or VP may raise anyway. It is handled in A5 and C4, not as a requirement row.
- Your hiring record (F2) and your on-call result (F3) are each one specific, user-confirmed claim with limited inspectable proof, so expect a verification probe on both.

## Prohibited claims

Built locally from the fit snapshot, because no dossier was present. Every cell in the pack is held against this list.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned a hardware-adjacent roadmap | Negative you stated (F6) | "I haven't owned a hardware-adjacent roadmap." Plain acknowledgment, then your plan. |
| Managed managers | Negative you stated ("I've never managed managers") | "I haven't managed managers." Plain acknowledgment. |
| Led two squads, or led two teams | Inflated form of F1 | "I was a team lead of six." Pack observation, in analysis: your material shows one team of six. |
| Owned delivery across 11 engineers | Inflated form of F3 | The reliability quarter at its own scope: one team. |
| Made hiring decisions for backend roles | Inflated form of F2 | "I run our hiring loop for backend roles — about 40 interviews." Pack observation: the quote says interviews, not decisions. |
| The 60% was yours alone | Inflated form of F3 | Your sentence as written: "after I pushed a reliability quarter through." "After" is not "because of", and no split of credit is stated. |

## Persona weights by round

Priors come from the round type (hiring manager: Case and Skeptic; panel: Peer Evaluator and Prober; executive: Values and Pressure). Depth follows weight.

| Round | Persona | Questions | Why this weight |
|---|---|---|---|
| 1, Director | Skeptic (top) | 4 | The Director is buying capability and derisking the two gaps in the snapshot, F1 and F6. |
| 1, Director | Case / Strategist | 2 | Expect a live problem on the device-management roadmap with hardware in it. |
| 1, Director | Pressure | 2 | Hold-then-concede on the 60% figure and the team-of-six scope. |
| 1, Director | Conversational | 1 | Opener is still scored. |
| 2, Panel | Peer Evaluator (top, staff engineers) | 4 | Staff engineers price what you would cost their work: seams, disagreement, credit. |
| 2, Panel | Data-Driven Prober | 2 | Staff engineers are likely to test the on-call figure. |
| 2, Panel | Case / Strategist (PM) | 2 | The PM will ask about roadmap trade-offs. |
| 3, VP | Values / Behavioral (top) | 5 | The recruiter named this round as values and leadership philosophy. Detected as a values-style round by your recruiter's words, which is a loop source. |
| 3, VP | Pressure | 2 | Executive altitude and composure. |
| 3, VP | Case / Strategist | 1 | Altitude check on the company's direction. |

Persona notes: no interviewer names were given, so no interviewer read was built. Panel members' personas are a blend, since their names are not known.

## Round 1 — Hiring manager (Director of Engineering), 45 min

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So — walk me through the last few years." | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company"; "I run our hiring loop for backend roles — about 40 interviews last year."; "I pushed a reliability quarter through against roadmap pressure" | A 90-second arc in your own words, using only these beats: the payments company, the team of six, the hiring loop, the reliability quarter. Add no beat the quotes do not state. | Casual openers are scored. The arc is built only from F1, F2 and F3. |
| A2 | "You haven't owned a hardware-adjacent roadmap, and this one partners with hardware on the roadmap. What would you do in the first ninety days?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap."; "partner with hardware and product on roadmap" | **Highest-ROI rehearsal in this pack.** Hold: "I haven't owned a hardware-adjacent roadmap." Then the plan as a plan: learn the hardware constraints from the people who own them, and name the roadmap decisions you would bring to them. Answer slot: if you have owned a roadmap with a team whose constraints you did not control, say how, in your own words; if not, say so plainly and give the plan. Hold two follow-ups by returning to the plan, and concede the exact gap. | F6 is a capability gap and F5 is the nearest adjacent work. This objection is near-certain in some form. The premise is the role's own text plus your stated absence. |
| A3 | "You've led one team of six. Why should we believe you can lead two squads?" | JD | [grounded] "3 as a team lead of 6"; "Lead two squads building device-management services" | Hold to the team of six, stated plainly. Answer slot: if you have set direction across more than one team at once, say which and at what size; if not, say so and say how you would run two squads. Return to the size on each follow-up. | F1. The question presupposes only the role's scope and your one-team fact. |
| A4 | "About forty interviews last year. What did you decide, and what did you leave to someone else?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Say the loop and the interviews in those terms. Answer slot: if you made hire or no-hire decisions, say which and how; if you ran interviews and others decided, say so. | F2. The "decide" is the inflation listed in the prohibited list; the slot keeps it honest. |
| A5 | "Sixty seconds: why you over someone who has already managed managers?" | JD | [grounded] "I've never managed managers" | Pause, then restate the question. Hold: "I haven't managed managers." Then what you would bring, from the team of six and the hiring loop. Hold through two follow-ups, then concede exactly what you lack. | Pressure stem. Premise is your stated negative. |
| A6 | "That reliability number — how much of it was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Hold your position in your words: you pushed the quarter through. Concede plainly what you cannot separate from the team's part. Answer slot on the figure: if you can say how the 60% was counted, say it; if you did not count it, say so and name the measure you would trust. | The figure raises the defend-the-number slots. The pack supplies no counting method. |
| A7 | "Why leave a payments company for industrial hardware?" | JD | [grounded] "currently at a payments company" | The material does not show your reason. Answer slot: if you have one, say it in your own words; if it is still forming, say that and name what would settle it. | Motivation consistency is scored. The reason is not in the material, so nothing is supplied. |
| A8 | "A firmware rollout to 40,000 devices fails on five percent of them. What do you do in the next 24 hours?" | CASE | [generic] | Clarify first: which device models, what the failure is, whether rollback is possible. Objective: stop the spread and protect devices already updated. Segment by hardware variant, decide the next step on the failing cohort, and name the risk of pausing. | Live problem from device management. Makes no claim about your past. |
| A9 | "The next sensor revision slips six weeks, and product wants the feature on the original date. Walk me through the call." | CASE | [generic] | Clarify what slips and what it costs. Identify who owns each date and propose a decision rule. Name what you would escalate and to whom. Do not claim you have run this before. | Tests the hardware and product partnership in the role text. |

Interview-level count: nine questions, as weighted above.

## Round 2 — Panel (two staff engineers and a product manager), 60 min

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Walk me through how you counted the on-call burden before and after." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Name, in your own words, the assumption behind the figure you would defend least, before they do. Answer slot: if you can say how the 60% was counted, say it; if you did not count it formally, say so plainly and name the measure you would trust. | Prober. This is the most-probed item in the pack. |
| B2 | "Which parts of that reliability quarter did you design yourself, and which did you only defend?" | EXP | [grounded] "I pushed a reliability quarter through against roadmap pressure" | Describe what pushing it through involved, in your words: what you held and what you asked for. Answer slot: if you designed parts of the work, say which; if you did not, say so and say what the pushing consisted of. | The premise "design" is not in the quote, so this is an answer slot with a false-premise branch. |
| B3 | "Where's the seam between your squads and the hardware team, and what happens when you disagree?" | JD | [grounded] "partner with hardware and product on roadmap" | Propose seam principles, not a seam you have not seen. Answer slot: if you have disagreed with an equal over priorities, say what happened and what you conceded; if not, give the principles and say what you would want to see first. | Peer Evaluator. The seam is raised by the role text. |
| B4 | "What would you need from the staff engineers to make your first quarter work?" | VAL | [generic] | Name two decisions you would ask them to own, not "anything". Say what your work would give back to their teams. | Peer pricing, which is reciprocity. Generic. |
| B5 | "How do you handle credit when work spans teams?" | VAL | [generic] | Use "we" for context and "I" for your contribution. Answer slot: give one case where your contribution was specific, in your words; if none comes to mind, say so and describe how you would handle it. | Peer stem. Generic scaffold. |
| B6 | "You have three product asks and a reliability backlog. What do you cut, and why?" | CASE | [generic] | Clarify the cost of each ask. Segment by customer and risk, propose the cut rule first and then the owner. Name what you would put to the PM and what to the staff engineers. | Roadmap trade-off for the PM. |
| B7 | "Fleet devices offline rose twenty percent in a month. Diagnose it." | CASE | [generic] | Clarify scope and the metric's definition. Segment by firmware, region and hardware variant. State hypotheses and the data you would need, not data you have. | General case. Labeled generic. |
| B8 | "Where did you disagree with a peer on priorities, and what did you concede?" | VAL | [generic] | Hold, then concede: state your position, then the specific point that was wrong. Answer slot: if you have had such a disagreement, say it; if not, say so and say how you would approach one. | Peer disagreement style. |

Interview-level count: eight questions.

## Round 3 — VP Engineering, 30 min ("values and leadership philosophy")

This is a values-style round, detected from your recruiter's words. The published values section is not in the pack because no company values were retrieved. The VAL questions below use selection scaffolds where your material has no story.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "I pushed a reliability quarter through against roadmap pressure" | Mapped story: the roadmap pressure, and the decision to push the reliability quarter through. STAR: "we" for context, "I" for the push. Answer slot on the reaction: your material does not show how leadership responded. If the truth landed, say so; if it did not, say that too. Do not supply an ending. | Values are scored. This quote is the only story you have. |
| C2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a time a customer or user outcome beat an internal target. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. | Your material has no customer story, so none is supplied. |
| C3 | "How do you grow the people who report to you?" | VAL | [generic] | Selection scaffold: name one person you developed and what changed for them. Answer slot: if you can name one, say who and what; if not, say so and describe how you would start. | Growth clause of the role (F4) has no quote. |
| C4 | "You've never managed managers. What's the case for you here?" | JD | [grounded] "I've never managed managers" | Hold: "I haven't managed managers." Then the case from the quotes you have: the team of six and the hiring loop. Concede specifically where the gap is. | Pressure. Likely probe even though the role text does not name it. |
| C5 | "Sixty seconds: why this, why now?" | JD | [grounded] "currently at a payments company" | Your material does not show the reason. Answer slot: if you have one, say it in your words; if it is not yet clear, say so. | Motivation under pressure. |
| C6 | "What would you want to be true about our device-management business in three years?" | CO | [generic] | No strategy source was retrieved, so do not assert their strategy. Describe what you would want to be true for engineers and for customers. | Company-altitude question with no company research. Labeled generic. |
| C7 | "Tell me about a decision you made that you would reverse." | VAL | [generic] | Selection scaffold, with the honest branch: if no such decision comes to mind, say so plainly, then give the nearest decision your material does carry. Keep to one decision and say what you would do now. | Accountability. |
| C8 | "Describe your leadership philosophy through one decision you would make the same way again." | VAL | [generic] | Scaffold: one decision, the principle it shows, and what you would keep. Do not name a principle that decision does not show. | Recruiter's named focus, leadership philosophy. |

Interview-level count: eight questions.

## Requirement coverage

| Requirement | Covered by |
|---|---|
| Lead two squads building device-management services | A3, C4 (partly) |
| Own delivery for 11 engineers | A6, B1, B2 |
| Own hiring for 11 engineers | A4 |
| Own growth for 11 engineers | C3 (F4 has no quote, so this is a scaffold) |
| Partner with hardware and product on roadmap | A2, A9, B3, B6 |
| Hardware-adjacent roadmap (your stated gap) | A2 |
| Managing managers (not in role text; your stated gap) | A5, C4 |

Session total is 25 questions across three rounds, which is within the 18–26 range for a session pack.

## Reverse questions

Each one has a reason it lands.

1. **Round 1, Director:** "What would the first ninety days need to have delivered for the two squads to be running well?" — It pins down the scope you will be judged on.
2. **Round 1, Director:** "Where does a roadmap call with the hardware team get made today, and who has the last word?" — It shows you are thinking about authority, the piece you have not owned.
3. **Round 2, panel:** "Where is the seam between the squads and the product team most strained right now?" — It invites a candid peer answer.
4. **Round 2, reciprocity (peer):** "What could a new engineering manager do in the first month that would genuinely help your team?" — It turns the panel toward what you would bring them.
5. **Round 3, VP:** "Give me one decision here that you would point to as an example of your values." — It asks them to show the value in action.
6. **Round 3, VP:** "What do managers here do that people who struggle in the role don't?" — It invites a specific answer on the job's real demands.

## Sources

- Provided by you: your message (background, the three rounds, the recruiter's note on the VP round) and the role description.
- Web search: three queries were sent and each was refused by permission. No results came back and no pages were fetched.
  - "Larkfield Systems values" — refused
  - "Larkfield Systems interview process engineering manager" — refused
  - "Larkfield Systems industrial IoT device management strategy" — refused

**Research tier:** L1 attempted, no results. Searches 0 of 6 completed (3 refused), fetches 0 of 2.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Larkfield Systems values` | unavailable | Values cheat sheet (section 10). Dropped, because no published values are in hand. |
| 2. `Larkfield Systems interview process engineering manager` | unavailable | Loop structure. Not needed for the round structure: your message names the three rounds, so the loop is established by your own words. |
| 3. `Larkfield Systems strategy` / recent news | unavailable | CO bank. C6 is generic for this reason. |
| 4. `{interviewer name} Larkfield Systems` | n/a | No interviewer names were given. |
| 5. representative engineering manager JD | skipped | The role description you gave fixes the requirements in the fit snapshot. A full JD would still improve it (see upgrade menu). |

## Upgrade menu

- **Full job description text** → the role clauses become complete requirements, and rows F1 to F6 can be checked against the whole posting instead of your summary.
- **Names of the Director, the two staff engineers, the PM and the VP** → a persona weight per named person, an interviewer read, and tailored reverse questions. Panel personas are blends until then.
- **Larkfield's published values page, pasted** → the values cheat sheet, and C1 to C3 and C7 to C8 mapped to named values in place of selection scaffolds.
- **Permission for web search, or the same three queries pasted as results** → loop structure, a strategy pass, and specific C6 and B6 cases. C6 is generic until then.
- **Recruiter's note on what the VP round will assess** → if it names specific values or a principles list, C-questions can be mapped to them.
- **Any hard terms in the role (on-site days, location, travel, pay)** → if one exists, it becomes a hard-gate row. No gates were found in the material.
