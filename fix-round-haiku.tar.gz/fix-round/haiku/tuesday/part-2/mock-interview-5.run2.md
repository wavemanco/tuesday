Your prep pack is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-tuesday-part-2-rooms-case-5-denied-02c53d3e/28cda526-f1da-4ae2-95c2-02c20c48cf3b/scratchpad/kelverton-rail_senior-partnerships-manager_interview_pack.md`. It covers the POV, Ross's commercial bank, Deepa's bank, the gap handling, and a timed plan for your four hours.

**Where to spend the time:**
- **The POV (75 min).** Pick one of three theses. Each has a built-in concession. My suggestion is T1, partner for the operator's change, not its purchase, with T3 (don't copy the payments ISV model) as your anti-pick. Speak it aloud timed to 12 minutes.
- **Ross (60 min).** The question that matters most is C1: "Roughly £4M of influenced revenue. How much of that was actually you?" Know how the £4M was counted. If you can't say, say that plainly.
- **The two honest lines (20 min).** "I've never sold into rail" and "I've never carried a direct quota." Say them without hedging. Deepa's likeliest objection is B1, "why would an operator take a meeting with you over someone who has sold into rail?" Hold on the bus and light rail planning view, then concede the rail sales gap.

**Caveats:**
- **Web search was refused**, four times, so the pack has no company, interviewer, or operator-context research. Deepa and Ross are unprofiled, and I haven't checked the current state of operator reform. Verify that yourself before Tuesday.
- **No JD**, so the requirements come from the recruiter's email and your own description of the company.
- **The market report isn't in this session.** The POV's "consensus answer" section is a placeholder until you paste its shortlist.

Two things would sharpen the pack:
1. Can you paste the JD? That would turn the inferred requirements into quoted ones and let me check coverage against the JD's own list.
2. Can you paste the report's shortlist and headline numbers? Then I can tell you which consensus answer to depart from.

I can also run a live drill on C1 or B1 if you want to rehearse, or save a `tuesday-dossier.md` recording the gaps this prep exposed. I can convert the pack to Word if you'd like that instead of markdown.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: kelverton-rail_senior-partnerships-manager_interview_pack.md -----
# Interview prep pack: Senior Partnerships Manager, Kelverton Rail

**Round:** second round, panel, 60 minutes. First 15 minutes is a spoken POV (no slides). Then Q&A.
**Panel:** Deepa (VP Partnerships, your future manager) and Ross (Commercial Director). Ross will push on commercials.
**Built from:** your message, and the recruiter's email quoted in it. No JD, no interviewer profile, no web research (search was refused, see Sources). Everything is labelled.

## How to use + type key

Personas describe how a question arrives. Types describe what is scored.

- **VAL**: values alignment. Not in this round.
- **EXP**: your own experience, and whether it survives scrutiny.
- **JD**: the role's stated responsibilities and gaps. No JD supplied, so these are inferred from the recruiter's words.
- **CO**: company and strategy knowledge.
- **CASE**: a live problem, reasoned aloud.

Guidance is scaffolding, not a script. Speak it in your own words.

## Prep triage (about 4 hours)

1. **POV build, 75 min.** Choose one thesis from Section 5. Write three bullets in your words. Speak it aloud, timed to 12 minutes, twice.
2. **Ross's commercial bank, 60 min.** C1 to C4 and D1 to D4. Answer each aloud in under 90 seconds.
3. **The two honest lines, 20 min.** B1 and B2 hold-and-concede. Say "I've never sold into rail" and "I've never carried a direct quota" aloud until they come out flat, not defensive.
4. **Deepa's bank and the opener, 35 min.** A1 to A5, E1, E2.
5. **Read the market report again, 20 min.** Find its consensus answer so you can depart from it.
6. **Live drill, 30 min.** If you take the drill offer.

Everything else is insurance.

## 1. Fit snapshot

No JD was supplied, so the requirements come from the recruiter's email (quoted, `[grounded]`) or from your own description of the company (also quoted). Hard gates: none identified in the material. Without a JD, a gate check is not possible.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "where you'd take our operator partnerships over the next 18 months" (recruiter email) | "took it from 6 partners to 40, roughly £4M of influenced revenue" (your message) | medium | [grounded] | transferability | Your sentence is about a partner channel in payments. It reaches partnership scale, not operator partnerships. Say the scale and the moves, then where they would and would not carry to an operator. Answer slot: if any of those moves would not carry, say which. |
| F2 | "sell scheduling software to train operating companies" (your message) | "bus and light rail network planning, so I know the operator world from the other side" (your message) | medium | [grounded] | transferability | Adjacent work. Bus and light rail planning is not train-operator work. Use the quote at its own scope, with its limit named. Do not stretch it toward rail operations. |
| F3 | "sell scheduling software to train operating companies" (your message) | "Never sold into rail specifically" (your message) | none | [grounded] | capability | Plain acknowledgment: "I've never sold into rail." Then how you would learn the buying committee, said as a plan, never as a past. |
| F4 | carries a direct revenue number (role-family pattern, no source) | "never carried a direct quota, only influenced revenue" (your message) | none | [grounded] | capability | Plain acknowledgment: "I've never carried a direct quota." Then what you did carry: "roughly £4M of influenced revenue", at its own scope. |
| F5 | "Ross will push on commercials." (recruiter email) | none given | none | [grounded] | discovery | The material does not show commercial structuring: partner terms, margin, deal economics. Answer slot: if you set or negotiated a partner term, say which and what you decided. If not, say so and say how you would find the right terms for operators. |
| F6 | "Please land on what it means for the operators themselves." (recruiter email) | none given | none | [grounded] | discovery | No evidence in the material on operator outcomes. This is a build requirement for the POV, not a claim about your past. Covered in Section 5. |

## 2. Prohibited claims

Built locally from the fit snapshot. These are the claims a candidate reaches for under pressure. Nothing in this pack asserts them.

| Not coached | Basis | Honest form |
|---|---|---|
| Knows rail operations | Inflated form of F2: bus and light rail planning widened to train operators | F2's sentence at its own scope. The material shows bus and light rail planning, not train operations. |
| Has sold into rail | Sourced entry: stated negative in F3 | "I've never sold into rail." No slot. |
| Has carried a revenue quota | Sourced entry: stated negative in F4 | "I've never carried a direct quota." No slot. |
| Owned or drove the £4M | Inflated form of F1: "influenced" widened to "owned" | "roughly £4M of influenced revenue", at its own scope. The material says influenced, not owned. |
| Built the ISV programme | Inflated form of F1: "running the ISV channel" widened to "built" | "running the ISV channel", and "took it from 6 partners to 40". |

## 3. Persona table

Panel: blend the top two personas for each member's relationship. Deepa is a hiring manager; Ross is an executive who has said he will push on commercials.

| Persona | Member | Likelihood and reasoning | Counter-strategy | Depth |
|---|---|---|---|---|
| Case/Strategist | Deepa | High. A hiring manager is buying capability and will test the POV against her roadmap. | Clarify before structuring. Name the operator first. | 5 |
| Skeptic | Deepa | High. Rail sales and the quota are the visible gaps; a hiring manager will probe them. | Hold-then-concede. The most predictable objection is B1. | 3 |
| Pressure / Stress | Ross | High. The recruiter said he will push on commercials, and the executive prior adds time pressure. | Pause, restate, hold the one defended number. | 4 |
| Data-Driven Prober | Ross | Medium-high. A commercial director probes the headline figure, and £4M is the headline. | Name the weakest assumption before he does. | 4 |
| Conversational | Either | Medium. Openers are usually biography, and casual questions are scored. | A 90-second arc. | 2 |
| Peer Evaluator | Ross | Low-medium. He will think about the seam with direct sales. | Seam principles, not a seam you know. | 2 |

Total: 20 questions.

## 4. Question banks

Provenance is each row's own quote(s). A `[generic]` row makes no claim about you.

### Deepa: Case/Strategist (depth 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "If you had to pick one operator to start with, which and why?" | CASE | [generic] | Clarify first: the operator's contract position, its change programme, what its planning team already uses. Then pick one and say what would change your pick. | Case scoring rewards clarifying before answering. Generic because it asks for a method, not your history. |
| A2 | "Take one timetable change at an operator. Where does a partner add value, and where does it get in the way?" | CASE | [grounded] "bus and light rail network planning, so I know the operator world from the other side" | Reason from the planning view. Answer slot: name a step of that work you did yourself, in your own words. If you saw it only from the consultant's side, say so and reason from there. | F2 is the closest operator-side evidence. The question tests how far it reaches. |
| A3 | "What would your first 90 days look like on operator partnerships?" | JD | [generic] | Three moves: learn two operators' buying and change cycles, test the thesis against your partner experience, and set the six-month check you would expect to be held to. | A standard hire question. No past claim. |
| A4 | "Which operator segment would you not pursue, and why?" | CASE | [generic] | State the anti-pick plainly, and its cost. | The POV's anti-pick is where judgment shows. Asked live. |
| A5 | "You haven't sold into rail. What would you do in six months to be credible with an operator?" | JD | [grounded] "Never sold into rail specifically" | Plain acknowledgment: "I've never sold into rail." Then the plan, in future tense: who you would learn from, which operator you would sit with first, what you would want to understand before proposing anything. Never describe rail selling as done. | F3 is the largest gap. The question presupposes it, and its source is your own negative. |

### Deepa: Skeptic (depth 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | **Highest-ROI prep.** "Why would an operator take a meeting with you over someone who has sold into rail?" | JD | [grounded] "Never sold into rail specifically"; [grounded] "bus and light rail network planning, so I know the operator world from the other side" | Hold-then-concede. Hold: the operator meeting rests on the planning view in that quote, at its own scope. Concede: "I haven't sold into rail, and a rail seller would know the buying committee better than I do today." Then your plan from A5. Hold through two follow-ups by returning to the planning view. Do not claim you have had operator meetings before. | F3 and F2. This is the objection most likely to be asked in some form, so it gets the deepest rehearsal. |
| B2 | "You've carried no quota. What number would you be comfortable being held to?" | JD | [grounded] "never carried a direct quota, only influenced revenue" | Plain acknowledgment: "I've never carried a direct quota." Then how a number should be built: from partners and pipeline, not a guess. Answer slot: if you have a view of partner-sourced revenue in year one, say how you would build it. Do not invent a figure. | F4. The honest answer is a method, not a number. |
| B3 | "Why leave a payments company for rail-tech, and why now?" | JD | [generic] | Answer slot: give the real reason in your own words. The material does not say what it is, so say it plainly, and tie it to operators only if that is true. | Motivation is a Skeptic probe. Nothing in the material answers it. |

### Ross: Pressure / Stress (depth 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Roughly £4M of influenced revenue. How much of that was actually you?" | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" | Hold the growth as your own account of the channel. Answer slot: how the £4M was counted, which part was yours to influence, and the assumption you would defend least. If you cannot say how it was counted, say so. Hold through two follow-ups. Concede the soft edges of the figure. | The headline figure. The most likely place for a defend-the-number probe. |
| C2 | "Operators' contracts run for years. What does your year-one pipeline look like?" | CASE | [generic] | Hold that year one is about partner enablement, not revenue. Concede that the pipeline is unknown to you today. Give no figures. If he corrects the premise, accept it. | Commercial pressure with no number in the material. |
| C3 | "What would you give away on margin to get an operator signed?" | JD | [generic] | Name the one term you would not give, and why, in your own words. Concede that you do not yet know operator margins, and say how you would find out. | Ross's commercial push. A defended floor is better than a guessed one. |
| C4 | "Your POV is a partner strategy. Isn't it just a sales strategy with a nicer name?" | CASE | [generic] | Hold: a partner strategy changes who does the work, not only who sells. Name what the operator does differently. Concede that the measure is partner-sourced revenue, so it has to show up in the number. | A pressure question on the POV's core thesis. |

### Ross: Data-Driven Prober (depth 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how you'd count a partner-sourced win at an operator." | EXP | [grounded] "roughly £4M of influenced revenue" | Name the weakest assumption in counting influence, the one you would defend least, before he does. Answer slot: how you would count it and which share you would call partner-sourced. If you have not counted it this way before, say so. | A metric question. The £4M raises the slot. |
| D2 | "Of your 40 partners, how many produced revenue, and how was that spread?" | EXP | [grounded] "took it from 6 partners to 40" | Answer slot: if you have the split, give it. If not, say you do not have it to hand and how you would get it. Do not estimate. | The 40 is quoted. What they produced is not. |
| D3 | "Operators run long contracts. What payback period would you accept on a partner?" | CASE | [generic] | Hold: name a test you would run before committing, not a payback figure. Concede that you do not yet know operator payback. | Pressure on commercials with no number in the material. |
| D4 | "What commercial assumption in your POV would you defend least?" | CASE | [generic] | Name one assumption in your own thesis, and what would show it false. | The weakest-assumption move, applied to your POV. |

### Conversational opener (depth 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So — walk me through the journey." | EXP | [grounded] "5 years in transport consulting"; [grounded] "took it from 6 partners to 40"; [grounded] "so I know the operator world from the other side" | A 90-second arc: transport consulting, then the payments channel, then why operators now. Use the sentences above and nothing else as facts. | Openers are scored. These sentences are the only facts you have stated. |
| E2 | "What are you reading on rail at the moment?" | CO | [grounded] "which I've read" (the internal market report) | Answer slot: name what you have read, in your own words. Do not cite the report's content unless you can say it in your own terms. | Casual, but scored. You can name the report you have read. |

### Ross: Peer Evaluator (depth 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Our direct sales team owns the operator relationship. What happens when your partners and our account managers disagree?" | JD | [generic] | Propose seam principles: who owns the account, how partner-sourced deals are credited, how it escalates. Do not claim to know this seam. | A seam probe. No past claim. |
| P2 | "What would you need from commercial and sales in the first quarter?" | JD | [generic] | Name two specific asks and what you would give back for each. | Reciprocity. A peer probe. |

## 5. Graded deliverable: the 15-minute POV

**Declared by the recruiter:** "present a short POV on where you'd take our operator partnerships over the next 18 months — no slides needed, just talk us through it. Please land on what it means for the operators themselves."

**Grounded facts to build on:**
- F1: "took it from 6 partners to 40, roughly £4M of influenced revenue." Use the scale and the moves. It is partner management in payments, not operator experience.
- F2: "bus and light rail network planning, so I know the operator world from the other side." Use it for the planning view, at its own scope.

**Theses (choose one; each has a mandatory concession):**
- **T1, partner for the operator's change, not its purchase.** `[generic]` Operators' main pain is the cost and risk of changing timetables. Partners who do that work (implementation and operations consultancies) let the product land faster. *Concession:* partners who implement also own the operator relationship, and can take value you would rather keep.
- **T2, go deep on fewer operators before broadening.** `[generic]` A concentrated buyer set on long contracts means each operator is a programme. *Concession:* slower logo growth, and a board may read it as a small channel.
- **T3, anti-pick: do not copy the payments ISV model.** `[generic]` Forty partners is a volume model. Operators are few, regulated buyers. *Concession:* this gives up the reach you are known for. Say where you think the volume model still has a place.

**Differentiation against the consensus answer:** the market report's shortlist is the consensus answer, and I have not seen it. Bring one item from it to show you read it, then depart with a reason. Paste the shortlist to sharpen this (see the upgrade menu).

**The close (what it means for operators):** name one thing that is better for an operator's planning team in twelve months, and how they would know. Your sentence, not mine.

**Spoken shape (12 minutes):** what I heard in the brief (1 min); the thesis and its concession (3 min); three moves over 18 months (5 min); what it means for the operators (2 min); what I would need to learn in the first 30 days (1 min).

## 6. Requirement coverage

| Requirement | Covered by |
|---|---|
| POV on operator partnerships, 18 months | Section 5 |
| What it means for operators | Section 5 close; A1, A2 |
| Commercials (Ross will push) | C1 to C4, D1 to D4 |
| Rail sales | A5, B1 |
| Direct revenue number | B2 |
| Motivation | B3 |
| Operator knowledge | A2, E1 |
| JD requirement list | None supplied. Cannot check against a JD. |

## 7. Reverse questions

Five, each with why it lands. None is tied to Deepa's own career path, because there is no interviewer profile.

- **R1.** "Which operator relationship are you most worried about right now?" *Why it lands:* it asks for the live problem, and Deepa will answer with her real priority.
- **R2.** "When a partner-sourced deal stalls between your team and an operator's procurement, who decides?" *Why it lands:* it names the seam Ross is likely to care about.
- **R3.** "What would you need to see by month six to believe this hire worked?" *Why it lands:* it shows you are already thinking about the measure they will use.
- **R4.** "How is the split between influenced and direct revenue set for this role?" *Why it lands:* it asks about the quota question on their terms, and the answer tells you how hard B2 will be.
- **R5.** "What did the last partnership that did not work at an operator teach the team?" *Why it lands:* it is specific, and signals the POV is not your first thought.

## 8. Sources

**Research tier: L0.** Four web searches were attempted. Each was refused by the host, so no outside source was used.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Company values | unavailable | Values cheat sheet. Not included, because no values-style round was detected. |
| 2. Company interview process | unavailable | Loop structure and persona weights. Persona weights rest on relationship priors instead. |
| 3. Company strategy and recent news | unavailable | CO questions grounded in current strategy. Would be restored by pasting the market report (upgrade menu). |
| 4. Interviewer names (Deepa, Ross) | unavailable | Interviewer read, per-member persona weights, a reverse question tied to their path. |
| 5. Representative JD | unavailable | Fit snapshot would have quoted an inferred JD. The JD was not supplied either. |

Queries sent, all refused:
- "Kelverton Rail scheduling software train operating companies"
- "Kelverton Rail Deepa VP Partnerships"
- "Kelverton Rail Ross Commercial Director"
- "UK rail train operating companies technology suppliers partnerships 2026 rail reform Great British Railways"

Provided documents: your message, and the recruiter's email as quoted in it. The market report is referenced but was not supplied to this session.

## Upgrade menu

- The JD text → F1, F3 and F4 get `[grounded]` requirements, and the coverage table can be checked against the JD's own list.
- The market report's shortlist and headline numbers, pasted → the consensus answer to depart from in Section 5, and CO questions grounded in the report.
- Web search enabled → a run on Deepa's and Ross's public footprint (interviewer read, per-member personas, a reverse question tied to their path) and on current operator context. Check the current status of the operator reform programme yourself before Tuesday; I have not verified it.
