Your prep pack is saved as /tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-tuesday-part-2-rooms-case-5-denied-b06663fc/b71efa85-d546-4eb6-a45f-ff82b86d8ff0/scratchpad/kelverton-rail_senior-partnerships-manager_interview_pack.md, and I've attached it here. It is built on your message and the recruiter's quoted lines only. I couldn't research Kelverton: the web search permission was declined, so the values, interview process and strategy are not established in the pack. I also haven't seen the market report.

The most useful thing in it is the schedule in section 1, which fits in about 3.5 hours. The highest-ROI rehearsal is B2, Deepa's "why should an operator trust a partnership plan from someone who has never sold into rail?" The pack holds the stated negative, concedes one specific thing, and offers a plan. It doesn't claim rail sales or operator advice. The POV in section 5 is three theses, each with a concession and an anti-pick. Those anti-picks are provisional until you check them against the report's headline recommendation.

Drill offer: say "drill B2" and I'll play Deepa's Skeptic with follow-ups.
Dossier offer: I can save a tuesday-dossier.md recording the gaps this prep exposed, for later sessions.

Three things would sharpen the pack:
1. Can you paste the job description text, if you have it? Without it, the requirements are only the recruiter's lines, and any location, travel or pay gates aren't visible.
2. In your transport consulting, were your clients train operators, authorities, or both? That decides whether "so I know the operator world from the other side" can be quoted at a wider scope.
3. Can you paste three or four headline points from the market report? I can't see the attachment, so I can't name the consensus answer your POV has to differ from.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: kelverton-rail_senior-partnerships-manager_interview_pack.md -----
# Interview prep pack: Senior Partnerships Manager, Kelverton Rail

**Round:** second round, panel, 60 minutes. First 15 minutes: a short spoken POV, no slides, on where you would take operator partnerships over 18 months, landing on what it means for the operators. Remaining 45 minutes: Q&A, with commercials pressed.
**Panel:** Deepa (VP Partnerships, your future manager); Ross (Commercial Director).
**Research:** web search was declined in this session. Company values, interview process and strategy are **not established** and are not used. The pack draws only on your message and the recruiter's quoted lines. The market report is not in this conversation, so nothing below is checked against it.

## How to use + type key

Personas are how a question is asked. Types are what is being scored.

- **CASE**: a live problem from the role, scored on structure and reasoning.
- **EXP**: your past work, scored on whether it survives scrutiny and what was actually yours.
- **JD**: a stated responsibility or gap, scored on whether you can do the listed job.
- **CO**: company and strategy knowledge, scored on altitude. Not rehearsed here; no research ran.
- **VAL**: values or behaviour. Not used; no values round is established.

Guidance is scaffolding, not a script. Each answer should be speakable in 90 to 120 seconds, in your own words.

## 1. Prep triage (about 4 hours)

In order. Each item points to the section that holds it.

1. **60 min, the POV (section 5).** Write three theses in your own words, each with its concession and its anti-pick. Speak the whole thing aloud once, timed. Target 12 minutes, leaving 3 for the first 90 days.
2. **45 min, the Skeptic (B2, B3).** Say each out loud three times. Hold the stated negative through two follow-ups, then concede the specific thing. This is the one most likely to decide the round.
3. **45 min, the numbers (C1, C4, D1, D2).** For the £4M and the 6-to-40 move, write what was counted, what the figure is sensitive to, the assumption you would defend least, and which part was yours. Only what you actually did.
4. **30 min, commercials (C2, C3, C5, D3).** Write a 60-second commercial case for operator partnerships: budget line first, price mechanism second, risk third.
5. **30 min, full run.** POV timed end to end, then one drill with Ross.

That is about 3.5 hours, leaving 30 minutes for re-reading the market report. Everything else is insurance.

## 2. Fit snapshot

Requirements come from the recruiter's quoted lines and your own description of the business, since no job description was supplied. Quotes are your sentences or the recruiter's, verbatim.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "where you'd take our operator partnerships over the next 18 months" (recruiter's email) | "9 years in partnerships" (your message); "running the ISV channel" (your message) | medium | [grounded] | transferability | Your partnership record is in payments, through a channel. Bridge at its own scope: "I ran the ISV channel at a payments company." Answer slot: name one part of that channel work you think carries to an operator, in your own words; if none does, say so and say what you would test first. |
| F2 | "sells scheduling software to train operating companies" (your message, describing the business) | "Never sold into rail specifically" (your message) | none | [grounded] | capability | The gap is one you stated, so the words are yours: "I haven't sold into rail specifically." Then how you would close it, said as a plan, never as a past. No claim of rail sales. |
| F3 | "Ross will push on commercials" (recruiter's email) | "roughly £4M of influenced revenue" (your message); "never carried a direct quota" (your message) | medium | [grounded] | transferability | Your figure is influenced revenue, not quota. Bridge stays at that scope: "roughly £4M of influenced revenue." The limit you stated: "I've never carried a direct quota." Answer slot: say what the £4M counted and which part was yours, in your own words. |
| F4 | "Please land on what it means for the operators themselves." (recruiter's email) | "bus and light rail network planning" (your message); "so I know the operator world from the other side" (your message) | medium | [grounded] | transferability | The operator-side knowledge is from the planning side of bus and light rail, not train operators. Bridge at that scope. The limit is this pack's observation, not words for you: your material says planning, not train operators. Answer slot: if any of that planning work involved an operator, say which and what you saw from that side; if none did, say so and stay with the planning side. |

## 3. Prohibited claims

Built here from the fit snapshot, before any question is written. These are the claims a candidate reaches for under pressure. Nothing below is coached.

| Not coached | Basis | Honest form |
|---|---|---|
| "I've sold into rail" | Stated negative from F2 | "I haven't sold into rail specifically." |
| "I carried a quota" or "I owned a revenue target" | Stated negative from F3 | "I've never carried a direct quota." |
| "I generated the £4M" or "I drove the £4M" | Inflated form of F3's "roughly £4M of influenced revenue" | Quote at its scope: "roughly £4M of influenced revenue." Limit, as this pack's observation: the material says influenced, not sourced. |
| "I advised or worked with train operators" | Inflated form of F4's "bus and light rail network planning" | Quote at its scope. The material says planning, not train operators. |
| "I grew the channel on my own" | Inflated form of F1's "took it from 6 partners to 40" | Quote at its scope. The material does not say who else worked the channel; that is this pack's observation, not a claim you make. |

## 4. Persona weights

No interviewer profiles were available, so the interviewer read is dropped and weights rest on round-type priors. The panel rule blends the top two personas of each member.

| Persona | Who | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|---|
| Case / Strategist | Deepa | Live operator problems from the role | High. Hiring managers buy capability and test it on their own roadmap. Depth: 4 questions. | Clarify, then segment, then approach, then the operator's metric, then risk. Say the structure aloud. |
| Skeptic | Deepa | The rail gap, and why an operator should trust you | High. The rail gap is the one the material leaves most exposed. Depth: 3 questions. | Hold the stated negative, then concede one specific thing and a plan. Rehearse until it is boring. |
| Pressure | Ross | Challenges to commercial claims, and to how much was yours | High. Commercial Director, and the recruiter named commercials. Depth: 5 questions. | Pause, restate, hold through two follow-ups, then concede only the uncertainty you can name. |
| Data-Driven Prober | Ross | Counting the £4M and the 40 partners | High. Both headline numbers invite a counting question. Depth: 4 questions. | Name the weakest assumption before he does. Say plainly when you do not know how a figure was counted. |
| Conversational | Both | The opener and the close | Medium. Casual openers are still scored. Depth: 2 questions. | A 90-second arc in your own words. Never answer the reverse-question slot with "I think you've covered everything." |
| Values / Behavioural | none | n/a | Not weighted. No values round is established, and no loop source documents one. | n/a |

## 5. Graded deliverable: the 15-minute operator POV

The recruiter announced this deliverable, so it is graded. Build it in your own words.

**Grounded facts to build on.** F1 and F4 are the only candidate facts here. Use F1's "9 years in partnerships" at that scope. Use F4's planning-side sentence at that scope. Do not use F2 or F3 in the POV; they belong in the Q&A.

**Consensus answer.** Unknown. The market report is not in this conversation. Everything below is provisional until you check it against the report's headline recommendation. If the report's top item is a partner-tier programme, that is the consensus, and the anti-picks below are the differentiation.

**Shape.** About 1 minute to frame, about 3.5 minutes per thesis, 3 minutes on the first 90 days, 1 minute to close.

**Thesis 1: attach partnerships to the operator's own recovery measure, not to our feature list.**
- Operator benefit (the close): the planner sees their own recovery target move first.
- Concession: operators may not share the data needed to measure recovery, and their contract terms may limit what they can spend. Test with two operators before committing to a programme.
- Differentiation: the consensus is probably a wider partner-tier programme. Yours is fewer, deeper integrations first.
- Anti-pick: say no to a generic reseller tier until two operators are running the integration.

**Thesis 2: fit the commercial case to the operator's budget line, not to ours.**
- Operator benefit (the close): the business case goes to their finance team in their own budget line, with a payback they can check.
- Concession: Kelverton carries the payback risk in the first year. This only works if the commercial model can absorb slower revenue. Say so before Ross does.
- Differentiation: the consensus is probably a licence uplift. Yours is pricing linked to an operator-measured saving, with a floor.
- Anti-pick: no first-logo discounts that the operator's finance team cannot re-base later.
- Do not cite the £4M here. It is a number you should defend in the Q&A, not a track record for this thesis.

**Thesis 3: the partner's job is to shorten the operator's procurement, not to resell.**
- Operator benefit (the close): one partner the planning team already knows replaces a multi-party procurement.
- Evidence to use: F1, at its scope. Say which channel lesson you think carries over and where it does not, in your own words.
- Concession: partners add margin and create channel conflict with direct sales. A partner who knows the planning system may also be a rival.
- Differentiation: the consensus is more partners. Yours is fewer partners, with a clear role for each.
- Anti-pick: no reseller margin on direct operator deals.

**Close.** What it means for the operators: a recovery target they already report, a business case in their budget line, and one partner they already know. Then the first 90 days: two operators, one measure, and what would make you change the plan.

## 6. Question banks

Provenance comes first in every row. Question IDs are letter-by-persona.

### Case / Strategist (Deepa), weight 4

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "An operator's planning team says the tool doesn't fit how they re-plan after disruption. Where do you start?" | CASE | [generic] | Clarify which disruption, which team and what they re-plan with today. Then segment the operators by their planning set-up, the approach, the metric the operator already reports, and the main risk. Make no claim about your past. | A live problem from the recruiter's "operators" line; generic because it is a pattern, not a fact about this employer. |
| A2 | "What is the one operator-side pressure you would build the next 18 months around?" | CASE | [generic] | Pick one, say why it beats the other two, and name what would change your mind. Use the market report's own language if it differs, once you have checked it. | Tests altitude and a clear choice. No strategy was researched, so the content stays generic. |
| A3 | "What would your first 90 days look like with our operator partnerships?" | JD | [grounded] "where you'd take our operator partnerships over the next 18 months" | A plan, not a past: the first three operator conversations, what you would listen for, and one measure you would set. | Scores the recruiter's stated scope. Future-tense, so it asks for no claim about your history. |
| A4 | "How would you know after a year that operator partnerships are working for the operators?" | JD | [grounded] "Please land on what it means for the operators themselves." | Name two operator-side measures before any commercial one. Say which you would measure first. Do not claim to have measured anything. | Scores the recruiter's close requirement; this is where the POV has to land. |

### Skeptic (Deepa), weight 3

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "What would you get wrong first in this job?" | JD | [grounded] "Never sold into rail specifically" | Name one thing you expect to get wrong and how you would find out. Do not name a rail sale or a past mistake. | Opens F2 without you choosing the framing; the answer should be a plan. |
| B2 | "Why should an operator's planning team trust a partnership plan from someone who has never sold into rail?" | JD | [grounded] "Never sold into rail specifically"; [grounded] "so I know the operator world from the other side" | **Highest-ROI prep in this pack.** Hold: "I haven't sold into rail specifically." Then the planning-side sentence at its own scope, and the limit said plainly: the operator world you know is the planning side. Hold through two follow-ups by returning to the channel and the plan. Concede specifically: the operator should not trust the plan on your word; name the first two conversations that would test it. Never claim operator advice or rail sales. | F2 is the objection most likely to arrive in some form, and the material is thinnest exactly there. The hold is only what you stated. |
| B3 | "What part of this job are you least sure you can do on day one?" | JD | [grounded] "never carried a direct quota" | Plain acknowledgment: "I've never carried a direct quota." Then what you would need to learn about owning a number, as a plan. Do not describe a sales track record. | F3's stated limit, rehearsed so the honest answer is ready before the probe. |

### Pressure (Ross), weight 5

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "£4M of influenced revenue. How much of that was yours?" | EXP | [grounded] "roughly £4M of influenced revenue" | Answer slot: say how the £4M was counted, what it is sensitive to, the assumption you would defend least, and which part was yours, in your own words. If no share was yours to claim, say so and say what you did influence. Hold through two follow-ups. Do not add a sizing method. | F3's headline figure; the most likely place for Ross to push. |
| C2 | "You've never carried a quota. Why should I trust a commercial forecast from you?" | JD | [grounded] "never carried a direct quota" | Plain acknowledgment: "I've never carried a direct quota." Then how you would build a forecast, as a plan: the price book, the pipeline stages, the operator's budget cycle. Hold two follow-ups. Concede the parts you would need help with. | F3's stated limit under pressure; hold-then-concede. |
| C3 | "Give me the commercial case for operator partnerships in sixty seconds." | CO | [grounded] "Ross will push on commercials." | Budget line first, price mechanism second, risk third. Sixty seconds. Use no revenue figure you cannot defend. The mechanics are generic; say so if asked. | The recruiter's own warning about commercials. |
| C4 | "Forty partners. Whose number is that?" | EXP | [grounded] "took it from 6 partners to 40" | Answer slot: say which decisions and which work were yours, in your own words, and what the team did. Do not claim the whole 40. If you cannot separate them, say so and say what you can separate. | Attribution under pressure; the second headline number. |
| C5 | "An operator wants a 30-month payback before they sign. What do you do in the room?" | CASE | [generic] | Hold the payback in the operator's own terms. Name what you would need from their finance team. Do not concede price before you know their budget line. | A live commercial problem; generic, and labelled as a pattern. |

### Data-Driven Prober (Ross), weight 4

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "How did you count a partner as active?" | EXP | [grounded] "took it from 6 partners to 40" | Answer slot: say how you counted, and if you did not define "active", say so. Name the assumption you would defend least. Do not supply a definition you did not use. | The counting question for the second headline number. |
| D2 | "Which assumption behind the £4M would you defend least?" | EXP | [grounded] "roughly £4M of influenced revenue" | Answer slot: name it in your own words. If you do not know how it was counted, say that plainly. | The weakest-assumption move for F3. |
| D3 | "What would change your mind about operator partnerships in 18 months?" | CASE | [generic] | Name the weakest assumption in your own POV, which is usually the Thesis 1 concession. Say what evidence would move you. | The Prober's usual close to a POV; a rehearsal, not a claim. |
| D4 | "Of your 9 years in partnerships, which part involved any operator, and in what role?" | EXP | [grounded] "9 years in partnerships"; [grounded] "so I know the operator world from the other side" | Answer slot: if an operator was involved in any of those years, say which and your role. If none was, say so and stay with the planning side. | F1 and F4 together. The question asks which, and the honest answer may be none. |

### Conversational (both), weight 2

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "9 years in partnerships"; [grounded] "running the ISV channel"; [grounded] "5 years in transport consulting" | A 90-second arc in three sentences, each from a quote, in your words. Add nothing. Close on the planning-side sentence. | An opener that is scored. Casual register is still a score. |
| E2 | "What are you most curious about in our operator base?" | JD | [grounded] "where you'd take our operator partnerships over the next 18 months" | Name one operator-side unknown and how you would find it out. | Shows you thought about operators, not just the company. |

**Coverage.** Each headline number has a defend-the-number question (C1, C4, D1, D2). The rail gap has its objection (B2) and two supporting questions (B1, B3). The commercials line has four (C2, C3, C5, D3).

**Requirement coverage**

| Requirement | Questions |
|---|---|
| "operator partnerships over the next 18 months" (recruiter) | POV, A1, A2, A3, E2 |
| "what it means for the operators themselves" (recruiter) | POV close, A4, D4 |
| "Ross will push on commercials" (recruiter) | C1, C2, C3, C5, D2, D3 |
| Sell to train operating companies (your description) | B1, B2, B3, C2 |
| Operator-side knowledge (F4) | B2, D4, E1 |
| Any job-description requirement | none, and why: no job description was supplied, so no further requirements are listed. |

## 7. Reverse questions

Each has a reason it lands. Deepa and Ross are both on the panel, so each question is aimed at one of them.

1. **For Deepa:** "What would you need from me in the first 90 days that you aren't getting now?" Why it lands: it shows you plan to be managed well, and it surfaces what she wants from the hire.
2. **For Deepa:** "Which operator conversation do you wish the team had had earlier?" Why it lands: it names a live problem and invites her to describe it.
3. **For Deepa:** "Where did the last partnerships hire stall, and what did they lack?" Why it lands: it shows you are assessing the job honestly, and the answer tells you what the panel is screening for.
4. **For Ross:** "Which commercial trade-off would you accept to land a first operator, and which are off the table?" Why it lands: it draws out his commercial line directly.
5. **For Ross:** "How do partnerships and commercial split an operator deal today?" Why it lands: it shows you care about the working seam between the two teams.
6. **For both:** "What would a strong first year look like, measured by someone at an operator?" Why it lands: it ties the question to the operator close of your POV.

## 8. Sources

No provided documents beyond your message and the recruiter's quoted lines. The market report the recruiter attached is not in this conversation; it was read by you and not pasted.

Every search below was sent, and each was refused by the session's permission gate. Nothing was returned.

- `Kelverton Rail values`: refused
- `Kelverton Rail interview process partnerships`: refused
- `Kelverton Rail strategy news`: refused

**Research tier:** L1 — searches 3 of 6, fetches 0 of 2 (all 3 refused). User links read: none.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Kelverton Rail values` | unavailable | Values cheat sheet: not built. The search was refused, so values are not established. |
| 2. `Kelverton Rail interview process` | unavailable | Loop structure. The recruiter's email establishes this session as one panel of 60 minutes with a 15-minute POV, so the loop is set by the source, not by an archetype. Persona weights therefore rest on the panel's own shape. |
| 3. `Kelverton Rail strategy` / recent news | unavailable | Strategy-tier CO questions: generic. The market report would move these, and it is not in this conversation. |
| 4. `Deepa` / `Ross` at Kelverton Rail | unavailable | Interviewer read: dropped. A search would have produced public footprint for both. |
| 5. Representative senior partnerships JD | unavailable | Fit snapshot: no job description was supplied, so requirements come from the recruiter's quoted lines only. |

## 9. Upgrade menu

- **Job description text** → the requirement rows in section 2 become quoted job-description lines, and the coverage table lists each one. It also shows any location, travel or pay gate, which the material does not settle yet.
- **The market report's headline sections, pasted** → the consensus answer is named, so the anti-picks in section 5 are checked against it, not guessed. The CO questions get real strategy language.
- **Web search allowed** → values, the interview process and strategy can be researched. The three targets above would then read `yes`.
- **Your transport-consulting clients, operators or authorities** → changes how F4 is bridged. If operators were among them, the operator-side sentence can be quoted at a wider scope.
- **Public footprint for Deepa and Ross** → personal persona weights, and reverse questions tied to their own paths.
