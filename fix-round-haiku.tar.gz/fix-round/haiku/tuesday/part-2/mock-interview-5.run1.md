Your prep pack is saved as /tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-tuesday-part-2-rooms-case-5-denied-1a8f9333/8247d8cb-9775-4da0-8fc7-5705e045eedf/scratchpad/kelverton_rail_senior_partnerships_manager_interview_pack.md, and I've attached it here. I built it for the panel as your recruiter described it: Deepa as the hiring manager and Ross as the commercial challenge.

Web search was refused in this session, so the pack has no company values, no strategy brief and no read on either interviewer. The Sources section lists each refused call. Your internal market report isn't in the conversation either, so the POV has no differentiation from it yet.

The POV is the spine of the prep. I'd build it on the planning-job thesis (T2) and use the channel-scale thesis (T1) as the commercial hook. Rehearse the £4M attribution answer (B2) hardest, since the pack names it as the highest-return prep.

Offers, not pushed:
- Say the word and I'll play Ross on B2, the £4M question.
- I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
- If you'd like the pack as a Word document, say so and I'll convert it.

Two things would change the pack:
1. Can you paste the top recommendations from the market report? That lets me mark which one to concede as consensus in the POV.
2. Does the posting or the recruiter's email mention location, travel or right to work for this role? The pack can't establish these yet.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: kelverton_rail_senior_partnerships_manager_interview_pack.md -----
# Interview prep pack: Senior Partnerships Manager, Kelverton Rail

**Round:** second round, panel, 60 minutes. First 15 minutes: a short spoken point of view (no slides) on where to take operator partnerships over the next 18 months, landing on what it means for the operators themselves. Remaining time: Q&A, with Ross pushing on commercials.
**Panel:** Deepa, VP Partnerships (future manager, hiring-manager relationship). Ross, Commercial Director (commercial challenge).
**Interviewer read:** not built. No public footprint was checked (search was refused, see Sources). Persona weights below come from the round's structure and the recruiter's words, not from either person's background.

## How to use + type key

Personas describe how a question arrives. Types describe what it scores. Guidance is scaffolding, not a script: say it in your own words, and stop where the guidance stops.

| Type | Meaning |
|---|---|
| VAL | Behavioral and values alignment |
| EXP | Deep-dive on your own work: what was actually yours |
| JD | Role-driven: can you do what the role needs, gaps included |
| CO | Company and strategy knowledge (not testable from this pack; no research ran) |
| CASE | Live problem from the role, reasoned out loud |

## Prep triage (about four hours)

1. **About 75 minutes: the POV.** Use thesis T2 as the spine and T1 as the commercial hook (see section 5). Write it as three beats, not a script. Speak it aloud twice against a timer. Target 15 minutes, not 12, not 20.
2. **About 60 minutes: Ross.** Rehearse B2 first (the £4M attribution question), then B1 and B3. The goal is answers you can repeat under a second and third question without adding anything.
3. **About 40 minutes: Deepa.** A2 (the rail gap) and A3 (the channel walk-through), then A1 and A4.
4. **About 20 minutes: reverse questions.** Pick two from the list and say them aloud until they sound like your own.

Everything else is insurance.

## 1. Fit snapshot

Requirements come from the recruiter's words, quoted from your pasted email, since no job description was supplied. Every evidence cell is your own sentence, quoted.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "our operator partnerships" (recruiter email) | "took it from 6 partners to 40" (your message) | medium | [grounded] | transferability | Your material shows a partner channel at a payments company, not operator partnerships. The words stay at that scope: "I took the channel from six partners to forty." Answer slot: if you set partner terms or selection criteria, say which and how you decided; if you did not, say so and stay with the scale. |
| F2 | "Ross will push on commercials" (recruiter email) | "roughly £4M of influenced revenue" (your message); "never carried a direct quota" (your message) | medium | [grounded] | transferability | Influenced revenue is adjacent to a revenue number you owned, and the material does not say you owned one. Words: "The channel had roughly £4M of influenced revenue." Limit, in your words: "I haven't carried a direct quota." Answer slot: how that figure was counted and which part was yours. |
| F3 | "what it means for the operators themselves" (recruiter email) | "bus and light rail network planning" (your message); "I know the operator world from the other side" (your message) | medium | [grounded] | transferability | Your planning work is close to the operator's job, but your message does not say which side your clients were on. Words: "Before payments I spent five years in transport consulting, on bus and light rail network planning." Answer slot: name the client side only if you can, in your own words. |
| F4 | selling into rail operators (recruiter email: "operator partnerships") | "Never sold into rail specifically" (your message) | none | [grounded] | capability | You stated this absence yourself. Words: "I haven't sold into rail." Then a plan, not a past: how you would learn operator buying in your first months. |
| F5 | location, travel, right to work (role-family, no source) | none given | none | [generic] | hard_gate | Your material does not establish any of these for this role, and no job description was supplied. One question in the presenting message asks about them. |

## 2. Prohibited claims

Built locally from the fit snapshot. These are the claims a candidate reaches for under pressure in this round. None of them is coached.

| Not coached | Basis | Honest form |
|---|---|---|
| "I drove £4M of revenue" or "I owned the revenue" | Inflated form of F2 | "roughly £4M of influenced revenue," at its own scope. The pack's observation, not words for you: your material says influenced, not owned. |
| "I carried a quota" or "I hit targets" | Negative you stated, F2 | "I haven't carried a direct quota." |
| "I sold into rail" or "I have rail operator relationships" | Negative you stated, F4 | "I haven't sold into rail." |
| "I designed the partner programme" or "I built the channel strategy" | Inflated form of F1 | "I took the channel from six partners to forty," with the decisions you made named and no others. |
| "I know how operators buy" or "I know operator procurement" | Inflated form of F3 | "I spent five years on bus and light rail network planning." Nothing about procurement. |
| "I worked for an operator" | Relationship not stated in your material (F3) | The planning work as you described it. Name a client side only if it is true and you can name it. |

## 3. Persona table

| Persona | Panel member | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|---|
| Case/Strategist | Deepa | Live problems on the operator side of the role | High. A hiring manager buys capability, and the POV already invites a strategy conversation. | Clarify first, then structure, then name one metric you would watch. |
| Skeptic | Deepa | "Why you, with no rail sales?" | High. F4 is the largest gap in the material. | Hold the fact in one sentence, then bridge only from quotes. Concede the rest. |
| Pressure | Ross | Interrupts, time-boxes, questions the number | High. The recruiter wrote that Ross will push on commercials; executive-level interviews lean this way. | Pause, restate the question, hold a position through two follow-ups before conceding anything real. |
| Data-driven Prober | Ross | "How was that counted?" "Which assumption would you defend least?" | High. The £4M figure is the magnet, and the material does not show how it was counted. | Say how you know what you know. "I don't know how it was counted" is an honest answer. |

Weights: Deepa's and Ross's relationships each get the top two personas for their role, blended in the panel. Ross's Pressure weight is slightly higher, because the recruiter named commercials specifically.

## 4. Question banks

Question types are as in the key above. Depth follows weight. The pack is short of its usual 18 to 26 questions because no job description was supplied, so the JD-tagged questions could not be written. The upgrade menu says what adds them.

### Deepa (Case/Strategist, then Skeptic)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Your first ninety days: what would you look at first across our operator partnerships?" | CASE | [grounded] "our operator partnerships" (recruiter email) | Clarify before answering: which operators, which partners, and what "working" would mean. Name the one thing you would look at first and why, and what would change your mind. About 90 seconds, spoken. | The POV's natural follow-up. Asks about your plan, not your past, so the guidance makes no claim about your history. |
| A2 | "You've never sold into rail. Why would an operator take a call from you?" | JD | [grounded] "Never sold into rail specifically" (your message) | Highest-weight Skeptic item. Hold the fact in one sentence: "I haven't sold into rail." Then say what your two quoted sentences give an operator conversation, in your own words, and stop there. Answer slot: if you have been in an operator conversation about planning or timetables, say what it was; if you have not, say so, and describe how you would learn the operator's planning work in your first month. Hold through two follow-ups by returning to the planning work, never by adding to it. | F4 is the capability gap, and this is where a hiring manager tests it. Rehearsed so the plain answer is ready before the probe. |
| A3 | "Walk me through how you took the channel from six partners to forty." | EXP | [grounded] "took it from 6 partners to 40" (your message) | Tell the scale-up in the order it happened, using only decisions you made. Answer slot: which of partner selection, partner terms or partner enablement were yours to set; if any were not, say so and stay with the scale. Never describe a mechanism you did not run. | F1 is the transferability gap, and a channel number is the first thing a hiring manager probes. |
| A4 | "An operator's planner tells you the scheduling tool can't represent how their network actually runs. What do you do?" | CASE | [generic] | Separate the configuration problem from the operating constraint. Bring the product and the planning team into one conversation. Do not promise a fix in the room. No claim about your past. | An operator-side problem in the role's own terms. [generic] because it is a pattern for the problem, not a fact about this employer. |
| A5 | "Where would your planning background make you a worse partnerships manager?" | JD | [grounded] "bus and light rail network planning" (your message) | Name one honest limit: a planner's view can under-weight the commercial buyer. Say it in your own words, then say what you would do about it. Do not claim the limit is already solved. | F3 is transferability. A Skeptic asks for the limit before you offer it, so offering it first lands better. |

### Ross (Pressure, then Data-driven Prober)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Sixty seconds: what does roughly £4M of influenced revenue actually prove?" | EXP | [grounded] "roughly £4M of influenced revenue" (your message) | Hold the figure as you stated it: "influenced" is the word. Say in your own words what influenced means here, and concede plainly that influenced is not owned. Say what you would need to see to own it. Hold through two follow-ups. Do not fold on the core claim that the channel was connected to that revenue unless you can show how. | F2. Ross will press the commercial claim first, and a held position that stays inside the quote is the one that survives the second follow-up. |
| B2 | "Of that roughly £4M, how much would you say was yours?" | EXP | [grounded] "roughly £4M of influenced revenue" (your message); [grounded] "took it from 6 partners to 40" (your message) | **Highest-ROI prep in this pack.** Answer slot: say how the figure was counted, the assumption behind it you would defend least, and which part was yours. If you cannot say how it was counted, say so plainly, then return to the two quoted sentences at their own scope. The pack does not supply a counting method, a baseline or a share. | This is where a prober will go, and where the material is thinnest. A rehearsed honest answer is worth more than a confident one you cannot repeat under a second question. |
| B3 | "You've never carried a direct quota. What would you commit to in year one?" | JD | [grounded] "never carried a direct quota" (your message) | Plain acknowledgment first: "I haven't carried a direct quota." Then say what you would need to see before committing to any number, in your own words. Do not name a figure in the room that you have not built. | F2 quota gap. The honest answer is a method and a list of inputs, not a number. |
| B4 | "Partner-sourced revenue has been flat for two quarters. Where do you start?" | CASE | [generic] | Clarify what flat is measured against. Split by operator, by partner and by product. Separate pipeline timing from lost deals. No claim about the company or your past. | A commercial case in the role's own terms. [generic] because it is a pattern, not a fact about Kelverton. |
| B5 | "Why would an operator pay for a scheduling change now rather than next year?" | CASE | [generic] | Name the operator's economics: what the change costs them to make, what it protects, and who signs. Keep it to categories. Do not supply company specifics. | Links the POV's operator close to Ross's commercial line. [generic] for the same reason as B4. |

**Coverage:** the recruiter's "operator partnerships" is covered by A1, A2, A4 and the POV. "Ross will push on commercials" is covered by B1 to B4. "What it means for the operators themselves" is covered by B5 and the POV's close. No job description was supplied, so no JD-tagged coverage can be checked.

## 5. Graded deliverable: the 15-minute point of view

The recruiter pre-declared this deliverable: a short spoken point of view on operator partnerships over 18 months, no slides, landing on what it means for the operators. Build it from the three grounded facts below.

**Grounded facts to build on:**
- F1: "took it from 6 partners to 40" (your message)
- F3: "bus and light rail network planning" (your message)
- F2: "roughly £4M of influenced revenue" (your message)

**Theses, each with a mandatory concession:**

- **T2 (spine): design the partnership around the planning job the operator already has**, so the software sits inside that work rather than beside it. Grounded in F3. *Concession:* I don't know an operator's planning tools or constraints beyond the planning work I did before payments. I would test this with two or three operators before I committed to it.
- **T1 (commercial hook): judge operator partnerships on what the operator's planners can do with them, not on partner count.** Grounded in F1. The number you would naturally reach for is the one this thesis argues against. *Concession:* partner count did matter in the payments channel, and I have not sold into rail. I am reasoning from the channel and from planning work, not from how operators buy.
- **T3 (anti-pick): stop treating partner-influenced revenue as the partnership's score, and say what you would measure instead.** Grounded in F2. The anti-pick is saying no to signing a partner on a revenue target alone when the operator outcome is not there. *Concession:* Ross needs a revenue line. If the replacement measure cannot be tied to revenue within a year, this thesis costs you credibility with the commercial plan.

**Differentiation:** the internal market report's shortlist is not in this pack, so the pack cannot tell consensus items from divergences. Do not recite the report. Once you paste its shortlist, the pack will mark which item to concede as consensus and which of T1 to T3 departs from it, with reasons.

**Requested close:** each thesis ends on one operator outcome, stated as what a planner or a controller would experience. Keep it to what the material carries. [generic]: the operator's experience is a pattern, not a fact about the operators you will meet.

**Current facts:** if you mention the current structure of UK rail, check it against a current source first. Nothing about it is in the material, and nothing here has been verified.

**Timing (15 minutes):** 2 minutes on the operator's problem; 5 minutes on T2; 3 minutes on T1; 3 minutes on T3 with its concession; 2 minutes on what it means for operators. Speak from three beats. Do not read.

## 6. Reverse questions

Each one has a reason it lands.

1. "Which operator relationship would you most want me to understand in my first month, and why?" Why it lands: it signals an operator focus, and the answer tells you where the partnerships are thinnest.
2. "How is partner-sourced revenue currently counted against the commercial plan?" Why it lands: it prepares the attribution answer before Ross gives his version, and shows you care how the number is built.
3. "Where has the team had to say no to an operator, and what happened?" Why it lands: it invites the honest version of T3's anti-pick, and tests whether the team says no at all.
4. "What does a win with an operator look like at twelve months: a contract, usage, or a planning outcome?" Why it lands: it asks the commercial question in operator terms, which is the close the recruiter asked for.
5. "What is the one thing the last person in this role got wrong?" Why it lands: a direct question that rewards a direct answer, and it reveals how the team handles mistakes.

Not included: an interviewer-path question. There is no interviewer read, because no public footprint was checked. The upgrade menu says what it would add.

## 7. Sources

**Provided documents:** the recruiter's email, as pasted in the request (quoted above). The internal market report was not in the conversation, so nothing in this pack is drawn from it. Your background, as stated in the request.

**Searches and fetches sent:**
- "Kelverton Rail scheduling software train operators": refused, permission to use web search not granted.
- "Kelverton Rail values strategy partnerships": refused, permission to use web search not granted.
- "Deepa VP Partnerships Kelverton Rail": refused, permission to use web search not granted.

No fetches were sent.

**Research tier:** L1, searches 3 of 6, fetches 0 of 2. No user links read.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Kelverton Rail values | unavailable | Refused (queries 2 and 1). The values cheat sheet is not in the pack, and no values-style round was detected. |
| 2. Interview process, role family | skipped | The recruiter's email fixes the round's format (panel, 60 minutes, POV first, Q&A). No search was sent for it. |
| 3. Strategy and recent news | unavailable | Refused (queries 1 and 2). The grounding brief is not in the pack. Your internal market report would have moved it, if pasted. |
| 4. Interviewer names, Deepa and Ross | unavailable | Refused (query 3). Without it, there is no interviewer read and no tied reverse question. |
| 5. Representative job description | unavailable | No job description was supplied, and no search was sent. A representative JD would have made the fit-snapshot requirements quoted rather than recruiter-sourced. |

## Upgrade menu

- The internal market report's shortlist, pasted → the POV's differentiation: one consensus item to concede, and each of T1 to T3 checked against it.
- The job description → F1 to F5 move from recruiter quotes to job-description quotes, the gate row becomes checkable, and JD-tagged questions get written.
- Permission for web search → the L1 pass (company values, interview process, the public profiles of Deepa and Ross) → an interviewer read, sharper persona weights, and a reverse question tied to Deepa's path.
- How the £4M was counted and which part was yours, in your own words → the answer slot in B2 becomes a rehearsed answer, if you can repeat it under a second question.
- Which side your consulting clients were on → settles the "other side" wording in F3 and the relationship entry in the prohibited claims.
