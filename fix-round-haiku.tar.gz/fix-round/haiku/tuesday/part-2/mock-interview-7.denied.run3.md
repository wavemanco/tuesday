Your prep pack is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-tuesday-part-2-rooms-case-7-denied-489812e9/6eca782f-d0af-40c1-a3a3-94e02280df9e/scratchpad/saltmarsh_live-ops-producer_interview_pack.md`. I built it for a hiring-manager round, since your note didn't say who you're meeting.

**Web search was refused in this session**, so I couldn't check Saltmarsh's values, interview process, recent strategy, or Tobias's public background. The pack is built only from your JD and your background. Anything about Saltmarsh itself is labelled generic.

**Prep in priority order:**

1. **Rehearse the objection you'll almost certainly get: "why should we trust you with two titles when you've never led a team?"** (question B1). Your honest answer is that you haven't led a team, and that you coordinated across QA through the release checklist. Hold that position through two follow-ups, then concede the gap specifically. Don't claim leadership. This is the highest-value prep in the pack.
2. **Know the two-titles gap.** You ran one title's weekly content-drop calendar for two years. Concede that plainly, then name what transfers: the cadence and the checklist.
3. **Have a plan for in-app purchases, not a claim.** Say "I haven't worked on a game with in-app purchases," then describe what you'd learn first: pricing, store review, purchase-flow QA, refund rules.
4. **Be precise about retention.** You presented the monthly numbers to the studio head. Be ready to say what you chose, calculated, or only presented, and which assumption you'd defend least. Don't let "presented" become "analysed" under pressure.
5. **Have an approach for the post-event review and the KPIs.** You don't have a post-event review in your material. If you didn't run one, say so and describe how you'd build one.

The pack has 18 questions across six interviewer styles. Its reverse questions are in the file. Read the watch-out line below before you rehearse.

**Two questions for you:**

- Is Tobias your future manager, and is this a one-to-one? Has the recruiter mentioned any focus areas or a take-home?
- Was your puzzle title a mobile game, and was it live-service (ongoing events, paid or free)? The JD asks for 3+ years of live-service experience, and I can't tell from your message whether your years count.

If you want the research pass, grant web search and I'll rerun it. That would add Saltmarsh's values, a loop-structure check, and a pass on Tobias's public background.

I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh_live-ops-producer_interview_pack.md -----
# Interview prep pack: Live Operations Producer, Saltmarsh Games

Interviewer: Tobias Wrenfield, Head of Live Operations. Relationship assumed to be hiring manager (your note didn't say; see the questions in the message).
Research tier: L0. Web search was refused in this session, so company values, loop structure and strategy are not established. Everything about Saltmarsh below is `[generic]` or from your JD.

## How to use this pack

- **Personas** = how a question is asked. **Types** = what is being scored.
- Type key: **VAL** behavioural/values · **EXP** work-experience deep-dive · **JD** role/JD-driven · **CO** company knowledge · **CASE** live problem.
- Guidance is scaffolding, not a script. Speak each answer in 90 to 120 seconds, and rehearse only what you actually did.

## Fit snapshot

Your material, quoted verbatim, against the JD.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | "For two years I ran the weekly content-drop calendar for our main title." Your material says one title and content drops, not two titles or live events. Answer slot: if you planned for more than one title, or ran events beyond content drops, say what and how; if not, say so and say how you would take on the second title. |
| F2 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | high | [grounded] | none | "For two years I ran the weekly content-drop calendar for our main title." Lead with the calendar, the cadence and the duration, in those terms. |
| F3 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | presentation | "I presented the monthly retention numbers to the studio head." The quote reaches retention in other terms but does not show analysis. Answer slot (defend-the-number): if you chose or calculated those numbers, say how and which assumption you would defend least; if not, say so. |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses" — your message | high | [grounded] | none | "I wrote the release checklist our QA team still uses." |
| F5 | "own the post-event review and the KPIs it reports" — JD | none given | none | [grounded] | discovery | Your material does not show a post-event review. Answer slot: if you ran one, say what it covered and which KPIs it reported; if none was yours, say so and describe how you would build one. |
| F6 | "coordinate design, art, engineering and community teams on each update" — JD | "Wrote the release checklist our QA team still uses" — your message | low | [grounded] | discovery | Your material shows QA only, not coordination with design, art, engineering or community. Answer slot: name any multi-team update you ran, the teams, and your part; if none, say so. |
| F7 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio" — your message | medium | [grounded] | discovery | The years are stated; whether the puzzle game was live-service is not. Answer slot: say what ran live (events, drops, retention tuning) and what did not; if you are unsure the title counts as live-service, say so. |
| F8 | "A live mobile title's economy runs on in-app purchases" — `[inferred]` from the JD's mobile-title context; not in the JD's words | "never worked on a game with in-app purchases" — your message | none | [grounded] | capability | "I haven't worked on a game with in-app purchases." Then how you would learn it, said as a plan and never as a past. |
| F9 | "coordinate design, art, engineering and community teams" — JD; leading a team is `[inferred]`, the JD says coordinate | "Never led a team" — your message | none | [grounded] | capability | "I haven't led a team." Then the cross-team coordination you did, in your own words. |

Gap types: `capability` = you stated the absence. `discovery` = the material is silent. `transferability` = adjacent work that does not fully reach the requirement. `presentation` = a quote that reaches the requirement in other terms.

## Prohibited claims

Not coached, in any answer, slot or hold.

| Not coached | Basis | Honest form |
|---|---|---|
| Ran live events across two titles | Inflated form of F1 | The F1 quote at its own scope. Observation, in analysis only: your material says one title and content drops. |
| Ran the release process with QA | Inflated form of F4 | "I wrote the release checklist our QA team still uses." |
| Analysed the retention numbers | Inflated form of F3 | "I presented the monthly retention numbers to the studio head." Observation: the material shows presenting. |
| Shipped live-service products | Inflated form of F7 | The F7 quote only. |
| Has worked on in-app purchases | Negative you stated, F8 | "I haven't worked on a game with in-app purchases." No slot. |
| Has led a team | Negative you stated, F9 | "I haven't led a team." No slot. |

## Persona weights

| Persona | How it shows up | Weight | Reasoning | Counter-strategy |
|---|---|---|---|---|
| Case / Strategist | Live problems on the calendar, diagnosis, two-title plan | 5 (top) | Hiring-manager prior; the JD is an operating list; no interviewer profile to adjust it | Clarify → objective → segmentation → approach → metrics → risks; say the framework aloud |
| Skeptic | "Why should we trust you with this?" | 3 | Hiring-manager prior; F8 and F9 are the stated gaps | Rehearse the single most predictable objection until it is boring (B1) |
| Data-Driven Prober | "Walk me through how that was counted" | 3 | Retention and calendar claims are read closely | Name the assumption you would defend least; say plainly what you do not know |
| Pressure / Stress | Sixty-second challenges, "how much of that was you" | 3 | Mid prior for a hiring manager testing composure on the gaps | Pause, restate, hold through two follow-ups, then concede specifically |
| Values / Behavioural | Open prompts on pushback and hard decisions | 2 | No values round is detected: no loop source was read | Honest branch in every story slot |
| Conversational | Casual opener, casual "what are you playing?" | 2 | Rapport openers are still scored | Pre-scripted 90-second arc; treat casual questions as scored |
| Peer Evaluator | — | 0 | Not plausible for a hiring-manager round | — |

Interviewer read: omitted. You gave a name and title only, and no public profile was read.

## Question banks

### A. Case / Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Two titles, one calendar. Where would you start in your first 90 days?" | CASE | [generic] | Clarify first: which title is furthest from its goals, what the next six weeks of drops are, and who owns each. Then objective → segmentation → approach → metrics → risks. | Tests the JD's first duty. No claim about your past, so none is made. |
| A2 | "A content drop finished two points under its retention target in week one. Diagnose it." | CASE | [generic] | Clarify: which cohort, what the target assumed, what changed in the drop. Split by cohort (new vs returning) and by content, then name the metric you would check first. | A live problem from the JD's KPI duty, asked as a diagnosis rather than a record. |
| A3 | "What would a post-event review of one of our updates contain, and which KPIs would it report?" | JD | [grounded] "own the post-event review and the KPIs it reports" — JD | Lay out the review's structure first: the decision it serves, the KPIs, the owner, the date. Answer slot: if you ran a post-event review, say what it covered and which KPIs it reported; if none was yours, say so plainly and describe how you would build one. | F5 has no quote, so the answer slot is the honest branch. |
| A4 | "Design, art, engineering and community all touch each update. How do you run that?" | JD | [grounded] "coordinate design, art, engineering and community teams on each update" — JD | Describe a sequence: scope lock, dependencies, sign-off gates, one owner per decision. That is your approach, not your history. Answer slot: if you ran a multi-team update, name the teams and your part; if not, say so. | F6 is low confidence, so this answer stays with approach. |
| A5 | "You're bringing a paid bundle to a title you haven't monetised before. What changes in your plan?" | CASE | [grounded] "never worked on a game with in-app purchases" — your message | Say the plain acknowledgment: "I haven't worked on a game with in-app purchases." Then what you would learn first: pricing, store review, purchase-flow QA, refund rules, and who owns the economy. | F8 is the stated gap. This tests whether you can plan around it without claiming it. |

### B. Skeptic (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | **Highest-ROI prep.** "Most of this job is coordinating teams you don't manage. Why should we trust you with two titles when you've never led a team?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases" — your message | Hold the position through two follow-ups by describing the cross-team work you did: "I wrote the release checklist our QA team still uses." Answer slot: name the cross-team work and your part in it, in your own words; if you had no authority over the people involved, say so. Concede specifically: "I haven't led a team, and that's the part I'd watch closest." Do not claim leadership. | F9 is the largest gap, and the JD's coordinate line raises it. This is the most likely objection in some form, so it gets the deepest rehearsal: name the concession before you are asked for it. |
| B2 | "Your material shows one title. What makes you ready for two?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" — your message | Concede the one-title fact plainly. Name what transfers: the weekly cadence and the checklist. Answer slot: if you planned for more than one title or ran events beyond content drops, say what; if not, say how you would take on the second title. | F1's transferability gap. |
| B3 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "never worked on a game with in-app purchases" — your message | Name in-app purchases as the honest weakest area: "I haven't worked on a game with in-app purchases." Then your learning plan. Do not offer a second area you cannot back. | A plain acknowledgment of F8. The question asks for your own weak spot, so the honest answer is the stated gap. |

### C. Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through the retention numbers you presented to the studio head: where they came from, and which assumption you'd defend least." | EXP | [grounded] "Presented the monthly retention numbers to the studio head" — your message | Defend-the-number slots: how the figure was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. Answer slot: if you did this, say how, in your own words; if there was no such step, or it was not yours, say so plainly and return to: "I presented the monthly retention numbers to the studio head." | F3's presentation gap. The Prober wants the source, which the material does not show. |
| C2 | "Your release checklist: how did you decide what went on it?" | EXP | [grounded] "Wrote the release checklist our QA team still uses" — your message | Say what you wrote and how QA used it. Answer slot: if you chose what went on it, say how; if the contents were set by others, say so plainly. Do not claim sign-off authority. | F4 is strong; the probe tests authorship. |
| C3 | "Over the two years, how did you know a weekly drop had gone well?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" — your message | Answer slot: if you measured drops, say what and how; if you did not, say so and say what you would measure. | The pre-cursor to the post-event review in F5. |

### D. Pressure / Stress (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why should we hire you over an internal candidate who has live-ops experience?" | JD | [generic] | Pause; restate the question; anchor in what you did: a two-year calendar and a checklist QA still uses. Hold through two follow-ups. Concede where it is true: "On live-service years, they would probably start ahead of me." | A pressure stem on the F7 and F9 gaps. |
| D2 | "That retention result: how much of it was actually you?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" — your message | Hold: "I presented them." Answer slot: say which part was yours; if others produced the figures, say so plainly. Never let "presented" become "analysed" under pressure. | Hold-then-concede on F3. |
| D3 | "Presenting numbers isn't owning a KPI. Why would you own one here?" | JD | [grounded] "Presented the monthly retention numbers to the studio head" — your message | Hold: "Presenting is what I've done." Concede specifically: owning a KPI is new to you. Name the first step: agree the KPI's definition with the title's product owner before reporting it. That is a plan, not a past. | Tests the KPI duty against F3 without a claim. |

### E. Values / Behavioural (weight 2)

No values round is detected, because no loop source was read. These are open prompts with a selection scaffold.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Tell me about a time you pushed back on a plan from a team you didn't run." | VAL | [generic] | Pick a time you disagreed with another team's plan. It needs a named stake, what you said, and how it ended. Answer slot: if no such time comes to mind, say so plainly, then give the nearest thing your material carries: the checklist work, and only what you did in it. | An open prompt on the Values theme. No event is supplied. |
| E2 | "Tell me about a decision you made that a team didn't like." | VAL | [generic] | The same scaffold, with one test: the hard truth landed. Answer slot: if you cannot name one, say so and give the nearest thing your material carries. | Second open prompt; low weight. |

### F. Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So — walk me through the journey." | CONV | [grounded] "4 years as an associate producer at a puzzle-game studio" — your message; "I ran the weekly content-drop calendar for our main title for the last two years" — your message | A 90-second arc: four years at the puzzle studio, two of them running the weekly content-drop calendar, the checklist QA still uses, the retention numbers you presented. Each beat is one of your quoted clauses, nothing more. | Rapport opener, scored in a casual register. |
| F2 | "What are you actually playing in live-ops these days?" | CONV | [generic] | Name a live title you play and what its drop cadence feels like to you. If you do not play, say so. Do not invent a favourite. | A casual question on the JD's domain; it is scored. |

Count: 18 questions (A 5, B 3, C 3, D 3, E 2, F 2).

## Requirement coverage

| JD requirement | Covered by | Note |
|---|---|---|
| Plan and run the live-events calendar for two titles | A1, B2 | |
| Coordinate design, art, engineering and community on each update | A4, B1 | |
| Own the post-event review and the KPIs it reports | A3, C3, D3 | |
| Manage the release checklist with QA | C2 | |
| 3+ years producing live-service games or apps | F1 (quote), B2 | Years are stated; the live-service type is an answer slot in F7. No dedicated question. |
| Experience running a content calendar | C3, F1 | |
| Comfortable with player-retention metrics | C1, D2 | |
| Clear written communication | — none, and why | Not assessable from your material. No question here. |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "How are the two titles' calendars planned today, and who signs off each update?" | Shows you read the JD's calendar and sign-off duties closely. |
| R2 | "How do KPIs split between live ops and each title's product owners?" | Ownership of the post-event review is usually contested. Asking shows you know that. |
| R3 | "What would a new producer do in their first month that would genuinely help the team?" | Reciprocity question. Scored as a preparation signal. |
| R4 | "Where does the release checklist with QA sit today, and what is the biggest sign-off failure the team has had?" | Tests checklist maturity and invites a candid answer. |
| R5 | "Which of the two titles is more exposed to in-app purchase changes, and how would the calendar shift?" | Uses the F8 gap as a question, without claiming the experience. |

## Sources

Research tier: **L0**. Web search permission was not granted, so each call below was refused. No outside claims are made.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | unavailable | Values cheat sheet (section 10). Not built: no values source. Query refused. |
| 2. `Saltmarsh Games interview process Live Operations Producer` | unavailable | Loop structure and persona weights. Persona weights stay at the hiring-manager prior. Query refused. |
| 3. `Saltmarsh Games mobile studio news strategy` | unavailable | Grounding brief and CO bank. Not built. Query refused. |
| 4. `Tobias Wrenfield Saltmarsh Games Head of Live Operations` | unavailable | Interviewer read and a tailored reverse question. Not built. Query refused. |
| 5. representative JD | skipped | Your JD fixes the fit snapshot. |

Provided documents: your JD and your background message.

## Upgrade menu

- Your answers to the two questions in the message → round type and the live-service status of your puzzle title reweight the personas and resolve F7.
- Web search permission → one research pass on Saltmarsh's values, loop and recent strategy, which would add a values cheat sheet, a grounding brief and a CO bank.
- Tobias's public footprint, from that same search → an interviewer read and a reverse question tied to his path.
- Your recruiter's prep email → coverage of any pre-declared deliverable.
