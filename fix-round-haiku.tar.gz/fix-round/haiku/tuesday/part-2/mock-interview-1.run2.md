Priya's prep pack is saved as `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-tuesday-part-2-rooms-case-1-denied-993493e8/7a58587e-8157-458a-96fa-81616a80a90b/scratchpad/northwind_data_senior_gtm_strategy_lead_interview_pack.md`. I built it for a peer round, since your note says Dan is her peer.

Web search was refused in this session, so the pack runs on your message and your research note. The values page, the interview process and Dan's public footprint are unchecked, and the file's Sources section shows this.

The pack has 21 questions across seven personas, weighted toward the Data-Driven Prober and the Peer Evaluator. Each question carries its type, provenance, guidance and rationale. Three things to know before you use it:

- **The highest-ROI prep is D2**: the "someone who has owned go-to-market for a product line" objection. It combines the owned-GTM gap with the missing sales-ops and quota experience.
- **The $400M ARR figure carries the most risk.** It is credited to a change she proposed, and the material doesn't show her share. The pack gives her answer slots for how it was counted and how much was hers, not a method or a share.
- **Priya should confirm the sales-ops and quota negative in her own words.** It came from your message, so the pack treats it as her stated gap.

Would you paste the full JD text? Until then, the JD rows are built from your highlights, and the JD-tagged questions are less exact.

If you'd like me to run one live drill, I can play the Skeptic on D2 and give feedback against its guidance cell. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions, and convert the pack to Word if you want it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: northwind_data_senior_gtm_strategy_lead_interview_pack.md -----
# Interview prep pack: Senior GTM Strategy Lead, Emerging Products, Northwind Data

**Round:** one 60-minute conversation with Dan Kovac, Director of Sales Strategy. Peer: both report to the same VP.
**Candidate:** Priya. **Mode:** session, first pass.
**Build note:** web search was refused in this session, so the pack runs on your message and your research note. See Sources.

## 1. How to use this pack

- **Personas** describe how a question arrives (its style). **Types** describe what is being scored.
- **Types:** VAL = behavioral and values fit. EXP = her past work, under scrutiny. JD = the listed job requirements. CO = company and strategy knowledge. CASE = a live problem from the role.
- Guidance is scaffolding, not a script. Each answer should run 90 to 120 seconds spoken.
- Labels: [grounded] traces to your message or research note. [inferred] is a derivation, named. [generic] is a pattern with no claim about this candidate or company.
- Answer slots (marked "Answer slot") are instructions for the interview. They are not questions to you.

## 2. Fit snapshot

Requirements are your JD highlights, quoted as you gave them. The evidence column holds only Priya's sentences from your message, quoted exactly.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" (your message, JD highlights) | "proposed a store-surface change credited with a ~$400M ARR uplift" (your message) | medium | [grounded] | transferability | Your material says she proposed a change and that it was credited with an uplift. It does not say she ran go-to-market for a product line, so the bridge stays at the proposal: "I proposed a store-surface change, credited with a ~$400M ARR uplift." Expect a probe on what she owned end to end. Answer slot: if she set any part of the go-to-market plan for that change, say which and how she decided; if she did not, say so and stay with the proposal. |
| F2 | "identify whitespace across land/adopt/expand/renew" (your message, JD highlights) | "built a partner-level revenue model used in carrier negotiations" (your message) | low | [inferred] (derivation: a revenue model touches where revenue sits, but no stage-level detail is stated) | discovery | The model touches the question without showing whether it reaches land, adopt, expand or renew. Answer slot: if the model separated revenue by stage of the customer relationship, say which stages and how; if it did not, say so and say how she would find whitespace across the four. |
| F3 | "run independent analysis in SQL and Tableau" (your message, JD highlights) | "skilled in SQL/Tableau" (your message) | medium | [grounded] | presentation | The quote reaches the requirement in other terms: "I'm skilled in SQL and Tableau." Adds no practice. Expect a probe: if she has an analysis she ran herself, offer to walk through it end to end. |
| F4 | "partner-motion design experience required" (your message, JD highlights) | "built a partner-level revenue model used in carrier negotiations" (your message) | medium | [grounded] | transferability | Adjacent partner work: a model used in negotiations. Motion design is not stated. Say what she built and what it was used for. Answer slot: if she designed any part of how partners were engaged, say which and how; if her part was the model used in negotiations, say so and stay there. |
| F5 | "strong cross-functional influence" (your message, JD highlights) | "set annual volume targets with cross-org consensus" (your message) | medium | [grounded] | presentation | The quote reaches influence in other terms: "I set annual volume targets with cross-org consensus." Expect a probe on how consensus was reached. Answer slot: if there were objections to the targets, say what they were and how she handled them; if there were none, say so. |
| F6 | "AI experience a plus" (your message, JD highlights) | "uses AI tools daily" (your message) | medium | [grounded] | transferability | Credible adjacent work: daily use, not AI product work. Bridge: "I use AI tools daily." Answer slot: what she uses them for in her work, and where her use stops, in her own words. |
| F7 | Sales-ops or quota-setting experience (not in your JD highlights; the gap comes from your message) | "No classic sales-ops or quota-setting experience" (your message) | none | [grounded] | capability | A stated absence, which the pack can give back as her words. Words: "I haven't done classic sales-ops or quota-setting work." Then how she would learn it, said as a plan, never as a past. Nothing added to make the gap feel smaller. |

**Gate rows:** none. Your material shows no eligibility term (authorization, location, schedule, pay, travel or credential) that the JD raises, so no gate question is asked.

**Pack-level observation:** the material supports a proposal, a model and a set of targets. It does not show ownership of a product line's go-to-market, and it does not show the quota work. The pack says so in its own analysis and never in her words.

## 3. Interviewer read

Source: your description of Dan's profile. The public-footprint search was refused, so no talks or writing were checked.

- **Career pattern:** pricing and monetization spine, with one early-stage-startup chapter.
- **Self-described style:** "relentlessly data-driven".
- **Implications:**
  1. Every number she states will be traced to its inputs. Keep the defend-the-number slots ready (A1 to A3).
  2. Case questions will lean toward pricing, packaging and unit economics, his native language. F4 is the closest honest bridge, and it is adjacent, not pricing experience.
  3. The startup chapter means builder stories land with him, and he will likely probe scrappiness and big-company pace (D3).
  4. As a peer, he is pricing what the hire costs his team. Expect seam and disagreement questions (B1, B4).
- **Mirror opportunity:** none offered. Her path has no startup chapter to pair with his.

## 4. Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy | Weight |
|---|---|---|---|---|
| Data-Driven Prober | "Walk me through how that was counted." | Highest. The peer prior is Peer Evaluator plus Prober. Dan's "relentlessly data-driven" self-description moves Prober up. The $400M figure is the one headline metric. | Defend-the-number slots and the weakest-assumption move. | 5 (A1 to A5) |
| Peer Evaluator | Seam questions, disagreement, credit | High. The relationship is peer, and he is pricing the hire's load on his team. | Reciprocity framing; seam principles, not a pretended knowledge of the seam. | 4 (B1 to B4) |
| Case/Strategist | Live problems in whitespace, expansion and pricing | Medium-high. The pricing spine tilts cases toward pricing and unit economics. The JD names whitespace. | Clarify, then structure. Name the denominator aloud. | 3 (C1 to C3) |
| Skeptic | "Which part would you be weakest at on day one?" | Medium. The stated gap (F7) and the owned-GTM line (F1) make this the likeliest objection set. | Hold on quoted facts; concede the one gap once, specifically. | 3 (D1 to D3) |
| Pressure | Time-boxed "why you" and "how much was yours" | Low-medium. Not a peer-round default, but the attribution on the $400M figure invites it. | Pause, restate, hold through two follow-ups. | 2 (E1, E2) |
| Conversational | "Walk me through the journey." Casual AI question | Low-medium. Casual openers are still scored, and the AI-plus line can come up casually. | A 90-second arc; treat casual questions as scored. | 2 (F1, F2) |
| Values/Behavioral | "Tell me about a time…" | Low. No values-style round is detected and no values page was read. Included so the style is not met cold. | Selection scaffolds ending in an honest branch. | 2 (G1, G2) |

Total: 21 questions. Depth follows weight.

## 5. Prohibited claims

Each entry names its basis and its honest form. Nothing on this list is coached, even as a probe.

| Not coached | Basis | Honest form |
|---|---|---|
| "I owned the go-to-market for a product line" | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: the material says a proposal, not go-to-market ownership. |
| "I drove the $400M" or "I delivered the $400M" | Inflated form of F1's quote ("credited with") | The quote at its own scope: a change credited with an uplift. Slots A1 to A3 and E2 stay inside it. |
| "I set the company's quotas" or "I owned sales targets" | Inflated form of F5 ("annual volume targets with cross-org consensus") | F5's quote at its own scope. |
| "I designed the partner motion" | Inflated form of F4 | F4's quote at its own scope: a model built and used in negotiations. |
| "I led AI product work" or "I built AI copilots" | Inflated form of F6 | "uses AI tools daily" at its own scope. |
| "I'm an expert in SQL" | Inflated form of F3 ("skilled in") | "skilled in SQL/Tableau" at its own scope. |
| "I haven't done classic sales-ops or quota-setting work." | Stated negative, F7 (plain acknowledgment) | That sentence, with no slot. Priya confirms it in her own words (upgrade menu). |

## 6. Question banks

**Requirement coverage.** JD1 to JD6 are the six lines in your JD highlights, in order.

| JD requirement | Covered by |
|---|---|
| JD1 own GTM strategy for two new product lines | D1, D2, E1, C1 |
| JD2 identify whitespace across land/adopt/expand/renew | C2 |
| JD3 run independent analysis in SQL and Tableau | A4 |
| JD4 partner-motion design experience required | A5, B3 |
| JD5 strong cross-functional influence | B1, B2, B4 |
| JD6 AI experience a plus | F2 |

Sales-ops and quota work is not a JD line. It is covered where the stated gap (F7) meets the JD (D1, D2, E1).

### A. Data-Driven Prober (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how the ~$400M ARR figure was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (your message) | Defend the number, counting and sensitivity. Say how it was counted only if she knows, in her own words. Name what the figure is most sensitive to, in one sentence. Answer slot: if she did this, say how; if there was no such count, or it was not hers to count, say so plainly and return to the change she proposed and what it was credited with. No method is supplied. | F1 carries the figure. A headline metric draws defend-the-number slots by rule, and a prober's first target. EXP because it tests what the count rests on. |
| A2 | "Which assumption behind that number would you defend least?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (your message) | Weakest-assumption move: name, in her words, the assumption she would defend least, before he does. Answer slot: if she knows the assumptions behind the figure, name the one she would defend least; if she does not, say so plainly. | The second defend-the-number slot. Naming the weak point first turns a gotcha into a credibility gain. |
| A3 | "How much of that uplift was actually yours?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (your message) | Precision on attribution. Hold the quote: she proposed the change, and it is credited with the uplift. Give her share only at the scope of what she did, and never as a number unless she can say how it was set. Answer slot: if she established her share with any analysis, say what it was; if she did not, say so plainly. | F1 is where attribution is weakest, so a prober goes straight at it. The honest answer is the quote's own scope. |
| A4 | "Tell me about an analysis you ran in SQL or Tableau, from question to recommendation." | JD | [grounded] "skilled in SQL/Tableau" (your message) | Open prompt, theme from JD3. The quote gives a skill, not an analysis, so there are no story beats in her material. Scaffold: pick an analysis she ran herself, and give the question, the data source, the number she landed on, and the one assumption that could move it. If she did not run one end to end, say so and give the nearest one she did run. | F3 is medium: the skill is stated, the proof is not. An open prompt lets her choose the instance. |
| A5 | "Walk me through how the carrier revenue model was built, and what it leaves out." | EXP, JD | [grounded] "built a partner-level revenue model used in carrier negotiations" (your message) | Premised question: the quote carries "built" and "used in carrier negotiations", and nothing about inputs, owners or limits. Say what the model was built to answer, its inputs in her words, and what it leaves out. Answer slot: if she chose the inputs, say which and why; if others set them, say so plainly and say what she did with them. | F4 is adjacent. The model is the most inspectable piece of her partner story, so expect a walkthrough. The premise stays inside the quote's own words. |

### B. Peer Evaluator (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our teams sit side by side. Where's the seam between yours and mine, and what happens when we disagree?" | JD | [generic] seam question; [grounded] "set annual volume targets with cross-org consensus" (your message) | Propose seam principles and do not pretend to know his seam: who owns targets, who owns pricing inputs, who owns partner data. Answer slot: if she has disagreed with a peer team over targets, say how it resolved; if she has not, say so and give the principle she would use. | F5 carries cross-org consensus, the nearest sentence to disagreement. JD5 is the raising source. |
| B2 | "How do you handle credit when work spans teams?" | EXP | [grounded] "set annual volume targets with cross-org consensus" and "proposed a store-surface change credited with a ~$400M ARR uplift" (your message) | Reciprocity: say whose work each credit went to, in her own words. Her two sentences carry only the words "consensus" and "credited", and nothing about how credit was divided. Answer slot: if she has a view on how credit was divided, say what it is; if she has no such case, say so and say what she would do. | A peer's credit probe. Stays inside the two quoted sentences. |
| B3 | "If we built a partner offer together, what would you need from my team?" | CASE | [grounded] "built a partner-level revenue model used in carrier negotiations" (your message) | Clarify first: which partners, which economics. Then say what she would need from his team, such as pricing inputs and deal data, and what she would bring: a revenue model built for negotiations, and nothing beyond it. | JD4 is the raising source. The live problem asks about the future, so it presumes nothing about her past. The reciprocity answer is what a peer listens for. |
| B4 | "Where would you push back on a plan from my team?" | JD | [grounded] "set annual volume targets with cross-org consensus" (your message) | Disagreement with equals: name one kind of point she would contest, and how she would raise it with a peer, showing spine and tact together. Answer slot: if she has pushed back on another team's plan, say the point and how it ended; if not, say so and describe how she would raise it. | JD5 and the peer prior. The disagreement answer is what the seam question tests, asked head-on. |

### C. Case/Strategist (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Compass is the AI copilot launch. How would you sequence go-to-market for the two new product lines around it?" | CO, CASE | [grounded] "an AI copilot launch ('Compass')" (your research note, not checked for currency) | Clarify first: which two product lines, and what Compass does for each. Then objective, segmentation, approach across land, adopt, expand and renew, metrics, risks. Use the name as given. Do not claim any role on Compass. | Compass is the first stated priority in your note and the likeliest strategic probe. CO for company altitude, CASE for a live plan. |
| C2 | "Build a whitespace view across land, adopt, expand and renew for one of the two lines. What do you need to know first?" | JD, CASE | [generic] structure; raising source JD2, "identify whitespace across land/adopt/expand/renew" (your message) | Clarify, then objective, segmentation by what the data holds, approach, metrics, risks. Say what she needs before she sizes anything. Name where a pricing lever could sit at each stage, as a hypothesis, not as experience. | JD2 is the requirement. It presumes nothing about her past. The pricing nudge reflects his spine. |
| C3 | "Enterprise expansion revenue fell 20% quarter over quarter. Diagnose it." | CASE | [grounded] "enterprise expansion" (your research note) | Structure: the denominator first, then price, volume and mix, then segments. Challenge one premise respectfully, for example whether the 20% sits on a base that changed. Say her clarifying questions aloud. | Enterprise expansion is the second priority in your note. He will probe the denominator, so she should ask for it first. |

### D. Skeptic (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "No classic sales-ops or quota-setting experience" (your message, a stated negative) | Open prompt, persona stem. Answer honestly: "I haven't done classic sales-ops or quota-setting work." Then how she would learn it, said as a plan, never as a past. Add nothing. | F7 is the one gap she has stated, and a peer will ask a version of this. The answer uses the stated negative only. |
| D2 | "What would you say to someone who argues this role needs a person who has owned go-to-market for a product line?" | JD | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" and "built a partner-level revenue model used in carrier negotiations" and "No classic sales-ops or quota-setting experience" (your message) | Highest-ROI prep in the pack. Hold: say what she did, at its scope. She proposed a change that is credited with an uplift, and she built a revenue model used in negotiations. Hold through two follow-ups by returning to those sentences. Concede: she has not done classic sales-ops or quota-setting work, and she says it once, specifically. Then a plan: what she would learn first in her first month. She never says "I owned" anything. | The objection is F1 and F7 together, where the material is thinnest. A second follow-up breaks any claim stronger than the quotes, so the hold is only what they carry. |
| D3 | "Nine years at a large company. Why would this move fast enough for you?" | EXP | [grounded] "9 at a large consumer-tech company in product strategy & ops" (your message) | Do not disparage the large company. Answer slot: if she made a decision in that work where she moved faster than the process, say what it was; if not, say so plainly and say what she would want from the pace here. | His startup chapter is the reason to expect pace skepticism. The premise is the quote's own words. |

### E. Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you, for this role, over someone who has run sales strategy for years?" | JD | [grounded] "set annual volume targets with cross-org consensus" and "No classic sales-ops or quota-setting experience" (your message) | Pause, restate the question, then answer in under 60 seconds, anchored in what she stated: targets set with cross-org consensus, a model used in negotiations, a change credited with an uplift. Hold through two follow-ups. Concede the one gap specifically, quota and sales-ops work. Never fold on the rest. | A time-boxed stress probe on the JD1 altitude. Hold-then-concede is the structure. |
| E2 | "You said 'credited', so was it yours, or not?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (your message) | Hold through two follow-ups. Say what she proposed, and say which part of the uplift she cannot claim. Do not fold to "not mine" and do not reclaim anything beyond the proposal. | A time-boxed attribution pressure. The interviewer's hook is the word "credited", which she used herself. |

### F. Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" and "built a partner-level revenue model used in carrier negotiations" (your message) | A 90-second arc in the order the quotes give: consulting, then consumer-tech product strategy and ops, then the partner model. Stop at the quotes' edge, and say in one sentence what she wants next. Add no roles. | A casual register is still scored. The arc follows the quotes' own order. |
| F2 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" (your message) | Name two or three tools and what she uses each for, in her words. Say where her use stops, in her own words. | JD6 asked casually. F6 is the only AI evidence, and it is daily use, so the answer stays at that scope. |

### G. Values/Behavioral (weight 2)

No values-style round is detected, so VAL is weighted low. These two are included so the style is not met cold.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you put a customer ahead of an internal metric." | VAL | [generic] | Open prompt, persona stem. No published values are in hand, so no value is mapped. Scaffold: pick a time when a customer's need and an internal target pulled apart, and say what she chose and why. Honest branch: if no such time comes to mind, say so plainly, then say how she would weigh it. | No values round, no values page. Weighted low, but the style must not be new on the day. |
| G2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Scaffold: pick a time she said something the room did not want to hear, with a named stake and what happened next. Honest branch: if no such time comes to mind, say so plainly, then say how she would handle it. Do not borrow F5's consensus into this story; it is a different event. | Same reasoning as G1. |

## 7. Reverse questions

| # | Question | Why it lands | Provenance |
|---|---|---|---|
| R1 | "You came up through pricing and monetization and spent a chapter at an early-stage company. Which of that carried into sales strategy here, and what didn't?" | Ties to his own path. It turns an interrogation into a peer conversation and shows she researched him, not only the company. | [generic] form; his path from your profile description |
| R2 | "What could a new person do in their first month that would genuinely help your team?" | Reciprocity, the peer question the pack requires. Dan weights this slot as a preparation signal. | [generic] |
| R3 | "Where does pricing end and sales strategy start on your side of the seam?" | Makes the seam concrete and invites him to state his own principle, which is what a peer evaluator listens for. | [generic] |
| R4 | "How do you decide when a whitespace estimate is good enough to act on?" | Speaks to his data-driven bar and gives him a place to show it. | [generic] |
| R5 | "What would a successful Compass launch look like for sales strategy specifically?" | Uses the priority from your note, at the altitude of his own team. | [grounded] "an AI copilot launch ('Compass')" (your research note) |
| R6 | "How does the larger platform vendor's bundling change the pricing work on your side?" | The competitive threat from your note, asked at his level. Shows she came in with the competitive frame. | [grounded] "main competitive threat is bundling by a much larger platform vendor" (your research note) |

## 8. Sources

**Provided documents:** your message (Priya's background, the JD highlights, and Dan's profile as you described it); your research note (three stated priorities, the competitive threat).

**Searches and fetches sent:**

- "Northwind Data company values principles": refused (WebSearch permission not granted in this session).
- "Northwind Data interview process sales strategy": refused (same).
- "Dan Kovac Director of Sales Strategy Northwind Data": refused (same).
- No fetches sent.

Research tier: L1, searches 3 of 6, fetches 0 of 2. User links read: none.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Northwind values | unavailable | Would have moved VAL themes. The values cheat sheet is not triggered, since no values-style round is detected. |
| 2. Interview process, sales strategy | unavailable | Would have confirmed the loop. Your message already establishes one 60-minute session with Dan, so no archetype fallback is needed. |
| 3. Strategy and recent news | skipped | Your research note supplies the three priorities and the competitive frame, which fix the CO questions. Its date is not stated, so its currency is unchecked. |
| 4. Dan Kovac, public footprint | unavailable | Would have moved the interviewer read beyond your profile description: talks, writing and recurring themes. |
| 5. Representative JD | skipped | Your JD highlights fix the fit snapshot and the JD-tagged questions. |

**Sections not included, and why:** Prep triage (no prep time stated). Graded deliverables (none declared). Grounding brief (no L2 run and no full strategy brief). Values cheat sheet (no values-style round detected). Delivery coaching (no assessment provided).

## 9. Upgrade menu

- **Full JD text** → JD1 to JD6 move from your highlights to exact quotes, the JD-tagged questions get exact wording, and F1 to F6 can be re-graded.
- **Priya's own wording of the sales-ops and quota gap** → F7 becomes her stated words instead of your summary. D1, D2 and E1 rely on it.
- **WebSearch permission** → the values page, the interview process and Dan's public footprint can be checked, and the currency of your research note can be confirmed. Targets 1, 2 and 4 would be re-run.
- **Priya's account of the $400M figure: what she proposed, who decided, and how the credit was assigned** → rows F1, A1 to A3 and E2 move from answer slots to grounded story beats, at the scope she gives.
- **Dan's public talks or writing** → adds recurring-theme questions and sharper reverse questions to his bank.
- **A tuesday-dossier.md** (see the offer in the message) → carries this pack's gaps into later sessions.
