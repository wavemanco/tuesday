Your prep pack is saved at /tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-tuesday-part-2-rooms-case-3-denied-ffe696d1/47691783-f0ea-47c5-ba56-575c450bf9bb/scratchpad/stripe_product-operations-manager_interview_pack.md. I built it for a final round with an unknown format, since your note didn't say who you're meeting or how many sessions there are.

Web search was refused in this session, so the pack has no Stripe-specific values, interview structure, or strategy. Every question is labeled generic, and the sources section says what was attempted. The main gap is the missing job posting and your background, so the requirements are guessed from the role family and the answers are scaffolds, not stories from your experience.

Three questions would restructure it:

1. Who is in the final round, and is it one conversation or several? Is there a pre-declared assignment, such as a presentation or take-home, or focus areas from the recruiter?
2. Can you paste the job posting and your CV or a few bullets about your background? With them, the requirements become real and the answers can be built from your own history.
3. Do any of these apply: you need work authorization or visa sponsorship, you'd need to relocate, or you have a schedule constraint? I only need to know whether each is met.

Say the word and I'll play the Skeptic on D1, "why this role, and why now." It's the highest-return rehearsal in the pack because it gets asked in some form in almost every final. I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: stripe_product-operations-manager_interview_pack.md -----
# Interview prep pack: Stripe, Product Operations Manager, final round

Round: final round, format and interviewer not yet known. Session mode. First delivery, so there is no changelog.
Built without web research and without a JD or CV. Everything Stripe-specific is absent, and every question is labeled `[generic]`.
Sections dropped because their inputs are missing: prep triage, graded deliverables, grounding brief, reading the interviewer, values cheat sheet, delivery coaching. The upgrade menu says what each one needs.

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what it is scoring.
- Type key: **VAL** behavioral and values; **EXP** your past work, probed in depth; **JD** the role's stated or implied requirements; **CO** company and strategy knowledge (none in this pack, because research did not run); **CASE** a live problem.
- Guidance is scaffolding, not a script. Each cell is built to be spoken in 90 to 120 seconds.

## Fit snapshot (worksheet variant)

No JD and no background were supplied, so the requirements below come from the role family, not from a posting. Nothing is quoted, and no evidence exists yet to quote. Each row says what strong evidence would look like and where a question will press.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| W1 | Designing and running an operating process that other teams depend on (role-family pattern, no posting) | none given | none | [generic] | discovery | Strong evidence is one process you designed, who adopted it, and what changed after. Your material does not show one yet. Answer slot: if you have such a process, name it and say what it replaced; if you have not designed one, say which part you have run and whose design it was |
| W2 | Setting metrics and using them to make decisions (role-family pattern, no posting) | none given | none | [generic] | discovery | Strong evidence is a metric you defined, what it was used to decide, and how you knew it was right. Your material does not show one yet. Answer slot: name the metric you would defend and say how you would count it |
| W3 | Driving work across teams with no direct authority, such as finance, engineering and go-to-market (role-family pattern, no posting) | none given | none | [generic] | discovery | Strong evidence is a cross-team outcome you moved and the means you used. Your material does not show one yet. Answer slot: say whose agreement you needed and how you got it, if you did; if you did not, say what you would do first |
| W4 | Running a launch or program from scoping to rollout (role-family pattern, no posting) | none given | none | [generic] | discovery | Strong evidence is one launch you ran end to end, with the parts you owned named. Your material does not show one yet. Answer slot: name the launch and the parts that were yours; if the launch was run by others, say what you contributed |
| W5 | Prioritizing an ambiguous problem space (role-family pattern, no posting) | none given | none | [generic] | discovery | Strong evidence is a case where you cut scope and what you cut. Your material does not show one yet. Answer slot: name what you dropped and why; if nothing was dropped, say that and describe how you chose the first thing |
| G1 | Work authorization or visa sponsorship for the role's location (gate, role-family pattern) | none given | none | [generic] | hard_gate | Surfaced, not bridged. Your material does not establish this, and nothing in this conversation does. The one question asked in the message is whether it is met |
| G2 | Ability to work from the role's office location or relocate (gate, role-family pattern) | none given | none | [generic] | hard_gate | Surfaced, not bridged. Your material does not establish this. The one question asked in the message is whether it is met |

## Prohibited claims

Built here, with no candidate sentences available to stretch. Listed so you know which claims the pack will not coach.

| Not coached | Basis | Honest form |
|---|---|---|
| Any claim about your past that you have not said out loud | Standing rule, applied to every answer | Say only what you did, in your own words. Once your background is in, this table will list the specific wordings to avoid |
| Insider knowledge of Stripe's internal tools, metrics or plans | Generic pattern for this interview type, not a fact about you | "I've read the public material on how the company works. Here's what I'd want to learn internally" |

## Persona weights

Relationship and round are unknown, and no loop source has established how many sessions this final has. The fallback archetype is generic, so the weights are flat and that is stated plainly. Every plausible persona is covered, so you will not meet a style for the first time live.

| Persona | Likelihood and reasoning | Depth | Counter-strategy |
|---|---|---|---|
| Case/Strategist | Medium. A final round often includes a live problem, and this role is scored on how you structure one | 3 | Clarify, then state the objective, segment, approach, metrics and risks. Think aloud and challenge one premise |
| Data-Driven Prober | Medium. The role involves metrics, so expect a probe on any number you give | 3 | Say how you would count a figure and which assumption you would defend least |
| Pressure / Stress | Medium. Used to test composure, not content | 3 | Pause, restate the question, hold a position through two follow-ups, then concede only the specific uncertainty |
| Skeptic | Medium. A final round is where the "why this role, why now" question is asked hardest | 3 | Rehearse the predictable objection until it is plain. Calibrated candor beats bluffing |
| Peer Evaluator | Medium. A peer, if present, prices what your hire costs their team | 3 | Offer seam principles, not a pretended knowledge of the seam. Reciprocity: say what you bring to their team |
| Conversational / Rapport | Medium. Friendly openers are still scored | 2 | Have a 90-second arc ready, and treat casual questions as scored |
| Values / Behavioral | Low to medium. No values-style round is detected, because no loop source documents one and no published values were read | 2 | Pick one real decision per prompt. If none fits, say so plainly and give the nearest one |

## Question banks

Every row is `[generic]`. The guidance makes no claim about your history, so the Provenance cell carries the label alone. Where an answer depends on your experience, the cell holds an answer slot and not an assumed story.

### A. Case/Strategist (depth 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A launch you own is two weeks from its date. Sales, finance and engineering disagree on whether it is ready. What do you do?" | CASE | [generic] | Clarify what "ready" means to each group and who decides. Then state the objective, the options, the criteria you would use, and the risks of each option. Name one assumption you would test first | A launch-coordination case is central to the Product Operations role family. Structure and clarification are what gets scored |
| A2 | "A conversion metric in an operations team dropped 20% over three weeks. Diagnose it." | CASE | [generic] | Before any cause, check the metric itself: definition, instrumentation, and whether the change is real. Then segment by time, geography and product. Build a short hypothesis tree and say which test would separate them | Metric diagnosis is the most common live problem for this role. The scoring is on the order of the reasoning, not on the answer |
| A3 | "Design the operating cadence for a new 25-person cross-functional team in its first quarter. What do you need to know first?" | CASE | [generic] | Ask about the team's goals, its decision rights and its existing rituals before proposing anything. Then propose a weekly, monthly and quarterly rhythm, and say what you would drop if it is too heavy | Tests process design without any claim about your past. Asking first is scored |

### B. Data-Driven Prober (depth 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a metric you put in front of leadership. How was it counted?" | EXP | [generic] | Pick one metric you actually built or used. Describe how it was counted, in your own words. Answer slot: if you did not build it, say whose it was and what your part was | An open prompt on a figure. The prober will go two levels deep, so the honest answer about who counted it matters most |
| B2 | "Which assumption behind a number you have relied on would you defend least?" | EXP | [generic] | Name the assumption before they do. Answer slot: if you can name one, say what it is and how you would check it; if you cannot, say so and say how you would find out | Persona stem. The move converts a gotcha into a credibility point and is scored on candor |
| B3 | "Tell me about a process you put in place. How did you know it worked?" | JD | [generic] | Name the process and the outcome you were watching for. Answer slot: if you measured adoption or results, say which measure and how you counted it; if you did not measure it, say so and say what you would measure now | Covers the process requirement (W1). Asks for the test of success, which is where a process claim is usually weakest |

### C. Pressure / Stress (depth 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Sixty seconds: why you over a candidate who has already run this kind of work?" | JD | [generic] | Pause, then restate the question. Answer with what you can show you have done and what you would do differently in this role. Do not invent a superiority | Persona stem. Tests composure under a comparison you cannot win on credentials |
| C2 | "Pick a result you are proud of. How much of it was actually you?" | EXP | [generic] | Name the result, then the part you did, then the part that was others'. Answer slot: state your share in your own words, even if it is smaller than the headline | Persona stem. The honest share is the answer that holds under a second follow-up |
| C3 | "You said you would prioritize one thing. Why not the other?" | JD | [generic] | Hold your position through two follow-ups by returning to the criterion you used. Concede only a specific uncertainty, such as the data you lacked. Never fold on the core claim to restore harmony | Hold-then-concede. The challenge is to your answer, not to a claim about your past |

### D. Skeptic (depth 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Why this role, and why now?" | JD | [generic] | Give one reason you can explain in two sentences and repeat under a follow-up. Answer slot: if you cannot name one, say so and decide before the interview whether you want the role for that reason. This is the highest-ROI rehearsal in the pack: it is asked in some form in almost every final, and a vague answer costs the most | The most predictable objection in any late-stage round. Named as the deepest rehearsal because nothing else in the pack is more likely to be asked |
| D2 | "Which part of this job would you be weakest at on day one?" | JD | [generic] | Name the area, then say how you would close the gap in the first month. Do not bluff a skill the interviewer owns | Persona stem. Scored on calibrated candor and a credible ramp plan |
| D3 | "Which requirement of this role do you have the least direct experience with?" | JD | [generic] | Name the requirement, say what you have done near it, and stop. Answer slot: if there is nothing near it, say that plainly and say how you would learn it | Asks for a self-assessed gap. Tests whether you can name a limit without over-explaining it |

### E. Peer Evaluator (depth 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Our teams sit side by side. Where is the seam between your work and ours, and what happens when we disagree?" | JD | [generic] | Propose principles for the seam, such as who decides which requests and how escalation works, and do not pretend to know their boundary. For disagreement, name one disagreement you resolved and how | Persona stem. Partnership fit is scored, and seam principles beat false precision |
| E2 | "How do you handle credit when work spans teams?" | JD | [generic] | Name how you credit the people who did the work, and what you did when credit was contested. Answer slot: if you have a real case, give it in your own words; if not, describe the practice you would use | Persona stem. Tests whether you reduce or add to a peer's load |
| E3 | "What would you need from my team to do this job well in the first quarter?" | JD | [generic] | Name two or three specific needs and say what you would give back. Keep it to what the role needs, not a wish list | Reciprocity framing. Shows you have thought about the peer's team, not only your own needs |

### F. Conversational / Rapport (depth 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | JD | [generic] | A 90-second arc: one line on where you started, the three moves that connect to this role, and why now. Build it from your own history only | Rapport openers are scored. An unscripted arc rambles, so script the shape |
| F2 | "What tools are you using to run operations day to day?" | JD | [generic] | Name the tools you have used, what each was for, and one you would like to learn. Answer slot: if you have used a tool for a process, say which and what it changed | Casual question about the stack. It is scored like any other JD question |

### G. Values / Behavioral (depth 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Select a time a leader heard something they did not want. Give the stake, what you did, and how it landed. Answer slot: if no such time comes to mind, say so plainly, then give the nearest one, or how you would handle it | Persona stem. Scored on whether you held the truth, not on whether the ending was pleasant |
| G2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Select a decision where the customer's interest and an internal number pointed different ways. Say what you chose and what it cost. Answer slot: if no such decision comes to mind, say so plainly and describe how you would decide | Persona stem. Without published values, the test is for a specific decision, not a slogan |

## Requirement coverage

| Requirement | Questions | Notes |
|---|---|---|
| W1 operating process | B3, A3 | |
| W2 metrics and decisions | A2, B1, B2 | |
| W3 cross-team influence | E1, E2, E3 | |
| W4 launch or program | A1, C2 | |
| W5 prioritization | C3, D2 | |
| G1 work authorization | none, and why: a gate the material does not settle. It is asked in the message, not in the bank | |
| G2 location | none, and why: a gate the material does not settle. It is asked in the message, not in the bank | |

These are role-family requirements, not a posting's list, so this table checks coverage of a guessed scope. It must be redone against the JD once one is supplied.

## Reverse questions

Each one has a reason it lands. Ask the ones that fit the round you are in.

1. "What does a strong first 90 days look like here, and what would the team want changed by then?" Lands because it shows you are thinking about outcomes, not about getting the job.
2. "How does this team decide between a process fix and a headcount request?" Lands because it asks how they make tradeoffs, which is the Case persona's real question.
3. "Which decisions does this team make without escalating, and which need sign-off?" Lands because it asks where the authority sits, which matters for a role without direct authority.
4. "What is the biggest operational problem the team is working on right now?" Lands because it lets you show you listened when they answer.
5. Peer rounds only: "What could a new person do in their first month that would genuinely help your team?" Lands because it turns the interview into a working conversation.

## Sources

Provided documents: the request itself (company, role, final round). No JD, CV, dossier, values page or recruiter note was supplied.

Searches sent, all refused by the session (web search permission was not granted), so none returned a result:
- "Stripe values operating principles"
- "Stripe interview process product operations manager final round"
- "Stripe strategy news 2026"
- "Stripe \"Product Operations Manager\" job description"

Research tier: L1 — searches 4 of 6, fetches 0 of 2; all calls refused, so the content above is `[generic]` throughout.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Stripe values` | unavailable | Values cheat sheet, section 10. Not built: no values were read, and no values-style round is detected |
| 2. `Stripe interview process product operations manager` | unavailable | Loop structure. Persona weights are flat because no loop source establishes the loop |
| 3. `Stripe strategy` / recent news | unavailable | The CO bank and the grounding brief. None of the pack's questions are CO |
| 4. `{interviewer name} Stripe` | n/a | No interviewer name was given, so there was no query to form |
| 5. representative `Product Operations Manager` JD | unavailable | Would have grounded the requirement rows as `[inferred]` instead of `[generic]` |

## Upgrade menu

- The round format and who is in it → persona weights for each interviewer, and a per-session mini-pack if the final is several sessions
- Any pre-declared assignment, such as a presentation or take-home → a build section for it, with the facts to build on
- The job posting text → the worksheet rows become quoted rows, the W rows are checked against the real list, and the coverage table becomes real
- Your CV or a few bullets about your background → the fit snapshot gets verbatim evidence, and the answer slots become story maps you can rehearse
- The interviewers' names → a tailored reverse question, and persona weights read from their public footprint
- Web search access in this session → a Stripe values sheet, the loop structure, and strategy-based Case questions. Research was refused in this run, so these are missing and not implied
- A tuesday-dossier.md from a job-underwriter run, if you have one → verified evidence and a prohibited-claims list built from it. It is not needed for this pack
