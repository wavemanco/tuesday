Your prep pack is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-tuesday-part-2-rooms-case-4-denied-9c050029/43937edf-2645-42c1-950d-c50d7221829a/scratchpad/quartzline_product-manager-platform-apis_interview_pack.md`. It's built from your dossier. Web search was refused, so the pack has no company values or interview-process information and treats both as unknown. Your dossier is also about three months old, so check that the posting still matches it.

Say the word and I'll play the Skeptic on A1, the objection the dossier names as the highest-ROI prep.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quartzline_product-manager-platform-apis_interview_pack.md -----
# Interview pack: Product Manager, Platform APIs at Quartzline

Hiring-manager round, 45 minutes, Thursday (tomorrow). Interviewer not named. First pack for this role; built from `tuesday-dossier.md` (decision: conditional_go) with no web research (see Sources).

## 1. How to use this pack

- **Personas** describe how a question will arrive. **Types** describe what is being scored: VAL (values), EXP (your experience, probed), JD (the role's stated requirements), CO (company knowledge), CASE (live problem).
- Guidance is scaffolding, not a script. Rehearse only what you actually did, in your own words.
- Provenance labels: **[grounded]** traces to your confirmed material or the dossier; **[inferred]** is a derivation this pack made; **[generic]** is a pattern for the role, with no claim about you or Quartzline.

## 2. Prep triage

Tonight and tomorrow morning. Do these in order; everything else is insurance.

1. **Tonight, 20 min:** Say A1 aloud until the plain acknowledgment comes first and the integration quote comes second without a pause. Then A2.
2. **Tonight, 15 min:** Rehearse E1, the 90-second arc, including the roadmap-input caveat said before anyone asks.
3. **Tonight, 15 min:** B2 (who decides between two squad requests) and B4 (how you would count adoption). These test the two unknowns the dossier flags.
4. **Tomorrow morning, 10 min:** C1, how the "30+" was counted and the assumption you would defend least. Then pick three reverse questions from section 7, starting with the two the dossier supplies.

Everything else is insurance.

## 3. Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" — JD R1, must-have | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier V1 | low | [grounded] | transferability | Words: "I haven't held a product manager title or role. I led 30+ end-to-end client integrations of the vendor's REST APIs, from scoping through go-live." Limit, as this pack's observation: the material shows client-side integration work, not product-management tenure. Confidence is the handoff's grade of the R1 claim, not V1's. |
| F2 | "Technical fluency: API docs, schemas" — JD R3, important | "Wrote the internal integration playbook her team uses" — dossier V2 | low | [inferred] | discovery | Answer slot: if the playbook covers how you check schemas or documentation, say which steps and what you checked. If it does not, say so and say what you would check first. Nothing about schema work goes in the answer unless you say it. |
| F3 | "Stakeholder management across engineering, sales, customers" — JD R4, important | "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier V3; "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier V1 | medium | [grounded] | transferability | Customer and product sides are in the quotes. Volunteer V3's limit before it is found: confirmed, limited inspectable proof. Engineering and sales are not in your material. Answer slot: if either was on the work, say what each wanted and what you did. If neither was, say so and stay with the client side. |
| F4 | "Agile delivery experience" — JD R5, preferred | none given | low | [grounded] | discovery | Clarify strategy. Answer slot: if the work ran in sprints or any defined cadence, name it. If it did not, say so and say what you would confirm about how this team defines agile. V1's sequence is the nearest thing in your material; it is a scaffold, not a bridge to agile. |
| F5 | "Shipped API or platform products" — JD R2, must-have | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier V1 | low | [inferred] | transferability | Not in the handoff's weak areas. This pack reads V1 as adjacent work from the client side of the vendor's APIs, and flags that for the underwriter rather than overriding it. Words: the V1 quote at its own scope. Limit, as this pack's observation: the material does not show a product you shipped. Answer slot: A3. |
| F6 | "Owning a roadmap and prioritization authority" — dossier R1 sub-claim, acknowledge_gap | none given. V3 is input to a roadmap, not ownership of one. | none | [grounded] | capability | Words, a plain acknowledgment sourced to the dossier's acknowledge_gap area and prohibited_claims: "I haven't owned a roadmap or set prioritization for an engineering squad." Then your ramp, said as a plan and never as past. No answer slot here. |

The handoff's weak areas list R1, the roadmap sub-claim and R5. This pack also routes R2 (F5) and R4 (F3) as transferability from the quotes. Both differences are flagged, not overridden.

## 4. Persona table

| Persona | How it shows up in this round | Weight and reasoning | Counter-strategy | Depth |
|---|---|---|---|---|
| Skeptic | Quiet, persistent probing of R1 and the roadmap gap; "why you, why now" | Top. The hiring-manager prior is capability and derisking, and the dossier's objection sits on this gap. | Rehearse the objection until it is dull. Bridge only from quoted work, and name the limit yourself. | 5 |
| Case / Strategist | Live problems on the role: a flat adoption curve, a squad conflict, a partner's breaking change | High. The hiring-manager prior weights cases, and two unknowns (decision authority, adoption baseline) are testable here. | Clarify, then structure out loud, then challenge one premise. Make no claim about past work. | 4 |
| Data-Driven Prober | Tests the "30+" count and the playbook as artifacts | Mid. The count is the one headline number in your material, and it is attached to integrations. | Say how the count was kept. Name the weakest assumption before they do. | 3 |
| Pressure / Stress | Time-boxed challenges to the "30+" and to a first-week call | Low. Not the stated format, but attribution probes are common in a 45-minute loop. | Pause, restate, hold through two follow-ups, then concede only what is unknown. | 2 |
| Conversational / Rapport | Opener and a casual question about API docs | Low by relationship prior, but casual questions are scored. | Pre-script the 90-second arc. Never answer the reverse-question slot with "you've covered everything." | 2 |
| Peer Evaluator | Seam questions between your work and the two squads; credit | Mid. The role's split across two squads makes seam questions likely even from a hiring manager. | Propose seam principles rather than pretend to know the seam. Show what you bring to the squads, not only what you need. | 3 |
| Values / Behavioral | Not weighted | None. No values source was established (research was refused), and this is not a values round. | Not applicable in this pack. | 0 |

No interviewer profile exists, so there are no interviewer-signal adjustments.

## 5. Question banks

**Requirement coverage**

| Requirement or responsibility | Covering questions |
|---|---|
| R1 — 3+ years PM | A1, A2, D2 |
| R2 — Shipped API or platform products | A3 |
| R3 — API docs, schemas | A5, E2 |
| R4 — Stakeholder management | F3 |
| R5 — Agile delivery | A4 |
| Responsibility: roadmap ownership | A1, A2, B2, D2 |
| Responsibility: specs and delivery with two squads | B2, F1 |
| Responsibility: adoption metrics | B4, C3 |
| Responsibility: partner discovery | B1, B3. No dedicated question; partner conversations are covered by the two cases. |

### A · Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier V1); plain acknowledgment from dossier prohibited_claims: "Having held a product manager title or role" | **The highest-ROI rehearsal in this pack.** Beat 1, the plain acknowledgment: "I haven't held a product manager title or role, and I haven't owned a roadmap." Beat 2, the quote at its own scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs, from scoping through go-live." Beat 3, a plan said as a plan: a PM with three years would ramp faster on roadmap decisions, so in the first months you would work from the squads' existing priorities while you learned how adoption is measured today. Hold through two follow-ups by returning to the integrations, never by adding a title. Concede specifically on roadmap authority, never on the integration work. | The underwriter named this as the most likely objection. It aims at F1 and F6, the thinnest part of the material, so it gets the deepest rehearsal. |
| A2 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | Name the roadmap, plainly: "I haven't owned a roadmap or set prioritization for an engineering squad." Then the ramp, as a plan: which squad decisions you would watch first, and how you would learn the adoption baseline. One weakness only; a list dilutes it. | A persona stem for the Skeptic. The gap is F6's, and the answer is a plain acknowledgment the dossier supports. |
| A3 | "Which API or platform product have you shipped, and what was your part in it?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier V1) | Answer slot: if you took part in shipping an API or platform product, name it and your part, in your own words. If the work was client-side integration of someone else's API, say that in the terms of the quote. | R2 is a must-have, and the quote does not reach it (F5). "Shipped" is the JD's own wording, so the second branch must allow that the shipping never happened. |
| A4 | "How did work move from requirements to go-live on your integrations — and was there a rhythm to it?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier V1) | Clarify strategy. No verified entry speaks to agile, so the only past claim is the sequence V1 lists, in the order it lists it. Answer slot: if the work ran in sprints or any defined cadence, name it and how it fit the sequence. If you did not work that way, say so plainly and say what you would want to confirm about how this team defines agile. | R5 is preferred, but the discovery is the question itself (F4). V1 is nearby, not a bridge. |
| A5 | "How do you check an API schema before a partner integration goes live?" | JD | [grounded] "Wrote the internal integration playbook her team uses" (dossier V2) | Answer slot: if the playbook covers schema or documentation checks, walk through the steps that do, in your own words. If it does not, say so and say what you would check first. | R3 is important, and the playbook may or may not carry schema checks (F2). The slot is the honest form. |

### B · Case / Strategist (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A partner's integration went live two months ago and its usage is flat. How would you diagnose it?" | CASE | [generic] | Clarify before structuring: which partners, what usage means, what "flat" is measured against. Then the objective, segmentation (partner, endpoint, client size), approach, metrics, and risks. Say the framework aloud before using it. Do not claim you have diagnosed one before. | A live problem from the adoption responsibility. CASE scores structure, not history. |
| B2 | "Two squad leads each ask you to take their request this quarter. Which do you take to the squad lead rather than decide yourself, and why?" | CASE | [generic] | Name the decision you would not make alone before naming the one you would. Propose a principle, for example that decisions crossing shared interfaces go to both leads. Do not assume authority you have not been given: ask who decides. | This tests the decision-authority risk. The JD asks for authority over two squads, and your material shows none. The answer makes no claim about your past. |
| B3 | "A partner asks for a breaking change to an endpoint, with two weeks' notice. What do you do?" | CASE | [generic] | Structure it: what the change breaks, which partners and at what volume, the deprecation path, who decides with the squads, and what you would tell the partner. Commit only to a timeline you could keep. | A live problem from partner work in the role. No claim about your past. |
| B4 | "How would you define adoption for a partner API — what would you count, and what would you leave out?" | CASE | [generic] | Start from what the metric answers: is the partner getting value from the API? Propose two or three counts and say what each excludes. Say you would need a baseline and that you do not have one. | The dossier names adoption as a responsibility and gives no current baseline. The answer proposes and does not claim. |

### C · Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the 30+ integrations were counted. What made one count as finished?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier V1) | Answer slot: say how the count was kept, in your own words. What counted as one integration? What was in and out? Was any integration you scoped but did not take to go-live in it? If you cannot say how it was counted, say so plainly. Name the assumption you would defend least before they do. | The headline figure gets the defend-the-number slots. The number belongs to "integrations" and nothing else (see the prohibited list). |
| C2 | "Which part of the integration playbook would you change first, and why?" | EXP | [grounded] "Wrote the internal integration playbook her team uses" (dossier V2) | Name the section you know is weakest, only if you know one. If you do not, say so, and say how you would find out whether the playbook is still used. | The question presupposes only the playbook the quote names. It tests the artifact the dossier says is inspectable. |
| C3 | "If adoption came back flat after go-live, what would you check first in your own data?" | JD | [generic] | Propose the checks in order: whether the integration is live in the right environment, whether the partner's calls are arriving, which endpoints are used. Name the data you would need and do not have. | The adoption responsibility, with the missing baseline. Generic; no claim about your past. |

### D · Pressure / Stress (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "That 30+ — how much of it was actually you?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier V1); [grounded] "Wrote the internal integration playbook her team uses" (dossier V2) | Pause and restate. Hold: "I led them." Answer slot: name which of scoping, requirements, architecture, UAT and go-live you ran, and which were others'. Concede only what you genuinely do not know. Hold through two follow-ups. | Attribution probe. The quote holds "led", so the hold is the quote, and the slot asks about the five stages the quote lists. |
| D2 | "Give me one prioritization call you would make in your first week, and defend it against me." | JD | [generic] | Frame it as a proposal, not as a decision you were given authority for. State the call in one sentence, the evidence you would want, and the one thing that would change your mind. Hold it through two follow-ups; concede uncertainty on the specific point, not the principle. | Pressure on the roadmap gap (F6). A proposal held under challenge tests judgment without claiming a past. |

### E · Conversational / Rapport (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So — walk me through the journey." | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier V1); [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" (dossier V3) | 90-second arc: the integrations (V1), then the playbook (V2), then the roadmap-input sessions (V3). Volunteer V3's limit: "That was feeding client evidence into product. I did not set the roadmap." End on the direction you want, the platform API role. Give no years figure: none is in your confirmed material. | A casual opener that is still scored. The arc is pre-scripted, and it volunteers the seam a prober would find. |
| E2 | "What does a good API doc look like to you?" | JD | [generic] | Name three things you would check: a first call that works, the error cases, and how schema versions are marked. Keep it to what you would check, not to tools you have used. | The casual form of R3. The answer is judgment, with no past claim. |

### F · Peer Evaluator (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Where would you expect the seam between your work and the squads' work to be, and what happens when you disagree with an engineering lead?" | JD | [generic] | Propose seam principles, not a seam you were told about. On disagreement: if you have a real example, tell it in your own words; if not, say how you would handle it and what you would bring to resolve it. Show what you bring to the squads, not only what you need. | A persona stem for the Peer. The responsibility to two squads makes it likely. No claim about your past. |
| F2 | "How do you handle credit when work spans teams?" | JD | [generic] | If you have an example from the integrations, tell it in your own words. Otherwise say how you would make credit explicit at the start of a cross-team piece of work. | A peer probe on reciprocity. No claim about your past. |
| F3 | "Tell me about a time you managed stakeholders across engineering, sales and customers on one piece of work." | JD | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" (dossier V3); [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier V1) | Open prompt on R4's own wording. Choose an instance from the integrations or the roadmap sessions. Customer and product beats are in the quotes. Answer slot: if engineering or sales were on the work, say what each wanted and what you did. If they were not, say so and stay with the client side. | R4 is important. The quotes carry customers and product, not engineering or sales, so the slot is the honest form. |

## 6. Reverse questions

Seven questions, each with its reason. No interviewer profile exists, so none is tied to the interviewer's own path (see the upgrade menu).

1. "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" (from the dossier.) **Why it lands:** it tests the decision-authority risk directly, and the answer decides whether the R1 bridge is enough.
2. "How is partner API adoption measured today, and what is the current baseline?" (from the dossier.) **Why it lands:** the baseline is unstated. Asking it reads as diligence and shows whether the metric exists at all.
3. "What is on the partner-facing roadmap this quarter, and which items are already committed?" **Why it lands:** it separates committed scope from open decisions and shows you think in roadmaps.
4. "What would a good first ninety days look like to you?" **Why it lands:** it turns A1's ramp into their expectation, so you can test the plan you gave.
5. "Who sets the adoption target, and who owns it when it is missed?" **Why it lands:** it probes ownership, the other half of the metrics responsibility.
6. "Which decisions here have you seen go wrong when they were made in one squad without the other?" **Why it lands:** it asks about the seam directly and lets them show their own history.
7. "What did the last person in this role leave undone?" **Why it lands:** it shows you expect the job to have gaps and want to see them.

## 7. Prohibited claims

Each entry names its basis and its honest form. None of these may be asserted, softened, or implied in any answer, slot, or cell above.

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | Dossier prohibited_claims | Plain acknowledgment: "I haven't held a product manager title or role." Then F1's quote at its own scope. No slot. |
| Having owned a product roadmap | Dossier prohibited_claims and acknowledge_gap | Plain acknowledgment from F6: "I haven't owned a roadmap or set prioritization for an engineering squad." V3 at its own scope: "Ran quarterly roadmap-input sessions feeding client evidence to product." |
| Having set prioritization for an engineering squad | Dossier prohibited_claims | Plain acknowledgment from F6, as above. |
| Shipped an API or platform product | Inflated form of V1, built here (F5) | V1 at its own scope. Limit, as this pack's observation: the material shows client-side integration, not a platform shipped. No first-person negative is given for this entry. |
| Drove adoption of the API across 30+ clients | Inflated form of V1, built here: the number attached to the wrong noun, plus an outcome the material does not contain | V1 at its own scope: 30+ integrations. The adoption figure is not in the material. C1's slot asks only what the count held. |

## 8. Sources

- **Provided document:** `tuesday-dossier.md`, dossier_version 1.1, generated 2026-08-14. Sections consumed: `role_profile` (requirement text R1 to R5, unknowns), `handoff_to_mock_interview` (all fields), and `decision` (context only). The dossier does not carry `evidence_map`, `risk_register`, `evidence_state` or `candidate_constraints`. The pack labels its verified entries V1 to V3, by position in `verified_candidate_evidence`, because the dossier does not number them.
- **Age of the dossier:** generated about three months before today. The requirement text has not been checked against a current posting.
- **Searches sent:** "Quartzline company values" (refused: search permission was not granted). "Quartzline interview process Product Manager Platform APIs" (refused).
- **Fetches sent:** none.

Research tier: L1 — searches 2 of 6, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quartzline values | unavailable | Values cheat sheet, section 10. Both calls were refused, so the values section is dropped and the Values persona is unweighted. |
| 2. Quartzline interview process | unavailable | Loop structure. Persona weights rest on the round as you described it, not on a loop source. |
| 3. Quartzline strategy / recent news | unavailable | The CO bank. No CO question is in this pack. |
| 4. Interviewer name | n/a | No name was given, so there was no query to form. The interviewer read and an interviewer-tied reverse question are absent. |
| 5. Representative JD | skipped | The dossier's `role_profile` fixes the requirement lines and the JD-tagged questions. |

## 9. Upgrade menu

- **Current posting text** (the dossier is about three months old) → R1 to R5 become [grounded] from the posting, and F1 to F5 are checked against its current wording.
- **Search permission for this host** → L1 company values and the interview process, which are currently unavailable; these would replace the generic values and loop assumptions. Deep research (L2) is also available, with a strategy brief, interviewer talks, loop reports and recent org context. It is capped at six further searches and two further fetches, and runs only if you ask.
- **Interviewer's name** → persona weights from their public footprint, and a reverse question tied to their own career path.
- **The integration playbook's text, pasted** → A5 and C2 move from answer slots to quoted specifics you can say.
- **Your CV** → A3, A4 and A5 slots become quoted sentences wherever the CV carries them.
- **Whether the 30+ count includes integrations taken only to scoping** → C1's slot becomes a quoted answer.
