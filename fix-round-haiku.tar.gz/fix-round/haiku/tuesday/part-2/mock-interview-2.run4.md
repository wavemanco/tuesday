Your prep pack is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-tuesday-part-2-rooms-case-2-denied-babddb54/bb896c56-96cc-4f7a-a36e-2318e8324fc4/scratchpad/atlas-freight_operations-manager_interview_pack.md`. I built it for a hiring-manager round, since your note didn't say who you're meeting. Web search was refused in this session, so the pack has no company values, interview-process or strategy material.

# Atlas Freight: Operations Manager interview prep pack

## How to use

- **Personas** describe how a question arrives. **Types** describe what is being scored.
- **JD**: tests a requirement the posting states. **EXP**: tests what you actually did in past work. **CASE**: a live problem from this role; it makes no claim about your past.
- Guidance is scaffolding, not a script. Rehearse only what you actually did, in your own words.

## Research status

Web search was attempted three times and every call was refused, so nothing below comes from research. There is no values section, no strategy questions and no interviewer read. No loop source was found, so persona weights rest on the hiring-manager prior and a generic archetype, not on this company's documented process.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| R1 | "Own daily terminal operations across 4 sites" (JD), location and travel | none given | none | [grounded] | hard_gate | Your material does not show where you would be based or whether you can travel between the four sites. Surfaced here, not bridged. Asked in the message below. |
| R2 | "Own daily terminal operations across 4 sites" (JD), scope of experience | "currently a senior shift manager over 3 supervisors" (your message) | medium | [grounded] | transferability | Your material describes one site and three supervisors. Words: "I'm a senior shift manager over three supervisors." Answer slot: if you have run operations across more than one site, say how; if not, say so and describe how you would take on four. |
| R3 | "lead a team of 12 supervisors" (JD) | "currently a senior shift manager over 3 supervisors" (your message) | medium | [grounded] | transferability | Your material shows three supervisors, not twelve. Words: "I'm a senior shift manager over three supervisors." Answer slot: if you have led more than three supervisors, or a team through supervisors, say how; if not, say so and say how you would structure twelve. |
| R4 | "5+ years operations leadership required" (JD) | "7 years in warehouse and distribution ops" (your message) | medium | [grounded] | presentation | Your material gives seven years in operations and does not date the leadership part. Words: "I have seven years in warehouse and distribution operations." |
| R5 | "drive on-time performance and cost-per-shipment down" (JD) | "cut mis-pick rate 40% by redesigning the pick path" (your message) | medium | [grounded] | transferability | Your material shows a mis-pick result, not on-time performance or cost per shipment. Words: the quote itself, then your own account of what you did. Answer slot: if you tracked on-time performance or cost per shipment, say what and how; if not, say so and say which measure you would start with. |
| R6 | "build reporting in Excel/Power BI" (JD), Excel | "solid Excel" (your message) | low | [grounded] | discovery | Your material says Excel and does not show reporting you built. Answer slot: if you have built a recurring report in Excel, name what it tracked and who read it; if not, say so and say what you would build first. |
| R7 | "build reporting in Excel/Power BI" (JD), Power BI | "never used Power BI" (your message) | none | [grounded] | capability | Words: "I've never used Power BI." Then how you would learn it, said as a plan and never as a past. |
| R8 | "Lean/Six Sigma a plus" (JD) | "green belt certified" (your message) | medium | [grounded] | none | Words: "I'm Green Belt certified." Certificate not inspected, so expect a probe on what the belt covered. |
| R9 | Plan for peak volume (role-family requirement, no JD line) | "ran the site's peak-season surge plan two years running" (your message) | medium | [grounded] | none | Words: "I ran the site's peak-season surge plan two years running." Used as story material in the banks. |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Ran operations across four sites | Inflated form of R2 | "I'm a senior shift manager over three supervisors." Your material describes one site. |
| Led twelve supervisors | Inflated form of R3 | Three supervisors, as quoted in R3. |
| Built Power BI reporting | Your own negative, R7 | "I've never used Power BI." |
| Owned on-time performance or cost per shipment | Inflated form of R5 | The mis-pick result, quoted as it stands. |
| Built recurring Excel reporting that leadership read | Inflated form of R6 | "solid Excel", and nothing added to it. |

## Persona table

Relationship unknown, so the hiring-manager prior is used: Case and Skeptic dominant. The generic archetype applies, so the weights are a pattern, not this company's loop.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy | Weight |
|---|---|---|---|---|
| Skeptic | Probes scope, scale and the missing tool | High. R2, R3 and R7 are the gaps a hiring manager screens for, and the JD leads with scope | Hold to what you stated; concede specifically | 5 |
| Case / Strategist | Live problem on sites or on cost per shipment | High. The JD's metric line invites a live diagnosis | Clarify, then structure, then answer | 4 |
| Data-Driven Prober | Asks how the 40% was counted | Medium. It is the one headline number on your side | Defend the number; name your weakest assumption before they do | 3 |
| Pressure | Interrupts, time-boxes, questions how much was yours | Medium. Common at hiring-manager level | Hold through two follow-ups, then concede the specific gap | 3 |
| Conversational | Friendly opener, casual questions | Medium. Casual questions are still scored | Practise a 90-second arc | 2 |
| Peer Evaluator | Seams between teams, handoffs | Low for a manager round; kept so you have met it | Propose principles, not a pretended answer | 2 |

## Question banks

Question IDs are letter-by-persona. Depth follows weight.

### A. Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Four sites is a bigger scope than a shift over three supervisors. What in your background shows you can run more than one site?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" (R2) | Hold to the quote: three supervisors on one site. Answer slot: if you have run operations across more than one site, say how; if not, say so and describe how you would take on four. | R2 is the largest scope gap and the likeliest opening probe. |
| A2 | "Twelve supervisors is well beyond the three you lead today. What makes you the person to lead them?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" (R3) | **Highest-ROI prep in this pack.** Hold: you lead three today, and the way you would structure more is your plan, not a record. Concede specifically: "I haven't led twelve." Hold through two follow-ups by returning to what you do now. Answer slot: if you have led through a second layer of supervision, say how; if not, say so. | The JD states the number; the material stops at three. This will be asked in some form. |
| A3 | "Operations leadership at five years plus: where is yours?" | JD | [grounded] "7 years in warehouse and distribution ops" (R4) | "I have seven years in warehouse and distribution operations." Then say, in your own words, which of those years you led people. | R4 is a presentation gap: the years are there, the leadership dating is not. |
| A4 | "You have no Power BI. How would you build reporting that a regional leadership team reads?" | JD | [grounded] "never used Power BI" (R7) | "I've never used Power BI." Then a plan for learning it and for the first report you would build. Answer slot: if you have built a recurring Excel report, name what it tracked and who read it; if not, say so. | R7 is a stated gap; the honest answer is a plan. |
| A5 | "A pick rate is not on-time performance. Why would we believe you can move on-time performance?" | JD | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (R5) | Give the quote as it stands. Answer slot: if you tracked on-time performance or cost per shipment, say what and how; if not, say which measure you would start with. | R5 is a transferability gap. |

### B. Case / Strategist (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Your four sites have different on-time rates. Where do you start in week one?" | CASE | [generic] role pattern, no sentence about you | Clarify first: which sites, how on-time is defined, what a shipment counts as. Then structure: segment by site, then by shift or lane, then check the data. Name the data you would need before you conclude. | JD line on on-time performance; live problem, no past claim. |
| B2 | "Cost per shipment rose eight percent quarter on quarter. Diagnose it." | CASE | [generic] role pattern, no sentence about you | Clarify the denominator first. Then split the cost into labour, volume and mix. Ask which lever you would test before changing anything. | JD line on cost per shipment; no claim about your past. |
| B3 | "A peak week is three weeks out and two sites are short on supervisors. What do you do?" | CASE | [grounded] "ran the site's peak-season surge plan two years running" (R9) | Story-mapped on R9: the plan ran two years, and that is the beat the quote states. Answer slot: if you set which steps the plan had, say which and how you decided; if others set it, say so and describe your part. | R9 is your strongest peak evidence; the second branch covers a plan you did not set. |
| B4 | "Lean or Six Sigma is a plus here. Where would you apply it first to a site with rising errors?" | JD | [grounded] "green belt certified" (R8) | "I'm Green Belt certified." Then a method you would use, described as a plan. Answer slot: if the pick path work followed a named method, say which; if it did not, say so. | R8 is a none-gap, so the risk is over-claiming how the belt was used. |

### C. Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the 40% mis-pick reduction was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (R5) | Answer slot: if you know how it was counted, say how in your own words; if you do not, say so plainly. Do not reconstruct a method you cannot repeat. | Defend-the-number slot the figure raises. |
| C2 | "Which assumption behind that 40% would you defend least?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (R5) | Name the assumption you are least sure of before they do. The assumption is yours to name, not the pack's. | Weakest-assumption move. |
| C3 | "Of that result, which part was yours and which was the team's?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (R5) | Answer slot: if you did the redesign, say what you did; if others did and you ran the rollout, say so. | Attribution honesty. |

### D. Pressure (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over someone who has run more sites?" | JD | [grounded] "7 years in warehouse and distribution ops" (R4) | Hold: seven years in operations and one measured result. Hold through two follow-ups. Concede specifically: "I haven't run four sites." | Hold-then-concede on the scope gap. |
| D2 | "That 40% — how much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (R5) | Hold the quote. Answer slot: say which part of the redesign was yours, in your own words. | Pressure on attribution. |
| D3 | "You don't have Power BI. Why would we hire you for reporting?" | JD | [grounded] "never used Power BI" (R7) | "I've never used Power BI." Hold on Excel only as the quote carries it, then the plan. | Hold-then-concede on the tool gap. |

### E. Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through how you got into operations." | EXP | [grounded] "7 years in warehouse and distribution ops" (R4) | A 90-second arc from warehouse floor to shift manager, using only the facts you stated. No invented events. | Open prompt; the biography is scored casually. |
| E2 | "What was the peak-season plan in your last role, in a sentence?" | EXP | [grounded] "ran the site's peak-season surge plan two years running" (R9) | "I ran the site's peak-season surge plan two years running." Then one more sentence in your own words. | Short-form version of B3. |

### F. Peer Evaluator (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "If you joined, what would you need from our site leads?" | JD | [generic] role pattern, no sentence about you | Propose principles for handoffs and reporting. Do not pretend to know their seams. | Reciprocity framing. |

Session total: 18 questions. CO and VAL questions are absent because research did not run and no values round was detected.

## Requirement coverage

| JD requirement | Question IDs |
|---|---|
| Own daily terminal operations across 4 sites | A1, B1, R1 (gate, asked in the message) |
| Drive on-time performance and cost-per-shipment down | A5, B1, B2, C1 |
| Lead a team of 12 supervisors | A2 |
| Build reporting in Excel/Power BI | A4, D3 |
| 5+ years operations leadership required | A3, D1 |
| Lean/Six Sigma a plus | B4 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "Is on-time performance measured per site or as one number?" | Shows you know the metric has a definition. |
| 2 | "What would make the first 90 days a success in this role?" | Turns the scope gap into a shared target. |
| 3 | "Which site has the biggest gap to target right now?" | Points at the live problem without assuming one. |
| 4 | "How is the peak-season plan set across the four sites?" | Connects your strongest evidence to their operation. |
| 5 | "Which weekly report do leadership teams read, and who builds it today?" | Shows you have thought about the reporting requirement. |

## Sources

- Provided: the job description, and your background message. Both pasted; no links read.
- Searches sent, all refused: "Atlas Freight regional logistics company values"; "Atlas Freight operations manager interview process"; "Atlas Freight logistics news 2026".

Research tier: L1, searches 3 of 6 (all refused), fetches 0 of 2; user links read 0.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. values | unavailable | Values cheat sheet: not produced. No values round detected. |
| 2. interview process | unavailable | Loop structure: not established. Persona weights use the generic archetype. |
| 3. strategy / recent news | unavailable | Company and strategy questions (CO bank): not produced. |
| 4. interviewer | n/a | No name was given, so there was no query to form. |
| 5. representative JD | skipped | The JD you supplied fixes the fit snapshot and the JD questions. |

## Upgrade menu

- Interviewer's name, or round type → persona weights from their public footprint, and one tailored reverse question.
- On-time rate and cost per shipment, if you tracked them → answers R5's slot, and upgrades A5 from a slot to a story.
- Green Belt certificate or project summary → R8 moves from medium toward high.
- An Excel report you built, and who read it → R6 moves from low to medium.
- Recruiter's prep email → coverage of any pre-declared deliverable.
- Web search permission in a later session → the values, interview-process and news targets, which would add the values section and the strategy questions.

---

Two things I need from you to finish the pack:

1. Is the person you're meeting your future manager, or a peer? That reweights every bank.
2. Are you able to be based at, or travel between, the four sites? The JD makes this a condition, and your material doesn't settle it.

I can also play the Skeptic on A2, the question the pack names as its highest-ROI prep, if you want a live drill. And I can save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: atlas-freight_operations-manager_interview_pack.md -----
# Atlas Freight: Operations Manager interview prep pack

Session pack, first delivery. Built for a hiring-manager round, since your note did not say who you are meeting. Interviewer not named.

## How to use

- **Personas** describe how a question arrives. **Types** describe what is being scored.
- **JD**: tests a requirement the posting states. **EXP**: tests what you actually did in past work. **CASE**: a live problem from this role; it makes no claim about your past.
- Guidance is scaffolding, not a script. Rehearse only what you actually did, in your own words.

## Research status

Web search was attempted three times and every call was refused, so nothing below comes from research. There is no values section, no strategy questions and no interviewer read. No loop source was found, so persona weights rest on the hiring-manager prior and a generic archetype, not on this company's documented process.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| R1 | "Own daily terminal operations across 4 sites" (JD), location and travel | none given | none | [grounded] | hard_gate | Your material does not show where you would be based or whether you can travel between the four sites. Surfaced here, not bridged. Asked in the message below. |
| R2 | "Own daily terminal operations across 4 sites" (JD), scope of experience | "currently a senior shift manager over 3 supervisors" (your message) | medium | [grounded] | transferability | Your material describes one site and three supervisors. Words: "I'm a senior shift manager over three supervisors." Answer slot: if you have run operations across more than one site, say how; if not, say so and describe how you would take on four. |
| R3 | "lead a team of 12 supervisors" (JD) | "currently a senior shift manager over 3 supervisors" (your message) | medium | [grounded] | transferability | Your material shows three supervisors, not twelve. Words: "I'm a senior shift manager over three supervisors." Answer slot: if you have led more than three supervisors, or a team through supervisors, say how; if not, say so and say how you would structure twelve. |
| R4 | "5+ years operations leadership required" (JD) | "7 years in warehouse and distribution ops" (your message) | medium | [grounded] | presentation | Your material gives seven years in operations and does not date the leadership part. Words: "I have seven years in warehouse and distribution operations." |
| R5 | "drive on-time performance and cost-per-shipment down" (JD) | "cut mis-pick rate 40% by redesigning the pick path" (your message) | medium | [grounded] | transferability | Your material shows a mis-pick result, not on-time performance or cost per shipment. Words: the quote itself, then your own account of what you did. Answer slot: if you tracked on-time performance or cost per shipment, say what and how; if not, say so and say which measure you would start with. |
| R6 | "build reporting in Excel/Power BI" (JD), Excel | "solid Excel" (your message) | low | [grounded] | discovery | Your material says Excel and does not show reporting you built. Answer slot: if you have built a recurring report in Excel, name what it tracked and who read it; if not, say so and say what you would build first. |
| R7 | "build reporting in Excel/Power BI" (JD), Power BI | "never used Power BI" (your message) | none | [grounded] | capability | Words: "I've never used Power BI." Then how you would learn it, said as a plan and never as a past. |
| R8 | "Lean/Six Sigma a plus" (JD) | "green belt certified" (your message) | medium | [grounded] | none | Words: "I'm Green Belt certified." Certificate not inspected, so expect a probe on what the belt covered. |
| R9 | Plan for peak volume (role-family requirement, no JD line) | "ran the site's peak-season surge plan two years running" (your message) | medium | [grounded] | none | Words: "I ran the site's peak-season surge plan two years running." Used as story material in the banks. |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Ran operations across four sites | Inflated form of R2 | "I'm a senior shift manager over three supervisors." Your material describes one site. |
| Led twelve supervisors | Inflated form of R3 | Three supervisors, as quoted in R3. |
| Built Power BI reporting | Your own negative, R7 | "I've never used Power BI." |
| Owned on-time performance or cost per shipment | Inflated form of R5 | The mis-pick result, quoted as it stands. |
| Built recurring Excel reporting that leadership read | Inflated form of R6 | "solid Excel", and nothing added to it. |

## Persona table

Relationship unknown, so the hiring-manager prior is used: Case and Skeptic dominant. The generic archetype applies, so the weights are a pattern, not this company's loop.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy | Weight |
|---|---|---|---|---|
| Skeptic | Probes scope, scale and the missing tool | High. R2, R3 and R7 are the gaps a hiring manager screens for, and the JD leads with scope | Hold to what you stated; concede specifically | 5 |
| Case / Strategist | Live problem on sites or on cost per shipment | High. The JD's metric line invites a live diagnosis | Clarify, then structure, then answer | 4 |
| Data-Driven Prober | Asks how the 40% was counted | Medium. It is the one headline number on your side | Defend the number; name your weakest assumption before they do | 3 |
| Pressure | Interrupts, time-boxes, questions how much was yours | Medium. Common at hiring-manager level | Hold through two follow-ups, then concede the specific gap | 3 |
| Conversational | Friendly opener, casual questions | Medium. Casual questions are still scored | Practise a 90-second arc | 2 |
| Peer Evaluator | Seams between teams, handoffs | Low for a manager round; kept so you have met it | Propose principles, not a pretended answer | 2 |

## Question banks

Question IDs are letter-by-persona. Depth follows weight.

### A. Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Four sites is a bigger scope than a shift over three supervisors. What in your background shows you can run more than one site?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" (R2) | Hold to the quote: three supervisors on one site. Answer slot: if you have run operations across more than one site, say how; if not, say so and describe how you would take on four. | R2 is the largest scope gap and the likeliest opening probe. |
| A2 | "Twelve supervisors is well beyond the three you lead today. What makes you the person to lead them?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" (R3) | **Highest-ROI prep in this pack.** Hold: you lead three today, and the way you would structure more is your plan, not a record. Concede specifically: "I haven't led twelve." Hold through two follow-ups by returning to what you do now. Answer slot: if you have led through a second layer of supervision, say how; if not, say so. | The JD states the number; the material stops at three. This will be asked in some form. |
| A3 | "Operations leadership at five years plus: where is yours?" | JD | [grounded] "7 years in warehouse and distribution ops" (R4) | "I have seven years in warehouse and distribution operations." Then say, in your own words, which of those years you led people. | R4 is a presentation gap: the years are there, the leadership dating is not. |
| A4 | "You have no Power BI. How would you build reporting that a regional leadership team reads?" | JD | [grounded] "never used Power BI" (R7) | "I've never used Power BI." Then a plan for learning it and for the first report you would build. Answer slot: if you have built a recurring Excel report, name what it tracked and who read it; if not, say so. | R7 is a stated gap; the honest answer is a plan. |
| A5 | "A pick rate is not on-time performance. Why would we believe you can move on-time performance?" | JD | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (R5) | Give the quote as it stands. Answer slot: if you tracked on-time performance or cost per shipment, say what and how; if not, say which measure you would start with. | R5 is a transferability gap. |

### B. Case / Strategist (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Your four sites have different on-time rates. Where do you start in week one?" | CASE | [generic] role pattern, no sentence about you | Clarify first: which sites, how on-time is defined, what a shipment counts as. Then structure: segment by site, then by shift or lane, then check the data. Name the data you would need before you conclude. | JD line on on-time performance; live problem, no past claim. |
| B2 | "Cost per shipment rose eight percent quarter on quarter. Diagnose it." | CASE | [generic] role pattern, no sentence about you | Clarify the denominator first. Then split the cost into labour, volume and mix. Ask which lever you would test before changing anything. | JD line on cost per shipment; no claim about your past. |
| B3 | "A peak week is three weeks out and two sites are short on supervisors. What do you do?" | CASE | [grounded] "ran the site's peak-season surge plan two years running" (R9) | Story-mapped on R9: the plan ran two years, and that is the beat the quote states. Answer slot: if you set which steps the plan had, say which and how you decided; if others set it, say so and describe your part. | R9 is your strongest peak evidence; the second branch covers a plan you did not set. |
| B4 | "Lean or Six Sigma is a plus here. Where would you apply it first to a site with rising errors?" | JD | [grounded] "green belt certified" (R8) | "I'm Green Belt certified." Then a method you would use, described as a plan. Answer slot: if the pick path work followed a named method, say which; if it did not, say so. | R8 is a none-gap, so the risk is over-claiming how the belt was used. |

### C. Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the 40% mis-pick reduction was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (R5) | Answer slot: if you know how it was counted, say how in your own words; if you do not, say so plainly. Do not reconstruct a method you cannot repeat. | Defend-the-number slot the figure raises. |
| C2 | "Which assumption behind that 40% would you defend least?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (R5) | Name the assumption you are least sure of before they do. The assumption is yours to name, not the pack's. | Weakest-assumption move. |
| C3 | "Of that result, which part was yours and which was the team's?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (R5) | Answer slot: if you did the redesign, say what you did; if others did and you ran the rollout, say so. | Attribution honesty. |

### D. Pressure (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over someone who has run more sites?" | JD | [grounded] "7 years in warehouse and distribution ops" (R4) | Hold: seven years in operations and one measured result. Hold through two follow-ups. Concede specifically: "I haven't run four sites." | Hold-then-concede on the scope gap. |
| D2 | "That 40% — how much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (R5) | Hold the quote. Answer slot: say which part of the redesign was yours, in your own words. | Pressure on attribution. |
| D3 | "You don't have Power BI. Why would we hire you for reporting?" | JD | [grounded] "never used Power BI" (R7) | "I've never used Power BI." Hold on Excel only as the quote carries it, then the plan. | Hold-then-concede on the tool gap. |

### E. Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through how you got into operations." | EXP | [grounded] "7 years in warehouse and distribution ops" (R4) | A 90-second arc from warehouse floor to shift manager, using only the facts you stated. No invented events. | Open prompt; the biography is scored casually. |
| E2 | "What was the peak-season plan in your last role, in a sentence?" | EXP | [grounded] "ran the site's peak-season surge plan two years running" (R9) | "I ran the site's peak-season surge plan two years running." Then one more sentence in your own words. | Short-form version of B3. |

### F. Peer Evaluator (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "If you joined, what would you need from our site leads?" | JD | [generic] role pattern, no sentence about you | Propose principles for handoffs and reporting. Do not pretend to know their seams. | Reciprocity framing. |

Session total: 18 questions. CO and VAL questions are absent because research did not run and no values round was detected.

## Requirement coverage

| JD requirement | Question IDs |
|---|---|
| Own daily terminal operations across 4 sites | A1, B1, R1 (gate, asked in the message) |
| Drive on-time performance and cost-per-shipment down | A5, B1, B2, C1 |
| Lead a team of 12 supervisors | A2 |
| Build reporting in Excel/Power BI | A4, D3 |
| 5+ years operations leadership required | A3, D1 |
| Lean/Six Sigma a plus | B4 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "Is on-time performance measured per site or as one number?" | Shows you know the metric has a definition. |
| 2 | "What would make the first 90 days a success in this role?" | Turns the scope gap into a shared target. |
| 3 | "Which site has the biggest gap to target right now?" | Points at the live problem without assuming one. |
| 4 | "How is the peak-season plan set across the four sites?" | Connects your strongest evidence to their operation. |
| 5 | "Which weekly report do leadership teams read, and who builds it today?" | Shows you have thought about the reporting requirement. |

## Sources

- Provided: the job description, and your background message. Both pasted; no links read.
- Searches sent, all refused: "Atlas Freight regional logistics company values"; "Atlas Freight operations manager interview process"; "Atlas Freight logistics news 2026".

Research tier: L1, searches 3 of 6 (all refused), fetches 0 of 2; user links read 0.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. values | unavailable | Values cheat sheet (section 10): not produced. No values round detected. |
| 2. interview process | unavailable | Loop structure: not established. Persona weights use the generic archetype. |
| 3. strategy / recent news | unavailable | Company and strategy questions (CO bank): not produced. |
| 4. interviewer | n/a | No name was given, so there was no query to form. |
| 5. representative JD | skipped | The JD you supplied fixes the fit snapshot and the JD questions. |

## Upgrade menu

- Interviewer's name, or round type → persona weights from their public footprint, and one tailored reverse question.
- On-time rate and cost per shipment, if you tracked them → answers R5's slot, and upgrades A5 from a slot to a story.
- Green Belt certificate or project summary → R8 moves from medium toward high.
- An Excel report you built, and who read it → R6 moves from low to medium.
- Recruiter's prep email → coverage of any pre-declared deliverable.
- Web search permission in a later session → the values, interview-process and news targets, which would add the values section and the strategy questions.
