Your prep pack is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-tuesday-part-2-rooms-case-3-denied-97cd106a/d93caab0-825a-47fd-b737-7b11d3920757/scratchpad/stripe_product-operations-manager_interview_pack.md`.

Web search was refused in this session, so the pack has no Stripe-specific values, interview-loop details or current strategy. Everything in it is generic to Product Operations Manager roles, and I did not fill those gaps from memory. The pack has 18 questions across four interviewer styles. The highest-value prep is B1, "Give me one thing you changed that stuck." With no CV on the page yet, that is the objection most likely to come up.

Two things would make this much sharper:

1. **Who is in the final round, and is it one session or several?** A hiring manager, a peer, or a cross-functional partner each call for different emphasis.
2. **Your CV and the job description.** With them, the pack can quote your own sentences and turn the generic rows into specific ones.

If you'd like me to run a live drill, I can play the Skeptic on B1. I can also save a `tuesday-dossier.md` to carry the gaps this prep exposed, or convert the pack to Word.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: stripe_product-operations-manager_interview_pack.md -----
# Stripe, Product Operations Manager: final-round interview pack

Built on the company and role title only. No CV, no job description, no interviewer name, and no web research (search was refused this session), so every guidance cell is `[generic]` and the personas are weighted on round type alone.

## How to use

- **Personas** describe how a question is asked (the register). **Types** describe what is being scored.
- **VAL**: behavioral and values alignment. **EXP**: deep-dive on your own experience. **JD**: the role's responsibilities. **CO**: company and strategy knowledge. **CASE**: a live problem.
- Guidance is scaffolding, not a script. Where a cell says "answer slot", the content is yours to supply in your own words. The pack writes no claim about your past.

## Fit snapshot (worksheet variant)

No JD was supplied and no representative JD could be fetched, so the requirements below are role-family requirements written as plain prose, not quotes. No CV was supplied, so every evidence cell reads `none given`. Gap type is `discovery` for every row, because silence is not capability.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Designing and running operating processes across several teams (role family) | none given | none | [generic] | discovery | Strong evidence looks like a process you designed, the teams it touched, and how you know it worked. Answer slot: name a process you introduced or changed. If you did not design it, say whose it was and what you changed in it. If none comes to mind, say so plainly and give the nearest thing you did carry through. |
| F2 | Leading launches or programs across teams without direct authority (role family) | none given | none | [generic] | discovery | Strong evidence looks like a launch you coordinated with named owners, the dates, and where it slipped. Answer slot: name one launch and your part in it, in your own words. If you were not the coordinator, say so and describe your actual role. |
| F3 | Defining and tracking metrics for a process or product area (role family) | none given | none | [generic] | discovery | Strong evidence looks like a metric you chose, how it was counted, and what you did when it moved. Answer slot: name a metric you tracked and how it was counted. If you tracked none, say so and say what you would measure first. |
| F4 | Intake and prioritization across a shared backlog or request queue (role family) | none given | none | [generic] | discovery | Strong evidence looks like a rule you set for what gets done first and who decided. Answer slot: describe a queue you triaged and the rule you used. If you did not set the rule, say whose it was. |
| F5 | Building or configuring tools and automation for internal workflows (role family) | none given | none | [generic] | discovery | Strong evidence looks like a tool you built or configured, who used it, and what they stopped doing. Answer slot: name one tool or automation and its users. If you only requested one, say so and describe what you asked for. |
| F6 | Influencing stakeholders and handling disagreement (role family) | none given | none | [generic] | discovery | Strong evidence looks like a disagreement with a named stake, what you held, and what you conceded. Answer slot: describe one disagreement and where you held or changed position. |
| F7 | Keeping a process working as volume or headcount grows (role family) | none given | none | [generic] | discovery | Strong evidence looks like a process you changed because the old one broke at scale. Answer slot: name what broke and what you changed. If nothing broke, say so and say what you would watch for. |
| F8 | Writing decision logs, updates, and memos that others can act on (role family) | none given | none | [generic] | discovery | Strong evidence looks like a document someone else used a year later. Answer slot: name one document and who used it. If you did not write one, say what you wrote instead. |

## Prohibited list

No entries. Nothing has been quoted from your material yet, so there is no sentence to stretch and no claim to limit. This list becomes live once your CV or your own sentences are in the pack. Every rehearsal here is also bound by one rule: say what you did, and let the interviewer draw the inference.

## Persona table

Relationship and round type are not known. Weights are therefore the round-type prior for a final round (hiring manager and peer), not a read on a named person.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | A live process problem, delivered as a whiteboard-style prompt | High. A product-operations role is mostly process problems, and a final round usually tests one live | Structure first: goal, who it is for, constraints, then options and a recommendation |
| Skeptic | "Show me one thing you changed that stuck." | High. With no evidence on the page yet, every claim will be probed | Hold the claim for two follow-ups, then concede the specific limit |
| Peer Evaluator / Data-Driven Prober | Asks how a metric was counted and what the denominator was | Medium. Typical of a cross-functional peer | Name the metric's weakest assumption before they do |
| Values / Behavioral | "Tell me about a time…" | Medium. No values round is established (see Sources), so this is a general prior | Choose one real instance with a named stake; give the honest branch if none fits |

Depth follows weight: Case and Skeptic get five questions each; Peer and Values get four each.

## Question banks

### A. Case / Strategist (weight: high, 5 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A set of product teams keeps slipping launches because each runs its own checklist. How would you design a shared launch process?" | CASE | [generic] | Clarify what slips and why before proposing anything. Propose a small shared core with room for team-level variation. Define two or three measures of whether it works, and name the adoption risk and how you would test it early. | A live problem from the role family. [generic], because it is a pattern for the problem, not a fact about this company. |
| A2 | "A team's request queue has about 200 items a month and no agreed order. What do you do first?" | CASE | [generic] | Separate request types. Ask the owners what each item costs if it waits. Set one intake rule with a named decider, and say what you would stop doing. | Intake and prioritization (F4) is a standard hiring-manager problem. |
| A3 | "A weekly manual report takes a day and keeps being wrong. Automate it or fix the upstream data?" | CASE | [generic] | Ask what the report is for and who acts on it. Check whether the error starts upstream. Recommend the cheaper fix that removes the error, and say what would change your mind. | Tests F5 and the judgment behind tool choices. |
| A4 | "Which metric would you put on the dashboard for a weekly operating review, and what would make you distrust it?" | JD | [generic] | Pick one metric and say what it measures. Name the assumption behind it that you would defend least, before the interviewer does. Name one signal that would tell you the metric is gamed. | Tests F3 at the level of judgment, not numbers. The weakest-assumption move is the one most candidates skip. |
| A5 | "What would your first 90 days look like in this role?" | JD | [generic] | Listen and map first: who owns which process, where the handoffs break. Pick one bottleneck to fix by day 60, with a stated test. Say what you would not touch yet. | Tests F7 and how you start in an unfamiliar org. A plan is not a past claim, so no answer slot is needed. |

### B. Skeptic (weight: high, 5 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Give me one thing you changed that stuck, and tell me how you know it stuck." | EXP | [generic] | Highest-ROI prep in this pack. Pick a process change you were part of that outlived your involvement. Give the change, then the evidence it held. Answer slot: if you did not design it, say whose it was and what you did; if none comes to mind, say so plainly and give the nearest thing you carried through. Hold the claim through two follow-ups, then concede the specific limit. | Nothing is on the page yet, so this is the objection most likely to arrive in some form. |
| B2 | "That sounds like coordination, not operations. What did you actually decide?" | JD | [generic] | Name the decisions you made, one at a time, and whom they affected. Hold your position through two follow-ups. Concede specifically where another person decided. | A pressure probe on F1 and F2. The hold-then-concede structure applies. |
| B3 | "Who pushed back on you hardest, and did you change your mind?" | VAL | [generic] | Choose one real disagreement with a named stake. Say what you held, what you conceded, and why. Answer slot: if you never changed your mind, say so and say what you learned from holding. | Tests F6 under pressure. A plain "I did not change my mind" answer is acceptable if it is true. |
| B4 | "Tell me about the last process you ran that broke. What broke?" | EXP | [generic] | Name the failure first, not the recovery. Say what signal you missed and when. Keep the blame where it is true, including on yourself. | Tests F7 and honesty about failure. Recovery stories with no failure in them are scored as spin. |
| B5 | "Ops teams write a lot of documents. What did you write that someone else used?" | EXP | [generic] | Name the document, who used it, and one thing they did because of it. Describe what you did, not adjectives such as "clear" or "strategic." | Tests F8. The interviewer is asking for evidence of use, not authorship. |

### C. Peer Evaluator / Data-Driven Prober (weight: medium, 4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Pick a metric you used to judge whether a process was healthy. How was it counted?" | EXP | [generic] | Answer slot: name the metric and how it was counted, then what it is sensitive to, then the assumption you would defend least, then which part of the number was yours. If you used no metric, say so and say what you would use. Never explain a method you cannot repeat under a second question. | Tests F3. Defend-the-number is the probe a prober will run. |
| C2 | "Two of your partner teams disagree about a launch date and each has a reasonable case. What do you do?" | CASE | [generic] | Separate what is fixed from what is negotiable. Name who decides and by when. Propose a decision rule that both teams can accept, and say what you would do if neither accepts it. | Tests F2 from a peer's point of view. |
| C3 | "Describe a tool or automation you built or configured for a team. Who used it, and what did they stop doing?" | EXP | [generic] | Name the tool, its users, and the manual step it removed. Answer slot: if you requested rather than built it, say so and describe what you asked for. | Tests F5 with a concrete outcome. "Stop doing" is more checkable than "saved time." |
| C4 | "How do you keep a decision log so people can find the decision six months later?" | JD | [generic] | Describe the format you use or would use: what is recorded, where it lives, and who checks it. Name one decision that was later reopened and what the log did for it. | Tests F8 and whether the candidate thinks about durability. |

### D. Values / Behavioral (weight: medium, 4 questions)

Stripe's published values were not retrieved (see Sources). These questions are therefore general behavioral prompts, not values questions. Do not prepare against values from memory.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell me about a time you made a call with incomplete information." | VAL | [generic] | Pick a decision with a named stake. Say what you knew, what you did not, what you did, and how you checked it afterward. If none comes to mind, say so plainly, then give the nearest thing your experience carries. | An open prompt. The candidate chooses the instance. |
| D2 | "Tell me about a time you were wrong about a process and changed it." | VAL | [generic] | Name the wrong belief, the evidence that showed it, and the change. Keep the story short and specific. | Tests honest self-correction, a common final-round theme for ops roles. |
| D3 | "Describe a time you pushed back on a senior stakeholder. What happened?" | VAL | [generic] | Named stake, a moment you did not fold, and a relationship intact at the end. Answer slot: if you did not push back, say so and describe the nearest disagreement. | Overlaps with B3. Use a different story if one exists, so you have two for the loop. |
| D4 | "What recent thing did you do because a user asked, not because a plan said so?" | VAL | [generic] | Name the request, what you did, and what changed for the user. Say whether you agreed with the request. | Tests user focus in a way that does not rely on values slogans. |

## Requirement coverage

| Requirement | Covered by |
|---|---|
| F1 Designing operating processes | A1, C4 |
| F2 Leading cross-team launches | A1, C2, B2 |
| F3 Metrics and tracking | A4, C1 |
| F4 Intake and prioritization | A2 |
| F5 Tools and automation | A3, C3 |
| F6 Stakeholder influence | B2, B3, D3 |
| F7 Scaling a process | A5, B4 |
| F8 Written communication | B5, C4 |

No requirement is left uncovered. Every row above is a generic role-family requirement, not a quote from a JD.

## Reverse questions

1. "What does a good partnership between operations and product look like here, and what does a bad one look like?" *Why it lands:* it shows you think about the role's interface, not only its tasks.
2. "Which process here would you most like to see improved, and what is blocking it?" *Why it lands:* it asks the interviewer to name a real problem, and you can respond with a concrete idea.
3. "How do you measure success for this role in the first year?" *Why it lands:* it turns the job description into a scorecard you can plan against.
4. "How do launches get owned between operations and the product teams?" *Why it lands:* it surfaces the ownership boundary the role will live inside.
5. "What did the last person in this role get right, and what would you change?" *Why it lands:* it invites candor and shows you are planning to build on what exists.

If the interviewer turns out to be a peer, add: "What could a new person do in their first month that would genuinely help your team?" That is the reciprocity question for peers.

## Sources

- **Provided documents:** the company and role title from the request. Nothing else.
- **Searches sent (all refused by the host, which did not grant search permission):**
  - `Stripe company values operating principles`: refused
  - `Stripe interview process product operations manager final round`: refused
  - `Stripe strategy 2026 news priorities`: refused
  - `Product Operations Manager job description Stripe`: refused
- **Fetches:** none.

**Research tier:** L1 requested by default; searches 0 of 6, fetches 0 of 2 (every search refused by the host).

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `{company} values` | unavailable | Would have fixed the published values for section 10 and the values bank (D). Not used. Values are not stated in this pack. |
| 2. `{company} interview process {role family}` | unavailable | Would have set the loop structure and persona weights. Weights here are the round-type prior. |
| 3. `{company} strategy` / recent news | unavailable | Would have fed a CO bank. No CO questions are written. |
| 4. `{interviewer name} {company}` | n/a | No interviewer name was given, so there was no query to form. |
| 5. representative `{role title}` JD | unavailable | Would have turned the role-family requirements into `[inferred]` quotes. They remain `[generic]` prose. |

## Upgrade menu

- **Your CV, or a few of your own sentences about past projects** → evidence cells quote your words, rows F1 to F8 move from `none given` to grounded quotes, and the answer slots become story maps.
- **The job description** → the role-family requirements become quoted requirements, and any hard gate in the posting is surfaced in its own row.
- **Who is in the final round, and whether it is one session or several** → persona weights are set for those people, and per-session mini-packs can be built if the schedule is several sessions.
- **Interviewer names** → a tailored reverse question and persona weights from their public footprint.
- **Recruiter's prep email** → coverage of any declared assignment or deliverable.
- **Working web search** → Stripe's own values page, the interview-process sources, and the current strategy, so that sections D and CO can be written from sources and not from memory. Rerun once search is permitted.
