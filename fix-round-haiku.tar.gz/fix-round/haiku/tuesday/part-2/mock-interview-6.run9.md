Your prep pack is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-tuesday-part-2-rooms-case-6-denied-d55a684a/52ce3efa-358d-49fd-97ac-ba9a63d7fedb/scratchpad/larkfield_engineering_manager_interview_pack.md`. It covers all three rounds in one shared fit snapshot, with a mini-pack per round.

Three things to know before you open it:

- **No Larkfield research ran.** Both search calls were refused by the search permission, so I have nothing on Larkfield's values, loop format or strategy. I left the values cheat sheet out and didn't fill those gaps from memory. The Monday round's values questions use selection scaffolds instead, with an honest branch where your material has no story.
- **The biggest risk is the hardware roadmap.** You've said you've never owned a hardware-adjacent roadmap, and the role asks for exactly that partnership. Question A3 in the Tuesday round is the one to rehearse hardest. Your answer should be a plan, not a past.
- **The 60% on-call number will be probed.** Expect the Director and the Prober to ask how it was counted and which part was yours. Rehearse A6 and B3 until you can name the assumption you'd defend least.

I can also run a drill on any question. Say which round and persona, and I'll play it.

I can save a `tuesday-dossier.md` that records the gaps this prep exposed, for carrying into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

Two questions that would change the pack:

1. Does the role require anything your material doesn't mention, such as on-site days, a specific location, travel to plants or hardware sites, or work authorization?
2. Did the recruiter announce a take-home, presentation or pre-read for any of the rounds?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: larkfield_engineering_manager_interview_pack.md -----
# Interview prep pack: Engineering Manager, Larkfield Systems (loop mode, 3 rounds)

**Candidate:** Yusuf
**Rounds:** (1) Tuesday, 45 min, hiring manager (Director of Engineering, would-be boss). (2) Thursday, 60 min, panel: two staff engineers and a product manager. (3) Following Monday, 30 min, VP Engineering, recruiter's description "values and leadership philosophy".
**Changelog:** First pass. No prior version.

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored: VAL (values), EXP (your past work), JD (the role's requirements), CO (company knowledge), CASE (a live problem).
- Guidance is scaffolding for a spoken answer, not a script. Rehearse only what you did, in your own words.
- Every row labels its source. [grounded] traces to a sentence you wrote or the role text you gave me. [inferred] is my derivation. [generic] is a pattern for this kind of role and makes no claim about Larkfield.

## Research status

Research did not run. My two searches for Larkfield values and interview process were refused by the search permission. Nothing below about Larkfield's values, loop format, or strategy is established, and I have not filled those gaps from memory. The values cheat sheet is therefore omitted. The loop structure rests on what the recruiter told you about each round, not on Larkfield's published process.

## Fit snapshot (shared across all three rounds)

Requirements come from the role text you gave me ("Engineering Manager — Larkfield Systems ..."). I have not seen a full job description, so each requirement is quoted from that text.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" (role text) | "9 years engineering, 3 as a team lead of 6, currently at a payments company" (your message) | medium | [grounded] | transferability | Your material shows one team of six for three years, not two squads and not device management. Say it in those terms: "For three years I was team lead of six." Answer slot: if you ever coordinated more than one group, say how and what you decided, in your own words; if not, say you led one team. |
| F2 | "Lead two squads building device-management services" (role text) | none given | none | [grounded] | discovery | The material says nothing about device, fleet or telemetry services. Answer slot: if you have built or run any such service, say which and what your part was; if not, say so and say how you would learn the domain. |
| F3 | "partner with hardware and product on roadmap" (role text) | "never owned a hardware-adjacent roadmap" (your message) | none | [grounded] | capability | Words you gave me: "I haven't owned a hardware-adjacent roadmap." Then how you would learn it, said as a plan and never as a past. |
| F4 | "own delivery, hiring and growth for 11 engineers" (role text) | "I run our hiring loop for backend roles — about 40 interviews last year." (your message) | medium | [grounded] | presentation | Reword only what the quote says: "I run our hiring loop for backend roles, about 40 interviews last year." Do not add offer approval, sourcing or headcount planning. |
| F5 | "own delivery, hiring and growth for 11 engineers" (role text) | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." (your message) | medium | [grounded] | none | The quote reaches delivery in role terms, so lead with it. Expect a probe on the 60%: how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. |
| F6 | "own delivery, hiring and growth for 11 engineers" (role text) | none given | none | [grounded] | discovery | The material says nothing about growth (promotions, development plans, underperformance). Answer slot: if you have grown engineers, say what you did and what changed for them; if not, say so and say what you would do first. |
| F7 | "partner with hardware and product on roadmap" (role text) | "pushed a reliability quarter through against roadmap pressure" (your message) | low | [inferred] | transferability | This shows roadmap negotiation with product, not with hardware. Derivation: the quote is the nearest product-side evidence. Say it at its own scope and leave the hardware half to F3. |

Not assessed: whether the role has any gate (on-site days, location, travel, work authorization). The role text does not mention one, and I have not invented one. Question 1 asks.

## Prohibited claims

Built from the fit snapshot. Each entry names its basis.

| Not coached | Basis | Honest form |
|---|---|---|
| "I led two squads" or "I led device-management services" | Inflated form of F1 and F2 | F1's quote at its own scope. The pack's observation, not words for you: your material shows one team of six. |
| "I owned delivery for 11 engineers" | Inflated form of F4 and F5 | F4 and F5 quotes at their own scope. Your material shows a team of six. |
| "I've managed managers" or any manager-of-managers experience | Negative you stated | "I've never managed managers." Plain acknowledgment. No slot. |
| "I've owned a hardware roadmap" | Negative you stated, F3 | "I haven't owned a hardware-adjacent roadmap." Plain acknowledgment. |
| Any account of how the reliability quarter was designed, scoped or staffed | Incident or practice inflation of F5 | F5's quote at its own scope. Only the answer slots below ask about it. |

## Round A: Tuesday, hiring manager (Director of Engineering)

**Relationship prior:** hiring manager. Dominant personas are Case/Strategist and Skeptic. The Director is buying capability and derisking the gaps in F1 to F3, so expect live problems on the actual roadmap.

**Persona weights:**

| Persona | Depth | How it shows up | Why | Counter-strategy |
|---|---|---|---|---|
| Case/Strategist | 4 | Live problems on the roadmap | Hiring manager buys capability | Clarify, then structure, then answer |
| Skeptic | 3 | Probing F1 to F3 | Gaps are the risk to them | Rehearse the top objection until plain |
| Pressure | 2 | Time-boxed challenge to F5 | Tests composure around the 60% | Hold through two follow-ups, then concede |
| Data-Driven Prober | 1 | Denominator on the 60% | Their first question on any metric | Name the weakest assumption first |

**Highest-ROI prep for this round:** A3. It is the objection this candidate will meet in some form. Rehearse it until the honest answer is boring.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Your first 90 days: two squads, one with a hardware dependency. What do you need to know before you change anything?" | CASE | [generic] | Clarify the objective, then the squads' current delivery, then the hardware dependency, then what you would change first and how you would measure it. Name the risk you would watch hardest. Makes no claim about your past. | A live problem from the role text (F1, F3). Asked as a decision, not a record. |
| A2 | "A device fleet's firmware update failure rate doubled this quarter. Diagnose it." | CASE | [generic] | Clarify the fleet, the failure definition and the timeline. Segment by hardware variant, then by update path. Propose a test before a fix. | A hardware-adjacent live problem for F3's gap. Pattern only. |
| A3 | "You haven't owned a hardware-adjacent roadmap. How would you run one?" | JD | [grounded] "I haven't owned a hardware-adjacent roadmap." | Highest-ROI rehearsal. The honest answer is a plan, not a past: how you would learn the hardware constraints, who you would ask first, and what you would not promise in the first quarter. Answer slot: if you have shaped a roadmap with a non-software dependency at any level, say which and what your part was; if not, say so and give the plan. Hold through two follow-ups by returning to the plan. | F3 is where the role's roadmap partnership presses hardest. The premise is your own stated negative, so this is a plain acknowledgment with a source. |
| A4 | "Two squads and eleven engineers, and you have led six. What makes you ready for the step up?" | Skeptic | [grounded] "9 years engineering, 3 as a team lead of 6" | Story-mapped on F1: you led six for three years. Answer slot: if you coordinated more than one group, say how; if not, say so and say what you would do on day one to run two. Do not describe a scale-up you did not do. | F1 is the gap the Director will name first. |
| A5 | "Walk me through the reliability quarter." | EXP | [grounded] "I pushed a reliability quarter through against roadmap pressure" | Story-mapped on F5. Tell it in your words: what the quarter was, what the roadmap pressure was, and what you pushed. Answer slot: if you set the scope or the trade-off, say so; if someone else did, say so plainly and describe what you did. | Premised on F5's quote. It is the story most likely to open the metric probe. |
| A6 | "That 60% drop: walk me through how it was counted." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through" | Defend the number: the window, the baseline, what counts as on-call, and what the figure is sensitive to. Name the assumption you would defend least before they do. Answer slot: if you counted it yourself, say how; if you did not, say so plainly and give the source you used. | Defend-the-number slot for F5. |
| A7 | "How much of that 60% was actually you?" | Pressure | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through" | Hold: "I pushed the quarter through." Concede specifically what the team did, what your manager did, and what you cannot attribute to yourself. Do not fold on the core claim to restore harmony. | Pressure stem on F5. The hold is what the quote carries, no more. |
| A8 | "Which part of this role would you be weakest at on day one?" | Skeptic | [grounded] "never owned a hardware-adjacent roadmap" | Name the weakest part honestly: the hardware roadmap (F3). Then give the plan: what you would learn first, from whom, and what you would delegate. Do not offer a bridge you did not build. | Skeptic stem aimed at F3. |

**Requirement coverage:**

| Requirement | Covered by |
|---|---|
| Lead two squads building device-management services | A1, A4 |
| Own delivery, hiring and growth for 11 engineers | A5, A6, A7 |
| Partner with hardware and product on roadmap | A2, A3, A8 |

**Reverse questions for this round:**

- "What would the first 90 days need to deliver for you to call the hire a success?" Why it lands: it is the Director's own scoring rubric for the role, asked openly.
- "Which of the two squads carries the bigger delivery risk right now, and why?" Why it lands: it tells you where the 60% story will matter most.
- "What is the hardest roadmap trade-off the squads will face this year?" Why it lands: it turns the F3 gap into a conversation about the real problem.
- "What would make you regret hiring someone at this level?" Why it lands: a direct read of the Director's real fear.
- "Who in the hardware org would I work with most, and what do they need from the software side?" Why it lands: it signals you are planning to learn the domain, not pretending you know it.

## Round B: Thursday, panel (two staff engineers and a product manager)

**Relationship prior:** panel. Members are not named, so I blend the top two personas for each member's relationship. The two staff engineers carry Peer Evaluator and Data-Driven Prober. The product manager carries Case/Strategist and Conversational.

**Persona weights:**

| Persona | Depth | Member | How it shows up | Counter-strategy |
|---|---|---|---|---|
| Peer Evaluator | 5 | Staff engineers | Seam questions, disagreement, credit | Reciprocity framing, seam principles, not invented seams |
| Data-Driven Prober | 3 | Staff engineers | Denominator on the 60% | Name the weakest assumption first |
| Case/Strategist | 3 | Product manager | Roadmap sequencing live | Clarify, structure, one challenged premise |
| Conversational | 1 | Product manager | Casual opener | Script the 90-second arc, treat it as scored |

Peer and prober questions split between the two staff engineers. Case and conversational questions go to the product manager.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our teams sit side by side. Where's the seam, and what happens when we disagree?" | JD | [generic] | Propose seam principles rather than pretending to know the seam: who decides scope, who holds the on-call. For disagreement, give a selection scaffold: "pick a time you disagreed with an equal and kept the working relationship; if none comes to mind, say so plainly, then describe the nearest one." | Peer question on partnership fit. The material holds no disagreement story, so the guidance is a scaffold. |
| B2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Scaffold: name the team that did the work, then your part in your own words. Answer slot: if you have a case where credit was shared, say how you handled it; if not, say so and give how you would handle it. | Peer probe on turf and credit. |
| B3 | "Which assumption behind that 60% would you defend least?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through" | Name the weakest assumption in your own words before they do. Answer slot: if you counted it, say what it is sensitive to; if you did not, say so and say what you would check first. | Metric weakest-assumption slot on F5. |
| B4 | "Which part of the reliability quarter did you personally own: the scope, the trade-offs, or the sign-off?" | EXP | [grounded] "I pushed a reliability quarter through against roadmap pressure" | Name the part that was yours, in your words. Answer slot: if you owned none of the three, say so plainly and say what you did. | Premised on F5; asks which part was yours, not whether you had one. |
| B5 | "Three hardware-dependent features and a deadline. How would you sequence them with product?" | CASE | [generic] | Clarify the dependencies and what is fixed. Sequence by risk and by who you need to talk to first. Name what you would drop. | Live roadmap problem from role text (F3). |
| B6 | "Product wants a feature before a reliability fix. What do you do?" | CASE | [grounded] "pushed a reliability quarter through against roadmap pressure" | Hold a position: reliability work gets a fixed share, and you negotiate the timing with product, not the principle. Concede specifically what you do not know about the feature's value. | F7 is the nearest product-side evidence. The hold is the quote's position, not a bigger one. |
| B7 | "So, walk me through the journey." | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | Script a 90-second arc: nine years, three as team lead of six, now at a payments company, and why this role. Treat the casual register as scored. | Conversational opener. The arc uses only the quoted sentence. |
| B8 | "Walk me through the hiring loop you run for backend roles." | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Story-map on F4: the loop, the roughly 40 interviews, and your part in it. Answer slot: if you set the loop's criteria or decided on offers, say so; if not, say so and say what you did run. | Premised on F4's quote. |

**Requirement coverage:**

| Requirement | Covered by |
|---|---|
| Lead two squads building device-management services | B5 |
| Own delivery, hiring and growth for 11 engineers | B3, B4, B8 |
| Partner with hardware and product on roadmap | B1, B5, B6 |

**Reverse questions for this round:**

- "Where does the hardware roadmap meet yours, and which seam causes the most rework?" Why it lands: it names the partnership problem directly, to the people who live with it.
- "What is the decision the product team got wrong last quarter, and what changed afterwards?" Why it lands: it invites a candid answer and shows you are thinking about the product side.
- "What could a new engineering manager do in the first month that would genuinely help your team?" Why it lands: reciprocity question for a peer panel. It shows you plan to add to their load, not only draw on it.
- "How do the staff engineers and the managers split the design review?" Why it lands: it shows you want to understand the decision rights before you make any move.

## Round C: Monday, VP Engineering (values and leadership philosophy)

**Relationship prior:** skip-level or executive. The recruiter's words, "values and leadership philosophy", are a loop source, so a values-style round is detected. Published Larkfield values are not in hand, so the VAL questions below use selection scaffolds with an honest branch, not mapped stories.

**Persona weights:**

| Persona | Depth | How it shows up | Why | Counter-strategy |
|---|---|---|---|---|
| Values/Behavioral | 5 | Scenario probes on leadership | Recruiter named the round | STAR-shaped, "we" for context, "I" for contribution |
| Case/Strategist | 2 | Altitude: where the platform goes | Skip-level strategy | Clarify, then three years, then what you would stop |
| Pressure | 1 | Time-boxed challenge | Executive composure | Pause, restate, hold through two follow-ups |

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time you told a senior person something they did not want to hear and the relationship held. Name the stake, the moment you did not fold, and the end. If none comes to mind, say so plainly, then give the nearest thing your material carries: the reliability quarter against roadmap pressure (F5). | Open prompt. The material has no such story, so the honest branch is written in. |
| C2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Scaffold as C1. If your reliability quarter put a customer or on-call engineer ahead of a roadmap metric, say so in your words. If not, say so and describe what you would do. | Open prompt on a likely value. No published value to map yet. |
| C3 | "Walk me through the reliability quarter, including the roadmap side of the trade." | VAL | [grounded] "pushed a reliability quarter through against roadmap pressure" | Story-mapped on F5 and F7: the roadmap pressure, the quarter, and what you pushed through. Answer slot: if you made the trade-off call, say so; if someone else did, say so and say what you did. Do not add stakeholders or outcomes you did not mention. | Premised on F5's quote. It is the story most likely to carry a values answer. |
| C4 | "How do you grow an engineer who is better than you at the thing you used to do?" | VAL | [generic] | Scaffold: name the growth you would put first and how you would know it worked. Answer slot: if you have grown someone past you, say how; if not, say so and say what you would do. | Leadership-philosophy question. The material has no growth story (F6). |
| C5 | "Where should a device-management platform be in three years, and what would you stop doing?" | CO | [generic] | Clarify the platform's current state and customers before answering. Name the one thing you would stop, and why. Do not quote Larkfield's strategy, which is not in hand. | Altitude question. Without research it stays generic, and the pack says so. |
| C6 | "Your team is six. Why would the VP trust you with two squads?" | Pressure | [grounded] "9 years engineering, 3 as a team lead of 6" | Pause, restate. Hold: three years leading six, and the specific things that make the step plausible. Concede what you have not done. Do not extend the six. | Pressure stem on F1, the gap the VP will hear. |

**Requirement coverage:**

| Requirement | Covered by |
|---|---|
| Lead two squads building device-management services | C5, C6 |
| Own delivery, hiring and growth for 11 engineers | C3, C4 |
| Partner with hardware and product on roadmap | C3, C5 |

**Reverse questions for this round:**

- "What does the company need an engineering manager to do differently from the way they ran their last team?" Why it lands: it asks the VP to state the values in their own words, which you can then mirror.
- "How do you know a leader is doing values work and not performing it?" Why it lands: it signals you care about the values as practice, and it is a question only a VP can answer well.
- "What is the one leadership mistake you see most in engineering managers here?" Why it lands: it shows you are asking about the job, not about yourself.

## Sources

**Provided documents:** the role text and your background message, read in full. No CV and no full job description were supplied.

**Research tier:** L1 — searches 2 of 6, fetches 0 of 2. Both search calls were refused by the search permission. Nothing was fetched.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Larkfield Systems values | unavailable | Values cheat sheet, section 10. Refused: "Larkfield Systems values" query, permission not granted. Omitted. Round C's VAL questions use scaffolds instead. |
| 2. Larkfield Systems interview process, engineering manager | unavailable | Loop structure. Refused: "Larkfield Systems interview process engineering manager" query, permission not granted. Persona weights follow the recruiter's round descriptions. |
| 3. Larkfield strategy or recent news | unavailable | CO bank. No call sent: the search permission was not granted, so no query was run. Round C's C5 stays generic. |
| 4. Interviewer name and company | n/a | No interviewer name was given, so there was no query to form. |
| 5. Representative engineering manager JD | unavailable | JD-tagged questions. No call sent. The role text you gave me is a summary, not a full posting. |

## Upgrade menu

- The full job description or the recruiter's posting → the three requirement rows become quoted [grounded] text, and any gate in it can be checked.
- Larkfield's published values page (or the values the recruiter named) → the values cheat sheet appears, and C1 and C2 become mapped stories where your material carries them.
- The names and titles of the two staff engineers and the product manager → personas assigned per member rather than blended.
- Any pre-declared take-home, presentation or pre-read from the recruiter → one build section per deliverable.
- Your CV → more verbatim quotes for F2, F6 and the growth and hiring rows.
- Search permission for this session → L1 research on values, loop format and strategy, the three targets refused above.
- A deeper research pass (L2): up to 6 more searches and 2 more fetches, several more minutes. Available on your say-so.
- Whether the two squads have managers under you → changes how F1 and F6 read.
