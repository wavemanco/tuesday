Your prep pack is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-tuesday-part-2-rooms-case-8-canned-900d2274/fdcaee22-2938-4e93-9b00-e3ab37e80848/scratchpad/ashgrove_member_experience_lead_interview_pack.md`. I built it in loop mode, with one mini-pack for each of the three rounds on 20 November.

Two things to know before you open it. Your background has no story for any of the four Ashgrove values, so the values answers are built around the honest branch, not a rehearsed story. The highest-return prep is B1, where the Head of Member Services asks why they should take the risk on a contact centre and senior presenting. The pack gives you a three-level follow-up ladder for it.

Say the word and I'll play the Skeptic on B1 with live follow-ups.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Is the 20-minute panel case about a specific complaint type, such as a fee dispute or a regulated complaint, or is it open? A specific type would replace the generic scenario in C5.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove_member_experience_lead_interview_pack.md -----
# Interview prep pack: Member Experience Lead, Ashgrove Credit Union

Three rounds on 20 November 2026: a 30-minute recruiter screen, a 45-minute behavioural round with the Head of Member Services (your prospective manager), and a 60-minute values panel of two branch managers that includes a 20-minute complaint-escalation case. Loop mode: one shared fit snapshot, then a mini-pack for each round with its own persona weights.

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored: **VAL** values, **EXP** your past work, **JD** a role requirement, **CO** company and strategy, **CASE** a live problem.
- **Guidance is scaffolding, not a script.** It is speakable in 90 to 120 seconds. Use your own words.
- **Answer slots** are instructions for the interview. They tell you what to say when the honest answer is "no" or "not yet". They are not questions to me.
- Every claim about your past is either one of your own sentences, quoted in the fit snapshot or in the question's Provenance cell, or it is an answer slot. Nothing in the pack describes something you did that you have not told me.

## Sources and research tier

Research tier: L0, no searches. User links read 0.

Provided documents:
1. The job description, as pasted.
2. The values page text, as copied from ashgrovecu.org/about/values on 11 November 2026.
3. The recruiter's email with the round structure.
4. Your summary of the July 2026 strategy brief. The brief itself was not pasted, so the strategy items below rest on your summary. Check every number against the brief before you use it in a round.
5. Your background, as written in your message.

Searches sent: none. Fetches sent: none.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | The values page you pasted fixes the value names and wording. |
| 2. Ashgrove interview process, Member Experience Lead | skipped | The recruiter's email names three rounds, their lengths and who runs each. That is a loop source, so it establishes the loop. It also documents a values-style round: the panel is scored against the four values. |
| 3. Ashgrove strategy and recent news | skipped | Your summary of the July 2026 brief supplies the current priorities and moves. |
| 4. Interviewer name and Ashgrove | n/a | No interviewer name was given. |
| 5. Representative Member Experience Lead JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions. |

## Fit snapshot (shared across all rounds)

Gate check: the JD text you sent has no legal, credential, location or schedule term. No row is a hard gate. If the full posting has one, send it (see the upgrade menu).

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" (JD) | "6 years in retail banking, the last 3 as a branch supervisor" (your message) | medium | [grounded] | presentation | Your years and your branch role are in the sentence. Say the years and the branch in those words, and let the interviewer judge how far branch work counts as customer operations. |
| F2 | "experience handling regulated complaints" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | transferability | Words: "I handled the branch's formal complaints log." Answer slot: if the log followed rules set outside the branch, say which and how you applied them; if it did not, say so and say what made it formal in your branch. |
| F3 | "Own the member complaints process end to end across branches and the contact centre" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | transferability | Your record is one branch's log, not the process across branches. Words: the log, at its own scope. Answer slot: which parts of the complaints process in your branch were yours to set; if none were, say so. |
| F4 | "coach branch supervisors on escalations" (JD) | "trained new tellers on our escalation script" (your message) | medium | [grounded] | transferability | Words: "I trained new tellers on our escalation script." Answer slot: if you coached other supervisors on escalations, say how; if you did not, say so and say what you would do first. |
| F5 | "report monthly on complaint volumes" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | medium | [grounded] | presentation | Words: "I built the monthly complaints spreadsheet our regional manager uses." The sentence already reaches monthly complaint reporting in other terms. |
| F6 | "resolution times" (JD, from "report monthly on complaint volumes and resolution times") | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | low | [inferred] | discovery | The spreadsheet is named, but the sentence does not show whether it tracked resolution times. Answer slot: if it did, say how that was measured; if it did not, say so. |
| F7 | "comfortable with Excel reporting" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | low | [inferred] | discovery | Your sentence does not name the tool. Answer slot: name the tool you built the spreadsheet in; if it was not Excel, say so. Check this before the interview. |
| F8 | "confident presenting to senior leaders" (JD) | "I've never presented to anyone above regional level." (your message) | none | [grounded] | capability | Words: "I haven't presented above regional level." Then a plan for how you would build that skill, said as a plan and never as a past. |
| F9 | "Own the member complaints process end to end across branches and the contact centre" (JD), contact-centre part | "Never worked in a contact centre" (your message) | none | [grounded] | capability | Words: "I haven't worked in a contact centre." Then a plan for how you would learn the contact centre's measures and escalation routes. |
| F10 | "work with digital teams on self-service journeys" (JD) | none given | none | [grounded] | discovery | Answer slot: if you have worked with a digital team on a customer-facing change, say what, in your own words; if you have not, say so and say how you would start. |

## Prohibited claims

Built locally from the fit snapshot. These are wording you might reach for under pressure. None of them appears in any guidance cell.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end across branches and the contact centre | Inflated form of F3 | The log, at its own scope: "I handled the branch's formal complaints log." The limit is the pack's observation: your material describes one branch's log. |
| Contact-centre experience | Negative you stated, F9 | "I haven't worked in a contact centre." No slot. |
| Presenting to senior leaders, or above regional level | Negative you stated, F8 | "I haven't presented above regional level." No slot. |
| Used Excel for the complaints spreadsheet | Inflated form of F7 (your sentence does not name the tool) | "I built the monthly complaints spreadsheet." The tool goes in F7's answer slot. |
| Reported monthly on resolution times | Inflated form of F5 and F6 | The spreadsheet at its own scope. Resolution times are an answer slot in B6. |
| Coached branch supervisors on escalations | Inflated form of F4 (your sentence is about tellers) | "I trained new tellers on our escalation script." C6's answer slot covers supervisors. |

## Grounding brief: strategy vocabulary

Source: your summary of the July 2026 brief. Check each figure against the brief before the screen.

| Strategy item (as you summarised it) | What it means for member complaints | Questions |
|---|---|---|
| Move 40% of member service to digital channels by 2028 | New complaint routes, and self-service journeys that generate complaints before anyone is in the room. | A4, B9 |
| Consolidate eight branches into five hubs over 2027 | Complaints move between sites during a merger, and the members who do not move online feel it most. | A4, B8 |
| Small-business lending product in Q1 2027 | A new product brings new complaint types. Not in your evidence, so it is not coached here. | None; see the upgrade menu. |
| App-only banks are the main competitive pressure | Members can leave, so the complaints process is a retention point. | A reverse question in round A. |

## Values cheat sheet

Your record carries no story for any of the four values. Each row below is a selection scaffold that ends in the honest branch, not a mapped story. That is the finding: prepare the honest branch as carefully as the story.

| Value (official name) | Working meaning (paraphrased from the page) | Carrying sentence | Story or scaffold |
|---|---|---|---|
| Members First, Always | Decide from the member's side of the counter. | F3: "I handled the branch's formal complaints log" | Scaffold, B2 and C1. |
| Plain Words | If a member needs it explained twice, the writing was wrong. | F4: "trained new tellers on our escalation script" | Scaffold, B3 and C2. |
| Neighbours, Not Numbers | Every branch is part of its town. | F5: "I built the monthly complaints spreadsheet our regional manager uses" | Scaffold, B4 and C3. |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved. | F3: "I handled the branch's formal complaints log" | Scaffold, B5 and C4. |

## Persona weights by round

Weights follow the relationship priors in the persona model and the loop the recruiter described. Depth follows weight: the top persona gets 4 to 5 questions, mid-weight personas 3, low-weight 2.

| Persona | Round A: recruiter, 30 min | Round B: Head of Member Services, 45 min | Round C: panel, 60 min | Counter-strategy |
|---|---|---|---|---|
| Conversational / rapport | 4 (A1 to A4) | none | none | Treat every casual question as scored. Give a 90-second arc. Never answer the reverse-question slot with "you've covered everything". |
| Skeptic | 3 (A5 to A7) | 1 (B1, deepest ladder) | none | Rehearse the contact-centre and senior-presenting gaps until they are boring. Concede the stated gap exactly; hold the record. |
| Values / Behavioral | none | 4 (B2 to B5) | 4 (C1 to C4) | Map each value to a story only where a sentence carries one. Otherwise use the scaffold and say the honest branch. |
| Case / Strategist | none | 2 (B8, B9) | 2 (C5, C6) | Clarify, then structure. Speak the framework aloud. Name the metrics and the risks. |
| Data-Driven Prober | none | 2 (B6, B7) | none | Say what the spreadsheet tracks, and say plainly what you do not know about how it was counted. |
| Pressure / stress | none | none | 1 (C9) | Pause, restate, hold through two follow-ups, concede only the specific gap. |
| Peer Evaluator | none | none | 2 (C7, C8) | Propose seam principles, not facts about their seam. Give credit to the people who did the work. |

Why these weights: the recruiter screen is a logistics and motivation check, so it is conversational with a light Skeptic. The Head of Member Services round is "mostly behavioural", so Values sits on top and the Skeptic gets one deep item, not several. The panel is the values round and the escalation case, and the branch managers are the people this role would sit across, so they price the seam.

---

## Round A: recruiter screen (30 min)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, walk me through the journey to here." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" (your message); [grounded] "I handled the branch's formal complaints log" (your message); [grounded] "I built the monthly complaints spreadsheet our regional manager uses" (your message) | 90-second arc, in your words, using only these three sentences: the six years and the last three as a branch supervisor; the complaints log; the spreadsheet your regional manager uses. Then one sentence on why this role. Do not add a story the sentences do not carry. | The opening question sets the frame for every later answer. F1, F2 and F5 are the evidence. |
| A2 | "Which Excel do you actually use for reporting?" | JD | [grounded] "comfortable with Excel reporting" (JD); [grounded] "I built the monthly complaints spreadsheet our regional manager uses" (your message) | Answer slot: name the tool you built the complaints spreadsheet in, and what it is used for. If it was not Excel, say so. | F7. The JD raises Excel, so the question may presuppose Excel use. The answer is the tool you actually used. |
| A3 | "Why this, and why now?" | VAL | [generic] | Selection scaffold: say one thing about a member-owned organisation that you believe is true, and what in your work shows you believe it. If nothing in your work shows it, say so, and say what you would look at in your first month. | Motivation has no quoted sentence in your material, so no story is mapped. The question is standard. |
| A4 | "What do you know about Ashgrove, and what does it mean for member complaints?" | CO | [grounded] "move 40% of member service to digital channels by 2028" (your summary of the July 2026 brief); [grounded] "consolidate eight branches into five hubs over 2027" (your summary of the July 2026 brief) | Name two facts with their numbers as the brief states them. Then one consequence for complaints: digital moves complaints onto new routes; a branch merger moves them between sites. | The differentiator in a screen. The numbers must match the brief, so check them first. |
| A5 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre" (your message) | Plain acknowledgment: "I haven't worked in a contact centre." Then a plan you can keep: how you would learn the contact centre's measures and its escalation routes. | Skeptic stem, asked by a recruiter. The answer is the stated gap, F9. Rehearsing it once keeps it short. |
| A6 | "Your six years are in retail banking. How does that carry to a contact centre?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" (your message); [grounded] "I handled the branch's formal complaints log" (your message) | Say what carries from the log and from the escalation script. Then say the contact-centre part is new to you. | A transfer probe on F1, F3 and F9. Your acknowledgment of the contact-centre gap is already yours. |
| A7 | "What would this role give you that the branch supervisor role does not?" | JD | [generic] | Selection scaffold: one reason tied to what this role contains, not to your current employer's faults. Your material does not show your reasons, so say the reason in one sentence, in your own words. | A motive question. No quoted sentence carries a motive, so none is mapped. The question presupposes no departure. |

Reverse questions, round A (why each lands):
- "What does a strong first 90 days look like for the person in this role?" Shows you are planning the seam, not just the job.
- "How does the process compete with app-only banks on the things members feel?" Connects the brief's competitive pressure to the complaints role.

---

## Round B: Head of Member Services (45 min, behavioural)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "This role runs the contact centre and presents to senior leaders. You've never worked in a contact centre, and you've never presented above regional level. Why should we take that risk?" | JD | [grounded] "Never worked in a contact centre" (your message); [grounded] "I've never presented to anyone above regional level." (your message) | Hold, then concede. First the concession, exactly: "I haven't worked in a contact centre, and I haven't presented above regional level." Second, the hold on the record: "I handled the branch's formal complaints log" and "I built the monthly complaints spreadsheet our regional manager uses." Follow-up one, "Which of those complaints would you point to?": answer with a complaint from the log, not an adjective. Follow-up two, "What would you do in the first 90 days?": answer with a small, dated plan. Never claim a senior presentation or a contact-centre result you have not had. | The highest-return rehearsal in this pack. The Skeptic objection comes straight from the two stated gaps on the JD's duty and presenting lines, and it will come in some form. The ladder runs three levels deep. F8 and F9. |
| B2 | "Tell me about a time you decided something from the member's side of the counter when the process pointed the other way." | VAL | [grounded] "we decide from the member's side of the counter" (values page); [grounded] "I handled the branch's formal complaints log" (your message) | Selection scaffold ending in the honest branch: pick one complaint from the log where the member's view and the process disagreed. Say what you did and what the member got, in your words. If none comes to mind, say so plainly, then give the nearest complaint you handled and what you decided. | Members First, Always. The question's theme is the value's own sentence. The log is the only sentence that carries anything, so the story is a scaffold. |
| B3 | "Tell me about a time someone needed something explained twice. What did you change?" | VAL | [grounded] "if a member needs it explained twice, we wrote it wrong" (values page); [grounded] "trained new tellers on our escalation script" (your message) | Selection scaffold: a time a member, teller or colleague had to ask twice, and what you changed afterwards. Answer slot: if you changed the wording of the escalation script, say what and why. If you did not, say so, and say how you trained tellers on it. | Plain Words. The script sentence is the nearest carrier. A wording change is an answer slot, not a claim. |
| B4 | "When did a number hide something about a branch or its members?" | VAL | [grounded] "every branch is part of its town" (values page); [grounded] "I built the monthly complaints spreadsheet our regional manager uses" (your message) | Selection scaffold: a time a count or a report gave a wrong picture of a branch. Say what the count missed and what you did. If you have no such time, say so, then say what the spreadsheet shows and what it does not, in your words. | Neighbours, Not Numbers. The spreadsheet is the only carrier, and "what it does not" is the honest branch. |
| B5 | "Tell me about a complaint you kept hold of until it was solved." | VAL | [grounded] "whoever finds the problem keeps hold of it until it is solved" (values page); [grounded] "I handled the branch's formal complaints log" (your message) | Selection scaffold: a complaint from the log that you followed past the first answer. Give the outcome in your words. If none went past the first answer, say so, then give the nearest complaint you handled, what you did next and where it ended. | Own the Fix. |
| B6 | "Walk me through the monthly complaints spreadsheet you built: what it tracks, and who uses it." | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" (your message) | Say what it tracks, in your words, and that your regional manager uses it. Answer slot on resolution times: if it tracked how long complaints took to resolve, say how that was measured. If it did not, say so and say what you would add. Do not describe a measure you did not track. | F5 and F6, the JD's monthly volumes and resolution-times line. The resolution-time slot is where a probe would go, and "it did not track it" is an honest answer. |
| B7 | "Your log was of formal complaints. What made it formal, and whose rules did it follow?" | JD | [grounded] "I handled the branch's formal complaints log" (your message) | Answer slot: if the log followed rules set outside the branch, say which and how you applied them. If it did not, say so, and say what made it formal in your branch. Do not name a regulator or a timeline the log did not carry. | F2, the regulated-complaints requirement. "Formal" is the only carrying word. The regulated part is what the JD raises, so it is asked rather than claimed. The second branch lets the premise be false. |
| B8 | "A branch with a weak complaints record is merging into a hub next year. What do you need to know first?" | CASE | [grounded] "consolidate eight branches into five hubs over 2027" (your summary of the July 2026 brief) | Clarify first: what the complaints record counts, when the move is timed, and how the members of that town bank. Then structure: the complaints queue before, during and after the move; volumes and resolution times by site as the metrics; the members who will not move online as the main risk. Say the structure aloud. | A case from the brief's hub plan. It presupposes the consolidation the brief states, and nothing about you. |
| B9 | "Ashgrove is moving 40% of member service to digital by 2028. What complaints will rise when a self-service journey goes live, and what would you do about it?" | CO | [grounded] "move 40% of member service to digital channels by 2028" (your summary of the July 2026 brief); [grounded] "work with digital teams on self-service journeys" (JD); [generic] how self-service journeys tend to generate complaints | Name two complaint types a self-service journey tends to create, and say how you would find them before launch. Say what you would need from the digital team, in those words. Do not name a journey you have run. | F10. The JD's digital line is unanswered in your record, so this question is where it gets tested. |

Reverse questions, round B:
- "What would you most want this role to fix in its first six months?" Shows ownership of the outcome, not the job description.
- "How do you want this role to tell a branch problem from a process problem?" Shows you are thinking about the seam between sites and systems.

---

## Round C: values panel (60 min, two branch managers, with the 20-minute escalation case)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "What's a complaint that taught you the process was wrong, not the member?" | VAL | [grounded] "we decide from the member's side of the counter" (values page); [grounded] "I handled the branch's formal complaints log" (your message) | Selection scaffold: a complaint whose outcome changed a process, if one did. Say what changed and who decided. If none did, say so, and say which step you would question first. | Members First, Always. The panel scores this separately from B2. Use a different example, or none, and say so. |
| C2 | "Tell me about a letter, script or message you rewrote so a member could act on it." | VAL | [grounded] "if a member needs it explained twice, we wrote it wrong" (values page); [grounded] "trained new tellers on our escalation script" (your message) | Selection scaffold ending in the honest branch: name a piece of member-facing wording you changed, and what it did. If you changed none, say so, then say how you checked that a script was understood, or that you did not check. | Plain Words. The panel asks for an artifact. Without a changed text, the honest branch is what you have. |
| C3 | "Tell me about a time a branch's figures and its town told you different things." | VAL | [grounded] "every branch is part of its town" (values page); [grounded] "I built the monthly complaints spreadsheet our regional manager uses" (your message) | Selection scaffold: a time the figures and what you saw on the ground disagreed. Say which you trusted and what you did. If none comes to mind, say so, then say what the spreadsheet can and cannot show about a branch in its town. | Neighbours, Not Numbers. A second values question on the spreadsheet, asked in a different register from B4. |
| C4 | "Describe a problem you found that wasn't yours to fix. What did you do with it?" | VAL | [grounded] "whoever finds the problem keeps hold of it until it is solved" (values page) | Selection scaffold: a problem you found outside your remit, and what you did to keep it moving. Say who you told and what happened next. If you did nothing past telling someone, say that. | Own the Fix. The "not yours" framing separates a value from a habit. The scenario is a pattern, so no quoted sentence carries it. |
| C5 | Case: "A member has been to their branch twice about a fee they dispute. The branch says it has been escalated. The member says nobody has called back. You're the Member Experience Lead. Walk us through your first hour." | CASE | [generic] the recruiter's "a 20-minute case on a complaint escalation" (recruiter email) | Clarify first: what the fee is, whether the complaint is regulated, how long it has been open, and whether the member needs extra support. Then the objective, the approach (who calls the member today, who owns the escalation, what the branch is told), the metrics (days open, callbacks missed) and the risks (a missed callback, if the complaint is a regulated one). Speak the framework aloud. Stop at the first hour. | The 20-minute case. The scenario is generic: the recruiter named the case type, not a fact about Ashgrove. It presupposes nothing about you. |
| C6 | "A branch supervisor sends you an escalated complaint and asks you to take it over. What do you coach them to do first?" | CASE | [grounded] "coach branch supervisors on escalations" (JD); [grounded] "trained new tellers on our escalation script" (your message) | Structure first: coach the supervisor to own the next step for the member before passing it up. Say what you would ask the supervisor, and what you would decide yourself. Then say how you would coach it so the supervisor learns, not just hands over. Answer slot: if you have coached a supervisor on an escalation, say how. If you have not, say so, and say how you would start. | F4, the JD's supervisor-coaching line. Your record is about tellers, so the honest branch is part of the answer. |
| C7 | "Our branches sit beside your team. Where's the seam between the branches and the contact centre, and what happens when we disagree?" | Peer | [grounded] "Own the member complaints process end to end across branches and the contact centre" (JD); [generic] the seam itself | Propose seam principles, not facts about their seam. Who owns the member once a call starts; who owns the branch once it ends; how a disagreement is settled, by the member's outcome. Do not claim you know their current seam. | Peer Evaluator. The panel is the people this role sits across, so they are the ones most likely to price the seam. |
| C8 | "How do you handle credit when a complaint fix needs three teams?" | Peer | [generic] | Selection scaffold: a time a fix needed more than one team. Say who did what, in your words, and name the others' parts without taking them. If none comes to mind, say so, then say how you make sure credit goes to the people who did the work. | Credit probe. No quoted sentence carries a multi-team fix, so no story is mapped. |
| C9 | "Sixty seconds: why should a branch manager trust a team lead who has never worked in a contact centre?" | JD | [grounded] "Never worked in a contact centre" (your message) | Pause, then restate the question. Then the concession: "I haven't worked in a contact centre." Then the hold, on the record: "I handled the branch's formal complaints log." Concede only the contact-centre part: it is new to you, and you would learn it from the contact centre's own staff. Hold through two follow-ups. | Pressure, a 60-second version of B1. The position you hold is what your log carries. |

Reverse questions, round C:
- "What would make this role a success for your branches in its first year?" Lands as a question about their branches, not about the role's title.
- "What could a new person do in their first month that would genuinely help your branches?" The reciprocity question for a peer panel. It signals you are planning to give, not only to take.

---

## Requirement coverage

| JD requirement | Questions covering it | Notes |
|---|---|---|
| 4+ years in financial-services customer operations | A1, A6 | Evidence F1. |
| Experience handling regulated complaints | B7 | Evidence F2, transferability; the regulated part is asked, not claimed. |
| Confident presenting to senior leaders | B1, C9 | Evidence F8, a stated gap. |
| Comfortable with Excel reporting | A2, B6 | Evidence F7, discovery. |
| Own the complaints process end to end across branches and the contact centre | A5, B1, C7 | Evidence F3 and F9. |
| Report monthly on complaint volumes and resolution times | B6, B8 | Evidence F5 and F6. |
| Coach branch supervisors on escalations | C6 | Evidence F4. |
| Work with digital teams on self-service journeys | B9 | Evidence F10, discovery. |

Every stated requirement has at least one JD-tagged question. None is left uncovered.

---

## Upgrade menu

- The 20-minute case's complaint type (a fee dispute, a regulated complaint, a service failure) → C5 becomes a specific scenario rather than a generic one.
- The interviewers' names → a reading of each interviewer, persona weights for each of the three rounds, and a reverse question tailored to each person's path.
- The tool behind the complaints spreadsheet → F7 moves from `[inferred]` to `[grounded]`, and A2 and B6 get a concrete answer.
- The full posting text, including any location, right-to-work, licence or credential term → a gate check. None is in the text you sent.
- Your CV → F1 to F5 can be checked against a document. To raise the medium rows, name an inspectable artifact, such as an anonymised layout of the complaints log or the spreadsheet's column structure. Do not bring member-identifiable data to any round.
- The recruiter's notes on each round's focus areas → the persona weights and coverage can be checked against what they expect.
- The strategy brief itself, pasted → the grounding brief and B8 and B9 can be checked against the exact wording.
- A digital or product project you worked on → F10 moves from an answer slot to a dated, named example.
