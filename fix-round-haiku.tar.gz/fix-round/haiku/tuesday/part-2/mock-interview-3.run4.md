Web search was refused in this session, so the pack will be built without Stripe-specific research. I'll write it from the role title and company alone and label everything accordingly.
Your prep pack is saved as `stripe_product-operations-manager_interview_pack.md` and attached above. It's a first pass built from the role title and company alone. I couldn't research Stripe's values, interview loop, or recent strategy because the web search permission was declined, so the pack has no Stripe-specific facts. Everything in it is labeled as generic role material or as a prompt for you to fill in from your own experience.

The most useful next step is getting your CV and the job posting into the pack. Then the fit table can quote your real experience, and the Skeptic questions can target your actual gaps.

Two offers, neither pushed: I can run a live drill on any question in the pack, starting with the case questions in bank A. I can also save a `tuesday-dossier.md` that records the gaps this prep exposed, for later sessions.

Two questions so I can shape the pack:
1. Who is the final round with (hiring manager, peer, a panel), and is it one session or several? If it's several, send the schedule, and mention any focus areas or exercise the recruiter gave you.
2. Could you paste your CV and the job posting? Even just the posting's list of requirements would help.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: stripe_product-operations-manager_interview_pack.md -----
# Stripe: Product Operations Manager, final round. Interview prep pack

First pass. Built from the role title and company only. No CV, no job description, no round details, and no web research (search was refused in this session). Everything below is role-family material labeled `[generic]`, or a selection scaffold. Nothing here assumes anything about your past.

## How to use

- **Personas** describe how a question is asked. **Types** describe what is being scored.
- Types: **VAL** behavioral/values, **EXP** your experience, **JD** role requirements, **CO** company knowledge, **CASE** live problem.
- Guidance is scaffolding, not a script. Rehearse only what you actually did, in your own words.

## Fit snapshot (worksheet variant)

No JD and no CV were supplied, so the requirements below are role-family prose, not quotes. Every evidence cell is `none given`, so every row is a worksheet row.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Runs cross-functional programs from scoping to launch (role-family prose) | none given | none | [generic] | discovery | Strong evidence looks like one program you scoped, staffed and landed across teams, with owners named. Selection scaffold: pick a cross-team effort you drove start to finish. If none comes to mind, say so plainly, then give the nearest thing you did. |
| F2 | Builds operating mechanisms: planning cadence, business reviews, metric reviews (role-family prose) | none given | none | [generic] | discovery | Strong evidence looks like a recurring review or cadence you designed or ran, with its inputs, owners and decision forum. Selection scaffold: name one such mechanism you ran, or say none was yours. |
| F3 | Designs and improves processes and internal tools, and checks whether they worked (role-family prose) | none given | none | [generic] | discovery | Strong evidence looks like a process you changed, plus how you knew it was better. Selection scaffold: name one change and the signal you used. If you did not measure it, say so. |
| F4 | Frames decisions with data for leaders, and says what the numbers cannot show (role-family prose) | none given | none | [generic] | discovery | Strong evidence looks like a figure you used to decide something, with its limits stated. Answer slot: if you used a figure to decide, say how it was counted and which assumption you would defend least. If you did not, say so and describe how you judged results. |
| F5 | Works with executives and teams with competing priorities, and makes tradeoffs explicit (role-family prose) | none given | none | [generic] | discovery | Strong evidence looks like a tradeoff you made visible and the decision that followed. Selection scaffold: pick a moment two priorities collided. |
| F6 | Structures ambiguous problems quickly (role-family prose) | none given | none | [generic] | discovery | Strong evidence looks like an unclear problem you turned into a plan. Selection scaffold: pick one, and say what you did first. |

## Prohibited claims

No sentences from you exist yet, so the pack cannot yet build inflated-form entries and has no sourced entries. Its standing limit: it will not coach any figure, outcome, team size, title, ownership or incident you have not stated yourself. An empty list here reflects empty material, not a clean record. It will be rebuilt once you share your CV.

## Persona weights

Relationship and round are unknown, so weights are flat, and this is noticeably weaker than a weighted pack. No loop source was read, so the loop follows the fallback archetype *big-tech structured* (Values and Case weighted up). That is a pattern, not a verified description of Stripe's final round.

| Persona | How it shows up | Likelihood (flat) and reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | Live operating problems | High: the archetype leans on case work | Clarify, then structure, then name one premise to test |
| Data-Driven Prober | Asks how a number was counted | High: operations roles are judged on evidence | Say how it was counted, and where you do not know |
| Values / Behavioral | Scenario prompts about judgment | Medium: the archetype usually has a values round, but no published values were read | Choose stories where the hard truth landed; say so if none did |
| Skeptic | Why this role, why now, where you are weakest | Medium: default for any final round | Calibrated candor over bluffing |
| Pressure / Stress | Interrupts, time-boxes | Low to medium: unknown | Pause, restate, hold through two follow-ups |
| Conversational | Casual openers that are still scored | Medium: common in final rounds | Prepare a 90-second career arc |
| Peer Evaluator | Seam questions with adjacent teams | Conditional: only if the round is with a peer | Offer what you bring their team, not only what you need |

## Question banks

Every guidance cell is `[generic]` or a selection scaffold. None rests on a quote from you. Depth is 4 per persona, since weights are flat.

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Sketch how you would launch a new internal process across three product teams. What do you need to know first?" | CASE | [generic] | Clarify: which teams, what exists today, what "launched" means. Then objective, the segments affected, approach, metrics, risks. Think aloud. | Persona stem; a live problem of the role's type; asks about no past |
| A2 | "Adoption of an internal tool dropped 20% a month after launch. Diagnose it." | CASE | [generic] | Ask whether the drop is real or a measurement change, then which segment, what changed around it, then a hypothesis tree. | Persona stem for the Case persona |
| A3 | "Walk me through setting up a planning cadence for a team that has none." | JD | [generic] | Inputs, owners, decision forum, outputs. Start small, and say what you would cut first. | Covers F2 |
| A4 | "What is one thing you would change about how a fast-growing company runs its internal operations?" | CO | [generic] | Pick one specific, defensible point, and say what evidence would change your mind. No company claims, since no research ran. | Tests altitude; CO questions go generic without research, as labeled |

### B. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a number you used to make a decision. How was it counted?" | EXP | [generic] | Selection scaffold: pick a figure you can explain end to end. Say how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. If no figure comes to mind, say so plainly, then describe how you judged results. | Covers F4; the highest-probability probe for this persona |
| B2 | "How would you know a process change actually worked, and what could you not tell?" | JD | [generic] | Before and after, a comparison group if you had one, and the selection effects you would watch for. Name what you would decline to claim. | Covers F3 |
| B3 | "Leadership wants one number to decide whether to fund a team. What do you give them?" | CASE | [generic] | One number, its limits, and the decision rule it supports. Say what the number cannot show. | Covers F4 |
| B4 | "Name a decision where the data went against what you expected. What did you do?" | EXP | [generic] | Selection scaffold: what the data showed, what you did, what you would check now. If none, say so, then give the nearest. | Probes whether you can be wrong in public |

### C. Values / Behavioral

No published values were read, so no values cheat sheet is built and these are selection scaffolds with honest branches.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: a named stake, a moment you did not fold, the relationship afterwards. If none, say so and give the nearest. | Persona stem; scored for judgment |
| C2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Same scaffold. Say what the metric was and what you chose. | Persona stem |
| C3 | "Tell me about a program that went wrong. What did you own?" | VAL | [generic] | Separate what was yours from what the team did. Do not invent a tidy ending. | Covers F1; tests attribution |
| C4 | "Tell me about a time you disagreed with someone senior. What happened after?" | VAL | [generic] | Selection scaffold: what you argued, what you conceded, what you held. | Covers F5 |

### D. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | Answer slot: name the one area where your material is thinnest, and say what you would do in the first 30 days to close it. | This is the placeholder for the highest-ROI prep until a CV exists |
| D2 | "Why leave where you are, and why here?" | EXP | [generic] | Tie the motivation to the role's work, in your own words. Keep it free of criticism of your current employer. | Motivation consistency |
| D3 | "Why this kind of role now, rather than the one you have been doing?" | EXP | [generic] | State the path honestly, in your own words, with no story added. | Transition probe |
| D4 | "Where would a hiring manager push hardest on your background? What is your honest answer?" | EXP | [generic] | Selection scaffold: name the probe, then your true answer, with any gap stated plainly. | Calibrated candor |

## Requirement coverage

| Requirement | Questions |
|---|---|
| F1 cross-functional programs | A1, C3 |
| F2 operating mechanisms | A3 |
| F3 processes and tools | B2 |
| F4 data for decisions | B1, B3, B4 |
| F5 competing priorities | C4 |
| F6 ambiguous problems | A1, A2, D1 |

## Reverse questions

Each one has a reason it lands. None is tied to an interviewer profile, because there is none.

1. "What does success look like for this role at 90 days?" Lands because it shows you think in outcomes.
2. "Which internal process is under the most strain right now, and what has been tried?" Lands because the answer shows the real scope.
3. "How does this role work with product, finance and go-to-market teams day to day?" Lands because it tests the seams.
4. "How does the team judge whether an internal process is working?" Lands because it reveals the metric culture, and pairs with bank B.
5. "What makes someone in this role succeed quickly, and what makes them struggle?" Lands because a candid answer shows the real expectations.
6. Only if the round is with a peer: "What could a new person do in their first month that would genuinely help your team?" Lands because it turns the round into a peer conversation.

## Sources

- Provided documents: none. Only the role title and company were given.
- Searches sent, all refused: "Stripe company values operating principles"; "Stripe interview process Product Operations Manager final round"; "Stripe news 2026 strategy". No fetches were sent.

Research tier: L1 — searches 3 of 6, fetches 0 of 2 (all refused)

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Stripe values | unavailable | Refused. Values cheat sheet not built; the values are not in hand |
| 2. Stripe interview process, product operations | unavailable | Refused. Loop structure unknown; archetype fallback used for persona weights |
| 3. Stripe strategy / recent news | unavailable | Refused. CO questions are generic, as labeled |
| 4. Named interviewer | n/a | No name given |
| 5. Representative Product Operations Manager JD | unavailable | Not sent. Search was refused for targets 1 to 3, so this host could not run it either. Would have grounded the F rows as `[inferred]` |

## Upgrade menu

- Your CV or resume → rows F1 to F6 gain quoted evidence; bank B and C scaffolds become story maps; the Skeptic bank gets real gap rows.
- The job description → requirement rows become `[grounded]` and the coverage table becomes exact.
- Round type and who you are meeting (manager, peer, panel) → persona weights and reverse questions are restructured.
- Recruiter notes on the final round's format or any assignment → coverage for that assignment, and a build section for it.
- Search access enabled → Stripe values, the loop structure and current strategy, which would ground C and A4.
- The interviewer's name → a tailored reverse question and a persona read from their public footprint.
