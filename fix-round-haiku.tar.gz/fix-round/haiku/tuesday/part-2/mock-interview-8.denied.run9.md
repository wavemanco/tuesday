Your prep pack is saved as /tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-tuesday-part-2-rooms-case-8-denied-ec335711/11eec7eb-2027-4259-a52f-2f32e88768a5/scratchpad/ashgrove-credit-union_member-experience-lead_interview_pack.md. I built it as a loop, one mini-pack per round, since you have three rounds on the 20th.

The three things to spend your evening on:

- **The contact-centre gap (B3).** The Head of Member Services is most likely to press on "never worked in a contact centre" alongside "one branch only". Hold on your branch log and training, concede the gap in one plain sentence, then give a plan. Don't stretch "handled the branch's formal complaints log" into end-to-end ownership.
- **Presenting above regional level.** This is the second gap, and it will come up in round 1 as a knockout and again in round 2 (A6, B6). Use the same plain-acknowledgment-then-plan shape.
- **The 20-minute escalation case (C1).** It is the centre of round 3. The pack gives a structure: member first, then owner of the fix, then plain-words reply, then deadline, then record. Name one assumption you would check first, and don't quote a regulatory timescale unless you are sure of it.

The values panel is covered in section 9. Your material gives real stories for Members First and Own the Fix (both through the complaints log). It has nothing for Neighbours, Not Numbers, so that one is a selection scaffold with an honest branch.

Choices I made that you can redirect:
- **No web research.** The values, the recruiter's process and your summary of the July brief were enough for this pass, so I ran at the no-search tier. The brief itself isn't in the pack's sources, so the strategy points come from your summary. The upgrade menu offers a deeper pass.
- **Dara's pronouns are they/them**, as you asked.
- **Question counts.** There are 22 questions across the three rounds, with reverse questions for each round.

Is the 20-minute case given to you in advance, or is it live on the day? If it's in advance, the pack can build a rehearsal against the actual document.

Want me to run a live drill? I can play the Head of Member Services on B3, the highest-ROI question in the pack. I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove-credit-union_member-experience-lead_interview_pack.md -----
# Interview pack: Member Experience Lead, Ashgrove Credit Union

**Rounds:** three, on 20 November 2026 (loop mode)
1. Recruiter screen, 30 min (recruiter, name not given)
2. Head of Member Services, 45 min (your future manager, name not given), mostly behavioural
3. Panel of two branch managers, 60 min (names not given), including a 20-minute complaint-escalation case; the panel scores the four values

First version. Built on your message, the JD text, the four values as you copied them, the recruiter's email, and your summary of the July 2026 strategy brief.

---

## 1. How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored: VAL (values), EXP (your past work), JD (the role's stated requirements), CO (company and strategy), CASE (a live problem).
- The guidance is scaffolding for a spoken answer, not a script. Say it in your own words.
- Every claim about your past is one of your own sentences, quoted in the fit snapshot or in the row's Provenance cell. Where the material does not show something, the cell says so and gives an answer slot instead of words to say.

---

## 2. Prep triage

Prep time was not stated, so no schedule is built. If you have an evening, use this order: section 3 (the gaps), then the round 2 Skeptic question B3, then the round 3 case C1. Everything else is insurance.

---

## 3. Fit snapshot (shared across all three rounds)

Sources for quoted text: "your message" is the background you wrote to me. JD text is quoted as you pasted it.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" (JD) | "6 years in retail banking, the last 3 as a branch supervisor." (your message) | medium | [grounded] | none | Your sentence gives the numbers. Say them as they are: six years in retail banking, three as a branch supervisor. |
| F2 | "experience handling regulated complaints" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | presentation | The sentence says formal complaints. It does not say regulated. Say what the log was, in those words. Answer slot: the JD names regulated complaints, so expect a probe on the regulatory side. If the log carried regulatory timescales or review rules, say which and how you applied them; if it did not, say so plainly and describe the log's formal steps. |
| F3 | "Own the member complaints process end to end across branches and the contact centre" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | transferability | Your sentence is one branch's log, and it says handled. "End to end across branches and the contact centre" is wider. Keep the branch scope. Answer slot: the JD's end-to-end line makes a probe on stages likely. If any stage was yours to set, say which and how you decided; if none was, or it was not yours, say so and stay with the log you handled. |
| F4 | "across branches and the contact centre" (JD) | "Never worked in a contact centre" (your message) | none | [grounded] | capability | A gap you stated. Words: "I haven't worked in a contact centre." Then how you would learn it, said as a plan and never as a past. |
| F5 | "report monthly on complaint volumes and resolution times" (JD) | "I built the monthly complaints spreadsheet our regional manager uses." (your message) | medium | [grounded] | presentation | The sentence says monthly, and that the spreadsheet is used upward. It does not say what the spreadsheet counted. Answer slot: the JD asks for volumes and resolution times. If the spreadsheet carried either, say which and how it was counted; if it carried neither, say what it did carry. |
| F6 | "comfortable with Excel reporting" (JD) | "I built the monthly complaints spreadsheet our regional manager uses." (your message) | medium | [grounded] | presentation | Your sentence says spreadsheet, not Excel. Say what you built it in and what it did. Answer slot: if you used particular functions or built it yourself end to end, say which, in your own words; if you did not build the workbook, say that. |
| F7 | "coach branch supervisors on escalations" (JD) | "trained new tellers on our escalation script" (your message) | medium | [grounded] | transferability | Training tellers is adjacent. Coaching supervisors is not in your sentence. Say the training as it was. Answer slot: if you coached anyone on escalations beyond new tellers, say who and what; if not, say so and describe how you would start with supervisors. |
| F8 | "confident presenting to senior leaders" (JD) | "I've never presented to anyone above regional level." (your message) | none | [grounded] | capability | A gap you stated. Words: "I haven't presented to anyone above regional level." Then the plan for senior presenting, as a plan. Nothing about regional presenting is claimed beyond what you wrote. |
| F9 | "work with digital teams on self-service journeys" (JD) | none given | none | [grounded] | discovery | The material does not show digital-team work, and you have not said there was none. Answer slot: if you worked with a digital or IT team on a member-facing change, say what it was and your part; if you did not, say so and say how you would start. |

**What the pack observes (analysis, not words for you):** your material is strong on branch complaints handling and weak on scope beyond one branch, the contact centre, and senior audiences. Those three are where the interviews will press.

### Prohibited list

These claims are not coached. Each names its basis, and the honest form is shown.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end | Inflated form of F3 | "I handled the branch's formal complaints log." The material says one branch's log, handled, not end to end across branches. |
| Experience handling regulated complaints | Inflated form of F2 | "I handled the branch's formal complaints log." |
| Coached branch supervisors on escalations | Inflated form of F7 | "trained new tellers on our escalation script." |
| Reported volumes and resolution times to leaders | Inflated form of F5 | "I built the monthly complaints spreadsheet our regional manager uses." |
| Advanced Excel skills | Inflated form of F6 | "I built the monthly complaints spreadsheet our regional manager uses." |
| Presented to senior leaders | Negative you stated, F8 | "I've never presented to anyone above regional level." No answer slot on this claim. |
| Worked in a contact centre | Negative you stated, F4 | "Never worked in a contact centre." No answer slot on this claim. |

---

## 4. Persona weights by round

| Round | Persona | Weight | How it shows up | Reasoning | Counter-strategy |
|---|---|---|---|---|---|
| 1 Recruiter | Conversational | Top (3 questions) | Friendly opener; the biography and motivation questions are scored | Recruiter-screen prior; the recruiter's own email sets logistics and motivation as the purpose | Pre-scripted 90-second arc; treat every casual question as scored |
| 1 Recruiter | Skeptic (light) | 2 | Contact-centre and presenting gaps come up as knockout checks | Prior for a screen; F4 and F8 are the two gaps a screen will find | Plain acknowledgment, then the plan |
| 2 Head of Member Services | Values / Behavioral | Top (3 questions, with B7 and B8 as cross-over) | STAR-shaped prompts, mostly behavioural | Recruiter's email says "mostly behavioural". That overrides the Case-and-Skeptic manager prior | Choose a story where the hard truth landed; where the material shows none, say so |
| 2 | Skeptic | 2 | The contact-centre and senior-presenting gaps, asked as "why should we trust you" | Manager is buying capability and derisking gaps (F4, F8) | Rehearse the highest-ROI objection (B3) until it is boring |
| 2 | Pressure | 1 | Interrupts and time-boxes on the one claim you made | Testing composure on your attribution | Hold, then concede the specific part |
| 2 | Case | 1 | A live digital-shift problem | Manager tests judgement on the strategy | Clarify, then structure |
| 3 Panel | Case / Strategist | Top, 2 questions plus the escalation case | The 20-minute escalation case | Recruiter's email names the case; the case is the scored centre of the round | Clarify, then the plan; name the honest limit |
| 3 Panel | Peer Evaluator | 2 | Seam questions between branches and the contact centre | Branch managers are peers in the seam your role would own | Seam principles, not a claim to know their seam; reciprocity |
| 3 Panel | Values / Behavioral | 2 | Both panel members score the four values | Recruiter's email says the panel scores the values, so values are guaranteed in this round | Map each value to a story or to the honest branch (section 9) |
| 3 Panel | Pressure | 1 | Pressure on the numbers you built | Panel tests the spreadsheet claim | Hold through two follow-ups, then concede specifically |
| 3 Panel | Skeptic | 1 | Coaching supervisors, which you have not done | JD raises it; F7 is thin | Plain account of what you did, then the plan |

No interviewer profiles were supplied, so no interviewer read is included. The names would change the weights (section 12).

---

## 5. Round 1: Recruiter screen (30 min)

Round type: recruiter screen. Relationship: recruiter, not a hiring manager. Focus stated: logistics, motivation, and the process itself.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through your background, briefly." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Story-mapped on F1: six years, three as a branch supervisor. Add the branch role in one sentence and stop there. | F1 is the foundation; the opener is where you are first scored |
| A2 | "Why Ashgrove, and why this role?" | VAL | [grounded] "Own the Fix — whoever finds the problem keeps hold of it until it is solved." (values, as you pasted them) | Pick one value and one strategy item. Name the one thing about the role that you want to do, in your own words. Do not claim knowledge of the hub plan beyond what you have read. | Motivation is scored in a screen; the values and the July brief are the sources you have |
| A3 | "This role covers the contact centre, and you haven't worked in one. What's your answer?" | JD | [grounded] "Never worked in a contact centre" | Plain acknowledgment: "I haven't worked in a contact centre." Then the plan: how you would learn the contact-centre side first, as a plan. | F4 is a stated gap and the most likely knockout; rehearse the plain line so it does not freeze you |
| A4 | "The hub plan consolidates eight branches into five hubs in 2027. How do you feel about that?" | CO | [grounded] "consolidate eight branches into five hubs over 2027" (July 2026 brief, as you summarised it) | Say what the change means for complaints (more cases per hub, longer routes to the branch). Do not claim you know which branches close. | The strategy shapes the role; the recruiter will test that you read the brief |
| A5 | "You've been a branch supervisor for three years. Why move on?" | EXP | [grounded] "the last 3 as a branch supervisor" | Motivation in your own words: what you want to do that the branch role does not let you. No criticism of the current employer. | A motivation check; keep it forward-looking |
| A6 | "You haven't presented above regional level. How will you handle a senior audience?" | JD | [grounded] "I've never presented to anyone above regional level." | Plain acknowledgment: "I haven't presented to anyone above regional level." Then the plan for senior presenting, as a plan. | F8 is a stated gap and the recruiter will test it lightly |

**Round 1 reverse questions** (each with why it lands)
1. "What does a good first 90 days look like for this role?" Why: shows you think in outcomes, and tells you the manager's priorities.
2. "Is the complaints role part of the hub plan?" Why: the answer tells you how much the role will change in 2027.
3. "What happens after the panel on the 20th?" Why: process questions are cheap signals of preparation, and the recruiter knows.

---

## 6. Round 2: Head of Member Services (45 min, mostly behavioural)

Round type: hiring manager, behavioural. Relationship: your future manager. Focus stated: behavioural; the manager will scope the role.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time you put a member's need ahead of a process rule." | VAL | [grounded] "we decide from the member's side of the counter" (values); F3 row for your log | Open prompt. Selection scaffold: pick a log entry where the member's side and the rule pulled apart. Say what you decided, what you did not decide, and what the member got. If no such case comes to mind, say so plainly, then give the nearest thing your log does carry, or how you would handle it. | Members First is the value this question scores. Your material does not carry a member outcome, so the story must come from your own memory, not from the pack |
| B2 | "Tell me about a complaint you kept hold of until it was solved." | VAL | [grounded] "Own the Fix — whoever finds the problem keeps hold of it until it is solved." (values) | Open prompt. Selection scaffold: pick a complaint you carried from intake to close. Name what closed it and what you did not own. If none comes to mind, say so, then describe how you tracked a complaint that was not yours to close. | Own the Fix is scored here; F3 is your nearest sentence, so the story must stay inside it |
| B3 | "You've worked only in one branch and never in a contact centre. Why should we trust you with 900 staff across both?" | JD | [grounded] "Never worked in a contact centre" (your message); [grounded] "I handled the branch's formal complaints log" (your message); [grounded] "trained new tellers on our escalation script" (your message) | **Highest-ROI prep in this pack.** Hold: name the branch log and the training as what you have done, in your own words. Then concede the contact-centre gap plainly: "I haven't worked in a contact centre." Hold through two follow-ups by returning to the branch log and the training, never by adding to them. Then the plan: how you would learn the contact centre in the first 90 days. | F3, F4 and F7 come together here. This is the objection most likely to land, and the answer that holds is candour, not a bigger claim |
| B4 | "Of the complaints log you handled, what part was yours to decide?" | Pressure | [grounded] "I handled the branch's formal complaints log" (your message) | Hold the position: say what handling meant in your own words. Answer slot: if you decided outcomes, say which; if you handled the log but did not decide, say so plainly and say who did. Concede specifically; do not fold on the handling claim. | Pressure tests the boundary between handling and deciding; F3 is the sentence it presses |
| B5 | "Members are moving to the app, and one branch's complaints spike. What do you check first?" | CASE | [grounded] "move 40% of member service to digital channels by 2028" (July 2026 brief, as you summarised it); [generic] structure | Clarify what counts as a spike, then the objective (where the complaints come from), then segmentation (app, branch, contact centre), then the approach, then the metrics you would track, then the risks. Think aloud and name one assumption you would test first. | A live problem from the strategy. It asks about no past of yours, so it claims nothing about your history. The digital-team requirement (F9) gets its only rehearsal here, as a partial |
| B6 | "Our next steering pack goes to the executive. What happens when you present it?" | JD | [grounded] "I've never presented to anyone above regional level." (your message) | Plain acknowledgment: "I haven't presented to anyone above regional level." Then the plan for the first executive pack: how you would prepare, and who you would rehearse with. | F8 is a stated gap; the manager will test whether you can plan around it |
| B7 | "How would you run a complaints review in a branch that is about to fold into a hub?" | VAL | [grounded] "every branch is part of its town" (values); [grounded] "consolidate eight branches into five hubs over 2027" (brief, as you summarised it) | Scaffold: how you would keep the town's view in the review (Neighbours, Not Numbers). No past claim is needed; say what you would ask the branch's customers and staff first. | Neighbours is the value this question scores; the consolidation makes it live |
| B8 | "Walk me through the monthly complaints spreadsheet you built. What does it count?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." (your message) | Answer slot, the JD raises volumes and resolution times: if the spreadsheet counted either, say which and how; if it counted neither, say what it counted. Name the one part you would defend least, in your own words. | F5 and F6 are the two requirements this sentence has to carry; the slot stays inside what you built |

**Round 2 reverse questions**
1. "Where does complaints data go today, and who reads it?" Why: tells you how far the monthly report reaches, and shows you care about use.
2. "What is the hardest escalation the branches brought you this year?" Why: a manager's answer tells you the real job, and it invites a peer-style conversation.
3. "How will the contact-centre side of this role be scoped in year one?" Why: it turns F4 into a question about the plan, which is what you want the manager to discuss.

---

## 7. Round 3: Panel of two branch managers (60 min, values scored, 20-minute case)

Round type: panel, values scored, live escalation case. Relationship: branch managers, who are your peers in the seam between branches and the contact centre.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | **The 20-minute case.** "A member has complained three times about a fee that the contact centre closed without a call back. The branch note calls the member difficult. They now ask for the regulator. Walk us through the first 24 hours." | CASE | [generic] pattern of an escalation; [grounded] "we decide from the member's side of the counter" (values) | Clarify first: what the member has been told, what the file shows, and whether the regulator's deadline applies. Structure: the member's side first, then the owner of the fix, then the plain-words reply, then the deadline, then the record. Think aloud and name one assumption you would check first. Do not state any specific regulatory timescale as a fact unless you are sure of it. | The case is the scored centre of the round. It asks about no past of yours; it presumes nothing about your record |
| C2 | "The contact centre and the branch disagree on who owns the fix. What happens?" | Peer | [grounded] "whoever finds the problem keeps hold of it until it is solved" (values) | Seam principle, not a claim to know their seam: agree who holds the fix, and say it in one line. Do not pretend you know the contact-centre process; say you would learn it with them. | Peer Evaluator tests the seam; Own the Fix is the principle in play |
| C3 | "Tell me about a time a member needed something explained twice. What did you change?" | VAL | [grounded] "if a member needs it explained twice, we wrote it wrong" (values) | Open prompt. Selection scaffold: pick a letter, script or form a member did not follow. Say what you changed and what you did not own. If none comes to mind, say so, then say which words you would change first. | Plain Words is the value this question scores. No sentence in your material carries a story for it, so the scaffold is the honest form |
| C4 | "What would you need from the branches, and what would you give back?" | Peer | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." (your message) | Reciprocity: say what you need from them, then what you would bring their teams, in your own words. The monthly reporting you built is what you would bring; say it as what you did, not as expertise. | Reciprocity is the peer question; it turns the seam into a joint plan |
| C5 | "When did you choose a town's view over a number?" | VAL | [grounded] "every branch is part of its town" (values) | Open prompt. Selection scaffold: pick a decision where the local view and the number disagreed. If none comes to mind, say so plainly, then say how you would find out what a town needs before a number decides. | Neighbours, Not Numbers is the value this question scores. Your material has no sentence for it, so it is a scaffold only |
| C6 | "How did you decide what counted as a complaint in that spreadsheet?" | Pressure | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." (your message) | Hold: say what you did in the build, in your own words. Answer slot: if you decided the definition, say how; if it came from the regional manager's template or from elsewhere, say so. Concede a specific limit; do not fold on the claim that you built it. | Pressure tests the spreadsheet, the one number-related claim in your material |
| C7 | "Your region is moving to five hubs. A branch manager's team fears losing its complaints role. What do you do?" | CASE | [grounded] "consolidate eight branches into five hubs over 2027" (brief, as you summarised it); [generic] structure | Clarify what the role change is, then the objective (keep complaints handled and the member served), then the people (the team's fear is real), then the approach, then the risks. Think aloud. | A live consolidation problem from the brief; it presumes nothing about your history |
| C8 | "You trained tellers. How would you coach our supervisors on escalations?" | JD | [grounded] "trained new tellers on our escalation script" (your message); the JD line "coach branch supervisors on escalations" | Answer slot: if you coached anyone on escalations beyond new tellers, say who and what; if you did not, say so plainly and describe how you would start with supervisors. | F7 is thin; the slot asks for what you did and then a plan, never a past you do not have |

**Round 3 reverse questions**
1. "What could a new person do in the first month that would genuinely help your branches?" Why: a reciprocity question, which a peer panel rewards.
2. "Where do complaints get stuck between a branch and the contact centre?" Why: it shows you want the seam, and the answer is the case you will work on.
3. "How do branches decide when a complaint goes up to the centre?" Why: it is the escalation rule your role would own, asked from the people who use it.

---

## 8. Requirement coverage

| JD requirement | Covered by |
|---|---|
| 4+ years in financial-services customer operations | A1 |
| experience handling regulated complaints | B8 (partial), C1 |
| confident presenting to senior leaders | A6, B6 |
| comfortable with Excel reporting | B8, C6 |
| own the complaints process end to end across branches and the contact centre | B2, B3 |
| report monthly on complaint volumes and resolution times | B8 |
| coach branch supervisors on escalations | C8 |
| work with digital teams on self-service journeys | B5 (partial: the digital move, not a team question). No rehearsed team-work story exists, so no team question is set |

---

## 9. Values cheat sheet

The panel scores all four values, so this section applies.

| Value (official name) | Working meaning | Mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | F3 carries the log. Scaffold: pick a log entry where the member's side and the rule pulled apart. If none comes to mind, say so and give the nearest thing the log carries. |
| Plain Words | If a member needs it explained twice, we wrote it wrong | F7 carries the training. Scaffold: name a letter, script or form a member did not follow. Honest branch: if you can name one you changed, say so; if not, say which words you would change first. |
| Neighbours, Not Numbers | Every branch is part of its town | No fit-snapshot row carries it. Scaffold: pick a decision where the local view and a number disagreed. Honest branch: if none, say so and say how you would find out what the town needs. |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | F3 carries the log. Scaffold: pick a complaint you carried from intake to close. Say what closed it and what you did not own. Honest branch: if none, describe how you tracked a complaint that was not yours to close. |

---

## 10. Grounding brief (from your summary of the July 2026 brief)

These are the facts the pack uses. They come from your summary, not from the brief itself. The brief is not in the sources.

- Move 40% of member service to digital channels by 2028.
- Consolidate eight branches into five hubs over 2027.
- Launch a small-business lending product in Q1 2027.
- The main competitive pressure is app-only banks.

Stale-framing check: none, because the brief was not supplied as text.

---

## 11. Sources

Provided: your message (background, JD text, the four values as you copied them, the recruiter's email, and your summary of the July 2026 brief).

Research tier: L0, no searches. This pass sent no searches. The pasted values, the recruiter's process details and your summary cover what the pack needs.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | The values text is in hand from your paste. The URL you named is the source of the pasted text, not a link to read |
| 2. Interview process | skipped | The recruiter's email fixes the three rounds and their formats |
| 3. Strategy and recent news | unavailable | This pass sent no searches. The July brief is only in your summary, and recent news was not checked. The deep-research offer in section 12 would run it |
| 4. Interviewer name | n/a | No names were given, so there was no query to form |
| 5. Representative JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

---

## 12. Upgrade menu

- Names of the Head of Member Services and the two branch managers → persona weights from their public footprint, and a reverse question tied to their own path.
- Whether the 20-minute case is given in advance or live → a structure you can rehearse against the actual document.
- Any volume or resolution-time figures from your spreadsheet (even rough) → F5's answer slot becomes a real defend-the-number rehearsal.
- Your CV or the spreadsheet itself → F2, F5 and F6 move from your message to an inspectable artifact, which raises their confidence.
- Where the role will be based (a hub or a branch) → the consolidation questions (A4, B7, C7) become concrete.
- A deep research pass (L2) on Ashgrove's recent news, the brief itself, and the complaint rules that apply to the credit union → grounds the case and the strategy questions in published text.
