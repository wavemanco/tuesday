Your prep pack is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-tuesday-part-2-rooms-case-2-denied-0150716d/7dbc0930-84c3-4c71-8e6c-c26e2154f896/scratchpad/atlas_freight_operations_manager_interview_pack.md`. I built it for a hiring-manager round by default, since your note didn't say who you're meeting. Web search was refused in this session, so the pack has no company values, interview loop or strategy from research. Those parts say so and rest on your JD and background alone.

The pack's biggest exposure is scale. You have three supervisors and one site's experience against a JD asking for twelve supervisors across four sites. Nothing in your material shows the on-time or cost-per-shipment numbers the JD names, and Power BI is a plain gap. The pack gives you honest answers for each of these, and it won't let you claim more than you told me.

Say the word and I'll play the Skeptic on A1, the question the pack names as highest-ROI prep: how many people you have led, and across how many sites. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

Who are you meeting, and what is the round: a hiring-manager conversation, a panel, a case or presentation, or something else? If the recruiter sent focus areas or a deliverable, include them, since they reweight every question.

Do the location and the shift pattern the role needs work for you? The posting doesn't say where the four sites are or when the shifts run, and that decides whether this is a role you can take.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: atlas_freight_operations_manager_interview_pack.md -----
# Interview prep pack: Operations Manager, Atlas Freight

- **Company:** Atlas Freight (regional logistics, 800 employees, per your note)
- **Role:** Operations Manager, four terminal sites, team of 12 supervisors
- **Interviewer:** not known
- **Round:** not known. Built as a hiring-manager round by default. Persona weights are flat until you say who you are meeting.

## 1. How to use this pack

Personas are how a question is asked. Types are what it is scoring.

| Type | Meaning |
|---|---|
| VAL | Behavioral: does past behavior show the values the company publishes |
| EXP | Experience: do your claims survive scrutiny, and what was actually yours |
| JD | Role: can you do the listed job, including its gaps |
| CO | Company and strategy knowledge |
| CASE | Live problem from the role, solved aloud |

The guidance is scaffolding, not a script. Rehearse the shape and the honest branch, not a memorised paragraph.

## 2. Fit snapshot

The JD requirements are the ones in your message. That text is a summary, not the full posting, so the requirement quotes are as you gave them. The evidence quotes are your own sentences.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" (JD, as pasted) | "7 years in warehouse and distribution ops" - your message; "ran the site's peak-season surge plan two years running" - your message | medium | [grounded] | transferability | Your material shows seven years in adjacent warehouse and distribution work, and a site-level surge plan. It does not show terminal operations, or more than one site. Bridge: "I have seven years in warehouse and distribution operations." Answer slot: if you have run operations at more than one site, say which and how; if not, say so, and say how you would learn a new site's routine first. |
| F2 | "lead a team of 12 supervisors" (JD, as pasted) | "currently a senior shift manager over 3 supervisors" - your message | medium | [grounded] | transferability | Your material shows three supervisors, not twelve. Bridge: "I'm currently a senior shift manager over three supervisors." Answer slot: if you have led more supervisors than that, or managers across sites, say how many and over what period; if not, say so, and say how you would build up to a team that size. |
| F3 | "5+ years operations leadership required" (JD, as pasted) | "7 years in warehouse and distribution ops" - your message; "senior shift manager" - your message | low | [inferred] | discovery | Years in operations are clear. Years in leadership are not: the material does not say when you first led people. The bridge is this pack's derivation, not your statement. Answer slot: say how many years you have led people, and in which role, in your own words. Do not round the count up. |
| F4 | "drive on-time performance and cost-per-shipment down" (JD, as pasted) | "cut mis-pick rate 40% by redesigning the pick path" - your message | low | [inferred] | discovery | The quote is an accuracy rate, not on-time performance or cost per shipment, so it does not show whether either is reached. Answer slot: if you have tracked on-time performance or cost per shipment, say what, over what period, and how it was counted; if you have not, say so, and say which measure you would track first. |
| F5 | "build reporting in Excel/Power BI" (JD, as pasted) | "solid Excel" - your message | medium | [grounded] | presentation | The quote reaches the Excel half in other words. Bridge: "I'm solid in Excel." It adds nothing. Answer slot: the JD asks for reporting, so expect a probe on what you have built; if you built a report someone used, name it; if not, say so. |
| F6 | "build reporting in Excel/Power BI" (JD, as pasted) | "never used Power BI" - your message | none | [grounded] | capability | You stated the absence, so the words are yours to say: "I haven't used Power BI." Then, as a plan and never as a past, how you would learn it. |
| F7 | "Lean/Six Sigma a plus" (JD, as pasted) | "green belt certified" - your message | medium | [grounded] | none | The quote already reaches the requirement. Confidence is medium because a certificate is not yet shown. Upgrade: a copy of the certificate. |
| F8 | Work at the site or sites the role covers, on the shift pattern it needs ([generic]: role-family condition, not stated in the JD as pasted) | none given | none | [generic] | hard_gate | Your material does not establish this. The posting names four sites and daily terminal operations but not where or when. Surfaced, not bridged. The one question on it is in the closing questions. |

Seven rules these rows follow: the evidence column holds only your sentences; a gap row never gets a bridge that adds practice or figures; the gap type follows the evidence, not the writer's sense of the row; the hard gate (F8) is surfaced, not coached.

## 3. Prohibited claims

Each entry names its basis and its honest form. These are not to be said in the interview.

| Not coached | Basis | Honest form |
|---|---|---|
| "Ran operations across four sites" | Inflated form of F1 | "7 years in warehouse and distribution ops", at its own scope. The material says warehouse and distribution work, not four terminals. |
| "Led a team of twelve supervisors" | Inflated form of F2 | "a senior shift manager over 3 supervisors" |
| "Reduced cost per shipment" | Inflated form of F4's quote | "cut mis-pick rate 40% by redesigning the pick path". The material says mis-picks, not cost. |
| "Built Power BI reporting" | Stated negative, F6 | "I haven't used Power BI." No slot. |
| "Led a Lean or Six Sigma project" | Inflated form of F7 | "green belt certified", at its own scope |

## 4. Persona table

Relationship is unknown, so the weights are flat priors, shown here so you can recalibrate them. The Peer Evaluator is left out for that reason. If the round is with a peer, the upgrade menu covers it.

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Probes the scale gaps (teams, sites) and the Power BI gap | 4. F1 to F3 are the largest gaps, and the Skeptic's material is the gaps. | Say the gap plainly, then the nearest thing you did. Do not bluff a number. |
| Data-Driven Prober | Asks how the 40% and the surge plan were counted | 4. Two headline figures in your material invite a count. | Name the weakest assumption before they do. Say plainly where you do not know how a figure was counted. |
| Case/Strategist | Live operations problems: an on-time drop, cost creep, a first 90 days | 4. The JD is operational, so a live problem is the likely test. This is a pattern for operations roles [generic], not a fact about this employer. | Clarify, then structure, then one measure per problem. Think aloud. |
| Pressure / Stress | Time-boxed "why you over an internal candidate", "how much was actually you" | 3. Mid weight under flat priors. | Pause, restate, hold through two follow-ups, concede the specific gap. |
| Values / Behavioral | Open prompts about unpopular truths and customers | 2. No values-style round is detected: no loop source was read, and the fallback archetype does not assume one. Kept low so the pack still touches it. | Selection scaffold, then the honest branch. |
| Conversational | An opening "walk me through" and a casual Power BI question | 2. Low weight, but casual questions are scored. | A 90-second arc built only from quoted sentences. |

## 5. Question banks

Provenance comes first in each row: the sentences the guidance rests on, quoted exactly as written.

### A: Skeptic (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "How many people have you led at one time, and across how many sites?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" | Answer with the 3, in those words. Answer slot: if you have led more people or more sites than that, say how many and over what period; if not, say so, and say how you would build up to a team of twelve. | F2 is the requirement with the largest gap, and this is its most predictable probe. Covers the 5+ years requirement only as to scope; the years are F3's slot. |
| A2 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Own daily terminal operations across 4 sites" | Name the thinnest part of your material, multi-site daily ownership, in your own words. Then the nearest thing you did, as the quote states it. Answer slot: if you have run more than one site, say so; if not, say so. | F1's gap is the one an honest candidate names first. A plain answer costs less than a defended one. |
| A3 | "Your reporting is in Excel and the role uses Power BI. How would you handle that?" | JD | [grounded] "never used Power BI" | Say the plain sentence: "I haven't used Power BI." Then the plan: what you would learn first, and what Excel would carry meanwhile. The plan is a plan, not a past. | F6 is a stated capability gap. The honest answer is the sentence and a plan, not a claimed skill. |
| A4 | "What on-time or cost-per-shipment numbers have you been accountable for?" | JD | [inferred] "cut mis-pick rate 40% by redesigning the pick path" | Name the closest number you have, the mis-pick rate, and say it is an accuracy measure. Answer slot: if you have tracked on-time performance or cost per shipment, say what, over what period, and how it was counted; if you have not, say so, and name the measure you would track first. | F4 is discovery, and the JD's two headline metrics are the probe. The mis-pick figure is the closest thing, not a substitute. |

### B: Data-Driven Prober (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Walk me through how you counted the 40% drop in mis-picks." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Tell how the rate was counted, in your words. Weakest-assumption move: name the assumption behind the 40% you would defend least, before they do. Answer slot: if you do not know how it was counted, say so; if someone else set the count, say who. | A headline figure. A figure you cannot repeat under a second question is worse than none. |
| B2 | "Which part of the pick-path result was yours, and which was the site's?" | EXP | [grounded] "by redesigning the pick path" | Hold the redesign as yours, in your words, and say what you changed. Concede any part that was not yours by name. Answer slot: if others' work was part of the result, say which part. | Attribution is what this probe tests. The quote gives you the redesign, nothing beyond it. |
| B3 | "Walk me through the peak-season surge plan you ran." | EXP | [grounded] "ran the site's peak-season surge plan two years running" | Tell it in sequence: what the plan covered, and what changed between the first year and the second. Answer slot: if you set its targets, say which and how; if you did not, say whose they were and what you did inside them. | The JD says "own"; this is the nearest owned plan on your record, so ownership of targets is the likely follow-up. |
| B4 | "What have you built in Excel that someone used to make a decision?" | JD | [grounded] "solid Excel" | Name the workbook, who used it, and what it decided. If none comes to mind, say so plainly, then say what you would build first for this role. | Open prompt on the reporting requirement. It asks you to choose an instance, not to claim one. |

### C: Case / Strategist (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Sketch your first 90 days across four sites. What do you need to know first?" | CASE | [generic] | Clarify before structuring: which site is furthest from target on on-time performance, how cost per shipment is counted now, who the site leads are. Then the structure: diagnose, stabilise, one measure per site, a reporting cadence. Speak it in 90 to 120 seconds. | A live problem from the role. No claim about your past. |
| C2 | "On-time performance dropped eight points at one site last month. Diagnose it." | CASE | [generic] | Clarify the metric definition first. Then segment: by lane, by shift, by carrier, by dock. Name the one assumption you would test first. | The JD's headline metric, as a problem. The approach is a method, not a claim. |
| C3 | "Cost per shipment is up and volume is flat. Where do you look?" | CASE | [generic] | Split cost into its parts, labour, premium freight, rework, and ask what changed in each. | A common cost pattern for operations roles [generic]. |
| C4 | "The business wants reporting moved from Excel to Power BI within six months. How do you sequence it?" | JD | [generic] | Agree the handful of numbers the site leads act on. Fix their definitions. Build them in Excel first, then move them once the definitions hold. | A live problem on the reporting requirement. It asks for a plan, and claims nothing about you. |

### D: Pressure (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why should we pick you over an internal candidate?" | JD | [grounded] "7 years in warehouse and distribution ops"; "cut mis-pick rate 40% by redesigning the pick path" | Hold on what you have: the seven years and the redesign. Under pressure, concede specifically that your material does not show a team of twelve or four sites. Never fold on the core claim. | A time-boxed challenge. The concession is the scale gap, named, not a general "I'm not sure". |
| D2 | "That 40%: how much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Hold the redesign as yours. Concede any part that was shared, by name. | A composure test on the headline figure. |
| D3 | "You have three people reporting to you today. Why would twelve accept you as their lead?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" | Hold on what you do with three now, in your words. Concede the step-up as a step-up, not as done. | The scale gap as a challenge. A hold without a concession reads as bluff. |

### E: Values / Behavioral (weight 2)

No values-style round is detected, and no company values were read. These are open prompts from the persona stems, so provenance is generic.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Pick a time you told someone senior something they did not want to hear, and it stuck. If none comes to mind, say so plainly, then say how you would handle it. | A pattern for values-style probes. Your material has no such story, so the honest branch is the answer. |
| E2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | As E1. Pick one instance; if none, say so, then how you would decide. | Same as E1. |

### F: Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | JD | [grounded] "7 years in warehouse and distribution ops"; "senior shift manager over 3 supervisors"; "cut mis-pick rate 40% by redesigning the pick path" | A 90-second arc built from those quoted sentences only, in order: seven years, the redesign, the surge plan, now a shift manager over three supervisors, and why this role. | Openers are scored. Every beat is one of your sentences. |
| F2 | "What are you actually playing with in Power BI these days?" | JD | [grounded] "never used Power BI" | "I haven't used Power BI." Then the plan for learning it. | A casual question on a JD plus-skill that you have not used. The honest answer is short. |

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| Own daily terminal operations across 4 sites | A2, C1 |
| Drive on-time performance and cost-per-shipment down | A4, B1, C2, C3 |
| Lead a team of 12 supervisors | A1, D3 |
| Build reporting in Excel/Power BI | A3, B4, C4, F2 |
| 5+ years operations leadership required | A1 (scope); years are F3's answer slot. No separate question. |
| Lean/Six Sigma a plus | None, and why: the Green Belt is on record, so it earns no question here. Add one if the round is methods-heavy. |

**Highest-ROI prep:** A1. The scale objection (three supervisors against twelve, and one site against four) will come in some form. A rehearsed plain answer changes the interview.

## 6. Reverse questions

Five questions, with why each lands. There is no interviewer profile, so none is tied to their career path, and the round is not known to be with a peer, so there is no reciprocity question.

| # | Question | Why it lands |
|---|---|---|
| R1 | "What would success look like for this role at day 90?" | Shows you think in outcomes, and tells you how the scale expectation is set. |
| R2 | "How is on-time performance measured across the four sites, and which site is furthest from target?" | Shows you know the headline metric. They can answer it, which keeps the conversation going. |
| R3 | "How is reporting produced today, and who reads it?" | Tests the Power BI question from their side and tells you what the tool is actually used for. |
| R4 | "What is the biggest operational challenge the new person would inherit?" | Lets you show judgment without claiming a result. |
| R5 | "How far ahead does peak-season planning start, and who owns it?" | Connects to the surge plan on your record, and shows you know it is a planning problem. |

## 7. Sources

- Provided: your message, with the JD summary and your background. No CV or dossier was provided.
- Research: three searches were sent, each refused by the session's permissions, and nothing was retrieved. The queries were "Atlas Freight regional logistics company values", "Atlas Freight operations manager interview process", and "Atlas Freight logistics strategy news 2026". No values, loop or strategy claim in this pack comes from research.

Research tier: L1 — searches 3 of 6, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Atlas Freight values | unavailable | Refused. Would have set the values section, but only if a values-style round had been detected. |
| 2. Atlas Freight interview process, operations manager | unavailable | Refused. Would have named the rounds and set the persona weights. Weights are flat instead. |
| 3. Atlas Freight strategy / recent news | unavailable | Refused. Would have fed the CO bank. The CO bank is empty, so no CO question is in this pack. |
| 4. Interviewer name and company | n/a | No name was given, so there was no query to form. |
| 5. Representative operations manager JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions. |

## 8. Upgrade menu

- Who you are meeting, their name and title → persona weights from their public footprint, and a tailored reverse question
- The round's format, and any focus areas from the recruiter → coverage of any declared deliverable, and reweighted banks
- Where the role is and what shift pattern it runs → clears F8, the hard gate, one way or the other
- Full job posting text → the requirement quotes become exact, and any requirement I have not seen can be covered
- Green Belt certificate → F7 moves from medium to high
- A workbook or report you built in Excel that someone used → F5 gains a named artifact, and B4 gets a real answer
- Team and site numbers you have led, and any on-time or cost-per-shipment figures you tracked → F2, F4 and the A-bank slots get your own words
- Permission for web search → the three research targets can run, and the CO bank and values section can be built from sources
