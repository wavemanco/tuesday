Your prep pack is saved as `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-tuesday-part-2-rooms-case-4-denied-a5bfabd7/50789f3b-da37-450c-af67-c47400c88771/scratchpad/quartzline_platform_apis_interview_pack.md`. It has 18 questions weighted toward the Skeptic and Case personas, since that is what a hiring-manager round usually looks like.

Three things to know before Thursday:

- **Rehearse A1 hardest.** It's the objection the dossier named: you've never held the PM title or owned a roadmap. The answer opens with the plain acknowledgment, then bridges with the integration work and its limit, then gives a ramp plan as a plan, not as past experience.
- **Don't say "seven years of integration leadership."** That phrase appears only in the dossier's decision summary, not in any verified evidence entry, so the pack doesn't use it.
- **Use the dossier's wording for your evidence.** The pack quotes three verified entries: the 30+ client integrations, the integration playbook, and the roadmap-input sessions. The roadmap-input sessions are medium confidence, so volunteer their limit before they're probed.

Web search was refused, so I have no Quartzline values, interview-loop structure or strategy. The values cheat sheet and loop-based persona weights are missing and labelled that way in the pack. The dossier is also 89 days old, so the posting may have changed.

Want me to run the Skeptic drill on A1 now?
I can also write a `tuesday-dossier.md` with `pack_feedback` once we've rehearsed, so the gaps carry into later sessions.
If you'd like a Word version of the pack, say so and I'll convert it.

Has the posting changed since August? And does the 45 minutes include a case or exercise?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quartzline_platform_apis_interview_pack.md -----
# Interview prep pack: Product Manager, Platform APIs at Quartzline

**Round:** hiring-manager conversation, 45 minutes, Thursday. **Interviewer:** not named.
**Built from:** tuesday-dossier.md (job-underwriter 1.1, generated 2026-08-14, 89 days before today). The posting and the role may have changed since then. Check that first (upgrade menu).

## 1. How to use

Personas are how a question arrives. Types are what it scores: **JD** is a stated requirement, **EXP** is what you actually did, **CASE** is a live problem from the role with no claim about your past, **VAL** is values. No CO (company knowledge) questions: research did not run. Guidance is scaffolding, not a script. Say only what a quoted line of yours supports, in your own words.

Highest-ROI prep: **A1**, the objection the underwriter named. Rehearse it deepest.

## 2. Fit snapshot

Dossier E1, E2, E3 are the `verified_candidate_evidence` entries, in order. Requirement text is the supplied JD's, as the dossier quotes it.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" — dossier R1, must_have | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier E1 | low | [grounded] | transferability | Adjacent work, not the title or the years. Your words: "I led integrations of the vendor's APIs end to end, from scoping through go-live." Limit, said plainly: "I haven't held the PM title." The years are not in your material, so add none. |
| F2 | "Own the roadmap for the partner-facing API platform" — JD responsibility | none given | none | [grounded] dossier acknowledge_gap | capability | Dossier records this as acknowledge_gap, so no bridge. Your words: "I haven't owned a product roadmap." Then a ramp as a plan, never as a past. |
| F3 | "Shipped API or platform products" — dossier R2, must_have | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier E1 | high | [grounded] | transferability | The underwriter did not grade R2, so this gap type is this pack's call. The quote is client integration work, not a platform you shipped. Your words: "I led integrations of the vendor's APIs through go-live." Answer slot: if you shipped an API or platform feature yourself, say which; if not, say so plainly and return to the integrations. |
| F4 | "Technical fluency: API docs, schemas" — dossier R3, important | "Wrote the internal integration playbook her team uses" — dossier E2 | high | [grounded] | presentation | The playbook is the nearest thing to API docs in your material. Name it as what it is, and add no tool, schema or document count. Your words: "I wrote the internal integration playbook our team uses." |
| F5 | "Stakeholder management across engineering, sales, customers" — dossier R4, important | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier E1 | high | [grounded] | discovery | The quote reaches customers and architecture. Engineering and sales are silent in your material. Answer slot: if engineering or sales were part of those integrations, say who and what you needed from them; if not, say so plainly and return to the customer and architecture work. |
| F6 | "Agile delivery experience" — dossier R5, preferred | none given | low | [inferred] from dossier R5's clarify strategy | discovery | Nothing quoted speaks to it. Answer slot: if you ran agile delivery, name the cadence and your part in it; if not, say so plainly, then say what you would want to confirm about how these squads define it. |
| F7 | "Define and track adoption metrics" — JD responsibility | none given | none | [inferred] from dossier unknowns | discovery | No current baseline is stated anywhere. Answer slot: if you defined or tracked adoption for an API, say what you counted; if not, say what you would measure first. Never describe a measure you did not track. |

## 3. Persona weights

Weights rest on the hiring-manager prior alone. The loop is unknown because research did not run.

| Persona | How it shows up here | Likelihood and why | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet probing of the roadmap and PM-title gap | High: hiring-manager prior, and the dossier's named objection sits here | Plain acknowledgment first, then the bridge with its limit, then a ramp as a plan |
| Case/Strategist | Live partner problems from the role | High: a hiring manager buys capability on their own roadmap | Clarify, objective, segmentation, approach, metrics, risks; name the framework once |
| Data-Driven Prober | "How was 30+ counted?" | Medium: E1 carries a figure, and figures get probed | Defend-the-number slot; name the weakest assumption you actually know |
| Pressure | "That sounds like PM work" | Lower: not in the hiring-manager prior; kept because the roadmap gap invites a pushed follow-up | Pause, restate, hold through two follow-ups, concede one specific point |
| Conversational | Opener, "walk me through" | Medium: the usual opener, and casual questions are scored | A pre-scripted 90-second arc |
| Values / Behavioral | Open "tell me about a time" prompts | Low: no values round detected and no loop source read; touched so the pack is not blind to it | Selection scaffold with its honest branch |

Peer weighting is not applied: this is a hiring-manager round.

## 4. Question banks

Requirement coverage: R1 (PM years) A1, A4, C1, D2, E1. R1 roadmap ownership A1, A2, A3, RQ1. R2 A4, C1. R3 C2, E2. R4 A3, B1. R5 A5. Discovery with partners B1, RQ3. Two engineering squads A3, B3, A5. Adoption metrics B2, B4, C3, RQ2. Uncovered: none.

### A. Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier E1 | Start with the plain acknowledgment: "I haven't held the PM title, and I haven't owned a product roadmap." Then the bridge with its limit: "What I bring is the integration side: I led integrations of the vendor's APIs end to end, from scoping through go-live." Then the ramp, as a plan: "In the first months I'd spend the most time on how the squads decide scope and on the adoption baseline before I change the roadmap." Hold through two follow-ups by returning to the quote. If pushed on the comparison, concede one point: "A PM with three years would need less ramp on the roadmap than I would." | The underwriter named this as the likeliest objection, so it is the deepest rehearsal. Its negatives come from the dossier's prohibited_claims and acknowledge_gap, so the question stands as written. Covers F1 and F2. |
| A2 | "How did client evidence get into product planning, and who decided what it changed?" | JD | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier E3, medium; [grounded] "Having set prioritization for an engineering squad" — dossier prohibited_claims | Volunteer the caveat first: the sessions were yours to run, and they fed client evidence in. Then the limit: "I haven't set priorities for an engineering squad." Answer slot: if a decision that came out of those sessions was yours, name it and how you made it, in your own words; if it was product's, say so plainly. | Roadmap ownership is in the JD, so a probe on who decided is likely. E3 is medium confidence, so the limit goes out before it is extracted. Covers F2. |
| A3 | "How would you split roadmap decisions between yourself and the two engineering squads?" | JD | [grounded] "Having set prioritization for an engineering squad" — dossier prohibited_claims | Answer as a principle, not as experience. Say the acknowledgment first: "I haven't set priorities for an engineering squad." Then propose how scope and partner commitments would divide, marked as a plan. Do not describe a split you have run. | "Two engineering squads" is the JD's line. The authority question is the dossier's open unknown, so it is asked as a plan question. Covers F2 and R4. |
| A4 | "Your integrations were delivered for clients of the vendor's APIs. What did that give you that a platform PM would need?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier E1 | Keep the relationship exactly as the quote has it: integrations delivered for clients, on the vendor's side. Describe what you did. Answer slot: if you shipped an API or platform feature yourself, say which; if not, say so plainly and say what the integrations showed you, in your own words. | Covers R2, which the dossier lists as must-have but did not grade. Describing the relationship the wrong way round, such as the customer's side, is what collapses on the first follow-up. |
| A5 | "How have you worked with engineering on delivery, and what did that look like in sprints?" | JD | [generic] | Clarify rather than bridge: nothing quoted speaks to agile delivery, so the answer is the slot. If you ran sprints or agile delivery, name the cadence and your part in it. If you did not, say so plainly, then say what you would want to confirm about how these squads define agile delivery. | The JD's Agile line is the raising source. The dossier marks it low confidence and discovery, so the guidance asks rather than asserts. Covers F6 and R5. |

### B. Case/Strategist (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Partners say a webhook in the docs doesn't match what the API sends. What do you do in your first week?" | CASE | [generic] | Clarify scope first: which partners, how many, and whether it is a documentation error or a behaviour error. Talk to two affected partners, the squad that owns the endpoint, and support. Decide by impact on live integrations, and say what you would tell partners while you verify. Name no past incident. | "Run discovery with integration partners" makes partner problems the core of the role. This is a live problem and presupposes nothing about you. Covers R4 and discovery. |
| B2 | "Partner API adoption has been flat for two quarters. Where do you start?" | CASE | [generic] | First question: how adoption is measured today and what the baseline is. The JD names adoption tracking but states no baseline. Then segment partners by integration stage (signed up, first call, in production) and look for the stage where they stall. | Tests the adoption responsibility (F7). The baseline question is the dossier's open unknown, and asking it reads as diligence. |
| B3 | "You have two engineering squads and more partner requests than capacity. How do you choose what goes first?" | CASE | [generic] | State criteria in order: partner impact, how many partners a request blocks, cost to each squad. Say who decides with the squad leads. Make the trade-off aloud and do not describe a past decision. | Covers "drive delivery with two engineering squads" and the squad-authority unknown. |
| B4 | "Define adoption for a partner API in one sentence." | CASE | [generic] | One metric with a denominator and a time window. Name what it excludes, then what would make the number misleading. | Tests metric definition, which the JD assigns to this role. Generic: no claim about your history. |

### C. Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the 30+ integrations were counted." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier E1 | Answer slot: if you counted them, say what counted as one integration and over what period; if someone else kept the count, say so. Name the part of the count you would defend least. Say which go-lives you led and which the team did. If you do not know how it was counted, say that. Never supply a method or number you do not have. | The figure in E1 is the one a prober will test. Defend it in your own words; do not reconstruct it. Covers F1 and F3. |
| C2 | "Your playbook — who uses it now, and how would you know?" | EXP | [grounded] "Wrote the internal integration playbook her team uses" — dossier E2 | Say the use you know of and how you know it. If you do not track use, say so and say what you would check first. | E2 is high confidence and inspectable, so this is where the playbook becomes evidence rather than a claim. Covers F4 and R3. |
| C3 | "What would you measure to know a partner integration had succeeded?" | CASE | [generic] | Pick one outcome (for example, first production call) and one guardrail (for example, support tickets per integration). Give the denominator. Do not describe a measure you tracked unless you did. | Covers the adoption responsibility (F7). A question about the role, not your past. |

### D. Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "That sounds like PM work. Which part of it was actually yours?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier E1; [grounded] "Having set prioritization for an engineering squad" — dossier prohibited_claims | Hold-then-concede. Pause and restate. Hold: "I led the integrations end to end: scoping, requirements, architecture, UAT, go-live." Follow-up 1 ("but who set the scope?"): return to the quote, "Scoping was part of the work I led." Follow-up 2: concede the specific limit, not the core: "I haven't set priorities for an engineering squad." Do not fold on the integration work. | The hold has to be one the quote carries. The concession is the plain acknowledgment, sourced by the dossier. Covers F1. |
| D2 | "Sixty seconds: why you over a PM with three years?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier E1; [grounded] "Wrote the internal integration playbook her team uses" — dossier E2 | Pause and restate it. Then anchor in the two quotes: the integrations, then the playbook. Close with the limit: "I haven't held the PM title, so my case is the integration side." Do not claim PM equivalence. | The time-boxed version of A1. Covers F1. |

### E. Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So — walk me through the journey." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier E1; [grounded] "Wrote the internal integration playbook her team uses" — dossier E2; [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier E3, medium | A 90-second arc in this order: integration delivery, the playbook, the roadmap-input sessions with their caveat, then why this platform. End on the integration side, not on a title. | Casual openers are scored. Rehearse the arc so the first two minutes never reach for "PM" as a held role. Covers R1. |
| E2 | "What API docs or schema tooling have you used lately?" | JD | [grounded] "Wrote the internal integration playbook her team uses" — dossier E2 | Answer slot: name tools you have used, and when. If none recently, say so plainly, then say how you would learn this platform's schemas. | Covers R3. Nothing in the material names a tool, so the tool names are the slot. |

### V. Values (weight 2, touch-point only)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time you told someone senior something they did not want to hear. It needs a named stake, your own words, and what happened after. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. | Persona stem. No values round is detected, so this is a touch-point, not a predicted round. |
| V2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Same scaffold: a real instance with the customer, the metric and the choice you made. If none, say so plainly, then the nearest thing your material carries, or how you would handle it. | Persona stem. Scaffold only; no claim. |

## 5. Reverse questions

| # | Question | Why it lands |
|---|---|---|
| RQ1 | "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" | Resolves the dossier's top unknown before you accept the role. |
| RQ2 | "How is partner API adoption measured today, and what is the current baseline?" | The JD assigns the metric and states no baseline. Asking reads as diligence. |
| RQ3 | "Who runs discovery with integration partners today, and how often does it happen?" | The JD names discovery. This tests whether it exists as a practice. |
| RQ4 | "What would a good first quarter in this role look like to you?" | Turns the interview into a success definition you can be measured against. |
| RQ5 | "When a squad lead and the PM disagree on scope, how does the team decide?" | The squad-authority question asked a second way. Shows how disagreement is handled as a process. |

No interviewer name was given, so no reverse question is tied to their path.

## 6. Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | Dossier prohibited_claims | "I haven't held the PM title." Plain acknowledgment, sourced. |
| Having owned a product roadmap | Dossier prohibited_claims and acknowledge_gap | "I haven't owned a product roadmap." Plain acknowledgment, sourced. |
| Having set prioritization for an engineering squad | Dossier prohibited_claims | "I haven't set priorities for an engineering squad." Plain acknowledgment, sourced. |
| Owned the roadmap, from "Ran quarterly roadmap-input sessions" | Inflated form of E3 | E3 at its own scope. Pack observation, not words for you: your material says roadmap-input sessions that fed evidence to product, not that you set the roadmap. |
| Shipped an API or platform product, from "Led 30+ end-to-end client integrations" | Inflated form of E1 | E1 at its own scope. A4's slot asks only about a feature you shipped yourself. |
| "Seven years of integration leadership" | Dossier decision summary only; no verified entry carries it | Not asserted. The dated facts come from your own record, not from this pack. |

## 7. Sources

- **Provided:** tuesday-dossier.md, dossier_version 1.1, generated 2026-08-14. Consumed: `role_profile` (JD tier), `handoff_to_mock_interview` (E1–E3 are its verified evidence; weak areas; likely objection; risks; employer questions; prohibited claims) and `decision` (context only). Absent from this dossier: `evidence_map`, `evidence_state` and `risk_register`. So the grading for F3–F7 is this pack's, not the underwriter's.
- The decision summary says "seven years of integration leadership". No verified entry carries that, so the pack does not use it.
- **Research tier: L1, searches 3 of 6, fetches 0 of 2.** All three searches were refused because web search permission was not granted.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quartzline values | unavailable | Would have set the values cheat sheet from the official page. No values section; no values round detected |
| 2. Quartzline interview process, product manager | unavailable | Would have named the loop and set persona weights. Weights here rest on the hiring-manager prior alone |
| 3. Quartzline strategy / recent news | unavailable | Would have fed the CO bank. None written; the case bank is generic |
| 4. Hiring-manager name | n/a | No name given, so no query and no interviewer read |
| 5. Representative JD | skipped | The dossier's `role_profile` fixes the requirements |

Refused queries: "Quartzline company values"; "Quartzline interview process product manager platform APIs"; "Quartzline strategy news 2026".

## 8. Upgrade menu

- The posting as it reads today → the dossier is from August. If requirements have moved, F1–F7 and the coverage line move with them.
- Web-search permission, or the Quartzline values page and interview guide pasted → the values cheat sheet, the loop, persona weights and CO questions (the three refused searches).
- The hiring manager's name → an interviewer read and a reverse question tied to their path.
- A list or count of the 30+ integrations, if you can share it → C1 can hold a figure you can inspect.
- Any API or platform feature you shipped yourself, named → A4 and F3 move from slot to evidence.
- Your dated record of roles and tenure → the "seven years" line can be stated only if your record shows it, quoted as written.
- Whether the 45 minutes includes a case or exercise → a graded-deliverable section, only if one is announced.
