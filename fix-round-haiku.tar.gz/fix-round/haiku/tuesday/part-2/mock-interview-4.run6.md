Your prep pack is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-tuesday-part-2-rooms-case-4-denied-ebe7f921/b448ef94-4263-4cd0-86d0-d60e68e0ed43/scratchpad/quartzline_product-manager-platform-apis_interview_pack.md`. It's built for the hiring-manager round, with 17 questions weighted toward the Skeptic and Case personas.

**What to be ready for**

- **The objection (S1):** "You've never held the PM title or owned a roadmap — why hire you into one?" The dossier flagged this as the likeliest question, so it gets the most rehearsal. Open with your integration work in its own words, then say plainly that you haven't held a PM title or owned a roadmap. Concede the roadmap part on the second follow-up. Don't argue it.
- **Roadmap authority (S2, C3, R1):** The JD says "own the roadmap," but nothing in your material shows decision rights over the squads. Ask how decisions split between you and the squad leads. That answer matters for whether the role is what it says.
- **Shipped platform products (S3):** Nothing in your material shows you shipped one, only integrations of the vendor's APIs. If you did ship something, name it and your part. If not, say so.
- **Adoption (C1, C2, R2):** The dossier says the current adoption baseline is unknown. Expect a case question on it, and ask for the baseline.

**Things I could not do**

- **Research didn't run.** The three web searches were refused because permission to use WebSearch wasn't granted. So the pack has no company values, interview-loop structure or current strategy. Grant search and I can rerun it before Thursday.
- **The dossier is three months old.** It's dated 2026-08-14 and today is 2026-11-11. Check the posting still matches its requirements before you prep against it.

**Offers, not pushed**

- Want me to run a live drill? I can play the Skeptic on S1, the question the pack names as the highest-value prep.
- I can save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry forward.
- I can convert the pack to a Word document if you'd like one.

Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quartzline_product-manager-platform-apis_interview_pack.md -----
# Interview prep pack: Product Manager, Platform APIs at Quartzline

**Round:** Hiring-manager conversation, 45 minutes, Thursday. Interviewer not named.
**Built from:** the job-underwriter dossier you carried in (`tuesday-dossier.md`, version 1.1, dated 2026-08-14, decision `conditional_go`). The dossier is about three months old. Confirm the posting still reads the same before Thursday.

## How to use + type key

Personas describe how a question arrives. Types describe what it scores.

- **JD**: can you do the listed job, including its gaps
- **EXP**: do your claims survive scrutiny, and what did you personally do
- **CASE**: live problem from the role, reasoned out loud
- **CO**: company and strategy knowledge (none rehearsed here; research did not run, see Sources)
- **VAL**: behavioral, against published values (not detected for this round)

Guidance is scaffolding, not a script. Say it in your own words.

## Fit snapshot

Requirements are quoted from the dossier's `role_profile`. Evidence is quoted from the dossier's `verified_candidate_evidence`. Confidence and gap type are the dossier's where it grades a row. Where it does not, the pack's own grade is marked.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" (dossier R1, must-have) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier row, verified) | low | [inferred] | transferability | Adjacent work, not PM tenure. Words: "I led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live." Limit, in your own words: "I haven't held a product manager title." Do not add years of PM work. |
| F2 | "Owning a roadmap and prioritization authority" (dossier R1 sub-claim) | "Ran quarterly roadmap-input sessions feeding client evidence to product" (dossier row, verified) | none | [grounded] | capability | The dossier records no roadmap ownership (acknowledge_gap). Words: "I haven't owned a product roadmap." Then a ramp plan, stated as a plan and never as a past. The quote above is input to product, not ownership, so do not stretch it. |
| F3 | "Shipped API or platform products" (dossier R2, must-have) | "Led 30+ end-to-end client integrations of the vendor's REST APIs" (dossier row, verified) | low (pack's grade; dossier silent) | [inferred] | discovery | The material shows integrations of someone else's platform, not a platform you shipped. Answer slot: if you shipped an API or platform product, name it and your part in it; if your work was the integrations above, say that plainly. |
| F4 | "Stakeholder management across engineering, sales, customers" (dossier R4, important) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier row, verified) | medium (pack's grade) | [grounded] | transferability | The quote reaches the customer side. No quote reaches engineering or sales. Words: the customer-side quote at its own scope. Answer slot for the other two: if you worked with engineering or sales on an integration, say how and what was yours; if not, say so and say how you would build those relationships. |
| F5 | "Technical fluency: API docs, schemas" (dossier R3, important) | none given | none | [inferred] | discovery | No quote. Answer slot: if you wrote or reviewed API docs or schemas, say which and what you checked; if you did not, say so and say how you would learn the partner schema. |
| F6 | "Agile delivery experience" (dossier R5, preferred) | none given that speaks to it | low | [inferred] | discovery | Dossier gives clarify strategy. Answer slot: "How do you define agile delivery inside a product org?" Honest branches: say what you did in delivery, or say you would confirm what they mean by it. |

Gap type follows the routing rule: the dossier's `gap_type` where it grades a row, otherwise the pack's call from the evidence cell.

## Prohibited list

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | Dossier `prohibited_claims` | "I haven't held a product manager title." No slot. |
| Having owned a product roadmap | Dossier `prohibited_claims` and `acknowledge_gap` area | "I haven't owned a product roadmap." No slot. |
| Having set prioritization for an engineering squad | Dossier `prohibited_claims` | Only the roadmap-input quote (F2) at its own scope. |
| Having shipped an API or platform product | Inflated form of F3 (local) | The F1 quote at its own scope. Limit as the pack's observation: the material shows integrations of the vendor's APIs, not a shipped platform. |
| Having run discovery with integration partners | Inflated form of F1 (local) | The F1 quote at its own scope. "Scoping" and "requirements" are the stages in the quote; "discovery" is not. |

## Persona weights

Relationship prior for hiring manager: Case/Strategist and Skeptic. The dossier's objection sits on the Skeptic axis, so Skeptic is weighted top. No interviewer profile exists, so no signal adjustments apply.

| Persona | Weight | Why | Counter-strategy |
|---|---|---|---|
| Skeptic | top (5) | Dossier names the PM-title objection as the highest-ROI rehearsal | Hold the quote, then the plain acknowledgment, then the ramp; concede the roadmap part specifically |
| Case/Strategist | high (5) | Hiring managers buy capability and test it on their own roadmap | Clarify, then structure, then metrics, then risks |
| Data-Driven Prober | mid (3) | F1 and the integration count will be probed | Say how you counted, and the weakest assumption, before they do |
| Pressure | mid (2) | Composure check on the PM-title gap | Pause, restate, anchor in your quote, hold two follow-ups |
| Conversational | low (2) | Opener and reverse-question slot read as scored | Scripted 90-second arc from quotes only |

Total: 17 questions. The guide targets 18 to 26; a 45-minute round cannot rehearse more than this, so the lower count is a deliberate cut. The bank covers every high-priority requirement.

## Question banks

### Skeptic (weight: top)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| S1 | "You've never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (F1). Negatives: dossier `prohibited_claims` ("Having held a product manager title or role") and `acknowledge_gap` area ("Owning a roadmap and prioritization authority") | Highest-ROI prep. The dossier named this objection; it is the interviewer's line. Hold: state the F1 quote, then "I haven't held a product manager title, and I haven't owned a product roadmap." Then say what the integration work gives you and what you would need to ramp on. Hold through two follow-ups by returning to the quote. Concede on the second follow-up: name the roadmap part as new to you and say what you would do in the first 30 days. Answer slot: none. The "three years" is from R1, which is the JD's own line. | F1 and F2 are where this lands. The objection is aimed at the thin spot, so do not thicken it. |
| S2 | "Which roadmap decisions would you make alone, and which would you need the squad leads to make?" | JD | [grounded] the JD line "Own the roadmap for the partner-facing API platform" (dossier `role_profile`) | Plain acknowledgment: "I haven't set roadmap priorities for an engineering squad." Then say how you would find the line: ask the leads, read past decisions, agree principles up front. Do not describe a decision you have made. | F2. The decision authority is unknown in the JD, so ask it back in reverse questions too. |
| S3 | "Which API or platform product have you shipped end to end, and what was your part?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (F3). Premise "shipped a platform product" is from R2 | Answer slot: if you shipped an API or platform product, name it and your part, in your own words. If your work was the integrations above, say so plainly and stay with them. | F3. The premise is the JD's, not your quote, so the second branch allows the premise to be false. |
| S4 | "What does a partner PM do that your integration work didn't cover?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (F1) | Name the overlap first (scoping, requirements, the client's view) and then the difference (owning the roadmap and the partner's priorities). Concede the difference without folding on the overlap. | F1 and F2. Tests whether you can separate adjacent from direct without overclaiming. |
| S5 | "Why leave the work you're doing now for a PM role you haven't held?" | JD | [generic] | Motivation: connect to the integration work you know and the roadmap you want to own. Keep it to what you can say truthfully. The question carries no premise about your past. | Motivation probe. Tied to the same gap as S1. |

### Case/Strategist (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Adoption of the partner API has been flat for a quarter. How would you diagnose it in your first 30 days?" | CASE | [generic] | Clarify first: how adoption is measured today and what the baseline is. Then segment partners, look at integration friction, and decide. Make no claim about your past. | The dossier lists adoption measurement as an unknown. Asking it back doubles as a reverse question. |
| C2 | "Name three adoption metrics for a partner API, and what each would tell you." | CASE | [generic] | Name metrics before weighting them. For each, name the assumption you would defend least. Do not invent a baseline. | Metric answers show the weakest-assumption move. |
| C3 | "A partner asks for a breaking schema change and one squad says no. How do you decide?" | CASE | [generic] | Clarify decision rights first. Name the people who decide. Lay out the trade-off for the partner and the squad. Say which decision is yours and which is theirs. | Tests the decision-authority unknown. Pair with reverse question R1. |
| C4 | "Walk me through how you'd spec a change to a partner-facing endpoint." | JD | [grounded] "scoping, requirements, architecture" from "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (F1) | Answer slot: if you wrote requirements for an integration, say what you wrote. Spec writing for a squad is not in your quotes; if you have not done it, say so and say how you would start. | F1 and F5. Premise is the JD's spec-writing line, so the second branch allows it to be false. |

### Data-Driven Prober (weight: mid)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "How did you count the thirty integrations, and which one would you defend least?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (F1) | Defend-the-number slot: say how you counted, in your own words. If you did not count them that way, say so. Name the assumption you would defend least and which part was yours. Do not supply a counting method. | F1 is the headline figure. Figures raise these four slots and no others. |
| D2 | "Who uses the integration playbook you wrote, and how would you know if it helped?" | EXP | [grounded] "Wrote the internal integration playbook … team uses" (F1, E2 in dossier) | Say who uses it, as your material says. "How would you know" is open: if you measured anything, say what; if not, say you would measure the thing that matters first. | The playbook is inspectable, which helps. The question is premised on use, not on measured effect. |
| D3 | "What evidence came out of your roadmap-input sessions, and what did product do with it?" | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" (F2) | Say what evidence came out, in the quote's terms. Answer slot: if product changed a decision because of it, say which and what you contributed; if you do not know, say so. | Medium confidence per the dossier. Expect a probe; volunteer the limit before it is extracted. |

### Pressure (weight: mid)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Sixty seconds: why should we hire you over someone who has run a roadmap?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (F1). Negative: `acknowledge_gap` area | Pause. Restate the question. Anchor in F1. Hold two follow-ups. Concede the roadmap part explicitly, without folding on the integration work. | Composure check on the largest gap. |
| P2 | "That integration result — how much of it was actually you?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs" (F1) | Answer slot: say which decisions were yours and which were the account team's or the client's. Do not claim the whole result. | Attribution honesty under pressure. |

### Conversational (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V1 | "So — walk me through the journey." | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs" (F1); "Wrote the internal integration playbook … team uses" (F1, E2); "Ran quarterly roadmap-input sessions feeding client evidence to product" (F2) | 90-second arc in three beats, each a quote: integrations led, playbook written, roadmap input run. Close with the plain acknowledgment: "I haven't held a PM title or owned a roadmap, which is why I'm talking to you." | Casual openers are still scored; this one maps the arc onto the gap. |
| V2 | "What are you playing with in API docs and schemas these days?" | JD | [grounded] none given for schemas; F5 has no quote | Answer slot: name what you have worked with in API docs or schemas, in your own words. If nothing specific comes to mind, say so and name how you would get current. | R3, which has no quote. Honest branch matters more than the answer. |

## Reading the interviewer

No interviewer profile. Persona weights rest on the relationship prior. No shared path can be offered, so no mirror opportunity is listed.

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" | Tests the decision-authority gap the dossier flagged as asserted in the JD but not evidenced. |
| R2 | "How is partner API adoption measured today, and what is the current baseline?" | The dossier's second unknown. Their answer tells you whether the metric is ready to own. |
| R3 | "What does the first 90 days look like for someone bringing integration-leadership experience into this role?" | Turns the bridge into a ramp conversation and shows you have thought about the gap. |
| R4 | "How does your team define agile delivery inside the product org?" | Clarifies R5, which the dossier gave a clarify strategy. |
| R5 | "What would make the first six months here a clear success for the person in this role?" | Gives you their success criteria, which you can hold yourself to. |

No reciprocity question: the interviewer is the hiring manager, not a peer.

## Requirement coverage

| Requirement | Covered by |
|---|---|
| R1, 3+ years PM experience | S1, P1, V1 |
| R1 sub, roadmap authority | S1, S2, C3, R1 |
| R2, shipped API or platform products | S3 |
| R3, API docs and schemas | C4, V2 |
| R4, stakeholder management | S4, D3, V1 |
| R5, agile delivery (preferred) | R4. No bank question: preferred tier, dossier gave clarify strategy, covered in reverse questions. |

## Prohibited claims

Repeated from above so nothing in the banks can drift past it. Do not say: having held a PM title or role; having owned a roadmap; having set priorities for an engineering squad; having shipped a platform product; having run discovery with partners.

## Sources

- **Provided documents:** the dossier (`tuesday-dossier.md`, version 1.1). Sections consumed: `role_profile` (requirements and responsibilities as the JD's lines), `verified_candidate_evidence` (evidence quotes), `handoff_to_mock_interview` (weak areas and strategies, likely objection, risks, employer questions, prohibited claims). `decision` read as context only. No CV, no JD text, no interviewer profile was provided.
- **Research tier:** L1 (default). Searches 0 of 6 completed. Fetches 0 of 2.
- **Calls sent:**
  - "Quartzline Platform APIs product manager interview process": refused. Permission to use WebSearch was not granted.
  - "Quartzline company strategy recent news": refused. Same reason.
  - "Quartzline values": refused. Same reason.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quartzline values` | unavailable | Values cheat sheet. Not built: no values round detected, so the section drops anyway. |
| 2. `Quartzline interview process Product Manager` | unavailable | Loop structure. Persona weights rest on the relationship prior, not on a documented loop. |
| 3. `Quartzline strategy` / recent news | unavailable | The grounding brief and CO bank. The CO bank is absent as a result. |
| 4. `{interviewer name} Quartzline` | n/a | No name was given. |
| 5. representative Product Manager Platform APIs JD | skipped | The dossier's `role_profile` fixes the requirements. |

## Upgrade menu

- The posting as it stands today → confirms the dossier's requirements are still current; a changed requirement would reshape the fit snapshot.
- The interviewer's name → persona weights from their public footprint, and a reverse question tied to their path.
- Research enabled for this session → values, loop structure, and a current-strategy brief. These would add a grounding brief and a CO bank. Rerun at L1 once search permission is granted.
- Your CV → turns F1, F3 and F4 from dossier-quoted rows into rows quoting your own sentences, and tests whether the quotes hold.
- A Word version of this pack → say so when you want it.
