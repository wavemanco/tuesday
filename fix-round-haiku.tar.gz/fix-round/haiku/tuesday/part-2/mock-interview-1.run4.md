Your prep pack is saved as `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-tuesday-part-2-rooms-case-1-denied-646420bc/9a8c85af-f152-4a32-9569-2c9943126529/scratchpad/northwind_senior-gtm-strategy-lead_interview_pack.md`. I built it as a session-mode pack for a peer round with Dan, since your note says Dan is a peer. Web search was refused in this session, so the pack rests on your notes and your message.

# Interview prep pack: Senior GTM Strategy Lead, Emerging Products, Northwind Data

Round: 60-minute peer conversation with Dan Kovac, Director of Sales Strategy. Dan is Priya's peer, and both report to the same VP. Session mode, first pack.

## How to use

- **Personas** describe how a question is asked. **Types** describe what is being scored: **VAL** (behavioral or values), **EXP** (your past work, deep-dived), **JD** (the role's listed requirements), **CO** (company and strategy knowledge), **CASE** (a live problem).
- Guidance is scaffolding for a spoken answer, not a script. Rehearse only what you actually did, in your own words.
- **Answer slots** are instructions for the interview, not questions to answer here. Each gives the honest branch as well as the stronger one.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" — your message | "9 at a large consumer-tech company in product strategy & ops" — the coach's notes | low | [inferred] | transferability | Your material says product strategy and operations, not go-to-market for a new product line. Words: "I spent 9 years at a large consumer-tech company in product strategy and operations." Answer slot: if you set go-to-market or launch plans for any product, say which and what you decided; if no such step was yours, say so plainly and stay with the product strategy work. |
| F2 | "identify whitespace across land/adopt/expand/renew" — your message | "set annual volume targets with cross-org consensus" — the coach's notes | low | [inferred] | discovery | Target-setting is sizing-adjacent, not whitespace, so the bridge does not stretch it. Answer slot: if you identified where volume was not being reached, say where and how; if you did not, say so and say how you would find it first. |
| F3 | "run independent analysis in SQL and Tableau" — your message | "skilled in SQL/Tableau" — the coach's notes | medium | [grounded] | presentation | Words: "I'm skilled in SQL and Tableau." The quote reaches the tools, not independent analysis, and no artifact has been inspected, so expect a walkthrough. Answer slot: name one analysis you ran yourself, its question and what it changed; if you have none to name, say so and say what you would build first. |
| F4 | "partner-motion design experience required" — your message | "built a partner-level revenue model used in carrier negotiations" — the coach's notes | medium | [grounded] | transferability | Words: "I built a partner-level revenue model that was used in carrier negotiations." That is partner economics, not the design of a partner motion. Answer slot: if you designed any co-sell terms, incentives or program rules, say which and how you decided; if none was yours, say so plainly and stay with the revenue model. |
| F5 | "strong cross-functional influence" — your message | "set annual volume targets with cross-org consensus" — the coach's notes | medium | [grounded] | presentation | Words: "I set annual volume targets with cross-org consensus." Reworded from the quote only. Answer slot: if you led the consensus, say how; if others did, say which part was yours. |
| F6 | "AI experience a plus" — your message | "uses AI tools daily" — the coach's notes | low | [inferred] | transferability | Words: "I use AI tools daily." Never AI product experience. Answer slot: name what you use them for. |
| F7 | No JD line. Raised by the interviewer's own function (sales strategy). | "No classic sales-ops or quota-setting experience" — the coach's notes | none | [grounded] | capability | The absence is stated, so the words come from it: "I haven't set quotas or run sales operations." Confirm this line in your own words before you say it. Then say how you would learn it, as a plan, never as a past. |
| F8 | No JD line. The figure a probe reaches first. | "proposed a store-surface change credited with a ~$400M ARR uplift" — the coach's notes | medium | [grounded] | discovery | Words: "I proposed a store-surface change that was credited with a ~$400M ARR uplift." The material does not show how the figure was counted or split, so the rest is answer slots (D1, D2). |

Presentation means your quote already reaches the requirement in other terms. Transferability means adjacent work that does not reach it. Discovery means the material is silent. Capability means you stated the absence yourself.

## Prohibited claims

Not coached in any answer, hold or rationale in this pack.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned go-to-market for a product line | Inflated form of F1 | F1's quote at its own scope. The limit is this pack's observation: your material says product strategy and operations. |
| "I drove the ~$400M ARR uplift" | Inflated form of F8's quote | "I proposed a store-surface change that was credited with a ~$400M ARR uplift." |
| "I designed partner programs" or "I designed co-sell motions" | Inflated form of F4 | F4's quote at its own scope. |
| AI product experience | Inflated form of F6 | "I use AI tools daily." |
| Expert in SQL | Inflated form of F3 | "I'm skilled in SQL and Tableau." |
| "I have set quotas or run sales operations" | Negative stated in the coach's notes (F7) | Plain acknowledgment: "I haven't set quotas or run sales operations." No slot on this. |

## Reading the interviewer

Built from your profile line only. No public footprint was checked, because search was refused.

- **Career pattern:** pricing and monetization roles, with one early-stage-startup chapter (your message).
- **Self-described style:** "relentlessly data-driven" (your message).
- **Practical implications:**
  1. Expect every metric to be probed back to its assumptions. D1 to D5 carry the weight.
  2. Case questions tilt toward pricing, packaging and unit economics, Dan's native language. See C1 and C3.
  3. The startup chapter means builder stories land well, and scrappiness probes are likely. See V2 and P3.
  4. Mirror opportunities: none offered. The material shows no shared professional path.

## Persona table

Relationship priors for a peer round are Peer Evaluator and Data-Driven Prober. Interviewer signals push Prober up. No loop source was found, so the loop is not established. The pack uses the generic archetype's flat weights, and says so.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy | Questions |
|---|---|---|---|---|
| Data-Driven Prober | Asks for denominators, counting methods and the assumption behind each figure | High. The interviewer describes themselves as "relentlessly data-driven," and the $400M figure is the most visible number in the background. | Know what you can and cannot say about how each figure was counted. Name the weakest assumption before they do. Say plainly when you do not know. | D1 to D5 |
| Peer Evaluator | Seam-splitting between teams, credit-sharing, "what would you need from me" | High. Peer rounds are priced on what the hire adds to the peer's load. | Reciprocity: what you bring their team, not only what you need. Propose seam principles rather than pretending to know the seam. | P1 to P4 |
| Case / Strategist | Live problems: bundling, whitespace, metric diagnosis | Medium to high. The research note names a competitive threat, and the pricing spine raises case weight. | Clarify, then objective, segmentation, approach, metrics, risks. Think aloud. | C1 to C4 |
| Skeptic | The sales-ops gap, "why this role" | Medium. The sales-ops gap is the obvious probe for a sales-strategy peer. | Hold the plain acknowledgment, then a plan. Never bluff a competency the interviewer owns. | S1 to S3 |
| Pressure / Stress | Time-boxed challenges, "how much was actually you" | Low to medium. Peer rounds rarely stress-test, but the $400M figure invites it. | Pause. Restate. Hold through two follow-ups before conceding anything real. | X1, X2 |
| Conversational / Rapport | Opening arc, casual check on the JD's plus items | Low to medium. Casual questions are still scored. | A 90-second arc. Treat casual questions about SQL and AI as scored. | K1, K2 |
| Values / Behavioral | Influence and customer-first prompts | Low. No values-style round is detected, because no loop source establishes one. Kept at two questions so the persona is touched. | Open prompts with an honest branch when no story comes to mind. | V1, V2 |

## Question banks

Every JD highlight has at least one JD-tagged question (see the coverage table). The Prober and Peer banks rest on your quoted sentences.

### Peer Evaluator (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Our two teams sit side by side on new products. Where's the seam between a GTM plan for a new product line and the sales-strategy work we already run, and what happens when we disagree about it?" | JD | [generic] | Propose seam principles, not a seam you have not seen: who owns the plan, who owns the number, how a disagreement gets settled by data both sides accept. Say what you would ask first. Do not claim to know this team's seam. | Peer probe on the first JD line, "own GTM strategy for two new product lines." It scores whether you would add to Dan's load. The guidance makes no claim about your past. |
| P2 | "How do you handle credit when work spans teams?" | VAL | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" — the coach's notes | Name who did what, in the order it happened. Your sentence says you proposed the change and the uplift was credited with it. Do not say you drove the uplift. Say what your part was and what was not. | F8 is the sentence a credit probe will test. |
| P3 | "When you and a peer disagree on a plan, what happens next?" | VAL | [generic] | Selection scaffold: pick a disagreement with a peer where you had to move a number to settle it. It needs a named stake and a result you can state. If no such time comes to mind, say so plainly, then give how you would handle it. The material carries no such story, so do not invent one. | Persona stem, testing the disagreement style the peer prior names. |
| P4 | "The JD asks for partner-motion design. If you were designing one here, what would you need to know first?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" — the coach's notes | Start with the economics you can speak to: the partner-level revenue model, its inputs and the negotiation it was used in. Answer slot: if you designed any co-sell terms, incentives or program rules, say which and how you decided; if none was yours, say so plainly and return to the revenue model. | F4 is the required skill with the widest gap. The question is a case, but its guidance draws on your one quoted partner sentence. |

### Data-Driven Prober (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how the ~$400M figure was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" — the coach's notes | Four answer slots, each in your own words: how it was counted; what it is sensitive to; the assumption you would defend least; which part was yours. If you did this, say how. If there was no such step, or it was not yours, say so plainly and return to "I proposed a store-surface change." Do not name a method the material never gives you. | F8 is the figure a prober reaches first. Attribution is the test. |
| D2 | "Which assumption behind that number would you defend least?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" — the coach's notes | Weakest-assumption move: name it before Dan does. Answer slot: name the assumption you would defend least, in your own words. If you have not identified one, say so and say what you would check first. | The most likely follow-up to D1. Naming the weak point yourself is worth more than defending the whole figure. |
| D3 | "The partner-level revenue model: what were its inputs, and which of them did you set?" | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" — the coach's notes | Keep to "built" and "used in carrier negotiations." Answer slots: name the inputs you can speak to; say which you set and which you were given; if you do not know how a given input was sourced, say so. | F4's evidence is the one artifact-like claim on the partner side, so it will be probed for inputs. |
| D4 | "Which SQL or Tableau analysis would you walk me through end to end?" | EXP | [grounded] "skilled in SQL/Tableau" — the coach's notes | Say the tools in the quote's terms. Answer slot: name one analysis you ran yourself, its question, its data source and what it changed. If you have none to name, say so, and say what you would build first. | F3 is a presentation gap. Dan will want a walkthrough of independent work, which is what the JD asks for. |
| D5 | "How did you set annual volume targets, and what did the cross-org consensus rest on?" | EXP | [grounded] "set annual volume targets with cross-org consensus" — the coach's notes | Answer slots: the method, which the material does not give; what the consensus rested on; who disagreed. If someone else set the targets and you contributed, say which part was yours. | D5 is the closest thing you have to quota-setting, so expect Dan to press it. F5 and F7 meet here. |

### Case / Strategist (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A much larger platform vendor bundles a similar capability into its suite next quarter. Where do you start, and what do you need to know first?" | CASE | [grounded] "main competitive threat is bundling by a much larger platform vendor" — your message (the research note) | Clarify, then objective, segmentation, approach, metrics, risks. Name the bundle's likely effect on price and renewal. Use the vocabulary of pricing and packaging. The note's threat is not verified externally. | The competitive threat comes from your research note, so it is the case the company most likely cares about. The pricing tilt follows from the interviewer read. |
| C2 | "Northwind is pursuing enterprise expansion, an AI copilot launch and profitability. Which one would your GTM plan serve first, and what does it give up?" | CO | [grounded] "enterprise expansion", "an AI copilot launch ('Compass')", "reaching profitability" — your message (the research note) | Pick one. Say the trade-off in pricing or coverage. Do not claim knowledge of internal priorities. The three priorities come from your note, which is not verified. | A CO question built from the three stated priorities. |
| C3 | "Where would you look for whitespace across land, adopt, expand and renew for one of the new product lines?" | JD | [generic] | Structure: the four motions, the data each needs (SQL is the tool), and which segment looks largest. Say what you would check first. It makes no claim about your past. | JD line 2, "identify whitespace across land/adopt/expand/renew." F2 is a discovery gap, so the answer is method, not a claimed result. |
| C4 | "Compass is the AI copilot launch. What would you measure in its first two quarters from a GTM view?" | JD | [grounded] "an AI copilot launch ('Compass')" — your message (the research note); [grounded] "uses AI tools daily" — the coach's notes | Name the metrics that tie to adoption and expansion, and state the weakest of them. If asked about your AI work, say what you use the tools for. You use AI tools; you have not built AI products. | JD line on AI, paired with a launch the company is actually running. F6 is low confidence, so the answer stays on use, not building. |

### Skeptic (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| S1 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "No classic sales-ops or quota-setting experience" — the coach's notes | Hold the plain acknowledgment: "I haven't set quotas or run sales operations." Then one plan: how you would learn it. Then one adjacent piece you can state: "I set annual volume targets with cross-org consensus." Add nothing to make the gap feel smaller. | F7's capability gap, asked as a day-one question. Answering it directly is the cheapest credibility you will get in the round. |
| S2 | "I don't see sales-ops or quota work in your background. How would you handle that in this role?" | JD | [grounded] "No classic sales-ops or quota-setting experience" — the coach's notes; [grounded] "set annual volume targets with cross-org consensus" — the coach's notes | **Deepest rehearsal in the pack.** Hold 1: "I haven't set quotas or run sales operations." Hold 2, if pressed on how: the ramp plan, meaning how you would learn it and with whom, as a plan and never as a past. Hold 3, if pressed on whether it matters: "The nearest thing I've done is setting annual volume targets with cross-org consensus. I wouldn't call that quota work." Concede specifically what you could not do on day one. Never fold on "I haven't." | The highest-ROI prep. Dan runs sales strategy, which is quota's neighbourhood, so this objection is near-certain in some form. Confirm the negative in your own words first, because the pack depends on it. |
| S3 | "What draws you to owning go-to-market for new products, rather than the product strategy work you've done?" | VAL | [grounded] "9 at a large consumer-tech company in product strategy & ops" — the coach's notes | Selection scaffold: your notes do not state a motivation, so pick one you can stand behind from the JD's line about owning GTM for two new product lines, and name the cost you accept. If the reason is not yet clear to you, say so and say what you would need to know. | The "why now" probe. Motivation is not in your material, so the guidance supplies a selection method, not a reason. |

### Pressure / Stress (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| X1 | "Sixty seconds: why you over an internal candidate?" | JD | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" — the coach's notes; [grounded] "built a partner-level revenue model used in carrier negotiations" — the coach's notes | Pause, then restate. Anchor on the two quoted facts: the consulting and product-strategy background, and the partner revenue model. Hold through two follow-ups. Concede specifically: you do not know the internal candidate's record, and you have not set quotas. | Pressure stem on the hire decision. The hold is what the quotes carry, and the concession is the plain acknowledgment. |
| X2 | "That result: how much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" — the coach's notes | Hold 1: "I proposed it, and it was credited with the uplift." Hold 2: say which part of the counting you cannot speak to. Concede that specifically. Do not fold on the proposal. | Hold-then-concede on the most-quoted figure. |

### Conversational / Rapport (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| K1 | "So, walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" — the coach's notes | A 90-second arc with only the beats the sentence states: consulting, then the consumer-tech product-strategy and operations years, then the next step in your own words. | The rapport opener is scored for economy and interest. The arc does not add roles or outcomes. |
| K2 | "What are you actually playing with in SQL or AI these days?" | JD | [grounded] "skilled in SQL/Tableau" — the coach's notes; [grounded] "uses AI tools daily" — the coach's notes | Name one recent SQL or Tableau example, and one AI tool and what you use it for. If you cannot name a recent example, say so. | Casual wording of two JD items, scored as a question. |

### Values / Behavioral (weight 2)

No published values were read. The round is not detected as values-style.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V1 | "Tell me about a time you had to influence a team that didn't report to you." | VAL | [grounded] "set annual volume targets with cross-org consensus" — the coach's notes | Open prompt on the JD line "strong cross-functional influence" (your message). Selection scaffold: pick a time you moved people outside your line to a decision, name the stake, and say what was yours. If none comes to mind, say so plainly, then give the consensus on annual volume targets, with only the words you can back: who was in the room, in your own words. | F5. Open prompts take a story from a quote, or an honest "none." |
| V2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: a decision where a customer outcome cost an internal number. If none comes to mind, say so plainly. Your material carries no such story, so do not supply one. | Persona stem for the Values persona. |

### Requirement coverage

| Requirement (source) | Covered by |
|---|---|
| "own GTM strategy for two new product lines" (your message) | P1, C2 |
| "identify whitespace across land/adopt/expand/renew" (your message) | C3 |
| "run independent analysis in SQL and Tableau" (your message) | D4, K2 |
| "partner-motion design experience required" (your message) | P4, D3 |
| "strong cross-functional influence" (your message) | V1, D5 |
| "AI experience a plus" (your message) | C4, K2 |
| No JD line: sales-ops and quota experience, raised by the interviewer's function | S1, S2 |

Session total: 22 questions (Peer 4, Prober 5, Case 4, Skeptic 3, Pressure 2, Conversational 2, Values 2).

## Reverse questions

1. "You came to sales strategy from pricing and monetization. What from that work would you want carried into how a new product line gets priced?" Why it lands: it ties to Dan's own path and turns the interview into peer talk.
2. "What could a new person do in their first month that would genuinely help your team?" Why it lands: the peer reciprocity question. It signals you are thinking about what you bring.
3. "Which of the three priorities (enterprise expansion, the AI copilot launch, reaching profitability) is the GTM plan most likely to be judged on this year?" Why it lands: it uses your research note. Check the priorities before you say them, since the note is not verified.
4. "Where do the sales-strategy and product teams split ownership of pricing for a new line?" Why it lands: a seam question, asked from the other side.
5. "How does a partner-motion decision get made here, and who has the final word?" Why it lands: it follows the JD's required partner line.
6. "What did the startup chapter teach you that a larger company's process tends to hide?" Why it lands: a builder question to someone with one startup chapter. It invites a story, not an interrogation.

## Sources

- **Provided:** the coach's notes (candidate background and the gap note); your message (the JD highlights, the research note's three priorities and competitive threat, and the interviewer profile line).
- **Research:** three searches were sent, all refused because web search was not permitted in this session. No fetches were sent.
  - "Northwind Data company values" (target 1)
  - "Northwind Data interview process sales strategy" (target 2)
  - "Dan Kovac Northwind Data Director of Sales Strategy" (target 4)

Research tier: L1 — searches 3 of 6 (all refused), fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Northwind Data values | unavailable | Refused. No values cheat sheet, and no values round is detected. |
| 2. Interview process, sales strategy | unavailable | Refused. Loop structure is not established. Persona weights are the generic archetype's. |
| 3. Strategy and recent news | unavailable | No call sent; search was refused for the session. Your research note is undated, so the check it would need could not run. |
| 4. Dan Kovac, Northwind | unavailable | Refused. The interviewer read is from your profile line only. |
| 5. Representative JD | unavailable | No call sent; search was refused for the session. You gave six JD highlights, not the full text. |

## Upgrade menu

- Full JD text → the six highlights become quoted lines, and the coverage table checks against the whole list.
- Permission to run web search, or the Northwind values page pasted → a values cheat sheet and VAL rows drawn from published values.
- The interview-process page or a candidate guide pasted → loop structure, and persona weights per named round.
- Dan's public talks or posts pasted → a deeper interviewer read, and reverse questions on their themes.
- The workbook or query behind F3 → F3 moves from medium to high, and D4 becomes a walkthrough you can point to.
- The sheet or brief behind the ~$400M figure → D1 and D2 move from answer slots to grounded answers, if she can point to how it was counted.
- The recruiter's focus areas or any named deliverable → coverage of any announced case or presentation.

---

Two things would sharpen this pack, and I need them from you:

1. Did the recruiter send focus areas, or name a deliverable such as a case, presentation or take-home for this round?
2. Can you paste the full JD text? Your six highlights cover the requirements, but the full posting lets the pack quote it and check coverage against the whole list.

If useful, I can run a drill with Dan's Data-Driven Prober persona on D1, the $400M counting question.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for Priya to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: northwind_senior-gtm-strategy-lead_interview_pack.md -----
# Interview prep pack: Senior GTM Strategy Lead, Emerging Products, Northwind Data

Round: 60-minute peer conversation with Dan Kovac, Director of Sales Strategy. Dan is Priya's peer, and both report to the same VP. Session mode, first pack. Not a regeneration.

## How to use

- **Personas** describe how a question is asked. **Types** describe what is being scored: **VAL** (behavioral or values), **EXP** (your past work, deep-dived), **JD** (the role's listed requirements), **CO** (company and strategy knowledge), **CASE** (a live problem).
- Guidance is scaffolding for a spoken answer, not a script. Rehearse only what you actually did, in your own words.
- **Answer slots** are instructions for the interview, not questions to answer here. Each one gives the honest branch as well as the stronger one.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" — your message | "9 at a large consumer-tech company in product strategy & ops" — the coach's notes | low | [inferred] | transferability | Your material says product strategy and operations, not go-to-market for a new product line. Words: "I spent 9 years at a large consumer-tech company in product strategy and operations." Answer slot: if you set go-to-market or launch plans for any product, say which and what you decided; if no such step was yours, say so plainly and stay with the product strategy work. |
| F2 | "identify whitespace across land/adopt/expand/renew" — your message | "set annual volume targets with cross-org consensus" — the coach's notes | low | [inferred] | discovery | Target-setting is sizing-adjacent, not whitespace, so the bridge does not stretch it. Answer slot: if you identified where volume was not being reached, say where and how; if you did not, say so and say how you would find it first. |
| F3 | "run independent analysis in SQL and Tableau" — your message | "skilled in SQL/Tableau" — the coach's notes | medium | [grounded] | presentation | Words: "I'm skilled in SQL and Tableau." The quote reaches the tools, not independent analysis, and no artifact has been inspected, so expect a walkthrough. Answer slot: name one analysis you ran yourself, its question and what it changed; if you have none to name, say so and say what you would build first. |
| F4 | "partner-motion design experience required" — your message | "built a partner-level revenue model used in carrier negotiations" — the coach's notes | medium | [grounded] | transferability | Words: "I built a partner-level revenue model that was used in carrier negotiations." That is partner economics, not the design of a partner motion. Answer slot: if you designed any co-sell terms, incentives or program rules, say which and how you decided; if none was yours, say so plainly and stay with the revenue model. |
| F5 | "strong cross-functional influence" — your message | "set annual volume targets with cross-org consensus" — the coach's notes | medium | [grounded] | presentation | Words: "I set annual volume targets with cross-org consensus." Reworded from the quote only. Answer slot: if you led the consensus, say how; if others did, say which part was yours. |
| F6 | "AI experience a plus" — your message | "uses AI tools daily" — the coach's notes | low | [inferred] | transferability | Words: "I use AI tools daily." Never AI product experience. Answer slot: name what you use them for. |
| F7 | No JD line. Raised by the interviewer's own function (sales strategy). | "No classic sales-ops or quota-setting experience" — the coach's notes | none | [grounded] | capability | The absence is stated, so the words come from it: "I haven't set quotas or run sales operations." Confirm this line in your own words before you say it. Then say how you would learn it, as a plan, never as a past. |
| F8 | No JD line. The figure a probe reaches first. | "proposed a store-surface change credited with a ~$400M ARR uplift" — the coach's notes | medium | [grounded] | discovery | Words: "I proposed a store-surface change that was credited with a ~$400M ARR uplift." The material does not show how the figure was counted or split, so the rest is answer slots (D1, D2). |

Read the gap column this way: presentation means your quote already reaches the requirement in other terms. Transferability means adjacent work that does not reach it. Discovery means the material is silent. Capability means you stated the absence yourself.

## Prohibited claims

Not coached in any answer, hold or rationale in this pack.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned go-to-market for a product line | Inflated form of F1 | F1's quote at its own scope. The limit is this pack's observation, not words for you: your material says product strategy and operations. |
| "I drove the ~$400M ARR uplift" | Inflated form of F8's quote | "I proposed a store-surface change that was credited with a ~$400M ARR uplift." |
| "I designed partner programs" or "I designed co-sell motions" | Inflated form of F4 | F4's quote at its own scope. |
| AI product experience | Inflated form of F6 | "I use AI tools daily." |
| Expert in SQL | Inflated form of F3 | "I'm skilled in SQL and Tableau." |
| "I have set quotas or run sales operations" | Negative stated in the coach's notes (F7) | Plain acknowledgment: "I haven't set quotas or run sales operations." No slot on this. |

## Reading the interviewer

Built from your profile line only. No public footprint was checked, because the search was refused.

- **Career pattern:** pricing and monetization roles, with one early-stage-startup chapter (your message).
- **Self-described style:** "relentlessly data-driven" (your message).
- **Practical implications:**
  1. Expect every metric to be probed back to its assumptions. D1 to D5 carry the weight.
  2. Case questions tilt toward pricing, packaging and unit economics. That is Dan's native language. See C1 and C3.
  3. The startup chapter means builder stories land well, and scrappiness probes are likely. See V2 and P3.
  4. Mirror opportunities: none offered. The material shows no shared professional path. Shared identity is not a strategy here.

## Persona table

Relationship priors for a peer round are Peer Evaluator and Data-Driven Prober. Interviewer signals push Prober up. No loop source was found, so the loop is not established. The pack uses the generic archetype's flat weights, and says so.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy | Questions |
|---|---|---|---|---|
| Data-Driven Prober | Asks for denominators, counting methods and the assumption behind each figure | High. The interviewer describes themselves as "relentlessly data-driven," and the $400M figure is the most visible number on the background. | Know what you can and cannot say about how each figure was counted. Name the weakest assumption before they do. Say plainly when you do not know. | D1 to D5 |
| Peer Evaluator | Seam-splitting between teams, credit-sharing, "what would you need from me" | High. Peer rounds are priced on what the hire adds to the peer's load. | Reciprocity: what you bring their team, not only what you need. Propose seam principles rather than pretending to know the seam. | P1 to P4 |
| Case / Strategist | Live problems: bundling, whitespace, metric diagnosis | Medium to high. The research note names a competitive threat, and the pricing spine raises case weight. | Clarify, then objective, segmentation, approach, metrics, risks. Think aloud. | C1 to C4 |
| Skeptic | The sales-ops gap, "why this role" | Medium. The sales-ops gap is the obvious probe for a sales-strategy peer. | Hold the plain acknowledgment, then a plan. Never bluff a competency the interviewer owns. | S1 to S3 |
| Pressure / Stress | Time-boxed challenges, "how much was actually you" | Low to medium. Peer rounds rarely stress-test, but the $400M figure invites it. | Pause. Restate. Hold through two follow-ups before conceding anything real. | X1, X2 |
| Conversational / Rapport | Opening arc, casual check on the JD's plus items | Low to medium. Casual questions are still scored. | A 90-second arc. Treat casual questions about SQL and AI as scored. | K1, K2 |
| Values / Behavioral | Influence and customer-first prompts | Low. No values-style round is detected, because no loop source establishes one. Kept at two questions so the persona is touched. | Open prompts with an honest branch when no story comes to mind. | V1, V2 |

## Question banks

Coverage rule: every JD highlight has at least one JD-tagged question (see the coverage table below). The Prober and Peer banks rest on the candidate's own quoted sentences.

### Peer Evaluator (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Our two teams sit side by side on new products. Where's the seam between a GTM plan for a new product line and the sales-strategy work we already run, and what happens when we disagree about it?" | JD | [generic] | Propose seam principles, not a seam you have not seen: who owns the plan, who owns the number, how a disagreement gets settled by data both sides accept. Say what you would ask first. Do not claim to know this team's seam. | Peer probe on the first JD line, "own GTM strategy for two new product lines." It is collegial, and it scores whether you would add to Dan's load. The guidance makes no claim about your past. |
| P2 | "How do you handle credit when work spans teams?" | VAL | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" — the coach's notes | Name who did what, in the order it happened. Your sentence says you proposed the change and the uplift was credited with it. Do not say you drove the uplift. Say what your part was and what was not. | F8 is the sentence a credit probe will test. Peers ask this to see how you split work. |
| P3 | "When you and a peer disagree on a plan, what happens next?" | VAL | [generic] | Selection scaffold: pick a disagreement with a peer where you had to move a number to settle it. It needs a named stake and a result you can state. If no such time comes to mind, say so plainly, then give how you would handle it. The material carries no such story, so do not invent one. | Persona stem, and it tests the disagreement style the peer prior names. Startup-chapter builders are scored on this. |
| P4 | "The JD asks for partner-motion design. If you were designing one here, what would you need to know first?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" — the coach's notes | Start with the economics you can speak to: the partner-level revenue model, its inputs and the negotiation it was used in. Answer slot: if you designed any co-sell terms, incentives or program rules, say which and how you decided; if none was yours, say so plainly and return to the revenue model. | F4 is the required skill with the widest gap. The question is a case, but its guidance draws on your one quoted partner sentence. |

### Data-Driven Prober (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how the ~$400M figure was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" — the coach's notes | Four answer slots, each in your own words: how it was counted; what it is sensitive to; the assumption you would defend least; which part was yours. If you did this, say how. If there was no such step, or it was not yours, say so plainly and return to "I proposed a store-surface change." Do not name a method the material never gives you. | F8 is the figure a prober reaches first. Attribution is the test. |
| D2 | "Which assumption behind that number would you defend least?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" — the coach's notes | Weakest-assumption move: name it before Dan does, which turns a gotcha into a credibility gain. Answer slot: name the assumption you would defend least, in your own words. If you have not identified one, say so and say what you would check first. | The most likely follow-up to D1. Naming the weak point yourself is worth more than defending the whole figure. |
| D3 | "The partner-level revenue model: what were its inputs, and which of them did you set?" | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" — the coach's notes | Keep to "built" and "used in carrier negotiations." Answer slots: name the inputs you can speak to; say which you set and which you were given; if you do not know how a given input was sourced, say so. | F4's evidence is the one artifact-like claim on the partner side, so it will be probed for inputs. |
| D4 | "Which SQL or Tableau analysis would you walk me through end to end?" | EXP | [grounded] "skilled in SQL/Tableau" — the coach's notes | Say the tools in the quote's terms. Answer slot: name one analysis you ran yourself, its question, its data source and what it changed. If you have none to name, say so, and say what you would build first. | F3 is a presentation gap. Dan will want a walkthrough of independent work, which is what the JD asks for. |
| D5 | "How did you set annual volume targets, and what did the cross-org consensus rest on?" | EXP | [grounded] "set annual volume targets with cross-org consensus" — the coach's notes | Answer slots: the method, which the material does not give; what the consensus rested on; who disagreed. If someone else set the targets and you contributed, say which part was yours. | D5 is the closest thing you have to quota-setting, so expect Dan to press it. F5 and F7 meet here. |

### Case / Strategist (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A much larger platform vendor bundles a similar capability into its suite next quarter. Where do you start, and what do you need to know first?" | CASE | [grounded] "main competitive threat is bundling by a much larger platform vendor" — your message (the research note) | Clarify, then objective, segmentation, approach, metrics, risks. Name the bundle's likely effect on price and renewal. Use the vocabulary of pricing and packaging. The note's threat is not verified externally. | The competitive threat comes from your research note, so it is the case the company most likely cares about. The pricing tilt follows from the interviewer read. |
| C2 | "Northwind is pursuing enterprise expansion, an AI copilot launch and profitability. Which one would your GTM plan serve first, and what does it give up?" | CO | [grounded] "enterprise expansion", "an AI copilot launch ('Compass')", "reaching profitability" — your message (the research note) | Pick one. Say the trade-off in pricing or coverage. Do not claim knowledge of internal priorities. The three priorities come from your note, which is not verified. | CO question built from the three stated priorities. It is the differentiator a candidate who did only the public homework cannot answer. |
| C3 | "Where would you look for whitespace across land, adopt, expand and renew for one of the new product lines?" | JD | [generic] | Structure: the four motions, the data each needs (SQL is the tool), and which segment looks largest. Say what you would check first. It makes no claim about your past. | JD line 2, "identify whitespace across land/adopt/expand/renew." F2 is a discovery gap, so the answer is method, not a claimed result. |
| C4 | "Compass is the AI copilot launch. What would you measure in its first two quarters from a GTM view?" | JD | [grounded] "an AI copilot launch ('Compass')" — your message (the research note); [grounded] "uses AI tools daily" — the coach's notes | Name the metrics that tie to adoption and expansion, and state the weakest of them. If asked about your AI work, say what you use the tools for. You use AI tools; you have not built AI products. | JD line on AI, "AI experience a plus," with a launch the company is actually running. F6 is low confidence, so the answer stays on use, not building. |

### Skeptic (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| S1 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "No classic sales-ops or quota-setting experience" — the coach's notes | Hold the plain acknowledgment: "I haven't set quotas or run sales operations." Then one plan: how you would learn it. Then one adjacent piece you can state: "I set annual volume targets with cross-org consensus." Add nothing to make the gap feel smaller. | F7's capability gap, asked as a day-one question. Answering it directly is the cheapest credibility you will get in the round. |
| S2 | "I don't see sales-ops or quota work in your background. How would you handle that in this role?" | JD | [grounded] "No classic sales-ops or quota-setting experience" — the coach's notes; [grounded] "set annual volume targets with cross-org consensus" — the coach's notes | **Deepest rehearsal in the pack.** Hold 1: "I haven't set quotas or run sales operations." Hold 2, if pressed on how: the ramp plan, meaning how you would learn it and with whom, as a plan and never as a past. Hold 3, if pressed on whether it matters: "The nearest thing I've done is setting annual volume targets with cross-org consensus. I wouldn't call that quota work." Concede specifically what you could not do on day one. Never fold on "I haven't." | The highest-ROI prep. Dan runs sales strategy, which is quota's neighbourhood, so this objection is near-certain in some form. The honest answer changes the round. Confirm the negative in your own words first, because the pack depends on it. |
| S3 | "What draws you to owning go-to-market for new products, rather than the product strategy work you've done?" | VAL | [grounded] "9 at a large consumer-tech company in product strategy & ops" — the coach's notes | Selection scaffold: your notes do not state a motivation, so pick one you can stand behind from the JD's own line about owning GTM for two new product lines, and name the cost you accept. If the reason is not yet clear to you, say so and say what you would need to know. | The "why now" probe. Motivation is not in your material, so the guidance supplies a selection method, not a reason. |

### Pressure / Stress (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| X1 | "Sixty seconds: why you over an internal candidate?" | JD | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" — the coach's notes; [grounded] "built a partner-level revenue model used in carrier negotiations" — the coach's notes | Pause, then restate. Anchor on the two quoted facts: the consulting and product-strategy background, and the partner revenue model. Hold through two follow-ups. Concede specifically: you do not know the internal candidate's record, and you have not set quotas. | Pressure stem on the hire decision. The hold is what the quotes carry, and the concession is the plain acknowledgment. |
| X2 | "That result: how much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" — the coach's notes | Hold 1: "I proposed it, and it was credited with the uplift." Hold 2: say which part of the counting you cannot speak to. Concede that specifically. Do not fold on the proposal. | Hold-then-concede on the most-quoted figure. Holding the one thing you can back is the point. |

### Conversational / Rapport (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| K1 | "So, walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" — the coach's notes | A 90-second arc with only the beats the sentence states: consulting, then the consumer-tech product-strategy and operations years, then the next step in your own words. | The rapport opener is scored for economy and interest. The arc does not add roles or outcomes. |
| K2 | "What are you actually playing with in SQL or AI these days?" | JD | [grounded] "skilled in SQL/Tableau" — the coach's notes; [grounded] "uses AI tools daily" — the coach's notes | Name one recent SQL or Tableau example, and one AI tool and what you use it for. If you cannot name a recent example, say so. | Casual wording of two JD items, scored as a question. Keep it concrete. |

### Values / Behavioral (weight 2)

No published values were read. The round is not detected as values-style.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V1 | "Tell me about a time you had to influence a team that didn't report to you." | VAL | [grounded] "set annual volume targets with cross-org consensus" — the coach's notes | Open prompt on the JD line "strong cross-functional influence" (your message). Selection scaffold: pick a time you moved people outside your line to a decision, name the stake, and say what was yours. If none comes to mind, say so plainly, then give the consensus on annual volume targets, with only the words you can back: who was in the room, in your own words. | F5. Open prompts take a story from a quote, or an honest "none." |
| V2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: a decision where a customer outcome cost an internal number. If none comes to mind, say so plainly. Your material carries no such story, so do not supply one. | Persona stem for the Values persona. Kept at two questions because it is plausible, not because a values round was detected. |

### Requirement coverage

| Requirement (source) | Covered by |
|---|---|
| "own GTM strategy for two new product lines" (your message) | P1, C2 |
| "identify whitespace across land/adopt/expand/renew" (your message) | C3 |
| "run independent analysis in SQL and Tableau" (your message) | D4, K2 |
| "partner-motion design experience required" (your message) | P4, D3 |
| "strong cross-functional influence" (your message) | V1, D5 |
| "AI experience a plus" (your message) | C4, K2 |
| No JD line: sales-ops and quota experience, raised by the interviewer's function | S1, S2 |

Session total: 22 questions (P 4, D 5, C 4, S 3, X 2, K 2, V 2).

## Reverse questions

Six, each with why it lands.

1. "You came to sales strategy from pricing and monetization. What from that work would you want carried into how a new product line gets priced?" Why it lands: it ties to Dan's own path, which turns the interview into peer talk and shows you researched them.
2. "What could a new person do in their first month that would genuinely help your team?" Why it lands: the peer reciprocity question. It signals you are thinking about what you bring, not only what you need.
3. "Which of the three priorities (enterprise expansion, the AI copilot launch, reaching profitability) is the GTM plan most likely to be judged on this year?" Why it lands: it uses your research note. Check the priorities before you say them, since the note is not verified.
4. "Where do the sales-strategy and product teams split ownership of pricing for a new line?" Why it lands: a seam question, asked from the other side.
5. "How does a partner-motion decision get made here, and who has the final word?" Why it lands: it follows the JD's required partner line, and asks how the decision is made.
6. "What did the startup chapter teach you that a larger company's process tends to hide?" Why it lands: a builder question to someone with one startup chapter. It invites a story, not an interrogation.

## Prep time

Not stated, so no prep triage.

## Sources

- **Provided:** the coach's notes (candidate background and the coach's gap note); your message (the JD highlights, the research note's three priorities and competitive threat, and the interviewer profile line).
- **Research:** three searches were sent. All three were refused, because web search was not permitted in this session. No fetches were sent.
  - "Northwind Data company values" (target 1)
  - "Northwind Data interview process sales strategy" (target 2)
  - "Dan Kovac Northwind Data Director of Sales Strategy" (target 4)

Research tier: L1 — searches 3 of 6 (all refused), fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Northwind Data values | unavailable | Refused. No values cheat sheet, because no published values were read, and no values round is detected. |
| 2. Interview process, sales strategy | unavailable | Refused. Loop structure is not established. Persona weights are the generic archetype's. |
| 3. Strategy and recent news | unavailable | No call sent; the host refused search. Your research note is undated, so the quick check it would need could not run. The CO questions use the note as provided. |
| 4. Dan Kovac, Northwind | unavailable | Refused. The interviewer read is from your profile line only. A public footprint would sharpen the reverse questions. |
| 5. Representative JD | unavailable | No call sent; the host refused search. You gave six JD highlights, not the full text, so the fit snapshot rests on those six. |

## Upgrade menu

- Full JD text → the six highlights become quoted lines, and the coverage table checks against the whole list.
- Permission to run web search, or the Northwind values page pasted → a values cheat sheet and VAL rows drawn from published values.
- The interview-process page or a candidate guide pasted → loop structure, and persona weights per named round.
- Dan's public talks or posts pasted → a deeper interviewer read, and reverse questions on their themes.
- The workbook or query behind F3 → F3 moves from medium to high, and D4 becomes a walkthrough you can point to.
- The sheet or brief behind the ~$400M figure → D1 and D2 move from answer slots to grounded answers, if you can point to how it was counted.
- The recruiter's focus areas or any named deliverable → coverage of any announced case or presentation.
