Your prep pack is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-tuesday-part-2-rooms-case-2-denied-78f895a0/e7172e79-2ab2-4f3a-ac9c-81dca3b9f178/scratchpad/atlas-freight_operations-manager_interview_pack.md`. I built it for a hiring-manager round, since your note didn't say who you're meeting. I could not research Atlas Freight: the two web searches were refused by the session's permission setting, so nothing in the pack about their values, interview process or strategy is verified.

**The three things to get ready for:**

1. **Scale.** The JD asks for four sites and twelve supervisors. You have one site's peak plan and three supervisors. The interviewer will almost certainly press this. Concede the gap in one sentence, then give a 90-day ramp as a plan, not a past. Don't say "I led four sites" or "I led twelve."
2. **The 40%.** It's a mis-pick rate, not on-time or cost-per-shipment. Expect "how was that counted?" and "how much was actually you?" If you don't know the baseline or method, say so.
3. **Power BI and the 5-year gate.** Say "I haven't used Power BI" and give a learning plan. Your material doesn't show how many years you've held a leadership role, so be ready to state that number.

The pack has 18 questions, a fit snapshot, the claims I won't coach you to make, and the answer slots for each probe.

**Two questions to answer before the interview:**
- Who are you meeting, and did the recruiter say what the round will cover?
- How many years have you led people in operations, and what's the largest group you've led?

Reply to either and I'll regenerate the affected sections. If you tell me how many days you have, I'll also turn the pack into a ranked prep schedule.

Offers, both optional:
- I can run a live drill on the scale question (A1), where I play the interviewer and give feedback against the pack's guidance.
- I can save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions.

I can also convert the pack to Word if you'd like.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: atlas-freight_operations-manager_interview_pack.md -----
# Interview prep pack: Operations Manager, Atlas Freight

Interviewer: not named. Round type: not stated. Built for a **hiring-manager round** (assumed, see the note in section 8). First version, so no changelog.

## 1. How to use this pack

- **Personas** describe how a question is asked. **Types** describe what is being scored.
- Type key (only the types this pack uses):
  - **JD**: can you do the listed job, including its gaps.
  - **EXP**: do your claims hold up when someone digs into them.
  - **CASE**: a live problem from the role, solved out loud.
  - **VAL** and **CO** are not used. No values round was detected and no company research ran (see section 14).
- Guidance is scaffolding, not a script. Say it in your own words. Each guidance cell is written to be spoken in 90 to 120 seconds.

## 2. Prep triage

Skipped: your prep time is not stated. Reply with how many days you have and I will turn this into a ranked schedule (upgrade menu).

## 3. Fit snapshot

Your inputs are your message and the JD text you pasted. There is no CV, so every evidence quote below comes from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" (JD) | "currently a senior shift manager over 3 supervisors" (your message); "ran the site's peak-season surge plan two years running" (your message) | medium | [grounded] | transferability | Your material shows daily shift leadership and one site's peak plan. It does not show operations across more than one site. Bridge stays at the quotes: "I'm a senior shift manager over three supervisors, and I ran the site's peak-season surge plan two years running." Answer slot: if you have overseen operations across more than one site, say which and how; if you have not, say so plainly and say how you would take on four. |
| F2 | "drive on-time performance and cost-per-shipment down" (JD) | "cut mis-pick rate 40% by redesigning the pick path" (your message) | medium | [grounded] | transferability | The result you have is an accuracy measure, not on-time performance or cost per shipment. Bridge: "I cut mis-pick rate 40% by redesigning the pick path." Answer slot: if the pick-path change moved on-time or cost figures, say which and how you know; if you did not measure them, say so and say what you would track first. |
| F3 | "lead a team of 12 supervisors" (JD) | "currently a senior shift manager over 3 supervisors" (your message) | medium | [grounded] | transferability | Leading supervisors is in your material; leading twelve is not. Bridge: "I lead three supervisors now." Answer slot: say the largest group you have led and how you ran it; if it has been three, say so and say how you would build to twelve. |
| F4 | "build reporting in Excel/Power BI" (JD), Excel half | "solid Excel, never used Power BI" (your message) | medium | [grounded] | transferability | Your material shows Excel skill, not reporting you built in it. Bridge: "I'm solid in Excel." Answer slot: what you have built in Excel, for whom, and how you checked it; if you have built none, say so. |
| F5 | "build reporting in Excel/Power BI" (JD), Power BI half | "solid Excel, never used Power BI" (your message) | high | [grounded] | capability | You stated the absence. Words: "I haven't used Power BI." Then how you would learn it, said as a plan, never as a past. No claim to dashboards or Power BI work. |
| F6 | "5+ years operations leadership required" (JD) | "7 years in warehouse and distribution ops" (your message); "currently a senior shift manager over 3 supervisors" (your message) | low | [grounded] | hard_gate | Your material shows seven years in operations work. It does not show how many years were in a leadership role, so the gate is not established. Surfaced here, not bridged. The one question for it is in the message that presents this pack. |
| F7 | "Lean/Six Sigma a plus" (JD) | "green belt certified" (your message) | high | [grounded] | none | Quote reaches the requirement. Bridge: "I'm a green belt." Expect a probe on where you applied it; the answer is your own project, in your own words. |

Reading the table: the two medium-confidence rows that matter most are F1 and F3, because they are the scale gaps. F6 is the gate. F5 is the one gap you stated yourself.

## 4. Prohibited claims

These are the claims this pack will not coach. Each one would stretch a quote you actually gave.

| Not coached | Basis | Honest form |
|---|---|---|
| Runs four sites, or owns terminal operations across sites | Inflated form of F1 | "I'm a senior shift manager over three supervisors, and I ran the site's peak-season surge plan two years running." Limit, as the pack's own observation: your material shows one site. |
| Led twelve supervisors, or led teams at scale | Inflated form of F3 | "I lead three supervisors now." |
| Drove on-time performance or cost-per-shipment | Inflated form of F2 | "I cut mis-pick rate 40% by redesigning the pick path." Limit, as the pack's observation: your material names an accuracy measure. |
| Designed the peak-season plan | Inflated form of F1 (your quote says "ran") | "I ran the site's peak-season surge plan two years running." |
| Built Power BI reports, or any Power BI work | Negative you stated, F5 | "I haven't used Power BI." No slot. |
| Five or more years in operations leadership | Gate not established, F6 | "Seven years in warehouse and distribution operations, and currently a senior shift manager." Years in a leadership role are not asserted until you say them. |
| A counting method or accuracy claim for the 40% | Silence in your material, F2 | Nothing is asserted about how it was counted. The answer slots in C1 to C3 carry it. |

## 5. Persona table

Round type and interviewer are unknown, so weights use the hiring-manager prior. The JD and your message then move them. Depth follows weight: top persona 5 questions, mid 4 and 3, low 2.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (A) | Presses the scale gaps: sites, span, Power BI. "Why you, at this size?" | Highest. The gaps are large and visible on one page: three supervisors against twelve, one site against four, and no Power BI. A hiring manager is buying derisked capability. | Rehearse the span objection until it is boring. Concede the gap in one sentence, then move to the ramp plan. |
| Case / Strategist (B) | Live problems from the role: on-time drop, cost per shipment, peak season | High. Hiring-manager prior, and the JD names on-time and cost as the job. | Clarify, then objective, segmentation, approach, metrics, risks. Think aloud. |
| Data-Driven Prober (C) | Asks how the 40% was counted and which assumption you would defend least | Medium-high. A headline number with no method behind it is a magnet for probes. | Say what you know about the count and say plainly when you do not. Name the weakest assumption before they do. |
| Pressure (D) | Time-boxed challenge on fit, the 40%, and Power BI | Medium. Round type unknown; a hiring manager may still test composure on the scale question. | Pause, restate, hold through two follow-ups, then concede only the specific point. |
| Conversational (E) | A friendly opener and a casual question about Lean | Low. Typical of recruiter screens; less typical for a hiring manager, but still scored. | A 90-second arc from your quotes. Treat the casual Lean question as scored. |

**Note.** These weights are flat because the round type is unknown. If the round is a peer panel or a skip-level, the table reweights (answer in section 8).

## 6. Question banks

### Skeptic (weight 5): highest-ROI prep

**The highest-ROI rehearsal in this pack is A1.** It will come in some form because the JD's scale and your message's scale do not match.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "This role leads twelve supervisors across four sites. Your current span is three supervisors. What would you do in the first ninety days to close that?" | JD | [grounded] "currently a senior shift manager over 3 supervisors"; JD: "lead a team of 12 supervisors" | Hold: "I lead three supervisors now." Then the ramp, as a plan: what you would learn about the four sites first, how you would structure supervisor reviews, what you would hand off. Answer slot: if you have led more people or sites than the quote shows, say so; if not, say so plainly and give the ramp. Hold through two follow-ups by returning to the ramp. | F3 and F1 are the gaps. This is the question the JD sets up. It is the deepest rehearsal in the pack. |
| A2 | "Your 40% is an accuracy measure. This role is judged on on-time performance and cost per shipment. Why should I expect you to move those?" | JD | [grounded] "cut mis-pick rate 40% by redesigning the pick path"; JD: "drive on-time performance and cost-per-shipment down" | Concede that the 40% is accuracy, not on-time or cost. Then answer slot: if the change moved on-time or cost figures, say which and how you know; if you did not measure them, say so and say what you would track first. Do not claim the link. | F2 is a transferability gap, so the honest answer is the concession plus a measurement plan. |
| A3 | "You arrive with four sites reporting to you. What do you need to know in the first thirty days before you change anything?" | CASE | [generic] | Structure: what you would look at first (sites, supervisors, the reports), who you would talk to, what you would change last. This is a live problem, so the guidance makes no claim about your past. | Covers the four-site scope as a decision, not a record. |
| A4 | "The role builds reporting in Excel and Power BI. Which of those can you do today, and how would you close the other?" | JD | [grounded] "solid Excel, never used Power BI" | Excel: "I'm solid in Excel." Power BI: "I haven't used Power BI." Then the learning plan as a plan. Answer slot: what you have built in Excel and for whom; if none, say so. | F4 and F5. The stated absence is answered with a plan, not with a past. |
| A5 | "If this goes badly at month six, what is the most likely reason?" | EXP | [generic] | Pick one real limit from your material: scale, Power BI, or multi-site work. Name it, say what you would do, and say when you would know it is working. This is a self-assessment question, so it needs no claim about your past. | Skeptics test whether candidates can name their own risk. A specific, honest limit scores better than a generic one. |

### Case / Strategist (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "On-time performance at one terminal dropped five points in a month. Where do you start?" | CASE | [generic] | Clarify (what changed, what the baseline was), then objective, then segmentation (shift, lane, dock, carrier), then metrics, then risks. Think aloud and name one assumption. | The JD names on-time as the job, so the case is the job. |
| B2 | "Cost per shipment is up and volume is flat across the network. Diagnose it." | CASE | [generic] | Clarify the cost definition first, then split cost into labour, transport and rework, and test each. Name the metric you would trust least. | Cost per shipment is in the JD. |
| B3 | "Peak arrives in six weeks at a site with a labour shortfall. What is your plan?" | CASE | [grounded] "ran the site's peak-season surge plan two years running" | Start from the plan's purpose: what it has to cover, and what can slip. Where you have run a surge plan before, say what it covered in your own words, using the quote's own scope. If the detail is not something you can describe, say so and give the approach. | The peak plan is your strongest operations evidence. Use it as a precedent, not a template. |
| B4 | "Your first ninety days. What do you fix first, and what do you leave alone?" | CASE | [generic] | Order by risk to on-time and cost, then by what the team can absorb. Name one thing you would leave alone and why. | Tests prioritisation at the level of the JD. |

### Data-Driven Prober (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You cut mis-pick rate 40%. Walk me through how that number was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Say what you know about the count in your own words. Answer slot: if you know the baseline, the period and the source, say them; if you do not, say so plainly. Never supply a method. | Headline number. The honest answer is the count you actually know. |
| C2 | "Which assumption behind that 40% would you defend least?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Name the weakest assumption before they do: for example, that the baseline period was typical. Only name an assumption you know was made. Answer slot: if you do not know of one, say so. | Weakest-assumption move. |
| C3 | "Of that 40%, which part was yours to decide and which was the team's?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Attribution: which decision was yours, which was shared, and who else worked the change. Use "I" for what you decided and "we" for the team's work. | Attribution honesty is what a prober scores. |
| C4 | "How do you check a spreadsheet before people act on its numbers?" | EXP | [grounded] "solid Excel" (your message); JD: "build reporting in Excel/Power BI" | Open prompt. Say what you actually do to check a workbook. If the answer is nothing formal, say so and say what you would add. | Tests the Excel claim without assuming you built reports. |

### Pressure (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why should we hire you for this role over a candidate who has already run four sites?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" | Pause. Restate the question in your words. Hold the position you can defend: what you have done at a smaller scale and how it transfers. Hold through two follow-ups. Concede only the specific gap (sites, span) in one sentence. | Composure test on the scale gap. |
| D2 | "That 40%: how much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Hold: say what you led and what you decided. Concede what was shared. Do not add to the claim under pressure. | Attribution under pressure. |
| D3 | "You've told me Power BI isn't in your toolkit. Why shouldn't I expect that to cost us a quarter?" | JD | [grounded] "never used Power BI" (your message) | Hold: "I haven't used Power BI." Then the plan and its timing. Concede the risk in one sentence rather than defending a timeline you have not tested. | Stated absence under pressure. |

### Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey to here." | EXP | [grounded] "7 years in warehouse and distribution ops" (your message); "currently a senior shift manager over 3 supervisors" (your message) | A 90-second arc from those two quotes and nothing more. Start with the seven years, then the shift role, then why this role. | Biography is scored even when casual. |
| E2 | "You're a green belt. What does that look like in your day-to-day?" | JD | [grounded] "green belt certified" (your message) | Say what you actually do with the method. Answer slot: if the green belt was a project, name the project and your part in it; if it is a credential you have not used much, say so. | JD plus; asked casually, scored anyway. |

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| Own daily terminal operations across 4 sites | A1, A3, B3 |
| Drive on-time performance and cost-per-shipment down | A2, B1, B2, B4 |
| Lead a team of 12 supervisors | A1, D1 |
| Build reporting in Excel/Power BI | A4, C4, D3 |
| 5+ years operations leadership required | None, and why: this is a gate. It is asked in the message that presents this pack, and it is not bridged, so it gets no bank question. |
| Lean/Six Sigma a plus | E2 |

## 7. Reverse questions

Each of these is worth asking because it shows you prepared. None is generic.

1. **"What does the first ninety days look like for whoever takes this role, and what would success look like at day 90?"** Why it lands: it turns the scale question into a shared plan and gives you the hiring manager's own definition of success.
2. **"Which of the four sites is furthest from its on-time target right now, and what is the main reason?"** Why it lands: it shows you already think in on-time terms, and the answer tells you where the first week goes.
3. **"How is cost per shipment defined and reviewed today?"** Why it lands: it is the definition question a prober would ask, and it tells you whether the metric is trusted.
4. **"What reporting exists today, and what would the team want Power BI to replace?"** Why it lands: it surfaces the reporting gap and turns it into a question about their need, not your deficit.
5. **"How is the supervisor team organised across the four sites, and who has direct reports?"** Why it lands: it tests your span gap from their side and tells you whether the twelve is a set of teams or one team.

## 8. Notes on this pack

- **Round type unknown.** The pack assumes a hiring-manager round, because that is the usual shape for this role. If you are meeting a peer, a skip-level or a panel, the persona weights and the reverse questions change, and the pack needs to be rebuilt for that round.
- **Interviewer unknown.** There is no interviewer read. Once you have a name, I can read their public footprint and tune the reverse questions.
- **No company research.** The two web searches I ran for values and the interview process were refused by the host's permission setting. Nothing about Atlas Freight's values, loop, or strategy is in this pack, and none of it is from memory.

## 9. Sources

- **Provided documents:** the JD text and the background paragraph in your message. Nothing else.
- **Research tier: L1, searches 0 of 6, fetches 0 of 2.** Both searches were refused by the host, so the target accounting below records them as refused.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Atlas Freight values | unavailable (query "Atlas Freight regional logistics company values" refused) | Values cheat sheet (section 10 of the template). Not included because no values-style round was detected. |
| 2. Atlas Freight interview process, operations manager | unavailable (query "Atlas Freight interview process operations manager" refused) | Loop structure. Without it, the loop falls back to the generic archetype, so persona weights are flat and said so in section 5. |
| 3. Atlas Freight strategy / recent news | unavailable (not sent, the host's search was refused) | Would have fed CO questions. None are in the pack. |
| 4. Interviewer name and company | n/a | No name was given, so there was no query to form. |
| 5. Representative operations manager JD | skipped | The JD you pasted fixes the fit snapshot and the JD-tagged questions. |

Loop: no loop source established it, so the fallback is the generic archetype. No values-style round is detected under that archetype.

## 10. Upgrade menu

- **Round type and who you are meeting** → persona weights for the real round, and reverse questions aimed at that person.
- **Years of leadership in operations, and the largest group you have led** → resolves the gate in F6, and tells us whether the span gap is real in your history or only in the JD.
- **Recruiter's note on focus areas or any exercise** → coverage check against what they will grade, and a graded-deliverable section if one is announced.
- **Interviewer's name** → interviewer read and a tailored reverse question.
- **Your CV, if you have one** → evidence quotes from the CV in place of the message, which would move F1 to F4 toward grounded and give the bank more to draw on.
- **Days you have to prepare** → a ranked prep schedule (section 2).
- **Atlas Freight's values page or a description of the interview process, pasted as text** → values cheat sheet and loop structure, without needing web search.
- **Web search, if the host allows it later** → L1 company research (values, loop, strategy).
