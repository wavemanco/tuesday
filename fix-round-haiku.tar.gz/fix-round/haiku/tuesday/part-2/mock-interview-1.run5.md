Your prep pack is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-tuesday-part-2-rooms-case-1-denied-17ddc327/01e1c59c-31ca-4502-afab-dae417de151c/scratchpad/northwind-data_senior-gtm-lead_interview_pack.md`. I built it as a peer round, since Dan is the same level as Priya.

It has 19 questions across six personas. The Peer Evaluator and Data-Driven Prober get the most weight, because the profile and the peer relationship point there. Each question has its type, provenance, answer guidance, and rationale.

Three things to know before she rehearses:

- **Web search was refused**, so there's no values page, no interview-process data, and nothing on Dan's public footprint. The values section is dropped, and the persona weights rest on the peer prior alone. If you can grant search, I'll run those three lookups.
- **Everything rests on your notes, not Priya's words.** No CV text or message from her was supplied, so each quote is labelled as coming from your notes. She should confirm them in her own words before rehearsing them as her story.
- **The JD is highlights only.** The mid-list requirements may be missing; sending the full text would firm up the coverage table.

The highest-ROI prep is D1, the partner-motion question. The required partner-motion line is the biggest gap between her notes and the JD, and the notes show a revenue model used in negotiations, not a motion she designed.

Would you like me to play Dan as the Data-Driven Prober on B1, the $400M defend-the-number question? Or should I save a `tuesday-dossier.md` recording the gaps this prep exposed? I can also convert the pack to Word if you want it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: northwind-data_senior-gtm-lead_interview_pack.md -----
# Interview prep pack: Senior GTM Strategy Lead, Emerging Products, Northwind Data

**Round:** one 60-minute conversation with Dan Kovac, Director of Sales Strategy. Dan is a peer: both report to the same VP.
**Candidate:** Priya
**Built from:** the coach's notes (Priya's background summary, the JD highlights, and the research note on Northwind's priorities and competitive threat). No CV text, no full JD text, no web results (see Sources).

## How to use, and the type key

Personas describe how a question arrives. Types describe what is being scored. Guidance is scaffolding for a spoken answer, not a script.

| Type | Meaning |
|---|---|
| VAL | Behavioral and values: past behavior that shows a published value or a working principle |
| EXP | Experience deep-dive: whether the claims on the record survive scrutiny, and what was actually hers |
| JD | Role and JD: can she do what the JD lists, including its gaps |
| CO | Company and strategy: can she think at Northwind's altitude |
| CASE | Live problem: structure and reasoning on a problem from the role, asked live |

Every question carries one primary type. The rationale says where a second type applies.

## Fit snapshot

Requirements are the JD highlights, quoted. Evidence is the coach's notes, quoted. No row quotes anything from Priya herself, because no CV text or message from her was supplied. Every "coach's notes" quote therefore needs one confirmation from her before she rehearses it as her own.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" (JD highlights) | "proposed a store-surface change credited with a ~$400M ARR uplift" (coach's notes) | medium | [grounded] | transferability | The notes show a proposed change and a credited figure, not GTM ownership of a product line. Words at that scope: "I proposed a store-surface change, and the ~$400M ARR is credited to it." Answer slot: expect a probe on which GTM decisions for a line were hers to set. If any were, she says which and how she decided. If none were, she says so plainly and describes the nearest thing she did. |
| F2 | "identify whitespace across land/adopt/expand/renew" (JD highlights) | "built a partner-level revenue model used in carrier negotiations" (coach's notes) | low | [inferred] | discovery | The notes do not show whitespace work, and the revenue model may or may not reach it. Answer slot: if the model ever sized where revenue was not yet reached, say which and how. If it did not, say so and say how she would find whitespace first. |
| F3 | "run independent analysis in SQL and Tableau" (JD highlights) | "skilled in SQL/Tableau" (coach's notes) | low | [inferred] | discovery | A skill is not an analysis run end to end. No bridge claim. Answer slot: name one analysis she ran herself in SQL or Tableau, from question to answer. If none comes to mind, say so and say what she would run first. |
| F4 | "partner-motion design experience required" (JD highlights) | "built a partner-level revenue model used in carrier negotiations" (coach's notes) | medium | [grounded] | transferability | Adjacent work: a model used in partner negotiations, not a partner motion she designed. Words at scope: "I built a partner-level revenue model, and it was used in carrier negotiations." Answer slot: if she designed how a partner was engaged, she says which parts and how she decided. If she did not, she says so plainly and says what the model was for. |
| F5 | "strong cross-functional influence" (JD highlights) | "set annual volume targets with cross-org consensus" (coach's notes) | medium | [grounded] | presentation | The quote reaches influence in other terms: consensus across orgs. Bridge: say it in those terms only, "I set annual volume targets with cross-org consensus." No added numbers and no added org count. Whether a particular group held out is an answer slot: if one did, how it resolved; if none did, say so. |
| F6 | "AI experience a plus" (JD highlights) | "uses AI tools daily" (coach's notes) | medium | [grounded] | transferability | Tool use at the scope the notes give. Building or deploying AI is not in the notes. Answer slot: if she built or shipped anything that uses a model, she says what and her part in it. If not, she says she uses AI tools daily and names them. |
| F7 | Sales operations and quota-setting (not in the JD highlights; plain prose, no quote) | "No classic sales-ops or quota-setting experience." (coach's notes) | none | [generic] | discovery | The negative comes from the coach's notes, not from Priya, so it cannot be rehearsed as her own absence. Answer slot: if she has set a quota or run sales ops, she says how. If not, she says so plainly and says what she would need to learn first. Confirming the negative in her own words would make this row a capability gap with a plain acknowledgment. |

Gap types follow the routing rule in the evidence conventions. No row is a hard gate, because the JD highlights state no location, travel, or work-authorization term. If the full JD does, send it and the pack adds a gate row.

## Prohibited claims

These are not coached, in any answer, hold, or slot. Each entry names its basis.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned GTM strategy for a product line | Inflated form of F1 | F1's words at scope. The limit is the pack's own observation: the notes say a proposed change, not a line's GTM. |
| The $400M as her result, or as her figure alone | Inflated form of F1's evidence ("credited with" turned into "drove") | The quote at its own scope: "credited with a ~$400M ARR uplift." No first-person negative. |
| Designed a partner motion | Inflated form of F4 | F4's quote at scope. The pack's observation: the notes say a model used in negotiations. |
| Set quotas or ran sales operations | Inflated form of F5 (targets turned into quotas), and F7 | F5's quote at scope. F7's answer slot. No first-person negative, because the negative is the coach's, not hers. |
| Ran independent SQL or Tableau analysis end to end | Inflated form of F3 | F3's answer slot only. |
| Built or shipped AI products | Inflated form of F6 | F6's quote at scope. No claim either way. |

## Question banks

Session total: 19 questions. Weights follow the persona model: top personas get 5, mid-weight personas 3, low-weight personas 2. Quotes in the Provenance column are the coach's notes unless marked otherwise.

### A. Peer Evaluator (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Our teams sit side by side. Where's the seam between sales strategy and GTM strategy for new product lines, and what happens when we disagree?" | JD | [generic] | Answer with a seam principle, not a claim that she knows this seam: which decision belongs to which team, and how a disagreement between equals gets settled. Then give one disagreement she had across a team boundary, in her own words, with "we" for the team and "I" for her part. If none comes to mind, say so plainly, then give the nearest thing her material carries. | This is the peer's first probe on turf and disagreement style. Cross-functional influence is a JD line. The guidance makes no claim about her, so the label stands alone. |
| A2 | "What would you need from my team in the first ninety days, and what would you bring to it?" | JD | [grounded] "set annual volume targets with cross-org consensus" (coach's notes) | Reciprocity first. Name what she needs from his team in concrete terms: data, a forecast, a review cadence. Then name what she brings, using the quoted line in its own words. Say what that involved in her words, and add nothing to it. | Reciprocity is the peer's question. The answer ties her one cross-org story to his team's needs. Rests on F5. |
| A3 | "When work spans our two teams, how do you handle credit?" | VAL | [generic] | Name the people whose work her piece built on, then say which part was hers. Use "we" for the shared result and "I" for her contribution. Do not round her part up to the team's total. | Credit-sharing is the peer's standard probe, and the answer is scored on whether her "we" and "I" split is honest. The VAL tag is the only place a values-style probe appears in this pack. |
| A4 | "Walk me through how the annual volume targets reached consensus. Which groups were involved?" | JD | [grounded] "set annual volume targets with cross-org consensus" (coach's notes) | Story-mapped on F5. The beats the quote states are the targets and the consensus across orgs. She names the groups in her words, and does not name approvers she cannot stand behind. Answer slot: if a group disagreed and it resolved, she says what it was and how. If the consensus came without that, she says so and describes the mechanism she actually used. | The consensus line is the strongest cross-functional evidence in the notes, and the peer will test it for who had standing. EXP sits under this question, because it tests what was hers. |
| A5 | "Partner motions are a big part of this role. Walk me through the partner-level revenue model, and how the carrier negotiations used it." | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" (coach's notes) | Story-mapped on F4. The beats are the model she built and its use in carrier negotiations, both as quoted. Tell the build in her words and how the negotiation used it, without adding who decided. Answer slot on partner-motion design: if any part of how a partner was engaged was hers to set, she says which and how she decided. If not, she says so plainly and returns to what the model did. | Partner-motion design is a required line, and this is the peer's natural follow-up on her partner work. The deeper version of this question is D1. |

### B. Data-Driven Prober (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Walk me through how the $400M figure was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (coach's notes) | The defend-the-number slots, in her words, in this order: how it was counted; what it is sensitive to; which part was hers. The notes say the figure is credited to the change, and say nothing about the method, so she supplies no method. Answer slot: if she knows how it was counted, she says it. If she did not count it, she says so plainly and says what she can attest to. | The prober's favourite target, and this is the attribution test the CV's headline invites. The word "credited" is the notes' scope, and her answer must keep it. |
| B2 | "Which assumption behind that number would you defend least?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (coach's notes) | The weakest-assumption move: she names it before he does, in her own words. The pack names none. If her honest answer to B1 was that she did not count the figure, the honest answer here is that she cannot name the assumption, and she says so. | This is the second-level probe that turns a gotcha into a credibility gain. It is the same figure as B1, so her answers must agree. |
| B3 | "Which analysis in SQL or Tableau have you run yourself, end to end?" | JD | [inferred] "skilled in SQL/Tableau" (coach's notes) | Nothing to coach from the notes. They say skilled, not what she ran. She picks one analysis she ran herself, from question to answer, in her own words. If she cannot name one, she says so, then says what she would run first on one of the two product lines. | "Independent analysis in SQL and Tableau" is a named tool, the mid-list kind of requirement that goes unrehearsed. The low confidence in F3 means the honest answer is one real instance or a plan. |
| B4 | "Which input moved the answer in that revenue model most, and which would you defend least?" | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" (coach's notes) | Name the input the result depended on most, and the one she would defend least, in her words. The notes give no inputs, so the pack supplies none. Answer slot: if she did not track which input drove the result, she says so plainly and says what the negotiation used the model for. | The prober applies the same test to her second quantified piece of work. EXP, because it tests what was hers. |
| B5 | "Which AI tool do you use every day, and for what?" | JD | [grounded] "uses AI tools daily" (coach's notes) | Name the tool and one task it does for her, in her words. Keep it to daily use. The notes say nothing about building or deploying a model, so she claims neither. Answer slot: if she has built or shipped something that uses a model, she says what it was and her part in it. If not, she says she uses AI tools daily and stops there. | The JD's plus-skill is asked casually and still scored. F6 is medium, so the honest answer is the scope of her use. |

### C. Case / Strategist (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Your two new lines need a whitespace view across land, adopt, expand and renew. Where do you start, and what would you count first?" | CASE | [generic] | Structure aloud. Clarify the two lines and what whitespace means at each stage. Set the objective. Segment accounts or use cases. Name the approach, then two or three metrics per stage, then one risk. Challenge one premise respectfully. Make no claim about her past. | This is the JD's whitespace requirement as a live problem. F2 is discovery, so a live structure answers it better than a story would. The label is [generic] because it is a pattern for the problem, not a fact about this employer. |
| C2 | "If a much larger platform vendor bundled a comparable capability into its suite, where would it hit your two lines first, and what would you do in the first thirty days?" | CO | [grounded] "main competitive threat is bundling by a much larger platform vendor" (the coach's research note) | Use the stated threat as the frame, in conditional form. Do not claim that any competitor move has happened. Say which line it reaches first and why. Name the one assumption behind that call. Then give the first thirty days as three actions. | The research note names bundling as the main threat. The conditional form keeps the question inside what the note supports, and the peer's altitude probe lands here. |
| C3 | "Northwind has three stated priorities: enterprise expansion, an AI copilot launch ('Compass'), and reaching profitability. Which one would your two lines be judged on first, and what's the first GTM decision you'd make on each?" | JD | [grounded] "enterprise expansion, an AI copilot launch ('Compass'), and reaching profitability" (the coach's research note) | Pick one priority and defend it in sixty seconds. Name the line it serves, then one first GTM decision per line. Make no claim about Compass's roadmap or timing, and say what would settle it. | This is the only question that tests the JD's "own GTM strategy for two new product lines" directly, so it is the JD-tagged coverage for that line. The CO element is in the priorities, and the CASE element is in the first decisions. |

### D. Skeptic (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Partner-motion design is required for this role. Tell me about a time you designed a partner motion." | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" (coach's notes) | **Highest-ROI prep in this pack.** Story-map from the quote: the model she built and its use in carrier negotiations. The partner-motion part is an answer slot: if she designed how a partner was engaged, she says which parts and how she decided. If not, she says so plainly and says what the model did. Limit to name before he asks: the notes show a model, not a motion. Hold through two follow-ups by returning to the model's scope. Never add a motion to it. Concede exactly what she did not design, then say how she would design one. | This is the required line with the largest distance between the notes and the JD. The open prompt's theme comes from the JD, so the question is lawful. It is the most predictable objection, and F4 is the only row that touches it. |
| D2 | "Your nine years were in consumer tech. What's your experience with enterprise buyers and renewal motions?" | JD | [grounded] "9 at a large consumer-tech company in product strategy & ops" (coach's notes) | Start from the nine years, in her words. Then name any enterprise buyer or renewal she has worked on, and her part in it. If none, she says so plainly and says how she would learn the renewal motion in her first ninety days. She does not answer with consumer metrics as if they were renewal metrics. | "Land, adopt, expand, renew" is a JD line, and the consumer background is the visible gap. The question asks about the gap rather than asserting its absence. |

### E. Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who has already run a partner motion?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations"; "set annual volume targets with cross-org consensus" (coach's notes) | Pause, then restate the question. Hold on the two things the notes carry: the carrier model, and the cross-org targets. Concede the partner gap in one specific sentence, then say how she would close it in ninety days. She does not argue that the other candidate is less qualified. | A composure test. The hold-then-concede structure is for the partner gap, which is the one the material does not cover. |
| E2 | "That result: how much of the $400M was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (coach's notes) | Hold: "I proposed the change, and the figure is credited to it." Then concede exactly what she cannot separate, in her own words. Name the part of the figure she cannot attribute, and say how she would find out. She does not offer a share. Hold through two follow-ups. Do not fold on "proposed". | The stress version of B1. It is a persona-stem probe that the CV's headline invites. The hold is only what the quote carries. |

### F. Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" (coach's notes) | A ninety-second arc, pre-scripted. Consulting first, then product strategy and ops, then the two things from the notes that matter most for this role: the carrier model and the cross-org targets. Keep each beat to the quoted words, and add no stake the notes do not state. | Rapport openers are scored, and an unscripted walk-through runs long and drifts into unquoted claims. |
| F2 | "What's the part of Northwind's strategy you find most interesting so far?" | CO | [grounded] "enterprise expansion, an AI copilot launch ('Compass'), and reaching profitability" (the coach's research note) | Pick one of the three stated priorities and ask one question about it. Do not perform expertise on Compass beyond what the notes say. A good question scores better than an opinion built on nothing. | Casual CO questions are read as a preparation signal, and this is the answer the interviewer will remember. |

### Requirement coverage

| Requirement (JD highlights) | Covered by |
|---|---|
| own GTM strategy for two new product lines | C3 (JD) |
| identify whitespace across land/adopt/expand/renew | C1 (CASE, JD) |
| run independent analysis in SQL and Tableau | B3 |
| partner-motion design experience required | A5, D1 |
| strong cross-functional influence | A1, A2, A4 |
| AI experience a plus | B5 |
| Sales operations and quota-setting (not a highlight; F7) | none, and why: it is not in the JD highlights. If the full JD lists it, add a question. |

Headline metric (the $400M): B1, B2, E2.

## Reading the interviewer

Source: the profile description the coach supplied. No public footprint was retrieved (see Sources).

- **Career pattern:** a pricing and monetization spine, with one early-stage-startup chapter.
- **Self-described style:** "relentlessly data-driven."
- **Implications:**
  1. Every number gets probed to its assumptions. That is B1 through B4, and the answers must agree with each other.
  2. Case questions tilt toward pricing, packaging, and unit economics. That is his native language, so C1 and C2 should be answered with the economics first.
  3. The startup chapter means builder stories land with him. Expect one question about pace or scrappiness, and answer it from what she did, not from a claim about speed.
- **Mirror opportunity:** a shared professional domain, not a shared jump. His monetization spine overlaps the revenue model quoted in F4: "built a partner-level revenue model used in carrier negotiations." Use it only as a shared topic in the conversation, never as a bond she builds on.

## Persona table

| Persona | Weight | How it shows up in this round | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|---|
| Peer Evaluator | 5 | Seam probes, reciprocity, credit sharing, disagreement style | High. A peer round prices what the hire costs his team, and the seat sits beside his. | A1 to A5: seam principles, "we" and "I," reciprocity first. |
| Data-Driven Prober | 5 | Denominators, assumptions, the one number that must survive scrutiny | High. His self-described style is the strongest interviewer signal in the file. | B1 to B5: know how each figure was or was not counted, and name the weakest assumption before he does. |
| Case / Strategist | 3 | Whitespace and bundling as live problems | Medium. His pricing spine tilts cases toward economics, and a single round carries one or two cases. | C1 to C3: clarify, structure, state one premise to challenge, then answer. |
| Skeptic | 2 | Partner-motion gap, enterprise and renewal gap | Medium. The required partner line is the largest distance between notes and JD. | D1 and D2: rehearse the partner objection until it is plain, hold the model's scope, concede exactly. |
| Pressure | 2 | Time-boxed attribution of the $400M | Low to medium. Peers rarely stress-test, but a data-driven peer can time-box. | E1 and E2: pause, restate, hold on what the notes carry, concede the gap specifically. |
| Conversational | 2 | The opener and the casual "what do you think" | Medium. A sixty-minute round opens warm, and casual questions are scored. | F1 and F2: a pre-scripted ninety-second arc, and one considered question. |
| Values / Behavioral | not weighted | Would appear only as a values-style probe | Not detected. No loop source establishes a values round, and no values page was retrieved. Its one plausible appearance is A3, which carries the VAL tag. | None beyond A3. |

## Reverse questions

Each has a one-line "why it lands." She asks them in her own words.

1. **"Your path runs through pricing and monetization, with an early-stage chapter in it. Which habit from that work do you think this seat most needs?"** Why it lands: it ties to his own career path and turns an interview into a peer conversation.
2. **"What could a new person do in their first month that would genuinely help your team?"** Why it lands: this is the reciprocity question a peer weights most.
3. **"When a competitor changes the frame, which team in the room finds out first, and how?"** Why it lands: it tests the seam from A1 from his side, and it uses the threat the research note names.
4. **"Which of the three priorities is your team's number judged on this year?"** Why it lands: it shows she read the priorities and wants to know what his team owns.
5. **"What's one metric your team argues about most, and what's the argument?"** Why it lands: it shows she wants to see the data culture, which is the thing a prober cares about.

## Sources

**Provided:** the coach's notes, in three parts. The candidate summary is quoted as "the coach's notes." The JD highlights are quoted as "JD highlights." The research note on priorities and threat is quoted as "the coach's research note."

**Searches and fetches:**

| Query or fetch | Result |
|---|---|
| Northwind Data company values principles (search) | refused |
| Northwind Data interview process GTM strategy sales (search) | refused |
| Dan Kovac Northwind Data Director of Sales Strategy (search) | refused |
| Fetches | none sent |

Research tier: L1, searches 3 of 6, fetches 0 of 2; user links read 0

**Target accounting:**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Northwind Data values | unavailable | Would have fixed the values names and whether a values section applies. Section dropped: no values page in hand and no values-style round detected. |
| 2. Northwind Data interview process, sales and GTM | unavailable | Would have fixed the loop structure and the persona weights. Weights rest on relationship priors and the Generic archetype, flat and said plainly. |
| 3. Northwind Data strategy and recent news | unavailable | Would have moved recent moves and the Compass timing. The CO bank rests on the coach's research note only. No call was sent after the first three were refused. |
| 4. Dan Kovac and Northwind Data | unavailable | Would have moved the interviewer footprint, any published talks, and a reverse question tied to his path. |
| 5. Representative JD for the title | skipped | The JD highlights supplied fix the fit snapshot and the JD-tagged questions. Full JD text would firm up mid-list requirements, and that is in the upgrade menu. |

## Upgrade menu

- **Full JD text** → the mid-list requirements get rows and questions, the coverage table is re-run against the whole list, and any gate term (location, travel, work authorization) becomes a gate row.
- **Priya's CV text, or a few sentences from her in her own words** → F1 to F6 move from the coach's notes to her own quotes, and F3 and F6 can rise in confidence. Confirming "no sales-ops or quota-setting" in her words turns F7 into a capability gap with a plain acknowledgment.
- **Web search permission for the three L1 targets** → values, loop structure, and Dan's public footprint. A values round in the loop would add the values cheat sheet. Talks and writing would sharpen the interviewer read and reverse questions 1 and 4.
- **How she counted the $400M, in her own words** → fills the answer slots in B1, B2 and E2. The pack does not supply it.
- **Her answer to the partner-motion slot** → D1 and F4 move from transferability toward a story with its limit stated.
- **The recruiter's note on round format** (case, presentation, or take-home) → if a deliverable is announced, it gets its own build section, and persona weights are retuned.
- **A company strategy brief** → adds the grounding section and sharpens the CO bank beyond the research note.
- **A deeper research pass (L2)**, offered once and only after search is allowed: up to six more searches and two more fetches, several more minutes. Want it?
