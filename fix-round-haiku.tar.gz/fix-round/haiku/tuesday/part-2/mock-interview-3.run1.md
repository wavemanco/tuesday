Your prep pack is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-tuesday-part-2-rooms-case-3-denied-d615f8d2/cd05c0f4-d186-4cf6-a7c5-f5120ea514c1/scratchpad/stripe_product-operations-manager_interview_pack.md`.

I had only the company, the title and "final round", so the pack is built from role-family patterns, not from Stripe's actual values, process or strategy. Every answer about your own experience is a slot to fill, not a claim. The web search was refused in this session, so I couldn't check Stripe's published values or current strategy. The pack has 17 questions, and the biggest gap is that there's no JD or CV to ground them.

The highest-priority question is B1, "Why leave where you are, and why now?" It's the objection most likely to come up, and there's no material behind it yet.

- I can run a drill with me playing the skeptic on B1.
- I can save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions.
- I can convert the pack to a Word document if you want one.

Two questions would restructure the pack:
1. Who are you meeting in the final: your future hiring manager, a peer, an executive or a panel? Did the recruiter name focus areas or an assignment?
2. Can you paste the job description and your CV? Without them, every fit row stays `[generic]`.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: stripe_product-operations-manager_interview_pack.md -----
# Stripe — Product Operations Manager — Final-round prep pack

*First version, session mode. Built from the company and role title only: no JD, no CV, no round details. Every candidate-specific cell is an answer slot until you add material.*

## How to use this pack

- **Personas** describe how a question is asked. **Types** describe what is being scored: VAL (values/behavioral), EXP (your experience, probed), JD (role requirements), CO (company knowledge), CASE (live problem).
- Guidance is scaffolding, not a script. Speak it in your own words.
- Provenance: `[generic]` means a role-family pattern with no company or candidate claim. No row here is `[grounded]` or `[inferred]` yet.

## Sources

Provided documents: none.

Research tier: L1 — searches 4 of 6, fetches 0 of 2 (all four searches refused by the host; web search permission was not granted)

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Stripe values | unavailable | Values cheat sheet (section 10) not built. Value names must come from Stripe's own page, not memory |
| 2. Stripe interview process, product operations | unavailable | Loop structure. Persona weights fall back to an archetype (below) |
| 3. Stripe strategy / recent news | unavailable | CO questions stay generic instead of grounded in current strategy |
| 4. Interviewer name + Stripe | n/a | No interviewer name was given, so there was no query to form |
| 5. Representative Product Operations Manager JD | unavailable | Fit snapshot requirements. Would have labeled them `[inferred]` |

Queries sent, all refused: "Stripe values operating principles"; "Stripe interview process Product Operations Manager final round"; "Stripe strategy news 2026"; "Product Operations Manager job description fintech payments 2026".

Loop: no loop source establishes the loop (a "final round" with no session count establishes nothing). Fallback archetype: **big-tech structured** (recruiter, hiring manager, skills/case, behavioral/values, committee). This is an assumption, not a documented Stripe process. Because the archetype reads `yes` for a values-style round, the values section is required in principle. It is dropped here because Stripe's published values are not in hand.

## Fit snapshot (worksheet variant)

No JD and no CV were provided, so every evidence cell is `none given` and every confidence is `none`. The requirements below are role-family patterns written as prose, not quotes. Each row is a question to answer, not a claim.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Run cross-functional operating processes (planning, reviews, launches) for a product org | none given | none | [generic] | discovery | Answer slot: say which process you have run end to end and what you owned in it. If you have not run one, say so and say how you would learn the first one |
| F2 | Use data and metrics to make product and process decisions | none given | none | [generic] | discovery | Answer slot: name a metric you used to decide something and how it was counted. If you have not, say so and say what you would measure first |
| F3 | Manage stakeholders across engineering, product, finance and risk | none given | none | [generic] | discovery | Answer slot: name one stakeholder conflict you worked through and what you did. If none, say so and describe how you would open it |
| F4 | Build intake, prioritization and documentation that teams actually use | none given | none | [generic] | discovery | Answer slot: name a framework or intake process you have built or run, and whether people used it. If not, say so |
| F5 | Working knowledge of payments or fintech | none given | none | [generic] | discovery | Answer slot: say what you know about how payments work, in your own words. If little, say so and say how you would learn it fast |

Gate rows: none known. No JD means no posted terms (work authorization, location, schedule) are on record. Confirm these with the recruiter.

## Prohibited claims

No candidate sentence exists yet, so no inflated form of your own wording can be listed. Standing limits for this pack:

| Not coached | Basis | Honest form |
|---|---|---|
| Experience with Stripe's internal processes, metrics or products | Not in your material; the company is not something you have shown you know from the inside | Say what you know from public sources, and what you would want to learn |
| Scale, team size or outcomes you have not stated | No figures given | Use only numbers you can name and explain. Otherwise leave the slot empty |
| Owning a process you only took part in | Applies to any process you describe | Say your role in it, in your own words |

## Persona weights

Relationship and interviewers are unknown. Priors for a final round at a hiring manager's level, with the big-tech archetype's values tilt applied:

| Persona | Weight | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|---|
| Case / Strategist | 5 (4 questions) | Live ops problem: a metric drop, a launch, a backlog | High. A product-ops hire is bought for judgment on live work | Clarify, then structure, then think aloud; name one premise you would test |
| Skeptic | 4 (3 questions) | "Why leave, why now" and the gap probes | High. Non-payments background is the likely objection | Rehearse the one objection until it is plain; say the gap and your ramp plan |
| Data-Driven Prober | 3 (3 questions) | "How was that counted?" | Medium. Ops roles get metric questions | Say what you know about how a figure was counted, and when you do not know |
| Values / Behavioral | 3 (3 questions) | STAR stories, unpopular truth, customer over metric | Medium. Fallback archetype | Use stories you have; say so plainly where you have none |
| Pressure / Stress | 2 (2 questions) | Time-boxed, challenged position | Medium. Often in finals with an executive | Pause, restate, hold a position through two follow-ups, concede only a specific uncertainty |
| Conversational | 2 (2 questions) | "Walk me through your journey" | Certain to occur in some form, and scored | Prepare a 90-second arc |

No interviewer read: no profile was given. It would sharpen the weights.

## Question banks

Question types are scored. The guidance shows what a strong answer covers and where your own material goes. Answer slots say what to say when you have no example.

### A — Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A payments product's failure rate rose 15% over two weeks. What do you do?" | CASE | [generic] | Clarify scope and the metric definition. Segment by merchant, geography, payment method and error code. Hypothesize, name the first two checks, and say who you would involve | Live problem from a payments ops role. It asks about no past of yours |
| A2 | "Design the operating cadence for a launch that involves three teams." | CASE | [generic] | Objective, owners, decision rights, milestones, risks, and the one metric you would watch first | Tests F1's requirement as a live design. Presumes nothing about your history |
| A3 | "A backlog of 200 requests has sales and engineering disagreeing on priority. Walk me through it." | CASE | [generic] | Intake criteria, a scoring rubric you would propose, who decides, how you communicate the outcome | Tests F4. A pattern for the problem, not a fact about this company |
| A4 | "What would you want to learn about how product teams here plan work before proposing any change?" | CO | [generic] | Name the three things you would learn first and why. Do not propose a fix you cannot back | Generic CO question, since research was unavailable. Interviewers reward homework you can show |

### B — Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Why leave where you are, and why now?" | JD | [generic] | Two sentences: the work you want next, and what made now the moment. Hold through one follow-up without adding detail you have not already stated. Answer slot: the "why leave" reason is yours to state | **Highest-ROI prep in this pack.** This is the objection most likely to come up, and it has no material behind it yet. Deepest rehearsal here |
| B2 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | Name one area plainly, then say how you would close it in the first 30 days. Answer slot: if you have payments or fintech experience, say what it was; if not, say so | Tests F5 directly. Calibrated candor beats a bluff |
| B3 | "Strong ops people here have struggled with ambiguity. What is your evidence it won't happen to you?" | EXP | [generic] | Name one ambiguous situation you handled, what you did, and what you would change. Answer slot: if you have no such example, say so and describe how you would structure the ambiguity | Probe on F1 and F3. Expect a follow-up |

### C — Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Pick a number from your last role. How was it counted?" | EXP | [generic] | Answer slot: say the figure, what was counted, the assumption you would defend least, and which part was yours. If you have no such figure, say so and name one you would track | Probes F2. Never supply a counting method you did not use |
| C2 | "What metric would show a process is working, and what would make it misleading?" | JD | [generic] | One primary metric, one guardrail, and the way it could mislead | Tests F2 as a general question. Presumes no history |
| C3 | "Tell me about a decision you made from data that turned out wrong." | EXP | [generic] | Open prompt. Choose an instance: what you believed, what the data showed, what you missed. Answer slot: if none comes to mind, say so and describe how you would check a decision next time | Open prompt on F2. Honest branch built in |

### D — Values / Behavioral (fallback archetype)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Pick a time the hard truth landed. Name the stake, the moment you did not fold, and how the relationship ended. If none, say so, then give the nearest case you have | Persona stem. Values-style round fallback |
| D2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Pick one case. Say what the metric was, what the customer needed, and what you chose | Persona stem. Pairs with F4 |
| D3 | "Describe a disagreement with another team about who owns a process. What happened?" | VAL | [generic] | Name the seam, what each side wanted, what you proposed, and how it was settled. Answer slot: if you have no such case, say so and describe how you would propose a seam principle | Tests F3. Stays honest where no story exists |

### E — Pressure / Stress

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over an internal candidate?" | JD | [generic] | Pause. Restate the question. Give the one reason you can defend, and hold it through two follow-ups. Concede one specific uncertainty without folding | Pressure drill on the core claim. Answer slot: the reason is yours to name |
| E2 | "That result — how much of it was actually you?" | EXP | [generic] | Name what you did, what the team did, and where your part stopped. Hold through two follow-ups | Attribution probe. Mirrors C1 |

### F — Conversational / Rapport

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So — walk me through your journey." | EXP | [generic] | A 90-second arc in three beats: the work, the throughline, why this role. Speak it aloud twice before the interview | Casual register, still scored. Fixed arc prevents wandering |
| F2 | "What are you curious about in how payments teams work day to day?" | JD | [generic] | A real question you would ask. Tie it to the work, not to a company fact you have not checked | Casual, but tests F5 and curiosity |

### Requirement coverage

No JD was given, so the coverage check runs against the role-family requirements in the fit snapshot:

| Requirement | Covered by |
|---|---|
| F1 cross-functional processes | A2, A3, D3 |
| F2 data and metrics | C1, C2, C3 |
| F3 stakeholders | D3, B3 |
| F4 intake and documentation | A3, D2 |
| F5 payments knowledge | B2, F2, A4 |

Session total: 17 questions. Coverage is thin without a JD. The upgrade menu says what would fix it.

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a strong first 90 days look like in this role?" | Shows you are planning the work, not just wanting the job |
| R2 | "Which team's process problem is most urgent right now, and what has been tried?" | Shows you diagnose before proposing |
| R3 | "How do product ops and product teams split decision rights on launches?" | Shows you think about the seams, a question peers and managers both score |
| R4 | "What would success look like in a year, and which metric would you check first?" | Turns the close into a discussion of measurement |
| R5 | "Where does the process break down most often between teams?" | Invites a candid answer and signals you will listen |

## Upgrade menu

- JD text → the fit snapshot rows become `[grounded]` and the coverage table becomes exact
- CV or résumé → fit rows become `[grounded]`, and the bank answers become story-mapped
- Round type and interviewer name(s) → persona weights, an interviewer read and tailored reverse questions
- Recruiter's prep email → coverage of any pre-declared assignment, such as a presentation or take-home
- Stripe's values page, pasted → the values cheat sheet (section 10) and a values bank grounded in its names
- Recent Stripe strategy text, pasted → CO questions grounded in current strategy
- If your final is several sessions, the schedule → one mini-pack per session
