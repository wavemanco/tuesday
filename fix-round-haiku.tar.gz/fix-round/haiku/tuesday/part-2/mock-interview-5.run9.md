Your prep pack is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-tuesday-part-2-rooms-case-5-denied-61ccacf2/b10f4720-d2f1-4d8a-bd58-3b6806ed2131/scratchpad/kelverton-rail_senior-partnerships-manager_interview_pack.md`. I built it for a panel, with Deepa weighted toward case and skeptic questions and Ross weighted toward pressure and numbers.

I couldn't research Kelverton. The web search permission was refused, so the pack uses only your message and the recruiter's email. Your strategy team's report wasn't pasted into the conversation either, so the POV's differentiation section is still open.

Where to spend the four hours:
- **The POV (about 75 minutes).** The brief is 15 minutes spoken, with "what it means for the operators" as the close. Three theses are in the pack, each with a concession. Ross will push on the close if it reads as a sales pitch, so keep it to one sentence about the operator outcome.
- **Commercials (about 45 minutes).** The £4M is "influenced revenue", and Ross's first question will likely be how much of it was yours. The pack gives you the honest branches for how it was counted and what you'd defend least. Don't rehearse a method you can't repeat.
- **Rail (about 20 minutes).** "I haven't sold into rail" is the admission most likely to come up. Say it once, then bridge to your transport-planning work from the operator side.

Offers, neither pushed:
- I can play the Pressure interviewer on the £4M question (C1), which the pack names as the highest-ROI prep for Ross.
- I can save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions.
- If you'd like the pack as a Word document, say so and I'll convert it.

Two questions that would change the pack:
1. Can you paste the strategy report's headline recommendations? That's what the POV has to diverge from.
2. Is there a job description text? I built the requirements from the recruiter's email, so a JD would make them quoted and complete.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: kelverton-rail_senior-partnerships-manager_interview_pack.md -----
# Interview pack: Senior Partnerships Manager, Kelverton Rail

Round: second round, panel, Tuesday. Deepa (VP Partnerships, future manager) and Ross (Commercial Director). 60 minutes: first 15 minutes a spoken point of view (no slides) on operator partnerships over 18 months, landing on what it means for the operators; remaining time Q&A, with Ross pressing on commercials.

Build note: this is a panel, so personas are blended per member. No company research ran (search permission was refused), so everything about Kelverton is generic or from your own sentences. No job description was supplied, so requirements come from the recruiter's email.

## How to use + type key

Personas describe how a question arrives. Types describe what is being scored.

- **CASE**: live problem from the role, scored on structure and reasoning
- **EXP**: your past, scored on whether it survives scrutiny and what was actually yours
- **JD**: stated requirement, scored on whether you can do the listed job, gaps included
- **CO**: company and strategy knowledge (none researched yet; see upgrade menu)
- **VAL**: values (none detected; see Sources)

Guidance is scaffolding, not a script. Speak it in your own words.

## Prep triage (about 3.5 of your 4 hours)

1. **75 min: build the POV.** Write three bullets, one per thesis in the POV section, each with its concession. Then talk through the full 15 minutes aloud twice, timed. The close (what it means for operators) must be one sentence you can say cold.
2. **45 min: commercials.** Rehearse C1, D1, D2 and C3 out loud. These are where Ross will press, and where your honest answers are shortest. Practise the hold-then-concede shape, not a defence.
3. **30 min: Deepa's case questions.** A1 and A2, cold, five minutes each, no notes.
4. **20 min: the rail admission.** B1. Two sentences plus the bridge, then stop. Practise not over-explaining.
5. **20 min: the 90-second opener.** E1 from your own sentences only.

Everything else is insurance.

## The fit snapshot

Requirements come from the recruiter's email and your own message, since there is no JD. Evidence cells hold only sentences you wrote or the recruiter wrote, verbatim.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Ross will push on commercials" — recruiter's email | "took it from 6 partners to 40, roughly £4M of influenced revenue" — your message | medium | [grounded] | transferability | Your material says influenced revenue, not revenue you closed or were measured on. Say the figure in those words. Answer slot: if a mechanism behind the growth was yours to set, say which and why; if none of it was, say so and say what you did do |
| F2 | "Ross will push on commercials" — recruiter's email | "never carried a direct quota" — your message | none | [grounded] | capability | Words: "I haven't carried a direct quota." Then what you would want to be measured on, as a plan and never as a past |
| F3 | "where you'd take our operator partnerships over the next 18 months" — recruiter's email | "Never sold into rail specifically" — your message | none | [grounded] | capability | Words: "I haven't sold into rail." Then how you would learn it, as a plan. Never a claim to rail sales |
| F4 | "what it means for the operators themselves" — recruiter's email | "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" — your message | medium | [grounded] | presentation | Your sentence says you planned networks from the operator side. Say that. Do not extend it to how operators buy or what they sign off |
| F5 | "operator partnerships" — recruiter's email | "took it from 6 partners to 40" — your message | medium | [grounded] | transferability | Partner-channel scale was built in payments ISV partners, not operators. The limit: operator partnerships differ in buyers and sign-off, which you have not run |

**Confidence and gap are separate calls.** F1 and F5 are medium because the figures are yours and specific, with no artifact behind them. F2 and F3 are none because you stated the absence.

## The prohibited list

Each entry has its basis and its honest form. None of these may be asserted in any answer.

| Not coached | Basis | Honest form |
|---|---|---|
| Built the ISV channel from zero | Inflated form of F5 | "took it from 6 partners to 40." The pack's observation: your material does not say where the channel started |
| Owned the £4M | Inflated form of F1 | "roughly £4M of influenced revenue." The pack's observation: influenced is not owned |
| Knows how operators buy or sign off | Inflated form of F4 | "so I know the operator world from the other side," meaning the planning side |
| Has sold into rail or operators | Negative you stated, F3 | "I haven't sold into rail." No slot needed on the negative itself |
| Has carried a quota | Negative you stated, F2 | "I haven't carried a direct quota." |

## The persona table

| Member | Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|---|
| Deepa | Case/Strategist (top) | Live operator problems; "what do you do first" | High. She is the hiring manager and the role is partnerships, so she scores structure on operators | Clarify before structure. Say your first question aloud |
| Deepa | Skeptic | "Why would an operator give you time?" | High. The rail gap is the obvious one | Two sentences, the bridge, then stop |
| Ross | Pressure/Stress (top) | Time-boxed, challenging the £4M | High. Commercial Director, pressing on commercials as your brief says | Pause, restate, hold a position through two follow-ups |
| Ross | Data-Driven Prober | "Walk me through how that was counted" | Medium-high. The £4M and 40 partners are headline numbers | Name the weakest assumption you know before he does |
| Panel (opener) | Conversational | "So walk me through the journey" | Low-medium. It is still scored | A 90-second arc from your own sentences |

Weights: Case 5 (Deepa), Skeptic 3, Pressure 5 (Ross), Prober 3, Conversational 2. Total 18. The panel mix is each member's top two personas. No values-style round is detected: no loop source names one, and the fallback archetype is not established.

## The POV: graded deliverable

The brief is a 15-minute spoken POV with a required close: what it means for the operators.

**Grounded facts to build on:** F4 and F5. Talk from the operator side you have seen, and from the partner scale you have run.

**Thesis A: start with a few operators on shared outcomes, not a broad program.**
- Operator benefit: fewer planning cycles spent reconciling changes. This is a [generic] benefit, not a fact about Kelverton's customers.
- Concession: slower, fewer logos, and most of the revenue lands in year two.

**Thesis B: build the calendar around the operator's planning cycle, not your sales calendar.**
- Operator benefit: partnerships run when operators can act on them.
- Concession: this depends on operator planning calendars I have not seen. Say so.

**Thesis C (the anti-pick): decline operators whose constraints the product cannot yet reflect.**
- Operator benefit: fewer partnerships that fail after launch.
- Concession: this turns away early revenue, which Ross will press on.

**Differentiation:** the strategy team's report was not visible to me, so I cannot yet say what the consensus answer is or where to diverge from it. Pasting its headline recommendations is question 1 in the message. Until then, do not recite its shortlist.

**Close:** one sentence on the operator outcome, in your words. Not a metric you have not measured.

## Question banks

Ordering by weight within each persona.

### Deepa: Case/Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Sketch the first 90 days: how would you find the first three operator partners?" | CASE | [generic] | Clarify what an operator partner is for Kelverton, then objective, segmentation, approach, metrics, risks. Think aloud | A live problem from the POV's own question. No claim about your past |
| A2 | "An operator says the tool adds planning time in their disruption season. What do you do?" | CASE | [generic] | Clarify what disruption season means for them, check the problem against the product's real use, then the decision and what you would tell the operator | A live problem from the operator side, which F4 supports you talking about without claiming their sign-off |
| A3 | "Where would you say no to an operator partnership?" | CASE | [generic] | Name Thesis C's anti-pick, its trigger, and its cost. Concede the revenue | The POV's anti-pick, asked as a probe |
| A4 | "You took it from 6 partners to 40. What drove that growth?" | EXP | [grounded] "took it from 6 partners to 40" | Story-mapped on F5: the growth, in the number's own terms. Answer slot: if a mechanism behind the growth was yours to set, say which and why; if none was yours, say so and say what you did do | Premised on F5 only. The likely probe is whether the growth was yours |
| A5 | "What does a transport planning background let you see in an operator that a sales lead wouldn't?" | EXP | [grounded] "so I know the operator world from the other side" | Name what you did from the planner's seat, in your sentence's own terms. Do not extend it to how operators buy | F4 is the operator-side evidence, and this question asks you to read it |
| A6 | "What would a first operator partnership look like, concretely?" | CASE | [generic] | Describe one shape, its scope, and what would make it fail. Admit the unknowns of Kelverton's operator base | A POV follow-up, asked as a plan |

### Skeptic (Deepa, weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've never sold into rail. Why would an operator give you their time?" | JD | [grounded] "Never sold into rail specifically" | **Highest-ROI prep.** Say "I haven't sold into rail," then the bridge: you planned networks on the operator side (F4). Hold through two follow-ups by returning to that bridge. Concede what you have not done. Never claim rail experience you do not have | F3 is the gap she is most likely to find. Deepest rehearsal on the negative you stated |
| B2 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "never carried a direct quota" | Name the quota ownership honestly, in those words, and what you would ask to be measured on | F2 is the other stated absence. Naming it first is stronger than being caught |
| B3 | "Why leave payments for rail-tech?" | EXP | [generic] | Answer slot: the motivation is yours and not in your material; say it in your own words, plainly | No sentence you wrote carries a motivation, so the guidance supplies none |

### Pressure/Stress (Ross, weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "That £4M. How much of it was actually you?" | EXP | [grounded] "roughly £4M of influenced revenue" | **Highest-ROI prep for Ross.** Hold: "It was influenced revenue, and here is my part in those deals." Answer slot: if you know how the influence was counted, say how in your own words; if you do not, say so plainly. Concede the attribution limit. Never claim to have owned the figure | F1. The second follow-up tests the number, so the honest branch must be ready |
| C2 | "Sixty seconds: why should I believe partner-influenced revenue means anything in an operator sale?" | CASE | [generic] | Hold that influence is worth tracking, and concede it is weaker than sourced revenue. Name what you would want to see before believing it | A pressure question on F1's framing |
| C3 | "You've never carried a quota. Why shouldn't I hire someone who has?" | JD | [grounded] "never carried a direct quota" | Plain acknowledgment: "I haven't carried a direct quota." Hold on the channel result, concede that a quota would be the test | F2's stated absence, pressed hard |
| C4 | "Give me the number you'd commit to for year one." | CASE | [generic] | Do not name a number you have not seen the pipeline for. Say what you would commit to on leading indicators and why | A common trap. The honest answer is a method, not a figure |
| C5 | "What would make you walk away from a rail deal?" | CASE | [generic] | Name Thesis C's trigger, then its cost. Hold the position | The anti-pick, asked under pressure |

### Prober (Ross, weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how that influenced figure was counted." | EXP | [grounded] "roughly £4M of influenced revenue" | Answer slot: if you know how it was counted, say how in your own words; if you do not, say so plainly and say what you would check. Do not invent a method | A figure raises the defend-the-number slots. None is supplied here |
| D2 | "Which assumption behind that number would you defend least?" | EXP | [grounded] "roughly £4M of influenced revenue" | Answer slot: name the assumption you know of, in your own words. If you know of none, say you do not know how it was counted | Weakest-assumption slot. Naming it first converts a gotcha into credibility |
| D3 | "How many of those 40 partners would you say you recruited yourself?" | EXP | [grounded] "took it from 6 partners to 40" | Answer slot: say how many you recruited, if you know; if the growth came through others, say so | F5's ownership limit |

### Conversational (opener, weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)"; "9 years in partnerships"; "last 4 at a payments company running the ISV channel" | 90 seconds: transport consulting first, then the payments ISV channel, then why this role. Use only those sentences | The opener is scored. Tell the arc from the quotes and add nothing |

**Requirement coverage**

| Stated requirement | Covered by |
|---|---|
| Operator partnerships over 18 months (POV) | A1, A6, POV Theses A to C |
| What it means for the operators | A2, A5, POV close |
| Commercials (Ross) | C1, C2, C3, C4, D1, D2, D3 |
| Why you, rail gap | B1, B2, B3 |
| Opener (no stated requirement) | E1 |

## Reverse questions

Each one has a reason it lands. No interviewer profile exists, so none ties to a path.

1. **Deepa:** "What did the last operator partnership that worked look like?" Lands because it asks her to describe the bar, not defend the role.
2. **Deepa:** "What would you need from me in the first 90 days to make the operator plan real?" Lands because it reads like a future manager's expectation.
3. **Ross:** "Which operator revenue do you count as partner-sourced, and which as partner-influenced?" Lands because it asks him to show his own attribution, which is the question he will ask you.
4. **Ross:** "What does a good first year look like on the commercial side?" Lands because it asks him for the bar, not your number.
5. **Either:** "Which part of the 18-month plan would you most want to test first?" Lands because it invites them into the POV rather than a verdict on it.

## Sources

Research tier: L0. Searches 3 of 6 sent, all refused by a permission prompt; fetches 0 of 2; user links read 0.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Kelverton Rail values | unavailable | Values cheat sheet (section 10). Search refused. No values detected; no values page in hand |
| 2. Kelverton Rail interview process, partnerships | unavailable | Loop structure. The recruiter's email establishes this session as a panel, which is enough for this round. Refused |
| 3. Kelverton Rail strategy / recent news | unavailable | CO bank. No strategy brief in hand. Refused |
| 4. Deepa and Ross, Kelverton Rail | unavailable | Interviewer read and reverse questions tied to path. Names given without surnames; no search sent |
| 5. Representative JD | unavailable | Requirements. No JD supplied, no search sent |

Provided documents: recruiter's email quoted in this pack; your message. The strategy team's report was not provided to me as text, so it is not used anywhere in this pack.

## Upgrade menu

- The strategy report's headline recommendations, pasted → the POV's differentiation section gets its consensus answer and a real divergence. Without it, the POV may recite what everyone else says.
- The job description text → the F rows become quoted JD requirements and the coverage table gets its full list
- Your CV → F1 to F5 quote your CV instead of your message, which strengthens every EXP question
- Deepa's and Ross's public bios or profiles, with surnames → the persona weights and a reverse question tied to their own path
- Confirmation whether there is a further round → loop mode, with a per-round mini-pack
