Your prep pack is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-tuesday-part-2-rooms-case-2-denied-21ac4c71/fc4e6fbe-2fb2-4e04-839c-91a626418e98/scratchpad/atlas-freight_operations-manager_interview_pack.md`. It has the full fit snapshot, prohibited claims, 16 questions across five personas, the reverse questions and the coverage map. I built it for a hiring-manager round because your note didn't say who you're meeting.

**The three things to rehearse most**

1. **Scope.** Your material shows 3 supervisors at one site. The JD asks for 12 supervisors across 4 sites. The most likely objection is "why you, for this step?" (question A1). Practise naming your largest team and how you ran it, and saying plainly what's new to you.
2. **Leadership years.** The JD requires 5+ years of operations leadership. Your material gives 7 years of operations but doesn't say how many of them were leadership. Know the exact number before the interview (question A3).
3. **Metrics.** Your 40% mis-pick reduction is an accuracy result. The JD asks for on-time performance and cost per shipment. Be ready to say whether you tracked either, and how the 40% was counted (questions B1 and B2).

**Strong points to lead with**

- The pick-path redesign, told as your own work (C3 and D2).
- The peak-season surge plan, run two years in a row (C3).
- The green belt, stated plainly. It fully meets the Lean/Six Sigma line.

**Power BI.** Say "I haven't used Power BI" directly, then give a concrete plan, such as rebuilding one Excel report in Power BI. Don't imply any past work with it (questions A2 and B4).

**Research.** I couldn't search for Atlas Freight. Web search wasn't permitted in this session, so the pack has no company values, interview-process or strategy material. Anything about the company is generic until you add its values page or a recruiter's description of the process.

**What would sharpen the pack**

- Who you're meeting (hiring manager, peer, panel or recruiter). This changes which questions get the most weight.
- Your number of years in a leadership role. This resolves the 5-year gate.

Two offers, neither pushed:
- I can run a live drill: I play the Skeptic on A1 and push until you hold your position, then give feedback against that question's guidance.
- I can save a `tuesday-dossier.md` recording the gaps this prep exposed, to carry into later sessions.

Would you like the pack as a Word document? I can convert it when you're done editing.

Is the person you're meeting your future manager, or a peer on the team? That answer reweights every question bank.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: atlas-freight_operations-manager_interview_pack.md -----
# Atlas Freight — Operations Manager: interview prep pack

Role: Operations Manager, Atlas Freight (regional logistics, 800 employees, 4 sites)
Interviewer: not named. Round type: not stated. This pack assumes a hiring-manager round, with flat persona weights until you confirm.

## How to use + type key

Personas describe how a question arrives. Types describe what is being scored.

- **VAL**: behavioral / values alignment
- **EXP**: your own experience, tested for what you actually did
- **JD**: the role's stated responsibilities and qualifications
- **CO**: company and strategy knowledge (none researched; see Sources)
- **CASE**: a live problem from the role

Guidance is scaffolding, not a script.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" — JD | "7 years in warehouse and distribution ops" — your message; "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | Your material shows shift-level operations over 3 supervisors, at one site. It does not show four sites. Words: "I'm a senior shift manager over 3 supervisors." Answer slot: if you have coordinated work across more than one site, say how, in your own words; if you have not, say so plainly and say how you would set up a four-site daily rhythm. |
| F2 | "drive on-time performance and cost-per-shipment down" — JD | "cut mis-pick rate 40% by redesigning the pick path" — your message | medium | [grounded] | transferability | Your material shows an accuracy result, not on-time performance or cost per shipment. Words: "I cut the mis-pick rate 40% by redesigning the pick path." Answer slot: if you tracked on-time performance or cost per shipment, say what you tracked and what moved; if you did not, say so plainly and say which measure you would start with. |
| F3 | "lead a team of 12 supervisors" — JD | "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | Three supervisors is the scope you have stated. Twelve is four times that. Answer slot: describe the largest team you have led and how you ran it; if a structure of 12 supervisors is new to you, say so and say how you would organize it. |
| F4 | "build reporting in Excel/Power BI" — JD | "solid Excel" — your message | medium | [grounded] | transferability | Your material supports Excel. It does not show reports you have built in it. Answer slot: if you built a recurring report, name it, what it was for, and who used it; if you have not built one, say so and say what you would build first. |
| F5 | "build reporting in Excel/Power BI" — JD | "never used Power BI" — your message | none | [grounded] | capability | Words: "I haven't used Power BI." Then how you would learn it, said as a plan and never as a past. |
| F6 | "5+ years operations leadership required" — JD | "7 years in warehouse and distribution ops" — your message; "currently a senior shift manager over 3 supervisors" — your message | low | [grounded] | hard_gate | Your material does not establish how many years you have held a leadership role. It gives 7 years of operations and a current supervisory role, with no leadership span. Surfaced, not bridged. Asked in Step 1. |
| F7 | "Lean/Six Sigma a plus" — JD | "green belt certified" — your message | high | [grounded] | none | Words: "I'm green belt certified." Lead with the certification. |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Ran daily terminal operations across four sites | Inflated form of F1 | The "senior shift manager over 3 supervisors" quote at its own scope. Limit, as the pack's own observation: your material shows one site's shift scope. |
| Led a team of 12 supervisors | Inflated form of F3 | The 3-supervisor quote. The F3 slot asks only for the largest team you have led. |
| Drove on-time performance or cost per shipment down | Inflated form of F2 | The mis-pick result at its own scope. |
| Built Power BI reporting | Negative you stated, F5 | "I haven't used Power BI." No claim of Power BI work. |
| Five years of operations leadership | Gate not established, F6 | The pack's observation only: your material does not establish the span. No first-person claim either way. |

## Persona weights

| Persona | Weight | Why |
|---|---|---|
| Skeptic | 5 (top) | Your gaps are scope (4 sites, 12 supervisors), Power BI, and the leadership-years gate. A hiring manager buying capability will probe these first. |
| Data-Driven Prober | 4 | Your headline number (40% mis-pick) and the Excel reporting claim will be tested for how they were counted. |
| Case / Strategist | 3 | Live operations problems are how a hiring manager tests a new site lead. |
| Pressure | 3 | The "why you, over someone who has run four sites" question is the likely composure test. |
| Conversational | 2 | Opening arc and casual Power BI questions. Still scored. |

Weights are relationship priors, not interviewer signals, because no interviewer is named.

## Question banks

Provenance comes before the guidance. The sentence is your own, quoted exactly.

### A. Skeptic (weight 5) — highest-ROI prep is A1

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You manage three supervisors. This role leads twelve across four sites. What makes you the one to take that step?" | JD | [grounded] "currently a senior shift manager over 3 supervisors"; "7 years in warehouse and distribution ops" | Name the 3 supervisors you lead and the 7 years in warehouse and distribution ops, in those words. Answer slot: name the largest team you have led and how you ran it. If the step to 12 across four sites is new, say so plainly and say how you would structure your first 90 days. Do not claim scale you have not had. Hold through the second follow-up by returning to the team you ran. | F3 and F1 are the largest gaps and the objection this JD will raise. Most likely to come up in some form. |
| A2 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "never used Power BI" | Name Power BI plainly: "I haven't used Power BI." Then your plan to close it. Answer slot: if another part of the role is weaker for you, name it and how you would cover it. | F5: the candidate's own stated negative. Answer with the plan, not a past. |
| A3 | "The role requires five years of operations leadership. How many years have you led people?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" | State the number of years you have held a supervisory role, and the scope, as the number you actually have. Do not round up. | F6, the hard gate. Interviewers often ask this directly. |

### B. Data-Driven Prober (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Walk me through how the 40% mis-pick reduction was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Answer slot: if you measured it, say how: the baseline period, the count, and the assumption you would defend least. If you do not know how it was counted, say so plainly. If the redesign was a team effort, name your part of it. | Headline number; the probe is precision about attribution. |
| B2 | "Did that change move on-time performance or cost per shipment?" | JD | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Say what you measured, in those words. Answer slot: if you tracked on-time performance or cost per shipment, say what moved. If you did not, say so plainly and name the measure you would start with. | F2, the gap between the requirement and the result you have. |
| B3 | "How would you build a weekly on-time report in Excel from scratch?" | CASE | [grounded] "solid Excel" | Describe the steps: source data, the cut by site and shift, the check that the totals match, the one chart a site manager would read. Answer slot: if you have built a recurring report, name it and who used it. If not, say so and describe your approach. | F4. Answer on approach, not on a report you have not built. |
| B4 | "Power BI is part of the job. What would your first two weeks with it look like?" | JD | [grounded] "never used Power BI" | "I haven't used Power BI." Then a learning plan with a concrete first deliverable: rebuild one Excel report in Power BI and compare the two. | F5. A plan, never a claim about past work. |

### C. Case / Strategist (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "One site is 8 points below on-time target and cost per shipment is rising. What do you do in week one?" | CASE | [generic] | Clarify first: which lanes, which shifts, what the baseline is, whether the change is recent. Then segment by shift, lane and dock before deciding. Talk to the supervisors who run those shifts. Pick two actions and say how you would know by week three. | Live problem from the JD's core metrics. No claim about your past. |
| C2 | "You're taking over four sites. What would you put in place first?" | CASE | [generic] | One shared daily metrics review across the four sites, a standard shift-start routine, and a weekly supervisor cadence. Say what you would look at first and why. | F1 and F3 at once, without making a claim about your past. |
| C3 | "Peak is six weeks away. How do you plan it?" | EXP | [grounded] "ran the site's peak-season surge plan two years running" | Tell the surge plan in your own words: what it covered, who was involved, what you changed each year. Answer slot: if the plan covered more than one site, say how you coordinated it. If it covered one site, say so and describe the part you ran. | Your strongest operational story. The slot keeps the four-site probe honest. |
| C4 | "Which one metric would you put on the wall at every site's morning meeting, and why?" | CASE | [generic] | Pick one measure that links to on-time performance and cost per shipment. Name the trade-off it creates, such as speed against accuracy, and how you would watch for it. | JD metrics. A common follow-up to C2. |

### D. Pressure (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you, over someone who has already run four sites?" | JD | [grounded] "7 years in warehouse and distribution ops"; "green belt certified" | Hold: seven years in warehouse and distribution operations, and a green belt, applied to the work. Hold through two follow-ups. Concede the four-site gap specifically, not the whole case. | F1 and F3 under pressure. Hold the position you can back, then concede the exact gap. |
| D2 | "That 40% — how much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Answer the part that was yours, in your own words. If the redesign was shared, say so and name your part. Do not fold on your part to restore harmony. | Attribution probe. Hold-then-concede. |
| D3 | "You already manage supervisors. Why not wait for a bigger site?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" | Hold the reason you are ready now, in the terms of the team you run. Concede the uncertainty that is real, specifically: the scale of four sites. | Motivation probe. Pressure tests whether you fold. |

### E. Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through how you got here." | EXP | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors"; "green belt certified" | A 90-second arc in your own words: operations, the pick-path work, the supervisor role, the belt. | Opening question, scored for clarity. |
| E2 | "Are you picking anything up right now?" | JD | [grounded] "never used Power BI" | Say plainly you haven't used Power BI, and name what you are doing about it. | Casual wording on a scored gap. |

### Coverage

| JD requirement | Questions |
|---|---|
| Own daily terminal operations across 4 sites | A1, C2, C3 |
| Drive on-time performance and cost-per-shipment down | B2, C1, C4 |
| Lead a team of 12 supervisors | A1, D1, D3 |
| Build reporting in Excel/Power BI | B3, B4, A2, E2 |
| 5+ years operations leadership | A3 |
| Lean/Six Sigma a plus | none, and why: the belt is a stated credential, covered in D1 and E1 |

## Reverse questions

1. "What does success look like for this role at 90 days, across the four sites?" Why it lands: shows you are planning for the whole role.
2. "Which site is furthest from its on-time target right now, and what is the working theory?" Why it lands: shows you think in operations terms.
3. "How is reporting built today, and is Power BI already in use?" Why it lands: tests whether your Power BI gap matters on day one.
4. "How is the team of 12 supervisors structured, and how long have they been in role?" Why it lands: shows you want the real structure before you commit.
5. "What would make someone in this role look strong at the end of the first quarter?" Why it lands: a standard question that signals you plan to be measured.

## Upgrade menu

- The interviewer's name → a tailored reverse question and persona weights from their public footprint
- The round type and whether it is a panel → restructures the banks (see Step 1)
- The five-years leadership span, in years → resolves F6 from an open gate into a plain answer
- The largest team and largest site count you have led → upgrades F1 and F3 from a slot into a quoted sentence
- Any recurring Excel report you built, and its use → upgrades F4 from a slot into a quoted sentence
- Atlas Freight's values page or interview-process description → adds a values cheat sheet and the loop structure (research was not available this session)
