Your prep pack is saved at /tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-tuesday-part-2-rooms-case-8-canned-c4c2a091/4fda540c-0950-4209-8989-07000292a3f3/scratchpad/Ashgrove_Credit_Union_member_experience_lead_interview_pack.md. I built it as a loop across the three rounds, with a shared fit snapshot and one mini-pack per round.

The main finding: your two stated gaps, no contact-centre experience and no presenting above regional level, will come up in round 2 with your prospective manager. The pack's highest-return prep is M4, where the manager presses on the contact-centre gap. Rehearse "I haven't worked in a contact centre," then "I handled the branch's formal complaints log," then a plan for learning the contact-centre side. Keep the story to what you did.

Other things to know before 20 November:

- **Round 3 is the one that's scored on values.** The 20-minute case has no story in your material yet, so the cheat sheet gives you selection scaffolds with an honest "say so if none comes to mind" branch for each value.
- **The strategy grounding is based on your summary of the brief.** I haven't read the brief itself. If you paste it, I can check the figures against the wording.
- **The values were copied from the site this morning and I haven't checked them live.**
- **Interviewer names would sharpen the round 2 and 3 weights.** The pack assumes the panel's relationship from the recruiter's description.

Want a drill? I can play the Skeptic on M4 and push through two or three follow-ups. I can also save a tuesday-dossier.md recording the gaps this prep exposed, for later sessions. A Word version of the pack is available if you want one.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Ashgrove_Credit_Union_member_experience_lead_interview_pack.md -----
# Interview pack: Member Experience Lead, Ashgrove Credit Union

**Role:** Member Experience Lead
**Company:** Ashgrove Credit Union
**Rounds (20 November 2026):** (1) 30 minutes with the recruiter; (2) 45 minutes with the Head of Member Services, your prospective manager, mostly behavioural; (3) 60 minutes with a panel of two branch managers, including a 20-minute complaint-escalation case, scored against the four values.
**Interviewers in rounds 2 and 3:** not yet named.
**Mode:** loop. Shared fit snapshot and prohibited list, then one mini-pack per round.

## How to use this pack

Personas describe how a question arrives. Types describe what is being scored.

| Type | Name | What it scores |
|---|---|---|
| VAL | Values | Whether past behaviour shows the published values |
| EXP | Experience | Whether your CV claims survive a close read, and what you personally did |
| JD | Role | Whether you can do the listed job, including its gaps |
| CO | Company | Whether you know the company's position and can think at its level |
| CASE | Live problem | Structure and reasoning on a problem from the role |

Guidance is scaffolding, not a script. Speak it in your own words. Each guidance cell is written to be said in 90 to 120 seconds.

## Fit snapshot

Requirements are quoted from the job description you sent. Evidence is quoted from your message. Nothing in the evidence column is paraphrased.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" (JD) | "6 years in retail banking, the last 3 as a branch supervisor." (your message) | medium | [grounded] | none | No gap on years or sector. The quote reaches the requirement in role terms. Say it in these words: six years in retail banking, the last three as a branch supervisor. |
| F2 | "experience handling regulated complaints" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | presentation | The quote reaches the requirement in other terms: formal complaints. Use the words as they stand: "I handled the branch's formal complaints log." The word "regulated" is the JD's, and a probe on it is likely; see M3 and S4. |
| F3 | "Own the member complaints process end to end across branches and the contact centre" (JD) | "I handled the branch's formal complaints log" (your message) | low | [inferred] | transferability | The quote carries one branch's log. It does not show the process end to end, and it does not show work across branches. Words: "I handled the branch's formal complaints log." Answer slot: if you handled a complaint that moved beyond your branch, say how, in your own words. If none did, say so plainly and stay with the log. |
| F4 | "the contact centre" (JD, from F3's requirement) | "Never worked in a contact centre" (your message) | none | [grounded] | capability | You stated this absence yourself, so the pack may give the words back: "I haven't worked in a contact centre." Then a plan for how you would learn it, said as a plan and never as a past. |
| F5 | "coach branch supervisors on escalations" (JD) | "trained new tellers on our escalation script" (your message) | medium | [inferred] | transferability | The quote is about tellers, not supervisors. Words: you trained new tellers on the escalation script. Answer slot: if you coached a supervisor on an escalation, say what you did, in your own words. If you did not, say so plainly and say how you would start. |
| F6 | "report monthly on complaint volumes and resolution times" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | medium | [grounded] | presentation | The quote reaches monthly reporting in other terms. Words: "I built the monthly complaints spreadsheet our regional manager uses." Pack observation: your material does not show which measures the spreadsheet holds. |
| F7 | "comfortable with Excel reporting" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | medium | [grounded] | presentation | Excel is not named in your material. The quote reaches the requirement in other terms. Use the same words as F6 and do not name a tool you have not named. |
| F8 | "confident presenting to senior leaders" (JD) | "I've never presented to anyone above regional level" (your message) | none | [grounded] | capability | You stated this absence yourself. Words: "I haven't presented to anyone above regional level." Then a plan, said as a plan. |
| F9 | "work with digital teams on self-service journeys" (JD) | none given | none | [grounded] | discovery | Nothing in your material touches this requirement, so the pack does not know whether the experience exists. Answer slot: if you worked with a team on a digital or self-service change, say what you did. If you did not, say so plainly and say how you would start. |

**Routing note:** Gap types follow the evidence cell. F4 and F8 are `capability` because you stated the absence. F9 is `discovery` because silence is not a negative you stated.

## Prohibited claims

These are not coached in any answer, slot, hold or rehearsal in this pack.

| Not coached | Basis | Honest form |
|---|---|---|
| "I owned the complaints process end to end" | Inflated form of F3. The material shows one branch's log. | "I handled the branch's formal complaints log." Pack observation: your material says the branch log, not the process end to end. |
| "I coached supervisors on escalations" | Inflated form of F5. The material shows tellers. | "trained new tellers on our escalation script." |
| "I measured complaint volumes and resolution times" | Inflated form of F6. The material shows a spreadsheet, not its measures. | The F6 quote at its own scope. Pack observation: your material does not show which measures it holds. |
| "I have worked in a contact centre" | Negative you stated (F4). | "I haven't worked in a contact centre." No slot. |
| "I have presented to senior leaders" | Negative you stated (F8). | "I haven't presented to anyone above regional level." No slot. |

## Grounding brief

Built from the summary of the July 2026 strategy brief in your message. I have not read the brief itself, so check these against the document before you rely on the exact figures.

- Target: 40% of member service moved to digital channels by 2028.
- Network: eight branches consolidated into five hubs during 2027.
- Product: small-business lending launch in Q1 2027.
- Pressure: app-only banks.

**Vocabulary to use:** digital channels, hubs, self-service, app-only banks, small-business lending.

**Tension to be ready for, without coaching you to correct the interviewer:** the hub consolidation sits against the value "Neighbours, Not Numbers". Expect a question that asks you to hold both.

## Values cheat sheet (round 3)

Your material carries no story for any of the four values, so each row is a selection scaffold ending in its honest branch.

| Value (official name) | Working meaning (paraphrased) | Mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter. | Scaffold: pick a complaint from your log where the member's side changed the outcome. If none comes to mind, say so plainly, then give the nearest thing your material carries: "I handled the branch's formal complaints log." |
| Plain Words | If a member needs something explained twice, it was written wrong. | Scaffold: if a script or a message was unclear to a teller or a member, say what you did about it. If none was, say so plainly and say how you would check one before it went out. |
| Neighbours, Not Numbers | Every branch is part of its town. | Scaffold: if you know what your branch's town was like and what it needed, say so. If you do not, say so, and say how you would find out before a branch moved into a hub. |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved. | Scaffold: pick one complaint you carried to close, from the log you handled. If none comes to mind, say so plainly, then describe how the log handled a case that stayed open. Quote anchor: "I handled the branch's formal complaints log." |

## Round 1: recruiter screen (30 minutes)

### Persona weights

| Persona | Weight | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|---|
| Conversational / Rapport | 4 | Friendly opener; "walk me through" | High. A recruiter screen is friendly by default, and the risk is treating it as unscored. | Pre-scripted 90-second arc from your quoted sentences only. Treat casual questions about the role as scored. |
| Skeptic (light) | 2 | Quiet check on the gaps and motives | Medium. The recruiter's job includes the knockout check, and F4 and F8 are the first thing it finds. | Say the two stated gaps plainly, then the plan. |
| Values / CO | 2 | Question about the company or its values | Medium. The panel scores values, and the recruiter may test the same vocabulary early. | Name one value and say what it means for your day, in your words. |

### Bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| S1 | "So, walk me through the journey to here." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log" "trained new tellers on our escalation script" "I built the monthly complaints spreadsheet our regional manager uses" | A 90-second arc using only those four sentences, in order: six years in retail banking, the last three as a branch supervisor; then the complaints log; the escalation training; the spreadsheet. Add nothing between them. | F1, F2, F5 and F6 are the spine of the screen. Using only the quoted sentences keeps the arc inside what you can defend in round 2. |
| S2 | "What's drawing you to this role?" | JD | [generic] | No sentence of yours carries a motive, so this is a selection scaffold: name one reason from the remit itself, the complaints process across branches and the contact centre, in your own words. If your real reason is different, give that one. | A motivation check the recruiter will make before the manager does. |
| S3 | "Which part of this role are you least ready for?" | JD | [grounded] "Never worked in a contact centre" "I've never presented to anyone above regional level" | Give the two plain acknowledgments: "I haven't worked in a contact centre." Then "I haven't presented to anyone above regional level." Then a plan for each, stated as a plan. Do not soften either one. | F4 and F8 are capability gaps you stated. Naming them first is cheaper than having them found. |
| S4 | "Tell me about the complaints work you've done." | EXP | [grounded] "I handled the branch's formal complaints log" | Say what you handled, in your words, starting from "I handled the branch's formal complaints log." Describe the work the log involved. Give no volumes, outcomes or timescales you do not have in hand. | F2 is the regulated-complaints requirement. The recruiter will test whether the experience is real, and the honest version is the one you can repeat in round 2. |
| S5 | "What do you know about us as a member-owned credit union?" | CO | [generic] | Name one of the four values and say what it means for the work you would do, in your own words. Go no further than the values page you have read. | The values are the panel's scoring frame, so the recruiter's version is a rehearsal for round 3. |
| S6 | "What would make you leave a branch supervisor role for this one?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Say what the remit adds to the supervisor role, in your own words: the complaints process across branches and the contact centre. If the pull is something else, say that instead. | A motivation-consistency check tied to F1. |
| S7 | "Tell me what you'd do in your first 90 days." | CASE | [generic] | Structure: read the log first; meet the supervisors whose escalations you would coach; learn the contact-centre side before you change anything. Answer slot: if you have set up a first 90 days in a past role, say what you did. If you have not, say so plainly and give the plan. | A live problem from the role, asked early, so the plan you give here has to match the one you give in round 2. |
| S8 | "How would you explain a complaint decision to a member in two sentences?" | VAL | [generic] | Two plain sentences, free of internal terms. Say each sentence aloud once. No story is needed. | Plain Words is a published value, and this question tests it directly. |

### Reverse questions

- "What does a strong first six months look like in this role?" Why it lands: it shows you are planning for outcomes, not for the job description.
- "Which of the four values do people here find hardest to live by in practice?" Why it lands: it shows you are working with the values, not quoting them.

## Round 2: Head of Member Services, your prospective manager (45 minutes)

### Persona weights

| Persona | Weight | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|---|
| Values / Behavioural | 4 | STAR-style prompts about past decisions | High. The recruiter said the round is mostly behavioural, which moves this above the usual hiring-manager weight. | Stories only from your log. Where none carries a story, say so, then give the nearest thing. |
| Skeptic | 2 | The gap, asked by the person who would manage it | High for the contact-centre gap. This is the person who would be living with it. | Hold the two stated gaps, then concede specifically. |
| Case / Strategist | 2 | A live problem on a branch change | Medium. Hiring managers test the problem they actually face. | Clarify, then structure, then say what you would measure first. |

### Bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| M1 | "Tell me about a time you decided something from a member's side of the counter." | VAL | [generic] | Selection scaffold: pick one decision from your log where the member's side was the deciding factor. If none comes to mind, say so plainly, then give the nearest thing your material carries: "I handled the branch's formal complaints log." | Members First is the value this manager is most likely to test first. |
| M2 | "Tell me about a complaint you kept hold of until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log" | Pick one entry from the log that you carried to close. If none you carried to close comes to mind, say so plainly, then describe how the log handled a case that stayed open. Do not claim you solved what you did not solve. | Own the Fix. F2 is the only quoted line, so the story has to be drawn from the log. |
| M3 | "Walk me through how you trained new tellers on the escalation script." | EXP | [grounded] "trained new tellers on our escalation script" | Say what the training covered and how you ran it, in your own words. Answer slot: if you checked whether tellers used the script correctly, say how. If you did not, say so plainly. | F5. The manager will test whether the coaching experience is real before the supervisor coaching in M8. |
| M4 | "You've never worked in a contact centre. How would you own complaints that run through one?" | JD | [grounded] "Never worked in a contact centre" "I handled the branch's formal complaints log" | Highest-ROI prep in this pack. Start with "I haven't worked in a contact centre." Then, at its own scope, "I handled the branch's formal complaints log." Then a plan: what you would learn from the contact-centre side first. Hold through two follow-ups by returning to the log, and concede the gap specifically. Answer slot: if a complaint of yours went through a contact-centre handoff, say how. If none did, say so plainly. | F3 and F4 together are the most predictable objection to you. It will come in some form, and a rehearsed, non-defensive answer changes the round. |
| M5 | "If complaints rose after a branch changed how it serves members, what would you want to know first?" | CASE | [generic] | Structure: is the rise in volume or in cause; which branches; what changed for members; how members were told. Then an approach and one measure. Use no facts about the network that you have not been given. | A live problem in the role. Hubs are the context in the brief, but the question itself presupposes nothing about them. |
| M6 | "What would you check in a member letter before it went out?" | VAL | [generic] | A short, plain list: is each sentence one that a member can act on, is any term internal, would a member need to read it twice. No story is needed. | Plain Words, tested as a method, not a record. |
| M7 | "What would you want the monthly complaints report to show the regional manager?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Name the spreadsheet you built, in those words. Then the measures the role asks for: volumes and resolution times. Answer slot: if your spreadsheet already counted volumes or resolution times, say which, and how. If it did not, say so plainly and say what you would count first. | F6 and F7 are the strongest reporting evidence you have, and they stop before the measures. |
| M8 | "How would you coach a supervisor who escalates too early?" | JD | [inferred] "trained new tellers on our escalation script" | The coaching you have done is with tellers, so say that first. Then a plan: listen to the escalations, agree the rule, check it after a month. Answer slot: if you coached a supervisor on an escalation, say what you did. If you did not, say so plainly. | F5. The JD asks for supervisor coaching, and this is where the transferability gap shows. |

### Reverse questions

- "How will the move to hubs change how complaints reach your team?" Why it lands: it shows you read the brief, and it asks for the manager's view rather than a summary.
- "What would you need from me in the first 90 days?" Why it lands: it shows you are planning around the manager's needs, not your own.

## Round 3: panel of two branch managers (60 minutes, including the 20-minute case)

### Persona weights

| Persona | Weight | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|---|
| Case / Strategist | 4 | The 20-minute escalation case | High. The recruiter named this case explicitly. | Clarify, then the member, then the fix, then the record. |
| Values / Behavioural | 3 | Each value scored separately | High. The recruiter said the panel is also the values round. | Map each value to a scaffold with its honest branch. |
| Peer Evaluator | 2 | Seams between branches and the contact centre | Medium. Two branch managers sit beside the role, not above it. | Propose seam principles, not pretend to know the seam. |

### Bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | The 20-minute case: a complaint escalation (the panel's live problem; exact wording unknown until the round). | CASE | [generic] | Structure: clarify what the member needs and what has been done so far (2 minutes); say who now owns the fix; decide what the member is told and how, in plain words; name the fix and the cause; say what you would record. Use no facts about the case that were not given to you. | The case is the most heavily weighted event in round 3. |
| P2 | Follow-up: "The fix sits with the other branch. What do you do?" | CASE | [generic] | Hold ownership: you keep hold of the complaint until it is solved, even when the fix is elsewhere. Say who you would call first and what you would tell the member. | Own the Fix, under pressure from a branch manager who may have the fix. |
| P3 | Follow-up: "What would you tell the member, and what would you not say?" | CASE | [generic] | Say the plain version first, in two sentences. Then one thing you would not say and why, in plain words. | Plain Words, tested inside the case. |
| P4 | "Tell me about a time you decided something from a member's side." | VAL | [generic] | The same selection scaffold as M1: pick one decision from your log, or give the nearest thing your material carries and say plainly that no story came to mind. | Members First, asked by a second person. |
| P5 | "How would you keep a branch's local members in view when a network changes?" | VAL | [generic] | Name what you would find out about the town before the change, and who you would ask. Say plainly if you do not know the town. | Neighbours, Not Numbers, tested against the hub move in the brief. |
| P6 | "Give us the two sentences you would use to tell a member their complaint is not upheld." | VAL | [generic] | Two plain sentences, then the next step for the member. No story needed. | Plain Words, tested live. |
| P7 | "Where would you expect the seam to be between your work and a branch manager's?" | JD | [generic] | Name the seam the JD itself describes: complaints that run across branches. Propose one principle for who holds a complaint when it crosses. Do not claim to know their process. | Peer Evaluator, on the across-branches requirement. |
| P8 | "How would you coach a branch supervisor on escalations?" | JD | [inferred] "trained new tellers on our escalation script" | The coaching you have done is with tellers. Say that, then a plan for supervisors. Answer slot: if you coached a supervisor on an escalation, say what you did. If you did not, say so plainly. | F5. Same gap as M8, asked by a peer. |

### Reverse questions

- "What could a new person do in their first month that would genuinely help your branch?" Why it lands: it is the reciprocity question a peer will weigh most. It turns the panel into a working conversation.
- "Where do complaints usually move between a branch and the contact centre?" Why it lands: it asks the panel for the seam, which you could not know from outside.

## Coverage: JD requirements to question IDs

| JD requirement | Covered by |
|---|---|
| 4+ years in financial-services customer operations | S1, S6 |
| Experience handling regulated complaints | S4, M2, M7 |
| Confident presenting to senior leaders | S3 (F8 is a stated gap; no rehearsal line can change it) |
| Comfortable with Excel reporting | M7 |
| Own the complaints process end to end across branches and the contact centre | M4, P1, P2, P7 |
| Report monthly on complaint volumes and resolution times | M7 |
| Coach branch supervisors on escalations | M3, M8, P8 |
| Work with digital teams on self-service journeys | S7 (no story; discovery gap F9 stands) |

## Sources

**Provided documents:** your message, containing the job description text, the values as copied from ashgrovecu.org/about/values on 11 November 2026, the recruiter's email, your summary of the July 2026 strategy brief, and your background.

**Research tier:** L1 (default). Searches 0 of 6, fetches 0 of 2. No search was run because the material in hand fixes every target.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | Values cheat sheet. The values page text is in your message, so no search was needed. Note: it was copied this morning, and I have not checked it live. |
| 2. Ashgrove interview process, customer operations | skipped | Round structure and persona weights. The recruiter's email fixes the three rounds and their lengths. |
| 3. Ashgrove strategy and recent news | skipped | Grounding brief. Your summary of the July 2026 brief covers the current priorities. |
| 4. Interviewer names | n/a | No names given. Round 2 and round 3 personas are assigned from the relationship priors and the recruiter's description. |
| 5. Representative customer operations role JD | skipped | The job description you sent fixes the fit snapshot and the JD-tagged questions. |

## Upgrade menu

- The strategy brief itself, pasted → the grounding brief checks against the wording, not your summary of it.
- The names of the two branch managers and of the Head of Member Services → personas weighted from their public footprint, and a tailored reverse question for each.
- The recruiter's note on the case's format or any materials → P1 to P3 rehearse against the real format.
- The figures on your spreadsheet (volumes or resolution times), if you can share them → F6 and M7 gain a figure to defend, with its own assumption.
- A dossier (see the offer in the message) → the objections and gaps in this pack carry forward into later sessions.
