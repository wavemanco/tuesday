Your prep pack is saved as /tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-tuesday-part-2-rooms-case-8-denied-c52af751/8d4ea7dc-d915-4d3f-b06b-229ffa545837/scratchpad/ashgrove-credit-union_member-experience-lead_interview_pack.md. I built it as a three-round prep, one section per round, since you have the schedule.

Web search was refused in this session, so the values and strategy checks didn't run. The pack uses your pasted values text and your summary of the strategy brief, and its Sources section says so.

Two things to rehearse first. M5 is the scope objection: no contact-centre work and one branch's complaints log against an end-to-end job. F6 is that you've never presented above regional level. Say both plainly, then give the plan.

Say the word and I'll run a drill on M5 with the Head of Member Services. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove-credit-union_member-experience-lead_interview_pack.md -----
# Interview prep pack: Member Experience Lead, Ashgrove Credit Union

**Rounds:** three, on 20 November 2026 (loop mode). Built 11 November 2026.
**Interviewers:** not yet named. Round 1 is the recruiter. Round 2 is the Head of Member Services, who would be your manager. Round 3 is a panel of two branch managers.
**Changelog:** first version, no regeneration.

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored: VAL (values), EXP (your past work, tested for attribution), JD (the job's stated requirements), CO (company and strategy), CASE (a live problem).
- Guidance is scaffolding, not a script. Rehearse what you actually did, in your own words.
- Where guidance says "answer slot", the interviewer may ask you to say how something was done. Answer from your own experience. If the step was not yours, or did not happen, say so plainly.

## Prep at a glance

The panel is the values round. The recruiter's email says the panel "score[s] against the four values", so the values cheat sheet sits in Round 3.

Three things will decide how the rounds go, and all three are in the fit snapshot:

1. **Scope.** The JD asks for end-to-end ownership across branches and the contact centre. Your material shows one branch's formal complaints log (F2), and no contact-centre work (quoted in F1 and M5).
2. **Senior presentations.** You have never presented above regional level (F6). Say that plainly and say what you would do about it.
3. **Your spreadsheet.** It is the strongest concrete thing you have for the reporting requirement (F3, F7). Rehearse exactly what it counts and what was yours.

**Highest-ROI prep: M5.** It is the objection most likely to be asked in some form, and it is the one the whole loop turns on. Rehearse the scope answer until it is plain and non-defensive.

## Fit snapshot

Requirements are quoted from the JD. Evidence is quoted from your own message. Gap and bridge language is what you may say aloud.

No requirement in the JD is a gate term such as location, travel, schedule or credential, so the snapshot has no hard-gate row. If the role lists one, tell me and it will be added.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" (JD) | "6 years in retail banking, the last 3 as branch supervisor" (your message) | medium | [grounded] | presentation | Say "six years in retail banking, the last three as a branch supervisor", in those words. "Customer operations" is the JD's phrase, not yours, so do not claim operations-team or contact-centre work. Expect a probe on whether branch service counts. |
| F2 | "Own the member complaints process end to end across branches and the contact centre" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | transferability | Adjacent work: one branch's formal log, which is the front of the process, not the end-to-end span across branches and the contact centre. Words: "I handled the branch's formal complaints log." Answer slot: the end-to-end line makes a probe likely on what happened after a complaint left the log. If you did any of that, say which and how. If not, say so and say where your part stopped. |
| F3 | "report monthly on complaint volumes and resolution times" (JD) | "I built the monthly complaints spreadsheet our regional manager uses." (your message) | medium | [grounded] | presentation | The quote reaches monthly complaint reporting. It does not say resolution times. Words: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: the JD names resolution times, so expect "did it count how long complaints took?" If it did, say which measure and how it was counted. If not, say so and say what you would measure first. A redacted copy of the spreadsheet would make this inspectable (see upgrade menu). |
| F4 | "coach branch supervisors on escalations" (JD) | "trained new tellers on our escalation script" (your message) | medium | [grounded] | transferability | Adjacent work: you trained tellers, not supervisors. Words: "I trained new tellers on our escalation script." Do not stretch this into coaching supervisors. Answer slot: if you ever coached a supervisor on an escalation, say how. If not, say so, and say what you would do first with a supervisor. |
| F5 | "experience handling regulated complaints" (JD) | "I handled the branch's formal complaints log" (your message) | low | [inferred] | discovery | Your material says "formal", not "regulated", and does not show whether the log carried any regulatory requirement. Never assert regulated-complaints experience. Answer slot: if the log carried a regulatory requirement, say which and what you did with it. If it did not, say so plainly. |
| F6 | "confident presenting to senior leaders" (JD) | "I've never presented to anyone above regional level." (your message) | none | [grounded] | capability | A gap you stated. Words: "I haven't presented to anyone above regional level." Then how you would learn it, said as a plan and never as a past. Do not add a presentation you did not give. |
| F7 | "comfortable with Excel reporting" (JD) | "I built the monthly complaints spreadsheet our regional manager uses." (your message) | medium | [grounded] | presentation | The material says "spreadsheet", not Excel. Use the quote's own words. Do not name Excel functions or skills you have not stated. |
| F8 | "work with digital teams on self-service journeys" (JD) | none given | none | [grounded] | discovery | Silence, not a stated gap. Answer slot: if you worked with a digital team on any journey, say which and what your part was. If not, say so, and say what you would do first. The strategy's digital shift (quoted under Grounding brief) raises the stakes. |

## Prohibited claims

Each entry is an inflated form of something you wrote, or a gap you stated. Do not say these, in any form.

| Not coached | Basis | Honest form |
|---|---|---|
| End-to-end ownership of the complaints process | Inflated form of F2 | F2's quote at its own scope: "I handled the branch's formal complaints log." My observation, not words for you: your material says one branch's log, not the process. |
| Owned resolution-time reporting | Inflated form of F3 | F3's quote at its own scope. Resolution times are an answer slot only. |
| Coached supervisors on escalations | Inflated form of F4 | F4's quote: "I trained new tellers on our escalation script." |
| Handled regulated complaints | Inflated form of F5 | F5 only: the log, described as "formal". |
| Six years in customer operations | Inflated form of F1 | "six years in retail banking, the last three as a branch supervisor" |
| Excel expertise | Inflated form of F7 | "I built the monthly complaints spreadsheet our regional manager uses." |
| Presented to senior leaders | Negative you stated, F6 | "I haven't presented to anyone above regional level." No slot about presenting above that. |

## Grounding brief

From your message (a summary of Ashgrove's July 2026 strategy brief, as the recruiter sent it; the brief itself is not in hand, so the wording below is yours, not theirs):

- "move 40% of member service to digital channels by 2028"
- "consolidate eight branches into five hubs over 2027"
- "launch a small-business lending product in Q1 2027"
- "the main competitive pressure is app-only banks"

Use these terms. Do not claim to know the brief's detail beyond them. Check the wording against the brief before the interview.

## Values cheat sheet (Round 3)

The recruiter's email documents a values-style round, so this section applies. Official names are from your pasted values text (copied from ashgrovecu.org/about/values on 11 November 2026). None of your quoted sentences carries a story for these values yet, so each row is a selection scaffold with an honest branch.

| Value (official name) | Working meaning (paraphrase) | Your mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter. | Scaffold: pick a time you decided from the member's side when a rule or target said otherwise. Name the stake and what you did. If none comes to mind, say so plainly, then give the nearest thing your material carries: "I trained new tellers on our escalation script." |
| Plain Words | If a member needs it explained twice, we wrote it wrong. | Scaffold: pick a time a member came back with the same question. What did you change, and what did you say? If none comes to mind, say so plainly, then give the nearest thing your material carries: "I built the monthly complaints spreadsheet our regional manager uses." |
| Neighbours, Not Numbers | Every branch is part of its town. | Scaffold: pick a time a branch-level decision affected people locally, and what you weighed. If none comes to mind, say so plainly, then give the nearest thing your material carries: "the last 3 as branch supervisor." Do not extend that into local-community work. |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved. | Scaffold: pick a problem you found that was not yours to fix, and say where you kept hold of it and where you stopped. If you never kept hold to the end, say so. Nearest thing your material carries: "I handled the branch's formal complaints log." Do not say "resolved" unless you did. |

## Question banks

Provenance comes first in each row. Guidance uses only quoted sentences, scaffolds, or answer slots. Rationale refers to the fit snapshot by row ID only.

### Round 1: Recruiter screen (30 min, 20 November)

Persona weights: Conversational 4, Skeptic 2, Data-Driven Prober 2, so 8 questions. The recruiter screen is a light, friendly register, and the scoring is still real. Relationship prior: conversational plus light skeptic. The CV's spreadsheet claim earns two prober questions.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R1 | "So, walk me through the journey to here." | EXP | [grounded] "6 years in retail banking, the last 3 as branch supervisor"; "I handled the branch's formal complaints log and trained new tellers on our escalation script." | A 90-second arc in your own words. Six years in retail banking, the last three as a branch supervisor. Then the two things your material carries: the formal complaints log, and training tellers on the escalation script. Do not add anything in between. | F1, F2 and F4 are the arc's sentences. The biography question is scored on precision, not on drama. |
| R2 | "What's drawn you to a member-facing role at a member-owned credit union?" | JD | [generic] | Answer about what you have seen from the member side, and what you want to do next. Make no claim about past membership, volunteering, or community work. | No candidate claim sits in this question, so it carries a generic label. Motivation is scored against the values, so tie it to what you would do, not what you believe about them. |
| R3 | "What are you playing with in Excel these days?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Name the spreadsheet in its own terms. Say what it holds if you can name it. If you have used other Excel features, name only what you have used. If you have not, say so. | F7. A casual question on a JD requirement is still scored. |
| R4 | "Which of the responsibilities in the role would you want to start with?" | JD | [grounded] "Own the member complaints process end to end across branches and the contact centre" (JD); "I handled the branch's formal complaints log" (your message) | Pick one part, say why, and tie it to what you actually did. If you start with the branch's formal complaints log, say so in those words. Do not describe the end-to-end process as yours. | F2. Shows you read the scope; does not claim it. |
| R5 | "You've never worked in a contact centre. What makes you the right person for this?" | JD | [grounded] "Never worked in a contact centre" (your message) | Acknowledge it: "I haven't worked in a contact centre." Then what your branch work does give you, using only F1 and F2's quotes, and a plan for the contact-centre side, said as a plan. | F4 and F6's plain acknowledgment logic apply. The question presupposes a stated negative, which you gave. |
| R6 | "Your complaints work is one branch's log. How would you run it across eight branches and a contact centre?" | JD | [grounded] "I handled the branch's formal complaints log" (your message); "consolidate eight branches into five hubs over 2027" (your message) | Hold the answer to the log and the scale. Say what you would do first and what you would need to know, without claiming a process you did not run. If you ran any part beyond the branch log, say which. | F2 and the strategy's branch consolidation. The "eight branches" premise comes from your summary of the brief. |
| R7 | "Walk me through what your spreadsheet counts, and how it counts it." | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Answer slot: say what the spreadsheet counts, in your own words. If you decided what it counted, say which decisions were yours. If you did not decide them, say so plainly and say who did. | F3 and F7. This is the defend-the-number slot: how it was counted, what it is sensitive to, the assumption you would defend least, which part was yours. |
| R8 | "Did your monthly figures include how long complaints took to close? If so, how did you count it?" | JD | [grounded] "report monthly on complaint volumes and resolution times" (JD); "I built the monthly complaints spreadsheet our regional manager uses." (your message) | Answer slot, both branches allowed: if it did, say which measure, how it was counted, and which part was yours. If it did not, say so plainly and say what you would measure first. | F3. Premised question kept open on purpose, because your quote does not say resolution times. |

Reverse questions (Round 1): see the reverse-question table below.

### Round 2: Head of Member Services (45 min, mostly behavioural)

Persona weights: Values/Behavioural 4, Skeptic 3, Case/Strategist 2, so 9 questions. The relationship prior for a hiring manager is case plus skeptic, but this round is described as mostly behavioural, so Values/Behavioural leads. The skeptic weight reflects a manager who is buying capability and derisking gaps.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| M1 | "Tell me about a time you had to tell a member something they didn't want to hear." | VAL | [generic] No sentence of yours carries this. Nearest: "I trained new tellers on our escalation script." | Selection scaffold: pick a time, name the stake, say what you said and what the member did. If none comes to mind, say so plainly, then give the nearest thing your material carries. Do not supply the outcome. | Plain Words is the value. No quote carries a story, so this is a scaffold, not a mapped answer. |
| M2 | "Tell me about a time you put a member's need ahead of a rule or a target." | VAL | [generic] No sentence of yours carries this. | Selection scaffold: pick a time you chose the member's side when a rule or target said otherwise. Name the rule, the choice, and what it cost. If none comes to mind, say so plainly. | Members First, Always. No candidate claim is made, so the guidance makes none. |
| M3 | "When did a complaint carry a deadline or a rule you had to follow? Walk me through it." | JD | [generic] No sentence of yours carries this. Nearest: "I handled the branch's formal complaints log." | Selection scaffold: pick a complaint with a deadline or a rule and say what you did about it. If the log had no such requirement, say so plainly, and do not use the word "regulated" for it. | F5. The JD names regulated complaints. Your material says "formal", so this is a discovery question. |
| M4 | "Tell me about a problem you found that wasn't yours to fix. What did you do with it?" | VAL | [generic] No sentence of yours carries this. Nearest: "I handled the branch's formal complaints log." | Selection scaffold: name the problem, where you kept hold of it, and where you stopped. Own the Fix requires you to say whether it was solved. If you did not keep hold to the end, say so. | Own the Fix. A scaffold because your material does not show whether you saw a problem through. |
| M5 | "You've never worked in a contact centre, and you've handled one branch's log. Why should we hire you for an end-to-end role?" | JD | [grounded] "Never worked in a contact centre" (your message); "I handled the branch's formal complaints log" (your message) | Highest-ROI prep. Hold position: "I haven't worked in a contact centre." Then the branch work you did, using F2's words. Then a plan for the contact-centre side, said as a plan, not a past. Hold through two follow-ups; concede the scope gap specifically, do not fold on the work you did. | F2 and F1. The most predictable objection: it is the JD's headline scope against your material's thinnest part. |
| M6 | "Presenting to senior leaders is in this role. Where are you on that?" | JD | [grounded] "I've never presented to anyone above regional level." (your message) | Say it plainly: "I haven't presented to anyone above regional level." Then how you would learn it, as a plan. Do not describe a presentation you did not give. | F6. Stated gap; plain acknowledgment only. |
| M7 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "I've never presented to anyone above regional level." (your message); "I handled the branch's formal complaints log" (your message) | Name one gap, not all of them. Use only the stated negatives: presenting above regional level, or the contact-centre side. Then a concrete first step. Do not add a gap you did not state. | Skeptic question. You choose the gap, which keeps it honest and contained. |
| M8 | "Two of your branches are being consolidated into a hub in 2027. How would you find out whether complaints are getting worse?" | CASE | [grounded] "consolidate eight branches into five hubs over 2027" (your message) | Clarify the hub design. Then a baseline: complaint volumes and resolution times by branch, the JD's own measures. Then segment by complaint type and channel, and watch the members who lose a local branch. Name the leading indicator you would check first. No past claim, so no coaching of experience. | CO and CASE. Live problem on the JD's reporting requirement, grounded in the strategy line. |
| M9 | "The strategy moves 40% of member service to digital by 2028. Which contacts would you move first, and which would you keep in person?" | CO | [grounded] "move 40% of member service to digital channels by 2028" (your message) | Segment by contact type, and say what must stay in person and why. Say what you would need from the digital team, as a plan. Do not claim digital-team experience (F8 is a slot). | F8 and the strategy's digital target. The strategy is your summary of the brief; check it before you quote it. |

Reverse questions (Round 2): see the reverse-question table below.

### Round 3: Panel of two branch managers (60 min, values round, includes a 20-minute case)

Persona weights: Values/Behavioural 4, Case/Strategist 3, Peer Evaluator 2, Pressure 2, so 11 questions. The panel is the values round, and it scores against the four values. Branch managers are the people you would coach, so the peer register matters.

The 20-minute complaint escalation case is P5 to P7. Plan roughly 10 minutes on the case and 10 on follow-ups.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Tell me about a time you decided from the member's side of the counter, when a rule said otherwise." | VAL | [generic] No sentence of yours carries this. | Members First, Always. Selection scaffold: name the rule, the decision, and what it cost you. If none comes to mind, say so plainly, then give the nearest thing your material carries. | Values round. A scaffold, because no quote carries this story. |
| P2 | "Tell me about a time a member came back with a question you thought you had already answered." | VAL | [generic] No sentence of yours carries this. | Plain Words. Selection scaffold: what you wrote or said the first time, what changed, and what the member did. If none comes to mind, say so plainly. | If a member needs it explained twice, we wrote it wrong. The scaffold asks for the rewrite, not a claim. |
| P3 | "Tell me about a decision you made that protected a branch's place in its town, even when the numbers pointed the other way." | VAL | [generic] No sentence of yours carries this. | Neighbours, Not Numbers. Selection scaffold: name the number, the local stake, and what you chose. If none comes to mind, say so plainly. Do not describe local-community work your material does not show. | Values round. Scaffold only. |
| P4 | "Tell me about a problem you found that wasn't yours to fix, and where you kept hold of it." | VAL | [generic] No sentence of yours carries this. Nearest: "I handled the branch's formal complaints log." | Own the Fix. Selection scaffold: name the problem, your hold on it, and whether it was solved. Say plainly if you stopped holding it before it was solved. | Values round. Same scaffold as M4, scored against the value this time. |
| P5 | "A member's complaint about a fee has been to the branch twice and to the contact centre once. Three weeks in, they call back angry and say nobody has told them what happens next. You're the Member Experience Lead. Walk us through your first hour, and what you would change in the process." | CASE | [generic] | Clarify first: what the complaint is, what has happened at each stage, and what the member has been told. Then the member's outcome and any timescale that applies. Then one owner and an interim contact. Then the fix, and the root cause. Then the measures you would track, such as time to resolution and repeat contacts. Name the risk of a missed deadline. Make no claim about your own past. | The panel's case. A live problem from the JD's end-to-end line, with no candidate claim, so it carries a generic label. |
| P6 | "Your branch supervisors escalate at different thresholds. How do you set one standard without losing local judgement?" | CASE | [generic] | Clarify what differs and why. Then a standard expressed as principles, with local discretion inside it. Then how you would coach a supervisor when they step outside it. Make no claim about coaching experience. | JD: coach branch supervisors on escalations. F4 is the nearest material, and it does not carry coaching, so this is a generic case. |
| P7 | "Eight branches become five hubs in 2027. Which complaints would you watch in the town that loses its branch?" | CO | [grounded] "consolidate eight branches into five hubs over 2027" (your message) | Name the complaints you would expect to change: access, distance, and the members who cannot use the app. Then say how you would measure them. Say what you would tell the branch manager about the town. Make no claim about hub experience. | Neighbours, Not Numbers meets the strategy. The brief's app-only competitor frames the second half. |
| P8 | "Where's the seam between a branch and your team, and what happens when we disagree about a complaint?" | JD | [grounded] "coach branch supervisors on escalations" (JD) | Peer register. Propose seam principles, not a seam you have seen. For disagreement, use a story only if you have one; your material does not carry one, so if you have none, say so and say how you would handle it. | Peer Evaluator. The panel are branch managers, so the seam is their question. |
| P9 | "When a complaint is fixed across two teams, how do you handle credit?" | JD | [generic] No sentence of yours carries this. | Peer register. Selection scaffold: what you would share, and what you would claim for yourself. If you have no example, say so. | Peer Evaluator. Scaffold only. |
| P10 | "Sixty seconds: why should we trust a Member Experience Lead who has never worked in a contact centre and never presented above regional level?" | JD | [grounded] "Never worked in a contact centre" (your message); "I've never presented to anyone above regional level." (your message) | Pause. Restate the question in your own words. Hold on what you did: the log, the training, the spreadsheet. Concede both gaps specifically. Then a plan. Hold through two follow-ups before conceding anything more. | Pressure. Two sourced negatives in one question; name both, and do not soften either. |
| P11 | "That spreadsheet: how much of the result was actually you?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." (your message) | Hold: "I built the monthly complaints spreadsheet our regional manager uses." Then the answer slot: which part was yours, and what the regional manager did with it. Concede any uncertainty specifically, and do not fold on the build. | Pressure on attribution. The hold-then-concede structure applies. |

Reverse questions (Round 3): see the reverse-question table below.

## Persona table

| Round | Persona | Weight | How it shows up | Reasoning | Counter-strategy |
|---|---|---|---|---|---|
| 1 Recruiter | Conversational | 4 | Friendly biography and motivation questions | Recruiter screen prior: logistics and motivation in a friendly register | Pre-scripted 90-second arc. Treat casual questions on JD topics (R3) as scored. |
| 1 Recruiter | Skeptic | 2 | "Never worked in a contact centre" as a knockout check | Light skeptic prior; the recruiter screens the gap early | Plain acknowledgment, then the bridge from F1 and F2 |
| 1 Recruiter | Data-Driven Prober | 2 | Asks what the spreadsheet counts | The CV's spreadsheet claim is a magnet for probes | Answer slot, precise attribution, the assumption you would defend least |
| 2 Head of Member Services | Values/Behavioural | 4 | Scenario probes, STAR-shaped | Mostly behavioural round, and the manager scores the job's behaviours | Scaffolds with honest branches. Name the stake and the outcome only if you have them. |
| 2 Head of Member Services | Skeptic | 3 | Scope and presenting gaps | The manager is buying capability and derisking gaps | M5 is the highest-ROI prep. Hold, then concede specifically. |
| 2 Head of Member Services | Case/Strategist | 2 | Hub consolidation and digital target | Strategy questions from the manager, grounded in the brief summary | Clarify, baseline, segment, leading indicator |
| 3 Panel | Values/Behavioural | 4 | The four values, one question each | The panel scores against the values | Scaffolds with honest branches. Do not borrow stories. |
| 3 Panel | Case/Strategist | 3 | The 20-minute escalation case, hub and escalation-threshold cases | The panel's case, and branch managers ask case questions about their own problems | Clarify, objective, segment, approach, measures, risk |
| 3 Panel | Peer Evaluator | 2 | Seams, disagreement, credit | Branch managers are your future peers and the people you would coach | Reciprocity, seam principles, no invented disagreement story |
| 3 Panel | Pressure | 2 | Sixty-second challenge, attribution challenge | Panel composure test, and the two sourced gaps are easy targets | Pause, restate, hold two follow-ups, concede specifically |

Interviewer names are not yet known, so there is no interviewer read and no personal persona weighting. The upgrade menu says what a name would add.

## Reverse questions

Five per round. One reciprocity question for the peer-facing panel. None is tied to an interviewer's own career path, because no interviewer is named yet.

| Round | Question | Why it lands |
|---|---|---|
| 1 Recruiter | "What does the team look like in the first month, and who would I be working with most?" | Shows you are planning for the role, not only interviewing for it |
| 1 Recruiter | "Which parts of the three rounds does the recruiter see as the strongest test?" | Lets the recruiter tell you what they score, which is a preparation signal |
| 1 Recruiter | "How is the hub consolidation shaping which complaints the role will own?" | Ties the strategy to the JD's scope, and asks rather than assumes |
| 1 Recruiter | "What has the team learned from the last process change?" | Shows interest in the operating history, without claiming any |
| 1 Recruiter | "What would a good first six months look like from the recruiter's side?" | A success test, asked of someone who has seen many candidates |
| 2 Head of Member Services | "What would a good first 90 days look like, from where you sit?" | Turns the interview into a planning conversation |
| 2 Head of Member Services | "How do the complaint figures currently reach senior leaders?" | Your presenting gap becomes a question about the process, not a confession |
| 2 Head of Member Services | "Which branches carry the most escalations at the moment?" | Shows you are thinking about the JD's scope |
| 2 Head of Member Services | "What would make the hub changes a success for complaint resolution?" | Connects the reporting requirement to the 2027 plan |
| 2 Head of Member Services | "Where would you most want this role to help your supervisors?" | Asks what the manager needs from the coaching requirement |
| 3 Panel | "What would the first month of this role need to look like for your branches to notice?" (reciprocity) | Asks what the peers need. The reciprocity question the peer register calls for |
| 3 Panel | "Where do complaints currently stall between the branch and the contact centre?" | Shows you are thinking about the end-to-end seam |
| 3 Panel | "Which of the four values do your branches find hardest to live?" | Shows values fluency, and asks for their view |
| 3 Panel | "What would you want me to bring to a branch manager on day one?" (reciprocity) | Makes the panel's needs the first subject |
| 3 Panel | "What has gone well in escalations this year, and what would you change?" | Lets the panel tell you what they value, which they will score against |

## Requirement coverage

| JD requirement | Questions covering it |
|---|---|
| 4+ years in financial-services customer operations | R1, R5, F1 |
| Own the member complaints process end to end across branches and the contact centre | R4, R6, M5, M7, P5, P10 |
| Report monthly on complaint volumes and resolution times | R7, R8, M8 |
| Coach branch supervisors on escalations | P6, P8 |
| Work with digital teams on self-service journeys | M9 (F8 is an answer slot) |
| Experience handling regulated complaints | M3 (F5 is a discovery question) |
| Confident presenting to senior leaders | M6, P10 |
| Comfortable with Excel reporting | R3, P11 |

## Values and strategy coverage

- Each value has a Round 3 question: P1 to P4.
- The strategy's four quoted lines have questions: branch consolidation (M8, P7, R6); digital shift (M9); small-business lending: none (not in the JD, not in your material); competitive pressure from app-only banks: P7 touches it.

## Sources

- **Provided documents:** the JD, the values text, the recruiter's round email, the strategy-brief summary, and your background message. All came in your message or as pasted text.
- **Searches sent, both refused:**
  - "Ashgrove Credit Union 2026 strategy digital branch hubs small business lending" (strategy): refused
  - "ashgrovecu.org about values Members First Always Plain Words Neighbours Not Numbers Own the Fix" (values): refused

## Research tier and target accounting

Research tier: L1 — searches 2 of 6, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove Credit Union values` | unavailable | Both calls refused (see Sources). Would have checked the pasted values text against the official page, and fixed the four official names. The pasted text is used as given. |
| 2. `Ashgrove Credit Union interview process member experience lead` | skipped | The recruiter's email fixes the three rounds, their lengths, who runs each, and that the panel is the values round |
| 3. `Ashgrove Credit Union strategy` | unavailable | Call refused (see Sources). Would have moved the CO questions and the grounding brief, which now rest on your summary of the brief |
| 4. `{interviewer name} Ashgrove Credit Union` | n/a | No interviewer names given, so no query could be formed |
| 5. representative JD for this title | skipped | The JD is supplied and fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- A redacted copy of your complaints spreadsheet → F3 and F7 can move from medium to high, and R8 and R7 can be answered from the artifact instead of from memory.
- The recruiter's full strategy brief, or the sections on hubs and digital → the grounding brief and M8, M9 and P7 rest on the document, not your summary.
- The interviewers' names → an interviewer read and per-member persona weights for the panel, plus reverse questions tied to their career paths.
- Whether the role is hub-based or branch-based, and any location or travel term in the JD → if the JD lists one, it becomes a gate row, surfaced, never bridged.
- One story for each value → the four Round 3 scaffolds (P1 to P4) become mapped answers.
- A time you worked with a digital team, or one you handled a regulated complaint → F8 and F5 move from answer slots to mapped answers.
- Deep research (L2): up to 6 more searches and 2 more fetches, several more minutes, covering the strategy brief, interviewer footprints, loop reports and recent org changes. Web search was refused this session, so an L2 run would have failed here too. Ask again once search is enabled.

Dossier offer and drill offer follow in the message.
