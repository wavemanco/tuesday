Your prep pack is saved as `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-tuesday-part-2-rooms-case-7-canned-98ae1b7e/49d754c5-5f17-4782-9f1a-40ee6b75a19a/scratchpad/saltmarsh_live_operations_producer_interview_pack.md`. I built it for the hiring-manager round you described.

Three things from the research shape the whole prep:

- **The 60 minutes are one session with Tobias, in two halves.** Saltmarsh's careers page calls it the "Outage Hour": a live-incident tabletop on a simulated outage during a live event, then a values conversation. There is no take-home. Practise a 20-minute incident walkthrough and a values conversation.
- **Their three values are published:** Players Before Plans, Ship the Patch Not the Promise, and Leave the Build Greener. Your checklist sentence maps best to the third. Your material does not contain a story that carries the first two, so the pack gives you selection scaffolds with an honest "if none comes to mind, say so" branch rather than invented stories.
- **Project Larkspur (September 2026)** moves two titles onto one shared events calendar from February 2027 and retires per-title event teams. The JD's "two of our mobile titles" may be those titles, but the JD doesn't say so, so the pack treats it as conditional.

Tobias gave a GDC 2026 talk, "Patch Notes Are a Promise", arguing a live team is judged by how often its patch notes match what shipped. Expect honesty about what shipped to come up. I only saw the talk listing, not the full talk.

Your gaps are the ones the pack spends most time on. "Never led a team" is the likeliest objection, so it gets the deepest rehearsal: say "I haven't led a team," then give a plan. The pack never lets you claim the two-title calendar, the post-event review, or the KPI ownership. The material shows one title's content drops, presenting retention numbers, and a checklist, and the pack keeps to those.

Research was the default light pass: four searches and two page fetches. I did not run a deep pass on the strategy or the talk. The pack lists what would sharpen it in the upgrade menu.

If you can send a copy of your release checklist or the calendar you ran, the pack can cite them directly. That moves your strongest claims from medium confidence to something you can show.

Offers, not pushed:
- I can play the Skeptic on C1, the team-leadership question, as a live drill.
- I can save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions.
- I can convert the pack to a Word document.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh_live_operations_producer_interview_pack.md -----
# Interview pack: Live Operations Producer, Saltmarsh Games

Interviewer: Tobias Wrenfield, Head of Live Operations (hiring manager). Round: 60-minute hiring-manager interview, Friday.
Built for: Femi. Session mode. Built at the default research tier (L1); no deep-research pass was run.

## How to use this pack

Personas describe how a question arrives. Types describe what it scores. Type key:

- **VAL**: behavioral / values alignment, against Saltmarsh's published values
- **EXP**: your own experience, checked for attribution
- **JD**: a stated responsibility or qualification of this role
- **CO**: company and strategy knowledge
- **CASE**: a live problem from the role, solved aloud

Guidance is scaffolding, not a script. Answer in your own words.

## The round, from Saltmarsh's own page

Saltmarsh's interviewing page says every loop is a recruiter call, then "the Outage Hour: a single 60-minute interview with the hiring manager, a live-incident tabletop on a simulated outage during a live event, then a values conversation. There is no take-home." So the 60 minutes are one case block and one values block, with Tobias. Plan for both halves.

## Persona table

| Persona | How it shows up here | Weight | Reasoning | Counter-strategy |
|---|---|---|---|---|
| Case / Strategist | The live-incident tabletop, then live problems on the calendar | 5 questions | The page names the tabletop. A hiring manager buys capability, so this is the top weight | Clarify the incident first, then the decision and its owners. Say the impact before the fix |
| Values / Behavioral | The values conversation, against three published values | 4 questions | The page names the values conversation. Tobias's public talk argues that a live team is judged by its patch notes (see reading below), so honesty about what shipped is likely to be probed | Map a story to a value only where a quoted sentence carries it. Where none does, say so plainly |
| Skeptic | Quiet probes on the gaps: team leadership, in-app purchases, the live-service question | 4 questions | Hiring-manager prior. Your background has three gaps a manager will check: team leadership, IAP, and whether the puzzle title ran on live-service terms | Rehearse the team-leadership objection until it is plain. Acknowledge the negatives you actually stated, then give a ramp plan |
| Data-Driven Prober | Follow-ups on the retention numbers and the checklist | 3 questions | Lower than a generic hiring manager because the talk and the page centre on process and honesty, not metric methods. A QA-background leader may still test a number | Name the weakest assumption behind each figure before he does. Say plainly what you did not count |
| Pressure | Time-boxed challenge on why you over someone who has led a team | 2 questions | Low prior for a hiring manager; kept for composure | Hold the calendar record through two follow-ups. Concede the team gap specifically, not in general |
| Conversational | The opener, and the "what are you playing" question | 2 questions | Every pack touches all plausible personas; casual questions are still scored | Use the 90-second arc. Do not invent a game claim |

## Reading the interviewer

Public footprint only:

- Role: Head of Live Operations at Saltmarsh Games (saltmarshgames.com, and the GDC 2026 talk listing).
- Talk: "Patch Notes Are a Promise" (GDC 2026). Its argument, as the listing states it: "a live team is judged by how often its patch notes describe what actually shipped." Previously a QA lead at a console studio, per the same listing.

Practical implications:

1. His talk and Saltmarsh's "Ship the Patch Not the Promise" value are one theme. Expect honesty about what shipped to be probed, in both halves of the hour.
2. His QA background means the checklist question (D2) is a home-ground question for him.
3. Shared vocabulary: QA and the release checklist. The sentence that carries it: "Wrote the release checklist our QA team still uses" (your message). This is a mirror opportunity, not a shared career jump: his QA-to-leadership path is not one you have made, so no jump is offered as shared.

## Grounding brief

Not included. It needs the deep research tier, which was not run.

## Fit snapshot

Requirements are the JD's words, quoted. Evidence is your sentences, quoted. Your two negatives, "Never led a team" and "never worked on a game with in-app purchases", are stated absences and are handled in the prohibited list.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | medium | [grounded] | transferability | Your material says one title's weekly content drops, not two titles' live-events calendar. Say it at that scope: "For two years I ran the weekly content-drop calendar for our main title." Answer slot: if you planned any event beyond the content drops, or ran a second title's calendar, say which and how; if not, say so and describe how you would run two titles |
| F2 | "experience running a content calendar" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | medium | [grounded] | none | No gap: your sentence already reaches the requirement. Confidence is medium because the calendar exists as an artifact you have not shown anyone. Bring it |
| F3 | "3+ years producing live-service games or apps" (JD) | "4 years as an associate producer at a puzzle-game studio" (your message) | medium | [grounded] | discovery | Your material shows four years and a puzzle game, not whether the game ran on live-service terms. Answer slot: if the title ran on ongoing content drops, say so in your own words; if it was not live-service, say so plainly and say what carries across: the weekly calendar |
| F4 | "comfortable with player-retention metrics" (JD) | "Presented the monthly retention numbers to the studio head" (your message) | medium | [grounded] | presentation | Your sentence already reaches the requirement in other terms. Say it as it is: "I presented the monthly retention numbers to the studio head." Do not add how they were counted unless you did the counting |
| F5 | "coordinate design, art, engineering and community teams on each update" (JD) | none given | none | [grounded] | discovery | Your material does not show coordinating design, art, engineering or community on an update. Answer slot: if you did this for any of those teams, say which and how; if not, say so plainly and say how you would set up that coordination for a live update |
| F6 | "manage the release checklist with QA" (JD) | "Wrote the release checklist our QA team still uses" (your message) | medium | [grounded] | none | No gap: your sentence reaches the requirement. Say "I wrote the release checklist our QA team still uses." Confidence is medium: the checklist is inspectable, and you should bring a copy |
| F7 | "own the post-event review and the KPIs it reports" (JD) | "Presented the monthly retention numbers to the studio head" (your message) | medium | [grounded] | transferability | Your sentence carries reporting numbers, not owning a post-event review. Say it at its own scope. Answer slot: if you ran any post-event review, say what it covered and whose decision it was to change anything; if you did not, say so |
| F8 | "clear written communication" (JD) | none given | none | [grounded] | discovery | Your material shows a checklist that QA still uses, but not how clearly you write. Answer slot: name one written piece that someone acted on without asking you a follow-up; if none comes to mind, say so and describe how you would write a release update |
Gate check: the JD names no legal, licence, location or travel term, so no hard gate is shown. "3+ years producing live-service games or apps" is a length of experience, not a gate, so it is graded as F3 above.

## Prohibited claims

Inflated forms of your sentences, and your stated negatives:

| Not coached | Basis | Honest form |
|---|---|---|
| Ran live events across two titles | Inflated form of F1 | "I ran the weekly content-drop calendar for our main title for the last two years." The limit is the pack's observation: your material says one title, not two |
| Owned the post-event review and its KPIs | Inflated form of F7 | "Presented the monthly retention numbers to the studio head." No slot names a review you did not run |
| Managed release sign-off with QA | Inflated form of F6 | "Wrote the release checklist our QA team still uses." |
| Coordinated design, art, engineering and community on updates | Silence in the material, not a stated negative | Answer slot only (F5). Never asserted |
| Experience with live-service products | Inflated form of F3 | "4 years as an associate producer at a puzzle-game studio." The live-service question stays a slot |
| Led a team | Negative you stated: "Never led a team" | "I haven't led a team." Then a plan, said as a plan |
| Worked on a game with in-app purchases | Negative you stated: "never worked on a game with in-app purchases" | "I haven't worked on a game with in-app purchases." Then how you would learn their IAP model |

## Question banks

Question IDs are letter-by-persona, in weight order. Each row's Provenance sits before its guidance.

### Case / Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "It is 7pm during a live event and a reward is granting players double the intended item. Walk me through the first ten minutes." | CASE | [generic] | Structure: confirm scope (how many players, which reward, whether it is still firing); stop the bleed (disable the grant or pause the event); decide hotfix or rollback with QA on the call; decide what to announce and when, announcing what is built, not what is hoped. Makes no claim about your past | The tabletop named on Saltmarsh's page. [generic] because it is a pattern for this kind of incident, not a Saltmarsh incident |
| A2 | "Engagement on a live event drops twenty percent on day three. Where do you start?" | CASE | [generic] | Clarify the metric definition and the cohort first. Split by platform, build and region. Check what shipped in the last 48 hours. Then state one hypothesis and the check that would kill it. Makes no claim about your past | Metric diagnosis is the Case persona's stock problem; a retention-metrics requirement (F4) is what it tests |
| A3 | "How would you lay out the next quarter's events for two titles that share one live-ops group?" | JD | [grounded] "Plan and run the live-events calendar for two of our mobile titles" (JD) | Name the lead times you would plan around: design, art, engineering and community each need a window per update, and QA needs a gate per release. Makes no claim about your past. Answer slot on coordination: F5 | JD requirement directly; the question is conditional, so it presupposes no company fact |
| A4 | "If two titles' calendars came under one live-ops group, what would you change first?" | CO | [grounded] "retires per-title event teams in favour of a single live-ops group" (Saltmarsh news, search result) | Name one change, say why, and say what you would check first. Do not describe a past consolidation. The strategy context is Project Larkspur, announced September 2026, which moves two titles to one shared events calendar from February 2027. Use it as context, not as a premise | CO question on current strategy. Conditional wording, because a news item is not a raising source |
| A5 | "You have a 40-item release checklist and 48 hours. What do you cut, and who signs it off?" | JD | [grounded] "manage the release checklist with QA" (JD) | Risk-based cut: keep what protects players and money, cut what can be verified after release. QA signs off on the cut. Makes no claim about your checklist's history | JD requirement on the checklist. The question tests judgment, not your past |

### Values / Behavioral (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time the calendar and the players disagreed. What did you do?" | VAL | [grounded] "when the calendar and the players disagree, the players win" (Saltmarsh values page); [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | Selection scaffold: pick a time in those two years when a content drop and what players needed pulled apart. Say what moved, whose call it was, and who you told. Answer slot: if no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | Players Before Plans is the first value. F2 is the only story your material carries, and it does not carry the ending, so the answer is a selection, not a fact |
| B2 | "Tell me about a release where what you announced was not what shipped. How did you handle it?" | VAL | [grounded] "we announce what is built, not what is hoped" (values page); [grounded] "a live team is judged by how often its patch notes describe what actually shipped" (Tobias Wrenfield's GDC 2026 talk listing) | Answer slot: if you were part of a release where the announcement and the build diverged, say what happened, what you did, and what the checklist caught or missed. If not, say so plainly, then say how you would make a release announcement match what shipped | Ship the Patch Not the Promise, and his talk's argument. Your sentence "Wrote the release checklist our QA team still uses" is the only one that can carry any part of this, and it does not carry an incident |
| B3 | "Tell me about a time you left a release process better than you found it." | VAL | [grounded] "every release leaves the codebase and the checklist better than it found them" (values page); [grounded] "Wrote the release checklist our QA team still uses" (your message) | Story from your sentence: you wrote the checklist; QA still uses it. The "better than it found them" beat is an answer slot: if you changed the checklist after a release, say what changed and why; if you did not, say so plainly and say what you would change first | Leave the Build Greener. Your checklist is the real story, but the improvement beat needs an event you have to supply yourself |
| B4 | "What does a good post-event review look like to you?" | JD | [grounded] "own the post-event review and the KPIs it reports" (JD) | Sketch the review: what you measured against what target, the attribution limit, and what changes after. Makes no claim about your past. If asked for your own review, the answer slot from F7 applies | Post-event review is a JD requirement; the question is open and asks for a view, not an event |

### Skeptic (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You haven't led a team. What would you do in your first month running a live-ops group?" | JD | [grounded] "Never led a team" (your message) | Acknowledge plainly: "I haven't led a team." Then a plan, said as a plan: meet each team's lead, learn the update cadence, sit in on one release. Do not describe a team you led | The stated negative is the most likely objection to this candidate. This is the highest-ROI rehearsal in the pack |
| C2 | "Which part of this JD are you weakest on today?" | JD | [grounded] "Never led a team" (your message); [grounded] "never worked on a game with in-app purchases" (your message) | Name the two stated gaps plainly: "I haven't led a team." "I haven't worked on a game with in-app purchases." Then the ramp plan for each. Do not add a third gap you did not state | Calibrated candour over bluffing. Both negatives are yours, so they may be said |
| C3 | "Your background is a puzzle game. Did the content calendar run on live-service terms?" | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio" (your message); [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | Answer slot: if the title ran on ongoing content drops, say so in those words; if it was not live-service, say so plainly and say what carries across: the weekly calendar | F3 is the discovery gap. The question's premise is the JD's, and the guidance does not adopt it |
| C4 | "You presented retention numbers to the studio head. Who chose which numbers?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" (your message) | Say what you presented and who chose it, in those words. Answer slot: if you chose the numbers, say which and why; if you did not, say so plainly. Name the assumption behind the figure you would defend least, if you know one | F4's presentation gap. Do not claim the choice of numbers unless you made it |

### Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how the monthly retention numbers were counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head" (your message) | Answer slot: if you did the counting, say how in your own words; if the numbers came from another team's pipeline, say so plainly. Name the assumption you would defend least | F4. A prober asks for the denominator. The honest answer is "I presented them", unless you counted |
| D2 | "Your checklist is still in use. How do you know it catches what it should?" | JD | [grounded] "Wrote the release checklist our QA team still uses" (your message) | Say what you wrote and that QA still uses it. Answer slot: name what it caught on the last release if you know; if you do not track that, say so and say how you would | Home-ground question for a QA-background leader. Keep the answer to what you can show |
| D3 | "What KPIs would you own after a live event, and how would you know they moved because of it?" | JD | [grounded] "own the post-event review and the KPIs it reports" (JD); [grounded] "Presented the monthly retention numbers to the studio head" (your message) | Name the KPI shape and the attribution limit in general terms. Pack observation, in analysis not as words for you: your material shows presenting retention numbers, not owning a post-event review. Answer slot per F7 | The JD's requirement, probed for attribution |

### Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why should we hire you over someone who has led a team?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio" (your message); [grounded] "Never led a team" (your message) | Hold: the calendar record and the checklist, in your own words. Concede the team gap specifically on the second follow-up: "I haven't led a team." Do not fold on the calendar | Pressure persona. Hold-then-concede: hold the position your sentences carry; concede only the stated negative |
| E2 | "That retention figure: how much of it was actually you?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" (your message) | Hold: "I presented the monthly retention numbers to the studio head." Concede: if you did not set the method, say so. Answer slot on the method | F4 under pressure. The hold is only the sentence you wrote |

### Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | JD | [grounded] "4 years as an associate producer at a puzzle-game studio" (your message); [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | Ninety-second arc: the studio, the calendar, the checklist, the retention numbers. Each beat is a sentence you wrote. Do not add a beat | Casual opener, still scored. The arc holds only your sentences |
| F2 | "What are you playing right now, and what would you change in its live calendar?" | JD | [generic] | Name a game you play, and one change you would make to its live calendar, as an opinion. Do not claim to have worked on it | Casual question on the JD's live-calendar work. Prepare one real answer, not a claimed one |

## Requirement coverage

| JD requirement | Questions | Notes |
|---|---|---|
| Plan and run the live-events calendar for two of our mobile titles | A3, A4 | |
| Coordinate design, art, engineering and community teams on each update | A3 | Covered by the planning answer; the answer slot is F5 |
| Own the post-event review and the KPIs it reports | B4, D3 | |
| Manage the release checklist with QA | A5, D2 | |
| 3+ years producing live-service games or apps | C3 | |
| Experience running a content calendar | B1, F1 | |
| Comfortable with player-retention metrics | C4, D1, E2 | |
| Clear written communication | none, and why | No question asks for a written sample: the Outage Hour has no take-home. Covered in the upgrade menu |

## Values / principles cheat sheet

Saltmarsh's three published values, from its values page: Players Before Plans, Ship the Patch Not the Promise, and Leave the Build Greener.

| Value (official name) | Working meaning (paraphrased) | Your story |
|---|---|---|
| Players Before Plans | When the calendar and the players disagree, the players win | Selection scaffold (B1): a time in your content-drop calendar when a drop and player need pulled apart. Honest branch: if none comes to mind, say so and give the nearest thing your material carries. Your sentence: "I ran the weekly content-drop calendar for our main title for the last two years" |
| Ship the Patch Not the Promise | We announce what is built, not what is hoped | Selection scaffold (B2): a release where announcement and build diverged, or the checklist's catch. Honest branch: if you have none, say so. Your sentence: "Presented the monthly retention numbers to the studio head" carries the presenting, not the honesty test |
| Leave the Build Greener | Every release leaves the codebase and the checklist better than it found them | Your sentence: "Wrote the release checklist our QA team still uses" (B3). The improvement beat is a slot: changed after a release, or the first change you would make |

## Reverse questions

Five, each with why it lands:

1. "When a live event's reward goes wrong, who makes the call between hotfix and rollback, and how long does that usually take?" Why it lands: it shows you rehearsed the Outage Hour, and it asks about the decision rights a live-ops producer needs.
2. "Your talk argues a live team is judged by how often its patch notes describe what actually shipped. What do you measure to know that, and what has to change in the checklist to hold it?" Why it lands: it ties his own published path to your one concrete artifact (F6). It is the highest-value reverse question here.
3. "Project Larkspur moves two titles to one shared events calendar from February 2027. How will the calendar owner's remit differ from a per-title team's?" Why it lands: it shows you read the strategy news. Keep the tone a question, not a verdict.
4. "Which two titles does this role cover, and how do their release cadences differ?" Why it lands: it turns the JD's "two of our mobile titles" into a concrete question.
5. "What would a good first ninety days look like for someone taking over the calendar as the teams consolidate?" Why it lands: it asks for his plan, not a reassurance.

## Sources

Provided documents: your message (the JD text and your background, pasted in the conversation).

Searches and fetches, by query, with what came back:

1. "Saltmarsh Games values": returned saltmarshgames.com/values. Fetched. Values page names three values: Players Before Plans, Ship the Patch Not the Promise, Leave the Build Greener.
2. "Saltmarsh Games interview process Live Operations Producer": returned saltmarshgames.com/careers/interviewing. Fetched. Names the Outage Hour: a single 60-minute hiring-manager interview with a live-incident tabletop and a values conversation.
3. "Saltmarsh Games strategy news": returned saltmarshgames.com/news/project-larkspur (search snippet, not fetched). Project Larkspur, September 2026: Tidepool Tactics and Lantern Row move to a season-pass model with one shared events calendar from February 2027; per-title event teams retired in favour of a single live-ops group.
4. "Tobias Wrenfield Saltmarsh Games Head of Live Operations": returned a GDC 2026 talk listing, "Patch Notes Are a Promise" (search snippet, not fetched). Names him as Head of Live Operations at Saltmarsh; previously a QA lead at a console studio.

Note: the Project Larkspur snippet names the two titles; the JD does not. This pack does not assume the JD's two titles are those two.

Research tier: L1 — searches 4 of 6, fetches 2 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh values | yes | Values cheat sheet, section 10: three values by name |
| 2. Saltmarsh interview process | yes | Round structure: the Outage Hour (one 60-minute session with the hiring manager, a tabletop, then a values conversation). Loop established by the company's own page |
| 3. Saltmarsh strategy / recent news | yes | Project Larkspur: CO question A4, reverse question 3 |
| 4. Tobias Wrenfield Saltmarsh | yes | Interviewer read and persona weights: his talk's argument and QA background |
| 5. Representative JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- A copy of your release checklist, or the calendar you ran → F2 and F6 move from medium toward a named artifact you can show, and the checklist question D2 gets a concrete answer
- Whether the JD's two titles are Tidepool Tactics and Lantern Row → A4 and reverse question 4 become specific instead of conditional
- The full text of Tobias's GDC talk → the interviewer read gains his actual argument, not the listing's summary
- Whether you ever ran a live incident, or handled a player-facing bug → B2 gets a story your material carries, instead of an answer slot
- Any post-event review you ran, even a small one → F7 and D3 gain a sentence the pack can quote
- A written sample you produced that others acted on → F8 gains a sentence, and the written-communication requirement gets a question
