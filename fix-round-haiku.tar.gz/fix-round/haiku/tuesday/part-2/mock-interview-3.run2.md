Your prep pack is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-tuesday-part-2-rooms-case-3-denied-e45b0d0a/93629b6c-212e-41e1-9f47-8a974cecc597/scratchpad/stripe_product-operations-manager_interview_pack.md`. I built it for a generic final-round conversation with flat persona weights, since I don't know who you're meeting or what the role's requirements are.

Web search was refused in this session, so the pack says nothing about Stripe's values, interview structure or current strategy. The question banks cover seven interviewer styles, with 21 questions in total. Every answer slot is written to make you say what you actually did, or say plainly that you didn't.

Three questions would make the pack specific:

1. What round is this, and who will you be meeting: a hiring manager, a peer, a panel, or someone senior? If it's several back-to-back sessions, send the schedule.
2. Can you paste the job description and your CV? Either one lets me quote your own sentences into the answers. Without them, I can proceed, but the answers stay generic.
3. Does the role's location or work authorization requirement fit your situation? The pack can't tell whether that gate is met.

I can also run a live drill on any question in the pack, with a persona of your choice, and I can save a `tuesday-dossier.md` to carry the gaps this prep exposed into later sessions. A Word version of the pack is available on request.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: stripe_product-operations-manager_interview_pack.md -----
# Stripe, Product Operations Manager: final-round prep pack

Built with no CV, no JD, no interviewer name and no round details. Web search was refused in this session, so nothing here is about Stripe's values, loop or strategy. Everything is generic until you add material (see the upgrade menu).

## How to use

- **Personas** describe how a question is asked. **Types** describe what is being scored.
- Type key: **VAL** behavioral and values; **EXP** your past work, tested for attribution; **JD** the role's stated duties; **CO** company knowledge; **CASE** a live problem from the role.
- Guidance is scaffolding for a spoken answer, not a script. Answer slots are instructions for the interview, not questions to me.

## Fit snapshot (worksheet variant)

No background is in hand, so every evidence cell is `none given`. Requirements are role-family prose, not quotes, because no JD was supplied and the representative-JD search was refused.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Owning a cross-team process end to end (role family) | none given | none | [generic] | discovery | Answer slot: name one cross-team process you ran from start to finish, in your own words. If you did not run one, say so and name the nearest one you did run |
| F2 | Defining, tracking and explaining operating metrics (role family) | none given | none | [generic] | discovery | Answer slot: pick a metric you tracked. Say how it was counted and which assumption behind it you would defend least. If you tracked none, say so and say what you would measure first |
| F3 | Coordinating a launch across product, engineering, finance and support (role family) | none given | none | [generic] | discovery | Answer slot: a launch you helped run, with your part in it stated in your own words. If none, say so and describe how you would coordinate one |
| F4 | Briefing executives and prioritizing competing asks (role family) | none given | none | [generic] | discovery | Selection scaffold: a decision you brought to a senior person, what you asked for, and what came back. If none comes to mind, say so and give the nearest case |
| F5 | Familiarity with payments or fintech operations (role family) | none given | none | [generic] | discovery | Answer slot: name one thing about payments or fintech operations you have actually used or read, and how. If none, say so plainly and state how you would get up to speed |
| F6 | Work authorization and location for the role (role family) | your material does not establish this | none | [generic] | hard_gate | Surfaced, not bridged. Asked once in the questions below. The pack cannot tell whether it is met |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Stripe product, metric or strategy details stated as current fact | No research ran, and no source in hand holds them | Your own knowledge, labeled as yours and dated. The pack asserts none |
| Any ownership, scale or metric claim about your work | No quoted sentence exists yet, so nothing can be stretched | None listed until a CV or message gives sentences to check |

## Persona table

Relationship is unknown, and the loop is not established, so weights are flat. Each persona gets three questions.

| Persona | How it shows up | Likelihood | Reasoning | Counter-strategy |
|---|---|---|---|---|
| Data-Driven Prober | Asks for the denominator and the assumptions | Medium | Ops roles are judged on metrics; flat prior | Name the weakest assumption before they do |
| Pressure / Stress | Time-boxes answers, challenges your choices | Medium | Flat prior; common at the final stage | Pause, restate, hold through two follow-ups, then concede precisely |
| Values / Behavioral | Scenario probes on judgment and candor | Medium | Stripe values not established, so the theme comes from the persona stem | "I" for your contribution, "we" for context, and say plainly where no story exists |
| Case / Strategist | Live problem from the role | Medium | Role-family case, not Stripe's real roadmap | Clarify, then structure, then metrics, then risks; think aloud |
| Skeptic | Probes the weakest point and why you, why now | Medium | Flat prior; the gaps are F1 to F5 | Rehearse the one predictable objection until it is plain; calibrated candor |
| Conversational | Friendly openers that are still scored | Medium | Casual questions still count | A 90-second arc; treat casual questions about the role as scored |
| Peer Evaluator | Seams between teams, credit, disagreement | Medium | Flat prior | Reciprocity: what you bring their team, not just what you need |

## Question banks

Every row is `[generic]`: no candidate sentence is quoted, so no guidance claims anything about your past.

### A. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | Tell me about a number you used to make a decision. How was it counted? | EXP | [generic] | Name the figure and what it counts, in your words. Answer slot: the assumption behind it you would defend least. If you did not count it, say so | Probers press headline numbers; tests attribution. F2 |
| A2 | Which assumption in that analysis would you defend least? | EXP | [generic] | Name the assumption before they do. Answer slot: if you did not build the analysis, say whose it was and what your part was | Converts a gotcha into a credibility point. F2 |
| A3 | How would you know whether a process change actually worked? | JD | [generic] | Name a metric, its baseline, and what result would show failure. Do not invent a baseline you do not have | Tests metric discipline in the role's own terms. F2 |

### B. Pressure / Stress

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | Sixty seconds: why you, over someone with direct experience in this work? | JD | [generic] | Hold: name the one contribution that is yours. Concede the gap plainly. Hold through two follow-ups; do not fold on the core | Pressure tests composure under a direct comparison. F4 |
| B2 | Describe a plan that people pushed back on. What did you hold, and what did you concede? | EXP | [generic] | Selection scaffold: a time you held a position and then conceded a specific point. If none, say so and give the nearest case | Hold-then-concede is the scored behavior. F4 |
| B3 | How much of the result you just described was actually you? | EXP | [generic] | Answer slot: separate what you did from what the team did, in your own words. If the result was not yours, say so | Tests attribution under pressure. F4 |

### C. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | Tell me about a time you delivered an unpopular truth to leadership. | VAL | [generic] | Selection scaffold: a time the truth changed a decision. Name who, the stake, what you said, and what happened. If none, say so and give the nearest case | Standard behavioral probe. F1 |
| C2 | When did you put a customer ahead of an internal metric? | VAL | [generic] | Selection scaffold: a decision where a customer outcome beat a dashboard number. If none, say so and give the nearest case | Tests judgment, not slogans. F1 |
| C3 | Tell me about a process you changed that people resisted. | VAL | [generic] | Selection scaffold: what the resistance was, what you did, and what changed afterward. If you did not change one, say so | Process change is the core of the role. F1 |

### D. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | A launch you own is missing its adoption target by 20% at week three. Diagnose it. | CASE | [generic] | Clarify the target and the segment first. Then state a hypothesis, the metrics to check, and the risks | Live problem from the role; asks about no past |
| D2 | Sketch an operations plan for supporting a new product line. What do you need to know first? | CASE | [generic] | Clarify scope, users and volume before proposing anything. Name what would change your plan | Tests structure over the right answer. F3 |
| D3 | Which metric would you use to decide whether to retire an internal tool? | CASE | [generic] | Name the metric, the threshold and who decides. Name one way the metric would mislead you | Tests metric judgment. F2 |

### E. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | Which part of this role would you be weakest at on day one? | JD | [generic] | Name the weakest part honestly. Bridge with a ramp plan, not a claim of ability you have not shown | Skeptics ask the predictable gap question first. F1 |
| E2 | Where does your background stop short of this role, and what would you do about it? | JD | [generic] | Answer slot: name where your experience stops, in your words. Then give a concrete 90-day ramp. If you have no gap you can name, say so and ask what they see | Calibrated candor beats bluffing. F5 |
| E3 | Why are you leaving your current role, and why now? | EXP | [generic] | Keep it to what is true and consistent across rounds. Do not invent a story | Motivation consistency is scored. F4 |

### F. Conversational / Rapport

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | So, walk me through your journey. | EXP | [generic] | A 90-second arc: one throughline, two specifics you would stand behind, and why this role | Casual openers are scored for economy |
| F2 | What have you been reading or using in payments lately? | CO | [generic] | Name one specific thing you have read or used, in your words. If none, say so. Do not pretend | Casual questions about the role are scored. F5 |
| F3 | What would you want to know about how our team works before your first week? | JD | [generic] | Name two specific questions. Show you have thought about the role, not just the company | Tests interest without rehearsed praise. F1 |

### G. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | Our teams sit side by side. Where is the seam, and what happens when we disagree? | JD | [generic] | Propose seam principles, not facts about their team. Name how you would disagree with an equal and close | Peer probes check collaboration. F1 |
| G2 | How do you handle credit when work spans teams? | VAL | [generic] | "I" for your contribution, "we" for context. Name one example you can stand behind | Credit-sharing probes test honesty. F1 |
| G3 | What would you need from my team in the first month? | CO | [generic] | Reciprocity: what you would bring their team, then what you would need | Peers weigh whether a hire adds to or removes load. F3 |

## Requirement coverage

| Requirement | Questions | Note |
|---|---|---|
| F1 cross-team process | C1, C3, G1, F3 | |
| F2 metrics | A1, A2, A3, D3 | |
| F3 launch coordination | D2, G3 | |
| F4 executives and prioritization | B1, B2, B3, E3 | |
| F5 payments or fintech | E2, F2 | |
| F6 work authorization and location | none, and why | Gate, asked once in the message that presents this pack |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | What does a strong first 90 days look like in this role, and what would the first hard problem be? | Shows you are planning for the job, not interviewing for it |
| R2 | Which decision in the last quarter did the operating process get wrong, and what changed? | Invites an honest answer and shows you want substance |
| R3 | When product and finance disagree about a launch, how does operations decide? | Surfaces the real decision path |
| R4 | What is the one metric the team reviews each week, and how is it counted? | Prober-friendly; shows you think in definitions |
| R5 | What could a new person do in their first month that would genuinely help your team? | Reciprocity framing; a strong close for a peer-weighted round |

No interviewer profile exists, so no reverse question is tied to an interviewer's own path.

## Research and sources

**Research tier: L1, searches 4 of 6, fetches 0 of 2.** All four searches were refused, because permission to use the web search tool was not granted. No other route was tried.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Stripe values | unavailable | The values cheat sheet. Refused query: "Stripe company values operating principles". Values not established, so no cheat sheet |
| 2. Stripe interview process, product operations | unavailable | Loop structure and persona weights. Refused query: "Stripe interview process product operations manager final round". Loop not established, so the Generic archetype applies and weights stay flat |
| 3. Stripe strategy and recent news | unavailable | The company-knowledge bank. Refused query: "Stripe strategy 2026 priorities news". CO questions stay generic |
| 4. Interviewer name and company | n/a | No name was given, so there is no query to form |
| 5. Representative Product Operations Manager JD | unavailable | Requirements F1 to F5. Refused query: "Product Operations Manager job description responsibilities qualifications". Requirements stay as generic role-family prose |

Provided documents: none. Dossier: none found.

## Upgrade menu

- Your CV or resume text: gives the banks sentences to quote, so F1 to F5 move from `none given` to evidence, and the answer slots become story maps
- The job description text: requirements become quoted, the coverage table gets real lines, and the generic rows become grounded
- Round type and who you are meeting: reweights the personas and turns the flat table into a real one. If the final is several back-to-back sessions, send the schedule for per-session mini-packs
- The interviewer's name: adds a public-footprint read and a tailored reverse question
- Stripe's values page, interview guide and recent strategy: needs web search allowed in this session. Once it is, these add a values cheat sheet if the loop has a values round, the loop structure, and a company-strategy bank
- Any pre-announced take-home or presentation from the recruiter: adds a build section for it
