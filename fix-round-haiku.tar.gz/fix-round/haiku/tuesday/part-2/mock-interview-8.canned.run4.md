Your prep pack is saved as /tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-tuesday-part-2-rooms-case-8-canned-ae470255/cb5c64e2-6353-4ffd-8559-ee2b4af649f0/scratchpad/ashgrove_member-experience-lead_interview_pack.md. I built it as three mini-packs, one per round, since you gave the full schedule. I ran no web searches: the JD, the values text, the recruiter's round structure and the strategy summary already covered every research target.

The biggest exposure is the scope of the role. The JD asks you to own the complaints process end to end across branches and the contact centre. Your material shows one branch's complaints log and no contact-centre work. Your stated gaps are the contact centre and presenting above regional level. The pack has you hold the log you can claim, then concede the wider scope in one sentence.

Say the word and I'll play the Skeptic on R2-B1, the question the pack names as its highest-ROI prep.

I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.

If you'd like the pack as a Word document, say so and I'll convert it.

Can you meet the role's location and travel terms? The JD doesn't state them, and the 2027 hub move may change them. Once you know them, I can settle that row.

Does the recruiter's note say whether the 20-minute case is sent in advance or given on the day, and whether you can bring notes?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove_member-experience-lead_interview_pack.md -----
# Interview prep pack: Member Experience Lead, Ashgrove Credit Union

Prepared 11 November 2026 for Dara. Loop mode, three rounds on 20 November 2026:

- **Round 1, recruiter, 30 min.**
- **Round 2, Head of Member Services (your future manager), 45 min, mostly behavioural.** Interviewer not yet named.
- **Round 3, panel of two branch managers, 60 min,** including a 20-minute complaint-escalation case. The panel scores against the four values. Panel members not yet named.

## How to use this pack

Personas describe how a question arrives. Types describe what is being scored: **VAL** (values), **EXP** (your own experience, probed), **JD** (the job's requirements), **CO** (company and strategy), **CASE** (a live problem). Guidance is scaffolding, not a script.

Where the guidance says **Answer slot**, the answer is yours to give from your own experience, in your own words. Either honest branch it names is a good answer.

Question IDs are round, then persona letter, then number. R2-B1 is round 2, Skeptic, first question.

## Grounding brief: Ashgrove

Words to use, from the July 2026 strategy brief as you summarised it: "member service", "digital channels", "hubs", "small-business lending", "app-only banks". Numbers to know: 40% of member service moving to digital channels by 2028; eight branches consolidated into five hubs over 2027; a small-business lending launch in Q1 2027. The brief names app-only banks as the main competitive pressure. This comes from your message and has not been checked against the published brief (see Sources).

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" (JD) | "6 years in retail banking, the last 3 as a branch supervisor" (your message) | medium | [grounded] | none | Your material shows six years in retail banking, three of them as a branch supervisor. Say it in those words. The JD says "customer operations"; the pack does not claim your branch work carried that title. |
| F2 | "own the member complaints process end to end across branches and the contact centre" (JD) | "I handled the branch's formal complaints log and trained new tellers on our escalation script." (your message) | medium | [grounded] | transferability | Your material places you on one branch's complaints log. It does not show the process end to end, across branches, or the contact centre. Words: "I handled the branch's formal complaints log." Answer slot: the JD's "end to end" line makes a probe on which steps you owned from the log to closure likely. If any step was yours to decide, say which and how. If not, or it was not yours, say so plainly and stay with the log you handled. |
| F3 | "experience handling regulated complaints" (JD) | "I handled the branch's formal complaints log and trained new tellers on our escalation script." (your message) | medium | [grounded] | presentation | The quote reaches the requirement in other terms: a formal complaints log you handled. Words: "I handled the branch's formal complaints log." Your material does not say which rules that log followed, so the pack does not call it regulated. If an interviewer asks, answer from what you know of those rules, in your own words. |
| F4 | "report monthly on complaint volumes and resolution times" (JD) | "I built the monthly complaints spreadsheet our regional manager uses." (your message) | medium | [grounded] | presentation | The quote reaches monthly complaints reporting in other terms. It does not say what the spreadsheet counted. Words: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: the JD names volumes and resolution times, so expect a probe on what the spreadsheet counted. Say what it counted, in your own words. If it did not track resolution times, say so. |
| F5 | "coach branch supervisors on escalations" (JD) | "I handled the branch's formal complaints log and trained new tellers on our escalation script." (your message) | medium | [grounded] | transferability | Your material shows training of new tellers on the escalation script, not coaching of supervisors. Words: "I trained new tellers on our escalation script." Answer slot: the JD asks for coaching supervisors, so expect a probe. If you have coached a colleague through an escalation, say who and what happened. If you have not, say so and say how you would start. |
| F6 | "work with digital teams on self-service journeys" (JD) | none given | none | [grounded] | discovery | Your material does not show work with digital teams, and the pack does not claim it. The strategy brief puts 40% of member service into digital channels by 2028, so expect a probe. Answer slot: if you have worked with any team on a customer-facing journey, say what it was. If you have not, say so plainly and say how you would start with a digital team. |
| F7 | "confident presenting to senior leaders" (JD) | "Never worked in a contact centre, and I've never presented to anyone above regional level." (your message) | none | [grounded] | capability | Words: "I've never presented to anyone above regional level." Then how you would learn it, said as a plan and never as a past. |
| F8 | "comfortable with Excel reporting" (JD) | "I built the monthly complaints spreadsheet our regional manager uses." (your message) | medium | [grounded] | discovery | Your material says a spreadsheet and does not name the tool. Answer slot: say what you built it in and what it did, in your own words. If it was not Excel, say what it was. |
| F9 | "across branches and the contact centre" (JD) | "Never worked in a contact centre, and I've never presented to anyone above regional level." (your message) | none | [grounded] | capability | Words: "I've never worked in a contact centre." Then the plan, said as a plan: ask how a complaint is logged and handed over to the contact centre, and what its queue shows. |
| F10 | Location and travel: not stated in the JD; read by the pack from "across branches and the contact centre" | none given | none | [inferred] | hard_gate | Your material does not show whether the role's location or travel terms can be met, and the JD does not state them. Surfaced here, not bridged. The question for this row is in the message that presents this pack. |

## Prohibited claims

The pack will not coach these. The honest form of each is shown.

| Not coached | Basis | Honest form |
|---|---|---|
| "I owned the member complaints process end to end across branches and the contact centre." | Inflated form of F2 | "I handled the branch's formal complaints log." The pack's observation: your material places you on one branch's log, not the process end to end. Answer slots stay inside the log. |
| "I coached branch supervisors on escalations." | Inflated form of F5 | "I trained new tellers on our escalation script." |
| "The spreadsheet reports complaint volumes and resolution times." | Inflated form of F4 | "I built the monthly complaints spreadsheet our regional manager uses." The pack's observation: your material does not say what it counts. |
| "I have presented to senior leaders." | Negative you stated, F7 | "I've never presented to anyone above regional level." No answer slot. |
| "I have worked in a contact centre." | Negative you stated, F9 | "I've never worked in a contact centre." No answer slot. |

## Sources and research

**Provided documents:** the JD, the values text (copied from ashgrovecu.org/about/values on 11 November 2026), the recruiter's round structure, the strategy brief summary, and your background, all in your message.

**Research tier: L0, no searches; user links read 0.**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | Values cheat sheet, round 3. The four values are in hand, pasted from the official page, so no search was needed. |
| 2. Interview process, role family | skipped | Loop structure and round split. The recruiter's note names the three rounds, their lengths, who runs each, and the values scoring. That establishes the loop, so no archetype fallback was used. |
| 3. Strategy and recent news | skipped | Grounding brief and CO questions R1-A2 and R3-B3. Your summary of the July 2026 brief covers the current priorities. It has not been checked against the published brief. |
| 4. Interviewer name and company | n/a | No names were given for rounds 2 or 3. The interviewer read is absent, and the upgrade menu says what names would unlock. |
| 5. Representative JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions. |

## Round 1: Recruiter screen (30 min)

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport (weight 4) | Friendly opener, "walk me through", a casual question on a hot JD topic | High. A recruiter screen carries this register as its prior, and casual questions are still scored. | A 90-second arc, and treat casual JD questions as scored. |
| Skeptic, light (weight 3) | Checks motivation and logistics, and probes the two gaps the material shows | Medium. The screen checks knockout gaps early: the contact centre and senior presenting. | Hold the plain acknowledgment. Do not bluff. |

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R1-A1 | "Walk me through your background." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" (your message) | A 90-second arc in your words: six years in retail banking, the last three as a branch supervisor, then the complaints log you handled and the escalation script you trained tellers on. Add nothing to those beats. | The screen's opener. F1 and F2 are the sentences it has to carry. |
| R1-A2 | "What do you know about Ashgrove, and why now?" | CO | [grounded] "move 40% of member service to digital channels by 2028" (your message) | Use the brief's words: digital channels, the move from eight branches to five hubs, and app-only banks as the main pressure. Say what you would want to understand first about how complaints move through that change. Claim nothing about the plan beyond the brief. | A CO question checking homework. The grounding brief is the only source for these words. |
| R1-A3 | "What about this role made you apply?" | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." (your message) | Name the complaints work as the pull, in your words. Then say which part of the wider process you want to own. | A motivation question. It tests whether the answer follows from the work you did. |
| R1-A4 | "Where do you think a complaints process most often breaks down?" | JD | [generic] | Answer slot: if you have seen it break down in your own branch, say where and what happened, in your words. If you have not, name the first place you would check. | An open JD question on the end-to-end line. It makes no claim about you, so the label is generic. |
| R1-A5 | "How do you stop a complaint getting lost between people?" | JD | [generic] | Answer slot: say what in your branch kept a complaint from being lost, in your words. If the log did not do that, say so and say what you would add. | Covers the regulated-complaints and own-the-fix requirements with an open prompt. |
| R1-B1 | "You've never worked in a contact centre. Why would this role work for you?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." (your message) | Plain acknowledgment: "I've never worked in a contact centre." Then the plan: what you would learn first about how a contact centre takes and hands over a complaint. Claim no past contact-centre work. | F9. The stated negative gives the words, and the rest is a plan, not a past. |
| R1-B2 | "The JD asks for four years in customer operations. How do your six years count?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" (your message) | Say the years in those words, and say which of them were customer-facing. Do not stretch "retail banking" into the JD's wording. Say how your branch work sits next to it. | F1. The question's premise is the JD's, and the guidance does not adopt it. |
| R1-B3 | "Why move from supervising a branch to running a process across branches?" | JD | [grounded] "I handled the branch's formal complaints log" (your message) | Name what carries over: the log, and the escalation script you trained tellers on. Say plainly that the scope across branches is wider than one branch's log. Answer slot: name any part of the process beyond your branch that was yours. If none was, say so and name the first step you would take. | F2 is the scope gap this question presses. The answer should draw that line itself. |

## Round 2: Head of Member Services (45 min)

Weights: Values / Behavioral 4, Skeptic 3, Pressure 2. The recruiter says the round is mostly behavioural, which moves Values / Behavioral to the top. The usual hiring-manager prior would put Case first, and that is overridden here.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral (weight 4) | "Tell me about a time" prompts, STAR-shaped | High. The recruiter's note names the format. | One story per question. "We" for context, "I" for what you did. |
| Skeptic (weight 3) | Probes scope and the presenting gap | High. A hiring manager is buying the derisking, and both stated gaps are hers or his to test. | Hold the plain acknowledgment. Name the first step. |
| Pressure (weight 2) | A time-boxed challenge to one claim | Low to medium. The round is behavioural, but a manager may time-box. | Pause, restate, hold through two follow-ups. |

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R2-A1 | "Tell me about a time you explained a complaint outcome to a member who didn't like it." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." (your message) | Story map from the log: the complaint you decided on, the explanation you gave, how the member reacted. If the log holds no such case, say so plainly, then give the nearest thing it does carry: how you trained tellers on the escalation script. Name only what you did. | Plain Words is the value this probes. The nearest-thing branch keeps the answer honest where the log is silent. |
| R2-A2 | "Tell me about a time a member's interest and a branch rule pulled in different directions." | VAL | [generic] | Selection scaffold: pick a time a member's interest and a rule pulled apart. Name the stake, what you did, and what it cost you. If none comes to mind, say so plainly, then say how you would handle it. | Members First, Always is the published value. No quoted sentence carries a story, so this is a scaffold. |
| R2-A3 | "Tell me about a complaint from the log you handled, from the first entry to the outcome. Who did what?" | EXP | [grounded] "I handled the branch's formal complaints log" (your message) | Walk through one complaint in the terms the quote gives. Say which steps were yours to decide and which were not, and who you handed the rest to. Answer slot: the JD's end-to-end line makes the step-by-step probe likely. If a step was not yours, say so plainly. | F2. The question asks about one log entry, which is what the quote carries. |
| R2-A4 | "Tell me about a time you disagreed with a colleague or senior person about how a complaint should be resolved." | VAL | [generic] | Scaffold: pick a time you disagreed on the fix. Name the stake, what you held, what you conceded, and how it ended. If none comes to mind, say so plainly, then say how you would hold a position with a senior colleague. | Own the Fix, and disagreement with seniors. No claim about you, so the label is generic. |
| R2-B1 | "This role owns the complaints process across branches and the contact centre. You've handled one branch's log. Why is that enough?" | JD | [grounded] "I handled the branch's formal complaints log" and "Never worked in a contact centre, and I've never presented to anyone above regional level." (your message) | The honest answer has the same shape as the quotes. Say the log first, then that the wider scope is a gap you have not worked in, then what you would learn first. Hold the core through two follow-ups: the log is what you can claim, and the wider scope is a plan. Concede specifically: "That's wider than what I've done." Never answer "that's enough" as a claim. Answer slot: name the parts of the log that carry across, and the first thing you would need to learn. | Highest-ROI prep. The headline JD requirement meets a stated scope gap in the manager's round. Deepest rehearsal: hold the log, then concede the scope in one sentence. |
| R2-B2 | "What does your regional manager do with the spreadsheet you built?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." (your message) | Say what your regional manager uses it for, in your own words. If you do not know what they decided from it, say so. Answer slot: the JD asks for monthly reporting to senior leaders, so expect a probe on what the reports showed. Say what you saw, and if you did not see the decisions, say that. | F4 and F8. The question asks what you know, not what you achieved. |
| R2-B3 | "What did the complaints spreadsheet count?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." (your message) | Say what it counted, in your own words, and which measures it held. Name the tool you built it in. If it did not track resolution times, say so. If you cannot say how a figure was counted, say that plainly. | F4 and F8. This question asks for the spreadsheet's contents, not for a number you have not given. |
| R2-C1 | "Sixty seconds: why should we hire you over someone who has run a contact centre?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." (your message) | Hold. Do not argue against a rival you have not met. Say what you bring from the log and the escalation training, in your own words, then stop. If pressed, concede the specific gap: "I haven't worked in a contact centre." Hold through two follow-ups before conceding anything more. | A pressure question. The concession is the one you stated, not one the pack adds. |
| R2-C2 | "You've never presented above regional level. How will you present monthly to senior leaders?" | JD | [grounded] "I've never presented to anyone above regional level." (your message) | Acknowledge plainly: "I've never presented to anyone above regional level." Then the plan: how you would prepare and get feedback before a first senior presentation. Do not describe a presentation you did not give. Concede that the plan is untested. | F7. The question's monthly-presentation premise comes from the JD. The plan answers it. |

## Round 3: Panel of two branch managers (60 min)

Panel members are not yet named, so weights are for the panel as a whole. The recruiter says the panel scores against the four values, so this round is the values round for the loop.

Weights: Values / Behavioral 4, Case / Strategist 3, Skeptic 2.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral (weight 4) | Scores each answer against the four values | High. The recruiter's note says the panel scores the values, and a loop source documents the round. | Map a story to each value where one exists. Say where none does. |
| Case / Strategist (weight 3) | The 20-minute complaint-escalation case | High. A live problem with structure weighted over the "right" answer. | Clarify, then structure, then act. Think aloud and name the first call. |
| Skeptic (weight 2) | Probes scope and the two stated gaps, as branch managers | Medium. The scope gap will come up in the case as well. | Hold the plain acknowledgment. Name the plan. |

### Values cheat sheet

| Value (official name) | Working meaning | Mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | No row carries a story. Scaffold: pick a complaint where the member's side and the branch's rule pulled apart. Name what you decided and what it cost. If no such time comes to mind, say so plainly, then give the nearest thing: F2, "I handled the branch's formal complaints log." |
| Plain Words | If a member needs it explained twice, we wrote it wrong | F5 carries training, not explanation. Scaffold: a time a member had to hear something twice, and what you changed. If none, say so plainly, then give the nearest thing: F5, "I trained new tellers on our escalation script." |
| Neighbours, Not Numbers | Every branch is part of its town | No row carries it. Scaffold: a time a number and a local customer's situation pointed different ways, and what you did. If none, say so plainly, then say how you would find out what the town's members need. |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | F2 carries handling, not holding on until the fix. Scaffold: a problem you found that was not yours to fix, and what you did to keep hold of it. If none, say so plainly, then give the nearest thing: F2, "I handled the branch's formal complaints log." |

### Round 3 bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R3-A1 | "Tell me about a time you put a member first when the process said something else." | VAL | [generic] | Scaffold from the Members First row: the stake, what you decided, what it cost. If none comes to mind, say so plainly, then give F2 as the nearest thing, with its limit. | Members First, Always is scored here. No quote carries the story, so the guidance is a scaffold. |
| R3-A2 | "Tell me about a time a member had to hear something more than once. What did you change?" | VAL | [generic] | Scaffold: the time, what the member needed to hear, and what changed in how it was explained. If none comes to mind, say so plainly, then give F5 as the nearest thing: "I trained new tellers on our escalation script." | The Plain Words value, asked as an open prompt. |
| R3-A3 | "Tell me about a problem you found that wasn't yours to fix. What did you do with it?" | VAL | [generic] | Scaffold: the problem, why it was not yours, and what you did to keep hold of it until it was solved. If none, say so plainly, then give F2 as the nearest thing, with the limit: that was the log, not the fix. | Own the Fix. The value's "keeps hold of it" is the raising source. |
| R3-A4 | "Tell me about a decision where the numbers and a community pointed in different directions." | VAL | [generic] | Scaffold: the decision, the number, the people, what you chose, and why. If none, say so plainly, then say how you would find out what the town needs before deciding. | Neighbours, Not Numbers. No quote carries it. |
| R3-B1 | The 20-minute case, read aloud: "A member complained to a branch about a fee. The branch said it would look into it. Three weeks later the member has heard nothing, and has been told two different things by two staff. They have now escalated it to you. Talk us through the next twenty minutes, and then the next month." | CASE | [generic] | Structure, in this order. Clarify facts first: what each staff member said, what the member was told, what is on file. Put the member's position in plain words and give them a next step with a date. Decide who owns the complaint to closure and say so. Check where the handover between branch and contact centre broke. Record it for the monthly report. Name the process gap, such as who was meant to call. Do not invent deadlines; check the response timescale in the complaints policy. | A live problem from the end-to-end line and the escalation. It asks about no past of yours and presupposes nothing about you. |
| R3-B2 | "A branch supervisor on your team is stuck on this complaint and asks what to do. What do you tell them?" | JD | [generic] | Coach the supervisor through the same order as the case: facts, the member's next step, one owner, the record. Answer slot: if you have coached a colleague through an escalation, say how, in your own words. If not, say so and say how you would coach one. | The coach-supervisors line (F5), asked as a live problem rather than a record. The guidance claims no past coaching. |
| R3-B3 | "More member service is moving to digital channels. Which complaints would you expect to move online first, and who would you work with to fix them?" | CO | [grounded] "move 40% of member service to digital channels by 2028" (your message) | Name the complaint types you would expect online first. Name the teams you would need, digital and branch both. Answer slot: if you have seen complaints that started online, say what they were. If you have worked with a digital team on a customer journey, say what it was. If you have not, say so and say how you would start. | F6 and the strategy move. The guidance uses the brief's own words. |
| R3-C1 | "You've never worked in a contact centre. When a complaint comes across to us from one, what do you do first?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." (your message) | Plain acknowledgment: "I've never worked in a contact centre." Then the first step, as a plan: ask how a complaint is logged and handed over, and what the queue shows. Claim no past contact-centre work. | F9. The stated negative gives the words. The rest is a plan. |
| R3-C2 | "Which of the four values does your own record show you least on?" | VAL | [generic] | Answer slot: name one value you can point to in your own words. If your record shows none to point to, say so plainly. Do not pick the value that flatters you. | A Skeptic question that makes you test the values against your own record. |

## Requirement coverage

| JD requirement | Question IDs | Note |
|---|---|---|
| 4+ years in financial-services customer operations | R1-B2 | |
| Own the member complaints process end to end across branches and the contact centre | R1-B3, R2-A3, R2-B1, R3-B1 | |
| Experience handling regulated complaints | R1-A5, R2-A3, R3-B1 | |
| Report monthly on complaint volumes and resolution times | R2-B2, R2-B3 | |
| Coach branch supervisors on escalations | R3-B2 | |
| Work with digital teams on self-service journeys | R1-A2, R3-B3 | |
| Confident presenting to senior leaders | R2-C1, R2-C2 | |
| Comfortable with Excel reporting | R2-B3 | |
| Work across the contact centre (JD scope) | R1-B1, R2-B1, R3-C1 | |
| Location and travel (not stated in the JD) | none, and why: this is a gate the material does not settle. Its one question is in the message that presents this pack. | |

## Reverse questions

The pack has no interviewer profile yet, so none of these is tied to an interviewer's path. Use whichever fits the round.

1. "How does a complaint move between a branch and the contact centre today, and where does it most often stall?" Why it lands: it asks them to name the hand-off, which is the part you have not worked in. Their answer tells you the scope.
2. "When branches consolidate into hubs in 2027, who owns a complaint that started at a branch that is closing?" Why it lands: it ties to the eight-to-five plan and shows you read the brief.
3. "How will complaint volumes be tracked as more member service moves to digital channels?" Why it lands: it connects the monthly report to the 40% target.
4. "What would the first 90 days need to deliver for you to call the hire a success?" Why it lands: it asks the manager's yardstick. Round 2 only.
5. "When a fix would favour one member and cost the branch, who decides, and how is it recorded?" Why it lands: it shows Own the Fix and a decision record. Round 3 only.

## Upgrade menu

- The role's location and travel terms, from the recruiter → turns F10 from a surfaced gate into a grounded row, and settles the question in the message.
- Interviewer names for rounds 2 and 3 → persona weights from their public footprint, a tailored reverse question, and panel personas assigned per member.
- The July 2026 strategy brief, pasted → exact figures in the grounding brief, R1-A2 and R3-B3 move from your summary to quoted sources.
- What the complaints spreadsheet counted, and any figure it produced → defend-the-number slots for F4 and R2-B3, once you give a figure.
- Any informal work with a digital or product team → F6 moves from discovery to grounded, and R3-B3 gets a story map.
- Any time you coached a colleague through an escalation → F5 moves from transferability to grounded, and R3-B2 gets a story map.
- The complaints rules your branch log followed, if you know them → F3's bridge gets a named basis.
- One deeper research pass, up to 6 more searches and 2 more fetches, several minutes: recent Ashgrove leadership or reorganisation news that would shape the panel and the hub plan. Offered once.
