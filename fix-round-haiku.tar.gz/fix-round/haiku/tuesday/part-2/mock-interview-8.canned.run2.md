Your prep pack is saved as /tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-tuesday-part-2-rooms-case-8-canned-1ec4f69b/d1eb0ceb-e5b9-4c60-907e-ac68a874a9a9/scratchpad/ashgrove_member-experience-lead_interview_pack.md. I built it as a three-round loop from your dates, the recruiter's round descriptions and your background. Nothing else was needed, so I ran no web searches; every output came from material you gave me.

The pack has 26 questions in total: 8 for the recruiter screen, 8 for the Head of Member Services, and 10 for the panel, including the 20-minute escalation case (C3). The highest-return prep is B4: "We'd have you running complaints across a contact centre you haven't worked in." Hold your position through two follow-ups, then concede the gap exactly. The values cheat sheet is in the round 3 section, because the recruiter says the panel scores the four values.

Say the word and I'll play the Skeptic on B4 as a live drill. I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove_member-experience-lead_interview_pack.md -----
# Ashgrove Credit Union: Member Experience Lead, interview prep pack

Three rounds on 20 November 2026. Loop mode. Built 11 November 2026 from your message, the job description, the values text you copied, the recruiter's email and your summary of the July 2026 strategy brief. Interviewers beyond the roles are not yet assigned, so personas are weighted by relationship.

## How to use

Personas describe how a question arrives. Types describe what it scores:

- **VAL**: values and behaviour
- **EXP**: your own experience and what you did in it
- **JD**: the stated role and its requirements
- **CO**: company and strategy
- **CASE**: a live problem from the job

Guidance is scaffolding, not a script. An answer slot is an instruction for the interview: it asks you to say which of two honest branches is true, in your own words.

## Fit snapshot (shared across rounds)

No requirement is a gate. None is a term, licence or credential. The four-year requirement is graded like the rest.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" (JD) | "6 years in retail banking, the last 3 as a branch supervisor." (your message) | medium | [grounded] | none | Your message already reaches the years and the sector. Say it in those terms. The supervisor years are the part to put first. |
| F2 | "experience handling regulated complaints" (JD) | "I handled the branch's formal complaints log and trained new tellers on our escalation script." (your message) | medium | [grounded] | transferability | The sentence carries formal complaints work, adjacent to regulated complaints. It does not say the log was regulated, and the bridge must not say it was. Answer slot: the JD asks about regulated complaints, so expect a probe on outside rules. If the log was subject to an external deadline or review, say which and how you tracked it. If it was internal only, say so plainly. |
| F3 | "Own the member complaints process end to end across branches and the contact centre" (JD) | "I handled the branch's formal complaints log and trained new tellers on our escalation script." (your message) | medium | [grounded] | transferability | The sentence carries one branch's log. It does not reach end-to-end ownership or any step beyond the branch. Say the log at its own scope. Answer slot: if you have ever run complaints beyond your own branch, say where and what you were responsible for. If you have not, say so plainly. |
| F4 | "across branches and the contact centre" (JD) | "Never worked in a contact centre, and I've never presented to anyone above regional level." (your message) | none | [grounded] | capability | Words for the gap: "I haven't worked in a contact centre." Then how you would learn it, said as a plan and never as a past. Never a claim of contact-centre work. |
| F5 | "comfortable with Excel reporting" (JD) | "I built the monthly complaints spreadsheet our regional manager uses." (your message) | medium | [grounded] | presentation | The sentence reaches monthly reporting in a spreadsheet, in other terms. Say it in its own words. The bridge adds no formula, dashboard or figure. Answer slot: if you used particular spreadsheet functions, name the ones you used. If you used none in particular, say so. |
| F6 | "report monthly on complaint volumes and resolution times" (JD) | none given | none | [grounded] | discovery | Your material does not show whether the spreadsheet counted volumes or resolution times. Answer slot: if it counted either, say which and how you read it. If it counted neither, say so plainly and name the measure you would track first. |
| F7 | "coach branch supervisors on escalations" (JD) | "I handled the branch's formal complaints log and trained new tellers on our escalation script." (your message); "6 years in retail banking, the last 3 as a branch supervisor." (your message) | medium | [grounded] | transferability | The sentences carry training tellers on an escalation script, and a branch supervisor role. Neither carries coaching supervisors. Say what you trained tellers on, in your words. Answer slot: if you coached a supervisor on an escalation, say what you did. If you did not, say so plainly and say what you would do first. |
| F8 | "work with digital teams on self-service journeys" (JD) | none given | none | [grounded] | discovery | Your material is silent on digital work. Answer slot: if you have worked with a digital or self-service team, say where and what your part was. If you have not, say so plainly and say how you would start with one. |
| F9 | "confident presenting to senior leaders" (JD) | "Never worked in a contact centre, and I've never presented to anyone above regional level." (your message) | none | [grounded] | capability | Words for the gap: "I've never presented to anyone above regional level." Then your plan for learning it, said as a plan. Never a claim of senior presenting. |

Requirement coverage. Each JD requirement, and the rows and questions that cover it:

| JD requirement | Covered by |
|---|---|
| 4+ years in financial-services customer operations | F1; A1, A3 |
| Experience handling regulated complaints | F2; B3 |
| Confident presenting to senior leaders | F9; C4 |
| Comfortable with Excel reporting | F5; A4, B7, P1 |
| Own complaints end to end across branches and the contact centre | F3, F4; B2, B4, C3, E1 |
| Report monthly on complaint volumes and resolution times | F6; B7, P1, P2 |
| Coach branch supervisors on escalations | F7; B6 |
| Work with digital teams on self-service journeys | F8; C2 |

## Sources

Research tier: L1 — searches 0 of 6, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | The values text you pasted fixes the values cheat sheet in round 3. |
| 2. Ashgrove interview process | skipped | The recruiter's email fixes the three rounds, their lengths and the panel's values scoring. |
| 3. Ashgrove strategy, recent news | skipped | Your summary of the July 2026 brief fixes the company questions C1 and C2. The brief's full text is not in this conversation. |
| 4. Interviewer names | n/a | No names were given, so there was no query to form. Persona weights are relationship-based; the upgrade menu says what names would unlock. |
| 5. Representative Member Experience Lead JD | skipped | The job description you supplied fixes the fit snapshot and the JD-tagged questions. |

Provided documents used: your message; the job description text; the values text you copied; the recruiter's email; your summary of the strategy brief.

## Persona weights by round

| Round | Relationship | Persona | Weight | Why this weight | Counter-strategy |
|---|---|---|---|---|---|
| 1, recruiter screen, 30 min | Recruiter | Conversational | 5 | The prior for a screen. Logistics and motivation, in a friendly register, still scored. | A ninety-second arc for the opener; treat casual questions about the JD's topics as scored. |
| 1 | Recruiter | Skeptic | 3 | Light, from the prior. The two JD gaps get one probe each. | Say the gap first, then the nearest true thing. |
| 2, Head of Member Services (your manager), 45 min | Hiring manager | Skeptic | 4 | The prior is case and skeptic. The recruiter says the round is mostly behavioural, so the skeptic items are gap probes asked through a story. | Hold, then concede: hold one position through two follow-ups, then name the gap exactly. |
| 2 | Hiring manager | Values/Behavioral | 2 | The recruiter's "mostly behavioural" moves weight here. If the round turns out to be mostly STAR stories, D1 and D2 move up. | Say what you did; the decision is the story. |
| 2 | Hiring manager | Case/Strategist | 2 | Prior. The live problems are the hub plan and the digital shift. | Clarify, then structure, then the owner. |
| 3, panel of two branch managers, 60 min including a 20-minute case | Peers (blended) | Values/Behavioral | 4 | The recruiter says the panel scores the four values, so the values questions are one per value. This is the top weight. | Map each value to a story only where your record carries one; otherwise say so. |
| 3 | Peers | Case/Strategist | 2 | The 20-minute escalation case (C3), and a senior-leader question (C4). | Phase the case: clarify, own, fix, record. |
| 3 | Peers | Peer Evaluator | 2 | Two branch managers with the seam between branches and the contact centre. | Propose seam principles; do not claim knowledge of a seam you have not seen. |
| 3 | Peers | Data-Driven Prober | 2 | The spreadsheet and the figures are the record the panel can check. | Say how each measure was counted, and say plainly when you do not know. |

## Round 1: recruiter screen, 30 minutes

Round weight: Conversational 5, Skeptic 3.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, walk me through the journey: from the branch to where you are now." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." and "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Ninety seconds. Six years in retail banking; three as a branch supervisor; the complaints log and the escalation script, in your own words; what you want next. Nothing about the bank's plans. | F1 is the spine of the opener. A casual invitation is still a screen. |
| A2 | "What is it about member complaints work that made you want this role?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Say what you did with the log, then what you want the role to hold: the end-to-end ownership the posting describes, said as a want. Do not describe ownership you have not had. | Motivation is screened early and must match the record. F3 is where the record stops, so the want sits beyond it. |
| A3 | "Why now? You've been a branch supervisor for three years." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | State the step as a reason tied to the work you did. Two sentences. No comment on Ashgrove's plans. | The question tests whether the move is consistent with F1. A reason that outruns the record is the one a skeptic tests. |
| A4 | "Tell me about the reporting work. How did the monthly spreadsheet come about?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Say you built it, who uses it and how often it runs. Answer slot: if it counted volumes or resolution times, say which. If you cannot say, say so. | F5 and F6. The spreadsheet is the only reporting evidence, and the JD's measures are the probe. |
| A5 | "Is there anything about you that isn't on your CV?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Name the gap yourself: "I haven't worked in a contact centre." Then one sentence on how you would close it. Do not swap it for a strength. | The screen's common miss is leaving the gap for the next round to find. The stated negative is safe to say first. |
| B1 | "What's the widest complaints remit you've held?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Name the log at its own scope, and the widest step you can point to in your own words. If the widest is the branch log, say so plainly. | F3 is transferability. The honest answer is the branch's log, stated exactly. |
| B2 | "Why should we believe a branch supervisor can run complaints across a contact centre you've never worked in?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Hold, then concede. Hold one: "I haven't worked in a contact centre." Then return to the log, at its scope. Concede the gap specifically: the contact centre is what you would learn first. Do not fold on the branch record. | The screen-stage version of the highest-ROI objection (B4). The negative is stated by you, so the question may presuppose it. |
| B3 | "Was the complaints log you handled subject to an external deadline or review, or was it internal only?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Answer slot: if it was external, say which deadline or review and how you tracked it. If it was internal only, say so plainly. | F2. Regulated complaints is a JD requirement the material does not show. The question asks; it does not assume. |

Reverse questions, round 1:

- "What does a strong first 90 days look like in this role?" Why it lands: asks for their success measure and invites the Own-the-Fix frame.
- "Which complaint measures does the team look at every month?" Why it lands: shows you read the monthly-reporting duty, and gives you the measures.
- "How do you expect digital self-service to change the complaints work over the next two years?" Why it lands: ties your question to the published forty-percent digital goal.

## Round 2: Head of Member Services (your manager), 45 minutes

Round weight: Skeptic 4, Values/Behavioral 2, Case/Strategist 2.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B4 | "We'd have you running complaints across a contact centre you haven't worked in. What would you do in your first month so it isn't the weak point?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Hold, then concede. Hold one: "I haven't worked in a contact centre." Give your first step as a plan: how you would learn the contact centre's complaint routing, and whom you would learn it from. Follow-up two returns to the branch log. Concede exactly: the contact centre is where you would be learning, not where you have a record. Do not claim it, and do not name a method you have not chosen. | Highest-ROI prep in this pack. The contact-centre gap is the largest gap in the snapshot, and this manager scores it. Hold through two follow-ups, then concede the gap exactly. |
| B5 | "Of the complaints in that branch log, what happened to the ones you handled, and which were yours to close?" | EXP | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Answer slot: say what "handled" meant, and which complaints you closed as you count them. If you passed some on, say so. Give no figure you cannot count. | F3. The question asks what you did, and does not presuppose a count the material does not carry. |
| B6 | "Tell me about an escalation you pushed up, or back, and what you did next." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Open prompt. An escalation with a named stake, where you did not drop it. If none comes to mind, say so plainly, then give the nearest thing your material carries: the escalation script you trained tellers on, and how you taught it. | The theme is the JD's line on coaching supervisors on escalations. The fallback is F7. |
| B7 | "Did your spreadsheet count resolution times, or only volumes?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Answer slot: if it counted resolution times, say how you read them. If it counted volumes only, say so plainly, and name the resolution measure you would track first. | F6. The JD asks for both measures and the material shows neither. The question asks, it does not assume. |
| C1 | "A branch is folded into a hub next year. It has open complaints on the day it closes. What do you do first?" | CASE | [generic] Raised by the strategy brief's plan to consolidate eight branches into five hubs during 2027. | Structure: which complaints are open, and what each member was promised. One owner for each until it is solved. What changes for the member, and what must not be lost in the move. Who you tell, and in what plain words. Keep it hypothetical and claim nothing about your past. | A live problem from published strategy. The hub plan is the strongest test of Neighbours, Not Numbers. |
| C2 | "Digital is taking forty percent of member service by 2028. A self-service journey fails for a member. Where does the complaint go, and who owns it?" | CASE | [generic] Raised by the strategy brief's forty-percent digital goal and the JD's self-service line. | Structure: the complaint has one owner whatever channel it came through. The failed journey is a cause to route to the digital team, not a reason to split ownership. You hold the complaint until the fix is made. | Tests whether you treat the channel shift as a complaints-ownership problem. Own the Fix covers it. |
| D1 | "Tell me about a complaint you took that you didn't want to hear." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Open prompt. A complaint whose substance you had to own, and what you did with it. If none comes to mind, say so plainly, then give the nearest thing: the log you handled, and what you did with the complaints in it. | Values stories are scored on the decision. Your material carries the log, not a decision, so the honest branch matters. |
| D2 | "Tell me about a time you had to tell a member no." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Open prompt. Say what the member needed, what you could offer, and what you said in words they could act on. If you have no such time, say so plainly and say what you would say now. | Theme: Plain Words, from the published values. The escalation script is the nearest sentence. It is not a story. |

Reverse questions, round 2:

- "When a complaint moves from a branch to the contact centre, who owns it today?" Why it lands: names the seam the role has to fix, and shows you read the JD line.
- "What would a successful first six months look like from your side?" Why it lands: their own success measure lets you tailor the next answer.
- "What does a good escalation from a branch supervisor look like to you?" Why it lands: the coaching line in the JD, in their own words.

## Round 3: panel of two branch managers, 60 minutes

Round weight: Values/Behavioral 4, Case/Strategist 2, Peer Evaluator 2, Data-Driven Prober 2. Values scoring is stated by the recruiter, so the four values carry one question each.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D3 | "Members First, Always: tell us a decision you made from the member's side of the counter." | VAL | [grounded] None of your sentences carries a member-side decision. The nearest is "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Selection scaffold: pick a decision where the member's view changed what you did. If none comes to mind, say so plainly. Then give the log you handled, and what it changed, if anything. | Scored per value. The record has no member-side decision, so the honest branch is the answer. |
| D4 | "Plain Words: tell us about a time you had to explain something to a member so it landed first time." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Open prompt. Pick a case where the explanation was the work. If none comes to mind, say so plainly. The escalation script you trained tellers on is the nearest thing your material carries, and only what you taught. | Plain Words is the value your material carries least. The nearest sentence is training, not explaining. |
| D5 | "Neighbours, Not Numbers: what does a branch's town need from its complaints process that a number would miss?" | VAL | [generic] Raised by the published value. | Structure: the town's trust in the branch; what a complaint looks like locally; the branch manager as the person who knows the town. If asked about the hub plan, say what you would want to learn before deciding anything, not a view on the plan. | A pattern question, led by the published value. The hub plan is the live tension, so the guidance takes no position on it. |
| D6 | "Own the Fix: tell us about a time you kept hold of a problem until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Open prompt. A problem you held through to a fix. If you handed it on, say to whom and whether you followed it up. If none comes to mind, say so plainly, then give the nearest thing: the complaints in your log, and what happened to them. | The value's own wording: whoever finds the problem keeps hold of it. Your material shows a log, not a fix. That is the honest gap. |
| C3 | "A member has been given two different answers, one by a branch and one by the contact centre, and has escalated. Walk us through the first twenty minutes." | CASE | [generic] Raised by the JD's end-to-end line and the Own-the-Fix value. | The twenty-minute case. Clarify first: what each channel said, what the member needs, and whether an external deadline applies. Ask; do not assume one. Name one owner who holds it until solved. Separate the fix for this member from the cause. Bring in the branch manager and the contact-centre lead, and the digital team if the answer came from a self-service screen. Say what you tell the member, in plain words. Say what you record for the monthly report. | The live case. The panel scores structure and ownership. The candidate may draw on no past here. |
| C4 | "A senior leader asks for the complaint trend on one slide. What goes on it?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Plan, not record. One measure, one trend, one action. Say how you would check the numbers before the slide. Hold to the plan: "I haven't presented above regional level; here is how I would build this." | Covers the presenting requirement through your stated negative. The answer is a plan, never a past. |
| E1 | "Our contact centre and branches sit side by side. Where's the seam, and what happens when we disagree about who owns a complaint?" | JD | [generic] Raised by the JD's end-to-end line. | Propose seam principles rather than pretending to know their seam: one owner per complaint, a named handover, a rule for disputes. If you have disagreed with another team about ownership, say what it was and how it ended. If not, say how you would settle it. | Peer probes look for turf awareness. Principles are safer than a claimed knowledge of a seam you have not seen. |
| E2 | "How do you handle credit when a complaint fix spans two teams?" | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Say what you did, and name the other team's work as theirs. If your part was the log, say that. | The peer's real question is whether the hire takes credit. Your record names only the log, and that is the part you can name. |
| P1 | "Which measures does the spreadsheet carry, and how were they counted?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Answer slot: how each measure was counted, in your own words. If there is a figure you would defend least, name its assumption before they do. If it carried no resolution times, say so plainly. | Defend-the-number applies to the spreadsheet's measures. You gave no figures, so the answer is the honest slot. |
| P2 | "What figures could you give us for the complaints you handled, and what would you need to check before quoting one?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Name any figure you can count, and say what you would check before quoting it. If you cannot give one, say so. A figure without a count behind it is the thing to avoid. | The figures are not in your material. This is the honest form of the probe. |

Reverse questions, round 3:

- "Where does a complaint's ownership most often break between the contact centre and the branches?" Why it lands: shows you think about the seam, and the answer shows where the panel's pain is.
- "What could a new person do in their first month that would genuinely help your team?" Why it lands: the reciprocity question for a peer panel. It turns the conversation toward what you bring.
- "If the hub plan goes ahead, what should the complaints process protect first?" Why it lands: ties Neighbours, Not Numbers to the live plan, and asks for their view rather than yours.
- "How does the panel decide a complaint is solved?" Why it lands: the Own-the-Fix closure test, in their words.

## Values cheat sheet (round 3)

| Value (official name) | Working meaning (paraphrased from your copy) | Mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter. | No mapped story. Selection scaffold in D3. Honest branch: say so plainly, then the nearest thing, the log you handled. |
| Plain Words | If a member needs it explained twice, the writing was the problem. | No mapped story. Selection scaffold in D4. Honest branch: say so plainly. The escalation script you trained tellers on is the nearest thing, and only what you taught. |
| Neighbours, Not Numbers | Every branch is part of its town. | No mapped story. Pattern question D5; no past claim is made. |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved. | No mapped story that shows a fix. Scaffold in D6. Honest branch: say what you held, and to whom you handed it on, if you did. |

## Prohibited claims

What this pack will not coach, with its basis and its honest form. Each entry is built from the snapshot.

| Not coached | Basis | Honest form |
|---|---|---|
| Ran complaints end to end across branches and the contact centre | Inflated form of F3 | "I handled the branch's formal complaints log." The limit, as the pack's own observation: your material shows one branch's log, not end-to-end ownership. |
| Worked in a contact centre | Sourced: you stated it | "I haven't worked in a contact centre." No slot. |
| Presented to senior leaders | Sourced: you stated it | "I've never presented to anyone above regional level." No slot. |
| Coached branch supervisors on escalations | Inflated form of F7 | "I trained new tellers on our escalation script." |
| Handled regulated complaints | Inflated form of F2 | "I handled the branch's formal complaints log." The limit, as the pack's own observation: your material does not say the log was regulated. B3 asks. |
| Built reporting on resolution times | Inflated form of F5 and F6 | "I built the monthly complaints spreadsheet our regional manager uses." |

## Upgrade menu

- Interviewer names for the three rounds, and for the two branch managers on the panel → persona weights per person, and a tailored reverse question for each. Panel names let personas be assigned per member instead of per round.
- Your CV as a document → quotes move from "your message" to "your CV", and any CV line the message did not carry joins the fit snapshot.
- One sentence on whether the spreadsheet counted volumes or resolution times → F6 moves from discovery to grounded, and A4, B7 and P1 get a settled answer.
- The recruiter's notes on focus areas, and any deliverable they have declared → a coverage check, and a graded-deliverable section if a presentation or take-home is named.
- The full text of the strategy brief → a grounding brief for the company questions, and sharper wording for C1 and C2.
- Deep research (L2), on your consent only: interviewer public talks and writing, role-family loop reports and recent Ashgrove news. Cost: up to six further searches and two further page fetches. It runs only if you say yes.
