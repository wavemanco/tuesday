Your prep pack for all three rounds is saved at /tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-tuesday-part-2-rooms-case-6-denied-777e5a0e/ff4d0127-275b-451e-b69f-347a3efe85b7/scratchpad/larkfield_engineering-manager_interview_pack.md. It has one fit snapshot shared across rounds, then a mini-pack for each: Tuesday's hiring manager, Thursday's panel, and Monday's VP round.

I built it from your message only. There was no JD text, no interviewer names, and no Larkfield values page, so I haven't run any web research. The values cheat sheet is left out of the VP round for that reason. The upgrade menu at the end of the file lists what each missing input would add.

The weakest rows are the ones with no story behind them: growing people, device-management or IoT work, and anything hardware-facing. The pack gives you honest answer slots for those, not invented stories. The highest-ROI prep is R1-S1, the Director's "which part would you be weakest at on day one" question.

Say the word and I'll play the Skeptic on R1-S1 as a live drill.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

1. Can you paste the full JD or the recruiter's posting? If not, I'll keep working from the role summary.
2. Do you want a research pass on Larkfield now? It would cover their values, the round structure and recent strategy, with up to 6 searches and 2 page fetches, several minutes. Without it, the VP round stays without a values cheat sheet.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: larkfield_engineering-manager_interview_pack.md -----
# Larkfield Systems: Engineering Manager, interview pack (three rounds)

**Role:** Engineering Manager, Larkfield Systems (industrial IoT, about 600 people). Two squads building device-management services; delivery, hiring and growth for 11 engineers; partnership with hardware and product on the roadmap.

**Rounds (loop mode):**
- R1: Tuesday, 45 min, Director of Engineering (hiring manager; would be your manager)
- R2: Thursday, 60 min, panel of two staff engineers and a product manager
- R3: Monday after, 30 min, VP Engineering, "values and leadership philosophy"

**Interviewer names:** not given, so there is no interviewer read and no per-member persona assignment for R2.

**Built from:** your message only (the role summary and your background). No JD text, no published Larkfield values, no research run. Research tier is L0; see Sources.

---

## How to use + type key

Personas describe how a question arrives. Types describe what is being scored.

- **VAL**: behavioral / values alignment
- **EXP**: work-experience deep-dive (attribution)
- **JD**: role-driven, scored against the role's listed requirements
- **CO**: company and strategy knowledge (none written at L0)
- **CASE**: live problem from the role, delivered in the interview

Guidance is scaffolding, not a script. Each cell is speakable in 90 to 120 seconds.

---

## Fit snapshot (shared across rounds)

Requirements come from the role summary in your message. Evidence is quoted verbatim from your message. There is no CV in this pack.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" (role summary, your message) | "9 years engineering, 3 as a team lead of 6" (your message) | medium | [grounded] | transferability | Your material shows one team of six, not two squads. Words: "For three years I was a team lead of six." Answer slot: if you ever ran more than one group at once, say how you split your time between them. If you did not, say so and name what you would do first with two squads. |
| F2 | "own delivery" (role summary, your message) | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." (your message) | medium | [grounded] | transferability | Your material shows one reliability quarter you pushed through, not ownership of a delivery plan. Words: "I pushed a reliability quarter through." Answer slot: if you owned the delivery plan for that quarter, say what you owned. If you pushed it through without owning the plan, say so and stay with the quarter. |
| F3 | "own ... hiring ... for 11 engineers" (role summary, your message) | "I run our hiring loop for backend roles — about 40 interviews last year." (your message) | medium | [grounded] | none | No gap in kind: the quote is hiring in role-relevant terms. Words: "I run our hiring loop for backend roles, about 40 interviews last year." Expect a probe on scope, since the quote says backend roles. |
| F4 | "growth for 11 engineers" (role summary, your message) | none given | none | [grounded] | discovery | Your material has no sentence about developing people. Answer slot: pick a time you developed someone on your team into a bigger role, and say what you did and what they did. If none comes to mind, say so plainly, then give the nearest thing your material carries (the team of six through a reliability quarter) and how you would grow eleven people. |
| F5 | "partner with hardware and product on roadmap" (role summary, your message), product half | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." (your message) | medium | [grounded] | transferability | Your material shows roadmap pressure you pushed against, not a partnership on the roadmap. Words: "I pushed a reliability quarter through against roadmap pressure." Answer slot: if you worked with product on a roadmap decision, name the decision and your part in it. If the pressure came from one side only, say so. |
| F6 | "partner with hardware and product on roadmap" (role summary, your message), hardware half | "I've never managed managers and never owned a hardware-adjacent roadmap." (your message) | none | [grounded] | capability | Your material records the absence in your own words. Words: "I haven't owned a hardware-adjacent roadmap." Then how you would learn it, said as a plan and never as a past. Never a claim to hardware roadmap work, and nothing added to make the gap feel smaller. |
| F7 | "build device-management services" (role summary, your message) | none given | none | [grounded] | discovery | Your material says nothing about device-management or IoT services. Answer slot: name any service you built and what it ran on, in your own words. If you have built none, say so, then say how you would learn the domain in the first quarter. |

**Gate rows:** none. The material names no eligibility, location, schedule or travel term.

---

## Prohibited claims

What this pack will not coach, and why. Each entry names its basis and its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Led two squads | Inflated form of F1. Your quote is one team of six. | F1's quote at its own scope. Limit, as the pack's observation: your material says one team of six. |
| Owned hiring (strategy, headcount, offers) | Inflated form of F3. Your quote is running the loop for backend roles. | F3's quote at its own scope: the loop for backend roles. |
| Drove the 60% on-call cut alone | Inflated form of the on-call sentence. The quote gives the team's burden and your push. | The sentence at its own scope: the team's on-call burden, after you pushed the quarter through. |
| Partnered with product on the roadmap | Inflated form of F5. | F5's quote at its own scope. |
| Managed managers | Negative you stated: "I've never managed managers." | Plain acknowledgment: "I haven't managed managers." No answer slot. |
| Owned a hardware-adjacent roadmap | Negative you stated: "never owned a hardware-adjacent roadmap." | Plain acknowledgment: "I haven't owned a hardware-adjacent roadmap." No answer slot. |

---

## Coverage map

Every requirement in the role summary, and the question IDs that cover it.

| Requirement | Question IDs |
|---|---|
| Lead two squads | R1-S4, R3-C1 |
| Build device-management services | R2-S1, R2-S2 |
| Own delivery | R1-C2, R3-V3 |
| Own hiring | R1-P2, R1-C3 |
| Growth for 11 engineers | R1-S3 |
| Partner with hardware | R1-S1, R1-C1, R2-E1 |
| Partner with product on roadmap | R2-C1, R3-V4, R2-E1 |

---

## Sources

**Provided documents:** your message (the role summary and your background). No JD text, no interviewer names, no published Larkfield values.

**Research tier: L0, no searches.** Research waits on your answer to question 2 in the message that presents this file. User links read: 0.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Larkfield Systems values | unavailable | Values cheat sheet, which is dropped from R3 until published values are in hand. R3's VAL questions use the recruiter's own words as their theme. |
| 2. Larkfield interview process, engineering manager | unavailable | Confirms the loop structure. The persona weights here follow your description of each round. |
| 3. Larkfield strategy and recent news | unavailable | CO questions for R3 and R2. None are written, because at L0 they would go generic. |
| 4. Interviewer names with Larkfield | n/a | No names were given, so there is no query to form. |
| 5. Representative Engineering Manager JD | unavailable | Fit snapshot rows and JD-tagged questions would rest on a typical posting instead of the role summary. |

---

## Round 1: Director of Engineering (hiring manager), Tuesday, 45 min

**Persona table (weights shown; total 11 questions):**

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (weight 4, top) | Probes the hardware gap, the growth gap and the two-squad step | Hiring-manager prior: they are buying capability and derisking gaps. Three of seven rows (F4, F6, F7) have no story, or only a stated absence. | Rehearse R1-S1 until it is boring. |
| Case/Strategist (weight 3) | A live delivery or roadmap problem on the partnership | Hiring-manager prior. The role summary names the roadmap work. | Clarify, objective, approach, metrics, risks. Name one challenged assumption. |
| Data-driven Prober (weight 2) | The 60% figure and the 40 interviews | Two headline figures in your message. Prober depth follows the figure. | Know how each was counted, or say plainly that you do not. |
| Pressure (weight 2) | A time-boxed challenge on the hardware gap or the reliability quarter | Low: the hiring-manager prior does not lead with it. | Pause, restate, hold through two follow-ups, concede the specific part. |

**Question bank:**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R1-S1 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "never owned a hardware-adjacent roadmap" (your message) | Name the hardware-adjacent roadmap as the part, in your words: "I haven't owned a hardware-adjacent roadmap." Then the first thirty days you would spend closing it, as a plan. Hold through two follow-ups by returning to the plan. Never describe the roadmap as owned. Answer slot: if any part of the role is one you have already done, name it. If none is, say so. | Highest-ROI prep in this round. F6 is the one requirement your material records as a stated absence, and this stem asks for the weakest part directly. JD because it scores the partnership requirement. |
| R1-S2 | "Why this role, given what you said you have never owned?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." (your message) | Motivation in two beats: what in device-management you want to own, and what in your reliability work carries over, in the quote's own scope. Do not claim IoT or hardware experience. Answer slot: if the connection is only the reliability work, say so and say why you still want the role. | Skeptic motivation probe. The honest answer rests on F2 and F6 only. |
| R1-S3 | "Tell me about a time you developed someone on your team into a bigger role." | JD | [generic] open prompt, theme from the role summary's "growth for 11 engineers". Guidance rests on [grounded] "9 years engineering, 3 as a team lead of 6" (your message). | Selection scaffold: pick someone whose growth you influenced, and say what you did and what they did, in your words. Answer slot: if no such person comes to mind, say so plainly, then give the nearest thing your material carries (the team of six through a reliability quarter) and how you would grow eleven. | F4 is a discovery row. The open prompt's theme comes from the role summary, so the question is raised, not presumed. |
| R1-S4 | "You have been a team lead of six. Why would two squads be the next step you can take?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6" (your message) | Hold the quote: three years as a team lead of six. Say what the six did together, in your words, then the step: two squads is more than the group you have led, and you would say so. Answer slot: if you have led more than one group at once, say how. If you have not, say so and name the first thing you would do with two squads. | Cross-examines the bridge in F1, which is transferability, not a match. |
| R1-C1 | "The hardware team needs a device-management change in two quarters, and product wants the roadmap cut to make room. What do you do first?" | CASE | [generic] | Clarify the hardware constraint and who owns the date. Separate the product trade from the engineering trade. Name the metric for the cut. Take the decision to the group, not around it. Think aloud, and name one assumption you are challenging. No claim about your past is needed. | A live problem from the partnership requirement, asked as a decision. [generic] because it is a pattern for this kind of trade, not a fact about Larkfield. |
| R1-C2 | "A squad is forty percent behind on a device-management milestone with two weeks left. Sketch your next 48 hours." | CASE | [generic] | Say what you need to know first: scope, the blocker, who is blocked. Then what you do with the team today, and what you tell product and when. Name the metrics you need before you commit to a date. | Scores the delivery requirement on a live problem, without asking about your past. |
| R1-C3 | "You are asked to hire the first backend engineer for a new squad. What do you do before the first interview?" | CASE | [generic] | Scope the role, set the bar, agree the loop and who decides. Say what you would check in the first screen. | Lets you show the hiring loop you run (F3) in a live setting, without claiming a past. |
| R1-P1 | "Walk me through how the 60% was counted." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." (your message) | Defend-the-number slots, in your words: how it was counted; what it is sensitive to; the assumption you would defend least; which part was yours. Name the weakest assumption before they do. Do not supply a baseline, window or denominator. Answer slot: if you counted it, say how. If you did not, say so and say what you can say about it. | Headline figure on your material. The coverage rule requires a defend-the-number slot for it. |
| R1-P2 | "Describe the backend hiring loop you run, stage by stage." | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." (your message) | Story-mapped on F3: the loop, and its roughly forty interviews, in the quote's own words. Answer slot: for each stage, say what you decided and what was set before you. If you set none of it, say so. | F3 is the strongest row. The stage probe tests whether "run" means "set". |
| R1-X1 | "Sixty seconds: why should we take you over someone who has run hardware roadmaps?" | JD | [grounded] "never owned a hardware-adjacent roadmap" (your message) | Pause and restate. Anchor in what you said: "I haven't owned a hardware-adjacent roadmap." Hold through two follow-ups, with the reliability quarter and the loop you run, both in quoted terms. Concede the specific part you do not know yet, and name it. Never fold on the quarter. | Pressure persona: time-boxed, a composure test. JD because the question is the partnership requirement. |
| R1-X2 | "That reliability quarter. How much of it was actually you?" | EXP | [grounded] "I pushed a reliability quarter through against roadmap pressure." (your message) | Hold-then-concede. "I pushed it through" is the claim. Name the parts that were the team's and concede them plainly. Do not upgrade "pushed through" to "decided". | Attribution probe on F2, under time pressure. |

**Reverse questions (no interviewer profile, so none tied to a career path; not a peer, so no reciprocity question):**

| # | Question | Why it lands |
|---|---|---|
| R1-R1 | What would make the first ninety days look like the right hire, from where you sit? | Turns a probe into a success-criteria conversation, and shows you plan against the role. |
| R1-R2 | Where do you expect the two-squad roadmap to slip first over the next two quarters? | Names a real risk without assuming one, and shows you think about delivery. |
| R1-R3 | Which roadmap decisions sit with product today, and which with the hardware team? | Asks for the partnership map, the first thing the role depends on. |
| R1-R4 | What did the last person in this seat get right, and what would you want different? | Shows you want the real constraints, and how this seat has been run. |
| R1-R5 | Which of the eleven roles are open first, and what does the hiring plan look like? | Gives you a conversation about hiring, your strongest area. |

---

## Round 2: panel (two staff engineers, one product manager), Thursday, 60 min

**Persona blend (total 10 questions; weights shown):**
- Staff engineers (each): Peer Evaluator and Data-driven Prober, the peer prior. Peer Evaluator is the top weight.
- Product manager: Peer Evaluator and Case/Strategist. The roadmap is the product manager's ground, and the cross-functional prior would add Values, which this panel does not own.

| Persona | Weight | How it shows up | Counter-strategy |
|---|---|---|---|
| Peer Evaluator | 4 (top) | Seam between squads and the hardware team; credit; disagreement with equals | Propose seam principles, not claimed knowledge of their seam. Reciprocity: what you bring their team. |
| Data-driven Prober | 2 | Headline figures; what was in the quarter | Name the weakest assumption; say plainly what you did not count. |
| Case/Strategist | 2 | A roadmap trade on a date the squads cannot hit | Clarify before structuring. Name the number that decides. |
| Skeptic | 2 | Device-management domain; the hardware partnership you have not run | Hold with the plain acknowledgment; concede the specific part. |

**Question bank:**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R2-E1 | "Our squads sit beside the hardware team. Where is the seam, and what happens when you disagree?" | JD | [grounded] "pushed a reliability quarter through against roadmap pressure" (your message) | Propose seam principles, not claimed knowledge of their seam. Use the quote only: the quarter was pushed against roadmap pressure. Say who applied the pressure, if you know. The quote does not say. Answer slot: if you disagreed with another team's lead and it resolved, name it. If not, say so and say what you would do first. | Peer stem. The seam is the partnership requirement (F5). Peer evaluators score what a hire costs their team. |
| R2-E2 | "How do you handle credit when work spans teams?" | JD | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." (your message) | Keep "team" for the outcome and "I" for the push, as the sentence does. Say where credit went and who else touched the quarter. Answer slot: if credit was contested, say how it was settled. If it was not, say so. | Credit probe. The 60% sentence already splits team and self, so use its split. |
| R2-E3 | "Tell me about a time you said no to another team's request. What happened?" | JD | [generic] open prompt, theme from the persona stem | Selection scaffold: pick a no that changed something. Say what you asked for, what the other team needed, and how it ended. If you have not said no to a peer team, say so, then give the closest decision you made with a partner team. | Peer probe on disagreement style, with equals. |
| R2-E4 | "Our teams sit side by side. What would you need from me in your first month?" | JD | [generic] | Answer with what you bring their team, not only what you need. Name one thing a staff engineer on this team gets from you. Make no claim about your past beyond your own sentences. | Peer probe on partnership. Its answer carries weight in a peer panel. |
| R2-P1 | "Which assumption behind the 60% would you defend least?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." (your message) | Weakest-assumption move, in your own words, before they name one. The pack names no assumption. Answer slot: if you counted it, name the assumption you would defend least. If you did not, say so and say what the 60% rests on as far as you know it. | Same figure as R1-P1, asked for the assumption rather than the method. |
| R2-P2 | "What was in the reliability quarter?" | EXP | [grounded] "I pushed a reliability quarter through." (your message) | Describe the contents in your words, item by item. Answer slot: if you chose the items, say how. If the work list came from elsewhere, say so. Do not reconstruct a list you did not keep. | Tests attribution of contents to F2. |
| R2-C1 | "The PM wants a device-management feature on a date your squads cannot hit. What do you need to know before you answer?" | CASE | [generic] | Clarify the date's source and what it protects. Then objective, segmentation of the feature, approach, metrics, risks. Think aloud, and challenge one premise. | Case stem from the roadmap partnership. No claim about your past. |
| R2-C2 | "An error budget is burning, and the roadmap still wants the launch date. Which number decides it?" | CASE | [generic] | Name the number before the decision: the burn rate, the blast radius, what the date costs. Say what you would not commit to yet. | Prober-leaning case. Asks nothing about your past. |
| R2-S1 | "Which part of device-management services would you be slowest to get up to speed on?" | JD | [grounded] "never owned a hardware-adjacent roadmap" (your message) | Name the part in your words. The hardware side is the quoted gap. Plan to learn it, as a plan. Hold through two follow-ups, and concede specifically. Answer slot: if you have built any device-facing service, name it and what it ran on. If you have not, say so. | Skeptic probe on the domain gap (F7) and the hardware gap (F6). |
| R2-S2 | "Why should the panel trust your read on a hardware partnership you have not run?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." (your message) | Hold with the plain acknowledgment: "I haven't owned a hardware-adjacent roadmap." Then what in your reliability work supports the read, in its own terms, and the limit. Do not argue that the read equals running one. | Second Skeptic item. The hold carries the limit. |

**Reverse questions (peer panel, so one reciprocity question):**

| # | Question | Why it lands |
|---|---|---|
| R2-R1 | What is the worst thing about the current device-management stack, and what would you fix first? | Shows you want to know what the panel lives with. |
| R2-R2 | Where do product and the hardware team disagree most often? | Names the seam. Peers answer that candidly. |
| R2-R3 | What does a good working relationship between a staff engineer and an engineering manager look like here? | Puts you in the peer's frame, and signals that you want their input. |
| R2-R4 | What could a new engineering manager do in the first month that would genuinely help your team? | Reciprocity: the peer's own question, asked back. Lands because the panel scores peer fit. |
| R2-R5 | What has failed in cross-team roadmap planning here, and what changed afterwards? | Shows you ask about failure, which a Prober rewards. |

---

## Round 3: VP Engineering, Monday, 30 min ("values and leadership philosophy")

The values cheat sheet is not included: no published Larkfield values are in hand. It returns with the upgrade menu. The recruiter's own words name a values round, so VAL questions are in the bank, themed on those words.

**Persona table (weights shown; total 10 questions):**

| Persona | Weight | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|---|
| Values/Behavioral | 4 (top) | Scored behavioral conversation on "values and leadership philosophy" | The recruiter names a values round, so this persona is guaranteed. The VP is usually outside the function. | One practice, anchored in what you did. Name a hard truth only if you carried one. |
| Case/Strategist (skip-level) | 3 | Altitude questions on two squads and the hardware date | Skip-level prior: altitude and composure. | Clarify, objective, approach, risks. Say what you would not promise. |
| Pressure | 3 | Time-boxed challenge on whether a first-time manager should be trusted with eleven | Skip-level prior: composure, time-boxed answers. | Pause, restate, hold through two follow-ups, concede the specific step. |

**Question bank:**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R3-V1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "pushed a reliability quarter through against roadmap pressure" (your message) | Story map: the quarter, the roadmap pressure you were under, what you pushed for. "We" for context, "I" for what you did. If the quarter contained a hard truth you carried upward, say it. If not, say so and give the nearest thing your material carries. | Theme from the recruiter's "leadership philosophy". The quarter is your only stated story for it. |
| R3-V2 | "What is your leadership philosophy? Give me one practice you would keep." | VAL | [grounded] "9 years engineering, 3 as a team lead of 6" (your message) | Answer from what you have done, not a slogan: one practice, anchored in the team of six. If the practice came from somewhere else, say where. If you have no philosophy beyond what you did with six people, say so plainly. | Theme from the recruiter's words. The VP will test whatever you claim here. |
| R3-V3 | "Tell me about a time a team you led hit a deadline and paid for it in quality." | VAL | [generic] open prompt, theme from the role summary's "own delivery" | Selection scaffold: pick a deadline met at a cost you chose. Name the trade, who decided, and what you would change. If none, say so, and give the nearest trade-off you made. | Open prompt. No event is supplied. |
| R3-V4 | "How do you decide what to say no to?" | VAL | [generic] open prompt, theme from the role summary's "partner with ... product on roadmap" | Name the criteria you use to refuse a roadmap item. Then one you actually refused, and what happened. If you have not refused one, say so and say what you would use. | Theme from the partnership requirement. |
| R3-C1 | "Eleven engineers, two squads, and a roadmap partner who wants the hardware date pulled in. What is your first leadership move?" | CASE | [generic] | Structure: what the date protects and who asked, what the squads can truthfully commit to, who must be in the room, the first conversation. Say what you would not promise. | Skip-level altitude test on the two-squad and partnership requirements. |
| R3-C2 | "The VP wants a two-quarter plan for device-management reliability. What do you need to know first?" | CASE | [generic] | Clarify the reliability target and ask for the baseline before you set one. Then the team constraints, objectives, approach, risks. | Strategy-heavy skip-level case. No CO claim, since L0 research means none is written. |
| R3-C3 | "Your strongest engineer says the plan is wrong. What do you do in the next 48 hours?" | CASE | [generic] | Listen before answering. Get the disagreement in writing. Decide with the data you have, and say what you would reverse if you are wrong. | Tests composure and decision-making under disagreement. |
| R3-X1 | "Sixty seconds: why should we bet on you over someone who has managed managers?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." (your message) | Pause and restate. Hold with the plain acknowledgment: "I haven't managed managers." Hold through two follow-ups with the three years of leading six and the loop you run. Concede the step you have not taken, and name it. | Pressure at skip-level. The sourced negative is one the VP can check. |
| R3-X2 | "That 60%. How much of it was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." (your message) | Hold the push as yours, and concede the team's share plainly. Do not add a baseline or method. | Attribution pressure on the headline figure. |
| R3-X3 | "Who on your team would tell me the quarter was theirs, not yours?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." (your message) | Name the work the team would claim, if you know it. Concede the share plainly. Do not fold on the push itself. | Composure probe on attribution. |

**Reverse questions:**

| # | Question | Why it lands |
|---|---|---|
| R3-R1 | What makes an engineering manager succeed here after twelve months, in your view? | Shows you plan to the VP's measure. |
| R3-R2 | Which decisions do you expect your managers to make without you? | Puts delegation on the table, which is the leadership-philosophy point. |
| R3-R3 | What changed about who decides in engineering in the last reorg? | Reads the real decision rights, and shows you have looked. |
| R3-R4 | What would make you say in six months that this was the wrong hire? | Turns risk into a shared criterion, and the VP answers candidly. |
| R3-R5 | Where do you see engineering and hardware drift apart first? | Asks the VP to name the seam, and shows you already think about it. |

---

## Upgrade menu

- **The full JD text** → the seven rows in the fit snapshot are graded against the posting's words. F2 and F5 become checkable, and the JD-tagged questions firm up.
- **Larkfield's published values or leadership principles** → adds the values cheat sheet, and turns R3-V1 to R3-V4 into mapped answers.
- **Research consent** (question 2 in the message) → L1 values page, loop structure and strategy sweep, up to 6 searches and 2 page fetches. Confirms the round structure, and writes CO questions for R2 and R3.
- **Panel and VP names and titles** → per-member persona assignment for R2, and a short interviewer read for each round.
- **Two or three more stories, only what happened:** a team you grew (upgrades R1-S3 from answer slot to story map), a device-facing system you built (F7, R2-S1), a time you disagreed with a peer team (F5, R2-E1, R2-E3).
- **How the 60% and the 40 interviews were counted** → R1-P1, R1-P2, R2-P1 and R3-X2 move from defend-the-number slots to answers you can repeat. The answer must be your own.
