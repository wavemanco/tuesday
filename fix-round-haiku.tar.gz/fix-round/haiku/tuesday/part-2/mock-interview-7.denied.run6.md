Your prep pack is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-tuesday-part-2-rooms-case-7-denied-047be9ef/e5f893e9-c59e-48ae-8e97-fa314ced635d/scratchpad/saltmarsh-games_live-operations-producer_interview_pack.md`.

I built it as a hiring-manager round, since you didn't say who is in the room. I used only the JD and your message. The web searches were denied, so nothing about Saltmarsh, Tobias or their interview process is in the pack unless it's labeled `[generic]`.

The three things to prepare most:

- **The one-title gap (B1).** The JD asks you to run live events across two titles. Your material shows one title and weekly content drops. Hold the calendar you actually ran, concede the scale difference plainly, and name your first step with the second title. Don't add a second title or any events.
- **Team leadership (B2, D1).** Say "I've never led a team" once, then move to what coordination means in this role. Don't claim leadership.
- **Retention numbers (C1, D2).** You presented them. Say what you did and didn't drive, and admit it if you never knew how they were counted.

Say the word and I'll play the Skeptic on B1. I can also save a `tuesday-dossier.md` with the gaps this prep exposed, or convert the pack to Word.

Two quick questions:
1. Is Tobias the person who'd manage this role, or is someone else in the room? Did the recruiter mention a presentation or a task?
2. How much time do you have before Friday?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview prep pack: Live Operations Producer, Saltmarsh Games

**Round:** 60-minute interview, Friday. **Interviewer:** Tobias Wrenfield, Head of Live Operations. **Relationship:** assumed hiring manager (you did not say who is in the room). **Built from:** the JD and your message only. Web searches were denied, so no company, interviewer or process facts are established; every such fact is labeled `[generic]` or left out.

## How to use this pack

- **Personas** describe how a question is asked. **Types** describe what is being scored: **VAL** behavioral/values, **EXP** your experience, **JD** the job's stated requirements, **CO** company knowledge, **CASE** a live problem.
- Guidance is scaffolding, not a script. Rehearse the beats, in your own words.
- Where a guidance cell says **answer slot**, answer it from what you actually did. Either branch of the slot is a valid answer.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years producing live-service games or apps" (JD) | "4 years as an associate producer at a puzzle-game studio" (your message) | medium | [grounded] | presentation | Say it in your terms: "I spent four years as an associate producer at a puzzle-game studio." Your material does not say whether the studio called its game live-service. F2 is the nearest proof. Do not add the phrase to your sentence. |
| F2 | "experience running a content calendar" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | none | No gap. This is a claim with nothing inspected behind it, so expect a probe. Lead with the calendar in your own terms: weekly, one title, two years. |
| F3 | "comfortable with player-retention metrics" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | medium | [grounded] | discovery | The sentence shows you presented retention numbers, not that you built or read them alone. Answer slot: if you produced or analysed those numbers, say which steps were yours; if you presented numbers someone else built, say so plainly. |
| F4 | "clear written communication" (JD) | "Wrote the release checklist our QA team still uses." (your message) | medium | [grounded] | presentation | Written work that a team still uses reaches the requirement in other terms. Say: "I wrote the release checklist our QA team still uses." Let the document and its users make the case for clarity. |
| F5 | "Plan and run the live-events calendar for two of our mobile titles" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | transferability | Adjacent work: one title, content drops, not live events. Say: "For two years I ran the weekly content-drop calendar for our main title." Your material shows one title. Answer slot: the two-title line makes a probe likely. If you planned events or another title's schedule, say which. If not, say so plainly and name the first thing you would do with the second title. |
| F6 | "coordinate design, art, engineering and community teams on each update" (JD) | "Wrote the release checklist our QA team still uses." (your message, touches QA only) | low | [grounded] | discovery | Your material shows work with QA, not with design, art, engineering or community. Answer slot: if you coordinated any of those four teams on a release or drop, say which team and what you agreed. If not, say so plainly and say how you would start with them. |
| F7 | "own the post-event review and the KPIs it reports" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | low | [grounded] | discovery | Your material shows a presented KPI, not a post-event review. Answer slot: if you ran a review after any drop or event, say what it covered and what changed. If not, say so plainly and describe the review you would run. |
| F8 | "manage the release checklist with QA" (JD) | "Wrote the release checklist our QA team still uses." (your message) | medium | [grounded] | presentation | Reaches the checklist and QA's use of it. Say: "I wrote the release checklist our QA team still uses." Do not describe sign-off or release decisions you did not make. |
| F9 | Leading people: not stated in the JD; the JD says coordinate. [generic] | "Never led a team" (your message) | none | [grounded] | capability | Your own negative. Words: "I've never led a team." The closure path is F6's answer slot, not a claim of leadership. |
| F10 | Revenue mechanics such as in-app purchases: not named in the JD. [generic] | "never worked on a game with in-app purchases" (your message) | none | [grounded] | capability | Your own negative. Words: "I've never worked on a game with in-app purchases." Mobile live-ops teams often track revenue next to retention `[generic]`, so expect this to come up. |

## Persona table

The relationship prior for a hiring manager is Case/Strategist plus Skeptic (`personas.md`). No loop source establishes Saltmarsh's process, so the fallback is the generic archetype (screen, hiring manager, panel), with flat weights. The weights rest on that pattern, not on this company's documented process.

| Persona | How it shows up | Weight | Why | Counter-strategy |
|---|---|---|---|---|
| Skeptic | "one title, two titles"; "never led a team"; in-app purchases | 5 | Hiring-manager prior; F5, F9 and F10 are the largest gaps in the material | Rehearse B1 until it is boring. Bridges come only from sentences you wrote. State limits plainly. |
| Case/Strategist | Plan a two-title event week; diagnose a retention drop | 4 | Hiring-manager prior: they are buying capability for the JD's headline scope | Clarify, then objective, segmentation, approach, metrics, risks. Name one premise you would challenge. |
| Data-Driven Prober | Where retention numbers came from; which KPIs you own | 3 | F3 is a presented number with no method shown | Say how a figure was counted if you know. If you don't, say so. |
| Pressure | "Why not someone who has led a team?" | 3 | Panel-style devil's advocate on F9 | Pause, restate, hold through two follow-ups, then concede the specific point. |
| Conversational | "Walk me through the journey" | 2 | Opening arc; casual questions are still scored | A 90-second arc built only from your quoted lines. |
| Behavioral (open prompts) | Two teams wanting different dates; bad news to a senior person | 2 | JD's coordinate line raises it | Selection scaffold ending in an honest branch. |
| Peer Evaluator | Where your job ends and engineering's begins | 2 | Coordination across teams; a peer on the team is possible | Seam principles, not claims about their team. |

## Question banks

**Requirement coverage:** 3+ years live-service: E1. Content calendar: B1. Player-retention metrics: A2, C1, C3. Clear written communication: C4. Plan and run two titles: A1, B1, B5. Coordinate four teams: A3, B2, F1, G1, G2. Post-event review and KPIs: C3, C4. Release checklist with QA: A4. Not in the JD, but likely: B2, B3, D1.

**Highest-ROI prep: B1.** It is the most predictable objection, and the material's largest scope gap.

### A. Case/Strategist (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Two of your titles are launching an event in the same week. Walk me through how you'd plan the calendar." | CASE | [generic] a live problem; no claim about you | Clarify first: which teams are in the launch, what the QA window is, what can slip. Then objective, sequence, and what you would hold back. Treat the release checklist as a fixed constraint. End on the one metric you would read after the event. Speakable in 90 to 120 seconds. | The JD's two-title line is the scoring sheet. F5 is where the gap sits, so rehearse the plan without claiming past events. |
| A2 | "A retention number drops 8% the week after an update. How do you find out why?" | CASE | [generic] | Segment before concluding: platform, version, cohort, exposure to the update. Separate the update from anything else that shipped that week. Name what you would rule out first, and which team you would ask for telemetry. | F3's requirement is retention. This tests reasoning, not your history. |
| A3 | "Design wants a change that engineering says will slip the drop. Who decides, and how?" | JD | [grounded] "coordinate design, art, engineering and community teams on each update" (JD) | Name the decision rights you would check first: who owns the calendar, who owns the discipline that breaks. Say what evidence you would ask for, the call you would make, and who you would tell. Do not claim you have made such a call. | F6 is discovery. This is the answer shape before the slot question. |
| A4 | "Walk me through the release checklist you wrote and how QA uses it today." | EXP | [grounded] "Wrote the release checklist our QA team still uses." (your message) | Story-mapped on the sentence: you wrote it, and QA still uses it. Tell those beats in your words. Answer slot: the JD's "manage" line makes a probe on sign-off likely. If you ran sign-off or set release gates, say which and how. If QA owned those, say so plainly and describe what the checklist covered. | F8. The JD's manage line is the raising source for the probe. |

### B. Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've run one title's content drops. What makes you ready to run live events across two?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." (your message); [grounded] "Plan and run the live-events calendar for two of our mobile titles" (JD) | Hold: "For two years I ran the weekly content-drop calendar for our main title." Name the parts of that job that carry over, in your words, such as the weekly cadence and the sequencing. Concede explicitly what you have not done: run events, or a second title. Answer slot: if you planned any event or another title's schedule, say which. If not, say so plainly and name the first thing you would do with the second title. Hold through two follow-ups by returning to the calendar, never by adding to it. | Deepest rehearsal. F5 is the biggest scope gap and the JD's headline. The premise, one title, is the quote's own scope. |
| B2 | "You've never led a team. This role coordinates four teams on every update. What's the difference, in practice?" | JD | [grounded] "Never led a team" (your message); [grounded] "coordinate design, art, engineering and community teams on each update" (JD) | Plain acknowledgment first: "I've never led a team." Then say what coordination needs from you in this role, in your words. Answer slot: if you coordinated work across any of those teams, say which and how. If not, say so plainly and say how you would build those relationships in the first month. | F9 and F6: the capability gap and its discovery slot. Nothing is added to the negative. |
| B3 | "You've never worked on a game with in-app purchases. How would you learn what matters there?" | JD | [grounded] "never worked on a game with in-app purchases" (your message) | Plain acknowledgment: "I've never worked on a game with in-app purchases." Then a learning plan, in the future tense: who you would ask, what you would read first. | F10. The plan is a plan, not a past. |
| B4 | "Four years on one puzzle title. Why this role, and why now?" | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio" (your message) | Your material does not give your reason, so the pack cannot supply one. Answer slot: give the reason in your words, tied to something the role actually asks, such as two titles or live events. Do not borrow the JD's vocabulary as your motive. | Motivation probes come from skeptics. The reason has to come from you. |
| B5 | "What would you need to have done in your first month for the second title to be in good shape?" | JD | [grounded] "Plan and run the live-events calendar for two of our mobile titles" (JD) | Plan, not claim. In week one: inspect the current calendar, the checklist and the last review; meet the people who own each piece; name one deliverable for day 30. Future tense throughout. | The Skeptic's ramp plan. |

### C. Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through the monthly retention numbers you presented: where they came from." | EXP | [grounded] "Presented the monthly retention numbers to the studio head." (your message) | Story-mapped on the sentence: monthly, presented, the studio head. Answer slot: where the figures came from. If you calculated them, say how and on what definition. If they came from a dashboard someone else built, say so plainly and say what you checked. Name the assumption you would defend least, in your words. If you never knew how they were counted, say that. | F3. |
| C3 | "The role owns the KPIs it reports. Which three would you own first, and why those?" | JD | [grounded] "own the post-event review and the KPIs it reports" (JD) | Name three KPIs, one line each on why, tied to the two-title shape: a retention metric, an event participation metric, a content metric. Plan only, no past claim. | F7. The JD's KPI line, answered as a plan. |
| C4 | "What goes into the write-up after an event, and who reads it first?" | JD | [grounded] "own the post-event review and the KPIs it reports" (JD); [grounded] "clear written communication" (JD) | Structure: what was planned, what happened on the KPIs, what you would change, and who acts. Answer slot: if you have written any review, a drop review or a release review, say what it covered and what changed. If none, say so and describe the one you would write. | Covers the JD's review line and its written-communication line. |

### D. Pressure (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why should I hire a producer who's never led a team over one who has?" | JD | [grounded] "Never led a team" (your message) | Pause, then restate. Hold: the role coordinates, and you carry the calendar you ran for two years and the checklist QA still uses, in those words. Concede specifically: "I haven't led a team, and I won't claim I have." Hold through two follow-ups. Never fold to "I'm a natural leader." | F9, the largest capability gap. Hold, then concede. |
| D2 | "The monthly retention numbers you presented: how much of what they showed was actually you?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." (your message) | Hold: you presented the numbers. Say what you did and what you did not drive. If a figure moved because of work you did, say which work. If you presented numbers you did not drive, say so. | F3. Attribution is the probe, and candor is the answer. |
| D3 | "Two titles is double the job of the one you've run. You're not ready for it." | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." (your message); [grounded] "for two of our mobile titles" (JD) | Hold the calendar's record. Concede the scale difference explicitly. Name the first step, not a claim of readiness. | F5 under pressure. |

### E. Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey. Puzzle studio to here." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio" (your message); [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | A 90-second arc. Four years as an associate producer, the calendar, the checklist, presenting retention, and one line on what you want next. Each beat is one of your quoted lines. | Casual, and scored. Also covers the 3+ years line. |
| E2 | "What live-ops calendar do you admire, and what does it do well?" | CO | [generic] a pattern; no claim about the company | Name one game you know well. Describe what its cadence tells you and one lesson you would take. Make no claim about Saltmarsh. | Warm opener that tests whether you follow the industry. |

### F. Behavioral, open prompts (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Tell me about a time two teams wanted different dates for the same release." | EXP | [grounded] "coordinate design, art, engineering and community teams on each update" (JD, the theme) | Selection scaffold: pick a real date clash, name the stake, and say what you decided. If none comes to mind, say so plainly, then give the nearest thing your material carries: the release checklist with QA, or the content-drop calendar. | F6. An open prompt: you choose the instance. |
| F2 | "Tell me about a time you had to tell someone senior that a plan wasn't working." | EXP | [grounded] "Presented the monthly retention numbers to the studio head." (your message) | Selection scaffold: pick a time you brought bad news to someone senior, the stake, the moment you did not soften it, and what followed. If the retention numbers were that moment, say what they showed. If not, say so, and give the nearest thing. | Behavioral stem. The theme comes from the persona table, not from a claim about your history. |

### G. Peer Evaluator (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Where does your job end and the engineering lead's begin on an event launch?" | JD | [grounded] "coordinate design, art, engineering and community teams on each update" (JD) | Seam principles, not claims: who owns the date, who owns the build, who can say no to a date, and who can say no to a build. Do not pretend to know their seam. Say what you would ask in week one. | Peer seam. |
| G2 | "What would engineering need from a producer before a build locks, so they don't route around you?" | JD | [generic] a role-family pattern | Reciprocity: name three things a producer must bring, such as a fixed scope, a test window, and a named decision owner. Plan voice. | Peer reciprocity, the question a peer uses to price the hire. |

## Reverse questions

Interviewer profile: none beyond the title, so no question is tied to his career path. Each "why it lands" is about the job.

| # | Question | Why it lands |
|---|---|---|
| R1 | "What would a strong first 90 days look like for whoever runs this calendar?" | Shows you plan for the job, not just the interview. |
| R2 | "How are the two titles' calendars decided today, and who can say no to a drop?" | Tests the seam with the other teams, and reveals decision rights. |
| R3 | "Where has a post-event review changed a decision here, and where has one been ignored?" | Shows you care whether reviews move anything. |
| R4 | "Which KPIs get targets, and which are tracked without one?" | Shows you know how metrics mature, and the answer tells you the state of their measurement. |
| R5 | "What has the release checklist caught recently, and what does QA still find by hand?" | Connects your checklist to their current gaps. |
| R6 | "What would make you say this hire was right at six months?" | The hiring manager's own success criteria, asked directly. |

## Prohibited claims

Each entry has its basis and its honest form. No slot, bridge, question or guidance cell in this pack asserts these.

| Not coached | Basis | Honest form |
|---|---|---|
| Ran live events across two titles | Inflated form of F2 and F5 | F2's quote at its own scope. The material shows one title and content drops, not two titles or events. |
| Owned the KPIs and the post-event review | Inflated form of F3 and F7 | "Presented the monthly retention numbers to the studio head." Presenting is not owning. |
| Led a team | Your own negative, F9 | "I've never led a team." |
| Credited with a retention lift | Inflated form of F3; no quote claims a change | F3's quote at its own scope. No change is claimed. |
| Managed release sign-off with QA | Inflated form of F8 | "I wrote the release checklist our QA team still uses." |
| Worked on a game with in-app purchases | Your own negative, F10 | "I've never worked on a game with in-app purchases." |

## Sources

- **Provided documents:** the JD text, and your message (the background, the team and the gaps). No CV was provided.
- **Searches sent:** four, all refused by the permission prompt, and not retried:
  1. "Saltmarsh Games values": refused
  2. "Saltmarsh Games interview process Live Operations Producer": refused
  3. "Saltmarsh Games mobile studio news strategy": refused
  4. "Tobias Wrenfield Saltmarsh Games Head of Live Operations": refused
- **Fetches:** none.
- **Values cheat sheet:** omitted. No values-style round is detected: no loop source establishes the loop, and the fallback archetype is generic, which reads `no`.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | unavailable | Values cheat sheet, section omitted; it would have named the company's own values |
| 2. `Saltmarsh Games interview process Live Operations Producer` | unavailable | Loop structure and round names; persona weights rest on the generic pattern instead |
| 3. `Saltmarsh Games strategy` / recent news | unavailable | Company-level CO questions are generic `[generic]`; E2 and the reverse questions carry no company facts |
| 4. `Tobias Wrenfield Saltmarsh Games` | unavailable | Interviewer read omitted; reverse questions are not tied to his career path |
| 5. representative `Live Operations Producer` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Approve the four searches on a re-run → the company's values, the interview process and recent strategy, and Tobias's public footprint: an interviewer read, personal persona weights, and a reverse question tied to his path.
- A copy of the release checklist you wrote, or a redacted screenshot → F4 and F8 move from `medium` toward `high` by giving the claim an inspectable artifact.
- A calendar document or a redacted screenshot of one → F2 and F5 get the same lift.
- Two or three sentences on why you want this role → B4 gets an answer you can say, rather than a slot.
- Your prep time before Friday → the prep triage section, sized to your hours.
- A `tuesday-dossier.md` from job-underwriter → verified evidence and absolute prohibited claims, in place of the locally built list.
