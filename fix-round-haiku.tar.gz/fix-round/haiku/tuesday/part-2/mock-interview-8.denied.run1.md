Your prep pack is saved as /tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/haiku/tuesday/part-2/rooms/case-8-denied-1da74087/ashgrove_member-experience-lead_interview_pack.md. Because you have three rounds on the same day, it's organised as a loop: one shared fit snapshot, then a mini-pack for each round with its own persona weights.

The main finding: your material shows nothing on the contact centre, presenting above regional level, or digital work, and none of your sentences carries a story for any of the four values. The pack therefore gives you plain acknowledgments and plans for the gaps, and honest selection scaffolds for the values. It does not give you stories to borrow. Your two real stories for B1 and B3 are the highest-value prep you can do this week.

Say the word and I'll run a drill on B5, the question the pack names as highest-ROI prep. I'll play the Skeptic and add a pressure follow-up. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

Is the panel's 20-minute case given as a written brief, or read out in the room? It changes how C1 should be rehearsed.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove_member-experience-lead_interview_pack.md -----
# Interview prep pack: Member Experience Lead, Ashgrove Credit Union

**Rounds:** three on 20 November 2026, run as a loop. Times not given.
- **Round 1:** recruiter screen, 30 minutes.
- **Round 2:** Head of Member Services, 45 minutes, mostly behavioural. This is your future manager. Name not given.
- **Round 3:** panel of two branch managers, 60 minutes, including a 20-minute complaint-escalation case. The panel scores you against the four values. Names not given.

**Today:** 11 November 2026. Nine days to the first round.

---

## 1. How to use this pack

- **Personas** describe how a question arrives. **Types** describe what it scores.
- Type key: **VAL** is behaviour measured against the published values. **EXP** is a deep-dive into your own work. **JD** is a requirement from the job description. **CO** is company and strategy. **CASE** is a live problem.
- Guidance is scaffolding, not a script. Say it in your own words. Quoted text is either your own sentences from your message or words Ashgrove published.
- An **answer slot** means the interviewer may ask about something your material does not show. Take the branch that is true for you.

## 2. Prep triage (nine days)

1. **11–12 Nov: the two gaps you cannot avoid.** Write your answers to B5 (contact centre) and B6 (presenting above regional level). Each is a plain acknowledgment plus a plan. A plan is something you will do, not something you have done.
2. **11–13 Nov: two real stories.** For B1 and B3, find one complaint from your branch years that you kept hold of to close, and one time a figure pointed one way while your branch's situation pointed the other. If you have no such story, say so in the room. Do not borrow one.
3. **14–15 Nov: the 20-minute case.** Run C1 twice out loud with a timer. Clarify before you structure, both times.
4. **16 Nov: drill B5 with a pressure follow-up.** The hold-then-concede move is the one to practise.
5. **17 Nov: the brief.** If you can get the strategy brief's text, paste it and check A2, B9, B10 and C2 against its wording.
6. **18 Nov: logistics and reverse questions.** Have your notice period, pay expectations and where you could work from ready. Choose five reverse questions for each round.
7. **19 Nov: one read-through.** No new material. Rest.

Everything else is insurance.

## 3. Fit snapshot (shared across all rounds)

Sources: your message, and the job description as you pasted it. No CV was supplied, so your background comes from your message alone.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches and the contact centre" (JD) | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message; "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | medium | [grounded] | transferability | Your material shows the branch's formal complaints log, not an end-to-end process and not the contact centre. Keep the bridge at branch scope: "For the branch, I handled the formal complaints log." For the contact centre, the stated negative: "I have never worked in a contact centre." Answer slot: the JD's end-to-end line makes a probe on which steps you set likely. If you set any step from first contact to close, say which and how you decided. If you did not, say so and say what you would map first. |
| F2 | "coach branch supervisors on escalations" (JD) | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material shows training for tellers, not coaching for supervisors. Bridge: "I trained new tellers on our escalation script." Answer slot: if you have coached a supervisor on an escalation, say how, in your own words. If you have not, say the training was for tellers, and describe how you would coach supervisors. |
| F3 | "report monthly on complaint volumes and resolution times" (JD) | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | The sentence reaches monthly complaints reporting. It does not show whether the sheet counts volumes or resolution times. The spreadsheet itself is the inspectable artifact; an anonymised copy would raise confidence. Answer slot: say what the spreadsheet counts. If it records resolution times, say how they were measured. If it does not, say so and say what you would add first. |
| F4 | "comfortable with Excel reporting" (JD) | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | presentation | The quote reaches reporting in other words: your message says spreadsheet, the JD says Excel. Reword only that sentence: "I built the monthly complaints spreadsheet our regional manager uses." Do not state an Excel skill level; your material does not give one. |
| F5 | "4+ years in financial-services customer operations" (JD) | "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | none | Met as written. Say the quote in your own words. Confidence is medium because the years are stated but not yet backed by a document you could show. |
| F6 | "experience handling regulated complaints" (JD) | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | low | [inferred] | discovery | Derivation: this pack reads your word "formal" as the JD's "regulated". Your material does not say what rules governed the log. Do not describe it as regulated. Answer slot: expect a probe on which rules applied. If a regulator's rules or timetable governed the log, say which and what you had to do under them. If none did, say what "formal" meant in your branch. |
| F7 | "confident presenting to senior leaders" (JD) | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A stated absence. Words: "I've never presented to anyone above regional level." Then a plan, said as a plan: what you would do to prepare before your first monthly report. Never a claim to presenting experience. |
| F8 | "work with digital teams on self-service journeys" (JD) | none given | none | [grounded] | discovery | Silence is discovery, not capability: your message does not mention digital work either way. Answer slot: if you have worked with a digital or product team on a journey a member uses, say which and what your part was, in your own words. If not, say so plainly and say how you would start. The brief's digital target makes a probe likely. |

## 4. Prohibited claims

Built from the fit snapshot. These are claims the pack will not coach you to make, with the honest form of each.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned complaints end to end across branches and the contact centre | Inflated form of F1 | "I handled the branch's formal complaints log." Limit, in this pack's analysis: your material shows the branch's log, not the end-to-end process or the contact centre. |
| Coached branch supervisors on escalations | Inflated form of F2 | "I trained new tellers on our escalation script." |
| Regulated complaints handling | Inflated form of F6 | "I handled the branch's formal complaints log." Whether a regime governed it is for you to settle, in your own words. |
| Resolution times tracked in the spreadsheet | Inflated form of F3 | "I built the monthly complaints spreadsheet our regional manager uses." Say what it counts, in your words. |
| An Excel skill level | Inflated form of F4 | "I built the monthly complaints spreadsheet our regional manager uses." No skill level is stated. |
| Presenting to senior leaders, or to anyone above regional level | Negative you stated (F7) | "I've never presented to anyone above regional level." |
| Contact-centre work of any kind | Negative you stated (F1) | "Never worked in a contact centre." Then the plan. |

## 5. Grounding brief

[grounded] Your summary of Ashgrove's 2026 strategy brief, as you relayed it. The brief's text was not pasted, so check every wording against the document before you use it.

| Move | What it says | Used in |
|---|---|---|
| Digital | "move 40% of member service to digital channels by 2028" | A4, B10, C2 |
| Branch network | "consolidate eight branches into five hubs over 2027" | B9, C2 |
| Lending | "launch a small-business lending product in Q1 2027" | A2 (sounding current) |
| Competitive frame | "the main competitive pressure is app-only banks" | A2, B10 |

Sound current, not archival. Use the brief's words, not your memory of them.

---

## 6. Round 1: recruiter screen (30 minutes)

**Persona table**

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport Builder | Warm opener, "walk me through", casual questions about the JD's topics | Top weight, 5 of 8 questions. A recruiter screen is conversational by prior, and the casual questions are still scored. | Pre-scripted 90-second arcs. Treat casual questions on digital and presenting as scored. |
| Skeptic (light) | Checks the two stated absences and motivation | Mid weight, 3 of 8. The recruiter is screening F1 and F7, and the reason for the move. | Plain acknowledgment plus a plan. Do not bluff. |

**Question bank**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through your path to where you are now." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | 90-second arc: six years in retail banking, the last three as a branch supervisor, then what that role covered, in your words. Stop there. Do not add a role you have not stated. | The biography question is scored for economy. F5 is its evidence. |
| A2 | "What drew you to Ashgrove, and why this role now?" | CO | [grounded] your summary of the brief: "move 40% of member service to digital channels by 2028" | Name one of the three moves you would want to be part of, and why, in your own words. Do not claim experience with it. | Motivation consistency, tested against the brief the recruiter sent. |
| A3 | "You've never worked in a contact centre. What makes you think you can run complaints across one?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Plain acknowledgment: "I have never worked in a contact centre." Then what you did carry: "I handled the branch's formal complaints log." Then a plan: what you would map first about complaints in a contact centre. Do not say you have handled contact-centre complaints. | This is the highest-ROI objection in this round. F1 is its evidence. |
| A4 | "What are you playing with in digital at the moment?" | JD | [grounded] JD: "work with digital teams on self-service journeys" | Answer slot: if you have worked with a digital or product team on a journey, say which and your part. If not, say so plainly and say how you would start. | A casual question on a JD requirement is scored. F8 is a silence row. |
| A5 | "The role needs you to be confident presenting to senior leaders. Where are you on that?" | JD | [grounded] "I've never presented to anyone above regional level." | Plain acknowledgment: "I haven't presented above regional level." Then a plan: how you would prepare the first monthly report with your manager. | F7 is a stated capability gap. The recruiter will judge how you say it. |
| A6 | "What would you need to learn first in this role?" | JD | [generic] | Name one or two requirements where you have no evidence to point to. Use only the negatives you have stated, such as the contact centre and presenting above regional level. For the rest, say how you would learn them. | A casual version of "what would you be weakest on". The answer is scored. |
| A7 | "Why are you leaving your branch now?" | EXP | [generic] | Say why, in your own words, about what you want next. Do not describe your employer. | A motivation-consistency knockout. Your material does not say why you are moving, so the answer has to come from you. |
| A8 | "You've trained people before. Tell me about that." | EXP | [grounded] "trained new tellers on our escalation script" | Story-mapped: what you taught, and how you knew it had stuck. Answer slot: if you have ever coached a supervisor on an escalation, say how. If not, say the training was for tellers. | F2 is the JD's coaching line. Recruiters test whether a teller trainer can scale to supervisors. |

**Reverse questions**

| # | Question | Why it lands |
|---|---|---|
| R1 | What does a good first 90 days look like in this role? | Shows you think in outcomes. |
| R2 | Who owns a complaint once it moves from a branch to the contact centre today? | Finds the seam the role depends on. The answer is the role's real scope. |
| R3 | Which of the three moves is changing the day-to-day most, and when? | Uses the brief the recruiter sent you. |
| R4 | What has the person before this role found hardest? | Signals candour, and tells you where the pain is. |
| R5 | What are the next steps after the 20th, and how long do they take? | Logistics, asked as a candidate who is planning. |

---

## 7. Round 2: Head of Member Services (45 minutes, behavioural, your future manager)

**Persona table**

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | Scenario probes tied to the four values, with STAR-shaped stories expected | Top weight, 5 of 10. The recruiter said mostly behavioural, and this manager is judging how you would run complaints. | A story for each value where one exists. Where none exists, the honest scaffold. |
| Skeptic | Probes the scope gap, the presenting gap and the regulated-complaints gap | Mid weight, 3 of 10. Your manager will test whether you can run what the JD asks. Pressure is tested through the follow-ups to B5. | Plain acknowledgment plus a plan. Hold, then concede precisely. |
| Case / Strategist | One live question on the hubs and on digital | Light, 2 of 10. A manager with a strategy agenda may ask one live problem. | Clarify, then structure out loud. |

**Question bank**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a complaint you kept hold of until it was solved." | VAL | [grounded] "Own the Fix — whoever finds the problem keeps hold of it until it is solved." and "I handled the branch's formal complaints log" | Selection scaffold: pick a complaint from your branch years where you had to keep it moving to close. Name what you did at each step you actually took. If none ran all the way to close, say which step you did not own, and what you would have done. Your complaints log is where to find candidates, not the story itself. | Your material carries no story for this value. The scaffold forces an honest pick, and the honest branch is allowed. |
| B2 | "When did you decide something from the member's side of the counter that the procedure did not cover?" | VAL | [grounded] "Members First, Always — we decide from the member's side of the counter." | Selection scaffold: a decision where a member's situation and the written procedure pointed apart. Say what you chose, who you told, and what happened. If none, say so, then give the nearest case you handled by the book and what you would change now. | No quoted sentence of yours carries a story for this value. |
| B3 | "Tell me about a time a figure pointed one way and a branch's situation pointed the other." | VAL | [grounded] "Neighbours, Not Numbers — every branch is part of its town." | Selection scaffold: name a number you used, what it said, and what you knew about the branch that it did not. Say what you did. If your figures have always been enough on their own, say so, and give the nearest case. Do not credit the spreadsheet with a change of mind unless one happened. | Your spreadsheet is the natural pull toward a numbers story. This question tests whether the story is yours. |
| B4 | "Tell me about an explanation you rewrote because a member came back with the same question." | VAL | [grounded] "Plain Words — if a member needs it explained twice, we wrote it wrong." | Selection scaffold: an explanation, letter or script you rewrote, and what changed on the second contact. If you have not rewritten one, say so, and say how you would find out whether ours need it. | Your escalation script is the nearest artifact. Whether it was plain is not established. |
| B5 | "Your experience is a branch's complaints log, and you've never worked in a contact centre. How would you run complaints across branches and the contact centre?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." and "Never worked in a contact centre, and I've never presented to anyone above regional level." | Hold, then concede. Open: "The part I've done is the branch's log." Hold: return to the log and to your plan for the contact-centre side. Concede precisely: "I have never worked in a contact centre. That is the part I would learn first." Pressure follow-up, "why shouldn't we hire someone who has?": "You may be right about the experience. Here is what I'd bring from the branch side, and how I'd close the contact-centre gap in the first 90 days." Answer slot: if any complaint you handled came through the phone or a contact centre, say so. If none did, say so. | The most likely objection in this round, and the highest-ROI prep in the pack. Deepest rehearsal. |
| B6 | "This role presents to senior leaders monthly. Where are you on that?" | JD | [grounded] "I've never presented to anyone above regional level." | Plain acknowledgment: "I haven't presented above regional level." Then a plan: what you would do before your first monthly report, such as rehearsing with your manager or asking for a review. | F7 is a stated capability gap, and the manager will judge how it is said. |
| B7 | "What made the branch's formal complaints log formal?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Answer slot: if a regulator's rules or timetable governed the log, say which and what you had to do under them. If none did, say what "formal" meant in your branch. Do not use the word "regulated" unless you say it. | F6 is low confidence and inferred. The JD's "regulated complaints" line makes this probe likely. |
| B8 | "How would you coach a branch supervisor who sends every complaint up the chain?" | VAL | [grounded] "coach branch supervisors on escalations" (JD) and "trained new tellers on our escalation script" | Answer slot: if you have coached a supervisor on an escalation, say how. If not, say the training you did was for tellers, then describe how you would coach a supervisor. | F2 is transferability. The JD's coaching line makes this a likely question. |
| B9 | "The brief consolidates eight branches into five hubs over 2027. What would you need to know before you planned the complaints side?" | CASE | [grounded] your summary of the brief: "consolidate eight branches into five hubs over 2027" | Clarify, then: objective; segmentation (which complaints move with which branch, and which towns lose theirs); approach; metrics (volumes and resolution times by branch, before and after); risks (member trust in towns that lose a branch). Speakable in two minutes. | Case-led question, grounded in the recruiter's brief. It makes no claim about your past. |
| B10 | "The brief moves 40% of member service to digital by 2028. What would you protect from that move?" | CO | [grounded] your summary of the brief: "move 40% of member service to digital channels by 2028" | Say which complaints must stay with a person, and why, before you name any digital step. Then say what you would measure. | Tests altitude. It separates complaints from routine service, and it makes no claim about your experience. |

**Reverse questions**

| # | Question | Why it lands |
|---|---|---|
| R1 | Where do you want the complaints process to be in two years, with eight branches becoming five hubs? | Asks your manager to state a direction. |
| R2 | When a complaint moves from a branch to the contact centre today, who holds it? | Finds the scope gap. The answer shows what you would inherit. |
| R3 | What would make you say this hire has worked after six months? | Surfaces success criteria you can plan against. |
| R4 | How is the role split between coaching supervisors and running the process? | Asks about the two halves of the JD. |
| R5 | What is one thing you would want a new lead not to change in the first quarter? | Shows respect for the team you would join. |

---

## 8. Round 3: panel of two branch managers (60 minutes, including a 20-minute case)

**Values-style round.** The recruiter's email says the panel scores against the four values. This round holds the values cheat sheet.

**Persona table**

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | Scores each answer against one of the four values | Top weight, 4 of 10. The recruiter said the panel scores on the values. | A story per value, or the honest scaffold. |
| Case / Strategist | The 20-minute escalation case, followed by a probe | Fixed weight, 2 of 10: the case is a set slot. | Clarify, objective, segmentation, approach, metrics, risks. |
| Peer Evaluator | Seams between branches and the contact centre, credit, "what would you need from me" | Mid weight, 2 of 10. Two branch managers are peers to the role you would lead. | Reciprocity framing. Propose seam principles, not a pretended knowledge of their seam. |
| Data-Driven Prober | Asks how the spreadsheet counts | Low weight, 2 of 10. A branch manager may ask about the spreadsheet you built. | Say what a row means and where the figures came from. If you cannot say, say so. |

**Values cheat sheet**

| Value (official name) | Working meaning | Your mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | None of your quoted sentences carries a story. Selection scaffold: pick a decision where you chose the member's side against a rule or a target. If none, say so, and give the nearest one with what you would do now. |
| Plain Words | If a member needs it explained twice, we wrote it wrong | None carries a story. Selection scaffold: pick an explanation you rewrote after a second question. If none, say how you would test one. |
| Neighbours, Not Numbers | Every branch is part of its town | None carries a story; no quoted sentence of yours speaks to a town. Selection scaffold: pick a time a branch's local situation changed what a number meant. If none, say how you would find out. |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | F1 carries "handled" but not "to solved". Selection scaffold: pick a complaint you kept hold of to close. If none ran to close, say which step you did not own. |

**Question bank**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A member's fee complaint has moved between your branch and the contact centre for three weeks. They now say they'll take it outside the credit union if it isn't fixed this week. You have twenty minutes: what do you do?" | CASE | [generic] | Clarify first: what the member has been told, what each side holds, whether any money has moved, and what "fixed" means to the member. Objective: one owner and a date. Segmentation: one-off or pattern. Approach: name the owner today, send one plain update, then fix the step that stalled. Metrics: time to first contact, time to resolution, repeat contacts. Risks: losing the member, and a pattern that keeps repeating. | The case is generic on purpose. It presumes nothing about your past. |
| C2 | "Two of those eight branches are about to close into a hub, and the member is from one of them. What changes?" | CASE | [grounded] your summary of the brief: "consolidate eight branches into five hubs over 2027" | Say how the member's town changes the message, not the fix. Name the metric you would watch in the hub. | Tests whether the case survives the strategy. |
| C3 | "In that case, who owns the member's complaint until it's closed, and what do you hold yourself to?" | VAL | [grounded] "Own the Fix — whoever finds the problem keeps hold of it until it is solved." | Name yourself as the holder. Give the date you would check back, and what you would tell the member at each check. No past claim is needed. | Links the case to the value without asking for a story. |
| C4 | "When did you put a member ahead of a target?" | VAL | [grounded] "Members First, Always — we decide from the member's side of the counter." | Selection scaffold: a decision where the member's side and an internal target pointed apart. Say what you chose and what it cost. If none, say so, and give the nearest one. | Your material carries no such story. The honest branch is allowed. |
| C5 | "How do you make sure a branch in a town is judged on more than its complaint numbers?" | VAL | [grounded] "Neighbours, Not Numbers — every branch is part of its town." | Selection scaffold: a time you did this, and what you looked at besides the numbers. If none, say how you would do it, and what you would look at first. | Tests the value against the spreadsheet you built, without assuming the answer. |
| C6 | "Show us what you would change in a complaint letter a member finds hard to follow." | VAL | [grounded] "Plain Words — if a member needs it explained twice, we wrote it wrong." | Hypothetical, so no past claim. Ask what the member needs to do next, cut the letter to that, and test it on one colleague who has not read the file. | Plain Words, scored as a short task. |
| C7 | "Our branches and the contact centre sit side by side. Where is the seam for complaints, and what happens when we disagree about who owns one?" | JD | [grounded] JD: "Own the member complaints process end to end across branches and the contact centre" | Propose principles, not the seam: one owner until the complaint closes; the first person to see it logs it; a disagreement goes to a named person within a set time. Say plainly that you do not yet know their seam, and that these are what you would test. | A peer probe. Principles are not claims about their seam. |
| C8 | "Tell me about work a different team fixed that you were part of. How did you credit them?" | VAL | [generic] | Selection scaffold: a time another team fixed something you were part of, and how you credited them. If none, say what you would do. | Peer credit probe, asked as an open prompt. |
| C9 | "Walk us through how the monthly complaints spreadsheet counts a complaint." | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Say what one row means, what counts as one complaint, and where the figures came from. Answer slot: if you cannot say what a row means, say so. | A premised question on your own artifact. The JD's "monthly complaint volumes" line makes it likely. |
| C10 | "What does the spreadsheet not tell you about a complaint?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Answer slot: if it records resolution times, say how they are measured. If it does not, say so, and name what you would add first. | Covers the resolution-time half of the JD's reporting line without presuming the sheet has that column. |

**Reverse questions**

| # | Question | Why it lands |
|---|---|---|
| R1 | What could a new person do in their first month that would genuinely help your branches? | Reciprocity, which suits a peer panel. It shows you are thinking about their load. |
| R2 | Where do complaints most often stall between a branch and the contact centre? | Finds the seam. The answer shows what you would fix first. |
| R3 | What does a good escalation look like to you, as a branch manager? | Asks for the standard they will score against. |
| R4 | When two branches are both involved in one complaint, who makes the call? | Finds how ownership works in practice. |
| R5 | What is one thing you would keep from the way the branches handle complaints today? | Shows respect for what already works. |

---

## 9. Requirement coverage

| JD requirement | Covered by |
|---|---|
| Own the complaints process end to end across branches and the contact centre | A3, B5, C1, C7; fit F1 |
| Report monthly on complaint volumes and resolution times | B9, C9, C10; fit F3 |
| Coach branch supervisors on escalations | A8, B8; fit F2 |
| Work with digital teams on self-service journeys | A4, B10; fit F8 |
| 4+ years in financial-services customer operations | A1; fit F5 |
| Experience handling regulated complaints | B7; fit F6 |
| Confident presenting to senior leaders | A5, B6; fit F7 |
| Comfortable with Excel reporting | C9; fit F4 |

Every requirement has at least one question. The CV has no figures beyond tenure, so no defend-the-number slots apply. If the spreadsheet holds counts, they become one (see the upgrade menu).

## 10. Sources

- **Provided documents:** your message (background, round details, the JD as pasted); the recruiter's email as you quoted it (round structure and the panel's values scoring); the values text as you pasted it from ashgrovecu.org/about/values on 11 November 2026; the strategy brief as your summary.
- **Searches and fetches sent:** none.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | The values text you pasted this morning fixes the names and wording in the values cheat sheet. |
| 2. Ashgrove interview process | skipped | The recruiter's email names the three rounds, who runs each, and what the panel scores. That loop source establishes the loop, so no archetype fallback is used. |
| 3. Ashgrove strategy and recent news | skipped | Your summary of the brief fixes the CO inputs. It is your summary, not the brief's text, and the grounding brief says so. |
| 4. Interviewer name | n/a | No names were given for the Head of Member Services or the panel, so there was no query to form. |
| 5. Representative JD | skipped | The JD was supplied. |

## 11. Upgrade menu

- **Your spreadsheet, anonymised, or a description of its columns** → F3 and F4 gain an inspectable artifact. C9 and C10 get a walkthrough you can defend, including whether the sheet records resolution times.
- **Two real stories from your branch years** → B1 to B4 and the values cheat sheet swap their scaffolds for stories you have actually told.
- **The strategy brief's text** → A2, B9, B10 and C2 quote the brief instead of your summary.
- **The names of the Head of Member Services and the two panel members** → an interviewer read, and persona weights for each person.
- **The panel case's format, written or read out** → C1 is reshaped to match.
- **A deeper research pass (L2)**, up to 6 more searches and 2 more fetches, several minutes → recent organisational context for B9 and B10: leadership, reorganisations, hiring. Offered once. Say if you want it.
