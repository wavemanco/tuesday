Your prep pack is saved at /tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-tuesday-part-2-rooms-case-8-canned-94caae4c/bab92298-34d4-46fc-bf33-a9a35f449c14/scratchpad/ashgrove_member-experience-lead_interview_pack.md. I built it for all three rounds, with a shared fit snapshot, values cheat sheet and prohibited-claims list, plus a question bank for each round.

Say the word and I'll play the Skeptic on S5, the question the pack names as its highest-ROI prep. I can also save a tuesday-dossier.md recording the gaps this prep exposed (F1, F3, F5, F7, F8), for later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove_member-experience-lead_interview_pack.md -----
# Interview prep pack: Member Experience Lead, Ashgrove Credit Union

Three rounds on 20 November 2026 (loop mode). Prepared 11 November 2026. First version.

## How to use

- **Personas** describe how a question arrives. **Types** describe what is being scored.
- **Types:** VAL = values alignment, scored against the published values. EXP = your own experience, tested for attribution. JD = the job's stated requirements. CO = company and strategy knowledge. CASE = a live problem, with no claim about your past.
- **Guidance is scaffolding, not a script.** Say things in your own words, and only what you did.
- **Answer slot:** where a line says "answer slot," there are two honest branches: your own experience, or a plain statement that it was not yours or did not happen. Never give an answer you could not repeat under a second question.
- **Provenance:** [grounded] = traceable to your message, the JD, the values page you pasted, the recruiter's email, or your summary of the strategy brief. [inferred] = a derivation, named where used. [generic] = a pattern, not a fact about Ashgrove or about you.

## Fit snapshot (shared across rounds)

Evidence is quoted from your message, unless marked otherwise. Confidence medium means you confirmed it and there is limited inspectable proof, so expect a probe.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches and the contact centre" (JD) | "I handled the branch's formal complaints log" (your message); "Never worked in a contact centre" (your message) | medium | [grounded] | transferability | Your material says one branch's formal log, not the process end to end, and nothing about the contact centre. Words that stay at that scope: "I handled the branch's formal complaints log." Answer slot: if you owned any stage of the process beyond the log, say which and how you decided, in your own words. If you did not, say so plainly and stay with the log. |
| F2 | "report monthly on complaint volumes" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | medium | [grounded] | presentation | Your sentence reaches monthly complaint reporting in its own terms: a monthly sheet, used by your regional manager. Words: "I built the monthly complaints spreadsheet our regional manager uses." No further claim. What the sheet counts is a probe, see B7. |
| F3 | "resolution times" (JD) | none given | none given | [grounded] | discovery | Your material does not show whether the sheet counts how long complaints take. Answer slot: if it did, say how it was counted, in your own words. If it did not, say so and say what you would measure first. |
| F4 | "coach branch supervisors on escalations" (JD) | "I trained new tellers on our escalation script" (your message); "6 years in retail banking, the last 3 as a branch supervisor" (your message) | medium | [grounded] | transferability | Your material says tellers, on a script. It does not say supervisors. Words: "I trained new tellers on our escalation script." Answer slot: if you coached anyone through an escalation decision, say who and what you did. If you did not, say so and describe how you would approach it. |
| F5 | "work with digital teams on self-service journeys" (JD) | none given | none given | [grounded] | discovery | Nothing in your material shows digital work. Answer slot: if you worked with a digital or IT team on a channel or form, say what it was and what your part was. If not, say so and say how you would start. |
| F6 | "4+ years in financial-services customer operations" (JD) | "6 years in retail banking, the last 3 as a branch supervisor" (your message) | medium | [grounded] | none | Met on your sentence. Say the years in those words. This is a length-of-experience line, not a gate. |
| F7 | "experience handling regulated complaints" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | discovery | Your material says formal. It does not say which rules governed the log. Answer slot: if you know the rules and timescales that applied, name them in your own words. If you do not, say so and say how you would find out. |
| F8 | "confident presenting to senior leaders" (JD) | "I've never presented to anyone above regional level." (your message) | none | [grounded] | capability | Your own words set the limit. Words: "I've never presented to anyone above regional level." Then a plan, said as a plan: how you would prepare for a senior audience. Never a claim to presenting above regional level. |
| F9 | "comfortable with Excel reporting" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | medium | [grounded] | presentation | Your sentence reaches Excel reporting in its own terms. Words: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: name the functions you used, in your own words, and say which you are less sure of. |

**Gates.** No JD requirement is a gate (a term such as location, schedule, pay, travel or a licence). The JD says nothing about where the role will be based after the branch consolidation, so that is an upgrade-menu question, not a fit row.

## Grounding brief (shared)

Source: your summary of Ashgrove's July 2026 strategy brief. I have not seen the document itself, so these are your words, not quotes from the brief. Paste the brief and these become exact quotes.

- "move 40% of member service to digital channels by 2028" [grounded, your summary]
- "consolidate eight branches into five hubs over 2027" [grounded, your summary]
- "launch a small-business lending product in Q1 2027" [grounded, your summary]
- "the main competitive pressure is app-only banks" [grounded, your summary]

Vocabulary to use: digital channels, hubs, member service. Use the brief's words, not "transformation" or other framings. No stale framings were flagged, because I have not read the brief.

## Prohibited claims (shared)

Built locally from the fit snapshot. These are not to be coached in any answer, slot or drill.

| Not coached | Basis | Honest form |
|---|---|---|
| "I owned the complaints process end to end" | Inflated form of F1 | F1's quote at its own scope. The limit is this pack's observation: your material says one branch's log. |
| "I've coached branch supervisors on escalations" | Inflated form of F4 | The tellers quote at its own scope. |
| "I've presented to senior leaders" | Negative you stated, F8 | "I've never presented to anyone above regional level." No slot on senior audiences above regional. |
| "I've worked in a contact centre" | Negative you stated, F1 | "Never worked in a contact centre." Plain acknowledgment. |
| "I know the rules that govern formal complaints" | Inflated form of F7 | The "formal complaints log" quote at its own scope. |
| "I'm advanced in Excel" | Inflated form of F9 | The spreadsheet quote at its own scope. |

Not listed, because they are silence rather than claims you made: resolution times, digital work, and what the sheet counts. Those are answer slots.

## Values cheat sheet (shared; lives with Round 3)

Detected: yes. Your recruiter's email says the panel scores against the four values. Working meanings are paraphrased from the values page you pasted.

| Value (official name) | Working meaning | Your mapped material |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | F1 and "I handled the branch's formal complaints log" carry a log, not a member's side. Selection scaffold: pick a complaint where the process and the member's side pulled apart. Say which side you took and what you did. Honest branch: if none did, say so and give the nearest log case. |
| Plain Words | If a member needs it explained twice, we wrote it wrong | "I trained new tellers on our escalation script" carries a script, not a member explanation. Selection scaffold: pick a time you changed how something was explained to a member. Honest branch: if the script was used as written, say so and say how you explained outcomes. |
| Neighbours, Not Numbers | Every branch is part of its town | "I built the monthly complaints spreadsheet our regional manager uses" carries the numbers side only. Selection scaffold: pick a time a figure and a branch's situation disagreed. Honest branch: if they never did, say so. Your material is number-heavy and says nothing about towns. |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | "I handled the branch's formal complaints log" says handled, not held until solved. Selection scaffold: pick a case you held until it closed. Honest branch: if the log moved cases on without you, say so. |

Your material supports the four values thinly. Four short stories from you, one per value, would change this table (see the upgrade menu).

---

## Round 1: Recruiter screen (30 minutes, with the recruiter)

**Persona weights.** Conversational, top weight (5 questions): a recruiter screen is friendly and scored on economy, motivation and logistics. Skeptic, light (3): the contact-centre and scope gaps get put directly.

| Persona | How it shows up | Weight and reason | Counter-strategy |
|---|---|---|---|
| Conversational / rapport | Open, chatty; "walk me through" | Top: screens run in this register | 90-second arc from your own sentences; treat casual questions as scored |
| Skeptic, light | Puts the gap in one plain sentence | Middle: the recruiter screens for the obvious gaps | Acknowledge once, plan once, return to what you did |

### Conversational (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| S1 | "Walk me through your journey so far, in ninety seconds." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "I handled the branch's formal complaints log and trained new tellers on our escalation script"; "I built the monthly complaints spreadsheet our regional manager uses" | Three beats in this order, each in your own words: the six years and the last three as a supervisor; the complaints log and the teller training; the monthly spreadsheet. Add no years, titles or results. | The opener every later answer starts from, so keep it to sentences you can repeat. F6, F4, F2. |
| S2 | "Why a member-owned credit union, rather than a bank?" | CO | [grounded] JD: "member-owned" | Answer slot: say what draws you and why member ownership matters to you. The pack has no source for your reasons, so they have to be yours. | A motivation probe in the recruiter's casual register. The answer must be yours, not the values page's. |
| S3 | "Walk me through your years in financial-services customer operations." | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | Say the years and the role in those words. The 4+ years line is met on this sentence. Do not stretch retail banking into work you did not do. | F6. A length-of-experience line, not a gate. |
| S7 | "How comfortable are you with Excel for reporting?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Answer slot: name the functions you used on that sheet, in your own words. Say which ones you are less sure of. Do not claim a skill level you cannot repeat. | F9. Asked casually, so it is scored as a JD probe. |
| S8 | "What would you do in your first thirty days?" | JD | [generic] | Plan, not past. Name the first complaint file you would read and who you would meet first. The answer is a plan, so it needs no source from your history. | Tests whether you have read the JD's scope. Recruiters weight this as a preparation signal. |

### Skeptic, light (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| S4 | "You haven't worked in a contact centre. How would you get up to speed on one?" | JD | [grounded] "Never worked in a contact centre" | Plain acknowledgment: "I haven't worked in a contact centre." Then a plan, said as a plan: name two things you would learn first and how. | F1's contact-centre gap, put directly. A light probe, so keep the answer short. |
| S5 | "Tell me about the widest scope of complaints work you've been accountable for." | JD | [grounded] JD: "Own the member complaints process end to end across branches and the contact centre" | Open prompt, pick the widest instance honestly. Answer slot: if you were accountable beyond one branch's formal log, say what and how far. If you were not, say so plainly and stay with the log. | **Highest-ROI prep in this pack.** The most predictable objection: one branch's log against an end-to-end, two-channel requirement. It also returns as P8 in the panel. Rehearse until the plain concession is routine. |
| S6 | "Describe the formal complaints log you handled: what went into it, and what came out." | JD | [grounded] "I handled the branch's formal complaints log" | Story-mapped on the log, using the sentence's own beats: you handled it, for one branch. Answer slot: if you know which rules or timescales applied to it, name them. If you do not, say so and say how you would find out. | F7. The JD's word "regulated" is not in your sentence, so the rules are the slot. |

**Reverse questions (Round 1)**
- "What does a good first three months look like in this role?" Why it lands: it makes the recruiter describe the priorities, and your first-month answer then matches them.
- "Which of the four values does the panel score most often in complaints work?" Why it lands: it shows you read the values page, and tells you what the panel will test.

---

## Round 2: Head of Member Services (45 minutes, behavioural, your future manager)

**Persona weights.** Values/Behavioral, top (5): the manager said mostly behavioural. Skeptic (4): motivation, the senior-audience gap and the metric probes are this manager's natural territory. Case (1): one live coaching problem.

| Persona | How it shows up | Weight and reason | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | STAR-shaped prompts; "tell me about a time" | Top: the round is mostly behavioural | One instance, "I" for your part, "we" for the context |
| Skeptic | Quiet, specific probes on the gaps | Middle: F3, F7, F8 and F2 are where a manager will probe | Hold the verified claim; concede the gap in one sentence |
| Case / Strategist | A coaching problem from the role | Low: one question | State the structure aloud before the content |

### Values / Behavioral (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a complaint where you decided from the member's side of the counter, when the process pointed the other way." | VAL | [grounded] "I handled the branch's formal complaints log" | Open prompt. The only instance your material names is a complaint from the log. Answer slot: if a decision went against the process to serve the member, say what you decided and why, in your words. If none did, say so and describe the nearest case from the log, and how you handled the member's side. | Members First, Always. The honest answer is the one most likely to hold under follow-up. |
| B2 | "Tell me about a time you had to explain a decision a member didn't like, in words they could use." | VAL | [grounded] "I trained new tellers on our escalation script" | Open prompt. Your sentence carries a script, not a member conversation. Answer slot: if you explained an outcome to a member in plain words, say what you said. If the script was used as written, say so and say how you explained it. | Plain Words. |
| B3 | "Tell me about a complaint you kept hold of until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log" | Answer slot: if you held a case until it closed, say what closed it. If the log moved cases on without you, say so. "Handled" is your word. Do not turn it into "held until solved" unless you did. | Own the Fix. Same sentence as F1, so expect the scope probe. |
| B4 | "When have you worked with a digital team on a self-service journey?" | JD | [grounded] JD label only: "work with digital teams on self-service journeys" | Open prompt. Answer slot: if you have, say what it was and your part in it. If not, say so and say how you would start. | F5. A discovery gap the JD makes almost certain to be asked. |
| B5 | "Tell me about a time a complaint came to you from a branch you didn't run." | VAL | [grounded] "I handled the branch's formal complaints log" | Open prompt. Answer slot: if one did, say how you took it on. If none did, say so and describe how you would take one over. | Members First, from a different side. |

### Skeptic (4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B6 | "How would you define resolution time, and what would you show each month?" | JD | [grounded] JD: "report monthly on complaint volumes and resolution times" | Name the measure in your words, from the start point to the end point you would choose, and say why. Answer slot: if the sheet you built counted resolution times, say how. If it did not, say so and say what you would measure first. | F3. A mid-list JD item that is easy to skip in prep. Do not skip it. |
| B7 | "Which number in your monthly spreadsheet would you defend least?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Weakest-assumption move: name, in your own words, the assumption behind the figure you would defend least, before they do. Answer slot: if you cannot say how a figure was counted, say so. Then say which part of the sheet was yours. | F2 and F9. A metric probe on the sheet you built. |
| B8 | "Tell me about the most senior audience you've presented complaint information to." | JD | [grounded] "I've never presented to anyone above regional level." | Open prompt. Answer slot: name the most senior audience you have presented to, in your words. If it was your regional manager, say so plainly, and stay there. Do not claim anything above regional. | F8. Your own sentence sets the ceiling, so state it without apology and move on. |
| B9 | "Why leave a branch role now?" | CO | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | Answer slot: say what you are moving toward, in your own words, and draw on the years in your sentence. Do not name a cause you cannot stand behind. | A motivation probe with a skeptic's edge. Consolidation is a tempting explanation, and a risky one unless it is what actually moved you. |

### Case / Strategist (1)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B10 | "A branch supervisor is unsure whether to escalate a complaint. How would you coach them through it?" | CASE | [grounded] JD: "coach branch supervisors on escalations" | Structure aloud: what they know, what the member needs, who decides, what gets written down. Answer slot: if you have coached someone through an escalation decision, say who and what you did. If not, say so and describe your approach. | F4. The coaching requirement, asked as a decision rather than a record. |

**Reverse questions (Round 2)**
- "What would you want changed in complaints within the first ninety days?" Why it lands: it shows what she is worried about, and your first-month plan can match it.
- "How do you want the coaching of branch supervisors on escalations to run day to day?" Why it lands: it treats the job as a working relationship and tests how much coaching she expects you to do yourself.

---

## Round 3: Panel of two branch managers (60 minutes, including a 20-minute case; scored against the four values)

**Persona weights.** Values/Behavioral, top (5): the panel scores all four values. Peer Evaluator (3): branch managers read the seam between branches and the contact centre as their own. Pressure (2): branch managers test whether you hold a position under escalation pressure.

| Persona | How it shows up | Weight and reason | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | Scored against each value; one question can score two | Top: the panel is the values round | Map a story to each value, or give the honest branch |
| Peer Evaluator | Seam questions; "what would you need from me" | Middle: two branch managers, each with a branch and a turf | Reciprocity: what you bring their branches, not only what you need |
| Pressure | Interruptions; "how much was actually you" | Low-middle: escalation is a panel theme | Pause, restate, hold two follow-ups, concede one specific thing |

### Values (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Tell me about a complaint where the branch's view and the member's view differed." | VAL | [grounded] "I handled the branch's formal complaints log" | Open prompt. Answer slot: if you took the member's side against the branch, say what you did and who you told. If the log shows no such case, say so and describe the nearest disagreement you handled. | Members First, Always. |
| P2 | "Tell me about a letter or a script you changed so a member could follow it, or say you never did." | VAL | [grounded] "I trained new tellers on our escalation script" | Open prompt with the honest branch in the question itself. Answer slot: if you changed wording for members, say what changed and why. If you did not, say so and say what you would check first in a letter. | Plain Words. |
| P3 | "Tell me about a time a figure and a town pulled you in different directions." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Open prompt. The sentence carries the figures side only. Answer slot: if a figure in your sheet and a branch's situation disagreed, say which won and why. If they never did, say so, and say what the sheet does not show about a branch's town. | Neighbours, Not Numbers. The sheet is your strongest numbers evidence and your thinnest town evidence. |
| P4 | "Tell me about a complaint you handed on before it was solved, and whether you still knew where it ended." | VAL | [grounded] "I handled the branch's formal complaints log" | Open prompt. Answer slot: if you handed one on, say to whom and whether you followed it. If you never handed one on, say so and say how you would hold one to the end. | Own the Fix, from the handover side. |
| P10 | "If a branch you supported were merging into a hub, what would a member in that town need from complaints handling?" | VAL | [generic] | Hypothetical, so no claim about your past. Answer slot: say what you would check first with members and the branch team, in your own words. Name no outcome you cannot stand behind. | Neighbours, Not Numbers, asked against the consolidation in the brief. Conditional phrasing, so it presupposes nothing about Ashgrove's plans. |

### Peer Evaluator (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P5 | "Where do complaints fall between a branch and the contact centre, and whose job is that?" | JD | [grounded] JD: "across branches and the contact centre" | Principles, not a map: how you would find the seam, who you would ask first, and how you would settle a dispute over ownership. Do not claim to know this contact centre's seams. You have not worked in one. | F1's seam. Peer turf. |
| P6 | "Tell me about a time you disagreed with a branch manager about how a complaint should be handled." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | Open prompt. Answer slot: if you disagreed with a branch manager, say what it was and how it ended. If you have not, say so and say how you would raise it with an equal. | Peer disagreement. Show spine and tact together. |
| P9 | "Digital teams want complaints handled in the app. What would you need from them, and what would you give them back?" | JD | [grounded] JD label only: "work with digital teams on self-service journeys" | Reciprocity: name what you would need from them and what your branch knowledge gives them. Principles, not claims. Answer slot: if you have given a digital team complaint data before, say what. If not, say so. | F5. Turns a need into a trade. |

### Pressure (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P7 | "Sixty seconds: why this role?" | CO | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | Pause, restate in your own words, answer in under sixty seconds. Hold: the position is the one your years carry. Concede once, specifically, where you are thinnest: the contact-centre side and senior audiences (F1, F8). Then return to the years. | A short, pressured motivation probe. Hold, then concede one named limit. |
| P8 | "That log you handled: how much of it was actually you?" | EXP | [grounded] "I handled the branch's formal complaints log" | Hold "I handled the log" through two follow-ups. Say which parts were yours, in your own words. If the log was shared, say who else touched it. Concede the specific part you did not decide. Do not fold on the core claim. | F1 under pressure. The echo of S5. Attribution is what this probe tests. |

### Case: escalation (20 minutes)

**C1.** "A member has escalated a complaint twice. The branch says the decision is final. The contact centre's note on the file says it is not. The member is at the counter now and asks to see whoever is in charge." Type CASE. Provenance: [generic]. No claim about Ashgrove or about you.

Time plan:
- **3 min, clarify.** What does the file show? Who made each decision, and on what basis? What does the member need in the next ten minutes?
- **4 min, objective and owner.** Aim: resolve it in a way the member can repeat back, with one owner. Name the owner; this is where Own the Fix shows.
- **8 min, approach.** Speak to the member in plain words now: what you will do and by when. Get both positions and the rule behind each. Decide, or escalate to a named person with a date.
- **3 min, measures and risks.** Measures: the member can repeat the outcome back; the file has one named owner. Risks: promising an outcome before the rule is checked; contradicting the branch in front of the member; any timescale you have not confirmed.
- **2 min, record.** Write what was decided, by whom, and when the member hears next.

Honesty note: tie each step to what you would do, not to what a bank usually does. If you have run a case like this, use it. If you have not, say the approach is a plan.

**Reverse questions (Round 3)**
- "What could a new person do in their first month that would genuinely help your branches?" Why it lands: reciprocity for peers. It treats the panel as people who will work with you, and it gives them a concrete thing to answer.
- "Where do you think complaints get lost between the branch and the contact centre today?" Why it lands: it asks them to describe the seam from their own side, and it tests P5 against their experience.

---

## Requirement coverage

| JD requirement | Question IDs |
|---|---|
| Own the complaints process end to end across branches and the contact centre | S5, S4, P5, P8 |
| Report monthly on complaint volumes | S7, B7 |
| Resolution times | B6 |
| Coach branch supervisors on escalations | B10, C1 |
| Work with digital teams on self-service journeys | B4, P9 |
| 4+ years in financial-services customer operations | S3 |
| Experience handling regulated complaints | S6 |
| Confident presenting to senior leaders | B8 |
| Comfortable with Excel reporting | S7, B7 |

No JD requirement is uncovered. Values coverage: Members First, Always (B1, P1); Plain Words (B2, P2); Neighbours, Not Numbers (P3, P10); Own the Fix (B3, P4).

## Sources

**Provided documents:** the JD text you pasted; the values page text you copied from ashgrovecu.org/about/values this morning (11 November 2026); your recruiter's email on the process; your summary of the July 2026 strategy brief (not the document itself); your background message.

**Research tier:** L0, no searches. The values-style round is detected on a loop source, the recruiter's email.

| Target | Status | What it moved |
|---|---|---|
| 1. Ashgrove values | skipped | The pasted values page fixes the values cheat sheet. No search at L0. |
| 2. Ashgrove interview process | skipped | The recruiter's email establishes the loop: three rounds, each with who runs it and its format. No archetype fallback is needed. |
| 3. Ashgrove strategy / recent news | skipped | Your summary of the brief fixes the grounding brief. No recent-news sweep at L0. |
| 4. Interviewer name and Ashgrove | n/a | No names given. The interviewer read is absent; the upgrade menu says what names would unlock. |
| 5. Representative JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions. |

## Upgrade menu

- The names of the Round 2 manager and the two panel members, if you have them → persona weights from their public footprint, and a reverse question tied to each one's career path.
- Paste the strategy brief → your summary becomes exact quotes, and the CO questions can use the brief's own words.
- Four short stories, one per value, in your own words, outside this pack → the values rows get mapped stories instead of selection scaffolds. Tell me the stories and I will regenerate the affected rows.
- A sanitised copy of the monthly sheet, with no member data → an inspectable artifact for F2 and F9, which raises them from medium to high if it shows what you built.
- The rules and timescales the formal complaints log followed → F7 moves from discovery to grounded, and S6 and B6 can be answered from a named rule.
- Whether the role's location, hours or team changes after the branch consolidation → a question for the recruiter. It is not in the JD, so it is not a fit row.
- A deeper research pass at L2 (up to 6 more searches and 2 more fetches; several minutes): interviewer footprints, loop reports from candidates, and recent organisational context. Want it?
