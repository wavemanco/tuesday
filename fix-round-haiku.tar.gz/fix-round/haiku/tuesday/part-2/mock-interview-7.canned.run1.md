Your prep pack is saved as `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-tuesday-part-2-rooms-case-7-canned-dbb680a1/f8edcd14-97a0-4051-a2f1-79c673f36fbd/scratchpad/saltmarsh_live-operations-producer_interview_pack.md`. I built it on the assumption that Friday's session is the single 60-minute "Outage Hour" with Tobias, which the Saltmarsh careers page describes.

The page changes the prep in three ways:

- **The hour is a live-incident tabletop, then a values conversation.** The tabletop is the core of the hour, so A1 (a live bug during an event) is the scenario to rehearse first. Your material has no incident response, so that answer will depend on what you have actually done.
- **His public argument is that patch notes should describe what shipped.** He gave a GDC 2026 talk with that thesis. Your release checklist is the strongest material you have for it, so keep the wording of "Wrote the release checklist our QA team still uses" exact.
- **The company is moving to a shared calendar.** Project Larkspur (September 2026) moves Tidepool Tactics and Lantern Row to a season-pass model with one shared events calendar from February 2027. You have no in-app purchase experience, so expect a probe there. The pack does not assume those two titles are the two in your JD.

The highest-return prep is **A2**: "Your next update touches design, art, engineering and community at once. How do you plan it?" Your material shows no cross-team coordination, so this is where the interview will press hardest. Say what you have done in your own words, and if the answer is no, say that plainly and describe how you would sequence it.

Two things to check before Friday:

- Is Friday's session the Outage Hour, and does it include the values conversation? If not, the persona weights change.
- Do you have a release checklist excerpt you can share, or the retention figure you presented and how it was counted? Either one would strengthen the answers on F4 and D1.

Would you like a drill? I can play Tobias on A1, the live-incident tabletop, and give feedback against that question's guidance. I can also save a `tuesday-dossier.md` with the gaps this prep exposed, or convert the pack to Word.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh_live-operations-producer_interview_pack.md -----
# Saltmarsh Games — Live Operations Producer — Interview pack

**Role:** Live Operations Producer, Saltmarsh Games (mobile, about 350 people)
**Round:** Friday, 60 minutes, the "Outage Hour" with the hiring manager (per the careers page)
**Interviewer:** Tobias Wrenfield, Head of Live Operations
**Candidate:** Femi (pronouns not stated; they/them used)

*Built on the assumption that Friday's session is the single 60-minute Outage Hour with Tobias, as the careers page describes it. If it is something else, the persona weights and the question banks change.*

Guidance is scaffolding, not a script. Personas describe how a question arrives; types describe what is being scored: **JD** (stated responsibility), **EXP** (your past, attribution), **VAL** (published values), **CO** (company knowledge), **CASE** (live problem).

---

## Fit snapshot

Requirements come from the JD you supplied, the careers page (fetched), and the Project Larkspur announcement (search result). Evidence is quoted from your message and nothing else.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material shows one title's weekly content drops, for two years. It does not show a live-events calendar across two titles. Words: "For two years I ran the weekly content-drop calendar for our main title." Answer slot: the JD asks for two titles, so expect a probe on running more than one. If you have planned across more than one title, say how, in your own words; if you have not, say so and describe how you would sequence two calendars. |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | "Wrote the release checklist our QA team still uses." — your message | low | [inferred] | discovery | The checklist shows work with QA. Nothing in the material shows coordinating design, art, engineering or community. Answer slot: if you coordinated any of those four teams on an update, say which and how. If none, say so and describe how you would plan the first update that needs all four. |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | low | [grounded] | discovery | Presenting numbers is reporting. Owning the KPI set or a post-event review is not shown. Answer slot: if you chose which KPIs were reported, or ran a review after an event, say what and why. If the KPIs were set for you, say so plainly and say what you would review first. |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | none | Your line reaches the requirement in role terms. Lead with it in your own words: "I wrote the release checklist our QA team still uses." No artifact has been inspected, so expect a probe on what it covers. |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message; "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | presentation | The years and the weekly drops are on the page. The words "live-service" do not appear in your material. Bridge: "Four years as an associate producer at a puzzle-game studio." Add nothing to it. |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | Reaches the requirement directly. Lead with it: "For two years I ran the weekly content-drop calendar for our main title." Expect a probe on its scope, which is one title. |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | presentation | Your line shows monthly retention numbers in front of the studio head. It does not show how the numbers were built. Words: "I presented the monthly retention numbers to the studio head." No figure is given, so no defend-the-number slot yet. |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | none | Reaches the requirement in role terms: a written document a team works from. No written work has been inspected. Words: "I wrote the release checklist our QA team still uses." |
| F9 | "a live-incident tabletop on a simulated outage during a live event" — careers page | none given | none | [grounded] | discovery | The material says nothing about running or taking part in an incident during a live event. Answer slot: if you have, say what you did, in your own words. If you have not, say so plainly and say how you would open a live incident. |
| F10 | "moves Tidepool Tactics and Lantern Row to a season-pass model" — Project Larkspur announcement | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [grounded] | capability | You stated the absence. Words: "I haven't worked on a game with in-app purchases." Then how you would learn monetised event mechanics, said as a plan and never as a past. |

**Pack observation, not words for you:** your material shows one title and weekly drops, presented numbers, and a checklist. It does not show cross-team coordination, KPI ownership, or incident response.

---

## Prohibited claims

Built locally from the fit snapshot. These are the claims this pack will not coach, and why.

| Not coached | Basis | Honest form |
|---|---|---|
| Ran a live-events calendar across two titles | Inflated form of F1 | F1's quote at its own scope: one title, weekly content drops, two years. |
| Coordinated design, art, engineering and community on each update | Inflated form of F2 | F2's quote at its own scope: a checklist QA still uses. |
| Owned the KPIs and the post-event review | Inflated form of F3 | F3's quote at its own scope: presented monthly retention numbers. |
| Has monetised live-service experience | Negative you stated, F10 | Plain acknowledgment: "I haven't worked on a game with in-app purchases." No slot. |
| Has led a team | Negative you stated | Plain acknowledgment: "I haven't led a team." No slot. |

---

## Interviewer read

- **Career pattern:** QA lead at a console studio before Head of Live Operations at Saltmarsh (from the GDC 2026 talk listing).
- **Public argument:** the GDC 2026 talk "Patch Notes Are a Promise" says a live team is judged by how often its patch notes describe what actually shipped. Only the listing was read, not the talk itself.
- **Implications:** expect release facts to be probed, because his measure is concrete. Your checklist (F4) is the strongest material you have for that conversation. Keep the words exact.
- **Mirror opportunities:** his talk's argument, "what actually shipped," sits next to F4. No shared career jump is offered, because you did not move from QA into live operations.

---

## Persona table

Relationship prior for a hiring manager is Case/Strategist and Skeptic. The careers page documents a values conversation, so Values is guaranteed in this round. The QA background and his talk add a Prober tilt.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist | The live-incident tabletop, which the careers page makes the core of the hour | Top weight (4 questions). The hour is built around the tabletop. | Clarify before triage. Name the cross-team step. |
| Values/Behavioral | The values conversation after the tabletop | High (4 questions). The careers page documents it, so values are guaranteed. | Map stories to a value only where one of your quotes carries it. Otherwise give the selection scaffold. |
| Skeptic | "Why you, and what haven't you done?" | Mid (3 questions). The gaps F1, F9 and F10 are where he will press. | Rehearse the scope objection until it is plain. Name the limits. |
| Data-Driven Prober | Checklist and retention numbers | Mid (3 questions). The QA background and the "what shipped" argument make release facts a likely probe. | Say what you know and what you do not know about how things were counted. |
| Conversational | The opener and the close | Low-mid (2 questions). Casual openers are still scored. | A 90-second arc, and a real answer to the closing question. |
| Pressure | Time-boxed holds | Low (2 questions). No stress signal is public. | Hold, then concede the specific limit. |

---

## Question banks

### Case/Strategist (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A reward-claim bug is hitting players in the middle of a live event. Walk me through the first hour." | CASE | [generic] | Clarify scope: how many players, which platforms, since when. Decide rollback or hotfix on what you know. Name who to pull in, from engineering, QA and community. Say what you would tell players, and when. Keep confirmed separate from hoped. | The format is the careers page's Outage Hour; the scenario is a pattern for the problem, so its label is generic. Covers F9. |
| A2 | "Your next update touches design, art, engineering and community at once. How do you plan it?" | JD | [grounded] "coordinate design, art, engineering and community teams on each update" — JD | Name each team's dependency and the cut-off date for each. Say where the QA check sits. Answer slot: if you have coordinated any of those teams on an update, say which and how, in your own words. If not, say so and describe how you would sequence it. | The highest-ROI rehearsal in this pack. F2 has no evidence, and this question will press exactly there. |
| A3 | "How would you set up the live-events calendar for two titles in the first 90 days?" | JD | [grounded] "Plan and run the live-events calendar for two of our mobile titles" — JD | Structure it: inventory each title, its cadence and freeze windows, dependencies, and what you would measure first. Say what you would learn before you commit to a calendar. No claim about your past. | Covers F1's gap as a forward plan rather than a record. |
| A4 | "A retention dip shows up a week after an event. What do you check?" | CASE | [generic] | Define the metric and the cohort. Check the baseline and the instrumentation. Separate the event effect from normal seasonality. Name the one assumption you would test first. | The post-event review is in the JD. This is a live problem from the role, so it makes no claim about your past. |

### Values/Behavioral (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time the calendar and the players disagreed. What did you do?" | VAL | [grounded] "Players Before Plans" — values page. No candidate quote carries a story. | Selection scaffold: pick a time a planned drop conflicted with what players needed. If no such time comes to mind, say so plainly. Then give the nearest thing your material carries, which is the weekly drop cadence, or how you would decide. | Values page names "Players Before Plans." None of your quotes carries this story, so the guidance is a scaffold with the honest branch. |
| B2 | "Tell me about a time what shipped did not match what was announced. What did you change?" | VAL | [grounded] "I wrote the release checklist our QA team still uses." — your message | Map the checklist: say what it covers, in its own terms. Answer slot: if the checklist checked release notes against the build, say so. If it did not, say what it did check. Do not say the checklist caught a mismatch unless you saw it do so. | "Ship the Patch Not the Promise" is the value. F4 is the only quote that touches it, so the story is the checklist, at its own scope. |
| B3 | "Tell me about something you left better than you found it." | VAL | [grounded] "Wrote the release checklist our QA team still uses." — your message | Map the checklist: you wrote it, and QA still uses it. Answer slot: if you changed it after release, say what and why. If you did not, say so, and say what the checklist does for the next release. | "Leave the Build Greener" reads "every release leaves the codebase and the checklist better than it found them." F4 is the nearest mapping. |
| B4 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] stem; [grounded] "Presented the monthly retention numbers to the studio head." — your message | Selection scaffold: pick a time the numbers you presented were not what leadership wanted. If none comes to mind, say so plainly, then give the nearest thing your material carries: presenting the monthly numbers. | Stem from the Values persona. F7 is the nearest sentence, and the scaffold stays inside its scope. |

### Skeptic (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "What is the weakest part of this JD for you on day one?" | JD | [grounded] "Plan and run the live-events calendar for two of our mobile titles" — JD; [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." — your message | Name the true scope: one title, weekly drops, two years. Then name the next step: how you would bring a second title's calendar in. Name the cross-team gap in your own words. | F1 is the objection most likely to be asked. Rehearse it until it is plain. |
| C2 | "You have never worked on a game with in-app purchases. What would you need to learn first?" | EXP | [grounded] "Never led a team, and never worked on a game with in-app purchases." — your message | Plain acknowledgment: "I haven't worked on a game with in-app purchases." Then say what you would learn first, as a plan and never as a past. | F10. The question's premise is your own stated negative, so it may be presupposed. |
| C3 | "You presented the retention numbers. Did you choose which KPIs were reported?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." — your message | Answer slot: if you chose which KPIs were reported, say which and why. If they were set for you, say so plainly and say what you would review first. Never describe a KPI you did not choose. | F3. The question asks about a practice the quote does not carry, so it is answered by either branch. |

### Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "How was the retention number you presented counted? Which assumption behind it would you defend least?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." — your message | Answer slot: if you know how it was counted, say how, in your own words. Name the assumption you would defend least only if you know it. If you did not own the counting, say so plainly. | F7. No figure is given, so this is the honest branch. |
| D2 | "What does the release checklist check, and what does it not check?" | JD | [grounded] "Wrote the release checklist our QA team still uses." — your message | Describe what it covers in its own terms. Answer slot: name a gap you know of, if you know one. If you have not looked at it since, say so. | F4 and F8. Also tests the written-communication requirement. |
| D3 | "What would you measure after an event to know it worked?" | JD | [grounded] "own the post-event review and the KPIs it reports" — JD | Define success before the event. Name one leading and one lagging metric, and the baseline each is judged against. Say how you would call the result. | F3. Forward plan, so no claim about your past. |

### Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." — your message; "I ran the weekly content-drop calendar for our main title for the last two years." — your message; "Wrote the release checklist our QA team still uses." — your message; "Presented the monthly retention numbers to the studio head." — your message | A 90-second arc in the order of your quotes: four years, two years of weekly drops, the checklist, the retention numbers. Say each in your own words, and stop where the quotes stop. | F5 and F6. Covers the three-plus-years requirement, which the quotes reach in role terms. |
| E2 | "What live game are you playing these days, and what does its event calendar do well?" | CO | [generic] | Name a live game you actually play and one thing its calendar does well. If you do not play one, say so. | Casual register, still scored. Keep it to a game you can speak about. |

### Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F-P1 | "Sixty seconds: why should we hire you over someone who has led a team and shipped a monetised title?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." — your message; [grounded] "For two years I ran the weekly content-drop calendar for our main title." | Hold the position with your quotes: two years of weekly drops, one title. Concede the limits plainly: "I haven't led a team, and I haven't worked on a game with in-app purchases." Do not fold on the calendar. | Hold, then concede the specific limit. The question's premise is a comparison, so the guidance adopts no premise. |
| F-P2 | "That checklist. How much of it was actually you?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." — your message | Hold: you wrote it. Concede exactly what others changed, if anything. If you did all of it, say that once and stop. | F4 at its own scope. Do not stretch "wrote" into "owned the process." |

---

## Requirement coverage

| JD requirement | Question IDs |
|---|---|
| Plan and run the live-events calendar for two titles | A3, C1 |
| Coordinate design, art, engineering and community on each update | A2 |
| Own the post-event review and the KPIs it reports | A4, C3, D3 |
| Manage the release checklist with QA | B2, D2 |
| 3+ years producing live-service games or apps | E1 — covered by the arc. No dedicated question. |
| Experience running a content calendar | E1, A3 |
| Comfortable with player-retention metrics | D1 |
| Clear written communication | D2 |
| Live-incident tabletop (careers page) | A1 |
| Values conversation (careers page) | B1, B2, B3, B4 |

---

## Values cheat sheet

The careers page documents a values conversation, so this section applies.

| Value (official name) | Working meaning | Mapped story |
|---|---|---|
| Players Before Plans | When the calendar and the players disagree, the players win. | No quote carries a story. Selection scaffold, B1, with its honest branch. |
| Ship the Patch Not the Promise | Announce what is built, not what is hoped. | F4: "Wrote the release checklist our QA team still uses." B2 maps it, at its own scope. |
| Leave the Build Greener | Every release leaves the codebase and the checklist better than it found them. | F4 again: B3. Answer slot on what changed after release. |

---

## Reverse questions

Each one lands for a reason.

1. "What would a strong first 90 days look like across both titles?" Lands because it shows you are thinking about scope, not only the job description.
2. "How will the shared calendar change which titles and teams this role owns?" Lands because it refers to the Project Larkspur announcement, which shows you read the strategy.
3. "In your GDC talk you argue a live team is judged by how often its patch notes describe what shipped. What do you measure to get that?" Lands because it uses his own public argument and asks him to teach you his measure.
4. "You came from QA into live operations. What did that move take to learn?" Lands as an interviewer-path question. It turns a motivation probe into a peer conversation.
5. "Where does the post-event review sit, who reads it, and what decision does it change?" Lands because it asks how KPI ownership works in practice.
6. "When a patch goes out, who signs off that the notes match the build, and what happens when they do not?" Lands because it asks about the release-checklist process he cares about.

---

## Sources

Provided documents: the JD, your background message.

Searches and fetches, every call sent:

| Query or URL | Returned |
|---|---|
| "Saltmarsh Games values" | saltmarshgames.com/values |
| "Saltmarsh Games interview process Live Operations Producer" | saltmarshgames.com/careers/interviewing |
| "Tobias Wrenfield Saltmarsh Games Head of Live Operations" | talks.gdconf.example/2026/patch-notes-are-a-promise (listing snippet only; not fetched) |
| "Saltmarsh Games news 2026 live events strategy" | saltmarshgames.com/news/project-larkspur (snippet only; not fetched) |
| Fetch: saltmarshgames.com/values | Values page text |
| Fetch: saltmarshgames.com/careers/interviewing | Interviewing page text |

Research tier: L1 — searches 4 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | yes | Values cheat sheet. Section 10 applies. |
| 2. Saltmarsh Games interview process | yes | The loop: one 60-minute Outage Hour with the hiring manager, a tabletop then a values conversation. Persona weights and the round format follow it. |
| 3. Saltmarsh Games strategy or recent news | yes | Project Larkspur, September 2026: Tidepool Tactics and Lantern Row to a season-pass model, one shared calendar from February 2027, per-title event teams retired. Feeds the reverse questions and the Larkspur row in the fit snapshot. The snippet does not say whether these two titles are the two in the JD, so the pack does not assume it. |
| 4. Tobias Wrenfield, Saltmarsh Games | yes | Career pattern (QA lead, then Head of Live Operations) and the talk's argument, from the listing snippet only. |
| 5. Representative JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions. |

---

## Upgrade menu

- Your release checklist, or an excerpt you can share → F4 and B2 gain an inspectable artifact, so confidence can move from medium to high.
- The retention figure you presented, and what it measured → unlocks the defend-the-number slots on D1.
- An incident or outage you were part of, at a live event → turns F9's answer slot into a story to map.
- A cross-team update you coordinated, and which teams → turns F2 from discovery into a grounded row.
- Confirmation that Tidepool Tactics and Lantern Row are the two titles in the role → sharpens A3 and C1.
- A deeper research pass (L2): up to 6 more searches and 2 more fetches, several more minutes. It would add the strategy brief, Tobias's other talks and writing, and recent org context, and would deepen the CO questions.
