Your prep pack is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-tuesday-part-2-rooms-case-7-denied-bd789a13/121f6fb7-5e19-49e5-bba1-4c085b28ec9b/scratchpad/Saltmarsh_Games_live-operations-producer_interview_pack.md`. I built it for a hiring-manager round, since your note didn't say how Tobias relates to the role.

No research ran. The host refused every web search, so the pack has nothing about Saltmarsh's values, interview format, strategy, or Tobias's background. Company-specific claims are absent rather than guessed. If you grant search permission, I can run the checks and add them.

The sharpest prep point is the leadership objection. You've never led a team, and the JD asks you to coordinate four functions on each update. Bank S1 rehearses holding that position, then giving a concrete plan for coordinating without authority. Your second biggest exposure is the in-app purchase gap (S3).

The pack also flags where your material is thin. The post-event review and KPI ownership, and the live-service question, are both answer slots. Your honest answer there is "I haven't" plus how you'd build it, not a claim.

I can also play the Skeptic on S1 as a drill, or save a `tuesday-dossier.md` recording the gaps this prep exposed. If you'd like the pack as a Word document, say so and I'll convert it.

Is Tobias your future manager, or a more senior person above your manager? The answer changes how the personas are weighted.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Saltmarsh_Games_live-operations-producer_interview_pack.md -----
# Interview pack: Live Operations Producer, Saltmarsh Games

**Interviewer:** Tobias Wrenfield, Head of Live Operations. Relationship not yet confirmed; this pack assumes a hiring-manager round, 60 minutes, on Friday.
**Research:** none ran. The host refused every web search, so nothing about Saltmarsh or Tobias is in this pack. Company facts are absent, not guessed.

## How to use this pack

Personas describe how a question arrives. Types describe what is being scored.

Type key:
- **VAL**: behavioral, values alignment (none detected here)
- **EXP**: your own past work, probed
- **JD**: the job's stated responsibilities
- **CO**: company and strategy knowledge (none researched)
- **CASE**: live problem from the role

Guidance is scaffolding, not a script. Say it in your own words, and only what you did.

## Fit snapshot

Requirements are quoted from the JD you pasted. Evidence is quoted from your message. Nothing else is evidence.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | transferability | Your material says one title and a weekly content-drop calendar. It does not say live events, or a second title. Say the calendar you ran, at its own scope. Answer slot: if you set any part of a calendar for a second title or for events beyond content drops, say what it was; if not, say so and say what you would do in the first month. |
| F2 | "experience running a content calendar" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | none | The quote reaches the requirement in role terms. Lead with it in its own words. A probe on cadence is likely; add no figures. |
| F3 | "manage the release checklist with QA" (JD) | "Wrote the release checklist our QA team still uses." (your message) | medium | [grounded] | presentation | The quote reaches the requirement in other terms: you wrote it, and QA still uses it. Say that. Do not turn "wrote" into running every release. |
| F4 | "coordinate design, art, engineering and community teams on each update" (JD) | none given | none | [grounded] | discovery | Your material does not show coordination with design, art, engineering or community on any update. Answer slot: if you coordinated any of those teams on a content drop, name the team and what you did; if you did not, say so plainly and say how you would set up coordination for the first update. |
| F5 | "own the post-event review and the KPIs it reports" (JD) | none given | none | [grounded] | discovery | Your material shows you presented retention numbers (F6). It does not show you owned a post-event review. Answer slot: if you wrote or ran a post-event review, say what it covered; if none was yours, say so and say how you would build one. |
| F6 | "comfortable with player-retention metrics" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | low | [inferred] | discovery | Presenting numbers is not the same as defining or analysing them, so do not stretch it. Answer slot: say what the monthly numbers measured and what you did with them; if you only presented them, say so and name the metric you would check first. |
| F7 | "3+ years producing live-service games or apps" (JD) | "4 years as an associate producer at a puzzle-game studio" (your message) | low | [inferred] | discovery | Four years clears three, but your material does not say the title was live-service. Answer slot: if it had live updates after launch, describe them in your own words; if not, say so and point to the nearest live cadence you ran. |
| F8 | "clear written communication" (JD) | "Wrote the release checklist our QA team still uses." (your message) | medium | [grounded] | none | A written artifact others still use reaches the requirement. Keep the claim to that artifact. |
| F9 | Working on monetised titles, as role-family prose; the JD names mobile titles but not in-app purchases [generic] | "Never led a team, and never worked on a game with in-app purchases." (your message) | none | [grounded] | capability | Your own statement: "I haven't worked on a game with in-app purchases." Then how you would learn the purchase side, said as a plan. Nothing added to make it smaller. |
| F10 | Leading the teams the coordination line implies, as role-family prose [generic] | "Never led a team, and never worked on a game with in-app purchases." (your message) | none | [grounded] | capability | Your own statement: "I haven't led a team." Then how you would coordinate without line authority, said as a plan. |

Gate check: the JD text you supplied contains no location, work-authorisation, pay or schedule terms, so no row is a gate.

### Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the live-events calendar | Inflated form of F1 | "I ran the weekly content-drop calendar for our main title for the last two years." Your material says one title's weekly calendar, not a live-events calendar. |
| Owned the post-event review and KPIs | Inflated form of F5 and F6 | "Presented the monthly retention numbers to the studio head." |
| Led a team | Negative you stated, F10 | "I haven't led a team." |
| Shipped a game with in-app purchases | Negative you stated, F9 | "I haven't worked on a game with in-app purchases." |
| Live-service experience | Inflated form of F7 | "4 years as an associate producer at a puzzle-game studio," at its own scope. |
| Wrote and owns the release checklist | Inflated form of F3 | "Wrote the release checklist our QA team still uses." |

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Weight | Counter-strategy |
|---|---|---|---|---|
| Case / Strategist | Live problems from the role: a drop with conflicting team views, a retention drop, a calendar plan | High. A hiring manager buys capability and tests it on their own roadmap. Relationship prior, not a documented loop. | 5 | Clarify, then structure, then one challenged premise. Think aloud. |
| Skeptic | Quiet probing of the leadership and monetisation gaps (F9, F10, F4) | High. Your two stated negatives are the obvious probes. | 4 | Rehearse the leadership objection until it is plain. Hold, then give the plan. |
| Data-Driven Prober | Asks how the retention number was counted and which assumption is weakest | Medium. You presented a headline number (F6). | 3 | Say how you know, and say plainly when you do not. |
| Pressure / Stress | Challenges your fit against the stated gaps; time-boxes | Medium. Common for a senior role in a hiring-manager round. | 3 | Pause, restate, hold through two follow-ups, then concede the specific thing. |
| Conversational / Rapport | Friendly opener and a casual question about mobile games | Medium. Casual questions are still scored. | 2 | A 90-second biography arc. Treat casual questions as scored. |
| Values / Behavioral | STAR-style prompts about holding a date and bad news | Low. No values-style round detected. | 2 | Choose a real instance; if none, say so and give the nearest one. |
| Peer Evaluator | Seam questions between QA and community | Low. Relationship is hiring manager, not peer. | 2 | Reciprocity framing. Propose seam principles, not a claimed seam. |

## Question banks

### Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A content drop for one of the two titles is due in three weeks, and design, art, engineering and community each see its scope differently. What do you do first?" | CASE | [generic] | Clarify what is fixed: date, QA window, what must ship. Name each team's concern and who decides. Cut scope to what can ship and write the tradeoff down. Name the checklist and the post-event review up front. | JD coordination line, as a live problem. Makes no claim about your past. |
| C2 | "Sketch how you would plan the live-events calendar for two titles over the next quarter. What do you need to know first?" | CASE | [generic] | Clarify: current KPIs, event types, team capacity, QA windows. Then objective, cadence, audience segments, approach, metrics, risks. Do not invent title numbers. | JD line "Plan and run the live-events calendar"; the strongest role-specific case. |
| C3 | "Day-7 retention on one title fell after last week's event. Diagnose it." | CASE | [generic] | Ask whether the drop is one cohort or the whole base. Check whether the event shipped on schedule and what QA passed. Split by platform or version. Name your weakest assumption before they do. | Retention is a stated requirement (F6); a diagnosis is the probe. |
| C4 | "You now run two live titles. How do you decide which content goes first?" | CASE | [generic] | Criteria: retention impact, cost, risk, team load. Name who owns the decision. | Tests prioritisation, which the calendar requirement implies. |
| C5 | "A live event is ready but QA has an open bug. Who decides, and on what basis?" | CASE | [generic] | Stop-or-ship criteria, who holds the call, what the release checklist says, what gets reviewed afterwards. | JD release-checklist line, as a decision. |

### Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| S1 | "You've never led a team. How will you coordinate design, art, engineering and community on each update without authority over any of them?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." (your message) | Hold: "I haven't led a team." Then the mechanism, said as a plan, not a past: one owner per update, scope agreed in writing with each function, a standing review. Hold through two follow-ups by returning to the plan. Concede specifically: the authority questions are ones you would learn in the first weeks. Answer slot: if you have coordinated any of those four functions, name the function and what you did; if not, say so plainly and stay with the plan. | Highest-ROI prep in this pack. F10 and F4 are the largest gaps and the most likely probe. The question's premise is your own stated negative. |
| S2 | "Walk me through a post-event review you have owned." | JD | [grounded] "Presented the monthly retention numbers to the studio head." (your message) | Answer slot: if you wrote or ran a post-event review, say what it covered, in your own words; if none was yours, say so plainly and describe how you would build one. The presented numbers may be the nearest thing you did; say so only if it was. | F5. The JD raises the review; your material does not show one. |
| S3 | "You've never worked on a game with in-app purchases. Why would monetisation not be a problem here?" | JD | [grounded] "never worked on a game with in-app purchases" (your message) | Hold the plain fact. Do not argue that monetisation is irrelevant. Say what you would learn first: how purchases shape the event calendar. Concede: you would want to see that before setting any target. | F9. A Skeptic's favourite probe. |
| S4 | "Why leave a puzzle studio for a 350-person mobile studio now?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio" (your message) | Give your own reason in one or two sentences. Answer slot: if part of it is the calendar work you did, say so and say what it was; if not, leave the calendar out. | Motivation probe; the honest answer is your own. |

### Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Walk me through how you ran the weekly content-drop calendar for the last two years." | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | Story-mapped on F1: the calendar, the weekly cadence, the two years. Tell them in your own words. Answer slot: which parts were yours to set (dates, scope, content mix) and how you decided; if any were set for you, say so. | F1 and F2. The likeliest place to be probed on calendars. |
| P2 | "What retention figure did you present to the studio head, and how was it counted?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." (your message) | Defend-the-number slot: say how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. If you do not know how it was counted, say so. | F6. Headline numbers are probed to their assumptions. |
| P3 | "Which KPIs would you put in a post-event review for one of these titles, and which would you trust least?" | JD | [grounded] "Presented the monthly retention numbers to the studio head." (your message) | Name the KPIs the JD asks for and the one you trust least, with the reason. Do not claim the team's KPI set. | F5 and F6. The JD's KPI line is the raising source. |

### Pressure / Stress

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| Pr1 | "Sixty seconds: why should we hire someone who has never led a team for a role that coordinates four functions?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." (your message) | Pause. Restate the question. Hold: you have not led a team, and what you have done is the calendar and the checklist. Hold through two follow-ups. Then concede the specific thing: the coordination without authority is what you would learn first. Never fold on the core claim. | F10. Tests composure, not content. |
| Pr2 | "That checklist QA still uses: how much of its use was really you?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." (your message) | Hold: you wrote it, and QA chose to keep it. Answer slot: if others changed it, say what they changed; if not, say so. | F3. Attribution probe. |
| Pr3 | "If someone challenged the monthly retention numbers you presented, what would you defend and what would you concede?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." (your message) | Hold the source of the number. Concede the assumption you would defend least. Add no figure. | F6. Hold-then-concede on a number. |

### Conversational / Rapport

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R1 | "So, walk me through the journey from the puzzle studio to here." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio" (your message) | A 90-second arc: four years, the weekly calendar, the checklist, the retention numbers, why this role. Each beat is a quoted sentence. Close on the calendar. | Casual biography question, scored. |
| R2 | "What mobile game do you play most, and what would you change about how its events run?" | JD | [generic] | Name a title you actually play, one event mechanic you would keep, and one thing you would measure. Invent nothing. | Casual question on a JD topic (live events). |

### Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V1 | "Tell me about a time you held a release date against pressure from another team." | VAL | [grounded] "Wrote the release checklist our QA team still uses." (your message) | Selection scaffold: pick a time you held a checklist gate; name the stake, what you held, and what changed after. If no such time comes to mind, say so plainly, then give the nearest thing your material carries. | Persona stem on the JD's QA line. |
| V2 | "Tell me about a time you had to tell a studio head something they did not want to hear." | VAL | [grounded] "Presented the monthly retention numbers to the studio head." (your message) | Selection scaffold: if the retention numbers carried bad news, say what they showed and what you said; if not, say so and give the nearest instance. | Persona stem; your presenting history is the nearest raising context. |

### Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| Pe1 | "Our community team and your QA team both want the same release window. Where's the seam, and what happens when you disagree?" | JD | [generic] | Propose seam principles, not a seam you have not seen. Say how you would decide and who would. Reciprocity: what you would take off their load. | Persona stem; the JD's coordination line. |
| Pe2 | "How do you handle credit when a release goes well and the community team did most of the work?" | VAL | [generic] | Name the team's share with specifics only if you saw them. Do not claim their work. | Credit-sharing probe. |

## Coverage

| JD requirement | Questions | Notes |
|---|---|---|
| Plan and run the live-events calendar for two titles | C2, P1 | |
| Coordinate design, art, engineering and community | C1, S1, Pe1, Pe2 | |
| Own the post-event review and KPIs | S2, P3 | |
| Manage the release checklist with QA | C5, Pr2, V1 | |
| 3+ years live-service | none, and why | Years clear; live-service is not established. Upgrade-menu item. |
| Experience running a content calendar | P1 | |
| Comfortable with player-retention metrics | P2, P3, Pr3 | |
| Clear written communication | Pr2 | Covered through the checklist artefact. |

## Reverse questions

Each one, with why it lands:
1. "What does the first three months look like for whoever owns the live-events calendar here?" Lands because it is the JD's own work, and it shows you are already planning it.
2. "When a live event misses its target, how does the post-event review decide what to change?" Lands because it tests the KPI ownership they care about.
3. "Which of the two titles needs the most calendar help right now, and why?" Lands because it shows you read the two-title setup in the JD.
4. "How do design, art, engineering and community agree on scope for an update today?" Lands because it goes straight at the coordination gap and invites them to describe it.
5. "What would make this role a success at six months?" Standard, but scored, and it hands you their own yardstick.

## Sources

Provided documents: the JD text and your background, both in your message.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | unavailable | Refused: query "Saltmarsh Games values". No values cheat sheet; no values-style round detected. |
| 2. Saltmarsh Games interview process, live operations producer | unavailable | Refused: query "Saltmarsh Games interview process Live Operations Producer". No loop source, so persona weights rest on the hiring-manager prior, not a documented loop. |
| 3. Saltmarsh Games strategy and recent news | unavailable | Refused: query "Saltmarsh Games mobile game studio news strategy". No grounding brief; the CO bank is absent. |
| 4. Tobias Wrenfield, Saltmarsh Games | unavailable | Refused: query "Tobias Wrenfield Saltmarsh Games Head of Live Operations". No interviewer read; reverse questions are role-generic. |
| 5. Representative live operations producer JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions. |

## Upgrade menu

- The recruiter's note on round format (panel, case, presentation, or a one-on-one) → coverage of any pre-declared deliverable and a case format that matches the round.
- Confirmation of the round's relationship (manager, skip-level, or peer) → reweighted personas across every bank.
- The official Saltmarsh values page, pasted → a values cheat sheet, with each value mapped to a quoted sentence where one carries a story.
- Tobias Wrenfield's public profile or talks, pasted → a read on his career pattern, tailored reverse questions, and persona weights from his own writing.
- The release checklist document and the retention slides you presented, as files → lifts F3 and F6 from medium and low toward high, because they are inspectable artefacts.
- Whether the puzzle title had live updates after launch, in one line → resolves F7 from discovery to a grounded claim, or to a stated limit.
- Research, once permission is granted → a Saltmarsh values check, a loop-format check, and a strategy check, each as a row above, within the L1 caps.
