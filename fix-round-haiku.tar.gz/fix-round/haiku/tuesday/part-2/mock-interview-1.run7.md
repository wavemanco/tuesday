I've read the playbook and its reference files. Next I'll write the pack to the scratchpad and send it.
Your prep pack is saved as `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-tuesday-part-2-rooms-case-1-denied-34cafbe1/29481c47-09e7-4f98-a495-e0526d48f5be/scratchpad/northwind_gtm-strategy-lead-emerging-products_interview_pack.md`. I built it for a peer round, since you described Dan as a peer. It has 21 questions across six personas, and every question carries its type, provenance, answer guidance and rationale.

**The main findings:**
- **Highest-ROI prep (D1):** "Partner-motion design experience is required." Priya's only partner evidence is a partner-level revenue model used in carrier negotiations. That is economics, not motion design. The pack gives her a hold-then-concede structure built on that exact sentence.
- **Likely probe on quota-setting (D2, E1):** Dan's title makes it probable, though no JD line raises it. The pack has her acknowledge the gap plainly and point to her volume-target work at its own scope.
- **The $400M (B1, B2):** "credited with" is a headline figure that a data-driven interviewer will take apart. The pack makes her name how it was counted and which part was hers, and it stops her from saying "I drove it."
- **Dan's pricing background** shapes the case questions (C1, C2): pricing-angle problems on enterprise renewals and bundling.

**Choices I made:**
- **No new research.** You said you had everything, so I used your research note and skipped searches. The pack's Sources section marks the values, interview-process, news and Dan-footprint checks as unavailable. Light research would fill those in.
- **No values cheat sheet or deliverable section.** Neither a values round nor a take-home was described.
- **Your JD highlights stand in for the full JD.** Quotes are exact to your text, but the full JD may add a location, work-authorization or travel gate.
- **Priya's quota negative comes from your note.** Confirm it in her own words before she rehearses "I haven't set quotas."

**One question for you:** does the full JD list a location, work-authorization or travel requirement? If it does, paste it and I'll add the gate row.

I can also play Dan as the Skeptic on D1 for a drill, or save a `tuesday-dossier.md` recording the gaps this prep exposed. A Word version is available if you want one.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: northwind_gtm-strategy-lead-emerging-products_interview_pack.md -----
# Interview prep pack: Priya, Senior GTM Strategy Lead, Emerging Products, Northwind Data

**Interviewer:** Dan Kovac, Director of Sales Strategy. Peer, same VP.
**Round:** single 60-minute conversation.
**Built from:** your message only (role, JD highlights, Priya's background, Dan's profile, your research note). No new research was run, at your direction.

## How to use this pack

- **Personas** describe how a question arrives: its tone and what the interviewer is listening for.
- **Types** describe what is being scored:
  - **EXP**: work-experience deep-dive. Tests what Priya actually did.
  - **JD**: role and JD driven. Tests whether she can do the listed job, gaps included.
  - **CO**: company and strategy knowledge. Tests whether she thinks at Northwind's altitude.
  - **CASE**: live problem. Tests structure and reasoning.
- The guidance is scaffolding, not a script. Rehearse the structure, and say only what Priya did, in her own words.
- Provenance labels: `[grounded]` traces to your input. `[inferred]` is a derivation from it. `[generic]` is a role-family pattern with no claim about Priya or Northwind.

## Fit snapshot

Requirements come from your JD highlights, not the full JD text. Quotes are exact.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" (your JD highlights) | "proposed a store-surface change credited with a ~$400M ARR uplift" (your message) | medium | [grounded] | transferability | Your material says she proposed a store-surface change and that the uplift was credited to it. It does not say she owned go-to-market for a product line. For the proposal, she says what she proposed, in those words. Any wider ownership is an answer slot: if she set the GTM for a product line, say what she decided; if not, say so and stay with the proposal. Probes on the $400M: B1, B2. |
| F2 | "partner-motion design experience required" (your JD highlights) | "built a partner-level revenue model used in carrier negotiations" (your message) | medium | [grounded] | transferability | Your material shows partner-level economics, used in negotiations. It does not show designing a partner motion. Words: "For the partner work, I built a partner-level revenue model used in carrier negotiations." Any part of a partner motion beyond the economics is an answer slot: if she did that work, say which part and how she decided it; if not, say so and how she would learn it. This is the largest gap. See D1. |
| F3 | "identify whitespace across land/adopt/expand/renew" (your JD highlights) | none given | none | [grounded] | discovery | Your material is silent on lifecycle whitespace. Words are an answer slot: if she has mapped where accounts stall between land, adopt, expand and renew, say how; if not, say what she would map first. No whitespace analysis is claimed. See C4. |
| F4 | "run independent analysis in SQL and Tableau" (your JD highlights) | "skilled in SQL/Tableau" (your message) | medium | [grounded] | none | The quote reaches the requirement in role terms. Expect a probe on the skill claim. If she has an analysis in these tools to describe, she describes it in her own words. See B5. |
| F5 | "strong cross-functional influence" (your JD highlights) | "set annual volume targets with cross-org consensus" (your message) | medium | [grounded] | presentation | The quote already reaches influence in other terms. Bridge rewords only that quote: "I set annual volume targets with cross-org consensus." Who was persuaded, and how, is added only if she says it herself. See A2. |
| F6 | "AI experience a plus" (your JD highlights) | "uses AI tools daily" (your message) | low | [inferred] | transferability | Clarify-strategy note only: use is not building. Derivation: "uses AI tools daily" read as adjacent to the requirement, not as AI experience. Coach her to say which tools and for what, in her own words. Do not present this as AI experience. See G2, C3. |
| F7 | Target and quota setting: [generic] role-family expectation, not a JD line | "No classic sales-ops or quota-setting experience." (your message) | none | [grounded] | capability | Stated absence in your material. Plain acknowledgment: "I haven't set quotas or worked in sales ops." Then the adjacent work at its own scope (F5's quote), and how she would learn quota design, said as a plan. Never a claim to quota work. See D2. |

No gate row appears, because the JD highlights state no location, work-authorization or travel requirement. The full JD could add one. See the upgrade menu.

## Prohibited claims

Built locally from the fit snapshot. None of the guidance below may assert, soften or imply these.

| Not coached | Basis | Honest form |
|---|---|---|
| "I owned go-to-market for a product line" | Inflated form of F1 | F1's quote at its own scope. Pack observation, not words for her: the material says "proposed," not "owned." |
| "I drove the $400M" or "the uplift was mine" | Inflated form of F1 ("credited with") | F1's quote at its own scope, plus the attribution slot in B2. |
| "I designed a partner motion" | Inflated form of F2 | F2's quote at its own scope, plus the slot in D1. |
| "I set quotas" or "I ran sales ops" | Negative she stated (F7), plus inflated form of F5 ("targets" becomes "quotas") | Plain acknowledgment F7. "Volume targets" stays at its scope. |
| "I built AI features" or "I have AI product experience" | Inflated form of F6 | "Uses AI tools daily," as a clarify-strategy note only. |

## Persona weights

| Persona | Weight (questions) | How it shows up | Why this weight | Counter-strategy |
|---|---|---|---|---|
| Peer Evaluator | 5 | Seams with Dan's team, disagreement, credit | Relationship prior for a peer round. Same VP, so seam questions are likely | Reciprocity framing. Seam principles, not a claimed seam. A real disagreement story, or an honest "none" |
| Data-Driven Prober | 5 | Counting, attribution, assumptions behind figures | Raised from mid-weight by Dan's self-description, "relentlessly data-driven" | Name the weakest assumption first. Say plainly what she does not know about how a figure was counted |
| Case / Strategist | 4 | Live pricing, bundling and lifecycle problems | GTM role with whitespace and two new lines. Dan's pricing and monetization career points to pricing-angle cases | Clarify, then structure, then metrics, then risks. Think aloud |
| Skeptic | 3 | Partner-motion gap, quota gap, motivation for the move | F2 and F7 are the gaps the JD and her background leave open | Rehearse the single most predictable objection until it is calm. Concede the gap plainly |
| Pressure | 2 | Holding the $400M and the model under challenge | Peer round, so low weight. Still touched, so she never meets it first live | Hold through two follow-ups, then concede the specific uncertainty |
| Rapport / Conversational | 2 | Opening biography, casual AI question | Casual openers are still scored | A 90-second arc. Treat casual questions on AI as scored |

Values / Behavioral: not included. No values-style round was described, and no company values were supplied.

Session total: 21 questions.

## Reading the interviewer

Public-footprint signals from your message only.

- **Career pattern:** pricing and monetization roles, plus one early-stage-startup chapter.
- **Self-described style:** "relentlessly data-driven."
- **Practical implications:**
  1. Every metric she gives will be taken apart for its assumptions. See B1 to B4.
  2. Her native language is pricing. Case questions lean toward pricing, packaging and unit economics. See C1, C2.
  3. The startup chapter makes scrappiness and speed probes likely. Answer with what she did, not with a claim about startup pace she has not worked at.
- **Mirror opportunity:** a shared professional domain, not a shared identity. Her monetization background is the same domain as Dan's pricing career. Pair it with F2's quote: "built a partner-level revenue model used in carrier negotiations."

## Grounding brief

Source: your research note, not fetched or verified here.

- Northwind's three stated priorities: enterprise expansion; an AI copilot launch ("Compass"); reaching profitability.
- Main competitive threat: bundling by a much larger platform vendor.
- Lifecycle vocabulary from the JD: land, adopt, expand, renew.

Before the round, confirm these are still current, especially Compass timing. Do not correct Dan on them in the room.

## Question banks

Answer slots (an instruction, not a question) are marked as such. Question IDs are letter-by-persona.

### A. Peer Evaluator (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Where would you draw the seam between Emerging Products GTM and a sales-strategy team, and what happens when we disagree?" | JD | [generic] persona stem | Propose seam principles, not a seam you do not know. Name how decisions get made when two teams disagree. Disagreement story: if she resolved a real peer disagreement, she says it in her words. If she has none, she names the nearest and how she would handle one. | Peer relationship prior with the same VP. Tests the cross-functional influence requirement (F5). JD because it scores "strong cross-functional influence." |
| A2 | "Tell me about the consensus behind those annual volume targets. Who had to agree?" | EXP | [grounded] "set annual volume targets with cross-org consensus" | Story-mapped: the targets, and the consensus across orgs, are the beats the quote states. Answer slot: if a party disagreed and she worked through it, say what she did; if none disagreed, say so and say how the consensus was reached. | F5 is her strongest influence evidence, and a peer will test the word "consensus." EXP because it asks what she did. |
| A3 | "Our partner team would hand you the partner economics on day one. What would you need from them to design a partner motion you'd stand behind?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | Reciprocity framing: say what the model does, at its own scope, then what she would ask the partner team for. Answer slot: if she has worked on partner work beyond the economics, say which part, in her words; if not, say so. | F2 is the reciprocity bridge. Tests the required partner-motion requirement from the peer side. D1 is the skeptic version. |
| A4 | "Compass, enterprise expansion and profitability are all live. Which would you want to own first, and where does pricing sit in that?" | CO | [grounded] "an AI copilot launch ('Compass')"; "enterprise expansion"; "reaching profitability" (your research note) | Name one priority and one reason. On pricing, say where a pricing decision changes the outcome, as a plan, not a claim. On AI, say "I use AI tools daily" at its own scope (F6); do not present AI product experience. | Tests altitude against Northwind's priorities. Pricing is Dan's native ground, so it is the natural peer seam. |
| A5 | "When a launch spans three teams, how do you decide who gets the credit?" | JD | [generic] persona stem | "We" for the team, "I" for her contribution. For the proposal, use F1's quote: she proposed the change, and the uplift was credited to it. If credit was shared, she says how, without reaching for the bigger share. | Peer credit-sharing probe. Tests whether she gives an honest share, which F1 needs. |

### B. Data-Driven Prober (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Walk me through how the ~$400M ARR uplift was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Defend-the-number. The beats: the proposal, then the uplift credited to it, each at the quote's scope. Answer slots, in her words: how it was counted; what it is sensitive to; the assumption she would defend least; which part was hers. If she did not see the counting, say so plainly. | F1 is her biggest headline figure, and Dan's profile says he probes figures. |
| B2 | "Which assumption behind that number would you defend least?" | EXP | [grounded] same as B1 | Weakest-assumption move: she names the assumption before he does, in her own words. Answer slot: if she cannot name one, she says she does not know how the figure was counted. Attribution: if the credit was shared, say what share and on what basis. | Second angle on the same figure, pressing on attribution. Dan will ask this directly. |
| B3 | "Take me through the partner-level revenue model. What were its inputs, and what did it leave out?" | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" | Story-mapped: the model, and its use in carrier negotiations. Answer slot: name the inputs she can recall; if she cannot list them, say the inputs are what she would check first. Name one limit she knows of, or say she knows none. | F2 is the nearest thing to the required partner work. A pricing-native interviewer will go to the model's inputs. |
| B4 | "How did you know the volume targets were right once the year closed?" | EXP | [grounded] "set annual volume targets with cross-org consensus" | The quote carries setting the targets, not checking them. Answer slot: if she compared targets with actuals, say what the gap was; if she did not check them, say so plainly and say what she would check. | F5 is the target-setting claim. Tests whether the targets were tested, which a data-driven interviewer always asks. |
| B5 | "Describe an analysis you ran in SQL or Tableau where the answer changed a decision." | JD | [grounded] "skilled in SQL/Tableau" | Open prompt. Pick one analysis, then say the question, the method at the level she did it, and the decision it changed. Answer slot: if no analysis changed a decision, say so and give the nearest one; if she did not run analyses in these tools, say so. | Raising source: "run independent analysis in SQL and Tableau" (your JD highlights). Tests F4 with an example, not an adjective. |

### C. Case / Strategist (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Enterprise expansion is a stated priority. An enterprise account that bought on land renews flat after a year. Diagnose it: what do you need to know first?" | CASE | [grounded] "enterprise expansion" (your research note); "land/adopt/expand/renew" (your JD highlights) | Live problem, no claim about her past. Clarify, then objective, then segmentation, then approach, then metrics, then risks. Pricing angle: separate a price problem from a value or adoption problem before proposing a lever. Name the first metric she would check, as a plan. | Dan's pricing lens, applied to the lifecycle requirement (R2) and a stated priority. |
| C2 | "A much larger platform vendor starts bundling a comparable product into its suite at no extra charge. What do you do with the two new product lines over the next two quarters?" | CO | [grounded] "main competitive threat is bundling by a much larger platform vendor" (your research note) | Segment by bundle exposure. Price and packaging options. Hold a line on what the bundle does not cover. Name one premise to challenge, respectfully. No claim about her past. | Competitive threat from the research note, asked as a live case. Covers the two-product-line requirement (R1) at the company's altitude. |
| C3 | "Compass is an AI copilot launch, and the company is reaching profitability at the same time. How would you sequence go-to-market investment?" | CO | [grounded] "an AI copilot launch ('Compass')"; "reaching profitability" (your research note) | Clarify before sequencing. Name the tradeoff between launch spend and profitability. If AI experience comes up, use F6 at its own scope: which tools she uses, and for what. Never present AI product experience. | Tests R6 (AI a plus) in case form, with the company's own vocabulary. |
| C4 | "Where would you look for whitespace across land, adopt, expand and renew for a new product line? Name the first cut." | CASE | [grounded] "identify whitespace across land/adopt/expand/renew" (your JD highlights) | Live problem, no claim about her past. Treat the lifecycle as stages. First cut by segment, and by where accounts stall. Name the data she would need. | Covers R2, where F3 is silent. CASE because the honest answer is structure, not a record. |

### D. Skeptic (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Partner-motion design experience is required for this role. Which part of that would you be weakest at on day one?" | JD | [grounded] "partner-motion design experience required" (your JD highlights) | **Highest-ROI prep in this pack.** Hold: the position is the one F2 carries, "For the partner work, I built a partner-level revenue model used in carrier negotiations." Hold through two follow-ups by returning to the model, never by adding to it. Concede on the second follow-up: the part of a partner motion beyond the economics is what she would learn first. Answer slot: if she has done work beyond the economics, say which part and how she decided it; if not, say so. Never fold on the model. | This is the most predictable objection: a required JD line, sitting on a transferability gap (F2). Rehearsing a calm, exact concession changes the interview. |
| D2 | "You haven't set quotas or worked in sales ops. Why should a sales-strategy team trust your targets?" | EXP | [grounded] "No classic sales-ops or quota-setting experience." (your message) | Plain acknowledgment: "I haven't set quotas or worked in sales ops." Then the quote at its scope: "set annual volume targets with cross-org consensus." Then how she would learn quota design, said as a plan. No claim to quota work. | F7 is a stated absence. Dan's title makes this likely, though no JD line raises it. Source note: this negative came from your message. Confirm it in Priya's own words. |
| D3 | "Nine years in consumer tech, now B2B data infrastructure. Why this, and why now?" | CO | [grounded] "9 at a large consumer-tech company in product strategy & ops" (your message); priorities from your research note | Motivation tied to the priorities: enterprise expansion, Compass, profitability. Name one thing from consumer work that transfers, at its own scope. Do not claim B2B data experience the material does not show. | Motivation probe on a domain switch, and the one "why leave" question a skeptic always asks. |

### E. Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who has run a quota cycle?" | JD | [generic] persona stem | Hold-then-concede. Hold on what the quotes carry: the partner-level model, the cross-org targets, the proposal. Hold through two follow-ups. Then concede, specifically: "I haven't run a quota cycle." Never fold on the model. | Composure under the quota gap (F7). Pressure is low weight for a peer round, but she should not meet it live for the first time. |
| E2 | "Why should I believe that carrier-negotiation model did anything, rather than just existed?" | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" | Hold on "used in carrier negotiations," which is the quote. Answer slot: if she knows what the negotiations did with the model, say it; if she does not have the outcome, say so plainly. Do not supply an outcome. | Tests whether the held claim survives a second follow-up. An outcome she cannot back is the first thing the follow-up breaks. |

### G. Rapport / Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm"; "9 at a large consumer-tech company in product strategy & ops" (your message) | A 90-second arc with two beats, both from the quotes: two years of strategy consulting, then nine years in consumer-tech product strategy and operations. End on why she is here. Casual, and scored. | Opener. Dan's first impression is made here, and it sets up the rest of the hour. |
| G2 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" (your message) | Name the tools and what she uses them for, in her own words. Answer slot: if she has built anything with them, say what; if not, say she uses them and for what. Do not present AI product experience. | Casual form of R6, the AI plus-skill. Scored despite the register. |

### Requirement coverage

| JD requirement | Question IDs | Note |
|---|---|---|
| own GTM strategy for two new product lines | C2, B1, A5 | F1 is transferability |
| identify whitespace across land/adopt/expand/renew | C1, C4 | F3 is silent; C4 makes no claim |
| run independent analysis in SQL and Tableau | B5 | F4 |
| partner-motion design experience required | D1, A3, B3, E2 | F2 is the largest gap |
| strong cross-functional influence | A1, A2, A5 | F5 |
| AI experience a plus | G2, C3, A4 | F6 is low confidence |
| Not a JD line: target and quota setting | D2, E1 | F7 is a stated absence |

## Reverse questions

Each one is for Dan. Why it lands is given for each.

1. "What did the startup chapter change about how you make pricing calls?" Lands because it ties to his own path and turns the interview into a peer conversation.
2. "What could a new person do in their first month that would genuinely help your team?" Lands as the reciprocity question a peer will weigh heavily.
3. "Where do pricing decisions and Emerging Products GTM hand off today?" Lands because it asks about the seam directly, the peer question A1 raises.
4. "Of enterprise expansion, Compass and profitability, which is the one where pricing is hardest right now?" Lands because it asks the pricing question in his language.
5. "Where has the bundling threat shown up in deals so far?" Lands because it shows she read the research note and wants the field view.
6. "When a pricing call goes wrong, how fast do you find out?" Lands with a data-driven interviewer, because it asks about his measurement loop.

## Delivery notes

Keep answers to 90 to 120 seconds. Use "I" for what she did and "we" for what the team did. Hold a position through two follow-ups before any concession, and make the concession exact.

## Sources

Provided documents: your message (role, JD highlights, Priya's background, Dan's profile, research note). No dossier was present. No searches or fetches were sent.

Research tier: L0. Searches 0, fetches 0. You asked for no further research.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Company values | unavailable | Values cheat sheet. Not included, because no values-style round was described |
| 2. Interview process for the role family | unavailable | Loop structure and persona weights beyond this round |
| 3. Company strategy and recent news | unavailable | Current Compass timing and recent moves beyond your note. The CO bank uses your note only |
| 4. Dan Kovac, Northwind | unavailable | Interviewer public footprint: talks, writing, recurring themes |
| 5. Representative JD for the title | unavailable | Full JD wording. Your highlights stand in for it |

## Upgrade menu

- **Full JD text:** turns the highlight rows into verbatim quotes, and shows whether a location, work-authorization or travel gate applies. If one does, it gets its own row.
- **Dan's public talks or posts:** sharpens the persona weights and the reverse questions from his published themes.
- **Light research (about six searches and two page fetches):** adds the company values, the interview process, and recent Compass timing. Those rows are currently unavailable.
- **Interview schedule, if the round is one of several sessions:** adds per-session mini-packs.
- **Priya's own wording of F1 and F7:** replaces your note with her sentences, so the attribution and the quota negative rest on what she said.
