Research calls were refused by the host permission, so the pack runs without web sources. I'll write it up now.
Your prep pack is saved as `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-tuesday-part-2-rooms-case-2-denied-88d798d5/a0e40083-03de-4855-9e78-b691960a0450/scratchpad/atlas_freight_operations_manager_interview_pack.md`. I built it for a hiring-manager or director round with a skeptical lean, since your note didn't say who you're meeting. Web research was refused by the host's permission check, so it uses only your JD text and your background.

The pack's biggest finding: the JD asks for 12 supervisors across four sites, and your material shows 3 supervisors at one site. Expect that to be the main probe. Question B1 is the one to rehearse hardest. Also, the JD's "5+ years operations leadership" is not clearly met by your material yet, so it needs your answer before the interview.

Tell me two things and I'll reweight the pack:

1. What kind of round is it, and who is interviewing you: your future manager, a peer, a skip-level, or a panel?
2. How many years have you led people, as opposed to working in ops? This decides whether the five-year requirement is met.

Two offers, neither pushed:
- I can run a live drill: I'll play the Skeptic on B1, and feed back against that question's guidance.
- I can save a `tuesday-dossier.md` recording the gaps this prep exposed, to carry into later sessions.

I can also convert the pack to Word if you'd like it that way.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: atlas_freight_operations_manager_interview_pack.md -----
# Interview prep pack: Operations Manager, Atlas Freight

Built with the inputs you gave: the JD text and your background summary. Round type and interviewer are unknown, so this pack assumes a hiring-manager or director-level round with a skeptical lean. Reweighting follows once you answer the two questions in the message.

## How to use + type key

Personas describe how a question is asked. Types describe what is being scored.

- **CASE**: live problem from the role, scored on structure and reasoning
- **EXP**: a claim from your background, scored on whether it survives scrutiny
- **JD**: a stated responsibility or requirement, scored on whether you can do the listed job, gaps included
- **CO**: company knowledge (none included; no research was available)
- **VAL**: values (none included; no published values were available)

Guidance is scaffolding, not a script. Rehearse the shape, then say it in your own words.

## Prep triage

Prep time was not stated, so no schedule. Priority order if you have limited time:

1. **B1**: the most likely objection to this candidacy, and the deepest rehearsal here
2. **D1** and **D2**: holding a position under pressure
3. **C1** and **C3**: the 40% figure and the reporting gap
4. Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" (JD) | "currently a senior shift manager over 3 supervisors" (your message); "7 years in warehouse and distribution ops" (your message) | medium | [grounded] | transferability | Your material shows one site at shift level. It does not show multi-site ownership, and that gap should not be bridged. Answer slot: if you have run more than one site or a daily operation across sites, say which and how; if not, say so plainly and say what you would do in the first 30 days. |
| F2 | "lead a team of 12 supervisors" (JD) | "currently a senior shift manager over 3 supervisors" (your message) | medium | [grounded] | transferability | Leading supervisors is in your material at a span of three. The span of twelve is not. Answer slot: if you have led a larger group of managers or supervisors, say how many and over what period; if not, say so and say how you would build the team. |
| F3 | "drive on-time performance and cost-per-shipment down" (JD) | "cut mis-pick rate 40% by redesigning the pick path" (your message) | medium | [grounded] | transferability | Your material shows accuracy, not on-time performance or cost per shipment. Those are adjacent measures, not the same. Answer slot: if you have moved OTP or a cost metric yourself, say which and what you changed; if not, say so and say which lever you would pull first. |
| F4 | "5+ years operations leadership required" (JD) | "7 years in warehouse and distribution ops" (your message), but the material does not establish how many of those years were leadership | none | [grounded] | hard_gate | Your material does not establish the five years of leadership the JD names. The question that decides this is asked in the message, not answered here. |
| F5 | "build reporting in Excel/Power BI" (JD) | "solid Excel" (your message); "never used Power BI" (your message) | none | [grounded] | capability | Words: "I haven't used Power BI." Then a plan for learning it, said as a plan and never as a past. |
| F6 | "Lean/Six Sigma a plus" (JD) | "green belt certified" (your message) | high | [grounded] | none | The certification reaches the requirement. Expect a probe on what you applied it to. |
| F7 | "ran the site's peak-season surge plan two years running" (your message) | "ran the site's peak-season surge plan two years running" (your message) | medium | [grounded] | presentation | This is the strongest operational-planning evidence you have. Its bridge uses your words; no figure or result is added. |

Requirement-coverage line: F1 → A3, B1; F2 → A4, B1; F3 → A1, A2, C3; F4 → message question (d), B2; F5 → C3, E2; F6 → C4; "Own daily terminal operations" and "lead a team" → A3, A4, B1. Nothing is uncovered.

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Ran daily operations across multiple sites | Inflated form of F1 | "I ran one site's shift." The limit is the pack's observation: your material says one site at shift level. |
| Led a team of twelve | Inflated form of F2 | "I currently manage three supervisors." No slot toward twelve. |
| Drove on-time performance or cost per shipment down | Inflated form of F3 | "I cut mis-picks 40% by redesigning the pick path." |
| Built Power BI reporting | Negative you stated, F5 | "I haven't used Power BI." No slot. |
| Met the five-year leadership requirement | Gate not yet established, F4 | Not claimed until you answer. |

## Question banks

Weights: Case/Strategist 4, Skeptic 4, Data-Driven Prober 3, Pressure 3, Conversational 2. Relationship priors fell back to a hiring-manager round, so the Peer Evaluator bank is omitted pending the round type.

### Case/Strategist (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "On-time performance slipped six points across four sites last quarter. Where do you start?" | CASE | [generic] | Clarify which sites and which shifts moved, then segment by site, shift, lane and carrier. Say the metric you would check first. Name the risks of each fix before you pick one. | A live problem from the OTP requirement. No claim about your past. |
| A2 | "Cost per shipment is up while volume is flat. Walk me through your first 30 days." | CASE | [generic] | Clarify what changed. Then split cost into labour, transport and rework. Say which split you would check in week one, and who you would ask. | Cost-per-shipment is the JD's second headline measure. No claim about your past. |
| A3 | "Daily terminal operations across four sites: what do you run on day one?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" (your message) | Describe the daily rhythm you would set up: a daily metrics review, a shift handover standard, an escalation route. Answer slot: if you have run a daily cross-site review, say how; if not, say so and describe what you would build. | F1 is the evidence and the likeliest place to be probed. The question is a plan, so it asks for no claim. |
| A4 | "You inherit twelve supervisors, most longer in post than you. Week one?" | CASE | [grounded] "currently a senior shift manager over 3 supervisors" (your message) | Start with listening: one-to-ones, then looking at the data each supervisor owns, then setting one shared target. Say what you would not change in week one. | F2 is the scale gap. The answer is a plan, not a record of past team size. |

### Skeptic (weight 4) — highest-ROI prep

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Your background is one site at supervisor level. Why should we believe you can run twelve supervisors across four sites?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" (your message) | Hold: say what you have done, which is run a shift and a site peak plan (F7), and name the team span you have led. Two follow-ups: return to what you ran. Concede specifically: "My current span is three supervisors. Twelve across four sites is the step I'd need to prove, and this is how I'd prepare for it." Answer slot: if you have led a wider span, say which. If not, say so plainly. | F1 and F2 are where the JD presses hardest, so this objection will arrive in some form. A rehearsed, non-defensive answer changes the interview. |
| B2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "5+ years operations leadership required" (JD) | The honest answer names one gap by its own name: leadership span (F2) or Power BI (F5). Do not list all of them. Give one, then the ramp plan. Answer slot: how many years you have led people, in your own words, and where the count stops. | F4 is the gate. The answer must come from you; the pack does not supply the number. |
| B3 | "I don't see five years of leadership on your CV. How would you handle that?" | JD | [grounded] "7 years in warehouse and distribution ops" (your message) | Acknowledge the gap as the material shows it. Then say the years you do have, and what they cover. Do not stretch the 7 years into leadership years. Answer slot: if your leadership years are fewer than five, say how many and from when. | F4. This is the probe if the gate is unclear. The honest branch is the count, not a bridge. |

### Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the 40% mis-pick reduction was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Defend the number: the baseline period, how errors were counted, and what the figure is sensitive to. Name the assumption you'd defend least before they do. Answer slot: state the baseline and counting method in your own words; if you don't know how it was counted, say so plainly. | Headline metric; magnet for probers. The pack supplies no baseline, method or attribution. |
| C2 | "Which part of the pick-path redesign did you decide, and which did the site decide?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Name what was yours and what was the site's, in your own words. Answer slot: if you proposed the design, say how. If someone else set it, say so plainly and describe your part. | Attribution honesty. The probe exists to catch inflation. |
| C3 | "Show us how you'd report on-time performance and cost per shipment to four site leads." | JD | [grounded] "build reporting in Excel/Power BI" (JD); "solid Excel" (your message); "I haven't used Power BI." (your message) | Describe the report: metrics, cadence, who reads it, and the Excel model you would build first. Name Power BI as the next step, with a learning plan, in one sentence. | F5. The Excel strength is grounded; the Power BI gap is stated as an absence, not bridged. |
| C4 | "Which Lean or Six Sigma project would you point to?" | EXP | [grounded] "green belt certified" (your message) | Name the project if you applied the method to one. Answer slot: if the certification is the extent of it, say so plainly and describe where you would apply it first. | F6. The quote reaches the requirement but not a project; the pack supplies none. |

### Pressure / Stress (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over someone who has run a team of twelve?" | JD | [grounded] "ran the site's peak-season surge plan two years running" (your message) | Pause. Hold the position through two follow-ups: the surge plan is what you ran, twice. Concede plainly: "They have the span I don't yet have. My case is the peak plan and the pick-path result." | Tests composure. Hold what you actually ran; concede the span. |
| D2 | "That mis-pick result: how much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Hold: name your part in the redesign. Two follow-ups: return to your part. Concede only what is true; do not fold on the core claim to restore harmony. | Attribution under pressure. Mirrors C2 in a stressed register. |

### Conversational / Rapport (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So — walk me through the journey." | JD | [grounded] "7 years in warehouse and distribution ops" and "currently a senior shift manager over 3 supervisors" (your message) | A 90-second arc: warehouse and distribution, to senior shift manager, to the pick-path result and the peak plan. Say each step in your own words. | Casual register; still scored. The arc uses only your sentences. |
| E2 | "What are you playing with in Power BI these days?" | JD | [grounded] "never used Power BI" (your message) | Acknowledge plainly: "I haven't used Power BI." Then the learning step you would take. No slot. | F5. Casual questions about JD topics are scored. |

## Reading the interviewer

No interviewer named. This section is absent until you give a name.

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist | Live operations problems | High: hiring-manager priors and the JD is operational | Clarify, objective, segment, approach, metrics, risks |
| Skeptic | Gap probes on span and leadership years | High: F1, F2, F4 are the gaps the JD states | Rehearse B1 until boring; concede the span specifically |
| Data-Driven Prober | Probes on the 40% and the reporting gap | Medium: one headline number and a Power BI gap | Name the weakest assumption; say when you don't know how it was counted |
| Pressure | Time-boxed challenge on fit | Medium: a skip-level or director round would use it | Hold, then concede |
| Conversational | Journey question, Power BI casual question | Medium: common opener | 90-second arc; scored like any question |

## Delivery coaching

No assessment provided. Section omitted.

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a good first 90 days look like for this role, and how will it be measured?" | Shows you're planning for the outcome, not the title. |
| R2 | "How do OTP and cost per shipment differ across the four sites today, and which one is the priority?" | Shows you read the JD's measures as separate problems. |
| R3 | "What reporting do site leads use now, and where is Power BI in that?" | Surfaces the tooling gap in a neutral way. |
| R4 | "What is the biggest operational problem you would want solved in the first six months?" | Asks for their priority, which tells you what they will judge you on. |
| R5 | "How do operations and commercial teams agree on cost-per-shipment targets?" | Shows you know the cost measure is shared, not owned by ops alone. |

## Sources

Provided documents: the JD text and your background message. No CV.

Research tier: L1 requested; 0 of 6 searches returned results, 0 of 2 fetches run.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Atlas Freight values` | unavailable | Values cheat sheet (section 10): not included. Three search calls were refused by the host's permission check, so no results came back. |
| 2. `Atlas Freight interview process operations manager` | unavailable | Loop structure and persona weights: not moved; weights are priors only. Refused by the same permission check. |
| 3. `Atlas Freight strategy / recent news` | unavailable | CO bank and grounding brief: not included. No call was sent to this target. |
| 4. `{interviewer name} Atlas Freight` | n/a | No name given. |
| 5. representative `Operations Manager` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions. |

## Upgrade menu

- The round type and who is interviewing → reweights the persona table and the question banks
- The five-year leadership answer → resolves gate F4 and B2/B3
- The interviewer's name → a tailored reverse question, and persona weights from public footprint
- Web access, if you can allow it → values and loop structure from research; the values cheat sheet and CO bank
- The job posting's full text, if different from what you pasted → exact quotes for any requirement missing one
