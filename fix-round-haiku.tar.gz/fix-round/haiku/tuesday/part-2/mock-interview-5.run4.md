Your prep pack is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-tuesday-part-2-rooms-case-5-denied-f3b85ede/08e7b42f-52df-415c-83bc-36de48506c22/scratchpad/kelverton-rail_senior-partnerships-manager_interview_pack.md`.

I built it on your message alone. I had no job description, no CV text, no values page, and no copy of the market report. Web search was refused by permission, so every company-specific claim is labelled `[generic]`.

The pack's main points:

- **Highest-risk question:** Ross on the quota (B2). You've never carried a direct quota, and that may be a gate for this role. Rehearse holding the position for two follow-ups, then conceding the risk specifically.
- **Commercial probe:** Ross will likely ask what "£4M influenced" actually counted (B1). Know the method and name your weakest assumption before he does.
- **POV (15 min):** three theses, each with a concession spoken aloud. (A) operators buy outcomes, not licences. (B) depth beats breadth: three or four implementation partners, not a long reseller list. Don't headline the 6-to-40 story, because a few dozen operators makes partner count the wrong measure. (C) a shared planning layer across operators. Only use C if the market report supports it.
- **Rail:** don't claim you know how train operators run timetables or rosters from the inside. Your transport work was network planning on the operator side, and the pack keeps it at that scope.

Four hours, roughly: 90 minutes building and timing the POV (aim for 12 minutes), 60 minutes on Ross's questions, 45 on Deepa's, 15 on reverse questions. The pack has the full schedule.

Two questions:

1. Does the job description list a quota or sales-target requirement? If it does, I'll rate the quota gap as a hard gate and rewrite the rows that depend on it.
2. Can you paste the market report's key lines, or the job description? Either would let me check Thesis C and replace the `[generic]` rows.

Offers:
- I can run a live drill: I play Ross on B2 and push back with follow-ups.
- I can save a `tuesday-dossier.md` recording the gaps this prep exposed, to carry into later sessions.
- I can convert the pack to a Word document if you want one.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: kelverton-rail_senior-partnerships-manager_interview_pack.md -----
# Interview pack: Senior Partnerships Manager, Kelverton Rail, second round (panel)

**Interviewers:** Deepa (VP Partnerships, your future manager) and Ross (Commercial Director).
**Format:** 60 minutes. First 15 minutes: a spoken point of view on operator partnerships over 18 months, no slides, landing on what it means for the operators. Remaining time: Q&A, with commercial pressure from Ross.
**Built on:** your message only. No job description, no CV text, no values page, and no copy of the internal market report were in the conversation. Research was attempted and refused (see Sources), so every company-specific claim here is `[generic]`.

## How to use + type key

Personas are how a question arrives. Types are what is being scored.

- **VAL**: values or behaviour. Not expected here unless Deepa asks about culture.
- **EXP**: your past work, probed for what was actually yours.
- **JD**: the role's stated responsibilities. Built from role-family requirements, so treat as `[generic]`.
- **CO**: company and strategy knowledge. Thin until the market report is in the conversation.
- **CASE**: a live problem for the role. Scored on structure.

Guidance is scaffolding, not a script. Speak it in your own words.

## Prep triage (4 hours)

1. **POV build, about 90 min.** Write the three theses in section 5 in plain sentences. Each needs its concession spoken aloud. Then say the whole POV out loud, timed at 12 minutes so you have slack. Do it three times.
2. **Ross drill, about 60 min.** Run B1 to B6 with a friend or aloud, then ask the follow-ups in section 6 until you can hold the position twice.
3. **Deepa drill, about 45 min.** Run A1 to A4, then the POV Q&A.
4. **Reverse questions, about 15 min.** Choose five from section 7 and rehearse them once each.

Everything else is insurance. Do not expand the pack to cover company facts you cannot verify.

## Fit snapshot

Requirements are role-family requirements, not quotes from a JD. Only your own sentences are quoted as evidence. Each row's gap type follows the routing rule in the template.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Sell into and grow operator relationships (role family) | "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" — your message | medium | [inferred] | transferability | Your material shows operator-side planning work, not selling to operators. Words stay at that scope: "I spent five years on the operator side of network planning." Answer slot: if you ever shaped a buying decision, a business case or a specification an operator signed off, say which and how; if you did not, say so and stay with planning. |
| F2 | Sold into rail specifically (JD line not supplied) | "Never sold into rail specifically" — your message | none | [grounded] | capability | A stated negative, so the words are yours: "I haven't sold into rail." Then how you would learn the buyer, said as a plan, never as a past. |
| F3 | Carry a direct revenue quota (role family, possibly a gate) | "never carried a direct quota, only influenced revenue" — your message | none | [grounded] | hard_gate | Surfaced, never bridged. Your material says you have not carried a direct quota. Whether this is a gate for the role is unknown until a JD arrives (see upgrade menu). Words, if asked: "I haven't carried a direct quota. What I've owned is influenced revenue." |
| F4 | Grow a partner or channel base (role family) | "took it from 6 partners to 40" — your message | medium | [grounded] | presentation | Your sentence reaches partner growth, in payments and ISV terms. Bridge rewords only that quote. Do not add operator specifics. |
| F5 | Attribute and report revenue through partners (role family) | "roughly £4M of influenced revenue" — your message | medium | [grounded] | discovery | The figure is yours but the method is not in the material. Answer slot: how it was counted, what it is sensitive to, and which part was yours. If you cannot say how it was counted, say so plainly. |
| F6 | Commercial depth on partner economics: margin, incentives, forecasting (role family) | None given | none | [generic] | discovery | Your material is silent. Answer slot: if you set or defended partner incentives or a forecast, say what and how; if not, say what you would model first. |

Observation (analysis, not words for you): your material shows partner growth and influenced revenue. It does not show operator-side selling, a direct quota, or the rail market.

## Prohibited list

| Not coached | Basis | Honest form |
|---|---|---|
| Sold into rail or to train operators | Inflated form of F1 and a stated negative (F2) | "I spent five years on the operator side of network planning" and "I haven't sold into rail." No slot pushes beyond these. |
| Carried a quota, or owned targets | Stated negative (F3) | "I haven't carried a direct quota. I've owned influenced revenue." |
| Know how train operators run timetables, rosters or performance regimes from the inside | Inflated form of F1; your material is bus and light-rail network planning | The planning work at its own scope. Ask about rail operations as a question you want to learn, not as something you know. |
| Grew the channel because of your individual plays alone | Inflated form of F4 | "I took it from 6 partners to 40" with what you led, in your words. |

## 5. Graded deliverable: the 15-minute POV

Declared by the recruiter. Do not let it run past 15 minutes. Aim for 12.

**Shape:** the first three minutes state the operator's problem in their own terms. The middle states your thesis. The last three say what it means for the operators.

**Thesis A: Operators buy outcomes (on-time running, recovery from disruption, crew compliance), not licences. Partnerships should be built around the operator's KPIs, not your product's features.** `[generic]`
- *Concession:* performance regimes and budget holders differ by operator and contract. A partner motion that sells to the wrong budget holder stalls.
- *What it means for operators:* partners who can show a KPI moving in the first 90 days.

**Thesis B: Depth beats breadth. Three or four integration and service partners who can implement inside an operator's existing planning and rostering stack will move faster than a long reseller list.** `[generic]`
- *Concession:* depth means fewer partners and a slower top line. I would accept that for 18 months and say how I would measure it.
- *Anti-pick:* do not headline the partner-count story (6 to 40). A buyer set of a few dozen operators makes count the wrong measure. This is the transfer from your ISV work that matters: the lesson is the method, not the number. (Your stated F4 sentence supports the claim that you grew a channel; it does not support a claim about operator buying.)
- *What it means for operators:* less disruption during implementation and fewer integration surprises.

**Thesis C: The industry's reorganisation is a window to offer a shared planning layer across operators, not a set of separate deals.** `[generic]`
- *Concession:* I cannot verify the current industry position from here. I have not read the internal market report in this conversation. Check this thesis against it before the interview, and drop it if the report says otherwise.
- *What it means for operators:* one planning data standard, less per-operator integration cost.

**Recommended pick:** A and B, with C as a sentence only if the market report supports it.

## 6. Question banks

Weights: Ross (B) is the heavier persona for commercials. Deepa (A) is the manager. The panel splits the 60 minutes roughly 15 POV, 25 Deepa-led, 20 Ross-led.

### Persona A: Deepa, manager (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk us through the partnership you would build first with an operator. Who is in the room?" | JD | [generic] | Name the buying group an operator would have: planning, operations, and finance. Then the partner you would bring in first and why. Do not claim you have met these people. | Role-family question about the buyer. `[generic]` because no JD and no quote covers it. |
| A2 | "What did you own in the ISV channel that you would not have done in a smaller team?" | EXP | [grounded] "took it from 6 partners to 40" | Name what you led, in your words, and what you delegated. If the choice of partners was shared, say so. | Tests what was yours. F4 is the evidence. |
| A3 | "Why would an operator care about a payments partner's approach? What transfers?" | EXP | [grounded] "so I know the operator world from the other side" | Answer about the method you would bring, not the sector knowledge. Keep the transport claim to planning. | F1 transfer is the likeliest probe. Hold to what the sentence carries. |
| A4 | "You haven't sold into rail. What is your plan for learning the buyer in the first 90 days?" | JD | [grounded] "Never sold into rail specifically" | Say the plan as a plan: talk to operators, learn their KPIs, map the budget holder. Plain acknowledgment: "I haven't sold into rail." No slot needed beyond that. | F2 is a stated negative. The plan is the strongest move. |
| A5 | Culture: "How would you work with a team that has been doing this for years?" | VAL | [generic] | Describe one time you joined a team and changed how it worked, only if your material carries one. If none, say so and give the nearest thing. | Selection scaffold ending in the honest branch. |

### Persona B: Ross, commercial director (weight 5, pressure and prober)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You say £4M influenced. Influenced is not booked. What did the finance team count?" | EXP | [grounded] "roughly £4M of influenced revenue" | Defend-the-number. Say how it was counted in your own words. Name the weakest assumption before he does. If you do not know the method, say so and say what you would check. | F5 is the evidence. The four defend-the-number slots apply. |
| B2 | "Ross pushes: you have never carried a quota. Why should we trust a partnerships leader to hit a number?" | JD | [grounded] "never carried a direct quota, only influenced revenue" | Hold the position. "I haven't carried a direct quota. What I've owned is influenced revenue, and here is how I'd connect partner activity to a forecast." Hold through two follow-ups. Concede specifically: the quota risk is real and you would want a ramp. | F3 is a hard gate candidate. Your highest-ROI prep. |
| B3 | "How do you model the margin on an operator partner deal where the operator pays through a regulated contract?" | JD | [generic] | Name what you would model first and what you do not know. Do not claim you have modelled a rail contract. | Role-family commercial question. `[generic]`. |
| B4 | "Give me the forecast for year one of this partnership channel." | CASE | [generic] | Structure the forecast: buyer count, sales cycle, partner contribution. Name the assumptions. Say what you would not commit to before data. | Live problem, scored on structure. Presupposes nothing about your past. |
| B5 | "Your ISV partners grew to 40. Operators are a few dozen. How do you get commercial return from a small buyer set?" | CO | [grounded] "took it from 6 partners to 40" | Do not defend the count. Say the concentrated buyer set changes the economics and what you would measure instead. | F4 is the evidence. Anti-pick shows judgement. |
| B6 | "What would you not do in your first six months commercially?" | JD | [generic] | Name one decision you would hold back on until you have operator data, such as a discount or a partner tier. Give the reason. | Shows judgement under pressure. |

Coverage: B1 and B2 test F3 and F5 directly. A1 and A4 test F1 and F2. B5 tests F4 at scale. F6 has no question yet; B3 covers it at `[generic]`.

### Requirement coverage

| Requirement (role family) | Question IDs |
|---|---|
| Operator buyer and relationship | A1, A3, A4 |
| Partner growth and channel management | A2, B5 |
| Revenue attribution | B1 |
| Direct quota ownership | B2 |
| Partner economics and forecasting | B3, B4, B6 |
| Rail domain | A4, F2 row only; no dedicated question |

## 7. Reverse questions

Ask at least five. Each has a reason it lands.

1. "What does a good first year look like for this role, in numbers?" *Lands because it shows you are thinking about outcomes, and Ross has to answer in figures.*
2. "Which operators are the most important accounts today, and what do they buy?" *Lands because it asks for the buyer's view, not the product's.*
3. "How is partner revenue currently counted, and what changed in that method last year?" *Lands because it invites the same question you were asked in B1.*
4. "Where has the partnerships approach gone wrong before?" *Lands because it signals you expect real history, not a pitch.*
5. "What would you need to see from me in 90 days to think I'm a good hire?" *Lands because it turns the interview into a working conversation with Deepa.*

Reciprocity note: Deepa is your future manager. Ask her one question about how she has changed the partnerships approach in her time there. Keep it to her path, not the company's.

## 8. Values / principles cheat sheet

Not applicable. No values-style round is detected, because no loop source establishes the loop and the company's values page could not be read.

## 9. Delivery coaching

No assessment was provided. Not applicable.

## Sources

**Provided documents:** your message (background, the interview format, the recruiter's email quoted). The internal market report was read by you but is not in this conversation, so it has not been used.

**Research tier:** L1 — searches 5 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Kelverton Rail values` | unavailable | Values cheat sheet; the search was refused, so it could not run. |
| 2. `Kelverton Rail interview process partnerships` | unavailable | Loop structure and persona weights. Refused. |
| 3. `Kelverton Rail strategy news` | unavailable | CO bank, and Thesis C's checking. Refused. |
| 4. Deepa and Ross, public footprint | unavailable | Reading the interviewers; query formed (first name, title and company), so not `n/a`. Refused. |
| 5. Representative Senior Partnerships Manager JD | unavailable | Fit snapshot requirements; the rows are `[generic]` because of this. Refused. |

Each search above was refused by permission: "Claude requested permissions to use WebSearch, but you haven't granted it yet." Fetches were not attempted.

## Upgrade menu

- **Full job description text** → the six `[generic]` requirement rows become `[grounded]`, and F3's hard-gate status is decided.
- **The internal market report pasted in, or its key lines** → CO questions and Thesis C can be checked against it; the consensus items to avoid can be named.
- **Interviewer names with surnames, or a link to Deepa's and Ross's public talks or profiles** → persona weights and a tailored reverse question.
- **Your CV text** → F1 to F5 quotes become verbatim CV lines, with their own provenance.
- **Search permission granted** → rows 1 to 5 can run at L1.
- **Recruiter's note on any further process, such as a case or a written exercise** → coverage for it.
