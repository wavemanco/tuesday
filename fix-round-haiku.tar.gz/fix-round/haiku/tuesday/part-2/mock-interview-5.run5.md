Your prep pack is saved as /tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-tuesday-part-2-rooms-case-5-denied-d3217659/7d7eed86-284f-4ff3-8d77-4cc6479f7f12/scratchpad/kelverton-rail_senior-partnerships-manager_interview_pack.md. I built it for a panel round, since you named Deepa and Ross and the format.

The main points:
- **Biggest risks:** no rail selling (C1) and no direct quota (A1). Both get hold-then-concede rehearsal.
- **The POV:** three theses, each with a concession you have to say out loud. The divergence from the internal report is not built yet, because I did not have its text.
- **Research:** search permission was denied, so the company's values, interview process and strategy are not in the pack. The loop comes from the recruiter's email instead.
- **Prep time:** a 4-hour schedule is in the file, with the POV first.

Two things would sharpen it most:
- Paste the market report's three headline recommendations, so the POV can depart from them.
- Paste the job description, if you have it, so I can add gate rows and JD-tagged questions.

Would you like a drill on C1 (the rail-selling objection), which the pack names as the highest-return prep? I can also save a tuesday-dossier.md recording the gaps this prep exposed, for later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

Is the person you're meeting your future manager, or a peer on the team? The answer reweights every bank. (Deepa is your future manager per your note, so the pack already assumes that.)

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: kelverton-rail_senior-partnerships-manager_interview_pack.md -----
# Kelverton Rail: Senior Partnerships Manager, second-round panel prep

**Panel (Tuesday, 60 min):** Deepa (VP Partnerships, your future manager) and Ross (Commercial Director).
**Structure per recruiter:** first 15 min a spoken POV on operator partnerships over the next 18 months, no slides, landing on what it means for the operators. Remaining time is Q&A, with Ross pressing on commercials.

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored: CO (company and commercial), CASE (live problem), JD (role requirement), EXP (your past work, tested for precision), VAL (values, none detected here).
- Guidance is scaffolding for a spoken answer, not a script. Rehearse only what you actually did, in your own words.
- Provenance labels: `[grounded]` traces to your message or the recruiter's email; `[inferred]` is a derivation; `[generic]` is a pattern with no claim about Kelverton.

## Prep triage (4 hours)

1. **60 min:** Draft the POV as spoken bullets: two theses from the build section, each with its concession. Cut to two if the draft runs past 12 minutes spoken.
2. **40 min:** Say the POV aloud twice against a timer. Target 12 to 13 minutes, leaving time for questions.
3. **40 min:** Drill the highest-ROI objections: C1 (no rail selling) and A1 (no quota, hold then concede).
4. **30 min:** Write the answer slots for B1 and A2 in your own words: what you can say about how the influenced figures were counted, and what you cannot.
5. **30 min:** D1 (first 90 days) and the reverse questions.

Everything else is insurance.

## Fit snapshot

No job description was supplied, so the requirements below come only from the recruiter's email and your own description of the role. Gate rows cannot be built without the JD.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "where you'd take our operator partnerships over the next 18 months" (recruiter's email) | "took it from 6 partners to 40, roughly £4M of influenced revenue" (your message) | medium | [grounded] | transferability | Your evidence is partner-channel work at a payments company, not operator partnerships. Words stay at the quote's scope: "I took the ISV channel from six partners to forty." Answer slot: expect a probe on whether any operator-facing relationship was yours to set; if none was, say so and describe the channel work. |
| F2 | "what it means for the operators themselves" (recruiter's email) | "bus and light rail network planning" (your message) | medium | [grounded] | transferability | Bus and light rail planning is adjacent to train operating companies, not the same work. Words: "I have worked on bus and light rail network planning." Answer slot: name who you advised on those networks, in your own words. Do not describe those clients as operators unless you were advising operators. |
| F3 | "Ross will push on commercials" (recruiter's email) | "only influenced revenue" (your message, from "never carried a direct quota, only influenced revenue") | medium | [grounded] | transferability | Your figure is influenced revenue, not owned revenue. Words: "I carried influenced revenue, roughly £4M." Answer slot: how the influence was counted and what share you would defend least. |
| F4 | "Ross will push on commercials" (recruiter's email) | "never carried a direct quota" (your message) | high | [grounded] | capability | This is a gap you stated. Words: "I haven't carried a direct quota." Then a plan for how you would learn the quota rhythm, said as a plan, never as a past. |
| F5 | "sell scheduling software to train operating companies" (your message, describing Kelverton) | "Never sold into rail specifically" (your message) | high | [grounded] | capability | This is a gap you stated. Words: "I haven't sold into rail." Then the ramp plan. Do not imply rail buying-cycle knowledge you have not shown. |

## The prohibited list

| Not coached | Basis | Honest form |
|---|---|---|
| Owned operator partnerships | Inflated form of F1 ("operator" is not in the quote) | F1 quote at its own scope. Pack's own observation, not words for you: your material says partner channel, not operators. |
| Delivered £4M of revenue | Inflated form of F3 ("influenced" becomes "delivered") | F3 quote at its own scope. |
| Knows how train operators buy or schedule | Inflated form of F2 (planning work for bus and light rail) | F2 quote at its own scope. |
| Sold into rail | Negative you stated (F5) | "I haven't sold into rail." No slot. |
| Carried a quota | Negative you stated (F4) | "I haven't carried a direct quota." No slot. |

## Interviewer read

Deepa and Ross are named in the recruiter's email, but no public profile was read: the search step was refused (see Sources). The interviewer read is absent. Persona weights below rest on each member's role in the panel. Upgrade menu carries the input that would sharpen this.

## Persona table

| Persona | Who | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|---|
| Pressure / Stress | Ross | Time-boxed challenges on commercials, interruptions on influenced versus owned revenue | High. Recruiter named commercials as his focus, and F3 and F4 are your sharpest gaps | Pause, restate, anchor in what you stated, hold through two follow-ups, then concede the specific uncertainty |
| Data-Driven Prober | Ross | Asks how the 40 partners and the £4M were counted | Medium-high. Headline figures always get tested | Name the weakest assumption before he does; say plainly what you do not know |
| Skeptic | Deepa | "Why should we believe you can sell into rail?" | High. Future manager; F5 is the largest gap and the recruiter's email does not mention it | Rehearse the plain acknowledgment and the ramp plan until it sounds ordinary |
| Case / Strategist | Deepa (and Ross on the operator question) | Live problem on the first 90 days, or on one operator's churn | Medium-high. The recruiter asked for an operator-level POV, so live operator problems are likely in Q&A | Clarify, then structure, then name a metric and one risk |
| Conversational | Deepa | Opener: "walk me through your journey" | Medium. Low weight on a panel, but scored | Pre-scripted 90-second arc from quoted facts only |

Values / Behavioral: not weighted. No loop source documents a values round, and the archetype fallback for a generic panel reads no. No VAL questions are written.

## Graded deliverable: the 15-minute POV

Recruiter named this as a deliverable, so it is graded. Build from:
- F1, F2, F3 (what you have built and at what scope)
- The required close: "what it means for the operators themselves"

**Consensus answer and divergence.** The internal market report would be the consensus answer for every prepared candidate, and the search step to find public material was refused. I have not seen the report's text. Once you paste its headline recommendations (question 1 below), the divergence below gets sharpened against them. Until then, do not recite the report.

**Thesis options (pick two; each carries its concession):**

- **T1. Sell to the planning desk, not only procurement.** Thesis: the operator's cost sits in planning and change, so a partnership that reaches the people who change timetables gets traction faster. Concession: I have not sold into rail, and I do not yet know which operator roles decide purchases. I would test that in three operator conversations before committing a plan.
- **T2. Use partners as the route into operators.** Thesis: the channel model that grew from six partners to forty is a transferable way to reach operators, through integrators and data partners. Concession: rail buying may run through frameworks that bypass partner routes, and I have not seen it work in rail.
- **T3. Measure partnerships by operator outcomes, not partner count.** Thesis: partner count was what I was measured on in the payments channel, and it is the wrong measure for operators. Concession: I have not owned outcome data in rail, so I would need to agree the measure with operators first.

**Differentiation strategy.** Name one consensus item (from the report, once pasted), then one thesis that departs from it, with your reasons. Scoring rewards the departure, not the recital.

**Anti-pick (where the role warrants saying no).** Say what you would not do in year one: for example, chasing every operator at once rather than two accounts you can learn from. Keep it as a thesis, not a claim about Kelverton's pipeline.

**Required close (operator benefit).** State it in the operator's terms, as a hypothesis to test, not a fact: for example, "fewer rework cycles when a timetable change lands." This is my suggestion, not something I verified about Kelverton's product. Replace it with the benefit the report or the recruiter states.

**Spoken script shape (about 12 minutes):** Who the operator is and what changes for them (1 min). Your two theses with concessions (6 min). Your divergence from consensus, with reasons (2 min). Operator close (1 min). Two minutes spare for the transition into Q&A.

## Question banks

Ordered by persona weight. Pressure and Skeptic are top-weight, so they carry the most depth.

### Pressure (Ross), weight high

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Sixty seconds: why should we believe influenced revenue means you can carry a quota?" | CO | [grounded] "never carried a direct quota, only influenced revenue" | Hold: "I have not carried a direct quota. What I carried is influenced revenue, roughly £4M." Hold through two follow-ups. Concede the specific uncertainty: "I don't yet know your quota rhythm; I'd expect to learn it in the first quarter." Never fold on the core claim. | F3 and F4 are the largest commercial gap; this is the question most likely to be asked in some form. |
| A2 | "That £4M. How much of it was actually you?" | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" | Answer slot: say how the influence was attributed in your own words. If you cannot say how it was counted, say so plainly and state the share you would defend least. | Premised on the figure the quote carries. The slot asks for attribution, not a method the pack supplies. |
| A3 | "You ran a channel, not an enterprise sale. What carries over to a train operating company?" | CO | [grounded] "running the ISV channel" | Name what transfers (partner-led reach, co-selling, partner forecasting) and what does not (rail buying cycles, frameworks). Do not claim knowledge of rail procurement. | F1 transferability; the honest version is the limit stated plainly. |
| A4 | "Year one: what would you give up to get operator revenue?" | CASE | [generic] | Structure the trade-off: which channel commitments you would pause, and what you would protect. Name the one you would stop. | Commercial trade-off with no past claim; the guidance makes none. |
| A5 | "Give me a two-quarter forecast on operator partnerships. What would you put a number on?" | CO | [generic] | Say what you would commit to and what you would not. Name the assumption you would defend least. Give no number without data. | Tests whether you will fake a forecast under pressure. Honest branch: "I wouldn't put a number on it without pipeline data." |

### Data-Driven Prober (Ross), weight medium

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Walk me through how the 6-to-40 partner count and the £4M were counted." | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" | Answer slot in four parts: how it was counted, what it is sensitive to, the assumption you would defend least, which part was yours. Say each in your own words. If you do not know how it was counted, say that. | Every headline figure is a probe target; the slot is precise attribution. |
| B2 | "Which of those 40 partners would you defend as a real partnership, not a listing?" | EXP | [grounded] "took it from 6 partners to 40" | Answer slot: if you can separate active partners from listed ones, say how you did it; if you cannot, say so and name what you would count first. | Partner count is the figure most easily inflated. |
| B3 | "What's your definition of influenced?" | EXP | [grounded] "roughly £4M of influenced revenue" | Give the definition only if you hold it. Answer slot: if you did not set the definition, say whose it was. | Tests whether you understand your own number. |

### Skeptic (Deepa), weight high

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "I don't see rail selling in your background. How would you handle that on day one?" | JD | [grounded] "Never sold into rail specifically" | The highest-ROI rehearsal in this pack. Plain acknowledgment: "I haven't sold into rail." Then a ramp plan, said as a plan, not a past: the three operator conversations you would have first, and who you would learn from internally. Bridge only from F2's quote at its own scope. | F5 is the largest gap and the recruiter's email does not mention it, so expect Deepa to raise it. |
| C2 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | Name direct quota ownership and rail buying cycles, in that order. For each, give the plan to close it. | Open prompt; the honest answer names real gaps. |
| C3 | "Why leave a payments company where the channel is growing?" | EXP | [grounded] "took it from 6 partners to 40" | Motivation from the operator question, not from the channel being finished. Do not say the channel is done. | Tests motivation consistency; the quote supports "growing", no more. |
| C4 | "What do you know about how a train operating company buys software?" | CO | [generic] | Say plainly what you have not seen, then what you would test first. Do not describe buying processes you have not observed. | A knowledge probe; the honest answer is the limit. |
| C5 | "What did you see in bus and light rail planning that a planner would miss from the desk?" | EXP | [grounded] "bus and light rail network planning" | Answer slot: if you did a piece of analysis yourself, describe it in your own words. If you only observed, say what you observed. | Tests whether your planning work carries the operator-side insight the recruiter asked for. |

### Case / Strategist (Deepa, with Ross on operators), weight medium

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sketch the first ninety days on operator partnerships. What do you need to know first?" | CASE | [generic] | Clarify, then objective, segmentation, approach, metrics, risks. Name the first three things you would need to know before writing a plan. | Live problem from the role; no claim about your past. |
| D2 | "One operator is moving partners to a rival. Diagnose it." | CASE | [generic] | Clarify what "moving" means and by when. Structure the hypotheses: product, relationship, price, or a change on the operator side. Name one metric and one risk. | Hypothetical; the guidance presupposes nothing about your history. |
| D3 | "What is the single operator outcome you would promise and measure?" | CO | [generic] | One outcome, in operator terms, with how you would measure it. Say it as a hypothesis to test. | Ties the POV close to a measurable promise. |
| D4 | "Where would you say no?" | CASE | [generic] | Name one thing you would decline in year one and why. | Anti-pick; tests judgment, not enthusiasm. |

### Conversational (Deepa), weight low

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | CO | [grounded] "9 years in partnerships" and "running the ISV channel" and "bus and light rail network planning" | 90-second arc in this order: five years in transport consulting on bus and light rail network planning; nine years in partnerships; the last four at a payments company running the ISV channel. Add no claims beyond these. | Casual register, still scored; the arc uses only quoted sentences. |
| E2 | "What have you been reading about rail lately?" | CO | [generic] | Name one thing you have read, only if you have read it. If you have not, say so and name what you would read first. | Casual question about a hot topic; never invent a reading. |

**Coverage.** Requirement-coverage line (no JD supplied; the three recruiter requirements and your stated gaps):
- Operator partnerships over 18 months: POV, D1, D2, D3, A3
- What it means for operators: POV close, D3, C4, C5, E2
- Commercials: A1 to A5, B1 to B3
- Rail selling gap (F5): C1, C2, C4
- Total questions: 19 (within 18 to 26)

## Reverse questions

1. "What is the operator decision you would most want a partner to change?" Why it lands: it turns the POV into a shared problem, not a pitch.
2. "What would you expect me to have in place by day ninety?" Why it lands: it tests the ramp plan from C1 against their actual expectation.
3. "Where do you see the current operator partnerships as weakest?" Why it lands: shows you researched the gap without reciting the report.
4. "How does Ross decide what counts as commercially sound in a new partnership?" Why it lands: the commercial question is the one he pressed on, and asking it openly signals you will be measured on it.
5. "What would tell you in six months that this hire was the right call?" Why it lands: a measurable success criterion from the manager.

## Values / principles cheat sheet

Not built. No values-style round is detected: no loop source documents one, and the generic-panel archetype reads no.

## Graded deliverable: see above (the POV build section)

## Sources

**Provided documents.** Recruiter's email as quoted in your message (round structure, POV brief, Ross's focus). Your background, in your message. The internal market report: you said you read it, but I was not given its text, so it is not used as a source here.

**Searches and fetches sent.** Permission to use search was denied in this session, so no results came back:

- `Kelverton Rail values`: refused
- `Kelverton Rail interview process partnerships`: refused
- `Kelverton Rail strategy news`: refused

No page fetches were attempted.

**Research tier:** L1, searches 3 of 6, fetches 0 of 2. user links read 0.

**Target accounting:**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `{company} values` | unavailable | Would have fixed value names for the values cheat sheet. Refused. No values cheat sheet is built, and this is the reason it is missing as well as the absence of a detected values round. |
| 2. `{company} interview process {role family}` | unavailable | Would have confirmed the loop. The loop is established instead by the recruiter's own words (one panel session, 60 minutes, POV first), so persona weights follow that. Refused. |
| 3. `{company} strategy` / recent news | unavailable | Would have fed the CO bank with current priorities. Refused, so CO questions are generic and labelled so. |
| 4. `{interviewer name} {company}` | unavailable | Would have given the interviewer read for Deepa and Ross. Names were available, so this is not n/a. Refused. |
| 5. representative `{role title}` JD | unavailable | Would have given requirement rows for the fit snapshot. No JD was supplied. Refused. |

## Upgrade menu

- The job description text → gate rows (any right-to-work, location or travel terms), JD-tagged questions, and the requirement-coverage line completed against the posting
- The market report's three headline recommendations → a sharper divergence in the POV build section, with a real consensus item to depart from
- Permission for search, or the company's values page pasted → values cheat sheet and loop structure checked against the company's own words
- Deepa's and Ross's public profiles (LinkedIn or talks, pasted) → interviewer read and persona weights tuned per member; a tailored reverse question for Deepa's path
- Deeper research, once offered: up to 6 more searches and 2 more fetches, several more minutes, for a strategy brief on Kelverton's operator business. Want it?
