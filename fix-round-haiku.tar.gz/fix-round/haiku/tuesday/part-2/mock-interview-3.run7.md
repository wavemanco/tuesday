Your prep pack is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-tuesday-part-2-rooms-case-3-denied-d5c039de/38acfae5-d253-4cc9-bd9c-d79bcd3e068e/scratchpad/stripe_product-operations-manager_interview_pack.md`.

It's a generic first pass. I had only the company and the role title, so it has no job description, no CV, no round details and no interviewer name. Web search was refused by the host, so nothing about Stripe's values, interview loop or strategy is sourced. I left those sections out rather than fill them from memory. Your own material would change the pack the most: the seven requirements are role-family guesses, and every question about your experience is an open prompt until I can see your background.

The highest-ROI prep is B1, "Which part of this role would you be weakest at on day one?" Without a record on file, that's the objection most likely to come up in some form. Its answer slot asks you to name the gap plainly and give a 30-day ramp plan.

Say the word and I'll play the Skeptic on B1 in a live drill. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

Two questions would restructure the pack:
1. Is the person you're meeting your future manager, a peer, or someone else? If the final is several sessions, send the schedule.
2. Can you paste the job description and your CV or résumé? With them, the generic rows become quoted requirements and the questions about your experience get your actual numbers.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: stripe_product-operations-manager_interview_pack.md -----
# Stripe: Product Operations Manager, final-round prep pack

**Role:** Product Operations Manager. **Company:** Stripe. **Round:** final (number of sessions, format and interviewers not given). **Interviewer:** not given.

**What this pack is built on:** the company and role title only. No job description, no CV, no round details, no interviewer name. Web research was refused by the host (see Sources), so nothing below about Stripe's values, interview loop or strategy is sourced. Those sections are dropped, not filled from memory. Everything that is not in your own words is labeled `[generic]`.

## How to use this pack

- **Personas** describe how a question is asked. **Types** describe what is being scored.
- Type key: **VAL** behavioral and values; **EXP** work-experience deep-dive; **JD** role-driven; **CO** company and strategy; **CASE** live problem.
- Guidance is scaffolding for a spoken answer, not a script.
- Nothing you have written about your experience is in this conversation yet, so every question about your past is an open prompt with a selection scaffold. Each one ends in an honest branch: if no example comes to mind, say so, then give the nearest one you have.

## 1. Fit snapshot (worksheet variant)

No JD and no CV, so the requirements below are role-family patterns for product operations, not Stripe's stated requirements. Every evidence cell is `none given`.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Running a process that several product, engineering and go-to-market teams have to follow (role-family pattern) | none given | none | [generic] | discovery | Strong evidence looks like one process you set up or ran end to end: which teams it touched, what changed. Selection scaffold: pick a process more than one team had to follow. If none comes to mind, say so, then give the nearest one. |
| F2 | Operating cadence: planning cycles, business reviews, prioritization forums (role-family pattern) | none given | none | [generic] | discovery | Strong evidence looks like a recurring forum you ran or fed. Selection scaffold: name a review you prepared for or chaired, and say which part was yours. |
| F3 | Defining and tracking metrics; knowing where a number came from (role-family pattern) | none given | none | [generic] | discovery | Strong evidence looks like one metric you owned or relied on, with its definition and source. Scaffold: name a metric, what it counted, and what it was sensitive to. |
| F4 | Launch or rollout coordination: go/no-go, risk tracking (role-family pattern) | none given | none | [generic] | discovery | Strong evidence looks like one launch you coordinated, with the risks you tracked and how they were closed. Scaffold: name the launch and your part in it. |
| F5 | Analysis for decisions: spreadsheets, SQL or similar, interpreting data for a non-analyst audience (role-family pattern) | none given | none | [generic] | discovery | Name only the tools you have used. Scaffold: one decision a piece of analysis changed, and what you did yourself. |
| F6 | Influence without authority when priorities conflict (role-family pattern) | none given | none | [generic] | discovery | Scaffold: a disagreement with a peer or senior partner, what you wanted, what you did, how it ended. Honest branch: say so if none is recent or yours to tell. |
| F7 | Motivation for this company and this role (role-family pattern) | none given | none | [generic] | discovery | Answer with one concrete problem you want to work on, in your own words. Avoid general praise of the company. |

## 2. Prohibited claims

No entries yet. A prohibited list is built from candidate sentences that a claim could stretch, and this conversation holds none. Standing rule for every answer in this pack: describe what you did, in your own words. Do not adopt a process name, metric or outcome you could not repeat under a second question. This list is built once a CV is in.

## 3. Persona table

No loop source establishes the final round's format, and no round relationship is known. The fallback is the generic archetype: flat weights, said plainly. No values-style round is assumed. Two values questions are kept as insurance, since finals often include one.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | A live product-ops problem: diagnose a drop, plan a launch | High. The role is operational; structure is scored | Clarify, then structure, then answer; say the framework aloud once |
| Skeptic | Quiet probing of the missing direct experience and of why this role | High. The most predictable line of questioning when nothing is yet on record | Rehearse the one objection until it is boring; calibrated candor, a ramp plan |
| Data-Driven Prober | "How was that counted?" | Medium. Probers go after any number you give | Say what you know and what you don't; name the weakest assumption first |
| Pressure | Time-boxed, interrupting, "how much of that was you" | Medium. Tests composure | Pause, restate, hold through two follow-ups, concede specifically |
| Peer Evaluator | Seams between teams; credit | Medium. Likely if the final includes a cross-functional partner | Propose seam principles rather than pretend to know the seam; offer what you'd bring their team |
| Conversational | A friendly opener, "walk me through your journey" | High as an opener. Casual questions are still scored | A 90-second arc, prepared in advance |
| Values / Behavioral | "Tell me about a time…" | Low-medium. No values round is documented, so this is insurance | Selection scaffolds; say plainly if no example fits |

## 4. Question banks

Depth: the four personas with the most weight get three questions each; the rest get two. Total 17, under the 18 floor because no JD or CV means fewer grounded questions.

### Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A product's weekly review shows its main adoption metric down 15% over three weeks. Walk me through how you'd diagnose it." | CASE | [generic] | Clarify what the metric counts and when it changed. Segment (by customer type, region, release, channel). List two or three hypotheses. Say what you'd check first and what would change your mind. No claim about your past. | Live problem typical of an operations role; scores structure and clarification |
| A2 | "You're launching one product in five markets, and three teams disagree on timing. What do you do in the first week?" | CASE | [generic] | Name the decision that has to be made and who makes it. Set up one shared view of dependencies and risks. Propose a decision forum and a date. Keep the answer to the first week. | Tests F1 and F4 as a live problem rather than a record |
| A3 | "What would you put in the operating cadence for a new team, and what would you cut?" | CASE | [generic] | Start from the decisions the team has to make. Add only forums that feed one of them. Name what you'd stop running. | Tests F2 as design judgment |

### Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | Highest-ROI prep in this pack. Name one specific area and why. Say what you have done adjacent to it, in your own words. Then a ramp plan: what you'd read, who you'd ask, what you'd deliver in 30 days. Answer slot: if you have no direct experience in that area, say so plainly, then give the learning plan. Hold through two follow-ups by returning to the plan. | This is the objection most likely to come in some form when there is no direct record. A rehearsed, non-defensive answer changes the interview |
| B2 | "Why product operations, and why now?" | JD | [generic] | One concrete reason tied to a problem you have actually seen, in your own words. Avoid generic praise of the company or the role. | F7 motivation probe; asked casually or directly |
| B3 | "What might make a hiring manager pick someone else?" | JD | [generic] | Name the gap plainly, then the nearest adjacent thing you have done, then how you would close the rest. Calibrated candor over bluffing. | Skeptic stem; tests honest self-assessment |

### Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "How would you choose the one metric that tells you a program is working?" | JD | [generic] | Start from the decision the metric drives. Say what it counts, what it would miss, and what would make you drop it. | F3 probe in a general form |
| C2 | "Tell me about a number you reported. How was it counted?" | EXP | [generic] | Open prompt: pick one number you reported. Say what it counted, what it was sensitive to, the assumption you'd defend least, and which part was yours. Answer slot: if you didn't count it, say so plainly. | Every headline figure is a probe target. Rehearse precise attribution |
| C3 | "Which analysis you've done would you redo first, and why?" | EXP | [generic] | Open prompt: pick one analysis. Name what you'd change and why. | Tests whether you know your own method's weak points |

### Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why should we pick you over someone who has run this process at a larger company?" | JD | [generic] | Restate the question. Anchor in one thing you did. Hold through two follow-ups. Concede one specific point, not the whole claim. | Pressure stem; tests composure more than content |
| D2 | "That result. How much of it was actually you?" | EXP | [generic] | Open prompt: pick a result you are proud of. Say what you did and what others did. If the honest answer is "less than it looks", say so and say what was yours. | Attribution probe; the hold-then-concede structure |

### Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Our teams sit side by side. Where's the seam between us, and what happens when we disagree?" | JD | [generic] | Propose seam principles, not a map you don't have. Say how you'd disagree with an equal: in private, with the data, and with a date. | Peer stem; partnership fit |
| E2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Open prompt: pick a shared piece of work. Say what you did and how you named others. | Partnership and credit; likely in cross-team interviews |

### Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [generic] | A 90-second arc: one role, one thing you changed, what you would do next. Do not claim outcomes you cannot say. | Opener scored on economy and interest |

### Values / Behavioral (insurance)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Open prompt. Pick a time you disagreed with someone senior and said so. Use "we" for context and "I" for what you did. If no such time comes to mind, say so plainly, then give the nearest one. | Standard behavioral probe; no published value is cited |
| G2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Open prompt. Name the customer, the metric, and the decision. If none fits, say so and give the nearest case. | As G1 |

### Company and strategy (generic, no research)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Pick one operational problem you think a payments company faces today. What would you check first?" | CO | [generic] | Name one problem and two checks. Do not cite Stripe facts you have not read. | Company-altitude question; generic because research was refused |

### Requirement coverage

| Requirement | Questions | Notes |
|---|---|---|
| F1 cross-team process | A2, E1 | |
| F2 operating cadence | A3 | |
| F3 metrics | C1, C2 | |
| F4 launch | A2 | |
| F5 analysis | C2, C3 | |
| F6 influence | D1, E2 | |
| F7 motivation | B2 | |

No requirement has no question.

## 5. Values cheat sheet

Dropped. No published values were retrieved, and no values round is documented. Values are not recited from memory.

## 6. Reverse questions

1. "What does the first 90 days look like for this role, and what would done look like?" Why it lands: makes the role concrete and shows you are planning.
2. "How does the product operations team measure its own impact?" Why it lands: asks the interviewer to describe the job's success test.
3. "Which decision in this group has been hardest to get right lately?" Why it lands: shows interest in the work itself.
4. "Where does the process most often break between product and go-to-market?" Why it lands: shows you think in seams.
5. "How many sessions are left in the final, and what does each one test?" Why it lands: a logistics question that also signals you know the process.
6. Reciprocity, if the interviewer is a peer: "What could a new person do in their first month that would genuinely help your team?"

## 7. Interviewer read

Dropped. No interviewer name given.

## 8. Delivery coaching

Dropped. No working-style assessment given.

## 9. Sources

- Provided documents: your message only.
- Searches sent, all refused by the host's permission setting:
  - "Stripe company values operating principles": refused
  - "Stripe interview process Product Operations Manager final round": refused
  - "Stripe strategy news 2026": refused
  - "Product Operations Manager job description Stripe": refused

Research tier: L1, searches 4 of 6, fetches 0 of 2. All four searches were refused by the host.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Stripe values | unavailable | Values cheat sheet (section 5), dropped. Refused. |
| 2. Stripe interview process, product operations | unavailable | Loop structure and persona weights. Fallback archetype used, flat weights. Refused. |
| 3. Stripe strategy / recent news | unavailable | CO bank: H1 generic. Refused. |
| 4. Interviewer name and Stripe | n/a | No name was given, so there was no query to form. |
| 5. Representative JD | unavailable | The fit snapshot (section 1) is role-family generic, not sourced. Refused. Its query named Stripe, which is looser than the spec's comparable-company query. |

## 10. Upgrade menu

- Paste the job description → the seven generic rows in section 1 become quoted requirements, and the coverage table becomes checkable.
- Paste your CV or résumé → the fit snapshot gets evidence cells, C2 and D2 get your real numbers, and the prohibited list is built.
- Tell me the round type and who you're meeting → persona weights and the question mix are recomputed. If the final is several sessions, send the schedule and I'll build one mini-pack per session.
- Forward the recruiter's note about focus areas or any take-home → a build section for each announced deliverable.
- The interviewer's name → a reverse question tied to their career path, and persona weights from their public footprint.
- Allow web search, or paste Stripe's values page and a recent strategy piece → values cheat sheet, loop structure, and CO questions grounded in sources. A deeper research pass (up to 6 more searches and 2 more fetches, several minutes) is available once search works, if you want it.
