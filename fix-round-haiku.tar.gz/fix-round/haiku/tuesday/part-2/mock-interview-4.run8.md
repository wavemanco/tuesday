Your prep pack is saved as `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-tuesday-part-2-rooms-case-4-denied-31a2b54b/63848d10-5d38-4296-b837-cbe49e927544/scratchpad/quartzline_platform-apis_interview_pack.md`. I built it for a hiring-manager round, using your dossier as the source. It has no CV or JD text, and web search was refused in this session, so company research didn't run.

Thursday is tomorrow, so I'd spend tonight on three things, in this order:
1. **A1**, the objection the underwriter named: "You've never held the PM title or owned a roadmap. Why should we hire you into one?" Say the plain acknowledgment first, then the 30+ integrations, and concede the roadmap gap specifically. Don't argue the title away.
2. **D1**, the 60-second version of the same question, under pressure.
3. **A5** and **C1**: whether you shipped an API product, and how you'd defend the "30+" figure. Answer both in your own words and in the scope the dossier's quote carries.

The core position is simple. You led 30+ end-to-end client integrations of the vendor's REST APIs, which is real and inspectable. You haven't held the PM title or owned a roadmap, and you should say so before anyone asks.

**Two things to check before Thursday:**
- The dossier is from 2026-08-14, about three months old. Confirm the posting still lists the same requirements. Pasting the current JD would let me check that.
- The dossier's decision summary mentions "seven years of integration leadership," but no verified entry carries that number. I left it out of the scripted answers. Only say a figure you can defend from your own record.

Two questions:
- Do you have the hiring manager's name? Their public background would sharpen the reverse questions.
- Is the posting still the one from August? If you paste the current JD, I'll check it against R1 to R5.

Offers, not pushed:
- I can run a live drill. Name a persona or question ID, and I'll play the Skeptic on A1 by default.
- I can save a `tuesday-dossier.md` with what the prep exposed, to carry into later sessions.
- I can convert the pack to a Word document.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quartzline_platform-apis_interview_pack.md -----
# Interview prep pack: Product Manager, Platform APIs, Quartzline

Interviewer: hiring manager (name not given). Relationship: your future manager. Round: 45-minute conversation.
Built from: `tuesday-dossier.md` (job-underwriter, dossier_version 1.1, generated 2026-08-14), with no CV and no JD text. The dossier is about three months old, so confirm the posting is unchanged (upgrade menu).

## How to use this pack

Personas describe how a question arrives. Types describe what is being scored. Guidance is scaffolding, not a script. Say things in your own words, and rehearse only what you actually did.

Type key:
- **VAL**: behavioral and values alignment (not used here; no values round detected)
- **EXP**: a deep-dive on something in your record
- **JD**: a stated requirement or responsibility
- **CO**: company and strategy knowledge (not used here; no research ran)
- **CASE**: a live problem from the role

Evidence labels: `[grounded]` traces to the dossier, a supplied JD line or a quote from you. `[inferred]` is a derivation this pack made. `[generic]` is a role pattern with no claim about you or Quartzline.

## The fit snapshot

Requirements are quoted from the dossier's role_profile (the supplied JD lines). Evidence is quoted from the dossier's verified_candidate_evidence and handoff.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Shipped API or platform products" (dossier role_profile R2) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier verified evidence) | high | [grounded] | presentation | Your material reaches API work from the integration side: you led integrations against the vendor's APIs. Nothing shows a platform you shipped. Words: "I led 30+ end-to-end client integrations of the vendor's REST APIs." Answer slot: if you shipped something others consume, say what and whose; if not, say you worked against the vendor's APIs and say which part you led. Expect this probe. |
| F2 | "Technical fluency: API docs, schemas" (dossier role_profile R3) | "Wrote the internal integration playbook her team uses" (dossier verified evidence) | high | [grounded] | discovery | The playbook reaches API documentation. Schemas are not in the material. Words: "I wrote the internal integration playbook my team uses." Answer slot: if you have worked with API schemas, say which and what you did with them; if not, say so plainly and say how you would learn them. |
| F3 | "Stakeholder management across engineering, sales, customers" (dossier role_profile R4) | "Ran quarterly roadmap-input sessions feeding client evidence to product" (dossier verified evidence) and the F1 quote | medium | [grounded] | presentation | Customers and product appear in your material. Engineering and sales do not appear by name. Words: "I ran quarterly roadmap-input sessions that fed client evidence to product." Medium caveat: confirmed, with limited inspectable proof, so expect a probe. Answer slot: if you worked with engineering or sales on one specific integration, name it; if not, say the work was with customers and product. |
| F4 | "3+ years product management experience" (dossier role_profile R1) | "Ran quarterly roadmap-input sessions feeding client evidence to product" (dossier verified evidence) | low | [inferred] | transferability | The dossier's bridge: adjacent work, with the limit named. Words: "I haven't held a product manager title. What I've done is run quarterly sessions that fed client evidence into product." Do not bring up a number of years. The dossier's decision summary mentions one, but no verified entry carries it. |
| F5 | "Own the roadmap for the partner-facing API platform" and prioritization authority (dossier role_profile R1 sub-claim) | none given | none | [grounded] (dossier acknowledge_gap) | capability | The dossier records this as a stated gap. Words: "I haven't owned a product roadmap or set prioritization for an engineering squad." Then a ramp, said as a plan and never as a past. No answer slot. |
| F6 | "Agile delivery experience" (dossier role_profile R5) | none given | low | [grounded] (dossier unknowns and clarify area) | discovery | Evidence may exist and the material does not show it. Answer slot in A2. |

## Persona table

| Persona | Weight | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|---|
| Skeptic | top (5 questions) | Presses on the missing PM title and roadmap ownership | Hiring managers are buying capability and checking gaps. The dossier names the objection. | Hold, then concede. Bridge with the limit named. |
| Case / Strategist | top (5 questions) | Live problems from the partner API roadmap | Hiring-manager prior. Expect a problem from their actual backlog. | Clarify, then structure. Make no claim about your past. |
| Data-Driven Prober | mid (3 questions) | The 30+ figure and adoption metrics, taken to their assumptions | The headline figure is a magnet for probing, and no adoption baseline is stated. | Defend-the-number slots: how it was counted, the weakest assumption, what was yours. |
| Pressure | mid (3 questions) | Interrupts on the title gap, time-boxes | The missing title raises the stakes in a manager round. | Pause, restate, hold two follow-ups. |
| Conversational | low (2 questions) | "Walk me through the journey" | Low weight in a manager round, but casual questions on JD topics are still scored. | A 90-second arc. |

No Peer Evaluator bank: the round is with your future manager, not a peer. No interviewer profile was given, so there is no interviewer read.

## Question banks

Provenance comes before guidance in each row. Quotes are the dossier's or the supplied JD's words.

### Skeptic (A)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've never held the PM title or owned a roadmap. Why should we hire you into one instead of a PM with three years of the actual job?" | JD, EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier verified evidence). [grounded] the dossier's acknowledge_gap and prohibited_claims fields: "Having held a product manager title or role"; "Having owned a product roadmap" | The highest-ROI rehearsal in this pack. Start with the plain acknowledgment: "I haven't held the PM title or owned a roadmap." Then: "What I've done is lead 30+ end-to-end client integrations of the vendor's REST APIs, through scoping, requirements, architecture, UAT and go-live." Hold through two follow-ups by returning to those integrations. Concede the roadmap and prioritization gap specifically, and offer a ramp as a plan: which roadmap calls you would validate with the two squad leads first. Do not argue the title away. | The dossier named this as the likeliest objection, so the pack uses its wording. Its negatives carry the dossier's own source, so the premise may stay. The defence is the record you actually have. |
| A2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Agile delivery experience" (supplied JD R5). [grounded] the F5 acknowledgment | Name the roadmap and prioritization gap first, as in A1. Then the answer slot: if you have run agile delivery in a product org, say how, in your own words; if you have not worked that way, say so plainly and say what you would want to confirm about how these squads plan. | R5 is discovery-grade (low confidence). The clarify strategy allows a question-shaped answer, and the second branch lets the answer be "not my way of working." |
| A3 | "Two squad leads already run a lot of this. What would you decide on your own, and what would you take to them?" | JD, CASE | [grounded] "Write specs and drive delivery with two engineering squads" (supplied JD responsibility). The guidance makes no claim about your past. | Split decisions by type: scope of the partner-facing contract, sequencing, deprecation, roadmap trade-offs. For each, say who owns it and what you would bring to the squad leads. Then ask which of these the role owns. | Decision authority is the dossier's open unknown, and this tests it live. The structure is `[generic]`. |
| A4 | "Tell me about a time an integration partner wanted something you didn't think should be built." | JD, EXP | [grounded] "Stakeholder management across engineering, sales, customers" (supplied JD R4). [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Selection scaffold: pick an integration where scope or go-live was contested. Name who wanted what, what you decided, and what it cost. If you did not make the call, say whose it was. The quote carries scoping and requirements, so those are your beats. If no such time comes to mind, say so plainly, then give the nearest thing your material carries: the quarterly roadmap-input sessions, where expect a probe on what they changed. | R4 is an important requirement. The quarterly sessions are the thinnest proof here. |
| A5 | "You integrated the vendor's APIs. Have you shipped an API product that your own customers consume?" | JD, EXP | [grounded] "Shipped API or platform products" (supplied JD R2). [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Answer slot: if you shipped something others consume, say what and whose, in your own words. If you did not, say plainly that your work was building client integrations against the vendor's APIs, and describe the part you led. Keep the verb as "led." | R2 is a must-have, and the integration quote reaches it only in other terms. This is where the platform-side distinction is probed. |

### Case / Strategist (B)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A partner's integration breaks a week after go-live. Walk me through how you'd triage it and what you'd tell the partner." | CASE, JD | [generic] a post-go-live break. [grounded] "Technical fluency: API docs, schemas" (supplied JD R3) | Structure: first the blast radius (which partners, which endpoints, since when). Then reproduce against the documented schema, and separate a documentation gap from a behaviour change. Decide rollback or hotfix, then write the partner update. Refer to go-live work only in the scope the F1 quote states. | Tests R3 live. The case makes no claim about your past. |
| B2 | "Partner API adoption is flat this quarter. What would you look at first, and what would you need before proposing a change?" | CASE, JD | [grounded] "Define and track adoption metrics" (supplied JD responsibility). [generic] adoption-diagnosis pattern | Clarify the denominator: which partners, which endpoints, and which activation step. Ask for the current baseline before proposing any change, since none is stated. | Adoption metrics are a stated responsibility, and the baseline is the dossier's open unknown. |
| B3 | "A partner wants a capability we don't offer. How would you run discovery on it?" | CASE, JD | [grounded] "Run discovery with integration partners" (supplied JD responsibility). [generic] discovery pattern | Separate the requested feature from the job behind it. Size how many partners share the need. Decide on evidence, not the loudest partner. Name the quarterly roadmap-input sessions only as what they were: client evidence fed to product. Do not claim discovery experience beyond that. | Tests the discovery responsibility. The quote is the only past claim, and it is kept to its own scope. |
| B4 | "Our two squads disagree on whether a breaking change to a v1 endpoint ships this quarter. How do you decide?" | CASE, JD | [grounded] "Write specs and drive delivery with two engineering squads" (supplied JD responsibility). [generic] decision-under-disagreement pattern | Structure: who breaks, and how badly. Whether a deprecation path exists. What rule settles it. When to escalate to the squad leads. Say which part you would decide yourself and which you would take to them. No past claim. | Tests decision authority, the dossier's open unknown, live. |
| B5 | "Pick one metric for the partner API dashboard and defend it." | CASE, JD | [grounded] "Define and track adoption metrics" (supplied JD responsibility). [generic] metric-defence pattern | Name the metric, its denominator, and its weakest assumption before the interviewer does. If you cannot yet say how it would be counted, say so. | Metric defence in the case register, on the JD's adoption responsibility. |

### Data-Driven Prober (C)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You led 30+ integrations. How did you count them, and which of them would you not count?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier verified evidence) | Defend-the-number, in your own words. Answer slot: if there is a record you counted from, name it; if you don't know how the count was kept, say so plainly. Then name, in your own words, the assumption behind the count you would defend least, and which of those integrations you led versus supported. The pack supplies no counting method. | The headline figure is the magnet for probers, and the dossier records no counting method. |
| C2 | "Your playbook: who uses it, and how do you know?" | EXP | [grounded] "Wrote the internal integration playbook her team uses" (dossier verified evidence) | Say what the playbook covers and that your team uses it, in the quote's words. Answer slot: if you can point to use, such as a revision or a team that onboarded from it, name that. If no use is tracked, say so. | "Uses" is the quote's claim. How anyone knows is the probe. |
| C3 | "How would you know partner API adoption is going up? What's the baseline today?" | JD, EXP | [grounded] "Define and track adoption metrics" (supplied JD responsibility). [grounded] the dossier's unknown: "How adoption is measured today" | Say which measure, and its denominator, and that you don't yet know the baseline. Answer slot: if you measured adoption on an integration you led, say what. If you did not, say so plainly and name what you would measure first. | Adoption measurement is the dossier's open unknown. |

### Pressure (D)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over a PM who has the title?" | JD, EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier verified evidence). [grounded] the dossier's prohibited_claims field: "Having held a product manager title or role" | Pause, restate the question once. Hold: in the first 20 seconds, name the integration work in the quote's terms. Concede: the title. On the second follow-up, concede the roadmap, not the integration depth. Never fold on the integration record. | The Pressure persona scores composure. Hold, then concede specifically. |
| D2 | "That 30-plus figure: how much of it was actually you?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Hold the verb "led" as the quote states it. Then split honestly: which of scoping, requirements, architecture, UAT and go-live you led, and which the client's team carried. Answer slot: if you don't know the split, say so plainly. Do not claim all five by default. | Attribution honesty. The quote lists five beats, and the split is the candidate's to supply. |
| D3 | "You'd be hired into roadmap authority you don't have yet. Why won't that hurt the squads?" | JD | [grounded] the dossier's acknowledge_gap and prohibited_claims fields: "Having owned a product roadmap"; "Having set prioritization for an engineering squad." [grounded] "Write specs and drive delivery with two engineering squads" (supplied JD responsibility) | Concede the gap plainly: "I haven't owned a product roadmap or set prioritization for an engineering squad." Then hold the ramp as a plan: which decisions you would validate with the squad leads, and in what order. Do not argue the gap is small. | The dossier acknowledges this gap, so there is no bridge here. |

### Conversational (E)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey. How did you end up leading integrations?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live". [grounded] "Wrote the internal integration playbook her team uses" | A 90-second arc: the integration work, what you wrote for your team, then the roadmap-input sessions. Give no number of years unless you can confirm it from your own record. | Casual openers are still scored. The years figure is not a verified entry. |
| E2 | "What are you playing with in API schemas these days?" | JD | [grounded] "Technical fluency: API docs, schemas" (supplied JD R3). [generic] schema-tooling pattern | Answer slot: if you work with schemas now, name what you use and what you do with them. If not, name what you have worked with and say so plainly. | A casual register on a scored JD topic. |

## Coverage: requirement to question

| Requirement or responsibility | Question IDs |
|---|---|
| R1: 3+ years PM experience (bridge and acknowledgment; no claim of PM years) | A1, D1, D3 |
| R1 sub-claim: roadmap and prioritization authority | A1, A3, B4, D3 |
| R2: shipped API or platform products | A5, C1 |
| R3: technical fluency, API docs and schemas | B1, C2, E2 |
| R4: stakeholder management | A4, B3, B4 |
| R5: agile delivery | A2 |
| Responsibility: adoption metrics | B2, B5, C3 |
| Responsibility: partner discovery | B3 |
| Responsibility: specs and delivery with two squads | A3, B4 |
| Responsibility: roadmap for the partner API platform | A1, A3 |

Session total: 18 questions (A1 to A5, B1 to B5, C1 to C3, D1 to D3, E1 to E2).

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R-1 | "Which roadmap decisions does this PM make alone, and which belong to the two squad leads?" | This is the dossier's decision-authority unknown. Asking it reads as diligence and answers what you need before accepting. |
| R-2 | "How is partner API adoption measured today, and what is the current baseline?" | The dossier's employer question. The baseline is unstated, and the answer tells you whether the metric exists. |
| R-3 | "When a partner asks for something the squads won't build, who says no, and how?" | Tests where escalation sits. A manager's answer shows the real authority map. |
| R-4 | "What would a good first 90 days look like for this role?" | Sets the bar with the person who will judge it. |
| R-5 | "What did the last person in this seat leave in good shape, and what did they leave unfinished?" | Asks for the working history without assuming a predecessor's record. |

## Prohibited claims

Each entry shows its basis and its honest form. The dossier's entries are binding; the local entries were built from the fit snapshot.

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | Dossier prohibited_claims (sourced) | "I haven't held a product manager title." No answer slot. |
| Having owned a product roadmap | Dossier prohibited_claims and acknowledge_gap (sourced) | "I haven't owned a product roadmap." No answer slot. |
| Having set prioritization for an engineering squad | Dossier prohibited_claims (sourced) | "I haven't set prioritization for an engineering squad." No answer slot. |
| Owned the partner API roadmap | Inflated form of "Ran quarterly roadmap-input sessions feeding client evidence to product" (local) | The quote at its own scope: you ran sessions that fed client evidence to product. The limit is this pack's observation: your material does not show you set the roadmap. |
| Shipped the partner API platform | Inflated form of "Led 30+ end-to-end client integrations of the vendor's REST APIs" (local) | The quote at its own scope: integrations you led against the vendor's APIs. A2's and A5's slots stay inside that scope. |
| A number of years in product or integration leadership | Figure from the dossier's decision summary, not a verified entry (local) | Give a number only if you can defend it from your own record. None is coached here. |

Not listed: tracking partner API adoption. The material is silent on it, so C3 and B2 carry it as an answer slot.

## Sources

- Provided documents: `tuesday-dossier.md` (job-underwriter, dossier_version 1.1, generated 2026-08-14). Consumed sections: `handoff_to_mock_interview` and `role_profile`. The full `evidence_map` and `evidence_state` were not in the pasted text, so they were not consumed.
- Searches sent, both refused by the host's permission setting:
  - "Quartzline platform APIs product manager": refused
  - "Quartzline company values": refused

Research tier: L1, searches 0 of 6, fetches 0 of 2 (search permission refused).

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quartzline values | unavailable | Would have checked for a values-style round. None is detected without a loop source, so no values section. |
| 2. Quartzline interview process, product role | unavailable | Would have confirmed loop structure and tuned persona weights. The weights here rest on the hiring-manager prior. |
| 3. Quartzline strategy and recent news | unavailable | Would have grounded CO questions. None written. |
| 4. Interviewer name | n/a | No name given. |
| 5. Representative JD | skipped | The dossier's role_profile fixes the requirements. |

Sections omitted because they do not apply: prep triage (no prep time stated), grounding brief (no research), reading the interviewer (no profile), graded deliverables (none declared), values cheat sheet (no values round detected), delivery coaching (no assessment provided).

## Upgrade menu

- Current JD text: confirms R1 to R5 and the responsibilities still match the August posting. The dossier is about three months old.
- The hiring manager's name: persona weights from their public footprint, and a reverse question tied to their career path.
- Your CV or resume: lets the 30+ figure and the years figure be checked against your record, and upgrades the verified rows to inspectable.
- The recruiter's note on focus areas: coverage of anything they flagged.
- Deep research (L2): the strategy brief, loop reports and recent org news, up to six more searches and two fetches. Needs search permission in this session.
