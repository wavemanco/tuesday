Your prep pack is saved at /tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-tuesday-part-2-rooms-case-7-denied-bc1fff30/9909d37a-8da8-4678-a963-91d9dca8a6c7/scratchpad/saltmarsh_live_operations_producer_interview_pack.md. I built it for a hiring-manager round, since your note didn't say who you're meeting.

The web searches for Saltmarsh's values, interview process and strategy, and for Tobias Wrenfield's public work, were all refused by a permission check. So the pack has no company values, no confirmed loop structure and no strategy questions. It is built from the JD and your background only.

Top priorities for Friday:
- **B1 is the highest-ROI prep.** The JD asks about two titles and live events, and your material shows one title and content drops. Rehearse the honest version of that scope.
- **Presented versus owned.** You presented retention numbers. The JD asks you to own the post-event review and its KPIs. Be exact about which is which (A4, B5, D2).
- **Don't stretch the negatives.** You haven't led a team or worked on an IAP game. Say those plainly; don't soften or argue them away (B3, B4).

Say the word and I'll play the Skeptic on B1, the question the pack names as its highest-ROI prep. I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

1. Is Tobias your hiring manager, and has the recruiter announced any exercise, take-home or presentation?
2. May I retry web search? Approving lets me run up to six searches for Saltmarsh's values, loop structure and strategy, and Tobias's public footprint.
3. Is the role on-site or remote, and do you have the right to work where it's based? The JD you pasted doesn't say, so that row stays open.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh_live_operations_producer_interview_pack.md -----
# Interview pack: Live Operations Producer, Saltmarsh Games

**Interviewer:** Tobias Wrenfield, Head of Live Operations. Relationship assumed to be hiring manager; no profile was researched (see Sources).
**Round:** one 60-minute session, format not specified.
**Built on:** the JD you pasted, your background in your message, and no research (every search was refused).

## How to use + type key

Personas describe how a question is asked. Types describe what is being scored.

- **EXP**: work-experience deep-dive. Tests whether what you did survives scrutiny.
- **JD**: role-driven. Tests whether you can do the listed job, gaps included.
- **CO**: company and strategy knowledge. Not covered here; no research ran.
- **CASE**: live problem. Tests structure and reasoning.
- **VAL**: values alignment. Not covered here; no values round was detected.

Guidance is scaffolding, not a script. Say it in your own words.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F0 | Location, on-site and work authorization: not stated in the JD text you pasted | none given | none | [grounded] | hard_gate | Your material does not establish this. Confirm it with the recruiter before Friday; the pack cannot settle it |
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material says one title and content drops, not two titles and live events. Bridge: "For two years I ran the weekly content-drop calendar for our main title." Answer slot: the JD asks about two titles and live events. If you planned events, or for a second title, say so; if not, say so plainly and describe how the drop calendar worked |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | none given | none | [grounded] | discovery | Your material does not show cross-team coordination. Answer slot: name the teams you coordinated with on a drop, and how you did it. If you did not coordinate across them, say so and describe how a drop reached release |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | transferability | Presenting numbers is not owning the review or its KPIs. Bridge: "I presented the monthly retention numbers to the studio head." Answer slot: did you run a post-event review, and which KPIs did you set, not just report? If not, say so and describe the review you would run |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | none | Lead with the quote in its own terms: you wrote it, and the QA team still uses it. Expect a probe on what it covers and who changes it |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message | medium | [grounded] | transferability | The four years count, but the material does not say the puzzle title was live-service. Bridge: "4 years as an associate producer at a puzzle-game studio, with a weekly content-drop calendar on the main title." Do not call it live-service unless you would say so under follow-up |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | Covered in the quote's own terms. Expect a probe on cadence, what went on it, and who decided |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | none | Covered by presenting monthly retention to the studio head. Expect a probe on how the figures were counted; you gave no figure, so do not invent one |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | low | [inferred] | discovery | One written artefact is the only written evidence in your material. Answer slot: name a document you wrote that others depended on, and what it said |

Gap labels follow the evidence cell. F0 is a gate the material does not settle, so it is surfaced, not bridged. F2 and F8 are thin, so their wording is an answer slot.

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Owns the post-event review and its KPIs | Inflated form of F3 | F3's quote at its own scope. The material shows presenting retention numbers, not owning the review. A-slot stays inside that |
| Ran a live-events calendar for two titles | Inflated form of F1 | F1's quote at its own scope. The material shows one title and content drops |
| Owns the release checklist with QA | Inflated form of F4 | F4's quote: wrote it, and QA still uses it. Not "owns" the process |
| Has led a team | Negative you stated | "I haven't led a team." No slot |
| Has worked on a game with in-app purchases | Negative you stated | "I haven't worked on a game with in-app purchases." No slot |

## Persona table

| Persona | How it shows up | Weight | Reasoning | Counter-strategy |
|---|---|---|---|---|
| Case / Strategist | Live roadmap problems: plan a calendar, diagnose a drop in retention | 5 (top) | Hiring managers buy capability and test it on their own roadmap | Clarify, then objective, segments, approach, metrics, risks. Think aloud |
| Skeptic | Probes the gaps: one title, no team lead, no IAP | 5 (top) | Same as above: the JD's mid-list gaps are where the skeptic goes | Rehearse the single most predictable objection until it is boring. Concede only the stated negatives |
| Data-Driven Prober | Asks how the figures were counted and who decided | 3 | Retention is a JD requirement and your numbers are presentations | Say what you can and cannot say about how a figure was counted |
| Pressure / Stress | Time-boxes, challenges the strongest claim | 3 | Head-level role; composure is tested | Pause, restate, hold through two follow-ups |
| Conversational | Opens casually: "walk me through the journey" | 2 | Casual questions are still scored | 90-second arc from your quoted sentences |
| Peer Evaluator | Seam-splitting between teams | 0 (not weighted) | The round reads as hiring-manager, not peer | Not prepared; say so if the round turns peer |
| Values / Behavioral | Scenario probes tied to published values | 0 (not detected) | No loop source documents a values round, and the generic archetype does not assume one | Not prepared. Upgrade menu |

## Question banks

### Case / Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Sketch your first 30 days planning the live-events calendar for two titles. What do you need to know first?" | CASE | [generic] | Clarify first: which titles, what the events are for, what the current cadence is, who signs off. Then objective, segments, approach, metrics, risks. Make no claim about your past | Tests the JD's first line as a live problem. [generic]: a pattern for the problem, not a fact about the employer |
| A2 | "Week-one retention on one of your titles dropped 20% after a content update. Diagnose it." | CASE | [generic] | Clarify what changed, the baseline, and what else shipped. Then segment and form hypotheses before proposing a fix. Name the metric you would trust most | Top-weight live problem on retention (JD: retention metrics). Needs no claim about your past |
| A3 | "How would you coordinate design, art, engineering and community on one update with one release date?" | JD | [grounded] "coordinate design, art, engineering and community teams on each update" (JD) | Structure the seams: who owns the decision, what each team needs by when, and where the release checklist sits. If you have a real example from a drop, use it; if not, say so and give the approach. Answer slot per F2: name the teams you coordinated with, and how; if you did not coordinate across them, say so and describe how a drop reached release | F2 is discovery: the material does not show cross-team work, so the answer is an honest branch, not a story |
| A4 | "Walk me through how you would run the post-event review, and which KPIs you would report." | JD | [grounded] "own the post-event review and the KPIs it reports" (JD); [grounded] "Presented the monthly retention numbers to the studio head." (your message) | Story-map on F3: the retention numbers you presented, in those words. Answer slot: did you run a post-event review, and which KPIs did you set rather than report? If not, say so and describe the review you would run. Never describe a review you did not run as yours | JD's "own" line. The honest answer is the presented-vs-owned distinction, rehearsed |
| A5 | "Which items on a release checklist would you never let slip, and why?" | JD | [grounded] "Wrote the release checklist our QA team still uses." (your message) | Name the two or three items that caught real problems, in your words. Say what the checklist covers and who changes it. If you cannot say which items mattered, say so and describe how you would find out | Tests the release-checklist requirement against your one written artefact |

### Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You have run one title's content-drop calendar. Why are you ready to plan two live-events calendars at once?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | **Highest-ROI prep in this pack.** Hold: "I ran the weekly content-drop calendar for our main title for two years." Hold through two follow-ups by returning to the calendar, not by adding scope. Answer slot: say what the two-title scope would change, what you have run and what you have not, in your own words. Never claim two-title planning | F1 is the scope gap and the likeliest objection. The question's premise is one title, which your quote carries |
| B2 | "Your background is a puzzle-game studio. What would you need to learn about live-service that you don't already know?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio." (your message) | Answer as a learning plan: name the two or three things you would need to learn, and how you would learn them. Do not call the puzzle title live-service unless you would say so under follow-up | F5 is the 3+ years requirement. The premise is the puzzle studio, which your quote carries. "Live-service" is the JD's word |
| B3 | "You have never led a team. Why should we trust you to coordinate four teams without authority?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." (your message) | Plain acknowledgment: "I haven't led a team." Then the coordination case: how you move work across teams without managing them. Answer slot per F2: the teams you actually worked with, and how | The JD asks for coordination, not leadership. Never claim team leadership |
| B4 | "You haven't worked on a game with in-app purchases. How would you think about monetization in our KPIs?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." (your message) | Plain acknowledgment: "I haven't worked on a game with in-app purchases." Then say how you would learn it: what you would read, who you would ask, what you would measure first. Frame it as a plan, never as a past | Monetization is a live-ops KPI most studios with IAP care about. Stay honest about the gap |
| B5 | "You presented the retention numbers. Did you own them, or did you present someone else's?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." (your message) | Presented, not owned, unless it was yours. Answer slot: if you set how the figure was counted or what it was used for, say so; if you did not, say that plainly and say what you did do | F3's review-ownership gap. Honest branch both ways |

### Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the retention numbers you presented were counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head." (your message) | Answer slot: bring one figure, then say how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. If you did not know how it was counted, say so plainly. Do not invent a method | F7 is covered only by presentation, so the probe reaches the counting. You gave no figure, so the slot is written for whichever figure you bring |
| C2 | "Walk me through the calendar you ran. What went in each week, and who decided?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | Story-map on F6: the calendar, the two years, the weekly cadence. Answer slot: who decided what went in each week. If you decided, say so; if others did, say who and what your part was | F6 is the content-calendar requirement. "Who decided" is the attribution probe |
| C3 | "Which items on your release checklist would you defend as the ones that actually mattered?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." (your message) | Answer in your own words: the items you would defend. If you cannot say which mattered, say so and give the nearest thing you know | Probes whether F4's checklist is backed by what it caught |

### Pressure / Stress (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over someone who has run a live-service title for five years?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio." (your message); [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | Pause, then restate. Hold: what you ran, for how long, and what you would do with the first month. Concede specifically and only from stated negatives: "I haven't worked on a game with in-app purchases." Never claim a live-service title | Composure test. Concession wording is the stated negative, not a new one |
| D2 | "That retention result: how much of it was actually you?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." (your message) | Hold: presented the numbers, to the studio head. Two follow-ups: say what you presented and what you did with it. Concede only where it is true | The hold is the presented/owned distinction, not a bigger role |
| D3 | "Your checklist belongs to QA. Why would they trust a producer to change it?" | JD | [grounded] "Wrote the release checklist our QA team still uses." (your message) | Hold: you wrote it and the team still uses it. Describe how changes were agreed, if they were; if not, say so | Tests the manage-with-QA requirement under pressure |

### Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through your journey." | JD | [grounded] the four sentences of your background message | 90-second arc: four years at the puzzle studio; two years on the content-drop calendar; the release checklist; the monthly retention presentation; then why this role | Opening casual question that is scored. Built only from your quoted sentences |
| E2 | "What do you play right now that's live-service?" | JD | [generic] | Answer honestly: name a game you actually play and what its live-ops cadence looks like to you. If you do not play live-service, say so and name what you do play | Casual version of the JD's live-service requirement. Makes no claim about your past |

## Requirement coverage

| JD requirement | Questions | Status |
|---|---|---|
| Plan and run the live-events calendar for two titles | A1, B1 | covered |
| Coordinate design, art, engineering and community teams | A3 | covered |
| Own the post-event review and its KPIs | A4, B5 | covered |
| Manage the release checklist with QA | A5, D3, C3 | covered |
| 3+ years producing live-service games or apps | B2, D1 | covered |
| Experience running a content calendar | C2 | covered |
| Comfortable with player-retention metrics | A2, C1 | covered |
| Clear written communication | none, and why: the interview is spoken, and the only written evidence in your material is the checklist (F8). A written exercise, if announced, needs its own section | — none, and why |

## Reverse questions

1. **"What does a good post-event review look like here, and who writes it?"** Why it lands: it tests the JD's "own" line from the other side and shows you read it.
2. **"Which two titles are in scope, and how far apart are their calendars?"** Why it lands: it turns B1 into a planning conversation.
3. **"Who has the final say when a live event is cut or delayed?"** Why it lands: it finds the decision seam between live ops, design and engineering.
4. **"Is the release checklist yours to change, or QA's?"** Why it lands: it shows you understand the QA boundary before you are asked about it.
5. **"What did the last update that missed its KPIs teach the team?"** Why it lands: it asks for the team's own review, which is the JD's central job.

## Sources

**Provided documents:** the JD text in your message; your background in your message.

**Research tier:** L1, searches 4 of 6, fetches 0 of 2. Four searches were sent and each was refused by the host's permission check. None returned a result, so none moved the pack.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | unavailable | Values cheat sheet. Refused: "Saltmarsh Games values" |
| 2. `Saltmarsh Games interview process Live Operations Producer` | unavailable | Loop structure and persona weights. Refused: "Saltmarsh Games interview process Live Operations Producer" |
| 3. `Saltmarsh Games mobile studio news strategy` | unavailable | Current strategy, CO bank. Refused: "Saltmarsh Games mobile studio news strategy" |
| 4. `Tobias Wrenfield Head of Live Operations Saltmarsh Games` | unavailable | Interviewer read, persona weights, reverse questions. Refused: "Tobias Wrenfield Head of Live Operations Saltmarsh Games" |
| 5. representative JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

Because no company values, loop structure or strategy was established, the values cheat sheet is absent, the loop is the generic archetype, and the CO bank is absent. The persona weights are a generic pattern, not this company's process.

## Upgrade menu

- Permission to use web search, so the company values, loop structure, strategy and Tobias Wrenfield's public footprint can be checked → a values cheat sheet if the round is values-style, CO questions on current strategy, and a tailored reverse question and persona weights from his public record
- The round's format and any pre-declared exercise, from the recruiter's email → coverage of any take-home or presentation
- The JD's full text (if you pasted only part of it) → any missing requirement becomes a question
- A `tuesday-dossier.md` from the underwriter, if you have one → the strongest version of the rows that need a verified claim
