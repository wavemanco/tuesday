I couldn't run web research: both WebSearch calls were refused for lack of permission. So the pack below is built from your message and the recruiter's wording only. Company values, the loop, and strategy are not established. I'm writing the pack to a file now.
Your combined prep pack is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-tuesday-part-2-rooms-case-6-denied-30b0dbb6/e7869c3a-7882-4cdc-a9aa-c5fcc469f420/scratchpad/larkfield_engineering_manager_interview_pack.md`. It covers all three rounds with one shared fit snapshot, a separate question bank for each round, and reverse questions for each.

**Research didn't run.** Both web searches were refused for lack of permission, so I couldn't check Larkfield's values, its interview loop, or its strategy. The pack is built from your message and the recruiter's wording only, and it says so. Grant search permission and I can rerun that research.

**What the pack says about your gaps:**
- **Manager-of-managers (the VP round).** This is your most likely objection. The pack treats it as the highest-value prep: a plain acknowledgment ("I haven't managed managers") and then a hold on what you did do. I can't tell from your inputs whether the two squads have their own leads, and that decides how hard this gap is.
- **Hardware roadmap (the hiring manager and panel).** Stated as an absence: "I haven't owned a hardware-adjacent roadmap." The pack gives you a plan for learning it, not a claim you don't have.
- **Span (hiring manager).** You've led six, not eleven across two squads. The pack has you name what carries over and concede the rest.
- **Strongest row.** The hiring loop: 40 interviews. Expect the panel and hiring manager to ask how it was counted and which decisions were yours.

**Rounds, with persona weights:**
- **Tuesday, hiring manager (45 min):** mostly case questions on live roadmap problems, plus skeptic probes on the gaps.
- **Thursday, panel (60 min):** staff engineers probe your numbers and the on-call story; the product manager runs roadmap trade-offs.
- **Monday, VP (30 min):** values and leadership questions, themed on the recruiter's words "values and leadership philosophy." I left out a values cheat sheet because there's no published values page to map to.

**To tighten the pack:**
- Paste the full job description and your CV. Right now the requirements come from your summary, and the evidence comes from your message.
- Tell me what the recruiter said about what the panel will test, and whether there's a take-home or presentation.
- Tell me any hard terms the posting states: location or on-site days, work authorization, pay floor. The pack doesn't assume any of them.

Say the word and I'll run a drill on the manager-of-managers question, the highest-ROI prep in the pack. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, and convert the pack to Word if you'd like.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: larkfield_engineering_manager_interview_pack.md -----
# Engineering Manager, Larkfield Systems: interview prep pack (three rounds)

Hiring manager (Director of Engineering), 45 min, Tuesday. Panel (two staff engineers and a product manager), 60 min, Thursday of the following week. VP Engineering, 30 min, the Monday after.

First version, loop mode. Built from your message only; no web research was available in this session.

**Research status:** Both search calls were refused, so nothing about Larkfield's values, interview loop or strategy is established. Persona weights rest on round type, not on a documented process. Nothing in this pack is labelled as company fact.

## How to use + type key

- Personas describe how a question arrives. Types describe what is being scored.
- VAL: behavioral and values alignment. EXP: work-experience deep-dive. JD: role requirement. CO: company knowledge. CASE: live problem.
- Guidance is scaffolding, not a script. Rehearse only what you did, in your own words.

## Fit snapshot

Requirements come from your message, which is the only role description in hand. Evidence quotes are your message's sentences.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" — your message | "9 years engineering, 3 as a team lead of 6" — your message | medium | [grounded] | transferability | You have led one team of six. Two squads is a wider span, and your material does not show a second squad. Say the team of six in those words. Answer slot: if you have coordinated work across two groups, say how; if not, say so and say how you would find out what two squads need. |
| F2 | "own delivery, hiring and growth for 11 engineers" — your message | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" — your message | medium | [grounded] | presentation | The quote is a delivery story: a quarter pushed through. Lead with that, in your words. Eleven engineers is not in your material. |
| F3 | "own delivery, hiring and growth for 11 engineers" — your message | "I run our hiring loop for backend roles — about 40 interviews last year" — your message | medium | [grounded] | none | Your quote reaches the hiring part in role-relevant terms: you run a loop, about 40 interviews. Expect a probe on what you decided versus what the loop decided. |
| F4 | "own delivery, hiring and growth for 11 engineers" — your message | none given | none | [grounded] | discovery | Growth of engineers does not appear in your material. Answer slot: if you grew an engineer, say how and what you did; if you have not, say so and say how you would start. |
| F5 | "partner with hardware and product on roadmap" — your message | "I've never managed managers and never owned a hardware-adjacent roadmap" — your message | none | [grounded] | capability | You have stated the absence. Words: "I haven't owned a hardware-adjacent roadmap." Then how you would learn it, said as a plan, never as past work. |
| F6 | "partner with hardware and product on roadmap" — your message | "pushed a reliability quarter through against roadmap pressure" — your message | medium | [grounded] | transferability | Product roadmap pressure is adjacent work. Hardware is not in it. Say the product pressure in those words. |
| F7 | Manager-of-managers scope, not stated in the role summary | "I've never managed managers" — your message | none | [grounded] | capability | You have stated the absence. Words: "I haven't managed managers." Whether this role needs it depends on whether the two squads have their own leads, which your inputs do not say. |
| F8 | Terms such as location, on-site days, work authorization, pay | none given | none | [inferred] | hard_gate | Your material does not establish these. The pack does not assume them. The one question about them is in the closing messages below. |

Reading: F1, F4, F5 and F7 are the rows the panel and VP will test. F3 is your strongest verifiable row, and a probe on it is likely.

## Prohibited list

| Not coached | Basis | Honest form |
|---|---|---|
| Led two squads | Inflated form of F1 | "I led a team of six for three years." The pack's own observation: your material says one team of six. |
| Managed managers | Negative you stated, F7 | "I haven't managed managers." No slot. |
| Owned a hardware roadmap | Negative you stated, F5 | "I haven't owned a hardware-adjacent roadmap." No slot. |
| Ran hiring for the org | Inflated form of F3 | "I run our hiring loop for backend roles." |
| The 60% was mine alone | Inflated form of F2 | "After I pushed a reliability quarter through." The credit for the team's work is said as "pushed", not "did". |

## Persona weights

| Round | Persona | Weight | Why | Depth |
|---|---|---|---|---|
| 1 Hiring manager | Case/Strategist | high | Relationship prior for a hiring manager; they are buying capability on a live roadmap | 4 |
| 1 Hiring manager | Skeptic | high | F4, F5 and F7 are the visible gaps | 3 |
| 1 Hiring manager | Data-Driven Prober | low | Nothing in your profile signals one, but 40 interviews and 60% invite denominators | 2 |
| 2 Panel | Data-Driven Prober | high | Staff engineers test numbers and assumptions | 3 |
| 2 Panel | Peer Evaluator | high | Product and staff engineers price what you cost their work | 3 |
| 2 Panel | Pressure | medium | Staff engineers test composure on the on-call story | 2 |
| 2 Panel | Case/Strategist | medium | Product manager runs live roadmap problems | 2 |
| 3 VP | Values/Behavioral | high | The recruiter's own words: "values and leadership philosophy" | 3 |
| 3 VP | Case/Strategist | medium | Skip-level altitude | 3 |
| 3 VP | Pressure | medium | Time-boxed, with the manager-of-managers objection | 2 |

Interviewer signals: none, since no names were given. The weights above come from round type alone. Loop: the three rounds come from your message, which establishes each session and who runs it.

## Round 1: Hiring manager (Director of Engineering), 45 min

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Your first ninety days: two squads, eleven engineers, a device-management roadmap you did not set. What do you need to know first?" | CASE | [generic] | Clarify before planning: what the roadmap commits to, who owns the hardware dates, what the squads are blocked on. Then a short plan, said as a plan. | Live problem from the role's scope. Presumes nothing about your past. |
| H2 | "Device reconnect failures rise after a firmware release. Diagnose it with me." | CASE | [generic] | Clarify, state two or three hypotheses, name who you would bring in from hardware and product. Do not claim hardware experience. | Tests the hardware-partnership gap (F5) as a live problem, not a record. |
| H3 | "Product wants a second device protocol next quarter and your squads are at capacity. What do you do?" | CASE | [generic] | State a decision rule before answering. Say what you would escalate and to whom. | Roadmap pressure is your best story area (F6). The guidance makes no claim about it. |
| H4 | "What does owning delivery look like when a hardware release date moves?" | CASE | [grounded] "own delivery, hiring and growth for 11 engineers" — your message | The honest evidence is "pushed a reliability quarter through against roadmap pressure" (F2). Answer slot: if a date moved under you, say what you did; if the dates were set by someone else, say so. | Tests the delivery requirement. Presumes no date moved on your watch. |
| H5 | "I don't see hardware in your background. How would you handle the hardware side of this role?" | Skeptic | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap" — your message | Plain acknowledgment: "I haven't owned a hardware-adjacent roadmap." Then the plan, in your words. Hold the plan to what you would do first. | F5 is the most predictable objection. The acknowledgment is the one you stated. |
| H6 | "You've run a team of six. Two squads and eleven engineers is almost double the span. Why is this your next step rather than a stretch?" | Skeptic | [grounded] "3 as a team lead of 6" — your message | Hold: name what carried from six, and say what you have not done at eleven. Answer slot: if you have run work across two groups, say how; if not, say so. | F1 is the span gap. Hold through two follow-ups, then concede the wider span plainly. |
| H7 | "Walk me through how the 40 interviews were counted. Which of those decisions was yours?" | Data-Driven Prober | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" — your message | Defend the number: how it was counted, what it is sensitive to, the assumption you would defend least. Answer slot: if you set the loop's stages, say so; if not, say so and say what you ran. | F3 is the strongest verifiable row, so a probe on it is likely. |
| H8 | "How was the 60% on-call drop measured?" | Data-Driven Prober | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" — your message | Name the weakest assumption before they do. Answer slot: if you measured a baseline, say what it was; if not, say so. | F2's number, rehearsed for its denominator. |
| H9 | "Tell me about a time you grew an engineer." | Skeptic | [grounded] "own delivery, hiring and growth for 11 engineers" — your message | Open prompt. Your material carries no story. Answer slot: if you grew someone, say what you did and what they did; if no such time comes to mind, say so plainly and describe how you would start. | F4 is discovery, not capability: silence, not a stated absence. |

**Reverse questions (round 1):**
- "What would the first six months look like for someone who succeeds here?" Why it lands: it shows you have thought past the job description.
- "Which hardware decisions will the squads have to live with next year?" Why it lands: it tests the gap in your own terms.
- "How do you decide between roadmap and reliability work when they collide?" Why it lands: it leads into your strongest story.
- "What did the last person in this seat do well, and what did they struggle with?" Why it lands: it is a peer conversation, not an interrogation.
- "What would make you say a year from now that you hired the right manager?" Why it lands: it asks for their success criteria.

## Round 2: Panel (two staff engineers and a product manager), 60 min

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Walk me through how the 60% on-call drop was measured." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" — your message | Defend the number: how it was counted, the assumption you would defend least. Answer slot: if you measured a baseline, say what it was; if not, say so. | Staff engineers probe the number itself. |
| P2 | "Walk me through how the 40 interviews were scored, and whose score carried the decision." | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" — your message | Say what the loop scored and who decided. Answer slot: if you set the scoring, say so; if not, say so and say what you ran. | Probes F3's attribution from the technical side. |
| P3 | "What would you need to understand about a device-management service before you approved a roadmap item for it?" | JD | [grounded] "Lead two squads building device-management services" — your message | Name what you would need to know: the decision inputs. Answer slot: if you have built a device-facing service, say what; if not, say so and say how you would find out. | F1 and F5 meet here. Do not claim you have built one. |
| P4 | "Hardware and product both want the same quarter. Where's the seam, and what happens when we disagree?" | Peer Evaluator | [grounded] "partner with hardware and product on roadmap" — your message | Propose seam principles, not a seam you have not seen. Use the product-pressure story (F6) as the one example. Answer slot: if hardware was in the disagreement, say so; if not, say that product was. | Peer-style probe on the partnership gap. |
| P5 | "How do you handle credit when work spans teams?" | Peer Evaluator | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through" — your message | Use "pushed", "my team", "the team's on-call burden". Name who did what. | Credit-sharing probe. |
| P6 | "Where would you disagree with a product lead's priority, and how would you do it?" | Peer Evaluator | [grounded] "pushed a reliability quarter through against roadmap pressure" — your message | Tell the disagreement in one story: what you argued, what it cost, who agreed. Answer slot: if the quarter cost a feature, say what it cost. | Tests spine and tact with an equal. |
| P7 | "Sixty seconds: why you over someone who has run hardware-facing services for five years?" | Pressure | [generic] | Pause, restate, anchor on what you stated. Do not claim hardware experience. Concede the gap specifically, then hold the one thing your material shows. | Composure test on F5. The hypothetical comparison presumes nothing about any real candidate. |
| P8 | "That 60%. How much of it was actually you?" | Pressure | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" — your message | Hold: "I pushed the quarter through." Hold through two follow-ups, then concede the team's share explicitly. Never fold on the core claim. | Hold-then-concede on the most-probed number. |
| P9 | "Our device fleet doubles next year and reconnect cost doubles with it. Sketch the plan. What do you need to know first?" | Case/Strategist | [generic] | Clarify objective, segment the fleet, name the metrics, state two risks. Say the framework aloud. | Live problem from the role. Presumes nothing about your past. |
| P10 | "Which of our roadmap bets would you cut first, and why?" | Case/Strategist | [generic] | State the decision rule before the list. Challenge one premise respectfully. | Tests judgment on roadmap trade-offs. |

**Reverse questions (round 2):**
- "What could a new person do in their first month that would genuinely help your team?" Why it lands: it is the reciprocity question for peers.
- "Where do the staff engineers and product disagree most right now?" Why it lands: it shows you are already thinking about the seams.
- "What does a good technical disagreement look like on this team?" Why it lands: it asks about norms, not the org chart.
- "What would you want the next squad lead to know before starting?" Why it lands: it leads into the manager-of-managers question.
- "What does the roadmap look like once hardware releases are fixed?" Why it lands: it tests your F5 gap as a shared question.

## Round 3: VP Engineering, 30 min (recruiter: "values and leadership philosophy")

No published values are in hand, so no values cheat sheet is included. The VAL questions below draw on the recruiter's words only.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "values and leadership philosophy" — recruiter's words, your message | Story from the reliability quarter, if the truth you told was part of it. Answer slot: if you told someone senior a truth they resisted, say what it was and what happened; if the quarter was agreed without that, say so. | Persona stem. Theme from the recruiter's words. |
| V2 | "What do you believe about how managers should spend their time? Give me one thing you stopped doing." | VAL | [generic] | State the principle first, then a story only if you have one. Answer slot: if you changed how you spend your time, say what you stopped and why. | Leadership philosophy, asked as a principle. |
| V3 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Open prompt. If no such time comes to mind, say so plainly, then give the nearest thing your material carries: the reliability quarter, in your own words. | Persona stem. Your material has no customer-first story, so the scaffold says so. |
| V4 | "You've never managed managers. Why should I trust you to run two squads through their leads?" | Pressure | [grounded] "I've never managed managers" — your message | Plain acknowledgment: "I haven't managed managers." Hold on what you did: "I pushed a reliability quarter through." Concede the untested part specifically. | F7 is the most likely objection at this level. Rehearse it deepest. |
| V5 | "That roadmap pressure you held against. Was it worth it? What did it cost?" | Pressure | [grounded] "pushed a reliability quarter through against roadmap pressure" — your message | Hold the decision. Name one specific cost if you can; if you cannot, say so. | Hold-then-concede on F6. |
| V6 | "Two squads disagree about a device-management architecture decision half the org depends on. How do you decide, and how fast?" | CASE | [generic] | Clarify what the decision is, who decides, and how reversible it is. Then a decision rule and a timeline. | Live problem at VP altitude. |
| V7 | "Your eleven engineers report delivery slipping by a quarter. What is your first week?" | CASE | [generic] | Clarify the cause before the fix. Name who you talk to first. | Tests the delivery requirement from the top. |
| V8 | "How would you decide what a hardware constraint means for a software roadmap?" | CASE | [generic] | Name a decision rule. Answer slot: if you have made such a call, say it; if not, say so and describe how you would decide. | F5 at VP altitude. |

**Reverse questions (round 3):**
- "What does leadership philosophy look like when it is tested here?" Why it lands: it asks for the values in practice, not as a slogan.
- "What has the VP changed their mind about in the last year?" Why it lands: it shows you want to learn how decisions get made.
- "What would you want the next manager to stop doing on day one?" Why it lands: it asks for the real norms.
- "How does this organization treat a manager who escalates a problem early?" Why it lands: it tests the leadership-philosophy question from the other side.
- "What would make the first year a success from your side?" Why it lands: it asks for the success criteria.

## Requirement coverage

| Requirement | Covered by |
|---|---|
| Lead two squads building device-management services | H6, P3, V4 |
| Own delivery | H4, H8, V7 |
| Hiring for 11 engineers | H7, P2 |
| Growth for 11 engineers | H9 (discovery), no credible story yet |
| Partner with hardware | H2, H5, P3, V8 |
| Partner with product on roadmap | H3, P4, P6, V5 |
| Terms such as location, pay, work authorization | none, and why: not in your inputs; asked in the closing messages |

## Sources

- Your message: role summary, the three rounds, your background, the recruiter's wording for round 3.
- Query "Larkfield Systems company values": refused (search permission not granted). Target 1 unavailable.
- Query "Larkfield Systems engineering manager interview process": refused. Target 2 unavailable.

**Research tier: L1 — searches 2 of 6, fetches 0 of 2**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Larkfield values | unavailable | Values cheat sheet (round 3), dropped; VAL questions use the recruiter's words instead |
| 2. Larkfield interview process | unavailable | Loop structure; the three rounds come from your message, so persona weights follow them |
| 3. Larkfield strategy / recent news | unavailable | Company knowledge bank (CO), none written |
| 4. Interviewer name + Larkfield | n/a | No names given |
| 5. Representative engineering manager JD | unavailable | Would have given inferred requirements; the role summary you gave is the requirement source |

## Upgrade menu

- Paste the full JD → F1–F5 move from your summary to grounded JD lines, and the coverage table checks against every requirement.
- Paste your CV → F2–F4 gain evidence beyond your message.
- Paste the Larkfield values page → a values cheat sheet for round 3, and VAL questions tied to named values.
- Allow web search and rerun → company values, loop and strategy become sourced, and CO questions appear.
- Interviewer names for each round → per-person persona weights and reverse questions tied to their path.
- Whether the two squads have their own leads → decides how much of the manager-of-managers prep (V4, F7) the pack should carry.
- The recruiter's note on what the panel tests → confirms or changes the panel mix.
- A deeper research pass (up to 6 more searches and 2 more fetches, several minutes), if search is granted.
