Your prep pack is saved as `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-tuesday-part-2-rooms-case-1-denied-3264c00b/acc76184-f5b6-4e83-9d94-a9f0d9fa742b/scratchpad/northwind_senior-gtm-strategy-lead_interview_pack.md`.

It's built on your JD highlights, your summary of Priya's background, Dan's profile, and your research note. I ran no searches, so it's at research tier L0. I treated the round as one 60-minute peer conversation, and I used they/them for Dan since their pronouns weren't stated.

**What the pack says:**
- **Highest-ROI prep:** the consumer-tech to GTM objection (S1). Priya's material shows product strategy and ops, not go-to-market ownership, so expect this probe. S1 has a four-level follow-up ladder.
- **Most likely probes:** the ~$400M figure (P1, X2) and the volume targets (P2). Dan's "relentlessly data-driven" self-description pushes these up.
- **Weighting:** Prober 5 questions, Peer 4, Case 3, Skeptic 3, Pressure 2, Conversational 2. That's 19 questions, with pricing-tilted cases from Dan's spine.
- **Gaps:** partner-motion design is a required JD line, and Priya's partner work is adjacent to it (S2). Enterprise/B2B experience is silent in her material.
- **Prohibited claims:** the pack won't coach "owned GTM," "designed a partner motion," "quotas," "drove the $400M," or "built AI products." Your note that she has no sales-ops or quota-setting experience isn't in her own words yet, so it stays an answer slot until she confirms it.

Offers:
- I can play Dan as the Skeptic on S1, or as the Prober on P1.
- I can save a `tuesday-dossier.md` recording the gaps this prep exposed.
- I can convert the pack to Word if you want it.

Questions:
1. Did the recruiter name focus areas, or a deliverable such as a take-home or POV for this round?
2. Can you paste the full JD text? The highlights are enough for this pack, but the full text may add gate terms like location, travel, or work authorization.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: northwind_senior-gtm-strategy-lead_interview_pack.md -----
# Interview prep pack: Priya, Senior GTM Strategy Lead, Emerging Products, Northwind Data

**Interviewer:** Dan Kovac, Director of Sales Strategy. Peer relationship: both report to the same VP.
**Round:** One 60-minute conversation. No other sessions were named, so this is a session-mode pack.
**Version:** First pack. No prior version to regenerate from.

**Build basis:** Your JD highlights, your summary of Priya's background, Dan's profile as you described it, and your research note. Research tier L0: no searches or fetches were run, so everything not in those four inputs is labeled `[generic]` or left as a slot.

## How to use this pack

- **Personas** describe how a question arrives: its register and delivery. **Types** describe what it scores.
- **Type key:** `JD` = a stated job requirement. `EXP` = a deep-dive into something on her record. `CO` = company and strategy knowledge. `CASE` = a live problem. `VAL` = values alignment (none in this round; see the persona table).
- **Guidance is scaffolding, not a script.** Each guidance cell is speakable in about 90 to 120 seconds. Where a cell says *Answer slot*, that is an instruction for the interview. Priya answers it from her own experience, and an honest "that wasn't mine" or "I haven't done that" is a complete answer.
- **Provenance** shows the sentence each guidance cell rests on. Only quoted sentences support claims about her past.

## Fit snapshot

Requirements are the lines from your JD highlights, quoted exactly. The evidence cells quote your summary of Priya's background, also exactly.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" — JD highlights | "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" — coach's notes | medium | [grounded] | transferability | Your material shows product strategy and operations, not go-to-market ownership. Words: "I spent nine years at a large consumer-tech company in product strategy and ops." Answer slot: the JD asks you to own GTM, so expect a probe on go-to-market decisions. If any were yours to make, say which and how you decided; if none was, or it was not yours, say so plainly and say what the product-strategy work carried over. |
| F2 | "identify whitespace across land/adopt/expand/renew" — JD highlights | "built a partner-level revenue model used in carrier negotiations" — coach's notes | medium | [grounded] | transferability | Revenue modelling for partner negotiations is adjacent to whitespace work and does not show the land, adopt, expand and renew split. Words: "I built a partner-level revenue model that was used in carrier negotiations." Answer slot: if you looked at the lifecycle stages in that model or elsewhere, say which and what it showed; if you did not, say so and say how you would find whitespace across the four stages. |
| F3 | "run independent analysis in SQL and Tableau" — JD highlights | "skilled in SQL/Tableau" — coach's notes | medium | [grounded] | presentation | The material says skilled, which reaches the tools but not independent analysis. Words: "I'm skilled in SQL and Tableau." Do not stretch that to analyses you ran unless one is named in the answer to P3. |
| F4 | "partner-motion design experience required" — JD highlights | "built a partner-level revenue model used in carrier negotiations" — coach's notes | low | [inferred] | transferability | Adjacent partner work, not design of a partner motion. The JD marks this as required, so it is a headline line. Words: "I built a partner-level revenue model that was used in carrier negotiations." Derivation for the label: the model is the only partner work in the material. Answer slot: S2 asks which partner decisions you shaped. If you shaped how the arrangement worked, say how; if you only built the model the negotiators used, say that plainly. |
| F5 | "strong cross-functional influence" — JD highlights | "set annual volume targets with cross-org consensus" — coach's notes | medium | [grounded] | none | The quote reaches cross-org agreement in role terms. It is a CV line with nothing inspected behind it, so expect a probe on who agreed and how. Lead with the targets and the consensus in your own words: "I set annual volume targets with cross-org consensus." |
| F6 | "AI experience a plus" — JD highlights | "uses AI tools daily" — coach's notes | low | [inferred] | transferability | Daily use is adjacent to AI experience in the role; it is not building or launching AI. Words: "I use AI tools every day." Derivation for the label: this is the only AI sentence in the material. |

**Read with the table:**

- **Not a row:** the research note's priorities. Enterprise expansion is a stated Northwind priority, and your material is silent on B2B or enterprise work. That silence is the pack's observation, not a claim Priya can make. It is carried in K3 and S3, not in the table, because a research note is not a JD line.
- **Not a row:** your note "No classic sales-ops or quota-setting experience." It is your note, not a statement Priya has made, so it cannot yet support a plain acknowledgment. It appears in the prohibited list below.
- **Coverage is against your highlights only.** The full JD may add requirements, including gate terms such as location, travel or work authorization. None are visible in the highlights, so none are scored here.

## Prohibited claims

Claims this pack will not coach, each with its basis and its honest form. No answer slot, hold, bridge or rationale in this pack asserts or implies any of them.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned go-to-market strategy | Inflated form of F1: "product strategy & ops" widened into GTM ownership | F1's quote at its own scope. Observation for you, not words for Priya: the material says product strategy and operations, not GTM. |
| Designed a partner motion | Inflated form of F4: "built a partner-level revenue model" widened into designing the motion | F4's quote at its own scope. The S2 slot asks which decisions she shaped. |
| Set quotas or sales targets | Inflated form of F5: "volume targets" widened into quotas | "I set annual volume targets with cross-org consensus." The material says volume targets; the word quota does not appear in it. |
| Drove the ~$400M ARR uplift | Inflated form of "proposed a store-surface change credited with a ~$400M ARR uplift": "credited with" widened into "drove" | "I proposed the store-surface change," with the uplift described as credited to it. The P1 and X2 slots cover attribution. |
| Built or launched AI products | Inflated form of F6: "uses AI tools daily" widened into building AI | "I use AI tools every day." |
| Sales-ops or quota-setting experience (absent) | Your note, not yet stated by Priya. A plain acknowledgment needs her own words. | Answer slot only, in S1 and P2, until Priya says it herself. Once she does, the plain acknowledgment becomes available as a sourced negative. |

## Grounding brief

Source: your research note. It gives the company's three stated priorities and its main competitive threat. The note has no date, so treat its framing as possibly stale and check it before you lean on it.

- **Priorities:** enterprise expansion; an AI copilot launch ("Compass"); reaching profitability.
- **Competitive frame:** bundling by a much larger platform vendor is the main threat.
- **Vocabulary to use:** the three priority names as the note states them. Do not coach Priya to correct the interviewer's framing; if Dan's wording differs from the note, use Dan's.

## Reading the interviewer

Public footprint only, from the profile you supplied. Dan's self-description is "relentlessly data-driven." Their career spine is pricing and monetization, with one early-stage-startup chapter.

**Practical implications:**

1. **Every number gets probed to its assumptions.** Priya should name the weakest assumption before Dan does. This drives P1, P2 and P5.
2. **Case questions lean toward pricing, packaging and unit economics.** That is Dan's native language. This drives K1 and K2.
3. **The startup chapter means builder stories land, and scrappiness probes are likely.** This drives S3 and any "what did you build yourself" follow-up.
4. **A peer on the same VP probes the seam.** Who owns pricing, who owns GTM, and what each needs from the other. This drives E1 and E3.

**Mirror opportunities:**

- **Shared professional domain (monetization):** Dan's pricing and monetization spine meets F2's sentence, "built a partner-level revenue model that was used in carrier negotiations." Offer this only in that sentence, not as a shared identity.
- **Shared career jump:** none. Dan's startup chapter has no counterpart in Priya's material, so do not invent one.

## Persona table

Weights follow the relationship prior for a peer round (Peer Evaluator and Data-Driven Prober at the top), adjusted by Dan's profile. This round is not a values round: no loop source establishes one, and a peer conversation is not a fallback values round. The values persona is therefore unweighted.

| Persona | Questions | How it shows up | Why this weight | Counter-strategy |
|---|---|---|---|---|
| Data-Driven Prober | 5 (P1 to P5) | Walks through the figures and asks for counting method and denominators. Follow-ups go two levels deeper. | Top weight. Dan describes themself as data-driven, and the $400M figure and the volume targets are the numbers to test. | Name the weakest assumption before Dan does. If an analysis was yours, offer to walk it end to end. Say plainly when you do not know how a figure was counted. |
| Peer Evaluator | 4 (E1 to E4) | Seam-splitting, "what would you need from me," credit-sharing. | Second weight. Peer prior, and both report to the same VP, so the seam is live. | Reciprocity framing: what Priya brings Dan's team, not only what she needs. Propose seam principles rather than claiming to know the seam. |
| Case / Strategist | 3 (K1 to K3) | A live problem: bundling, renewal decline, sequencing the three priorities. | Mid weight, tilted to pricing by Dan's spine. | Clarify, then objective, segments, approach, metrics, risks. Think aloud. Challenge one premise per case. |
| Skeptic | 3 (S1 to S3) | Probes the consumer-tech to GTM gap and the partner-design requirement. | Mid weight. The GTM gap is the most predictable objection. | Rehearse S1 until boring. Calibrated candor over bluffing a competency. |
| Pressure / Stress | 2 (X1 and X2) | Time-boxed challenge: "why you over an internal candidate," "how much of it was actually you." | Lower weight: a peer round rarely escalates, but the $400M figure invites it. | Hold the proposal through two follow-ups, then concede one named part. Never fold the core claim. |
| Conversational / Rapport | 2 (V1 and V2) | Friendly opener, then a casual question on AI. | Lower weight, but casual questions are still scored. | A 90-second arc for the opener. Treat the AI question as scored. |
| Values / Behavioral | 0 | Not expected. | No values-style round detected. | Not applicable to this round. |
| Protective mini-bank | Not included | Not requested. | — | — |

**Total:** 19 bank questions, within the 18 to 26 range.

## Question banks

Each question carries a type tag and a provenance cell. Rationales refer to Priya's history only by fit row ID.

### Data-Driven Prober (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Walk me through how the ~$400M ARR uplift was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" — coach's notes | Defend-the-number, in your own words: how it was counted, what it is most sensitive to, the assumption you would defend least, and which part was yours. Open with the proposal: "I proposed the store-surface change." Answer slot: if you know how the uplift was attributed, say how; if you do not, say so plainly and say what you would check first. Do not name a method, a baseline or a model. | This is the headline figure, and it is the one a prober goes to first. The sentence it rests on is in Provenance, and nothing else in the pack describes how it was reached. |
| P2 | "Which assumption behind the annual volume targets would you defend least?" | EXP | [grounded] "set annual volume targets with cross-org consensus" — coach's notes | Weakest-assumption move, in your own words, before Dan asks. The material gives no target number, so do not supply one. Answer slot: if you can name the assumption, say it; if you cannot, say you would check how the target was built. | F5's line is a target set by consensus, and a prober tests a target for its basis. The slot is the weakest-assumption move, and the quote is all it has. |
| P3 | "Pick one analysis you ran in SQL or Tableau. What was the question, where did the data come from, and where could the numbers be wrong?" | JD | [grounded] "skilled in SQL/Tableau" — coach's notes | Open prompt: choose one analysis you ran yourself. If you ran none independently, say so and name the nearest SQL or Tableau work, saying what it did and did not do. The three beats are a scaffold, not facts. | F3 is a presentation gap: the material reaches the skill, not independent analysis. This question is where an analysis would come from, if there is one. |
| P4 | "How would you size whitespace across land, adopt, expand and renew for a new product line, and which data would you distrust first?" | CASE | [generic] | Structure: define whitespace per stage, name the data each stage needs, identify the data most likely to mislead, and name the check you would run before a number goes to leadership. No claim about your past. | This is a live problem from the JD line "identify whitespace across land/adopt/expand/renew." It asks about no past, so it presupposes nothing about Priya. |
| P5 | "What would the partner revenue model have gotten wrong, and how would you have known?" | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" — coach's notes | Open reflection on the model's limits. Name one input you would not defend and what you would check. Answer slot: if the model was checked against outcomes, say how; if it was not checked, say so. Do not describe it as validated. | A prober opens a model as an artifact. The quote says built and used, and nothing about checking it. |

### Peer Evaluator (4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Our teams sit side by side on this. Where is the seam between your work and mine, and what happens when we disagree?" | JD | [grounded] "strong cross-functional influence" — JD highlights; "set annual volume targets with cross-org consensus" — coach's notes | Seam principles, not a map you do not have: name what each team owns and the decision that needs both. For disagreement, open prompt: pick one time you disagreed with a peer team and held a position without going around them. If no time comes to mind, say so and give the nearest case your material carries, or how you would handle it. Use the consensus sentence only if it fits. | The peer prior's seam probe. The JD line is the raising source for the influence theme. |
| E2 | "Walk me through how the annual volume targets were set, and who agreed to them." | EXP | [grounded] "set annual volume targets with cross-org consensus" — coach's notes | Story map on F5: the targets, the cross-org part, and the consensus. Those are the beats the sentence states. Answer slot: name the orgs in your own words; if anyone disagreed, say what they wanted and how it resolved; if no one did, say so. | A peer tests agreement and credit on the line most likely to be probed. |
| E3 | "Where should pricing for a new product line sit, between your team and mine?" | JD | [generic] | Seam principle: name the decision that needs both teams, and what each team's input is. Propose a rule for who decides and who reviews. No past claim. | The seam is Dan's pricing remit against the GTM ownership in the JD line "own GTM strategy for two new product lines." Dan's spine makes this sharp. |
| E4 | "How do you handle credit when a result spans two teams?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" — coach's notes | Credit, honestly: say who did what in the change, whose work it depended on, and how the credit actually got split, in your own words. Answer slot: if you do not know how the credit was split, say so. Do not claim sole credit. | The $400M result is the example a peer will reach for. Credit-sharing is the peer probe. |

### Case / Strategist (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| K1 | "Suppose a much larger platform vendor bundles a comparable capability into its suite. Where do you price the new line, and what would you measure in the first two quarters?" | CASE | [grounded] "main competitive threat is bundling by a much larger platform vendor" — research note | Clarify first: what the bundle includes and who buys it. Then objective, segments, pricing approach (price, or packaging adjacent to the bundle), metrics (attach, renewal, win rate), and risks. Speak it as a structure. No claim about your past. | Dan's pricing spine tilts this to pricing and packaging. The threat comes from your research note, so check its date before relying on it. |
| K2 | "Renewal rate on a new product line drops twenty percent in a single quarter. Diagnose it." | CASE | [generic] | Clarify: which renewals, which segment, and what changed in that quarter. Split the causes into price, product, adoption and competitor bundle. Name the one check you would run first. | A Case stem with the pricing-and-unit-economics tilt. No past claim. |
| K3 | "Northwind is pursuing enterprise expansion, an AI copilot launch and profitability together. Where would you put GTM effort in the first 90 days?" | CO | [grounded] "enterprise expansion, an AI copilot launch ('Compass'), and reaching profitability" — research note | Sequence by the priorities: what must be true for each, which one you would protect, and which one you would not start yet. Answer from the priorities and the sequencing alone. Bring in your background only in a sentence the material carries. | The company-altitude question. The three priorities come from your research note, and the note has no date. |

### Skeptic (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| S1 | "Your background is product strategy and operations. Which parts of owning a go-to-market have you actually run?" | JD | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" — coach's notes | **Deepest rehearsal. Four levels.** (1) Answer with what you ran, in your own words: "I spent nine years at a large consumer-tech company in product strategy and ops," then the consulting years. (2) Follow-up "which decision was yours?": answer with the decision and your part, or say none. (3) Follow-up "what would you do first with no sales history?": answer as a plan, never as a past. (4) If pressed on a GTM part you have not run, name that part and stop there. Hold the product-strategy claim through two follow-ups. Concede only the specific part you have not run, never the whole claim. Answer slot: if any go-to-market decision was yours, say which; if none was, say so plainly. | F1 is the headline gap, and this objection is near certain in some form. This is the single most predictable objection to this candidate, so it is the highest-return prep in the pack. Rehearse it until it is boring. |
| S2 | "Partner-motion design is required for this role. Which partner decisions have you been part of, and in what role?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" — coach's notes | Say what the model was for and where you sat relative to the negotiations, in your own words. Answer slot: if you shaped how the partner arrangement worked, say how; if you built the model the negotiators used and had no part in the arrangement, say that plainly. Do not call it design work. | F4's gap, read against a JD line marked required. |
| S3 | "What do you know about Northwind's enterprise customers that a consumer-tech product team would not?" | CO | [grounded] "enterprise expansion" — research note; "9 at a large consumer-tech company in product strategy & ops" — coach's notes | Answer slot: if the honest answer is that you know little about their enterprise customers, say so, and say how you would learn it in the first month. Do not claim B2B knowledge the material does not show. | Tests the silence on B2B and enterprise work that the fit snapshot notes. The enterprise priority comes from the research note; the silence comes from the coach's summary. |

### Pressure / Stress (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| X1 | "Sixty seconds: why you over an internal candidate?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations"; "set annual volume targets with cross-org consensus" — coach's notes | Scaffold for sixty seconds: pick the one quoted sentence that answers the JD most directly, state it, and stop. Then say what you would do first, framed as a plan. Do not describe the other candidate. If the honest answer is that someone else has more go-to-market experience, say your strongest fit in one sentence. | A time-boxed challenge forces the fit sentence. The scaffold leaves the choice of sentence to Priya. |
| X2 | "That result: how much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" — coach's notes | Hold, then concede. Hold "I proposed the store-surface change" through two follow-ups, and add nothing to it. Concede the one specific part you cannot defend: the share of the uplift attributed to you, if you cannot say how the attribution was made. Never fold the proposal itself. | The figure a pressure interviewer goes to. The hold is the sentence the quote carries, and the concession is specific. |

### Conversational / Rapport (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V1 | "So, walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" — coach's notes | Pre-scripted 90-second arc: the consulting years, then the consumer-tech product strategy and operations years, then why this role. Use the quoted clauses only. End on the one fit sentence. | A casual opener is still scored on communication economy. |
| V2 | "What are you actually playing with in AI these days?" | JD | [inferred] "uses AI tools daily" — coach's notes | Say what you use, what for, and how often, in your own words. Do not describe building or launching AI. Derivation for the label: daily use is the only AI sentence in the material, so the answer stays at use. | A casual question on a JD plus item. Dan will score it as one. |

### Coverage against the JD highlights

| JD requirement | Covered by |
|---|---|
| own GTM strategy for two new product lines | S1, E3 (JD tags); K3 (CO) |
| identify whitespace across land/adopt/expand/renew | P4 (CASE) |
| run independent analysis in SQL and Tableau | P3 |
| partner-motion design experience required | S2, P5 |
| strong cross-functional influence | E1, E2 |
| AI experience a plus | V2 |

Coverage is against the highlights you supplied. A full JD may add rows.

## Reverse questions

Each one has a "why it lands." Dan is a peer, so the reciprocity and seam questions carry the most weight.

| # | Question | Why it lands |
|---|---|---|
| R1 | "You came through pricing and monetization and a startup chapter. What did the startup teach you about pricing that a larger company hides?" | Tied to Dan's own path from the profile. It turns an interview into a peer conversation and shows you looked at them, not only at the company. |
| R2 | "What could a new person do in the first month that would genuinely help your team?" | The reciprocity question for a peer. It shows you are thinking about their load, not only your own. |
| R3 | "Where does pricing for a new line sit today: with you, with product, or split?" | Names the seam E3 tests. The answer tells you the real remit and shows you raised the question on purpose. |
| R4 | "What number would you want to see from a new product line at twelve months?" | A data-driven peer will answer this with a metric. Their answer shows you the measure they use. |
| R5 | "Of the three priorities, enterprise expansion, the copilot launch and profitability, which is hardest to hold together in this role?" | A company-altitude question that invites Dan's own view, without requiring you to know the answer. |
| R6 | "What would make the first ninety days a success from where you sit?" | Asks for the peer's expectations directly. It is the cleanest answer to the closing slot "any questions for me?" |

## Sources

**Provided documents:**

1. JD highlights (your message).
2. Candidate background summary (coach's notes).
3. Interviewer profile, as you described it (your message).
4. Research note on Northwind's priorities and competitive threat (your message).

No other document was read.

**Research tier:** L0, no searches or fetches sent. User links read: 0.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `{company} values` | unavailable | You chose L0. Would have supplied the value names if a values-style round arises. None is detected, so the values cheat sheet is dropped. |
| 2. `{company} interview process {role family}` | skipped | Your message fixes the loop: one 60-minute conversation with Dan Kovac, a peer. |
| 3. `{company} strategy` / recent news | skipped | Your research note already supplies the three priorities and the competitive frame. Its date is not stated, so the currency of those priorities is unchecked. |
| 4. `{interviewer name} {company}` | unavailable | You chose L0. Would have added Dan's published talks and writing, which could sharpen R1 and the question themes. The profile you supplied is used as given. |
| 5. representative `{role title}` JD | unavailable | You chose L0. Would have checked for requirements your highlights may omit. |

## Upgrade menu

- **Full JD text** → the six highlight rows can be checked against the whole posting; any gate terms (location, travel, work authorization) would appear as rows; the coverage table checks the complete list.
- **Priya's full CV text** → quotes can come from the CV's own sentences in place of the summary. Confidence can rise only from an inspectable artifact, not from a fuller summary.
- **An analysis Priya built in SQL or Tableau** → F3 can move toward `high` with the artifact attached, and P3 can be answered from it.
- **The readout or model behind the ~$400M figure** → P1, P2 and X2 can be answered from evidence in place of answer slots.
- **Confirmation in Priya's own words of no sales-ops or quota-setting experience** → the plain acknowledgment becomes available for S1 and P2, and the prohibited-list entry can be rewritten as a sourced negative.
- **Dan's public talks and writing** → sharper R1 and a question-theme check, from L1 target 4.
- **Recruiter's prep email** → focus areas or any pre-declared deliverable (take-home or point of view) would add a graded-deliverable section. None is in the pack now.
- **Date of the research note** → confirms whether the priorities and the bundling threat in K1 and K3 are current.
- **Prep time before the round** → a triaged schedule of what to rehearse first.
- **Deeper research (L2):** up to six more searches and two more fetches, several minutes. It would add a strategy brief, Dan's talks in depth, role-family loop reports, and recent org context. Offered once.
