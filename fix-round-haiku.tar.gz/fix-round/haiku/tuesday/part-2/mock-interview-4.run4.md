Your prep pack is saved here: `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-tuesday-part-2-rooms-case-4-denied-74edb861/2c87d6cd-92f7-43ce-919c-8ad2ada40396/scratchpad/Quartzline_Product-Manager-Platform-APIs_interview_pack.md`

Thursday is tomorrow (Nov 12), so the pack is built for one day of prep. Start with three things:

1. **A1**, the objection the underwriter named ("never held the PM title or owned a roadmap, why hire you into one?"). The answer holds on the integrations you led and the roadmap-input sessions, then concedes the roadmap call specifically. Don't argue the title.
2. **A2 and A4**, the day-one weakness and the agile question. Both get plain acknowledgments, with no hedging.
3. **B2 and B3**, the adoption and two-squad case questions, then reverse questions **R-1** and **R-2**. These go straight at the two open risks in your dossier: who decides roadmap calls, and whether there is any adoption baseline.

Three things to know before you rely on it:

- **Web research didn't run.** The search calls were refused by the host's permissions, so I couldn't check Quartzline's values, interview structure or current strategy. The pack says so and drops the values cheat sheet and any strategy-grounded questions. If you grant web search, I can run those checks.
- **The dossier is from August 14.** The requirement wording may not match the current posting. Check it before Thursday.
- **Two fit rows are my derivation.** The dossier doesn't grade R2 (shipped API products) or R4 (stakeholders across engineering, sales and customers). I graded them from the same evidence and labeled them `[inferred]`. The pack says engineering, sales and shipping are not in your material, and it doesn't claim them.

Is the hiring manager's name known? If so, I can tailor the reverse questions and persona weights to them.

I can also play the Skeptic on A1 as a live drill, or save a `tuesday-dossier.md` with the gaps this prep exposed. If you'd like the pack as a Word document, I can convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Quartzline_Product-Manager-Platform-APIs_interview_pack.md -----
# Interview prep pack: Product Manager, Platform APIs at Quartzline

**Round:** 45-minute conversation with the hiring manager, Thursday (Nov 12).
**Interviewer:** not named. Relationship: hiring manager.
**Built from:** your underwriting dossier (`tuesday-dossier.md`, generated 2026-08-14, decision `conditional_go`). Web research did not run this session (see Sources).

## How to use this pack

- **Personas** = how the question is asked. **Types** = what is being scored: JD (the listed job), EXP (your past work), CASE (a live problem), CO (company knowledge), VAL (behavior and values).
- Guidance is scaffolding, not a script. Each answer should take 90 to 120 seconds spoken.
- Lines starting **Answer slot:** are instructions for the interview. They are not questions for you to answer here.
- The dossier is 89 days old. If the posting changed since August, the requirement wording below may be stale. Check it against the posting before Thursday.

## Prep triage

Prep time is about one day. In this order:

1. **A1**, the objection the underwriter named. Say the hold and the concession aloud three times.
2. **A2** and **A4**, so the plain acknowledgments come out without hedging.
3. **B2** and **B3**, then reverse questions **R-1** and **R-2**, which go straight at the two open risks in the dossier.

Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" (dossier role_profile, R1) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier, verified evidence 1; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier, verified evidence 3 | low | [inferred] | transferability | Adjacent work, not the title. Bridge with its limit: "I haven't held a product manager title. What I have done is led 30+ end-to-end client integrations of the vendor's REST APIs, from scoping through go-live, and run quarterly roadmap-input sessions that fed client evidence to product." The title negative rests on the dossier's prohibited_claims item. The rest rests on the two quotes. |
| F2 | "Owning a roadmap and prioritization authority" (dossier role_profile R1 sub-claim; dossier uncertain_or_weak_areas) | none given | none | [grounded] | capability | The dossier records this as an acknowledged gap, so the words are plain: "I haven't owned a product roadmap." Then a ramp, said as a plan and never as a past: "In the first month I'd want to learn the partner roadmap, what each squad has committed, and where the adoption number comes from." No bridge is offered here. |
| F3 | "Shipped API or platform products" (dossier role_profile, R2) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier, verified evidence 1 | low | [inferred] | discovery | Your material is silent on whether you shipped the API itself. Answer slot (A3): if you shaped what a release contained, say which and how; if the API was shipped by others and your part was the integrations, say so plainly and stay with the integrations you led. Pack observation, not words for you: the material shows integrations of the vendor's REST APIs, not an API product shipped. |
| F4 | "Technical fluency: API docs, schemas" (dossier role_profile, R3) | "Wrote the internal integration playbook her team uses" — dossier, verified evidence 2 | low | [inferred] | discovery | The material touches documentation through the playbook and shows nothing on schemas. Answer slot (B1, E1): if you wrote or reviewed API docs or schemas, say which and for whom; if the playbook is the closest you have come, say what it covered and whether schemas were in it. |
| F5 | "Stakeholder management across engineering, sales, customers" (dossier role_profile, R4) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier, verified evidence 1; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier, verified evidence 3 | low | [inferred] | transferability | Customer and product work is quoted; engineering and sales are not. Bridge: "With customers I led the integrations end to end. For product, I ran the roadmap-input sessions." Pack observation, in analysis only: engineering and sales do not appear in the material, so A5's slot covers them. |
| F6 | "Agile delivery experience" (dossier role_profile, R5, preferred) | none given | low | [inferred] | discovery | No quoted sentence speaks to agile delivery, so this is a clarify, not a bridge. Answer slot (A4): if you ran delivery on a sprint or planning cadence, say which, in your own words; if you did not work that way, say so and ask what this team means by agile. |

**Confidence and provenance.** F1's confidence is low because the adjacent evidence is indirect, so its guidance is labeled [inferred] with the derivation named. The verified claims in E1 and E3 are high and medium respectively. E3 is medium because the material shows the sessions but not what came of them. That is the probe you should expect (C2).

## Prohibited list

Built from the fit snapshot before the banks were written. Each entry names its basis, because the basis decides its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | Sourced entry: dossier prohibited_claims | "I haven't held a product manager title." Then F1's quotes at their own scope. No answer slot. |
| Having owned a product roadmap | Sourced entry: dossier prohibited_claims and acknowledge_gap | "I haven't owned a product roadmap." Then F2's ramp, as a plan. |
| Having set prioritization for an engineering squad | Sourced entry: dossier prohibited_claims | "I haven't set prioritization for an engineering squad." No answer slot. |
| Shipped an API or platform product | Inflated form of F3: "Led … integrations" widened to "shipped the product" | E1 at its own scope. The limit is the pack's observation only. No first-person negative. A3's slot stays inside the integrations. |
| Managed engineering and sales stakeholders | Inflated form of F5 | E1 and E3 at their scope. Engineering and sales appear only as A5's slot, never as a claim. |

## Persona weights and the reasoning

| Persona | Weight | Why this weight |
|---|---|---|
| Skeptic | 5 | Hiring-manager prior: they are buying capability and checking gaps. The dossier's named objection is a Skeptic objection. |
| Case / Strategist | 5 | Hiring-manager prior: expect live problems on their actual roadmap. The JD's responsibilities are the source. |
| Data-Driven Prober | 3 | The CV carries a headline figure (30+) and a claim with little after it (the roadmap sessions). No signal on the interviewer's style. |
| Pressure | 3 | Not a hiring-manager prior, but the dossier's named gap is a pressure target. |
| Values / Behavioral | 1 | No values-style round is detected: no loop source establishes the loop, and the generic fallback says no. Touched once because the JD names customers. |
| Conversational | 1 | Open-first. Cheap insurance. |
| Peer Evaluator | 0 | Not plausible for a hiring-manager round. Not touched. |

**Loop.** No loop source establishes the loop, so the archetype fallback is generic, which carries a flat tilt. The weights above come from the round-type prior alone. Interviewer read: dropped, because no name was given. Values cheat sheet: dropped, because no values-style round is detected. Graded deliverables: none declared. Grounding brief: dropped, because L2 research did not run. Delivery coaching: dropped, because no assessment was provided.

## Question banks

Eighteen questions. Every provenance cell carries the sentence the guidance rests on.

### Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've never held a product manager title or owned a roadmap. Why should we hire you into that instead of a PM with three years of the job?" | JD | [grounded] dossier prohibited_claims: "Having held a product manager title or role"; [grounded] dossier acknowledge_gap: "Owning a roadmap and prioritization authority (R1 sub-claim)"; [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | **The highest-ROI prep in this pack.** The underwriter named this objection, and it will come in some form. Do not argue the title. Hold: "I haven't held a product manager title. What I have done is led 30+ end-to-end client integrations of the vendor's REST APIs, from scoping through go-live." Hold through the first follow-up by returning to the integrations. Concede on the second, specifically: "The roadmap call is the part I'd be learning, not the part I'd bring. Here is what I'd do in the first month." | Named by the underwriter. Tests the transferability gap (F1) and the roadmap gap (F2) together. JD type because it scores the listed job. |
| A2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] dossier acknowledge_gap: "Owning a roadmap and prioritization authority (R1 sub-claim)" | Name roadmap ownership first, in plain words: "I haven't owned a product roadmap." Then the ramp as a plan: learn the partner roadmap, what each squad has committed, and where the adoption number comes from. Use no past tense for any of it. | F2 is the acknowledged gap. The allowed strategy is acknowledge_gap, so there is no bridge here. |
| A3 | "Tell me about an API or platform product you've been part of shipping, and where you sat in it." | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Open prompt. Map it to the integrations you led, in the quote's terms. Answer slot: if you shaped what a release contained, say which and how; if the API was shipped by others and your part was the integrations, say so plainly and stay with the integrations you led. | F3 is discovery: the material is silent on shipping. The second branch lets the practice never have been yours. |
| A4 | "The JD asks for agile delivery experience. What's your experience there?" | JD | [grounded] role_profile R5: "Agile delivery experience" | Clarify slot, because no quoted sentence speaks to agile directly. If you ran delivery on a sprint or planning cadence, say which, in your own words. If you did not work that way, say so, and ask what this team means by agile. | F6 is discovery with a clarify strategy. A bridge would be inflation. |
| A5 | "Stakeholder management across engineering, sales and customers. Which of those have you actually managed, and how?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Answer in the quotes' terms: customers through the integrations you led, product through the roadmap-input sessions. Answer slot: if you worked with engineering or sales on any of it, say how; if you did not, say so and say what you would do first. | F5. The question asks for three groups; the material shows two. Do not say "managed" for product. |

### Case / Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A partner's integration has slipped six weeks, and two of the three engineering teams say the API docs are wrong. What do you do, starting this week?" | CASE | [generic] | Clarify, then objective, segmentation, approach, metrics, risks. Think aloud. Challenge one premise: has anyone checked the docs claim against the actual calls? No claim about your past. | A live problem from the JD's "API docs, schemas" line (F4). [generic] because it is a pattern for the problem, not a fact about this team. |
| B2 | "Partner API adoption has been flat for two quarters. How would you diagnose it?" | CASE | [generic] | Ask first what the adoption number is today and how it is counted. The JD names adoption metrics but no baseline, so asking for one is a strong move. Then segment by partner and integration stage. Name the assumption you would defend least. | Responsibility from the JD: "Define and track adoption metrics." Feeds R-2. |
| B3 | "Two engineering squads both want the next quarter. How would you decide what goes first?" | CASE | [grounded] role_profile responsibility: "Write specs and drive delivery with two engineering squads" | Clarify who decides before you answer: "Which of these calls is mine, and which belongs to the squad leads?" Then a framework: partner impact, adoption evidence, squad capacity. Hypothetical only. Do not describe setting priorities for a squad. | The decision-authority risk from the dossier. Feeds R-1. Avoids the prohibited claim about squad prioritization. |
| B4 | "What would your first 90 days look like on this platform?" | JD | [generic] | Plan language only. Days 1 to 30: learn the partner roadmap and the squads' commitments. Days 31 to 60: partner discovery. Days 61 to 90: a first decision, with a baseline for adoption. Say each as a plan. | The ramp for F2 and F6. Plan language, never a past. |
| B5 | "A large partner asks for a breaking change to the auth flow next month. What do you do?" | JD | [generic] | Structure: who is affected, what the partner actually needs, options including versioning, who decides, and how partners are told. No past claims. | Tests the partner-discovery responsibility. No candidate claim is made. |

### Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how you counted the 30+ integrations." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Defend-the-number slot. Say what you counted, in your own words. Answer slot: if you cannot say how it was counted, say so. The pack does not supply a method. Use "led", never "ran" or "owned the scope". | The headline figure on the dossier. Coverage rule: every headline figure gets a defend-the-number question. |
| C2 | "What did product change because of those roadmap-input sessions?" | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Answer slot: if product changed something because of the sessions, say what and how you know. If you cannot point to a change, say so. The limit is the pack's observation, not words for you: the material shows the sessions, not what came of them. | E3 is medium confidence. This is the probe to expect. Volunteer the limit before it is extracted. |
| C3 | "Which adoption metric would you pick, and what assumption behind it would you defend least?" | JD | [generic] | Name one metric and one assumption, in your own words. Do not supply a baseline or a metric you have tracked. | The JD names adoption metrics. The prober tests assumptions, so the weakest-assumption move is the one to rehearse. |

### Pressure (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: what's the strongest argument against hiring you for this role?" | JD | [grounded] dossier acknowledge_gap: "Owning a roadmap and prioritization authority (R1 sub-claim)"; [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Hold-then-concede. Lead with the roadmap gap in plain words. Hold the integrations through two follow-ups. Concede specifically: "I'd be learning the roadmap call, not bringing it." Never fold on the core claim to restore harmony. | Pressure persona. The concession must be specific, not a general "I could improve". |
| D2 | "That 30+ number. How much of it was actually you?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Answer slot: say which integrations you led end to end, and which parts of scoping, requirements, architecture, UAT and go-live you did yourself, in your own words. Do not add a stage the quote does not name. | Attribution honesty. The question's own beats come from the quote. |
| D3 | "If your two squad leads disagreed with your priorities, who would win?" | JD | [generic] | The honest answer depends on the decision split, which you do not yet know. Say so, then ask how the split is drawn. Do not assert authority you have not been given. | The dossier's decision-authority risk. The strongest answer here is the question back. |

### Conversational (weight 1)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; [grounded] "Wrote the internal integration playbook her team uses"; [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | A 90-second arc in three beats: the integrations, the playbook, the roadmap sessions. Then what you are looking for. Do not frame it as a product-manager story. | Casual register, still scored. The arc is built from three quotes only. |

### Values / Behavioral (weight 1)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Tell me about a time you had to tell a customer something they didn't want to hear about an integration." | VAL | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Open prompt. Selection scaffold: pick a time you had to say something hard to a client on one of those integrations. It needs a named stake, the moment you said it, and what happened after. If no such time comes to mind, say so plainly, then give the nearest thing your material carries: the scoping or go-live stage. | The JD names customers. No values round is detected, so this is a single touch, not a bank. |

**Coverage.** Every JD line is covered: 3+ years (A1, A2, D1), shipped products (A3), API docs and schemas (B1), stakeholders (A5, B3), agile (A4). The responsibilities are covered: roadmap (A1, A2, B3, D3), adoption metrics (B2, C3), squad delivery (B3), partner discovery (B5). Session total: 18 bank questions.

## Reverse questions

Five, with the reason each one lands. None is tied to the interviewer's own path, because no name was given.

| # | Question | Why it lands |
|---|---|---|
| R-1 | "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" | Tests the dossier's open risk on decision authority. The JD asserts it. Nothing in your material shows it. |
| R-2 | "How is partner API adoption measured today, and what is the current baseline?" | The dossier's second open risk. If there is no baseline, the first job is building one, and that is worth knowing before you accept. |
| R-3 | "What would make you say in six months that this was the right hire?" | Turns the hiring manager's own objection into the success criteria. [generic] for this round. |
| R-4 | "What is the hardest partner conversation on the platform right now?" | Invites a live problem from the actual roadmap. [generic]. |
| R-5 | "Which of the two squads is further along on partner-facing work, and where does the platform roadmap meet theirs?" | Probes the seam between the squads and your decision space. [generic]. |

## Target accounting in Sources

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quartzline values | unavailable | Every call refused. Query: "Quartzline values operating principles" (refused). No values page, so no values cheat sheet. |
| 2. Quartzline interview process, product manager, platform APIs | unavailable | Every call refused. Query: "Quartzline interview process product manager platform APIs" (refused). No loop source, so the loop is unknown. The archetype fallback is generic and flat. Persona weights rest on the round-type prior alone. |
| 3. Quartzline strategy and recent news | unavailable | Every call refused. Query: "Quartzline strategy recent news 2026" (refused). No grounded CO questions. The bank has no CO question, because none is grounded. |
| 4. Interviewer name and company | n/a | No name was given, so there was no query to form. The interviewer read is absent. |
| 5. Representative JD for the title | skipped | The dossier's role_profile fixes the fit snapshot and the JD-tagged questions. |

**Dossier consumed.** Sections used: `role_profile` (requirement wording), `handoff_to_mock_interview` (verified evidence, weak areas and allowed strategies, the likely objection, the risks, employer questions, prohibited claims), and `decision` (context only). The dossier is dated 2026-08-14. Its requirement wording and its evidence reflect the posting as it stood then.

**Not established:** Quartzline's values, its interview structure, and its current strategy. Anything about them in this pack is absent, not inferred.

## Upgrade menu

- Permission for web search → company values, interview structure and recent strategy (targets 1 to 3). That would add a values cheat sheet if values are published, a grounded loop, and grounded CO questions.
- The current posting text → confirms or updates the requirement wording the dossier carries from August.
- The interviewer's name → a tailored reverse question, and persona weights from their public footprint.
- The recruiter's note on the round's format → confirms whether this is one conversation or a panel, which reweights the personas.
- Any inspectable integration or API work (a release note, a schema, the playbook itself) → would upgrade F3 and F4 from discovery toward a bridge.
- What came out of the roadmap-input sessions, in your own words → would settle C2.
- A deeper research pass (up to 6 more searches and 2 more fetches, several minutes), if web search is enabled.
