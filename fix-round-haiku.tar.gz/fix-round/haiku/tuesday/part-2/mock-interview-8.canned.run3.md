Your prep pack is saved as /tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-tuesday-part-2-rooms-case-8-canned-88a8c2aa/f4f20de6-f2e0-4db7-8942-88fada424ab5/scratchpad/ashgrove-credit-union_member-experience-lead_interview_pack.md. It's built as a three-round loop, with a shared fit snapshot and a mini-pack per round. I didn't run any searches, because the values, round structure and strategy were already in your message.

Where to start, with nine days to go:
- **The 20-minute escalation case (R3-C1).** It's the highest-weight item in round three.
- **The objection you'll hear in round two:** no contact-centre work and nothing above regional level (R2-B1). The pack names it the highest-ROI prep.
- **Values.** You have no mapped story for any of the four values yet. Find one real decision for each before Friday. Where you can't, use the honest branch the pack gives you.

Say the word and I'll play the Head of Member Services on R2-B1 and push on the follow-ups.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove-credit-union_member-experience-lead_interview_pack.md -----
# Interview prep pack: Member Experience Lead, Ashgrove Credit Union

**Loop:** three rounds on Friday 20 November 2026. Built Wednesday 11 November 2026.

- **Round 1:** recruiter screen, 30 minutes.
- **Round 2:** Head of Member Services (your future manager), 45 minutes, mostly behavioural.
- **Round 3:** panel of two branch managers, 60 minutes, including a 20-minute complaint-escalation case. The panel scores you against the four values.

Interviewer names are not yet assigned. This is loop mode: one shared fit snapshot and sources block, then a mini-pack per round.

**Built from:** the JD text, the values copy (ashgrovecu.org/about/values, copied 11 November 2026), the recruiter's round email, your summary of the July 2026 strategy brief, and your background as written in your message. You have not sent a CV, so your message is the only evidence source.

## How to use

- **Personas** describe how a question arrives. **Types** describe what it scores: VAL (values and behaviour), EXP (your work-experience record), JD (a stated requirement), CO (company and strategy), CASE (a live problem).
- Guidance is scaffolding for a spoken answer, not a script.
- An answer slot is an instruction for the interview. It is not a question to you.
- No take-home or presentation was announced, so there is no deliverable section.
- Interviewer read: omitted, since no names are assigned yet (see upgrade menu).

## Prep triage (9 days)

1. **Wed 11 to Thu 12 November: R3-C1, the 20-minute case.** Say the structure aloud twice. It is the highest-weight item in round three.
2. **Fri 13 to Sat 14 November: the values stories.** You have no mapped story for any of the four values yet. Find one real decision for each value, using the scaffolds in R2-A1, R2-A2, R3-A1, R3-A3 and R3-A4. Where you find none, use the honest branch.
3. **Sun 15 to Tue 17 November: the gaps.** Rehearse R2-B1 (the highest-ROI prep in the pack), R1-B2 and R2-C1. Say the plain acknowledgment and the ramp plan out loud, three times each, until the second follow-up no longer knocks you off.
4. **Wed 18 November: one full drill** on R2-B1 or R3-C1. The offer is at the foot of the message that presents this pack.
5. **Thu 19 November: R1-A1**, the ninety-second career arc, and the reverse questions. Then rest.

Everything else is insurance.

## Fit snapshot (shared across rounds)

No gate rows: the JD states no authorisation, licence, location, schedule, pay or travel term. Length of experience is not a gate.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches and the contact centre" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | transferability | Your material puts you at one branch's formal log, not the process end to end and not across branches. Words: "I handled the branch's formal complaints log." Limit, as the pack's observation: the material does not show anything beyond the log. Answer slot: if any part of the process beyond the log was yours to set, say which and how you decided; if none of it was yours, say so and say what you would look at first across branches. |
| F2 | "experience handling regulated complaints" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | presentation | The quote reaches complaints handling in role-relevant terms. It does not say "regulated", and the material does not show which rules applied. Words: "I handled the branch's formal complaints log." Answer slot: say what governed the handling and which part was yours; if nothing beyond the branch's own practice governed it, say so. |
| F3 | "coach branch supervisors on escalations" (JD) | "trained new tellers on our escalation script" (your message) | medium | [grounded] | transferability | Training tellers on an escalation script is adjacent to coaching supervisors on escalations, not the same thing. Words: "I trained new tellers on our escalation script." Limit: the sentence says tellers, and the script was already "our". Answer slot: if you have coached anyone on an escalation decision, say who, what you covered and what you did not decide; if you have not, say so and say how you would start with branch supervisors. |
| F4 | "report monthly on complaint volumes and resolution times" (JD) | "I built the monthly complaints spreadsheet our regional manager uses." (your message) | medium | [grounded] | presentation | The quote reaches monthly complaints reporting in role-relevant terms. It does not say what the spreadsheet counted. Words: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: say what the spreadsheet counted and what you chose to include; if you did not choose what it counted, say who did. |
| F5 | "comfortable with Excel reporting" (JD) | "I built the monthly complaints spreadsheet our regional manager uses." (your message) | medium | [grounded] | discovery | Your material says "spreadsheet". It does not name a tool. Answer slot: name the tool and the functions you used in it, in your own words. |
| F6 | "4+ years in financial-services customer operations" (JD) | "6 years in retail banking, the last 3 as a branch supervisor." (your message) | medium | [grounded] | none | Tenure in retail banking reaches the requirement. No gap. Words: "6 years in retail banking, the last 3 as a branch supervisor." |
| F7 | "confident presenting to senior leaders" (JD) | "I've never presented to anyone above regional level." (your message) | none | [grounded] | capability | You stated the absence. Words: "I haven't presented to anyone above regional level." Then how you would build to it, said as a plan and never as a past. Never claim presenting experience, and add nothing to make the gap feel smaller. |
| F8 | "work with digital teams on self-service journeys" (JD) | none given | none | [grounded] | discovery | Your material is silent. No digital or product work is mentioned, and you have not said it is absent. Answer slot: if you have worked with a digital or product team on a customer-facing change, say what you did and what you decided; if you have not, say so and say how you would start. |
| F9 | "across branches and the contact centre" (JD) | "Never worked in a contact centre" (your message) | none | [grounded] | capability | You stated the absence. Words: "I haven't worked in a contact centre." Then the ramp, as a plan. |

Confidence grades your evidence. Provenance grades this pack's statement of it. Medium is the right band while nothing has been inspected, so expect a probe on each row.

## Prohibited claims

These are claims the pack will not coach, because the material does not carry them.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the member complaints process end to end | Inflated form of F1 | F1's quote at its own scope. The pack's observation, not words for you: the material says one branch's formal log. |
| Ran complaints across branches or the contact centre | Your stated negative, F9 | "I haven't worked in a contact centre." No answer slot on it. |
| Presented to senior leaders | Your stated negative, F7 | "I haven't presented to anyone above regional level." No answer slot on it. |
| Excel as a tool you used | Inflated form of F4 and F5; the material says spreadsheet | "The monthly complaints spreadsheet our regional manager uses." Name a tool only if it is true. |
| Wrote the escalation script | Inflated form of F3 ("our" script) | "I trained new tellers on our escalation script." |
| Coached branch supervisors on escalations | Inflated form of F3 | F3's quote at its own scope. |
| Met regulatory response deadlines | Inflated form of F2 | F2's quote at its own scope. The material does not show any deadlines. |

## Grounding brief

From your summary of the July 2026 strategy brief. You did not paste the brief, so check each wording against the original before you use it.

| Current fact | Provenance |
|---|---|
| Move 40% of member service to digital channels by 2028 | [grounded] "move 40% of member service to digital channels by 2028" (your summary of the brief) |
| Consolidate eight branches into five hubs over 2027 | [grounded] "consolidate eight branches into five hubs over 2027" (your summary of the brief) |
| Launch a small-business lending product in Q1 2027 | [grounded] "launch a small-business lending product in Q1 2027" (your summary of the brief) |
| Main competitive pressure is app-only banks | [grounded] "the main competitive pressure is app-only banks" (your summary of the brief) |

Round 3's branch managers may work in branches that are consolidated. You do not know whether either of them does, so do not assume it either way.

## Requirement coverage

| JD requirement | Questions |
|---|---|
| Own complaints end to end across branches and the contact centre | R2-B2, R3-B1, R3-B3 (F1, F9) |
| Report monthly on complaint volumes and resolution times | R2-C2 (F4) |
| Coach branch supervisors on escalations | R2-B3, R3-C2, R3-C1 (F3) |
| Work with digital teams on self-service journeys | R1-A3, R3-C3 (F8) |
| 4+ years in financial-services customer operations | R1-A1, R1-A2 (F6) |
| Experience handling regulated complaints | R1-C2, R2-B1 (F2) |
| Confident presenting to senior leaders | R1-B2, R2-A3, R2-C1 (F7) |
| Comfortable with Excel reporting | R2-C2 (F5) |
| Published value: Members First, Always | R2-A2, R3-A1 |
| Published value: Plain Words | R3-A2 |
| Published value: Neighbours, Not Numbers | R3-A3 |
| Published value: Own the Fix | R2-A1, R3-A4 |

---

## Round 1: recruiter screen (30 minutes)

**Persona weights**

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / rapport builder | Friendly openers, a biography ask, casual questions on hot JD topics | 4 of 8 (top). The recruiter-screen prior is conversational. Casual questions are still scored. | Pre-scripted ninety-second arc. Treat every casual JD question as scored. |
| Skeptic (light) | Motivation check, the knockout on senior presenting | 2 of 8. The screen is the first place a gap is noticed. | Plain acknowledgment, then the ramp as a plan. |
| Values / behavioural (light) | A quick first-instinct question on a complaint | 2 of 8. The panel scores values, so the screen only sets the first impression. | Give one real instance, or the honest branch. |

**Question bank**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R1-A1 | "Walk me through your career so far, in about ninety seconds." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "I handled the branch's formal complaints log"; "trained new tellers on our escalation script" | Story-mapped on F6, F1 and F3, in that order. The beats are the three quoted sentences, in your own words: six years in retail banking, the last three as a branch supervisor; the branch's formal complaints log; training new tellers on the escalation script. End with one sentence on why this role, in your own words. Add no beat the sentences do not state. | Casual, but scored. The biography is the first consistency check against the CV, and F6 is the requirement it proves. |
| R1-A2 | "What did the supervisor role involve day to day?" | EXP | [grounded] "the last 3 as a branch supervisor" | Your message does not say what the day-to-day involved. Say it in your own words and keep to what you did. Answer slot: if you made escalation decisions as a supervisor, say which and how; if you did not make them, say who did and what you did. | Tests the depth of the supervisory claim under F6. |
| R1-A3 | "What have you been doing with digital or self-service lately?" | JD | [grounded] JD line "work with digital teams on self-service journeys" | Answer slot: if you have worked with a digital or product team on a customer-facing change, say what you did and what you decided; if you have not, say so plainly and say how you would start. No claim about your work is made here. | F8 has no evidence in your material. A casual question on a hot JD topic is scored. |
| R1-A4 | "What in this job description would you want to understand first?" | JD | [grounded] JD line "Own the member complaints process end to end across branches and the contact centre" | Pick one line and say what you would need to know to do it well, in plan language. Name nothing you have done. | Shows whether you separate what you know from what you would learn. Covers F1 by plan. |
| R1-B1 | "Why are you thinking about leaving your branch for this?" | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | Give your real reason in your own words, and tie it to something in the JD you can defend in round two. Do not invent a reason the material does not give. | A motive that does not match the CV reads as a gap. |
| R1-B2 | "The role presents to senior leaders. What is your experience of that?" | JD | [grounded] "I've never presented to anyone above regional level." | Plain acknowledgment: "I haven't presented to anyone above regional level." Then, as a plan, the first step you would take to build to it. If you have presented to your regional manager, say what that involved. Never claim senior presenting. | F7. This is the first knockout check on the requirement, and the words are yours to say truthfully. |
| R1-C1 | "When a member is upset about a charge, what is the first thing you do?" | VAL | [generic] scaffold; nearest sentence "I handled the branch's formal complaints log" | Selection scaffold: pick a real time a member was upset about a charge, and say what you did first and what you told them. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, the formal complaints log, and how you would handle it now. | Tests the first instinct on a complaint, which the Members First value is scored on. The nearest sentence is named so the honest branch has words. |
| R1-C2 | "What rules, if any, governed how your formal complaints were handled?" | JD | [grounded] "I handled the branch's formal complaints log" | Say what governed the handling, in your own words, and which part was yours. Answer slot: if nothing beyond the branch's own practice governed it, say so plainly and say what that practice was. Name no rule or timescale your material does not give you. | F2. The requirement is regulated complaints. Your material says formal, so the answer stays inside the quote. |

**Reverse questions**

1. "What happens between this screen and the Head of Member Services round?" Why it lands: it shows you are planning the loop, and the answer tells you what each round scores.
2. "Where do complaints come from today, the branches or the contact centre?" Why it lands: it reads the volume shape and shows you have already found the seam.
3. "How will the 2027 move from eight branches to five hubs shape this role?" Provenance: [grounded] "consolidate eight branches into five hubs over 2027" (your summary of the brief). Why it lands: it uses the brief, and it names the change most likely to change what a complaints lead does.
4. "What would the first thirty days look like for whoever takes this role?" Why it lands: it reveals onboarding and what they score first.
5. "What will the panel be listening for in round three?" Why it lands: a direct ask gets an honest steer, and it shows you read the round structure.

---

## Round 2: Head of Member Services (45 minutes, mostly behavioural)

**Persona weights**

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Values / behavioural | Scenario probes, STAR-shaped stories | 4 of 9 (top). The recruiter names this round as mostly behavioural, which moves values to the top. The hiring-manager prior of case-led and skeptic is adjusted down, because the case is in round three. | Map a story to each value where you can. Where you cannot, say so, then give the nearest thing. |
| Skeptic | Probing the CV gaps: no contact centre, nothing above regional, the end-to-end scope | 3 of 9 (mid). Your future manager is buying the capability and checking the gaps, so this is where the objection lands. | Rehearse the single most predictable objection until it is boring. Plain acknowledgment plus ramp. |
| Pressure / stress | Interruptions, time-boxed answers, attribution challenges | 2 of 9 (low). Not the manager's usual register, but composure still counts. | Pause, restate, hold through two follow-ups, then concede specifically. |

**Question bank**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R2-A1 | "Tell me about a time you kept hold of a complaint after it had been passed to someone else." | VAL | [generic] scaffold; nearest sentence "I handled the branch's formal complaints log" | Own the Fix. A real time: the problem stayed open, you did a named thing, and it ended in a fix or an honest close. Say who you handed it to and what you still checked. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry and how you would keep hold of a case now. | Own the Fix has no story in your material yet. The question is built from the published value. |
| R2-A2 | "When did you put a member ahead of a target or a procedure?" | VAL | [generic] scaffold; nearest sentence "trained new tellers on our escalation script" | Members First. The procedure said one thing and the member needed another. Say what you decided, who it affected and what you would do again. If no such time comes to mind, say so, then give the nearest thing: the script you trained tellers on, and what you would change about how it reaches a member. | Scored on the value, not the process. |
| R2-A3 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] persona stem; nearest sentence "I've never presented to anyone above regional level." | Hold the honest answer. If you have told a manager something unwelcome, that is the story: what you said, how, and what changed. If you have not, say so plainly, and use the plain acknowledgment: "I haven't presented to anyone above regional level." Then say how you would prepare for the first time you have to. | The answer doubles as the F7 check, so it must match your round-one answer. |
| R2-A4 | "Tell me about a time you put a customer ahead of an internal metric." | VAL | [generic] persona stem; nearest sentence "I handled the branch's formal complaints log" | Members First again, from the other side. Name the metric, what it measured, and the decision you made against it. If you have no such time, say so, then give the nearest thing. Name no metric your material does not give. Say whether the log was measured, and by whom, only if you know. | Overlaps R2-A2 on purpose: the manager tests the value from two angles. |
| R2-B1 | "Your material has no contact-centre work and no presentations above regional level. Why should we hire you for an end-to-end role across branches and the contact centre?" | JD | [grounded] "Never worked in a contact centre"; "I've never presented to anyone above regional level."; "I handled the branch's formal complaints log" | The deepest rehearsal in this pack, and the single most predictable objection. Hold through two follow-ups: say what you did do, the branch's formal complaints log, and what it covered. Concede the gaps in your own words: "I haven't worked in a contact centre," and "I haven't presented above regional level." Then the ramp, as a plan: what you would learn first and from whom. Never fold to "I'm not the right person", and never inflate to "I've run complaints across channels." | Named in the fit snapshot as the highest-ROI prep. The objection is aimed at F1, F7 and F9 at once. The second follow-up is the real test. |
| R2-B2 | "What would you do in your first thirty days on complaints across branches and the contact centre?" | JD | [generic] scaffold; no claim about you | Plan language only: what you would learn first, who you would learn it from, and what you would look at across branches before changing anything. Name no past work in the contact centre. | Covers F1 and F9 by plan. The manager scores the plan before the record. |
| R2-B3 | "How would you coach a branch supervisor who sends every escalation to head office?" | CASE | [grounded] JD line "coach branch supervisors on escalations" | Live problem. Ask what the supervisor is escalating and why before offering anything. Then the approach: the decision the supervisor keeps, and how you would check progress. Answer slot: if you have coached someone on an escalation decision, say who, what you covered and what you did not decide; if you have not, say so and say how you would start. | F3's requirement. The case asks for an approach, not a past, and the second branch keeps F3's limit. |
| R2-C1 | "Sixty seconds: why you over someone who has run a contact centre?" | JD | [grounded] "Never worked in a contact centre" | Pressure. Pause, restate the question in your own words, and anchor in what you did say: the branch's formal complaints log. Hold through two follow-ups without defending past the record. Concede specifically: "I haven't worked in a contact centre." Do not fold to "you're right, I'm not the person for this." | F9 and F7 under a composure test. The concession is the honest line. |
| R2-C2 | "That complaints spreadsheet: how much of it was actually you?" | EXP (JD content) | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Pressure on attribution. Hold: you built it. Say what it counted and what you chose to include. Say what the regional manager asked for, only if you know. Name the tool and the functions you used in it, in your own words. If you did not choose what it counted, say so and say who did; do not fold to "it was mostly the manager's" unless that is true. No headline figure is on file, so no defend-the-number slot applies yet. | F4 and F5 under pressure. Also covers the JD's monthly reporting and Excel requirements, without naming Excel as yours. |

**Reverse questions**

1. "What does a good first six months look like for this role?" Why it lands: it shows what you will be scored on first.
2. "Which complaint measure do you look at first, and what does it tell you?" Why it lands: it reveals the number the manager trusts, and you can check your spreadsheet against it.
3. "How do branch and contact-centre complaints reach you today?" Why it lands: it maps the seam before the panel does.
4. "How do you expect the move to digital to change what complaints look like?" Provenance: [grounded] "move 40% of member service to digital channels by 2028" (your summary of the brief). Why it lands: it uses the 2028 target as the employer's own number.
5. "What would make you say at the end of the year that this was the right hire?" Why it lands: it is the closing ask, and the answer is the manager's scoring rubric in their own words.

---

## Round 3: panel of two branch managers (60 minutes, values-scored, with a 20-minute case)

This round is the values round. The recruiter's email names it that way, which is why the values cheat sheet sits here.

**Persona weights**

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Values / behavioural | The panel scores you against the four values | 4 of 10 (top). A loop source names this round as the values round. | One real instance per value, or the honest branch. Plain words in the room. |
| Peer Evaluator | Seam questions between branches and the contact centre, credit-sharing, what a new lead would need from them | 3 of 10. Branch managers are peers in the network this role coordinates. The panel is blended because their names are not known. | Reciprocity framing. Propose seam principles, not pretend knowledge. |
| Case / Strategist | The 20-minute escalation case | 3 of 10. It is a live problem from the role. | Clarify, then act, then find the cause, then escalate, then record. Think aloud. |
| Data-Driven Prober | Would probe the reporting figures | Not weighted. No loop source names a reporting probe for the panel. The spreadsheet question stays in round two (R2-C2). | Not applicable this round. |
| Skeptic | Would press the gaps | Not weighted. Round two holds the objection, so the panel gets a seam question instead. | Not applicable this round. |

**Question bank**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R3-A1 | "Tell me about a time you decided something from the member's side of the counter when the process pointed the other way." | VAL | [generic] scaffold; nearest sentence "I handled the branch's formal complaints log" | Members First. A real decision, your part in it, and the member's outcome. If none comes to mind, say so plainly, then give the nearest thing: the formal complaints log. Do not describe a decision you did not make. | The panel's first scored value. No story exists in your material yet. |
| R3-A2 | "Tell me about a time a member needed something explained twice. What did you change?" | VAL | [generic] scaffold; nearest sentence "trained new tellers on our escalation script" | Plain Words. The published line is: if a member needs it explained twice, we wrote it wrong. Say what you changed in the explanation or the script, and how you knew it had worked. If no such time comes to mind, say so, then give the nearest thing: the script training, and what you would change about how it is explained. | Plain Words is scored on the language you use in the room, so answer in plain words. |
| R3-A3 | "What do you know about the town a branch serves, and how has that changed what you did?" | VAL | [generic] scaffold; no sentence in your material carries this value | Neighbours, Not Numbers. Describe one thing you knew about a town's needs and what you did with it, if that happened. If not, say so plainly, then say what you would find out first about a town before changing a branch's complaint handling. Do not claim local knowledge you have not described. | No quoted sentence of yours speaks to this value, so the honest branch is the answer. Say it plainly. |
| R3-A4 | "When did you find a problem nobody had asked you to look at, and what did you do with it?" | VAL | [generic] scaffold; nearest sentence "I handled the branch's formal complaints log" | Own the Fix. The problem you found, the thing you did, and whether it was solved or honestly handed on. If none, say so, then give the nearest: the log, and what you would look for in it first. | Overlaps R2-A1 by design. The panel asks for a second instance. |
| R3-B1 | "Where is the seam between a branch and the contact centre on complaints, and what happens when the two disagree about who owns a case?" | JD | [grounded] "Never worked in a contact centre"; [generic] seam principles | Propose a principle rather than pretend to know the seam: one named owner per complaint, who stays with it until the member has an answer. Plain acknowledgment: "I haven't worked in a contact centre." Then what you would ask the contact-centre lead first. | Peer persona: partnership fit. The principles are proposed, not claimed as past practice. |
| R3-B2 | "How do you handle credit when a complaint is fixed by someone else's team?" | VAL | [generic] scaffold | Reciprocity framing: what the fix did for the member, who did the work, and what you would say to them. Keep credit with the people who did the work. Do not describe a past instance unless you have one. | Peer persona: a credit-sharing probe, tested through Own the Fix. |
| R3-B3 | "What would you need from the branches to take this on well?" | JD | [generic] scaffold | Plan language: what you would ask each branch manager for in the first month, and what you would offer back. Name nothing you have already done with a branch. | The panel asks what the role would take from them. A clear reciprocal answer scores as partnership. Covers F1 by plan. |
| R3-C1 | "A member says a fee was taken twice. It has sat in one branch for three weeks, and the member has said they will take it further. Walk us through the next hour." | CASE | [generic] | Structure: clarify (what the member has been told, who holds the case, whether an outside route has a clock); act now (own it, call the member in plain words, confirm the double charge is checked); find the cause (one branch or a process, and who can say); escalate to the owner with the facts on one page; then record and report. Think aloud and name one assumption you are making. Make no past claims. | The twenty-minute case, scored on structure before answer. Covers the escalation requirement and Own the Fix in one live problem. |
| R3-C2 | "What would you say to the supervisor who has been holding this one?" | JD | [grounded] JD line "coach branch supervisors on escalations" | Plan language. Ask what is holding the case before you direct it, agree the decision the supervisor keeps, and set a check date. Name no past coaching. | Second part of the case block. Tests the coaching requirement. |
| R3-C3 | "Digital is meant to take forty percent of member service by 2028. Which complaints grow as that happens, and what would you change first?" | CO | [grounded] "move 40% of member service to digital channels by 2028" (your summary of the July 2026 brief) | Differentiate from the obvious answer. One thesis, one uncertainty you would test first, and one thing you would not change. Attribute the figure to the brief, not to yourself. | The strategy question. The panel will check whether you read the brief, and the concession is what makes the answer credible. |

**Reverse questions**

1. "What could a new person do in their first month that would genuinely help your branches?" Why it lands: it is the reciprocity question for a peer panel. It shows you think of them as partners.
2. "Where do branch and contact-centre teams see the same complaint differently today?" Why it lands: it names the seam from their side.
3. "What is the hardest value to keep on a busy day in your branch?" Why it lands: it gives you the honest version of the values, and shows you take all four seriously.
4. "What would a good first coaching conversation with a branch supervisor look like to you?" Why it lands: it tells you the coaching standard before you are judged on it.
5. "How does your branch know a complaint has been resolved well, not just closed?" Why it lands: it asks for their measure of resolution without naming a figure.

**Values cheat sheet**

The four values are paraphrased below. The official names are used as published.

| Value (official name) | Working meaning (paraphrased) | Mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter. | No mapped story. No quoted sentence of yours carries one. Scaffold: R3-A1 and R2-A2. Nearest sentence: "I handled the branch's formal complaints log." Honest branch: say so plainly, then the nearest thing. |
| Plain Words | If a member needs it explained twice, we wrote it wrong. | No mapped story. Scaffold: R3-A2. Nearest sentence: "trained new tellers on our escalation script." |
| Neighbours, Not Numbers | Every branch is part of its town. | No mapped story. Scaffold: R3-A3. The honest branch is the answer, since no sentence of yours speaks to a town. |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved. | No mapped story. Scaffold: R2-A1 and R3-A4. Nearest sentence: "I handled the branch's formal complaints log." |

The headline: you have no mapped values story yet. Find one real decision for each value before Friday (prep triage, step 2).

---

## Sources and target accounting

**Provided documents:** the JD text; the values copy from ashgrovecu.org/about/values (copied 11 November 2026); the recruiter's round email; the July 2026 strategy brief, as summarised in your message and not pasted; your background as written in your message (no CV). No dossier was present.

**Research tier: L1, searches 0 of 6, fetches 0 of 2.** No call was sent: every L1 target is already fixed by the inputs above.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | The values cheat sheet. The pasted values copy fixes the four names and wording. |
| 2. Ashgrove interview process, member services | skipped | The loop structure. The recruiter's email fixes the three rounds, their lengths and the panel's role. |
| 3. Ashgrove strategy and recent news | skipped | The grounding brief and R3-C3. Your summary of the July 2026 brief supplies the current priorities. The brief itself was not pasted. |
| 4. Interviewer name | n/a | No names are assigned, so no query could be formed. The upgrade menu says what a name would unlock. |
| 5. Representative JD for the title | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions. |

## Upgrade menu

- The Head of Member Services' name and the two branch managers' names → persona weights per panel member, an interviewer read, and one tailored reverse question each.
- Your monthly complaints spreadsheet's column headings, with no customer details → the defend-the-number slots for R2-C2 and F4, and an honest answer on what it counted.
- Any figure from that spreadsheet, such as a monthly volume → defend-the-number slots, with the weakest assumption named by you.
- The July 2026 strategy brief, pasted → a grounding brief from the source instead of your summary, and each figure in R1, R2 and R3 checked against it.
- A CV → the fit snapshot quotes it directly, and the medium rows can be checked against an inspectable line.
- Any work with a digital or product team → upgrades F8, R1-A3 and R3-C3 from discovery to a grounded story.
- Any time you held a line with someone senior, or changed a process → upgrades R2-A1, R2-A3, R3-A1 and R3-A4 from scaffold to story.
- Whether the twenty-minute case comes with written material or data, from the recruiter → the case bank in R3-C1.
- Deep research (L2), offered once: four further targets (the strategy brief, interviewer talks and writing, role-family loop reports, recent organisation news), at most 6 further searches and 2 further fetches. Run only on your consent.
- A tuesday-dossier.md, offered once: it would carry the gaps this prep exposes into later sessions, without making the pack depend on it.
