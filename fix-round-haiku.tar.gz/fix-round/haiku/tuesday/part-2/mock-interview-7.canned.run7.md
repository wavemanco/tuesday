Tool's loaded. Running the L1 research now: company values, interview process, recent news, and the interviewer's public footprint.
Your prep pack is saved as `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-tuesday-part-2-rooms-case-7-canned-7f531323/64187255-3a21-4505-a77b-11947271580b/scratchpad/saltmarsh_live-operations-producer_interview_pack.md`, and I've sent it to you as an attachment. I built it for the Outage Hour, the 60-minute session Saltmarsh's careers page describes: a live-incident tabletop, then a values conversation with the hiring manager. I've assumed Tobias is that hiring manager.

The main things to know before Friday:

- **Your biggest gap is leadership.** Question C1 ("You've never led a team. Why would we hire you?") is the one most likely to come up. The pack gives you a hold-then-concede structure for it, and it's worth rehearsing first.
- **Coordination is the other thin spot.** The JD asks you to coordinate design, art, engineering and community on each update. Your message doesn't show which teams you worked with, so the pack asks you to say so plainly rather than describe something you didn't do.
- **Use the talk and the values.** Tobias gave a GDC 2026 talk, "Patch Notes Are a Promise". Your release checklist (the one QA still uses) is your strongest link to that theme, and the values "Ship the Patch Not the Promise" and "Leave the Build Greener" both map to it.
- **Don't overstate.** The pack lists the stretched versions it won't coach, such as "owned the KPIs" or "live-service". Your material says you presented the retention numbers and wrote the checklist, and that is how to describe them.

Two things I couldn't fully verify: the Project Larkspur news and Tobias's talk both came from search snippets, and I didn't open those pages.

I can run a live drill on C1, the Skeptic question, and I can save a `tuesday-dossier.md` recording the gaps this prep exposed. If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh_live-operations-producer_interview_pack.md -----
# Interview prep pack: Live Operations Producer, Saltmarsh Games

Interviewer: Tobias Wrenfield, Head of Live Operations (treated as the hiring manager for this session; the loop source describes the Outage Hour as "a single 60-minute interview with the hiring manager")
Round: Outage Hour, 60 minutes: a live-incident tabletop, then a values conversation
Candidate: Femi (they/them)

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored.

| Type | Meaning |
|---|---|
| VAL | Behavioral and values: does past behavior show the published values |
| EXP | Experience deep-dive: do your claims survive scrutiny |
| JD | Role-driven: can you do the listed job, gaps included |
| CO | Company knowledge: current strategy and recent moves |
| CASE | Live problem: structure and reasoning on a problem from this role |

Guidance is scaffolding, not a script. Rehearse what you did, in your own words.

## Fit snapshot

Requirements are quoted from the JD. Evidence is quoted from your message. No JD requirement is a gate (the 3+ years line is a length of experience, graded like any other requirement).

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material describes a weekly content-drop calendar for one title. It does not mention live events or a second title. Words: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: if you planned any live event, or a calendar for a second title, say which and what you decided; if you did not, say so and stay with the one calendar. |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | none given | none | [grounded] | discovery | Nothing in your material shows which teams you worked with on an update. Answer slot: name who you worked with on a drop and what each team needed from you, in your own words; if no team beyond your own was involved, say so. |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | presentation | The sentence reaches the KPI reporting in other terms. Words: "I presented the monthly retention numbers to the studio head." The bridge rewords only that sentence. It does not show that you chose the KPIs or owned them; do not say that unless it is true, and if someone else chose them, say who. |
| F4 | "own the post-event review and the KPIs it reports" — JD | none given | none | [grounded] | discovery | No sentence in your material mentions a post-event review. Answer slot: if you ran a review after a content drop or event, say what it covered and what it changed; if none was run, say so and say how you would set one up. |
| F5 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | none | No gap; the sentence reaches the requirement. Words: "I wrote the release checklist our QA team still uses." Expect a probe on what it checks. Keep "wrote" and "still uses"; do not say you manage it unless you do. |
| F6 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message | medium | [grounded] | transferability | Words: "four years as an associate producer at a puzzle-game studio." Your material does not say the game was live-service, so do not call it that. Answer slot: if the game ran on events or drops with a retention model, say what that involved, in your own words. |
| F7 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | No gap; the sentence reaches the requirement. Expect a probe on how each drop was approved; answer in your own words. |
| F8 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | none | No gap at the level of the sentence. Expect a probe on how retention was defined. Say the definition you used if you know it; if you did not set it, say so. |
| F9 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | low | [inferred] | discovery | The checklist is one written artifact that another team uses; your material shows no other writing. This is a lead, not a claim. Answer slot: if you can recall a written update that changed a decision, say what it said and who acted on it. |

Gap types above are chosen from the evidence cell, not from how the row feels. Confidence is set by what can be inspected, so every `medium` row is one a probe can test.

## Prohibited claims

Not coached, with basis and honest form. The first four are stretched forms of sentences you wrote; the last two are things you stated about yourself.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the KPIs or chose the retention metrics | Inflated form of F3 | F3's quote at its own scope. The pack's observation, in analysis only: the material says you presented the numbers, not that you owned the KPIs. |
| Ran live events, or a calendar across two titles | Inflated form of F1 | F1's quote at its own scope. |
| Produced live-service games | Inflated form of F6 | F6's quote at its own scope. The material does not say live-service. |
| Owned the release checklist | Inflated form of F5 | F5's quote with "wrote" and "still uses". |
| Led a team | Negative you stated ("Never led a team") | Plain acknowledgment: "I haven't led a team." No slot. |
| Worked on in-app purchase economics | Negative you stated ("never worked on a game with in-app purchases") | Plain acknowledgment: "I haven't worked on a game with in-app purchases." No slot. |

## Reading the interviewer

Public footprint only.

- Career pattern: a search result describes Tobias Wrenfield as Head of Live Operations at Saltmarsh Games, previously a QA lead at a console studio. This came from a search snippet; the talk page was not opened.
- Published talk: "Patch Notes Are a Promise" (GDC 2026). The snippet gives its argument as: a live team is judged by how often its patch notes describe what actually shipped.
- Implications:
  1. Expect the release checklist (F5) and the gap between what shipped and what was announced to be probed. B2 and B3 are the highest-value answers to rehearse.
  2. Do not claim QA expertise you have not stated. F5 is the only QA-adjacent evidence.
  3. Give your answers in the talk's own terms (announced versus built) only where you have a sentence to back them.
- Mirror opportunity (shared professional area, not a shared jump): both of you have worked on release checks with QA. F5 carries your side: "Wrote the release checklist our QA team still uses." Use it as a professional link, not as affinity.

## Persona table

Relationship prior: a hiring manager, so Case/Strategist and Skeptic start up. The loop source adds a live-incident tabletop (Case and Pressure) and a values conversation (Values/Behavioral). The first-round conversational opener is folded into the Values bank rather than given its own persona.

| Persona | How it shows up in this loop | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| A. Case/Strategist | Live tabletop: a simulated outage during a live event, plus a live problem on the calendar | 5 questions. The loop source names the tabletop as the session's main content, so it carries the most weight. | Clarify, stop the damage, decide, communicate, then record for review. Think aloud. |
| B. Values/Behavioral | Values conversation tied to the published values | 4 questions. The loop source documents a values conversation, so a values-style round is detected. | STAR-shaped stories; state what you did. Use a selection scaffold where your material has no story. |
| C. Skeptic | Probes the gaps: no team leadership, no coordination evidence, no in-app purchase experience | 3 questions. The gaps F2, F4, F6 and F9 are the ones a hiring manager will test. | Rehearse the single most likely objection until it is boring: hold, then concede exactly what you have not done. |
| D. Pressure | Time-boxed challenge to the calendar, the retention work, and why you over someone with live-service experience | 3 questions. The tabletop is time-boxed, and the talk makes checklist-versus-release a live theme. | Pause, restate, hold through two follow-ups, concede specifically. |
| E. Data-Driven Prober | Asks how the retention numbers were defined and counted | 3 questions. F8 is the only metric evidence; the probe will go to its definition. | Say the definition if you know it. If you did not set it, say so. Name the weakest assumption you know. |

## Question banks

### A. Case/Strategist (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A live event goes wrong about forty minutes after launch. Walk me through the next hour." | CASE | [generic] | Clarify scope and severity first. Stop the damage before you diagnose: pause, roll back, or hold the event. Name who you bring in (design, engineering, QA, community) and what each does. Decide what players hear and when. Write down the decision points so they can go into the review. | The Outage Hour's tabletop. [generic]: a structure for a live incident, with no claim about this studio's systems. |
| A2 | "The next patch is due in two days and QA has found a crash on one device family. Ship, delay, or ship with a notice?" | CASE | [generic] | Name the severity, the share of players affected, and what the team has already promised. Give a recommendation and the one fact that would change it. Tie the answer to announcing what is built, not what is hoped. | A live tradeoff from the loop source's theme. [generic]: the reasoning pattern, not this studio's policy. |
| A3 | "Retention dropped in week two of an event. Diagnose it." | JD | [generic] | Fix the metric definition first. Then split the drop by cohort, by device, and by what changed in the same window. Say what you would rule out before you name a cause. | Covers F8 as a live problem rather than a past claim. [generic]: no claim about your history. |
| A4 | "Saltmarsh's news says one shared events calendar runs from February 2027. How would you plan its first quarter?" | CO | [grounded] "one shared events calendar from February 2027" (saltmarshgames.com/news, research); [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | Plan the quarter around a weekly rhythm, since that is what you ran for two years. Name the two titles' dependencies and the one date you would not move. Answer slot: if you have planned across two titles before, say how; if not, say so and say what the weekly rhythm does and does not carry over. | Covers the JD's two-title line with current strategy. The news is research, not a presupposition the candidate must accept. |
| A5 | "Write the three-line player notice for a patch that is slipping by a week." | JD | [generic] | Lead with what changes and when. Say what players can do now. Make no promise you cannot keep. Read it aloud once, then cut any sentence that promises an unbuilt feature. | Covers "clear written communication" with a live writing task. [generic]: a writing pattern, no claim about you. |

### B. Values/Behavioral (4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time a calendar and the players disagreed." | VAL | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Selection scaffold, since no sentence carries a player-versus-calendar decision: pick a time a drop had to move for players, or a time you wanted to hold a date and the players pushed back. Give the stake and what you decided. If no such time comes to mind, say so plainly, then give how you decided what moved in the weekly calendar. | Values round, Players Before Plans. F7 is the nearest evidence. |
| B2 | "Tell me about a time you announced something before it was finished." | VAL | [grounded] "Wrote the release checklist our QA team still uses." | Selection scaffold: a time a note or announcement went out early, or a time you held one back. Give the stake and the outcome. If none comes to mind, say so, then say what the checklist required before anything went out, if it did; if it did not gate announcements, say that. | Values round, Ship the Patch Not the Promise. The talk's theme. Highest-value values answer. |
| B3 | "When did you leave a release better than you found it?" | VAL | [grounded] "Wrote the release checklist our QA team still uses." | Story map from F5: you wrote the checklist; QA still uses it. Answer slot: if you changed it after a release, say what changed and why; if it was never revised after you wrote it, say so. Do not claim it improved anything you did not measure. | Values round, Leave the Build Greener. |
| B4 | "Walk me through your path to here." | Opener | [grounded] "4 years as an associate producer at a puzzle-game studio." · "Presented the monthly retention numbers to the studio head." | A 90-second arc with four beats, each a sentence you wrote: four years as an associate producer on a puzzle game; the weekly calendar for the main title; the checklist QA still uses; the monthly retention presentation. Stop there; do not add a beat you did not write. | Rapport opener. Scored like any question: the arc is where the JD's requirements first surface. |

### C. Skeptic (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You've never led a team. Why would we hire you to run this group?" | JD | [grounded] "Never led a team" (your message) | Highest-ROI prep in this pack. Hold: "I haven't led a team." Then describe what you did run: the weekly calendar and the release checklist, in those words. Hold through two follow-ups. Concede plainly: "Coordinating design, art, engineering and community on an update is the part I have least direct evidence for, and I'd want to learn it fast." | The likeliest objection, since the JD's coordinate-and-own lines sit next to a stated gap. Its premise is a negative you stated, so it may be asked. |
| C2 | "Tell me about the teams you worked with on an update, or the closest you got." | JD | [grounded] F2 evidence: none given. Raising source: the JD line "coordinate design, art, engineering and community teams on each update" | Open prompt. Answer slot: name who you worked with and what each needed from you, in your own words. If no team beyond your own was involved, say so, and do not describe a coordination you did not do. | F2's discovery gap. The question asks for an instance; it does not supply one. |
| C3 | "You haven't worked on a game with in-app purchases. What would you read first?" | JD | [grounded] "never worked on a game with in-app purchases" (your message) | Plain acknowledgment: "I haven't worked on a game with in-app purchases." Then name the first thing you would read on a purchase-driven title, as a plan, not a past. | The premise is your own negative, so it is asked. The answer is a plan, not a claim of experience. |

### D. Pressure (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over someone who has run a live-service title?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Hold: two years of weekly drops on one title, in those words. Hold through two follow-ups. Concede specifically: "I can't claim live-service title experience from what I've done. What I'd bring is the calendar and the checklist." Do not argue the category. | Tests composure on the F6 gap. |
| D2 | "The monthly retention numbers you presented: who produced them?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Answer in your own words. If you pulled the numbers, say so and what you did with them. If someone else pulled them, say who and what you did with them. Answer slot: whichever is true; do not claim the analysis if it was not yours. | Attribution test for F3. A premised question, but it presupposes only the presentation the sentence states. |
| D3 | "Tell me about the last thing the release checklist caught, or missed." | JD | [grounded] "Wrote the release checklist our QA team still uses." | Answer slot: if you know a catch or a miss, say what it was and how you learned of it. If you do not know, say so, and say how you would find out. Do not invent a catch. | F5 under pressure. Open prompt; the answer must be a real instance. |

### E. Data-Driven Prober (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "How was retention defined in the numbers you presented?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Answer slot: if you know the definition, state it. If you did not set it, say so and name who did. Do not supply a definition you cannot repeat under a second question. | F8. The prober's first question on any metric. |
| E2 | "What would you check before trusting a post-event KPI?" | JD | [generic] | Name the denominator, the time window, and what else changed in the same window. Say what you would not trust without a second source. | Covers the JD's post-event review and KPI line. [generic]: a practice for the role, with no claim about your history. |
| E3 | "Which assumption behind a retention number you presented would you defend least?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Answer slot: name the assumption you know of, or say you do not know how the number was counted. Then say which part of the number was yours. | Weakest-assumption move for F8. No figure was given, so the defend-the-number slots apply only as far as the sentence goes. |

## Requirement coverage

| JD requirement | Questions |
|---|---|
| "Plan and run the live-events calendar for two of our mobile titles" | A4; F1 |
| "coordinate design, art, engineering and community teams on each update" | C1, C2; F2 |
| "own the post-event review and the KPIs it reports" | E2, E1; F3, F4 |
| "manage the release checklist with QA" | B2, B3, D3; F5 |
| "3+ years producing live-service games or apps" | D1; F6 |
| "experience running a content calendar" | B1, B4; F7 |
| "comfortable with player-retention metrics" | A3, E1, E3; F8 |
| "clear written communication" | A5; F9 |

Session total: 18 questions (A5, B4, C3, D3, E3).

## Values and principles cheat sheet

Values are from the official page (saltmarshgames.com/values). Stories come from your sentences only; where none carries one, the entry is a selection scaffold with its honest branch.

| Value (official name) | Working meaning | Mapped story |
|---|---|---|
| Players Before Plans | When the calendar and the players disagree, the players win. | No sentence carries it. Scaffold (B1): a time a drop moved for players. If none, say so, then give how you decided what moved in the weekly calendar (F7). |
| Ship the Patch Not the Promise | We announce what is built, not what is hoped. | F5, "Wrote the release checklist our QA team still uses." Scaffold (B2): what the checklist required before an announcement, if it did. If it did not gate announcements, say so. |
| Leave the Build Greener | Every release leaves the codebase and the checklist better than it found them. | F5. Scaffold (B3): whether you changed the checklist after a release, and what. If it was never revised after you wrote it, say so. |

## Reverse questions

Five, each with why it lands.

1. "Your GDC talk argues that a live team is judged by how often its patch notes describe what shipped. How does the team check that before a live event?" Why it lands: it shows you read the talk, and it turns the Skeptic conversation into a peer one.
2. "You came up through QA before running live operations. What did you change first when you took the role?" Why it lands: it asks about their own path, which converts a probe into a conversation.
3. "The Project Larkspur announcement folds per-title event teams into one live-ops group. Which part of that handover is hardest?" Why it lands: it shows you read the company's current news, and asks where the role's real work sits.
4. "At the end of the Outage Hour, what separates a strong answer from an adequate one?" Why it lands: it shows you know it is scored.
5. "What would the first month look like for someone on the events calendar for two titles?" Why it lands: it makes the JD concrete and gives you the onboarding picture to answer against.

## Sources

Research tier: L1 — searches 4 of 6, fetches 2 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | yes | Values cheat sheet: three values by name, fetched from saltmarshgames.com/values |
| 2. `Saltmarsh Games interview process Live Operations Producer` | yes | Loop established: recruiter call, then the Outage Hour (60 minutes, hiring manager, a live-incident tabletop, then a values conversation, no take-home). Fetched from saltmarshgames.com/careers/interviewing. Persona weights follow the named rounds. |
| 3. `Saltmarsh Games mobile studio news strategy` | yes | Current strategy: Project Larkspur (September 2026) puts Tidepool Tactics and Lantern Row on one shared events calendar from February 2027 and folds per-title event teams into one live-ops group. From a search snippet on saltmarshgames.com/news; not fetched. Moved A4 and reverse question 3. |
| 4. `Tobias Wrenfield Saltmarsh Games Head of Live Operations` | yes | Interviewer read: role and previous QA-lead background, and the GDC 2026 talk "Patch Notes Are a Promise". From a search snippet; the talk page was not opened. Moved the interviewer read and persona weights. |
| 5. representative JD | skipped | The JD supplied by the user fixes the fit snapshot and the JD-tagged questions. |

Provided documents: the JD and your message.

## Upgrade menu

- Notes or a written KPI report from any post-event review you ran → F4 becomes a grounded row; F3 gets its bridge
- A written sample (a player notice, a patch note, a post-event summary) you wrote → F9 becomes [grounded] rather than [inferred]
- The titles and calendar you ran, in one line each → F1 and F6 gain their missing detail
- The recruiter's confirmation that the session is the Outage Hour with the hiring manager → the loop line gains a second source
- A deeper research pass (L2): up to 6 more searches and 2 more fetches, several more minutes, for the full Larkspur strategy brief, the interviewer's talks, and role-family loop reports. Want it?
