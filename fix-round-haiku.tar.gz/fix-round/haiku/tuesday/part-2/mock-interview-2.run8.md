I couldn't run company research: both web searches were refused for permission, so the pack relies on your message and the JD alone. I'll write the pack now and note that in the Sources section.
Your prep pack is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-tuesday-part-2-rooms-case-2-denied-c2ca2b4e/6fe6e99a-ebe4-4504-8adf-c94487d0fec3/scratchpad/atlas_freight_operations_manager_interview_pack.md`. I built it for a hiring-manager round, since your note didn't say who you're meeting. I could not research Atlas Freight: both web searches were refused permission, so the company's values and interview process are unknown.

**Where the interviewer will press hardest**

- **Scale.** Your material shows three supervisors on one shift. The JD asks for twelve supervisors across four sites. Expect this first. Prepare a plan for the bigger structure, and don't stretch the three.
- **Cost and on-time performance.** Your 40% result is a mis-pick (accuracy) number. The JD asks for on-time performance and cost-per-shipment. Be ready to say what you measured, and what you would measure first.
- **The 40% figure.** Expect "how was it counted?" and "how much of that was you?" Know the baseline and the volume. If you don't know how it was counted, say so.
- **Power BI.** Say "I haven't used Power BI," then give a concrete plan for learning it. Don't imply any Power BI work.
- **Leadership years.** Seven years in operations is not the same as seven years leading people. Know how many of those years had direct reports.

**What to avoid**

Don't describe the pick-path redesign as multi-site work, don't claim you designed the peak plan from scratch (you "ran" it), and don't go beyond your green belt when asked about Lean.

**Strongest material**

Your 40% mis-pick reduction, the peak-season plan run two years running, and the green belt are your best evidence. Bring the green belt certificate.

**Drill and dossier offers**

- I can play the Skeptic on the scale question (A1 in the pack), the one most likely to come up. Say the word and we'll run it.
- I can save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions.
- I can convert the pack to a Word document if you want one.

**Two questions**

1. Is the person you're meeting your future manager, a peer, or a panel? The answer changes the weighting of the banks.
2. How much prep time do you have before the round? I can then order the pack into a schedule.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: atlas_freight_operations_manager_interview_pack.md -----
# Atlas Freight — Operations Manager — Interview prep pack

**Company:** Atlas Freight (regional logistics, about 800 employees)
**Role:** Operations Manager, four sites
**Interviewer:** not named
**Round:** not stated. Built as a **hiring-manager round** (assumed); persona weights below change if it is a peer, panel or recruiter screen.

## How to use this pack

Personas describe how a question arrives. Types describe what is being scored.

| Type | Meaning |
|---|---|
| VAL | Values or behavioral alignment |
| EXP | Your experience, tested for attribution and honesty |
| JD | The job's stated responsibilities and qualifications, gaps included |
| CO | Company and strategy knowledge (not covered: no research ran) |
| CASE | A live problem from the role |

Guidance is scaffolding, not a script. Rehearse in your own words, and only what you did.

## Fit snapshot

Requirements are quoted from the JD. Evidence is quoted from your message, verbatim. Nothing here is a claim about your past beyond those quotes.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" (JD) | "7 years in warehouse and distribution ops" (your message); "currently a senior shift manager over 3 supervisors" (your message) | medium | [grounded] | transferability | Your material shows one site's shift, not daily ownership across four. Say the shift you run in those terms. Answer slot: if you have run daily operations across more than one site, say what and how; if not, say so and describe how you would set a daily cadence across four. |
| F2 | "lead a team of 12 supervisors" (JD) | "currently a senior shift manager over 3 supervisors" (your message) | medium | [grounded] | transferability | Three is the number your material gives. Do not stretch it to twelve. Answer slot: if you have set priorities or cadence across more than three supervisors, say how; if not, say so and say how you would split twelve across four sites. |
| F3 | "drive on-time performance and cost-per-shipment down" (JD) | "cut mis-pick rate 40% by redesigning the pick path" (your message) | medium | [grounded] | transferability | The quote is an accuracy result, not on-time or cost-per-shipment. Say the 40% in its own terms. Answer slot: if you measured on-time or cost per shipment for any change, say what; if not, say so and name the measure you would start with. |
| F4 | "build reporting in Excel/Power BI" (JD) | "solid Excel" (your message) | medium | [grounded] | transferability | The quote reaches the tool, not reporting others relied on. Answer slot: if you built a report someone else used, say what it tracked and who used it; if not, say so. |
| F5 | "build reporting in Excel/Power BI" (JD) | "never used Power BI" (your message) | none | [grounded] | capability | Words: "I haven't used Power BI." Then how you would learn it, stated as a plan, never as a past. No claim of Power BI work. |
| F6 | "5+ years operations leadership required" (JD) | "7 years in warehouse and distribution ops" (your message) | medium | [grounded] | discovery | Your material gives seven years in operations, not how many as a leader. Answer slot: say how many of those years you had people reporting to you, in your own words. |
| F7 | "Lean/Six Sigma a plus" (JD) | "green belt certified" (your message) | medium | [grounded] | none | The quote already reaches the requirement. The certificate is inspectable; bring it. |
| F8 | "Own daily terminal operations across 4 sites" (JD) | "ran the site's peak-season surge plan two years running" (your message) | medium | [grounded] | transferability | Planning under surge on one site. Say it at that scope, not as multi-site ownership. |

No requirement in the JD is a hard gate. "5+ years" is a length-of-experience requirement, graded on fit like the rest.

## Prohibited claims

What this pack will not coach, and the honest form of each.

| Not coached | Basis | Honest form |
|---|---|---|
| Ran operations across 4 sites, or led 12 supervisors | Inflated form of F1 and F2 | "I run a shift over three supervisors on one site." The limit is the pack's observation: your material shows one site and three supervisors. |
| Drove on-time performance or cost-per-shipment down | Inflated form of F3 | "I cut mis-pick rate 40% by redesigning the pick path." |
| Designed or built the peak-season plan from scratch | Inflated form of F8 ("ran") | "I ran the site's peak-season surge plan two years running." |
| Power BI experience of any kind | Negative you stated, F5 | "I haven't used Power BI." No slot. |
| Six Sigma practice beyond the green belt | Inflated form of F7 | "I'm green belt certified." |

## Persona weights

| Persona | Weight | Why |
|---|---|---|
| Skeptic | 5 questions | Hiring managers buy capability and derisk gaps; F1, F2, F3 and F5 are where your material is thin. |
| Data-Driven Prober | 3 | The 40% figure will be tested for how it was counted. |
| Case / Strategist | 3 | Hiring managers pose live problems on their own roadmap. |
| Pressure | 2 | Senior operations interviews often time-box answers. |
| Conversational | 2 | Casual openers carry scoring, including the Lean question. |
| Peer Evaluator | 2 | Likely if any panel member runs a site. |
| Values / Behavioral | 2 | No values-style round detected (no loop source ran), so this stays low weight. |

The weights rest on a round-type prior, not on Atlas's documented interview process, because that research did not run.

## Question banks

Provenance comes first. Quoted sentences are yours; "[generic]" marks a pattern, not a fact about you or Atlas.

### A. Skeptic (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Your material shows three supervisors on one shift. How would you run four sites with twelve?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" (your message) | Name the three in your own words, then the structure you would use for twelve, stated as a plan. Answer slot: if you have set cadence or priorities across more than three supervisors, say how; if not, say so and say what you would do first. Hold through two follow-ups by returning to the three and the plan. | **Highest-ROI prep in this pack.** F2 is the largest gap and this objection will come in some form. Deepest rehearsal here. |
| A2 | "What have you run across more than one site?" | JD | [grounded] "ran the site's peak-season surge plan two years running" (your message) | Give the surge plan at its one-site scope. Answer slot: if you have run daily work across sites, say what and how; if not, say so and describe the cadence you would set. | F1 at its own scope. |
| A3 | "On cost-per-shipment, what have you moved, and how do you know?" | JD | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | The 40% is an accuracy result. Answer slot: if you tracked cost or on-time for any change, say what; if not, say so and name the first measure you would use. | F3's thin bridge, rehearsed so the honest answer is ready before the probe. |
| A4 | "Tell me about a report you have built that someone else relied on." | EXP | [grounded] "solid Excel" (your message) | Answer slot: if you built one, say what it tracked and who used it, in your own words; if not, say so and say what you would build first. | Open prompt: it chooses an instance and presupposes none. F4. |
| A5 | "The role asks for Power BI reporting. What is your plan?" | JD | [grounded] "never used Power BI" (your message) | Say "I haven't used Power BI." Then the learning plan as a plan. No claim of past work. | F5 is a stated gap; the plan carries it. |

### B. Data-Driven Prober (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Walk me through how that 40% was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Answer slot: say how the mis-pick count was taken, in your own words. If you do not know how it was counted, say so. | Defend-the-number slot. Do not supply a baseline or method. |
| B2 | "Which assumption behind that figure would you defend least?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Name the assumption you are least sure of before they find it. If you cannot name one, say the count is the thing you would check. | Weakest-assumption move, required for any headline figure. |
| B3 | "How much of the 40% was your redesign, and how much was volume or staffing?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Answer slot: if you can separate the effects, say how. If you cannot, say so and name what you would use to isolate them. | Attribution probe. Hold only what you did: the redesign. |

### C. Case / Strategist (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "One site's cost-per-shipment has risen. Walk me through how you would diagnose it." | CASE | [generic] | Clarify, then objective, then segmentation (shift, lane, volume, labor hours), then approach, then metrics, then risks. Think aloud. | Live problem from the role. Makes no claim about your past. |
| C2 | "Four sites, one on-time target. How would you stop the sites competing on the wrong number?" | CASE | [generic] | Name what each site controls, how the target is split, and how you would check the target is measuring the right thing. | Probes the role's cross-site scope. |
| C3 | "A supervisor's shift keeps missing pick accuracy after a process change. What do you do in week one?" | CASE | [generic] | Start with the data, then go to the floor, then decide whether the change or the training is at fault. Do not describe your own history here. | Adjacent to F3, framed as a live problem. |

### D. Pressure (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why should we hire you over someone with more operations leadership?" | JD | [grounded] "7 years in warehouse and distribution ops" (your message) | Pause, restate, then anchor in what you did. Hold through two follow-ups. Concede specifically on leadership years (F6), never on the core claim. | F6 and the 5+ years line. Hold-then-concede. |
| D2 | "That mis-pick result: how much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Hold: you redesigned the pick path. Concede specifically what you do not know about the rest of the 40%. Do not add a team reaction or a stakeholder you did not mention. | Attribution under pressure. |

### E. Conversational (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey from the warehouse floor to shift manager." | JD | [grounded] "7 years in warehouse and distribution ops" and "currently a senior shift manager over 3 supervisors" (your message) | A 90-second arc in your own words, using only those two sentences as beats. | Casual but scored. |
| E2 | "What are you playing with in Lean these days?" | JD | [grounded] "green belt certified" (your message) | Name the green belt. Answer slot: if you have applied Lean beyond the belt course, say where; if not, say so and say what you would apply it to first. | F7, asked casually. |

### F. Peer Evaluator (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F-P1 | "Our sites sit beside yours. Where is the seam, and what happens when we disagree?" | JD | [generic] | Propose seam principles, not facts about their sites. Name how you would raise disagreement and resolve it. | Peer-style seam probe. |
| F-P2 | "How do you handle credit when work spans teams?" | JD | [generic] + "ran the site's peak-season surge plan two years running" (your message) | Give the nearest thing your material carries: the surge plan, at its one-site scope. If no such time comes to mind, say so plainly. | Selection scaffold with its honest branch. |

### G. Values / Behavioral (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you had to tell leadership something they did not want to hear." | VAL | [generic] | Selection scaffold: a named stake, a moment you held your position, an intact relationship at the end. If none comes to mind, say so plainly, then give the nearest thing your material carries. | No values round detected; kept at low weight. |
| G2 | "What have you changed in a process because a number told you it wasn't working?" | VAL | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Tell the pick-path redesign at its own scope: what the number showed, what you changed. | Nearest honest story. |

### Requirement coverage

| JD requirement | Question IDs | Note |
|---|---|---|
| Own daily terminal operations across 4 sites | A1, A2, C2, F-P1 | |
| Drive on-time performance and cost-per-shipment down | A3, C1, C2, B3 | |
| Lead a team of 12 supervisors | A1, D1 | |
| Build reporting in Excel/Power BI | A4, A5, E2 | |
| 5+ years operations leadership required | D1, E1 | Not a gate; graded on fit. |
| Lean/Six Sigma a plus | E2 | |

## Reverse questions

Each ends with why it lands.

1. "What does a good first 90 days look like for someone taking on the four sites?" Why it lands: shows you are planning for the full scope.
2. "How are the supervisors set up across the four sites today?" Why it lands: asks about the structure you would be inheriting, without assuming a gap.
3. "What reporting do the sites run on today, and what question would you most want Power BI to answer?" Why it lands: turns F5 into a conversation about the work.
4. "How is cost-per-shipment measured now, and who owns that number?" Why it lands: it's the measurement question you need answered before the job.
5. "Where is Lean or Six Sigma work already running, and where would a green belt help?" Why it lands: connects F7 to their real work.

## Prohibited claims check

Every guidance cell above was checked against the table in Prohibited claims. None asserts Power BI experience, multi-site or twelve-supervisor leadership, or cost or on-time results.

## Sources

- Provided documents: the JD excerpt and the background in your message.
- Research: two searches were sent and both were refused permission. Their queries were "Atlas Freight regional logistics company values" and "Atlas Freight interview process operations manager". Both are listed as refused. No company facts come from research.

Research tier: L1 — searches 2 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Atlas Freight values | unavailable | Values cheat sheet (not included). Search refused. |
| 2. Atlas Freight interview process, operations | unavailable | Loop structure and persona weights. Search refused; weights rest on the round-type prior. |
| 3. Atlas Freight strategy / recent news | unavailable | CO questions (none included). No search was sent for this target. |
| 4. Interviewer name + Atlas Freight | n/a | No interviewer name was given. |
| 5. Representative JD | skipped | The JD you supplied fixes the fit snapshot. |

## Upgrade menu

- Round type and who you are meeting → persona weights from their role, and a tailored reverse question
- Recruiter's prep email (focus areas or a pre-declared exercise) → coverage of anything they name
- Atlas Freight's careers or interview page pasted → values and loop structure, replacing the assumed weights
- Your green belt certificate → F7 moves from medium to high confidence
- How the 40% mis-pick figure was counted (period and volume) → B1 to B3 become rehearsable answers
- Anything you have run across more than one site or shift → A1, A2 and F1 gain a grounded bridge
