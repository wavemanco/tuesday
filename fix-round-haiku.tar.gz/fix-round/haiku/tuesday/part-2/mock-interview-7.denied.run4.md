Web search was refused on this host, so the pack is built from your message and the JD only. I'll write it to the scratchpad now.
Your prep pack is saved as `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-tuesday-part-2-rooms-case-7-denied-5d941e5d/65ce985a-8c77-4b32-b7dc-b2a914d1d1e8/scratchpad/saltmarsh_live_operations_producer_interview_pack.md`. I built it for a hiring-manager round: one 60-minute conversation with Tobias.

**What the pack covers**
- **Gap plan:** Your two named gaps get their own rows. For team leadership, the answer is "I haven't led a team," then a plan for coordinating four disciplines. For in-app purchases, it's "I haven't worked on a game with in-app purchases," then what you'd want to know about the titles' monetisation before the first update. Both are rehearsed as plans, never as experience.
- **Likely hardest questions:** B2 (leadership) is the one to rehearse most. B1 asks what you'd be weakest at on day one, and B4 asks why one title's calendar means you can handle two.
- **Weak spots in your material:** Your JD requirements that are only partly covered are the two-title calendar, the post-event review and KPI ownership, and coordinating design, art, engineering and community. Your quotes show you presented retention numbers and wrote the release checklist. They don't show you owned the KPIs or coordinated the other teams. The pack keeps your claims at that scope so you don't stretch them in the room.
- **Prohibited claims:** Phrases I won't coach include "I ran the calendar for two titles," "I owned the KPIs," and "I led a team."
- **Question banks** with case, data and pressure questions, a requirement coverage table, and six reverse questions.

**What's missing**
- Web search was refused on this host, so I couldn't research Saltmarsh Games' values, interview process or recent strategy, or Tobias's public background. The pack is built only from your message and the JD. The sources section records each refused call.
- No interviewer read, values cheat sheet or strategy questions, because they depend on that research. The upgrade menu says what each would add. If you can paste Saltmarsh's values page or Tobias's public profile, I'll rebuild those sections.

**Your choices to check**
- I assumed Tobias is your hiring manager and this is one conversation. If it's a panel or several sessions, the persona weights change.
- I counted the puzzle title as relevant to "3+ years producing live-service games or apps" only on years. Whether it was live-service is open (B5). If it ran post-launch content, say so and the pack gets stronger.

Two offers, neither pushed:
- Want to run a live drill? I can play the Skeptic on B2, the question the pack names as the highest-value prep.
- I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions.

Two quick questions:
1. Is Tobias your direct hiring manager, or a peer?
2. Did the puzzle title run content after launch, and on what cadence? That decides whether B5 is a strong answer or an honest "no."

Watch-out: Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh_live_operations_producer_interview_pack.md -----
# Interview prep pack: Live Operations Producer, Saltmarsh Games

**Interviewer:** Tobias Wrenfield, Head of Live Operations. Relationship assumed: hiring manager, one 60-minute conversation. No public profile was read, so the interviewer read is absent.
**Candidate:** Femi. Built from your message and the JD you pasted.

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored: JD (the stated requirements), EXP (your past work), CASE (a live problem), CO (company knowledge, not covered here).
- Guidance is scaffolding for a spoken answer, not a script. Rehearse only what you actually did, in your own words.

## Persona table

| Persona | How it shows up here | Weight | Why | Counter-strategy |
|---|---|---|---|---|
| Skeptic | "Which part of this JD would you be weakest at?" | High | A hiring manager is buying capability and checking the gaps you named | Rehearse the leadership and in-app-purchase answers until they are plain |
| Case / Strategist | A live calendar or retention problem on the real role | High | The JD asks you to plan and run a calendar and own KPIs | Clarify, then structure, then name metrics and risks, out loud |
| Data-Driven Prober | "How was that retention figure counted?" | Medium | You presented retention numbers, and the JD asks for comfort with retention metrics | Say what you know about the count and name your weakest assumption |
| Pressure | "How much of that was actually you?" | Low to medium | Plausible on the calendar you ran | Hold what you ran; concede what was shared |
| Conversational | Opening biography and "anything else?" | Low | Friendly openers are still scored | Prepare a 90-second arc from your own sentences |

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | transferability | Your material shows one title and a weekly content-drop calendar, not two titles or live events. Words: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: if you planned across more than one title, or ran events beyond content drops, say what and how you decided. If not, say so and say how you would extend one calendar to two. |
| F2 | "coordinate design, art, engineering and community teams on each update" (JD) | "Wrote the release checklist our QA team still uses." (your message) | low | [grounded] | discovery | The material touches QA and says nothing about the other four teams. Answer slot: name a specific update you coordinated across teams and what each one had to do. If you did not coordinate them directly, say so and say which team you worked through. |
| F3 | "own the post-event review and the KPIs it reports" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | medium | [grounded] | transferability | Your material shows presenting retention numbers, not owning the KPIs or running a post-event review. Words: "I presented the monthly retention numbers to the studio head." Answer slot: if you chose which KPIs were reported or ran a review after an event, say what and how. If not, say so and stay with the monthly presentation. |
| F4 | "manage the release checklist with QA" (JD) | "Wrote the release checklist our QA team still uses." (your message) | medium | [grounded] | none | The quote already reaches the requirement. Expect a probe on how the checklist is used day to day. Lead with the artifact in the quote's own terms. |
| F5 | "3+ years producing live-service games or apps" (JD) | "4 years as an associate producer at a puzzle-game studio." (your message) | medium | [grounded] | discovery | The years match. Whether the puzzle title was live-service is not in your material. Answer slot: if it ran content after launch, say what cadence and what you ran. If it did not, say so. |
| F6 | "experience running a content calendar" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | none | The quote reaches the requirement. Expect a probe on scale, which is one title on a weekly cadence. |
| F7 | "comfortable with player-retention metrics" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | medium | [grounded] | none | The quote reaches the requirement in role terms. No figure is stated, so no defend-the-number slot is raised. |
| F8 | "clear written communication" (JD) | "Wrote the release checklist our QA team still uses." (your message) | low | [inferred] | presentation | The checklist is a written artifact a team relies on. Bridge: name the checklist as your example of written work and let the reader judge the rest. Derivation: low-confidence evidence, so the label is inferred. |
| F9 | Not in the JD. Team leadership, which you named as a gap | "Never led a team, and never worked on a game with in-app purchases." (your message) | high | [grounded] | capability | Words: "I haven't led a team." Then how you would learn it, said as a plan, never as a past. Never a claim to team leadership. |
| F10 | Not in the JD. In-app-purchase experience, which you named as a gap. The JD does not mention monetisation | "Never led a team, and never worked on a game with in-app purchases." (your message) | high | [grounded] | capability | Words: "I haven't worked on a game with in-app purchases." Then a plan: what you would want to know about the titles' monetisation before the first update. |

F9 and F10 are gaps you stated, so the pack may give you their words back. F1 and F3 are where the JD's wording runs ahead of your quotes: the pack's observation is that your material says the round and the presentation, not the pipeline and the ownership.

## Prohibited claims

These will not be coached, and each entry carries its basis and its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| "I ran the live-events calendar for two titles" | Inflated form of F1 | F1's quote at its own scope. The material says one title and content drops. |
| "I owned the KPIs" or "I set the retention targets" | Inflated form of F3 | F3's quote at its own scope. The material says presented. |
| "I led a team" or "I managed people" | Negative you stated, F9 | "I haven't led a team." No slot. |
| "I've shipped in-app purchase features" or "I've worked on monetised titles" | Negative you stated, F10 | "I haven't worked on a game with in-app purchases." No slot. |
| "I ran the release process across QA and engineering" | Inflated form of F4 | F4's quote: "Wrote the release checklist our QA team still uses." |

## Question banks

Each row's Provenance carries every sentence its guidance rests on. Questions with no claim about you carry only the label.

### Skeptic (high weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." [grounded] "Wrote the release checklist our QA team still uses." | Name the two-title calendar and cross-team coordination as where you are least proven, and say what you would do in the first 30 days. Answer slot: none needed beyond that. | F1 and F2 are the widest gaps; this is the most likely opening move. |
| B2 | "I don't see team leadership in your background. How would you coordinate four disciplines without managing them?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Plain acknowledgment: "I haven't led a team." Then describe the coordination you would do as a plan, using the checklist as the one concrete example you have. Highest-ROI prep in this pack. | F9 and F2 meet here. The objection is aimed exactly where the material is thin. |
| B3 | "You've never worked on a game with in-app purchases. What changes when a monetised event goes live?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Plain acknowledgment: "I haven't worked on a game with in-app purchases." Then a plan: what you would ask about economy and store review before the first update. | F10. Answer as a plan, never as experience. |
| B4 | "Your background is one title. Why won't two be a step too far?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Stay with the calendar you ran. Answer slot: say what changes when a second title joins, and how you would split the cadence. | F1. Hold the scope the quote states. |
| B5 | "Was the puzzle title live in the sense we mean, with ongoing content after launch?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio." | Answer slot: if it ran post-launch content, say the cadence and what you ran. If not, say so plainly and say what you would bring to live content. | F5. Only the stated years are yours to claim. |

### Case / Strategist (high weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Sketch how you would plan the next quarter's events for two titles. What do you need to know first?" | CASE | [generic] | Clarify first: the titles, the cadence, the team capacity, the KPIs in play. Then objective, approach, metrics, risks. The question needs no claim about your past. | F1 and F3 meet in a live problem. |
| C2 | "Retention on one title dropped ten percent week over week after an update. Diagnose it." | CASE | [generic] | Structure: check what shipped, what the event calendar did, and what outside the game changed. Name the metrics you would pull and the order you would pull them in. | Tests the structure you will use in the post-event review. |
| C3 | "An update needs design, art, engineering and community on the same day. Walk me through the checklist you would run." | CASE | [grounded] "Wrote the release checklist our QA team still uses." | Build on the checklist you wrote, in those words. Say which items you would add for the other teams, as a plan. | F4 and F2. The JD raises the checklist; your quote carries the artifact. |

### Data-Driven Prober (medium weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how the retention numbers you presented were counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Answer slot: say what the numbers counted, in your own words. If you did not define the count, say so and say what you did check. | F7. No figure is stated, so the slot covers the definition only. |
| D2 | "Which assumption behind that retention figure would you defend least?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Name the weakest assumption you know of before the interviewer does. If you do not know how the count was set, say that plainly. | Weakest-assumption move, applied to the one thing you presented. |

### Pressure (low to medium weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Sixty seconds: why you over someone who has led live teams?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Hold: the calendar you ran and the checklist you wrote are the position. Concede "I haven't led a team" explicitly. Do not fold on the calendar. | Hold-then-concede. F9. |
| P2 | "That calendar ran for one title. How much of it was actually you?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Answer slot: say which parts you set and which the studio set. Do not claim more than you set. | Attribution test. F1. |

### Conversational (low weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." | A 90-second arc: the studio, the years, the calendar, the checklist, the retention presentation. Use only those sentences. | Casual openers are still scored. |
| R2 | "What are you playing at the moment in live-service?" | JD | [generic] | Name one live title you play and what its event cadence tells you. Make no claim about your past here. | Friendly, but it tests whether you know the category. |

## Requirement coverage

| JD requirement | Covered by | Note |
|---|---|---|
| "Plan and run the live-events calendar for two of our mobile titles" | F1, B4, C1 | |
| "coordinate design, art, engineering and community teams on each update" | F2, B2, C3 | |
| "own the post-event review and the KPIs it reports" | F3, D1, D2, C2 | |
| "manage the release checklist with QA" | F4, C3 | |
| "3+ years producing live-service games or apps" | F5, B5 | |
| "experience running a content calendar" | F6, B4 | |
| "comfortable with player-retention metrics" | F7, D1, D2 | |
| "clear written communication" | F8 | No question scores it directly. It shows in how you answer D1 and C1. |

## Reverse questions

Every reverse question is tied to what the JD and your gaps raise. Why each lands is in brackets after it.

1. "How many updates per title does the calendar carry each month?" (Shows you read the JD and want the real load.)
2. "Are the two titles monetised with in-app purchases, and who owns that economy?" (Tests the IAP gap head-on and turns it into a question you can ask.)
3. "How does the post-event review run today, and who owns the KPIs it reports?" (Maps straight to F3.)
4. "Who runs the release checklist with QA now, and what does it cover?" (Lets you describe the checklist you wrote and learn what has changed since.)
5. "How is coordination across design, art, engineering and community structured. Does each team have its own lead?" (Probes the leadership gap from the other side.)
6. "What would a strong first 90 days look like for this role?" (Gives you the interviewer's scoring sheet in his own words.)

## Sources

Provided documents: the JD and the background in your message. Read directly; no link was given.

Search calls sent (both refused by this host, which denied the search permission):
1. "Saltmarsh Games mobile studio live operations": refused. Aimed at the values, strategy and company footprint targets.
2. "Tobias Wrenfield Head of Live Operations Saltmarsh Games": refused. Aimed at the interviewer footprint target.

Research tier: L1 — searches 2 of 6, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | unavailable | Search refused. Would have moved the values cheat sheet, which is also absent because no values-style round is established. |
| 2. Saltmarsh Games interview process | unavailable | No call sent; the host denied search. Would have moved the loop structure and the persona weights, which are therefore archetype priors. |
| 3. Saltmarsh Games strategy / news | unavailable | Search refused. Would have moved the CO bank, which is absent. |
| 4. Tobias Wrenfield footprint | unavailable | Search refused. Would have moved the interviewer read and a reverse question tied to his own path. |
| 5. Representative JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions. |

Not established: nothing about Saltmarsh Games or Tobias Wrenfield is used in this pack beyond what you told me.

## Upgrade menu

- Tobias's public profile or talks → an interviewer read, persona weights tuned to him, and a reverse question tied to his career path
- Saltmarsh's values page or a recent post about its titles → a values cheat sheet and current strategy questions in the CO bank
- The interview schedule from the recruiter, or confirmation that this is one session → firm persona weights, and per-session mini-packs if it is several
- Whether the puzzle title ran post-launch content, with the cadence → F5 moves from discovery to grounded, and B5 gets a stated answer
- Two or three numbers from the retention work, with how each was counted → defend-the-number slots for F3 and F7, and a sharper D1
