This matches the candidate-side interview prep skill, so I'll load it and let it route the request.
The skill's rules are loaded. Before I build the pack, I'll check whether Larkfield Systems has public values or interview-process information, since the values round depends on it.
I'm going to write the pack now. Web search was refused, so the pack is built only from what you've given me, and I'll say that in the sources section.
Your prep pack is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-tuesday-part-2-rooms-case-6-denied-f3e2d259/c8cde47b-dad2-4cb5-abd9-d4f720e339fc/scratchpad/larkfield_engineering_manager_interview_pack.md`. It covers all three rounds: a shared fit snapshot, then 10 questions per round, with reverse questions for each.

Web search was refused in this session, so the pack has no company research. The values cheat sheet is dropped, and the VP round uses selection scaffolds. Pasting Larkfield's values page would fill that gap.

The sharpest prep point is S2: "You've never managed managers and never owned a hardware-adjacent roadmap. Why should I believe you can do both at once?" Rehearse the plain acknowledgment first, then hold on "3 as a team lead of 6", and concede the hardware side as something you'd learn first, as a plan.

Two questions, so I can finish the pack:
1. Can you paste the full JD text? I only have your three-line summary of the role.
2. Is the role on-site or hybrid, and does it involve travel to plants or sites?

Want a drill on S2? Say the word and I'll play the Director. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions. A Word version of the pack is available too.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: larkfield_engineering_manager_interview_pack.md -----
# Interview pack: Engineering Manager, Larkfield Systems

**Candidate:** Yusuf
**Company:** Larkfield Systems (industrial IoT, about 600 people)
**Role:** Engineering Manager. Lead two squads building device-management services; own delivery, hiring and growth for 11 engineers; partner with hardware and product on roadmap.
**Loop (loop mode, three rounds):**

| Round | Format | Interviewer(s) | Relationship |
|---|---|---|---|
| 1 | 45 min, Tuesday | Director of Engineering (name not given) | Hiring manager |
| 2 | 60 min, Thursday after | Two staff engineers and a product manager (names not given) | Panel, peer-weighted |
| 3 | 30 min, following Monday | VP Engineering (name not given) | Values and leadership philosophy, as the recruiter described it |

No interviewer names were given, so no interviewer read is included.

## How to use + type key

Personas describe how a question arrives. Types describe what is being scored. Guidance is scaffolding, not a script. Say it in your own words, and rehearse only what you actually did.

Question types:
- **JD**: can you do the listed job, including its gaps
- **EXP**: whether your claims survive scrutiny, and what you personally did
- **VAL**: whether past behavior shows the values or leadership being asked about
- **CO**: company and strategy knowledge. None in this pack, because no research ran.
- **CASE**: a live problem from the role, scored on structure and reasoning

Provenance labels: `[grounded]` means traceable to your words or the supplied role text. `[inferred]` means derived. `[generic]` means a pattern with no claim about you or Larkfield.

Question IDs are by persona: S = Skeptic, K = Case/Strategist, D = Data-Driven Prober, P = Pressure, E = Peer Evaluator, V = Values/Behavioral, R = Conversational. Round 1 is S1 to S4, K1, K2, D1, D2, P1, P2. Round 2 is E1 to E4, D3, D4, K3, K4, S5, S6. Round 3 is V1 to V4, P3, P4, K5, K6, R1, R2.

## Prep triage

Dropped: no prep time was given, so the schedule cannot be sized. See the upgrade menu.

## Fit snapshot (shared across all three rounds)

The requirement text is your own summary of the role, not the full posting, so it is quoted from your message. It is not the full JD.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" (your message) | "9 years engineering, 3 as a team lead of 6" (your message) | medium | [grounded] | transferability | Your material shows a team of six led for three years, not two squads and not a device-management service. Say the team of six as it is. Answer slot: if you have led more than one team at once, or shipped a service of this kind, say which and how. If not, say so and say how you would run two squads. |
| F2 | "own delivery, hiring and growth for 11 engineers" (your message), hiring part | "I run our hiring loop for backend roles" (your message); "about 40 interviews last year" (your message) | medium | [grounded] | transferability | The loop reaches hiring for backend roles. The requirement is hiring for a team of 11, which your material does not show. Say the loop and the count in those words. Answer slot: if you set hire or no-hire decisions, say which. If not, say whose they were. |
| F3 | "own delivery, hiring and growth for 11 engineers" (your message), delivery part | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" (your message) | medium | [grounded] | presentation | The quote already reaches delivery in other terms: a reliability quarter, pushed through against roadmap pressure. The bridge rewords only that quote. The 60% is a figure, and how it was counted is an answer slot (D1). |
| F4 | "own delivery, hiring and growth for 11 engineers" (your message), growth part | none given | none | [grounded] | discovery | Nothing in your material speaks to growth. Answer slot: name one development step you drove for an engineer, in your own words. If none, say so, and say what you would do first. |
| F5 | "partner with hardware and product on roadmap" (your message) | "never owned a hardware-adjacent roadmap" (your message) | none | [grounded] | capability | You stated this absence. Words: "I haven't owned a hardware-adjacent roadmap." Then how you would learn it, said as a plan and never as a past. |
| F6 | "partner with hardware and product on roadmap" (your message), product part | "pushed a reliability quarter through against roadmap pressure" (your message) | medium | [grounded] | transferability | Adjacent work: negotiating roadmap within a payments team. Your material has no hardware partner in it. Say the quarter, not a partnership. |
| G1 | On-site, location and travel terms for a hardware-adjacent role. No requirement quoted. | none given | none | [generic] | hard_gate | Your material does not establish these terms. Surfaced here, not bridged. The one question in this message asks whether the gate is met. |

## The prohibited list

Built locally from the fit snapshot. Each entry names its basis and its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Led two squads, or led multi-squad delivery | Inflated form of F1 | "3 of my 9 years as a team lead of six." Stay at the quote's scope. |
| Owned a hardware-adjacent roadmap, or hardware experience | Negative you stated (F5) | "I haven't owned a hardware-adjacent roadmap." No answer slot. Then the plan. |
| Managed managers | Negative you stated (your message) | "I haven't managed managers." No answer slot. |
| Owned hiring for 11 engineers, or made the hiring decisions | Inflated form of F2 | "I run our hiring loop for backend roles," and "about 40 interviews last year." Say whose decisions they were. |
| "I cut on-call by 60%," or "the 60% was my result alone" | Inflated form of F3 | "My team's on-call burden dropped 60% after I pushed a reliability quarter through." The attribution is in the answer slot, D1 and P2. |

## Persona weights, per round

Weights are how many questions each persona gets in a round. Counts are 4 for the top persona and 2 for each other persona that appears. Each round has 10 questions.

| Persona | Round 1 (hiring manager) | Round 2 (panel) | Round 3 (VP) | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|---|---|---|
| Skeptic | 4 | 2 | 0 | Cross-examines the gaps, and the "why you, why now" question | Top weight in round 1: a hiring manager is buying capability and derisking the gaps in F1 and F5. Round 2 gets two from the staff engineers' angle. Round 3 gets none, because the VP round is framed as values. The Skeptic still appears there through P3 | Rehearse the most predictable objection until it is plain (S2) |
| Case/Strategist | 2 | 2 | 2 | Live problems on two squads, a hardware dependency, a cut in scope | Hiring managers and panels use live problems to test structure | Clarify, then structure, then answer. Say what you don't know |
| Data-Driven Prober | 2 | 2 | 0 | Asks for the denominator behind the 60% and the 40 interviews | Round 1 and 2 technical interviewers probe metrics. Round 3 is values, so none | Name the weakest assumption before they do. Say plainly if you did not count it |
| Pressure | 2 | 0 | 2 | Time-boxed challenges, "how much was actually you" | Round 1 hiring manager and the VP both use composure checks. The panel does not | Hold the position through two follow-ups, concede specifically, never fold on the core claim |
| Peer Evaluator | 0 | 4 | 0 | Seams between teams, credit, disagreement | The panel is peer-weighted: two staff engineers and a product manager | Reciprocity framing. Propose seam principles, not a seam you have not seen |
| Values/Behavioral | 0 | 0 | 4 | Scenario probes about leadership and team health | The VP round is described as values and leadership philosophy. The recruiter's words are a raising source | Story-map where your quotes carry a story. Use a selection scaffold with an honest branch where they don't |
| Conversational | 0 | 0 | 2 | Opening biography, casual questions about the work | Casual questions are still scored | Pre-scripted 90-second arc. Treat casual questions as scored |

## Round 1: Hiring manager, Director of Engineering (45 min)

Persona top: Skeptic. Highest-ROI prep in this round, and across the loop: **S2**.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| S1 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "partner with hardware and product on roadmap" (your message) | Name the hardware-adjacent roadmap as the weakest part, in your words: "I haven't owned a hardware-adjacent roadmap." Then the plan: who you would ask first, what you would read on the hardware side. Describe no hardware work you have not done. | F5 is the capability gap. The question comes from the role text, not from anything you said about yourself. |
| S2 | "You've never managed managers and never owned a hardware-adjacent roadmap. Why should I believe you can do both at once?" | JD | [grounded] "I've never managed managers" (your message); "never owned a hardware-adjacent roadmap" (your message); "3 as a team lead of 6" (your message) | Open with the plain acknowledgment: "I haven't managed managers, and I haven't owned a hardware-adjacent roadmap." Then hold on what you do have: "3 as a team lead of 6." Keep the team lead as what it is, not manager-of-managers. Hold through two follow-ups. Concede the specific part: the hardware side is what you would learn first. The bridge is a plan, not a past. | Highest-ROI item. Both negatives are your own words, so the acknowledgment is yours to give. Expect this in some form. |
| S3 | "I don't see hardware or industrial work in your background. How would you handle that in this role?" | JD | [grounded] "never owned a hardware-adjacent roadmap" (your message) | Acknowledge in the same words, then how you would close it in the first quarter, as a plan. Do not list adjacent work your material does not contain. The nearest real thing is the roadmap pressure you held in the reliability quarter, at its own scope (F6). | F5 and F6. Framing it as "I don't see" keeps it an observation. |
| S4 | "Why leave a payments company for industrial IoT, and why now?" | JD | [grounded] "currently at a payments company" (your message); [generic] the motivation pattern | Give the real reason in your own words, about the work and its scope. If the reason depends on Larkfield facts you have not checked, say you would check them first. Do not describe Larkfield's business from memory. | No quote states a reason, so the guidance is a scaffold. The "why leave" presupposition is the quote's. |
| K1 | "Two squads, one device-management roadmap, and hardware asking for a change in the same quarter. How do you decide what goes first?" | CASE | [generic] | Clarify what each request costs and who is blocked. Then sequence, then say what you would tell hardware and product. Structure: clarify, objective, options, criteria, risks. | Live problem on the role's own requirements. It asserts nothing about your past. |
| K2 | "What do you need to know in your first 30 days before you plan anything?" | CASE | [generic] | Name four or five things and ask for each: the two squads' current scope, the hardware and product partners and their cadence, the delivery and on-call baseline, the hiring plan for the 11 engineers. Assert none as known. | Covers "Lead two squads" and growth. Scores structure. |
| D1 | "Walk me through how the 60% on-call drop was counted." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" (your message) | Defend the number in your words, four parts: how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. Answer slot: if you counted it, say how. If you did not, say so and say what you would measure. Name the weakest assumption before they do. | A headline figure on the record is a magnet for probers. F3. The method is yours to give, not the pack's. |
| D2 | "Of the roughly 40 interviews last year, which decisions did you make yourself?" | EXP | [grounded] "I run our hiring loop for backend roles" (your message); "about 40 interviews last year" (your message) | Give the count as you gave it, "about 40," and do not round up. Say which hire or no-hire calls were yours. Answer slot: if you set the decision rule or made the calls, say which. If not, say whose they were and what your role was. | F2. The count is yours. The decisions are only what you can name. |
| P1 | "Sixty seconds: give me the one reason to hire you for this role." | JD | [grounded] "3 as a team lead of 6" (your message); "pushed a reliability quarter through against roadmap pressure" (your message) | Pause, restate the question in one line, then answer in under sixty seconds using the team lead and the reliability push. Hold the position through two follow-ups. Do not pad with claims you cannot back. | Composure under a time box. F1 and F3. |
| P2 | "That 60%. How much of it was actually you?" | EXP | [grounded] "pushed a reliability quarter through against roadmap pressure" (your message) | Hold: say what you pushed, in your words. Then say what the team did, if you know it. If you did not do the work itself, say so. Hold through two follow-ups by returning to what you pushed. Concede the part that was shared. | Pressure on attribution. F3 is the claim under test. |

## Round 2: Panel, two staff engineers and a product manager (60 min)

Persona top: Peer Evaluator. Assignment by function, because no names were given: the staff engineers take Prober and Peer, and the product manager takes Peer and Case.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Where's the seam between a device-management service and the teams that build on it, and what happens when you disagree?" | JD | [grounded] "partner with hardware and product on roadmap" (your message) | Propose seam principles, not a seam you have not seen: who owns an interface, who decides a breaking change, how a disagreement escalates. Say what you would bring to their team, not only what you would need. | Peer partnership, without claiming hardware experience. F5 and F6. |
| E2 | "Tell me about a time you traded one team's priority for another's." | JD | [grounded] "partner with hardware and product on roadmap" (your message) | Selection scaffold: pick a time you traded one priority for another. Name the two priorities, the call you made, and what the other team lost. If the nearest time is the reliability quarter, use it at its own scope: you pushed it through against roadmap pressure. If no such time comes to mind, say so plainly, then give how you would handle it now. | No quote carries a trade-off across teams, so this is a scaffold with an honest branch. |
| E3 | "How do you handle credit when work spans teams?" | JD | [generic] | Name the people and what each did. Say what you claim and what you don't. Do not claim the reliability quarter's team outcome beyond what you pushed. | Peer credit probe. The guidance repeats the F3 scope. |
| E4 | "What would make you say no to a hardware request in a quarter?" | CASE | [grounded] "partner with hardware and product on roadmap" (your message) | State a principle you can defend: a request is weighed against the delivery baseline and the on-call risk, and what would change your answer. Do not invent a past "no." | Disagreement style with equals. The principle is a view, not a claim about your history. |
| D3 | "Walk me through how your loop decides a no-hire. Which part of that was yours?" | EXP | [grounded] "I run our hiring loop for backend roles" (your message) | Answer slot: if you set the decision rule, say the rule and how you set it. If the rule was set elsewhere, say where, and what your role was. Do not describe a rubric unless you can name it. | F2. The question presupposes a decision rule. The second branch allows that none existed. |
| D4 | "Which assumption behind your on-call number would you defend least?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" (your message) | Name the assumption before they do. If you cannot name how the figure was counted, say so plainly. | Same figure as D1, from the assumption side. F3. |
| K3 | "Walk me through how you'd split ownership of a device-management service across two squads." | CASE | [grounded] "Lead two squads building device-management services" (your message) | Clarify first: which service boundaries exist, what each squad would own. Sketch a split by criteria: interface, on-call, release cadence. Say what you don't know. | F1. Scores structure on the role's own problem. |
| K4 | "Hardware is about to change something your service depends on, and nobody on your side has seen it yet. What's your sequence?" | CASE | [grounded] "partner with hardware and product on roadmap" (your message) | Structure: what you need from hardware, who needs it, what you can check before committing, and the rollback. Say what you would ask first. | F5. A live problem. It asserts nothing about your past. |
| S5 | "Two squads is more than the team of six you've led. What breaks first?" | JD | [grounded] "3 as a team lead of 6" (your message); "Lead two squads building device-management services" (your message) | Hold the fact: "I've led a team of six, three of my nine years as a team lead." Then name what would break first, as your judgment, and what you would check. Do not say you have run two squads. Concede the specific: you haven't. Hold through two follow-ups. | F1 transferability. Panel-level skeptic angle on the same gap as S2. |
| S6 | "What would you need from the hardware team in the first month?" | JD | [grounded] "partner with hardware and product on roadmap" (your message) | Ask for specifics: named contacts, the calendar, the decisions owed. Do not claim to know their roadmap. | Turns the F5 gap into a plan the panel can test. |

## Round 3: VP Engineering, values and leadership philosophy (30 min)

Persona top: Values/Behavioral. The recruiter's words are the raising source for the round: "values and leadership philosophy" (your message).

**Values cheat sheet: dropped.** It needs Larkfield's published values in hand, and none were pasted. The round's values questions below use selection scaffolds where your quotes do not carry a story. See the upgrade menu.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V1 | "Tell me about a time you protected your team's health against a roadmap commitment." | VAL | [grounded] "pushed a reliability quarter through against roadmap pressure" (your message) | Story-mapped on the quote's beats: the reliability quarter, the roadmap pressure, the push through. Give the 60% once and attribute it to the team's burden. Answer slot: who pushed back and what it cost. If no one pushed back, say so. If it cost something, say what. | F3 and F6. The raising source is the recruiter's "values and leadership philosophy." |
| V2 | "When did you disagree with a decision from above and still have to carry it out?" | VAL | [generic] | Selection scaffold: pick a time you disagreed with a decision you then carried out. Name the decision, what you said, and what you did next. If no such time comes to mind, say so plainly, then say how you would handle it now. | No quote carries a disagreement. Theme from the persona stem and the recruiter's words. |
| V3 | "What does leadership mean to you when the team is eleven engineers and you're not managing managers?" | VAL | [grounded] "9 years engineering, 3 as a team lead of 6" (your message); "own delivery, hiring and growth for 11 engineers" (your message) | State your view of leadership in your words. Anchor any example to the team of six. Do not claim experience managing managers. | The answer is a view, not a past. The team of six is the only example your material carries. |
| V4 | "Tell me about an engineer who grew on your team, and what you did to make it happen." | VAL | [grounded] "own delivery, hiring and growth for 11 engineers" (your message) | Answer slot: name one development step you drove, in your own words. If none, say so, and say what you would do first for growth. Never claim a promotion you did not drive. | F4. The honest branch is the point of this question. |
| P3 | "Make the case against hiring you as the leader for this role." | JD | [grounded] "I've never managed managers" (your message); "3 as a team lead of 6" (your message) | Hold: "3 of my 9 years as a team lead of six." Hold through two follow-ups. Concede the specific: no manager-of-managers experience. Do not argue for skills you have not shown. | Pressure, altitude version. The concession is your own stated negative. |
| P4 | "You had a reliability quarter. What did you give up for it?" | EXP | [grounded] "pushed a reliability quarter through against roadmap pressure" (your message) | Answer slot: if something was given up, name it and who paid. If nothing visible was, say so. Do not invent a cost. | Presupposes a cost the quote does not carry. The second branch allows that none was visible. |
| K5 | "How would you decide between a reliability backlog and a hardware-driven feature in the same quarter?" | CASE | [generic] | Clarify what each costs, who is blocked, and what is reversible. Use criteria, name the one you would defend, and say what would change your mind. | Scores altitude. A live problem on the role's requirements. |
| K6 | "Two squads, eleven engineers, and a product line that wants more. What would you cut first?" | CASE | [generic] | Structure: the outcome the VP wants, the cost of cutting each item, the sequence. Say what you would refuse and why. | Altitude and trade-offs. A live problem. |
| R1 | "So, walk me through the journey." | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" (your message) | A 90-second arc: nine years of engineering, three as a team lead of six, the payments company now, the reliability quarter, the hiring loop. Use only those beats. | Casual register, still scored. |
| R2 | "What's the one thing you'd change about the hiring loop you run?" | EXP | [grounded] "I run our hiring loop for backend roles" (your message) | Sixty seconds: how the loop runs, about 40 interviews last year, and one change, in your words. | F2. A conversational opener that tests whether you know your own process. |

## Requirement coverage

| Requirement | Questions | Note |
|---|---|---|
| Lead two squads building device-management services | S2, S5, K1, K2, K3, K6 | |
| Own delivery | D1, D4, P1, P2, P4, K1, V1 | |
| Own hiring | D2, D3, R2 | |
| Own growth for 11 engineers | V4, K2 | F4 is discovery. The honest branch is in V4. |
| Partner with hardware and product on roadmap | S1, S3, S6, E1, E2, E4, K4, K5 | |
| On-site, location and travel terms | none, and why: the JD text is not supplied, so the gate cannot be read from the material. It is asked in the questions below, not in the interview bank | |

## Reverse questions

Each has a one-line "why it lands."

**Round 1 (hiring manager):**
1. "What would success look like at the six-month review for this role?" Anchors the scope in the interviewer's own terms.
2. "Which of the two squads carries the most on-call pressure today?" Shows you read the split, with no claim about your past.
3. "What does your hardware team need from engineering that they don't get today?" Tests the partner-on-roadmap requirement directly.
4. "What would make you regret this hire in a year?" Surfaces the expectation behind the Skeptic questions.
5. "How are the 11 engineers split across the two squads?" Shows you're planning the team, not only the job.

No interviewer profile was given, so no reverse question is tied to the interviewer's own path. See the upgrade menu.

**Round 2 (panel):**
1. "Where does your team's work most often wait on the other side of the seam?" Opens the seam question from their side.
2. "What would a new person do in their first month that would genuinely help your team?" Reciprocity, required for a peer panel. It shows you're thinking about what you bring.
3. "How do your squads decide when a breaking change crosses the device boundary?" Concrete, and it tests the seam principles you proposed.
4. "What's one thing about how engineering and product disagree here that you'd want the next manager to change?" Asks about the disagreement pattern directly.
5. "What does a good design review look like on your side?" Shows how you'd work with their staff engineers day to day.

**Round 3 (VP):**
1. "What would you want the next manager of these squads to have proven in their first two quarters?" The leadership expectation, stated in their words.
2. "How do you think about the trade-off between reliability and roadmap over the next year?" Lets you connect the reliability story to their altitude.
3. "Where do you see engineering's biggest risk to the device roadmap?" Altitude question, and it needs no claim from you.
4. "What does a values conversation look like when it goes well here?" Invites them to describe their values in practice.
5. "What's one thing you'd want a new leader here to avoid?" Surfaces the pressure points in the leadership philosophy.

## Sources

Provided documents: your message (the role summary, your background, the recruiter's phrase "values and leadership philosophy"). No CV, no JD text, no interviewer names, no values page.

Research tier: L1 — searches 2 of 6, fetches 0 of 2. Both searches were refused, because web search permission was not granted in this session.

Searches sent:
- "Larkfield Systems values engineering": refused (permission not granted)
- "Larkfield Systems engineering manager interview process": refused (permission not granted)

Target accounting:

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Larkfield Systems values` | unavailable | Values cheat sheet, section 10. Dropped. The two searches sent were refused, and no values page was pasted. |
| 2. `Larkfield Systems interview process engineering manager` | unavailable | Loop structure. Persona weights follow the rounds you named, not a researched loop. |
| 3. `Larkfield Systems strategy` / recent news | unavailable | Would have moved the CO bank. No call was sent after the first two were refused, so the CO bank is empty. |
| 4. Interviewer name | n/a | No names were given, so there was no query to form. |
| 5. Representative Engineering Manager JD | unavailable | Would have fixed the requirements beyond your three-line summary. |

Items I did not verify: nothing about Larkfield is in this pack from a source. Every claim about the company is absent from the pack, not guessed.

## Upgrade menu

- Full JD text → quotes the whole posting instead of your summary, and may add requirement rows, or the mid-list items that currently have no question.
- Larkfield's published values page, pasted → the values cheat sheet (section 10), and V1 to V4 move from scaffolds to mapped stories where your material carries one.
- Names of the Director and the panel members → per-member persona assignment and an interviewer read.
- Your CV → more quoted sentences. A postmortem or dashboard for the on-call drop would move D1 and P2 from medium to high confidence.
- Web search permission → L1 research on the values and the interview process, which would fill the dropped sections and the CO bank.
- Prep time per round → a prep triage section, sized to the time you have.
- Answer on the gate question → resolves G1 for the fit snapshot.
- Answer slots (F1, F2, F4, D1, D3, P4, V1, V4), in your own words → each one becomes new quoted material for the fit snapshot.
