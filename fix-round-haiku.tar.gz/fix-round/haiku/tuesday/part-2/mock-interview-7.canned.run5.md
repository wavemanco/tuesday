Your prep pack is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-tuesday-part-2-rooms-case-7-canned-b98eb8a4/7700ad02-b7fa-4750-893d-fa6491cb3beb/scratchpad/saltmarsh_live_ops_producer_interview_pack.md`.

Three things from the research change how you should prepare:

- **The round is a tabletop, not a chat.** Saltmarsh's careers page says every loop is a recruiter call, then the "Outage Hour": one 60-minute session with the hiring manager, a live-incident tabletop on a simulated outage during a live event, then a values conversation. Spend the most time on the case questions (A1 and A2 in the pack). Your background doesn't include incident work, so the pack gives you a structure to walk through rather than a story.
- **The values are Players Before Plans, Ship the Patch Not the Promise, and Leave the Build Greener.** Your material only carries a story for the third one (the release checklist QA still uses). For the other two, the pack gives you a way to answer honestly.
- **Tobias came up through QA.** A search result describes him as a former QA lead who gave a GDC 2026 talk on patch notes matching what shipped. I did not open that page, and its domain looks like a placeholder, so verify it before you mention the talk.

The pack's biggest rehearsal target is C1: "You have never led a team. Why would you coordinate four teams on an update?" Your honest answer is that you haven't led a team, then the nearest cross-team work you can actually describe. The in-app purchase gap (C3) is the second one to rehearse. The JD doesn't mention monetization, but a mobile live-events interviewer may ask.

Questions for you (answers would change the pack):
1. Is Friday's session the Outage Hour described on the careers page, and is Tobias the hiring manager for this role?
2. Have you planned any live event, even a small one, or run a calendar for a second title? That would move F1 from transferability to a direct match.

Offers, neither pushed:
- **Drill:** I can play the Skeptic on C1 and push you through the team-leadership objection.
- **Dossier:** I can save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions.
- **Word:** I can convert the pack to a .docx if you want it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh_live_ops_producer_interview_pack.md -----
# Interview prep pack: Live Operations Producer, Saltmarsh Games

**Round:** 60-minute session with Tobias Wrenfield, Head of Live Operations. Saltmarsh's careers page describes this as the hiring-manager "Outage Hour" (a live-incident tabletop, then a values conversation). The loop source establishes it; I did not have to fall back to an archetype.

## 1. How to use this pack

- **Personas** = how a question arrives. **Types** = what is being scored: VAL (values), EXP (your experience, attribution), JD (the listed job), CO (company knowledge), CASE (live problem).
- Guidance is scaffolding for a spoken answer, not a script.
- Every claim about your past is a sentence you wrote in your message or CV. Where the material is silent, the answer is an **answer slot**: say what you did if it was yours, or say plainly that it was not.

## 2. Fit snapshot

Sources: "your message" = your background message. "careers page" = saltmarshgames.com/careers/interviewing (fetched). "JD" = the job description you supplied. No row is a gate: no requirement is a term or credential bar.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | medium | [grounded] | transferability | Your material says one title's content-drop calendar, not live events and not two titles. Words: "For two years I ran the weekly content-drop calendar for our main title." Answer slot: if you planned any live event or ran a second title's calendar, say so in your own words; if not, say so and say how you would plan two titles. |
| F2 | "coordinate design, art, engineering and community teams on each update" (JD) | none given | none | [grounded] | discovery | Your material does not show cross-team coordination on updates. Answer slot: describe one update you got out, who you coordinated with, and what was yours to decide. If none, say so and describe how you would set up that coordination. |
| F3 | "own the post-event review and the KPIs it reports" (JD) | "Presented the monthly retention numbers to the studio head" (your message) | medium | [grounded] | transferability | Presenting is not owning. Words: "I presented the monthly retention numbers to the studio head." Answer slot: if you chose the metrics or wrote the review, say so; if someone else set them, say so and what you did with them. |
| F4 | "manage the release checklist with QA" (JD) | "Wrote the release checklist our QA team still uses" (your message) | medium | [grounded] | presentation | The quote already reaches the requirement in other terms. Words: "I wrote the release checklist, and our QA team still uses it." Confidence is medium because nothing has been inspected. Bring the checklist (see upgrade menu). |
| F5 | "3+ years producing live-service games or apps" (JD) | "4 years as an associate producer at a puzzle-game studio" (your message) | medium | [grounded] | transferability | The years are real. Whether the title ran as a live-service product is not stated. Words: "I spent four years as an associate producer at a puzzle-game studio." Answer slot: say what ongoing content meant for how you produced the title. This is a length requirement, so it is graded on fit, not treated as a gate. |
| F6 | "experience running a content calendar" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | medium | [grounded] | none | Direct match. Confidence is medium until you can show the calendar itself. |
| F7 | "comfortable with player-retention metrics" (JD) | "Presented the monthly retention numbers to the studio head" (your message) | medium | [grounded] | none | The quote reaches the requirement. Expect a probe on how the numbers were built (see D1 and D2). |
| F8 | "clear written communication" (JD) | "Wrote the release checklist our QA team still uses" (your message) | low | [inferred] | discovery | A checklist shows that you write for people who act on it. It does not show clarity under a live-incident brief. Answer slot: if you have a written update or review you can describe, do so; if not, say so. |
| F9 | Live-incident tabletop, "a live-incident tabletop on a simulated outage during a live event" (careers page) | none given | none | [grounded] | discovery | Your material does not show incident or outage work. Answer slot: if you have been part of an incident or outage response, describe your role in it. If not, say so plainly and walk through how you would open the tabletop. |
| F10 | Never led a team (your message, not in the JD) | "Never led a team" (your message) | high | [grounded] | capability | This is your own statement. Words: "I haven't led a team." Then how you would coordinate without line authority, said as a plan, not a past. |
| F11 | Never worked on a game with in-app purchases (your message, not in the JD) | "Never worked on a game with in-app purchases" (your message) | high | [grounded] | capability | Your own statement. The JD does not list monetization, but a mobile live-events role may be probed on it. Words: "I haven't worked on a game with in-app purchases." Then how you would learn it, as a plan. |

## 3. Prohibited list

Not coached in any answer, hold or rationale, and why.

| Not coached | Basis | Honest form |
|---|---|---|
| Led a team or managed people | Inflated form of F10, and a negative you stated | "I haven't led a team." No slot may imply it. |
| Owned the post-event review or its KPIs | Inflated form of F3 | "I presented the monthly retention numbers." Limit, as the pack's own observation: your material says presented, not owned. |
| Planned live events, or ran two titles' calendars | Inflated form of F1 | "I ran the weekly content-drop calendar for our main title." |
| Shipped a live-service title | Inflated form of F5 | Your material says a puzzle-game studio with content drops. |
| Managed QA or the release process | Inflated form of F4 | "I wrote the release checklist our QA team still uses." |
| Experience with in-app purchase economics | Negative you stated, F11 | "I haven't worked on a game with in-app purchases." No slot. |

## 4. Persona weights

Relationship prior for a hiring manager: Case and Skeptic. The careers page adds a values conversation, so Values is raised. Pressure and Conversational are kept at lower weight so you meet the delivery styles.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Case / Strategist (top, 5 Qs) | A live-incident problem on a live event | Highest. The Outage Hour is a tabletop by name. | Clarify, then structure, then decide. Name what you would check before you act. |
| B. Values / Behavioral (4 Qs) | "Tell me about a time…" against the three values | High. The careers page names a values conversation. | Map each value to a story only where your quotes carry one. Otherwise give the selection scaffold and its honest branch. |
| C. Skeptic (4 Qs) | "Why you, given X?" | High. Two gaps are explicit (F10, F11) and the JD says "coordinate" and "own". | Concede the gap in one sentence, then bridge only from what you stated. Rehearse the team-leadership objection most. |
| D. Data-Driven Prober (3 Qs) | "How was that counted?" | Medium. A retention figure appears in your CV line. | Know how the number was counted, or say you do not. Name the weakest assumption first. |
| E. Pressure (2 Qs) | "How much of that was actually you?" | Medium-low. Used if the interviewer tests composure. | Pause, restate, hold through two follow-ups, then concede precisely. |
| F. Conversational (2 Qs) | "So, walk me through the journey." | Low, but scored. | Have a 90-second arc built only from your quotes. |

## 5. Question banks

**Highest-ROI prep:** C1. It is the objection this session is most likely to raise, and it ties to F10.

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A player-facing event is live and the reward grant fails for some players. Walk me through the first hour." | CASE | [grounded] "a live-incident tabletop on a simulated outage during a live event" (careers page) | Clarify impact and scope first. Decide whether to stop the event, roll back, or hotfix. Work out what the player-facing message says, and say only what is built. Name the metrics you watch and what goes into the post-event review. Do not claim incident experience. | The loop round is this tabletop. F9 means structure, not anecdote. |
| A2 | "Day-1 retention dropped after last week's content drop. How do you diagnose it?" | CASE | [generic] | Clarify the cohort and the drop's size. Split by platform, version, and content exposure. Name the assumption you would test first. | Live problem on the retention area (F7). It needs no claim about your past. |
| A3 | "Two partner teams disagree on whether a fix ships this week. What do you do?" | CASE | [generic] | Separate the players' impact from the schedule. Decide who has the call and say what you would tell each team. | JD coordination line (F2). Presupposes nothing about your history. |
| A4 | "Plan the next six weeks of content for a title with no roadmap yet. What is your first document?" | CASE | [grounded] JD "Plan and run the live-events calendar" | Name the calendar's constraints first: the checklist, QA time, what the players already have. Then say the first document you would write. | JD calendar line (F1). The premise is the JD's. |
| A5 | "Walk me through how you would change the release checklist for a feature that touches a system QA has never tested." | CASE | [grounded] JD "manage the release checklist with QA"; [grounded] "Wrote the release checklist our QA team still uses" (your message) | Story-mapped on F4: you wrote the checklist QA uses. Say what you would add first and who you would ask in QA. Answer slot: if QA changed the checklist after a release, say what changed. If not, say so. | JD release line (F4). The question presumes a checklist, which the quote carries. |

### B. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time the calendar and the players disagreed. What did you do?" | VAL | [grounded] "Players Before Plans: when the calendar and the players disagree, the players win" (values page) | Scaffold: pick a time a date moved or was held for player reasons. If no such time comes to mind, say so plainly, then give the nearest thing your material carries: "I ran the weekly content-drop calendar for our main title for the last two years" (F6). | Players Before Plans. Your material shows no such decision. |
| B2 | "Tell me about a time you announced something before it was built, or held it back." | VAL | [grounded] "we announce what is built, not what is hoped" (values page) | Scaffold: a time you described what had shipped and not what was planned, or a time you held a claim. If none, say so, then give the nearest thing: "Presented the monthly retention numbers to the studio head" (F3). | Ship the Patch Not the Promise. Your material shows no such decision. |
| B3 | "Tell me about a time your work left a process better than you found it." | VAL | [grounded] "Wrote the release checklist our QA team still uses" (your message) | Story-mapped on F4: the checklist, and that QA still uses it. Answer slot: if you revised it after a release, or as the process changed, say what changed and why. If not, say so and say what you would add first. | Leave the Build Greener. The "better" beat is not stated. |
| B4 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "Presented the monthly retention numbers to the studio head" (your message) | Story-mapped on F3: you presented the monthly numbers. Answer slot: if the numbers were unwelcome, say what they showed and how you put it to the studio head. If they were not, say so and say what you would bring. | Stem from persona B. The unpopular part is an answer slot. |

### C. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You have never led a team. Why would you coordinate four teams on an update?" | JD | [grounded] "Never led a team" (your message); [grounded] JD "coordinate design, art, engineering and community teams on each update" | **Deepest rehearsal.** Hold: "I haven't led a team." Then the cross-team thing you did, in your own words. Answer slot: describe one update you coordinated, and what was yours to decide. If none, say so, then say how you would set up coordination for those four teams on the first update. Hold through two follow-ups by returning to the checklist, never by adding a team. | Highest-ROI prep. F10 and F2 are the gaps the JD exposes. |
| C2 | "The JD asks you to own the post-event review and its KPIs. What have you owned, as opposed to presented?" | JD | [grounded] "Presented the monthly retention numbers to the studio head" (your message) | Story-mapped on F3: you presented. Answer slot: if you chose the metrics or wrote the review, say so. If someone else set them, say so plainly and what you did with them. | F3 is the thinnest ownership claim. Hold to "presented" and do not stretch it. |
| C3 | "Have you worked on a game with in-app purchases?" | JD | [grounded] "Never worked on a game with in-app purchases" (your message) | Plain acknowledgment: "I haven't worked on a game with in-app purchases." Then the plan: how you would learn the store's economics: which data you would ask for, and from whom. | F11. The JD does not list monetization. Mobile live events often are tied to it, which is `[generic]`. |
| C4 | "Your background is a puzzle game with content drops. Why would that transfer to a live title with a store?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" (your message); [grounded] "4 years as an associate producer at a puzzle-game studio" (your message) | Story-mapped on F1: the calendar you ran. Answer slot: say what in that process carries over to a title with a store, and what does not. Say what you do not know yet. | F1 and F5 are the transferability case. Keep it to the quote's scope. |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how the retention numbers you presented were counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head" (your message) | Answer slot: if you know how they were counted, say how, in your own words. If you did not build that method, say so plainly. Then say what you presented. | F7 is the retention claim, and no figure has been quoted. The question asks for a method, which the material does not hold. |
| D2 | "Which assumption behind that number would you defend least?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" (your message) | Name the assumption you would defend least, before they ask, in your own words. If you do not know the assumptions, say so. | The weakest-assumption move for any metric (F7). |
| D3 | "Which post-event KPI would you report first, and what would make you stop reporting it?" | JD | [grounded] JD "own the post-event review and the KPIs it reports" | Open, hypothetical. Name one KPI, the decision it informs, and the signal that would retire it. Claim no past work. | Tests ownership of the review (F3) without asking about your history. |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why should we hire you over someone who has run a live title for three years?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" (your message); [grounded] "Never worked on a game with in-app purchases" (your message) | Pause. Restate. Hold: two years running the content-drop calendar for one title. Concede precisely: "I haven't worked on a game with in-app purchases." Do not concede the calendar. | Hold-then-concede. Composure is what is scored. |
| E2 | "That retention result: how much of it was actually you?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" (your message) | Answer slot: if you drove the change in retention, say which part. If you only presented it, say so and what you did with the figures. Do not take credit for a movement you did not drive. | F7 and F3. Stays inside what you presented. |

### F. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | JD | [grounded] "4 years as an associate producer at a puzzle-game studio" (your message); [grounded] "Wrote the release checklist our QA team still uses" (your message) | A 90-second arc built only from your quotes: the puzzle studio, the content-drop calendar, the checklist QA uses, the monthly retention numbers. Nothing more. | Casual register is still scored. |
| F2 | "What live game are you playing now, and what would you change about how it is run?" | JD | [generic] | Name a title you actually play. If you do not play live games, say so. Keep the change to one thing you could defend. | Casual question on the JD's live-events topic. Do not invent a player history. |

## 6. Requirement coverage

| JD requirement | Questions | Notes |
|---|---|---|
| Plan and run the live-events calendar for two titles | A4, C4, E1 | F1 is transferability |
| Coordinate design, art, engineering and community teams | A3, C1 | F2 is discovery |
| Own the post-event review and the KPIs | C2, D3, E2 | F3 is transferability |
| Manage the release checklist with QA | A5, B3 | F4 is presentation |
| 3+ years producing live-service games or apps | C4, E1 | F5. A length requirement, not a gate |
| Experience running a content calendar | C4, E1 | F6 is direct |
| Comfortable with player-retention metrics | D1, D2, E2 | F7 is direct; the figure is unquoted |
| Clear written communication | none, and why: no written sample in the material | F8. Upgrade menu asks for one |
| Careers page: live-incident tabletop | A1, A2 | F9 is discovery |
| Careers page: values conversation | B1, B2, B3, B4 | Values cheat sheet |

## 7. Values cheat sheet

Published values, from saltmarshgames.com/values (fetched):

| Value (official name) | Working meaning | Your mapped story |
|---|---|---|
| Players Before Plans | When the calendar and the players disagree, the players win. | None carried. Scaffold and honest branch in B1. |
| Ship the Patch Not the Promise | Announce what is built, not what is hoped. | None carried. Scaffold in B2; nearest F3. |
| Leave the Build Greener | Every release leaves the codebase and the checklist better than it found them. | F4 carries the checklist. The "better" beat is not stated: answer slot in B3. |

## 8. Reading the interviewer

Public footprint only, from a search that returned a talk listing (not opened):

- **Tobias Wrenfield, Head of Live Operations.** The listing describes a GDC 2026 talk, "Patch Notes Are a Promise," and a previous role as a QA lead at a console studio. Its argument: a live team is judged by how often its patch notes describe what actually shipped.
- **Implications.** Expect questions on what was announced versus what shipped (B2). He came up through QA, and so did your checklist work: a shared professional path, not a shared identity. A reverse question about the QA-to-live-ops move (R2) is fair.
- **Caveat.** The talk link returned by the search was not opened, and its domain looks like a placeholder. Verify the talk before you mention it. Drop R1 if you cannot.

## 9. Reverse questions

Each lands for a reason:

- **R1.** "Your talk argues patch notes should describe what shipped. Where does your team see the gap?" Why it lands: it shows you read his work. Use only if the talk checks out.
- **R2.** "You came up through QA before running live ops. What from that still shapes how your team works?" Why it lands: it converts an interview into a peer conversation about his path.
- **R3.** "How is the calendar planned across the two titles today, and who holds the trade-offs?" Why it lands: it tests the role's real scope.
- **R4.** "Which KPI does the studio review most, and how is a bad one handled?" Why it lands: it shows you understand the review the role owns.
- **R5.** "What would a strong first quarter look like for this role?" Why it lands: it asks for the scoring in his own words.
- **R6.** "What has changed in the release checklist with QA over the last year?" Why it lands: it shows you know the artifact you would manage.

## 10. Sources

Provided: your JD text and background message.

Searches and fetches (research tier L1):

- `Saltmarsh Games values`: returned saltmarshgames.com/values.
- `Saltmarsh Games interview process live operations producer`: returned saltmarshgames.com/careers/interviewing.
- `Tobias Wrenfield Saltmarsh Games`: returned a GDC 2026 talk listing (not fetched).
- Fetched: saltmarshgames.com/careers/interviewing; saltmarshgames.com/values.

Research tier: L1, searches 3 of 6, fetches 2 of 2.

| Target | Status | What it moved |
|---|---|---|
| 1. Company values | yes | Values cheat sheet, section 7 |
| 2. Interview process | yes | The loop: the Outage Hour, persona weights, A1 and A2 |
| 3. Strategy / recent news | skipped | The round is a case and values conversation; the careers page fixes its content |
| 4. Interviewer name | yes | Section 8, with the talk caveat |
| 5. Representative JD | skipped | The JD supplied fixes the fit snapshot |

## 11. Upgrade menu

- **Your CV** → converts the "your message" quotes into CV quotes, which raises F1 to F7 to `high` where the CV carries them.
- **The release checklist, or a redacted copy** → makes F4 inspectable, so F4 can rise from medium to high.
- **A calendar sample from the content-drop schedule** → makes F6 inspectable.
- **A written update or review you wrote** → gives F8 an artifact.
- **Confirmation of the Friday format and Tobias's role** → confirms the round in section 1.
- **A deeper research pass**, up to 6 more searches and 2 more fetches, several more minutes. It would cover the company strategy, Tobias's talks in full, and recent org changes at Saltmarsh.
