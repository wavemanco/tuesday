Your prep pack is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-tuesday-part-2-rooms-case-7-denied-c35495aa/3bf753cf-ae7f-4437-a6bc-65ed960b292d/scratchpad/Saltmarsh_Games_live-ops-producer_interview_pack.md` and attached here. I built it for a hiring-manager round with Tobias, since your note didn't say who you're meeting.

I couldn't research Saltmarsh or Tobias, because web search wasn't permitted in this session. The pack rests on your JD and your message only. No values page, loop structure, strategy, or interviewer profile is in it.

The biggest risk is B1: "You've never led a team. How would you get design, art, engineering and community to commit to an update's date when none of them report to you?" The JD asks for exactly that coordination, so expect it in some form. Rehearse the hold first ("I haven't led a team"), then the calendar work you did, then a concrete plan for getting the commitment. Don't add leadership you haven't done.

Two questions, so the pack fits your 60 minutes:
- Is Friday's round just you and Tobias, or is there a panel or a take-home?
- Did the recruiter say anything about process or focus areas? If so, paste it and I'll tighten the coverage.

Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Saltmarsh_Games_live-ops-producer_interview_pack.md -----
# Interview prep pack: Live Operations Producer, Saltmarsh Games

Interviewer: Tobias Wrenfield, Head of Live Operations. Relationship: assumed hiring manager (not confirmed). Format: 60 minutes, one session.
Changelog: first version.

## How to use this pack

Personas are how a question arrives. Types are what it scores.

- **VAL**: behavioral / values alignment
- **EXP**: work-experience deep-dive
- **JD**: role and JD-driven
- **CO**: company and strategy knowledge
- **CASE**: hypothetical or live problem

Guidance is scaffolding, not a script. Say the parts that are yours in your own words. Where a guidance cell says "answer slot," give whichever branch is true.

## Fit snapshot

Requirements are quoted from the JD you pasted, or from your message when they are not JD lines. Your evidence is quoted from your message; no CV was provided.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years producing live-service games or apps" (JD) | "4 years as an associate producer at a puzzle-game studio" (your message) | medium | [grounded] | transferability | Your material gives four years on a puzzle game. It does not say the game was live-service, so do not call it that unless you can say what made its cadence live. Answer slot: if the game's content was released on a schedule after launch, say how; if you cannot say that, stay with the four years. |
| F2 | "experience running a content calendar" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | high | [grounded] | none | No gap. Lead with the calendar in the quote's own terms: weekly, main title, two years. |
| F3 | "comfortable with player-retention metrics" (JD) | "Presented the monthly retention numbers to the studio head" (your message) | medium | [grounded] | presentation | Your material reaches retention through presenting it. Words: "Presented the monthly retention numbers to the studio head." The bridge stops there; if asked what you did with the numbers, stay with what you presented. |
| F4 | "Plan and run the live-events calendar for two of our mobile titles" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | medium | [grounded] | transferability | Your material gives one title and a weekly drop cadence. The JD asks for two titles and live events. Say what you did for the main title and nothing wider. Answer slot: if you planned for any title beyond the main one, say which and how; if you did not, say so plainly. |
| F5 | "coordinate design, art, engineering and community teams on each update" (JD) | "Wrote the release checklist our QA team still uses" (your message) | low | [inferred] | discovery | Your material shows one cross-team link, to QA, and does not show whether it reached design, art, engineering or community. Answer slot: if you coordinated any of those teams on an update, say which and how; if you did not, say so plainly and say how you would set it up. |
| F6 | "manage the release checklist with QA" (JD) | "Wrote the release checklist our QA team still uses" (your message) | medium | [grounded] | none | No gap in kind. Lead with the checklist in the quote's terms: you wrote it, and QA still uses it. |
| F7 | "own the post-event review and the KPIs it reports" (JD) | "Presented the monthly retention numbers to the studio head" (your message) | low | [inferred] | discovery | Presenting numbers is not owning a review or its KPIs, and the bridge should not be stretched. Answer slot: if you ran a post-event review, say what it covered and who read it; if you did not, say so plainly and say what you would review first. |
| F8 | "clear written communication" (JD) | none given | none | [grounded] | discovery | The material shows no written sample of yours. Answer slot: if a checklist, report or update you wrote can be described, say what it was for; if none can, say how you would show it. |
| F9 | Lead a team (not a JD line; raised by your message) | "Never led a team, and never worked on a game with in-app purchases" (your message) | none | [grounded] | capability | Plain acknowledgment: "I haven't led a team." Then a plan for how you would learn it, said as a plan and never as a past. |
| F10 | Games with in-app purchases (not a JD line; raised by your message) | "Never led a team, and never worked on a game with in-app purchases" (your message) | none | [grounded] | capability | Plain acknowledgment: "I haven't worked on a game with in-app purchases." The JD does not name monetization, so expect a probe on it only if the interviewer raises it. |

## Prohibited claims

What this pack will not coach, and why. Each entry names its basis.

| Not coached | Basis | Honest form |
|---|---|---|
| Led a team | Negative you stated, F9 | "I haven't led a team." No slot on leadership history. |
| Worked on a game with in-app purchases | Negative you stated, F10 | "I haven't worked on a game with in-app purchases." |
| Ran the live-events calendar for two titles | Inflated form of F2 and F4 | F2's quote at its own scope. Observation, in this pack's analysis: your material says one main title, not two. |
| Owned the post-event review and the KPIs it reports | Inflated form of F7 | F3's quote at its own scope. Observation: your material says you presented the numbers, not that you owned the review. |
| Shipped live-service games | Inflated form of F1 | F1's quote at its own scope. Observation: your material says a puzzle game. |
| Managed the release checklist | Inflated form of F6 | "Wrote the release checklist our QA team still uses." Observation: your material says you wrote it, not that you ran QA's process. |

## Persona table

Relationship prior for a hiring-manager round is Case/Strategist plus Skeptic. No public footprint for Tobias was retrieved, so the interviewer signals do not adjust these weights. The loop is not documented, so the weights rest on the archetype and the round type, which is an assumption.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy | Weight |
|---|---|---|---|---|
| Case/Strategist | Live problem on the two titles' calendar, or an update that slips | High. A hiring manager buys capability against the JD's calendar and coordination mandate. | Clarify before structuring; state what you need to know first. | 5 |
| Skeptic | "You've never led a team" and "in-app purchases" | High. F9 and F10 are the gaps the material shows, and the JD asks for cross-team coordination. | Hold, then bridge with the quote you have, then a plan. | 5 |
| Data-Driven Prober | Retention numbers, their definitions, KPI ownership | Medium. F3 and F7 are presented, not owned, so a probe on how it was counted is likely. | Name the weakest assumption before they do; say plainly what you do not know. | 3 |
| Pressure / Stress | A time-boxed challenge. Sixty minutes is long enough for one. | Medium. Weighted at 3 because the slot is long enough to hold a challenge round, but the hiring-manager prior is not Pressure-heavy. | Pause, restate, hold a position through two follow-ups before any concession. | 3 |
| Conversational / Rapport | An opener: "walk me through the journey" | Medium. Usually the first question. | A 90-second arc that you have rehearsed aloud. | 2 |

## Question banks

Type and provenance come before guidance. Question IDs are letter-by-persona.

### Case/Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Two titles, one live-events calendar. What do you need to know before you lock next quarter?" | CASE | [generic] | Clarify before structuring: the two titles' current retention and revenue baseline, team capacity, QA windows, and what is already committed. Then objective, sequencing and risks. Makes no claim about your past. | Raised by the JD's calendar mandate, J1. Generic because the question is a live problem, not a fact about you. |
| A2 | "An update's QA sign-off slips two days before launch. What do you do?" | CASE | [generic] | Structure: what QA must confirm, what can be cut, who decides, and what the community hears. Makes no claim about your past. | Raised by the JD's release-checklist line, J4. Scores how you run a checklist under time pressure. |
| A3 | "Design wants a bigger reward for the event, and engineering says the build cannot support it by the date. How do you settle it?" | CASE | [generic] | Name the decision owner, the dates, the options and the cost of each, and how the decision is written down. No claim about your past. | Raised by the JD's line to coordinate design, art, engineering and community on each update, J2. A live problem from the role, so it presupposes nothing about you. |
| A4 | "Retention dropped after last month's event. Which numbers do you pull first, and what would you need to know about how they were counted?" | CASE | [generic] "Presented the monthly retention numbers to the studio head" | Name the metric, the cohort, and the comparison window; name the assumption you would test first. Answer slot: if you have pulled a post-event read before, say how it was counted, in your own words; if you have not, say so plainly and describe the steps. | Raised by the JD's retention and KPI lines, J3 and J7. F3 is the thin evidence behind it. |
| A5 | "What goes in a post-event review, and what would you do if a KPI moved the wrong way?" | JD | [generic] | Structure: the hypothesis, the metrics against plan, what changed, the owner of each next action. Answer slot: if you have run a review, say what it covered and who read it; if you have not, say so plainly and say what you would do first. | Covers J3, the post-event review line. F7 is the evidence gap behind it. |

### Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've never led a team. How would you get design, art, engineering and community to commit to an update's date when none of them report to you?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases"; [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | **The highest-ROI prep in this pack.** This is the objection the JD and your material most likely produce. Hold: "I haven't led a team." Then the nearest thing your material carries: "I ran the weekly content-drop calendar for our main title for the last two years." Then how you would get the commitment, in writing, with the decision owner and the dates, said as a plan and never as a past. Answer slot: if you have got a team that does not report to you to commit to a date, say how, in your own words; if you have not, say so plainly and describe how you would set it up. Hold through two follow-ups by returning to the calendar, never by adding to it. Concede specifically: "Leading a team is the part I haven't done yet." | Raised by the JD's coordination line, J2, against F9. Deepest rehearsal because it will be asked in some form. |
| B2 | "The JD asks for three years of live-service work. Your material shows four years on a puzzle game. How do you bridge that?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio"; raising source: J5 "3+ years producing live-service games or apps" | Say the quote, then the cadence beats the quote states: the weekly content drop. Answer slot: if the puzzle game's content ran live in the sense the JD means, say what made it so; if it did not, say so and say what carries across. Do not describe the game as live-service unless you can say why. | Raised by J5 against F1. Transferability, so the bridge stays inside the quote's scope. |
| B3 | "You have not worked on a game with in-app purchases. What would you need to learn first, and how?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases" | Plain acknowledgment: "I haven't worked on a game with in-app purchases." Then three things you would learn first, as a plan and never as a past. | Stated negative, F10. The JD does not name monetization, so this is a probe for a live-events role, not a requirement in the text. |
| B4 | "You presented retention numbers to the studio head. Did you own the post-event review, or present someone else's analysis?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head"; raising source: J3 "own the post-event review and the KPIs it reports" | Hold the quote: "Presented the monthly retention numbers to the studio head." Answer slot: if you did the analysis or ran the review, say which parts and how; if you presented numbers someone else built, say that plainly. Concede specifically if the review was not yours. | F7's gap. The second branch is what makes the question honest, so use it if it is true. |
| B5 | "Your release checklist is still used by QA. Did you change it after you wrote it?" | EXP | [grounded] "Wrote the release checklist our QA team still uses" | Plain statement: "I wrote the release checklist our QA team still uses." Answer slot: if you changed it since, say what changed and why; if you did not, say so plainly. | Premised question on a quoted sentence. F6 is the evidence. |

### Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how you ran the weekly content-drop calendar for two years." | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Beats the quote states: the weekly cadence, the main title, the two years. Tell them in your own words. Answer slot: name what you decided yourself on the calendar and what was set above you; if nothing was yours to set, say so and describe how the calendar ran. | F2 is the strongest evidence in the pack, so this is where a probe will go to check it. |
| C2 | "Which retention figure did you present most often, and how was it defined?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Name the figure in your own words. Name the assumption behind it that you would defend least, before they do. Answer slot: if you defined the figure, say how; if you did not, say so plainly and say who did. | F3 is the evidence, and it has no figure in it. A definition is a practice, so the second branch must allow that it was not yours. |
| C3 | "Name one KPI you would report from every event. Why that one?" | JD | [generic] | Name one KPI, the reason it reads retention or revenue, and what would make you change it. No claim about your past. | Covers J3. Generic because it asks for a judgment, not a fact about you. |

### Pressure / Stress (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why should we hire someone who has never led a team for this role?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases"; [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Pause. Restate the question. Hold: "I haven't led a team." Then the quote about the calendar. Then the first 90 days, as a plan. Hold-then-concede: hold that the calendar work is the relevant part; concede that leading is untested. | F9 under a time-boxed challenge. Hold, then concede specifically. |
| D2 | "That calendar claim: how much of it was actually you?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Hold the quote's scope. Answer slot: say which parts were yours to decide; if some were not, say so. Hold two follow-ups before conceding anything. | F2 under pressure. The hold is only what the quote carries. |
| D3 | "You presented retention numbers. Why should I trust you to own the KPIs?" | JD | [grounded] "Presented the monthly retention numbers to the studio head"; raising source: J3 "own the post-event review and the KPIs it reports" | Hold the quote. Concede specifically: "Presenting the numbers is what I did; owning the KPIs is what I would need to show you." Then one thing you would do in the first month. | F7 under pressure. |

### Conversational / Rapport (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio"; [grounded] "I ran the weekly content-drop calendar for our main title for the last two years"; [grounded] "Wrote the release checklist our QA team still uses"; [grounded] "Presented the monthly retention numbers to the studio head" | A 90-second arc through the four quotes, in that order. Tell them in your own words. Do not add a title, a team or a number. | Opener. Casual questions are still scored. |
| E2 | "What are you playing right now, and what would you change in its events?" | CO | [generic] | Name one live game you play, one event you would change, and why. Makes no claim about your past. | Casual register on a live-ops topic. Generic because it asks about your taste, not your work. |

## Requirement coverage

| JD requirement | Covered by |
|---|---|
| Plan and run the live-events calendar for two mobile titles | A1, C1 |
| Coordinate design, art, engineering and community on each update | A3, B1 |
| Own the post-event review and the KPIs it reports | A4, A5, B4, C3, D3 |
| Manage the release checklist with QA | A2, B5 |
| 3+ years producing live-service games or apps | B2 |
| Experience running a content calendar | C1, D2 |
| Comfortable with player-retention metrics | C2, A4 |
| Clear written communication | none, and why: the pack has no written-sample question. A 60-minute spoken round does not test it well; see the upgrade menu. |

## Reverse questions

No interviewer profile was available, so none ties to Tobias's own path. The round is assumed to be a hiring-manager round, so no reciprocity question is included.

1. "What do the two titles' live calendars look like today, and which one is harder to hold?" Why it lands: shows you already think in calendar terms, not just in your own work.
2. "How is the post-event review used, and who reads it? What changes because of it?" Why it lands: tests whether the review is a real input or a formality, which goes to the KPI ownership the JD names.
3. "Where does the QA release checklist sit relative to the content calendar, and who approves changes to it?" Why it lands: connects to what you wrote, and shows you know the checklist is a shared tool.
4. "Which retention metric is the north star for each title?" Why it lands: a question a hiring manager has to answer clearly, which tells you whether the KPIs are settled.
5. "How are design, art, engineering and community sequenced on an update, and who has the final say on a cut?" Why it lands: goes straight to the coordination the JD asks for, and to the decision owner you would need to name in B1.
6. "What would a good first 90 days look like, and what did the last person in this role get wrong?" Why it lands: makes the conversation about the role, and shows you plan to work on the gap rather than explain it away.

## Sources

Provided documents: the JD and your message, as pasted in the conversation.

Searches sent, with outcome:

- "Saltmarsh Games mobile studio": refused (no search permission in this session).
- "Tobias Wrenfield Head of Live Operations Saltmarsh Games": refused (no search permission in this session).

No page was fetched.

Research tier: L1 requested; searches 0 of 6 returned, fetches 0 of 2, because search permission was refused.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | unavailable | Values cheat sheet, section 10. Not included, because no values page was read and no values-style round is established. |
| 2. `Saltmarsh Games interview process live operations` | unavailable | Loop structure. Persona weights rest on the hiring-manager prior, not a documented loop. |
| 3. `Saltmarsh Games strategy` / recent news | unavailable | Grounding brief and CO questions. Current strategy is absent, so E2 and the CO slots are generic. |
| 4. `Tobias Wrenfield Saltmarsh Games` | unavailable | Interviewer read and tailored reverse questions. Query sent and refused. |
| 5. representative Live Operations Producer JD | skipped | The JD you pasted fixes the fit snapshot and the JD-tagged questions. |

## Upgrade menu

- Your prep time before Friday → a prioritized triage section that orders the questions above by time available.
- The recruiter's note on the round format, or any take-home or presentation → confirms whether the round has a graded deliverable, and adds a build section if it does.
- Tobias's public talks or posts, pasted → persona weights from his own footprint, and a reverse question tied to his path.
- Saltmarsh's values page, pasted → the values cheat sheet, mapped to your quoted stories.
- Your CV → the "your message" quotes can become "your CV" quotes, and F3 and F7 can rise from low or medium confidence.
- The retention figures you presented → defend-the-number slots on C2 and A4, with the weakest assumption named.
