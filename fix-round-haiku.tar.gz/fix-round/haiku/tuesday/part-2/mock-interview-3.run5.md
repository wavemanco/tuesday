Your prep pack is saved as `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-tuesday-part-2-rooms-case-3-denied-f892f9b9/a5f07f07-a90b-4dc3-81d6-6c571f0e5085/scratchpad/stripe_product-operations-manager_interview_pack.md`. I built it for a final round with an unknown interviewer, since your note didn't say who you're meeting or what format the round takes.

It's built from the role title alone, so it's thinner than it could be. Web search was refused in this session, so I couldn't check Stripe's values or interview structure. I didn't fill those gaps from memory. The values cheat sheet is dropped, and the loop is a generic big-tech pattern, not Stripe's documented process. The pack has 22 generic questions across seven interviewer styles, weighted toward case and values questions. The experience questions are open prompts with honest fallbacks, since I have none of your sentences to draw on.

Two things would change it most:

- Who you're meeting and whether it's your future manager or a peer. This reweights every question bank.
- Your CV and the job description. With them, the pack can quote your own sentences and map real stories to the requirements.

Want me to play the Skeptic on E1, the question the pack expects to be the hardest to answer well? I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: stripe_product-operations-manager_interview_pack.md -----
# Stripe, Product Operations Manager: final-round prep pack

**Round:** final round. **Interviewer and relationship:** not given. **Format:** not given.
**Built on:** company and role title only. No job description, no CV, and no web research (web search was not permitted in this session, so every research target below is unavailable).
**What changes it:** the sections marked as needing a JD or CV are skeletal until those arrive. See the upgrade menu.

## 1. How to use this pack

- **Personas** describe how a question is asked (its style and register).
- **Types** describe what is being scored: VAL (values and behavior), EXP (past work), JD (stated role requirements), CO (company knowledge), CASE (a live problem).
- Guidance is scaffolding for a spoken answer, not a script. Rehearse only what you actually did, in your own words.

## 2. Fit snapshot (worksheet variant)

No JD and no CV were supplied, so there are no quoted requirements and no quoted evidence. The rows below are role-family requirements written as plain prose, labeled `[generic]`. Every evidence cell reads `none given`. Each bridge is a selection scaffold, not a claim.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| R1 | Designing and running a planning or review cadence across several product teams | none given | none | [generic] | discovery | Selection scaffold: pick a planning cycle you helped set up or run. Say what it replaced, who used it, and whether it held. If you have not run one, say so plainly and describe how you would design one. |
| R2 | Managing a launch or rollout that spans several functions | none given | none | [generic] | discovery | Selection scaffold: pick a launch that needed more than one team to agree. Say what the readiness checklist covered and what you personally owned. If you did not own it, say so and describe your part. |
| R3 | Building metrics or dashboards that a team actually uses | none given | none | [generic] | discovery | Selection scaffold: pick a metric someone acted on. Say who acted, and what changed. If none of your metrics were acted on, say so and describe the one you would build first. |
| R4 | Turning ambiguous requests into prioritized process work, and saying no | none given | none | [generic] | discovery | Selection scaffold: pick a request you declined or re-scoped. Say what you offered instead and what the requester did next. |
| R5 | Documenting and maintaining processes and tools so others can run them | none given | none | [generic] | discovery | Selection scaffold: pick a process you documented. Say who used the document and whether they used it without you. |

## 3. Prohibited claims

None listed. Every entry on this list comes from a candidate sentence that limits a stretched wording, or from a stated negative. The pack has no candidate sentences yet, so nothing can be listed. Until a CV or your own words arrive, every story you tell should come from your own memory of what you did. Do not borrow an impressive outcome from a colleague or from a generic example.

## 4. Persona weights

Relationship is unknown and the round is a final. Stripe's own loop is not established (see section 13), so the fallback archetype is big-tech structured, with its tilt toward case and values. The archetype is a pattern, not a confirmed description of this company's process.

| Persona | Weight | Why |
|---|---|---|
| Case / Strategist | 5 (top) | Big-tech structured fallback tilts toward a live problem in a final round |
| Values / Behavioral | 4 | The fallback archetype usually includes a values round. No values are established, so questions are generic |
| Pressure / Stress | 3 | Finals often test composure. Weight is flat because the interviewer's style is unknown |
| Data-Driven Prober | 3 | Process and metrics roles get probed on how numbers were counted |
| Skeptic | 3 | The most likely objection is not known until a CV arrives, so this stays mid-weight |
| Conversational | 2 | Casual openers are still scored |
| Peer Evaluator | 2 | Kept in case the final includes a peer from a partner team |

## 5. Question banks

Every question here is `[generic]`. Nothing in these banks asserts anything about your experience, because the pack has none to quote. Experience questions are open prompts with selection scaffolds, and each one ends with an honest branch.

### A. Case / Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A launch you own has shipped and adoption is flat after two weeks. Walk me through how you'd diagnose it." | CASE | [generic] | Clarify the goal and what "adoption" means. Segment the users. Form two or three hypotheses. Name the metric you would check first and the risk you would watch. Think aloud. | Live problem from the role's core launch work. Structure is scored over the answer. |
| A2 | "How would you design the operating cadence for a product org whose planning runs through five different tools?" | CASE | [generic] | Start with what the cadence must decide, then who needs to see what, then the smallest change that gets there. Name one thing you would not change yet. | Role-family problem. Tests altitude and sequencing. |
| A3 | "How would you know, six months from now, that a new internal process is working?" | CASE | [generic] | Name the outcome the process is for, then one leading and one lagging measure, then the point at which you would stop or change the process. | Tests whether you define success before the process exists. |
| A4 | "A team asks you for a dashboard to answer a question nobody has yet defined. What do you do?" | CASE | [generic] | Clarify the decision the dashboard would support. Offer a smaller version that answers the decision first. Say what you would not build. | Tests scoping and pushback. |
| A5 | "What would make you say no to a request from a senior leader?" | CASE | [generic] | Name the criteria you would apply, such as cost, opportunity cost and whether the request has a decision behind it. Say how you would deliver the no and what you would offer instead. | Tests judgment under seniority pressure. |

### B. Values / Behavioral (weight 4)

No published values are established, so these questions are not mapped to any values. Each one is an open prompt with a selection scaffold.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time you pushed back on a decision from someone more senior." | VAL | [generic] | Pick a time with a named stake, a moment you did not fold, and a relationship that was intact at the end. Use "we" for context and "I" for what you did. If no such time comes to mind, say so plainly, then give the nearest thing you have and how you handled it. | Open prompt. Tests candor under seniority. |
| B2 | "Tell me about a process you changed that people initially resisted." | VAL | [generic] | Pick a process where the change was real. Say what the resistance was, what you did about it, and what changed afterward. If the change did not stick, say so. | Open prompt. Tests change management. |
| B3 | "Describe a time you made a call with incomplete data." | VAL | [generic] | Name what was missing, what you chose to do anyway, and how you would decide differently with the data in hand. Keep the decision and the outcome separate. | Open prompt. Tests judgment. |
| B4 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Pick a case where the customer's need and the team's target actually conflicted. Say which you chose, what it cost, and what you told the team. If none comes to mind, say so and describe the nearest case. | Stem from the values persona. Open prompt. |

### C. Pressure / Stress (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Sixty seconds: why you over an internal candidate?" | JD | [generic] | Pause. Restate the question. Answer with one specific thing you bring that the internal candidate would need to learn. Hold it through two follow-ups. Concede specifically if you are uncertain, and never fold on the core claim. | Stress-persona opener, time-boxed on purpose. |
| C2 | "Tell me about a result you're proud of. How much of it was your own doing?" | EXP | [generic] | Pick a result with a clear outcome. Separate your part from the team's. Name the part you would defend least. If the result was mostly a team's, say so and describe your share. | Open prompt. Tests attribution under challenge. |
| C3 | "What's the strongest argument that product ops is just overhead here?" | JD | [generic] | Acknowledge the argument fairly. Name the cost it points to, then the one thing product ops prevents or speeds up that the team would notice if it were gone. Hold your position and concede only where the argument is right. | Challenges the premise of the role. Tests composure and fairness. |

### D. Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Pick a metric you've moved. How was it counted, and what would have changed the answer?" | EXP | [generic] | Name the metric, what it counted and what it excluded. Name the assumption you would defend least before the interviewer does. If you did not know how it was counted, say so. | Open prompt. Metric questions get probed to their assumptions. |
| D2 | "What's the one number you'd want to see before trusting a process's impact?" | CASE | [generic] | Name the baseline or comparison first, then the measure. Say what would make you distrust it. | Tests measurement thinking. |
| D3 | "If a process metric went up 20% last quarter, what would you check before celebrating?" | CASE | [generic] | Check whether the definition changed, whether the population changed, whether a shock explains it, and whether the metric moved for the wrong reason. Name the first check you would run. | Tests skepticism about numbers. |

### E. Skeptic (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | Name one specific area and why. Then say how you would close the gap in the first month. Calibrated candor beats bluffing. | Stem from the Skeptic persona. Highest-ROI prep, since it is the most predictable objection to any candidate without a CV in hand. |
| E2 | "Why leave where you are, and why now?" | JD | [generic] | Give a reason that points toward the role, not away from your current job. Keep it short and specific. | Motivation-consistency check. Asked in almost every final round. |
| E3 | "Where would your experience be thinnest for this role, and how would you close it?" | JD | [generic] | Name the thinnest area honestly. Describe a concrete closing step, such as a project, a mentor or a reading plan. Do not invent experience to cover it. | Open skeptic probe. Tests self-awareness. |

### F. Conversational / Rapport (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [generic] | Prepare a 90-second arc: where you started, one turning point, why this role now. Say it in your own words. | Casual opener that is still scored for communication economy. |
| F2 | "What has made you most curious about this role?" | JD | [generic] | Name one specific thing about the work, not the company's reputation. Keep it short. | Tests genuine interest, scored casually. |

### G. Peer Evaluator (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Our teams sit side by side. Where's the seam between us, and what happens when we disagree?" | JD | [generic] | Propose seam principles rather than claiming to know their seam. Describe how you disagree with an equal: say the view, hear the reply, then decide together. | Stem from the Peer persona. Tests partnership fit. |
| G2 | "How do you handle credit when work spans teams?" | EXP | [generic] | Say how you name each team's contribution in writing and in the room. If you have not faced this yet, say so and describe the default you would use. | Stem from the Peer persona. Open prompt. |

## 6. Requirement coverage

No JD was supplied, so there is no requirement list to map. The table is built when a JD arrives. Until then, the role-family requirements in section 2 (R1 to R5) are covered as follows: R1 by A2 and A3, R2 by A1 and A4, R3 by D1 and D2, R4 by A4 and A5, R5 by B2 and B4.

## 7. Values cheat sheet

Dropped. The condition for this section is a set of published values in hand, and none is established. The values page search was not permitted, so I have not used any values from memory.

## 8. Reverse questions

At least five, each with why it lands. None is tied to the interviewer's own path, because no interviewer is named.

| # | Question | Why it lands |
|---|---|---|
| RQ1 | "What does someone in this role get right in their first 90 days that a strong candidate might miss?" | Shows you are thinking about outcomes, not a task list. |
| RQ2 | "Which decision did this team make recently that was hard to get right? How was it made?" | Invites the interviewer to describe how the team actually works. Good for reading their judgment. |
| RQ3 | "Where does product ops end and the product managers' work begin, in practice?" | Surfaces the seam question directly. Interviewers respect people who ask it. |
| RQ4 | "How does your planning cycle work today, and where does it break down?" | Shows you care about the operating system, not a clean one. |
| RQ5 | "What would you want this person to have changed by their six-month review?" | Turns the close into a success-definition conversation. |
| RQ6 | (if the interviewer is a peer) "What could a new person do in their first month that would genuinely help your team?" | A reciprocity question. It signals that you plan to help the peer, not only to be assessed. |

## 9. Sources

Provided documents: the role title and the company name, from the request.

Research tier: L1, searches 3 of 6, fetches 0 of 2. All three search calls were refused by a permission prompt, and no fetch was attempted.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Stripe values | unavailable | Search refused. Values cheat sheet (section 7) dropped. No values are used from memory. |
| 2. Stripe interview process, product operations | unavailable | Search refused. Loop not established, so the fallback archetype in section 4 applies. Would have set the round structure and the persona weights. |
| 3. Stripe strategy, recent news | unavailable | Search refused. The CO bank is absent. Would have produced one or two CO or CASE questions tied to current strategy. |
| 4. Interviewer name and company | n/a | No interviewer name was given, so there is no query to form. |
| 5. Representative product operations JD | unavailable | No call sent. Would have grounded the fit snapshot in a typical posting, labeled `[inferred]`. |

## 10. Upgrade menu

- The job description text → the five role-family rows in section 2 become quoted and `[grounded]`, and the requirement-coverage table in section 6 is built.
- Your CV or résumé → the selection scaffolds become story maps from your own sentences, the prohibited list is built, and the experience questions get real guidance.
- The round format and who you are meeting → persona weights are set by relationship, and the reverse questions are tailored.
- The interviewer's name → a tailored reverse question and persona weights from their public footprint.
- The recruiter's guidance, if you have it → focus areas, any take-home or presentation, and coverage of any graded deliverable.
- Web search permitted for this session → the values page, the loop structure and recent strategy can be checked, which fills sections 7 and 9 and moves the CO bank off `[generic]`.
