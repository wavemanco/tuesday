Your prep pack is saved as `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-tuesday-part-2-rooms-case-3-denied-95004f41/3adcac00-1d43-43cb-ba13-041c3c2683df/scratchpad/stripe_product_operations_manager_interview_pack.md`.

It's a first pass built without your CV, the job description, or any details of the round. Web search was refused in this session, so I could not check Stripe's values, interview structure, or current strategy. The pack labels everything about Stripe as generic and says so where it matters. Your highest-value prep is the "weakest part of this role on day one" question (D1 in the pack), where you name a real gap and give a ramp plan. Expect a case question on a stalled launch or a metric drop, and a values-style prompt about disagreeing with a senior leader.

Two things would make the pack much sharper: your CV and the job description. Both let me replace the scaffolds with your own sentences.

Offers, none pushed:
- A live drill: I can play the Skeptic on D1 or the Pressure interviewer, and give feedback against each question's guidance.
- A `tuesday-dossier.md` recording the gaps this prep exposed, to carry into later sessions.
- A Word version of the pack, if you want one.

Questions:
1. Who are you meeting in the final, and what are their roles? Is it one conversation or several back-to-back sessions?
2. Can you paste your CV and the job description?
3. Are there any requirements you must confirm before the round, such as work authorization, location, or in-office days?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: stripe_product_operations_manager_interview_pack.md -----
# Stripe: Product Operations Manager, final round, interview pack

Changelog: first version. Built with no CV, no job description and no round details. Web research was refused this turn, so nothing about Stripe's values, loop or strategy is established here.

## 1. How to use this pack

- **Personas** describe how a question is asked. **Types** describe what is being scored.
- Type key: **VAL** behavioral and values, **EXP** work-experience deep-dive, **JD** role requirement, **CO** company and strategy, **CASE** live problem.
- Guidance is scaffolding, not a script. Rehearse only what you actually did, in your own words.

## 2. Research status

Research tier: L0, no searches. Web search was refused by the permission setting, so the rows below that would normally carry Stripe's published values, loop structure and strategy are marked unavailable in section 12.

## 3. Fit snapshot (worksheet variant)

No background was given, so every evidence cell reads `none given`. The requirements are role-family patterns, not quotes from a posting, so they are unquoted and labelled `[generic]`. Gap types are `discovery`: the evidence may exist and nothing here shows it. The bridge column says what strong evidence looks like, and the coaching is a selection scaffold ending in an honest branch.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Run cross-functional operating processes end to end, such as planning, launches or reviews (role family) | none given | none | [generic] | discovery | Strong evidence is one process you designed or ran from start to finish, with its owners and its outcome. Pick one. If none was yours to run, say which part you did run |
| F2 | Diagnose a metric or operational problem with data (role family) | none given | none | [generic] | discovery | Strong evidence is one figure you used to make a decision, and how it was counted. If you never counted it yourself, say so |
| F3 | Drive decisions through stakeholders who do not report to you (role family) | none given | none | [generic] | discovery | Strong evidence is one decision you moved where you held no formal authority, and what you did to move it. If none, say so and say how you would start |
| F4 | Build repeatable intake, prioritization or documentation that teams use (role family) | none given | none | [generic] | discovery | Strong evidence is a process or template people kept using after you stopped running it. If none exists, say what you would build first |

No gate rows are known. The round may still carry gates such as work authorization, location or in-office days. Those are asked in section 13.

## 4. Prohibited claims (built locally)

No quotes exist yet, so no stretched wording can be built from them. The list below holds only the general rule for this pack.

| Not coached | Basis | Honest form |
|---|---|---|
| Ownership, scale, metrics or outcomes you cannot describe in detail | Pressure and prober questions test exactly this | Describe what you did, in your words. Share your CV and this list gets rebuilt from your own sentences |

## 5. Persona weights

Relationship and round are unknown, so the weights are flat and said plainly. No loop source establishes Stripe's loop. The fallback archetype is a big-tech structured loop, which usually includes a values-style round. These weights therefore rest on a pattern, not on Stripe's documented process.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | Live operating problems: a stalled launch, a metric drop, an intake backlog | High. Ops roles are scored on structure, and the archetype leans this way | Clarify, then structure, then name metrics and the risk you would watch |
| Values / Behavioral | STAR-shaped prompts about disagreement, failure, users | High. The archetype carries a values-style round; Stripe's own values are not established here | Pick a true story; "we" for context, "I" for your part; say where the material shows none |
| Pressure / Stress | Time-boxed challenge on why you over an internal candidate | Medium. Common in final rounds, not specific to this company | Pause, restate, hold two follow-ups, concede a real gap specifically |
| Skeptic | Probing of gaps: "why now," "where would you be weakest" | Medium-high. Final rounds test motivation and fit | Rehearse the weak spot until it is plain; concrete ramp plan |
| Data-Driven Prober | "How was that number counted?" | Medium. Any metric you give will be probed | Say how it was counted; name the weakest assumption before they do |
| Conversational | Friendly opener, "walk me through your journey" | Low-medium. Casual questions are still scored | A 90-second arc with three beats you can back |

## 6. Question banks

Ordered by weight. Depth follows weight: the top persona gets four questions.

### Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A launch is two weeks from slipping because a partner team has not signed off. What do you do?" | CASE | [generic] | Clarify what the slip costs and who decides. Map the blocker. Decide what to escalate today. Name the trade-off you would accept and what you would tell the launch owner | A live operating problem in the role's own work; `[generic]` because it is a pattern, not a fact about Stripe |
| A2 | "Design an intake and prioritization process for ten product teams sending you requests." | CASE | [generic] | Clarify volume and decision rights first. Propose one simple scoring rhythm. State what you would say no to. Define how you would know the process itself works | Maps to F4; the question is a design problem, so it presupposes nothing about your past |
| A3 | "A key operating metric fell 15% this month. Walk me through your diagnosis." | CASE | [generic] | Check whether the drop is real before anything else: a definition change, instrumentation, a segment mix shift. Rank two or three hypotheses. Name the one check you would run first and the assumption you are least sure of | Maps to F2; a diagnosis scores structure and humility |
| A4 | "How would you know a process change you made actually worked?" | CASE | [generic] | Name the outcome you want, the leading indicator, the baseline you would need, and the date you would look. Say what would make you roll it back | Maps to F2 and F1; tests whether you measure your own work |

### Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time you told a senior leader something they did not want to hear." | VAL | [generic] open prompt | Pick a time you disagreed with someone above you and it cost something. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | Open prompt; theme comes from the archetype's values round, not a published Stripe value |
| B2 | "Tell me about a process you changed that people resisted." | VAL | [generic] open prompt | Pick a process change. Say what the resistance was, what you did, and what changed afterwards. If you have not changed one, say so and say how you would approach it | Maps to F3 and F4 |
| B3 | "Tell me about a project that stalled or failed. What did you change?" | VAL | [generic] open prompt | Pick a real stall. Name what was yours to decide and what was not. If none, say so, then give the nearest one | Maps to F1; tests honesty about attribution |

### Pressure / Stress

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Sixty seconds: why you over an internal candidate?" | JD | [generic] | Pause. Restate the question. Answer with what you can do that the role needs, in one concrete example you can describe fully. Hold through two follow-ups; concede a real gap specifically | Pressure tests composure, not content |
| C2 | "That result: how much of it was actually you?" | EXP | [generic] | Separate what you did, what others did, and what you cannot tell. Do not claim credit you cannot describe in detail. Hold your part through two follow-ups | Attribution probe; tests honesty under pressure |
| C3 | "What would you fix on day one, and why would you be wrong about it?" | CASE | [generic] | Name one specific fix with the reason it matters. Then name the assumption most likely to be wrong and what you would check first | Pressure with a case shape |

### Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | Name the gap plainly. Then give a ramp plan: what you would learn first, from whom, in what order. Do not bluff a skill you lack | **Highest-ROI prep in this pack.** It is almost certain to be asked in some form. Without a CV, the gap is unknown, so rehearse the honest shape: a named gap and a plan |
| D2 | "Why leave where you are, and why here, and why now?" | EXP | [generic] | One reason about the work, one about the company, one about timing. No criticism of your current employer | Motivation-consistency check; the answer must hold together across three parts |

### Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Pick a number you have reported. How was it counted?" | EXP | [generic] open prompt | Name the figure, the definition, the source, and one thing it is sensitive to. Name the assumption you would defend least. If you did not count it yourself, say so | Open prompt; prober follow-ups go two levels deep |
| E2 | "Which assumption behind your best result would you defend least?" | EXP | [generic] | Name the assumption before they do. Say what would change if it were wrong | Converts a gotcha into a credibility point |

### Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through your journey." | JD | [generic] | A 90-second arc in three beats: where you started, what you built or ran, why this role now. Each beat a sentence you can back | Casual openers are scored too |

## 7. Coverage line

| Requirement | Question IDs | Note |
|---|---|---|
| F1 cross-functional process | A2, B3, D1 | |
| F2 metric diagnosis | A3, A4, E1 | |
| F3 stakeholders without authority | B2, C2 | |
| F4 intake and documentation | A2, B2 | |

The values cheat sheet is omitted. Its condition is a published values list in hand, and none is. The archetype fallback suggests a values round, but that alone does not fill the section.

## 8. Reverse questions

Five, each with why it lands. None is tied to the interviewer's path, because no interviewer was named.

1. "What does success look like for this role in the first six months?" Why it lands: shows you are scoping the job, not just wanting it.
2. "Which operating problem would this role solve first?" Why it lands: turns the interview into a shared problem.
3. "How do decision rights split between product operations and the teams it supports?" Why it lands: the question that exposes the real job.
4. "What is the hardest trade-off the team made last quarter?" Why it lands: tests how candid the answer is.
5. "What would make you say the hire was a mistake a year from now?" Why it lands: surfaces the success measure directly.

## 9. Delivery notes

- Prep time was not given, so no prioritized schedule is included. The highest-ROI item is D1: rehearse a named gap and a ramp plan until it is boring.
- Everything else is insurance.

## 10. Sources

- Provided documents: none beyond this conversation.
- Searches attempted: "Stripe company values operating principles" (refused); "Stripe interview process final round onsite behavioral values" (refused).

Research tier: L0, no searches counted as successful. Calls refused: 2 of 6.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Stripe values` | unavailable | Values cheat sheet, section 6 and section 7. Omitted; calls refused |
| 2. `Stripe interview process product operations` | unavailable | Loop structure. Persona weights fall back to an archetype and say so |
| 3. `Stripe strategy` / recent news | unavailable | CO bank, section 6. Currently no CO questions |
| 4. Interviewer name | n/a | No name given |
| 5. Representative JD | unavailable | Would have grounded the requirements in section 3 as `[inferred]` |

## 11. Upgrade menu

- Your CV or resume → the fit snapshot gets verbatim quotes, the story maps replace the scaffolds, and the prohibited list gets real content
- The job description → the requirement rows gain quotes, and the coverage line becomes checkable
- The interviewer's name → a tailored reverse question and persona weights from their public footprint
- The recruiter's note on round format → confirms whether the final is several sessions and whether any deliverable is announced
- Web search permission → Stripe's values, loop structure and strategy, with a values cheat sheet and CO questions
