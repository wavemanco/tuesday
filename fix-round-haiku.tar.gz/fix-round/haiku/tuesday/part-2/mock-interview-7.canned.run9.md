Your prep pack is saved as `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-tuesday-part-2-rooms-case-7-canned-011bf275/c410a50d-6c62-4baf-a009-8fe01ea330d3/scratchpad/saltmarsh_live-operations-producer_interview_pack.md`. I built it for the Outage Hour, the hiring-manager round Saltmarsh's careers page describes: a live-incident tabletop during a live event, then a values conversation. There's no take-home.

The biggest risk is the two-title, live-event gap. Question C1 is the one to rehearse first. Hold on the two years you ran one title's calendar, and concede the second title plainly rather than stretching the claim.

Say the word and I'll play the Skeptic on C1, or run a tabletop drill on A1.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Have you ever worked through a live incident or outage, even a small one on your puzzle title? If so, the tabletop questions (A1, B1) can use a real story instead of a scaffold.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh_live-operations-producer_interview_pack.md -----
# Saltmarsh Games: Live Operations Producer interview prep pack

**Role:** Live Operations Producer, Saltmarsh Games
**Round:** The Outage Hour, one 60-minute interview with the hiring manager: a live-incident tabletop on a simulated outage during a live event, then a values conversation (saltmarshgames.com/careers/interviewing)
**Interviewer:** Tobias Wrenfield, Head of Live Operations (hiring manager relationship)

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored.
- **Type key:** VAL = behavioral and values; EXP = work-experience deep-dive; JD = the role's stated requirements; CO = company knowledge; CASE = live problem.
- **Provenance:** `[grounded]` traces to your message, a fetched company page, or a named source. `[inferred]` is a derivation I made from a grounded fact. `[generic]` is a role-family pattern with no claim about you or this company.
- Guidance is scaffolding, not a script. Rehearse only what you did, in your own words.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | medium | [grounded] | transferability | Your material says one main title and weekly content drops, not two titles and live events. The bridge stays there: "For two years I ran the weekly content-drop calendar for our main title." Answer slot: if you planned across more than one title, or any event beyond the weekly drops, say which and what your part was; if not, say so and describe how the weekly calendar ran. |
| F2 | "experience running a content calendar" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | medium | [grounded] | none | Your sentence reaches this requirement directly. Confirmed, with one title's calendar behind it; expect a probe on how it ran. |
| F3 | "3+ years producing live-service games or apps" (JD) | "4 years as an associate producer at a puzzle-game studio" (your message) | medium | [grounded] | presentation | The years match. Say "four years as an associate producer at a puzzle-game studio" and no more. The material does not say whether the puzzle title ran as a live service; expect that probe. |
| F4 | "comfortable with player-retention metrics" (JD) | "Presented the monthly retention numbers to the studio head" (your message) | medium | [grounded] | presentation | You presented the numbers. Your material does not show how they were counted or who defined them. Say "I presented the monthly retention numbers to the studio head," and say what you know about the counting, if anything. |
| F5 | "clear written communication" (JD) | "Wrote the release checklist our QA team still uses" (your message) | medium | [grounded] | presentation | One written artifact in active use shows written clarity for a working team. Your material shows nothing about written player-facing or leadership updates; do not stretch the checklist into those. |
| F6 | "manage the release checklist with QA" (JD) | "Wrote the release checklist our QA team still uses" (your message) | medium | [grounded] | transferability | You wrote it; QA uses it. "Manage" is a wider scope than "wrote," so keep the bridge at the verb you have: "I wrote the release checklist, and our QA team still uses it." Your material does not show who signs off a release on the checklist. |
| F7 | "coordinate design, art, engineering and community teams on each update" (JD) | none given | none | [grounded] | discovery | The material is silent on cross-team coordination. Answer slot: if you coordinated any of those teams on an update, say which and your part; if you did not, say so plainly and describe how you would set that up. |
| F8 | "own the post-event review and the KPIs it reports" (JD) | "Presented the monthly retention numbers to the studio head" (your message) | low | [grounded] | discovery | The quote touches KPI reporting without showing whether you owned the review or its KPIs. Answer slot: if you ran a post-event review or chose what it reported, say how; if you presented numbers someone else defined, say that. |

**Observation (analysis, not words for you):** Your material shows one title, one calendar, and one checklist. Nothing in it shows a live event, a two-title plan, a post-event review, or cross-team coordination. Those rows are where the pack has no quote to stand on.

## Interviewer read

Public footprint only. From a search snippet, not a fetched page:

- Tobias Wrenfield gave a GDC 2026 talk, "Patch Notes Are a Promise," as Head of Live Operations at Saltmarsh Games. Earlier, Tobias was a QA lead at a console studio.
- The talk's stated argument: a live team is judged by how often its patch notes describe what actually shipped.

**Implications:**

1. Expect the Outage Hour's values conversation to test accuracy of what you announce. The company's own value "Ship the Patch Not the Promise" points the same way.
2. Your checklist (F6) is a QA-facing artifact. Mirror it as a fact about your work, not as a claim about QA career.
3. Shared jump: none offered. Tobias moved from QA into live ops; your material shows QA as a team you worked with, not a career path.

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy | Qs |
|---|---|---|---|---|
| Case / Strategist | Live incident problems from the role's own live events | High. The company page names a live-incident tabletop as the core of this hour | Clarify scope first, then decide, then say what gets communicated | 5 |
| Values / Behavioral | Scenario probes mapped to the three published values | High. The company page names a values conversation in this hour, so a values-style round is documented, not assumed | Map each value to one story, or say the honest branch | 4 |
| Skeptic | "Why you, with what you have?" | High. The hiring-manager prior, plus the gaps in your own message: never led a team, never worked on in-app purchases | Rehearse the single predictable objection until it's boring; hold, then concede precisely | 4 |
| Pressure / Stress | Time-boxed challenges to claims about your work | Medium. Hiring-manager prior; no stress signal in the sources | Pause, restate, hold through two follow-ups, concede only the specific gap | 3 |
| Data-Driven Prober | Asks how a number was counted | Medium. The JD names retention metrics and KPIs; no public signal of an analytics-heavy history | Say how it was counted if you know; name the weakest assumption; say when you don't know | 3 |
| Conversational / Rapport | Friendly opener, casual questions about the JD | Low. The page structures this hour as an incident then a values talk | Treat casual questions as scored; keep the 90-second arc ready | 2 |

Weights: Case 5, Values 4, Skeptic 4, Pressure 3, Prober 3, Conversational 2. Total 21 questions. Peer Evaluator not weighted: this is not a peer round.

## Question banks

### Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Players are reporting that a reward from your live event isn't granting. You have a few minutes before the community team asks. What do you do?" | CASE | [grounded] "a live-incident tabletop on a simulated outage during a live event" (interviewing page) | Clarify scope first: how many players, which build, is the event still live. Decide whether to pause the event. Write a short holding statement with only what is known. Name the owners in engineering and QA. Decide hotfix or rollback. Write down what you decided and why. About 90 seconds. | The tabletop's core. Scored on structure and clarifying before acting, not on a right answer. |
| A2 | "Retention dropped on day seven after last month's event. Walk me through your first three checks." | CASE | [generic] | Split new from returning players. Compare players who were exposed to the event with those who weren't. Check release timing against the event. Name the weakest assumption in your retention definition before they do. | The JD asks for retention metrics and KPIs. [generic] because it is a pattern for the problem, not a fact about this studio. |
| A3 | "A content drop is three days out and QA flags a blocker in the reward flow. Do you ship?" | CASE | [generic] | Decide on player impact, whether there is a workaround, and the fix ETA. Say what you would announce and what you would not promise yet. | The JD's release checklist line, and the company's "Ship the Patch Not the Promise" value. |
| A4 | "How would you plan the calendar for two titles that share engineers but not designers?" | JD | [generic] | Name the dependencies, freeze dates, and what you would check with each team before committing a date. Make no claim about your past. | Raised by the JD line "Plan and run the live-events calendar for two of our mobile titles." |
| A5 | "Walk me through the weekly content-drop calendar you ran." | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Tell the beats your sentence states: weekly, one main title, two years. Describe how a drop got onto the calendar in your own words. If someone else set a step, say so plainly. | F2 is your strongest evidence and the likeliest place to be probed. |

### Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time the calendar and the players disagreed. Which one won?" | VAL | [generic] open prompt; theme from the published value "Players Before Plans" (saltmarshgames.com/values) | Pick a decision where a date moved for players' sake. If none comes to mind, say so plainly, then say how you would make that call now. | Open prompt. No quote carries this story, so the guidance is a scaffold ending in the honest branch. |
| B2 | "Tell me about a time you announced something before it was built. What happened?" | VAL | [generic] open prompt; theme from "Ship the Patch Not the Promise" (saltmarshgames.com/values) | If you have one, tell it in order. If none comes to mind, say so plainly, then say what you would announce first and why. | Tests the value in the interviewer's own terms. |
| B3 | "What did you leave better than you found it?" | VAL | [grounded] "Wrote the release checklist our QA team still uses" | Your sentence carries the checklist and its continued use. The "better than it found it" beat is not in the quote. Answer slot: if it changed something, say what and how you know; if you have no evidence it changed anything, say so. | Maps "Leave the Build Greener" to F6. The improvement beat is an answer slot. |
| B4 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "Presented the monthly retention numbers to the studio head" | Persona stem. The presentation is your sentence; whether the truth was unpopular is not in it. Answer slot: if the numbers went against what the room expected, say how; if they did not, say so and describe how you presented them. | Values round stem; the presentation is the only record you have of leadership-facing numbers. |

### Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You've run one title's content drops for two years. This role runs live events on two titles, with KPIs and a release checklist. Why should we believe you can do the two-title version?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years"; [grounded] "4 years as an associate producer at a puzzle-game studio"; [grounded] "Plan and run the live-events calendar for two of our mobile titles" (JD) | **Highest-ROI prep.** Hold on the two years on one title and what you ran, and return to it through two follow-ups. Concede the step plainly: name what the second title and the live events would need, and what you'd check first. Answer slot: if you ran a second title or any live event, say which and your part; if not, say so. Never claim the two-title version. | F1 is the gap this objection presses. It is most likely to arrive in some form, and the pack's guidance stays inside your sentence. |
| C2 | "You've never led a team. What's your plan for the first 90 days?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases" | Plain acknowledgment: "I've never led a team." Then the plan, stated as a plan, not as a past. | Your own negative. Speak it plainly and move to the plan. |
| C3 | "You've never worked on a game with in-app purchases. How would you run a store event without that background?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases" | Plain acknowledgment: "I've never worked on a game with in-app purchases." Then how you'd learn it: who you would ask, what you would read first. Make no claim about store work. | Your own negative, rehearsed so the plan is ready before the probe. |
| C4 | "Which of design, art, engineering and community have you coordinated on an update, and how?" | JD | [grounded] JD line "coordinate design, art, engineering and community teams on each update" | Answer slot: if you coordinated any of those teams on an update, say which and your part; if you did not, say so plainly and describe how you would set that coordination up. | F7 is discovery; the material is silent, so the answer is yours to supply. |

### Pressure / Stress

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over someone who has run live events on two titles?" | JD | [grounded] "Wrote the release checklist our QA team still uses"; [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Pause. Restate the question. Anchor in one of the two sentences. Hold through two follow-ups. Concede the specific gap (live events, two titles); never fold on the core claim that you ran a calendar and wrote a checklist QA still uses. | Pressure against the Skeptic objection, in a time box. |
| D2 | "That checklist: how much of it was actually you?" | EXP | [grounded] "Wrote the release checklist our QA team still uses" | Say what you wrote and that QA uses it. Answer slot: if others changed it, say what they changed; if no one changed it, say so. | F6 attribution. Hold the words of the sentence. |
| D3 | "Who else looked at the retention numbers before the studio head did?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Say who checked them. If no one checked them first, say so plainly. | Tests whether the presentation was a single-person figure or a reviewed one. |

### Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Walk me through how the monthly retention numbers were counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Defend-the-number, in your words. If you know how it was counted, say how. Name the assumption you would defend least, if you know one. If you do not know how it was counted, say so plainly. | F4. No figure is given in your material, so the question asks only how the count was made. |
| E2 | "What retention definition would you defend in a KPI review?" | JD | [generic] | Name one definition and the weakest assumption in it. Make no claim about the one you used. | The JD's "player-retention metrics" line. |
| E3 | "The post-event review reports KPIs. Which KPI would you stop reporting, and why?" | JD | [generic] | Pick one KPI. Say what it hides. Say what would replace it. | The JD's "own the post-event review and the KPIs it reports" line. |

### Conversational / Rapport

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | JD | [grounded] "4 years as an associate producer at a puzzle-game studio"; [grounded] "I ran the weekly content-drop calendar for our main title for the last two years"; [grounded] "Wrote the release checklist our QA team still uses"; [grounded] "Presented the monthly retention numbers to the studio head" | A 90-second arc built from those four sentences, in your words. Make no claim beyond them. | Opening question; scored as casually as the rest. |
| F2 | "What are you playing right now, in mobile live service?" | JD | [generic] | Name a game you actually play and one live thing you noticed in it. Say only what is true. | A casual question about a JD topic is still scored. |

## Coverage

| JD requirement | Question IDs |
|---|---|
| Plan and run the live-events calendar for two of our mobile titles | A4, C1, D1 |
| Coordinate design, art, engineering and community on each update | C4, A4 |
| Own the post-event review and the KPIs it reports | A2, E2, E3 |
| Manage the release checklist with QA | A3, D2, B3 |
| 3+ years producing live-service games or apps | C1, F1 |
| Experience running a content calendar | A5, C1 |
| Comfortable with player-retention metrics | E1, E2, D3 |
| Clear written communication | none, and why: no written exercise is announced, and the Outage Hour is spoken. Ask the recruiter in the upgrade menu. |

## Reading the company's values

Source: saltmarshgames.com/values (fetched).

| Value (official name) | Working meaning (paraphrased) | Mapped story |
|---|---|---|
| Players Before Plans | When the calendar and the players disagree, the players win | None of your sentences carries this decision. Scaffold: pick a time a date had to move for players' sake; if none comes to mind, say so plainly, then say how you would make that call now. |
| Ship the Patch Not the Promise | Announce what is built, not what is hoped | None of your sentences carries this. Scaffold: pick a time you announced something after it was built; if none comes to mind, say so plainly, then say what you would announce first. |
| Leave the Build Greener | Every release leaves the codebase and the checklist better than it found them | F6: "Wrote the release checklist our QA team still uses." The checklist and its continued use are in the quote. The "better than it found" beat is not. Answer slot: if it changed something, say what and how you know; if you have no evidence of change, say so. |

## Reverse questions

Each has a reason it lands.

1. "In your GDC talk you argued that a live team is judged by how often its patch notes describe what actually shipped. How do you measure that day to day?" Lands because it asks about the interviewer's own published argument. The talk is from a search snippet, not a fetched page; check the talk before you cite it.
2. "How does the live-ops group work with QA on a release day?" Lands because it shows you are thinking about the checklist's place in the process.
3. "With Project Larkspur moving two titles onto one shared events calendar, what changes for this role?" Lands because it names a change the company announced. Source: saltmarshgames.com/news/project-larkspur (search snippet, not fetched).
4. "What would the first 90 days need to look like for this role to be a success?" Lands because it asks for their standard, not a pitch.
5. "What is the biggest live-events decision on the calendar this quarter?" Lands because it asks for the work itself.

## Prohibited claims

Each entry names its basis and the honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| "I've led a team" | Your stated negative: "Never led a team" | "I've never led a team." Plain acknowledgment, then the plan. |
| "I've worked on a game with in-app purchases" | Your stated negative: "never worked on a game with in-app purchases" | "I've never worked on a game with in-app purchases." Plain acknowledgment, then how you would learn it. |
| "I owned the calendar across two titles" | Inflated form of F1 | "For two years I ran the weekly content-drop calendar for our main title." Limit, as analysis: your material says one title and weekly content drops. |
| "I owned the retention KPIs" | Inflated form of F4 | "I presented the monthly retention numbers to the studio head." Limit, as analysis: your material says presented, not owned definitions. |
| "I ran QA sign-off on releases" | Inflated form of F6 | "I wrote the release checklist our QA team still uses." Limit, as analysis: your material does not show who signs off a release. |

## Sources

Research tier: L1 — searches 4 of 6, fetches 2 of 2; user links read 0

Provided documents: your message (the JD and background).

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | yes | Values cheat sheet: three values by name from saltmarshgames.com/values (fetched) |
| 2. Saltmarsh Games interview process, Live Operations Producer | yes | Loop established by the careers page (fetched): one 60-minute Outage Hour with the hiring manager. No archetype fallback needed |
| 3. Saltmarsh Games strategy / recent news | yes | Project Larkspur (search snippet, saltmarshgames.com/news/project-larkspur): moved reverse question 3. Snippet only, not fetched |
| 4. Tobias Wrenfield Saltmarsh Games | yes | GDC 2026 talk "Patch Notes Are a Promise" and a QA-lead background (search snippet, not fetched): moved the interviewer read and reverse question 1 |
| 5. Representative JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

Queries sent:
- "Saltmarsh Games values": returned saltmarshgames.com/values. Fetched.
- "Saltmarsh Games interview process Live Operations Producer": returned saltmarshgames.com/careers/interviewing. Fetched.
- "Tobias Wrenfield Saltmarsh Games": returned the GDC 2026 talk page. Snippet only.
- "Saltmarsh Games live operations 2026 news strategy": returned saltmarshgames.com/news/project-larkspur. Snippet only.

Deep research (L2) was not run.

## Upgrade menu

- Your Outage Hour prep: a live-event incident you handled, even a small one on your puzzle title → A1 and B1 get a story you have, not a scaffold.
- The recruiter's note: whether the values conversation is with Tobias alone, and whether you are expected to bring anything → confirms the round's shape.
- Two-title or live-event experience, if you have any → C1 and F1 move from the concession to a shown record.
- A fetched GDC 2026 talk page → the interviewer read moves from snippet to checked, and reverse question 1 can cite the talk directly.
- A fetched Project Larkspur article → reverse question 3 can cite the announcement directly.
- A deeper research pass (L2): up to 6 more searches and 2 more fetches, several more minutes. Want it?
- A written exercise, if the recruiter names one → a graded deliverable section; the JD's "clear written communication" line currently has no question.
