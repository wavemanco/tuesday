Your prep pack is saved as /tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-tuesday-part-2-rooms-case-4-denied-0423ba7a/8cfb993d-d7ed-4cbf-bb90-bf39661a3fb9/scratchpad/quartzline_product-manager-platform-apis_interview_pack.md. I built it for a hiring-manager round from your dossier. Web search was refused in this session, so there's no Quartzline values, interview-loop or strategy material in it. The dossier is also about three months old, so check that the posting still matches it.

One gap the dossier didn't flag: "Shipped API or platform products" is a must-have, but your evidence shows integrations built on the vendor's APIs, not an API product you shipped. The pack treats that as a transferability gap (B3 and F2).

Say the word and I'll play the Skeptic on B1, the PM-title objection the dossier names as the highest-ROI prep.
I can also update tuesday-dossier.md with the gaps this prep exposed, for you to carry forward.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quartzline_product-manager-platform-apis_interview_pack.md -----
# Interview prep pack: Product Manager, Platform APIs at Quartzline

**Round:** 45-minute conversation with the hiring manager (Thursday). Interviewer name not given.
**Built from:** the job-underwriter dossier (`tuesday-dossier.md`, dated 2026-08-14, decision `conditional_go`). The web search for company facts was refused in this session, so company-specific material is absent (see Sources).

## How to use

Personas are how a question is asked. Types are what it scores. Guidance is scaffolding for a spoken answer, not a script. Rehearse only what you actually did, in your own words.

Type key:
- **JD**: tests a requirement the posting states.
- **EXP**: tests a claim on your background.
- **CASE**: a live problem from the role, delivered aloud.
- **CO**: company knowledge. Not covered here, since research did not run.
- **VAL**: values. Not covered here, since no values round is detected.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" (dossier role_profile R1) | "Ran quarterly roadmap-input sessions feeding client evidence to product" (dossier E3) | medium | [grounded] | transferability | The dossier grades this requirement low. Your material shows the roadmap-input sessions, not a product management role, and the limit is this pack's observation: nothing in it shows a PM title or PM years. Say it at the quote's scope: "I ran quarterly roadmap-input sessions that fed client evidence to product." The sessions are medium confidence with limited inspectable proof, so expect a probe. |
| F2 | "Shipped API or platform products" (dossier role_profile R2) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier E1) | high | [grounded] | transferability | The dossier lists R2 as a must-have but does not flag it as uncertain. Your material shows integrations built on the vendor's APIs at client scope, not an API product you shipped. Say: "I led 30+ end-to-end client integrations of the vendor's REST APIs." Answer slot: if you had a part in shipping an API product of your own, say what it was and what your part was; if you did not, say so plainly and stay with the integrations. |
| F3 | "Technical fluency: API docs, schemas" (dossier role_profile R3) | "Wrote the internal integration playbook her team uses" (dossier E2) | high | [grounded] | discovery | The material does not show whether the playbook covers specs, docs or schemas. Answer slot: if it did, say what it covered; if it did not, say so plainly. |
| F4 | "Stakeholder management across engineering, sales, customers" (dossier role_profile R4) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier E1); "Ran quarterly roadmap-input sessions feeding client evidence to product" (dossier E3) | medium | [grounded] | transferability | The quotes carry customer-side work and product feedback. They do not show engineering or sales. Say the customer side at its own scope. Answer slot: if you worked with engineering or sales on an integration, say how it went, in your own words; if you did not, say so plainly. |
| F5 | "Agile delivery experience" (dossier role_profile R5, preferred) | none given | low | [grounded] | discovery | The dossier grades this low with a clarify strategy. Nothing in the material speaks to it. Answer slot: if your integration work ran to a delivery cadence, describe it; if it did not, say so plainly and say what you would confirm about the squads' cadence. |
| F6 | Sub-claim: "Owning a roadmap and prioritization authority" (dossier role_profile unknowns; uncertain_or_weak_areas) | none given | none | [grounded] | capability | The dossier records this as an acknowledge_gap area and lists the related claims as prohibited. Words: "I haven't owned a product roadmap or set prioritization for an engineering squad." No bridge and no answer slot on this row. |

## Persona table

Hiring-manager prior: Case/Strategist and Skeptic dominate. No interviewer profile was given, so there are no interviewer-signal adjustments. No loop source establishes Quartzline's rounds, so the weights fall back to the Generic archetype: flat weights, and they rest on the hiring-manager prior, not on this company's documented process.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Presses the gaps in the PM requirement and asks why you over a PM with years in the job | Highest. The dossier names the PM-title objection as the likeliest one, and the hiring manager is buying derisked capability | Hold the integration evidence, concede the roadmap gap plainly, then a ramp plan stated as a plan |
| Case/Strategist | Live problems on the partner API roadmap, adoption and partner requests | High. The JD's responsibilities are a case menu | Clarify, then structure: objective, partners, baseline, trade-offs, risks |
| Data-Driven Prober | Asks how the 30+ figure and the playbook's effect were counted | Medium. The 30+ figure is a CV headline, and the playbook is the high-confidence artifact a prober will open | Say what counted, what you led end to end, and the assumption you would defend least; say when you do not know |
| Pressure | Time-boxed challenge to a position | Lower. The hiring-manager relationship is less adversarial, but the PM objection can be pressed hard | Pause, restate, hold through two follow-ups, then concede the specific point |
| Conversational | Friendly openers that are still scored | Lower. Easy to underrate | Ninety-second arc from the quotes, with the limit stated before it is asked for |
| Peer Evaluator | Not weighted | Low. A hiring manager is not a peer | None in this pack |

## Question banks

Coverage line: R1 is covered by B1, B2, D1 and E1. R2 by B3. R3 by A4 and E2, with F3's slot. R4 by A5 and B5. R5 by B4. The dossier's risks are covered by A1, A2, C3 and B5. No JD requirement is left without a question.

Persona weights: Skeptic 5, Case/Strategist 5, Prober 4, Pressure 2, Conversational 2. Eighteen questions in all.

### Skeptic (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You have never held the PM title or owned a roadmap. Why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" (dossier E3); [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier E1); the negatives in the question and in the concession come from dossier prohibited_claims and uncertain_or_weak_areas acknowledge_gap, named by field | Hold, then concede. Hold what the quotes carry: "I led 30+ end-to-end client integrations of the vendor's REST APIs, and I ran quarterly roadmap-input sessions that fed client evidence to product." Concede once and plainly: "I haven't owned a product roadmap or set prioritization for an engineering squad, and a PM with three years in the job would be ahead on that." Then the ramp, stated as a plan: learn how the squads set priorities before you set anything. Hold two follow-ups by returning to the integrations. Never add a roadmap to them. | The dossier named this as the highest-ROI prep. F1 and F6 are its material. The question is the dossier's own wording, and its negatives have the source the rubric requires. |
| B2 | "Walk me through your first 90 days on the partner API roadmap." | CASE | [generic] | Clarify first: which decisions are yours and which belong to the two squad leads, and that you would confirm it in week one. Then partner discovery, the adoption baseline, and the squads' capacity. Plan only; make no claim about the past. | The JD's first responsibility, "Own the roadmap for the partner-facing API platform," raises it. Decision authority is an open risk in the dossier. |
| B3 | "Have you shipped an API or platform product?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier E1) | Say the integrations at their scope. Answer slot: if you had a part in shipping an API product of your own, say what it was and what your part was; if you did not, say so plainly and stay with the integrations. Do not use the word platform for them. | F2. The JD's "Shipped API or platform products" is the raising line for the slot. |
| B4 | "How have you worked with a squad's delivery cadence?" | JD | [grounded] (JD line "Agile delivery experience") | Clarify. Answer slot: if your integration work ran to a delivery cadence, describe it in your own words; if it did not, say so plainly and say what you would confirm about the squads' cadence. | F5. Nothing in the material speaks to agile, so the slot is the only honest form. |
| B5 | "Two engineering squads, two leads. Who makes the call when they disagree on a partner commitment?" | CASE | [generic] | Do not claim authority. Say you would put the trade-off to both leads with the partner impact, and that you would want the decision rule stated before you are asked to make one. Ask the question back. | The decision-authority risk. The JD's "Write specs and drive delivery with two engineering squads" raises it. |

### Case/Strategist (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how you'd set the partner API roadmap for the next two quarters." | CASE | [generic] | Structure: objective in partner outcomes, the partners and their asks, the adoption baseline (say you need it first), squad capacity, trade-offs, risks. Ask first which decisions are yours. Speakable in 90 to 120 seconds. | The JD's roadmap responsibility. Covers the dossier's decision-authority risk. |
| A2 | "Partner API adoption is flat this quarter. Where do you start?" | CASE | [generic] | Ask how adoption is counted today and what the baseline is. Segment partners by integration stage. Pick one hypothesis to test. Say the baseline is not known to you yet. | The dossier's adoption-baseline risk. |
| A3 | "A key partner asks for an endpoint the squads have not planned. What do you do?" | CASE | [generic] | Clarify the partner's need, the cost to the squads, what discovery would show, and who decides. Answer the partner with a timeline, not a yes. | The JD's "Run discovery with integration partners." |
| A4 | "How would you judge whether a schema change is safe for partners?" | JD | [generic] | Versioning, the deprecation window, partner communication, test coverage, docs. Do not claim experience with a specific tool. | R3, the JD's technical-fluency requirement. F3 holds the answer slot for your past. |
| A5 | "Sales wants a feature for one account. Engineering says it will slip the roadmap. What do you do?" | CASE | [generic] | Separate the account's need from the roadmap's cost. Take it to both sides with the numbers you have. Name what you would not agree to. | R4, stakeholder management across engineering, sales and customers. |

### Data-Driven Prober (4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Your integration count is 30 plus. How was that counted?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier E1) | Answer slot on the figure: say what counted as one integration, which of the 30 plus you led end to end, and the assumption you would defend least. If the count was not yours to define, say so plainly. Never give a counting method you did not use. | E1 is a headline figure, so the defend-the-number slots apply. |
| C2 | "Did the integration playbook change anything you can measure? Name the measure." | EXP | [grounded] "Wrote the internal integration playbook her team uses" (dossier E2) | Answer slot: if you saw a measured change, name the measure and how it was counted; if none was measured, say so plainly. | E2 is high confidence and inspectable, so a prober will ask what it moved. |
| C3 | "How would you measure partner API adoption, and what would the baseline be?" | JD | [generic] | Define the adoption event, what you would not count, and the current baseline if you can get it. Say the baseline is not known to you yet. | The JD's "Define and track adoption metrics," and the dossier's no-baseline risk. |
| C4 | "If adoption rose 20% next quarter, how would you know it was your doing?" | CASE | [generic] | Attribution: other releases, seasonality, partner marketing. Name the comparison you would want. | Same JD line as C3. Tests whether you can separate your work from the trend. |

### Pressure (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over a PM with three years in the job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier E1); [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" (dossier E3) | Pause, restate the question. Hold on what the quotes carry: the end-to-end integrations and the sessions that fed client evidence to product. Concede specifically: "A PM with three years of roadmap work is ahead of me there, and I haven't owned a roadmap." | F1 and F6. The concession is sourced by the dossier's acknowledge_gap area. |
| D2 | "That playbook. How much of it was actually you?" | EXP | [grounded] "Wrote the internal integration playbook her team uses" (dossier E2) | Hold: say what you wrote and what the team added, in your own words. Answer slot: if you wrote some sections and the team wrote others, say which; if it was written together, say so. | E2 with a probe on attribution. Tests honesty about shared work. |

### Conversational (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier E1); [grounded] "Wrote the internal integration playbook her team uses" (dossier E2); [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" (dossier E3) | Ninety-second arc in this order: the integrations, the playbook, the roadmap-input sessions, then the limit stated before it is asked: "I haven't owned a roadmap yet, and that is what I'd be building toward." | F1 and F2. Casual, but scored. |
| E2 | "What are you actually working with in APIs these days?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier E1) | Name the APIs and specs you have worked with, in the integration's terms. Answer slot: if you have worked with API docs or schemas, say which; if not, say which you would learn first. | R3, the JD's "API docs, schemas." |

## Reverse questions

1. "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" Why it lands: the dossier's decision-authority risk, asked as diligence. It tests the role before you accept it.
2. "How is partner API adoption measured today, and what is the current baseline?" Why it lands: the dossier's no-baseline risk. A candidate who asks it sounds like someone who will own the number.
3. "What did the last person in this role own in their first six months?" Why it lands: it gives you the real scope without asking the hiring manager to defend it.
4. "Where do the two squads disagree most about partner commitments today?" Why it lands: it shows you are asking about the seam, and it surfaces the squad-authority question.
5. "What would make the first 90 days a success for you?" Why it lands: a hiring manager's own definition of success is the most useful reverse question you can ask.

## Prohibited claims

Each entry names its basis and its honest form. No answer, hold, bridge or rationale in this pack asserts any of them.

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | Dossier prohibited_claims | "I haven't held a product manager title." The adjacent work is E3 at its own scope. |
| Having owned a product roadmap | Dossier prohibited_claims and uncertain_or_weak_areas acknowledge_gap | "I haven't owned a product roadmap." |
| Having set prioritization for an engineering squad | Dossier prohibited_claims | "I haven't set prioritization for an engineering squad." |
| Shipped an API or platform product | Inflated form of E1, built locally | E1 at its own scope: "Led 30+ end-to-end client integrations of the vendor's REST APIs." The limit is this pack's observation, not a first-person negative. |
| Owned the integration process | Inflated form of E2, built locally | E2 at its own scope: "Wrote the internal integration playbook her team uses." |

## Sources

- **Provided document:** `tuesday-dossier.md`, pasted in this conversation, dossier_version 1.1, generated 2026-08-14. Sections consumed: role_profile (the requirements R1 to R5, quoted here as the JD lines), handoff_to_mock_interview (verified evidence E1 to E3, uncertain and weak areas, the likeliest objection, the risks, the employer questions, and prohibited_claims), and decision (as context only). The dossier has no evidence_map, evidence_state or risk_register section, so it carries no rejected inferences. The dossier is about three months old, and the posting may have changed since.
- **Evidence labels:** E1, E2 and E3 are the dossier's verified_candidate_evidence entries, quoted exactly. Each confidence note from the dossier is stated in the bridge, not in the quote.
- **Searches sent:** "Quartzline values operating principles", "Quartzline interview process Product Manager Platform APIs", "Quartzline strategy news 2026". All three were refused by the session's search permission. No result came back.

**Research tier: L1 — searches 3 of 6, fetches 0 of 2**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quartzline values | unavailable | Every call refused. No values cheat sheet. No values-style round is detected, since no loop source and no archetype fallback names one. |
| 2. Quartzline interview process, product management | unavailable | Every call refused. Loop structure unknown, so the persona weights are flat and rest on the hiring-manager prior. |
| 3. Quartzline strategy and recent news | unavailable | Every call refused. No grounding brief and no CO questions. |
| 4. Interviewer name and Quartzline | n/a | No name was given, so there was no query to form. |
| 5. Representative product management JD | skipped | The dossier's role_profile fixes the requirements and the JD-tagged questions. |

## Upgrade menu

- **Search permission for WebSearch:** reruns the three refused targets. A values cheat sheet and CO questions appear only if the research finds them. Searching for the loop structure would also firm up the persona weights.
- **The live posting text:** confirms that the August role_profile still matches. The requirement lines quoted here would then be checked against the current wording.
- **The integration playbook, if you can show it or a redacted section, and it is shareable:** E2 becomes an inspectable artifact, which lets C2 and D2 point at something. If it is confidential, leave it out.
- **The interviewer's name:** persona weights from their public footprint, and a reverse question tailored to their path.
- **The recruiter's note on format:** whether there is a case or a written exercise, and whether the adoption baseline will be shared. This would sharpen A1 and C3.
- **A deeper research pass (L2), offered once:** up to 6 more searches and 2 more fetches, several minutes. It needs search permission first.
