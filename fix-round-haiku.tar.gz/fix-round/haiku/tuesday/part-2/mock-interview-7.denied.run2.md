Your prep pack is saved at `/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-tuesday-part-2-rooms-case-7-denied-47c758f5/5bf2e4a6-fdda-4fc0-b056-f75d0b40404c/scratchpad/saltmarsh_live_operations_producer_interview_pack.md`. I built it for a hiring-manager round, since your note didn't say who you're meeting.

Web search was refused, so the pack has nothing on Saltmarsh's values, interview loop, or Tobias Wrenfield's public background. Everything is grounded in the JD and your message.

The most important prep is question B1, "Tell me about an update you coordinated across design, art, engineering and community." The JD's middle clause is the centre of the job, and your material only shows work with QA. Decide now what your honest answer is, including "I haven't coordinated those teams, and here's how I'd start." Rehearse that answer before anything else.

Offers, one line each, neither pushed:
- Want to rehearse? I can play the Skeptic on B1 and react to your answer.
- I can save a `tuesday-dossier.md` recording the gaps this prep exposed, to carry into later sessions.
- If you'd like the pack as a Word document, say so and I'll convert it.

Is Tobias your future manager, or a peer on the team? The answer reweights the question banks.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh_live_operations_producer_interview_pack.md -----
# Live Operations Producer, Saltmarsh Games: interview prep pack

**Round:** Hiring-manager round with Tobias Wrenfield, Head of Live Operations (60 minutes, Friday)
**Relationship:** assumed hiring manager (see the upgrade menu). Persona weights use round-type priors because no interviewer profile was available.
**Research:** none ran. Both web searches were refused (permission not granted), so company values, loop structure and the interviewer's public footprint are absent. Everything below is grounded in the JD and the candidate's message, or labeled `[generic]`.

## 1. How to use this pack

Personas describe how a question arrives. Types describe what is being scored.

| Type | Meaning |
|---|---|
| VAL | Behavioral and values alignment |
| EXP | Deep-dive on what you actually did |
| JD | The job's stated responsibilities and qualifications |
| CO | Company and strategy knowledge (not covered; no research ran) |
| CASE | A live problem from the role |

Guidance is scaffolding, not a script. Rehearse the shape of each answer, then say it in your own words.

## 2. Fit snapshot

Requirements are quoted from the JD. Evidence is quoted from your message. Nothing is added to either.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | transferability | Your material shows a calendar for one title, and the JD asks for two. Keep the bridge at one: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: the JD's "two of our mobile titles" makes a probe on a second title likely. If you ran or shared a calendar across more than one title, say how. If not, say so, and say what you would check first when adding a second. |
| F2 | "experience running a content calendar" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | none | No gap; the quote already reaches the requirement. It is a claim with nothing inspected behind it, so expect a probe on the cadence. Lead with the calendar in the quote's own terms. |
| F3 | "coordinate design, art, engineering and community teams on each update" (JD) | none given | none | [grounded] | discovery | Nothing in your material shows coordinating design, art, engineering or community on an update. The JD's middle clause is the centre of the job, so expect a probe. Answer slot: if you coordinated any of those teams on an update, say which and what your part was. If your coordination was with QA only, say so plainly and describe how you would run the other four. |
| F4 | "own the post-event review and the KPIs it reports" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | low | [inferred] | discovery | Presenting numbers is not owning a post-event review. Your material does not show whether you wrote the reviews or chose the KPIs, so the bridge does not stretch. Answer slot: if you ran a review after a content drop, or chose which numbers were reported, say what it covered. If you presented numbers someone else set, say so plainly and say what you would put in a post-event review first. |
| F5 | "manage the release checklist with QA" (JD) | "Wrote the release checklist our QA team still uses." (your message) | medium | [grounded] | presentation | The quote reaches the requirement in other terms: you wrote it, and QA still uses it. Bridge: "I wrote the release checklist our QA team still uses." Answer slot: the JD asks about managing it with QA on each release, so expect a probe on how it ran release to release. If you ran that process, say how. If release sign-off was not yours, say so and stay with what you wrote. |
| F6 | "3+ years producing live-service games or apps" (JD) | "4 years as an associate producer at a puzzle-game studio" (your message) | medium | [grounded] | presentation | The quote carries the length and the studio type. It does not say whether the title was live-service, and the bridge does not claim it. Bridge: "I was an associate producer at a puzzle-game studio for four years." Answer slot: if the title took regular updates after launch, say so in your own words and point to the content drops. If it did not, say which part of the four years was live. |
| F7 | "comfortable with player-retention metrics" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | medium | [grounded] | presentation | The quote reaches the requirement in other terms. Bridge: "I presented the monthly retention numbers to the studio head." Answer slot: the JD raises comfort with the metric itself, so expect a question on how retention was counted. If you built or checked the count, say how. If you presented figures you did not count, say so plainly. |
| F8 | "clear written communication" (JD) | "Wrote the release checklist our QA team still uses." (your message) | low | [inferred] | discovery | One piece of writing used by a team is the only written evidence in your material, so the bridge claims no more. Answer slot: if you can name a document you wrote that people acted on, say what it was and who used it. |

**Gates.** The JD names no legal, credential or location gate. The "3+ years" line is experience, not a gate, so it is graded above.

## 3. Prohibited claims

What this pack will not coach, and the honest form of each.

| Not coached | Basis | Honest form |
|---|---|---|
| Led a team, or led cross-functional work | Stated negative: "Never led a team, and never worked on a game with in-app purchases." | Plain acknowledgment: "I've never led a team." No slot. |
| Owned the post-event review | Inflated form of F4 | F4's quote at its own scope: "Presented the monthly retention numbers to the studio head." Limit, as the pack's own observation: your material says presenting, not owning. |
| Ran a live-service title | Inflated form of F6 | F6's quote at its own scope. Limit, as the pack's own observation: the material does not say the title was live-service. |
| Ran the calendar for two titles | Inflated form of F1 | "I ran the weekly content-drop calendar for our main title for the last two years." |
| Owned the release checklist process with QA | Inflated form of F5 | "Wrote the release checklist our QA team still uses." |
| Worked on a game with in-app purchases | Stated negative: "never worked on a game with in-app purchases" | Plain acknowledgment: "I've never worked on a game with in-app purchases." No slot. |

## 4. Persona table

Weights start from the hiring-manager prior: Case/Strategist and Skeptic. No interviewer signals were available, so no adjustments were made.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy | Weight |
|---|---|---|---|---|
| Case/Strategist | Live problems on the calendar and a release | High. A hiring manager is buying capability and will test it on the real roadmap. | Clarify first, then structure, then decide. Name what you would decide with design and community rather than alone. | 5 |
| Skeptic | The JD's middle clause, the second title, the missing team lead, the missing in-app purchase work | High. The hiring manager's job is to derisk exactly these gaps. | Rehearse the single most predictable objection (B1) until it is boring. Hold on what you did. Concede plainly what you did not. | 4 |
| Data-Driven Prober | Retention figures and how they were counted | Medium. Retention is a JD requirement and the material shows presenting, not defining, retention. | Say what you know about how a figure was counted, name its weakest assumption, and say plainly when you do not know. | 3 |
| Pressure | "You've never led a team" and "how much of that was you" | Medium. Both are visible gaps a composure test would use. | Pause, restate, hold through two follow-ups, then concede the specific thing. Never fold on the core claim. | 3 |
| Conversational | The opener and the "any questions" slot | Low-medium. Casual questions are still scored. | A 90-second arc drawn from your quoted sentences. Ask good reverse questions. | 2 |
| Values/Behavioral | Scenario prompts from the persona library | Low. No published values were found, so this is generic. | Selection scaffolds with the honest branch. | 2 |

## 5. Question banks

Total: 19 questions, within the 18 to 26 range. Each question carries its type and provenance.

### A. Case/Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Two titles have events due in the same six weeks. How would you plan that calendar?" | CASE | [grounded] (JD: "Plan and run the live-events calendar for two of our mobile titles") | Clarify what is fixed: release dates, QA windows, which events compete for players. Then sequence, then name what you would decide with design and community. Speakable in about 90 seconds. | F1's requirement, as a live problem. No claim about your past, so no quote is needed. |
| A2 | "You've run one title's calendar. What changes when you add a second?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Hold to the calendar you ran and its two years. Then name what would change: team capacity, release overlap, which KPIs differ. Present these as what you would check, not as experience. Answer slot: if you ever planned or shared another title's calendar, say how. If not, say so and say what you would check first. | F1 and F2. Premised on one title, which the quote carries. The second branch allows that you have not done it. |
| A3 | "An update's QA sign-off slips two days and the event is set for Friday. What do you do?" | CASE | [generic] | Structure it: what is at risk for players, who you would call (QA lead, engineering, community), the decision, and the record you would keep. | F5's requirement, as a live decision. The question makes no claim about your past. |
| A4 | "What would you lead with in a post-event review for an event that underperformed?" | CASE | [generic] | Name the KPI you would lead with and the assumption it rests on. Name what you would check before calling the event a miss. | F4's requirement as a decision. Yours to answer in your own terms. |
| A5 | "Retention fell four points two weeks after an event. Diagnose it." | CASE | [generic] | Clarify the cohort, the event's reach, and seasonal effects, then structure before you answer. Name one assumption you would test first. | F7's requirement, as a diagnosis. Strategists score structure over the right answer. |

### B. Skeptic (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about an update you coordinated across design, art, engineering and community." | JD | [grounded] (JD: "coordinate design, art, engineering and community teams on each update") | **Highest-ROI prep in this pack.** This is the JD's centre and the least-evidenced requirement. Hold on the teams you actually worked with and your part of each handover. Answer slot: if your coordination was with QA only, or with some of those teams, say which and what your part was. If you did not coordinate them, say so plainly and describe how you would run the first update with them. Hold through two follow-ups by returning to the teams you named. | F3. The question is an open prompt, so it supplies no event; the second branch allows that the work never happened. |
| B2 | "You've run one title's calendar. Why should we believe you can run two?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Hold on the two years you ran. Concede the difference plainly: a second title is a different job, and you would verify its cadence before committing to it. Do not claim experience you do not have. | F1. The concession is the honest answer; the hold is the calendar. |
| B3 | "You've spent four years on a puzzle game. What in that work carries over to live-service games?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio" and "I ran the weekly content-drop calendar for our main title for the last two years." | Name the content-drop cadence as the part that carries over, in your words. Do not say the puzzle title was live-service. Answer slot: if the title took regular updates after launch, say which and how. If that is not your experience, say the content drops are the part that carries over. | F6. The question asks what carries over, not whether the title was live. |
| B4 | "You've never led a team. Why should we hire you to coordinate people who don't report to you?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Hold on the work you did, in your own words: the checklist QA still uses, and the calendar. Concede plainly: "I've never led a team." Do not describe leadership you did not do. Hold through one follow-up, then concede what remains. | Stated negative, so the plain acknowledgment has its source. The bridge is the quote from F5, not a leadership claim. |

### C. Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "How was the monthly retention figure you presented counted? What did you leave out?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Say how it was counted only if you know. Name the weakest assumption you know of before they do. Answer slot: if you built or checked the count, say how in your own words. If you only presented it, say so and name the assumption you would question first. | F7. Premised on the presented figure, which the quote carries. |
| C2 | "Which retention figure would you trust least, and what assumption sits behind it?" | JD | [grounded] (JD: "comfortable with player-retention metrics") | Name, in your own words, the figure you would trust least and the assumption behind it. If you have not worked with one, say so and say which you would check first. | F7. The weakest-assumption move, which the candidate names rather than the pack. |
| C3 | "Walk me through the content-drop calendar you ran. How did you know whether a drop had worked, if you did?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Say what you looked at, if anything. Answer slot: if you measured drops, say what and how it was counted. If you did not, say so plainly. | F2. The "if you did" clause keeps the premise open. |

### D. Pressure (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You've never led a team. Why should we hire you for this role?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Pause. Hold on what you did: the checklist and the calendar. Concede specifically: "I haven't led a team." Hold through two follow-ups. Do not fold on the core claim, and do not overstate. | Composure test. The negative is the candidate's own. |
| D2 | "That checklist. How much of it was actually you?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Say what you wrote and that QA still uses it. Answer slot: if others changed it after you, say which parts. If it is still as you wrote it, say so. | F5. Attribution honesty, which this probe exists to test. |
| D3 | "Pick the retention number you presented that you'd defend least. Defend it for two minutes." | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Hold on the part you can defend. Concede the weakest part specifically. If you did not count the figure, say so before you defend anything. | F7. Pressure on the presented figure. |

### E. Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey to here." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio," "I ran the weekly content-drop calendar for our main title for the last two years," "Wrote the release checklist our QA team still uses," "Presented the monthly retention numbers to the studio head." | A 90-second arc through the four quoted sentences in that order. Do not add a stage. | Casual openers are scored. The arc is drawn only from quotes. |
| E2 | "What live game have you been playing lately, and what did its updates do well?" | JD | [generic] | Pick one live game you actually play. Describe one update you noticed and what it did for you. Keep it to what you saw as a player. | Casual route to the JD's live-service requirement. [generic] because it names no fact about you. |

### V. Values/Behavioral (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time you had to tell someone senior that something was not ready. It needs a named stake, a moment you did not fold, and an intact relationship at the end. If no such time comes to mind, say so plainly, then give the nearest thing you did. | Persona stem. No published values were found, so this is generic. |
| V2 | "When did you put the player ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a time a number was not the right call for players. Name the stake and what you did. If none comes to mind, say so plainly, then give the nearest thing you did. | Persona stem. Generic, as above. |

### Requirement coverage

| JD requirement | Questions | Note |
|---|---|---|
| Plan and run the live-events calendar for two titles | A1, A2, B2 | |
| Coordinate design, art, engineering and community | B1 | Highest-ROI item |
| Own the post-event review and the KPIs | A4, C1 | |
| Manage the release checklist with QA | A3, D2 | |
| 3+ years producing live-service games or apps | B3, E2 | |
| Experience running a content calendar | A2, C3 | |
| Comfortable with player-retention metrics | A5, C2, D3 | |
| Clear written communication | none, and why | No writing sample was supplied, so there is nothing to rehearse a probe against. See the upgrade menu. |

## 6. Reverse questions

Each has a reason it lands. No interviewer profile exists, so none is tied to the interviewer's path.

1. "What does an update look like from the day design picks it up to the day it ships?" Lands because it tests how the coordination model works in practice.
2. "Which title's calendar is tighter right now, and what is the constraint?" Lands because it shows you are already thinking about the two-title problem.
3. "Who owns the post-event KPI readout, and how is it reviewed?" Lands because it asks directly about the role's most-owned output.
4. "What did the last two events on each title teach the team?" Lands because it asks for their learning, not your pitch.
5. "What would a new producer be expected to own in the first ninety days?" Lands because it signals you are planning for the job, not interviewing for a title.
6. "How do QA and the release checklist fit into a live release today?" Lands because it probes the part of the JD you can speak to most directly.

## 7. Sources

- **Provided documents:** the JD text in your message; your background in your message.
- **Searches attempted:**
  - "Saltmarsh Games mobile studio live operations": refused, because web search permission was not granted.
  - "Tobias Wrenfield Saltmarsh Games Head of Live Operations": refused, for the same reason.
- **Research tier:** L1 requested. Searches 0 of 6, fetches 0 of 2. Both calls were refused.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | unavailable | Values cheat sheet, and the values round's VAL questions. No call was sent. |
| 2. Saltmarsh Games interview process, live operations | unavailable | Loop structure and persona weights. |
| 3. Saltmarsh Games strategy and recent news | unavailable | CO bank and grounding brief. Refused. |
| 4. Tobias Wrenfield, Saltmarsh Games | unavailable | Interviewer read, persona weights, and tailored reverse questions. Refused. |
| 5. Representative Live Operations Producer JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions. |

## 8. Upgrade menu

- **Web search permission** → company values, the interview loop, and Tobias Wrenfield's public footprint: a values cheat sheet, loop-specific persona weights, and tailored reverse questions.
- **A redacted calendar you ran** → F1 and F2 move from medium to high confidence, and A2 and B2 can cite an artifact instead of a sentence.
- **A post-event note or review you wrote** → F4 and F8 gain an inspectable artifact and can be answered from evidence rather than a slot.
- **A writing sample** → F8 can be rehearsed against something real, and the coverage line gains a question.
- **Any update you coordinated across design, art, engineering or community** → B1 becomes a story instead of an answer slot.
- **The recruiter's note on the round** → confirms the round's structure and whether anything beyond the hiring-manager conversation is coming.
- **Your prep time before Friday** → the prep triage section.
