Your prep pack for all three rounds is saved at:
/tmp/claude-0/-tmp-claude-0--home-user-tuesday-ef77e489-8808-5f2b-a3f0-8906fb79ef25-scratchpad-fixround-round-haiku-tuesday-part-2-rooms-case-6-denied-6484a389/a30a9558-de8d-477d-b7e5-54acb2cc7415/scratchpad/larkfield_engineering_manager_interview_pack.md

It's built as a loop: one shared fit snapshot, then a mini-pack for each round with its own persona weights and 8 questions, 24 in total. Your own sentences are the only evidence it uses, so the answers say what you did and nothing more.

**What the pack says you'll face:**
- **Round 1 (Director, Tuesday):** Skeptic is the top persona. The main objection is that you've never owned a hardware-adjacent roadmap, and that's where the deepest rehearsal goes. The second is managing managers, which you've never done.
- **Round 2 (panel, Thursday):** The staff engineers will probe the 40 interviews and the 60% on-call result. The PM will press on roadmap sequencing against reliability work.
- **Round 3 (VP, Monday):** Values is the top persona. Your material holds one story that sits near the leadership-philosophy theme, so the other values questions give you a selection prompt with an honest "say so if it isn't there" branch rather than an invented story.

**Things to know:**
- **Web research didn't run.** The three searches were refused by a permission prompt, so there's no Larkfield values page, interview guide or strategy. The values cheat sheet is dropped, and the company-strategy questions are generic. If you grant search permission, I can rerun it.
- **The claims to avoid are listed in the pack.** Don't say you led two squads, ran hiring for 11 people, or owned the hardware roadmap. Don't say you cut on-call 60% on your own either. Each has the honest version beside it.
- **One question for you:** where is the role based, and how many on-site days does it expect? Nothing you've given me says, and it's a deal-breaker-type question. Your answer goes into the pack.

Want a drill? I can play the Skeptic on the hardware-roadmap question, which is the highest-value prep in the pack. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, to carry into later sessions.

Watch-out: Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: larkfield_engineering_manager_interview_pack.md -----
# Larkfield Systems, Engineering Manager: interview prep pack (loop of three rounds)

Role: Engineering Manager, device-management services, Larkfield Systems (industrial IoT, about 600 people)
Candidate: Yusuf
Rounds: (1) Tuesday, 45 min, hiring manager (Director of Engineering); (2) Thursday, 60 min panel, two staff engineers and a product manager; (3) Monday, 30 min, VP Engineering, described by the recruiter as "values and leadership philosophy"

First build, from the role brief and background in your message. No full JD text, no CV text and no interviewer names were supplied, so every row below is built on your own sentences.

## How to use this pack

- Personas describe how each question arrives. Types describe what is being scored: JD (the role's stated requirements), EXP (what you actually did), CASE (a live problem from the role), VAL (values and leadership).
- Guidance is scaffolding, not a script. Say it in your own words. Where it says "answer slot", the honest answer is either branch the slot gives you.
- Question IDs are by persona: S (Skeptic), C (Case/Strategist), D (Data-Driven Prober), E (Peer Evaluator), P (Pressure), V (Values/Behavioral).

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" (role brief in your message) | "9 years engineering, 3 as a team lead of 6" (your message) | medium | [grounded] | transferability | Your material shows one team of six, not two squads and not device-management services. Keep the bridge at that scope: "3 as a team lead of 6." Answer slot: if you have led people across more than one team, or in a different domain, say what it was and how many people it covered; if not, say so, and say what you would do first to learn the device domain. |
| F2 | "own delivery, hiring and growth for 11 engineers" (role brief in your message) | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." (your message) | medium | [grounded] | presentation | The evidence is a delivery outcome under roadmap pressure, but it is not yet told in delivery-management terms. Bridge rewords only that sentence and adds no practice, figure or event. Answer slot: if you know how the 60% was counted, say so; if you do not, say so. |
| F3 | "own delivery, hiring and growth for 11 engineers" (role brief in your message) | "I run our hiring loop for backend roles — about 40 interviews last year." (your message) | medium | [grounded] | transferability | Running a hiring loop for backend roles is adjacent to owning hiring for a team of 11. Keep the words at the loop: "I run our hiring loop for backend roles." Answer slot: if you have made hiring decisions for your own team, say which and how; if not, say so. |
| F4 | "Lead two squads building device-management services" (role brief in your message) | "I've never managed managers" (your message) | none | [grounded] | capability | A gap you stated yourself. Words: "I've never managed managers." Then how you would learn it, as a plan, never as a past. Nothing added to make the gap feel smaller. |
| F5 | "partner with hardware and product on roadmap" (role brief in your message) | "never owned a hardware-adjacent roadmap" (your message) | none | [grounded] | capability | A gap you stated yourself. Words: "I've never owned a hardware-adjacent roadmap." Then the plan for learning the hardware constraints, said as a plan. |
| F6 | "partner with hardware and product on roadmap" (role brief in your message) | none given | none | [grounded] | discovery | Your material does not show a roadmap set with a non-engineering partner. Answer slot: if you have set a roadmap with product or another team, say with whom and what you decided; if not, say so. |
| F7 | "own delivery, hiring and growth for 11 engineers" (role brief in your message) | none given | none | [grounded] | discovery | Your material does not show how you have grown the people you lead. Answer slot: if you have a way of telling that someone grew, say what it is; if not, say so and say what you would use first. |
| F8 | Location and on-site pattern (not in the role brief; a gate, so this row is [generic]) | none given | none | [generic] | hard_gate | Your material does not establish this. The one question in this pack asks it. Wording cannot close a gate. |
| F9 | Background in payments (your message) | "currently at a payments company" (your message) | medium | [grounded] | none | Your current domain is stated. It is the context your motivation answer rests on. |

## Prohibited claims

Each entry names its basis. Honest forms are the quote at its own scope.

| Not coached | Basis | Honest form |
|---|---|---|
| Led two squads | Inflated form of F1 | "3 as a team lead of 6." Your material says one team of six. |
| Ran hiring for an 11-person team | Inflated form of F3 | "I run our hiring loop for backend roles." The material says the loop, not the team's hiring. |
| Owned the hardware roadmap | Negative you stated (F5) | "I've never owned a hardware-adjacent roadmap." No slot. |
| Cut on-call by 60% on my own | Inflated form of F2 | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." The sentence says the team's burden and that you pushed the quarter through. It does not say you were the only cause. |

## Loop reading

The loop is established by your own words: three named rounds, with who runs each and what it holds. So the pack runs in loop mode, with one shared fit snapshot and one mini-pack per round. The third round is documented as a values-style round by the recruiter's words, so Values is guaranteed in this loop.

Persona weights, with the reasoning shown:
- Round 1 (Director, hiring manager). Relationship prior: Case/Strategist and Skeptic. You are being bought for capability and the Director's gaps are F4 and F5, so Skeptic is top, Case second, Pressure third.
- Round 2 (panel). Staff engineers take Prober and Peer Evaluator (one each). The product manager takes Case, on roadmap and sequencing.
- Round 3 (VP). Values/Behavioral is top, Pressure second.

## Round 1: Director of Engineering, 45 minutes

Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (weight 5) | Quiet cross-examination of the gaps: managing managers, the hardware roadmap, the step from one team to two | Highest. The hiring manager is buying capability and derisking F4 and F5 | Rehearse S2 until it is boring. Hold a plain statement of the gap, then the plan |
| Case/Strategist (weight 4) | A live problem from the role | High. Relationship prior for a hiring manager | Clarify, then structure. Say the framework aloud before using it |
| Pressure (weight 3) | Time-boxed challenge on your strongest numbers | Medium. Tests composure on the on-call result | Hold through two follow-ups, then concede only what is true |

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| S1 | "I don't see managing managers in your background. How would you handle that on day one?" | JD | [grounded] "I've never managed managers" (your message) | Hold the plain statement: "I've never managed managers." Then the plan for the first month: who you would talk to, what you would watch. A plan, not a past. Answer slot: if you have supported a manager of managers in any form, say how; if not, say so | F4 is the gap most likely to be raised; the plain statement is words you already said |
| S2 (highest-ROI) | "You've never owned a hardware-adjacent roadmap. Why should we bet this role on you?" | JD | [grounded] "never owned a hardware-adjacent roadmap" (your message); [grounded] "9 years engineering, 3 as a team lead of 6" (your message) | The deepest rehearsal in the pack. Hold: "I've never owned a hardware-adjacent roadmap." Then the one thing you can say the material carries: "3 as a team lead of 6." Concede specifically: name the first 90 days you would spend on the hardware constraints. Hold through two follow-ups by returning to the 3 years. Do not add a hardware story | F5 is where the role's partnering mandate presses hardest, so this objection will arrive in some form. A rehearsed plain answer changes the interview |
| S3 | "Lead two squads. You've led one team of six. What do you think you are underestimating?" | JD | [grounded] "3 as a team lead of 6" (your message) | Say what you know about the step from one team to two, in your words. Answer slot: if you have thought about a specific difference, name it; if not, say so and name the first thing you would check | F1 is the transferability gap and the Director will probe scope |
| S4 | "Why this role now, coming from a payments company?" | JD | [grounded] "currently at a payments company" (your message) | Motivation in your own words, with the device domain as the reason, not the payments domain. No claim about device experience. Answer slot: if there is a specific reason you want this role, name it; if the reason is the team or the mission, say so | F9 is your current context. The question tests whether the move is a considered one |
| C1 | "Your squads disagree with the hardware team on a firmware rollout timeline. How do you decide?" | CASE | [generic] | Clarify what the rollout risk is, state the objective, segment the options, name the metrics you would watch, then the decision. Ask one question about the premise | A live problem from the role. No claim about your past |
| C2 | "Two device-management services each want the same engineers next quarter. What would you do first?" | CASE | [generic] | Clarify priority and the cost of each slip, then structure, then the people trade-off. Think aloud | A live problem from the role, the ownership mandate in the brief |
| P1 | "That 60% — how much of it was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." (your message) | Hold: "I pushed the quarter through." Name the weakest assumption you know of, in your words. Concede only what you do not know: how the 60% was counted, and which parts were the team's. Do not add stakeholders or trade-offs | F2. A figure you gave is the place a probe lands. An explanation you cannot repeat under a second question is worse than none |
| P2 | "Sixty seconds: why you over someone who has managed managers?" | JD | [grounded] "I've never managed managers" (your message); [grounded] "3 as a team lead of 6" (your message) | Hold: the three years and the quarter. Concede plainly: "I've never managed managers." Then the plan | F4 under time pressure. The composure is the thing scored |

## Round 2: panel, 60 minutes

Persona table (per panel member)

| Member | Persona | Weight | Reasoning |
|---|---|---|---|
| Staff engineer A | Data-Driven Prober | 3 questions | Staff engineers read the CV line by line; the 40 interviews and the 60% are the lines to probe |
| Staff engineer B | Peer Evaluator | 2 questions | Seam questions between your service and their firmware or platform work |
| Product manager | Case/Strategist | 3 questions | Roadmap sequencing and what they need from you |

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how the 40 interviews were counted, and which part of the loop was yours." | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." (your message) | Say what the quote counts: interviews, for backend roles. Answer slot: how the 40 was counted, the assumption you would defend least, and which part of the loop was yours. If you do not know how it was counted, say so | F3. A figure invites a count probe. The quote gives the scope |
| D2 | "How would you know whether an engineer on your team had grown this year?" | JD | [grounded] "own delivery, hiring and growth for 11 engineers" (role brief in your message) | Answer slot: if you have a way of telling that someone grew, name it in your words. If you have not, say so and name what you would use first | F7. The growth requirement is in the brief; no sentence of yours carries it |
| D3 | "What would you expect to see for these two squads by month six?" | CASE | [generic] | Structure a delivery measure: what it counts, what it is sensitive to, what you would not trust. Name the assumption you would defend least | A live problem about delivery, from the brief's own ownership line. No claim about your past |
| E1 | "Our teams sit side by side on the device fleet. Where's the seam between a service you'd own and our firmware work?" | JD | [generic] | Propose seam principles, not a seam you have not seen. Say which decisions you would want on each side | Partnership with hardware, the brief's own line. Peer Evaluator tests turf awareness |
| E2 | "When a service-side decision breaks something on our side, what happens next?" | VAL | [generic] | Selection scaffold: pick a time you disagreed with an equal and changed the outcome. If none comes to mind, say so plainly, then give how you would handle it | Peer disagreement. Your material holds no such story, so the honest branch is the answer |
| C3 | "Roadmap: reliability work against new feature requests. How do you sequence them?" | CASE | [grounded] "pushed a reliability quarter through against roadmap pressure" (your message) | Structure the choice, then the decision rule. Hold the reliability case with the quote's own words. Answer slot: if there was a rule that decided the sequence, say what it was; if none, say so | F2 supplies the one story; the product manager will press the trade-off |
| C4 | "What would you need from product in the first 90 days?" | JD | [generic] | List the decisions and data you would need, and say what you would give in return. Reciprocity framing | A product manager tests what the hire needs from them |
| C5 | "The hardware team's firmware cadence is outside your control. Where does the roadmap bend?" | CASE | [generic] | Structure: which dates are fixed, which are yours to move, who decides. Say what you do not know about the hardware schedule | F5 territory in live form. No claim about your past |

Reverse questions for the panel

- "What could a new engineering manager do in the first month that would genuinely help your team?" Why it lands: the reciprocity question for peers. It turns the panel into a working conversation.
- "Where does the roadmap for the device fleet most often change without warning?" Why it lands: shows you are already thinking about the hardware seam.

## Round 3: VP Engineering, 30 minutes

Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral (weight 5) | Scenario probes on "values and leadership philosophy" | Highest. The recruiter named this round as values-led | Selection scaffolds where no story exists; say so, do not supply an ending |
| Pressure (weight 3) | A skip-level challenge to your leadership philosophy | Medium. VP rounds test composure | Hold, then concede plainly |

No published company values are in hand, so the values cheat sheet is dropped (see the upgrade menu). The VAL questions below are themed from the recruiter's words, which is a raising source.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "pushed a reliability quarter through against roadmap pressure" (your message) | Selection scaffold: if the reliability quarter involved telling someone senior a hard truth, say how, in your words. If not, say so plainly and give the nearest thing your material carries | The recruiter's "leadership philosophy" theme. Your material has one nearby sentence, nothing more |
| V2 | "Tell me about someone you developed who went on to outperform you." | VAL | [generic] | Selection scaffold: pick a person you developed, what you did, and what they did next. If none comes to mind, say so plainly | A growth question. Your material does not show this, so the honest branch is the answer |
| V3 | "What is your leadership philosophy in one sentence, and where did it come from?" | VAL | [grounded] "9 years engineering, 3 as a team lead of 6" (your message) | Say one sentence you actually believe, and anchor the origin in the three years, in your words. No borrowed phrasing | The recruiter's "leadership philosophy" framing. One sentence you can defend under follow-up |
| V4 | "How do you decide when reliability work loses to a roadmap commitment?" | VAL | [grounded] "pushed a reliability quarter through against roadmap pressure" (your message) | Hold the quoted story. Answer slot: if you gave something up to win the argument, say what; if you did not, say so | F2 is the only story the material carries on this question |
| V5 | "How do you know your team is healthy?" | VAL | [generic] | Selection scaffold: name two signals you have actually watched. If none, say so and name the first two you would start with | A leadership-philosophy question. Your material does not show a measure, so the honest branch is the answer |
| V6 | "When did you change your mind about how to lead someone?" | VAL | [generic] | Selection scaffold: a time you changed course, and what you learned. If none comes to mind, say so plainly | A values question about learning. Your material holds none, so the honest branch carries |
| P3 | "You've run one team of six. Why should we trust you with leaders?" | JD | [grounded] "3 as a team lead of 6" (your message); [grounded] "I've never managed managers" (your message) | Hold: the three years. Concede: "I've never managed managers." Then the plan, as a plan | F4 at skip-level, time-boxed. The composure is what is scored |
| P4 | "That result. Which part of it would you not stand behind?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." (your message) | Hold the quoted sentence. Name the weakest assumption you know of. Concede only what you do not know | F2 under a skip-level probe |

Reverse questions for the VP

- "How do you define leadership philosophy in practice on your team?" Why it lands: asks for the VP's working definition, so you hear the bar before you answer V3.
- "What does a decision that broke a value here look like?" Why it lands: shows you ask about failure as well as success.

Reverse questions for the Director (round 1)

- "What would success look like at 90 days for this role?" Why it lands: tests the Director's expectation against F4 and F5 without naming them.
- "Where do you expect the hardware-adjacent roadmap to bend first?" Why it lands: a live question on the partnering mandate.

## Requirement coverage

| Requirement | Question IDs | Note |
|---|---|---|
| Lead two squads building device-management services | S3, E1, C1, C3 | |
| Own delivery | P1, D3, C3, P4 | |
| Hiring for 11 engineers | D1 | |
| Growth for 11 engineers | D2 | |
| Partner with hardware and product on roadmap | S2, E1, C3, C5 | |
| Managing managers (F4) | S1, P2, P3 | |
| Hardware-adjacent roadmap (F5) | S2, C5 | |
| Values and leadership philosophy (recruiter) | V1 to V6 | |
| Location and on-site pattern (F8) | none, and why: not in the material; asked as the one question below | |

## Sources

- Provided material: the role brief and background in your message. No CV text, no JD text, no interviewer names, no company values page, no interview guide.
- Research tier: L1, searches 3 of 6, fetches 0 of 2.
- Searches sent: "Larkfield Systems values"; "Larkfield Systems interview process engineering manager"; "Larkfield Systems strategy news industrial IoT device management". All three were refused by a permission prompt, so no results came back.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Larkfield Systems values | unavailable | Values cheat sheet: dropped. It needs the company's published values in hand |
| 2. Larkfield Systems interview process | unavailable | Loop structure. The loop is set by your own words instead, so persona weights follow the three named rounds |
| 3. Larkfield Systems strategy and recent news | unavailable | Grounding brief and CO questions. CO questions are generic as a result |
| 4. Interviewer name and Larkfield | n/a | No name was given, so there was no query to form |
| 5. Representative JD for the title | skipped | The role brief in your message fixes the requirement rows |

## Upgrade menu

- The full job description text, pasted → the requirement rows F1 to F7 move from role-brief quotes to JD quotes, and D2 and E1 get stronger guidance
- Company values page, pasted or read → the values cheat sheet returns, and V1 to V6 can map to published values
- The interviewer names for the three rounds → personalized persona weights and interviewer-specific reverse questions
- Recruiter's prep email → coverage of any deliverable or round format it names
- Permission to run the web searches again → targets 1 to 3 can run; a strategy brief would strengthen the CO and CASE questions
- Deeper research, offered once: up to 6 more searches and 2 more page fetches, several minutes, if you want it
- A `tuesday-dossier.md` from a job-underwriter run, if you have one → sharper objections and verified evidence
- Your location and on-site expectation → closes the F8 gate
