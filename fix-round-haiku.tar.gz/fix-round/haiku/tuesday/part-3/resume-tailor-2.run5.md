I've run the resume-tailor module. Nothing is applied yet: it produces an edit ledger first, and the tailored resume comes only after you approve rows. The 3+ years data-engineering requirement is a real gap that no wording closes, and I've flagged it below.

## Edit ledger (all rows pending your approval)

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| L1 | Summary (new) | *(none)* | "Senior Data Analyst, 5 years in retail. SQL every day on Redshift; built and maintained about 25 dbt models; designed the star schema for the orders mart with our then-DE." | `merge` | "Senior Data Analyst, 5 years, retail."; "SQL every day on Redshift, complex window functions and CTEs."; "Built and maintained about 25 dbt models including the core orders mart."; "I designed the star schema for the orders mart with our then-DE." | `[grounded]` resume | pending your approval |
| L2 | Experience | "I've fixed our nightly dbt job when it breaks and added tests to it." | "Fixed our nightly dbt job when it breaks and added tests to it." | `surface` | "I've fixed our nightly dbt job when it breaks and added tests to it." | `[grounded]` resume | pending your approval |
| L3 | Experience | "I designed the star schema for the orders mart with our then-DE." | Same line, moved to the top of Experience | `reorder` | "I designed the star schema for the orders mart with our then-DE." | `[grounded]` resume | pending your approval |
| L4 | Experience | "Built and maintained about 25 dbt models including the core orders mart." | Same line, moved above the Python bullet | `reorder` | "Built and maintained about 25 dbt models including the core orders mart." | `[grounded]` resume | pending your approval |
| L5 | Skills / Experience | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | "Python for analysis (pandas) and some scripting to pull vendor APIs on a cron." | `compress` | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | `[grounded]` resume | pending your approval |

Notes on the ledger:
- L1 keeps "with our then-DE." Dropping it would make you the sole designer, which your sentence doesn't say.
- L1 says "dbt models" and "star schema," your own terms, rather than the JD's "dimensional modelling."
- L5 does not say "production." Your sentence doesn't support it.

## Not written, and why

- **"Data engineer" as a title, or "3 years data engineering."** The resume shows analytics work only.
- **"Owned data quality," "owned the nightly pipeline," or "owned SLAs."** You fixed and tested the nightly job. Ownership isn't in your sentences.
- **"Production Python."** Your sentences say analysis and cron-scheduled scripts.
- **"Airflow," "orchestration," "Spark," "Kafka," "streaming."** You've never used them, and the resume shouldn't imply otherwise.
- **"Dimensional modelling" as a label.** The resume's term is "star schema." The JD's term describes the same work, but it is borrowed vocabulary.
- **"Modelled the warehouse."** Your evidence covers one mart, the orders mart, not the warehouse.
- **"Partnered with analytics on requirements."** "Partner" is the posting's word; your sentences don't say it, and the word would change which side of the table you were on.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| C1 | 3+ years data engineering | must-have | not_evidenced | Analytics titles only; dbt and star-schema work is adjacent | `[grounded]` resume: "Senior Data Analyst, 5 years, retail." |
| C2 | Dimensional modelling | important | already_evidenced | "I designed the star schema for the orders mart…" (L3 moves it up) | `[grounded]` resume |
| C3 | Build and own batch pipelines | important | surfaced_by_edit | dbt models and nightly job (L2, L4); no ingestion or ownership stated | `[grounded]` resume |
| C4 | Model the warehouse | important | surfaced_by_edit | One mart (L1, L3); scope is the orders mart only | `[grounded]` resume |
| C5 | Own data quality | important | surfaced_by_edit | Tests added to the nightly job (L2); no ownership claimed | `[grounded]` resume |
| C6 | Own SLAs | important | not_evidenced | No SLA or freshness target in the resume | `[grounded]` resume |
| C7 | Production Python | important | not_evidenced | Analysis Python and cron scripts (L5); "production" not stated | `[grounded]` resume |
| C8 | Airflow or equivalent orchestration | important | not_evidenced | The nightly dbt job's scheduler isn't named | `[grounded]` resume |
| C9 | Partner with analytics on requirements | important | not_evidenced | Analyst background implies it, but no sentence says it | `[grounded]` resume |
| C10 | Streaming pipelines | preferred | not_evidenced | Never built one; never touched Kafka | `[grounded]` resume: "Never touched Kafka." |
| C11 | Spark | preferred | not_evidenced | Named in the stack, not a stated requirement; "Never used Airflow or Spark." | `[grounded]` resume |

## Gap handling

- **C1, 3+ years data engineering (named absence).** Your resume shows five years as an analyst and no data-engineering role. The dbt, star-schema and nightly-job work is the closest evidence, but it sits under an analytics title, and no line can change that without inventing a title or years. Closing it takes time in a data-engineering or data-engineering-scoped role. Whether to apply with this gap is job-underwriter's call, which I'd run before you invest more in this resume.
- **C6, C8, C7 (recall prompts).** Q1 to Q3 below. Each answer that checks out becomes a row, after a confirmation step.
- **C9, partnering with analytics (named absence with a closing path).** The stakeholder side of your analyst work isn't written down. If you took a requirement from a business team into a model, one specific example in your own words would become a row.
- **C10 and C11, streaming and Spark (named absence).** You have no streaming or Spark work. Streaming is listed as a plus, so it doesn't gate the role, and closing it would mean a real project, not a resume edit. I wouldn't chase it for this application.

## Parse-safety check

Your resume arrived as pasted text, so I couldn't check layout, tables, headers or file type. Send the actual file and I'll run the checks that the file allows.

## Upgrade menu (proposals, built only if you say yes)

- A link to or file of the dbt project for the orders mart, including model YAML and tests. This would let L1 to L4 rest on something inspectable instead of your word alone.
- A short description or diagram of how the nightly job runs and alerts. This would ground C6 and C8.
- The cron configuration and any error handling for the vendor-API scripts. This would ground C7.

## Questions

Q1 (C8): What runs the nightly dbt job: cron, Airflow, dbt Cloud, or something else? If it's an orchestrator, which one, and what did you configure in it?

Q2 (C6): For the orders mart, was there a freshness or availability target, and did anyone get alerted or check when it missed?

Q3 (C7): Did any vendor-API cron script run unattended for someone who depended on its output, with error handling, alerts or tests?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.