I've worked from your description, since no resume file came through. The output is a ledger of proposed edits, not a rewritten resume. Nothing is applied until you approve rows. I also assumed your current bullets sit in the order you described them.

## Edit ledger

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| L1 | Summary (new) | *(no current line)* | "Senior Data Analyst, 5 years in retail. SQL every day on Redshift, including complex window functions and CTEs. Built and maintained about 25 dbt models, including the core orders mart, and designed the star schema for it with a data engineer." | merge | "Senior Data Analyst, 5 years, retail."; "SQL every day on Redshift, complex window functions and CTEs."; "Built and maintained about 25 dbt models including the core orders mart."; "I designed the star schema for the orders mart with our then-DE." | `[grounded]` resume, description | pending your approval |
| L2 | Experience | "I designed the star schema for the orders mart with our then-DE." | "Designed the star schema for the orders mart with our then-DE." (moved to the top of Experience) | reorder | "I designed the star schema for the orders mart with our then-DE." | `[grounded]` resume, description | pending your approval |
| L3 | Experience | "Built and maintained about 25 dbt models including the core orders mart." | Unchanged, moved to second position | reorder | "Built and maintained about 25 dbt models including the core orders mart." | `[grounded]` resume, description | pending your approval |
| L4 | Experience | "I've fixed our nightly dbt job when it breaks and added tests to it." | "Fixed our nightly dbt job when it breaks, and added tests to it." (placed beside L3) | reorder | "I've fixed our nightly dbt job when it breaks and added tests to it." | `[grounded]` resume, description | pending your approval |
| L5 | Skills | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | "Python for analysis (pandas), and some scripting to pull vendor APIs on a cron." | reframe | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | `[grounded]` resume, description | pending your approval |

Notes on the audit:
- L1 keeps "5 years" and "about 25" attached to what they count. "With a data engineer" stands in for "with our then-DE" without changing who did the work.
- I kept "designed … with" rather than "co-designed". "Co-designed" is a verb change, and it would move the work toward ownership.
- "Production" appears nowhere. You did not say any of this work ran in production, so the posting's word would be borrowed.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| C1 | 3+ years data engineering | must-have | not_evidenced | Gap is transferability. Adjacent work is in L1, L3 and L4. No data-engineering tenure is stated. Recovery: R1. | `[grounded]` resume title and years |
| C2 | Production Python | important | not_evidenced | Gap is transferability. L5 shows pandas and cron-scheduled scripts, not production ownership. Recovery: R2. | `[grounded]` resume |
| C3 | Airflow or equivalent orchestration | important | not_evidenced | Gap is transferability. Cron is the nearest thing, and whether it counts as orchestration is the reader's call, so this row does not claim it. Recovery: R2. | `[grounded]` you have never used Airflow |
| C4 | Dimensional modelling | important | surfaced_by_edit | L2 and L1. The star schema is in your description but not near the top. | `[grounded]` resume |
| C5 | Model the warehouse | important | surfaced_by_edit | L1 and L2. The evidence covers one mart, not the warehouse, and the row claims no more. | `[grounded]` resume |
| C6 | Build and own batch pipelines | important | surfaced_by_edit | L3 and L4. The evidence shows building and maintaining dbt models. "Own" is not shown. | `[grounded]` resume |
| C7 | Own data quality | important | surfaced_by_edit | L4. Fixing the nightly job and adding tests show contribution, not ownership. | `[grounded]` resume |
| C8 | Own SLAs | important | not_evidenced | Gap is discovery. Nothing in your description mentions a delivery or freshness commitment. Recovery: R3. | `[grounded]` resume |
| C9 | Partner with analytics on requirements | important | not_evidenced | Gap is discovery. Your description does not say how requirements reached you. Recovery: R3. | `[grounded]` resume |
| C10 | Streaming pipelines (Kafka, Spark) | preferred | not_evidenced | Gap is capability. You have never used Kafka or Spark. Named absence: N1. | `[grounded]` you have never touched Kafka |

## Gap handling

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| R1 | C1: 3+ years data engineering | must-have | Five years as an analyst, with dbt models and a star schema. No data-engineering title. | The posting names years, not a credential, so this is a fit gap and not a hard gate. A reader filtering on years will read five years of analysis as analysis. `[generic]` pattern for screening on stated years | A loading job others depended on; a scheduled process you were called about when it failed | Repo or run logs for that job | `[grounded]` what the resume shows; `[generic]` how screeners treat stated years |
| R2 | C2 and C3: production Python; Airflow or equivalent | important | pandas analysis, and cron-scheduled vendor-API scripts | The posting names both as requirements, and the scripts are the nearest evidence | Vendor pulls others relied on, with error handling or tests; scheduled jobs with dependencies or alerts | The scripts' repo, the scheduler config for the nightly job, a run log | `[grounded]` what the resume says; `[generic]` what these requirements usually mean |
| R3 | C8 and C9: own SLAs; partner with analytics | important | Nothing about freshness commitments or requirements gathering | These are the promises analytics depends on, and an engineer in this role would own them | A freshness target the orders mart met or missed; requirements you gathered from its users | A stakeholder thread, a ticket, an SLA note | `[grounded]` resume |

**N1 — C10, streaming (named absence).** You have never used Kafka or Spark, and the posting lists streaming as a plus, not a requirement. Closing it would take a real project. A small one would be a pipeline that reads a public event feed through Kafka into a table and runs for several weeks, with a repo link to show it. That link would be the evidence, and the row closes only with it. `[grounded]` your description; `[generic]` what a small project costs.

## Prohibited claims

Not written, and why:
- **"Data Engineer" in any title or summary.** Your titles are analyst titles, and retitling them is a claim about the job you held.
- **Any years of data engineering.** You have none stated, and C1 is a must-have.
- **"Airflow," "orchestrated pipelines" or "DAGs."** You have never used Airflow, and cron scripts are not orchestration in the sense the posting means.
- **"Spark," "Kafka," "streaming" or "real-time."** You have never used or touched them.
- **"Owned data quality," "owned the nightly job" or "owned SLAs."** You fixed and tested the job. Ownership is not stated.
- **"Production Python" or "production pipelines."** Not stated.
- **"Modelled the warehouse."** You designed one mart's star schema. "The warehouse" widens the scope.
- **"Partnered with analytics on requirements."** Not in your description. The posting's word would not be yours.

Rejected rows: none yet.

## Parse-safety check

Your resume came as a description, so I could not run any layout check: multi-column layout, tables, text boxes, header or footer contact details, or section headings. Send the file and I will run them.

## Upgrade menu

- **The resume file, or your bullets in their current order.** This checks the order assumption and lets the parse-safety check run on the real layout.
- **The dbt project or the cron scripts' repo, with the tests.** This makes "added tests" and the scripts inspectable, which moves C2 and C7 on evidence.
- **The scheduler config for the nightly job.** This settles C3 directly.
- **A written freshness target for the orders mart, or a ticket where analytics asked for something.** This moves C8 and C9.
- **A streaming project link, only if you build one.** This is the only way N1 closes.

Whether to apply at all, with a three-year must-have and no data-engineering tenure, is job-underwriter's call.

## Questions

R1 — Beyond the dbt work, did you ever build a loading or ingestion job, or get called when a scheduled job failed, with other people depending on it?

R2 — What ran the vendor-API scripts and the nightly dbt job: plain cron or something else, and did anyone besides you rely on them or get alerted when they failed?

R3 — Who relied on the orders mart, and how did that work: did anyone agree a delivery time with you, or did requests come to you from them?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.