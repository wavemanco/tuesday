**Short answer:** Keyword placement will help a little, but it can't close the gap this posting is mostly about. Terraform, ArgoCD, Istio, Prometheus/Grafana, Vault, Helm, GitLab, Go, and EKS in production don't appear in your resume. I can't add them without claims you'd have to defend in an interview. What I can do is make your real experience easier to find.

**Why keywords alone probably aren't the cause.** The evidence is thinner than most advice suggests. In one vendor's interviews with 25 US recruiters, two had content-based auto-rejection set up, and the vendor calls the findings themes rather than representative statistics (cite C25). Where teams use match scores, a low score doesn't reject you outright: "in high-volume roles, it can push you to the bottom of the pile" (cite C27). The more common machine rejection is knockout questions: "yes/no eligibility checks (work authorization, required license, location)" (cite C26). Those are answered on the application form, not in the resume, so check them before you spend more time on the document. Whether to apply at all, given these gaps, is a job-underwriter question.

## Coverage map

The posting doesn't rank its requirements, so I've treated the named tools as must-have and the rest as important.

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| 1 | Kubernetes | must-have | surfaced_by_edit | E1: proof-of-concept only; "never went to production" stays in | `[grounded]` resume |
| 2 | AWS EKS | must-have | not_evidenced | No EKS in the resume; the proof-of-concept platform is unknown (C1) | `[grounded]` resume |
| 3 | Terraform | must-have | not_evidenced | No infrastructure-as-code tool named; Ansible is config management (C2) | `[grounded]` resume |
| 4 | GitOps / ArgoCD | must-have | not_evidenced | Deploys are pushed from Jenkins; no Git-driven reconciliation shown | `[grounded]` resume |
| 5 | Prometheus / Grafana / observability | must-have | not_evidenced | CloudWatch monitoring is adjacent, not the same tools (C3) | `[grounded]` resume |
| 6 | SRE practices / platform reliability | must-have | not_evidenced | No SLOs, on-call or incident work named (C3) | `[grounded]` resume |
| 7 | Developer experience | must-have | not_evidenced | The pipeline is the nearest evidence; nothing shows developer-facing change | `[grounded]` resume |
| 8 | Helm | important | not_evidenced | Not named; asked in C1 | `[grounded]` resume |
| 9 | Istio / service mesh | important | not_evidenced | Not present | `[grounded]` resume |
| 10 | Vault | important | not_evidenced | Not present; IAM is access control, not secrets management | `[grounded]` resume |
| 11 | CI/CD | important | surfaced_by_edit | E2: the deploy pipeline carries the category; the term is added as an edit | `[grounded]` resume |
| 12 | GitLab CI | important | not_evidenced | Jenkins only | `[grounded]` resume |
| 13 | Go | important | not_evidenced | Not present | `[grounded]` resume |
| 14 | Python | important | already_evidenced | "Bash and Python scripting" | `[grounded]` resume |
| 15 | AWS | must-have | already_evidenced | EC2, S3, RDS, IAM | `[grounded]` resume |

## Edit ledger

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Skills | "AWS (EC2, S3, RDS, IAM), Docker, Jenkins, Bash and Python scripting, Ansible for config management, CloudWatch for monitoring." | "AWS (EC2, S3, RDS, IAM), Kubernetes (proof-of-concept, not production), Docker, Jenkins, Bash and Python scripting, Ansible for config management, CloudWatch for monitoring." | `surface` | "Ran a Kubernetes proof-of-concept for two months last year — never went to production." | `[grounded]` resume | pending your approval |
| E2 | Experience | "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs." | "Built our CI/CD deploy pipeline in Jenkins and maintain about 30 Jenkins jobs." | `reframe` | "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs." | `[inferred]` the term CI/CD for a deploy pipeline | pending your approval |

Notes on the two rows:
- **E1** keeps the qualifier. Listing Kubernetes without "proof-of-concept, not production" would be the claim that gets you caught.
- **E2** is borderline under the audit. The posting says "CI/CD (GitLab)", and I'm using the term only because a deploy pipeline in Jenkins is usually called CI/CD. Approve it only if the pipeline built and tested code, not just deployed it. Reject it if you'd rather not use the term.

Nothing else on the resume supports a truthful edit toward this posting. That's a finding, not a failure to look.

## Recovery: what would change the picture

These three recall prompts are the only places a gap might close. Answer any of them in text, or say skip.

| # | Requirement | What the resume shows | Experience that may count | Provenance |
|---|---|---|---|---|
| C1 | EKS, Helm | Proof-of-concept only; platform and deploy method unknown | Which cluster it ran on; how apps were deployed; whether anyone used it | `[grounded]` resume; `[generic]` what this costs on applications of this kind |
| C2 | Terraform | Ansible and console-level AWS work | Any AWS resource created or changed by code (Terraform, CloudFormation, Ansible) | `[grounded]` resume |
| C3 | Observability, SRE | CloudWatch monitoring only | A CloudWatch alarm or dashboard others acted on; on-call; a post-incident review | `[grounded]` resume |

**Named absences (no question needed):**
- **GitOps / ArgoCD:** Your deploys are pushed from Jenkins. GitOps keeps the desired state in Git and has a controller apply it. Closing it means a hands-on project with ArgoCD on a cluster you control, with a documented sync. Until then, it stays out of the resume.
- **Istio / service mesh:** Not present. Closing means installing it on a test cluster and documenting one traffic policy.
- **Vault:** Not present. Closing means running it in dev mode and using it from one pipeline job.
- **GitLab CI:** Jenkins only. Closing means moving one pipeline to GitLab CI in a personal project.
- **Go:** Python and Bash are your languages here. Closing means a small Go tool. Worth closing only if the role's tooling needs it.

## Not written, and why

- **"Production Kubernetes experience" or "EKS clusters"**: the proof-of-concept never went to production, and the platform is unconfirmed.
- **"Platform Engineer" as a title, or "platform engineering"**: the title is an upgrade from DevOps Engineer.
- **"Owned platform reliability" or "owned developer experience"**: the posting's sentence, not your history.
- **"GitOps"**: a push pipeline from Jenkins isn't GitOps.
- **Any of Terraform, ArgoCD, Istio, Prometheus, Grafana, Vault, Helm, GitLab, Go in a skills list**: listing a tool claims you used it.
- **"Observability" for CloudWatch work**: monitoring is the word you used; observability is the posting's word.
- **"Managed our Jenkins infrastructure" or "owned the CI/CD platform"**: "built our deploy pipeline" and "maintain about 30 Jenkins jobs" are your sentences. Anything bigger is a scope claim.

## Parse-safety check

I haven't seen the PDF, so this is based on your description and I couldn't run the checks on the file itself.

| Check | Observed | What it costs |
|---|---|---|
| Multi-column layout | Yes, two columns | Text may interleave, and dates may separate from the roles they belong to |
| Tables and text boxes | Unknown; Canva often uses text boxes | Sections can vanish if they're boxed |
| Icons per skill | Yes | Skill names may be dropped or come through as garbage characters |
| Content in headers | Yes, contact details | Your contact details may not be extracted, so a recruiter can't reach you |
| Section headings | Unknown | Non-standard headings may not be recognised |
| File type | PDF; text layer unknown | Check by selecting all text in the PDF: if it copies cleanly in reading order, the text layer is probably fine |

## Upgrade menu

- A summary line built only from your existing sentences, as a merge row for you to approve or reject.
- Once you answer C1–C3, I'll run the confirmation card and add rows only for what you confirm.
- A plain-text copy of the approved content for uploading, with the same facts and no layout.

## Questions

**C1:** What cluster did the Kubernetes proof-of-concept run on (EKS or something else), and how did you deploy apps to it: Helm charts, plain manifests, or something else?

**C2:** For the AWS resources you've managed (EC2, S3, RDS, IAM), were any created or changed through code (Terraform, CloudFormation, Ansible) rather than the console?

**C3:** Have you owned a CloudWatch alarm or dashboard that other people acted on, been on an on-call rotation, or run a post-incident review?

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.