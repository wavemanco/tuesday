Short answer: keyword matching is probably not the main reason you're being rejected. The bigger problem is that this JD asks for about eleven tools your resume can't show. The Canva layout also likely hides the skills you do have from a parser. Below, I've only used what you've told me. I haven't seen the PDF, so "current line" means your wording as you described it.

**Why keywords alone won't fix this.** In the one sample available, content-based auto-rejection is uncommon: "AI/content auto-rejection configured: 8% of recruiters" (cite C25), and that is two of 25 recruiters, from a résumé-builder vendor. Knockout questions in the application form are what most often reject people without a person reading: "When automated filters are used, they're almost always knockout questions" (cite C26). Match scores mostly set who gets reviewed first (cite C27). So a tailored resume can make you easier to find, but it can't add Terraform or Istio.

Research tier: L0, no searches.

## 1. Edit ledger

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience | "Ran a Kubernetes proof-of-concept for two months last year — never went to production." | Same wording, moved to the first Experience bullet | `reorder` | "Ran a Kubernetes proof-of-concept for two months last year — never went to production." | `[grounded]` your description | pending your approval |
| E2 | Skills | "AWS (EC2, S3, RDS, IAM), Docker, Jenkins, Bash and Python scripting, Ansible for config management, CloudWatch for monitoring." | "Python and Bash scripting, AWS (EC2, S3, RDS, IAM), Jenkins, Docker, Ansible for config management, CloudWatch for monitoring." | `reorder` | "AWS (EC2, S3, RDS, IAM), Docker, Jenkins, Bash and Python scripting, Ansible for config management, CloudWatch for monitoring." | `[grounded]` your description | pending your approval |
| E3 | Summary (new) | none | "DevOps Engineer, 4 years. Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs. Ran a Kubernetes proof-of-concept for two months last year — never went to production." | `merge` | "DevOps Engineer, 4 years."; "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs."; "Ran a Kubernetes proof-of-concept for two months last year — never went to production." | `[grounded]` your description | pending your approval |

E3 keeps the production qualifier. Merging the three sentences into one clause would make the PoC sound like production work, so they stay as separate sentences.

## 2. Coverage map

Your JD doesn't rank its requirements, so I've treated each named tool as a must-have.

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| C1 | Kubernetes | must-have | surfaced_by_edit | E1, E3. A proof-of-concept only, not production. | `[grounded]` your description |
| C2 | AWS EKS | must-have | not_evidenced | Nothing in your material says whether the PoC used EKS. See Q2. | `[grounded]` absence in your description |
| C3 | AWS | must-have | already_evidenced | E2 | `[grounded]` your description |
| C4 | Python | must-have | already_evidenced | E2 | `[grounded]` your description |
| C5 | CI/CD | must-have | already_evidenced | E3, for Jenkins. GitLab is a separate row. | `[grounded]` your description |
| C6 | GitLab CI | must-have | not_evidenced | No GitLab in your material. | `[grounded]` absence in your description |
| C7 | Terraform | must-have | not_evidenced | transferability: Ansible is configuration management, not provisioning | `[grounded]` absence in your description |
| C8 | Helm | must-have | not_evidenced | Unknown whether the PoC used it. See Q2. | `[grounded]` absence in your description |
| C9 | ArgoCD / GitOps | must-have | not_evidenced | capability: Jenkins is push-based, and GitOps is pull-based | `[grounded]` absence in your description |
| C10 | Istio / service mesh | must-have | not_evidenced | capability | `[grounded]` absence in your description |
| C11 | Prometheus / Grafana | must-have | not_evidenced | transferability: CloudWatch is adjacent monitoring, not these tools | `[grounded]` absence in your description |
| C12 | Observability | must-have | not_evidenced | transferability: CloudWatch monitoring is the closest evidence | `[grounded]` your description |
| C13 | Vault | must-have | not_evidenced | IAM is access control, not secrets management | `[grounded]` absence in your description |
| C14 | Go | must-have | not_evidenced | No Go in your material. | `[grounded]` absence in your description |
| C15 | SRE practices / platform reliability | must-have | not_evidenced | No reliability ownership in your material. See Q3. | `[grounded]` absence in your description |
| C16 | Developer experience | must-have | not_evidenced | Unknown whether your work served developers. See Q3. | `[grounded]` absence in your description |

## 3. Gap handling

- **C2 (EKS), C8 (Helm), C6 (GitLab), and C7 (Terraform):** one question closes these, Q2. The answer could move any of them to `surfaced_by_edit`, but only if you confirm it.
- **C15 and C16 (SRE, developer experience):** Q3 asks whether you have any example. If not, these stay absent.
- **Named absences, no recall pull:**
  - **Istio / service mesh (C10):** would need a mesh you've configured, such as traffic policy or mTLS, on a real cluster. A personal lab would be a closing path, not experience.
  - **ArgoCD / GitOps (C9):** would mean moving one service's deploys to Argo CD in a test cluster.
  - **Prometheus / Grafana (C11):** would mean instrumenting a service and building a dashboard.
  - **Vault (C13):** would mean running Vault and serving one app's secrets from it.
  - **Go (C14):** would mean a tool or service in Go with its code in a repo.

## 4. Not written, and why

- **"Production Kubernetes" or "Kubernetes in production":** the PoC never went to production.
- **Terraform, ArgoCD, Istio, Vault, Prometheus, Grafana, Helm, GitLab, Go, GitOps, service mesh, EKS in a skills list:** none appears in your material. Listing them claims them. Q2 is the way to check EKS and Helm.
- **"Platform Engineer" as a title:** you have held DevOps Engineer. Changing the title to a higher-status one is an upgrade, not an equivalent.
- **"Owned platform reliability" or "owned developer experience":** nothing you've described is ownership of either.
- **"Observability" in place of "monitoring" for CloudWatch:** that changes what the work was, from monitoring to observability.

## 5. Parse-safety check

This is run on your description, not the file, so the text-layer check could not be run.

- **Icons for each skill:** a parser will usually skip icons, so the skills list may be empty to a keyword matcher. This is probably the most direct cause of weak keyword matches.
- **Two-column layout:** parsers often read columns across rows, which scrambles text and can detach dates from roles.
- **Contact details in the header:** headers are often dropped during parsing, so the recruiter may not get your contact details.

I'm not making a visual design point here. Moving to a single column or dropping icons is about what the parser reads, not how it looks.

## 6. Upgrade menu

- **The resume as text:** copy all text from the PDF, paste it here, and I can check every quote against the real wording and see what a parser would get. This is the most useful next input.
- **A plain-text or .docx version:** a text-layer export with no icons or columns would let keyword matching see your skills.
- **Recall answers:** each one you answer could move a must-have from absent to surfaced.
- **Whether you should apply at all:** with this many gaps, job-underwriter can give a go/no-go on this role.

## Questions

1. **Q1 (C1, E1–E3):** Can you paste your resume text, copied from the PDF with select-all?
2. **Q2 (C2, C6, C7, C8):** For the Kubernetes PoC, did you run it on EKS or another cluster? Did you use Helm, Terraform or GitLab CI anywhere, even in the PoC? For each, say yes, no or not sure.
3. **Q3 (C15, C16):** Have you done on-call, incident response, SLO work or anything other engineers used day to day? Name one example, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.