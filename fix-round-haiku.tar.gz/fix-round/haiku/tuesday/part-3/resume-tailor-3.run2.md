Here's the tailored ledger. Nothing is applied yet; every row waits for your approval.

**Inputs:** I worked from the dossier excerpt and the CV summary in your message. I could not see the full `tuesday-dossier.md` or your actual CV bullets, so each "Current line" below is a placeholder. Paste the real bullets and I'll re-trace each row against them word for word.

**The honest ceiling:** This CV cannot meet the must-have "3+ yrs PM." Nothing below claims PM experience, roadmap ownership, or shipped products. The edits make the adjacent case clearer and stop there.

## Edit ledger

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience | (your bullet containing it; paste it) | Wrote the internal integration playbook the whole team uses. | split | "Wrote the internal integration playbook the whole team uses." | [grounded] CV summary | pending your approval |
| E2 | Experience | (your bullet; paste it) | Led 30+ client integrations of our REST APIs end to end. | reorder | "Led 30+ client integrations of our REST APIs end to end." | [grounded] CV summary | pending your approval |
| E3 | Experience | (your bullet; paste it) | Ran quarterly roadmap-input sessions collecting client feedback for product. | surface | "Ran quarterly roadmap-input sessions collecting client feedback for product." | [grounded] CV summary | pending your approval |
| E4 | Skills | (your tools line; paste it) | Comfortable in Postman, SQL, OpenAPI specs. | surface | "Comfortable in Postman, SQL, OpenAPI specs." | [grounded] CV summary | pending your approval |
| E5 | Summary | (no current line) | 7 years solutions engineer / implementation lead at an enterprise software vendor. Led 30+ client integrations of our REST APIs end to end. | merge | "7 years solutions engineer / implementation lead at an enterprise software vendor."; "Led 30+ client integrations of our REST APIs end to end." | [grounded] CV summary | pending your approval |

Notes:
- **E1** is the pending edit from the dossier. I re-audited it against your sentence rather than inheriting it, and it holds.
- **E3** stays "collecting client feedback." It does not become "drove the roadmap" or "ran discovery."
- **E5** keeps the two sentences separate, so neither claim grows.

## Coverage map

Priority for the "shipped products" and roadmap rows is my assumption. The excerpt marks only the PM years as must-have.

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| C-R1 | 3+ yrs PM | must-have | not_evidenced | transferability: E2 and E3 are adjacent; no PM title or roadmap ownership | [grounded] |
| C-R2 | Shipped API or platform products | important | not_evidenced | adjacent: E2 delivered integrations of "our REST APIs"; no product shipped | [grounded] |
| C-R3 | Own the roadmap and prioritisation | must-have | not_evidenced | E3 shows input-gathering only; the decision authority is not stated | [grounded] |
| C-R4 | Discovery with integration partners | important | not_evidenced | nearest is E3 (client feedback); partner discovery research is not stated | [grounded] |
| C-R5 | Specs and delivery with two engineering squads | important | not_evidenced | nearest is E2 (client-side integration work); no spec ownership or internal squads stated | [grounded] |
| C-R6 | Define adoption metrics | important | not_evidenced | nothing in the CV | [grounded] |
| C-R7 | Technical fluency | important | surfaced_by_edit | E4, with E2 for REST and OpenAPI | [grounded] |
| C-R8 | Stakeholder management | important | surfaced_by_edit | E2 and E3 show client-facing delivery; the phrase itself is not in the CV and should not be added | [grounded] |

## Recovery per gap

- **C-R1 and C-R3** (decision authority): asked below as C1.
- **C-R5** (specs): asked below as C2.
- **C-R6 (adoption metrics), named absence:** nothing in your CV measures post-launch adoption. Closing it would take one feature or integration you tracked after release, with the metric you watched and what changed. Without that, leave it as a gap.
- **C-R2 (shipped product), named absence:** the CV shows delivery of the vendor's APIs into client systems, not a product you shipped. Closing it would take a product you shipped, even internal, with a version you can point to. If you have none, target roles that value integration leadership over product ownership.
- **C-R4 (partner discovery), named absence:** closing it would take a discovery round you ran with partners or clients, with the questions you asked and the decisions it changed.

## Prohibited claims

Not written, and why:

- **"Product Manager" or any PM title, or "PM experience."** You have never held the title, and the dossier rates the PM years as adjacent with transferability as the gap type.
- **"Owned the roadmap" or "set priorities."** E3 shows input collection. The decision authority is not stated.
- **"Shipped API products."** The evidence is client integrations of your vendor's APIs, not a product you shipped.
- **Your time as a partner API platform customer.** The dossier rejected this inference: you worked vendor-side.
- **"Built an internal request-triage tool."** The dossier rejected this inference: ownership was not confirmed.
- **"Partner."** The JD says "integration partners"; your CV says "client." Swapping the word moves which side of the table you sat on.
- **"Ran discovery," "wrote specs," "drove delivery with engineering squads," "defined adoption metrics."** None of these is in your CV.
- **"Stakeholder management" as a skill label.** Not stated; the evidence is in E2 and E3.

## Parse-safety check

I could only check the summary text you sent, not the file. No hidden text, metadata, or knockout issues can be checked from here. Run the check on the actual document before you send it.

## Upgrade menu

- **Attach the playbook, or a redacted section of it.** This would turn E1 from a CV claim into an inspectable artifact. Check your employer's confidentiality terms before sharing it.
- **Attach a one-page summary of one quarterly roadmap-input session.** It would show what you collected and what happened to it. It would not show that you decided the roadmap.

## Questions

**C1 (C-R1, C-R3):** Name one decision about what got built next, from roadmap inputs or client integrations. Who decided, what you proposed, and what happened? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**C2 (C-R5):** Did you ever write a spec or requirements document that an engineering team built from? If so, for what, and for whom? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.