Research tier: L0, no searches. Your CV and the JD are both in hand, so this is built from the pasted text alone.

## Edit ledger

Two proposed edits, both pending your approval. The rest of the CV already puts the strongest evidence first, so nothing else moves. The pasted text has no headings, so the Section names are my assumption.

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Summary (new) | *(no current line)* | "Senior Software Engineer, 7 years. Currently at a payments company. Go and Rust daily for 4 years, Python before that." | `merge` | "Senior Software Engineer, 7 years."; "Currently at a payments company."; "Go and Rust daily for 4 years, Python before that." | `[grounded]` CV | pending your approval |
| E2 | Experience | "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | "On-call rotation every fourth week for two years." and "I've run six incidents as incident commander." | `split` | "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | `[grounded]` CV | pending your approval |

Reply with the rows you approve, for example `Approved: E1, E2`. I'll produce the resume from approved rows only.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| G1 | 5+ years backend engineering | must-have | already_evidenced | 7 years, and "services" in the ledger pipeline. The word "backend" is not in the CV, and no row adds it. | `[grounded]` CV |
| G2 | Production Go | must-have | surfaced_by_edit | "Go and Rust daily for 4 years" is buried beside Rust. E1 surfaces it. Whether the three services are in Go is not stated; see the G2 question below. | `[grounded]` CV |
| G3 | Distributed systems at scale | must-have | not_evidenced | Scale is evidenced (40k requests/minute at peak). Distributed design is not described. Kafka and gRPC appear only in the tools list. | `[grounded]` CV |
| G4 | Design and ship Go services handling high request volume | must-have | already_evidenced | "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak." | `[grounded]` CV |
| G5 | Drive down p99 latency | important | already_evidenced | "Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer." | `[grounded]` CV |
| G6 | Strong incident response | must-have | surfaced_by_edit | Incident command sits at the end of the on-call sentence. E2 gives it its own line. | `[grounded]` CV |
| G7 | Own on-call for your services | important | already_evidenced | "On-call rotation every fourth week for two years." | `[grounded]` CV |
| G8 | Mentor mid-level engineers | must-have | not_evidenced | Adjacent: onboarding and first-month pairing for new hires, usually two or three a year. That is not mentoring mid-level engineers. Gap type: transferability. See C2. | `[grounded]` what the CV holds |
| G9 | Partner with product on roadmap sequencing | important | not_evidenced | The CV says nothing about working with product on priorities. Closing it takes a real case where you set or changed a service's priorities with product. If there isn't one, say so in the interview rather than claim it. | `[grounded]` absence in the CV |

## Gap handling

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Distributed systems at scale | must-have | Scale: 40k requests/minute at peak across three services. Distributed design: not described. Kafka and gRPC appear only in the tools list. | The role's core is high-volume services, so an interviewer will probe how your services behave when a call or message path fails. The CV gives them nothing to start from. | A failure or backlog you reasoned about across services; a gRPC contract between two of them; a consumer or producer design on the Kafka path | A design doc, runbook, or Datadog dashboard for that path | `[grounded]` what the CV does and doesn't say; `[generic]` what interviewers probe on applications of this kind |
| C2 | Mentor mid-level engineers | must-have | Onboarding for new hires on your team, usually two or three a year, pairing with them for their first month. | The JD asks for mentoring. Onboarding is the closest match, and it is not the same thing. | A mid-level engineer you grew over months through reviews, a project you handed them, or a promotion case you wrote | A note from a manager or the engineer, a feedback write-up, a promotion packet | `[grounded]` what the CV holds; `[generic]` how mentoring requirements are usually read |

## Prohibited claims: not written, and why

- **"Senior Backend Engineer" as your title.** Your title is Senior Software Engineer. The JD's title is not your history.
- **"Mentored mid-level engineers."** Onboarding and first-month pairing is a different job. The JD's word would move the claim.
- **"Distributed systems at scale."** The CV names Kafka and gRPC but describes no distributed design. A tools list is not a design claim.
- **"Led the p99 work."** The CV says you cut p99 by reworking the cache layer. "Led" is a verb upgrade.
- **"Partnered with product on roadmap sequencing."** Nothing in the CV supports it.

## Parse-safety check

This CV arrived as pasted text, so I could not check layout, tables, text boxes, headers, footers or section headings. Before you send the file, check that your contact details are in the body and not in the header or footer, since some parsers drop header and footer text.

## Upgrade menu

- **A design doc, runbook or dashboard for the Kafka/gRPC path:** would turn G3 into a real row with inspectable proof.
- **A repo list or service list naming the language of each of the three services:** would make G2 `[grounded]` beyond the one CV sentence.
- **A mentee's or manager's note about a mid-level engineer you grew:** would give G8 evidence beyond onboarding.
- **An earlier resume version:** may hold evidence the current CV dropped.

## Questions

- **C1.** Describe one failure or design problem that crossed more than one of your services, such as the Kafka path, a gRPC call, or the balance-read path. What did you own, and what did the others own?
- **C2.** Beyond onboarding, have you grown a mid-level engineer over months, through reviews, a handed-over project, or a promotion case? If so, who, what did you do, and what changed for them?
- **G2.** Are the three ledger services you own written in Go? If any are Rust, which ones?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.