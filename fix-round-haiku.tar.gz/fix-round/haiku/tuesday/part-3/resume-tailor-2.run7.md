Research tier: L0, no searches

Nothing is applied. Every row is pending your approval. I worked from the description you sent, not the document, so the Current line column quotes your sentences. Whether to apply at all, given the must-have, is job-underwriter's call.

## The edit ledger

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| L1 | Experience | "Built and maintained about 25 dbt models including the core orders mart." | *(unchanged, moved to the top of Experience)* | `reorder` | "Built and maintained about 25 dbt models including the core orders mart." | `[grounded]` resume | pending your approval |
| L2 | Experience | "I designed the star schema for the orders mart with our then-DE." | "Designed the star schema for the orders mart, with our then-DE." | `reorder` | "I designed the star schema for the orders mart with our then-DE." | `[grounded]` resume | pending your approval |
| L3 | Experience | "I've fixed our nightly dbt job when it breaks and added tests to it." | "Fixed our nightly dbt job when it broke." | `split` | "I've fixed our nightly dbt job when it breaks and added tests to it." | `[grounded]` resume | pending your approval |
| L4 | Experience | "I've fixed our nightly dbt job when it breaks and added tests to it." | "Added tests to our nightly dbt job." | `split` | "I've fixed our nightly dbt job when it breaks and added tests to it." | `[grounded]` resume | pending your approval |
| L5 | Experience | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | "Python for analysis, in pandas." | `split` | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | `[grounded]` resume | pending your approval |
| L6 | Experience | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | "Some scripting to pull vendor APIs on a cron." | `split` | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | `[grounded]` resume | pending your approval |

- L2 drops "I" and keeps "with our then-DE". The qualifier is what keeps the design credit honest.
- L3 and L4 split the fix from the tests. Each half traces to the full sentence.
- L5 and L6 keep "some". Dropping it would claim more scripting than you described.
- No row changes the title. "Senior Data Analyst" stays.

## Coverage map

The posting marks only "3+ years data engineering" as must-have. I've treated the other listed requirements as important.

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 3+ years data engineering | must-have | not_evidenced | No DE tenure on the resume. Adjacent work is in L1–L4. Gap: transferability (G1). | `[grounded]` resume: "Senior Data Analyst, 5 years, retail." |
| R2 | Build batch pipelines | important | surfaced_by_edit | The dbt models and nightly job are in L1, L3, L4. The cron pulls are in L5, L6. | `[grounded]` resume |
| R3 | Own batch pipelines | important | not_evidenced | "Fixed" and "maintained" are on the resume. "Own" is not. Gap: discovery (C1, C2). | `[grounded]` resume |
| R4 | Airflow or equivalent orchestration | important | not_evidenced | "Never used Airflow." The nightly job's scheduler is not named. Gap: discovery (C2). | `[grounded]` resume |
| R5 | Production Python | important | not_evidenced | Python for analysis is stated. Whether the scripts ran in production is not. Gap: discovery (C1). | `[grounded]` resume |
| R6 | Dimensional and warehouse modelling | important | surfaced_by_edit | Star schema for the orders mart, co-designed. L2 moves it up and keeps "with our then-DE." Gap: none. | `[grounded]` resume |
| R7 | Data-quality checks | important | surfaced_by_edit | Tests added to the nightly dbt job: L4. Gap: none. | `[grounded]` resume |
| R8 | Own data quality and SLAs | important | not_evidenced | Tests exist. No SLA or freshness target is in the material. Gap: discovery (C3). | `[grounded]` resume |
| R9 | Partner with analytics on requirements | important | already_evidenced | The analytics side of that partnership is the current role. Gap: none. | `[grounded]` resume |
| R10 | Streaming (Kafka, Spark) | preferred | not_evidenced | "Never touched Kafka." Spark never used. Gap: capability (G2). | `[grounded]` resume |

## Gap handling

Recall prompts. The questions for these are in the closing block, tagged to their rows.

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Production Python; own batch pipelines | important | "some scripting to pull vendor APIs on a cron." Nothing on whether those jobs ran unattended or whether anyone relied on them. | The Python line is the only evidence for production Python, and it reads as analysis. | A vendor pull that ran on schedule into a table others queried; a failed pull you diagnosed and fixed; a backfill you ran. | The script or repo path, the cron entry, one run log. | `[grounded]` what the resume says; `[generic]` how a reader takes "for analysis" |
| C2 | Airflow or equivalent orchestration; own batch pipelines | important | "our nightly dbt job." Its scheduler is not named. | Orchestration is a listed requirement, and nothing on the page answers it. | A job whose steps waited on each other; a retry or backfill you configured; a schedule in a dbt Cloud or Airflow-style tool. | The nightly job's schedule config, or a screenshot of its run history. | `[grounded]` what the resume says; `[generic]` what a screener does with a missing tool name |
| C3 | Own data quality and SLAs | important | "added tests to it." No delivery time or freshness target appears. | The posting names SLAs, and the material has none. | A time the orders mart had to be ready by; an alert you set on the nightly job; a stakeholder who relied on the data arriving on time. | The dbt test file, any freshness config, a thread about a late job. | `[grounded]` the posting and the resume |

Named absences:

- **G1: 3+ years data engineering (must-have).** The five years are analytics, and no line can turn them into data-engineering tenure. The closing path is time on work where you own a pipeline's design and failures, not only consume its output. Until then, the honest target is a title that matches the work, such as analytics engineering, where dbt and modelling carry more weight. Provenance: `[grounded]` for the years; `[generic]` for what those roles weigh.
- **G2: Streaming (Kafka, Spark), preferred.** There is no streaming work. The closing path is one small project that reads events from one source into one table and handles duplicate and late records. It differentiates you without closing the must-have. Provenance: `[generic]` for what it signals to a reader.

## Not written, and why

- "Data Engineer," or "3 years data engineering." The years are analytics. The must-have is the one line this material cannot carry.
- "Owned the nightly pipeline" or "owned batch pipelines." The material says fixed and maintained. Owning is a different job, and an interviewer will test it in one question.
- "Owned data quality and SLAs." Tests were added. No SLA is in the material.
- "Airflow," "Spark," or "Kafka" in any line or skills list. You have not used them.
- "Production Python." The material says pandas for analysis, plus scripts on a cron.
- "Designed the warehouse" or "modelled the warehouse" without "with our then-DE." Dropping the qualifier moves you from co-designer to sole designer.
- Anything streaming.

## Parse-safety check

Not run: layout, tables, text boxes, headers and footers, icons, and section headings. The resume arrived as your description, not a file. Send the file as a .docx or a text-layer PDF, the safe pair, and I can run this check on it.

## Upgrade menu

- **The resume file.** Replaces the description with your real lines, so the Current line column is exact, and unlocks the parse-safety check.
- **The vendor-API scripts (path, cron entry, one run log).** Unlocks C1.
- **The nightly job's schedule config or run history.** Unlocks C2.
- **The dbt test files or any freshness target.** Unlocks C3.
- **Offer, not built:** a summary line drawn only from approved rows. It would give the move one opening sentence, since the ledger has none. I'll build it only if you approve.

## Questions

For each, answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**C1:** Did any of the vendor-API scripts run unattended on a schedule, write to a table others queried, and get fixed after a failed pull?

**C2:** What scheduled the nightly dbt job: plain cron, a scheduler tool such as Airflow or dbt Cloud, or something else?

**C3:** Did the orders mart or the nightly job have a time it had to be ready by, and did you set the tests yourself or were they set for you?

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.