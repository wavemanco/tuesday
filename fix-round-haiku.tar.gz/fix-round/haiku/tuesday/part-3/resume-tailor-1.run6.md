**Research tier: L0, no searches.** Working from the posting and your CV text only. I could not run the parse-safety check on a file, so it is limited to what the pasted text shows (see below).

**Assumptions this is built on**
- You have no section headers in what you sent, so I've assumed Summary and Experience sections.
- "Go and Rust daily" and "I own three services" together mean the ledger services are Go and in production. If that's wrong, tell me and rows E1 and the Go coverage line change.

Approve or reject by row, e.g. `Approved: E1, E2, E4`. Nothing is applied yet.

## The edit ledger

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Summary (new) | *(no current line)* | "Senior Software Engineer, 7 years. Go and Rust daily for 4 years, Python before that." | `merge` | "Senior Software Engineer, 7 years."; "Go and Rust daily for 4 years, Python before that." | `[grounded]` CV | pending your approval |
| E2 | Experience | "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak." | "Own three services in our ledger pipeline." | `split` | "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak." | `[grounded]` CV | pending your approval |
| E3 | Experience | "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak." | "One of them handles about 40k requests/minute at peak." | `split` | "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak." | `[grounded]` CV | pending your approval |
| E4 | Experience | "Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer." | *(unchanged, moved to the top of Experience)* | `reorder` | "Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer." | `[grounded]` CV | pending your approval |
| E5 | Experience | "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | "On-call rotation every fourth week for two years." | `split` | "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | `[grounded]` CV | pending your approval |
| E6 | Experience | "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | "Ran six incidents as incident commander." | `split` | "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | `[grounded]` CV | pending your approval |
| E7 | Experience | "I do onboarding for new hires on my team — usually two or three a year, I pair with them for their first month." | "Onboard new hires on my team, usually two or three a year, and pair with each for their first month." | `reframe` | "I do onboarding for new hires on my team — usually two or three a year, I pair with them for their first month." | `[grounded]` CV | pending your approval |

E7 says "onboard" and "pair", not "mentor". The onboarding line does not stand in for the mentoring requirement; see C1 below.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 5+ years backend | must-have | not_evidenced | CV says 7 years of software engineering, not how many were backend. See C3. | `[grounded]` CV |
| R2 | Production Go | must-have | already_evidenced | "Go and Rust daily for 4 years" (E1). Production status is the stated assumption above. | `[grounded]` CV |
| R3 | Design and ship Go services at high request volume | must-have | surfaced_by_edit | Owning three services and the 40k requests/minute figure (E2, E3). "Design" and "ship" are not in the CV and are not claimed. | `[grounded]` CV |
| R4 | Drive down p99 latency | must-have | already_evidenced | The 380ms to 95ms cut (E4 moves it up; no wording change). It is on the balance-read path, not a build cache. | `[grounded]` CV |
| R5 | Own on-call for your services | must-have | already_evidenced | Four-weekly on-call rotation for two years (E5). | `[grounded]` CV |
| R6 | Strong incident response | must-have | already_evidenced | Six incidents as incident commander (E5, E6). | `[grounded]` CV |
| R7 | Distributed systems at scale | must-have | surfaced_by_edit | The 40k requests/minute figure (E3). Kafka and gRPC appear only in the skills list, with no usage stated, so they are not linked to the work. | `[grounded]` CV |
| R8 | Mentor mid-level engineers | must-have | not_evidenced | Onboarding and pairing with 2–3 new hires a year (E7) is adjacent. It is not mentoring of mid-level engineers. See C1. | `[grounded]` CV |
| R9 | Partner with product on roadmap sequencing | important | not_evidenced | Nothing in the CV about product or sequencing. See C2. | `[grounded]` CV |

## Gap handling

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Mentor mid-level engineers | must-have | Onboarding and pairing with new hires for their first month. That is onboarding, not mentoring of people past the new-hire stage. | The posting lists mentoring as a requirement, and interviewers usually probe it past onboarding. | Feedback or code review that changed how a mid-level engineer worked; a growth plan or check-ins over several months; running a design review or reading group for the team. | A review thread, a feedback note, or a growth-plan summary with names removed. | `[grounded]` what the CV says; `[generic]` how interviewers usually probe this requirement |
| C2 | Partner with product on roadmap sequencing | important | Nothing about product, planning or sequencing. | The posting makes it part of the role, and it is the one requirement the CV does not touch. | A decision on what ships first in ledger work, made with a product owner; a migration or deprecation timed around a product launch; a scoping document agreed with product. | A roadmap or planning document, a decision record, or a thread with product. | `[grounded]` what the CV says; `[generic]` how this requirement is usually assessed |
| C3 | 5+ years backend | must-have | "Senior Software Engineer, 7 years." It does not say how many years were backend work. | The posting asks for 5+ years of backend. If the backend years are 5 or more, R1 moves to surfaced_by_edit. | Work on the ledger services; any earlier role where the services were server-side, such as the Python work. | Dated role history with titles and employers. | `[grounded]` what the CV says |

Only the three questions in the closing block need answering. If you have none of these examples, say skip and I'll leave the row as it is.

## Not written, and why

- **"Mentored mid-level engineers" or "mentor"**: the CV describes onboarding and pairing with new hires. Mentoring is a different job; it would be the posting's word applied to your record.
- **"Distributed systems"**: the CV never uses the phrase. The 40k figure carries the scale claim, and Kafka and gRPC are listed without any stated use.
- **"Design" or "ship" for Go services**: neither word is in the CV. "Own" and "services" are the words you used.
- **"Build-cache" or "build-cache platform experience"**: your cache work was on a payments balance-read path. Calling it build-cache would change the domain, not just the wording.
- **"Led" or "drove" the p99 work across the platform**: the CV says you cut p99 on one path. Spreading it to the platform widens the scope.
- **"Backend engineer" as the title or summary**: the CV does not say backend. R1 stays open until C3 is answered.
- **"Partnered with product"**: not in the CV, and "partner" is the posting's word. See C2.

## Parse-safety check (limited)

This ran on the text you pasted. It could not check layout, tables, headers, footers or icons, because there was no file. Nothing in the text points to a parse risk. If you send the resume as a `.docx` or text-layer PDF, I can run the full check.

## Upgrade menu

- **Dated role history** (titles, employers, start and end dates): settles R1 and sharpens E1 with real years, rather than my assumption.
- **The write-up or design doc for the 380ms to 95ms cache change**: would give R4 inspectable proof, moving it from a claim you made to a checked one.
- **The CV as a file** (`.docx` or text-layer PDF): lets the parse-safety check run on the real layout, and confirms the section headers the ledger assumes.

C1 — Beyond onboarding, have you mentored or grown a mid-level engineer, through code review, growth plans, or feedback over months?

C2 — Have you decided what ships in what order with product or a PM, even informally? If so, what was the decision?

C3 — How many of your 7 years were backend work, and roughly when did that start?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.