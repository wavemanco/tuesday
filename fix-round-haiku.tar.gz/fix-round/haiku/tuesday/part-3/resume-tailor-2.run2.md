I used the resume-tailor module. Nothing is applied yet: every row waits for your approval, and I'll build the resume from approved rows only.

The honest picture: your history supports the modelling and dbt half of this job. The pipeline-ownership, orchestration and streaming half isn't in it, so the ledger doesn't write around those gaps. I read only "3+ years data engineering" as labelled must-have, treated the other requirements as important, and streaming as preferred because the JD calls it "a plus."

## Edit ledger

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Summary (new) | *(no current line)* | Designed the star schema for the orders mart with our then-DE. Built and maintained about 25 dbt models, including the core orders mart. | merge | "I designed the star schema for the orders mart with our then-DE."; "Built and maintained about 25 dbt models including the core orders mart." | `[grounded]` resume | pending your approval |
| E2 | Experience | "I've fixed our nightly dbt job when it breaks and added tests to it." | Fixed our nightly dbt job when it breaks and added tests to it. | reframe | "I've fixed our nightly dbt job when it breaks and added tests to it." | `[grounded]` resume | pending your approval |
| E3 | Experience | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | Python for analysis (pandas) and some scripting to pull vendor APIs on a cron. | reframe | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | `[grounded]` resume | pending your approval |

E1 keeps "with our then-DE," so the star schema stays shared credit. "Senior Data Analyst, 5 years, retail" is ambiguous (five years in retail, or five years in total), so I left that header line alone and didn't use it in E1.

## Coverage map

Research tier: L0, no searches. This skill declares no research targets.

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 3+ years data engineering | must-have | not_evidenced | Five years of analytics work, with dbt and pipeline upkeep. No data-engineering title or tenure. Named absence below. | `[grounded]` resume |
| R2 | Production Python | important | surfaced_by_edit | E3 surfaces the cron-scheduled scripts. The resume doesn't say "production," so the line doesn't either. Recall C2. | `[grounded]` resume |
| R3 | Airflow or equivalent orchestration | important | not_evidenced | Never used Airflow. What schedules the nightly dbt job isn't stated. Recall C1. | `[grounded]` resume |
| R4 | Dimensional and warehouse modelling | important | surfaced_by_edit | E1: star schema for the orders mart, designed with your then-DE. | `[grounded]` resume |
| R5 | Build and own batch pipelines | important | surfaced_by_edit | E1, E2, E3: built and maintained dbt models, fixed the nightly job. "Own" isn't stated, so it isn't claimed. | `[grounded]` resume |
| R6 | Data quality | important | surfaced_by_edit | E2: tests added to the nightly job. | `[grounded]` resume |
| R7 | SLAs | important | not_evidenced | Nothing on delivery times, freshness or alerting. Recall C2. | `[grounded]` resume |
| R8 | Partner with analytics on requirements | important | not_evidenced | Analyst-side work is visible; requirements conversations with stakeholders are not. Recall C3. | `[grounded]` resume |
| R9 | Streaming (Kafka) | preferred | not_evidenced | "Never touched Kafka." Named absence below. | `[grounded]` resume |
| R10 | Spark | important | not_evidenced | Named in the responsibilities rather than the requirements. "Never used Airflow or Spark." Named absence below. | `[grounded]` resume |

## Gap handling

**Recall prompts**

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| R3 / C1 | Airflow or equivalent orchestration | important | Nothing on what runs the nightly dbt job | Orchestration is usually one of the first things a data-engineering interview covers. | Who set the job's schedule, retries or dependencies, even if it's plain cron | The job's schedule or DAG config | `[grounded]` what the resume does not say; `[generic]` the interview pattern |
| R7 / C2 | SLAs, and production Python (R2) | important | Nothing on freshness, delivery times or alerting | An SLA is only real if someone knows what the business relies on and gets alerted when it slips. | Any alert, retry, or readiness time on the nightly job or the vendor pulls | Alert config, run logs, a freshness check | `[grounded]` what the resume does not say; `[generic]` what SLA ownership usually involves |
| R8 / C3 | Partner with analytics on requirements | important | Analyst-side work only | Requirements work is the link between the two halves of this role. | Requirements you took from stakeholders for a model you built; any ingest or backfill work | Tickets, specs, or a design doc from that work | `[grounded]` what the resume does not say |

**Named absences**

- **3+ years data engineering (R1).** The resume can't close this, and nothing in your history is data-engineering tenure. Closing it takes time in data-engineering work. The realistic options are to target analytics-engineering roles, where dbt and warehouse modelling are the centre of the job and your history is direct, or to apply to data engineering knowing the years are below the stated bar and leading with the star schema and dbt work. Whether to apply at that bar is a separate call.
- **Spark (R10).** Closing path: a small PySpark job that reprocesses one of your existing extracts, in a public repo. That shows you've run Spark. It doesn't make it years of experience.
- **Kafka and streaming (R9).** It's a plus, not a requirement, so the cost is smaller than the batch gaps. Closing path: a small consumer that reads a Kafka topic into a table, in a repo. It's worth it only if the roles you're targeting make streaming central.
- **Airflow itself.** If C1 shows the nightly job runs on Airflow, R3 closes. If it doesn't, a small Airflow DAG that runs your dbt build, in a personal project, closes it at the level of a demo.

## Prohibited claims

Not written, and why:

- **"Data Engineer" as a title, or "data engineering experience."** You have analytics titles only, and the must-have is about tenure you don't have.
- **"Built and owned batch pipelines," "owned the warehouse."** You co-designed the mart with your then-DE, and nothing in the source says you owned it.
- **"Owned data quality," "set SLAs."** You added tests and fixed breaks. No SLA ownership is in the source.
- **"Production Python," "production pipelines."** The source says "scripting" and "a cron." "Production" would move it.
- **"Pipelines" for the vendor pulls.** They're scripts; the word would promote them.
- **"Led the star schema."** You designed it with your then-DE. "Led" moves the credit.
- **"Partnered with analytics on requirements."** That's the posting's word, and the resume doesn't describe requirements work.
- **Airflow, Spark, Kafka, streaming.** "Never used Airflow or Spark" and "Never touched Kafka" stay out of the resume entirely.

## Parse-safety check

This ran on pasted text, so the layout check couldn't run. I couldn't see columns, headers or tables. When you send the resume as a file, use a .docx or a text-layer PDF, put your contact details in the body rather than the header, and keep standard section titles such as Experience and Skills.

## Upgrade menu

- **The resume as a file** (.docx or text-layer PDF) lets the parse-safety check see the layout.
- **A repo or link to the dbt project, the cron scripts or the nightly job's config** makes R2, R5 and R6 inspectable, so a reader can check them.
- **Alert configs, run logs or freshness checks from the nightly job** answer C2 with evidence.
- **Any Airflow, Spark or Kafka project, even a small one,** turns a named absence into something you can show.

## Questions

Answer any of these in text, paste a voice transcript, attach a document, drop a link, or say skip.

- **C1:** What schedules and runs the nightly dbt job: plain cron, Airflow, dbt Cloud, or something else?
- **C2:** Did the nightly job or the vendor pulls ever alert anyone, retry on failure, or have a time by which the data had to be ready?
- **C3:** Did you ever gather requirements from analytics or business stakeholders for a model you then built, or work on loading data (ingest or backfill) rather than only transforms?

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.