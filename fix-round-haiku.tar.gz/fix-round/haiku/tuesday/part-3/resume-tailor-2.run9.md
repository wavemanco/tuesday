This is a tailored draft, not an applied resume. Every row below is pending your approval, and I haven't changed the resume itself. The strongest matches are the warehouse modelling and dbt work. The 3+ years of data engineering must-have is not something a rewrite can cover, so I haven't tried. Whether to apply despite that is job-underwriter's question, and I haven't weighed it here.

You gave me the resume as pasted text, not a file, so I could not run the layout check on it.

## Edit ledger

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| L1 | Summary (new) | *(none)* | Senior Data Analyst with 5 years in retail. Built and maintained about 25 dbt models, including the core orders mart, and designed its star schema with our then-DE. | `merge` | "Senior Data Analyst, 5 years, retail."; "Built and maintained about 25 dbt models including the core orders mart."; "I designed the star schema for the orders mart with our then-DE." | `[grounded]` resume | pending your approval |
| L2 | Experience, first bullet | "Built and maintained about 25 dbt models including the core orders mart." | Built and maintained about 25 dbt models, including the core orders mart. | `reorder` | "Built and maintained about 25 dbt models including the core orders mart." | `[grounded]` resume | pending your approval |
| L3 | Experience | "I've fixed our nightly dbt job when it breaks and added tests to it." | Fixed our nightly dbt job when it breaks, and added tests to it. | `reframe` | "I've fixed our nightly dbt job when it breaks and added tests to it." | `[grounded]` resume | pending your approval |
| L4 | Experience, first bullet | "I designed the star schema for the orders mart with our then-DE." | Designed the star schema for the orders mart with our then-DE. | `reframe` | "I designed the star schema for the orders mart with our then-DE." | `[grounded]` resume | pending your approval |
| L5 | Experience | "SQL every day on Redshift, complex window functions and CTEs." | Daily SQL on Redshift, including complex window functions and CTEs. | `surface` | "SQL every day on Redshift, complex window functions and CTEs." | `[grounded]` resume | pending your approval |
| L6 | Experience | "I write Python for analysis: pandas, plus some scripting to pull vendor APIs on a cron." | Write Python for analysis (pandas), and scripting that pulls vendor APIs on a cron. | `surface` | "I write Python for analysis: pandas, plus some scripting to pull vendor APIs on a cron." | `[grounded]` resume | pending your approval |

L1 is the row most likely to drift. Its second clause joins two of your sentences, so check that "its" refers to the orders mart, as your original does.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| M1 | 3+ years data engineering | must-have | not_evidenced | Transferability: L2, L3 and L4 are your closest work, but they are analytics-side years. No DE title. See named absence N1. | `[grounded]` resume and your message |
| M2 | Production Python | must-have | surfaced_by_edit | L6 surfaces the scripting. Nothing you wrote establishes "production". | `[grounded]` resume |
| M3 | Airflow or equivalent orchestration | must-have | not_evidenced | Discovery: the resume names no scheduler for the nightly job. See C1. | `[grounded]` resume |
| M4 | Dimensional modelling | must-have | surfaced_by_edit | L1 and L4 move the star-schema work up from the last bullet. "Star schema" is your term, so I did not use the JD's phrase. | `[grounded]` resume |
| M5 | Model the warehouse | important | surfaced_by_edit | L4 and L5 name the star schema and Redshift. | `[grounded]` resume |
| M6 | Build and own batch pipelines | important | not_evidenced | Transferability: L2, L3 and L6 are batch-shaped, but the resume shows no end-to-end pipeline you built or owned. See C3. | `[grounded]` resume |
| M7 | Streaming (Kafka); Spark (listed with pipelines) | preferred | not_evidenced | Capability: you have never used Kafka or Spark. See N2. | `[grounded]` resume |
| M8 | Own data quality | important | surfaced_by_edit | L3 surfaces the tests you added to the nightly job. "Own" is not established. | `[grounded]` resume |
| M9 | Own SLAs | important | not_evidenced | Discovery: nothing names a freshness target or deadline. See C2. | `[grounded]` resume |
| M10 | Partner with analytics on requirements | important | not_evidenced | Transferability: you were on the analytics side, and the nearest line is L4 (working with the then-DE). Nothing shows you gathering requirements. See N3. | `[grounded]` resume |

## Gap handling

**Recall prompts**

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Airflow or equivalent orchestration | must-have | The nightly dbt job, with no scheduler named | This is the one must-have where the answer could already be yes. | Any scheduler config you touched when fixing the nightly job | Scheduler config or DAG, anonymised | `[grounded]` the resume names no scheduler |
| C2 | Own SLAs | important | Fixing breaks and adding tests; no deadline or freshness target | SLA ownership is in the JD's core duties. | Any "data must be ready by" expectation for the nightly job | A written freshness target or alert threshold | `[grounded]` the resume names no target |
| C3 | Build and own batch pipelines | important | Vendor API pulls on a cron, and dbt transformations | Batch ownership is a core duty; the cron scripts are the nearest ingestion. | The vendor pulls, if their output loaded into Redshift and others used it | The script, anonymised | `[grounded]` the resume shows scripts, not a pipeline |

**Named absences**

- **N1, 3+ years data engineering.** You do not have it, and no line can say you do. The posting makes it a must-have, not a legal gate, so it is a fit gap. Closing it takes time in data engineering work, not wording. The honest options are a role that already counts your transformation work, or a DE role where you say plainly what your five years covered.
- **N2, Kafka, Spark and streaming.** You have never used them. A realistic closing path is one small project: read from a public event stream and write the results to a Redshift table, over a few months of evenings. Streaming is listed as a plus, so closing it is not required for this posting.
- **N3, requirements gathering.** Nothing in your material shows you gathering requirements from analysts. If you have a written requirements doc from the orders mart work, that closes it.

## Not written, and why

- **"Data Engineer" or any DE title.** You have never held one, and the posting makes 3+ years of DE work a must-have.
- **"Built and owned batch and streaming pipelines."** Your material shows dbt transformations and cron scripts, not end-to-end pipelines you owned.
- **"Owned data quality and SLAs."** You added tests and fixed breaks. Ownership and SLAs are not in your material.
- **"Production Python."** Not established anywhere in your material.
- **Airflow, Spark or Kafka in any line.** You have never used them.
- **"Designed the star schema" without "with our then-DE."** The qualifier is the accurate part, and removing it would change who did the work.
- **"Dimensional modelling."** The JD's phrase. Your own term, "star schema", is what the ledger uses.
- **"Partnered with analytics on requirements."** Not in your material.

## Parse-safety check

Not run. The resume arrived as pasted text, so I cannot see the layout, headers, footers or any tables. Send the file as a `.docx` or a text-layer PDF and I will run the check.

## Upgrade menu

- **The resume as a file:** runs the parse-safety check on the real layout.
- **An anonymised dbt model and one test you added:** makes L2, L3 and M8 inspectable rather than self-reported.
- **An anonymised vendor-API script:** makes L6 and M2 concrete.
- **The nightly job's schedule or config, anonymised:** settles M3 whichever way C1 comes out.
- **A written requirements doc for the orders mart, if one exists:** closes N3.

## Questions

1. **C1:** What runs the nightly dbt job: Airflow, cron, a dbt Cloud schedule, a warehouse scheduler, or something else?
2. **C2:** Did the nightly data have to be ready by a particular time, or a freshness target? Were you ever told it was late?
3. **C3:** Where did the vendor-API pulls land, and did anyone depend on what they returned?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.