Here is the tailoring as a ledger. Nothing is applied yet. Every row waits for your approval, and I'll produce the tailored CV only from the rows you approve. Your CV already covers the p99 work, on-call and incident command, and ownership well. Three things the posting asks for are not supported by what you've given me, so I've listed them as gaps instead of writing around them.

Research tier: L0, no searches; user links read 0.

## Edit ledger

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Summary (new) | *(no current line)* | "Senior Software Engineer, 7 years. Currently at a payments company, owning three services in our ledger pipeline; one handles about 40k requests/minute at peak." | `merge` | "Senior Software Engineer, 7 years."; "Currently at a payments company."; "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak." | `[grounded]` CV | pending your approval |
| E2 | Skills | "CV also lists: Kafka, Postgres, Terraform, gRPC, Datadog." | "Go, Rust, Python, Kafka, Postgres, Terraform, gRPC, Datadog" | `surface` | "Go and Rust daily for 4 years, Python before that."; "CV also lists: Kafka, Postgres, Terraform, gRPC, Datadog." | `[grounded]` CV | pending your approval |
| E3a | Experience | "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | "On-call rotation every fourth week for two years." | `split` | "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | `[grounded]` CV | pending your approval |
| E3b | Experience | "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | "Ran six incidents as incident commander." | `split` | "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | `[grounded]` CV | pending your approval |
| E4 | Experience | "Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer." | *(unchanged — moved to the first experience bullet)* | `reorder` | "Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer." | `[grounded]` CV | pending your approval |
| E5 | Experience | "I do onboarding for new hires on my team — usually two or three a year, I pair with them for their first month." | "Onboard new hires on my team, usually two or three a year, pairing with each for their first month." | `reframe` | "I do onboarding for new hires on my team — usually two or three a year, I pair with them for their first month." | `[grounded]` CV | pending your approval |

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| 1 | 5+ years backend | must-have | surfaced_by_edit | E1. Seven years is your total engineering time. The word "backend" is not in your material; I've read it from "services" and request load. Confirm if your early years were not server-side. | `[grounded]` CV |
| 2 | Production Go | must-have | surfaced_by_edit | E2 puts Go in the skills line; E1 places it in the services work | `[grounded]` CV |
| 3 | Distributed systems at scale | must-have | not_evidenced | No row. You describe services and a 40k requests/minute peak, not distributed design. Recall prompt C1. | `[grounded]` CV |
| 4 | Strong incident response | must-have | surfaced_by_edit | E3a and E3b split the buried sentence into two lines | `[grounded]` CV |
| 5 | Experience mentoring | must-have | surfaced_by_edit | E5 surfaces onboarding and pairing. It does not show mid-level mentoring; see row 6. | `[grounded]` CV |
| 6 | Mentor mid-level engineers | important | not_evidenced | No row. Recall prompt C2. | `[grounded]` CV |
| 7 | Own services; design and ship Go services at high request volume | important | surfaced_by_edit | E1 states ownership; E4 shows a shipped cache rework. Designing a new service is not stated and is not claimed. | `[grounded]` CV |
| 8 | Drive down p99 latency | important | already_evidenced | Stated in full in the CV; E4 moves it up | `[grounded]` CV |
| 9 | Own on-call for your services | important | surfaced_by_edit | E3a | `[grounded]` CV |
| 10 | Partner with product on roadmap sequencing | important | not_evidenced | No row. Recall prompt C3. | `[grounded]` CV |

## Gap handling

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Distributed systems at scale | must-have | Services and a 40k requests/minute peak. Does not say the systems were distributed, or what you decided about failure or consistency. | A must-have in this posting, and the first thing a reader will look for. | A partition or consumer scheme you tuned on Kafka; a cross-service failure you designed around; a consistency choice in the ledger path. | A design doc for the pipeline; a throughput dashboard; a postmortem from one of the six incidents. | `[grounded]` what the CV does and does not say; `[generic]` what a must-have gap costs on applications of this kind |
| C2 | Mentor mid-level engineers | important | Onboarding and a month of pairing with two or three new hires a year. No mention of mid-level engineers or of growth beyond onboarding. | The posting names mentoring as part of the role; the onboarding line will read as narrower than that. | Coaching a mid-level engineer on a project, a promotion case or a hard design. | Feedback you wrote for someone you coached; a growth plan; a manager's note. | `[grounded]` what the CV does and does not say; `[generic]` what a narrower match costs on applications of this kind |
| C3 | Partner with product on roadmap sequencing | important | Nothing about product or planning. | The posting names it as a responsibility, and a reader will look for it. | A roadmap decision you shaped with a product manager: what was sequenced first, what was cut or deferred, and why. | A roadmap doc, a planning thread, or a decision record. | `[grounded]` what the CV does and does not say; `[generic]` what a missing responsibility costs on applications of this kind |

## Prohibited claims

Not written, and why:

- **"Senior Backend Engineer" as your title.** You hold "Senior Software Engineer." The posting's title is its own.
- **"Mentored mid-level engineers" or "mentoring."** You described onboarding and pairing with new hires. Nothing says mid-level or growth-focused. This is gap C2.
- **"Designed distributed systems at scale."** You described a peak load and services. Nothing says they were distributed or that you designed them. This is gap C1.
- **"Partnered with product on roadmap sequencing."** Not in your material. "Partner" is also the posting's word, not yours. This is gap C3.
- **"Designed and shipped new Go services."** You said you own three services and reworked a cache layer. Designing and launching a new service is not stated.
- **"Expert in Kafka, gRPC, Terraform."** These are listed, not described. A tool listed is not a tool owned, and depth is not stated.
- **"Cut p99 across the service."** The change was on the balance-read path. Widening that is a scope inflation.
- **"Reduced latency by 75%."** The percentage is arithmetic on your numbers, not a figure you stated. The 380ms and 95ms stand as you wrote them.

## Parse-safety check

This is pasted text, not a file. Layout, tables, headers and footers, images, section headings and file type could not be checked. Send the CV as a .docx or a text-layer PDF and I'll run them.

## Upgrade menu

- **The CV as a file (.docx or text-layer PDF):** runs the parse-safety checks that pasted text cannot.
- **A before-and-after Datadog view of the balance-read p99:** turns the 380ms → 95ms line from your word into an inspectable artifact.
- **One of the six incident reviews you wrote:** supports the incident-response lines and may answer C1 at the same time.
- **An earlier resume version:** may hold experience the current one dropped.

## Questions

C1 — Were the ledger pipeline's services distributed across machines or partitions? If so, what did you decide about failure or consistency in them?

C2 — Have you coached a mid-level engineer past their first month, on growth, a project or a promotion case? One example, please.

C3 — Have you shaped a roadmap decision with product, such as what was sequenced first or what was cut? One example, please.

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.