The resume can carry the dbt, star-schema, Python and testing work toward this role. It cannot carry the must-have: nothing in it shows three years of data engineering, and I haven't written around that. Nothing below is applied until you approve it.

I've assumed the paste's dbt, Python and schema lines sit under Experience, since it has no section headers. The summary line in E1 is new.

Reply with the rows you approve, for example `Approved: E1, E2, E4`, and I'll build the resume from those rows only.

## Edit ledger

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Summary (new) | *(none)* | "Senior Data Analyst, 5 years in retail. SQL every day on Redshift, with complex window functions and CTEs. Built and maintained about 25 dbt models, including the core orders mart." | `merge` | "Senior Data Analyst, 5 years, retail."; "SQL every day on Redshift, complex window functions and CTEs."; "Built and maintained about 25 dbt models including the core orders mart." | `[grounded]` resume | pending your approval |
| E2 | Experience | "Built and maintained about 25 dbt models including the core orders mart." | *(unchanged, moved to the top of Experience)* | `reorder` | "Built and maintained about 25 dbt models including the core orders mart." | `[grounded]` resume | pending your approval |
| E3 | Experience | "I've fixed our nightly dbt job when it breaks and added tests to it." | "Fixed our nightly dbt job when it broke." | `split` | "I've fixed our nightly dbt job when it breaks and added tests to it." | `[grounded]` resume | pending your approval |
| E4 | Experience | *(same line as E3)* | "Added tests to our nightly dbt job." | `split` | "I've fixed our nightly dbt job when it breaks and added tests to it." | `[grounded]` resume | pending your approval |
| E5 | Experience | "I designed the star schema for the orders mart with our then-DE." | "Designed the star schema for the orders mart, with our then-data engineer." | `reframe` | "I designed the star schema for the orders mart with our then-DE." | `[grounded]` resume | pending your approval |
| E6 | Experience | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | "Write Python for analysis in pandas." | `split` | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | `[grounded]` resume | pending your approval |
| E7 | Experience | *(same line as E6)* | "Write some scripts that pull vendor APIs on a cron." | `split` | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | `[grounded]` resume | pending your approval |

E5 keeps "with our then-data engineer", so the shared credit stays. E3 and E4 keep "our", and E7 keeps "some".

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| K1 | 3+ years data engineering | must-have | not_evidenced | Nothing titled or dated as data engineering. The nearest work is E2, E3 and E5, which is dbt and schema work inside an analyst role. The 5 years are analyst years. | `[grounded]` resume |
| K2 | Build and own batch pipelines | important | surfaced_by_edit | E2, E3 and E6–E7 surface the dbt models, the nightly dbt job and the cron scripts. "Own" is not claimed. | `[grounded]` resume |
| K3 | Streaming pipelines (Kafka, Spark) | preferred | not_evidenced | None. The resume says you never touched Kafka and never used Spark. | `[grounded]` resume |
| K4 | Airflow or equivalent orchestration | important | not_evidenced | The nightly dbt job's scheduler is not named. The cron scripts are scheduling, not orchestration. Recall prompt C1. | `[grounded]` resume |
| K5 | Production Python | important | surfaced_by_edit | E6–E7 surface pandas and the cron API scripts. "Production" is not claimed. Whether unattended scripts count is C3. | `[grounded]` resume |
| K6 | Dimensional modelling; model the warehouse | important | surfaced_by_edit | E5 surfaces the orders-mart star schema, kept as shared with the then-DE. | `[grounded]` resume |
| K7 | Own data quality | important | surfaced_by_edit | E3–E4 surface the added dbt tests and the fixes. "Own" is not claimed. | `[grounded]` resume |
| K8 | Own SLAs | important | not_evidenced | No deadline, freshness target or on-call duty appears. Recall prompt C2. | `[grounded]` resume |
| K9 | Partner with analytics on requirements | important | already_evidenced | The analyst title and daily SQL show the analytics side. Gathering requirements is not stated and is not claimed. | `[grounded]` resume |

**Recovery per gap**

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Airflow or equivalent orchestration | important | The nightly dbt job runs. The resume doesn't say what schedules it or what you did to it. | The JD lists orchestration as a requirement, and a screener looking for it finds nothing. | Changed the schedule, retries, dependencies or alerts on the nightly job; set up or moved a scheduled pipeline. | The job's schedule config, or a screenshot of its run history. | `[grounded]` the resume; `[generic]` how screeners treat named tools |
| C2 | Own SLAs | important | Fixing a broken job. No delivery commitment. | The JD makes SLAs part of the role's ownership, and fixing is not committing to a time. | A freshness deadline the business relied on for the orders mart; being the one paged when the nightly job missed it. | A runbook, an alert, or a stakeholder message about a missed load. | `[grounded]` the resume |
| C3 | Production Python | important | Cron-scheduled scripts that pull vendor APIs. | Whether those ran unattended with someone relying on them decides whether "production" is honest here. | A cron script whose output someone downstream used; a failure you fixed. | The script, redacted if needed, and its cron entry. | `[grounded]` the resume |

**Named absences**

- **K1, 3+ years of data engineering.** You have not held a data engineering title, and the JD makes three years a must-have. Closing it takes sustained pipeline work as your main job, not added to an analyst role. Until then the resume can show the dbt and schema work, but it cannot claim the years. Whether to apply anyway is a job-underwriter question.
- **K3, streaming.** You have never built or run a streaming pipeline, and the JD treats it as a plus. Closing it takes a scoped project you can show, such as one Kafka topic or one Spark job loading a table. Until then it stays a named gap.

## Not written, and why

- "Data engineer" or "analytics engineer" as a title. You have held neither, and retitling would be an upgrade.
- "3+ years data engineering" or "5 years of data engineering." The 5 years are analyst years.
- "Built and owned batch and streaming pipelines." "Own" is not stated, and you have never touched streaming.
- "Production" for Python or pipelines. The word is not in your material.
- Airflow, Spark or Kafka in any form. You have never used them.
- "Owned data quality" or "owned SLAs." Adding tests and fixing the job are what is stated. Ownership is not.
- "Designed the star schema" without "with our then-DE." Dropping that phrase drops the shared credit.

## Parse-safety check

Your resume came as pasted text, not a file. I could not check column layout, tables, or headers and footers, so contact details placed there could be lost in parsing. Nothing in the paste suggests hidden text.

## Upgrade menu

- **The resume as a file** (.docx or a text-layer PDF): lets me run the layout and header check.
- **The dbt repo, or one redacted model and its test file:** would let E2–E4 be checked by inspection rather than self-report.
- **One redacted cron script and its cron entry:** would test whether K5's "production" line holds.
- **A link to a streaming or Spark side project:** would move K3 from not_evidenced to surfaced_by_edit. Without one, nothing about K3 changes.

## Questions

**C1.** Which system ran the nightly dbt job, and did you change its schedule, retries, dependencies or alerts? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**C2.** On the orders mart, did anyone depend on a delivery time, and were you the one responsible when it slipped? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**C3.** Did the vendor-API cron scripts run unattended with someone downstream relying on the output, and did you fix one when it failed? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.