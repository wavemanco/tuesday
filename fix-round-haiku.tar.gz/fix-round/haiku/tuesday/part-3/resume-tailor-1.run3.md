Your CV came through as typed text, not a file, so the "current line" for each row is your own sentence as you wrote it. If your real bullets differ, send them and I'll rerun the rows. Nothing is applied yet: every row waits for your approval.

Research tier: L0, no searches; user links read 0.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| C1 | Own services in the build-cache platform | important | not_evidenced | Recall R1. Nearest is E3, a request-serving cache, not build caching. | `[grounded]` nothing in your material covers build caching or developer tools |
| C2 | Design and ship Go services at high request volume | important | surfaced_by_edit | E2, E4. Your sentences say you use Go daily and that you own services in the ledger pipeline, but not that those services are Go. Confirmation is in the upgrade menu. | `[grounded]` the quoted sentences; `[inferred]` about 670 requests/second, from 40k/minute ÷ 60 |
| C3 | Drive down p99 latency | important | already_evidenced | Already on the page; E3 moves it to the top | `[grounded]` |
| C4 | Own on-call for your services | important | already_evidenced | Already on the page; E5 splits it for clarity | `[grounded]` |
| C5 | Mentor mid-level engineers | important | not_evidenced | Recall R2. Nearest is E6, onboarding, which is a narrower kind of work. | `[grounded]` the onboarding sentence |
| C6 | Experience mentoring | must-have | not_evidenced | Same gap as C5; closed by the same answer to R2 | `[grounded]` |
| C7 | Partner with product on roadmap sequencing | important | not_evidenced | Recall R3. Nothing in your material. | `[grounded]` |
| C8 | 5+ years backend | must-have | already_evidenced | E1. "Backend" appears nowhere; a reader infers it from the ledger services. | `[grounded]` 7 years; `[inferred]` backend, from the ledger-service work |
| C9 | Production Go | must-have | surfaced_by_edit | E1, E2 | `[grounded]` Go daily for 4 years; `[inferred]` "production", implied by 40k peak traffic |
| C10 | Distributed systems at scale | must-have | surfaced_by_edit | E4 surfaces the 40k figure. Kafka is listed but no sentence says where you use it, so it stays out of the bullets. | `[grounded]` the 40k sentence and the skills list; `[inferred]` about 670 requests/second |
| C11 | Strong incident response | must-have | already_evidenced | E5 | `[grounded]` six incidents as incident commander |

## Edit ledger

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Summary (new) | *(none)* | Senior Software Engineer, 7 years; Go and Rust daily for 4 years, Python before that; owns three services in our ledger pipeline at a payments company. | merge | "Senior Software Engineer, 7 years."; "Go and Rust daily for 4 years, Python before that."; "Currently at a payments company."; "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak." | `[grounded]` summary you typed | pending your approval |
| E2 | Skills | "Go and Rust daily for 4 years, Python before that." | *(unchanged, moved to the top of Skills)* | reorder | "Go and Rust daily for 4 years, Python before that." | `[grounded]` summary you typed | pending your approval |
| E3 | Experience | "Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer." | *(unchanged, moved to the top bullet of Experience)* | reorder | "Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer." | `[grounded]` summary you typed | pending your approval |
| E4 | Experience | "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak." | (a) "Own three services in our ledger pipeline." (b) "One of them handles about 40k requests/minute at peak." | split | "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak." | `[grounded]` summary you typed | pending your approval |
| E5 | Experience | "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | (a) "On-call rotation every fourth week for two years." (b) "Incident commander for six incidents." | split | "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | `[grounded]` summary you typed | pending your approval |
| E6 | Experience | "I do onboarding for new hires on my team — usually two or three a year, I pair with them for their first month." | "Onboard new hires to my team, usually two or three a year, pairing with each for their first month." Kept as onboarding, not mentoring. | reframe | "I do onboarding for new hires on my team — usually two or three a year, I pair with them for their first month." | `[grounded]` summary you typed | pending your approval |

## Recovery for the gaps

| # | Requirement | Priority | What your resume shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| R1 | Build-cache platform (C1) | important | Cache-layer rework on balance reads (E3). No build, artifact or CI caching. | This is the job's domain, and the first thing a hiring manager checks. | Dependency, artifact or CI caching; cache-hit or eviction work you owned; a build-time or hit-rate target you set | A design doc, a Datadog cache dashboard, a postmortem | `[grounded]` what the summary does and doesn't say; `[generic]` what a domain gap costs on applications of this kind |
| R2 | Mentoring mid-level engineers (C5, C6) | must-have / important | Onboarding 2–3 hires a year, pairing for their first month (E6) | The JD asks for mentoring as a responsibility and as experience. Onboarding is a narrower kind of work. | A mid-level engineer you developed over months: a growth plan, a promotion case, regular 1:1s, design-review coaching | A promotion case you wrote, or a note from the person | `[grounded]` the onboarding sentence; `[generic]` how interviewers probe mentoring claims |
| R3 | Roadmap sequencing with product (C7) | important | Nothing | The role owns sequencing with product. | A roadmap or priority call you made with a PM; a migration or deprecation you sequenced; a tradeoff you put to product | A roadmap doc, a planning thread | `[grounded]` nothing in the summary; `[generic]` what this costs on applications of this kind |

## Not written, and why

- **"Mentored mid-level engineers."** Your onboarding work is real, but it is not mentoring of mid-level engineers. E6 keeps the word "onboarding" for that reason.
- **"Build-cache experience" or "owned build-cache services."** None of your material covers this.
- **"Partnered with product on roadmap sequencing."** No evidence.
- **"Distributed systems at scale" or "high-throughput."** The only scale figure is 40k requests/minute, about 670 per second. Stating the figure is fine; the label is a judgement you'd have to defend.
- **"Backend" as a title or summary word.** Not in your sentences.
- **Kafka in any bullet.** It's listed, and no sentence says where you use it.
- **"Go services."** Your sentences don't say the ledger services are Go.

No rows were rejected, and no premise about screening came up.

## Parse-safety check

This came as typed text, not a file, so I couldn't check columns, headers, footers or the file type. Nothing in the typed summary would break a parser.

## Upgrade menu

- **The CV file (.docx or text-layer PDF).** Lets me check each current line exactly and run the parse-safety check on the real layout.
- **One line on whether the three ledger services are Go.** Unlocks an explicit "Go services" bullet for C2.
- **One sentence on where Kafka is used, if it is.** Moves Kafka from the list into a bullet.
- **Sustained or per-replica throughput.** Unlocks a scale sentence for C10 stated on your terms.

## Questions

**R1:** Have you worked on build, artifact, dependency or CI caching at any point? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**R2:** Have you formally mentored a mid-level engineer, through a growth plan, a promotion case or regular 1:1s over months? Name one and what you did.

**R3:** Can you name a roadmap or sequencing call you made with a product manager: what you proposed, what was decided, and what happened?

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.