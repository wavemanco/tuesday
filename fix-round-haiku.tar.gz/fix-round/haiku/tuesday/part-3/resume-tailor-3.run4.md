I tailored the CV as an approve-first ledger. Nothing is applied yet. Every row is pending your approval, and I haven't produced a tailored document.

Two inputs were missing. There was no CV file in the working directory, so "current line" means the sentences you wrote in your message. There was no `tuesday-dossier.md` either, so I worked from the excerpt you pasted. Rows I couldn't see aren't reflected here.

The main limit is that tailoring can't close the must-haves. You have no PM title and no PM years, and roadmap ownership isn't evidenced. The ledger can make your integration, API and client-discovery work easier to read. It can't make you look like a product owner. Your dossier's `conditional_go` depends on whether the questions below turn up real decision-making.

## Edit ledger

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience | *(sits inside a role bullet; no separate line)* | Wrote the internal integration playbook the whole team uses. | `surface` | "Wrote the internal integration playbook the whole team uses." | `[grounded]` cv | pending your approval |
| E2 | Experience | Led 30+ client integrations of our REST APIs end to end. | *(unchanged, moved to top of Experience)* | `reorder` | "Led 30+ client integrations of our REST APIs end to end." | `[grounded]` cv | pending your approval |
| E3 | Experience | Ran quarterly roadmap-input sessions collecting client feedback for product. | *(unchanged, moved directly under E2)* | `reorder` | "Ran quarterly roadmap-input sessions collecting client feedback for product." | `[grounded]` cv | pending your approval |
| E4 | Skills | Comfortable in Postman, SQL, OpenAPI specs. | *(unchanged, moved to top of skills block)* | `reorder` | "Comfortable in Postman, SQL, OpenAPI specs." | `[grounded]` cv self-report | pending your approval |
| E5 | Summary | *(no current line)* | Solutions engineer / implementation lead, 7 years at an enterprise software vendor. Led 30+ client integrations of our REST APIs end to end and wrote the internal integration playbook the whole team uses. Ran quarterly roadmap-input sessions collecting client feedback for product. | `merge` | "7 years solutions engineer / implementation lead at an enterprise software vendor."; "Led 30+ client integrations of our REST APIs end to end."; "Wrote the internal integration playbook the whole team uses."; "Ran quarterly roadmap-input sessions collecting client feedback for product." | `[grounded]` cv | pending your approval |

E1 is the pending edit from your dossier. I audited it again rather than trusting it: the scope stays "internal", the verb stays "wrote", and nothing is added. Your title stays as it is. I did not retitle it toward PM.

E5 is optional. It is built only from your four sentences, and I've kept them as separate clauses so that "led" doesn't drift into "owned" or "managed".

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| 1 | 3+ years PM | must-have | not_evidenced | No PM years in the CV. Adjacent work is E2 and E3. Dossier R1: adjacent, transferability, medium. | `[grounded]` cv: "Never held a PM title." |
| 2 | Shipped API or platform products | must-have | not_evidenced | E2 shows integration delivery on your REST APIs, not ownership of a shipped product. Dossier R2: adjacent, medium. | `[grounded]` cv |
| 3 | Technical fluency | important | already_evidenced | E4 and E2. Tools are self-reported. | `[grounded]` cv self-report |
| 4 | Stakeholder management | important | already_evidenced | Client integrations (E2) and client-facing roadmap sessions (E3). The phrase itself is not in the CV, and it should not be added. | `[grounded]` cv |
| 5 | Own the roadmap for the partner API platform | important | not_evidenced | E3 is input gathered for product, not roadmap decisions. Dossier R1: prioritisation authority not evidenced. | `[grounded]` cv |
| 6 | Discovery with integration partners | important | surfaced_by_edit | E3 is the closest evidence. It is surfaced in its own words, not renamed "discovery". | `[grounded]` cv; `[inferred]` that these sessions are discovery-type work |
| 7 | Write specs and drive delivery with two engineering squads | important | not_evidenced | E4 is tool familiarity, not specs written for build teams. Your integrations were delivered client-side. | `[grounded]` cv |
| 8 | Define adoption metrics | important | not_evidenced | No adoption measure in the CV. "30+" counts integrations led, not adoption. | `[grounded]` cv |

## Recovery per gap

| # | Requirement | Priority | What your resume currently shows | What closes it | Provenance |
|---|---|---|---|---|---|
| R1 | 3+ years PM | must-have | Seven years of solutions and implementation work, no PM title. | Named absence. Closing it takes a role where you were accountable for product decisions for roughly three years. A tailored CV can't stand in for that. | `[grounded]` cv; `[generic]` that PM-years requirements are usually screened literally |
| R2 | Shipped API or platform products | must-have | Integration delivery on your REST APIs. | Named absence unless Q1 turns up a feature you were accountable for shipping. | `[grounded]` cv |
| R5 | Own the roadmap | important | Input gathering (E3). | Q1 below. | `[grounded]` cv |
| R7 | Specs and delivery with engineering squads | important | OpenAPI fluency (E4). | Q2 below. | `[grounded]` cv |
| R8 | Adoption metrics | important | Count of integrations led (E2). | Q3 below. | `[grounded]` cv |

## Prohibited claims

Not written, and why:

- **"Product Manager" or any PM title.** You have never held one.
- **Any figure for PM years.** The CV has none. Your seven years are solutions and implementation work.
- **"Owned the API roadmap", "set priorities", "prioritised the backlog".** Roadmap ownership and prioritisation authority are not evidenced (dossier R1). E3 is input you gathered, not decisions you made.
- **"Shipped API products" as owner.** The CV says integrations on your REST APIs, delivered to clients (dossier R2: adjacent).
- **"Built an internal request-triage tool".** Rejected in your dossier: ownership unconfirmed.
- **"Customer of a partner API platform", or any buyer-side claim.** Rejected in your dossier: you worked vendor-side.
- **"Partner" in place of "client".** The posting's word is "partner" and yours is "client". Swapping it would change which side of the table you were on.
- **"Ran discovery with integration partners".** The CV says "collecting client feedback". Discovery is a different kind of work.
- **"Wrote specs for two engineering squads", "drove delivery with engineering teams".** You are comfortable in OpenAPI specs, which is tool familiarity, not specs built from for build teams.
- **"Defined adoption metrics".** Nothing in the CV, and "30+" counts integrations, not adoption.
- **"Stakeholder management" as a phrase.** That is the posting's vocabulary. The evidence is your client work, and a reader can infer the rest from it.

## Parse-safety check

No file was received, only pasted text, so the layout checks (columns, tables, text boxes, headers) could not run. I found no hidden text in what you pasted. When the CV file arrives, the check runs on it. A `.docx` or a text-layer PDF is the safe pair.

## Upgrade menu

- **The full `tuesday-dossier.md`.** It isn't in the working directory, so I used only the excerpt. Sending the file would confirm the rows I couldn't see.
- **The CV as a file.** This would let the parse-safety check run on the real layout.
- **The integration playbook, or its table of contents.** This would turn E1 from self-report into an inspectable artifact.
- **One output from a roadmap-input session**, such as the request list and what changed in the product as a result. This is evidence for R5 and R6.
- **One OpenAPI spec or requirements doc you wrote.** This is evidence for R7.
- **Your application form's knockout questions, if any.** If it asks a yes/no on PM years, that gate sits outside the CV and should be checked before more tailoring effort.

## Questions

Q1 — Did you ever decide what the API product built next, not just pass client input along? If so, what got scoped, and who signed it off?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

Q2 — Have you written a spec that engineers built from? Name one, and what shipped from it.
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

Q3 — After an integration went live, did you track anything showing it was used, such as time to first call, go-live rate or drop-off? Name the measure, even if informal.
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.