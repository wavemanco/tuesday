**Short version:** keywords probably aren't the main problem. The bigger issue is that this posting asks for about 16 things your resume doesn't show. Keyword placement can make the things you do have easier to find, but it can't close those gaps, and I won't write them in.

**Three things to check before editing the resume**

- **Auto-rejection by content is real but uncommon.** One vendor's interviews with 25 recruiters found 2 using it. The vendor sells resume builders, so treat that as weak evidence.
- **Knockout questions are the more likely cause.** These are yes/no questions in the application form, such as work authorization, required licence or location. They often reject without a person reviewing anything, and no resume edit changes them. Check the form.
- **Match scores affect ordering more than rejection.** A low score usually pushes a resume down the pile rather than rejecting it. In high-volume roles, that can mean it's never read.

Whether a role with this gap profile is worth applying to is job-underwriter's call, and I haven't made it here.

## Edit ledger

I only have your description, not the resume file, so the trace quotes below are verbatim from your message. If you paste the resume text, I can quote exact lines. Every row is pending your approval; nothing is applied.

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Skills | (Kubernetes is not in the skills list) | Kubernetes (proof-of-concept, two months, never in production) | surface | "Ran a Kubernetes proof-of-concept for two months last year — never went to production." | `[grounded]` cv | pending your approval |
| E2 | Experience | Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs. | Unchanged; moved to the top of the DevOps Engineer role | reorder | "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs." | `[grounded]` cv | pending your approval |
| E3 | Summary (new) | (no current line) | DevOps Engineer, 4 years. Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs. | merge | "DevOps Engineer, 4 years."; "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs." | `[grounded]` cv | pending your approval |

E1 keeps the qualifier. Dropping "proof-of-concept" or "never in production" would turn a prototype into experience you don't have.

## Coverage map

I treated the named tools as must-have, since the posting doesn't rank them. "Owns platform reliability and developer experience" is marked important.

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | Kubernetes | must-have | surfaced_by_edit | E1, as a proof-of-concept only | `[grounded]` cv |
| R2 | AWS EKS | must-have | not_evidenced | Nothing named. Whether the PoC ran on EKS is unknown; see C1 | `[grounded]` cv does not say |
| R3 | Terraform | must-have | not_evidenced | Transferability: Ansible for config management is adjacent, not Terraform. See C2 | `[grounded]` cv does not say |
| R4 | GitOps | must-have | not_evidenced | Capability gap. No deploy-from-git tooling named. See C1 | `[grounded]` cv does not say |
| R5 | ArgoCD | must-have | not_evidenced | Capability gap. See C1 | `[grounded]` cv does not say |
| R6 | Helm | must-have | not_evidenced | Capability gap. See C1 | `[grounded]` cv does not say |
| R7 | Istio | must-have | not_evidenced | Named absence N1 | `[grounded]` cv does not say |
| R8 | Service mesh | must-have | not_evidenced | Named absence N1 | `[grounded]` cv does not say |
| R9 | Prometheus | must-have | not_evidenced | Capability gap. See C3 | `[grounded]` cv does not say |
| R10 | Grafana | must-have | not_evidenced | Capability gap. See C3 | `[grounded]` cv does not say |
| R11 | Observability | must-have | not_evidenced | Transferability: CloudWatch monitoring is adjacent. No metrics, tracing or dashboards named | `[grounded]` cv |
| R12 | Vault | must-have | not_evidenced | Capability gap. IAM is access control, not secrets management. See C3 | `[grounded]` cv does not say |
| R13 | SRE practices | important | not_evidenced | No reliability practice named. Maintaining Jenkins jobs is adjacent | `[grounded]` cv does not say |
| R14 | Platform reliability ownership | important | not_evidenced | No ownership of uptime, incidents or on-call named | `[grounded]` cv does not say |
| R15 | Developer experience | important | not_evidenced | Transferability: the deploy pipeline is adjacent. The resume doesn't say who used it | `[grounded]` cv does not say |
| R16 | CI/CD | must-have | already_evidenced | Jenkins deploy pipeline, about 30 jobs (E2, E3) | `[grounded]` cv |
| R17 | GitLab CI/CD | must-have | not_evidenced | Transferability: Jenkins is adjacent. No GitLab named. See N3 | `[grounded]` cv does not say |
| R18 | Python | must-have | already_evidenced | "Bash and Python scripting" | `[grounded]` cv |
| R19 | Go | must-have | not_evidenced | Nothing named. See N2 | `[grounded]` cv does not say |

## Recovery per gap

**Recall prompts** (the questions are in the closing block)

| # | Requirement | Priority | What your resume currently shows | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|
| C1 | EKS, Helm, GitOps, ArgoCD | must-have | A two-month Kubernetes PoC, never in production. The platform, packaging and deploy method aren't stated | The PoC itself, and any Helm chart or Git-driven deploy from it | PoC repo, manifests or Helm charts, a short README | `[grounded]` cv does not say |
| C2 | Terraform | must-have | Ansible for config management. No infrastructure-as-code tool named | Any Terraform, including a sandbox module or a stack you created and tore down | A repo containing .tf files | `[grounded]` cv does not say |
| C3 | Prometheus, Grafana, Vault | must-have | CloudWatch monitoring. IAM for access control | Any metrics stack, alert dashboards, or secrets storage beyond IAM | Dashboard screenshots, a Vault config or policy file | `[grounded]` cv does not say |

**Named absences** (no recall prompt)

- **N1, Istio and service mesh:** Nothing in your material supports this. Closing it would take a small finished project, such as a sample app behind Istio on a local cluster, documented in a repo. A project you build can be evidence. Saying you've used it without that is not.
- **N2, Go:** Nothing in your material supports this. Closing it would take a small finished Go tool or service in a public repo.
- **N3, GitLab CI:** Jenkins is adjacent. Closing it would take moving one small project's pipeline to GitLab CI.
- **N4, SRE practices, reliability ownership, developer experience:** Nothing in the resume says these. Only real work closes them. If you've run on-call, led incident response or set SLOs, that's worth recalling. If you haven't, leave it off the resume rather than hedging.

## Prohibited claims

Not written, and why:

- **"Platform Engineer" as a title.** You haven't held it. Retitling to it is an upgrade, not an equivalent.
- **"Kubernetes" without the PoC qualifier, or "Kubernetes in production".** The PoC never reached production.
- **"Kubernetes on EKS" or "Helm" or "ArgoCD" or "GitOps".** Nothing in your material names them. C1 could change that.
- **"Terraform", "Prometheus", "Grafana", "Vault", "Istio", "service mesh", "GitLab", "Go".** None appear in your material.
- **"Observability stack" or "SRE".** CloudWatch monitoring is not an observability stack, and no reliability work is named.
- **"Secrets management".** IAM is access control.
- **"Across the engineering organisation" for the 30 Jenkins jobs.** You said you maintain about 30, not whose jobs they are.

## Parse-safety check

I ran this against your description, not the file, so the layout itself is unchecked.

- **Two-column layout.** Parsers read across rows, so columns can interleave, and dates can detach from the roles they belong to.
- **Icons for each skill.** Icons are usually garbled or skipped. The skills they label may vanish from the text, and skills are where keyword matching happens.
- **Contact details in the header.** Header text is often discarded as page furniture. Your name and contact details could be lost, and a recruiter couldn't reach you.
- **Canva PDF.** I can't tell whether it has a text layer. To test: select all in a PDF viewer, paste into a plain text editor, and read the output. Interleaved columns, missing icon text or a missing header are what a parser sees.

This check reports the risks. It doesn't redesign the document.

## Upgrade menu

- **The resume as pasted text.** Lets me quote exact lines and run the parse check against what you actually submitted.
- **Kubernetes PoC repo or notes.** Could confirm or change R2, R4, R5 and R6 (C1).
- **A Terraform repo.** Would be the inspectable proof for R3 (C2).
- **Dashboards or alert configs from any project.** Would be the inspectable proof for R9 to R11 (C3).
- **A sanitised Jenkinsfile.** Could make E2 more specific, without adding new claims.

## Questions

**C1:** Where did the Kubernetes PoC run, on AWS EKS or self-managed, and did it use Helm charts or a Git-driven deploy tool such as ArgoCD? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**C2:** Have you written Terraform at any point, even for a sandbox or a personal project? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**C3:** Have you used Prometheus, Grafana or Vault, even briefly? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.