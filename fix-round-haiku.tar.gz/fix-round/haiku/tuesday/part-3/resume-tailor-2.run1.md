I worked from your message, not a resume file, so the quotes below are your sentences as you wrote them. Whether to apply at all is job-underwriter's call; this covers the document only. Nothing is applied yet. Every row waits for your approval.

## Edit ledger

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Summary (new) | *(no current line)* | Senior Data Analyst, 5 years, retail. Built and maintained about 25 dbt models including the core orders mart. Designed the star schema for the orders mart with our then-DE. | `merge` | "Senior Data Analyst, 5 years, retail."; "Built and maintained about 25 dbt models including the core orders mart."; "I designed the star schema for the orders mart with our then-DE." | `[grounded]` your message | pending your approval |
| E2 | Experience | "I designed the star schema for the orders mart with our then-DE." | "I designed the star schema for the orders mart with our then-DE." (unchanged, moved above the dbt line) | `reorder` | "I designed the star schema for the orders mart with our then-DE." | `[grounded]` your message | pending your approval |
| E3 | Experience | "I've fixed our nightly dbt job when it breaks and added tests to it." | "Fixed our nightly dbt job when it breaks, and added tests to it." | `compress` | "I've fixed our nightly dbt job when it breaks and added tests to it." | `[grounded]` your message | pending your approval |
| E4 | Experience | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | "Scripting in Python to pull vendor APIs on a cron." (its own bullet; the pandas line stays as it is) | `split` | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | `[grounded]` your message | pending your approval |

Each line passed the reframing audit clause by clause. E4 keeps "scripting" and drops nothing that qualifies it. E2 keeps "with our then-DE", because that co-ownership is the part an interviewer will probe. Nothing says "data engineer", "production", "owned", or any tool you have not used.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| 1 | 3+ years data engineering | must-have | not_evidenced | none. E2–E4 are adjacent work, but none of it is stated as data engineering or as a period of years | `[grounded]` your message |
| 2 | Production Python | important | surfaced_by_edit | E4. The cron scripts are the closest evidence; "production" is not something you wrote | `[grounded]` your message |
| 3 | Airflow or equivalent orchestration | important | not_evidenced | none. You wrote "Never used Airflow"; what scheduled the nightly dbt job is not stated | `[grounded]` your message |
| 4 | Dimensional modelling | important | already_evidenced | E2 only moves the star-schema line earlier; the claim is already there | `[grounded]` your message |
| 5 | Model the warehouse | important | surfaced_by_edit | E2. Partial: one mart, co-designed. Whole-warehouse modelling is not evidenced | `[grounded]` your message |
| 6 | Build and own batch pipelines | important | surfaced_by_edit | E2, E3. Partial: the dbt transformation layer, maintained nightly. Ingestion and scheduling are not evidenced, and "own" is not stated | `[grounded]` your message |
| 7 | Own data quality | important | surfaced_by_edit | E3 (tests added to the nightly job). Partial: ownership is not stated | `[grounded]` your message |
| 8 | Own SLAs | important | not_evidenced | none. No SLA, freshness target or on-call appears in what you wrote | `[grounded]` your message |
| 9 | Partner with analytics on requirements | important | not_evidenced | none. Five years on the analytics side is the closest bridge, but no line says you shaped pipeline requirements with analysts | `[grounded]` your message |
| 10 | Streaming pipelines (Kafka; Spark also named) | preferred | not_evidenced | none. "Never touched Kafka." "Never used Airflow or Spark." | `[grounded]` your message |

## Gap handling

**Named absences (no recall prompt, the gap is closed by a path):**
- **#1, 3+ years data engineering.** Your years are analytics years, and the posting makes this a must-have. The closing path is a stretch of six to twelve months where data engineering is the job, such as owning an ingestion or pipeline project on your current team. The other path is a narrower target: analytics engineering, which your dbt work already fits. Whether to keep applying is job-underwriter's call.
- **#10, streaming.** It is a plus, not a requirement. The closing path is a small Kafka consumer project you can show. If you do not do that, carry it as an accepted gap.

**Recall prompts (the questions are in the closing block, tagged to these rows):**
- **#3, orchestration.** What you wrote does not show what ran the nightly dbt job. Experience that may count: a scheduler you configured, changes to job dependencies, retries or alerting. Useful evidence: the job's config or a screenshot of its schedule.
- **#8, SLAs.** Experience that may count: a freshness or completion target on the orders mart, a missed-run response you handled, a stakeholder agreement. Useful evidence: an alert log or a status page.
- **#9, requirements.** Experience that may count: scoping the grain or definitions of a model with an analyst, or deciding which metrics the orders mart would carry. Useful evidence: a spec or a ticket thread.

## Prohibited claims

Not written, and why:

- **"Data Engineer" as a title, or "3+ years data engineering."** You have not held that title or done that work for that period. The posting makes it a must-have.
- **"Owned the nightly dbt job" or "owned the orders mart."** You wrote "fixed" and "maintained." "Owned" moves you from operator to accountable owner.
- **"Modelled the warehouse."** You co-designed the star schema for one mart. "The warehouse" widens the scope.
- **Airflow, Spark, Kafka, or "streaming" in any form, including the skills list.** You wrote "Never used" and "Never touched."
- **"Production Python."** The cron scripts are the closest thing. "Production" is not a word you used, and it would claim operating standards you have not described.
- **"Data quality ownership" or "SLAs."** Tests were added, and no SLA appears.
- **"Partnered with analytics on requirements."** That is the posting's phrasing for a role you have not described. Your side of that table was the analytics side.

## Parse-safety check

Your resume came as a description in your message, not a file, so I could not check layout, headers or footers. When you send the file, check three things: multi-column layout (it can detach dates from roles), contact details placed in a header or footer, and a non-standard heading for Experience.

## Upgrade menu

- **The resume file (.docx or text-layer PDF), or the bullets as they now read.** This replaces my reading of your description with exact quotes and a real "Current line" column, and it may change which rows survive.
- **A repo or a sanitized snippet of the cron scripts or the dbt project, including the tests.** This is the inspectable artifact for #2 (production Python) and #7 (data quality). Strip employer-confidential names first.
- **The nightly job's run history or a failure log showing a fix you made.** This is evidence for #6 and #7 at a stronger level than your word alone.

## Questions

1. **#3 (orchestration):** What ran the nightly dbt job, such as Airflow, dbt Cloud or a cron box, and did you ever change its dependencies, retries or alerts?
2. **#8 (SLAs):** Did anyone track a freshness or completion target for the orders mart, and did you get paged or own the response when it missed?
3. **#9 (requirements):** When analysts asked for a model or metric in the orders mart, did you scope its grain and definitions with them, or did someone else?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.