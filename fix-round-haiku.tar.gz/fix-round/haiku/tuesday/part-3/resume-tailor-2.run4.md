I worked from your description, not a file, so there are no current lines to rewrite. Every row below quotes a sentence you wrote, and each one needs checking against the actual document. Nothing is applied yet.

The honest version can make your dbt, star-schema, data-quality and Python-scripting work visible for this role. It cannot cover the 3+ years must-have, orchestration, Spark, Kafka or SLAs.

## Edit ledger

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Summary (new) | none supplied | "Senior Data Analyst, 5 years, retail. Built and maintained about 25 dbt models including the core orders mart, and designed the star schema for that mart with our then-DE." | `merge` | "Senior Data Analyst, 5 years, retail."; "Built and maintained about 25 dbt models including the core orders mart."; "I designed the star schema for the orders mart with our then-DE." | `[grounded]` your description | pending your approval |
| E2 | Experience | none supplied | "Designed the star schema for the orders mart with our then-DE." | `reorder` | "I designed the star schema for the orders mart with our then-DE." | `[grounded]` your description | pending your approval |
| E3 | Experience | none supplied | "Fixed our nightly dbt job when it breaks and added tests to it." | `surface` | "I've fixed our nightly dbt job when it breaks and added tests to it." | `[grounded]` your description | pending your approval |
| E4 | Experience | none supplied | "Python: pandas for analysis, and some scripting to pull vendor APIs on a cron." | `split` | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | `[grounded]` your description | pending your approval |
| E5 | Skills or Experience | none supplied | "SQL on Redshift every day, including complex window functions and CTEs." | `surface` | "SQL every day on Redshift, complex window functions and CTEs." | `[grounded]` your description | pending your approval |
| E6 | Experience | none supplied | "Built and maintained about 25 dbt models including the core orders mart." | `reorder` | "Built and maintained about 25 dbt models including the core orders mart." | `[grounded]` your description | pending your approval |

E4 drops "some" nowhere and adds no "production" or "pipeline". E1 is a summary built only from your sentences; reject it if you'd rather not have one.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| C1 | 3+ years data engineering | must-have | not_evidenced | Your five years are analytics. The pipeline-adjacent work (E3, E6) is real, but its duration is not stated. | `[grounded]` the material; no data engineering years |
| C2 | Production Python | important | surfaced_by_edit | E4 surfaces the cron-scheduled API scripts. "Production" is not in the material, so it stays off the line. | `[grounded]` |
| C3 | Airflow or equivalent orchestration | important | not_evidenced | "Never used Airflow" is your statement. A cron entry alone may not count. | `[grounded]` the absence; `[generic]` what counts as equivalent varies by employer |
| C4 | Dimensional and warehouse modelling | important | surfaced_by_edit | E2 moves the star schema claim up, keeping "with our then-DE". E5 adds the Redshift work. | `[grounded]` |
| C5 | Build and own batch pipelines | important | surfaced_by_edit | E1 and E6 put the dbt models first. The material shows you built and maintained transforms, not ingestion or scheduling. | `[grounded]` |
| C6 | Spark, batch and streaming | important | not_evidenced | "Never used Airflow or Spark." | `[grounded]` |
| C7 | Kafka and streaming | preferred | not_evidenced | "Never touched Kafka." Streaming is listed as a plus. | `[grounded]` |
| C8 | Own data quality | important | surfaced_by_edit | E3: fixing the nightly job and adding tests is the evidence. "Own" stays off the line. | `[grounded]` |
| C9 | Own SLAs | important | not_evidenced | No delivery time, freshness target or alerting appears in the material. | `[grounded]` the absence; `[generic]` SLAs are usually set and tracked, not just met |
| C10 | Partner with analytics on requirements | important | not_evidenced | Your analyst years are the strongest argument here, but no line says you gathered requirements. | `[grounded]` the absence |

No requirement is `already_evidenced` as written, because the current lines are unknown.

## Recovery per gap

**Recall prompts** (questions are in the closing block):

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | 3+ years data engineering | must-have | Five years of analytics; no duration for the pipeline work | A must-have on years is read first, and five years of analyst work can end the read there | Maintaining the nightly dbt job; keeping the orders mart running; the vendor-API pulls; the star schema build | Job history, commit history, the mart's change log | `[grounded]` what the material says; `[generic]` must-have years are often read as a screen |
| C3 | Airflow or equivalent orchestration | important | "Never used Airflow"; the scheduler for the nightly job is not named | Scheduling, retries and dependencies are what "orchestration" usually means here | Whatever ran the nightly dbt job; whatever ran the vendor pulls | The job's schedule or config | `[grounded]` the material; `[generic]` equivalence is judged per employer |
| C9 | Own SLAs | important | Nothing on delivery times, freshness or alerts | "Own SLAs" is a named responsibility, and the reader sees no commitment | Nightly completion expectations; freshness the analysts relied on; alerts on failed runs | Alert history; a message setting an expected time | `[grounded]` the absence; `[generic]` SLAs are usually set and tracked |

**Named absences** (say what it would take):

- **C6, Spark.** The material says you have not used Spark, and nothing else touches distributed processing. Closing it means a batch Spark job you can run and show, on data you're allowed to share. Otherwise it means months on a team that runs Spark in production. Until then, don't claim it.
- **C7, Kafka and streaming.** Streaming is a plus, so this costs less than Spark. Closing it means a small producer and consumer you can run and show, or targeting roles where streaming isn't listed.
- **C10, Partnering with analytics on requirements.** Closing it needs a specific exchange you took part in about what a dataset should contain. If none happened, the line can't be written; the analyst background, already in E1, is the honest version.

## Prohibited claims

Not written, and why:

- **"Data Engineer" as a title or in the summary.** You have not held it. A title changes the claim rather than describing it.
- **Any data engineering year count.** The material gives five years of analytics and no DE years.
- **"Owned" the nightly pipeline, data quality or SLAs.** The material says you fixed the job and added tests. "Owned" turns participation into ownership.
- **"Production Python" or "Python pipelines."** The material says analysis and cron scripts.
- **Airflow, Spark, Kafka or streaming, including in a skills list.** You said you have never used them, and a listed tool is a tool claimed.
- **"Designed the warehouse" or "led dimensional modelling."** You designed the star schema with the then-DE. "Led" is a verb upgrade, and "with our then-DE" stays.
- **"Partnered with analytics on requirements."** No such exchange is in the material, and "partnered" borrows the posting's word for a thing you did from the analyst side.

No rows have been rejected yet, so the list holds only refusals.

## Parse-safety check

This could not run. The resume arrived as a description, not a file. Send the file and I'll check for multi-column layout, tables or text boxes, contact details in headers or footers, non-standard section headings, and file type. A .docx or a text-layer PDF is the safe pair.

## Upgrades you can choose

- **The resume file.** It replaces the description with real current lines, fills the current-line column, and enables the parse-safety check.
- **A non-confidential sample.** A dbt model or the vendor-pull script, with identifying details removed. It could support C2 and C3 if it shows what the job does on failure.
- **job-underwriter.** It can say whether the 3+ years must-have is a knockout for this posting, before you put more into this application.

**Questions**

C1 — Roughly how many years have you spent on pipeline and modelling work (the nightly dbt job, the orders mart, the vendor pulls) as opposed to analysis? Give the years you maintained the nightly job.
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

C3 — What scheduled the nightly dbt job and the vendor pulls: plain cron, an orchestrator with retries and dependencies, or a dbt Cloud-style scheduler?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

C9 — Did anyone expect the orders data by a certain time or freshness, and did a missed run get noticed or alert anyone?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.