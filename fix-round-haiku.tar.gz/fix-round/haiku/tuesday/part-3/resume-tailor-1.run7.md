I've run the resume-tailor module on the CV text you sent. It's prose, not a file, so I treated it as your self-report. Nothing is applied yet. Every row is pending your approval, and I'll produce the tailored CV only from the rows you approve.

## Edit ledger

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| L1 | Summary (new) | *(none)* | Senior Software Engineer, 7 years. Currently at a payments company. Go and Rust daily for 4 years, Python before that. | `merge` | "Senior Software Engineer, 7 years."; "Currently at a payments company."; "Go and Rust daily for 4 years, Python before that." | `[grounded]` cv | pending your approval |
| L2 | Skills | "Kafka, Postgres, Terraform, gRPC, Datadog." | Go, Rust, Python, Kafka, Postgres, Terraform, gRPC, Datadog. | `surface` | "Go and Rust daily for 4 years, Python before that."; "Kafka, Postgres, Terraform, gRPC, Datadog." | `[grounded]` cv | pending your approval |
| L3 | Experience | "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak." | I own three services in our ledger pipeline. | `split` | "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak." | `[grounded]` cv | pending your approval |
| L4 | Experience | "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak." | One of those services handles about 40k requests/minute at peak. | `split` | "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak." | `[grounded]` cv | pending your approval |
| L5 | Experience | "Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer." | *(unchanged, moved to the top of the experience bullets)* | `reorder` | "Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer." | `[grounded]` cv | pending your approval |
| L6 | Experience | "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | On-call rotation every fourth week for two years. | `split` | "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | `[grounded]` cv | pending your approval |
| L7 | Experience | "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | Ran six incidents as incident commander. | `split` | "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | `[grounded]` cv | pending your approval |
| L8 | Experience | "I do onboarding for new hires on my team — usually two or three a year, I pair with them for their first month." | Onboard new hires on my team — usually two or three a year — and pair with each for their first month. | `reframe` | "I do onboarding for new hires on my team — usually two or three a year, I pair with them for their first month." | `[grounded]` cv | pending your approval |

Notes on the rows:
- **L1** is built only from existing sentences, and each one is kept whole.
- **L4** keeps "about". The 40k is one service's peak, not the three together.
- **L8** keeps "usually". Dropping it would turn "usually two or three" into a fixed number.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| C1 | 5+ years backend | must-have | already_evidenced | "Senior Software Engineer, 7 years." The word "backend" isn't in the CV. A reader infers it from the owned services, and no row adds it. | `[grounded]` |
| C2 | Production Go | must-have | surfaced_by_edit | L2 moves Go into the skills list. Go is 4 years, not 5. "Production" isn't stated; see the prohibited list. | `[grounded]` |
| C3 | High request volume | important | surfaced_by_edit | L3, L4: the 40k/min peak is currently buried mid-sentence. | `[grounded]` |
| C4 | Distributed systems | must-have | not_evidenced | Kafka is listed with no context, and no distributed design is described. Recall prompt R2. | `[grounded]` what the CV does and doesn't say |
| C5 | Strong incident response | must-have | surfaced_by_edit | L6, L7: six incidents as incident commander, currently one clause. | `[grounded]` |
| C6 | Experience mentoring | must-have | surfaced_by_edit | L8: onboarding pairing, two or three hires a year. This is onboarding, not mentoring as such. | `[grounded]` |
| C7 | Mentor mid-level engineers | important | not_evidenced | Nothing beyond onboarding. Recall prompt R1. | `[grounded]` |
| C8 | Own on-call for your services | important | surfaced_by_edit | L3, L6: three owned services, every fourth week for two years. | `[grounded]` |
| C9 | Drive down p99 latency | important | surfaced_by_edit | L5: 380ms to 95ms, currently in the middle of a sentence. | `[grounded]` |
| C10 | Design and ship Go services | important | not_evidenced | "Own" and "reworking" are stated. Designing or shipping a new service is not. Recall prompt R2. | `[grounded]` |
| C11 | Partner with product on roadmap sequencing | important | not_evidenced | Nothing in the CV. Recall prompt R3. | `[grounded]` |
| C12 | Build-cache platform | important | not_evidenced | The nearest adjacent work is the cache-layer rework (L5), on payments balance reads. Named absence below. | `[grounded]` |

## Gap handling

**Recall prompts** (the questions for these are in the closing block):

- **R1, for C7.** What the CV shows: onboarding pairing only. Why it matters: the posting asks you to mentor mid-level engineers, and onboarding alone reads as junior-facing. Experience that may count: a mid-level colleague you coached past their first month, a promotion case you wrote for someone, an on-call handover you ran. Useful evidence: a promotion packet, a 1:1 plan, a review thread. `[grounded]` what the CV does and doesn't say; `[generic]` what this costs on applications of this kind.
- **R2, for C4 and C10.** What the CV shows: Kafka in a list, and owned services. Why it matters: the posting asks you to design and ship Go services and to work on distributed systems at scale. Experience that may count: a service you designed from scratch, the Kafka topology in the pipeline, a consistency or failure-handling decision. Useful evidence: a design doc, an ADR, an architecture diagram.
- **R3, for C11.** What the CV shows: nothing about product. Why it matters: roadmap sequencing is a named responsibility. Experience that may count: a quarter where you re-sequenced work with product, a migration or deprecation you scheduled with them. Useful evidence: a roadmap doc, planning notes.

**Named absence, C12 (build-cache platform).** Plainly: the CV has no build-cache or developer-tools work. The closest thing is reworking the cache layer on payments balance reads (L5), which is a different system. The posting makes build-cache work the job itself, not an extra, so this is central. Closing it would take a build-cache or artifact-cache project, or a contribution to a build system such as Bazel or Gradle. If you have neither, this is a requirement to weigh before applying. Whether to apply is a separate decision, and I haven't made it.

## Prohibited claims

Not written, and why:

- **"Build-cache," "developer tools," "build systems."** No evidence in the CV. The cache work is on payments reads.
- **"Mentored mid-level engineers."** The CV has onboarding only. L8 says what it is.
- **"Partnered with product on roadmap."** Nothing in the CV supports it.
- **"Designed" or "shipped" a new Go service.** The CV says you own services and rework a cache layer.
- **"Distributed systems."** The CV doesn't say it, though Kafka sits in the list.
- **"Backend" as a title, or "7 years of backend."** The CV says "Senior Software Engineer, 7 years."
- **"Production Go."** The CV doesn't say it. The owned services imply it strongly. Tell me if you want it used and I'll audit it as a new row.
- **Dropping "usually" from onboarding, or "about" from 40k.** Both would make a looser claim than your sentence.
- **"40k requests/minute" across all three services, or "sustained."** It's one service's peak.
- **"Led" incidents.** The CV says "run" and "incident commander," so L7 keeps those words.
- **The posting's words for your history.** "High request volume," "roadmap sequencing" and "design and ship" are not used for anything you've done.

## Parse-safety check

You pasted text, not a file, so I couldn't check layout, columns, headers, footers or file type. From the text alone, there are no tables or icons. Two things to check in your real file: contact details placed in a header or footer, which some parsers drop, and any skill bars, which parsers can't read.

## Upgrade menu

- **A Datadog p99 graph for the balance-read path, before and after the cache rework, or the design doc for that change.** This would move C9 from a number you've stated to a figure someone can inspect.
- **One postmortem from the six incidents you ran as commander.** This would make C5 inspectable.
- **A promotion packet, a 1:1 plan or a mentoring note.** This is the most direct route to C7.
- **A prior resume version.** Anything your current CV dropped may hold evidence for C4, C10 or C11.

## Questions

R1: Beyond onboarding, have you mentored an engineer past their first month, such as a mid-level colleague you coached through a project or a promotion case you wrote? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

R2: Have you designed a service or a major pipeline change from scratch, including the Kafka topology or the consistency and failure-handling choices? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

R3: Have you shaped what your team built next alongside product, such as deciding what got sequenced when, or pushing a product request back? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

To approve, reply by row, for example "Approved: L1–L8" or "Approved: L2, L3, L5; Rejected: L1 — I don't want a summary." Rejected rows go into the prohibited list.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.