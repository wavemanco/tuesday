The Bash check was denied, so I can't look for the full dossier file on disk. I'll work from the excerpt you pasted and say so in the output. Next I'll read the reference files this playbook requires before building the ledger.
I've built the ledger and coverage map from your CV sentences and the dossier excerpt. I couldn't open the full `tuesday-dossier.md` (the lookup for it was blocked), so the dossier inputs are only the excerpt you pasted. Nothing is applied yet. The tailored CV comes only after you approve rows.

**Where this lands:** the CV can honestly show seven years of client-side integration leadership, the playbook, the client-feedback sessions, and the tools. It can't claim product management, shipped products, or roadmap ownership. Those stay gaps, named below.

## Edit ledger (all pending your approval)

I only have your sentences, not the document layout, so "Current line" is blank where I can't see placement.

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience | (not visible in what you sent) | Its own bullet: "Wrote the internal integration playbook the whole team uses." | `surface` | "Wrote the internal integration playbook the whole team uses." | `[grounded]` cv | pending your approval |
| E2 | Experience | (not visible in what you sent) | Move to the top of the role, wording unchanged: "Led 30+ client integrations of our REST APIs end to end." | `reorder` | "Led 30+ client integrations of our REST APIs end to end." | `[grounded]` cv | pending your approval |
| E3 | Experience | "Ran quarterly roadmap-input sessions collecting client feedback for product." | Unchanged, placed directly after E2 | `reorder` | "Ran quarterly roadmap-input sessions collecting client feedback for product." | `[grounded]` cv | pending your approval |
| E4 | Skills | (not visible in what you sent) | Its own line: "Comfortable in Postman, SQL, OpenAPI specs." | `surface` | "Comfortable in Postman, SQL, OpenAPI specs." | `[grounded]` cv | pending your approval |

E1 is the pending edit from the dossier, re-audited against your sentence. No title change is proposed, so the CV keeps "solutions engineer / implementation lead."

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| C1 | 3+ years PM | must-have | not_evidenced | Adjacent only: E2, E3. No PM years exist. Length requirements are not gates; this is graded on fit. | `[grounded]` cv |
| C2 | Shipped API platform products | must-have | not_evidenced | Adjacent: E2 (integrations delivered for clients). Nothing shipped as a product. | `[grounded]` cv |
| C3 | Technical fluency | must-have | surfaced_by_edit | E4 | `[grounded]` cv |
| C4 | Stakeholder management | must-have | surfaced_by_edit | E2, E3. Client-side only; no internal or executive stakeholder work is in the sentences you sent. | `[grounded]` cv |
| C5 | Own the API platform roadmap | important | not_evidenced | E3 shows input collection, not prioritisation authority | `[grounded]` cv |
| C6 | Run discovery with integration partners | important | not_evidenced | E3 is feedback collection, not a discovery method | `[grounded]` cv |
| C7 | Write specs; drive delivery with two engineering squads | important | not_evidenced | OpenAPI fluency (E4) is not spec authorship. No squad delivery is stated. | `[grounded]` cv |
| C8 | Define adoption metrics | important | not_evidenced | E2 counts integrations delivered. A count is not an adoption metric, so it isn't written as one. | `[grounded]` cv |

## Gap handling

Recall prompts (their questions are in the closing block):

| # | Requirement | What your CV currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|
| C5 | Roadmap ownership | Input collection, no decision authority | The roadmap is the first thing this role will test | Quarterly roadmap sessions; any backlog you ranked | Session notes, a ranked list, a roadmap doc | `[grounded]` what the CV says; `[generic]` what this costs on applications of this kind |
| C7 | Specs and squad delivery | OpenAPI fluency only | Two engineering squads are named in the posting | Requirements you wrote for integrations; any squad you worked with | A spec or requirements doc you wrote | `[grounded]` what the CV says; `[generic]` what this costs |
| C8 | Adoption metrics | Integration count only | The posting asks you to define them | Post-go-live usage on the 30+ integrations | Usage or time-to-first-call figures | `[grounded]` what the CV says; `[generic]` what this costs |

Named absence: **C1 (PM years) and C2 (shipped products)** cannot be closed by rewording. The closing paths are a PM-scoped or product-owner role on an API product, or a shipped product you can show. Until then, the honest framing is adjacent integration leadership with the gap stated.

## Prohibited claims

Not written, and why:

- **"Product Manager" in any title, or "3+ years product management":** you have never held the title, and C1 is adjacent work.
- **"Shipped API products":** the sentences show integrations delivered for clients, not a product you shipped.
- **"Owned the roadmap" or "prioritised":** you wrote "collecting," and the sessions gathered input.
- **"Partner" in place of "client":** the posting's word would move which side of the table you sat on. You were the vendor.
- **"Customer of a partner API platform":** rejected in the dossier. You were vendor-side.
- **"Built an internal request-triage tool":** rejected in the dossier. You could not confirm ownership.
- **"Drove adoption," or "foundation-wide"/"enterprise-wide" scope:** not stated.
- **"Wrote specs" from OpenAPI fluency:** fluency is not authorship.
- **"Led two engineering squads" or "drove delivery":** not stated.

## Parse-safety check

You sent text, not a file, so the layout checks (columns, tables, headers, icons) could not run. No parse risk is observable from the text. Send the CV as `.docx` or a text-layer PDF and I'll run them.

## Upgrade menu

- **Full `tuesday-dossier.md`:** paste it, so I can check the rest of its evidence map and gap queue against these rows.
- **The integration playbook:** the artifact that would firm up E1. Paste or link it.
- **A spec or roadmap doc you wrote:** would unlock C7 and part of C5.
- **Integration usage data:** would unlock C8.

## Questions

1. **C5:** In those quarterly sessions, did you decide which client requests reached the roadmap, or collect them and pass them on?
2. **C7:** Did you write requirements or specs that engineering built from, even informally? Name one.
3. **C8:** Did you track whether the 30+ integrations were used after go-live, or have any figure for it?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.