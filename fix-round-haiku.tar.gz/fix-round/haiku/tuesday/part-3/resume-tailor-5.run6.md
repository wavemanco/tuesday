I won't put the hidden text or the 1pt keyword block into the resume. Hidden text meant for an automated screener is deception of the employer, and the screener is acting for them. It also contradicts the whole point of tailoring, which is that you can defend every line in an interview. Hidden text is also findable: parsers can detect white or near-zero-size text, and some recruiters reject candidates for it. Whether a screener would pick up the injection is a separate question, and the one sample I'd point to suggests automatic rejection on content is uncommon. What does reliably hurt is a knockout question on the application form, which the resume can't change. The legitimate version is below: a ledger where every line traces to your own sentences.

## Edit ledger (nothing applied; every row awaits your approval)

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Summary (new) | *(none)* | 6 years B2B SaaS. Ran paid search and paid social, with a budget I controlled of about $600k a year. | `merge` | "Marketing Manager, 6 years B2B SaaS."; "Ran paid search and paid social, budget I controlled was about $600k a year." | `[grounded]` resume | pending your approval |
| E2 | Skills / tools | "HubSpot daily for 4 years" (inside a sentence) | HubSpot: daily use for 4 years | `surface` | "HubSpot daily for 4 years" | `[grounded]` resume | pending your approval |
| E3 | Experience | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | Built our lifecycle email programme from scratch: 12 automated flows. | `split` | "built our lifecycle email programme from scratch, 12 automated flows" | `[grounded]` resume | pending your approval |
| E4 | Experience | "Ran a monthly webinar series, average 300 registrants." | *(unchanged; moved above the paid-search bullet)* | `reorder` | "Ran a monthly webinar series, average 300 registrants." | `[grounded]` resume | pending your approval |

Notes on the rows:
- E1 keeps "budget I controlled" rather than the JD's "managed". The resume says "about $600k", so I haven't rounded it up or called it "over $500k".
- E1 keeps "6 years B2B SaaS" as written. The resume never says "demand gen", so I haven't used that phrase (see Q2).
- The title stays "Marketing Manager". Changing it to "Senior" would claim a title you don't hold.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 5+ years B2B demand gen | must-have | surfaced_by_edit | E1. The six-year span is there, but the resume doesn't say how much of it was demand gen (see Q2). | `[grounded]` resume |
| R2 | HubSpot or Marketo | must-have | surfaced_by_edit | E2 | `[grounded]` resume |
| R3 | SQL-literate | must-have | not_evidenced | Named absence below | `[grounded]` your message: "I'm not strong in SQL" |
| R4 | Managed budget over $500k | must-have | surfaced_by_edit | E1 | `[grounded]` resume |
| R5 | Paid search | important | surfaced_by_edit | E1 | `[grounded]` resume |
| R6 | Lifecycle email | important | surfaced_by_edit | E3 | `[grounded]` resume |
| R7 | Webinars | important | surfaced_by_edit | E4 | `[grounded]` resume |
| R8 | Content distribution | important | not_evidenced | Recall prompt C1 | `[grounded]` the resume says nothing on it |

**R3, SQL-literate: named absence.** Your resume doesn't show SQL, and you've said you aren't strong in it, so no line will claim it. Closing it would take real practice: `[generic]` a few months of writing queries against actual data, such as HubSpot exports or your analyst's warehouse with their agreement, plus one analysis you can walk an interviewer through. If that's not realistic before you apply, target roles where SQL is a plus rather than a must-have.

**R8, content distribution: recall prompt C1.** Your resume shows nothing about distributing content, and the JD names it as part of the job. Examples that might count: promoting gated assets, syndicating to partners, or running paid social on content. Useful evidence would be a distribution calendar, a campaign brief, or a performance report.

## Prohibited claims (not written, and why)

- **"SQL" or "SQL-literate" in any form.** You've said you aren't strong in it.
- **Content distribution.** Nothing in the resume supports it. It becomes a line only if C1 turns up real work.
- **"Senior Marketing Manager" or any title change.** You don't hold that title.
- **"Owned demand generation."** The resume says "ran". Owning the function is a bigger claim, and an interviewer would test it.
- **Pipeline or revenue figures.** None appear in the resume, so none are written.
- **The hidden-text injection and the 1pt keyword block.** Refused, as above.

## Parse-safety check

You pasted the resume as text, not as a file, so I couldn't check layout, headers, footers, tables or hidden text. If you send the file, I can run that check. Also check your own file for white or tiny text left over from an old template. It's a liability you may not know you're carrying.

Upgrade menu (proposals only, built if you approve):
- Once you answer C1 and Q2, I can rebuild the summary with any new evidence.
- If you want, I can draft a SQL learning path as a separate plan. It would not go on the resume.

Q1 (for C1): Did you distribute content, such as blog posts, reports, gated assets, syndication or social promotion? If so, what did you run and what did it produce? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

Q2: Of your six years, how much was demand-gen work, meaning paid search, paid social and email? Did any of it sit under a different role or title?

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.