**Short answer:** keyword matching is probably not the main reason you're being rejected. Your resume also doesn't yet show most of this stack, and no wording change can fix that. Below is what I can honestly propose. Nothing is applied until you approve it.

**Why keywords probably aren't the whole story.** The sources I checked point to these, in order:
- Knockout questions on the application form reject the most people without a human reading the resume. They cover things like work authorization, required licence and location. Resume wording doesn't change them. (cite C26)
- Content-based auto-rejection exists but is uncommon. The one sample I found had 2 of 25 recruiters using it, and it comes from a résumé-builder vendor. (cite C25)
- Match scores mostly decide who gets reviewed first, and a low score lowers a resume rather than rejecting it. (cite C27)

So truthful keywords can make your real experience easier to find. They can't make the resume match a production Kubernetes, Terraform, ArgoCD and Istio role. Also, the parse problems below may be where your keywords are getting lost.

**Caveat:** I haven't seen the PDF. I'm working from your description. The "traces" below are quoted from your message, and they have to match the real file word for word. Paste the resume text (copy-select-all from the PDF) so I can check them.

Research tier: L0 — no searches

**Coverage map** (the JD gives no must-have/nice-to-have tiers, so I've marked the platform core as must-have; tell me if the full posting differs)

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| 1 | Kubernetes | must-have | surfaced_by_edit | E1, E4. Proof-of-concept only; not production | [grounded] resume |
| 2 | AWS EKS | must-have | not_evidenced | EC2, S3, RDS and IAM are shown, not EKS. Recall C1 | [grounded] absent from resume |
| 3 | Terraform | must-have | not_evidenced | Ansible is adjacent (config management, not provisioning). Recall C2 | [grounded] absent from resume |
| 4 | GitOps / ArgoCD | must-have | not_evidenced | Named absence; see closing path | [grounded] absent from resume |
| 5 | Helm | important | not_evidenced | Asked with row 2 (C1) | [grounded] absent from resume |
| 6 | Istio / service mesh | important | not_evidenced | Named absence | [grounded] absent from resume |
| 7 | Prometheus / Grafana / observability | important | not_evidenced | CloudWatch monitoring is adjacent (transferability). Recall C3 | [grounded] absent from resume |
| 8 | Vault | important | not_evidenced | IAM is access control, not secrets management. Named absence | [grounded] absent from resume |
| 9 | CI/CD (GitLab) | important | surfaced_by_edit | Jenkins deploy pipeline: E2, E3. GitLab itself is not evidenced | [grounded] resume |
| 10 | Python | important | already_evidenced | "Bash and Python scripting" already on the resume | [grounded] resume |
| 11 | AWS | important | already_evidenced | Skills line already shows the services | [grounded] resume |
| 12 | Go | important | not_evidenced | Named absence | [grounded] absent from resume |
| 13 | SRE practices / platform reliability | must-have | not_evidenced | No on-call, SLO or incident work on the resume. Named absence | [grounded] absent from resume |
| 14 | Developer experience | important | not_evidenced | Nothing on the resume describes developers as users. Named absence | [grounded] absent from resume |

**Edit ledger** (all `pending your approval`)

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Skills | *(not listed)* | "Kubernetes (proof-of-concept, two months last year; not in production)" | surface | "Ran a Kubernetes proof-of-concept for two months last year — never went to production." | [grounded] resume | pending your approval |
| E2 | Experience | "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs." | *(unchanged — moved to the top of Experience)* | reorder | "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs." | [grounded] resume | pending your approval |
| E3 | Skills | "AWS (EC2, S3, RDS, IAM), Docker, Jenkins, Bash and Python scripting, Ansible for config management, CloudWatch for monitoring." | "CI/CD: Jenkins" (added as a label; the rest of the list is unchanged) | reframe | "AWS (EC2, S3, RDS, IAM), Docker, Jenkins, Bash and Python scripting, Ansible for config management, CloudWatch for monitoring." | [grounded] Jenkins. "CI/CD" is a category label, not a claim about scope. Approve or reject this row on its own | pending your approval |
| E4 | Summary (new) | *(no current line)* | "DevOps Engineer, 4 years: Jenkins deploy pipeline with about 30 jobs, AWS, Bash and Python scripting, Ansible, CloudWatch monitoring; Kubernetes proof-of-concept, never in production." | merge | "DevOps Engineer, 4 years."; "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs."; "Ran a Kubernetes proof-of-concept for two months last year — never went to production." | [grounded] resume | pending your approval |

**Not written, and why**
- **"Platform Engineer" as a title.** You've been a DevOps Engineer, and retitling would claim a role you haven't held.
- **Terraform, EKS, ArgoCD, GitOps, Helm, Istio, service mesh, Vault, Prometheus, Grafana, GitLab, Go.** None appear in your history. Listing them would claim use.
- **"Kubernetes in production", "owned clusters".** The proof-of-concept never went to production.
- **"Platform reliability", "SRE practices", "developer experience", "observability".** These are the posting's words for your history, and "CloudWatch for monitoring" would become a bigger job if relabelled.
- **"30+ jobs" or "maintained 30 pipelines".** The number is "about 30 Jenkins jobs", and it stays attached to jobs.

**Parse-safety check** (reported only; I haven't redesigned anything)

| Check | What breaks | What it costs you |
|---|---|---|
| Two-column layout | Parsers read across columns, so text can interleave | Dates can detach from the roles they belong to |
| Skill icons | Icons render as garbage or are skipped | If skill names are only in icons, those keywords are absent to the parser. This is the most likely place your keywords are disappearing |
| Contact details in the header | Header text can be treated as page furniture and dropped | You could become unreachable through the parser |
| File type | Canva PDFs may or may not have a text layer | Check by selecting all in a PDF viewer and pasting into a text editor. If that's garbled or empty, the parser is seeing the same thing |

**Upgrade menu**
- **Paste the resume text.** This makes the traces checkable and runs the real parse check.
- **Kubernetes proof-of-concept artifacts** (repo, manifests, notes). Inspectable proof would move E1 from `medium` to `high`.
- **A sanitised Jenkinsfile or pipeline config.** This would give the CI/CD row an inspectable artifact.
- **The full posting.** If it has must-have and nice-to-have labels, the priorities above may change.

**Closing paths for the named absences** (only if you want them): Terraform and EKS together are the realistic gap to close, through a small project on EKS managed with Terraform and deployed with Helm and ArgoCD, published as a repo. Istio, Vault and Go are much bigger jumps and may not be worth closing for this role.

**Questions**
- **C1 (Kubernetes, EKS, Helm, GitOps):** Was the proof-of-concept on AWS EKS, and did you deploy anything with Helm or set up ArgoCD or any GitOps sync? Answer in text, paste, or say skip.
- **C2 (Terraform):** Have you written Terraform for any AWS resources, at work or in a personal project? Answer in text, paste, or say skip.
- **C3 (Prometheus / Grafana):** Have you built Grafana dashboards or Prometheus alerts, or was your monitoring CloudWatch only? Answer in text, paste, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.