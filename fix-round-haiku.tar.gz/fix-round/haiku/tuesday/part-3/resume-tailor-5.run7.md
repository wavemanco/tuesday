I'm not going to write the white-text prompt-injection block or the 1pt keyword block. Hidden text meant to steer an automated screener is deception of the employer, and it contradicts the point of this work: you should be able to defend every line of your resume. It is also detectable. Some platforms report finding white text, and a candidate has been turned down after a recruiter found his. Your friend's premise is also overstated. Content-based auto-rejection exists but is uncommon in the one sample available (25 recruiters, run by a résumé-builder vendor). Knockout questions on the application form are what most often reject people without a person looking, and keyword match scores mainly decide who gets reviewed first. The legitimate version is below: truthful keywords where your evidence already supports them, the strongest evidence first, and a parse check.

Nothing below is applied. Every row is pending your approval. The tailored resume comes only after you approve rows.

## Edit ledger

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience | "Ran paid search and paid social, budget I controlled was about $600k a year." | "Ran paid search and paid social. Controlled a budget of about $600k a year." | `split` | "Ran paid search and paid social, budget I controlled was about $600k a year." | `[grounded]` resume, Experience | pending your approval |
| E2 | Experience | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | "Used HubSpot daily for 4 years. Built our lifecycle email programme from scratch: 12 automated flows." | `split` | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | `[grounded]` resume, Experience | pending your approval |
| E3 | Summary (new) | *(no current line)* | "Marketing Manager, 6 years B2B SaaS. Built our lifecycle email programme from scratch, 12 automated flows. Ran a monthly webinar series, average 300 registrants." | `merge` | "Marketing Manager, 6 years B2B SaaS."; "built our lifecycle email programme from scratch, 12 automated flows"; "Ran a monthly webinar series, average 300 registrants." | `[grounded]` resume | pending your approval |

E1 keeps your word "controlled" and does not change "about". E2 keeps "from scratch" and "our". E3 is optional; reject it if you don't want a summary block.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| 1 | 5+ years B2B demand gen | must-have | surfaced_by_edit | E3 and E1. Your six years are B2B SaaS marketing. The resume never says demand gen, so the years of demand-gen work need confirming (Q3). | `[grounded]` resume |
| 2 | HubSpot or Marketo | must-have | surfaced_by_edit | E2 (HubSpot, 4 years, was buried in the lifecycle sentence). Marketo is not on the resume and is not claimed. | `[grounded]` resume |
| 3 | SQL-literate | must-have | not_evidenced | Named absence below | `[grounded]` your message: you're not strong in SQL |
| 4 | Managed a budget over $500k | must-have | surfaced_by_edit | E1. Whether the $600k covered only paid channels is open (Q2). | `[grounded]` resume |
| 5 | Paid search | important | already_evidenced | Resume as written, and E1 keeps it | `[grounded]` resume |
| 6 | Lifecycle email | important | already_evidenced | Resume as written, and E2 keeps it | `[grounded]` resume |
| 7 | Webinars | important | already_evidenced | Resume as written, and E3 keeps it | `[grounded]` resume |
| 8 | Content distribution | important | not_evidenced | Recall prompt C1 | `[grounded]` resume has no content distribution line |

## Gap handling

**SQL-literate (row 3), named absence.** The resume can't claim SQL, and you've said you aren't strong in it, so this stays open. Closing it would take sustained work: writing your own queries against HubSpot or warehouse data rather than asking the analyst, for a few months, and ending with one query or analysis you can walk through in an interview. This is a must-have and could be a knockout if the form asks about it directly. If it does, answer truthfully.

**Content distribution (row 8), recall prompt C1.** Asked in the closing block.

## Prohibited claims

Not written, and why:

- **"Senior Marketing Manager" or any title you haven't held.** The JD's title is not yours.
- **"Demand generation" as a label for your work.** The resume never uses it. The functions are shown by name instead.
- **"Marketo".** Not on the resume.
- **"SQL" or "SQL-literate".** You've said you aren't strong in it.
- **"Owned the pipeline" or "owned demand generation".** Neither is stated.
- **"Content distribution".** No evidence on the resume.
- **"300 attendees".** You wrote "average 300 registrants". Registrants and attendees are different numbers.
- **"Managed" in place of "controlled".** The word on the resume is "controlled", so the ledger keeps it.
- **Hidden text, white text, 1pt keyword blocks, or any instruction aimed at a screener.** Refused above.

## Parse-safety check

Your resume arrived as pasted text, so I could not check layout, tables, text boxes, headers or footers. If you send the file, I can run the check. Use a .docx or a text-layer PDF, keep contact details in the body rather than the header or footer, and avoid multi-column layouts.

## Upgrade menu

- **A HubSpot export or screenshot of the 12 flows, with build dates.** This would make the lifecycle claim checkable in an interview.
- **The budget sheet or approval record for the $600k.** This would make the budget claim checkable.
- **A webinar registration report.** This would confirm the 300 average.

## Questions

**C1 — Content distribution.** Did you run content distribution, such as promoting blog posts or gated assets through email, social or partners, and did you own it? Name one example, the channel, and a number if you have one. Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Q2 — Budget scope.** Was the roughly $600k a year only for paid search and paid social, or a wider marketing budget?

**Q3 — Years.** Were most of your six years spent on demand-generation work, such as pipeline targets for paid and lifecycle programmes, or in a broader marketing role?

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.