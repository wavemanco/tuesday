Priya, this is an approve-first ledger. Nothing is applied until you approve specific rows. It is built only from the summary in your message, because the full CV text didn't come through. The "Traces to" quotes are verbatim from that message. Once you paste the CV, I can check each "Current line" against the real document, and the parse-safety check can run on the actual file.

**What the role asks for against what you've shown:** Strong on production Go, p99 latency, request volume, on-call and incident command. Partial on mentoring, since your evidence is onboarding, not mid-level mentorship. Not evidenced at all: roadmap sequencing with product, and anything in build-cache work. The only "distributed systems" evidence is scale and Kafka, and the distributed part is not stated.

## Edit ledger

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Summary (new) | *(none)* | "Senior Software Engineer, 7 years. Go and Rust daily for 4 years, Python before that. Currently at a payments company, owning three services in our ledger pipeline." | `merge` | "Senior Software Engineer, 7 years."; "Currently at a payments company."; "Go and Rust daily for 4 years, Python before that."; "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak." | `[grounded]` your message | pending your approval |
| E2 | Experience (payments role) | "Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer." | *(unchanged, moved to the top of this role's bullets)* | `reorder` | "Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer." | `[grounded]` your message | pending your approval |
| E3 | Experience (payments role) | "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak." | "Own three services in our ledger pipeline; one handles about 40k requests/minute at peak." | `reorder` | "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak." | `[grounded]` your message | pending your approval |
| E4 | Experience (payments role) | "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | "On-call every fourth week for two years; incident commander for six incidents." | `compress` | "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | `[grounded]` your message | pending your approval |
| E5 | Experience (payments role) | "I do onboarding for new hires on my team — usually two or three a year, I pair with them for their first month." | "Onboard new hires on my team, usually two or three a year, pairing with each for their first month." | `compress` | "I do onboarding for new hires on my team — usually two or three a year, I pair with them for their first month." | `[grounded]` your message | pending your approval |
| E6 | Skills | "Kafka, Postgres, Terraform, gRPC, Datadog" | "Go, Rust, Python, gRPC, Kafka, Postgres, Terraform, Datadog" | `surface` | "Go and Rust daily for 4 years, Python before that."; "CV also lists: Kafka, Postgres, Terraform, gRPC, Datadog." | `[grounded]` your message | pending your approval |

Notes:
- E1 keeps "our" from your sentence. Changing it to "its" would be harmless, but I left it as written.
- E5 keeps "usually" and "two or three a year". Dropping either would overstate the pattern.
- E6 lists Go, Rust and Python because you said you use them daily. Listing Kafka and gRPC does not say you used them on the ledger services, so that stays as you wrote it. If your skills section already has these, E6 is moot.
- The payments-role section and the bullet order are my assumption. Your CV's real layout may differ.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| C1 | 5+ years backend | must-have | surfaced_by_edit | E1 | `[grounded]` "7 years"; `[inferred]` that those years are backend work, from the services described |
| C2 | Production Go | must-have | surfaced_by_edit | E1, E6 | `[grounded]` "Go and Rust daily for 4 years" |
| C3 | Distributed systems at scale | must-have | surfaced_by_edit | E1, E3. "Distributed" is not stated anywhere; see R1 | `[grounded]` "40k requests/minute at peak"; `[grounded]` Kafka and gRPC listed |
| C4 | Strong incident response | must-have | surfaced_by_edit | E4 | `[grounded]` "run six incidents as incident commander". "Strong" is a judgement for the interviewer, so the row states only the record |
| C5 | Experience mentoring | must-have | surfaced_by_edit | E5. Mentoring beyond onboarding is not evidenced; see R2 | `[grounded]` onboarding and first-month pairing |
| C6 | Drive down p99 latency | important | surfaced_by_edit | E2 | `[grounded]` "Cut p99 on the balance-read path from 380ms to 95ms" |
| C7 | Design and ship high-volume Go services | important | surfaced_by_edit | E1, E3 | `[grounded]` "owning three services"; "40k requests/minute at peak" |
| C8 | Own on-call for your services | important | surfaced_by_edit | E4 | `[grounded]` "On-call rotation every fourth week for two years" |
| C9 | Mentor mid-level engineers | important | not_evidenced | Nothing yet. Onboarding (E5) is adjacent only. See R2 | `[grounded]` what E5 shows; the rest is absence in your material |
| C10 | Partner with product on roadmap sequencing | important | not_evidenced | Nothing in your material. See R3 | `[grounded]` absence in your material |
| C11 | Build-cache platform experience | important | not_evidenced | Adjacent only: E2, a cache-layer rework on a payments balance-read path, not build artifacts | `[grounded]` "reworking the cache layer"; `[grounded]` absence of build-cache work |

## Gap handling

- **R1 (C3, distributed systems, important-to-must):** Your material shows scale and Kafka, but not what the services do across boundaries. The question is in the closing block.
- **R2 (C9, mentoring mid-level engineers, important):** You have onboarding evidence only. The question is in the closing block.
- **R3 (C10, roadmap sequencing, important):** Nothing in your material. The question is in the closing block.
- **C11 (build-cache):** A named absence. Your cache work is real but on a different kind of system. Closing this would take a project or a conversation about build caching, and I don't have a way to supply that from here. Carried as a material risk.

## Not written, and why

- **"Mentored mid-level engineers"**: you onboard new hires for their first month. Mentoring mid-level engineers is different work, and an interviewer will test the difference.
- **"Partnered with product on roadmap sequencing"**: nothing in your material supports it.
- **"Designed and shipped" services**: your text says you own services and reworked a cache layer. "Designed" and "shipped" are not in it.
- **"Senior Backend Engineer" as a title**: you hold Senior Software Engineer. A retitle would be a claim about your role.
- **"Led" incident response**: the record is incident commander for six incidents. "Led" is a stronger verb than that.
- **"Distributed systems" as a skill or claim**: not written until you confirm it (R1).
- **Build-cache or build-artifact experience**: none in your material.
- **"Strong incident response" as a self-description**: the record goes in; the adjective is the interviewer's to give.

## Parse-safety

Could not run. You pasted text, not a file, so I can't see layout, columns, headers or footers. Once you send the CV as a file (.docx or a text-layer PDF is the safe pair), I can run the checks.

## Upgrade menu

- **Full CV text, pasted or as a file:** verifies every "Current line" and the parse-safety check, and may surface sentences I can't see here.
- **An inspectable artifact for the ledger cache rework (E2)**, such as a design doc, a benchmark, or a shareable write-up, if your employer allows it. That would move the latency claim from your word to something a reviewer can read.
- **A written postmortem for one of the six incidents (E4)**, if shareable. Check your employer's policy first.

## Questions

R1 (C3): Do the ledger services exchange events or calls with other services, through Kafka or gRPC for example, and what part of that path did you own? Answer in text or say skip.

R2 (C9): Beyond onboarding, have you mentored an engineer who was already working, such as a mid-level engineer growing toward senior? If so, what did that look like? Answer in text or say skip.

R3 (C10): Have you shaped what your team built next with a product manager, deciding order or scope of work? If so, can you name one time? Answer in text or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.