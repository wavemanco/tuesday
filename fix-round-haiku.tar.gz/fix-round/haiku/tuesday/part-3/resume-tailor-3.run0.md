I can tailor this CV, but the tailoring will not close the must-have. Nothing below is applied yet: every row is pending your approval, and I'll produce the tailored resume only from the rows you approve. I used the excerpt you pasted, not the full dossier file, and I traced each row to the sentences you gave me in your message. If your CV file words them differently, send it and I'll re-quote the traces.

**Where the posting stands against your material**

Only the 3+ years PM requirement is marked must-have. I treated the other requirements as important. Your seven years are solutions and implementation work, so they don't count toward PM years.

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 3+ years PM | must-have | not_evidenced | No PM years in the material. Closest rows: E2, E3. Dossier: adjacent, transferability. | `[grounded]` CV and dossier R1 |
| R2 | Shipped API or platform products | important | not_evidenced | You integrated clients onto our REST APIs. Shipping the API product isn't shown. Closest: E2. | `[grounded]` CV |
| R3 | Technical fluency | important | surfaced_by_edit | E4 moves the tools line up; E5 brings it into the opening. | `[grounded]` CV |
| R4 | Stakeholder management | important | surfaced_by_edit | Client-side only (E2, E3). Internal or executive stakeholder work isn't shown, and the label isn't used. | `[grounded]` CV |
| R5 | Own the roadmap | important | not_evidenced | E3 is input collection, not ownership. Recall prompt C1. | `[grounded]` CV and dossier |
| R6 | Discovery with integration partners | important | not_evidenced | E3 is client feedback in quarterly sessions, not discovery. Named absence N1. | `[grounded]` CV |
| R7 | Write specs and drive delivery with two engineering squads | important | not_evidenced | E1 is a process playbook, not specs for engineering. Recall prompt C2. | `[grounded]` CV |
| R8 | Define adoption metrics | important | not_evidenced | No adoption measure in the material. Recall prompt C3. | `[grounded]` CV |

**Edit ledger (all pending your approval)**

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience | Playbook authorship not on its own line (per dossier E1) | Wrote the internal integration playbook the whole team uses. | `surface` | "Wrote the internal integration playbook the whole team uses." | `[grounded]` CV; dossier E1 | pending your approval |
| E2 | Experience | Integration work; position not in material | Led 30+ client integrations of our REST APIs end to end. | `surface` | "Led 30+ client integrations of our REST APIs end to end." | `[grounded]` CV | pending your approval |
| E3 | Experience | Roadmap-input sessions; position not in material | Ran quarterly roadmap-input sessions collecting client feedback for product. | `surface` | "Ran quarterly roadmap-input sessions collecting client feedback for product." | `[grounded]` CV | pending your approval |
| E4 | Skills | Not in material | Comfortable in Postman, SQL, OpenAPI specs. | `surface` | "Comfortable in Postman, SQL, OpenAPI specs." | `[grounded]` CV | pending your approval |
| E5 | Summary | (none) | 7 years solutions engineer / implementation lead at an enterprise software vendor. Led 30+ client integrations of our REST APIs end to end. | `merge` | "7 years solutions engineer / implementation lead at an enterprise software vendor."; "Led 30+ client integrations of our REST APIs end to end." | `[grounded]` CV | pending your approval |

E5 is the row most likely to drift, so it quotes both sentences in full. It keeps your title as it is and adds no PM framing. No row retitles your role, because "Product" would be an upgrade you haven't earned.

**Recall prompts and named absences**

- **C1 (R5):** Did you ever own a backlog or decide what the team built next, even informally? Would count: a decision you made, with the call you had to win.
- **C2 (R7):** Did you write requirements or specs that an engineering team built from? Would count: one document and who built from it.
- **C3 (R8):** Did you track any adoption measure for the integrations or the API, or make API decisions such as versioning, deprecation or endpoint scope? Would count: a number you tracked, or a decision you owned.
- **N1 (R6, discovery with partners):** No evidence. Closing it means running discovery yourself: interviews, problem framing, and a decision made on what you learned. No rewording closes it.
- **N2 (R1, 3+ years PM):** Zero PM years in the material. Closing it means PM work over time, or a target role closer to your current title. Wording cannot close it.

**Not written, and why**

- **A PM title, or "Product" in the headline.** You have never held the title, and R1 is a must-have.
- **"Owned the roadmap" or "prioritisation authority."** Not evidenced. C1 is the only way back in.
- **"Shipped API products" or "API platform."** You integrated clients onto the APIs. You did not ship the platform.
- **"Partner" or "customer" for the integration clients.** You were vendor-side. Either word would flip which side of the table you sat on. Your word, "client", stays.
- **"Built an internal request-triage tool."** Rejected in the dossier: ownership could not be confirmed.
- **"Has been the customer of a partner API platform."** Rejected in the dossier: you worked vendor-side.
- **"Discovery with integration partners."** Collecting feedback in sessions is a different kind of work from running discovery.
- **"Wrote specs for engineering squads."** You wrote a playbook. OpenAPI fluency is a tool, not a spec-authoring record.
- **"Defined adoption metrics."** Not in the material.
- **"Stakeholder management" as a label.** That is the posting's vocabulary for your history.
- **Counting the seven years toward the PM requirement.**

**Parse-safety check**

Your CV arrived as a pasted summary, not a file. I could not check layout, columns, tables, headers or footers, so I can't say whether your contact details survive parsing. Send the file (.docx or a text-layer PDF) and I'll run those checks.

**Upgrade menu**

- **The CV file:** lets me check parsing and confirm the current lines that E1–E5 are written against.
- **Answers to C1–C3:** each answered prompt can move R5, R7 or R8 off `not_evidenced`, after I confirm the answer before writing a row.
- **The integration playbook itself:** an inspectable artifact, the strongest support for R3 and R4.
- **An API spec or doc you authored:** the strongest support for R7, if you wrote one.
- **Earlier resume versions:** they may hold evidence the current one dropped.

**Questions**

C1 — Did you ever own a backlog or decide what the team built next, even informally? Give one example.
C2 — Did you write requirements or specs that an engineering team built from? Name one.
C3 — Did you track any adoption measure for the integrations or the API, or make API decisions such as versioning, deprecation or endpoint scope? Give one example, with a number if you have one.

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip. To approve, reply by row, for example "Approved: E1, E2, E4" with any rejections and the reason.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.