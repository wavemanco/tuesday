**Short answer:** Keyword matching is probably part of it, but no keyword edit closes the gap for this posting. The resume shows Python, AWS, Docker, Jenkins and a Kubernetes proof-of-concept. The posting asks for about a dozen platform tools and practices you don't have yet. I've tailored what the resume honestly supports and marked the rest as gaps. I haven't seen the PDF, so the parse check below is based on your description.

**Premise check: what the evidence says about ATS rejection**

| Claim | Provenance | Source |
|---|---|---|
| Content-based auto-rejection was configured by 2 of 25 recruiters interviewed. The source is a résumé-builder vendor, and it calls the findings themes, not statistics. | [grounded] | (cite C25) |
| Where automated filters are used, they are almost always yes/no knockout questions on work authorization, required licence or location. These are answered on the application form, not in the resume. | [grounded] | (cite C26) |
| Many teams use match scores to decide who is reviewed first. A low score pushes a resume down the pile; it does not reject it outright. | [grounded] | (cite C27) |
| Keywords drive those match scores. | [inferred] from the match-score finding; the source doesn't say what the score counts | — |

So the likely causes, in order: the application form's knockout questions (which I can't see), a low match score that buries you in the pile, and a parser that hides your skills (see the parse check). Keyword optimisation helps the second and third. It can't help with the posting's missing tools.

**The ledger (pending your approval, nothing applied)**

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| R1 | Summary (new) | *(none)* | "DevOps Engineer, 4 years. Works with AWS (EC2, S3, RDS, IAM), Docker, Jenkins, Ansible and CloudWatch." | `merge` | "DevOps Engineer, 4 years."; "AWS (EC2, S3, RDS, IAM), Docker, Jenkins, Bash and Python scripting, Ansible for config management, CloudWatch for monitoring." | [grounded] resume | pending your approval |
| R2 | Experience | "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs." | Unchanged, moved to the first Experience bullet | `reorder` | "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs." | [grounded] resume | pending your approval |
| R3 | Skills | "Ran a Kubernetes proof-of-concept for two months last year — never went to production." | "Kubernetes — proof-of-concept, two months, not run in production" | `surface` | "Ran a Kubernetes proof-of-concept for two months last year — never went to production." | [grounded] resume | pending your approval |
| R4 | Skills | "Bash and Python scripting" | Two lines: "Python scripting" and "Bash scripting" | `split` | "Bash and Python scripting" | [grounded] resume | pending your approval |

R3 keeps the qualifier. Drop "never went to production" and the line claims more than you did.

**Coverage map**

The posting gives no priority tiers. I've read the named platform stack as must-have, Go as preferred, and GitLab-specific CI as important.

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| 1 | Kubernetes | must-have | surfaced_by_edit | R3; proof-of-concept only | [grounded] |
| 2 | AWS EKS | must-have | not_evidenced | EC2, S3, RDS and IAM are on the resume; EKS isn't, and it's unknown whether the PoC used it | [grounded] |
| 3 | Terraform | must-have | not_evidenced | Ansible covers configuration; no provisioning is named | [grounded] |
| 4 | ArgoCD and GitOps | must-have | not_evidenced | No Git-driven deployment tooling is named | [grounded] |
| 5 | Helm | important | not_evidenced | Nothing named | [grounded] |
| 6 | Istio and service mesh | must-have | not_evidenced | Nothing named | [grounded] |
| 7 | Prometheus and Grafana | must-have | not_evidenced | CloudWatch is adjacent (monitoring, not a metrics stack) | [grounded] |
| 8 | Observability | must-have | not_evidenced | CloudWatch monitoring is adjacent; "observability" is the posting's word | [grounded] |
| 9 | Vault | important | not_evidenced | IAM is adjacent; secrets management isn't named | [grounded] |
| 10 | CI/CD (GitLab) | important | surfaced_by_edit | R2; Jenkins only, GitLab not evidenced | [grounded] |
| 11 | Python | important | surfaced_by_edit | R4 | [grounded] |
| 12 | Go | preferred | not_evidenced | Nothing named | [grounded] |
| 13 | SRE practices | must-have | not_evidenced | No on-call, incident, SLO or reliability work is named | [grounded] |
| 14 | Platform reliability and developer experience ownership | must-have | not_evidenced | The resume shows building and maintaining pipelines, not owning a platform | [grounded] |

Rows 2–9, 12, 13 and 14 are `not_evidenced`. Rows 1, 10 and 11 are `surfaced_by_edit`.

**Recovery per gap**

- **C1 (rows 1, 2, 5):** What the Kubernetes proof-of-concept actually ran, on what platform, and with what tooling. This is the most likely source of real evidence.
- **C2 (rows 3, 4, 6, 7, 9):** Any use of these tools, even in a lab or side project.
- **C3 (rows 8, 13, 14):** Any on-call, alerting or incident work on the pipeline or services you ran.
- **Named absence, row 12 (Go):** You have no Go in your material. Closing it would take a published tool or service written in Go, a few weeks of work. It's worth that only if this role is a priority.
- **Named absences, rows 3, 4 (Terraform, ArgoCD) if C2 is no:** One public project would start to close these: Terraform building an EKS cluster in a personal AWS account, and a Helm chart deployed through ArgoCD. That's months of work, not weeks. Istio and Vault need more than that.

**Prohibited claims: not written, and why**

- **"Ran Kubernetes in production"**: the PoC never went to production. R3 keeps that qualifier.
- **"EKS"**: not in your material. Attaching it to the PoC would be a guess.
- **Terraform, ArgoCD, GitOps, Helm, Istio, service mesh, Vault, Prometheus, Grafana, Go, GitLab**: none appears in your material.
- **"Owned the deploy pipeline"**: your sentence says built and maintain. "Owned" is a higher verb.
- **"Observability", "SRE practices", "platform reliability"** as descriptions of your work: these are the posting's words. Your sentence says "CloudWatch for monitoring".
- **"Infrastructure as code"** for Ansible: Ansible configures existing machines. Provisioning infrastructure is a different kind of work, and an interviewer will test the difference.
- **"CI/CD"**: the posting's term. Your line already says what the pipeline does.

**Parse-safety check** (run on your description, not the file)

| Check | Observed? | What it costs |
|---|---|---|
| Two-column layout | Yes | Parsers read across columns, so text interleaves and dates can detach from their roles. |
| Skill icons | Yes | If skill names live inside icons, the parser sees none of them, and the keyword match can't happen. This is the most serious item. |
| Contact details in header | Yes | Header text is often dropped, and then recruiters can't contact you. |
| Section headings | Not checkable from text | Couldn't run. |
| File type (Canva PDF) | Not inspected | To check it yourself, copy the whole page from the PDF into a plain text editor. If the skill names and contact details don't appear, a parser can't see them either. |

Changing the layout is a fix for parsing, not a design recommendation. A one-column .docx or a text-layer PDF with skills written as plain text would avoid these risks.

**What the evidence doesn't resolve:** whether your rejections came from the application form, the match score, or a human reading the resume. The fastest test is the knockout questions on the form you filled in.

**Upgrade menu**

- **The PDF itself:** lets me run the parse check on the real file, not your description.
- **Notes or a repo from the Kubernetes PoC:** would settle C1, and could move row 2 or row 5.
- **Any Terraform or ArgoCD lab, repo or course project:** would move rows 3 and 4 from `not_evidenced` to a real line.

**Questions**

C1 — On the Kubernetes proof-of-concept: did it run on EKS, and what did you deploy onto it (workloads, Helm charts, any Git-driven deploys, any metrics or secrets tooling)? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

C2 — Have you used Terraform, ArgoCD, Istio, Vault, Prometheus or Grafana at all, in work, a lab or a side project, even briefly? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

C3 — Has your Jenkins pipeline, or any service you ran, had an on-call rotation, alerts you responded to, or incident reviews? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**To proceed:** reply by row, for example "Approved: R1, R2, R3, R4" or "Rejected: R1 — I don't want a summary." I'll produce the tailored resume from the approved rows only.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.