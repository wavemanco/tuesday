Nothing is applied yet. Every row below is pending your approval, and I'll produce the tailored CV only from the rows you approve. I worked from the CV lines in your message, not a full file. If you paste the full CV, I'll re-check each "Traces to" quote against its exact wording.

## Edit ledger

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| L1 | Header | "Senior Software Engineer, 7 years." | "Senior Software Engineer, 7 years, currently at a payments company, owning three services in our ledger pipeline." | merge | "Senior Software Engineer, 7 years."; "Currently at a payments company."; "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak." | `[grounded]` cv | pending your approval |
| L2 | Experience | *(no current line)* | "Go and Rust daily for 4 years, Python before that." | surface | "Go and Rust daily for 4 years, Python before that." | `[grounded]` cv | pending your approval |
| L3 | Experience | "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak." | "Own three services in our ledger pipeline; one handles about 40k requests/minute at peak." | compress | "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak." | `[grounded]` cv | pending your approval |
| L4 | Experience | "Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer." | *(unchanged, moved above L3)* | reorder | "Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer." | `[grounded]` cv | pending your approval |
| L5a | Experience | "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | "On-call rotation every fourth week for two years." | split | "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | `[grounded]` cv | pending your approval |
| L5b | Experience | "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | "Ran six incidents as incident commander." | split | "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | `[grounded]` cv | pending your approval |
| L6 | Experience | "I do onboarding for new hires on my team — usually two or three a year, I pair with them for their first month." | "Onboard new hires on my team, usually two or three a year, pairing with each for their first month." | compress | "I do onboarding for new hires on my team — usually two or three a year, I pair with them for their first month." | `[grounded]` cv | pending your approval |
| L7 | Skills | "CV also lists: Kafka, Postgres, Terraform, gRPC, Datadog." | "Kafka, gRPC, Postgres, Terraform, Datadog." | reorder | "CV also lists: Kafka, Postgres, Terraform, gRPC, Datadog." | `[grounded]` cv | pending your approval |

L6 is onboarding, not mentoring. It supports the mentoring requirement only in part, as the coverage map shows.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 5+ years backend | must-have | already_evidenced | Header (L1): 7 years as a Senior Software Engineer. The CV does not say those years were backend work. | `[grounded]` cv |
| R2 | Production Go | must-have | already_evidenced | L2 and L3: Go daily for 4 years, owning services at 40k requests/minute at peak. | `[grounded]` cv |
| R3 | Distributed systems at scale | must-have | not_evidenced | The ledger pipeline (L3) and Kafka and gRPC (L7) are the closest evidence. No sentence says the system is distributed. Recovery: C2. | `[grounded]` cv |
| R4 | Strong incident response | must-have | already_evidenced | L5b: six incidents as incident commander. | `[grounded]` cv |
| R5 | Mentoring experience | must-have | surfaced_by_edit | L6 surfaces onboarding and pairing with new hires. That is not stated as mentoring mid-level engineers. Recovery: C3. | `[grounded]` cv |
| R6 | Own services; design and ship Go services | important | not_evidenced | Ownership is on the CV (L3). Designing or shipping a service is not. Recovery: C2. | `[grounded]` cv |
| R7 | Drive down p99 latency | important | surfaced_by_edit | L4, moved to the top of the experience section. | `[grounded]` cv |
| R8 | Own on-call for your services | important | already_evidenced | L5a: on-call rotation every fourth week for two years. Rotation participation is what is stated. | `[grounded]` cv |
| R9 | Partner with product on roadmap sequencing | important | not_evidenced | Nothing on the CV. Recovery: C1. | `[grounded]` cv |
| R10 | Build-cache platform or developer-tools domain | preferred | not_evidenced | No build-cache or developer-tools work on the CV. The cache-layer rework (L4) is the nearest adjacent work, and it sits on a payments read path. Recovery: named absence below. | `[grounded]` cv |

## Gap handling

**C1 — Partner with product on roadmap sequencing (R9)**

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Partner with product on roadmap sequencing | important | Nothing. The CV says nothing about product or sequencing. | The JD names it as part of the role, so a reader scanning for it finds no line. | A sequencing call you made or argued for; a migration or deprecation timed against product's plans; a feature you shaped with a product manager. | A roadmap or planning doc, a planning thread, a launch note you wrote or were tagged on. | `[grounded]` what the CV does and does not say; `[generic]` that screeners and interviewers for senior roles usually probe this directly |

**C2 — Distributed systems at scale; design and ship (R3, R6)**

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C2 | Distributed systems at scale; designing and shipping Go services | must-have | Ownership of three services and a 40k requests/minute peak (L3). Kafka and gRPC appear only as a list (L7). The CV does not say whether you designed or shipped any service, or how the pipeline is split across services or hosts. | Without it, a reader can't tell whether the scale is a single-service fact or a distributed-systems one. | A service you designed from a blank page; Kafka producers or consumers you ran; a flow that crosses service boundaries. | A design doc, an RFC, an architecture diagram, repo history showing your commits. | `[grounded]` what the CV does and does not say; `[generic]` what screeners check for this kind of requirement |

**C3 — Mentoring experience (R5)**

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C3 | Mentoring mid-level engineers | must-have | Onboarding and a month of pairing with new hires (L6). | The JD asks for mentoring mid-level engineers. Onboarding is a narrower, time-boxed form of that. | Mid-level engineers you developed over months rather than a first month; feedback you gave them; a growth plan or promotion case. | A growth plan, written feedback you gave, a promotion packet line you contributed to. | `[grounded]` what the CV does and does not say; `[generic]` how interviewers usually test mentoring claims |

**Named absence — build-cache or developer-tools domain (R10).** The CV has no build-cache or developer-tools work, and the JD lists it as preferred. The closest work is the cache-layer rework (L4), which is cache design under a latency target on a payments read path. The honest closing path is to make that transferable case in interviews. If you want something on paper, write up the cache redesign's trade-offs in the terms a build-cache team would ask about. I would not write the line itself as build-cache experience.

## Prohibited claims

Not written, and why:

- **"Designed" or "architected" any service.** The CV says you own the services. It does not say you designed them.
- **"Led" or "mentored" mid-level engineers.** The CV supports onboarding and pairing with new hires only.
- **"Partnered with product" or any roadmap role.** Nothing on the CV supports it.
- **Build-cache or developer-tools experience, or "cache platform."** The rework was on a payments read path.
- **"Distributed systems" as a description of your work.** Not established by the CV.
- **"On-call owner."** The CV states rotation participation only.
- **A percentage reduction in p99.** Not added. The stated figures (380ms to 95ms, 40k requests/minute) stay as written, so no new number is attached to them.

## Parse-safety check

This runs on pasted text, not a file, so I could not check layout, tables, text boxes, headers or footers, or file type. Contact details placed in a header or footer could be lost, so check those when you send the file. The text you pasted contains no hidden or white text. The "CV also lists:" line is a sentence rather than a section heading, so a parser may not read it as a skills section.

## Upgrade menu

- **Cache-layer design doc or PR for the 380ms to 95ms change.** Would give L4 an inspectable artifact, which raises its evidence band.
- **Postmortems for the six incidents you commanded.** Would turn R4 into proof a reader can inspect.
- **A design doc or RFC for a service you designed.** Would answer C2 with an artifact.
- **A roadmap or planning doc you co-wrote with product.** Would answer C1 with an artifact.
- **Written feedback from a mentee, or a growth plan.** Would answer C3 with an artifact.

## Questions

**C1 —** Have you shaped a roadmap or sequencing decision with product? Name one and what you did.
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**C2 —** Which of the three services did you design or ship yourself, and was the ledger pipeline spread across several services or hosts?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**C3 —** Have you mentored a mid-level engineer over more than a month? Name one and what changed for them.
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.