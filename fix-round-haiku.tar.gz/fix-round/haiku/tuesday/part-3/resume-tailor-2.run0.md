Short version: the resume can show the data-engineering-shaped work you did, which is dbt modelling, the star schema, and fixing and testing the nightly job. It cannot show three years of data engineering, or Airflow, Spark or Kafka, and I haven't written it to.

I worked from your message, not a resume file, so each "Current line" below is your own sentence as you wrote it. Check those against the document before you approve anything.

## Edit ledger

Nothing is applied. Approve or reject by row number.

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience | "Built and maintained about 25 dbt models including the core orders mart." / "I designed the star schema for the orders mart with our then-DE." | "Built and maintained about 25 dbt models including the core orders mart; designed the star schema for the orders mart with our then-DE." | `merge` | "Built and maintained about 25 dbt models including the core orders mart."; "I designed the star schema for the orders mart with our then-DE." | `[grounded]` self-report in your message | pending your approval |
| E2 | Experience | "I've fixed our nightly dbt job when it breaks and added tests to it." | Unchanged, moved to sit directly beside E1 | `reorder` | "I've fixed our nightly dbt job when it breaks and added tests to it." | `[grounded]` self-report in your message | pending your approval |

Notes on the rows:
- E1 keeps "with our then-DE". The star schema was shared work, and the resume should say so.
- E2 changes only position. The tests and the fix are your work, and putting them next to the dbt bullet is what lets a reader see the data-quality work.
- There is no row for Python. "Python for analysis — pandas, some scripting to pull vendor APIs on a cron" is accurate, and "production" is not in it.
- I did not retitle you to "Data Engineer". The title you hold is Senior Data Analyst, and changing it would be a title claim.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| 1 | 3+ years data engineering | must-have | not_evidenced | No DE title or DE years. The closest work is dbt and modelling inside an analyst role (adjacent, not direct). See N1. | `[grounded]` what the resume does not say |
| 2 | Dimensional and warehouse modelling | important | surfaced_by_edit | E1 (star schema, shared with then-DE) | `[grounded]` |
| 3 | Production Python | important | not_evidenced | Python is shown; "production" is not. Recall C1 | `[grounded]` |
| 4 | Airflow or equivalent orchestration | important | not_evidenced | Nothing names what schedules the nightly job or the pulls. Recall C2 | `[grounded]` |
| 5 | Build and own batch pipelines | important | not_evidenced | Building is shown (E1, E2). End-to-end ownership is not. Recall C1, C2 | `[grounded]` |
| 6 | Own data quality | important | surfaced_by_edit | E2 (added tests, fixed nightly job) | `[grounded]` |
| 7 | Own SLAs | important | not_evidenced | No SLA or freshness target stated. Recall C3 | `[grounded]` |
| 8 | Partner with analytics on requirements | important | not_evidenced | No requirements work described. See N4 | `[grounded]` |
| 9 | Spark | important | not_evidenced | Never used. See N2 | `[grounded]` "Never used Airflow or Spark." |
| 10 | Streaming (Kafka) | preferred | not_evidenced | Never used. See N3 | `[grounded]` "Never touched Kafka." |

SQL is not in the posting's requirements. It is still your strongest line, and it is already on the resume as written.

## Recall prompts

These are the places where your own history may hold more than your sentences say.

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Production Python; build and own pipelines | important | "Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | A reader will take cron scripts as analysis scripting unless something shows they ran unattended and mattered. | The vendor-API pulls: did they write to Redshift, run for long periods, or get depended on? | The script or repo, the cron config, a failure you handled | `[grounded]` what the resume says; `[generic]` postings like this usually look for unattended code with failure handling |
| C2 | Airflow or equivalent orchestration | important | The nightly dbt job is mentioned, but not what schedules it. | Airflow is named, so a reader looks for scheduled, dependency-aware pipelines. | What ran the nightly dbt job and the pulls, and any retry or alert logic someone wrote | Scheduler config (dbt Cloud job, cron file, other), an alert or incident | `[grounded]` what the resume says; `[generic]` orchestration is a common screen for DE roles |
| C3 | Own SLAs | important | Tests were added; no delivery time or freshness target. | The posting makes the DE own SLAs, so a reader needs a commitment, not just tests. | Any readiness time the orders mart had, and any late or wrong number a stakeholder noticed | A freshness check, an SLA note, an incident thread | `[grounded]` what the resume does not say |

## Named absences

| # | Requirement | The gap | Closing path | Provenance |
|---|---|---|---|---|
| N1 | 3+ years data engineering | No DE years are on the resume, and none can be added by rewording. The dbt and modelling work is real but sits inside an analyst role. | Time in DE-shaped work: a role where pipelines are the job, or a dated portfolio of pipeline code. Or aim at analytics-engineering roles, where dbt and modelling are the core. That is a different target, not this one. | `[grounded]` the posting's tier; `[generic]` what closing it takes |
| N2 | Spark | Never used. | One PySpark job over a dataset you already have, in a repo you can link. | `[grounded]` "Never used Airflow or Spark." |
| N3 | Streaming (Kafka) | Never used. It is listed as a plus, not a requirement. | A small consumer on a public feed that lands in a table, in a repo you can link. Not worth closing before applying if the years gap decides this. | `[grounded]` the posting says "a plus" |
| N4 | Partner with analytics on requirements | No sentence says how requirements were handled with a DE team. You sat on the analyst side, which is the closest evidence. | Write one line only if you ran a real requirements cycle with a DE team. If you did not, say so in interview. | `[grounded]` what the resume does not say |

Whether to apply through the years gap is job-underwriter's call. I'd run that on the posting before putting more time into this resume.

## Prohibited claims: not written, and why

- **"3+ years data engineering," or any DE years.** No sentence in your material says them.
- **"Data Engineer" as a title or headline.** The held title is Senior Data Analyst.
- **"Built and owned batch pipelines."** Building dbt models is not owning a pipeline.
- **"Owned data quality and SLAs."** Adding tests is not owning data quality, and there is no SLA.
- **"Production Python" or "production pipelines."** The scripts are described as scripts on a cron.
- **Airflow, Spark or Kafka in a skills list.** You have never used them, and a listed tool is not a tool owned.
- **"Partnered with analytics on requirements."** That is the posting's phrasing. Your resume puts you on the analyst side.
- **"Designed" without "with our then-DE."** The shared credit stays.

## Parse-safety check

Not run. Your resume reached me as a description, not a file, so there is no layout, table or header to check.

## Upgrade menu

- **The resume as a file (.docx, or a PDF with a text layer).** This lets me check each quote against the real text and run the parse-safety check.
- **A repo or link for the vendor-API scripts or the dbt project.** That makes C1 and the test coverage in E2 `[grounded]` on an inspectable artifact, not self-report.
- **The scheduler config, or an alert or runbook for the nightly job.** That moves C2 and C3 from prompts to evidence.

## Questions

**C1** — Did the vendor-API scripts ever write into Redshift or run unattended, and what happened when one failed?

**C2** — What scheduled the nightly dbt job and the vendor pulls, and who set up retries or failure alerts?

**C3** — Did anyone depend on a time the orders mart would be ready, and did you ever miss one?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.