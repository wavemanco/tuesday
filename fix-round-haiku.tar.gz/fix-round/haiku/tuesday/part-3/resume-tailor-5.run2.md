The hidden white text and the 1pt keyword block are out. Hidden text aimed at an automated screener is deception of the employer's tool, and it contradicts the point of the resume: you should be able to defend every line in an interview. Your friend's premise is also overstated. One small sample of recruiters reported content-based auto-rejection at about 8%. What most often rejects people without a human seeing the resume is yes/no knockout questions on the application form, which a resume edit doesn't change. Keywords may affect ranking, so the legitimate version is to put the terms you actually have, such as HubSpot, paid search, paid social, lifecycle email and webinars, where they're true and visible. Hidden text is also readable by the parsers that scan for it, and recruiters have found it and rejected candidates for it.

Below is the tailoring. Nothing is applied until you approve rows.

## Edit ledger (pending your approval)

Your resume came as pasted text, so the quotes below are your sentences exactly as you wrote them.

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Summary (new) | *(no current line)* | "Marketing Manager, 6 years B2B SaaS. Ran paid search and paid social, and built our lifecycle email programme from scratch." | merge | "Marketing Manager, 6 years B2B SaaS."; "Ran paid search and paid social, budget I controlled was about $600k a year."; "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | [grounded] resume | pending your approval |
| E2 | Experience | "Ran paid search and paid social, budget I controlled was about $600k a year." | "Ran paid search and paid social." / "Budget I controlled was about $600k a year." | split | "Ran paid search and paid social, budget I controlled was about $600k a year." | [grounded] resume | pending your approval |
| E3 | Experience | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | "Built our lifecycle email programme from scratch, 12 automated flows." | split | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | [grounded] resume | pending your approval |
| E4 | Tools (new) | *(no current line)* | "HubSpot, daily use for 4 years" | surface | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | [grounded] resume | pending your approval |
| E5 | Experience | "Ran a monthly webinar series, average 300 registrants." | unchanged, moved above the lifecycle line | reorder | "Ran a monthly webinar series, average 300 registrants." | [grounded] resume | pending your approval |

Reply with the row IDs you approve, for example "Approved: E1, E2, E4", and any you reject with a reason.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 5+ years B2B demand gen | must-have | surfaced_by_edit | E1 and E5 put the channels up top. Whether all six years were demand gen is C2 | [grounded] resume |
| R2 | HubSpot or Marketo | must-have | surfaced_by_edit | E4 moves HubSpot into its own line | [grounded] resume |
| R3 | SQL-literate | must-have | not_evidenced | Nothing to land. Named absence below | [grounded] your own words, "not strong in SQL" |
| R4 | Managed a budget over $500k | must-have | surfaced_by_edit | E2 gives the budget its own line. Whether it was the whole budget is C3 | [grounded] resume |
| R5 | Paid search | important | already_evidenced | Stated as written in the current sentence | [grounded] resume |
| R6 | Lifecycle email | important | surfaced_by_edit | E3 separates it from the HubSpot sentence | [grounded] resume |
| R7 | Webinars | important | already_evidenced | Stated as written. E5 only changes position | [grounded] resume |
| R8 | Content distribution | important | not_evidenced | Nothing on the resume. Recall prompt C1 | [grounded] resume (absence) |
| R9 | B2B SaaS | preferred | already_evidenced | "6 years B2B SaaS" | [grounded] resume |

## Recovery per gap

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Content distribution | important | Nothing. The phrase appears only in the posting | An interviewer will test whether you distributed content, not just ran channels | Articles, reports or case studies sent through email, paid or social | A list of published pieces and the channels used | [grounded] what the resume does and does not say; [generic] what this costs on applications of this kind |
| C2 | 5+ years B2B demand gen | must-have | "6 years B2B SaaS" and the channels, but no sentence says how many of the six were demand gen | Years of this specific work is what the must-have asks for; a title alone reads as generic | Paid search and paid social years; the lifecycle build; the webinar series | Dated channel history from HubSpot or your own role record | [grounded] resume; [generic] how screeners read titles without channel detail |
| C3 | Managed a budget over $500k | must-have | "budget I controlled was about $600k a year", for paid search and paid social | E2 states the figure as yours; whether it covers the whole channel mix changes the claim | Setting spend and approving changes, as opposed to executing them | A budget sheet or ad-platform spend summary for one year | [grounded] resume |

**SQL-literate (R3): named absence.** You have said you are not strong in SQL, and asking your analyst for numbers is not SQL, so no row writes it in. Closing it means writing queries yourself against real data, such as your own HubSpot or analytics exports, and producing one analysis you can walk an interviewer through. [grounded] your own words; [generic] that this takes a few months of steady practice, not a line to write. If the application form has a yes/no SQL knockout, that is where this bites first.

## Not written, and why

- **"Senior Marketing Manager" or any seniority title.** Your title is Marketing Manager, and nothing shows a senior one.
- **"Owned demand generation."** The JD's phrase is "own demand generation". You ran channels and a budget, and the word "own" would claim the whole function.
- **"SQL-literate," "analysed data with SQL," or "partnered with analytics."** You said you ask your analyst.
- **"Managed" in place of "controlled," or "over $500k."** The JD's wording is the requirement's, not yours. The figure you gave is about $600k.
- **Content distribution.** No evidence on the resume; see C1.
- **Leads, pipeline, or attendees.** You gave registrants only, so the webinar line stays as "average 300 registrants."
- **Hidden text and a keyword block.** Refused, for the reasons above.

## Parse-safety check

The resume came as pasted text, so I could not check layout, headers, footers, tables or columns. The pasted text itself shows no parse risk. Send the file as a .docx or a text-layer PDF and the check runs on what it actually contains. If the file came from a template or a tool, I will also check it for hidden text you didn't write.

## Upgrade menu

- **The resume as a .docx or text-layer PDF:** runs the parse-safety check on the real layout, and checks for inherited hidden text.
- **Earlier resume versions:** may hold evidence the current one dropped, such as content distribution or a fuller title history.
- **A HubSpot flow list or a one-year budget summary:** lets the lifecycle and budget claims rest on an inspectable artifact, which moves them from self-report toward verified.

## Questions

C1 — Did you distribute content (articles, reports, case studies) through email, paid or social? If so, what did you publish and through which channels?

C2 — Of your six years, how many were spent running paid, lifecycle or webinar programmes, rather than other marketing work?

C3 — Is the about $600k a year the total you controlled across paid search and paid social, or only part of that spend?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.