**Resume tailor: Nadia's CV for the Quartzline Platform APIs PM role**

I worked from the five CV sentences you gave me and the dossier excerpt (R1, R2, the two rejected inferences, E1, conditional_go). No CV file came through, so placements below are proposals against your sentences, not against a layout I've seen. Nothing is applied yet. Every row waits for your approval.

**Coverage map**

The posting labels only the PM years as must-have. I've marked the other listed requirements and responsibilities as important. Tell me if you want them re-ranked. For J1 and J2 I carried the dossier's judgments. The excerpt didn't include rows for the other requirements, so I derived those from the CV.

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| J1 | 3+ years PM | must-have | not_evidenced | No PM years on the CV. Adjacent work is in E2 and E3. Dossier R1 inherited: adjacent, transferability. | `[grounded]` dossier R1 |
| J2 | Shipped API or platform products | important | not_evidenced | REST API integrations delivered to clients (E2) are adjacent. No product you owned and shipped is shown. Dossier R2 inherited. | `[grounded]` dossier R2 |
| J3 | Own the roadmap, prioritisation authority | important | not_evidenced | Roadmap input collected for product (E3). Ownership isn't evidenced. | `[grounded]` dossier R1 reasoning |
| J4 | Technical fluency (APIs, specs, SQL) | important | surfaced_by_edit | E4 (tools) and E2 (REST API work) | `[grounded]` cv |
| J5 | Stakeholder management | important | surfaced_by_edit | Client-facing delivery (E2) and feedback sessions (E3) | `[inferred]` derived: client delivery and feedback sessions read as stakeholder work. No stakeholder role is stated. |
| J6 | Discovery with integration partners | important | not_evidenced | Client feedback sessions (E3) are the nearest match. Discovery you ran as a practice isn't shown. | `[grounded]` cv |
| J7 | Write specs, drive delivery with two engineering squads | important | not_evidenced | OpenAPI fluency (E4) and the playbook (E1) are adjacent. No spec that drove a squad is shown. | `[grounded]` cv |
| J8 | Define adoption metrics | important | not_evidenced | No measure of adoption appears on the CV. | `[grounded]` cv (absence) |

**Edit ledger**

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience | *(buried in the role, per dossier E1)* | Wrote the internal integration playbook the whole team uses. | surface | "Wrote the internal integration playbook the whole team uses." | `[grounded]` cv | pending your approval |
| E2 | Summary (new) | *(no current line)* | 7 years solutions engineer / implementation lead at an enterprise software vendor. Led 30+ client integrations of our REST APIs end to end. | merge | "7 years solutions engineer / implementation lead at an enterprise software vendor."; "Led 30+ client integrations of our REST APIs end to end." | `[grounded]` cv | pending your approval |
| E3 | Experience | *(placement not seen)* | Ran quarterly roadmap-input sessions collecting client feedback for product. | surface | "Ran quarterly roadmap-input sessions collecting client feedback for product." | `[grounded]` cv | pending your approval |
| E4 | Skills | *(placement not seen)* | Comfortable in Postman, SQL, OpenAPI specs. | surface | "Comfortable in Postman, SQL, OpenAPI specs." | `[grounded]` cv | pending your approval |

E2 keeps "our REST APIs" as written. That wording marks you as the vendor side, and the posting's "partner" would move you to the other side of the table, so I haven't used it.

**Gap handling**

- **J1, named absence.** You have no PM title and no PM years, and the posting makes three-plus years a must-have. No wording on the CV can close this, and I won't try. Closing paths: a PM-scoped stint in your current role, or a scoped-down target where integration delivery counts toward PM experience. The dossier's conditional_go already reflects this gap.
- **J2, J3, J7, J8, recall prompts.** Each is asked once, in the questions block below. Any answer goes through a confirmation step before it becomes a row.

**Prohibited claims (not written, and why)**

- Any PM title, or "Product Manager" in any form. You have never held one.
- "Owned the roadmap" or "partner-facing roadmap." Your sessions collected input for product. Ownership isn't shown.
- "Shipped API products." Your integrations were delivered to clients. You didn't ship a product.
- "Ran discovery with integration partners." "Discovery" is the posting's word. Collecting client feedback is a different kind of work.
- "Defined adoption metrics," "drove adoption," or "wrote specs that drove two squads." Nothing on the CV shows any of these.
- Dossier rejected inferences, kept absolute: no internal request-triage tool, and no "customer of a partner API platform."

**Parse-safety check: could not run.** Without a file I can't see columns, tables, headers, or the file type. Send the .docx or text-layer PDF and I'll run it, including whether contact details sit in a header.

**Upgrade menu**

- **The CV file** (.docx or text-layer PDF). It unlocks the parse-safety check and exact placement for E1–E4.
- **The full dossier.** If you paste all of it, I can check J1–J8 against the stored judgments rather than deriving the rows that weren't in the excerpt.
- **Priority labels from the posting.** If it ranks the other requirements, I'll update the priorities.

Reply with approvals by row, for example "Approved: E1, E2" or "Rejected: E4 — …".

**Questions**

C1 (J3): Did you ever decide what a product or feature team built next, or drop something from its plan, even for one quarter?

C2 (J2, J7): Did a feature of the REST APIs ship because of a spec or requirements document you wrote?

C3 (J8): Did you track whether the integrations or the playbook were used or successful? If so, do you have the numbers?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.