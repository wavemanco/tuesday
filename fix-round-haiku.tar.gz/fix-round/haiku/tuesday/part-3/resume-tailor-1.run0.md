I worked from the description of your CV in your message, not a document, so the section names below are my assumptions. The quotes are verbatim from that description. Nothing is applied yet. Approve or reject rows by number.

**Edit ledger**

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| R1 | Summary (new) | *(no current line)* | "Senior Software Engineer, 7 years, currently at a payments company: Go and Rust daily for 4 years, Python before that." | `merge` | "Senior Software Engineer, 7 years."; "Currently at a payments company."; "Go and Rust daily for 4 years, Python before that." | `[grounded]` cv | pending your approval |
| R2 | Experience | "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak." | "Own three services in our ledger pipeline; one handles about 40k requests/minute at peak." | `compress` | "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak." | `[grounded]` cv | pending your approval |
| R3 | Experience | "Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer." | *(unchanged — moved to the first bullet of Experience)* | `reorder` | "Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer." | `[grounded]` cv | pending your approval |
| R4 | Experience | "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | "On-call rotation every fourth week for two years; ran six incidents as incident commander." | `compress` | "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | `[grounded]` cv | pending your approval |
| R5 | Experience | "I do onboarding for new hires on my team — usually two or three a year, I pair with them for their first month." | "Onboard new hires on my team, usually two or three a year, pairing with each for their first month." | `compress` | "I do onboarding for new hires on my team — usually two or three a year, I pair with them for their first month." | `[grounded]` cv | pending your approval |

I did not add a row for the tools list (Kafka, Postgres, Terraform, gRPC, Datadog). The posting names no tools, so moving them up would be a `surface` with nothing for the reader to match.

**Coverage map**

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| K1 | 5+ years backend | must-have | already_evidenced | R1: 7 years as a senior engineer. "Backend" is not on the CV; the ledger services imply it, so the word stays off until you confirm it. | `[grounded]` cv |
| K2 | Production Go | must-have | already_evidenced | R1: "Go and Rust daily for 4 years" | `[grounded]` cv |
| K3 | Distributed systems at scale | must-have | not_evidenced | 40k requests/minute is scale, but the CV does not say how the ledger services are distributed. Recovery: C3. | `[grounded]` what the CV does and does not say |
| K4 | Strong incident response | must-have | surfaced_by_edit | R4: six incidents as incident commander | `[grounded]` cv |
| K5 | Experience mentoring | must-have | surfaced_by_edit | R5: pairing new hires for their first month. This is onboarding; it is not mentoring beyond new hires (I4). | `[grounded]` cv |
| I1 | Design and ship Go services handling high request volume | important | surfaced_by_edit | R2: owns three services, one at about 40k requests/minute. "Design" is not on the CV and is not added. | `[grounded]` cv |
| I2 | Drive down p99 latency | important | surfaced_by_edit | R3: 380ms to 95ms on the balance-read path | `[grounded]` cv |
| I3 | Own on-call for your services | important | surfaced_by_edit | R4: every fourth week for two years | `[grounded]` cv |
| I4 | Mentor mid-level engineers | important | not_evidenced | Nothing on the CV about engineers past onboarding. Recovery: C1. | `[grounded]` what the CV does and does not say |
| I5 | Partner with product on roadmap sequencing | important | not_evidenced | Nothing on the CV about product or roadmap work. Recovery: C2. | `[grounded]` what the CV does and does not say |
| I6 | Build-cache platform services | important | not_evidenced | Adjacent only: the cache-layer rework (R3) is on the balance-read path, not a build cache. Closing path below. | `[grounded]` cv |

**Gap handling**

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Mentor mid-level engineers | important | Onboarding pairs for a new hire's first month (R5). Nothing past that. | The posting names mid-level engineers, which onboarding does not reach. `[generic]` Screens for mentoring usually look for ongoing growth work, not onboarding. | Reviewing a mid-level engineer's designs over months; a growth plan; a project you guided someone through | A note from a manager, a review, or a document the engineer wrote | `[grounded]` what the CV does and does not say; `[generic]` what this costs on applications of this kind |
| C2 | Partner with product on roadmap sequencing | important | Nothing on product or roadmap work | The posting makes it a responsibility, and `[generic]` sequencing is a common senior-loop topic. | Scoping a quarter's technical work with a product manager; deciding what slipped and why; a reliability investment you argued for | A roadmap or planning document, a planning ticket, a decision record | `[grounded]` what the CV does and does not say; `[generic]` what this costs on applications of this kind |
| C3 | Distributed systems at scale | must-have | 40k requests/minute at peak; Kafka and gRPC listed | A must-have. `[generic]` A reader will ask how these services fail and recover. | Changing retry, idempotency or partitioning in the ledger pipeline; a failure you diagnosed across services | A design doc, a postmortem from one of the six incidents, an architecture diagram | `[grounded]` what the CV does and does not say; `[generic]` what this costs on applications of this kind |

**I6 is a named absence.** Your CV does not show build-cache work, and the posting makes it a responsibility. Closing it would take roughly six months on a build cache or a comparable cache-serving system. Without that, the honest move is to say the cache-layer rework is the closest match and that it is not the same system.

**Not written, and why**

- "Production Go" — the posting's words. Your CV says "Go … daily for 4 years", and that is what R1 keeps.
- "Mentored mid-level engineers" or "mentoring" as a verb — the CV describes onboarding and first-month pairing, not mentoring. Using the posting's word would move what you did.
- "Designed services" or "designed the ledger pipeline" — the CV says "own", not "design".
- "Owned the roadmap" or "partnered with product" — nothing on the CV says it.
- "Build-cache" experience — not on the CV.
- "Reduced latency across the platform" — the CV's figure covers the balance-read path only.
- "Scaled to 667 requests/second" — the CV says "40k requests/minute". Converting the unit adds a figure you did not state.

**Parse-safety check.** I ran this on pasted text. I could not check layout, tables, headers or file type, so please check those yourself on the real file.

**Upgrade menu**
- **The CV file** (.docx, or a PDF with a text layer). This unlocks the parse-safety check on the real layout and confirms the section names I assumed.
- **A postmortem or design doc for the 380ms→95ms change.** This turns R3 from a sentence into inspectable proof, and would let the summary cite it.
- **Writeups for the six incidents.** This gives R4 the same kind of proof.

**Questions** (answer in text, paste a voice transcript, attach a document, drop a link, or say skip)

1. **C1:** Beyond first-month onboarding, have you coached an engineer at mid-level over several months, for example through design reviews or a growth plan?
2. **C2:** Have you worked with product on what the team builds next, such as sequencing reliability work against feature work?
3. **C3:** In the ledger pipeline, have you changed how services handle partial failure across services, such as retries, idempotency or partitioning?

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.