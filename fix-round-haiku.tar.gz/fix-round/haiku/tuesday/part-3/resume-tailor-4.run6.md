**Short answer:** keyword matching is probably not the main reason you're being rejected, and no keyword edit can fix the bigger problem. This posting names 16 things. Your resume shows Python outright, four in part (Kubernetes, AWS, CI/CD, observability), and 11 not at all (Terraform, ArgoCD/GitOps, Istio/service mesh, Prometheus, Grafana, Vault, Helm, GitLab CI, Go, SRE practices, platform ownership). The folklore says software silently drops resumes that miss keywords. The evidence is thinner: content-based auto-rejection "configured: 8% of recruiters" (cite C25), in a sample that source calls themes rather than representative statistics, and "When automated filters are used, they’re almost always knockout questions" (cite C26). Those knockouts are yes/no questions on the application form, such as work authorization, licence or location, and no resume edit changes them. Match scores mostly order review: "Low score ≠ auto-reject, but in high-volume roles, it can push you to the bottom of the pile" (cite C27).

So the honest version of "optimise for ATS" is: make the true things findable, and don't pretend to the rest. The ledger below does that. It's short on purpose.

## Edit ledger

Nothing is applied yet. Approve or reject rows by number. The quotes come from the resume text you pasted, not the PDF, so check them against the file before you approve.

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| L1 | Skills | AWS (EC2, S3, RDS, IAM), Docker, Jenkins, Bash and Python scripting, Ansible for config management, CloudWatch for monitoring. | Bash and Python scripting, AWS (EC2, S3, RDS, IAM), Jenkins, Ansible for config management, CloudWatch for monitoring, Docker | reorder | "AWS (EC2, S3, RDS, IAM), Docker, Jenkins, Bash and Python scripting, Ansible for config management, CloudWatch for monitoring." | `[grounded]` resume, skills line | pending your approval |
| L2 | Skills (new entry) | *(none in the skills list)* | Kubernetes: two-month proof-of-concept, never taken to production | surface | "Ran a Kubernetes proof-of-concept for two months last year — never went to production." | `[grounded]` resume | pending your approval |

- **No row for the Jenkins bullet.** "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs." already uses your words. Whether it covered build and test stages is a question (C2), not an edit.
- **L2 keeps the qualifier.** A tool listed is not a tool owned, so "Kubernetes" appears only with "never taken to production" beside it.

## Coverage map

The posting doesn't mark priority tiers. I read the ownership sentence as must-have and the named tools as important: `[inferred]` from the posting's wording.

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| 1 | Kubernetes | important | surfaced_by_edit | L2; a proof-of-concept only, and the claim stops there | `[grounded]` the proof-of-concept sentence |
| 2 | AWS EKS | important | not_evidenced | C1 | `[grounded]` resume names AWS EC2, S3, RDS and IAM, not EKS |
| 3 | AWS | important | already_evidenced | Skills line, as written | `[grounded]` skills line |
| 4 | Python | important | already_evidenced | Skills line, "Bash and Python scripting"; scripting only | `[grounded]` skills line |
| 5 | Terraform | important | not_evidenced | Named absence below | `[grounded]` resume names no infrastructure-as-code tool |
| 6 | ArgoCD and GitOps | important | not_evidenced | Named absence below | `[grounded]` resume describes Jenkins jobs, not Git-driven deploys |
| 7 | Istio and service mesh | important | not_evidenced | Named absence below | `[grounded]` resume names no mesh |
| 8 | Prometheus and Grafana | important | not_evidenced | Named absence below | `[grounded]` resume names CloudWatch only |
| 9 | Observability | important | not_evidenced | C3; CloudWatch monitoring is adjacent, and the claim stops there | `[grounded]` "CloudWatch for monitoring" |
| 10 | Vault | important | not_evidenced | Named absence below | `[grounded]` resume names no secrets tool |
| 11 | Helm | important | not_evidenced | Named absence below; C1 may change it | `[grounded]` resume names no Helm |
| 12 | CI/CD | important | not_evidenced | C2; the Jenkins pipeline is adjacent, and the term is not yet in your own words | `[grounded]` "Built our deploy pipeline in Jenkins…" |
| 13 | GitLab CI | important | not_evidenced | Named absence below | `[grounded]` Jenkins only |
| 14 | Go | important | not_evidenced | Named absence below | `[grounded]` resume names no Go |
| 15 | Own platform reliability and developer experience | must-have | not_evidenced | Named absence below | `[grounded]` no platform ownership in production is stated |
| 16 | SRE practices | important | not_evidenced | C3 | `[grounded]` resume names monitoring, not reliability practice |

## Gap handling

**Recall prompts.** Each is asked once, in the closing questions.

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | AWS EKS, and Kubernetes overall | important | A two-month Kubernetes proof-of-concept, never in production. It doesn't say where it ran. | The posting names EKS, and a reader will ask which cluster the work was on. | A proof-of-concept cluster on EKS; manifests or Helm charts from it; a workload you ran on it | Repo, notes, or a screenshot | `[grounded]` the proof-of-concept sentence; `[generic]` how readers weigh EKS against plain Kubernetes |
| C2 | CI/CD | important | A Jenkins deploy pipeline and about 30 jobs. It doesn't say whether build and test stages were included, or who deployed through it. | The posting asks for CI/CD, and that term isn't yet in your own words. | Build or test stages in those jobs; teams that deployed through the pipeline; a change that cut deploy time | Job list with names only, or a pipeline diagram | `[grounded]` the Jenkins sentence |
| C3 | Observability and SRE practices | important | CloudWatch for monitoring. It doesn't say what was alarmed on, or whether you were paged. | The posting pairs observability with reliability ownership. | Alarms or dashboards you set up; an alarm you responded to; an on-call rota; an incident you worked | Dashboard screenshot, alarm definitions, incident notes | `[grounded]` "CloudWatch for monitoring"; `[generic]` what reliability ownership usually involves |

**Named absences.** Each has a closing path, and none can be closed by editing the resume.

- **Terraform.** No infrastructure-as-code tool is named, and Ansible doesn't count as Terraform. Path: a repo you own that provisions real AWS resources (a VPC, an S3 bucket with its IAM policy) in Terraform, with remote state.
- **ArgoCD and GitOps.** Your Jenkins pipeline pushes deploys, and nothing shows a cluster syncing from Git. Path: deploy one service through Argo CD from a Git repo, then roll back once through Git. This needs a cluster, so it depends on the Kubernetes work.
- **Istio and service mesh.** No mesh work is listed. Path: install Istio on a test cluster, route traffic between two services with a rule, and check the result in telemetry.
- **Prometheus and Grafana.** CloudWatch is the only monitoring named. Path: scrape one service with Prometheus and build a Grafana dashboard for it.
- **Vault.** No secrets manager is named. Path: move one Jenkins credential into Vault and read it from a job.
- **Helm.** Not named. If the proof-of-concept used Helm charts, that becomes a real row through C1. Otherwise, path: package one app as a Helm chart and install it to a test cluster.
- **GitLab CI.** Jenkins only. Path: port one Jenkins job to `.gitlab-ci.yml`.
- **Go.** Not named. Path: write one small CLI or service in Go, in a public repo you can link.
- **Platform reliability and developer experience ownership.** No platform you ran in production is shown. Path: this is a scope question, not a wording one. The realistic target is a role where you own a pipeline or platform, and this posting is a stretch for where your evidence stands.

## Not written, and why

- **"Platform Engineer" as a title.** You have never held it, and retitling to it is an upgrade.
- **"Kubernetes in production" or unqualified "Kubernetes experience."** The proof-of-concept never reached production.
- **"GitOps" or "Argo CD."** Nothing shows Git-driven reconciliation, and Jenkins pushes aren't GitOps.
- **"Terraform" or "infrastructure as code."** Neither is named. Writing them next to Ansible would blur the two.
- **"Prometheus," "Grafana," "observability," or "SRE."** CloudWatch is the only monitoring named.
- **"Vault," "service mesh," "Istio," "Helm," "EKS," "GitLab," or "Go."** None appears in your material.
- **"CI/CD."** That is the posting's term. Your sentence says deploy pipeline. It waits for C2.
- **"Developer experience."** The posting's phrase. Nothing describes developers as users of your work.
- **"Python development" or "Python services."** The claim is "Python scripting."
- **"Owned platform reliability."** "Built" and "maintain" describe the Jenkins work, and nothing shows ownership of reliability.

## Parse-safety check

I haven't seen the PDF. These findings come from your description, so they're observable from that but not confirmed from the file.

| Check | What breaks | What it costs | Observed |
|---|---|---|---|
| Two-column layout | Parsers read across the columns, so the text interleaves | Dates can detach from the roles they belong to | Yes, from your description |
| Icons for each skill | Rendered as garbage characters, or skipped | Skill names are missing if the icon is the only carrier | Unknown: it depends on whether the names are also text |
| Contact details in the header | Header content is often treated as page furniture and dropped | You could become unreachable | Yes, from your description |
| Section headings | Parsers look for conventional labels | Sections may go unrecognised | Could not check |
| Hidden text | Could not inspect | Could not check | Could not run |
| File type | Varies by parser | A `.docx` or a PDF with a text layer is the safe pair | Could not check |

**One test you can run now:** open the PDF, press Ctrl+A (Cmd+A on Mac), copy, and paste into a plain text editor. What you see is roughly what a parser sees. If the contact details, skill names or dates are missing or jumbled, that's a parse risk, and the file is worth fixing before anything else.

## Upgrade menu

- **The proof-of-concept's repo, notes, or a demo.** Unlocks the detail on L2 and C1, and settles the Helm question.
- **The Jenkins job names.** Unlocks C2 with specifics.
- **A CloudWatch alarm or dashboard screenshot.** Unlocks C3.
- **The resume as the actual PDF.** Lets the parse check run on the file, not your description.
- **An earlier resume version.** It may hold evidence the current one dropped.

Whether to apply at all, given these gaps, is a separate call. job-underwriter makes it.

## Questions

**C1 —** Did the Kubernetes proof-of-concept run on AWS EKS?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**C2 —** Did the Jenkins deploy pipeline include build and test stages, not only deployment?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**C3 —** What did your CloudWatch alarms and dashboards cover?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.