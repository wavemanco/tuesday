I've worked from your description, since no CV file came through. Treat it as self-report: every "current line" below is your sentence as you wrote it here, not your document. Check each one against your real CV before approving. Nothing is applied yet, and every row is pending your approval.

## Parse-safety check

Not run. The CV arrived as pasted prose, so I can't see layout, headers, tables or file type. If you send the file (a .docx or text-layer PDF is safest), I'll run it.

## Edit ledger

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Summary (new) | *(no current line)* | "Senior Software Engineer, 7 years, currently at a payments company, owning three services in our ledger pipeline." | `merge` | "Senior Software Engineer, 7 years."; "Currently at a payments company."; "I own three services in our ledger pipeline" | `[grounded]` self-report | pending your approval |
| E2 | Experience | "Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer." | *(unchanged, moved to first bullet)* | `reorder` | "Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer." | `[grounded]` self-report | pending your approval |
| E3 | Experience | "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak." | *(unchanged, moved to second bullet)* | `reorder` | "I own three services in our ledger pipeline — one handles about 40k requests/minute at peak." | `[grounded]` self-report | pending your approval |
| E4 | Experience | "On-call rotation every fourth week for two years, I've run six incidents as incident commander." | "On-call rotation every fourth week for two years." | `split` (1 of 2) | "On-call rotation every fourth week for two years" | `[grounded]` self-report | pending your approval |
| E5 | Experience | *(same sentence as E4)* | "Ran six incidents as incident commander." | `split` (2 of 2) | "I've run six incidents as incident commander." | `[grounded]` self-report | pending your approval |
| E6 | Experience | "I do onboarding for new hires on my team — usually two or three a year, I pair with them for their first month." | "Onboard new hires on my team, usually two or three a year, pairing with each for their first month." | `reframe` | "I do onboarding for new hires on my team — usually two or three a year, I pair with them for their first month." | `[grounded]` self-report | pending your approval |
| E7 | Skills | "CV also lists: Kafka, Postgres, Terraform, gRPC, Datadog." | "Kafka, gRPC, Datadog, Postgres, Terraform" | `reorder` | "CV also lists: Kafka, Postgres, Terraform, gRPC, Datadog." | `[grounded]` self-report | pending your approval |

E4 and E5 are one sentence split in two, so on-call and incident command each get a line you can check on its own.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 5+ years backend | must-have | surfaced_by_edit | E1 states 7 years and owning services in the ledger pipeline. The material doesn't say how many of the 7 years were backend. See Q3. | `[grounded]` self-report |
| R2 | Production Go | must-have | already_evidenced | "Go and Rust daily for 4 years", and she owns production ledger services. | `[grounded]` self-report |
| R3 | Distributed systems at scale | must-have | surfaced_by_edit | E3 moves the 40k requests/minute figure up. Kafka and gRPC appear in E7. The material never says "distributed systems" or that she designed one, so the row claims only scale and tools. | `[grounded]` self-report |
| R4 | Design and ship high-volume Go services | must-have | surfaced_by_edit | E1 and E3. She owns three services and reworked a cache layer. "Design" is not stated outright. | `[grounded]` self-report |
| R5 | Drive down p99 latency | must-have | surfaced_by_edit | E2 moves the 380ms→95ms result to the top. It is evidenced but buried. | `[grounded]` self-report |
| R6 | Strong incident response | must-have | surfaced_by_edit | E5 gives six incidents as incident commander their own line. | `[grounded]` self-report |
| R7 | Own on-call for your services | must-have | surfaced_by_edit | E4 gives the rotation its own line. | `[grounded]` self-report |
| R8 | Experience mentoring | must-have | surfaced_by_edit | E6 surfaces onboarding of new hires. Mentoring mid-level engineers is not in the material. Partial. See C2. | `[grounded]` self-report |
| R9 | Partner with product on roadmap sequencing | important | not_evidenced | Nothing in the material. See C1. | `[grounded]` what the material does not say |
| R10 | Build-cache / developer-tools context | preferred | not_evidenced | Named absence below. | `[grounded]` what the material does not say |

## Recall prompts

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Partner with product on roadmap sequencing | important | Nothing. The material describes engineering work only. | The JD lists it among the role's core duties, so a reader will look for it. | Deciding which reliability or latency work goes first; scoping a migration with a product or account owner; the cache rework, if it was prioritised with someone outside engineering. | A planning doc, roadmap note or ticket where you proposed the order of work. | `[grounded]` what the material does not say; `[generic]` what this costs on applications of this kind |
| C2 | Experience mentoring (mid-level engineers) | must-have | Onboarding of new hires for their first month. | "Mentor mid-level engineers" is named in the JD, and onboarding is a different job. | Growth-focused pairing or code review with an engineer past their first month; a promotion case you supported; a design review you coached someone through. | A feedback note, a promotion packet, or a review thread. | `[grounded]` what the material does not say; `[generic]` what this costs on applications of this kind |

## Named absence

**R10, build-cache and developer-tools context.** Nothing in the material touches build systems, caches as a product, or developer tooling. The closest real evidence is the balance-read cache rework, a high-read-volume caching problem. That is adjacent work, so it can be claimed only as transferable, with its limits named. Closing the gap takes a real project in that area, not a sentence on the CV. Interviewers will test the transfer, so be ready to say where the work carries over and where it doesn't.

## Not written, and why

- **"Distributed systems at scale" as a claim.** The material gives scale and tools, not that you designed distributed systems. R3 holds the honest version.
- **"Mentored mid-level engineers."** The material describes onboarding new hires for their first month. That is a different job, and E6 keeps it as stated.
- **"Partnered with product on roadmap."** Nothing supports it. C1 is the route to evidence.
- **"Designed the cache layer."** The material says "reworking". "Designed" would move the verb up.
- **"Strong incident response."** The adjective is the JD's description of you. Your sentence is six incidents as commander, and E5 keeps that.
- **Any build-cache or developer-tools experience.** None in the material.

## Upgrade menu

- **Your CV file** (.docx or text-layer PDF). This checks every "current line" against your real document and runs the parse-safety check.
- **A roadmap or sequencing example** (C1). Turns R9 from `not_evidenced` into a traced row.
- **A mid-level mentoring example** (C2). Turns R8 from partial into a full row.

## Questions

1. **C1:** Have you ever shaped what the team built next or in what order with someone outside engineering, even informally? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.
2. **C2:** Have you mentored an engineer past their first month, such as a mid-level engineer's growth, a promotion case, or design coaching? Same answer modes.
3. **Q3:** Of your seven years, how many were backend work? Same answer modes.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.