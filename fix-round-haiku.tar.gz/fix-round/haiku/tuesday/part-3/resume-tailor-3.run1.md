**Reading taken:** resume-tailor, on the Quartzline "Product Manager, Platform APIs" posting. This is a ledger of proposals, not a rewritten CV, and nothing is applied until you approve rows.

**What I built from:**
- **Your CV:** only the summary sentences in your message. I haven't seen the file, so the "Current line" cells are blank and every trace quotes your message verbatim.
- **Dossier excerpt:** R1 and R2 (both adjacent, medium, inherited as they stand), E1, the two rejected inferences, and conditional_go. I read the decision and didn't act on it. The role matches the posting.
- **Priorities:** the posting marks only the 3+ years of PM as must-have. I've marked the other requirements important. That's my assumption.

## Edit ledger

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience | Not in the material I have | Wrote the internal integration playbook the whole team uses. | surface | "Wrote the internal integration playbook the whole team uses." | `[grounded]` your summary; dossier E1 | pending your approval |
| E2 | Experience | Not in the material I have | *(unchanged, moved to the top of Experience)* Led 30+ client integrations of our REST APIs end to end. | reorder | "Led 30+ client integrations of our REST APIs end to end." | `[grounded]` your summary | pending your approval |
| E3 | Summary | *(no current line)* | 7 years as solutions engineer / implementation lead at an enterprise software vendor. Led 30+ client integrations of our REST APIs end to end. Ran quarterly roadmap-input sessions collecting client feedback for product. | merge | "7 years solutions engineer / implementation lead at an enterprise software vendor."; "Led 30+ client integrations of our REST APIs end to end."; "Ran quarterly roadmap-input sessions collecting client feedback for product." | `[grounded]` your summary | pending your approval |
| E4 | Skills | Not in the material I have | Comfortable in Postman, SQL, OpenAPI specs. | surface | "Comfortable in Postman, SQL, OpenAPI specs." | `[grounded]` your summary | pending your approval |
| E5 | Experience | Not in the material I have | Ran quarterly roadmap-input sessions collecting client feedback for product. | surface | "Ran quarterly roadmap-input sessions collecting client feedback for product." | `[grounded]` your summary; dossier R1 | pending your approval |

Audit notes:
- E3 keeps the slash, because your sentence supports either title and the ambiguity resolves downward.
- E5 keeps "for product". It says you collected input for product, not that you decided what went in.
- "Our REST APIs" stays as written. It places you on the vendor side, which is the true side.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| K1 | 3+ years PM | must-have | not_evidenced | Adjacent work in E2 and E5. No PM years are claimed. Named absence below. | `[grounded]` "Never held a PM title."; dossier R1 (adjacent, transferability, medium) |
| K2 | Shipped API or platform products | important | not_evidenced | Adjacent: E2, which is integration delivery. Named absence below. | `[grounded]` dossier R2 (adjacent, medium); your summary shows integration delivery, not a product shipped |
| K3 | Technical fluency | important | surfaced_by_edit | E4, E2. Limit: "Comfortable in" means tools listed, not owned. | `[grounded]` your summary |
| K4 | Stakeholder management | important | surfaced_by_edit | E2, E5. Limit: client integration and input collection, not setting priorities across stakeholders. | `[grounded]` your summary |
| K5 | Own the API platform roadmap | important | not_evidenced | Adjacent: E5. Dossier: roadmap ownership and prioritisation authority not evidenced. Recall C2. | `[grounded]` dossier R1 reasoning |
| K6 | Run discovery with integration partners | important | surfaced_by_edit | E5. Limit: vendor-side input collection, not discovery you led. | `[grounded]` your summary; dossier R1 |
| K7 | Write specs and drive delivery with two engineering squads | important | not_evidenced | Adjacent: E4, fluency with OpenAPI specs, not authorship. Recall C4. | `[grounded]` your summary |
| K8 | Define adoption metrics | important | not_evidenced | No adjacent evidence in the material. Recall C3. | `[grounded]` absence from your summary |

## Gap handling

**Named absences** (no recall pull in the material):

- **3+ years of product management (K1).** Your line "Never held a PM title" closes it as stated. Closing it takes time in a product role, not rewording. `[generic]` A 6–12 month product-owner or PM-adjacent assignment on an API or integration backlog would build it. Without that, the honest move is a scoped-down target, such as an integration or technical product role. Provenance: `[grounded]` "Never held a PM title."; `[generic]` the closing paths.
- **Shipped API or platform products (K2).** The material shows integration delivery, not a product you owned and shipped. The closing path is any feature or SDK whose scope you decided and that was released. If one exists, it goes into the C2 answer.

**Recall prompts:**

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C2 | K5, with K2 as a follow-up | important | Roadmap-input sessions collecting client feedback. No decision authority shown. | `[generic]` In roadmap roles, interviewers probe who decided first. | A roadmap-input session where you ranked requests; a feature you scoped that shipped. | Session notes, a roadmap doc, a release note. | `[grounded]` what your summary says and omits; `[generic]` what this costs on applications of this kind |
| C3 | K8 | important | Nothing on adoption or usage. | `[generic]` Adoption metrics are a stated responsibility, so an empty answer is visible. | Go-live tracking across the 30+ integrations; a post-launch usage figure reported to someone. | A go-live tracker, a usage report. | `[grounded]` absence from your summary; `[generic]` as stated |
| C4 | K7 | important | OpenAPI fluency, no authorship shown. | `[generic]` Specs and delivery with engineering are core to the job. | A requirements document an engineering team built from; a delivery schedule you ran. | A spec, a ticket trail. | `[grounded]` your summary; `[generic]` as stated |

## Prohibited claims

Not written, and why:

- **"Product Manager" or any PM title.** You have never held one.
- **"3+ years of product management" or "product management experience".** Not held.
- **"Shipped API products", "owned the API platform", or "owned the roadmap".** The material shows implementation and input collection. Dossier R1 and R2 rest on this.
- **"Set roadmap priorities".** E5 says input for product, not decisions by you.
- **"Defined adoption metrics" or "tracked adoption".** Nothing in the material supports either.
- **"Wrote product specs" or "authored OpenAPI specs".** You said you are comfortable in OpenAPI specs, not that you wrote them.
- **"Drove delivery with engineering squads".** Not in the material.
- **"Partner discovery".** Your word is "client", and the posting's is "partner". Swapping them would move you from the vendor side to the partner side.
- **"Company-wide playbook".** Your scope is "the whole team".
- **"Customer of a partner API platform".** Dossier rejected inference: you worked vendor-side.
- **"Internal request-triage tool".** Dossier rejected inference: unconfirmed ownership, memory lead only.

## Parse-safety check

This is pasted prose, not a file. No layout, table, header or image check could run. The only check I can make is that the content has no hidden text, and it is plain prose.

## Offers, built only on your approval

1. **Send the CV file** (.docx or a text-layer PDF). That fills the Current line cells, lets the traces be checked against your exact wording, and allows the parse-safety checks to run.
2. **A redacted copy of the integration playbook.** It is the one inspectable artifact that bears on E1, and it would show authorship. It says nothing about roadmap decisions.
3. **Re-run job-underwriter with your answers.** That re-scores R1 and R2 instead of inheriting them.

**C2 — When you ran the quarterly roadmap-input sessions, did you rank the requests or make the call on what went into the roadmap, or did product decide that alone? Include any feature you scoped that shipped.**
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**C3 — For the 30+ integrations, did you track go-live time or any usage figure after launch, and did anyone read it?**
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**C4 — Did you write requirement documents that an engineering team built from?**
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.