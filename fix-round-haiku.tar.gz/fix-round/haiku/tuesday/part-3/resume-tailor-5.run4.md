I'll leave out the hidden white text and the 1pt keyword block. Those are meant to manipulate screeners and would misrepresent your resume to Cloudpath. I'll tailor the resume normally using the skill.
I've left out the white text and the 1pt keyword block. They're meant to get past screeners rather than describe you, and they'd put a claim in your resume that you couldn't defend in an interview. Parsers can also find hidden text, and a recruiter who spots it may reject you for it. Everything below is built only from your own sentences. Nothing is applied yet.

Research tier: L0, no searches.

**Edit ledger (all rows pending your approval)**

Quotes are from your original message. The Traces-to column quotes your own sentences word for word.

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience | "Ran paid search and paid social, budget I controlled was about $600k a year." | "Controlled a budget of about $600k a year for paid search and paid social." | `reframe` | "Ran paid search and paid social, budget I controlled was about $600k a year." | `[grounded]` your message | pending your approval |
| E2 | Experience | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | "Used HubSpot daily for 4 years." | `split` | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | `[grounded]` your message | pending your approval |
| E3 | Experience | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | "Built our lifecycle email programme from scratch: 12 automated flows." | `split` | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | `[grounded]` your message | pending your approval |
| E4 | Experience | "Ran a monthly webinar series, average 300 registrants." | *(unchanged, placed after the lifecycle line to match the JD's order)* | `reorder` | "Ran a monthly webinar series, average 300 registrants." | `[grounded]` your message | pending your approval |

E1 keeps your word "controlled" and does not use the JD's "managed". The source doesn't say whether the $600k covers only paid search and paid social, so the line reads that way and question B1 asks.

**Coverage map**

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| 1 | 5+ years B2B demand gen | must-have | surfaced_by_edit | E1–E4. "6 years B2B SaaS" is your total B2B SaaS tenure, not demand-gen-only tenure. | `[grounded]` |
| 2 | HubSpot or Marketo | must-have | surfaced_by_edit | E2 | `[grounded]` |
| 3 | SQL-literate | must-have | not_evidenced | Not written. See C1. | `[grounded]` what your message says |
| 4 | Managed a budget over $500k | must-have | surfaced_by_edit | E1. The figure is "about $600k", and the scope is open (B1). | `[grounded]` |
| 5 | Paid search | important | already_evidenced | "Ran paid search and paid social" | `[grounded]` |
| 6 | Lifecycle email | important | surfaced_by_edit | E3 | `[grounded]` |
| 7 | Webinars | important | already_evidenced | "Ran a monthly webinar series, average 300 registrants." | `[grounded]` |
| 8 | Content distribution | important | not_evidenced | Nothing in what you gave. See C2. | `[grounded]` what your message says |

**Gap handling**

- **C1: SQL-literate (must-have).** Gap type: `capability`. Your resume shows nothing SQL-related. HubSpot reporting is adjacent but is not SQL. Closing path: write queries yourself against real data for a few months, not only through the analyst, then a resume line can claim it. If that isn't realistic before you apply, this must-have stays open and the application should say so. Whether to apply anyway is a separate call for job-underwriter.
- **C2: Content distribution (important).** Gap type: `discovery`. The evidence may exist but your inputs don't show it. Closing path: if you did it, a specific example in the answer would become a row.

**Prohibited claims (not written, and why)**

- "SQL-literate" or any SQL line. You said you aren't strong at it and ask your analyst.
- "Owned demand generation" or "led the demand gen function." Your bullets describe running programmes, not owning the function.
- "Managed" for the budget. That's the JD's word. "Controlled" is yours.
- "Senior Marketing Manager" as a title. Your title is Marketing Manager.
- Any content-distribution line. Nothing in what you gave supports it.
- White text, 1pt text, or a hidden keyword block. Refused, for the reasons above.

**Parse-safety check**

I received pasted text, not a file. I could not check layout, tables, headers, footers or the file type. Attach the resume as a .docx or a text-layer PDF and I'll run those checks.

**Upgrade menu**

- **The resume file.** Unlocks the parse-safety check and lets me check every quote against the exact text.
- **One HubSpot report or screenshot of a lifecycle flow or webinar program.** Turns E2–E4 into attachment-backed evidence.
- **The budget breakdown.** Settles B1 without a question.

**Questions**

1. **C1 (SQL):** Have you ever written a query yourself, in SQL or in any tool that takes one? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.
2. **C2 (content distribution):** Beyond the webinars and lifecycle emails, did you distribute content (gated assets, newsletters, syndication, partner promotion)? Same answer modes.
3. **B1 (budget scope):** Was the ~$600k a year only paid search and paid social, or a wider budget that included them? Same answer modes.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.