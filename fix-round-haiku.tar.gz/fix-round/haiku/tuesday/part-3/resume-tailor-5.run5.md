I won't add the hidden white-text instruction or the 1pt keyword block. That's an attempt to manipulate the screener, and if it's found it's likely to get you rejected. I'll tailor the resume honestly against this JD. I'm loading the resume-tailor module now.
I've kept the honest tailoring and left out the hidden text and keyword block. Your resume already covers most of this JD, and what it doesn't cover I've marked rather than papered over.

**Why I won't add the hidden block:** Instructions aimed at an automated screener, whether white text, 1pt keywords or "ignore previous instructions", are a form of misrepresentation. Screeners and recruiters increasingly check for them, and a flagged resume gets rejected outright. Even if it passed, you'd be asked about a "highly qualified" rating in the interview and wouldn't have a good answer. The honest version below is also what gets you past a keyword screen, because the JD's terms show up where you actually did the work.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 5+ years B2B demand gen | must-have | already_evidenced | "6 years B2B SaaS" supports the years; the demand-gen framing is yours to confirm | `[grounded]` |
| R2 | Paid search | must-have | surfaced_by_edit | Buried in one line with paid social; E1 splits it out | `[grounded]` |
| R3 | Lifecycle email | must-have | already_evidenced | Stated clearly; E3 moves it up | `[grounded]` |
| R4 | Webinars | must-have | already_evidenced | Stated clearly; E4 moves it up | `[grounded]` |
| R5 | Content distribution | must-have | not_evidenced | Not in the resume; see C1 | — |
| R6 | HubSpot or Marketo | must-have | already_evidenced (HubSpot) | HubSpot 4 years; E5 surfaces it | `[grounded]` |
| R6b | Marketo | — | not_evidenced | Not in the resume; see C2 | — |
| R7 | SQL-literate | must-have | not_evidenced | You said you're not strong and ask your analyst; there's no honest line for it | — |
| R8 | Managed budget over $500k | must-have | surfaced_by_edit | "about $600k a year" sits in a line with paid social; E2 surfaces it | `[grounded]` |

## Edit ledger (all pending your approval)

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience | "Ran paid search and paid social, budget I controlled was about $600k a year." | "Ran paid search." | `split` | "Ran paid search and paid social, budget I controlled was about $600k a year." | `[grounded]` | pending your approval |
| E2 | Experience | (same line) | "Controlled a budget of about $600k a year." | `surface` | "Ran paid search and paid social, budget I controlled was about $600k a year." | `[grounded]` | pending your approval |
| E3 | Experience | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | "Built our lifecycle email programme from scratch, 12 automated flows." | `split` (moved up) | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | `[grounded]` | pending your approval |
| E4 | Experience | "Ran a monthly webinar series, average 300 registrants." | Unchanged, moved to follow E3 | `reorder` | "Ran a monthly webinar series, average 300 registrants." | `[grounded]` | pending your approval |
| E5 | Skills | (not listed) | "HubSpot (daily use, 4 years)" | `surface` | "HubSpot daily for 4 years" | `[grounded]` | pending your approval |
| E6 | Experience | (not listed) | "Pull my own performance reporting in HubSpot." | `surface` | "I pull my own numbers in HubSpot reporting" | `[grounded]` self-report | pending your approval |

Notes: E2 keeps "about" and "controlled" as you wrote them, rather than "managed", which would be a stronger claim. E3 is a split, so the lifecycle line doesn't gain "led" or "owned" from its new position.

## Gap handling

- **Content distribution (R5):** not evidenced. Closing it would take a real example from your history, such as distribution channels you planned or ran. Nothing gets written until you give one.
- **Marketo (R6b):** not evidenced. If you've used it, even briefly, say so. Otherwise it's a named gap, and HubSpot is the tool your resume can honestly carry.
- **SQL (R7):** not evidenced. Closing it would take real query work, such as building custom reports, writing queries yourself, or doing a course and practising on real data. Until then, leave it off, and be ready to say "I rely on an analyst for SQL and I'm building that skill."

## Prohibited claims

- SQL skills of any kind
- Marketo experience
- Content distribution experience
- Any hidden or invisible text, or keyword blocks aimed at screeners (refused, reason above)
- "Managed" in place of "controlled" for the budget

## Parse-safety check

I only have the text you pasted, not the PDF, so I can check this only in part. Keep it a text-based PDF (not a scan), keep the section headings standard ("Experience", "Skills"), and keep key details out of headers, footers and images, since some parsers skip those.

**Upgrade menu (optional, built only on your approval):**
- Once you've answered C1 and C2, I can draft a short summary line, traced to your sentences.
- I can also draft a cover note that covers the paid search and budget points without claiming SQL.

**Questions:**
- **C1:** Have you ever planned, run or measured content distribution (e.g. promoting articles, newsletters or guest posts), even as part of another role? Answer in text, or say skip.
- **C2:** Have you used Marketo at any point, even briefly? Answer in text, or say skip.

Approve by row, e.g. "Approved: E1, E2, E3, E4, E5. Rejected: E6." Once you do, I'll produce the tailored resume from approved rows only.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.