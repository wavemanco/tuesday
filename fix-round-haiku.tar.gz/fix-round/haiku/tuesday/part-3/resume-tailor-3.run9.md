I built the ledger from the CV summary and the dossier excerpt in your message. I couldn't open the attached `tuesday-dossier.md` itself, so I worked from the excerpt. Nothing is applied yet. Every row needs your approval, and the tailored CV comes only after you approve rows.

## Edit ledger

Your pending dossier edit (E1) is included and re-audited. Each row traces to your own sentences.

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience | "Wrote the internal integration playbook the whole team uses." | Its own bullet, not folded into a list: "Wrote the internal integration playbook the whole team uses." | `surface` | "Wrote the internal integration playbook the whole team uses." | `[grounded]` cv | pending your approval |
| E2 | Summary (new) | *(no current line)* | "7 years as solutions engineer / implementation lead at an enterprise software vendor. Led 30+ client integrations of our REST APIs end to end. Ran quarterly roadmap-input sessions collecting client feedback for product." | `merge` | "7 years solutions engineer / implementation lead at an enterprise software vendor."; "Led 30+ client integrations of our REST APIs end to end."; "Ran quarterly roadmap-input sessions collecting client feedback for product." | `[grounded]` cv | pending your approval |
| E3 | Skills | "Comfortable in Postman, SQL, OpenAPI specs." | Its own Skills line directly under the summary: "Comfortable in Postman, SQL, OpenAPI specs." | `surface` | "Comfortable in Postman, SQL, OpenAPI specs." | `[grounded]` cv | pending your approval |

Audit notes:
- **E1:** No drift. "whole team" is your own scope.
- **E2:** Kept as three sentences, not one clause. Joined into one clause, the roadmap sessions could read as roadmap ownership. "Led" stays "Led", and "vendor-side" stays vendor-side.
- **E3:** "Comfortable" stays. It is not "proficient" or "expert". OpenAPI here means reading and using specs, not writing product specs.

## Coverage map

Priority is my call where the posting doesn't tag it. Only the PM years line is marked must-have. The rest I've treated as important.

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| 1 | 3+ years PM | must-have | not_evidenced | No PM title. Adjacent work sits in E2 (client integrations, roadmap input). Dossier grades it adjacent, transferability, medium. | `[grounded]` cv: "Never held a PM title." |
| 2 | Shipped API or platform products | important | not_evidenced | Adjacent: E2 (30+ integrations of our REST APIs). That is integration delivery, not a shipped product. | `[grounded]` cv |
| 3 | Technical fluency | important | surfaced_by_edit | E3 | `[grounded]` cv |
| 4 | Stakeholder management | important | surfaced_by_edit | E2 (client integrations end to end; feedback sessions with clients). The CV shows client-facing work but never names stakeholder management, so the reader has to infer it. | `[grounded]` cv |
| 5 | Discovery with integration partners | important | surfaced_by_edit | E2 (roadmap-input sessions). Written as "clients", the CV's word, not the posting's "partners". | `[grounded]` cv |
| 6 | Own the roadmap | important | not_evidenced | Roadmap sessions collected input for product. They are not decisions. | `[grounded]` cv |
| 7 | Write specs and drive delivery with engineering squads | important | not_evidenced | Adjacent: E1 and the OpenAPI familiarity. No product specs or squad delivery appear. | `[grounded]` cv |
| 8 | Define adoption metrics | important | not_evidenced | Nothing in the CV. | `[grounded]` cv |

## Gap handling

- **Row 1, PM years:** Recall prompt C1 below. Named absence: the PM-years requirement cannot be claimed from this CV. Closing it would take a PM-titled role, or a scoped-down target such as an integrations or technical product role, where the adjacent work counts.
- **Row 2, shipped products:** Recall prompt C2 below.
- **Row 6, roadmap ownership, and Row 7, specs and squads:** Named absences. For the roadmap, the honest version is "input to product", unless C1 surfaces a real decision. For specs and squads, the closing path is one product spec for an integration change, carried through delivery with an engineering team.
- **Row 8, adoption metrics:** Recall prompt C3 below.

## Prohibited claims

Not written, and why:
- **Any PM title, or "Product Manager".** You have never held one.
- **"Owned" or "set" the roadmap, or "prioritised".** Roadmap sessions collected input.
- **"Shipped API or platform products".** The CV shows integrations delivered for clients.
- **"Built an internal request-triage tool".** The dossier rejected this inference. You could not confirm ownership.
- **"Has been the customer of a partner API platform".** The dossier rejected this. You worked vendor-side.
- **"Partners" for clients.** That is the posting's word, not yours.
- **"Wrote product specs" or "led engineering squads".** Neither is in your material.
- **"Defined or tracked adoption metrics".** Not in your material.
- **"Proficient" or "expert" in the tools.** You wrote "comfortable".
- **"Enterprise-wide" playbook.** You wrote "whole team".

## Parse-safety check

You pasted text, not a file, so I could not check layout, tables, headers or hidden text. Nothing in the pasted text looks risky. For the file itself, a `.docx` or a text-layer PDF is the safe pair.

## Upgrade menu

- **Attach the integration playbook**, with confidential detail removed. It is the one inspectable artifact that backs E1, and it would move that row's proof above medium.
- **Paste your full CV text.** I've worked from your summary. The full text would let me set the exact current lines and check bullet order.

## Questions

**C1.** Did you ever decide which integration or API work went into a release, or did you only collect input? Answer in text, paste, attach, drop a link, or say skip.

**C2.** Did any integration work turn into something reusable that others adopted beyond one client, such as an SDK, onboarding flow, sandbox or docs? Same response modes.

**C3.** Did you track any adoption measure for integrations, such as time to first call, time to go-live, or endpoints adopted? Same response modes.

Once you approve or reject rows by ID, I'll produce the tailored CV from the approved rows only.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.