I've built the edit ledger from the dossier excerpt and the CV summary you pasted. Nothing is applied yet. Every row is pending your approval, and the tailored CV comes only after you approve rows. No `tuesday-dossier.md` file is in this workspace, so I took the evidence map, rejected inferences, E1 and the conditional_go decision from your excerpt.

The main constraint: the posting's one must-have is 3+ years of PM, and no edit can supply that. The tailored CV will show adjacent integration leadership, not a product role.

## The edit ledger

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience | *(inside the role description, no line of its own)* | Wrote the internal integration playbook the whole team uses. | `surface` | "Wrote the internal integration playbook the whole team uses." | `[grounded]` CV; dossier E1, re-audited | pending your approval |
| E2 | Experience | Led 30+ client integrations of our REST APIs end to end. | Led 30+ client integrations of our REST APIs end to end. *(moved to the top of the role's bullets)* | `reorder` | "Led 30+ client integrations of our REST APIs end to end." | `[grounded]` CV | pending your approval |
| E3 | Experience | Ran quarterly roadmap-input sessions collecting client feedback for product. | Ran quarterly roadmap-input sessions collecting client feedback for product. *(moved beside E2)* | `reorder` | "Ran quarterly roadmap-input sessions collecting client feedback for product." | `[grounded]` CV | pending your approval |
| E4 | Skills | Comfortable in Postman, SQL, OpenAPI specs. | Comfortable in Postman, SQL, OpenAPI specs. *(surfaced into its own tools line)* | `surface` | "Comfortable in Postman, SQL, OpenAPI specs." | `[grounded]` CV | pending your approval |
| E5 | Summary | *(no current line)* | 7 years solutions engineer / implementation lead at an enterprise software vendor. Led 30+ client integrations of our REST APIs end to end. | `merge` | "7 years solutions engineer / implementation lead at an enterprise software vendor."; "Led 30+ client integrations of our REST APIs end to end." | `[grounded]` CV | pending your approval |

E1 is the dossier's pending edit. I re-audited it rather than inheriting it, and it still traces. E5 is a summary built only from two existing sentences, kept as two clauses. It makes no PM claim and does not say "platform" or "partner".

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 3+ years of product management | must-have | not_evidenced | No PM title held. Adjacent integration leadership is in E2 and E5. Named absence below. | `[grounded]` dossier R1: adjacent, transferability, medium |
| R2 | Shipped API or platform products | important | not_evidenced | Client integrations shipped in E2. No product she owned. | `[grounded]` dossier R2: adjacent, medium |
| R3 | Technical fluency | important | surfaced_by_edit | Tools in E4. | `[grounded]` CV |
| R4 | Stakeholder management | important | surfaced_by_edit | Client feedback sessions in E3. No internal stakeholder management shown. | `[grounded]` CV |
| R5 | Own the roadmap | important | not_evidenced | E3 feeds someone else's roadmap. Dossier: roadmap ownership and prioritisation authority not evidenced. | `[grounded]` dossier R1 reasoning |
| R6 | Run discovery with integration partners | important | not_evidenced | E3 is the nearest match: client feedback, not discovery. | `[grounded]` CV |
| R7 | Write specs and drive delivery with two engineering squads | important | not_evidenced | E1 is process documentation, not product specs. OpenAPI fluency in E4 is a tool, not a spec record. | `[grounded]` CV |
| R8 | Define adoption metrics | important | not_evidenced | Nothing in the CV. | `[grounded]` CV |

Priorities follow the posting. Only the 3+ years line is tagged must-have there, so the responsibilities are marked important.

## Recovery per gap

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | R5 Own the roadmap, also R6 and R2 | important | Client feedback going into product (E3), integrations shipped (E2). No decision of yours shown. | Shows whether you decided what got built or only fed the decision. | Any feature scope or sequencing call on the integrations you led | A roadmap doc, a decision memo, a ticket trail | `[grounded]` what the CV does and does not say; `[generic]` for a platform PM role, the decision record is usually the first thing a hiring manager asks for |
| C2 | R8 Define adoption metrics | important | No measure of adoption shown. | Adoption metrics are one of the four responsibilities. | Go-live times, integrations per quarter, or playbook use on the 30+ integrations | A dashboard, a report, a client status sheet | `[grounded]` absence in the CV; `[generic]` integration go-live timing is a common adoption measure |
| C3 | R7 Write specs and drive delivery with engineering squads | important | Playbook authorship (E1) and OpenAPI fluency (E4). No spec record. | The JD makes spec-writing and delivery the core of the job. | Requirements or specs engineering built against on integrations you led | A spec, a PRD, a sprint review note | `[grounded]` absence in the CV |

**Named absence: R1, 3+ years of product management (must-have).** No edit can supply a PM title, and the CV does not claim one. Closing it would take about six months owning one integration product area's roadmap under a product title, or a role scoped as implementation-to-product. The adjacent work in E2 and E5 supports a transition case, but it does not meet this requirement.

## Not written, and why

- **"Product Manager" or any PM title, or "Product" in a retitled section.** You have never held one.
- **"Owned the platform API roadmap" or "set priorities".** Dossier rejected inference: roadmap ownership and prioritisation authority are not evidenced.
- **"Ran discovery with integration partners".** You ran client feedback sessions for product. "Discovery" and "partners" are the posting's words. "Client" is yours, and the word change would also move which side of the table you sat on.
- **"Customer-side view of a partner API platform".** Dossier rejected inference: you worked vendor-side.
- **"Built an internal request-triage tool".** Dossier rejected inference: ownership could not be confirmed.
- **"Shipped API products".** You delivered integrations to clients, not a product you owned.
- **"Wrote product specs for engineering squads".** You wrote a playbook and are comfortable with OpenAPI specs.
- **"Defined adoption metrics".** Nothing in the CV supports it.

## Parse-safety check

| Check | Result |
|---|---|
| Multi-column layout | Could not run. The CV came as a message summary, not a file. |
| Tables and text boxes | Could not run. |
| Images and icons | Could not run. |
| Contact details in headers or footers | Could not run. Worth checking by hand: contact details in a header or footer can be lost in parsing. |
| Section headings | Could not run. Section names in the ledger are assumed. |
| File type | Could not run. A `.docx` or text-layer PDF is the safe pair. |

## Upgrade menu

- Send the CV as a file, and the layout and parse-safety checks can run on it. The section names in the ledger are assumed until then.
- Once you approve rows, I produce the tailored CV from approved rows only.
- If you want a summary-line variant, I can draft it from approved sentences only.

## Questions

C1 — Describe one decision you shaped about which integration capability or API change got built, even partly: who else weighed in, what you recommended, and whether the team followed it.
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

C2 — Did you track any measure of how clients adopted the integrations or the playbook, such as days to first live call, integrations per quarter, or playbook use?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

C3 — On the integrations you led, did you write the requirements or specs that engineering built against, and how were scope and delivery decisions made with the engineers?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.