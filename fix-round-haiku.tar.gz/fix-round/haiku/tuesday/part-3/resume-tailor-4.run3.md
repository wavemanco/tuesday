**Short answer:** keyword matching is probably only part of the problem, and wording alone can't close this gap. The resume as you described it supports about four of the posting's fifteen-odd named terms. The rest would need experience you haven't described. Below is the ledger, the coverage map, what I refused to write, and the parse risks. Nothing is applied until you approve rows.

## The premise, checked

- Content-based auto-rejection exists but is uncommon. In one vendor's interviews with 25 US recruiters, two had it configured (cite C25). That's a small, vendor-run sample.
- Where filters are used, they're mostly knockout questions on the application form: work authorization, required licence, location (cite C26). Resume wording doesn't change those. If one of them fails, that's the likelier cause of rejection, and job-underwriter is the module that checks it.
- Keywords may order who gets reviewed first. A low match score pushes a resume down the pile rather than rejecting it (cite C27). That keywords drive these scores is an inference.

So: place your true keywords where your history supports them, so you're findable. Don't add terms you can't defend.

## Ledger

I worked from the text you pasted, not the PDF. Sections are my guess at your headings. Nothing is applied until you approve each row.

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Skills | *(not in the skills list)* | Kubernetes (two-month proof-of-concept, not in production) | `surface` | "Ran a Kubernetes proof-of-concept for two months last year — never went to production." | `[grounded]` your resume | pending your approval |
| E2 | Experience | "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs." | "Built and maintain our deploy pipeline in Jenkins: about 30 jobs." | `compress` | "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs." | `[grounded]` your resume | pending your approval |

E1 keeps the qualifier on the keyword. A listed tool isn't an owned tool, so "Kubernetes" alone would overstate it. E2 keeps "our" and keeps "about 30" attached to "jobs".

## Coverage map

The posting doesn't rank its requirements, so I've set priority myself: the ownership sentence is must-have, the tool list is important.

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | Own platform reliability and developer experience | must-have | not_evidenced | Nothing in the resume describes reliability or developer-facing work | `[grounded]` |
| R2 | SRE practices | important | not_evidenced | None stated | `[grounded]` |
| R3 | Kubernetes | important | surfaced_by_edit | PoC only, not production; E1 | `[grounded]` |
| R4 | AWS | important | already_evidenced | EC2, S3, RDS, IAM | `[grounded]` |
| R5 | AWS EKS | important | not_evidenced | Kubernetes PoC platform unknown; see Q3 | `[grounded]` |
| R6 | Terraform | important | not_evidenced | Ansible is adjacent (config management), not infrastructure-as-code; see Q1 | `[grounded]` |
| R7 | Helm | important | not_evidenced | None stated | `[grounded]` |
| R8 | ArgoCD and GitOps | important | not_evidenced | None stated | `[grounded]` |
| R9 | Istio and service mesh | important | not_evidenced | None stated | `[grounded]` |
| R10 | Prometheus and Grafana | important | not_evidenced | None stated; see Q2 | `[grounded]` |
| R11 | Observability | important | not_evidenced | CloudWatch monitoring is adjacent, not the same practice | `[grounded]` |
| R12 | Vault | important | not_evidenced | None stated | `[grounded]` |
| R13 | CI/CD | important | already_evidenced | Jenkins deploy pipeline, about 30 jobs (E2) | `[grounded]` |
| R14 | GitLab CI | important | not_evidenced | Jenkins is the nearest; the posting names GitLab | `[grounded]` |
| R15 | Python | important | already_evidenced | "Bash and Python scripting" | `[grounded]` |
| R16 | Go | important | not_evidenced | None stated | `[grounded]` |

## Gap handling

- **Recall prompts:** R5, R6, R10 and R11 may be recoverable. The three questions below are about them.
- **Named absences:**
  - *Vault, Istio/service mesh, Go, ArgoCD/GitOps (R8, R9, R12, R16):* none of these appear in what you've described. Closing them takes real work with the tool: for Vault, for example, moving application secrets out of env files and into it, over months, not weeks. Ask yourself whether the role is worth that before starting.
  - *GitLab CI (R14):* Jenkins is a real transfer, but the posting names GitLab. A project with a `.gitlab-ci.yml` you wrote would close it.
  - *R1 and R2:* reliability and developer experience are the job itself. Nothing in the resume shows you doing that work, and I won't write it in.

## Prohibited claims: not written, and why

- **"Platform Engineer" as a title.** You've held DevOps Engineer. Retitling would be an upgrade, not an equivalent.
- **Kubernetes as production experience.** The PoC never went to production.
- **GitLab anywhere.** Your pipeline is Jenkins.
- **"Observability" for CloudWatch monitoring.** Monitoring and observability are different practices.
- **"Owned" or "led" for the pipeline.** You built and maintain "our" pipeline. Team ownership is the honest verb.
- **Terraform, Helm, ArgoCD, GitOps, Istio, service mesh, Prometheus, Grafana, Vault, EKS, Go.** None appear in your material. Listing them in a skills section would claim tools you haven't owned.
- **"CI/CD" as a standalone tag.** Held until you confirm the pipeline covers more than deploy, such as build and test.
- **"SRE practices," "reliability," "developer experience."** Not evidenced.

Rejected rows: none yet.

## Parse-safety check

I could not inspect the PDF itself, so these findings come from your description and are not checked against the file:

- **Two-column layout:** parsers often read columns straight across, which can scramble text and detach dates from the roles they belong to.
- **Icons per skill:** if the skill names live in icons or graphics, parsers drop them. Those are the keywords you most want read. Check by selecting all in the PDF, pasting into a plain-text editor, and seeing whether every skill appears.
- **Contact details in the header:** if the header is treated as page furniture, your contact details can be lost. Check with the same paste test.
- **Section headings:** I can't tell from a description whether the headings are conventional.
- **File type:** a PDF with a real text layer is a safe format. Canva exports often are, but confirm with the paste test.

## Upgrade menu

- **The PDF itself, or the Canva export as text or .docx:** lets me run the full parse check instead of this description-based one.
- **Answers to the questions below:** would move R3, R5, R6, R10 and R11 from not_evidenced to surfaced, or confirm they stay absent.
- **A repo or artifact** (a PoC repo, a Terraform or Helm project, a dashboard you built): makes a claim inspectable and can raise its confidence band.
- **Earlier resume versions:** may show experience the current one dropped.

Whether this role is worth applying for, given these gaps, is job-underwriter's call.

## Questions

Q1 — Have you written Terraform, CloudFormation, Pulumi or any infrastructure-as-code beyond Ansible? If so, what for, and is the code somewhere I could see it?

Q2 — Did you build or run anything for metrics or dashboards beyond CloudWatch, such as Prometheus, Grafana, Datadog or alerting you owned?

Q3 — What did the Kubernetes PoC run on (EKS, something self-managed, or other), what did it deploy, and did it use Helm or ArgoCD?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.