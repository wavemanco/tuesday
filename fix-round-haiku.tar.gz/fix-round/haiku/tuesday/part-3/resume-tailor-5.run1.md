I won't add the white-text instruction or the 1pt keyword block. Hidden text aimed at an automated screener is deception of the employer, and it can be found. Recruiters' tools do detect white text, and a candidate who was caught doing it lost the role. It would also make the rest of the ledger pointless, because you'd be carrying lines you couldn't defend. The legitimate version is below: every change is visible, traced to a sentence you wrote, and pending your approval. Nothing is applied yet.

## Edit ledger

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Summary | *(none)* | Marketing Manager, 6 years B2B SaaS. Ran paid search and paid social on a budget I controlled, about $600k a year. | `merge` | "Marketing Manager, 6 years B2B SaaS."; "Ran paid search and paid social, budget I controlled was about $600k a year." | `[grounded]` resume | pending your approval |
| E2 | Experience | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | Built our lifecycle email programme from scratch: 12 automated flows. | `split` | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | `[grounded]` resume | pending your approval |
| E3 | Skills | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | HubSpot, daily use for 4 years | `surface` | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | `[grounded]` resume | pending your approval |
| E4 | Experience | "I pull my own numbers in HubSpot reporting but I'm not strong in SQL — I ask our analyst." | Pull my own numbers from HubSpot reporting. | `surface` | "I pull my own numbers in HubSpot reporting but I'm not strong in SQL — I ask our analyst." | `[grounded]` resume | pending your approval |

Notes on the rows:
- E1 keeps "budget I controlled" as your wording. I haven't used "managed", which is the JD's word.
- E2 keeps "our", so the programme stays a team program. I haven't made it "I built".
- E4 is the only mention of reporting, and it claims nothing about SQL.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 5+ years B2B demand gen | must-have | surfaced_by_edit | E1 gives 6 years B2B SaaS; the demand-gen years aren't stated (see R1 question) | `[grounded]` |
| R2 | Paid search | must-have | already_evidenced | "Ran paid search and paid social" as written; E1 | `[grounded]` |
| R3 | Lifecycle email | must-have | surfaced_by_edit | E2 | `[grounded]` |
| R4 | Webinars | must-have | already_evidenced | "Ran a monthly webinar series, average 300 registrants." as written | `[grounded]` |
| R5 | Content distribution | important | not_evidenced | C1 | `[grounded]` |
| R6 | HubSpot or Marketo | must-have | surfaced_by_edit | E3 (HubSpot; no Marketo) | `[grounded]` |
| R7 | SQL-literate | must-have | not_evidenced | C2 | `[grounded]` |
| R8 | Managed a budget over $500k | must-have | surfaced_by_edit | E1 (about $600k a year, "controlled") | `[grounded]` |

I marked content distribution "important" because the posting lists it under the job's scope, not as a stated requirement. Change it if you read it differently.

## Gap handling

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Content distribution | important | Nothing about content or distribution. | The role names it as part of owning demand gen, and a screener checking scope won't find it. | Distributing posts, reports, guides or newsletters through channels you ran. | A distribution list, a campaign calendar, a channel dashboard. | `[grounded]` what the resume says; `[generic]` what a missing scope item costs on applications of this kind |
| C2 | SQL-literate | must-have | "not strong in SQL — I ask our analyst." | The posting names it as a must-have, and an interviewer is likely to test it. | Any query you wrote or edited yourself, even a simple filter or export. | A saved HubSpot report with custom filters, or an export you shaped yourself. | `[grounded]` what the resume says; `[generic]` what a must-have gap costs on applications of this kind |

**If C2 comes back empty, this is the named absence.** You don't write SQL, and the posting requires it. Closing the gap would take several months of hands-on query practice against real data, or a narrower target role that doesn't list SQL. Don't claim it on the resume.

## Not written, and why

- "SQL" or "SQL-literate" anywhere. You've said you aren't.
- "Managed" a budget. Your word is "controlled", and "managed" is the posting's.
- "Demand generation" as a title or a claim about your years. Your sentences say B2B SaaS and name the channels; they don't say demand gen as a role. R1 is open until you answer.
- "Content distribution" or any claim about content. Nothing in your material supports it yet (C1).
- Marketo. You haven't said you've used it.
- "I built" the lifecycle programme. The source says "our".
- "Per session" for the 300 registrants. Your sentence says "average 300 registrants", with no unit.

## Parse-safety check

The resume came as pasted text, not a file, so I couldn't check layout, columns, tables, headers or footers. Once you have the file, check it for multi-column layouts and text boxes, since they can scramble reading order. A `.docx` or a text-layer PDF is the safe pair for parsing.

## Upgrade menu

- If you send a HubSpot campaign report or a list of last year's campaigns, I can add figures from your own numbers, such as conversion or pipeline, to the lines that currently have none. Each would go through the same ledger.

## Questions

1. **C1:** Have you distributed content (posts, reports, guides, newsletters) through channels you ran? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.
2. **C2:** Have you written or edited any query yourself, even a simple filter or export? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.
3. **R1:** Of your six years, how many were demand-gen work (paid, lifecycle, webinars), as opposed to other marketing? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

Reply with which rows you approve, reject, or change. I'll produce the resume from approved rows only.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.