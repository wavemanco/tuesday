**Short answer:** keyword matching is probably not the main cause, and no rewording will fix the biggest gap. Most of this JD's stack isn't in your resume, and the two-column Canva layout can hide what is there. Nothing below is applied yet. Every row is pending your approval.

**What's likely rejecting you**

- Automated content rejection exists but is uncommon. In one vendor's interviews with 25 recruiters, 2 used it (cite C25).
- Knockout questions on the application form (work authorization, required licence, location) most often reject people without a person looking (cite C26). Check those answers before you spend more time on the resume.
- Match scores mostly set the review order. A low score can push you to the bottom of the pile (cite C27).
- Your resume is missing most of the JD's named stack, and the Kubernetes line says it never reached production. A keyword pass can't honestly change that.

**Parse-safety check**

I haven't seen the PDF, so this runs on your description.

| Check | What breaks | What it costs | Observed |
|---|---|---|---|
| Multi-column layout | Parsers read across columns, so text interleaves | Dates detach from the roles they belong to | Yes, two columns |
| Icons for skills | Icons are skipped or become garbage characters | The skills they carry may vanish | Yes, an icon per skill |
| Contact details in header | Headers are often discarded as page furniture | You could become unreachable | Yes, contact in header |
| Canva PDF text layer | Some exports are image-only | Nothing parses | Not checked. Test: select all in a PDF reader and paste into a text file. If the text comes out in reading order, the layer is there |
| Section headings | Unconventional labels aren't detected | Sections go missing | Not checkable without the file |

Whether single column looks better is a design call, and I'm not making it. The parse risks are the reason to change the layout.

**Research tier: L0, no searches.**

**Coverage map**

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| 1 | Kubernetes in production | must-have | not_evidenced | Two-month PoC, which the resume says never went to production | [grounded] resume |
| 2 | AWS EKS | must-have | not_evidenced | No EKS line; the PoC doesn't say what it ran on | [grounded] absence in resume |
| 3 | Terraform | must-have | not_evidenced | Adjacent only: Ansible for config management, which is not provisioning | [grounded] resume; transferability |
| 4 | ArgoCD / GitOps | must-have | not_evidenced | No adjacent evidence | [grounded] absence in resume |
| 5 | Observability | must-have | not_evidenced | Adjacent: CloudWatch for monitoring | [grounded] resume |
| 6 | SRE practices / reliability | must-have | not_evidenced | Nothing stated | [grounded] absence in resume |
| 7 | Developer experience | must-have | not_evidenced | Adjacent: about 30 Jenkins jobs, users not stated | [grounded] resume |
| 8 | CI/CD | must-have | surfaced_by_edit | Jenkins deploy pipeline; L2 names it CI/CD | [grounded] resume |
| 9 | CI/CD (GitLab) | important | not_evidenced | Jenkins only; GitLab not named | [grounded] absence in resume |
| 10 | Helm | important | not_evidenced | Nothing stated | [grounded] absence in resume |
| 11 | Istio / service mesh | important | not_evidenced | Nothing stated | [grounded] absence in resume |
| 12 | Prometheus / Grafana | important | not_evidenced | Adjacent: CloudWatch | [grounded] resume |
| 13 | Vault | important | not_evidenced | Adjacent only: AWS IAM, which is access control, not secrets management | [grounded] resume |
| 14 | Go | important | not_evidenced | Nothing stated | [grounded] absence in resume |
| 15 | Python | important | already_evidenced | "Bash and Python scripting" | [grounded] resume |
| 16 | AWS | must-have | already_evidenced | EC2, S3, RDS, IAM | [grounded] resume |

The JD doesn't tier its list. I've marked the platform core as must-have and the rest as important. Re-tier it if you see the role differently.

**Edit ledger**

I've left the Kubernetes line as it is. "Never went to production" is what makes it true.

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| L1 | Skills (new text block) | Icons only | "Skills: AWS (EC2, S3, RDS, IAM), Docker, Jenkins, Ansible, CloudWatch, Bash, Python" | `surface` | "AWS (EC2, S3, RDS, IAM), Docker, Jenkins, Bash and Python scripting, Ansible for config management, CloudWatch for monitoring" | [grounded] your description | pending your approval |
| L2 | Experience | "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs." | "Built and maintain our CI/CD deploy pipeline in Jenkins: about 30 jobs." | `reframe` | "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs." | [grounded] your description | pending your approval |

L2 is the one to check. "CI/CD" names the same activity, but it's a term an interviewer will ask you to define. Approve it only if you'd use that word for your own pipeline.

**Recovery per gap**

These rows carry no questions. The closing block asks them.

| # | Requirement | Priority | What the resume shows | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|
| C1 | Kubernetes in production, AWS EKS | must-have | A two-month PoC, not production | The PoC, if it ran on EKS or served anything beyond you | PoC repo, notes, or diagram | [grounded] resume |
| C2 | Terraform, ArgoCD / GitOps, Helm | must-have | Ansible only | Any infrastructure-as-code in work or side projects | Terraform, Helm, or Argo CD files, scrubbed | [grounded] resume |
| C3 | Observability, SRE, developer experience | must-have | CloudWatch monitoring; about 30 Jenkins jobs | Alerts, on-call, or a service others depended on; pipeline changes made for developers | Alarm or dashboard screenshot | [grounded] resume |

**Named absences** (nothing to pull; closing paths given)

- **Istio / service mesh:** nothing adjacent. Closing it takes hands-on time with a mesh on a sandbox cluster, which you could show in a repo. Otherwise treat it as a gap.
- **Prometheus / Grafana:** adjacent to CloudWatch only. A sandbox stack you can show would close it.
- **Vault:** AWS IAM isn't secrets management. A small project with a secrets store would close it.
- **Go:** nothing stated. A small Go tool you can link would close it.
- **GitLab CI:** transferable from Jenkins, not the same tool. One GitLab pipeline in a project closes it.

**Prohibited claims: not written, and why**

- **"Kubernetes in production" or "ran Kubernetes clusters":** the PoC never went to production, and the JD asks for production work.
- **"Platform Engineer" as your title:** you've held DevOps Engineer. Retitling is an upgrade.
- **EKS, Terraform, ArgoCD, GitOps, Helm, Istio, Prometheus, Grafana, Vault, GitLab, Go:** none appear in your resume. A tool listed is a tool owned.
- **"Terraform" implied by "Ansible for config management":** config management and provisioning are different work.
- **"Observability":** that's the JD's word. Your line says "CloudWatch for monitoring".
- **"Owned platform reliability" or "served developers":** the JD describes the role. Your sentences don't say you owned reliability or served developers.
- **A hidden keyword block in white or tiny text:** refused. It deceives the screener, and it can be detected.

**Upgrade menu**

- A PoC repo, notes, or diagram. Unlocks C1, and would show whether EKS was involved.
- An anonymised Jenkinsfile or job config. Gives L2 an inspectable artifact.
- A scrubbed CloudWatch alarm or dashboard screenshot. Strengthens the observability adjacency.
- Terraform, Helm, or Argo CD files from any project. Unlocks C2.
- A previous resume version. It may hold evidence the current one dropped.

Given these gaps, job-underwriter can tell you whether this role is worth applying to before you put more work into the resume.

**Questions**

1. Did your Kubernetes proof-of-concept run on AWS EKS, and was it a cluster you were responsible for?
2. Have you written Terraform, Helm charts or Argo CD configs, in work or a side project?
3. Have you ever owned alerts, on-call, or a service other teams depended on, or changed a pipeline because developers asked?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.