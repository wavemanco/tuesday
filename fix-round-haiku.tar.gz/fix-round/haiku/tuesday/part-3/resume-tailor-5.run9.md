I've left out the hidden text and the 1pt keyword block. Hidden text meant to steer an automated screener is deception aimed at the employer, and it's also detectable: some screening software flags white or tiny text, and at least one candidate reported being turned down for it. Here is the tailored resume as a ledger. Nothing is applied until you approve each row.

**Two corrections to the premise:** what most often rejects applicants without a person reading is knockout questions on the application form, such as work authorization or required certifications. Keywords may affect ranking, but they can't make a claim true. Your real keywords are already in your resume, so the goal is to make them easy to find.

## Edit ledger (all rows pending your approval)

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Summary (new) | *(none)* | "Marketing Manager, 6 years in B2B SaaS. Ran paid search and paid social, built lifecycle email from scratch (12 automated flows), and ran a monthly webinar series averaging 300 registrants." | merge | "Marketing Manager, 6 years B2B SaaS"; "Ran paid search and paid social"; "built our lifecycle email programme from scratch, 12 automated flows"; "Ran a monthly webinar series, average 300 registrants" | `[grounded]` resume | pending your approval |
| E2 | Experience | "Ran paid search and paid social, budget I controlled was about $600k a year." | "Controlled a budget of about $600k a year across paid search and paid social." | split | "Ran paid search and paid social, budget I controlled was about $600k a year." | `[grounded]` resume | pending your approval |
| E3 | Experience | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | "Used HubSpot daily for 4 years." | split | "HubSpot daily for 4 years" | `[grounded]` resume | pending your approval |
| E4 | Experience | *(same line as E3)* | "Built our lifecycle email programme from scratch: 12 automated flows." | split | "built our lifecycle email programme from scratch, 12 automated flows" | `[grounded]` resume | pending your approval |

I kept "controlled" rather than the posting's "managed," because that's your word. I also kept "about" on the $600k.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| 1 | 5+ years B2B demand gen | must-have | surfaced_by_edit | E1 states 6 years in B2B SaaS and the channels. Whether all six were demand gen is not stated (see Q3). | `[grounded]` resume |
| 2 | HubSpot or Marketo | must-have | surfaced_by_edit | E3. Four years of daily HubSpot use is currently buried in the lifecycle sentence. | `[grounded]` resume |
| 3 | SQL-literate | must-have | not_evidenced | Named absence below. | `[grounded]` your statement that you aren't strong in SQL |
| 4 | Managed a budget over $500k | must-have | surfaced_by_edit | E2. The figure is currently a clause at the end of a bullet. | `[grounded]` resume |
| 5 | Paid search | important | already_evidenced | Stated as written. | `[grounded]` resume |
| 6 | Lifecycle email | important | already_evidenced | Stated as written; E4 gives it its own line. | `[grounded]` resume |
| 7 | Webinars | important | already_evidenced | Stated as written. | `[grounded]` resume |
| 8 | Content distribution | important | not_evidenced | Recall prompt C1 below. | `[grounded]` the resume does not mention it |

**Named absence: SQL.** Your resume doesn't show SQL, and you've said you're not strong in it. The posting lists it as a must-have, not a plus, so it's a real gap that a recruiter screen will probably test. To close it, you'd need something you can point to, such as a few weeks of focused SQL practice on real campaign data, ideally writing one query yourself and having the analyst review it. If that can't happen before you apply, the honest choice is to apply only if the screen doesn't hinge on it, or to pass. Whether this gap blocks the application outright is job-underwriter's call.

**Recall prompt C1 (content distribution)**

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Content distribution | important | Nothing. Webinars and lifecycle email are covered, but no content distribution is stated. | The posting names it as part of the demand-gen scope, so its absence is visible on one read. | Gated assets pushed through paid social; content shared through partner newsletters; a blog or newsletter distribution programme | Campaign briefs, channel-level lead counts, distribution reports | `[grounded]` what the resume does and does not say; `[generic]` that screeners scan for named channels |

## Not written, and why

- "Owned demand generation" or "owned the demand gen function." You ran channels, and "owned" claims more than that.
- "SQL," "SQL-literate," or "queried data." You've said you're not strong in SQL and rely on the analyst.
- "Content distribution." It isn't in your sentences.
- "Demand generation" as a label for your role. Your title is Marketing Manager, so I'd only use this if your job was called that.
- Pipeline, revenue, or conversion figures. None are in your resume.
- "Enterprise" or "company-wide" scope. Nothing you wrote claims it.

## Parse-safety check

You pasted the resume as text, so I couldn't check the file's layout, headers, footers, or any hidden text it may contain. Check your original file for white or tiny text left over from a template or an older tool, and remove any you find. If it's a `.docx` or a text-layer PDF, parsing is usually safe.

## Upgrade menu

- A HubSpot report export or screenshot showing the webinar registrants or lifecycle flows would become a stronger grounded attachment.
- Your answer to C1 would turn that row into a real bullet.

## Questions

1. **C1:** Did you distribute content in any way (gated assets, partner newsletters, a blog or newsletter programme)? Answer in text, attach a document, or say skip.
2. Is the ~$600k for paid search and paid social only, or your wider marketing budget? E2 depends on it.
3. Were all six years in demand generation, or did some sit in other marketing work? This affects the 5+ years line.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.