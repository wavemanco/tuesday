I can't put the hidden text or the invisible keyword block in your resume. Those are instructions aimed at an automated screener, and the screener is acting for the employer, so it's deception of the employer. It also contradicts the point of tailoring, which is that you can defend every line. Hidden text is also detectable: some platforms report finding white text in résumés, and one candidate was turned down after a recruiter found his. The version that works is the honest one: make sure the real keywords you already have appear early and in plain text.

I've tailored the resume from your text only. You pasted it rather than sending a file, so I could not check layout, tables, or headers. Send it as a .docx or a text-layer PDF and I'll run the parse-safety check.

**Edit ledger** (all rows pending your approval; nothing is applied)

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| R1 | Experience | Ran paid search and paid social, budget I controlled was about $600k a year. | Controlled a budget of about $600k a year for paid search and paid social. | reframe | "Ran paid search and paid social, budget I controlled was about $600k a year." | `[grounded]` resume | pending your approval |
| R2 | Experience | HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows. | Built our lifecycle email programme from scratch in HubSpot: 12 automated flows, used daily for 4 years. | reframe | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | `[grounded]` resume | pending your approval |
| R3 | Experience | Ran a monthly webinar series, average 300 registrants. | Ran a monthly webinar series, average 300 registrants. (moved up, after R2) | reorder | "Ran a monthly webinar series, average 300 registrants." | `[grounded]` resume | pending your approval |

Ordering R1 to R3 first puts the three demand-gen channels the JD names at the top. The budget figure keeps "about", so it doesn't claim more than you said. I kept "controlled" rather than "managed" because "controlled" is your word.

**Coverage map**

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| 1 | Paid search | must-have | already_evidenced | R1 | `[grounded]` |
| 2 | Lifecycle email | important | already_evidenced | R2 | `[grounded]` |
| 3 | Webinars | important | already_evidenced | R3 | `[grounded]` |
| 4 | HubSpot | must-have | already_evidenced | R2 (4 years daily) | `[grounded]` |
| 5 | Managed budget over $500k | must-have | already_evidenced | R1 ("about $600k"; "about" stays) | `[grounded]` |
| 6 | 5+ years B2B demand gen | must-have | already_evidenced | Resume shows 6 years B2B SaaS. Demand-gen years aren't stated; see Q2 | `[grounded]` |
| 7 | Content distribution | important | not_evidenced | Not in resume; see C1 | `[grounded]` what the resume says |
| 8 | SQL literacy | must-have | not_evidenced | Named absence below | `[grounded]` what you told me |

**Gap handling**

- **C1 (content distribution, important):** the resume doesn't mention distributing content. If you did, the evidence would be things like: did you plan and run distribution for blog posts, gated assets or social amplification, and what did it produce?
- **SQL literacy (must-have): named absence.** You're not strong in SQL, and you ask your analyst for queries. The resume can't claim it, and no wording should gesture at it. Closing it would take a few months of practice on your own reporting data, or an honest statement in interviews that you pull numbers in HubSpot and work with an analyst on SQL-heavy questions. Whether a must-have gap here rules the role out is job-underwriter's call, and I can run that if you want.

**Not written, and why**

- "SQL" or "SQL-literate" anywhere: you've said you aren't, and an interviewer will test it.
- "Senior Marketing Manager" as your title: the resume says Marketing Manager, and the title is not yours to change.
- "5+ years demand gen" or "6 years demand generation": the resume says 6 years of B2B SaaS, not demand gen specifically.
- "Owned demand generation" or "content distribution": neither is in your text.
- "300 attendees": the figure is registrants.

**Upgrade (optional):** If you want a summary line, I can draft one using only sentences from R1 to R3, marked pending your approval.

**Questions**

Q1 — C1: Did you plan or run content distribution (blog, gated assets, social, partner syndication)? If yes, what, how often, and what result? Answer in text, or say skip.
Q2 — Of the 6 years, how many were in demand generation specifically (paid, lifecycle, webinars), and how many in other B2B SaaS marketing? Answer in text, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.