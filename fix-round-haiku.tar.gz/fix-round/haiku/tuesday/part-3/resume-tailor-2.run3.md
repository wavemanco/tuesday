Nothing is applied yet. Every row below is pending your approval, and the tailored resume comes only from the rows you approve. I took the posting's "3+ years" as the only labelled must-have, treated Python, orchestration and modelling as important, and treated streaming as preferred.

## Edit ledger

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience, top bullet | "Built and maintained about 25 dbt models including the core orders mart." / "I designed the star schema for the orders mart with our then-DE." | "Built and maintained about 25 dbt models, including the core orders mart, and designed its star schema with our then-DE." | merge | "Built and maintained about 25 dbt models including the core orders mart."; "I designed the star schema for the orders mart with our then-DE." | `[grounded]` resume | pending your approval |
| E2 | Experience | "I've fixed our nightly dbt job when it breaks and added tests to it." | "Fixed our nightly dbt job when it breaks and added tests to it." | surface | "I've fixed our nightly dbt job when it breaks and added tests to it." | `[grounded]` resume | pending your approval |
| E3 | Experience | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | "Write Python for analysis (pandas)." | split | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | `[grounded]` resume | pending your approval |
| E4 | Experience | (same sentence as E3) | "Write some scripts to pull vendor APIs on a cron." | split | "I write Python for analysis — pandas, some scripting to pull vendor APIs on a cron." | `[grounded]` resume | pending your approval |
| E5 | Experience | "Never used Airflow or Spark." / "Never touched Kafka." | *(removed)* | cut | "Never used Airflow or Spark."; "Never touched Kafka." | `[grounded]` resume | pending your approval |

Notes on the rows:
- **E1** keeps "then-DE" and "designed", so the star schema reads as shared work. I did not write "led" or "owned".
- **E2** drops the "I've" and nothing else. I did not write "maintained" for the job, because the source says you fixed it when it broke.
- **E3 and E4** keep "some". The cron scripts are the closest thing on the page to batch pipeline work, so E4 is surfaced as its own line.
- **E5** removes the negatives. A resume lists what you did, not what you have not. This is a cut, not hidden text, and the application form may still ask you directly.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| R1 | 3+ years data engineering | must-have | not_evidenced | No DE title or DE years. Adjacent work is E1, E2, E4: transferability, not tenure | `[grounded]` resume |
| R2 | Build and own batch pipelines | important | not_evidenced | The nightly job (E2) and cron scripts (E4) are adjacent. Building or owning a pipeline is not stated | `[grounded]` resume |
| R3 | Production Python | important | surfaced_by_edit | E3 and E4 surface the Python. "Production" is not established (C2) | `[grounded]` resume |
| R4 | Airflow or equivalent orchestration | important | not_evidenced | No scheduler named. Cron (E4) and the nightly job (E2) are nearest; who scheduled them is unknown (C2) | `[grounded]` resume |
| R5 | Dimensional modelling | important | surfaced_by_edit | E1: star schema, designed with our then-DE | `[grounded]` resume |
| R6 | Model the warehouse | important | surfaced_by_edit | E1: about 25 dbt models including the core orders mart | `[grounded]` resume |
| R7 | Own data quality | important | surfaced_by_edit | E2: tests added, breaks fixed. Ownership of data quality as a whole is not shown | `[grounded]` resume |
| R8 | Own SLAs | important | not_evidenced | Nothing on deadlines or freshness (C3) | `[grounded]` resume |
| R9 | Partner with analytics on requirements | important | not_evidenced | Analytics-side work is there. Requirements taken from stakeholders is not (C3) | `[grounded]` resume |
| R10 | Streaming (Kafka, Spark) | preferred | not_evidenced | Never touched Kafka; never used Spark. Named absence below | `[grounded]` resume |

No requirement is `already_evidenced` as written. That is the honest result for this posting.

## Gap handling

**Recall prompts.** These are the places where your answer could change a row. Each question is in the closing block.

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | R1, R2: 3+ years DE; build and own pipelines | must-have | Analytics work, dbt models, one nightly job fixed and tested, cron scripts. Does not establish owning a pipeline end to end | The posting's first must-have is years of DE, and it is the line a reader checks first | Owning ingestion, scheduling, alerts or reruns for a job; a backfill you ran; an incident you resolved end to end | A runbook, a ticket, an alert, a commit history | `[grounded]` resume and posting; `[generic]` what a reader checks first |
| C2 | R3, R4: production Python; Airflow or orchestration | important | Python for analysis and cron-run scripts. No scheduler, retry or deploy named | `[grounded]` the posting names orchestration; `[generic]` interviewers commonly probe scheduling on DE screens | What ran the nightly dbt job and the cron scripts; anything that retried or alerted; whether others deployed them | Cron file, scheduler config, dbt Cloud or Airflow screenshot, deploy log | `[grounded]` resume; `[generic]` the interview pattern |
| C3 | R8, R9: SLAs; partner with analytics on requirements | important | Nightly job and tests; analytics-side work. No deadline or requirement-gathering named | `[grounded]` the posting names both; `[generic]` SLA questions usually ask for a number | A deadline someone relied on; a freshness check; requirements you wrote or took for the orders mart | A ticket or spec for the orders mart, a stakeholder thread, a freshness alert | `[grounded]` resume and posting; `[generic]` the interview pattern |

**Named absences.** Where no recall prompt can close the gap, the closing path is stated.

- **R1, 3+ years DE.** Years cannot be written into a resume. What closes it is time in DE-titled work, or a pipeline you can show you built and ran end to end. The posting gives no sign that the years line is a knockout. `[grounded]` The application form may still ask it yes/no, and a resume cannot change that answer. C26 describes knockouts as "yes/no eligibility checks (work authorization, required license, location)" (cite C26), so whether a years question is one is `[inferred]`. Whether to apply on that basis is job-underwriter's call.
- **R10, streaming.** You have not used Kafka or Spark, and the posting lists streaming as a plus. Closing it would take a small project you can show, such as a consumer reading a public event feed into a table you query. `[generic]` That is a few weekends of work. It does not change R1, so it is worth doing only if you are applying to roles that require streaming.
- **R4, Airflow**, if C2 comes back as "nothing schedules them." The closing path is a small DAG that runs your vendor-API script daily with retries and an alert, in a public repo. `[generic]` That is a few weeks of evenings.

## Prohibited claims

Not written, and why:

- **"Data Engineer" as a title or in the summary.** You have not held it, and the posting's must-have is years of it.
- **"Built" or "owned" pipelines, or "production pipelines."** You maintained a nightly dbt job and some cron scripts. Owning a pipeline is a different job.
- **"Owned data quality and SLAs."** You added tests and fixed breaks. Ownership of the whole area and any SLA are not in your material.
- **"Maintained" for the nightly job.** Your sentence says you fixed it when it broke.
- **"Led" the star schema.** You designed it with the then-DE, and "led" changes who made the decisions.
- **"Partnered with analytics on requirements."** Your material does not say it, and the posting's word is "partner."
- **Airflow, Spark, Kafka or streaming on a skills list.** You have not used them.
- **"Production" on the Python line.** It stays out unless C2 confirms it.

## Parse-safety check

The resume arrived as pasted text, not a file. Layout, columns, tables, headers and file type could not be checked, so no parse risk is reported. The text itself is plain.

## Upgrade menu

- **A sanitized repo or script**, such as the vendor-API script or the orders mart dbt models. This would make the Python and modelling lines inspectable rather than self-report.
- **What runs the nightly job**, with no data beyond the scheduler name. This answers C2 without a conversation.
- **Earlier resume versions.** They may hold pipeline work the current version dropped.
- **The full posting with priority labels.** The pasted text labels only "3+ years" as must-have. The other priorities above are my reading.

## Questions

**C1**: Have you owned a pipeline end to end, covering ingestion, scheduling, alerts and reruns? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**C2**: What ran the nightly dbt job and the vendor-API scripts (cron, a scheduler, dbt Cloud, something else), and did anything retry or alert on them? Same response modes.

**C3**: Did anyone depend on the nightly job by a set time, or did you take requirements from stakeholders for the orders mart? Same response modes.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.