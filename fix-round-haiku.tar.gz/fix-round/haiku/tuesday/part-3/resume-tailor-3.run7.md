Nothing is applied yet. Below is the edit ledger for your review. Approve rows by number, and I'll build the tailored resume from approved rows only.

**Check first:** I worked from the CV as you summarised it in your message, not from the CV file. Every "Traces to" quote is copied from that summary, so check each one against your actual CV text before approving. If a quote doesn't match, tell me and I'll rebuild that row.

**Edit ledger**

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience | "Led 30+ client integrations of our REST APIs end to end." | *(unchanged, moved to the first bullet)* | `reorder` | "Led 30+ client integrations of our REST APIs end to end." | `[grounded]` CV | pending your approval |
| E2 | Experience | "Wrote the internal integration playbook the whole team uses." | "Wrote the internal integration playbook the whole team uses." (own line) | `surface` | "Wrote the internal integration playbook the whole team uses." | `[grounded]` CV; dossier edit E1, re-audited | pending your approval |
| E3 | Experience | "Ran quarterly roadmap-input sessions collecting client feedback for product." | *(unchanged, own line)* | `surface` | "Ran quarterly roadmap-input sessions collecting client feedback for product." | `[grounded]` CV | pending your approval |
| E4 | Skills | "Comfortable in Postman, SQL, OpenAPI specs." | *(unchanged, moved to the top of the skills section)* | `reorder` | "Comfortable in Postman, SQL, OpenAPI specs." | `[grounded]` CV | pending your approval |
| E5 | Summary | *(no summary line)* | "7 years solutions engineer / implementation lead at an enterprise software vendor. Led 30+ client integrations of our REST APIs end to end. Wrote the internal integration playbook the whole team uses." | `merge` | "7 years solutions engineer / implementation lead at an enterprise software vendor."; "Led 30+ client integrations of our REST APIs end to end."; "Wrote the internal integration playbook the whole team uses." | `[grounded]` CV | pending your approval |

E2 is the dossier's pending edit E1, re-audited. The scope stays "the whole team", with no headcount added. E5 uses only your three sentences and contains no "product", "PM" or "roadmap" wording.

**Coverage map**

The posting doesn't tier the requirements beyond the 3+ years PM must-have. I've marked the rest `important` and you can change that.

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| C1 | 3+ years product management | must-have | not_evidenced | No PM title or role. Adjacent work is E2 and E3. | `[grounded]` dossier R1 |
| C2 | Shipped API or platform products | important | not_evidenced | You led integrations onto REST APIs; the evidence doesn't show you shipped one. Adjacent: E1. | `[grounded]` dossier R2 |
| C3 | Technical fluency | important | surfaced_by_edit | E4, E1 | `[grounded]` CV |
| C4 | Stakeholder management | important | surfaced_by_edit | E3, E1: client and product stakeholders | `[grounded]` CV |
| C5 | Discovery with integration partners | important | surfaced_by_edit | E3: client feedback sessions. The line doesn't use the word "discovery", and it shouldn't. | `[grounded]` CV |
| C6 | Write specs and drive delivery with engineering squads | important | not_evidenced | No spec authorship or squad delivery in the CV. OpenAPI fluency (E4) is not authorship. | `[grounded]` CV |
| C7 | Define adoption metrics | important | not_evidenced | Nothing in the CV measures adoption. | `[grounded]` CV (absence) |

**Recovery per gap**

| # | Requirement | What your resume currently shows | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|
| C1 | 3+ years PM | Integration leadership and client-feedback sessions for product | Any decision you made on what the integration surface built next, or in what order | A roadmap or priority list you authored or presented | `[grounded]` CV; the recall prompt is the question in the closing block |
| C2 | Shipped API products | Client integrations on REST APIs | A client-driven change to an endpoint, field or version that shipped, where your case for it decided the outcome | The release note or change log for it | `[grounded]` CV; the recall prompt is the question in the closing block |
| C6 | Specs and squad delivery | OpenAPI fluency, no authorship stated | Any OpenAPI spec you wrote, not only read or changed | The spec file itself | `[grounded]` CV; the recall prompt is the question in the closing block |
| C7 | Adoption metrics | Nothing | **Named absence:** nothing in the CV measures whether clients adopted an API or integration. Closing it would take a metric you tracked yourself, such as time from a client's first call to going live, if you measured it. Without one, leave C7 off the resume. | — | `[generic]` example metric; the gap itself is `[grounded]` in the CV |

**Prohibited claims: not written, and why**

- **"Product Manager" or any PM title, in the headline or Experience.** You have never held one, and C1 is a must-have.
- **"Owned the API roadmap", "set priorities", "prioritised the backlog".** The evidence shows you ran input sessions. It doesn't show you decided priorities. Q1 could change this.
- **"Shipped an API product" or "built the platform".** You integrated clients onto APIs. Q2 could change this.
- **"Built an internal request-triage tool".** Rejected in the dossier. You said you could not confirm ownership.
- **"Customer of a partner API platform", or any buyer-side framing.** Rejected in the dossier. You worked vendor-side.
- **"Ran discovery", "defined adoption metrics", "drove adoption".** "Discovery" is the posting's word, not your history. No adoption work is in the CV.
- **"Wrote specs" or "authored OpenAPI specs".** You're comfortable with them; authorship isn't evidenced. Q3 could change this.
- **Team sizes or numbers for the playbook.** Only "the whole team" is in your material.

**Parse-safety check**

You pasted this as text, not as a file. I could not check layout, multi-column structure, tables, headers or footers, or the file type. None of the parse risks can be observed from pasted text, so I've reported no findings. Send the file if you want those checks run.

**Upgrade menu**

- **Your CV file:** lets me verify every trace quote verbatim. This is the most useful input.
- **The integration playbook (or its table of contents):** an inspectable artifact that would strengthen E2 and the summary line.
- **Roadmap-input session notes or a deck:** would support E3, and possibly C1 if they show you shaped the outcome.
- **The full dossier:** I used only the excerpt you pasted. Its other `evidence_map` rows could change the ledger.

**Questions**

Q1 (C1): In those quarterly roadmap-input sessions, did you decide what went on the roadmap, or did you bring client feedback to the people who decided? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

Q2 (C2): Did a client-driven change ever ship in the REST API itself (an endpoint, a field or a version) where your case for it decided the outcome? Name it and your part in it, or say skip.

Q3 (C6): Have you written an OpenAPI spec yourself, or only read and changed ones others wrote? Name one, or say skip.

Whether this must-have gap is worth applying through is job-underwriter's question. The dossier's conditional_go already rests on it.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.