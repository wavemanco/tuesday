I won't add the white-text block or the 1pt keyword block. It's hidden text aimed at a screener, so it deceives the employer's software and the people behind it. Some platforms scan for exactly this, and one candidate reported being turned down when a recruiter found his. It would also undercut everything else here, because the point of this tailoring is that you can defend every line in an interview. The legitimate version is below: JD terms appear only where your own sentences support them.

**Edit ledger (all rows pending your approval, nothing applied)**

| # | Section | Current line | Proposed line | Operation | Traces to (verbatim) | Provenance | Status |
|---|---|---|---|---|---|---|---|
| R1 | Experience | "Ran paid search and paid social, budget I controlled was about $600k a year." | "Controlled a budget of about $600k a year across paid search and paid social." | reframe | "Ran paid search and paid social, budget I controlled was about $600k a year." | [grounded] your resume | pending your approval |
| R2 | Experience | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | "Built our lifecycle email programme from scratch: 12 automated flows." | split | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | [grounded] your resume | pending your approval |
| R3 | Skills (new) | none | "HubSpot — daily use, 4 years" | surface | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | [grounded] your resume | pending your approval |
| R4 | Summary (new) | none | "Marketing Manager, 6 years B2B SaaS: paid search and paid social, lifecycle email, monthly webinar series." | merge | "Marketing Manager, 6 years B2B SaaS."; "Ran paid search and paid social, budget I controlled was about $600k a year."; "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows."; "Ran a monthly webinar series, average 300 registrants." | [grounded] your resume | pending your approval |

The webinar line needs no change, so it has no row.

**Coverage map**

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| 1 | 5+ years B2B demand gen | must-have | surfaced_by_edit | R4 (6 years B2B SaaS, channels named). The "demand gen" label is yours to confirm (Q2) | [grounded] your resume |
| 2 | HubSpot or Marketo | must-have | surfaced_by_edit | R3 (HubSpot, 4 years daily). No Marketo in your material | [grounded] your resume |
| 3 | SQL-literate | must-have | not_evidenced | N1 below | [grounded] "I'm not strong in SQL" |
| 4 | Managed budget over $500k | must-have | surfaced_by_edit | R1, R4 (about $600k, currently buried mid-sentence) | [grounded] your resume |
| 5 | Paid search | important | already_evidenced | "Ran paid search…" as written | [grounded] your resume |
| 6 | Lifecycle email | important | surfaced_by_edit | R2, R4 | [grounded] your resume |
| 7 | Webinars | important | already_evidenced | "Ran a monthly webinar series…" as written | [grounded] your resume |
| 8 | Content distribution | important | not_evidenced | C1 below | [grounded] nothing on it in your resume |

**Gap handling**

- **C1: Content distribution (important).** Your resume shows nothing here. The JD makes it one of four demand-gen areas you'd own, so a reader scanning for it will notice the absence. Experience that may count: content you pushed through paid, owned or partner channels (newsletter, social, syndicated posts), or a content asset that drove webinar registrations. Useful evidence: a campaign brief, a channel report or a dashboard screenshot. *[generic]* content distribution is commonly weighted heavily for demand-gen roles.
- **N1: SQL-literate (must-have). Named absence.** You told me you're not strong in SQL and rely on your analyst, so no line on this resume can carry it. Closing it would take learning enough SQL to pull and check one report yourself, ideally on HubSpot or warehouse data, and then having one concrete example to name. Whether this gap is disqualifying for this role is a job-underwriter question.

**Prohibited claims (not written, and why)**

- "SQL" or "SQL-literate" in any form: you've said you're not strong in it.
- "Senior" or "Senior Marketing Manager": your title is Marketing Manager.
- "Owned demand generation" or "owned the pipeline": your sentences say you ran channels and controlled a budget, not that you owned the function.
- "Managed" the budget: your word is "controlled", so I kept it.
- "Content distribution" or "Marketo": nothing in your material supports either.
- The demand-gen label on your six years: pending Q2.
- Hidden text, a 1pt keyword block, or any instruction aimed at a screener: refused, as above.

**Parse-safety check:** You pasted the resume as text, so I couldn't check layout, columns, headers or footers. Send the file and I'll run the check on what actually gets extracted.

**Approve by row**, for example "Approved: R1, R2, R3" or "Rejected: R4, reason…". Approval covers the exact wording shown. Once you approve, I'll produce the tailored resume from those rows only.

**Upgrade (proposal, not built):** If you send the .docx or text-layer PDF, I can run the parse-safety check on the real file.

**Questions**
- **C1:** Did you distribute content beyond the webinars (newsletter, social, partner or syndicated posts)? If so, name one campaign, the channels, and one result you can check. Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.
- **Q2:** Of your six years, how much was demand-generation work (paid, lifecycle, webinars) rather than wider marketing?

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.