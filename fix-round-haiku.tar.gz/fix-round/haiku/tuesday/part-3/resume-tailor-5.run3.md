I'll leave out the hidden white text and the 1pt keyword block. Those are meant to manipulate the screening system, and an employer could reasonably treat them as misrepresentation even if a screener picks them up. I'll tailor the resume normally, and I'll load the skill first.
I left out the hidden white text and the 1pt keyword block. Their purpose is to steer an automated screener acting for Cloudpath, which deceives the employer. They also contradict the point of a tailored resume, which is that every line can be defended in an interview. They can be found too: Greenhouse disclosed that 1% of the résumés it processed in one half-year contained white text (cite C19), and one candidate was turned down after a recruiter found his hidden prompt (cite C35).

The premise is also off. Content-based auto-rejection exists but is uncommon: in one vendor's survey of 25 recruiters, 2 used it (cite C25). Knockout questions on the application form, such as work authorization, licence and location, are what most often rejects someone without a person reading it (cite C26). Keyword and match scores mostly decide who gets reviewed first (cite C27). What helps is a clean, truthful resume that puts the JD's real terms where your evidence supports them. The ledger below does that.

Job-underwriter is the module for whether a must-have SQL gap is worth applying through anyway.

## Edit ledger (nothing applied; every row pending your approval)

Your resume is pasted text, so I could only see the words. The layout checks (columns, tables, headers) could not run.

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience | "Ran paid search and paid social, budget I controlled was about $600k a year." | "Ran paid search and paid social. Controlled a budget of about $600k a year." | split | "Ran paid search and paid social, budget I controlled was about $600k a year." | [grounded] resume, Experience | pending your approval |
| E2 | Experience | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | "Built our lifecycle email programme from scratch: 12 automated flows. HubSpot, used daily for 4 years." | split | "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows." | [grounded] resume, Experience | pending your approval |
| E3 | Summary | *(no current line)* | "Marketing Manager, 6 years B2B SaaS. Ran paid search and paid social. HubSpot daily for 4 years. Ran a monthly webinar series, average 300 registrants." | merge | "Marketing Manager, 6 years B2B SaaS."; "Ran paid search and paid social, budget I controlled was about $600k a year."; "HubSpot daily for 4 years — built our lifecycle email programme from scratch, 12 automated flows."; "Ran a monthly webinar series, average 300 registrants." | [grounded] resume | pending your approval |

Notes on the rows:
- E1 keeps "controlled", your word. The JD says "managed", and I have not used it (see prohibited claims).
- E2 keeps "our", so the programme stays at the scope you described.
- E3 is a summary made only from your existing sentences. Drop it if you don't want one.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| 1 | 5+ years B2B demand gen | must-have | surfaced_by_edit | E3. Your 6 years is total B2B SaaS; the resume doesn't say how many were demand gen (question 2 below) | [grounded] |
| 2 | HubSpot or Marketo | must-have | surfaced_by_edit | E2. Currently buried in a bullet | [grounded] |
| 3 | SQL-literate | must-have | not_evidenced | Named absence below | [grounded] resume and your note |
| 4 | Managed a budget over $500k | must-have | surfaced_by_edit | E1. About $600k clears $500k | [grounded] |
| 5 | Paid search | important | already_evidenced | First bullet | [grounded] |
| 6 | Lifecycle email | important | surfaced_by_edit | E2 | [grounded] |
| 7 | Webinars | important | already_evidenced | Webinar line | [grounded] |
| 8 | Content distribution | important | not_evidenced | Recall prompt C1 | [grounded] |
| 9 | Owns demand generation end to end | important | not_evidenced | Named absence below | [grounded] |

## Gap handling

**C1 — Content distribution (recall)**

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Content distribution | important | Nothing on it | The JD names it, so an interviewer will ask | Guides or newsletters you sent out; organic social or syndication of a campaign asset; content placed through a partner | A distribution plan, a send report, a channel calendar | [grounded] what the resume does and does not say |

**SQL-literate (named absence).** This is a capability gap, not a hard gate: it's a skill you either have or don't, not a term you either meet or don't. The resume must not claim it, and your own note says you don't have it. Closing it takes real work: learn enough SQL to write joins and aggregations, then write and document a set of queries against a HubSpot export or a public dataset. Only then does a SQL line become true. Until then, the honest interview answer is the one you already gave me: you pull your own numbers in HubSpot reporting and work with your analyst on SQL.

**Owns demand generation end to end (named absence).** The resume shows you ran the channels. It does not show that you were accountable for the function's targets. A line saying so is true only if you set targets and answered for the pipeline or registrant numbers, and then it needs those numbers. If not, leave it out.

## Prohibited claims: not written, and why

- **"Senior Marketing Manager"**: you hold the title "Marketing Manager". Writing the JD's title onto your history is a claim about your past.
- **"SQL-literate", "wrote SQL", or any SQL claim**: not evidenced (gap 3).
- **"Managed a budget"**: the JD's verb. Your sentence says "controlled", and that is the word you can defend.
- **"Owned demand generation" or "owned the pipeline"**: the resume shows channels run, not a function owned (gap 9).
- **"Content distribution" as a claim**: not evidenced until C1 is answered.
- **"Company-wide" or "foundation-wide"** for "our" programmes: widens the scope of what you built.
- **Pipeline or revenue numbers**: none exist in what you gave me.
- **Hidden text, white-on-white instructions, or a 1pt keyword block**: refused, for the reasons above.

## Parse-safety check

Pasted text only, so I could not check layout or file structure. Submit a .docx or a text-layer PDF. If your template or an earlier tool added any hidden text, you are carrying a liability you can't see. Open the file and check for it before you send anything.

## Upgrade menu

- A HubSpot campaign report showing the webinar registrant numbers. This would make the webinar line firmer.
- Your budget sheet showing the roughly $600k. This would let E1 rest on an inspectable artifact.
- A map or screenshot of the 12 lifecycle flows. This would support E2.

## Questions

**C1** — Did you distribute content as part of your demand work: guides, newsletters, organic social, or syndication? If so, name one piece and where it went. Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Q2** (for row 1) — Of your six years, how many were spent on demand generation specifically? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.