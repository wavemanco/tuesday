Your instinct is partly right, but keyword matching is probably not the whole story. Two things are likely hurting you:

- **Your experience doesn't cover most of the stack.** About 13 of the 18 requirements below have no support in what you've described. Adding keywords can't fix that. Only honest evidence can, and the resume doesn't yet have it.
- **The layout can hide the keywords you do have.** Parsers often mangle two-column PDFs with icons, and contact details in a header can be dropped. That's a separate, checkable problem.

On the wider picture: content-based auto-rejection is less common than people assume. In one vendor survey of 25 recruiters, only 2 used it (cite C25). Knockout questions in the application form are what most often reject candidates without a person reading (cite C26). Match scores mostly affect who gets reviewed first (cite C27). Whether this role is worth applying for, given the gaps, is job-underwriter's call, and I haven't made it here.

I worked from your description, not the PDF. The "current lines" below are your own sentences from this message, so the quotes need checking against the actual file (see the upgrade menu).

## Edit ledger (all pending your approval)

Nothing is applied. I proposed only three changes, because anything more would need claims the resume doesn't support.

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Summary (new) | *(none)* | "DevOps Engineer, 4 years: built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs; ran a Kubernetes proof-of-concept for two months last year, and it never went to production." | `merge` | "DevOps Engineer, 4 years." · "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs." · "Ran a Kubernetes proof-of-concept for two months last year — never went to production." | `[grounded]` your description | pending your approval |
| E2 | Experience | "Ran a Kubernetes proof-of-concept for two months last year — never went to production." | *(unchanged, moved above the Jenkins line)* | `reorder` | "Ran a Kubernetes proof-of-concept for two months last year — never went to production." | `[grounded]` your description | pending your approval |
| E3 | Skills | "Docker, Jenkins, Bash and Python scripting, Ansible for config management, CloudWatch for monitoring" | "Docker, Jenkins, Bash and Python scripting, Ansible for config management, CloudWatch for monitoring, Kubernetes (proof-of-concept, never went to production)" | `surface` | "Ran a Kubernetes proof-of-concept for two months last year — never went to production." | `[grounded]` your description | pending your approval |

E1 deliberately keeps "never went to production" in the sentence. Dropping it would turn a proof-of-concept into apparent production experience.

## Coverage map

Priorities are my assumption. The JD doesn't rank its list, so I've marked the two stated duties as must-have and the tools as important. Go is marked preferred because the JD pairs it with Python.

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| 1 | Kubernetes | important | surfaced_by_edit | E2, E3; proof-of-concept only | `[grounded]` your description |
| 2 | AWS EKS | important | not_evidenced | C2; the PoC's platform isn't stated | `[grounded]` resume does not name EKS |
| 3 | Terraform | important | not_evidenced | C1 | `[grounded]` not in the resume |
| 4 | ArgoCD | important | not_evidenced | C2 | `[grounded]` not in the resume |
| 5 | GitOps | important | not_evidenced | C2; Jenkins deploys are not described as Git-driven | `[grounded]` what the resume says; `[generic]` Jenkins pipelines are usually push-based |
| 6 | Helm | important | not_evidenced | C2 | `[grounded]` not in the resume |
| 7 | Istio / service mesh | important | not_evidenced | N1 | `[grounded]` not in the resume |
| 8 | Prometheus | important | not_evidenced | C2 | `[grounded]` not in the resume |
| 9 | Grafana | important | not_evidenced | C2 | `[grounded]` not in the resume |
| 10 | Observability | important | not_evidenced | CloudWatch monitoring is adjacent, not an observability practice; C3 | `[grounded]` "CloudWatch for monitoring" |
| 11 | Vault | important | not_evidenced | N2 | `[grounded]` not in the resume |
| 12 | CI/CD | important | already_evidenced | Jenkins deploy pipeline, as written | `[grounded]` "Built our deploy pipeline in Jenkins…" |
| 13 | GitLab CI | preferred | not_evidenced | N3; Jenkins is adjacent | `[grounded]` not in the resume |
| 14 | Python | important | already_evidenced | "Bash and Python scripting", as written | `[grounded]` your description |
| 15 | Go | preferred | not_evidenced | N4 | `[grounded]` not in the resume |
| 16 | SRE practices | must-have | not_evidenced | C3 | `[grounded]` not in the resume |
| 17 | Platform reliability | must-have | not_evidenced | C3 | `[grounded]` not in the resume |
| 18 | Developer experience | must-have | not_evidenced | C4; the Jenkins pipeline is the nearest base | `[grounded]` not in the resume |

## Recall prompts

These rows carry no questions. The questions are in the closing block.

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Terraform | important | Ansible for config management; no provisioning tool | `[generic]` platform roles usually expect infrastructure provisioned as code, not only configured | Terraform or CloudFormation; Ansible that created AWS resources | A repo or README of provisioning code | `[grounded]` resume; `[generic]` role expectation |
| C2 | AWS EKS, Argo CD, GitOps, Helm, Prometheus, Grafana | important | A PoC with no stated platform or tools | The PoC is your only Kubernetes evidence, and its details decide how many of six rows move | EKS or self-managed cluster; Helm charts; Argo CD sync; Prometheus or Grafana install | PoC repo, manifests, notes, or a screenshot | `[grounded]` resume |
| C3 | SRE practices, platform reliability, observability | must-have | CloudWatch for monitoring | `[generic]` the JD's first stated duty is reliability, and screeners look for on-call or incident evidence | On-call rotation; owned alerts; incident reviews; SLOs | Runbook, alert definition, or sanitised postmortem | `[grounded]` resume; `[generic]` JD emphasis |
| C4 | Developer experience | must-have | A deploy pipeline built and maintained | The JD's second stated duty; the pipeline is the strongest base for it | Other teams using the pipeline; templates; docs; onboarding | Pipeline docs or a template repo | `[grounded]` resume |

## Named absences

- **N1, Istio / service mesh.** You have no service mesh experience on record. Closing it means installing Istio on a local kind cluster with a two-service app, enabling mTLS, and publishing the manifests. That counts as learned, not production.
- **N2, Vault.** You have no secrets-management experience on record. Closing it means running Vault in dev mode and wiring one app to read a secret, then publishing the repo.
- **N3, GitLab CI.** Your CI experience is in Jenkins, which transfers in concept but not in syntax. Closing it means moving one Jenkins job to `.gitlab-ci.yml` in a personal project.
- **N4, Go.** You have no Go experience on record. Closing it means a small Go CLI or a Kubernetes controller, published on GitHub. It's a preferred item, so it's worth it only if you're applying to roles that need it.

## Not written, and why

- **"Production Kubernetes" or "managed EKS".** The PoC never went to production, and the platform is unknown.
- **Terraform, Argo CD, GitOps, Helm, Istio, Prometheus, Grafana, Vault, GitLab CI or Go in the skills list.** A tool listed is not a tool owned. Add them only after an answer to C1 or C2 or a closed gap.
- **"Owned platform reliability", "SRE", or "observability" as a practice.** You have described CloudWatch monitoring, not ownership of reliability.
- **"Led" or "owned" the Jenkins pipeline.** You built and maintain it. Those verbs would claim more than that.
- **"CI/CD" as your own label.** The JD's term isn't your term. Keep your wording unless you tell me "CI/CD" describes what you did.

## Parse-safety check

I could not run these checks on the file. From your description, these risks are present:

| Check | Present? | What breaks | What it costs |
|---|---|---|---|
| Multi-column layout | Yes, two columns | Parsers read across columns | Dates detach from roles; skills interleave |
| Icons and skill marks | Yes, one per skill | Icons drop out or become garbage characters | The skill names can vanish with them |
| Contact details in header | Yes | Headers are often treated as page furniture | You could be unreachable by the parser |
| Section headings | Unknown | Non-standard headings aren't detected | Experience or Skills may not be found |
| File type | PDF; unknown whether it has a text layer | An image-only PDF yields no text | Everything is lost |

Quick test: open the PDF, select all, and paste into a plain text editor. If the skills are scattered, or your name and email are missing, the parser has the same problem. A .docx or text-layer PDF is the safest pair. These are parse risks. This is not a judgement on the design.

## Upgrade menu

- **The exact resume text, extracted from the PDF.** This lets me check every quote in the ledger against your actual wording. Without it, the quotes come from your description.
- **Your Kubernetes proof-of-concept artifacts (repo, manifests, notes).** These would turn C2's six rows from not_evidenced into grounded evidence.
- **A small Terraform or Argo CD sandbox repo.** If you build one, C1 and rows 3–5 move from not_evidenced to surfaced.
- **The full JD with its must-have and preferred labels.** This would replace my priority assignments.

## Questions

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

1. **C2:** For the Kubernetes proof-of-concept, what platform did it run on (EKS, self-managed, kind or minikube), and which of Helm, Argo CD, Prometheus, Grafana or Istio did you actually use?
2. **C1:** Have you ever provisioned AWS resources with Terraform or CloudFormation, rather than only configuring hosts with Ansible?
3. **C3:** Have you been on call for a production service, or owned alerts, incident reviews or SLOs?

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.