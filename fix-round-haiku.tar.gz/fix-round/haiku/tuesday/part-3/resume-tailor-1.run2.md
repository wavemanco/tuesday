I worked from the text you pasted, not a CV file, so the traces below quote your message. Before you approve anything, paste your CV as it stands. The rows can only be checked against your real document.

Your strongest matches are the latency work, the incident and on-call record, and the scale of the ledger services. The two responsibilities the posting names outright, mentoring mid-level engineers and partnering with product on roadmap sequencing, have no evidence in what you sent. I have not written around either.

## Ledger (nothing applied; every row pending your approval)

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Summary (new) | *(not in what you pasted)* | Senior Software Engineer, 7 years. Go and Rust daily for 4 years, Python before that. Currently at a payments company, owning three services in our ledger pipeline. | `merge` | "Senior Software Engineer, 7 years."; "Go and Rust daily for 4 years, Python before that."; "Currently at a payments company."; "I own three services in our ledger pipeline" | `[grounded]` CV | pending your approval |
| E2 | Experience | "Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer." | *(unchanged, moved to the first bullet of the role)* | `reorder` | "Cut p99 on the balance-read path from 380ms to 95ms by reworking the cache layer." | `[grounded]` CV | pending your approval |
| E3 | Experience | "On-call rotation every fourth week for two years" / "I've run six incidents as incident commander" | "On-call rotation every fourth week for two years. Have run six incidents as incident commander." | `merge` | "On-call rotation every fourth week for two years,"; "I've run six incidents as incident commander." | `[grounded]` CV | pending your approval |
| E4 | Experience | "I do onboarding for new hires on my team — usually two or three a year, I pair with them for their first month." | "Run onboarding for new hires on my team, usually two or three a year, pairing with each for their first month." | `surface` | "I do onboarding for new hires on my team — usually two or three a year, I pair with them for their first month." | `[grounded]` CV | pending your approval |

Two notes on the rows:
- The "about" and "at peak" qualifiers on the 40k figure stay wherever that line appears. Dropping them would make the claim larger.
- E4 stays framed as onboarding. It is not mentoring, and it does not become mentoring anywhere in the document.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| C1 | Design and ship Go services at high request volume | must-have | already_evidenced | Three owned services, one at about 40k requests/minute at peak. Already on the CV. | `[grounded]` CV |
| C2 | Drive down p99 latency | must-have | surfaced_by_edit | E2 moves the 380ms to 95ms line to the top of the role. | `[grounded]` CV |
| C3 | Own on-call for your services | must-have | surfaced_by_edit | E3 pairs the rotation with the incident record. The CV shows rotation participation, not ownership of on-call for the services. | `[grounded]` CV |
| C4 | Strong incident response | must-have | surfaced_by_edit | E3: six incidents as incident commander. | `[grounded]` CV |
| C5 | Production Go | must-have | already_evidenced | "Go and Rust daily for 4 years." The CV does not say which of the three services are in Go. | `[grounded]` CV |
| C6 | 5+ years backend | must-have | surfaced_by_edit | E1 states seven years next to the service work. The word "backend" does not appear and is not added. | `[grounded]` CV |
| C7 | Distributed systems at scale | must-have | surfaced_by_edit | E2 and E3 carry the scale and the cache-layer rework. Kafka and gRPC are listed, not shown in use. No line states distributed design work. | `[grounded]` CV |
| C8 | Experience mentoring | must-have | surfaced_by_edit | E4 is onboarding pairs for new hires. It is not ongoing mentoring. See R1. | `[grounded]` CV |
| C9 | Mentor mid-level engineers | important | not_evidenced | See R1. | `[grounded]` CV (absence) |
| C10 | Partner with product on roadmap sequencing | important | not_evidenced | See R2. | `[grounded]` CV (absence) |

## Recovery per gap

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| R1 | Mentor mid-level engineers | important | Onboarding pairs for new hires, first month (E4). Nothing about mid-level engineers or mentoring beyond onboarding. | The posting names it directly, and onboarding alone can read as a different job. | Coaching a mid-level engineer through a design or code-review decision; a growth plan for someone past their first year that you shaped | A review thread, or a growth note with names removed | `[grounded]` what the CV does and does not say; `[generic]` interviewers usually probe mentoring beyond onboarding |
| R2 | Partner with product on roadmap sequencing | important | Nothing. | The posting makes it a responsibility, so an interviewer will ask how you sequenced work against product's priorities. | A launch or deadline where you set the order of reliability or cache work against product's; a roadmap where you pushed back on a date for latency reasons | A roadmap doc or planning thread | `[grounded]` the CV has no such line; `[generic]` senior candidates are usually asked this |

## Not written, and why

- **"Mentored mid-level engineers."** The CV shows onboarding pairs for new hires. Nothing else is in the evidence, so this stays unwritten until R1 is answered.
- **"Owned the roadmap" or "partnered with product on sequencing."** No such line exists. R2 is open.
- **"Distributed systems design."** The CV names a cache-layer rework and a scale figure. It does not say you designed distributed behaviour, so that wording is not written.
- **"Backend engineer" as a title or self-description.** Your title is Senior Software Engineer, and the posting's word is not applied to it.
- **"Build-cache" or "developer tools" experience.** Nothing in the CV is about build systems or developer tooling. The posting's domain is not borrowed.
- **"Owned on-call for the services."** The CV shows rotation participation. Ownership is not stated.
- **"Led six incidents."** The CV says you ran them as incident commander. "Led" is a stronger verb than your own.

## Parse-safety check

This ran on pasted text, so it could not check columns, tables, headers, or section headings. Send the CV as a `.docx` or a text-layer PDF to run it.

**Upgrade menu**
- **Your CV as a file (`.docx` or text-layer PDF):** runs the parse-safety check, and each trace becomes a verbatim quote from your document.
- **A review, growth note, or roadmap document:** turns R1 or R2 from a gap into a confirmed row.
- **A design doc or repository for the cache-layer rework:** would let C7 be claimed directly rather than inferred.

**Questions**
1. Paste your CV as it stands, so the trace quotes can be checked against it. Are the three services in Go?
2. R1: When did you last shape how a mid-level engineer grew, beyond their first month? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.
3. R2: Have you ever set the order of reliability or cache work against a product date or roadmap? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.