**Short answer:** the resume can be made easier to find for this posting, but it can't honestly match most of the stack. Keyword changes can only surface what you have already done. The biggest gaps are Terraform, production Kubernetes, GitOps, and the service-mesh and secrets tools.

**A correction to the theory first.** Keyword matching may affect ranking, but it is probably not what is rejecting you. Where teams use match scores, they mostly use them to order who gets reviewed first (cite C27). In one vendor's interviews with 25 recruiters, two had content-based auto-rejection configured (cite C25). The vendor is a résumé-builder company and calls these themes, not representative statistics. The more common rejection without a person is knockout questions on the application form, such as work authorization, required licence, or location (cite C26). Check those answers before you spend more time on the resume. Parsing is the other mechanical risk, and your resume has several (see the parse check below).

**Assumption:** the posting doesn't mark must-haves. I've treated the core stack as important, and Kubernetes, Terraform, EKS and SRE practices as must-have because the role says you will own reliability.

## The edit ledger

Every row is pending your approval. Nothing has been applied. I've proposed no change to the AWS, Ansible, Docker or CloudWatch lines, because they already say what you did.

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Skills block (new) | *(none)* | "Kubernetes — two-month proof-of-concept, not taken to production" | surface | "Ran a Kubernetes proof-of-concept for two months last year — never went to production." | `[grounded]` cv | pending your approval |
| E2 | Skills block (new) | *(none)* | "Jenkins — built our deploy pipeline and maintain about 30 jobs" | surface | "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs." | `[grounded]` cv | pending your approval |
| E3 | Skills block | "Bash and Python scripting" | "Python scripting" and "Bash scripting", as two lines | split | "Bash and Python scripting" | `[grounded]` cv | pending your approval |
| E4 | Summary (new) | *(none)* | "DevOps Engineer, 4 years. Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs. Ran a Kubernetes proof-of-concept for two months last year — never went to production." | merge | "DevOps Engineer, 4 years."; "Built our deploy pipeline in Jenkins and maintain about 30 Jenkins jobs."; "Ran a Kubernetes proof-of-concept for two months last year — never went to production." | `[grounded]` cv | pending your approval |

Two notes on the ledger:
- **CI/CD is left out on purpose.** The posting says "CI/CD", but your sentence says "deploy pipeline". If you're comfortable calling your Jenkins pipeline CI/CD, approve that as a changed row and it will go through the audit again.
- **E4 is three of your own sentences put together.** It adds nothing new, and it places the strongest true evidence first.

## Coverage map

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| 1 | Kubernetes | must-have | surfaced_by_edit | E1 and E4; production is not claimed | `[grounded]` cv |
| 2 | AWS EKS | must-have | not_evidenced | Resume names no EKS; PoC cluster type unknown, see R2 | `[grounded]` what the resume does and does not say |
| 3 | Terraform | must-have | not_evidenced | Absent. Ansible is config management, not provisioning, see R1 | `[grounded]` cv |
| 4 | SRE practices and platform reliability | must-have | not_evidenced | Absent, see R3 | `[grounded]` cv |
| 5 | AWS (EC2, S3, RDS, IAM) | important | already_evidenced | Listed as written | `[grounded]` cv |
| 6 | CI/CD pipelines | important | already_evidenced | Jenkins deploy pipeline, about 30 jobs; E2 moves it up | `[grounded]` cv |
| 7 | GitLab CI | preferred | not_evidenced | Jenkins only, see N1 | `[grounded]` cv |
| 8 | ArgoCD and GitOps | important | not_evidenced | Jenkins pushes changes; GitOps pulls from Git, see N2 | `[grounded]` cv |
| 9 | Istio and service mesh | important | not_evidenced | Absent, see N3 | `[grounded]` cv |
| 10 | Prometheus, Grafana and observability | important | not_evidenced | CloudWatch monitoring is adjacent, not observability, see N4 | `[grounded]` cv |
| 11 | Vault | important | not_evidenced | Absent. IAM is adjacent but is not secrets management, see N5 | `[grounded]` cv |
| 12 | Helm | preferred | not_evidenced | Not stated, see R2 | `[grounded]` cv |
| 13 | Python | important | already_evidenced | "Python scripting", which is scripting rather than application development; E3 keeps that qualifier | `[grounded]` cv |
| 14 | Go | preferred | not_evidenced | Absent, see N6 | `[grounded]` cv |
| 15 | Developer experience | important | not_evidenced | You built "our" pipeline, but who used it is not stated, see R3 | `[grounded]` cv |

## Gap handling

**Recall rows.** Each has its question in the closing block, tagged to the row.

| # | Requirement | Priority | What your resume currently shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| R1 | Terraform | must-have | Ansible for config management; EC2, S3, RDS and IAM with no stated method of setup | The posting makes infrastructure as code a core skill | Any AWS resources you defined in code, including IAM policies or RDS setup, even partly | A repo, module, or pipeline file that provisioned something | `[grounded]` the resume is silent on provisioning; `[generic]` infrastructure as code is standard for this kind of role |
| R2 | AWS EKS and Helm | must-have, preferred | "Ran a Kubernetes proof-of-concept for two months" with no cluster type or packaging stated | EKS is named; Helm is the usual way to package Kubernetes apps | The PoC cluster, if it was EKS; any Helm charts or manifests you wrote | PoC notes, a repo, or manifests | `[grounded]` the resume does not say which cluster or packaging |
| R3 | SRE practices and developer experience | must-have, important | Deploy pipeline built and maintained; nothing on incidents, alerts, or users | The role says you will own reliability and developer experience | On-call, incident response, or alerts for the pipeline or any service it shipped; any named team that relied on it | A runbook, postmortem, alert config, or usage notes | `[grounded]` the resume does not say |

**Named absences.** These have no recall prompt because the resume gives nothing to pull. Each is a gap and a closing path.

- **N1, GitLab CI.** Your Jenkins experience transfers, but the GitLab syntax doesn't. Closing path: convert one Jenkins pipeline to GitLab CI and keep it in a repo.
- **N2, ArgoCD and GitOps.** Closing path: install Argo CD on the PoC cluster and deploy one app from a Git repo, so the cluster is reconciled from Git.
- **N3, Istio and service mesh.** Closing path: install Istio on the PoC cluster and show one traffic split or mTLS setting you can explain. This is a demo, not production, and it should be described as one.
- **N4, Prometheus, Grafana and observability.** Closing path: install a Prometheus and Grafana stack on the PoC cluster and build one dashboard and one alert. Observability also covers tracing and logs, which your CloudWatch work doesn't show.
- **N5, Vault.** Closing path: run Vault in dev mode, move one secret out of a Jenkins configuration into it, and write down what broke.
- **N6, Go.** Closing path: write one small Go command that replaces one of your Bash scripts, and put it in a repo someone else can read.

## Prohibited claims

Not written, and why:

- **"Platform Engineer" as your title.** You hold DevOps Engineer. Retitling would change the claim.
- **Production Kubernetes, or managing clusters.** You ran a two-month PoC that never went to production.
- **"Owned the deploy pipeline."** Your sentence says you built it and maintain it. "Owned" moves that up.
- **Terraform, EKS, Helm, ArgoCD, GitOps, Istio, Vault, Prometheus, Grafana, GitLab, Go.** None appears in your material.
- **"Observability."** The posting's word is "observability"; yours is "CloudWatch for monitoring". Using the posting's word would change what you monitored.
- **"Platform reliability" and "SRE practices."** Your material shows no reliability ownership.
- **"Developer experience."** Your material doesn't show who used the pipeline.

## Parse-safety check

You described the file rather than sending it, so I could not run the layout checks. What I can see from your description:

| Check | Observed | What breaks | What it costs |
|---|---|---|---|
| Multi-column layout | Yes, two columns | Parsers read across the row and interleave the columns | Dates can detach from the roles they belong to |
| Icons for skills | Yes | Icons are read as garbage or skipped | If the skill names sit inside the icons, the parser sees none of your skills. This is probably the largest keyword loss on the resume |
| Contact details in the header | Yes | Header text is often discarded as page furniture | Recruiters may be unable to contact you |
| Section headings | Not checked | Non-standard headings may not be detected | Experience and Skills may go unrecognised |
| Text layer in the PDF | Not checked | An image-only PDF has no text at all | Everything is lost |

A quick test: open the PDF, select all, and paste into a plain text editor. What comes out is roughly what a linear parser sees. If it reads in the wrong order or is missing your skills, that is the parse risk.

## Upgrade menu

- **The PDF itself, or a text export of it.** Unlocks the layout checks above and lets me confirm whether the headings and header survive.
- **The full posting.** The pasted version gives a stack list but no must-have tiers, so the priorities above are my reading.
- **Answers to the three recall prompts.** Each one answered can move a not_evidenced row.
- **PoC artifacts, such as a repo, manifests or notes.** Inspectable proof would firm up the Kubernetes row.
- **The application form's knockout questions.** These reject most often without a person, and nothing on the resume changes them.

## Questions

- **R1:** Did you define any of the AWS resources you ran (EC2, S3, RDS, IAM) as code, in Terraform, CloudFormation or CDK, or were they built by hand, through the console, or with Ansible? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.
- **R2:** What kind of cluster did the PoC run on, EKS or something you set up yourself, and did you package anything with Helm? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.
- **R3:** Did you carry on-call or incident response for the deploy pipeline or any service it shipped, and who relied on the pipeline day to day? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

Whether to apply at all, given these gaps, is a separate decision for job-underwriter.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.