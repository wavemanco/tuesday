I tailored Nadia's CV for the Quartzline posting, using the dossier excerpt and the CV text you pasted. Nothing is applied yet. Every row waits for your approval, and I haven't produced a revised resume. Only the excerpt of tuesday-dossier.md was in the conversation, so if the full file has other pending edits or rejected inferences, tell me and I'll re-check the ledger against it.

The dossier's conditional_go decision is noted but not acted on. The 3+ years PM requirement is graded on fit and gap type, not treated as a gate. Nothing in the CV holds a PM title, product ownership, or shipped product, so the edits below only surface what is already there.

## Coverage map

The posting marks only the 3+ years as must-have. I read the other requirements as important.

| # | Requirement | Priority | Status | Where it lands | Provenance |
|---|---|---|---|---|---|
| 1 | 3+ years product management | must-have | not_evidenced | No PM title in the CV. Roadmap-input work is adjacent (E3). Recall prompt C1. | `[grounded]` CV; dossier R1 (adjacent, transferability, medium) |
| 2 | Shipped API or platform products | important | not_evidenced | Client integration delivery is evidenced (E2). A shipped product is not. Recall prompt C2. | `[grounded]` CV; dossier R2 (adjacent, medium) |
| 3 | Technical fluency | important | surfaced_by_edit | E4 moves the tools line up from the end of a sentence. | `[grounded]` CV |
| 4 | Stakeholder management | important | surfaced_by_edit | E2 and E3 surface client-facing work. Managing competing stakeholders is not stated. | `[grounded]` CV |
| 5 | Own the roadmap for the partner-facing API platform | important | not_evidenced | Roadmap input is adjacent (E3). Ownership and prioritisation authority are not evidenced. Recall prompt C1. | `[grounded]` CV; dossier R1 |
| 6 | Run discovery with integration partners | important | not_evidenced | Named absence. Client feedback sessions are adjacent, but clients are not partners of a platform. | `[grounded]` CV and posting |
| 7 | Write specs and drive delivery with two engineering squads | important | not_evidenced | Named absence. Integration delivery is evidenced (E2). Product specs and squad work are not. | `[grounded]` CV |
| 8 | Define adoption metrics | important | not_evidenced | Recall prompt C3. | `[grounded]` CV |

## Edit ledger

Section names are my placement suggestion, since I only have the CV as pasted text. Current lines are quoted from what you wrote.

| # | Section | Current line | Proposed line | Operation | Traces to | Provenance | Status |
|---|---|---|---|---|---|---|---|
| E1 | Experience | (not on its own line yet; dossier E1) | Wrote the internal integration playbook the whole team uses. | split | "Wrote the internal integration playbook the whole team uses." | `[grounded]` CV; dossier E1, re-audited | pending your approval |
| E2 | Experience | (position not stated) | Led 30+ client integrations of our REST APIs end to end. | reorder | "Led 30+ client integrations of our REST APIs end to end." | `[grounded]` CV | pending your approval |
| E3 | Experience | (position not stated) | Ran quarterly roadmap-input sessions collecting client feedback for product. | reorder | "Ran quarterly roadmap-input sessions collecting client feedback for product." | `[grounded]` CV | pending your approval |
| E4 | Skills | (sits at the end of a sentence) | Comfortable in Postman, SQL, OpenAPI specs. | surface | "Comfortable in Postman, SQL, OpenAPI specs." | `[grounded]` CV | pending your approval |

Notes on the rows:
- E1 is the dossier's pending edit. I re-audited it and kept the wording exact. "Wrote" is not stretched to "owned" or "maintained".
- E2 keeps "our" attached to your employer. Make sure the role header names the vendor, so no reader takes it for a partner platform.
- I didn't propose a summary line. Any summary I write would have to lead with a title you have never held, so it isn't written. If you want one later, I can build it only from E1–E4.

## Recovery per gap

**Recall prompts** (questions are in the closing block):

| # | Requirement | Priority | What the CV shows | Why it matters here | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| C1 | Roadmap ownership and prioritisation (rows 1, 5) | must-have | Roadmap-input sessions only. No decision authority stated. | No answer changes the years count, but it decides whether any roadmap line can be written. | Choosing which client requests went to product; setting the order of integration asks. | A roadmap or input summary you wrote; a prioritised list. | `[grounded]` what the CV does and does not say; `[generic]` what this costs on applications of this kind |
| C2 | Shipped API or platform products (row 2) | important | Client integrations delivered end to end. No product shipped. | Shipping a product is a different kind of work from delivering one client integration. | A connector, SDK sample or API version more than one client adopted. | A release note; a changelog; a repo. | `[grounded]` as above; `[generic]` as above |
| C3 | Adoption metrics (row 8) | important | No metric stated. | An adoption metric has to be measured, not described. | Go-live time per integration; number of clients live on one endpoint. | A go-live tracker; a dashboard or export. | `[grounded]` as above; `[generic]` as above |

**Named absences:**
- **Row 1, the years count.** Seven years of solutions and implementation work cannot be turned into product-management years. The honest closing path is a target that does not gate on PM years, or PM work you can verify through C1.
- **Row 6, discovery with partners.** The closing path is one documented discovery round with external integrators on a single feature, with the interview notes and the decision it drove.
- **Row 7, specs and squads.** The closing path is one written spec you took through build with an engineering team, with the ticket trail as the artifact.

## Prohibited claims

Not written, and why:

- **"Product Manager" or any PM title, or "3+ years of product management."** You have never held the title, and the posting makes the years a must-have.
- **"Owned the roadmap" or "set priorities."** The dossier records roadmap ownership and prioritisation authority as not evidenced.
- **"Built" or "owned" the internal request-triage tool.** Rejected in the dossier: you could not confirm ownership.
- **"Customer of a partner API platform" or any partner-side experience.** Rejected in the dossier: you worked vendor-side.
- **Changing "client" to "partner."** Clients and partners are different relationships, and this swap moves which side of the table you sat on.
- **"Shipped API products" or "shipped a platform."** The work was client integration delivery.
- **"Ran discovery with integration partners."** The sessions collected client feedback for product. That is a different kind of work.
- **"Wrote specs" for the platform.** The playbook is a practice document, not a product spec. "Comfortable in OpenAPI specs" is fluency, not authorship.
- **"Drove delivery with two engineering squads."** Not stated.
- **"Defined adoption metrics."** Not stated.

## Parse-safety check

This ran on pasted text, not a file. I could not check multi-column layout, tables, text boxes, headers or footers, or the file type. Send the CV as a `.docx` or a text-layer PDF and I can run those checks.

**Watch-out:** The words I quote as yours beside each edit can differ slightly from what you wrote — before you approve a line or send the resume, check that quote and the new line against what you actually wrote.