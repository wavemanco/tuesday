import json, os, re, sys, collections
tree = sys.argv[1]
def strings(x):
    if isinstance(x, str): yield x
    elif isinstance(x, dict):
        for k, v in x.items(): yield from strings(v)
    elif isinstance(x, list):
        for v in x: yield from strings(v)
fx = {}
for m in os.listdir(f'{tree}/skills'):
    p = f'{tree}/skills/{m}/evals/evals.json'
    if not os.path.exists(p): continue
    d = json.load(open(p))
    for e in d['evals']:
        fx[(m, e['id'])] = '\n'.join(s for k in ('prompt', 'files', 'research', 'candidate_text', 'sentinels') if k in e for s in strings(e[k]))
alltext = '\n'.join(fx.values())
shipped = {}
for root in ('skills', 'dist'):
    for d, _, fs in os.walk(f'{tree}/{root}'):
        if '/evals' in d: continue
        for f in fs:
            p = os.path.join(d, f)
            if p.endswith('.skill'): continue
            try: shipped[os.path.relpath(p, tree)] = open(p, encoding='utf-8').read()
            except Exception: pass
for extra in ('README.md',):
    shipped[extra] = open(f'{tree}/{extra}', encoding='utf-8').read()
shiptext = '\n'.join(shipped.values())
lower = set(re.findall(r'\b[a-z][a-z]+\b', alltext + shiptext))
caps = collections.Counter(re.findall(r"\b[A-Z][a-zA-Z]{2,}\b", alltext))
cands = {w for w in caps if w.lower() not in lower}
handles = set(re.findall(r'@[A-Za-z0-9_.]+|[a-z0-9.-]+\.example\b', alltext))
hits = collections.defaultdict(set)
for path, t in shipped.items():
    toks = set(re.findall(r"\b[A-Z][a-zA-Z]{2,}\b", t))
    for w in cands & toks: hits[w].add(path)
    for h in handles:
        if h in t: hits[h].add(path)
print('fixture name candidates:', len(cands), 'handles/domains:', len(handles))
for w in sorted(hits):
    srcs = [f'{m[0][:3]}{m[1]}' for m, t in fx.items() if w in t]
    print(f'{w:20} in fixtures {srcs[:6]} shipped-in {len(hits[w])}: {sorted(hits[w])[:3]}')
