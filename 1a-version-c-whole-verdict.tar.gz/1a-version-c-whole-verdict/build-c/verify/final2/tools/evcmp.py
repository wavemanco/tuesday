import json, sys
names = sys.argv[1:]
for m in ('job-underwriter', 'mock-interview'):
    ds = [json.load(open(f'{n}/skills/{m}/evals/evals.json')) for n in names]
    new = ds[0]
    for label, old in zip(names[1:], ds[1:]):
        print(f'== {m}: fresh vs {label.split("/")[-2] + "/" + label.split("/")[-1]}')
        ck = sorted(set(new['clauses']) | set(old['clauses']))
        for k in ck:
            a, b = new['clauses'].get(k), old['clauses'].get(k)
            if a != b: print('  clause', k, 'ADDED' if b is None else ('REMOVED' if a is None else 'CHANGED'))
        oe = {e['id']: e for e in old['evals']}
        for e in new['evals']:
            o = oe.get(e['id'])
            if o is None: print('  eval', e['id'], 'NEW'); continue
            if e == o: print('  eval', e['id'], 'same'); continue
            diffk = [k for k in sorted(set(e) | set(o)) if e.get(k) != o.get(k)]
            print('  eval', e['id'], 'CHANGED keys', diffk)
            if 'expectations' in diffk:
                for i, (x, y) in enumerate(zip(e['expectations'], o['expectations'])):
                    if x != y: print('     exp', i, 'changed')
                if len(e['expectations']) != len(o['expectations']): print('     exp count', len(e['expectations']), len(o['expectations']))
        if [x for x in new.keys() if x not in ('clauses','evals') and new[x] != old.get(x)]: print('  top-level differs')
