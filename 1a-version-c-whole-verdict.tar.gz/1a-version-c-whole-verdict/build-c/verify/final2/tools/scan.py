import os, re, sys, zipfile, io, collections
email = os.environ.get('VERIFY_EMAIL', '')
ok_email = bool(email) and '@' in email
targets = sys.argv[1:]
KEY = re.compile(rb'(sk-ant-[A-Za-z0-9_-]{10,}|sk-[A-Za-z0-9]{20,}|AKIA[0-9A-Z]{16}|ASIA[0-9A-Z]{16}|gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{20,}|xox[abprs]-[A-Za-z0-9-]{10,}|AIza[0-9A-Za-z_-]{35}|-----BEGIN [A-Z ]*PRIVATE KEY-----|glpat-[A-Za-z0-9_-]{20}|eyJ[A-Za-z0-9_-]{10,}\.eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}|(?i:bearer)\s+[A-Za-z0-9._-]{30,}|(?i:(api[_-]?key|secret|token|password)["\']?\s*[:=]\s*["\'][A-Za-z0-9/+_.-]{16,}["\']))')
HOME = re.compile(rb'/home/(?!user(?![A-Za-z0-9_.-]))[A-Za-z0-9_.-]+|/Users/[A-Za-z0-9_.-]+|[A-Za-z]:\\\\Users\\\\[A-Za-z0-9_.-]+')
ROOTHOME = re.compile(rb'/root/')
def blobs(path):
    if os.path.isdir(path):
        for d, _, fs in os.walk(path):
            for f in fs:
                p = os.path.join(d, f)
                if os.path.islink(p): continue
                yield from blobs(p)
        return
    data = open(path, 'rb').read()
    yield path, data
    if path.endswith('.skill') or zipfile.is_zipfile(io.BytesIO(data)) and path.endswith('.zip'):
        try:
            z = zipfile.ZipFile(io.BytesIO(data))
            for i in z.infolist(): yield path + '!' + i.filename, z.read(i)
        except zipfile.BadZipFile: pass
tot = collections.Counter()
for t in targets:
    c = collections.Counter(); keyhits = []; homehits = collections.Counter()
    for p, data in blobs(t):
        c['files'] += 1
        if '!' in p: c['zip_members'] += 1
        if ok_email:
            low = data.lower(); e = email.lower().encode()
            c['email'] += low.count(e) + low.count(e.replace(b'@', b'%40'))
        for m in KEY.finditer(data): c['key'] += 1; keyhits.append((os.path.relpath(p.split('!')[0], t) if os.path.isdir(t) else os.path.basename(p), m.group(0)[:12]))
        for m in HOME.finditer(data): c['home_other'] += 1; homehits[m.group(0)[:20]] += 1
        c['root_home'] += len(ROOTHOME.findall(data))
    print(f"{t}: files {c['files']} (zip members {c['zip_members']}), account email {c['email'] if ok_email else 'N/A'}, key-shaped {c['key']}, home paths other than /home/user {c['home_other']}, /root/ paths {c['root_home']}")
    for k in keyhits[:10]: print('    key-shaped at', k[0], 'prefix', k[1])
    for k, n in homehits.most_common(10): print('    home path', k, n)
    tot.update(c)
print('email read ok:', ok_email)
print('TOTAL', dict(tot))
