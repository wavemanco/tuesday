import os, sys, stat, hashlib
def walk(root):
    out = {}
    for d, dirs, files in os.walk(root):
        for f in files:
            p = os.path.join(d, f)
            rel = os.path.relpath(p, root)
            st = os.lstat(p)
            if stat.S_ISLNK(st.st_mode):
                out[rel] = ('L', os.readlink(p), False)
            else:
                with open(p, 'rb') as fh:
                    out[rel] = ('F', hashlib.sha256(fh.read()).hexdigest(), bool(st.st_mode & 0o100))
    return out
a, b = walk(sys.argv[1]), walk(sys.argv[2])
diff = 0
for k in sorted(set(a) | set(b)):
    if k not in a: print('ONLY-B', k); diff += 1
    elif k not in b: print('ONLY-A', k); diff += 1
    elif a[k] != b[k]: print('DIFF', k, a[k], b[k]); diff += 1
print(f'files A={len(a)} B={len(b)} differences={diff} exec-A={sum(v[2] for v in a.values())} exec-B={sum(v[2] for v in b.values())}')
sys.exit(1 if diff else 0)
