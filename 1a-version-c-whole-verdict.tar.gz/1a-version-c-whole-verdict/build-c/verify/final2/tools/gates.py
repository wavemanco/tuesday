import json, os, shutil, subprocess, sys, time
from pathlib import Path
tree, out, steps = Path(sys.argv[1]), Path(sys.argv[2]), sys.argv[3].split(',')
env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', TMPDIR=sys.argv[4])
env['PATH'] = os.pathsep.join(d for d in env.get('PATH', '').split(os.pathsep) if d and not (Path(d) / 'claude').exists())
assert shutil.which('claude', path=env['PATH']) is None
CMDS = {'check_skills': ['python3', '-I', '-B', 'ci/check_skills.py'], 'sync-check': ['python3', '-I', '-B', 'ci/sync.py', '--check'],
        'test_harness': ['python3', '-I', '-B', 'evals/test_harness.py'], 'test_checks': ['python3', '-I', '-B', 'ci/test_checks.py']}
rows = []
for s in steps:
    t0 = time.time()
    p = subprocess.run(CMDS[s], cwd=tree, env=env, capture_output=True, text=True)
    (out / f'{s}.txt').write_text(p.stdout + '\n--- stderr ---\n' + p.stderr + f'\n[exit {p.returncode}]\n')
    lines = [l for l in p.stdout.splitlines() if l.strip()]
    rows.append({'step': ' '.join(CMDS[s]), 'exit': p.returncode, 'seconds': round(time.time() - t0), 'last': lines[-3:] if lines else []})
    print(json.dumps(rows[-1]), flush=True)
(out / 'gates.json').write_text(json.dumps(rows, indent=1) + '\n')
