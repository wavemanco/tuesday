import zipfile, sys, os, hashlib
tree, out = sys.argv[1], sys.argv[2]
for name in sorted(os.listdir(os.path.join(tree, 'dist'))):
    if not name.endswith('.skill'): continue
    z = zipfile.ZipFile(os.path.join(tree, 'dist', name))
    n_same = n_diff = 0
    for info in z.infolist():
        data = z.read(info)
        dest = os.path.join(out, info.filename)
        os.makedirs(os.path.dirname(dest), exist_ok=True)
        open(dest, 'wb').write(data)
        src = os.path.join(tree, 'skills', info.filename)
        if os.path.exists(src) and open(src, 'rb').read() == data: n_same += 1
        else: n_diff += 1; print('  member differs from source:', info.filename)
    print(name, 'members', len(z.infolist()), 'same-as-source', n_same, 'diff', n_diff, 'evals-members', sum('/evals/' in i.filename for i in z.infolist()))
