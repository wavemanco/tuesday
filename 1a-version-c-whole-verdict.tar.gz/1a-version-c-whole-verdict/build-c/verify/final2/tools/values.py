import hashlib, json, os, sys
from pathlib import Path
sys.dont_write_bytecode = True
T = Path(sys.argv[1]).resolve(); OUT = Path(sys.argv[2])
sys.path[:0] = [str(T / 'evals'), str(T / 'ci')]
os.chdir(T)
import check_skills as cs, fixture_clauses as fc, run_fixtures as rf
for mod in (cs, fc, rf): assert Path(mod.__file__).resolve().is_relative_to(T)
h = lambda b: hashlib.sha256(b).hexdigest()
v = {'tuesday_digests': cs.tuesday_digests(), 'measured': dict(cs.MEASURED_TUESDAY), 'payload': rf.payload_digests(),
     'grader_prompt_sha256': rf.GRADER_PROMPT_SHA256,
     'cases': {r: h((T / r).read_bytes()) for r in ('skills/job-underwriter/evals/evals.json', 'skills/mock-interview/evals/evals.json',
               'skills/resume-tailor/evals/evals.json', 'evals/suite-explicit.json', 'evals/suite-routing.json')}}
OUT.mkdir(parents=True, exist_ok=True)
e = {}
for skill, ids in (('job-underwriter', (7, 8)), ('mock-interview', (9, 10, 11, 12, 13))):
    src = T / 'skills' / skill / 'evals' / 'evals.json'
    data = json.loads(src.read_text(encoding='utf-8'))
    for n in ids:
        case = [c for c in data['evals'] if c['id'] == n]; assert len(case) == 1
        body = (json.dumps({'skill_name': data['skill_name'], 'clauses': data['clauses'], 'evals': case}, indent=2, ensure_ascii=False) + '\n').encode()
        p = OUT / f'e23-{skill}-{n}.json'; p.write_bytes(body)
        ext = fc.load_cases(p)[0]; treat = [c for c in fc.load_cases(src) if c['id'] == n][0]
        e[p.name] = {'sha256': h(body), 'identical': ext['expectations'] == treat['expectations'] and ext['prompt'] == treat['prompt'], 'n_exp': len(ext['expectations'])}
v['e23'] = e
print(json.dumps(v, indent=1, sort_keys=True))
