import hashlib, json, os, sys
from pathlib import Path
sys.dont_write_bytecode = True
T = Path(sys.argv[1]).resolve()
sys.path[:0] = [str(T / 'evals'), str(T / 'ci')]
os.chdir(T)
import check_skills as cs, run_fixtures as rf
h = lambda b: hashlib.sha256(b).hexdigest()
DEPS = ["ci/check_skills.py", "ci/ledger_rules.py", "ci/package.py", "ci/sync.py", "evals/backfill_tools.py", "evals/child_env.py", "evals/compare_arms.py", "evals/fixture_clauses.py", "evals/output_checks.py", "evals/research_server.py", "evals/routing_variants.py", "evals/run_fixtures.py", "evals/run_routing.py", "evals/run_transcripts.py"]
print(json.dumps({'tuesday_digests': cs.tuesday_digests(), 'measured': dict(cs.MEASURED_TUESDAY), 'payload': rf.payload_digests(),
  'inventory': rf.inventory(), 'grader': rf.GRADER_PROMPT_SHA256, 'deps': {d: h((T / d).read_bytes()) for d in DEPS},
  'cases': {r: h((T / r).read_bytes()) for r in ('skills/job-underwriter/evals/evals.json', 'skills/mock-interview/evals/evals.json', 'skills/resume-tailor/evals/evals.json', 'evals/suite-explicit.json', 'evals/suite-routing.json')}}, indent=1, sort_keys=True))
