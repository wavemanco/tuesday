import os, sys, collections
R = "I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call."
L = "It's an AI assistant and can make mistakes. It points out warning signs in what you share, but it can't confirm who an employer, recruiter or sender really is. Please check before you act; the decision is always yours."
P = "It is plain text: no label,"
for root in sys.argv[1:]:
    c = collections.Counter()
    for d, _, fs in os.walk(root):
        for f in fs:
            p = os.path.join(d, f)
            if p.endswith('.skill'): continue
            try: t = open(p, encoding='utf-8').read()
            except Exception: continue
            rel = os.path.relpath(p, root)
            for k, s in (('R', R), ('L', L), ('P', P)):
                n = t.count(s)
                if n: c[(k, rel)] += n
    print('==', root)
    for k in sorted(c): print(' ', k[0], c[k], k[1])
