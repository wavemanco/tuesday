import json, re, sys, difflib, os
new, old = sys.argv[1], sys.argv[2]
STOP = frozenset("""a an the of to in on for and or but is are was were be been by with as at from
that this these those it its their they them we our you your he she his her not no may might can could
would should will than then so such into over under about per via have has had do does did use used get
got make made just also""".split()) | {"i", "me", "my", "we", "us"}
DASH = dict.fromkeys(map(ord, "‐‑‒–—―−"), "-"); Q = {ord("“"): '"', ord("”"): '"', ord("‘"): "'", ord("’"): "'"}
def toks(t): return [x for x in re.findall(r"[a-z0-9]+(?:_[a-z0-9]+)*(?:'[a-z]+)?", t.translate(Q).translate(DASH).lower()) if x not in STOP]
idx = {}
for m in ('job-underwriter', 'mock-interview', 'resume-tailor'):
    d = json.load(open(f'{new}/skills/{m}/evals/evals.json'))
    for c in d['evals']:
        texts = [('prompt', c.get('prompt', ''))]
        r = c.get('research') or {}
        for p in [*(r.get('pages') or []), *(r.get('user_pages') or [])]:
            texts.append(('page ' + p.get('url', '?'), p.get('title', '') + '\n' + p.get('text', '')))
        for f in c.get('files') or []:
            if isinstance(f, dict):
                texts.append(('file', json.dumps(f)))
        for where, t in texts:
            tk = toks(t)
            for i in range(len(tk) - 2): idx.setdefault(tuple(tk[i:i+3]), f'{m[:3]}{c["id"]} {where}')
files = ['skills/job-underwriter/SKILL.md', 'skills/job-underwriter/references/risk-and-decision.md', 'skills/job-underwriter/README.md',
         'skills/mock-interview/SKILL.md', 'skills/mock-interview/references/output-template.md', 'skills/mock-interview/references/question-rubric.md',
         'skills/mock-interview/references/personas.md', 'skills/mock-interview/README.md', 'docs/roadmap.html']
total = 0
for f in files:
    a = open(f'{old}/{f}', encoding='utf-8').read().splitlines()
    b = open(f'{new}/{f}', encoding='utf-8').read().splitlines()
    added = []
    for op, i1, i2, j1, j2 in difflib.SequenceMatcher(None, a, b, autojunk=False).get_opcodes():
        if op in ('replace', 'insert'): added += b[j1:j2]
    hits = set()
    for line in added:
        # only the words new to this line vs. the old text, by word-level diff, would be stricter; use whole lines
        tk = toks(line)
        for i in range(len(tk) - 2):
            r = tuple(tk[i:i+3])
            if r in idx: hits.add((' '.join(r), idx[r]))
    total += len(hits)
    print(f'{f}: added lines {len(added)}, shared 3-content-word runs {len(hits)}')
    for h in sorted(hits): print('    ', h)
print('TOTAL', total)
