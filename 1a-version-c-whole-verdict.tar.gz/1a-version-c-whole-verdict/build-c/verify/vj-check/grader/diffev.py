import sys, json, difflib
sys.dont_write_bytecode = True
B = sys.argv[1]
pairs = [("job-underwriter", B + "/verify/vj/before/ju-evals.json"), ("mock-interview", B + "/verify/vj/before/mi-evals.json")]
for skill, before in pairs:
    new = json.load(open(f"{B}/tree/skills/{skill}/evals/evals.json"))
    old = json.load(open(before))
    print("=====", skill)
    # clauses
    for k in sorted(set(new["clauses"]) | set(old["clauses"])):
        a, b = old["clauses"].get(k), new["clauses"].get(k)
        if a != b:
            print("CLAUSE CHANGED:", k)
    # other top-level keys
    for k in set(new) | set(old):
        if k not in ("clauses", "evals") and new.get(k) != old.get(k):
            print("TOPLEVEL CHANGED", k)
    for cn, co in zip(new["evals"], old["evals"]):
        for k in set(cn) | set(co):
            if k == "expectations":
                for i, (en, eo) in enumerate(zip(cn[k], co[k]), 1):
                    if en != eo:
                        print(f"case {cn['id']} #{i} changed")
                if len(cn[k]) != len(co[k]): print("LEN CHANGED", cn['id'])
            elif cn.get(k) != co.get(k):
                print(f"case {cn['id']} field {k} changed")
