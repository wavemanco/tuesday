import sys, json, re
sys.dont_write_bytecode = True
B = sys.argv[1]
def split(t):
    # split at '. ' + capital, outside parentheses and single-quoted examples
    out, cur, depth, q = [], "", 0, False
    i = 0
    while i < len(t):
        ch = t[i]; cur += ch
        if ch == "(": depth += 1
        elif ch == ")": depth = max(0, depth - 1)
        if ch == "." and depth == 0 and i + 2 < len(t) and t[i+1] == " " and (t[i+2].isupper() or t[i+2] in "'\""):
            # skip inside a quoted example like ('This is very likely a scam. Don't ...')
            if cur.count("'") % 2 == 1 and re.search(r"[(\s]'[A-Z]", cur) and False:
                pass
            out.append(cur.strip()); cur = ""
        i += 1
    if cur.strip(): out.append(cur.strip())
    return out
for skill, ver in (("job-underwriter","ju"),("mock-interview","mi")):
    for label, path in (("before", f"{B}/verify/vj/before/{ver}-evals.json"), ("after", f"{B}/tree/skills/{skill}/evals/evals.json")):
        d = json.load(open(path))
        for k in ("no_party_accusation","no_fraud_claim","invite_pointer","request_verdicts","no_accusation"):
            if k in d["clauses"]:
                ss = split(d["clauses"][k])
                print(skill, label, k, "total", len(d["clauses"][k].split()), "sentences", [len(s.split()) for s in ss])
