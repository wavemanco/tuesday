import sys, json, difflib, re
sys.dont_write_bytecode = True
B = sys.argv[1]
def wd(a, b):
    aw, bw = re.findall(r"\S+|\s+", a), re.findall(r"\S+|\s+", b)
    out = []
    for op, i1, i2, j1, j2 in difflib.SequenceMatcher(None, aw, bw, autojunk=False).get_opcodes():
        if op == "equal":
            seg = "".join(aw[i1:i2])
            out.append(seg if len(seg) < 80 else seg[:35] + " ... " + seg[-35:])
        else:
            if i2 > i1: out.append("[-" + "".join(aw[i1:i2]) + "-]")
            if j2 > j1: out.append("{+" + "".join(bw[j1:j2]) + "+}")
    return "".join(out)
for skill, before in [("job-underwriter", "ju"), ("mock-interview", "mi")]:
    new = json.load(open(f"{B}/tree/skills/{skill}/evals/evals.json"))
    old = json.load(open(f"{B}/verify/vj/before/{before}-evals.json"))
    for k in new["clauses"]:
        if new["clauses"][k] != old["clauses"].get(k):
            print(f"===== {skill} clause {k}\n" + wd(old["clauses"][k], new["clauses"][k]) + "\n")
    for cn, co in zip(new["evals"], old["evals"]):
        for i, (en, eo) in enumerate(zip(cn["expectations"], co["expectations"]), 1):
            if en != eo:
                print(f"===== {skill} case {cn['id']} #{i}\n" + wd(eo, en) + "\n")
