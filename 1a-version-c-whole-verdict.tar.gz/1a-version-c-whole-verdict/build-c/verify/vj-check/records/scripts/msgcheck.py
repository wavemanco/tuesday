import sys, re
T1 = "Co-Authored-By: Claude Opus 5.5 <noreply@anthropic.com>"
T2 = "Claude-Session: https://claude.ai/code/session_015ptydWtHPYTwrwMYpgde4U"
for p in sys.argv[1:]:
    raw = open(p, "rb").read(); t = raw.decode("utf-8")
    lines = t.split("\n")
    print(p.split("/")[-1], "bytes", len(raw), "CR", raw.count(b"\r"), "TAB", raw.count(b"\t"), "ends with single newline", t.endswith("\n") and not t.endswith("\n\n"))
    body = lines[:-1] if lines[-1] == "" else lines
    over = [(i+1, len(l)) for i, l in enumerate(body) if len(l) > 72]
    print("  subject cols", len(body[0]), "; lines > 72 cols:", over)
    print("  last two lines are trailers:", body[-2:] == [T1, T2], "; blank before:", body[-3] == "", "; T1 count", t.count(T1), "T2 count", t.count(T2))
    rest = t.replace(T1, "").replace(T2, "")
    hits = re.findall(r"(?i)\b(claude|opus|sonnet|haiku|anthropic|gpt|gemini|model)\b[^\n]{0,30}", rest)
    print("  model-ish words outside trailers:", hits)
    print("  non-ascii chars:", sorted(set(c for c in t if ord(c) > 127)))
