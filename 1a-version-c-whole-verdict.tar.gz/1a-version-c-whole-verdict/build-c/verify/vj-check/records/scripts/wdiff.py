import json, sys, difflib
from pathlib import Path
T = Path(sys.argv[1]); VB = Path(sys.argv[2])
for skill, bef in (("job-underwriter","ju-evals.json"),("mock-interview","mi-evals.json")):
    N = json.loads((T/"skills"/skill/"evals/evals.json").read_text(encoding="utf-8")); O = json.loads((VB/bef).read_text(encoding="utf-8"))
    items = [(f"clause {k}", O["clauses"][k], N["clauses"][k]) for k in N["clauses"] if N["clauses"][k] != O["clauses"][k]]
    for e, f in zip(N["evals"], O["evals"]):
        for i, (a, b) in enumerate(zip(e["expectations"], f["expectations"])):
            if a != b: items.append((f"case {e['id']} #{i+1}", b, a))
    for lab, old, new in items:
        print(f"===== {skill} {lab}")
        a, b = old.split(" "), new.split(" ")
        for op, i1, i2, j1, j2 in difflib.SequenceMatcher(None, a, b, autojunk=False).get_opcodes():
            if op == "equal": continue
            print(f"  [{op}] -{' '.join(a[i1:i2])!r}\n         +{' '.join(b[j1:j2])!r}")
