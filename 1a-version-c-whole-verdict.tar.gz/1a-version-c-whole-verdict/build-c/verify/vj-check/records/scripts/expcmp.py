import json, sys
base = json.load(open(sys.argv[1], encoding="utf-8"))
for f in sys.argv[2:]:
    d = json.load(open(f, encoding="utf-8"))
    for s, want in (("job-underwriter", range(1,7)), ("mock-interview", range(1,9)), ("resume-tailor", range(1,6))):
        same = [i for i in want if d[s].get(str(i)) == base[s].get(str(i))]
        print(f.split("/")[-1], s, f"{len(same)}/{len(want)} identical to 7b56c17", "base ids", sorted(map(int, base[s])))
