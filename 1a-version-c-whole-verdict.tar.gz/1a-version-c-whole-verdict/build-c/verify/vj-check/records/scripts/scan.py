import os, sys, re, io, zipfile, zlib, base64
from pathlib import Path
sys.dont_write_bytecode = True
EMAIL = os.environ.pop("SCAN_EMAIL", "")
assert "@" in EMAIL and len(EMAIL) > 5, "no email"
LOCAL = EMAIL.split("@")[0]
em = EMAIL.lower().encode(); lp = LOCAL.lower().encode()
KEYS = re.compile(rb"sk-ant-|ghp_[A-Za-z0-9]|github_pat_|AKIA[0-9A-Z]{16}|-----BEGIN")
HOMES = re.compile(rb"/home/(?!user(?![A-Za-z0-9._-]))[A-Za-z0-9._-]+|/Users/[A-Za-z0-9._-]+|[Cc]:\\\\?Users")
ROOT = re.compile(rb"/root(?![A-Za-z0-9_-])")
def scan_bytes(b):
    lb = b.lower()
    return [lb.count(em), lb.count(lp), len(KEYS.findall(b)), len(HOMES.findall(b)), len(ROOT.findall(b))]
def git_b85(lines):
    out = b""
    for l in lines:
        c = l[0]; n = ord(c) - 64 if "A" <= c <= "Z" else ord(c) - 96 + 26
        out += base64.b85decode(l[1:])[:n]
    return out
def texts_of(path):
    """yield (label, bytes) for a file, its zip members, and decoded git binary hunks"""
    b = path.read_bytes(); yield (str(path), b)
    if zipfile.is_zipfile(path):
        with zipfile.ZipFile(path) as z:
            for n in z.namelist(): yield (f"{path}!{n}", z.read(n))
    if path.suffix == ".patch":
        t = b.decode("utf-8", "surrogateescape").split("\n"); i = 0
        while i < len(t):
            if t[i].startswith(("literal ", "delta ")):
                j = i + 1; block = []
                while j < len(t) and t[j]: block.append(t[j]); j += 1
                raw = zlib.decompress(git_b85(block)); yield (f"{path}#hunk{i}", raw)
                if raw[:2] == b"PK":
                    try:
                        with zipfile.ZipFile(io.BytesIO(raw)) as z:
                            for n in z.namelist(): yield (f"{path}#hunk{i}!{n}", z.read(n))
                    except zipfile.BadZipFile: pass
                i = j
            else: i += 1
groups = [(a.split("=", 1)[0], [Path(p) for p in a.split("=", 1)[1].split(",")]) for a in sys.argv[1:]]
print(f"{'group':28} {'files':>6} {'texts':>6} {'email':>6} {'local':>6} {'keys':>5} {'homes':>6} {'/root':>6}")
for g, roots in groups:
    files = []
    for r in roots: files += [r] if r.is_file() else sorted(p for p in r.rglob("*") if p.is_file())
    tot = [0]*5; nt = 0; where = {}
    for f in files:
        for lab, b in texts_of(f):
            nt += 1; c = scan_bytes(b)
            for k in range(5): tot[k] += c[k]
            if c[0] or c[1] or c[2] or c[3]: where[lab] = c[:4]
    print(f"{g:28} {len(files):6} {nt:6} {tot[0]:6} {tot[1]:6} {tot[2]:5} {tot[3]:6} {tot[4]:6}")
    for lab, c in list(where.items())[:8]: print(f"    hit: {lab} email {c[0]} local {c[1]} keys {c[2]} homes {c[3]}")
# in-memory controls (nothing written)
ctl = scan_bytes(b"x " + EMAIL.encode() + b" y AKIA" + b"A"*16 + b" /home/bob/x /home/user/ok /root/ok")
print("controls (email, local, keys, homes, /root) on a planted string:", ctl, "expected [1, 1, 1, 1, 1]")
