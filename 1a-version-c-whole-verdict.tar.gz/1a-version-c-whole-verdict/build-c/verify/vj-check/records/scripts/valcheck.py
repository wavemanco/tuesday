import json, sys
v = json.load(open(sys.argv[1], encoding="utf-8")); k = json.load(open(sys.argv[2], encoding="utf-8")); man = open(sys.argv[3], encoding="utf-8").read()
rows = []
for rel, h in v["cases"].items(): rows.append((f"case {rel}", h, k["cases"]["candidate"].get(rel)))
for key, h in v["tuesday_digests"].items(): rows.append((f"digest {key}", h, k["digests"]["candidate"].get(key)))
for key, h in v["payload"].items(): rows.append((f"payload {key}", h, k["payload"]["candidate"].get(key)))
for name, d in v["e23"].items():
    rows.append((f"e23 {name}", d["regen"], k["e23"].get(name)))
for key, h in v["measured"].items(): rows.append((f"measured {key}", h, k["measured"].get(key)))
bad = 0
for lab, mine, kit in rows:
    inman = str(mine) in man
    ok = mine == kit
    bad += (not ok) or (not inman and lab.split()[0] != "measured")
    print(f"{'ok ' if ok else 'BAD'} {lab:55} {str(mine)[:16]} kit-equal={ok} printed-in-manifest={inman}")
print("e23 all regen==disk and identical:", all(d["regen_eq_disk"] and d["identical"] for d in v["e23"].values()))
print("builds disk == generated:", v["builds_disk_equals_generated"])
print("problems:", bad)
