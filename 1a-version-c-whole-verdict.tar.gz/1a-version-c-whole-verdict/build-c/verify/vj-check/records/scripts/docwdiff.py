import sys, difflib
a = open(sys.argv[1], encoding="utf-8").read().split("\n"); b = open(sys.argv[2], encoding="utf-8").read().split("\n")
sm = difflib.SequenceMatcher(None, a, b, autojunk=False)
for op, i1, i2, j1, j2 in sm.get_opcodes():
    if op == "equal": continue
    print(f"@@ {op} old {i1+1}-{i2} new {j1+1}-{j2}")
    if op == "replace" and (i2 - i1) == (j2 - j1):
        for x, y in zip(a[i1:i2], b[j1:j2]):
            wa, wb = x.split(" "), y.split(" ")
            for o, p1, p2, q1, q2 in difflib.SequenceMatcher(None, wa, wb, autojunk=False).get_opcodes():
                if o != "equal": print(f"   [{o}] -{' '.join(wa[p1:p2])!r}\n          +{' '.join(wb[q1:q2])!r}")
    else:
        for x in a[i1:i2]: print("   - " + x[:3000])
        for y in b[j1:j2]: print("   + " + y[:3000])
