import json, sys
B = sys.argv[1]
a = json.load(open(B+"/verify/vj/before/edits.json", encoding="utf-8")); b = json.load(open(B+"/edits.json", encoding="utf-8"))
print("top keys same:", list(a) == list(b), "; non-phase top-level equal:", all(a[k] == b[k] for k in a if k != "phases"))
for pa, pb in zip(a["phases"], b["phases"]):
    print("phase", pa["phase"], pa["name"], "meta equal:", {k: pa[k] == pb[k] for k in pa if k != "edits"}, "n edits", len(pa["edits"]), len(pb["edits"]))
    ida = [e["id"] for e in pa["edits"]]; idb = [e["id"] for e in pb["edits"]]
    print("  ids/order same:", ida == idb)
    for ea, eb in zip(pa["edits"], pb["edits"]):
        if ea != eb:
            ch = {k: (ea.get(k), eb.get(k)) for k in set(ea) | set(eb) if ea.get(k) != eb.get(k)}
            print("  CHANGED", ea["id"], sorted(ch))
            for k, (x, y) in ch.items():
                if isinstance(x, str) and isinstance(y, str) and y.startswith(x):
                    print("     ", k, "APPENDED:", repr(y[len(x):]))
                elif isinstance(x, list) and isinstance(y, list):
                    print("     ", k, x, "->", y)
                elif isinstance(x, str) and isinstance(y, str):
                    import difflib
                    for op in difflib.SequenceMatcher(None, x, y, autojunk=False).get_opcodes():
                        if op[0] != "equal": print("     ", k, op[0], repr(x[op[1]:op[2]][:300]), "->", repr(y[op[3]:op[4]][:600]))
                else:
                    print("     ", k, type(x), type(y))
print(sorted(set(k for p in b["phases"] for e in p["edits"] for k in e)))
