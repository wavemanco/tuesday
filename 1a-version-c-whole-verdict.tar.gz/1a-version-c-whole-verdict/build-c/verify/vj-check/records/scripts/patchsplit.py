import sys, re
def split(p):
    t = open(p, encoding="utf-8", errors="surrogateescape").read()
    parts = re.split(r"(?m)^(?=diff --git )", t)
    return {re.match(r"diff --git a/(\S+)", x).group(1): x for x in parts if x.startswith("diff --git")}
a, b = split(sys.argv[1]), split(sys.argv[2])
print("same path list in order:", list(a) == list(b))
print("differing hunks:", [k for k in a if a[k] != b.get(k)])
