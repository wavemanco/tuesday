import json, sys, collections
from pathlib import Path
B = Path(sys.argv[1]); T = B/"tree"
b = json.load(open(B/"edits.json", encoding="utf-8"))
ops = collections.Counter(); res = collections.Counter(); bad = []
for p in b["phases"]:
    if p["phase"] != "C": continue
    for e in p["edits"]:
        ops[e["op"]] += 1
        f = T/e["file"]; txt = f.read_text(encoding="utf-8") if f.exists() else None
        ok = None
        if e["op"] == "add_clause":
            ok = json.loads(txt)["clauses"].get(e["name"]) == e["text"]
        elif e["op"] == "add_case":
            ok = any(c == e["case"] for c in json.loads(txt)["evals"])
        elif e["op"] == "append_eval":
            ok = any(c == e["case"] for c in json.loads(txt)["evals"])
        elif "new" in e:
            ok = e["new"] in txt and (e.get("old") is None or e["old"] not in txt or e["old"] in e["new"])
        res[(e["op"], ok)] += 1
        if not ok: bad.append((e["id"], e["op"], e["file"]))
print(dict(ops)); print(dict(res)); print("not verified:", bad)
