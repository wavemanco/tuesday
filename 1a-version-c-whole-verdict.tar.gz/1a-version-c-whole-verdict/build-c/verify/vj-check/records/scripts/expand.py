import sys, json
from pathlib import Path
sys.dont_write_bytecode = True
T = Path(sys.argv[1]).resolve(); out = sys.argv[2]
sys.path.insert(0, str(T / "evals"))
import fixture_clauses as fc
assert Path(fc.__file__).resolve().is_relative_to(T), fc.__file__
res = {}
for s in ("job-underwriter", "mock-interview", "resume-tailor"):
    res[s] = {str(c["id"]): json.dumps(c, ensure_ascii=False, sort_keys=True) for c in fc.load_cases(T / "skills" / s / "evals" / "evals.json")}
json.dump(res, open(out, "w", encoding="utf-8"), ensure_ascii=False, indent=0)
print(T, {s: sorted(map(int, v)) for s, v in res.items()})
