import sys, json, hashlib, subprocess
from pathlib import Path
sys.dont_write_bytecode = True
B = Path(sys.argv[1]); K = Path(sys.argv[2]); V = Path(sys.argv[3])
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
def exps(tree):
    code = f"""
import sys, json, hashlib; sys.dont_write_bytecode=True; sys.path.insert(0, {str(Path(tree)/'evals')!r}); import fixture_clauses as fc
from pathlib import Path
r = {{}}
for s in ('job-underwriter','mock-interview'):
    p = Path({str(tree)!r})/'skills'/s/'evals'/'evals.json'
    d = json.loads(p.read_text(encoding='utf-8'))
    for k, v in d['clauses'].items(): r[f'clause {{s}} {{k}}'] = hashlib.sha256(v.encode()).hexdigest()
    for c in fc.load_cases(p):
        for i, e in enumerate(c['expectations'], 1): r[f'exp {{s}} {{c["id"]}} #{{i}}'] = hashlib.sha256(e.encode()).hexdigest()
print(json.dumps(r))
"""
    return json.loads(subprocess.run([sys.executable, "-I", "-B", "-c", code], capture_output=True, text=True, check=True).stdout)
def vals(d, tr, kitdir, docs):
    o = {f"case {s}": sha(tr/"skills"/s/"evals/evals.json") for s in ("job-underwriter", "mock-interview")}
    o.update({f"e23 {p.name}": sha(p) for p in sorted((d/"e23").iterdir())})
    o.update({"patch": sha(d/"patches/C-c.patch"), "name-status": sha(d/"patches/C-c.name-status"), "expect": sha(kitdir/"expect-c.json"), "kit README": sha(kitdir/"README.md")})
    for f in docs:
        if (d/f).exists(): o[f"doc {f}"] = sha(d/f)
    o.update(exps(tr))
    return o
DOCS = ("spec.md", "manifest.md", "owner-summary.md", "edits.json", "commit-msg.txt", "revert-msg.txt", "expect-c.after.json")
cur = vals(B, B/"tree", K, DOCS); cur["doc expect-c.after"] = sha(B/"verify/expect-c.after.json")
curset = set(cur.values())
old = {}
for tag, d, tr in (("vj", B/"verify/vj/before", V/"vjbefore-tree"), ("vi", B/"verify/vi/before", V/"vibefore-tree"),
                   ("vh", B/"verify/vh/before", B/"verify/vh/before/tree"), ("vg", B/"verify/vg/before", B/"verify/vg/before/tree")):
    for k, v in vals(d, tr, d/"kit", DOCS).items():
        if v not in curset: old.setdefault(v, f"{tag} {k}")
json.dump({"current": cur, "old": {v: k for v, k in old.items()}}, open(V/"old-values.json", "w"), indent=1)
targets = [B/"spec.md", B/"manifest.md", B/"owner-summary.md", B/"edits.json", K/"README.md", K/"expect-c.json", B/"commit-msg.txt", B/"revert-msg.txt"]
texts = {t: t.read_text(encoding="utf-8") for t in targets}
print("superseded values (not equal to any current value):", len(old))
kinds = {}
for v, k in old.items(): kinds[k.split()[1]] = kinds.get(k.split()[1], 0) + 1
print("  by kind:", kinds)
hits = 0
for v, k in old.items():
    for t, s in texts.items():
        if v[:8] in s:
            hits += 1; i = s.index(v[:8]); print("HIT", k, v[:12], "in", t.name, "context:", repr(s[max(0,i-60):i+20]))
print("hits in targets (8-char prefix):", hits)
ctl = 0
for v, k in old.items():
    d = B/"verify"/k.split()[0]/"before"
    if any(v[:8] in (d/f).read_text(encoding="utf-8") for f in ("spec.md", "manifest.md", "kit/expect-c.json", "owner-summary.md") if (d/f).exists()): ctl += 1
print("positive control: superseded values found in their own before copies:", ctl, "of", len(old))
