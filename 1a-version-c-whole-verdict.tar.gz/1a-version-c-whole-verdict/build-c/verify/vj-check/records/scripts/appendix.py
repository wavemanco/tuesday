import sys, re, json, hashlib
from pathlib import Path
sys.dont_write_bytecode = True
T = Path(sys.argv[1]).resolve(); man = open(sys.argv[2], encoding="utf-8").read()
sys.path.insert(0, str(T / "evals")); import fixture_clauses as fc
assert Path(fc.__file__).resolve().is_relative_to(T)
cases = {s: {c["id"]: c for c in fc.load_cases(T/"skills"/s/"evals"/"evals.json")} for s in ("job-underwriter", "mock-interview")}
app = man[man.index("## Appendix A"):]
sec = None; n = ok = 0; bad = []; entries = []
for line in app.split("\n"):
    m = re.match(r"#### (job-underwriter|mock-interview) (\d+)$", line)
    if m: sec = (m.group(1), int(m.group(2))); continue
    m = re.match(r"- \*\*#(\d+), ([^*]*)\*\* \(`([0-9a-f]+)…`\)\. (.*)$", line)
    if m and sec:
        k = int(m.group(1)); pre = m.group(3); text = m.group(4)
        exp = cases[sec[0]][sec[1]]["expectations"][k-1]
        h = hashlib.sha256(exp.encode("utf-8")).hexdigest(); n += 1; entries.append((sec, k, m.group(2)))
        if h.startswith(pre) and text == exp: ok += 1
        else: bad.append((sec, k, h.startswith(pre), text == exp))
print("appendix entries", n, "ok", ok, "bad", bad)
for e in entries:
    if e[0][1] in (8, 10, 11, 12) : print("  ", e)
