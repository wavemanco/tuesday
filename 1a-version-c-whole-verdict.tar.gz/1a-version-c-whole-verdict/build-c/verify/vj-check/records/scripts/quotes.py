import json, re, sys
from pathlib import Path
V = Path(sys.argv[1]); T = Path(sys.argv[2]); VB = Path(sys.argv[3])
ju = json.loads((T/"skills/job-underwriter/evals/evals.json").read_text(encoding="utf-8"))
mi = json.loads((T/"skills/mock-interview/evals/evals.json").read_text(encoding="utf-8"))
jub = json.loads((VB/"ju-evals.json").read_text(encoding="utf-8"))
mib = json.loads((VB/"mi-evals.json").read_text(encoding="utf-8"))
def ev(d, i): return next(e for e in d["evals"] if e["id"] == i)
items = [("ju_npa", ju["clauses"]["no_party_accusation"], jub["clauses"]["no_party_accusation"]),
         ("mi_nfc", mi["clauses"]["no_fraud_claim"], mib["clauses"]["no_fraud_claim"]),
         ("mi_ip", mi["clauses"]["invite_pointer"], mib["clauses"]["invite_pointer"]),
         ("ju_rv", ju["clauses"]["request_verdicts"], jub["clauses"]["request_verdicts"]),
         ("mi_rv", mi["clauses"]["request_verdicts"], mib["clauses"]["request_verdicts"]),
         ("mi10_3", ev(mi,10)["expectations"][2], ev(mib,10)["expectations"][2]),
         ("mi10_9", ev(mi,10)["expectations"][8], ev(mib,10)["expectations"][8]),
         ("mi11_3", ev(mi,11)["expectations"][2], ev(mib,11)["expectations"][2]),
         ("mi11_6", ev(mi,11)["expectations"][5], ev(mib,11)["expectations"][5])]
def sents(t): return re.split(r"(?<=[.])\s+(?=[A-Z])", t)
for k, new, old in items:
    q = (V/"q"/f"{k}.txt").read_text(encoding="utf-8").rstrip("\n")
    print(f"{k}: quote==shipped {q == new}; words {len(old.split())}->{len(new.split())}; sentences before {[len(s.split()) for s in sents(old)]} after {[len(s.split()) for s in sents(new)]}")
    if q != new:
        import difflib
        for op in difflib.SequenceMatcher(None, q, new, autojunk=False).get_opcodes():
            if op[0] != "equal": print("   ", op[0], repr(q[op[1]:op[2]]), repr(new[op[3]:op[4]]))
# other unchanged checks
print("JU 8 unchanged:", ev(ju,8) == ev(jub,8), " MI 12 unchanged:", ev(mi,12) == ev(mib,12), " no_accusation unchanged:", ju["clauses"]["no_accusation"] == jub["clauses"]["no_accusation"])
