import json, re, sys
from pathlib import Path
B = Path(sys.argv[1])
spec = (B/"spec.md").read_text(encoding="utf-8").split("\n")
def corpus(p):
    d = json.loads(Path(p).read_text(encoding="utf-8")); out = []
    for ph in d["phases"]:
        for e in ph["edits"]:
            for k in ("text", "new"):
                if isinstance(e.get(k), str): out.append(e[k])
            if isinstance(e.get("case"), dict): out += e["case"]["expectations"]
    return "\n".join(out)
secs = {"VG": (153, 168, B/"verify/vh/before/edits.json"), "VH": (169, 185, B/"verify/vi/before/edits.json"),
        "VI": (186, 205, B/"verify/vj/before/edits.json"), "VJ": (206, 224, B/"edits.json")}
for tag, (a, b, src) in secs.items():
    c = corpus(src); found = miss = 0; misses = []
    text = "\n".join(spec[a-1:b])
    for q in re.findall(r'"([^"]{40,}?)"(?=[\s,.;:)\]]|$)', text):
        frags = [f.strip(" .;,") for f in re.split(r"…", q) if len(f.strip(" .;,")) >= 12]
        if not frags: continue
        if all(f in c for f in frags): found += 1
        else: miss += 1; misses.append(q[:150])
    print(f"{tag} (spec {a}-{b}) vs {src.relative_to(B)}: {found} quotes found, {miss} not found")
    for m in misses: print("    not found:", m)
