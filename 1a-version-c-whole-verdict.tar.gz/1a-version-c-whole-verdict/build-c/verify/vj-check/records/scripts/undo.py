import json, sys
from pathlib import Path
T = Path(sys.argv[1]); VB = Path(sys.argv[2])
def enc(s): return json.dumps(s, ensure_ascii=False)[1:-1]
for skill, bef in (("job-underwriter","ju-evals.json"),("mock-interview","mi-evals.json")):
    raw = (T/"skills"/skill/"evals/evals.json").read_text(encoding="utf-8")
    old_raw = (VB/bef).read_text(encoding="utf-8")
    N = json.loads(raw); O = json.loads(old_raw)
    pairs = []
    for k in N["clauses"]:
        if N["clauses"][k] != O["clauses"][k]: pairs.append((N["clauses"][k], O["clauses"][k]))
    for e, f in zip(N["evals"], O["evals"]):
        for a, b in zip(e["expectations"], f["expectations"]):
            if a != b: pairs.append((a, b))
    undone = raw
    for a, b in pairs:
        c = undone.count(enc(a)); assert c == 1, (c, a[:60])
        undone = undone.replace(enc(a), enc(b))
    print(skill, len(pairs), "changes; undo gives before byte for byte:", undone.encode() == (VB/bef).read_bytes())
