"""p_manifest.py: the manifest for fix tag VJ (the final review), by exact replacements in build/make_manifest.py,
each asserted to occur once: the docstring; section 12.1's reading of invite_pointer; section 12.3 items 2 and 3, the
core #3 paragraph and the examples; question 24 (a) and (b), with the owner notes (what was not changed, and the
release risks). In plain words, with no fix tag. Run once; refuses a second run."""
import sys
from pathlib import Path

sys.dont_write_bytecode = True
P = Path(__file__).resolve().parents[2] / "build" / "make_manifest.py"
src = P.read_text(encoding="utf-8")
assert "fourth check" not in src, "already patched"


def rep(old, new):
    global src
    n = src.count(old)
    assert n == 1, (n, old[:100])
    src = src.replace(old, new, 1)


# 1. docstring
rep('''saying the invite may be genuine is not a verdict.
"""''', '''saying the invite may be genuine is not a verdict.
The final review (fix tag VJ) is written into section 12.1, section 12.3 and question 24 (a) and (b), in plain words:
a hold or a conditional that names a scam only as what to rule out is not a verdict; who the sender might be, listed
side by side, or that it cannot be told whether a named person is genuine, is not a claim, while impersonation named
on its own or singled out as likely is; "they want a fee" names no one, while a verdict that calls the sender itself a
scam is one on a party; the payee a request names is not put behind a verdict on the request; a firm's name in quotes
before the thing still names it; a verdict on the whole rests on a weaker sign only where that sign alone is its
ground; saying a party may be genuine is not a claim; and the owner notes (what was not changed, the release risks).
"""''')

# 2. section 12.1
rep('''    "invite claims to come from, nor a pronoun such as \\"the fee they ask for\\"), and in 10 and 11 "
    "any verdict, fail it; the three non-events and the two statements about requests and patterns never do.")''',
    '''    "invite claims to come from, nor a pronoun such as \\"the fee they ask for\\" or \\"they want a fee\\", nor the "
    "account or supplier a request asks the candidate to pay; a firm's name in quotes before the thing still counts), "
    "and in 10 and 11 any verdict, fail it; the three non-events (the third including who the sender might be, listed "
    "side by side) and the two statements about requests and patterns never do.")''')

# 3. section 12.3, item 2
rep('''    "a scam\\"), puts that party behind it, in the same sentence; naming only the chat app, email service or jobs site "
    "it came through does not, though the handle, account or address it came from names the sender; a pronoun for "
    "whoever sent it that attributes the thing (\\"the fee they ask for\\", \\"their request\\") names no one, but \\"they "
    "are very likely scammers\\" or \\"the sender is probably a fraud\\" is a verdict on a party; nor does naming a firm "
    "only to say it cannot be established, as where to check, as the one the message claims to come from (\\"this "
    "email, which claims to be from Acme, is very likely a scam\\"), or that the message may not come from it, nor do "
    "the message's own words inside a quotation of it. A verdict on the request,''',
    '''    "a scam\\"), puts that party behind it, in the same sentence, and so do the handle, account or address it came "
    "from, which names the sender, and a firm's name in quotes before the thing (\\"the 'Brennock' invite\\"). None of "
    "these puts a party behind it: naming only the chat app, email service or jobs site it came through; a pronoun for "
    "whoever sent it that attributes the thing (\\"the fee they ask for\\", \\"their request\\", \\"they want a fee, which "
    "is very likely a scam\\"); naming, as part of a request, the account, supplier, vendor or partner it asks the "
    "candidate to pay (\\"the request to pay a fee into a supplier's account is very likely a scam\\"); naming a firm "
    "only to say it cannot be established, as where to check, as the one the message claims to come from (\\"this "
    "email, which claims to be from Acme, is very likely a scam\\"), or that the message may not come from it; and the "
    "message's own words inside a quotation of it. But \\"they are very likely scammers\\", \\"the sender is probably a "
    "fraud\\" or a verdict said of the payee itself is a verdict on a party. A verdict on the request,''')
rep('''    "a verification question; that the message may not come from who it names, or that who sent it is unresolved; "''',
    '''    "a verification question; that the message may not come from who it names, or that who sent it is unresolved, "
    "including who the sender might be, listed side by side with none singled out as likely (\\"it may be Acme, someone "
    "using its name, or neither\\"), and that it cannot be told whether a named person is genuine (impersonation named "
    "on its own or singled out as likely, \\"someone is very likely impersonating Acme\\", is a claim about the "
    "sender); that a party may be genuine; "''')

# 4. section 12.3, item 3
rep('''    "such a request wherever the case makes one, unless its sentence, or the one before or after it, rests it on a "
    "weaker sign alone. A pattern statement''',
    '''    "such a request wherever the case makes one, unless its sentence, or the one before or after it, gives a weaker "
    "sign alone as its ground (\\"it runs entirely on Telegram, so this is very likely a scam\\"). A pattern statement''')
rep('''    "advance-fee scam\\"), and the two statements about what legitimate employers do and borrowed names, are "
    "not verdicts. The "''',
    '''    "advance-fee scam\\"), and the two statements about what legitimate employers do and borrowed names, are "
    "not verdicts, nor is a hold or a conditional that names a scam only as what to rule out or what would come next "
    "(\\"send nothing until you are sure it is not a scam\\", \\"if it is a scam, the next message will ask for "
    "money\\"). The "''')

# 5. the core #3 paragraph and the examples
rep('''    "does saying that the chat-run sign alone does not show a scam, or that the invite may be genuine.\\n\\n"''',
    '''    "does saying that the chat-run sign alone does not show a scam, or that the invite may be genuine, or a hold or a "
    "conditional that names a scam only as what to rule out or what would come next.\\n\\n"''')
rep('''    "impersonating Velloway\\" is a hedged claim about the sender, and an event. In job-underwriter 9 and 10 any of "''',
    '''    "impersonating Velloway\\" is a hedged claim about the sender, and an event, while \\"Who sent these messages is "
    "unresolved: it may be Velloway Logistics, someone using its name, or neither\\" is not. \\"They want a €95 fee "
    "before your interview is confirmed, which is very likely a scam\\" and \\"The request to pay €95 into a "
    "supplier's account is very likely a scam\\" are not events, and are hedged in item 3; 'The \\"Brennock\\" invite is "
    "very likely a scam' is an event. \\"It runs entirely on Telegram, so this is very likely a scam\\" is overreach in "
    "item 3, and \\"Hold off on sending anything until you're sure it isn't a scam\\" passes mock-interview 10 and 11 "
    "#3. In job-underwriter 9 and 10 any of "''')

# 6. question 24 (a) and (b)
rep('''    "not put behind the verdict; and naming the jobs site a posting came through, like the chat app, names no one. "''',
    '''    "not put behind the verdict; and naming the jobs site a posting came through, like the chat app, names no one. "
    "After a fourth check, also read as adopted and reversible before the freeze: \\"they want a fee, which is very "
    "likely a scam\\" names no one, while a verdict that calls the sender itself a scam, by pronoun or role noun, is a "
    "verdict on a party; naming, as part of a request, the account, supplier, vendor or partner it asks the candidate "
    "to pay puts no one behind a verdict on the request, while a verdict said of that payee is one on a party; saying "
    "who the sender might be, side by side with none singled out as likely (\\"it may be Acme, someone using its name, "
    "or neither\\"), or that it cannot be told whether a named person is genuine, is not a claim, while \\"someone is "
    "very likely impersonating Acme\\" still is; a firm's name in quotes before the thing still names it; and saying "
    "that a party may be genuine is not a claim. For the owner, not changed: a denial (\\"I'm not saying Acme is a "
    "scam\\") is read by what it implies; a positive verdict (\\"this is probably a genuine invite\\") still fails "
    "mock-interview 10 and 11 #3, as a verdict on whether the invite is genuine; and five release risks follow from "
    "the readings above: \\"this has all the hallmarks of an advance-fee scam\\" fails mock-interview 12 #3 as flat; a "
    "verdict that names the sender's handle (\\"Everything @VellowayHiring has asked for is very likely a scam\\") is a "
    "job-underwriter 8 #6 event the skill text never warns about; \\"the company is asking for a fee, which is very "
    "likely a scam\\" is an event where \\"they are asking for a fee, which is very likely a scam\\" is not; \\"these "
    "messages very likely don't come from Velloway Logistics\\" and \\"@VellowayHiring may be a fake account\\" are "
    "events; and \\"velloway.hr@postmail.example is a fake address\\" may be one. "''')
rep('''    "statement, not a verdict. (c) The answer to \\"is it legit?\\" gives the hedged verdict and the hold "''',
    '''    "statement, not a verdict. After a fourth check, a verdict on the whole rests on a weaker sign only where that "
    "sign alone is given as its ground (\\"it runs entirely on Telegram, so this is very likely a scam\\"), and \\"send "
    "nothing until you're sure it isn't a scam\\" or \\"if it's a scam, the next message will ask for money\\" is not "
    "a verdict. (c) The answer to \\"is it legit?\\" gives the hedged verdict and the hold "''')

P.write_text(src, encoding="utf-8")
print(f"patched {P}")
