"""show.py (VJ): print the clauses and per-case lines VJ changes, as they now ship in B/tree, with word counts and
sentence lengths before (vj/before) and after; list every other clause or case field that differs. Reads only."""
import json
import re
import sys
from pathlib import Path

sys.dont_write_bytecode = True
V = Path(__file__).resolve().parent
B = V.parents[1]


def sents(t):
    return re.split(r"(?<=[.])\s+(?=[A-Z])", t)


for skill, short in (("job-underwriter", "ju"), ("mock-interview", "mi")):
    was = json.loads((V / "before" / f"{short}-evals.json").read_text(encoding="utf-8"))
    now = json.loads((B / "tree" / "skills" / skill / "evals" / "evals.json").read_text(encoding="utf-8"))
    for k in now["clauses"]:
        a, b = was["clauses"].get(k), now["clauses"][k]
        if a != b:
            print(f"== {skill} clause {k}: {len(a.split())} -> {len(b.split())} words; sentences before "
                  f"{[len(x.split()) for x in sents(a)]}, after {[len(x.split()) for x in sents(b)]}")
            print(b)
            print()
    wa = {c["id"]: c for c in was["evals"]}
    for c in now["evals"]:
        o = wa[c["id"]]
        for key in sorted(set(c) | set(o)):
            if key != "expectations" and c.get(key) != o.get(key):
                print(f"!! {skill} {c['id']} field {key} differs")
        for n, (x, y) in enumerate(zip(o["expectations"], c["expectations"]), 1):
            if x != y:
                print(f"== {skill} {c['id']} #{n}: {len(x.split())} -> {len(y.split())} words")
                print(y)
                print()
        if len(o["expectations"]) != len(c["expectations"]):
            print(f"!! {skill} {c['id']} expectation count differs")
