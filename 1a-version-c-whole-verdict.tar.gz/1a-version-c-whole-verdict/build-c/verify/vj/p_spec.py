"""p_spec.py: the spec for fix tag VJ (the final review), by exact replacements in build/make_spec.py, each asserted
to occur once:
- the docstring and the summary: four reviews;
- the VK1, VK3 and VW notes and the VG and VH intros point to VJ;
- the VI subsection quotes VI's own output (verify/vj/before/edits.json), its intro says plainly which findings were
  fixed where (the records lens's observation), and its Checked bullet and VI5 bullet point to VJ;
- a new subsection, "The final review (VJ)": each change with the clause text as it ships (asserted against
  edits.json and against VI's own output), the sentence lengths before and after VJ5, what was not changed and why,
  the records fixes (P1, P2, the VI intro, the O2 line made exact), gating, the record and the lint;
- section 6.1: items 2 and 3, the table (new and extended rows), "Core #3 and item 3 agree";
- section 9's lint summary (3j) and owner question 15 (a) and (b).
Run once; refuses a second run."""
import sys
from pathlib import Path

sys.dont_write_bytecode = True
P = Path(__file__).resolve().parents[2] / "build" / "make_spec.py"
src = P.read_text(encoding="utf-8")
assert "_VJC" not in src, "already patched"


def rep(old, new):
    global src
    n = src.count(old)
    assert n == 1, (n, old[:100])
    src = src.replace(old, new, 1)


# 1. docstring and summary
rep('''five per-case lines only; the VH subsection now quotes VH's own output (verify/vi/before/edits.json), and the VI
subsection the text as it ships.
"""''', '''five per-case lines only; the VH subsection now quotes VH's own output (verify/vi/before/edits.json).
The final review (fix tag VJ: the grader lens and the records lens on VI) again changes the same five fixture clauses and
four of those per-case lines (MI 10 and 11) only; the VI subsection now quotes VI's own output
(verify/vj/before/edits.json), and the VJ subsection the text as it ships.
"""''')
rep('''  "Three reviews of that change (fix tags VG, VH and VI, below) made the graders' readings more precise, in the fixture "''',
    '''  "Four reviews of that change (fix tags VG, VH, VI and VJ, below) made the graders' readings more precise, in the fixture "''')

rep('''- {f for f, _ in CHANGES} - {"VO", "VW", "VG", "VH", "VI"}, set(by_fix)''',
    '''- {f for f, _ in CHANGES} - {"VO", "VW", "VG", "VH", "VI", "VJ"}, set(by_fix)''')

# 2. VK1, VK3, VW notes; VG and VH intros
rep('''     "counted-pattern note to the first, and whether a named employer is involved to the third.)"),''',
    '''     "counted-pattern note to the first, and whether a named employer is involved to the third; VJ adds, after the "
     "three, that the third includes who the sender might be, listed side by side, and that it cannot be told whether "
     "a named person is genuine, and splits its long sentence into the three cases and a list of what puts no one "
     "behind a verdict.)"),''')
rep('''     "thing, a firm the material claims to come from and its quoted words, and, in `no_fraud_claim`, attribution read "
     "in the same sentence."),''',
    '''     "thing, a firm the material claims to come from and its quoted words, and, in `no_fraud_claim`, attribution read "
     "in the same sentence; VJ ends the attribution sentence at \\"puts that party behind it\\", lists in one sentence "
     "what puts no party behind a verdict (a payee named as part of a request among it), and says that a firm's name "
     "quoted before the thing is still a name before it."),''')
rep('''  "below) reads a firm the invite claims to come from, its quoted words, a pronoun and the jobs site as the party "
  "bars do.")''', '''  "below) reads a firm the invite claims to come from, its quoted words, a pronoun and the jobs site as the party "
  "bars do; the final one (VJ, below) names its three cases first and lists in one sentence what puts no one behind "
  "a verdict.")''')
rep('''  "to a paragraph or entry that names no such request; the third (VI, below) to the paragraph or entry the verdict "
  "is in, wherever it sits there.")''', '''  "to a paragraph or entry that names no such request; the third (VI, below) to the paragraph or entry the verdict "
  "is in, wherever it sits there; and the final one (VJ, below) rests a verdict on the whole on a weaker sign only "
  "where that sign alone is given as its ground.")''')
rep('''  "read from its own output (`verify/vh/before/edits.json`); the second and third reviews (VH and VI, below) change "''',
    '''  "read from its own output (`verify/vh/before/edits.json`); the second, third and final reviews (VH, VI and VJ, below) change "''')
rep('''  "left it, read from its own output (`verify/vi/before/edits.json`); the third review (VI, below) changes several "
  f"of them again [{', '.join(vh_ids)}]:\\n")''', '''  "left it, read from its own output (`verify/vi/before/edits.json`); the third and final reviews (VI and VJ, below) "
  f"change several of them again [{', '.join(vh_ids)}]:\\n")''')

# 3. the VI subsection reads VI's own output
rep('''_VIC = {"no_party_accusation": EDITS["C06a"]["text"], "ju_verdicts": EDITS["C06b"]["text"],
        "invite_pointer": EDITS["C26"]["text"], "no_fraud_claim": EDITS["C27"]["text"],
        "mi_verdicts": EDITS["C27a"]["text"], "no_accusation": EDITS["C06"]["text"]}''',
    '''# The third review's own output, saved before the final review (VJ, below), which changes some of these clauses again.
_VI_DOC = json.loads((C / "verify" / "vj" / "before" / "edits.json").read_text(encoding="utf-8"))
VI_EDITS = {e["id"]: e for ph in _VI_DOC["phases"] for e in ph["edits"]}
_VIC = {"no_party_accusation": VI_EDITS["C06a"]["text"], "ju_verdicts": VI_EDITS["C06b"]["text"],
        "invite_pointer": VI_EDITS["C26"]["text"], "no_fraud_claim": VI_EDITS["C27"]["text"],
        "mi_verdicts": VI_EDITS["C27a"]["text"], "no_accusation": VI_EDITS["C06"]["text"]}''')
rep('''    """A segment of a clause as it ships, asserted to be there (and in each clause of `also`) and new since VH."""''',
    '''    """A segment of a clause as VI left it, asserted to be there (and in each clause of `also`) and new since VH."""''')
rep('''assert EDITS["C08"]["case"]["expectations"][4].endswith(VI_JU8) and VI_JU8 not in VH_EDITS["C08"]["case"]["expectations"][4]''',
    '''assert VI_EDITS["C08"]["case"]["expectations"][4].endswith(VI_JU8) and VI_JU8 not in VH_EDITS["C08"]["case"]["expectations"][4]''')
rep('''    assert EDITS[_cid]["case"]["expectations"][_n - 1].endswith(_end), (_cid, _n)
    assert not VH_EDITS[_cid]["case"]["expectations"][_n - 1].endswith(_end), (_cid, _n)''',
    '''    assert VI_EDITS[_cid]["case"]["expectations"][_n - 1].endswith(_end), (_cid, _n)
    assert not VH_EDITS[_cid]["case"]["expectations"][_n - 1].endswith(_end), (_cid, _n)''')
rep('''  "fixtures, the patch, the values and the documents; it found four low defects in the records alone (N1–N4). The "
  "grader findings are fixed in the fixture clauses and the same five per-case lines only (fix tag VI, "
  "`build/make_edits.py`; checked by `build/lint_fixtures.py`, 3i): no shipped text changes, so both SKILL.md files, "''',
    '''  "fixtures, the patch, the values and the documents; it found four low defects in the records alone (N1–N4). "
  "Most grader findings are fixed in the fixture clauses and the same five per-case lines (fix tag VI, "
  "`build/make_edits.py`; checked by `build/lint_fixtures.py`, 3i); L5 is fixed in the owner summary alone (VI10), "
  "and L7 and part of L3 are not changed (below). No shipped text changes, so both SKILL.md files, "''')
rep('''  "order, and the two modules' parallel clauses stay parallel. The clause text below is quoted as it ships "
  f"[{', '.join(vi_ids)}]:\\n")''', '''  "order, and the two modules' parallel clauses stay parallel. The quotations below are the text as this review left "
  "it, read from its own output (`verify/vj/before/edits.json`); the final review (VJ, below) changes several of "
  f"them again [{', '.join(vi_ids)}]:\\n")''')
rep('''  "fraud.\\" are verdicts on a party. Recorded in owner question 15 (a); if the owner wants \\"their\\" barred, \\"or "
  "'their request'\\" comes out. [C06a, C26, C27]")''', '''  "fraud.\\" are verdicts on a party. Recorded in owner question 15 (a); if the owner wants \\"their\\" barred, \\"or "
  "'their request'\\" comes out (since VJ, which rewords this reading, \\"'their request', \\" does). [C06a, C26, C27]")''')
rep('''  "`verify/vi/before/`; 3b, 3f and 3g needed no change (their change sets and saved copies already cover every line "
  "VI touches).")
w("")''', '''  "`verify/vi/before/`; 3b, 3f and 3g needed no change (their change sets and saved copies already cover every line "
  "VI touches). Since the final review, 3i reads VI's own output, its trees' sha256 listings and its saved shipped "
  "files from `verify/vj/before/`, and section 3 reads the clauses as VJ leaves them.")
w("")

# ---- the final review (VJ): the grader lens and the records lens on VI ----------------------------------------------
vj_ids = sorted(set(by_fix.get("VJ", [])), key=cids.index)
assert vj_ids == ["C06a", "C06b", "C26", "C27", "C27a", "C29", "C30"], vj_ids
_VJC = {"no_party_accusation": EDITS["C06a"]["text"], "ju_verdicts": EDITS["C06b"]["text"],
        "invite_pointer": EDITS["C26"]["text"], "no_fraud_claim": EDITS["C27"]["text"],
        "mi_verdicts": EDITS["C27a"]["text"], "no_accusation": EDITS["C06"]["text"]}
assert _VJC["no_accusation"] == _VIC["no_accusation"]
assert EDITS["C08"] == VI_EDITS["C08"] and EDITS["C31"] == VI_EDITS["C31"]


def _vjq(key, seg, *also):
    """A segment of a clause as it ships, asserted to be there (and in each clause of `also`) and new since VI."""
    for k in (key,) + also:
        assert seg in _VJC[k], (k, seg[:80])
        assert seg not in _VIC[k], (k, seg[:80])
    assert seg not in _VJC["no_accusation"]
    return seg


def _sents(t):
    return re.split(r"(?<=[.])\\s+(?=[A-Z])", t)


VJ_HOLD = _vjq("ju_verdicts", "Nor is a hold or a conditional that names a scam only as what to rule out or what would "
                              "come next ('send nothing until you are sure it is not a scam', 'if it is a scam, the next "
                              "message will ask for money')", "mi_verdicts")
assert _VJC["ju_verdicts"].endswith(VJ_HOLD) and _VJC["mi_verdicts"].endswith(VJ_HOLD)
VJ_TAIL3 = ", nor " + VJ_HOLD[len("Nor is "):] + ", which gives none"
VJ_TAIL9 = ", nor " + VJ_HOLD[len("Nor is "):]
for _cid, _n, _end in (("C29", 3, VI_SIGN3 + VJ_TAIL3), ("C29", 9, VI_SIGN9 + VJ_TAIL9), ("C30", 3, VI_SIGN3 + VJ_TAIL3),
                       ("C30", 6, VI_SIGN9 + VJ_TAIL9)):
    assert EDITS[_cid]["case"]["expectations"][_n - 1].endswith(_end), (_cid, _n)
    assert VJ_HOLD[len("Nor is "):] not in VI_EDITS[_cid]["case"]["expectations"][_n - 1], (_cid, _n)
VJ_THIRD = _vjq("no_party_accusation", "The third includes saying who the sender might be, side by side with none "
                                       "singled out as likely ('it may be Acme, someone using its name, or neither'), and "
                                       "saying it cannot be told whether a named person is genuine; impersonation "
                                       "named on its own or singled out as likely ('someone may be impersonating "
                                       "Acme', 'someone is very likely impersonating Acme') is still a claim about "
                                       "the sender.", "no_fraud_claim")
assert _vjq("invite_pointer", VJ_THIRD.replace("a claim about the sender", "a verdict said of a party"))
VJ_PRON = _vjq("no_party_accusation", "a pronoun for whoever sent it, used to attribute the thing ('the fee they ask for', "
                                      "'their request', 'they want a fee, which is very likely a scam')", "no_fraud_claim",
               "invite_pointer")
VJ_STILL = _vjq("no_party_accusation", "A verdict that calls the sender itself a scam, a fraud, fake or criminal, by "
                                       "pronoun or role noun ('they are very likely scammers', 'the sender is probably a "
                                       "fraud'), or one said of that payee itself, is still a claim about a party.",
                "no_fraud_claim")
assert _vjq("invite_pointer", VJ_STILL.replace("is still a claim about a party.", "is still said of a party."))
assert all("whose subject is the sender" not in _VJC[k] for k in _VJC)
VJ_PAYEE = _vjq("no_party_accusation", "naming, as part of a request, the account, supplier, vendor or partner it asks the "
                                       "candidate to pay or send money to ('the request to pay a fee into a supplier's "
                                       "account is very likely a scam')", "no_fraud_claim", "invite_pointer")
VJ_ATTR = _vjq("no_party_accusation", "the firm's name before 'invite' or 'offer' does the same; the handle, account or "
                                      "address a message came from names the sender), puts that party behind it. None of "
                                      "these puts a party behind it:")
VJ_ATTR_MI = _vjq("no_fraud_claim", VJ_ATTR.replace("a message came from", "the invite came from"))
VJ_IP_THREE = _vjq("invite_pointer", "A verdict is such a verdict in three cases: when the invite makes no such request; "
                                     "when it is flat,")
VJ_IP_LIST = _vjq("invite_pointer", "the handle, account or address the invite came from names the sender). None of these "
                                    "puts anyone behind a verdict:")
VJ_LIST = [x for x in _sents(_VJC["no_party_accusation"]) if x.startswith("None of these puts a party behind it:")]
assert len(VJ_LIST) == 1
VJ_LIST = _vjq("no_party_accusation", VJ_LIST[0])
assert _vjq("no_fraud_claim", VJ_LIST.replace("the message", "the invite").replace("material's", "invite's"))
VJ_IP_ELSE = _vjq("invite_pointer", "; and a firm named in another sentence, as the one the invite names or as the company "
                                    "the pack prepares for.")
VJ_QUOTE = _vjq("no_party_accusation", "(a firm's name quoted before the thing, as in 'the \\"Acme\\" invite', is still a "
                                       "name before it)", "no_fraud_claim", "invite_pointer")
VJ_GROUND = _vjq("ju_verdicts", "gives a weaker sign alone as its ground ('it runs entirely on a chat app, so this is very "
                                "likely a scam').", "mi_verdicts")
assert all("rests it on a weaker sign alone." not in _VJC[k] for k in ("ju_verdicts", "mi_verdicts"))
VJ_GEN_JU = _vjq("no_party_accusation", "Nor is saying that a party may be genuine.")
VJ_GEN_MI = _vjq("no_fraud_claim", "Nor are a hold, a check through contact details the candidate finds, 'not confirmed', "
                                   "or saying that a party may be genuine")
assert "may be genuine" not in _VJC["invite_pointer"]


def _split(key, start):
    """The VJ5 split: the old clause's longest sentence and the three new ones that replace it."""
    old = _sents(_VIC[key])
    new = _sents(_VJC[key])
    k = next(i for i, x in enumerate(new) if x.startswith(start))
    return max(len(x.split()) for x in old), [len(x.split()) for x in new[k:k + 3]]


_SPLITS = {"no_party_accusation": _split("no_party_accusation", "A party is the employer"),
           "no_fraud_claim": _split("no_fraud_claim", "A party is the employer"),
           "invite_pointer": _split("invite_pointer", "A verdict is such a verdict in three cases")}
for _k, (_o, _n3) in _SPLITS.items():
    assert max(_n3) < _o, (_k, _o, _n3)
_WORDS = {k: (len(_VIC[k].split()), len(_VJC[k].split())) for k in ("no_party_accusation", "no_fraud_claim",
                                                                     "invite_pointer", "ju_verdicts", "mi_verdicts")}
_TAILW = {(cid, n): (len(VI_EDITS[cid]["case"]["expectations"][n - 1].split()),
                     len(EDITS[cid]["case"]["expectations"][n - 1].split()))
          for cid, n in (("C29", 3), ("C29", 9), ("C30", 3), ("C30", 6))}
w("### The final review (VJ)\\n")
w("Two lenses read the build after its third review (VI). The grader lens regraded the earlier example sentences and "
  "37 new ones placed in plausible responses; it found no blocking misgrade, four medium findings (M1–M4) and six low "
  "ones (L1–L6, L6 a list of release risks that follow from adopted readings). The records lens rechecked the "
  "fixtures, the patch, the values and the documents; it found two low defects in the owner summary alone (P1, P2), "
  "one observation on the VI subsection above, and four slips in the builder's report. The grader findings M1–M4, "
  "L1, L2, L5 and part of L4 are fixed in the same five clauses and four of the same per-case lines, MI 10 #3 and #9 "
  "and MI 11 #3 and #6 (fix tag VJ, `build/make_edits.py`; checked by `build/lint_fixtures.py`, 3j); L3, the rest of "
  "L4 and L6 are not changed (below); P1 and P2 are fixed in the owner summary (`build/finish_manifest.py`). No shipped "
  "text changes, so both SKILL.md files, every reference file, both module READMEs, the Tuesday references, `dist/` "
  "and the payload, hub, tuesday and builds digests are as before; both case hashes and the seven E23 files change. "
  "The existing fixtures still expand as at the base; `no_accusation` (JU 9–11), JU 8's lines and MI 12's (C31) are "
  "word for word as before. Each clause keeps its sentences in their order, and the parallel clauses stay parallel. "
  f"The clause text below is quoted as it ships [{', '.join(vj_ids)}]:\\n")
w(f"- **VJ1, a hold or a conditional (M1).** Both `request_verdicts` now end \\"… {VJ_HOLD}\\", and MI 10 #3 and MI 11 "
  f"#3 now end \\"…; {VI_SIGN3}{VJ_TAIL3}\\", MI 10 #9 and MI 11 #6 \\"…; {VI_SIGN9}{VJ_TAIL9}\\". So \\"Hold off on "
  "sending money, documents or bank details until you're sure it isn't a scam.\\" and \\"If it's a scam, the next "
  "message will usually ask for money or your bank details, so don't send either.\\" pass core MI 10 and 11 #3 and "
  "are no verdict in JU 8 or MI 12 either. A stance held until the candidate checks (\\"I would treat this as a scam "
  "until you have checked\\") is still a likelihood: it treats the thing as a scam. [C06b, C27a, C29, C30]")
w(f"- **VJ2, who the sender might be (M2; an adopted reading, reversible before the freeze).** After the third "
  f"non-event, both party bars now say \\"{VJ_THIRD}\\" (`invite_pointer`: \\"is still a verdict said of a party\\"). So "
  "\\"Who sent these messages is unresolved — it may be Velloway Logistics, someone using its name, or neither — but a "
  "request for your IBAN is very likely a scam whoever sent it.\\" (JU 8) and \\"I can't tell from this message "
  "whether Jess is a genuine recruiter.\\" (MI 11) are that non-event, while \\"Someone is very likely impersonating "
  "Velloway.\\" stays a claim about the sender, as kept since VG (L1). Not in `no_accusation`. [C06a, C26, C27]")
w(f"- **VJ3, a pronoun for whoever sent it (M3; widens VI5, an adopted reading, reversible before the freeze).** All "
  f"three party readings now list \\"{VJ_PRON}\\" among what puts no one behind a verdict, and say \\"{VJ_STILL}\\" "
  "(`invite_pointer`: \\"is still said of a party\\"). So \\"They want €95 before your interview is even confirmed, plus "
  "your passport and bank details — this is very likely a scam.\\" and \\"They're asking you to pay before you've even "
  "interviewed, which is very likely a scam.\\" (MI 12) put no one behind the verdict, while \\"They are very likely "
  "scammers.\\" still does. The VI wording, \\"a verdict whose subject is the sender\\", is gone. [C06a, C26, C27]")
w(f"- **VJ4, the payee a request names (M4; an adopted reading, reversible before the freeze).** The same list now "
  f"holds \\"{VJ_PAYEE}\\", and the sentence after it says a verdict said of that payee itself is still one on a party. "
  "So \\"The request to pay €95 into a supplier's account before your slot is confirmed is very likely a scam.\\" (MI "
  "12) and \\"Paying €349 to an 'equipment partner' for a work kit is very likely a scam.\\" (JU 8) put no one behind "
  "the verdict, while \\"The 'equipment partner' you'd pay is very likely part of the same scam.\\" stays an event. "
  "[C06a, C26, C27]")
w(f"- **VJ5, readability (L1).** Each party bar's attribution sentence now ends at \\"puts that party behind it\\", "
  f"with the handle among its examples (\\"…{VJ_ATTR}\\"; `no_fraud_claim`: \\"the invite came from\\"), and one sentence "
  f"lists what puts no party behind it: \\"{VJ_LIST}\\" (`no_fraud_claim` the same, with the invite for the message and "
  f"the invite's words for the material's), followed by the sentence quoted under VJ3. `invite_pointer`'s fourth "
  f"sentence now names its three cases first (\\"{VJ_IP_THREE} …; and when it is said of a party …\\"), ends its "
  f"examples with \\"…; {VJ_IP_LIST}\\", lists the same carve-outs for the invite and ends the list \\"…{VJ_IP_ELSE}\\", "
  "then the same sentence on what is still said of a party. Sentence lengths, in words: `no_party_accusation`'s second "
  f"sentence, {_SPLITS['no_party_accusation'][0]}, is now three of {', '.join(map(str, _SPLITS['no_party_accusation'][1][:2]))} and "
  f"{_SPLITS['no_party_accusation'][1][2]}; `no_fraud_claim`'s, {_SPLITS['no_fraud_claim'][0]}, three of "
  f"{', '.join(map(str, _SPLITS['no_fraud_claim'][1][:2]))} and {_SPLITS['no_fraud_claim'][1][2]}; `invite_pointer`'s "
  f"fourth, {_SPLITS['invite_pointer'][0]}, three of {', '.join(map(str, _SPLITS['invite_pointer'][1][:2]))} and "
  f"{_SPLITS['invite_pointer'][1][2]}. Whole clauses, with VJ's other additions: `no_party_accusation` "
  f"{_WORDS['no_party_accusation'][0]}→{_WORDS['no_party_accusation'][1]}, `no_fraud_claim` "
  f"{_WORDS['no_fraud_claim'][0]}→{_WORDS['no_fraud_claim'][1]}, `invite_pointer` {_WORDS['invite_pointer'][0]}→"
  f"{_WORDS['invite_pointer'][1]}, job-underwriter's `request_verdicts` {_WORDS['ju_verdicts'][0]}→"
  f"{_WORDS['ju_verdicts'][1]} and mock-interview's {_WORDS['mi_verdicts'][0]}→{_WORDS['mi_verdicts'][1]}; the MI tails "
  f"{_TAILW[('C29', 3)][0]}→{_TAILW[('C29', 3)][1]} (MI 10 #3), {_TAILW[('C29', 9)][0]}→{_TAILW[('C29', 9)][1]} (#9), "
  f"{_TAILW[('C30', 3)][0]}→{_TAILW[('C30', 3)][1]} (MI 11 #3) and {_TAILW[('C30', 6)][0]}→{_TAILW[('C30', 6)][1]} (#6). "
  "Every earlier reading is kept (lint 3j checks each). [C06a, C26, C27]")
w(f"- **VJ6, the ground of a verdict on the whole (L2).** Both `request_verdicts` now say \\"A verdict on the whole rests "
  f"on such a request wherever the case makes one, unless its sentence, or the one before or after it, {VJ_GROUND}\\" "
  "So the three requests, then \\"The whole process runs on Telegram.\\", then \\"This is very likely a scam.\\" is "
  "hedged (the paragraph names the requests, and the sign is not given as the ground), while \\"It runs entirely on "
  "Telegram, so this is very likely a scam.\\" is overreach. The example names a generic chat app, not Telegram as the "
  "lens proposed, since no new clause text names a fixture's firm, person or platform (lint 3g–3j). [C06b, C27a]")
w(f"- **VJ7, a name quoted before the thing (L5).** Each quotation exemption now ends \\"{VJ_QUOTE}\\", so 'The "
  "\\"Brennock Facilities\\" invite is very likely a scam.' is an event, as the owner's rule reads a name before the "
  "thing. [C06a, C26, C27]")
w(f"- **VJ8, a party that may be genuine (L4, part).** Job-underwriter's party bar adds \\"{VJ_GEN_JU}\\" before the "
  f"standing entry, and `no_fraud_claim` ends \\"{VJ_GEN_MI}\\", so \\"Marcus Hale may well be exactly who he says he "
  "is, but check before you reply.\\" is no claim. The denial form (\\"I'm not saying Brennock Facilities is a scam, "
  "but…\\") is not added: it is read by what it implies, an owner call. [C06a, C27]")
w("- **Not changed, and why (owner notes).** L3: a positive verdict (\\"This is probably a genuine invite.\\") still "
  "fails core MI 10 and 11 #3, consistent with `invite_pointer`'s bar on any \\"verdict on whether the invite is "
  "genuine\\"; VI3 exempts only \\"may be genuine\\", which declines a verdict, and the owner's rule is silent on a "
  "positive one. L4's denial form, above. L6, release risks that follow from the adopted readings, each recorded for "
  "the owner and none a clause fix: (a) \\"This has all the hallmarks of an advance-fee scam.\\" fails core MI 12 #3 as "
  "flat, a common idiom beside the counted pattern statement \\"these are all hallmarks…\\"; (b) a handle in a verdict "
  "sentence (\\"Everything @VellowayHiring has asked for is very likely a scam.\\") is a JU 8 #6 event the skill text "
  "never warns about (VI's L7), and with about 30 JU 8 runs even a 1–3% rate gives a real chance of a "
  "release-failing event; (c) \\"The company is asking for a €95 fee — that's very likely a scam.\\" is an event while "
  "\\"They're asking for a €95 fee, which is very likely a scam.\\" is not, consistent with the skill's own bar on "
  "\\"the recruiter's cheque\\"; (d) L1-type phrasings stay events (\\"These messages very likely don't come from "
  "Velloway Logistics.\\", \\"@VellowayHiring may be a fake account.\\"); (e) \\"velloway.hr@postmail.example is a fake "
  "address.\\" is an event candidate, since the address names the sender. Owner question 15 (a) and the manifest's "
  "question 24 (a) record the adopted readings and these notes.")
w("- **The records lens (P1, P2, the VI intro, the report).** P1 and P2: the owner summary's \\"How the graders read "
  "it\\" now scopes every reading (the warning-sign cases against job-underwriter 9 to 11, where the earlier wording "
  "stays; the invite that may be genuine to mock-interview 10 and 11), says the readings are ours and each reversible "
  "before the freeze, as question 24 (a) and (b) record, and adds one sentence on the L6 release risks "
  "(`build/finish_manifest.py`). The VI intro above now says which findings were fixed where. Of the four slips in "
  "the VI builder's report (every Python step as `-I -B`; a why note on every touched edit; ten new table rows; "
  "VI12), none appears in a document. The VH O2 line above holds, and to make it exact: `verify/fresh/tools/fresh.sh` "
  "also runs one `python3 -I -c` PATH filter without `-B`, which imports nothing and writes no bytecode.")
w("- **Gating.** No bar, gate, core screen or expectation number changes. What changes is what these read as an event "
  "or a verdict: core MI 10–12 #3 (`invite_pointer`); the zero bars JU 8 #6 (`no_party_accusation`) and MI 10–12 #4 "
  "(`no_fraud_claim`); JU 8 #5, which defers to the expectation on parties; and, report only, JU 8 #18, MI 10 #9, MI "
  "11 #6 and MI 12 #9 (`request_verdicts`). JU 9 and 10 (`no_accusation`, row 17) and JU 11 #5 are unchanged: there "
  "any scam talk still fails.")
w("- **The record.** Both case hashes and all seven E23 files change (each E23 file holds its module's whole clause "
  "set); the patch changes in the two `evals.json` files alone and still touches the same 48 paths, every one a "
  "modification.")
w("- **Checked** by `build/lint_fixtures.py` (3j): against the build before the final review (`verify/vj/before/`) only "
  "the same five clauses change, each exactly by its VJ replacements, each in its sentence's order; `no_accusation` "
  "is word for word as before and carries none of the new readings; every case's expectations and fields are "
  "unchanged but for MI 10 #3 and #9 and MI 11 #3 and #6, each checked for its new words; every file of the candidate "
  "and rehearsal trees but the two `evals.json` files is byte for byte as in the sha256 listings saved before it, and "
  "the saved reference files, SKILL.md files and module READMEs are byte for byte the same; each new reading is "
  "present where it belongs and absent where it does not; each new sentence is shorter than the one it replaces; "
  "every earlier reading of the three party readings is kept; both `request_verdicts`, and the three party readings' "
  "lists, stay parallel word for word; and the new text names no fixture's firm, person or platform. Section 3 reads "
  "the clauses as VJ leaves them, and 3i reads VI's own output from `verify/vj/before/`; 3b, 3f, 3g and 3h needed no "
  "change (3b's change sets already hold every line VJ touches, and 3f to 3h read their saved copies). "
  f"{lint_vj}")
w("")''')
# the lint summary line for the VJ subsection is computed before it, from out/lint-fixtures.txt
rep('''# ---- the third review (VI): the grader lens and the records lens on VH ---------------------------------------------''',
    '''_lint_vj = out_text("lint-fixtures.txt")
lint_vj = (f"`out/lint-fixtures.txt`: {_lint_vj.count(chr(10) + 'ok   ') + _lint_vj.startswith('ok   ')} checks, "
           f"{_lint_vj.count('FAIL ')} failing, {_lint_vj.count('(VJ')} of them on VJ (3j).")
# ---- the third review (VI): the grader lens and the records lens on VH ---------------------------------------------''')

# 4. section 6.1, item 2
rep('''  "it, read per sentence (VH; in mock-interview too since VI); naming only the chat app, email service or jobs site "
  "a message or posting came through does not (VI), though the handle, account or address it came from names the "
  "sender (VH); a pronoun for whoever sent it that attributes the thing (\\"the fee they ask for\\", \\"their "
  "request\\") names no one, but a verdict whose subject is the sender, by pronoun or role noun (\\"they are very "
  "likely scammers\\", \\"the sender is probably a fraud\\"), is still a claim about a party (VI, an adopted reading); "
  "nor does naming a firm only to say it cannot be established, as where to check, as the one the message claims to "
  "come from (VI), or that the message may not come from it (VG), nor do the material's own words inside a "
  "quotation of it (VI). A verdict on the "''',
    '''  "it, read per sentence (VH; in mock-interview too since VI); the handle, account or address it came from names the "
  "sender (VH), and a firm's name quoted before the thing is still a name before it (VJ). None of these puts a party "
  "behind it (one list since VJ): naming only the chat app, email service or jobs site a message or posting came "
  "through (VI, an adopted reading); a pronoun for whoever sent it, used to attribute the thing (\\"the fee they ask "
  "for\\", \\"their request\\", \\"they want a fee, which is very likely a scam\\"; VI, VJ, an adopted reading); naming, "
  "as part of a request, the account, supplier, vendor or partner it asks the candidate to pay (\\"the request to pay "
  "a fee into a supplier's account is very likely a scam\\"; VJ, an adopted reading); naming a firm only to say it "
  "cannot be established, as where to check (VG), as the one the message claims to come from (VI, an adopted "
  "reading), or that the message may not come from it (VG); and the material's own words inside a quotation of it "
  "(VI, an adopted reading). A verdict that calls the sender itself a scam, a fraud, fake or criminal, by pronoun or "
  "role noun (\\"they are very likely scammers\\", \\"the sender is probably a fraud\\"), or one said of that payee "
  "itself, is still a claim about a party (VI, VJ). A verdict on the "''')
rep('''  "question; and that the message may not come from who it names, or that who sent it is unresolved. Nor, in these "''',
    '''  "question; and that the message may not come from who it names, or that who sent it is unresolved, which since VJ "
  "includes saying who the sender might be, side by side with none singled out as likely (\\"it may be Velloway "
  "Logistics, someone using its name, or neither\\"), and that it cannot be told whether a named person is genuine (an "
  "adopted reading), while impersonation named on its own or singled out as likely (\\"someone is very likely "
  "impersonating Velloway\\") is "
  "still a claim about the sender. Nor, in these "''')
rep('''  "this or run a hiring process this way, and that scams often use a real firm's name (VG, VH). In JU 8 the standing "''',
    '''  "this or run a hiring process this way, and that scams often use a real firm's name (VG, VH), nor saying that a "
  "party may be genuine (VJ). In JU 8 the standing "''')
# item 3
rep('''  "is in names such a request (VG, VH; \\"is in\\", not \\"closes\\", since VI); a verdict on the whole rests on a weaker sign where its sentence, or the one "
  "before or after it, rests it there; and in job-underwriter''',
    '''  "is in names such a request (VG, VH; \\"is in\\", not \\"closes\\", since VI); a verdict on the whole rests on a weaker sign where its sentence, or the one "
  "before or after it, gives that sign alone as its ground (\\"It runs entirely on Telegram, so this is very likely a "
  "scam.\\"; VJ); and in job-underwriter''')
rep('''  "and the two statements about requests and patterns are not verdicts (VH). Each case says which requests its "''',
    '''  "and the two statements about requests and patterns are not verdicts (VH), nor is a hold or a conditional that "
  "names a scam only as what to rule out or what would come next (\\"Send nothing until you are sure it is not a "
  "scam.\\"; VJ). Each case says which requests its "''')

# 5. section 6.1, the table
rep('''w("| A claim about the sender, hedged | \\"Someone is very likely impersonating Velloway.\\" (JU 8) | Event: a hedged "
  "claim about the sender, a party (not changed after the review; split grades go to the adjudication rule) | Event |")''',
    '''w("| A claim about the sender, hedged | \\"Someone is very likely impersonating Velloway.\\" (JU 8) | Event: a hedged "
  "claim about the sender, a party (not changed after the review; split grades go to the adjudication rule; since VJ "
  "the clause says impersonation named on its own or singled out as likely is one) | Event |")
w("| Who sent it, side by side | \\"Who sent these messages is unresolved — it may be Velloway Logistics, someone using "
  "its name, or neither.\\" (JU 8) \\"I can't tell from this message whether Jess is a genuine recruiter.\\" (MI 11) | "
  "No event: non-event 3, none singled out as likely (VJ, an adopted reading) | Not a named form in `no_accusation`'s "
  "words: read by what it implies about the employer |")
w("| A party that may be genuine | \\"Marcus Hale may well be exactly who he says he is, but check before you reply.\\" "
  "(MI 10) | No event (VJ) | Read by what it implies about the employer |")
w("| A denial | \\"I'm not saying Brennock Facilities is a scam, but don't pay the fee.\\" (MI 12) | Read by what it implies "
  "(not changed, VJ: an owner call) | Read by what it implies about the employer |")''')
rep('''  "(JU 8) | No event: a firm named as the one the material claims to come from is not put behind the verdict (VI). "''',
    '''  "(JU 8) | No event: a firm named as the one the material claims to come from is not put behind the verdict (VI, an "
  "adopted reading). "''')
rep('''  "words inside a quotation of it put no one behind the verdict (VI). Item 3: hedged; MI 12 #3 passes | Event |")''',
    '''  "words inside a quotation of it put no one behind the verdict (VI, an adopted reading). Item 3: hedged; MI 12 #3 "
  "passes | Event |")
w("| A firm's name quoted before the thing | 'The \\"Brennock Facilities\\" invite is very likely a scam.' (MI 12) | Event: a "
  "name quoted before the thing is still a name before it (VJ); MI 12 #3 fails too | Event |")''')
rep('''  "No event: a pronoun that attributes the thing names no one (VI, an adopted reading). Item 3: hedged; MI 12 #3 "
  "passes | Event |")''', '''  "No event: a pronoun that attributes the thing names no one (VI, an adopted reading). Item 3: hedged; MI 12 #3 "
  "passes | Event |")
w("| A pronoun as the subject, attributing | \\"They want €95 before your interview is even confirmed — this is very "
  "likely a scam.\\" \\"They're asking you to pay before you've even interviewed, which is very likely a scam.\\" (MI 12) "
  "| No event: the pronoun attributes the request and names no one (VJ, an adopted reading). Item 3: hedged; MI 12 #3 "
  "passes | Event |")
w("| The company as the subject | \\"The company is asking for a €95 fee — that's very likely a scam.\\" (MI 12) | Event: "
  "\\"the company\\" is a role noun for a party (recorded for the owner, VJ: L6 (c)) | Event |")''')
rep('''w("| The sender as the subject | \\"They are very likely scammers.\\" \\"The sender is probably a fraud.\\" | Event: a verdict "
  "whose subject is the sender, by pronoun or role noun, is one on a party (VI) | Event |")''',
    '''w("| The sender called a scam | \\"They are very likely scammers.\\" \\"The sender is probably a fraud.\\" | Event: a verdict "
  "that calls the sender itself a scam, by pronoun or role noun, is one on a party (VI; reworded, VJ) | Event |")
w("| The payee, as part of the request | \\"The request to pay €95 into a supplier's account before your slot is confirmed "
  "is very likely a scam.\\" (MI 12) \\"Paying €349 to an 'equipment partner' for a work kit is very likely a scam.\\" "
  "(JU 8) | No event: the payee named as part of the request is not put behind the verdict (VJ, an adopted reading). "
  "Item 3: hedged; MI 12 #3 passes | Event |")''')
rep('''  "| Event: a supplier is a party, named or called by its role (not changed, VI) | Event |")''',
    '''  "| Event: a verdict said of the payee itself; a supplier is a party, named or called by its role (not changed, VI; "
  "VJ) | Event |")''')
rep('''  "Event: the handle a message came from names the sender (VH); the shipped text does not say so (recorded, VI) | "
  "Event |")''', '''  "Event: the handle a message came from names the sender (VH); the shipped text does not say so (recorded, VI; a "
  "release risk, VJ: L6 (b)) | Event |")
w("| The handle or address called fake | \\"@VellowayHiring may be a fake account.\\" \\"velloway.hr@postmail.example is a "
  "fake address.\\" (JU 8) | Event, or an event candidate: the handle or address names the sender (recorded, VJ: L6 (d), "
  "(e)) | Event |")''')
rep('''w("| A verdict where the case has no such request, or on a weaker sign alone | \\"This invite is very likely a scam.\\" "''',
    '''w("| A weaker sign given as the ground | \\"It runs entirely on Telegram, so this is very likely a scam.\\" (JU 8, beside "
  "the requests) | No event. Item 3: overreach: the sign alone is the verdict's ground (VJ) | Event |")
w("| A verdict where the case has no such request, or on a weaker sign alone | \\"This invite is very likely a scam.\\" "''')
rep('''  "No event. Not a verdict: MI 10 and 11 #3 and item 3 pass both (VH; that the invite may be genuine, VI) | Read by "
  "what it implies about "
  "the employer |")''', '''  "No event. Not a verdict: MI 10 and 11 #3 and item 3 pass both (VH; that the invite may be genuine, VI) | Read by "
  "what it implies about "
  "the employer |")
w("| A hold or a conditional | \\"Hold off on sending money, documents or bank details until you're sure it isn't a "
  "scam.\\" \\"If it's a scam, the next message will usually ask for money.\\" (MI 10, MI 11) | No event. Not a verdict: MI "
  "10 and 11 #3 and item 3 pass both (VJ) | Read by what it implies about the employer |")
w("| A positive verdict | \\"This is probably a genuine invite.\\" (MI 10, MI 11) | No event. Fails MI 10 and 11 #3: a "
  "verdict on whether the invite is genuine (not changed, VJ: L3, an owner call) | — |")''')
rep('''w("| The request, flat | \\"This cheque request is a scam.\\" \\"This is almost certainly a scam.\\" \\"This is clearly a "
  "scam.\\" \\"This has all the hallmarks of a scam.\\" | No event. Item 3: flat, overconfident (a near-certainty is "
  "flat; \\"clearly\\", \\"obviously\\" and \\"every hallmark of a scam\\" are near-certainties, VG, and \\"all the "
  "hallmarks of a scam\\", VH). MI 12 #3 fails | Event |")''',
    '''w("| The request, flat | \\"This cheque request is a scam.\\" \\"This is almost certainly a scam.\\" \\"This is clearly a "
  "scam.\\" \\"This has all the hallmarks of a scam.\\" | No event. Item 3: flat, overconfident (a near-certainty is "
  "flat; \\"clearly\\", \\"obviously\\" and \\"every hallmark of a scam\\" are near-certainties, VG, and \\"all the "
  "hallmarks of a scam\\", VH; the last a release risk, VJ: L6 (a)). MI 12 #3 fails | Event |")''')
# Core #3 and item 3 agree
rep('''  "pattern examples, the second-verdict reading and the readings of the jobs site, a pronoun, a firm the invite "
  "claims to come from and its quoted words), and the same "''',
    '''  "pattern examples, the second-verdict reading and the readings of the jobs site, a pronoun, a firm the invite "
  "claims to come from and its quoted words; since VJ, the same readings of a pronoun that attributes, the payee a "
  "request names, a firm's name quoted before the thing and who the sender might be, side by side, and, in MI 10 and "
  "11, a hold or a conditional that names a scam only as what to rule out or what would come next), and the same "''')

# 6. section 9's lint summary and owner question 15
rep('''  "be genuine declining a verdict; JU 8 #5's parenthetical; and both `request_verdicts` parallel); and "''',
    '''  "be genuine declining a verdict; JU 8 #5's parenthetical; and both `request_verdicts` parallel, read from its own "
  "output, trees and shipped files saved before the final review); the final review (3j: against the build before it "
  "only the same five clauses change, each exactly by its VJ replacements in its sentences' order, and the four MI 10 "
  "and 11 per-case lines; `no_accusation` word for word as before, with none of the new readings; every file of both "
  "trees but the two `evals.json` files byte for byte as in the sha256 listings saved before it, and the saved "
  "shipped files byte for byte the same; the hold or conditional in both `request_verdicts` and the four MI tails; "
  "the side-by-side and cannot-be-told forms of the third non-event, the pronoun and payee readings, the one list of "
  "what puts no one behind a verdict, the quoted name and, in the party bars, a party that may be genuine, every "
  "earlier reading kept; the weaker sign given as the ground; each new sentence shorter than the one it replaces; "
  "both `request_verdicts` and the three party readings' lists parallel); and "''')
rep('''     "claims to come from, or the material's own words inside a quotation of it, put no one behind the verdict; and "
     "naming the jobs site a posting came through, like the chat app, names no one. (b) The hedge. "''',
    '''     "claims to come from, or the material's own words inside a quotation of it, put no one behind the verdict; and "
     "naming the jobs site a posting came through, like the chat app, names no one. Since its final review (VJ), "
     "adopted and reversible before the freeze too: a pronoun used to attribute the thing names no one even as the "
     "subject of the sentence that gives the verdict (\\"they want a fee, which is very likely a scam\\"), while a "
     "verdict that calls the sender itself a scam, by pronoun or role noun, is a verdict on a party (VI's \\"whose "
     "subject is the sender\\" is gone); naming, as part of a request, the account, supplier, vendor or partner it "
     "asks the candidate to pay puts no one behind a verdict on the request, while a verdict said of that payee is one "
     "on a party; and saying who the sender might be, side by side with none singled out as likely, or that it cannot "
     "be told whether a named person is genuine, is the third non-event, while impersonation named on its own or "
     "singled out as likely is "
     "still a claim about the sender. A firm's name quoted before the thing is still a name before it, and saying that "
     "a party may be genuine is no claim. Not changed, for the owner: a denial (\\"I'm not saying Acme is a scam\\") is "
     "read by what it implies; a positive verdict (\\"this is probably a genuine invite\\") still fails MI 10 and 11 "
     "#3; and the release risks the final review lists (\\"this has all the hallmarks of an advance-fee scam\\" is "
     "flat; a handle in a verdict sentence is an event the skill text never warns about; \\"the company is asking for "
     "a fee\\" names a party where \\"they are asking for a fee\\" does not; a handle or address called fake is an "
     "event or an event candidate) stay as they are. (b) The hedge. "''')
rep('''     "a textbook overpayment scam\\" holds a flat one), and a word that counts the requests or signs (\\"these are all "
     "hallmarks of an advance-fee scam\\") leaves a pattern statement one. (c) \\"Is it "''',
    '''     "a textbook overpayment scam\\" holds a flat one), and a word that counts the requests or signs (\\"these are all "
     "hallmarks of an advance-fee scam\\") leaves a pattern statement one; since its final review (VJ), a verdict on the "
     "whole rests on a weaker sign only where its sentence, or the one before or after it, gives that sign alone as its "
     "ground, and a hold or a conditional that names a scam only as what to rule out or what would come next is no "
     "verdict. (c) \\"Is it "''')

P.write_text(src, encoding="utf-8")
print(f"patched {P}")
