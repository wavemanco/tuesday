"""p_make_edits.py: apply fix tag VJ (the final review: the grader lens and the records lens on VI) to
build/make_edits.py, by exact replacements, each asserted to occur once. Run once; refuses a second run.

VJ changes the five clauses VI changed (no_party_accusation and request_verdicts in job-underwriter; invite_pointer,
no_fraud_claim and request_verdicts in mock-interview) and the four MI 10 and 11 per-case lines (#3 and #9, #3 and #6),
never shipped text, never no_accusation, never C31 or JU 8."""
import sys
from pathlib import Path

sys.dont_write_bytecode = True
P = Path(__file__).resolve().parents[2] / "build" / "make_edits.py"
src = P.read_text(encoding="utf-8")
assert "VJ_HOLD" not in src, "already patched"


def rep(old, new):
    global src
    n = src.count(old)
    assert n == 1, (n, old[:90])
    src = src.replace(old, new, 1)


# 1. docstring: one paragraph for VJ
rep('''request; and saying the invite may be genuine declines a verdict. Every edit it touches carries the fix tag "VI".
''', '''request; and saying the invite may be genuine declines a verdict. Every edit it touches carries the fix tag "VI".
The final review (VJ, the grader lens and the records lens on VI) again changes the same five clauses and the four
MI 10 and 11 per-case lines only: a hold or a conditional that names a scam only as what to rule out or what would come
next gives no verdict; the third non-event includes who the sender might be, listed side by side with none singled out
as likely, and saying it cannot be told whether a named person is genuine, while impersonation named on its own or
singled out as likely is still a claim about the sender; a pronoun used to attribute the thing names no one, but a verdict that calls the sender
itself a scam is a claim about a party; naming, as part of a request, the account, supplier, vendor or partner it asks
the candidate to pay puts no one behind a verdict on the request, but a verdict said of that payee is a claim; the three
party readings end their attribution sentence at "puts that party behind it" and list in one sentence what puts no
party behind a verdict (invite_pointer: the three cases that make a verdict such a verdict, then that list); a verdict
on the whole rests on a weaker sign where the sign alone is given as its ground; a firm's name quoted before the thing
is still a name before it; and saying that a party may be genuine is no claim. Every edit it touches carries the fix
tag "VJ".
''')

# 2. the VJ block, after the VI block's last assertion
rep('''assert not any(x in NO_ACCUSATION for x in ("red flag", "counts the requests", "email service or jobs site", "pronoun", "claims to come",
                                             "quotation", "second verdict", "it is in"))
''', '''assert not any(x in NO_ACCUSATION for x in ("red flag", "counts the requests", "email service or jobs site", "pronoun", "claims to come",
                                             "quotation", "second verdict", "it is in"))

# ---- the final review (VJ: the grader lens and the records lens on VI), in the clauses and per-case lines only ------
# VJ1 (M1): a hold or a conditional that names a scam only as what to rule out or what would come next gives no
# verdict, in both request_verdicts and in the MI 10 and 11 tails (below). VJ2 (M2): the third non-event, in the three
# party readings, includes who the sender might be listed side by side with none singled out as likely, and saying it
# cannot be told whether a named person is genuine; impersonation named on its own or singled out as likely is still a
# claim about the sender (the reading kept since VG, L1). VJ3 (M3): a pronoun used to attribute the thing names no one, including 'they
# want a fee, which is very likely a scam', but a verdict that calls the sender itself a scam, a fraud, fake or
# criminal, by pronoun or role noun, is a claim about a party (no longer "whose subject is the sender"). VJ4 (M4):
# naming, as part of a request, the account, supplier, vendor or partner it asks the candidate to pay puts no one behind
# a verdict on the request; a verdict said of that payee itself is still a claim. VJ5 (L1, readability): each party
# bar's attribution sentence ends at "puts that party behind it", the handle reading moves into its examples, and one
# sentence, "None of these puts a party behind it: ...", lists the carve-outs, followed by one on what is still a
# claim; invite_pointer's fourth sentence becomes the three cases, then "None of these puts anyone behind a verdict:
# ...", then the same "still" sentence. VJ6 (L2): a verdict on the whole rests on a weaker sign where its sentence, or
# the one before or after it, gives that sign alone as its ground (the example names a generic chat app, not a
# fixture's platform). VJ7 (L5): a firm's name quoted before the thing is still a name before it. VJ8 (L4, part):
# saying that a party may be genuine is no claim, in both party bars. Not changed: the denial form ('I am not saying
# Acme is a scam'), read by what it implies (an owner call); a positive verdict ('probably a genuine invite') still
# fails MI 10 and 11 #3 (L3); the release risks of L6, recorded for the owner.
VJ_CHAN = "naming only the chat app, email service or jobs site a message or posting came through"
VJ_PRON = ("a pronoun for whoever sent it, used to attribute the thing ('the fee they ask for', 'their request', 'they "
           "want a fee, which is very likely a scam')")
VJ_PAYEE = ("naming, as part of a request, the account, supplier, vendor or partner it asks the candidate to pay or send "
            "money to ('the request to pay a fee into a supplier's account is very likely a scam')")
VJ_CLAIMS = ("naming a firm only to say it cannot be established, as where to check, as the one the {0} claims to come "
             "from ('this email, which claims to be from Acme, is very likely a scam'), or that the {0} may not come from it")
VJ_QUOTE = ("the {0} own words inside a quotation of it (a firm's name quoted before the thing, as in 'the \\"Acme\\" "
            "invite', is still a name before it)")
VJ_STILL = ("A verdict that calls the sender itself a scam, a fraud, fake or criminal, by pronoun or role noun ('they are "
            "very likely scammers', 'the sender is probably a fraud'), or one said of that payee itself, is still {0}.")
VJ_HANDLE = "; the handle, account or address {0} came from names the sender)"
VJ_THIRD = (" The third includes saying who the sender might be, side by side with none singled out as likely ('it may "
            "be Acme, someone using its name, or neither'), and saying it cannot be told whether a named person is "
            "genuine; impersonation named on its own or singled out as likely ('someone may be impersonating Acme', "
            "'someone is very likely impersonating Acme') is still {0}.")
VJ_HOLD = ("a hold or a conditional that names a scam only as what to rule out or what would come next ('send nothing "
           "until you are sure it is not a scam', 'if it is a scam, the next message will ask for money')")
VJ_GROUND = ("unless its sentence, or the one before or after it, rests it on a weaker sign alone.",
             "unless its sentence, or the one before or after it, gives a weaker sign alone as its ground ('it runs "
             "entirely on a chat app, so this is very likely a scam').")
VJ_GENUINE = "saying that a party may be genuine"


def vj_party(clause, thing, words, src, unknown):
    """A party bar after the final review (VJ): the attribution sentence ends at 'puts that party behind it' with the
    handle among its examples; one sentence lists what puts no party behind it (VJ3, VJ4, VJ7 in it); one says what is
    still a claim; and the third non-event gains its side-by-side and cannot-be-told forms (VJ2)."""
    old = ("does the same), puts that party behind it; " + VI_CHANNEL[1] + VI_PRONOUN.format("such a claim")[1:] + ", "
           + VI_CLAIMS.format(thing, words) + ".")
    new = ("does the same" + VJ_HANDLE.format(src) + ", puts that party behind it. None of these puts a party behind "
           "it: " + VJ_CHAN + "; " + VJ_PRON + "; " + VJ_PAYEE + "; " + VJ_CLAIMS.format(thing) + "; and "
           + VJ_QUOTE.format(words) + ". " + VJ_STILL.format("a claim about a party"))
    clause = patch(clause, old, new, "VJ5, VJ3, VJ4, VJ7")
    return patch(clause, unknown, unknown + VJ_THIRD.format("a claim about the sender"), "VJ2")


NO_PARTY_ACCUSATION_C = vj_party(NO_PARTY_ACCUSATION_C, "message", "material's", "a message",
                                 "and whether the named firm had any part in it, is unresolved.")
NO_PARTY_ACCUSATION_C = patch(NO_PARTY_ACCUSATION_C, "and that scams often use a real firm's name. Nor is the standing",
                              "and that scams often use a real firm's name. Nor is " + VJ_GENUINE + ". Nor is the "
                              "standing", "VJ8")
NO_FRAUD_CLAIM_C = vj_party(NO_FRAUD_CLAIM_C, "invite", "invite's", "the invite",
                            "and whether a named employer is involved, is unproven.")
NO_FRAUD_CLAIM_C = patch(NO_FRAUD_CLAIM_C, "Nor are a hold, a check through contact details the candidate finds, or 'not "
                         "confirmed'", "Nor are a hold, a check through contact details the candidate finds, 'not "
                         "confirmed', or " + VJ_GENUINE, "VJ8")
VJ_IP_FLAT = ("stated as a fact or a near-certainty ('almost certainly', 'definitely', 'a classic scam', 'a textbook "
              "scam', 'clearly', 'obviously', 'every hallmark of a scam', 'all the hallmarks of a scam'; 'looks like', "
              "'appears to be', 'seems' and 'has the hallmarks of', without 'every' or 'all', are a likelihood)")
VJ_IP_PARTY = ("said of a party (a firm or a person, named or called 'the company', 'the employer', 'the recruiter', 'the "
               "sender' or the like) or puts one behind the thing in the same sentence{0} by a possessive, by a name "
               "before the thing, or by naming it as the thing's sender or source ('the company's cheque request is very "
               "likely a scam', 'the cheque request from Acme', 'the fee Acme asks for'; a firm's name before 'invite' or "
               "'offer' does the same")
VJ_IP_ELSE = "a firm named {0}, as the one the invite names or as the company the pack prepares for"
VJ_IP_OLD = ("A verdict is such a verdict when it is flat, " + VJ_IP_FLAT + "; when it is " + VJ_IP_PARTY.format(":")
             + "), though " + VI_CHANNEL[1] + VI_PRONOUN.format("said of a party")[1:] + ", "
             + VI_CLAIMS.format("invite", "invite's") + ", nor is " + VJ_IP_ELSE.format("elsewhere")
             + ", put behind a verdict in another sentence; or when the invite makes no such request.")
VJ_IP_NEW = ("A verdict is such a verdict in three cases: when the invite makes no such request; when it is flat, "
             + VJ_IP_FLAT + "; and when it is " + VJ_IP_PARTY.format(",") + VJ_HANDLE.format("the invite")
             + ". None of these puts anyone behind a verdict: " + VJ_CHAN + "; " + VJ_PRON + "; " + VJ_PAYEE + "; "
             + VJ_CLAIMS.format("invite") + "; " + VJ_QUOTE.format("invite's") + "; and "
             + VJ_IP_ELSE.format("in another sentence") + ". " + VJ_STILL.format("said of a party"))
INVITE_POINTER_C = patch(INVITE_POINTER_C, VJ_IP_OLD, VJ_IP_NEW, "VJ5, VJ3, VJ4, VJ7")
INVITE_POINTER_C = patch(INVITE_POINTER_C, "and whether a named employer is involved, is unproven.",
                         "and whether a named employer is involved, is unproven." + VJ_THIRD.format("a verdict said of a party"),
                         "VJ2")


def vj_verdicts(clause):
    """request_verdicts after the final review (VJ): the weaker sign given as the ground (VJ6), and a hold or a
    conditional that names a scam only as what to rule out or what would come next is no verdict (VJ1)."""
    clause = patch(clause, VJ_GROUND[0], VJ_GROUND[1], "VJ6")
    assert clause.endswith("and that scams often use a real firm's name"), clause[-80:]
    return clause + ". Nor is " + VJ_HOLD


VC_VERDICTS_JU = vj_verdicts(VC_VERDICTS_JU)
VC_VERDICTS_MI = vj_verdicts(VC_VERDICTS_MI)
for _c in (NO_PARTY_ACCUSATION_C, NO_FRAUD_CLAIM_C, INVITE_POINTER_C):
    assert _c.count(VJ_CHAN) == 1 and VI_CHANNEL[1] not in _c and _c.count(VJ_PRON) == 1 and _c.count(VJ_PAYEE) == 1
    assert "whose subject is the sender" not in _c and "'the \\"Acme\\" invite'" in _c and _c.count("The third includes") == 1
    assert "None of these puts" in _c and "the handle, account or address it came from" not in _c
for _c in (NO_PARTY_ACCUSATION_C, NO_FRAUD_CLAIM_C):
    assert _c.count(VJ_GENUINE) == 1 and _c.count(VJ_STILL.format("a claim about a party")) == 1
for _c in (VC_VERDICTS_JU, VC_VERDICTS_MI):
    assert _c.count(VJ_GROUND[1]) == 1 and VJ_GROUND[0] not in _c and _c.endswith(VJ_HOLD)
    assert "pronoun" not in _c and "payee" not in _c
assert INVITE_POINTER_C.count("in three cases: when the invite makes no such request;") == 1
assert INVITE_POINTER_C.count(VJ_STILL.format("said of a party")) == 1 and VJ_GENUINE not in INVITE_POINTER_C
assert VJ_HOLD not in INVITE_POINTER_C and "as its ground" not in INVITE_POINTER_C
assert NO_PARTY_ACCUSATION_C.endswith(NO_ACCUSATION[NO_ACCUSATION.index(" Nor is a finding"):])
assert not any(x in NO_ACCUSATION for x in ("None of these", "payee", "side by side with none", "impersonat", "a hold or a "
                                            "conditional", "as its ground", "may be genuine", "quoted before the thing"))
''')

# 3. MI 10 and 11 #3 and their request_verdicts lines (VJ1), after the VI3 tails
rep('''    assert x[2].endswith("which declines a verdict") and x[n_rv - 1].endswith("the sign alone does not show a scam")
    x[n_rv - 1] = x[n_rv - 1] + ", or that the invite may be genuine"
''', '''    assert x[2].endswith("which declines a verdict") and x[n_rv - 1].endswith("the sign alone does not show a scam")
    x[n_rv - 1] = x[n_rv - 1] + ", or that the invite may be genuine"
# The final review (VJ1, M1): a hold or a conditional that names a scam only as what to rule out or what would come
# next gives no verdict.
for i, n_rv in ((10, 9), (11, 6)):
    x = mi[i]["expectations"]
    x[2] = patch(x[2], "or that the invite may be genuine, which declines a verdict",
                 "or that the invite may be genuine, which declines a verdict, nor " + VJ_HOLD + ", which gives none", "VJ1")
    assert x[2].endswith(", which gives none") and x[n_rv - 1].endswith(", or that the invite may be genuine")
    x[n_rv - 1] = x[n_rv - 1] + ", nor " + VJ_HOLD
''')

# 4. fixes and whys (VJ): C06a, C06b, C26, C27, C27a gain a note; C29 and C30 the tag (their why is a case description)
rep('''                     "material's own words inside a quotation, puts no one behind a verdict.",
              "fixes": ["VB", "VC", "VK3", "VK4", "VG", "VH", "VI"]})''',
    '''                     "material's own words inside a quotation, puts no one behind a verdict. After its final "
                     "review (VJ): the attribution sentence ends at 'puts that party behind it', with the handle among "
                     "its examples, and one sentence lists what puts no party behind it; a verdict that calls the "
                     "sender itself a scam, by pronoun or role noun, is a claim, while a pronoun used to attribute the "
                     "thing ('they want a fee, which is very likely a scam') is not; naming the account, supplier, "
                     "vendor or partner a request asks the candidate to pay puts no one behind a verdict on the "
                     "request, but a verdict said of that payee is a claim; a firm's name quoted before the thing is "
                     "still a name before it; the third non-event includes who the sender might be, side by side with "
                     "none singled out as likely, and saying it cannot be told whether a named person is genuine, "
                     "while impersonation named on its own or singled out as likely is a claim; saying that a party "
                     "may be genuine is no "
                     "claim.",
              "fixes": ["VB", "VC", "VK3", "VK4", "VG", "VH", "VI", "VJ"]})''')
rep('''                     "it closes, names no such request. Never a gate, never core.",
              "fixes": ["VB", "VC", "VK2", "VS7", "VW", "VG", "VH", "VI"]})''',
    '''                     "it closes, names no such request. After its final review (VJ): a verdict on the whole rests on "
                     "a weaker sign only where its sentence, or the one before or after it, gives that sign alone as "
                     "its ground; a hold or a conditional that names a scam only as what to rule out or what would come "
                     "next is no verdict. Never a gate, never core.",
              "fixes": ["VB", "VC", "VK2", "VS7", "VW", "VG", "VH", "VI", "VJ"]})''')
rep('''                             "'invite' or 'offer', as in the party bars.",
                      "fixes": ["VC", "VK1", "VK2", "VS7", "VW", "VG", "VH", "VI"]})''',
    '''                             "'invite' or 'offer', as in the party bars. After its final review (VJ): its fourth "
                             "sentence becomes the three cases that make a verdict such a verdict, then one sentence "
                             "listing what puts no one behind a verdict and one on what is still said of a party; the "
                             "party bars' readings of a pronoun, a payee, a firm's name quoted before the thing and "
                             "the third non-event.",
                      "fixes": ["VC", "VK1", "VK2", "VS7", "VW", "VG", "VH", "VI", "VJ"]})''')
rep('''                         "reads it; the party list names a recruiter's or sender's company." if fixed
                  else "Invite-warning clause.", **({"fixes": ["C2", "K5", "VB", "VC", "VK3", "VG", "VH", "VI"]} if fixed else {})})''',
    '''                         "reads it; the party list names a recruiter's or sender's company. After its final review "
                         "(VJ): as job-underwriter's C06a." if fixed
                  else "Invite-warning clause.", **({"fixes": ["C2", "K5", "VB", "VC", "VK3", "VG", "VH", "VI", "VJ"]} if fixed else {})})''')
rep('''                     "second and third reviews (VH, VI), as job-underwriter's C06b, without the entry rule. Never a "''',
    '''                     "second, third and final reviews (VH, VI, VJ), as job-underwriter's C06b, without the entry "
                     "rule. Never a "''')
rep('''              "fixes": ["VB", "VC", "VK2", "VK8", "VS7", "VW", "VG", "VH", "VI"]})''',
    '''              "fixes": ["VB", "VC", "VK2", "VK8", "VS7", "VW", "VG", "VH", "VI", "VJ"]})''')
rep('''                  + (["VW", "VG", "VH", "VI"] if i in (10, 11) else [])})''',
    '''                  + (["VW", "VG", "VH", "VI", "VJ"] if i in (10, 11) else [])})''')

P.write_text(src, encoding="utf-8")
print(f"patched {P}")
