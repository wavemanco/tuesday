#!/bin/bash
# repo-state.sh (VJ, as verify/vi/repo-state.sh): the repository's state, read-only git only (no index refresh: --no-optional-locks)
R=/home/user/tuesday
echo "HEAD $(git -C $R rev-parse HEAD)"
echo "porcelain $(git -C $R --no-optional-locks status --porcelain | wc -l)"
echo "stash $(git -C $R stash list | wc -l)"
echo "config $(sha256sum $R/.git/config | cut -c1-64)"
echo "index $(sha256sum $R/.git/index | cut -c1-64)"
echo "refs $(git -C $R for-each-ref | sha256sum | cut -c1-64)"
echo "worktrees $(git -C $R worktree list | wc -l)"
echo "branch $(git -C $R rev-parse --abbrev-ref HEAD)"
