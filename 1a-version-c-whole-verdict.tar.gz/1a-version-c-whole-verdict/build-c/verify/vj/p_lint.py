"""p_lint.py: the lint for fix tag VJ (the final review). Exact replacements in build/lint_fixtures.py, each asserted
to occur once:
- the docstring: section 3 reads the clauses as VJ leaves them; 3i reads VI's own output from ../verify/vj/before/;
  a new 3j;
- section 3 (3d's checks live there): the party bars' channel carve-out, request_verdicts' whole-verdict ground and
  invite_pointer's long sentence and third non-event, as VJ restructures them;
- 3i: VI's own output, trees and saved shipped files are read from ../verify/vj/before/ (VJ changes the same clauses
  and per-case lines after it), as VI did for 3h;
- 3j: against ../verify/vj/before/, only the five clauses and the four MI 10 and 11 per-case lines change, each exactly
  by the VJ replacements, in sentence order; no_accusation unchanged; the trees and the saved shipped files byte for
  byte; each VJ reading present where it belongs and absent elsewhere; every earlier reading kept; the clauses parallel;
  the new sentence lengths; no fixture's name in the new text.
3b, 3f, 3g and 3h need no change: 3b's change sets (against variant B) already hold every line VJ touches, and 3f, 3g
and 3h read their saved copies, which VJ does not touch. Run once; refuses a second run."""
import re
import sys
from pathlib import Path

sys.dont_write_bytecode = True
P = Path(__file__).resolve().parents[2] / "build" / "lint_fixtures.py"
src = P.read_text(encoding="utf-8")
assert "VJ_BEFORE" not in src, "already patched"


def rep(old, new):
    global src
    n = src.count(old)
    assert n == 1, (n, old[:90])
    src = src.replace(old, new, 1)


# 1. docstring
rep("""   no_accusation keeps the old words. Section 3 reads the clauses as the third review (3i) leaves them.""",
    """   no_accusation keeps the old words. Section 3 reads the clauses as the final review (3j) leaves them.""")
rep("""3i. The third review (VI: the grader lens and the records lens on VH), against the build before it
   (../verify/vi/before/): only the same five clauses change,""",
    """3i. The third review (VI: the grader lens and the records lens on VH), against the build before it
   (../verify/vi/before/), read from its own output, saved before the final review as ../verify/vj/before/ (3j changes
   the same clauses and per-case lines; VI's trees and saved shipped files are read there too): only the same five
   clauses change,""")
rep("""   (VI11); saying the invite may be genuine declines a verdict in MI 10 and 11 (VI3); both request_verdicts stay
   parallel; and the new text names no fixture's firm, person or platform.
""", """   (VI11); saying the invite may be genuine declines a verdict in MI 10 and 11 (VI3); both request_verdicts stay
   parallel; and the new text names no fixture's firm, person or platform.
3j. The final review (VJ: the grader lens and the records lens on VI), against the build before it
   (../verify/vj/before/): only the same five clauses change, each exactly by the VJ replacements, in its sentences'
   order; no_accusation is unchanged word for word and carries none of the new readings; every case's raw expectations
   and fields are unchanged but for MI 10 #3 and #9 and MI 11 #3 and #6 (VJ1), each checked for its new words (JU 8 and
   MI 12, C31, unchanged); every file of the candidate and rehearsal trees but the two evals.json files is byte for
   byte as in the sha256 listings saved there, and the saved reference files, SKILL.md files and module READMEs are
   byte for byte the same, so no shipped text changes; a hold or a conditional that names a scam only as what to rule
   out or what would come next is no verdict, in both request_verdicts and the four MI tails (VJ1); the third
   non-event includes who the sender might be, side by side, and that it cannot be told whether a named person is
   genuine, while impersonation named on its own or singled out as likely stays a claim, in the three party readings
   (VJ2); a pronoun
   used to attribute the thing names no one, while a verdict that calls the sender itself a scam is a claim (VJ3); a
   payee named as part of a request puts no one behind a verdict on it, while a verdict said of the payee is a claim
   (VJ4); the attribution sentence ends at "puts that party behind it", one sentence lists what puts no party behind
   a verdict, and invite_pointer names its three cases first (VJ5), each new sentence shorter than the one it
   replaces; a verdict on the whole rests on a weaker sign given as its ground (VJ6); a firm's name quoted before the
   thing is still a name before it (VJ7); saying that a party may be genuine is no claim, in both party bars (VJ8);
   every earlier reading of the three party readings is kept; both request_verdicts and the three party readings'
   lists stay parallel; and the new text names no fixture's firm, person or platform.
""")

# 2. section 3, as VJ leaves the clauses
rep('''                 "naming only the chat app, email service or jobs site a message or posting came through does not"):''',
    '''                 "puts that party behind it. None of these puts a party behind it: naming only the chat app, email "
                 "service or jobs site a message or posting came through;"):''')
rep('''                 "A verdict on the whole rests on such a request wherever the case makes one, unless its sentence, or "
                 "the one before or after it, rests it on a weaker sign alone.",''',
    '''                 "A verdict on the whole rests on such a request wherever the case makes one, unless its sentence, or "
                 "the one before or after it, gives a weaker sign alone as its ground ('it runs entirely on a chat "
                 "app, so this is very likely a scam').",''')
i0 = src.index('''             "A verdict is such a verdict when it is flat, stated as a fact or a near-certainty ('almost certainly', "''')
i1 = src.index('''             "verdict in another sentence; or when the invite makes no such request.",\n''') + len(
    '''             "verdict in another sentence; or when the invite makes no such request.",\n''')
old_ip = src[i0:i1]
assert old_ip.count("\n") == 17, old_ip.count("\n")
src = src[:i0] + '''             "A verdict is such a verdict in three cases: when the invite makes no such request; when it is flat, "
             "stated as a fact or a near-certainty ('almost certainly', 'definitely', 'a classic scam', 'a textbook "
             "scam', 'clearly', 'obviously', 'every hallmark of a scam', 'all the hallmarks of a scam'; 'looks like', "
             "'appears to be', 'seems' and 'has the hallmarks of', without 'every' or 'all', are a likelihood); and "
             "when it is said of a party (a firm or a person, named or called 'the company', 'the employer', 'the "
             "recruiter', 'the sender' or the like) or puts one behind the thing in the same sentence, by a "
             "possessive, by a name before the thing, or by naming it as the thing's sender or source ('the company's "
             "cheque request is very likely a scam', 'the cheque request from Acme', 'the fee Acme asks for'; a firm's "
             "name before 'invite' or 'offer' does the same; the handle, account or address the invite came from names "
             "the sender). None of these puts anyone behind a verdict: naming only the chat app, email service or jobs "
             "site a message or posting came through; a pronoun for whoever sent it, used to attribute the thing ('the "
             "fee they ask for', 'their request', 'they want a fee, which is very likely a scam'); naming, as part of a "
             "request, the account, supplier, vendor or partner it asks the candidate to pay or send money to ('the "
             "request to pay a fee into a supplier's account is very likely a scam'); naming a firm only to say it "
             "cannot be established, as where to check, as the one the invite claims to come from ('this email, which "
             "claims to be from Acme, is very likely a scam'), or that the invite may not come from it; the invite's "
             "own words inside a quotation of it (a firm's name quoted before the thing, as in 'the \\"Acme\\" invite', "
             "is still a name before it); and a firm named in another sentence, as the one the invite names or as the "
             "company the pack prepares for. A verdict that calls the sender itself a scam, a fraud, fake or criminal, "
             "by pronoun or role noun ('they are very likely scammers', 'the sender is probably a fraud'), or one said "
             "of that payee itself, is still said of a party.",
''' + src[i1:]
rep('''             "employer is involved, is unproven. Nor are two statements about requests and patterns, not about the "''',
    '''             "employer is involved, is unproven. The third includes saying who the sender might be, side by side "
             "with none singled out as likely ('it may be Acme, someone using its name, or neither'), and saying it "
             "cannot be told whether a named person is genuine; impersonation named on its own or singled out as "
             "likely ('someone may be impersonating Acme', 'someone is very likely impersonating Acme') is still a "
             "verdict said of a party. Nor are two statements about "
             "requests and patterns, not about the "''')

# 3. 3i reads VI's own output, trees and saved shipped files from ../verify/vj/before/
s3i = src.index("# 3i. the third review (VI: the grader lens and the records lens on VH)")
s3j = src.index('shipped = [p for p in (TREE / "skills").rglob("*.md")]')
blk = src[s3i:s3j]
blk = blk.replace('''# 3i. the third review (VI: the grader lens and the records lens on VH), against the build before it (saved, read only)
''', '''# 3i. the third review (VI: the grader lens and the records lens on VH), against the build before it (saved, read only).
# Its own output is read from the copy saved before the final review (VJ_BEFORE, 3j), since VJ changed the same clauses
# and per-case lines after it; its trees from the sha256 listings, and its shipped files from the copies, saved there.
VJ_BEFORE = C / "verify" / "vj" / "before"
_VI_OUT = {short: json.loads((VJ_BEFORE / f"{short}-evals.json").read_text(encoding="utf-8")) for short in ("ju", "mi")}
ijcl, imcl = _VI_OUT["ju"]["clauses"], _VI_OUT["mi"]["clauses"]
''', 1)
n_before = blk.count("jcl[") + blk.count("mcl[")
blk = re.sub(r"(?<![a-z])jcl\[", "ijcl[", blk)
blk = re.sub(r"(?<![a-z])mcl\[", "imcl[", blk)
assert blk.count("ijcl[") >= 10 and blk.count("imcl[") >= 10, (blk.count("ijcl["), blk.count("imcl["))
for old, new in (
        ('''    now = json.loads((TREE / "skills" / skill / "evals" / "evals.json").read_text(encoding="utf-8"))
    edits_ = VI_CLAUSE_EDITS[skill]''', '''    now = _VI_OUT[short]
    edits_ = VI_CLAUSE_EDITS[skill]'''),
        ('''_mi_vi = {c["id"]: c for c in json.loads((TREE / "skills/mock-interview/evals/evals.json").read_text())["evals"]}''',
         '''_mi_vi = {c["id"]: c for c in _VI_OUT["mi"]["evals"]}'''),
        ('''_j5vi = jraw[8]["expectations"][4]''', '''_j5vi = {c["id"]: c for c in _VI_OUT["ju"]["evals"]}[8]["expectations"][4]'''),
        ('''for label, root, listing in (("candidate", TREE, "tree-sha256.txt"), ("rehearsal", REH, "tree-rehearsal-sha256.txt")):
    fa, fb = _listing(VI_BEFORE / listing), _sha_files(root)
    differ = sorted(k for k in set(fa) | set(fb) if fa.get(k) != fb.get(k))
    say(set(fa) == set(fb) and set(differ) == EVALS_JSON,
        f"{label} (VI): {len(fb)} files,''',
         '''for label, listing in (("candidate", "tree-sha256.txt"), ("rehearsal", "tree-rehearsal-sha256.txt")):
    fa, fb = _listing(VI_BEFORE / listing), _listing(VJ_BEFORE / listing)
    differ = sorted(k for k in set(fa) | set(fb) if fa.get(k) != fb.get(k))
    say(set(fa) == set(fb) and set(differ) == EVALS_JSON,
        f"{label} (VI, its saved output): {len(fb)} files,'''),
        ('''for label, root, saved in (("candidate", TREE, "shipped-tree"), ("rehearsal", REH, "shipped-tree-rehearsal")):
    kept = _files(VI_BEFORE / saved)
    same = [k for k, p in kept.items() if (root / k).is_file() and (root / k).read_bytes() == p.read_bytes()]
    say(len(kept) > 0 and len(same) == len(kept),
        f"{label} (VI): the {len(kept)} saved''',
         '''for label, saved in (("candidate", "shipped-tree"), ("rehearsal", "shipped-tree-rehearsal")):
    kept, after = _files(VI_BEFORE / saved), _files(VJ_BEFORE / saved)
    same = [k for k, p in kept.items() if k in after and after[k].read_bytes() == p.read_bytes()]
    say(len(kept) > 0 and len(same) == len(kept) == len(after),
        f"{label} (VI, its saved output): the {len(kept)} saved''')):
    assert blk.count(old) == 1, old[:80]
    blk = blk.replace(old, new, 1)
assert "TREE /" not in blk and "jraw" not in blk, "3i still reads the current tree"

# 4. 3j, the final review
blk += r'''# 3j. the final review (VJ: the grader lens and the records lens on VI), against the build before it (saved, read only)
import re  # noqa: E402
VJ_CHAN = "naming only the chat app, email service or jobs site a message or posting came through"
VJ_PRON = ("a pronoun for whoever sent it, used to attribute the thing ('the fee they ask for', 'their request', 'they "
           "want a fee, which is very likely a scam')")
VJ_PAYEE = ("naming, as part of a request, the account, supplier, vendor or partner it asks the candidate to pay or send "
            "money to ('the request to pay a fee into a supplier's account is very likely a scam')")
VJ_CLAIMS = ("naming a firm only to say it cannot be established, as where to check, as the one the {0} claims to come "
             "from ('this email, which claims to be from Acme, is very likely a scam'), or that the {0} may not come from it")
VJ_QUOTE = ("the {0} own words inside a quotation of it (a firm's name quoted before the thing, as in 'the \"Acme\" "
            "invite', is still a name before it)")
VJ_STILL = ("A verdict that calls the sender itself a scam, a fraud, fake or criminal, by pronoun or role noun ('they are "
            "very likely scammers', 'the sender is probably a fraud'), or one said of that payee itself, is still {0}.")
VJ_THIRD = (" The third includes saying who the sender might be, side by side with none singled out as likely ('it may "
            "be Acme, someone using its name, or neither'), and saying it cannot be told whether a named person is "
            "genuine; impersonation named on its own or singled out as likely ('someone may be impersonating Acme', "
            "'someone is very likely impersonating Acme') is still {0}.")
VJ_HOLD = ("a hold or a conditional that names a scam only as what to rule out or what would come next ('send nothing "
           "until you are sure it is not a scam', 'if it is a scam, the next message will ask for money')")
VJ_GROUND = ("unless its sentence, or the one before or after it, rests it on a weaker sign alone.",
             "unless its sentence, or the one before or after it, gives a weaker sign alone as its ground ('it runs "
             "entirely on a chat app, so this is very likely a scam').")
VJ_GENUINE = "saying that a party may be genuine"
_IP_FLAT = ("stated as a fact or a near-certainty ('almost certainly', 'definitely', 'a classic scam', 'a textbook scam', "
            "'clearly', 'obviously', 'every hallmark of a scam', 'all the hallmarks of a scam'; 'looks like', 'appears "
            "to be', 'seems' and 'has the hallmarks of', without 'every' or 'all', are a likelihood)")
_IP_PARTY = ("said of a party (a firm or a person, named or called 'the company', 'the employer', 'the recruiter', 'the "
             "sender' or the like) or puts one behind the thing in the same sentence{0} by a possessive, by a name before "
             "the thing, or by naming it as the thing's sender or source ('the company's cheque request is very likely a "
             "scam', 'the cheque request from Acme', 'the fee Acme asks for'; a firm's name before 'invite' or 'offer' "
             "does the same")
_IP_ELSE = "a firm named {0}, as the one the invite names or as the company the pack prepares for"


def _party_vj(thing, words, src_):
    old = ("does the same), puts that party behind it; " + _CHAN[1] + _PRONOUN.format("such a claim")[1:] + ", "
           + _CLAIMS.format(thing, words) + ".")
    new = ("does the same; the handle, account or address " + src_ + " came from names the sender), puts that party "
           "behind it. None of these puts a party behind it: " + VJ_CHAN + "; " + VJ_PRON + "; " + VJ_PAYEE + "; "
           + VJ_CLAIMS.format(thing) + "; and " + VJ_QUOTE.format(words) + ". " + VJ_STILL.format("a claim about a party"))
    return (old, new)


def _third_vj(end, verb):
    return (end, end + VJ_THIRD.format(verb))


_IP_OLD = ("A verdict is such a verdict when it is flat, " + _IP_FLAT + "; when it is " + _IP_PARTY.format(":")
           + "), though " + _CHAN[1] + _PRONOUN.format("said of a party")[1:] + ", " + _CLAIMS.format("invite", "invite's")
           + ", nor is " + _IP_ELSE.format("elsewhere") + ", put behind a verdict in another sentence; or when the invite "
           "makes no such request.")
_IP_NEW = ("A verdict is such a verdict in three cases: when the invite makes no such request; when it is flat, "
           + _IP_FLAT + "; and when it is " + _IP_PARTY.format(",") + "; the handle, account or address the invite came "
           "from names the sender). None of these puts anyone behind a verdict: " + VJ_CHAN + "; " + VJ_PRON + "; "
           + VJ_PAYEE + "; " + VJ_CLAIMS.format("invite") + "; " + VJ_QUOTE.format("invite's") + "; and "
           + _IP_ELSE.format("in another sentence") + ". " + VJ_STILL.format("said of a party"))
_RV_END = "and that scams often use a real firm's name"
VJ_CLAUSE_EDITS = {
    "job-underwriter": {
        "no_party_accusation": [_party_vj("message", "material's", "a message"),
                                _third_vj("and whether the named firm had any part in it, is unresolved.",
                                          "a claim about the sender"),
                                ("and that scams often use a real firm's name. Nor is the standing",
                                 "and that scams often use a real firm's name. Nor is " + VJ_GENUINE + ". Nor is the "
                                 "standing")],
        "request_verdicts": [VJ_GROUND, (_RV_END, _RV_END + ". Nor is " + VJ_HOLD)]},
    "mock-interview": {
        "no_fraud_claim": [_party_vj("invite", "invite's", "the invite"),
                           _third_vj("and whether a named employer is involved, is unproven.", "a claim about the sender"),
                           ("Nor are a hold, a check through contact details the candidate finds, or 'not confirmed'",
                            "Nor are a hold, a check through contact details the candidate finds, 'not confirmed', or "
                            + VJ_GENUINE)],
        "request_verdicts": [VJ_GROUND, (_RV_END, _RV_END + ". Nor is " + VJ_HOLD)],
        "invite_pointer": [(_IP_OLD, _IP_NEW),
                           _third_vj("and whether a named employer is involved, is unproven.",
                                     "a verdict said of a party")]},
}
_GEN3 = "or that the invite may be genuine, which declines a verdict"
_GEN9 = ", or that the invite may be genuine"
VJ_LINES = {"job-underwriter": {},
            "mock-interview": {i: {3: (_GEN3, _GEN3 + ", nor " + VJ_HOLD + ", which gives none"),
                                   n: (_GEN9, _GEN9 + ", nor " + VJ_HOLD)} for i, n in ((10, 9), (11, 6))}}


def _sents(t):
    return re.split(r"(?<=[.])\s+(?=[A-Z])", t)


_NOW = {}
for skill, short in (("job-underwriter", "ju"), ("mock-interview", "mi")):
    was = _VI_OUT[short]
    now = json.loads((TREE / "skills" / skill / "evals" / "evals.json").read_text(encoding="utf-8"))
    _NOW[short] = now
    edits_ = VJ_CLAUSE_EDITS[skill]
    diff = {k for k in set(was["clauses"]) | set(now["clauses"]) if was["clauses"].get(k) != now["clauses"].get(k)}
    say(diff == set(edits_) and list(was["clauses"]) == list(now["clauses"]),
        f"{skill} (VJ): only {sorted(edits_)} changed among the clauses, in the same order {sorted(diff) if diff != set(edits_) else ''}")
    for name, pairs in edits_.items():
        t = was["clauses"][name]
        pos = [t.find(old) for old, new in pairs]
        ok, added = pos == sorted(pos) and min(pos) >= 0, []
        for old, new in pairs:
            ok = ok and t.count(old) == 1 and new not in t
            t = t.replace(old, new, 1)
            added.append(new)
        say(ok and t == now["clauses"][name], f"{skill} {name} (VJ): the before text with exactly the "
                                               f"{len(pairs)} VJ replacements, each in its sentence's order")
        hits = [n for n in VG_NAMES if any(n in a for a in added)]
        say(not hits, f"{skill} {name} (VJ): the new text names no fixture's firm, person or platform {hits or ''}")
    lines_vj = VJ_LINES[skill]

    def masked(evals):
        out = json.loads(json.dumps(evals))
        for c in out:
            for n in lines_vj.get(c["id"], {}):
                c["expectations"][n - 1] = None
        return out
    say(masked(was["evals"]) == masked(now["evals"]) and was["skill_name"] == now["skill_name"]
        and list(was) == list(now),
        f"{skill} (VJ): every case's raw expectations, tails and fields are unchanged"
        + ("".join(f"{' but for ' if not k else ', '}{short.upper()} {i} #{n}" for k, (i, n) in enumerate(
            (i, n) for i in sorted(lines_vj) for n in sorted(lines_vj[i]))) or ", every line of every case"))
    bw, bn = {c["id"]: c for c in was["evals"]}, {c["id"]: c for c in now["evals"]}
    for i, nums in sorted(lines_vj.items()):
        for n, (old, new) in sorted(nums.items()):
            a, b = bw[i]["expectations"][n - 1], bn[i]["expectations"][n - 1]
            ok = a.count(old) == 1 and new not in a and b == a.replace(old, new, 1) and a.endswith(old) and b.endswith(new)
            say(ok, f"{skill} {i} #{n} (VJ1): '...{old[-44:]}' gains '{new[len(old):][:60]}...' and nothing else changes")
            hits = [x for x in VG_NAMES if x in new]
            say(not hits, f"{skill} {i} #{n} (VJ): the new words name no fixture's firm, person or platform {hits or ''}")
_vjj, _vjm = _NOW["ju"]["clauses"], _NOW["mi"]["clauses"]
_NEW_WORDS = ("None of these", "payee", "side by side with none", "impersonat", "a hold or a conditional", "as its ground",
              "may be genuine", "quoted before the thing", "they want a fee", "calls the sender itself")
say(_vjj["no_accusation"] == ijcl["no_accusation"] == hjcl["no_accusation"]
    and not any(x in _vjj["no_accusation"] for x in _NEW_WORDS),
    "no_accusation (VJ): unchanged word for word, none of the new readings; in JU 9-11 any scam talk still fails")
_THREE_VJ = (("no_party_accusation", _vjj["no_party_accusation"], "message", "material's", "a claim about a party",
              "a claim about the sender", "None of these puts a party behind it: "),
             ("no_fraud_claim", _vjm["no_fraud_claim"], "invite", "invite's", "a claim about a party",
              "a claim about the sender", "None of these puts a party behind it: "),
             ("invite_pointer", _vjm["invite_pointer"], "invite", "invite's", "said of a party",
              "a verdict said of a party", "None of these puts anyone behind a verdict: "))
_RV_VJ = (("job-underwriter request_verdicts", _vjj["request_verdicts"]),
          ("mock-interview request_verdicts", _vjm["request_verdicts"]))
for name, clause in _RV_VJ:
    say(clause.endswith(_RV_END + ". Nor is " + VJ_HOLD) and clause.count(VJ_HOLD) == 1,
        f"{name} (VJ1): a hold or a conditional that names a scam only as what to rule out or what would come next is no "
        "verdict, after the statements that are not verdicts")
    say(clause.count(VJ_GROUND[1]) == 1 and VJ_GROUND[0] not in clause,
        f"{name} (VJ6): a verdict on the whole rests on a weaker sign only where the sign alone is given as its ground")
    say(not any(x in clause for x in ("None of these", "payee", "pronoun", "impersonat", "may be genuine", "quoted before")),
        f"{name} (VJ): the party readings stay in the party bars and invite_pointer")
_mt = {c["id"]: c for c in _NOW["mi"]["evals"]}
say(all(_mt[i]["expectations"][n - 1].endswith(end) for i, n, end in
        ((10, 3, _GEN3 + ", nor " + VJ_HOLD + ", which gives none"), (11, 3, _GEN3 + ", nor " + VJ_HOLD + ", which gives none"),
         (10, 9, _GEN9 + ", nor " + VJ_HOLD), (11, 6, _GEN9 + ", nor " + VJ_HOLD)))
    and VJ_HOLD not in _mt[12]["expectations"][2] and VJ_HOLD not in _vjm["invite_pointer"],
    "mock-interview 10 and 11 #3 and request_verdicts (VJ1): a hold or a conditional that names a scam only as what to rule "
    "out or what would come next gives no verdict; MI 12 #3 (C31) and invite_pointer unchanged in this")
_lists = {}
for name, clause, thing, words, still, third, head in _THREE_VJ:
    say(clause.count(VJ_THIRD.format(third)) == 1 and clause.index(VJ_THIRD.format(third)) > clause.index("a verification question"),
        f"{name} (VJ2): the third non-event includes who the sender might be, side by side with none singled out, and that "
        "it cannot be told whether a named person is genuine; impersonation named on its own or singled out as likely "
        "stays " + third)
    say(clause.count(VJ_PRON) == 1 and "whose subject is the sender" not in clause and clause.count(VJ_STILL.format(still)) == 1,
        f"{name} (VJ3): a pronoun used to attribute the thing names no one ('they want a fee, which is very likely a "
        "scam'); a verdict that calls the sender itself a scam, by pronoun or role noun, is still " + still)
    say(clause.count(VJ_PAYEE) == 1 and "or one said of that payee itself" in clause,
        f"{name} (VJ4): naming, as part of a request, the payee it asks for puts no one behind the verdict; a verdict "
        "said of that payee itself is still " + still)
    say(clause.count(VJ_QUOTE.format(words)) == 1,
        f"{name} (VJ7): a firm's name quoted before the thing is still a name before it")
    s = _sents(clause)
    k = next(n for n, x in enumerate(s) if x.startswith(head))
    say(s[k - 1].endswith("names the sender), puts that party behind it.") if thing != "invite" or "anyone" not in head
        else s[k - 1].startswith("A verdict is such a verdict in three cases: when the invite makes no such request; when "
                                 "it is flat,") and "; and when it is said of a party" in s[k - 1],
        f"{name} (VJ5): " + ("the attribution sentence ends at 'puts that party behind it', the handle among its examples, "
                             if "anyone" not in head else "the three cases come first, ")
        + f"then one sentence lists what puts no one behind a verdict ({len(s[k - 1].split())} and {len(s[k].split())} "
          f"words), then one on what is still {still} ({len(s[k + 1].split())} words)")
    say(s[k + 1] == VJ_STILL.format(still), f"{name} (VJ5): the 'still' sentence follows the list")
    _lists[name] = s[k][len(head):]
    old_long = max(len(x.split()) for x in _sents(_VI_OUT['ju' if name == 'no_party_accusation' else 'mi']['clauses'][
        'no_party_accusation' if name == 'no_party_accusation' else name]))
    say(max(len(s[k - 1].split()), len(s[k].split())) < old_long,
        f"{name} (VJ5): the longest of the new sentences ({max(len(s[k - 1].split()), len(s[k].split()))} words) is "
        f"shorter than the one it replaces ({old_long})")
    for part in ("'the fee they ask for'", "'their request'", "'they are very likely scammers'",
                 "'the sender is probably a fraud'", "('this email, which claims to be from Acme, is very likely a scam')",
                 "own words inside a quotation of it", VJ_CHAN, "came from names the sender",
                 "'the cheque request from Acme', 'the fee Acme asks for'", "before 'invite' or 'offer' does the same",
                 "or by naming", "in the same sentence" if thing == "invite" else "the sentence attributes to a party",
                 "may not come from who it names"):
        say(part in clause, f"{name} (VJ, every earlier reading kept): still says {part[:60]!r}")
for name in ("no_party_accusation", "no_fraud_claim"):
    clause = _vjj[name] if name == "no_party_accusation" else _vjm[name]
    say("a named firm — a recruiter's or sender's company, a supplier or a jobs site among them —" in clause
        and clause.count(VJ_GENUINE) == 1, f"{name} (VJ8; VI8 not changed): saying that a party may be genuine is no "
                                           "claim; a supplier, named or called by its role, is still a party")
say(_vjm["no_fraud_claim"].endswith("'not confirmed', or " + VJ_GENUINE) and VJ_GENUINE not in _vjm["invite_pointer"]
    and "Nor is " + VJ_GENUINE + ". Nor is the standing" in _vjj["no_party_accusation"],
    "no_fraud_claim and no_party_accusation (VJ8): the hold sentence, and a sentence of its own before the standing entry; "
    "not in invite_pointer (the invite's own 'may be genuine' is MI 10 and 11's, VI3)")
say(_lists["no_party_accusation"].replace("the message", "the invite").replace("material's", "invite's") == _lists["no_fraud_claim"]
    and _lists["invite_pointer"].replace("; and " + _IP_ELSE.format("in another sentence") + ".", ".")
    .replace("; the invite's own words", "; and the invite's own words") == _lists["no_fraud_claim"],
    "the three party readings (VJ5): one list of what puts no one behind a verdict, word for word but for message or "
    "invite, and invite_pointer's firm named in another sentence")
say("a firm named in another sentence, as the one the invite names or as the company the pack prepares for"
    in _vjm["invite_pointer"] and "nor is a firm named elsewhere" not in _vjm["invite_pointer"]
    and _IP_FLAT in _vjm["invite_pointer"],
    "invite_pointer (VJ5): the firm named in another sentence, the likelihood note and the near-certainties kept")
_par_vj = (_vjj["request_verdicts"].replace("Each sentence of the response, its risk register and snapshot included,",
                                            "Each statement in the response, any saved file included,")
           .replace("a hiring process run wholly by chat, or contact off the employer's domain beyond scheduling)",
                    "a hiring process run wholly by chat)")
           .replace("that the message may not come from who it names", "that the invite may not come from who it names")
           .replace("nor the paragraph or entry it is in", "nor the paragraph it is in")
           .replace(_ENTRY_VH, "."))
say(_par_vj == _vjm["request_verdicts"], "request_verdicts (VJ): the two modules' clauses stay parallel, word for word "
                                         "but for scope, weaker signs, message or invite, and the entry rule")
for label, root, listing in (("candidate", TREE, "tree-sha256.txt"), ("rehearsal", REH, "tree-rehearsal-sha256.txt")):
    fa, fb = _listing(VJ_BEFORE / listing), _sha_files(root)
    differ = sorted(k for k in set(fa) | set(fb) if fa.get(k) != fb.get(k))
    say(set(fa) == set(fb) and set(differ) == EVALS_JSON,
        f"{label} (VJ): {len(fb)} files, every one byte for byte as before but the two evals.json files "
        f"(shipped text, the .skill archives and dist/ unchanged) {differ if set(differ) != EVALS_JSON else ''}")
for label, root, saved in (("candidate", TREE, "shipped-tree"), ("rehearsal", REH, "shipped-tree-rehearsal")):
    kept = _files(VJ_BEFORE / saved)
    same = [k for k, p in kept.items() if (root / k).is_file() and (root / k).read_bytes() == p.read_bytes()]
    say(len(kept) > 0 and len(same) == len(kept),
        f"{label} (VJ): the {len(kept)} saved reference files, SKILL.md files and module READMEs are byte for byte "
        "the same")

'''
src = src[:s3i] + blk + src[s3j:]

P.write_text(src, encoding="utf-8")
print(f"patched {P}")
