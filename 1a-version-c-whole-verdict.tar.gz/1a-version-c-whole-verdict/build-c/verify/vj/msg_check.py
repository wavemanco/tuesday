"""msg_check.py (VJ): check commit-msg.txt and revert-msg.txt after the final review: byte-identical to vj/before;
72 columns but for the subject and the two trailers; the two trailers last, once each, after a blank line; and the
claims that depend on the build (body sizes, mutation and must-pass counts) against out/ and the fresh gates."""
import json
import re
import sys
from pathlib import Path

sys.dont_write_bytecode = True
V = Path(__file__).resolve().parent
B = V.parents[1]
T1 = "Co-Authored-By: Claude Opus 5.5 <noreply@anthropic.com>"
T2 = "Claude-Session: https://claude.ai/code/session_015ptydWtHPYTwrwMYpgde4U"
for name in ("commit-msg.txt", "revert-msg.txt"):
    b = (B / name).read_bytes()
    print(f"{name}: byte-identical to vj/before: {b == (V / 'before' / name).read_bytes()}")
    t = b.decode("utf-8")
    lines = t.split("\n")
    assert t.endswith("\n") and not t.endswith("\n\n"), name
    lines = lines[:-1]
    long_ = [i + 1 for i, l in enumerate(lines) if len(l) > 72 and i != 0 and l not in (T1, T2)]
    print(f"  lines over 72 columns other than the subject and trailers: {long_}; subject {len(lines[0])} columns")
    print(f"  trailers last, once each, after a blank line: {lines[-2:] == [T1, T2] and lines[-3] == '' and t.count(T1) == 1 and t.count(T2) == 1}")
    print(f"  CR or tab: {chr(13) in t or chr(9) in t}")
msg = (B / "commit-msg.txt").read_text(encoding="utf-8")
bodies = json.loads((B / "out" / "bodies.json").read_text())
print("bodies.json:", json.dumps(bodies)[:300])
for n in re.findall(r"\d{2},\d{3}", msg):
    print(f"  commit message body size {n} present in bodies.json: {n.replace(',', '') in json.dumps(bodies)}")
G = B / "verify" / "fresh" / "gates"
for f in sorted(G.glob("*summary.txt")):
    print(f.name, "->", f.read_text().strip().replace("\n", " | ")[:600])
