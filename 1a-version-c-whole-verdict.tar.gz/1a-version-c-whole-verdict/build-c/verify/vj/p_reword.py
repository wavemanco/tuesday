"""p_reword.py (VJ, a revision before the chain): in the three VJ patch scripts, VJ2's last clause names impersonation
on its own as well as impersonation singled out as likely, so the reading kept since VG (L1: a hedged claim that
someone is impersonating the firm is a claim about the sender) stays explicit; the spec's L6 (b) note says "about 30
JU 8 runs", as the lens wrote; and the lint's JU line-change message reads "unchanged" where no line changes. Exact
replacements in verify/vj/p_*.py, each asserted to occur once."""
import sys
from pathlib import Path

sys.dont_write_bytecode = True
V = Path(__file__).resolve().parent
EDITS = {
    "p_make_edits.py": [
        ("as likely, and saying it cannot be told whether a named person is genuine, while impersonation singled out as likely is\nstill a claim about the sender;",
         "as likely, and saying it cannot be told whether a named person is genuine, while impersonation named on its own or\nsingled out as likely is still a claim about the sender;"),
        ("# cannot be told whether a named person is genuine; impersonation singled out as likely is still a claim about the\n# sender (the reading kept since VG, L1).",
         "# cannot be told whether a named person is genuine; impersonation named on its own or singled out as likely is still a\n# claim about the sender (the reading kept since VG, L1)."),
        ("            \"genuine; singling impersonation out as likely ('someone is very likely impersonating Acme') is still {0}.\")",
         "            \"genuine; impersonation named on its own or singled out as likely ('someone may be impersonating Acme', \"\n"
         "            \"'someone is very likely impersonating Acme') is still {0}.\")"),
        ("                     \"while impersonation singled out as likely is a claim; saying that a party may be genuine is no \"",
         "                     \"while impersonation named on its own or singled out as likely is a claim; saying that a party \"\n"
         "                     \"may be genuine is no \""),
    ],
    "p_lint.py": [
        ("   genuine, while impersonation singled out as likely stays a claim, in the three party readings (VJ2); a pronoun",
         "   genuine, while impersonation named on its own or singled out as likely stays a claim, in the three party readings\n   (VJ2); a pronoun"),
        ("             \"cannot be told whether a named person is genuine; singling impersonation out as likely ('someone is \"\n"
         "             \"very likely impersonating Acme') is still a verdict said of a party. Nor are two statements about \"",
         "             \"cannot be told whether a named person is genuine; impersonation named on its own or singled out as \"\n"
         "             \"likely ('someone may be impersonating Acme', 'someone is very likely impersonating Acme') is still a \"\n"
         "             \"verdict said of a party. Nor are two statements about \""),
        ("            \"genuine; singling impersonation out as likely ('someone is very likely impersonating Acme') is still {0}.\")",
         "            \"genuine; impersonation named on its own or singled out as likely ('someone may be impersonating Acme', \"\n"
         "            \"'someone is very likely impersonating Acme') is still {0}.\")"),
        ("\"it cannot be told whether a named person is genuine; impersonation singled out as likely stays \" + third)",
         "\"it cannot be told whether a named person is genuine; impersonation named on its own or singled out as likely \"\n"
         "        \"stays \" + third)"),
        ("""        f"{skill} (VJ): every case's raw expectations, tails and fields are unchanged but for "
        + (", ".join(f"{short.upper()} {i} #{n}" for i in sorted(lines_vj) for n in sorted(lines_vj[i])) or "none"))""",
         """        f"{skill} (VJ): every case's raw expectations, tails and fields are unchanged"
        + ("".join(f"{' but for ' if not k else ', '}{short.upper()} {i} #{n}" for k, (i, n) in enumerate(
            (i, n) for i in sorted(lines_vj) for n in sorted(lines_vj[i]))) or ", every line of every case"))"""),
    ],
    "p_spec.py": [
        ("                                       \"saying it cannot be told whether a named person is genuine; singling \"\n"
         "                                       \"impersonation out as likely ('someone is very likely impersonating Acme') is \"\n"
         "                                       \"still a claim about the sender.\", \"no_fraud_claim\")",
         "                                       \"saying it cannot be told whether a named person is genuine; impersonation \"\n"
         "                                       \"named on its own or singled out as likely ('someone may be impersonating \"\n"
         "                                       \"Acme', 'someone is very likely impersonating Acme') is still a claim about \"\n"
         "                                       \"the sender.\", \"no_fraud_claim\")"),
        ("  \"adopted reading), while impersonation singled out as likely (\\\\\"someone is very likely impersonating Velloway\\\\\") is \"",
         "  \"adopted reading), while impersonation named on its own or singled out as likely (\\\\\"someone is very likely \"\n"
         "  \"impersonating Velloway\\\\\") is \""),
        ("  \"the clause says impersonation singled out as likely is one) | Event |\")",
         "  \"the clause says impersonation named on its own or singled out as likely is one) | Event |\")"),
        ("     \"be told whether a named person is genuine, is the third non-event, while impersonation singled out as likely is \"",
         "     \"be told whether a named person is genuine, is the third non-event, while impersonation named on its own or \"\n"
         "     \"singled out as likely is \""),
        ("never warns about (VI's L7), and with about 30 JU 8 runs per model even a 1–3% rate",
         "never warns about (VI's L7), and with about 30 JU 8 runs even a 1–3% rate"),
    ],
}
for name, pairs in EDITS.items():
    p = V / name
    s = p.read_text(encoding="utf-8")
    for old, new in pairs:
        assert s.count(old) == 1, (name, s.count(old), old[:90])
        s = s.replace(old, new, 1)
    p.write_text(s, encoding="utf-8")
    print(f"reworded {p}: {len(pairs)} replacements")
