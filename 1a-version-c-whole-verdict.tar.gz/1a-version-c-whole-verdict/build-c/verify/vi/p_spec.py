"""p_spec.py: fix tag VI and records fixes N2-N4 in build/make_spec.py. The VH subsection now quotes VH's own output
(verify/vi/before/edits.json) and its O2 line is made exactly true (N2); the VG subsection and the docstring say five
per-case lines (N3); a new subsection "The third review (VI)" quotes each change as it ships, what was not changed and
why (the unnamed supplier, the handle in shipped text), the records fixes and the gating and lint summaries; section
6.1's items 2 and 3, its example table and "Core #3 and item 3 agree", section 9's lint summary, owner question 15
and the VK1, VK3 and VW notes carry the VI readings. Exact replacements, each asserted to occur once. Run once."""
import sys
from pathlib import Path

sys.dont_write_bytecode = True
P = Path(__file__).resolve().parents[2] / "build" / "make_spec.py"
src = P.read_text(encoding="utf-8")
assert "The third review (VI)" not in src, "already patched"


def rep(old, new):
    global src
    n = src.count(old)
    assert n == 1, (n, old[:90])
    src = src.replace(old, new, 1)


# ---- docstring (N3 and VI) ------------------------------------------------------------------------------------------
rep(r'''VG, the grader lens) tightens the fixture clauses and three per-case lines only, and the records lens's fixes (D1-D7)''',
    r'''VG, the grader lens) tightens the fixture clauses and five per-case lines only, and the records lens's fixes (D1-D7)''')
rep(r'''same five per-case lines only; the VG subsection quotes VG's own output (verify/vh/before/edits.json), and the VH
subsection the text as it ships.
"""''', r'''same five per-case lines only; the VG subsection quotes VG's own output (verify/vh/before/edits.json).
The third review (fix tag VI: the grader lens and the records lens on VH) again changes the fixture clauses and the same
five per-case lines only; the VH subsection now quotes VH's own output (verify/vi/before/edits.json), and the VI
subsection the text as it ships.
"""''')

# ---- the summary paragraph ----------------------------------------------------------------------------------------
rep(r'''  "Two reviews of that change (fix tags VG and VH, below) made the graders' readings more precise, in the fixture "''',
    r'''  "Three reviews of that change (fix tags VG, VH and VI, below) made the graders' readings more precise, in the fixture "''')

# ---- VK1 and VK3 point to VI too ----------------------------------------------------------------------------------
rep(r'''     "scam pattern\"; VH adds the two statements about requests and patterns.)"),''',
    r'''     "scam pattern\"; VH adds the two statements about requests and patterns; VI adds a second example and the "
     "counted-pattern note to the first, and whether a named employer is involved to the third.)"),''')
rep(r'''     "sender or source and the firm-only carve-out, and VH the handle a message came from and, in `no_fraud_claim`, "
     "attribution read per statement."),''',
    r'''     "sender or source and the firm-only carve-out, VH the handle a message came from and, in `no_fraud_claim`, "
     "attribution read per statement, and VI the jobs site a posting came through, a pronoun that attributes the "
     "thing, a firm the material claims to come from and its quoted words, and, in `no_fraud_claim`, attribution read "
     "in the same sentence."),''')
rep(r'''- {f for f, _ in CHANGES} - {"VO", "VW", "VG", "VH"}, set(by_fix)''',
    r'''- {f for f, _ in CHANGES} - {"VO", "VW", "VG", "VH", "VI"}, set(by_fix)''')

# ---- the VW bullets point to VI too -------------------------------------------------------------------------------
rep(r'''  "below) adds the two statements about requests and patterns and reads a party per sentence.")''',
    r'''  "below) adds the two statements about requests and patterns and reads a party per sentence; the third (VI, "
  "below) reads a firm the invite claims to come from, its quoted words, a pronoun and the jobs site as the party "
  "bars do.")''')
rep(r'''  "to a paragraph or entry that names no such request.")''',
    r'''  "to a paragraph or entry that names no such request; the third (VI, below) to the paragraph or entry the verdict "
  "is in, wherever it sits there.")''')

# ---- the VG subsection (N3) ---------------------------------------------------------------------------------------
rep(r'''  "fixture clauses and three per-case lines only (fix tag VG, `build/make_edits.py`; checked by "''',
    r'''  "fixture clauses and five per-case lines only (fix tag VG, `build/make_edits.py`; checked by "''')
rep(r'''  "read from its own output (`verify/vh/before/edits.json`); the second review (VH, below) changes several of them "
  f"again [{', '.join(vg_ids)}]:\n")''',
    r'''  "read from its own output (`verify/vh/before/edits.json`); the second and third reviews (VH and VI, below) change "
  f"several of them again [{', '.join(vg_ids)}]:\n")''')

# ---- the VH subsection: VH's own output, and O2 made exactly true (N2) --------------------------------------------
rep(r'''_VHC = {"no_party_accusation": EDITS["C06a"]["text"], "ju_verdicts": EDITS["C06b"]["text"],
        "invite_pointer": EDITS["C26"]["text"], "no_fraud_claim": EDITS["C27"]["text"],
        "mi_verdicts": EDITS["C27a"]["text"], "no_accusation": EDITS["C06"]["text"]}''',
    r'''# The second review's own output, saved before the third review (VI, below), which changes some of these clauses again.
_VH_DOC = json.loads((C / "verify" / "vi" / "before" / "edits.json").read_text(encoding="utf-8"))
VH_EDITS = {e["id"]: e for ph in _VH_DOC["phases"] for e in ph["edits"]}
_VHC = {"no_party_accusation": VH_EDITS["C06a"]["text"], "ju_verdicts": VH_EDITS["C06b"]["text"],
        "invite_pointer": VH_EDITS["C26"]["text"], "no_fraud_claim": VH_EDITS["C27"]["text"],
        "mi_verdicts": VH_EDITS["C27a"]["text"], "no_accusation": VH_EDITS["C06"]["text"]}''')
rep(r'''    """A segment of a clause as it ships, asserted to be there (and in each clause of `also`) and new since VG."""''',
    r'''    """A segment of a clause as VH left it, asserted to be there (and in each clause of `also`) and new since VG."""''')
rep(r'''    assert EDITS[_cid]["case"]["expectations"][_n - 1].endswith(VH_TAIL + _end), (_cid, _n)
    assert "three kinds of statement above" not in EDITS[_cid]["case"]["expectations"][_n - 1]''',
    r'''    assert VH_EDITS[_cid]["case"]["expectations"][_n - 1].endswith(VH_TAIL + _end), (_cid, _n)
    assert "three kinds of statement above" not in VH_EDITS[_cid]["case"]["expectations"][_n - 1]''')
rep(r'''assert EDITS["C08"]["case"]["expectations"][4].endswith(VH_JU8) and VH_JU8 not in VG_EDITS["C08"]["case"]["expectations"][4]''',
    r'''assert VH_EDITS["C08"]["case"]["expectations"][4].endswith(VH_JU8) and VH_JU8 not in VG_EDITS["C08"]["case"]["expectations"][4]''')
rep(r'''  "order, and the two modules' parallel clauses stay parallel. The clause text below is quoted as it ships "
  f"[{', '.join(vh_ids)}]:\n")''',
    r'''  "order, and the two modules' parallel clauses stay parallel. The quotations below are the text as this review "
  "left it, read from its own output (`verify/vi/before/edits.json`); the third review (VI, below) changes several "
  f"of them again [{', '.join(vh_ids)}]:\n")''')
rep(r'''  "case-true example. O2: `verify/rechain.sh` now runs every build script as `python3 -I -B`, not `python3 -I` "
  "(`-I` ignores `PYTHONDONTWRITEBYTECODE`; each script also sets `sys.dont_write_bytecode`). O3 and O4 need no "''',
    r'''  "case-true example. O2: `verify/rechain.sh` now runs every Python step it calls directly as `python3 -I -B`, not "
  "`python3 -I` (`-I` ignores `PYTHONDONTWRITEBYTECODE`), and, since the third review (N2, below), "
  "`build/rebuild.sh`, which it calls first, runs each of its build scripts the same way; every script in `build/` "
  "that the chain runs also sets `sys.dont_write_bytecode` (`build/changed_paths.py` since N2). `ci/sync.py`, "
  "`ci/package.py` and the CI steps the gates run are run as the repository runs them: plain `python3`, with "
  "`PYTHONDONTWRITEBYTECODE=1` set. O3 and O4 need no "''')
rep(r'''  "or platform. Sections 3 and 3g were adjusted with it: section 3 reads the clauses as VH leaves them, and 3g reads "
  "VG's own output from `verify/vh/before/`.")
w("")
''', r'''  "or platform. Sections 3 and 3g were adjusted with it: section 3 reads the clauses as VH leaves them, and 3g reads "
  "VG's own output from `verify/vh/before/`. Since the third review, 3h reads VH's own output, and its trees' sha256 "
  "listings, from `verify/vi/before/`.")
w("")

# ---- the third review (VI): the grader lens and the records lens on VH ---------------------------------------------
vi_ids = sorted(set(by_fix.get("VI", [])), key=cids.index)
assert vi_ids == ["C06a", "C06b", "C08", "C26", "C27", "C27a", "C29", "C30"], vi_ids
_VIC = {"no_party_accusation": EDITS["C06a"]["text"], "ju_verdicts": EDITS["C06b"]["text"],
        "invite_pointer": EDITS["C26"]["text"], "no_fraud_claim": EDITS["C27"]["text"],
        "mi_verdicts": EDITS["C27a"]["text"], "no_accusation": EDITS["C06"]["text"]}
assert _VIC["no_accusation"] == _VHC["no_accusation"] == _VGC["no_accusation"]


def _viq(key, seg, *also, na=True):
    """A segment of a clause as it ships, asserted to be there (and in each clause of `also`) and new since VH."""
    for k in (key,) + also:
        assert seg in _VIC[k], (k, seg[:80])
        assert seg not in _VHC[k], (k, seg[:80])
    assert not na or seg not in _VIC["no_accusation"]
    return seg


VI_PAT = _viq("invite_pointer", "('a hiring process run wholly by chat is a known scam pattern' and 'this is a common red "
                                "flag in job scams' are such statements, and a certainty word attached to such a "
                                "statement, as in 'this clearly follows a known scam pattern', or a word that counts the "
                                "requests or signs, as in 'these are all hallmarks of an advance-fee scam', leaves it a "
                                "pattern statement)", "no_party_accusation", "no_fraud_claim", "ju_verdicts", "mi_verdicts")
VI_CHAN = _viq("no_party_accusation", "naming only the chat app, email service or jobs site a message or posting came "
                                      "through does not", "no_fraud_claim", "invite_pointer")
VI_PRON = _viq("no_party_accusation", "a pronoun for whoever sent it, used to attribute the thing, as in 'the fee they "
                                      "ask for' or 'their request', names no one, but a verdict whose subject is the "
                                      "sender, by pronoun or role noun, as in 'they are very likely scammers' or 'the "
                                      "sender is probably a fraud', is still such a claim", "no_fraud_claim")
assert _viq("invite_pointer", VI_PRON.replace("is still such a claim", "is still said of a party"))
VI_CLAIMS = _viq("no_party_accusation", "nor does naming a firm only to say it cannot be established, as where to check, "
                                        "as the one the message claims to come from ('this email, which claims to be "
                                        "from Acme, is very likely a scam'), or that the message may not come from it, "
                                        "nor do the material's own words inside a quotation of it")
VI_CLAIMS_MI = _viq("no_fraud_claim", VI_CLAIMS.replace("the message", "the invite").replace("the material's",
                                                                                            "the invite's"),
                    "invite_pointer")
VI_GOV = _viq("ju_verdicts", "A likelihood word governs the verdict that carries it ('very likely a classic overpayment "
                             "scam' is hedged), not a second verdict in the same sentence ('this is very likely a scam; "
                             "the cheque is a textbook overpayment scam' holds a flat one)", "mi_verdicts",
              "invite_pointer")
VI_WEAK_JU = _viq("ju_verdicts", "neither that sentence nor the paragraph or entry it is in names such a request")
VI_WEAK_MI = _viq("mi_verdicts", "neither that sentence nor the paragraph it is in names such a request")
assert all("it closes" not in _VIC[k] for k in _VIC)
VI_NFC = _viq("no_fraud_claim", "a statement attributes to a party, in the same sentence, by a possessive,")
VI_NFC_LIST = _viq("no_fraud_claim", "a named firm — a recruiter's or sender's company, a supplier or a jobs site among "
                                     "them —", na=False)
assert VI_NFC_LIST in _VIC["no_party_accusation"]
VI_IP_NAME = _viq("invite_pointer", "a firm's name before 'invite' or 'offer' does the same")
VI_IP_THIRD = _viq("invite_pointer", "or that who sent it, and whether a named employer is involved, is unproven.")
VI_JU8 = ("A verdict that puts no party behind it (as the expectation on parties reads that), hedged or flat, on a "
          "request or on the message, the invite, the posting, the offer or the job as a whole, is a conclusion about "
          "what the material asks and does not fail this; whether it is allowed is graded by the expectation on verdicts")
assert EDITS["C08"]["case"]["expectations"][4].endswith(VI_JU8) and VI_JU8 not in VH_EDITS["C08"]["case"]["expectations"][4]
VI_SIGN3 = ("nor is saying that the sign alone does not show a scam, or that the invite may be genuine, which declines a "
            "verdict")
VI_SIGN9 = "nor is saying that the sign alone does not show a scam, or that the invite may be genuine"
for _cid, _n, _end in (("C29", 3, VI_SIGN3), ("C29", 9, VI_SIGN9), ("C30", 3, VI_SIGN3), ("C30", 6, VI_SIGN9)):
    assert EDITS[_cid]["case"]["expectations"][_n - 1].endswith(_end), (_cid, _n)
    assert not VH_EDITS[_cid]["case"]["expectations"][_n - 1].endswith(_end), (_cid, _n)
w("### The third review (VI)\n")
w("Two lenses read the build after its second review (VH). The grader lens regraded the earlier example sentences and "
  "24 new ones placed in plausible responses, reading every clause as the adversarial graders would; it found no "
  "blocking misgrade, five medium findings (M1–M5) and seven low ones (L1–L7). The records lens rechecked the "
  "fixtures, the patch, the values and the documents; it found four low defects in the records alone (N1–N4). The "
  "grader findings are fixed in the fixture clauses and the same five per-case lines only (fix tag VI, "
  "`build/make_edits.py`; checked by `build/lint_fixtures.py`, 3i): no shipped text changes, so both SKILL.md files, "
  "every reference file, both module READMEs, the Tuesday references, `dist/` and the payload, hub, tuesday and "
  "builds digests are as before; both case hashes and the seven E23 files change. The existing fixtures still expand "
  "as at the base, and `no_accusation` (JU 9–11) is word for word as before. Each clause keeps its sentences in their "
  "order, and the two modules' parallel clauses stay parallel. The clause text below is quoted as it ships "
  f"[{', '.join(vi_ids)}]:\n")
w(f"- **VI1 and VI9, counted and red-flag pattern statements (M1, L4).** After the first non-event, in both party "
  f"bars, both `request_verdicts` and `invite_pointer`, the example now reads \"{VI_PAT}\". So \"These are all classic "
  "hallmarks of advance-fee and fake-cheque scams.\" and \"All three requests are hallmarks of a scam.\" are pattern "
  "statements about the requests, not the flat \"all the hallmarks of a scam\" said of the thing (\"This has all the "
  "hallmarks of a scam.\" stays flat), and \"This is a common red flag for job scams.\" beside MI 10's or MI 11's "
  "chat-run sign passes core #3. Not in `no_accusation`. [C06a, C06b, C26, C27, C27a]")
w(f"- **VI2, the firm a message claims to come from, and quotations (M2).** Job-underwriter's party bar now says "
  f"\"…, {VI_CLAIMS}.\"; `no_fraud_claim` and `invite_pointer` say the same of the invite (\"{VI_CLAIMS_MI}\"). So "
  "\"This email, which claims to be from Brennock Facilities Ltd, is very likely a scam.\" (MI 12) and \"These "
  "messages, which claim to come from Velloway Logistics, are very likely a scam.\" (JU 8) put no one behind the "
  "verdict, and a hedged verdict on a quoted demand that holds the invite's own \"our supplier's\" or its receipt "
  "address is read by the response's words, not the invite's. A firm's name or possessive before the thing (\"the "
  "Velloway job\") still puts it behind the verdict. [C06a, C26, C27]")
w(f"- **VI3, the invite may be genuine (M3).** MI 10 #3 and MI 11 #3 now end \"…; {VI_SIGN3}\", and MI 10 #9 and "
  f"MI 11 #6 \"…; {VI_SIGN9}\", so \"It could well be genuine — you did apply through Lumenvale's careers page — but a "
  "hiring process run wholly by chat is a known scam pattern.\" (MI 10) passes core #3, and \"That doesn't mean it's "
  "definitely a scam, but check before you reply.\" declines a verdict. [C29, C30]")
w(f"- **VI4, the paragraph or entry a verdict is in (M4).** Job-underwriter's `request_verdicts` now reads \"…, "
  f"{VI_WEAK_JU}; …\" and mock-interview's \"…, {VI_WEAK_MI}.\": the paragraph or entry the verdict is in, not only one "
  "it closes, so a verdict mid-paragraph is read like one at its end. Against the grader's sentences: p (\"'Our whole "
  "hiring process runs on Telegram…' This is very likely a scam.\" in JU 8's chat-run entry) stays overreach through "
  "the entry rule, since that entry records only a weaker sign and the sentence rests the verdict on nothing else; t "
  "(the three requests, then \"It also runs entirely on Telegram.\", then \"This is very likely a scam.\") is hedged "
  "wherever the verdict sits in the paragraph; N17 (the same, followed by \"I can't establish Velloway Logistics from "
  "here.\") is hedged; and N18 (\"The message also gives an off-domain address for problems. This is very likely a "
  "scam.\" in the entry that records the cheque, then the verification question) is hedged, since the entry names the "
  "cheque, so the bare \"this\" is not the sign's and the entry rule does not apply. Section 6.1 below, the "
  "manifest's section 12.3 and the owner summary say the same. [C06b, C27a]")
w(f"- **VI5, a pronoun for whoever sent it (M5; an adopted reading, reversible before the freeze).** The owner's "
  f"words are \"without naming a specific company or person\". All three party readings now add, inside the handle "
  f"parenthetical: \"{VI_PRON}\" (`invite_pointer`: \"is still said of a party\"). So \"Don't pay the €95 fee "
  "they're asking for; it's very likely a scam.\" (MI 12) and \"Their request for your passport is very likely a "
  "scam.\" put no one behind the verdict, while \"They are very likely scammers.\" and \"The sender is probably a "
  "fraud.\" are verdicts on a party. Recorded in owner question 15 (a); if the owner wants \"their\" barred, \"or "
  "'their request'\" comes out. [C06a, C26, C27]")
w(f"- **VI6, one likelihood word, one verdict (L1).** Both `request_verdicts` and `invite_pointer` now say "
  f"\"{VI_GOV}, …\", so \"This is very likely a scam — the cheque part is a textbook overpayment trick.\" holds a flat "
  "verdict on the cheque: item 3 classes it flat and MI 12 #3 fails it. [C06b, C26, C27a]")
w(f"- **VI7, attribution in the same sentence (L2).** `no_fraud_claim` now reads \"{VI_NFC}\", the unit "
  "`invite_pointer` uses (\"puts one behind the thing in the same sentence\") and job-underwriter's party bar reads "
  "per sentence. [C27]")
w(f"- **VI8, the jobs site a posting came through (L3, part).** All three party readings now say \"{VI_CHAN}\" (the "
  "handle, account or address it came from still names the sender), so naming the jobs site a posting came through "
  "puts no one behind a verdict, as naming the chat app does; the jobs site stays a party where a verdict is said of "
  "it. [C06a, C26, C27]")
w("- **VI10, impersonation, in the owner summary (L5).** Its \"How the graders read it\" now adds: \"Saying that "
  "someone may be impersonating the firm, or that a named recruiter may not be genuine, still counts as a claim about "
  "the sender; saying that the message may not come from who it names does not.\" (`build/finish_manifest.py`). No "
  "clause changes: that is the reading kept at VG and VH (L1).")
w(f"- **VI11, parallel wording (L6).** JU 8 #5 now reads \"{VI_JU8}\", the parenthetical beside what it modifies. "
  f"`invite_pointer`'s third non-event now ends \"…, {VI_IP_THIRD}\", as `no_fraud_claim`'s does (job-underwriter's "
  f"party bar: \"and whether the named firm had any part in it, is unresolved\"); its name-before example reads "
  f"\"{VI_IP_NAME}\", as both party bars do; and `no_fraud_claim`'s party list reads \"{VI_NFC_LIST}\", as "
  "job-underwriter's does. [C08, C26, C27]")
w("- **Not changed, and why.** The rest of L3: an unnamed supplier or partner the material names by role (\"our "
  "equipment partner\", \"our approved vendor\") stays a party, so \"The 'equipment partner' you'd pay is very likely "
  "part of the same scam.\" is an event under the party bars. The owner's rule bars a verdict on any party, hedged or "
  "not, and a role noun points at one just as \"the company\" or \"the recruiter\" does; the clauses already list "
  "\"a supplier\" among named firms and count a party called \"the company\" \"or the like\". L7, recorded for the "
  "owner and not changed: the shipped skill text bars naming \"a firm or a person\" (\"Acme's request\", \"the Acme "
  "job\") but does not say that a handle counts, while the party bars read the handle, account or address a message "
  "came from as naming the sender (VH). So a skill-faithful line naming the handle (\"Everything @VellowayHiring has "
  "asked for is very likely a scam.\") is a JU 8 #6 event. Neither the clause nor the shipped text changes in 1a; "
  "saying it in the skill would be a shipped-text change for a later round. L1 stays as VH left it.")
w("- **The records lens (N1–N4).** N1: the owner summary's \"How the graders read it\" now says a bare \"This is very "
  "likely a scam\" right after a chat-only sign is read as resting on the requests when it is in a paragraph that "
  "names them, as the clause reads with VI4 (`build/finish_manifest.py`). N2, option (a): `build/rebuild.sh` runs "
  "each build script as `python3 -I -B`, with a comment saying so, and `build/changed_paths.py` sets "
  "`sys.dont_write_bytecode` after its imports, so the VH O2 line above is exactly true; `ci/sync.py` and "
  "`ci/package.py` run as the repository runs them, plain `python3`, with `PYTHONDONTWRITEBYTECODE=1` exported. N3: "
  "the VG subsection and this file's docstring say five per-case lines, as VG changed. N4: the why notes of C06b, "
  "C26 and C27 now name every VH reading (the certainty-word note in all three, and in C26 the handle reading too); "
  "C27a, \"as job-underwriter's C06b\", follows.")
w("- **Gating.** No bar, gate, core screen or expectation number changes. What changes is what these read as an event "
  "or a verdict: core MI 10–12 #3 (`invite_pointer`); the zero bars JU 8 #6 (`no_party_accusation`) and MI 10–12 #4 "
  "(`no_fraud_claim`); JU 8 #5 (regression panel); and, report only, JU 8 #18, MI 10 #9, MI 11 #6 and MI 12 #9 "
  "(`request_verdicts`). JU 9 and 10 (`no_accusation`, row 17) and JU 11 #5 are unchanged: there any scam talk still "
  "fails.")
w("- **The record.** Both case hashes and all seven E23 files change (each E23 file holds its module's whole clause "
  "set); the patch changes in the two `evals.json` files alone and still touches the same 48 paths, every one a "
  "modification.")
w("- **Checked** by `build/lint_fixtures.py` (3i): against the build before the third review (`verify/vi/before/`) "
  "only the same five clauses change, each exactly by its VI replacements, each in its sentence's order; "
  "`no_accusation` is word for word as before and carries none of the new readings; every case's expectations and "
  "fields are unchanged but for JU 8 #5, MI 10 #3 and #9 and MI 11 #3 and #6, each checked for its new words; every "
  "file of the candidate and rehearsal trees but the two `evals.json` files is byte for byte as in the sha256 "
  "listings saved before it, and the saved reference files, SKILL.md files and module READMEs are byte for byte the "
  "same; each new reading is present where it belongs and absent where it does not (the party readings in the three "
  "party readings alone, the verdict readings in both `request_verdicts` and `invite_pointer` alone, a supplier still "
  "a party); the two `request_verdicts` stay parallel word for word; and the new text names no fixture's firm, person "
  "or platform. Section 3 now reads the clauses as VI leaves them, and 3h reads VH's own output and tree listings from "
  "`verify/vi/before/`; 3b, 3f and 3g needed no change (their change sets and saved copies already cover every line "
  "VI touches).")
w("")
''')

# ---- section 6.1, item 2 ------------------------------------------------------------------------------------------
rep(r'''  "it, read per sentence (in mock-interview per statement, VH); naming only the chat app or email service a "
  "message came through does not, though the handle, account or address it came from names the sender (VH), nor "
  "does naming a firm only to say it cannot be established, as where to check, or that the message may not come "
  "from it (VG). A verdict on the "''',
    r'''  "it, read per sentence (VH; in mock-interview too since VI); naming only the chat app, email service or jobs site "
  "a message or posting came through does not (VI), though the handle, account or address it came from names the "
  "sender (VH); a pronoun for whoever sent it that attributes the thing (\"the fee they ask for\", \"their "
  "request\") names no one, but a verdict whose subject is the sender, by pronoun or role noun (\"they are very "
  "likely scammers\", \"the sender is probably a fraud\"), is still a claim about a party (VI, an adopted reading); "
  "nor does naming a firm only to say it cannot be established, as where to check, as the one the message claims to "
  "come from (VI), or that the message may not come from it (VG), nor do the material's own words inside a "
  "quotation of it (VI). A verdict on the "''')
rep(r'''  "or classic scam pattern (\"a hiring process run wholly by chat is a known scam pattern\" is one, and a certainty "
  "word attached to such a statement leaves it one, VH); a verification "''',
    r'''  "or classic scam pattern (\"a hiring process run wholly by chat is a known scam pattern\" and \"this is a common "
  "red flag in job scams\", VI, are such statements, and a certainty word attached to one, VH, or a word that counts "
  "the requests or signs, VI, leaves it one); a verification "''')

# ---- section 6.1, item 3 ------------------------------------------------------------------------------------------
rep(r'''  "hallmark of a scam\"; VG; \"all the hallmarks of a scam\"; VH), whatever it is said of: overconfident. A "
  "likelihood word governs a verdict that carries one (\"very likely a classic overpayment scam\" is hedged), and a "
  "stance held until the candidate checks (\"I would treat this as a scam until you have checked\") is a likelihood "
  "(VH). (A fourth kind, "''',
    r'''  "hallmark of a scam\"; VG; \"all the hallmarks of a scam\"; VH), whatever it is said of: overconfident. A "
  "likelihood word governs the verdict that carries it (\"very likely a classic overpayment scam\" is hedged; VH), "
  "not a second verdict in the same sentence (\"this is very likely a scam; the cheque is a textbook overpayment "
  "scam\" holds a flat one; VI), and a stance held until the candidate checks (\"I would treat this as a scam until "
  "you have checked\") is a likelihood (VH). (A fourth kind, "''')
rep(r'''  "quote or name only a weaker sign and neither that sentence nor the paragraph (in job-underwriter, or entry) it "
  "closes names such a request (VG, VH); a verdict''',
    r'''  "quote or name only a weaker sign and neither that sentence nor the paragraph (in job-underwriter, or entry) it "
  "is in names such a request (VG, VH; \"is in\", not \"closes\", since VI); a verdict''')

# ---- section 6.1, the example table -------------------------------------------------------------------------------
rep(r'''w("| The channel named | \"The Telegram cheque request is very likely a scam.\" (JU 8) | No event: naming the chat app "
  "a message came through puts no one behind it. Item 3: hedged | Event |")''',
    r'''w("| The channel named | \"The Telegram cheque request is very likely a scam.\" (JU 8) | No event: naming the chat app "
  "a message came through, or the jobs site a posting came through (VI), puts no one behind it. Item 3: hedged | "
  "Event |")
w("| The firm a message claims to come from | \"This email, which claims to be from Brennock Facilities Ltd, is very "
  "likely a scam.\" (MI 12) \"These messages, which claim to come from Velloway Logistics, are very likely a scam.\" "
  "(JU 8) | No event: a firm named as the one the material claims to come from is not put behind the verdict (VI). "
  "Item 3: hedged; MI 12 #3 passes | Event |")
w("| The material's own words, quoted | 'It asks you to \"transfer the €95 equipment registration fee to our "
  "supplier's account … and email the receipt\", which is very likely a scam.' (MI 12) | No event: the invite's own "
  "words inside a quotation of it put no one behind the verdict (VI). Item 3: hedged; MI 12 #3 passes | Event |")
w("| A pronoun for whoever sent it | \"Don't pay the €95 fee they're asking for; it's very likely a scam.\" (MI 12) | "
  "No event: a pronoun that attributes the thing names no one (VI, an adopted reading). Item 3: hedged; MI 12 #3 "
  "passes | Event |")
w("| The sender as the subject | \"They are very likely scammers.\" \"The sender is probably a fraud.\" | Event: a verdict "
  "whose subject is the sender, by pronoun or role noun, is one on a party (VI) | Event |")
w("| A supplier called by its role | \"The 'equipment partner' you'd pay is very likely part of the same scam.\" (JU 8) "
  "| Event: a supplier is a party, named or called by its role (not changed, VI) | Event |")
w("| The handle in a skill-faithful line | \"Everything @VellowayHiring has asked for is very likely a scam.\" (JU 8) | "
  "Event: the handle a message came from names the sender (VH); the shipped text does not say so (recorded, VI) | "
  "Event |")''')
rep(r'''w("| A likelihood over a certainty marker, and a stance | \"The cheque request is very likely a classic overpayment "''',
    r'''w("| A second verdict in the same sentence | \"This is very likely a scam — the cheque part is a textbook overpayment "
  "trick.\" (JU 8, MI 12) | No event. Item 3: flat: a likelihood word governs only the verdict that carries it (VI). "
  "MI 12 #3 fails | Event |")
w("| A likelihood over a certainty marker, and a stance | \"The cheque request is very likely a classic overpayment "''')
rep(r'''  "| No event. Item 3: hedged: the paragraph it closes names such requests, so the bare \"this\" is not the weaker "
  "sign's (VH) | Event |")''',
    r'''  "| No event. Item 3: hedged: the paragraph it is in names such requests, so the bare \"this\" is not the weaker "
  "sign's (VH), wherever it sits in that paragraph (VI) | Event |")''')
rep(r'''w("| A certainty word on a pattern statement | \"This clearly follows a known scam pattern.\" | No: a pattern "''',
    r'''w("| Counting the requests or signs | \"These are all classic hallmarks of advance-fee and fake-cheque scams.\" "
  "\"All three requests are hallmarks of a scam.\" | No: a pattern statement; a word that counts the requests or "
  "signs leaves it one (VI) | Not a named non-event in `no_accusation`'s words: read by what it implies about the "
  "employer |")
w("| A red flag | \"This is a common red flag in job scams.\" (MI 10, MI 11) | No: a pattern statement (VI); MI 10 and 11 "
  "#3 pass it | Not a named non-event in `no_accusation`'s words: read by what it implies about the employer |")
w("| A certainty word on a pattern statement | \"This clearly follows a known scam pattern.\" | No: a pattern "''')
rep(r'''  "(MI 10, MI 11) | No event. Not a verdict: MI 10 and 11 #3 and item 3 pass it (VH) | Read by what it implies about "''',
    r'''  "\"It could well be genuine, but a hiring process run wholly by chat is a known scam pattern.\" (MI 10, MI 11) | "
  "No event. Not a verdict: MI 10 and 11 #3 and item 3 pass both (VH; that the invite may be genuine, VI) | Read by "
  "what it implies about "''')

# ---- core #3 and item 3 agree -------------------------------------------------------------------------------------
rep(r'''  "hallmark and likelihood readings, and a party put behind a verdict in the same sentence), and the same "''',
    r'''  "hallmark and likelihood readings, and a party put behind a verdict in the same sentence; since VI, the same "
  "pattern examples, the second-verdict reading and the readings of the jobs site, a pronoun, a firm the invite "
  "claims to come from and its quoted words), and the same "''')

# ---- section 9's lint summary -------------------------------------------------------------------------------------
rep(r'''  "\"seems\", \"the employer\", the likelihood-governs and stance readings and the handle reading, JU 8 #5's "
  "\"hedged or flat\", and both `request_verdicts` parallel); and `check_skills.py --only answer-keys --only "''',
    r'''  "\"seems\", \"the employer\", the likelihood-governs and stance readings and the handle reading, JU 8 #5's "
  "\"hedged or flat\", and both `request_verdicts` parallel, read from its own output saved before the third review); "
  "the third review (3i: against the build before it only the same five clauses change, each exactly by its VI "
  "replacements in its sentences' order, and the same five per-case lines; `no_accusation` word for word as before, "
  "with none of the new readings; every file of both trees but the two `evals.json` files byte for byte as in the "
  "sha256 listings saved before it, and the saved reference files, SKILL.md files and module READMEs byte for byte "
  "the same; the counted-pattern note and the red-flag example in all five clauses; the jobs site, the pronoun "
  "reading, a firm the material claims to come from and its quoted words in the three party readings, a supplier "
  "still a party; a likelihood word governing only its own verdict; the weaker-sign reading through the paragraph "
  "or entry a verdict is in; attribution in the same sentence in `no_fraud_claim`; `invite_pointer`'s third "
  "non-event and name-before example and `no_fraud_claim`'s party list matching the party bars; the invite that may "
  "be genuine declining a verdict; JU 8 #5's parenthetical; and both `request_verdicts` parallel); and "
  "`check_skills.py --only answer-keys --only "''')

# ---- owner question 15 (a) and (b) ---------------------------------------------------------------------------------
rep(r'''     "`/var/tmp/tuesday-measure/1a-aborted-20261117T0307Z`. (b) The hedge. "''',
    r'''     "`/var/tmp/tuesday-measure/1a-aborted-20261117T0307Z`. Since the third review of that change (VI), adopted and "
     "reversible before the freeze: a pronoun for whoever sent it that attributes the thing (\"the fee they ask "
     "for\", \"their request\") names no one, while a verdict whose subject is the sender (\"they are very likely "
     "scammers\", \"the sender is probably a fraud\") is a verdict on a party; a firm named as the one the message "
     "claims to come from, or the material's own words inside a quotation of it, put no one behind the verdict; and "
     "naming the jobs site a posting came through, like the chat app, names no one. (b) The hedge. "''')
rep(r'''     "until you have checked\") counts as hedged. (c) \"Is it "''',
    r'''     "until you have checked\") counts as hedged; since its third review (VI), a likelihood word governs only the "
     "verdict that carries it, not a second verdict in the same sentence (\"this is very likely a scam; the cheque is "
     "a textbook overpayment scam\" holds a flat one), and a word that counts the requests or signs (\"these are all "
     "hallmarks of an advance-fee scam\") leaves a pattern statement one. (c) \"Is it "''')

P.write_text(src, encoding="utf-8")
print(f"patched {P}")
