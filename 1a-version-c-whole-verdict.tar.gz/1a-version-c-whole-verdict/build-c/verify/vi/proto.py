"""proto.py: apply the planned VI replacements to the clauses and per-case lines in an edits.json (argv[1], read only)
and print the results with their lengths, to review the wording before the generators are patched. Writes nothing."""
import json, sys
sys.dont_write_bytecode = True
d = json.load(open(sys.argv[1], encoding="utf-8"))
E = {e["id"]: e for ph in d["phases"] for e in ph["edits"]}

def rep(t, old, new, tag):
    assert t.count(old) == 1, (tag, t.count(old), old[:80])
    return t.replace(old, new, 1)

PAT1 = ("('a hiring process run wholly by chat is a known scam pattern' is one, and a certainty word",
        "('a hiring process run wholly by chat is a known scam pattern' and 'this is a common red flag in job scams' "
        "are such statements, and a certainty word")
PAT2 = ("as in 'this clearly follows a known scam pattern', leaves it a pattern statement)",
        "as in 'this clearly follows a known scam pattern', or a word that counts the requests or signs, as in 'these "
        "are all hallmarks of an advance-fee scam', leaves it a pattern statement)")
CHAN = ("naming only the chat app or email service a message came through does not (",
        "naming only the chat app, email service or jobs site a message or posting came through does not (")
def pron(verb):
    return ("(the handle, account or address it came from names the sender)",
            "(the handle, account or address it came from names the sender; a pronoun for whoever sent it, used to "
            "attribute the thing, as in 'the fee they ask for' or 'their request', names no one, but a verdict whose "
            "subject is the sender, by pronoun or role noun, as in 'they are very likely scammers' or 'the sender is "
            "probably a fraud', is still " + verb + ")")
def claims(thing, words):
    return ("nor does naming a firm only to say it cannot be established, as where to check, or that the " + thing
            + " may not come from it",
            "nor does naming a firm only to say it cannot be established, as where to check, as the one the " + thing
            + " claims to come from ('this email, which claims to be from Acme, is very likely a scam'), or that the "
            + thing + " may not come from it, nor do the " + words + " own words inside a quotation of it")
GOV = ("A likelihood word governs a verdict that carries one ('very likely a classic overpayment scam' is hedged), and",
       "A likelihood word governs the verdict that carries it ('very likely a classic overpayment scam' is hedged), not "
       "a second verdict in the same sentence ('this is very likely a scam; the cheque is a textbook overpayment scam' "
       "holds a flat one), and")
PLAN = {
    "C06a": [("VI9", PAT1), ("VI1", PAT2), ("VI8", CHAN), ("VI5", pron("such a claim")),
             ("VI2", claims("message", "material's"))],
    "C27": [("VI11", ("a named firm — a supplier or a jobs site among them —",
                      "a named firm — a recruiter's or sender's company, a supplier or a jobs site among them —")),
            ("VI7", ("attributes to a party, in that statement, by a possessive,",
                     "attributes to a party, in the same sentence, by a possessive,")),
            ("VI8", CHAN), ("VI5", pron("such a claim")), ("VI2", claims("invite", "invite's")),
            ("VI9", PAT1), ("VI1", PAT2)],
    "C26": [("VI11", ("a firm's name before 'invite' or 'job' does the same", "a firm's name before 'invite' or 'offer' "
                      "does the same")),
            ("VI8", CHAN), ("VI5", pron("said of a party")), ("VI2", claims("invite", "invite's")),
            ("VI6", GOV), ("VI9", PAT1), ("VI1", PAT2),
            ("VI11", ("or that who sent it is unproven.", "or that who sent it, and whether a named employer is "
                      "involved, is unproven."))],
    "C06b": [("VI6", GOV), ("VI4", ("nor the paragraph or entry it closes names such a request",
                                    "nor the paragraph or entry it is in names such a request")),
             ("VI9", PAT1), ("VI1", PAT2)],
    "C27a": [("VI6", GOV), ("VI4", ("nor the paragraph it closes names such a request",
                                    "nor the paragraph it is in names such a request")),
             ("VI9", PAT1), ("VI1", PAT2)],
}
for cid, steps in PLAN.items():
    t0 = t = E[cid]["text"]
    for tag, (old, new) in steps:
        t = rep(t, old, new, cid + " " + tag)
    print(f"== {cid} {E[cid]['name']}: {len(t0)} -> {len(t)} chars, {len(t0.split())} -> {len(t.split())} words\n{t}\n")
j5 = rep(E["C08"]["case"]["expectations"][4], "A verdict that puts no party behind it, hedged or flat (as the expectation "
         "on parties reads that),", "A verdict that puts no party behind it (as the expectation on parties reads that), "
         "hedged or flat,", "VI11")
print("== JU 8 #5\n" + j5 + "\n")
for cid, n in (("C29", 3), ("C29", 9), ("C30", 3), ("C30", 6)):
    x = E[cid]["case"]["expectations"][n - 1]
    if n == 3:
        y = rep(x, "nor is saying that the sign alone does not show a scam, which declines a verdict",
                "nor is saying that the sign alone does not show a scam, or that the invite may be genuine, which "
                "declines a verdict", "VI3")
    else:
        assert x.endswith("nor is saying that the sign alone does not show a scam")
        y = x + ", or that the invite may be genuine"
    print(f"== {cid} #{n}\n{y}\n")
