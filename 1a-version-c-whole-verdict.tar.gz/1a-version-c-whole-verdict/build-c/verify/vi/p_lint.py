"""p_lint.py: fix tag VI in build/lint_fixtures.py. Section 3 reads the clauses as the third review leaves them; 3h
reads the second review's own output from the copy saved before the third review (verify/vi/before/), and its tree
check reads that copy's sha256 listing; a new 3i checks the third review against that copy. Exact replacements, each
asserted to occur once. Run once; refuses a second run."""
import re
import sys
from pathlib import Path

sys.dont_write_bytecode = True
P = Path(__file__).resolve().parents[2] / "build" / "lint_fixtures.py"
src = P.read_text(encoding="utf-8")
assert "3i." not in src, "already patched"


def rep(old, new):
    global src
    n = src.count(old)
    assert n == 1, (n, old[:90])
    src = src.replace(old, new, 1)


# ---- the docstring ----------------------------------------------------------------------------------------------
rep("   no_accusation keeps the old words. Section 3 reads the clauses as the second review (3h) leaves them.",
    "   no_accusation keeps the old words. Section 3 reads the clauses as the third review (3i) leaves them.")
rep('''3h. The second review (VH: the grader lens and the records lens on VG), against the build before it
   (../verify/vh/before/): only the same five clauses change,''',
    '''3h. The second review (VH: the grader lens and the records lens on VG), against the build before it
   (../verify/vh/before/), read from its own output, saved before the third review as ../verify/vi/before/ (3i changes
   the same clauses, and its trees are read from the sha256 listings saved there): only the same five clauses change,''')
rep('''   (VH7); both request_verdicts stay parallel; and the new text names no fixture's firm, person or platform.
4. The sentinel kinds''', '''   (VH7); both request_verdicts stay parallel; and the new text names no fixture's firm, person or platform.
3i. The third review (VI: the grader lens and the records lens on VH), against the build before it
   (../verify/vi/before/): only the same five clauses change, each exactly by the VI replacements, in its sentences'
   order; no_accusation is unchanged word for word and carries none of the new readings; every case's raw expectations
   and fields are unchanged but for JU 8 #5 (VI11) and MI 10 #3 and #9 and MI 11 #3 and #6 (VI3), each checked for
   its new words; every file of the candidate and rehearsal trees but the two evals.json files is byte for byte as in
   the sha256 listings saved there, and the saved reference files, SKILL.md files and module READMEs are byte for byte
   the same, so no shipped text changes; a word that counts the requests or signs leaves a pattern statement one, and
   'this is a common red flag in job scams' is such a statement, in all five clauses (VI1, VI9); in the three party
   readings a firm named as the one the material claims to come from and the material's own quoted words put no one
   behind a verdict (VI2), a pronoun that attributes the thing names no one while a verdict whose subject is the sender
   is one on a party (VI5), and the jobs site a posting came through is a channel (VI8), with a supplier still a party;
   a bare 'this' is the weaker sign's only where the paragraph (or entry) it is in names no such request (VI4); a
   likelihood word governs only the verdict that carries it (VI6); no_fraud_claim reads attribution in the same sentence
   (VI7); invite_pointer's third non-event, its name-before example and no_fraud_claim's party list match the party bars
   (VI11); saying the invite may be genuine declines a verdict in MI 10 and 11 (VI3); both request_verdicts stay
   parallel; and the new text names no fixture's firm, person or platform.
4. The sentinel kinds''')

# ---- section 3: the clauses as VI leaves them -------------------------------------------------------------------
rep('''                 "naming only the chat app or email service a message came through does not"):''',
    '''                 "naming only the chat app, email service or jobs site a message or posting came through does not"):''')
s = src.index('for part in ("verdict on whether the invite is genuine. Where the invite asks for " + VC_REQ')
e_marker = '''    say(part in mcl["invite_pointer"], f"invite_pointer (version C) says {part[-70:]!r}")\n'''
e = src.index(e_marker, s) + len(e_marker)
assert src.count(e_marker) == 1
NEW_IP_BLOCK = '''for part in ("verdict on whether the invite is genuine. Where the invite asks for " + VC_REQ + ", a hedged verdict on "
             "such a request, or on the message, the invite, the posting, the offer or the job as a whole, that puts "
             "no firm or person behind it ('this request is very likely a scam', 'this job is very likely a scam') is "
             "part of the warning and not such a verdict",
             "A verdict is such a verdict when it is flat, stated as a fact or a near-certainty ('almost certainly', "
             "'definitely', 'a classic scam', 'a textbook scam', 'clearly', 'obviously', 'every hallmark of a scam', "
             "'all the hallmarks of a scam'; 'looks like', 'appears to be', 'seems' and 'has the hallmarks of', "
             "without 'every' or 'all', are a likelihood); when it is said of a party (a firm or a person, named or "
             "called 'the company', 'the employer', 'the recruiter', 'the sender' or the like) or puts one behind the "
             "thing in the same sentence: by a possessive, by a name before the thing, or by naming it as the thing's "
             "sender or source ('the company's cheque request is very likely a scam', 'the cheque request from Acme', "
             "'the fee Acme asks for'; a firm's name before 'invite' or 'offer' does the same), though naming only the "
             "chat app, email service or jobs site a message or posting came through does not (the handle, account or "
             "address it came from names the sender; a pronoun for whoever sent it, used to attribute the thing, as in "
             "'the fee they ask for' or 'their request', names no one, but a verdict whose subject is the sender, by "
             "pronoun or role noun, as in 'they are very likely scammers' or 'the sender is probably a fraud', is still "
             "said of a party), nor does naming a firm only to say it cannot be established, as where to check, as the "
             "one the invite claims to come from ('this email, which claims to be from Acme, is very likely a scam'), "
             "or that the invite may not come from it, nor do the invite's own words inside a quotation of it, nor is a "
             "firm named elsewhere, as the one the invite names or as the company the pack prepares for, put behind a "
             "verdict in another sentence; or when the invite makes no such request.",
             "A likelihood word governs the verdict that carries it ('very likely a classic overpayment scam' is "
             "hedged), not a second verdict in the same sentence ('this is very likely a scam; the cheque is a textbook "
             "overpayment scam' holds a flat one), and a stance held until the candidate checks ('I would treat this as "
             "a scam until you have checked') is a likelihood.",
             "A bare 'this' or 'it' is said of the request where its sentence, or the one before or after it, quotes "
             "or names one such request or its hold",
             "Three kinds of statement are not such a verdict: that requests or signs like this are, or follow, a "
             "known or classic scam pattern ('a hiring process run wholly by chat is a known scam pattern' and 'this is "
             "a common red flag in job scams' are such statements, and a certainty word attached to such a statement, "
             "as in 'this clearly follows a known scam pattern', or a word that counts the requests or signs, as in "
             "'these are all hallmarks of an advance-fee scam', leaves it a pattern statement), a verification "
             "question, and that the invite may not come from who it names, or that who sent it, and whether a named "
             "employer is involved, is unproven. Nor are two statements about requests and patterns, not about the "
             "invite: that legitimate employers do not make requests like this or run a hiring process this way, and "
             "that scams often use a real firm's name."):
    say(part in mcl["invite_pointer"], f"invite_pointer (version C) says {part[-70:]!r}")
'''
src = src[:s] + NEW_IP_BLOCK + src[e:]

# ---- 3h: read the second review's own output from verify/vi/before/ ----------------------------------------------
h0 = src.index("# 3h. the second review (VH: the grader lens and the records lens on VG), against the build before it")
h1 = src.index("shipped = [p for p in (TREE / \"skills\").rglob(\"*.md\")]")
seg = src[h0:h1]
seg = re.sub(r"(?<![\w])jcl\[", "hjcl[", seg)
seg = re.sub(r"(?<![\w])mcl\[", "hmcl[", seg)


def srep(old, new):
    global seg
    assert seg.count(old) == 1, (seg.count(old), old[:90])
    seg = seg.replace(old, new, 1)


srep('''# 3h. the second review (VH: the grader lens and the records lens on VG), against the build before it (saved, read only)
''', '''# 3h. the second review (VH: the grader lens and the records lens on VG), against the build before it (saved, read only).
# Its own output is read from the copy saved before the third review (VI_BEFORE, 3i), since VI changed the same clauses
# and per-case lines after it; its trees from the sha256 listings saved there (VI changed only the two evals.json files).
VI_BEFORE = C / "verify" / "vi" / "before"
_VH_OUT = {short: json.loads((VI_BEFORE / f"{short}-evals.json").read_text(encoding="utf-8")) for short in ("ju", "mi")}
hjcl, hmcl = _VH_OUT["ju"]["clauses"], _VH_OUT["mi"]["clauses"]
''')
srep('''    now = json.loads((TREE / "skills" / skill / "evals" / "evals.json").read_text(encoding="utf-8"))
    edits_ = VH_CLAUSE_EDITS[skill]''', '''    now = _VH_OUT[short]
    edits_ = VH_CLAUSE_EDITS[skill]''')
srep('''_mi_now = {c["id"]: c for c in json.loads((TREE / "skills/mock-interview/evals/evals.json").read_text())["evals"]}''',
     '''_mi_now = {c["id"]: c for c in _VH_OUT["mi"]["evals"]}''')
srep('''_j5n = jraw[8]["expectations"][4]''', '''_j5n = {c["id"]: c for c in _VH_OUT["ju"]["evals"]}[8]["expectations"][4]''')
srep('''for label, root, was_root in (("candidate", TREE, VH_BEFORE / "tree"), ("rehearsal", REH, VH_BEFORE / "tree-rehearsal")):
    fa, fb = _files(was_root), _files(root)
    differ = sorted(k for k in set(fa) | set(fb) if k not in fa or k not in fb or fa[k].read_bytes() != fb[k].read_bytes())
    say(set(fa) == set(fb) and set(differ) == EVALS_JSON,
        f"{label} (VH): {len(fb)} files, every one byte for byte as before but the two evals.json files "
        f"(shipped text, the .skill archives and dist/ unchanged) {differ if set(differ) != EVALS_JSON else ''}")
''', '''import hashlib  # noqa: E402


def _listing(path):
    """A tree's sha256 listing as saved before the third review: {relative path: sha256}."""
    out = {}
    for line in path.read_text(encoding="utf-8").splitlines():
        h, rel = line.split("  ", 1)
        out[rel[2:] if rel.startswith("./") else rel] = h
    return out


def _sha_files(root):
    return {k: hashlib.sha256(p.read_bytes()).hexdigest() for k, p in _files(root).items()}


for label, listing, was_root in (("candidate", "tree-sha256.txt", VH_BEFORE / "tree"),
                                 ("rehearsal", "tree-rehearsal-sha256.txt", VH_BEFORE / "tree-rehearsal")):
    fa, fb = _sha_files(was_root), _listing(VI_BEFORE / listing)
    differ = sorted(k for k in set(fa) | set(fb) if fa.get(k) != fb.get(k))
    say(set(fa) == set(fb) and set(differ) == EVALS_JSON,
        f"{label} (VH, its saved output): {len(fb)} files, every one byte for byte as before but the two evals.json "
        f"files (shipped text, the .skill archives and dist/ unchanged) {differ if set(differ) != EVALS_JSON else ''}")
''')
assert "TREE" not in seg and "jraw" not in seg and not re.search(r"(?<![\w])[jm]cl\[", seg), "3h still reads the tree"
src = src[:h0] + seg + "@@3I@@" + src[h1:]

# ---- 3i: the third review, against verify/vi/before/ --------------------------------------------------------------
SECTION_3I = '''# 3i. the third review (VI: the grader lens and the records lens on VH), against the build before it (saved, read only)
VI_PAT_ONE = ("('a hiring process run wholly by chat is a known scam pattern' is one, and a certainty word",
              "('a hiring process run wholly by chat is a known scam pattern' and 'this is a common red flag in job "
              "scams' are such statements, and a certainty word")
VI_COUNT = ("as in 'this clearly follows a known scam pattern', leaves it a pattern statement)",
            "as in 'this clearly follows a known scam pattern', or a word that counts the requests or signs, as in "
            "'these are all hallmarks of an advance-fee scam', leaves it a pattern statement)")
VI_PAT = VH_PATTERN.replace(*VI_PAT_ONE).replace(*VI_COUNT)
_CHAN = ("naming only the chat app or email service a message came through does not (",
         "naming only the chat app, email service or jobs site a message or posting came through does not (")
_PRONOUN = ("(the handle, account or address it came from names the sender; a pronoun for whoever sent it, used to "
            "attribute the thing, as in 'the fee they ask for' or 'their request', names no one, but a verdict whose "
            "subject is the sender, by pronoun or role noun, as in 'they are very likely scammers' or 'the sender is "
            "probably a fraud', is still {0})")
_CLAIMS = ("nor does naming a firm only to say it cannot be established, as where to check, as the one the {0} claims to "
           "come from ('this email, which claims to be from Acme, is very likely a scam'), or that the {0} may not come "
           "from it, nor do the {1} own words inside a quotation of it")
_GOV_VI = ("A likelihood word governs the verdict that carries it ('very likely a classic overpayment scam' is hedged), "
           "not a second verdict in the same sentence ('this is very likely a scam; the cheque is a textbook "
           "overpayment scam' holds a flat one), and a stance held until the candidate checks ('I would treat this as a "
           "scam until you have checked') is a likelihood. ")


def _party_vi(thing, words, verb):
    return [_CHAN, ("(the handle, account or address it came from names the sender)", _PRONOUN.format(verb)),
            ("nor does naming a firm only to say it cannot be established, as where to check, or that the " + thing
             + " may not come from it", _CLAIMS.format(thing, words))]


def _verdicts_vi(where):
    return [(_GOVERNS, _GOV_VI), ("nor the paragraph" + where + " it closes names such a request",
                                  "nor the paragraph" + where + " it is in names such a request"), VI_PAT_ONE, VI_COUNT]


VI_CLAUSE_EDITS = {
    "job-underwriter": {
        "no_party_accusation": _party_vi("message", "material's", "such a claim") + [VI_PAT_ONE, VI_COUNT],
        "request_verdicts": _verdicts_vi(" or entry")},
    "mock-interview": {
        "no_fraud_claim": [("a named firm — a supplier or a jobs site among them —",
                            "a named firm — a recruiter's or sender's company, a supplier or a jobs site among them —"),
                           ("attributes to a party, in that statement, by a possessive,",
                            "attributes to a party, in the same sentence, by a possessive,")]
                          + _party_vi("invite", "invite's", "such a claim") + [VI_PAT_ONE, VI_COUNT],
        "request_verdicts": _verdicts_vi(""),
        "invite_pointer": [("a firm's name before 'invite' or 'job' does the same",
                            "a firm's name before 'invite' or 'offer' does the same")]
                          + _party_vi("invite", "invite's", "said of a party")
                          + [(_GOVERNS, _GOV_VI), VI_PAT_ONE, VI_COUNT,
                             ("or that who sent it is unproven.",
                              "or that who sent it, and whether a named employer is involved, is unproven.")]},
}
_SIGN = "nor is saying that the sign alone does not show a scam"
_GENUINE = ", or that the invite may be genuine"
VI_LINES = {"job-underwriter": {8: {5: ("A verdict that puts no party behind it, hedged or flat (as the expectation on "
                                        "parties reads that),", "A verdict that puts no party behind it (as the "
                                        "expectation on parties reads that), hedged or flat,")}},
            "mock-interview": {i: {3: (_SIGN + ", which declines a verdict", _SIGN + _GENUINE + ", which declines a verdict"),
                                   n: (_SIGN, _SIGN + _GENUINE)} for i, n in ((10, 9), (11, 6))}}
for skill, short in (("job-underwriter", "ju"), ("mock-interview", "mi")):
    was = _VH_OUT[short]
    now = json.loads((TREE / "skills" / skill / "evals" / "evals.json").read_text(encoding="utf-8"))
    edits_ = VI_CLAUSE_EDITS[skill]
    diff = {k for k in set(was["clauses"]) | set(now["clauses"]) if was["clauses"].get(k) != now["clauses"].get(k)}
    say(diff == set(edits_) and list(was["clauses"]) == list(now["clauses"]),
        f"{skill} (VI): only {sorted(edits_)} changed among the clauses, in the same order {sorted(diff) if diff != set(edits_) else ''}")
    for name, pairs in edits_.items():
        t = was["clauses"][name]
        pos = [t.find(old) for old, new in pairs]
        ok, added = pos == sorted(pos), []
        for old, new in pairs:
            ok = ok and t.count(old) == 1 and new not in t
            t = t.replace(old, new, 1)
            added.append(new)
        say(ok and t == now["clauses"][name], f"{skill} {name} (VI): the before text with exactly the "
                                               f"{len(pairs)} VI replacements, each in its sentence's order")
        hits = [n for n in VG_NAMES if any(n in a for a in added)]
        say(not hits, f"{skill} {name} (VI): the new text names no fixture's firm, person or platform {hits or ''}")
    lines_vi = VI_LINES[skill]

    def masked(evals):
        out = json.loads(json.dumps(evals))
        for c in out:
            for n in lines_vi.get(c["id"], {}):
                c["expectations"][n - 1] = None
        return out
    say(masked(was["evals"]) == masked(now["evals"]) and was["skill_name"] == now["skill_name"]
        and [k for k in was if k != "clauses"] == [k for k in now if k != "clauses"],
        f"{skill} (VI): every case's raw expectations, tails and fields are unchanged but for "
        + ", ".join(f"{short.upper()} {i} #{n}" for i in sorted(lines_vi) for n in sorted(lines_vi[i])))
    bw, bn = {c["id"]: c for c in was["evals"]}, {c["id"]: c for c in now["evals"]}
    for i, nums in sorted(lines_vi.items()):
        for n, (old, new) in sorted(nums.items()):
            a, b = bw[i]["expectations"][n - 1], bn[i]["expectations"][n - 1]
            ok = a.count(old) == 1 and new not in a and b == a.replace(old, new, 1)
            if short == "mi":
                ok = ok and a.endswith(old) and b.endswith(new)
            say(ok, f"{skill} {i} #{n} (VI): '{old[:44]}...' becomes '{new[:44]}...' and nothing else changes")
            hits = [x for x in VG_NAMES if x in new]
            say(not hits, f"{skill} {i} #{n} (VI): the new words name no fixture's firm, person or platform {hits or ''}")
say(jcl["no_accusation"] == hjcl["no_accusation"] == vjcl["no_accusation"]
    and not any(x in jcl["no_accusation"] for x in ("red flag", "counts the requests", "email service or jobs site",
                                                    "pronoun", "claims to come", "quotation", "second verdict", "it is in",
                                                    "may be genuine")),
    "no_accusation (VI): unchanged word for word, none of the new readings; in JU 9-11 any scam talk still fails")
_FIVE_VI = (("no_party_accusation", jcl["no_party_accusation"]), ("no_fraud_claim", mcl["no_fraud_claim"]),
            ("job-underwriter request_verdicts", jcl["request_verdicts"]),
            ("mock-interview request_verdicts", mcl["request_verdicts"]), ("invite_pointer", mcl["invite_pointer"]))
for name, clause in _FIVE_VI:
    say(clause.count(VI_PAT) == 1 and VH_PATTERN not in clause,
        f"{name} (VI1, VI9): 'this is a common red flag in job scams' is a pattern statement, and a word that counts the "
        "requests or signs, like a certainty word, leaves one a pattern statement")
    say("it closes" not in clause, f"{name} (VI4): nothing binds through the paragraph a verdict closes")
_THREE_VI = (("no_party_accusation", jcl["no_party_accusation"], "message", "material's", "such a claim"),
             ("no_fraud_claim", mcl["no_fraud_claim"], "invite", "invite's", "such a claim"),
             ("invite_pointer", mcl["invite_pointer"], "invite", "invite's", "said of a party"))
for name, clause, thing, words, verb in _THREE_VI:
    say(clause.count(_CHAN[1]) == 1 and _CHAN[0] not in clause,
        f"{name} (VI8): the chat app, email service or jobs site a message or posting came through puts no one behind it")
    say(clause.count(_PRONOUN.format(verb)) == 1,
        f"{name} (VI5): a pronoun that attributes the thing to whoever sent it names no one; a verdict whose subject "
        "is the sender, by pronoun or role noun, is still one on a party")
    say(clause.count(_CLAIMS.format(thing, words)) == 1,
        f"{name} (VI2): a firm named as the one the {thing} claims to come from, and the {thing}'s own quoted words, "
        "put no one behind a verdict")
for name, clause in (("no_party_accusation", jcl["no_party_accusation"]), ("no_fraud_claim", mcl["no_fraud_claim"])):
    say("a named firm — a recruiter's or sender's company, a supplier or a jobs site among them —" in clause
        and "the firm's name before 'invite' or 'offer' does the same" in clause,
        f"{name} (VI8 not changed, VI11): a supplier, named or called by its role, is still a party; the same party "
        "list and name-before example in both party bars")
for name, clause in (("job-underwriter request_verdicts", jcl["request_verdicts"]),
                     ("mock-interview request_verdicts", mcl["request_verdicts"]), ("invite_pointer", mcl["invite_pointer"])):
    say(clause.count(_GOV_VI) == 1 and _GOVERNS not in clause,
        f"{name} (VI6): a likelihood word governs the verdict that carries it, not a second verdict in the same sentence")
for name, clause in (("no_party_accusation", jcl["no_party_accusation"]), ("no_fraud_claim", mcl["no_fraud_claim"])):
    say("likelihood word" not in clause and "it is in names" not in clause,
        f"{name} (VI4, VI6): the verdict readings stay in request_verdicts and invite_pointer")
for name, clause in (("job-underwriter request_verdicts", jcl["request_verdicts"]),
                     ("mock-interview request_verdicts", mcl["request_verdicts"])):
    say("pronoun" not in clause and "claims to come from" not in clause and "jobs site" not in clause,
        f"{name} (VI2, VI5, VI8): the party readings stay in the party bars and invite_pointer")
say("neither that sentence nor the paragraph or entry it is in names such a request" in jcl["request_verdicts"]
    and "neither that sentence nor the paragraph it is in names such a request" in mcl["request_verdicts"],
    "request_verdicts (VI4): a bare 'this' is the weaker sign's only where the paragraph (in job-underwriter, or entry) "
    "it is in names no such request")
say("a statement attributes to a party, in the same sentence, by a possessive," in mcl["no_fraud_claim"]
    and "in that statement" not in mcl["no_fraud_claim"] and "or puts one behind the thing in the same sentence:" in
    mcl["invite_pointer"], "no_fraud_claim (VI7): attribution read in the same sentence, as invite_pointer reads it")
say("a firm's name before 'invite' or 'offer' does the same" in mcl["invite_pointer"]
    and "'invite' or 'job'" not in mcl["invite_pointer"]
    and "or that who sent it, and whether a named employer is involved, is unproven." in mcl["invite_pointer"]
    and "and whether a named employer is involved, is unproven." in mcl["no_fraud_claim"]
    and "and whether the named firm had any part in it, is unresolved." in jcl["no_party_accusation"],
    "invite_pointer (VI11): its third non-event and name-before example match the party bars")
_par_vi = (jcl["request_verdicts"].replace("Each sentence of the response, its risk register and snapshot included,",
                                           "Each statement in the response, any saved file included,")
           .replace("a hiring process run wholly by chat, or contact off the employer's domain beyond scheduling)",
                    "a hiring process run wholly by chat)")
           .replace("that the message may not come from who it names", "that the invite may not come from who it names")
           .replace("nor the paragraph or entry it is in", "nor the paragraph it is in")
           .replace(_ENTRY_VH, "."))
say(_par_vi == mcl["request_verdicts"], "request_verdicts (VI): the two modules' clauses stay parallel, word for word "
                                        "but for scope, weaker signs, message or invite, and the entry rule")
_mi_vi = {c["id"]: c for c in json.loads((TREE / "skills/mock-interview/evals/evals.json").read_text())["evals"]}
say(all(_mi_vi[i]["expectations"][n - 1].endswith(_VH_TAIL + end) for i, n, end in
        ((10, 3, "does not fail this; " + _SIGN + _GENUINE + ", which declines a verdict"),
         (11, 3, "does not fail this; " + _SIGN + _GENUINE + ", which declines a verdict"),
         (10, 9, "is not overreach; " + _SIGN + _GENUINE), (11, 6, "is not overreach; " + _SIGN + _GENUINE))),
    "mock-interview 10 and 11 #3 and request_verdicts (VI3): saying the sign alone does not show a scam, or that the "
    "invite may be genuine, declines a verdict")
_j5vi = jraw[8]["expectations"][4]
say("A verdict that puts no party behind it (as the expectation on parties reads that), hedged or flat, on a request"
    in _j5vi and "hedged or flat (as" not in _j5vi,
    "job-underwriter 8 #5 (VI11): the parenthetical sits next to what it modifies")
for label, root, listing in (("candidate", TREE, "tree-sha256.txt"), ("rehearsal", REH, "tree-rehearsal-sha256.txt")):
    fa, fb = _listing(VI_BEFORE / listing), _sha_files(root)
    differ = sorted(k for k in set(fa) | set(fb) if fa.get(k) != fb.get(k))
    say(set(fa) == set(fb) and set(differ) == EVALS_JSON,
        f"{label} (VI): {len(fb)} files, every one byte for byte as before but the two evals.json files "
        f"(shipped text, the .skill archives and dist/ unchanged) {differ if set(differ) != EVALS_JSON else ''}")
for label, root, saved in (("candidate", TREE, "shipped-tree"), ("rehearsal", REH, "shipped-tree-rehearsal")):
    kept = _files(VI_BEFORE / saved)
    same = [k for k, p in kept.items() if (root / k).is_file() and (root / k).read_bytes() == p.read_bytes()]
    say(len(kept) > 0 and len(same) == len(kept),
        f"{label} (VI): the {len(kept)} saved reference files, SKILL.md files and module READMEs are byte for byte "
        "the same")

'''
src = src.replace("@@3I@@", SECTION_3I, 1)
assert "@@3I@@" not in src
P.write_text(src, encoding="utf-8")
print(f"patched {P}")
