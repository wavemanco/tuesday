"""p_rebuild.py: records fix N2, option (a): build/rebuild.sh runs each build script as `python3 -I -B` (it ran them as
`python3 -I`, and -I ignores PYTHONDONTWRITEBYTECODE), with one comment line saying so and that ci/sync.py and
ci/package.py run as the repository runs them; and build/changed_paths.py sets sys.dont_write_bytecode after its
imports, as every other build script does. Exact replacements, each asserted. Run once; refuses a second run."""
import re
import sys
from pathlib import Path

sys.dont_write_bytecode = True
BUILD = Path(__file__).resolve().parents[2] / "build"

rb = BUILD / "rebuild.sh"
src = rb.read_text(encoding="utf-8")
assert "python3 -I -B" not in src, "already patched"
calls = re.findall(r'python3 -I "\$B/build/(\w+\.py)"', src)
assert calls == ["make_edits.py", "h_noop.py", "apply.py", "rehearse.py", "changed_paths.py", "changed_paths.py"], calls
src = src.replace('python3 -I "$B/build/', 'python3 -I -B "$B/build/')
old = "export PYTHONDONTWRITEBYTECODE=1\n"
assert src.count(old) == 1
src = src.replace(old, old + "# Build scripts run as python3 -I -B (-I alone ignores PYTHONDONTWRITEBYTECODE); ci/sync.py and ci/package.py run\n"
                             "# as the repository runs them, plain python3, with PYTHONDONTWRITEBYTECODE=1 exported (records fix N2).\n", 1)
assert len(re.findall(r'python3 -I -B "\$B/build/', src)) == 6 and not re.findall(r"python3 -I (?!-B)", src)
assert src.count("python3 ci/sync.py") == 1 and src.count("python3 ci/package.py") == 2
rb.write_text(src, encoding="utf-8")
print(f"patched {rb}: 6 build-script calls now python3 -I -B; ci/sync.py and ci/package.py unchanged")

cp = BUILD / "changed_paths.py"
src = cp.read_text(encoding="utf-8")
assert "dont_write_bytecode" not in src, "already patched"
old = "import filecmp\nimport sys\nfrom pathlib import Path\n"
assert src.count(old) == 1
src = src.replace(old, old + "\nsys.dont_write_bytecode = True\n", 1)
src = src.replace("    python3 -I changed_paths.py BASE_TREE TREE OUT_FILE", "    python3 -I -B changed_paths.py BASE_TREE TREE OUT_FILE", 1)
cp.write_text(src, encoding="utf-8")
print(f"patched {cp}: sys.dont_write_bytecode set after the imports")
