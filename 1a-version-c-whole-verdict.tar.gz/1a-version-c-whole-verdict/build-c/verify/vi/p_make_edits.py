"""p_make_edits.py: apply fix tag VI (the third review: the grader lens and the records lens on VH) to
build/make_edits.py, by exact replacements, each asserted to occur once, and records fixes N3 (docstring) and N4 (the
why notes of C06b, C26 and C27). Run once; refuses a second run."""
import sys
from pathlib import Path

sys.dont_write_bytecode = True
P = Path(__file__).resolve().parents[2] / "build" / "make_edits.py"
src = P.read_text(encoding="utf-8")
assert "VI_PAT_ONE" not in src, "already patched"


def rep(old, new):
    global src
    n = src.count(old)
    assert n == 1, (n, old[:90])
    src = src.replace(old, new, 1)


# 1. docstring: N3 (VG changed five per-case lines, not three) and one paragraph for VI
rep('''The review of that change (VG, the grader lens) tightens the clauses and three per-case lines only, never shipped text:''',
    '''The review of that change (VG, the grader lens) tightens the clauses and five per-case lines only, never shipped text:''')
rep('''from names the sender. Every edit it touches carries the fix tag "VH".
''', '''from names the sender. Every edit it touches carries the fix tag "VH".
The third review (VI, the grader lens and the records lens on VH) again changes the clauses and the same per-case lines
only: a word that counts the requests or signs leaves a pattern statement one, and 'this is a common red flag in job
scams' is one; a firm named as the one the material claims to come from, the material's own words in a quotation, the
jobs site a posting came through, and a pronoun that attributes the thing to whoever sent it put no one behind a
verdict, but a verdict whose subject is the sender is a verdict on a party; a likelihood word governs only the verdict
that carries it; a bare 'this' is a weaker sign's only where the paragraph or entry it is in names no qualifying
request; and saying the invite may be genuine declines a verdict. Every edit it touches carries the fix tag "VI".
''')

# 2. the VI block, after the VH block
rep('''assert VG_PATTERN_OLD in NO_ACCUSATION and "hallmark" not in NO_ACCUSATION and "legitimate employers" not in NO_ACCUSATION
''', '''assert VG_PATTERN_OLD in NO_ACCUSATION and "hallmark" not in NO_ACCUSATION and "legitimate employers" not in NO_ACCUSATION

# ---- the third review (VI: the grader lens and the records lens on VH), in the clauses and per-case lines only ------
# VI1 (M1): a word that counts the requests or signs ('these are all hallmarks of an advance-fee scam') leaves a pattern
# statement one, in the certainty-word note of all five clauses. VI9 (L4): 'this is a common red flag in job scams' is
# a pattern statement too, beside the gate example. VI2 (M2): in the three party readings, naming a firm as the one the
# message or invite claims to come from, or the material's own words inside a quotation of it, puts no one behind a
# verdict. VI5 (M5, an adopted reading): a pronoun for whoever sent it, used to attribute the thing, names no one, but a
# verdict whose subject is the sender, by pronoun or role noun, is still one on a party. VI8 (L3): the jobs site a
# posting came through is a channel, like the chat app or email service. VI6 (L1): a likelihood word governs the
# verdict that carries it, not a second verdict in the same sentence. VI4 (M4): a bare 'this' is the weaker sign's only
# where the paragraph (or entry) it is in, not only the one it closes, names no such request. VI7 (L2): no_fraud_claim
# reads attribution in the same sentence, as invite_pointer does. VI11 (L6): invite_pointer's third non-event covers
# whether a named employer is involved and its name-before example is 'invite' or 'offer'; no_fraud_claim's party list
# names a recruiter's or sender's company. VI3 (M3) and VI11's JU 8 #5 are per-case lines, below. Not changed: an
# unnamed supplier or partner named by role ('our equipment partner') stays a party (the owner bars a verdict on any
# party, a role noun included); the shipped text, which never says a handle names the sender (L7, recorded only).
VI_PAT_ONE = ("('a hiring process run wholly by chat is a known scam pattern' is one, and a certainty word",
              "('a hiring process run wholly by chat is a known scam pattern' and 'this is a common red flag in job "
              "scams' are such statements, and a certainty word")
VI_COUNT = ("as in 'this clearly follows a known scam pattern', leaves it a pattern statement)",
            "as in 'this clearly follows a known scam pattern', or a word that counts the requests or signs, as in "
            "'these are all hallmarks of an advance-fee scam', leaves it a pattern statement)")
VI_CHANNEL = ("naming only the chat app or email service a message came through does not (",
              "naming only the chat app, email service or jobs site a message or posting came through does not (")
VI_PRONOUN_OLD = "(the handle, account or address it came from names the sender)"
VI_PRONOUN = ("(the handle, account or address it came from names the sender; a pronoun for whoever sent it, used to "
              "attribute the thing, as in 'the fee they ask for' or 'their request', names no one, but a verdict whose "
              "subject is the sender, by pronoun or role noun, as in 'they are very likely scammers' or 'the sender is "
              "probably a fraud', is still {0})")
VI_CLAIMS_OLD = ("nor does naming a firm only to say it cannot be established, as where to check, or that the {0} may not "
                 "come from it")
VI_CLAIMS = ("nor does naming a firm only to say it cannot be established, as where to check, as the one the {0} claims "
             "to come from ('this email, which claims to be from Acme, is very likely a scam'), or that the {0} may not "
             "come from it, nor do the {1} own words inside a quotation of it")
VI_GOVERNS = ("A likelihood word governs a verdict that carries one ('very likely a classic overpayment scam' is hedged), "
              "and a stance",
              "A likelihood word governs the verdict that carries it ('very likely a classic overpayment scam' is "
              "hedged), not a second verdict in the same sentence ('this is very likely a scam; the cheque is a textbook "
              "overpayment scam' holds a flat one), and a stance")
VI_PAT = VH_PATTERN.replace(*VI_PAT_ONE).replace(*VI_COUNT)
assert VI_PAT != VH_PATTERN and VI_PAT.count("such statements") == 1 and VI_PAT.count("counts the requests") == 1


def vi_party(clause, thing, words, verb):
    """A party reading after the third review (VI): the jobs site a channel, a pronoun that attributes names no one,
    a firm named as the one the material claims to come from and the material's own quoted words put no one behind it,
    and the pattern note."""
    clause = patch(clause, VI_CHANNEL[0], VI_CHANNEL[1], "VI8")
    clause = patch(clause, VI_PRONOUN_OLD, VI_PRONOUN.format(verb), "VI5")
    clause = patch(clause, VI_CLAIMS_OLD.format(thing), VI_CLAIMS.format(thing, words), "VI2")
    clause = patch(clause, VI_PAT_ONE[0], VI_PAT_ONE[1], "VI9")
    return patch(clause, VI_COUNT[0], VI_COUNT[1], "VI1")


NO_PARTY_ACCUSATION_C = vi_party(NO_PARTY_ACCUSATION_C, "message", "material's", "such a claim")
NO_FRAUD_CLAIM_C = patch(NO_FRAUD_CLAIM_C, "a named firm — a supplier or a jobs site among them —", "a named firm — a "
                         "recruiter's or sender's company, a supplier or a jobs site among them —", "VI11")
NO_FRAUD_CLAIM_C = patch(NO_FRAUD_CLAIM_C, "attributes to a party, in that statement, by a possessive,",
                         "attributes to a party, in the same sentence, by a possessive,", "VI7")
NO_FRAUD_CLAIM_C = vi_party(NO_FRAUD_CLAIM_C, "invite", "invite's", "such a claim")
INVITE_POINTER_C = patch(INVITE_POINTER_C, "a firm's name before 'invite' or 'job' does the same", "a firm's name "
                         "before 'invite' or 'offer' does the same", "VI11")
INVITE_POINTER_C = vi_party(INVITE_POINTER_C, "invite", "invite's", "said of a party")
INVITE_POINTER_C = patch(INVITE_POINTER_C, VI_GOVERNS[0], VI_GOVERNS[1], "VI6")
INVITE_POINTER_C = patch(INVITE_POINTER_C, "or that who sent it is unproven.", "or that who sent it, and whether a "
                         "named employer is involved, is unproven.", "VI11")


def vi_verdicts(clause, entry):
    """request_verdicts after the third review (VI): a likelihood word governs only the verdict that carries it, the
    weaker-sign reading binds through the paragraph (or entry) a verdict is in, and the pattern note."""
    clause = patch(clause, VI_GOVERNS[0], VI_GOVERNS[1], "VI6")
    where = " or entry" if entry else ""
    clause = patch(clause, "nor the paragraph" + where + " it closes names such a request",
                   "nor the paragraph" + where + " it is in names such a request", "VI4")
    clause = patch(clause, VI_PAT_ONE[0], VI_PAT_ONE[1], "VI9")
    return patch(clause, VI_COUNT[0], VI_COUNT[1], "VI1")


VC_VERDICTS_JU = vi_verdicts(VC_VERDICTS_JU, True)
VC_VERDICTS_MI = vi_verdicts(VC_VERDICTS_MI, False)
for _c in (NO_PARTY_ACCUSATION_C, NO_FRAUD_CLAIM_C, VC_VERDICTS_JU, VC_VERDICTS_MI, INVITE_POINTER_C):
    assert _c.count(VI_PAT) == 1 and VH_PATTERN not in _c and "it closes" not in _c
for _c in (NO_PARTY_ACCUSATION_C, NO_FRAUD_CLAIM_C, INVITE_POINTER_C):
    assert VI_CHANNEL[1] in _c and "claims to come from" in _c and "inside a quotation of it" in _c
    assert "'the fee they ask for'" in _c and "'they are very likely scammers'" in _c
for _c in (VC_VERDICTS_JU, VC_VERDICTS_MI, INVITE_POINTER_C):
    assert VI_GOVERNS[1] in _c
assert "a recruiter's or sender's company" in NO_FRAUD_CLAIM_C and "in that statement" not in NO_FRAUD_CLAIM_C
assert "before 'invite' or 'job'" not in INVITE_POINTER_C and "whether a named employer is involved" in INVITE_POINTER_C
assert NO_PARTY_ACCUSATION_C.endswith(NO_ACCUSATION[NO_ACCUSATION.index(" Nor is a finding"):])
assert NO_FRAUD_CLAIM_C.endswith(NO_FRAUD_CLAIM_A[NO_FRAUD_CLAIM_A.index(" Nor are a hold"):])
assert not any(x in NO_ACCUSATION for x in ("red flag", "counts the requests", "email service or jobs site", "pronoun", "claims to come",
                                             "quotation", "second verdict", "it is in"))
''')

# 3. JU 8 #5 (VI11), after the VH patch of it
rep('''    "A verdict that puts no party behind it, hedged or flat (as the expectation on parties reads that),", "VH")
''', '''    "A verdict that puts no party behind it, hedged or flat (as the expectation on parties reads that),", "VH")
# The third review (VI11, L6): the parenthetical sits next to what it modifies.
ju8["expectations"][4] = patch(
    ju8["expectations"][4], "A verdict that puts no party behind it, hedged or flat (as the expectation on parties reads "
    "that),", "A verdict that puts no party behind it (as the expectation on parties reads that), hedged or flat,", "VI")
''')

# 4. MI 10 and 11 #3 and their request_verdicts lines (VI3), after the VH tails
rep('''    x[n_rv - 1] = patch(x[n_rv - 1], VG_TAIL + "is not overreach", VH_TAIL + "is not overreach; nor is saying that the "
                        "sign alone does not show a scam", "VH")
''', '''    x[n_rv - 1] = patch(x[n_rv - 1], VG_TAIL + "is not overreach", VH_TAIL + "is not overreach; nor is saying that the "
                        "sign alone does not show a scam", "VH")
# The third review (VI3, M3): saying that the invite may be genuine declines a verdict too.
for i, n_rv in ((10, 9), (11, 6)):
    x = mi[i]["expectations"]
    x[2] = patch(x[2], "nor is saying that the sign alone does not show a scam, which declines a verdict",
                 "nor is saying that the sign alone does not show a scam, or that the invite may be genuine, which "
                 "declines a verdict", "VI")
    assert x[2].endswith("which declines a verdict") and x[n_rv - 1].endswith("the sign alone does not show a scam")
    x[n_rv - 1] = x[n_rv - 1] + ", or that the invite may be genuine"
''')

# 5. fixes and whys (VI), with records fix N4 (the VH readings each why omitted)
rep('''    fx = {8: ["K3", "VB", "VC", "VW", "VG", "VH"], 9:''', '''    fx = {8: ["K3", "VB", "VC", "VW", "VG", "VH", "VI"], 9:''')
rep('''                  + (["VW", "VG", "VH"] if i in (10, 11) else [])})''',
    '''                  + (["VW", "VG", "VH", "VI"] if i in (10, 11) else [])})''')
rep('''                     "one; the handle, account or address a message came from names the sender.",
              "fixes": ["VB", "VC", "VK3", "VK4", "VG", "VH"]})''',
    '''                     "one; the handle, account or address a message came from names the sender. After its third "
                     "review (VI): a word that counts the requests or signs leaves a pattern statement one, and 'this "
                     "is a common red flag in job scams' is one; the jobs site a posting came through is a channel; a "
                     "pronoun that attributes the thing to whoever sent it names no one, but a verdict whose subject is "
                     "the sender is a claim; naming a firm as the one the message claims to come from, or the "
                     "material's own words inside a quotation, puts no one behind a verdict.",
              "fixes": ["VB", "VC", "VK3", "VK4", "VG", "VH", "VI"]})''')
rep('''                     "such request; the two statements about requests and patterns are no verdict. Never a gate, never "
                     "core.",
              "fixes": ["VB", "VC", "VK2", "VS7", "VW", "VG", "VH"]})''',
    '''                     "such request; a certainty word leaves a pattern statement one; the two statements about requests "
                     "and patterns are no verdict. After its third review (VI): a word that counts the requests or "
                     "signs leaves a pattern statement one, and 'this is a common red flag in job scams' is one; a "
                     "likelihood word governs the verdict that carries it, not a second verdict in the same sentence; "
                     "a bare 'this' is the weaker sign's only where the paragraph or entry it is in, not only the one "
                     "it closes, names no such request. Never a gate, never core.",
              "fixes": ["VB", "VC", "VK2", "VS7", "VW", "VG", "VH", "VI"]})''')
rep('''                             "role noun; a party is put behind a verdict in the same sentence only; the two statements "
                             "about requests and patterns are no verdict.",
                      "fixes": ["VC", "VK1", "VK2", "VS7", "VW", "VG", "VH"]})''',
    '''                             "role noun; a party is put behind a verdict in the same sentence only; a certainty word "
                             "leaves a pattern statement one; the handle, account or address a message came from names "
                             "the sender; the two statements about requests and patterns are no verdict. After its "
                             "third review (VI): the party bars' readings of the jobs site, a pronoun, a firm the "
                             "invite claims to come from and the invite's quoted words, and request_verdicts' readings "
                             "of a counted pattern statement, a red flag and a second verdict in a sentence; the third "
                             "non-event covers whether a named employer is involved, and the name-before example is "
                             "'invite' or 'offer', as in the party bars.",
                      "fixes": ["VC", "VK1", "VK2", "VS7", "VW", "VG", "VH", "VI"]})''')
rep('''                         "its second review (VH): attribution is read per statement; the two statements cover a "
                         "hiring process run this way too; the handle, account or address a message came from names "
                         "the sender." if fixed
                  else "Invite-warning clause.", **({"fixes": ["C2", "K5", "VB", "VC", "VK3", "VG", "VH"]} if fixed else {})})''',
    '''                         "its second review (VH): attribution is read per statement; a certainty word leaves a "
                         "pattern statement one; the two statements cover a hiring process run this way too; the "
                         "handle, account or address a message came from names the sender. After its third review "
                         "(VI): as job-underwriter's C06a; attribution is read in the same sentence, as invite_pointer "
                         "reads it; the party list names a recruiter's or sender's company." if fixed
                  else "Invite-warning clause.", **({"fixes": ["C2", "K5", "VB", "VC", "VK3", "VG", "VH", "VI"]} if fixed else {})})''')
rep('''                     "second review (VH), as job-underwriter's C06b, without the entry rule. Never a gate, never core.",
              "fixes": ["VB", "VC", "VK2", "VK8", "VS7", "VW", "VG", "VH"]})''',
    '''                     "second and third reviews (VH, VI), as job-underwriter's C06b, without the entry rule. Never a "
                     "gate, never core.",
              "fixes": ["VB", "VC", "VK2", "VK8", "VS7", "VW", "VG", "VH", "VI"]})''')

P.write_text(src, encoding="utf-8")
print(f"patched {P}")
