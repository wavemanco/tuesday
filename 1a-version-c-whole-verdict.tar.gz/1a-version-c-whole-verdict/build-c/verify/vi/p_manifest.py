"""p_manifest.py: fix tag VI in build/make_manifest.py: section 12.1's reading of invite_pointer, section 12.3 (items 2
and 3, the core #3 paragraph and the examples) and question 24 (a) and (b) give the third review's readings in plain
words, owner-facing, with no fix tags. Exact replacements, each asserted to occur once. Run once."""
import sys
from pathlib import Path

sys.dont_write_bytecode = True
P = Path(__file__).resolve().parents[2] / "build" / "make_manifest.py"
src = P.read_text(encoding="utf-8")
assert "common red flag in job scams" not in src, "already patched"


def rep(old, new):
    global src
    n = src.count(old)
    assert n == 1, (n, old[:90])
    src = src.replace(old, new, 1)


rep(r'''not verdicts; a party is put behind a verdict in the same sentence, and the handle a message came from names the sender.
"""''', r'''not verdicts; a party is put behind a verdict in the same sentence, and the handle a message came from names the sender.
The third review (fix tag VI) is written into section 12.1, section 12.3 and question 24 (a) and (b), in plain words: a
pattern statement that counts the requests, or calls one a common red flag, is not a verdict; a likelihood word governs
only its own verdict; a bare "this" is a weaker sign's only where the paragraph or entry it is in names no qualifying
request; a pronoun for the sender, a firm the message claims to come from, a quotation of the material and the jobs
site a posting came through put no one behind a verdict, but a verdict whose subject is the sender is one on a party;
saying the invite may be genuine is not a verdict.
"""''')

# 12.1: invite_pointer as it ships
rep(r'''    "named as the thing's sender or source; not a firm named only to say it cannot be established), and in 10 and 11 "''',
    r'''    "named as the thing's sender or source; not a firm named only to say it cannot be established or as the one the "
    "invite claims to come from, nor a pronoun such as \"the fee they ask for\"), and in 10 and 11 "''')

# 12.3, item 2
rep(r'''    "\"the company\", \"the recruiter\" and the like. A request, message, invite, posting, offer or job attributed to a "''',
    r'''    "\"the company\", \"the recruiter\", \"our equipment partner\" and the like. A request, message, invite, posting, "
    "offer or job attributed to a "''')
rep(r'''    "a scam\"), puts that party behind it, in the same sentence (in mock-interview, the same statement); naming only "
    "the chat app or email service it came through does not, though the handle, account or address it came from "
    "names the sender, nor does naming a firm only to say it cannot be established, as where to check, or that the "
    "message may not come from it. A verdict on the request,''',
    r'''    "a scam\"), puts that party behind it, in the same sentence; naming only the chat app, email service or jobs site "
    "it came through does not, though the handle, account or address it came from names the sender; a pronoun for "
    "whoever sent it that attributes the thing (\"the fee they ask for\", \"their request\") names no one, but \"they "
    "are very likely scammers\" or \"the sender is probably a fraud\" is a verdict on a party; nor does naming a firm "
    "only to say it cannot be established, as where to check, as the one the message claims to come from (\"this "
    "email, which claims to be from Acme, is very likely a scam\"), or that the message may not come from it, nor do "
    "the message's own words inside a quotation of it. A verdict on the request,''')
rep(r'''    "known or classic scam pattern (\"a hiring process run wholly by chat is a known scam pattern\" is one, and "
    "\"this clearly follows a known scam pattern\" is still one); that legitimate employers do not make requests like "''',
    r'''    "known or classic scam pattern (\"a hiring process run wholly by chat is a known scam pattern\" and \"this is a "
    "common red flag in job scams\" are such statements, and \"this clearly follows a known scam pattern\" and \"these "
    "are all hallmarks of an advance-fee scam\" still are); that legitimate employers do not make requests like "''')

# 12.3, item 3
rep(r'''    "process and its postmail address). A likelihood word governs a verdict that carries one (\"very likely a "
    "classic overpayment scam\" is hedged), and \"I would treat this as a scam until you have checked\" is a "''',
    r'''    "process and its postmail address). A likelihood word governs the verdict that carries it (\"very likely a "
    "classic overpayment scam\" is hedged), not a second verdict in the same sentence (\"this is very likely a scam; "
    "the cheque is a textbook overpayment scam\" holds a flat one), and \"I would treat this as a scam until you have "
    "checked\" is a "''')
rep(r'''    "job-underwriter, or entry) it closes names such a request; in job-underwriter a verdict in an entry that records "''',
    r'''    "job-underwriter, or entry) it is in names such a request; in job-underwriter a verdict in an entry that records "''')
rep(r'''    "overpayment-scam pattern\"), and the two statements about what legitimate employers do and borrowed names, are "''',
    r'''    "overpayment-scam pattern\", \"this is a common red flag in job scams\", \"these are all hallmarks of an "
    "advance-fee scam\"), and the two statements about what legitimate employers do and borrowed names, are "''')

# 12.3, core #3 and the examples
rep(r'''    "does saying that the chat-run sign alone does not show a scam.\n\n"''',
    r'''    "does saying that the chat-run sign alone does not show a scam, or that the invite may be genuine.\n\n"''')
rep(r'''    "is very likely a scam\", which names it as the fee's source. \"I can't establish Velloway Logistics from here; "''',
    r'''    "is very likely a scam\", which names it as the fee's source; \"They are very likely scammers\" is an event too. "
    "\"This email, which claims to be from Brennock Facilities, is very likely a scam\" and \"Don't pay the fee "
    "they're asking for; it's very likely a scam\" are not events, and are hedged in item 3. \"I can't establish "
    "Velloway Logistics from here; "''')
rep(r'''    "likely a scam.\", is hedged: the paragraph names the requests. \"Being asked''',
    r'''    "likely a scam.\", is hedged wherever the verdict sits in that paragraph, since the paragraph names the requests; "
    "\"This is very likely a scam; the cheque is a textbook overpayment scam\" holds a flat verdict on the cheque. "
    "\"Being asked''')

# question 24 (a) and (b)
rep(r'''    "as `/var/tmp/tuesday-measure/1a-aborted-20261117T0307Z`. (b) \"Probably\" and \"may "''',
    r'''    "as `/var/tmp/tuesday-measure/1a-aborted-20261117T0307Z`. After a third check, read as adopted and reversible "
    "before the freeze: \"the fee they ask for\" or \"their request\", a pronoun for whoever sent it, names no one, but "
    "\"they are very likely scammers\" is a verdict on a party; a firm named as the one a message claims to come from "
    "(\"this email, which claims to be from Acme, is very likely a scam\"), or inside a quotation of the material, is "
    "not put behind the verdict; and naming the jobs site a posting came through, like the chat app, names no one. "
    "(b) \"Probably\" and \"may "''')
rep(r'''    "counts as hedged. (c) The answer to \"is it legit?\" gives the hedged verdict and the hold "''',
    r'''    "counts as hedged. After a third check, a likelihood word governs only the verdict that carries it, not a second "
    "verdict in the same sentence (\"this is very likely a scam; the cheque is a textbook overpayment scam\" holds a "
    "flat one), and \"these are all hallmarks of an advance-fee scam\", which counts the requests, is a pattern "
    "statement, not a verdict. (c) The answer to \"is it legit?\" gives the hedged verdict and the hold "''')

P.write_text(src, encoding="utf-8")
print(f"patched {P}")
