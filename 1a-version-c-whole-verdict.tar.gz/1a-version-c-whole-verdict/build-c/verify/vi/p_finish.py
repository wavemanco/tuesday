"""p_finish.py: records fix N1 and fix tag VI (with VI10) in build/finish_manifest.py: the owner summary's "How the
graders read it" says the bare "this" after a chat-only sign rests on the requests when it is in a paragraph that names
them (N1, with VI4), gives the third review's readings in plain words (the pronoun reading marked as reversible), adds
the impersonation sentence (VI10) and that saying the invite may be genuine is not a verdict. No fix tags. Exact
replacements, each asserted to occur once. Run once."""
import sys
from pathlib import Path

sys.dont_write_bytecode = True
P = Path(__file__).resolve().parents[2] / "build" / "finish_manifest.py"
src = P.read_text(encoding="utf-8")
assert "A third check" not in src, "already patched"


def rep(old, new):
    global src
    n = src.count(old)
    assert n == 1, (n, old[:90])
    src = src.replace(old, new, 1)


rep('''the second review, the graders' readings again, with the non-verdict sentence scoped to the warning-sign cases. Offline.
''', '''the second review, the graders' readings again, with the non-verdict sentence scoped to the warning-sign cases; and,
after the third review, its readings in plain words, the impersonation sentence, and the bare "this" after a chat-only
sign read as the clause reads it. Offline.
''')
rep(''' "This is very likely a scam" after a chat-only sign is read as said of the requests when the same paragraph names them; and the account or address a message came from counts as naming the sender.''',
    ''' "This is very likely a scam" right after a chat-only sign is read as resting on the requests when it is in a paragraph that names them; and the account or address a message came from counts as naming the sender. A third check, again with no change to the skills: "these are all hallmarks of a scam", said of the requests, and "this is a common red flag" are not verdicts; in "This is very likely a scam; the cheque is a textbook scam" the second verdict counts as overconfident; "this email, which claims to be from Acme", the message's own words in a quote, and the jobs site a posting came through name no one; and "the fee they're asking for" names no one either, though "they are very likely scammers" is a verdict on the sender (that reading is ours, from your "without naming a specific company or person", and can be reversed before the freeze). Saying that someone may be impersonating the firm, or that a named recruiter may not be genuine, still counts as a claim about the sender; saying that the message may not come from who it names does not.''')
rep('''that a chat-only process alone doesn't show a scam, or that a firm can't be confirmed from here is not a verdict on anyone;''',
    '''that a chat-only process alone doesn't show a scam, that the invite may be genuine, or that a firm can't be confirmed from here is not a verdict on anyone;''')

P.write_text(src, encoding="utf-8")
print(f"patched {P}")
