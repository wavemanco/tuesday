#!/bin/bash
# standin.sh (third review, VI; as verify/vh/standin.sh, as verify/vg/standin.sh for records fix D7): the run kit's stand-in freeze against the final runkit/expect-c.json, in scratch only,
# the way verify/whole-verdict/standin-*.txt were made: M and PINS in a scratch folder (l1a/scratch-M), the two
# stand-in folders there (a fresh git archive 7b56c17, and a fresh archive with patches/C-c.patch applied by
# git apply --binary), a stand-in CLI_VERSION, claude off PATH, freeze.sh --dirs; then the frozen kit's --plan for
# haiku, sonnet and opus. The outputs are kept in verify/vi/; the scratch folder is deleted after. No model, no
# network, nothing written in the repository (git archive only).
set -uo pipefail
S=/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad
B=$S/l1a/build-c; K=$S/l1a/runkit; V=$B/verify/vi; SM=$S/l1a/scratch-M
export PYTHONDONTWRITEBYTECODE=1
NEWPATH=""; IFS=: read -ra parts <<< "$PATH"
for p in "${parts[@]}"; do [ -e "$p/claude" ] || NEWPATH="${NEWPATH:+$NEWPATH:}$p"; done; export PATH="$NEWPATH"
command -v claude >/dev/null && { echo "claude on PATH"; exit 9; }
[ -e "$SM" ] && { echo "$SM exists: refusing to reuse it"; exit 9; }
mkdir -p "$SM/standin/base" "$SM/standin/cand" "$SM/pins"
git -C /home/user/tuesday archive 7b56c17 | tar -x -C "$SM/standin/base"
git -C /home/user/tuesday archive 7b56c17 | tar -x -C "$SM/standin/cand"
(cd "$SM/standin/cand" && git apply --binary "$B/patches/C-c.patch") || { echo "git apply failed"; exit 1; }
SI=(env REPO="$SM/no-repo" M="$SM/M" PINS="$SM/pins" WT_BASE="$SM/standin/base" WT_CAND="$SM/standin/cand"
    CLI_VERSION="0.0.0-standin (stand-in CLI)")
echo "expect-c.json sha256 $(sha256sum "$K/expect-c.json" | cut -c1-64); manifest.md sha256 $(sha256sum "$B/manifest.md" | cut -c1-64)"
"${SI[@]}" bash "$K/freeze.sh" --dirs "$SM/standin/base" "$SM/standin/cand" "$K/expect-c.json" > "$V/standin-freeze.out" 2>&1
fz=$?; echo "freeze.sh --dirs exit $fz"
pl=0
if [ "$fz" -eq 0 ]; then
  for m in haiku sonnet opus; do
    "${SI[@]}" bash "$SM/M/frozen/kit/run_step.sh" "$m" quality --plan > "$V/standin-plan-$m.txt" 2>&1
    rc=$?; echo "run_step.sh $m quality --plan exit $rc: $(tail -1 "$V/standin-plan-$m.txt")"; [ "$rc" -eq 0 ] || pl=1
  done
fi
grep -c "^  ok " "$V/standin-freeze.out" | sed 's/^/freeze checks ok: /'
grep -c "^  FAIL\|STOPPED" "$V/standin-freeze.out" | sed 's/^/freeze FAIL or STOPPED lines: /'
chmod -R u+w "$SM" 2>/dev/null; rm -rf "$SM"
[ -e "$SM" ] && echo "scratch folder still there" || echo "scratch folder $SM deleted"
find "$B" "$K" -name __pycache__ -type d -prune -exec rm -rf {} + 2>/dev/null
[ "$fz" -eq 0 ] && [ "$pl" -eq 0 ] && echo "stand-in freeze and the three plans pass" || { echo "STAND-IN FAILED"; exit 1; }
