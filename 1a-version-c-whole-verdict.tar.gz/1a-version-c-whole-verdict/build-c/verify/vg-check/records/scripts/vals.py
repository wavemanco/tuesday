import sys, os, json, hashlib
from pathlib import Path
sys.dont_write_bytecode = True
TREE = Path(sys.argv[1]).resolve(); E23 = Path(sys.argv[2])
sys.path[:0] = [str(TREE / "evals"), str(TREE / "ci")]
os.chdir(TREE)
import check_skills, run_fixtures as rf, fixture_clauses as fc
for m in (check_skills, rf, fc): assert Path(m.__file__).resolve().is_relative_to(TREE), m.__file__
out = {"tuesday_digests": check_skills.tuesday_digests(), "payload": rf.payload_digests(),
       "measured": dict(check_skills.MEASURED_TUESDAY)}
out["cases"] = {rel: hashlib.sha256((TREE/rel).read_bytes()).hexdigest() for rel in
   ["skills/job-underwriter/evals/evals.json","skills/mock-interview/evals/evals.json","skills/resume-tailor/evals/evals.json","evals/suite-explicit.json","evals/suite-routing.json"]}
e = {}
for skill, n in (("job-underwriter",7),("job-underwriter",8),("mock-interview",9),("mock-interview",10),("mock-interview",11),("mock-interview",12),("mock-interview",13)):
    src = TREE/"skills"/skill/"evals"/"evals.json"; data = json.loads(src.read_text(encoding="utf-8"))
    case = next(c for c in data["evals"] if c["id"] == n)
    body = (json.dumps({"skill_name": data["skill_name"], "clauses": data["clauses"], "evals": [case]}, indent=2, ensure_ascii=False) + "\n").encode()
    name = f"e23-{skill}-{n}.json"; f = E23/name
    disk = f.read_bytes()
    ext = fc.expand_spec(json.loads(disk))[0]; treat = next(c for c in fc.load_cases(src) if c["id"] == n)
    e[name] = {"regen": hashlib.sha256(body).hexdigest(), "disk": hashlib.sha256(disk).hexdigest(), "regen_eq_disk": body == disk,
               "identical": ext["expectations"] == treat["expectations"] and ext["prompt"] == treat["prompt"]}
out["e23"] = e
# independent builds digest check: files on disk under dist/claude-code vs builds()
b = check_skills.builds(); pre = "dist/claude-code/"
disk = {p.relative_to(TREE/"dist/claude-code").as_posix(): p.read_bytes() for p in (TREE/"dist/claude-code").rglob("*") if p.is_file()}
gen = {k[len(pre):]: v for k, v in b.items() if k.startswith(pre)}
out["builds_disk_equals_generated"] = disk == gen
out["builds_digest_of_disk"] = check_skills.sync.tree_digest(disk)
print(json.dumps(out, indent=1, sort_keys=True))
