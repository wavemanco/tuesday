import os, sys, re, zipfile, io, zlib, base64
from pathlib import Path
sys.dont_write_bytecode = True
email = os.environ.get("SCAN_EMAIL", "")
assert "@" in email, "no email"
local = email.split("@")[0]
E = email.lower().encode(); L = local.lower().encode()
LW = re.compile(rb"(?<![A-Za-z0-9._%+-])" + re.escape(L) + rb"(?![A-Za-z0-9_%+-])", re.I)
KEYS = {"sk-ant-": re.compile(rb"sk-ant-"), "ghp_": re.compile(rb"ghp_[A-Za-z0-9]{10,}"), "ghp_any": re.compile(rb"ghp_"),
        "github_pat_": re.compile(rb"github_pat_"), "AKIA": re.compile(rb"AKIA[0-9A-Z]{16}"), "AKIA_any": re.compile(rb"AKIA"),
        "-----BEGIN": re.compile(rb"-----BEGIN")}
HOME = re.compile(rb"/home/(?!user(?![A-Za-z0-9._-]))[A-Za-z0-9._-]+")
OTHER = {"/Users/": re.compile(rb"/Users/"), "C:\\Users": re.compile(rb"C:\\\\?Users", re.I)}
def git85(lines):
    alphabet = b"0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz!#$%&()*+-;<=>?@^_`{|}~"
    dec = {c: i for i, c in enumerate(alphabet)}
    out = bytearray()
    for ln in lines:
        c = ln[0]; n = c - 64 if c <= 90 else c - 96 + 26
        data = ln[1:]; buf = bytearray()
        for i in range(0, len(data), 5):
            acc = 0
            for ch in data[i:i+5]: acc = acc * 85 + dec[ch]
            buf += acc.to_bytes(4, "big")
        out += buf[:n]
    return bytes(out)
def texts_of(path: Path):
    data = path.read_bytes()
    yield str(path), data
    if data[:4] == b"PK\x03\x04":
        try:
            z = zipfile.ZipFile(io.BytesIO(data))
            for i in z.infolist():
                yield f"{path}!{i.filename}", z.read(i)
        except zipfile.BadZipFile:
            pass
    if path.suffix == ".patch":
        lines = data.split(b"\n"); i = 0
        while i < len(lines):
            if lines[i] in (b"GIT binary patch",) or lines[i].startswith(b"literal ") or lines[i].startswith(b"delta "):
                if lines[i].startswith((b"literal ", b"delta ")):
                    j = i + 1; chunk = []
                    while j < len(lines) and lines[j]:
                        chunk.append(lines[j]); j += 1
                    try:
                        yield f"{path}#hunk{i}", zlib.decompress(git85(chunk))
                    except Exception as e:
                        yield f"{path}#hunk{i}-undecoded", b""
                    i = j
            i += 1
def scan(label, roots):
    tot = {"texts": 0, "email": 0, "email_files": 0, "local_sub": 0, "local_word": 0, "home_other": 0}
    for k in KEYS: tot[k] = 0
    for k in OTHER: tot[k] = 0
    hunks = 0
    for root in roots:
        root = Path(root)
        files = [root] if root.is_file() else sorted(p for p in root.rglob("*") if p.is_file())
        for f in files:
            for name, data in texts_of(f):
                if "#hunk" in name: hunks += 1
                tot["texts"] += 1
                low = data.lower()
                c = low.count(E); tot["email"] += c; tot["email_files"] += bool(c)
                tot["local_sub"] += low.count(L); tot["local_word"] += len(LW.findall(data))
                for k, rx in KEYS.items(): tot[k] += len(rx.findall(data))
                h = HOME.findall(data); tot["home_other"] += len(h)
                for k, rx in OTHER.items(): tot[k] += len(rx.findall(data))
    extra = f", decoded binary hunks {hunks}" if hunks else ""
    print(f"{label}: " + ", ".join(f"{k} {v}" for k, v in tot.items()) + extra)
# positive control, in memory only
ctl = b"x " + email.encode() + b" y sk-ant-abc ghp_abcdefghijklmn /home/other/x -----BEGIN"
assert ctl.lower().count(E) == 1 and LW.findall(ctl) and HOME.findall(ctl) and KEYS["sk-ant-"].findall(ctl)
print("positive control ok")
groups = [a.split("=", 1) for a in sys.argv[1:]]
for label, paths in groups:
    scan(label, paths.split(","))
