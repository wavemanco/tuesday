import sys, difflib, re
a=open(sys.argv[1],encoding='utf-8').read().split('\n'); b=open(sys.argv[2],encoding='utf-8').read().split('\n')
maxw=int(sys.argv[3]) if len(sys.argv)>3 else 400
sm=difflib.SequenceMatcher(None,a,b,autojunk=False)
for op,i1,i2,j1,j2 in sm.get_opcodes():
    if op=='equal': continue
    print(f'=== {op} old {i1+1}-{i2} new {j1+1}-{j2}')
    if op=='replace' and (i2-i1)==(j2-j1):
        for x,y,ln in zip(a[i1:i2],b[j1:j2],range(j1+1,j2+1)):
            ta=re.findall(r'\S+|\s+',x); tb=re.findall(r'\S+|\s+',y)
            s=difflib.SequenceMatcher(None,ta,tb,autojunk=False)
            out=[]
            for o,p1,p2,q1,q2 in s.get_opcodes():
                if o=='equal':
                    seg=''.join(ta[p1:p2])
                    out.append(seg if len(seg)<80 else seg[:35]+' … '+seg[-35:])
                else:
                    out.append('[-'+''.join(ta[p1:p2])+'-]' if p2>p1 else '')
                    out.append('{+'+''.join(tb[q1:q2])+'+}' if q2>q1 else '')
            t=''.join(out)
            print(f' L{ln}: '+(t if len(t)<maxw*4 else t[:maxw*4]+' …[cut]'))
    else:
        for x in a[i1:i2]: print(' - '+(x if len(x)<maxw else x[:maxw]+' …'))
        for y in b[j1:j2]: print(' + '+(y if len(y)<maxw else y[:maxw]+' …'))
