import json, sys, difflib, re
B = sys.argv[1]
for skill, before, names in (("job-underwriter", "ju-evals.json", ["no_party_accusation","request_verdicts"]), ("mock-interview", "mi-evals.json", ["invite_pointer","no_fraud_claim","request_verdicts"])):
    new = json.load(open(f"{B}/tree/skills/{skill}/evals/evals.json"))["clauses"]
    old = json.load(open(f"{B}/verify/vg/before/{before}"))["clauses"]
    for n in names:
        a = re.findall(r"\S+|\s+", old[n]); b = re.findall(r"\S+|\s+", new[n])
        sm = difflib.SequenceMatcher(None, a, b, autojunk=False)
        print(f"===== {skill} {n}")
        for op, i1, i2, j1, j2 in sm.get_opcodes():
            if op != "equal":
                print(f"  {op}: -[{''.join(a[i1:i2])}] +[{''.join(b[j1:j2])}]")
