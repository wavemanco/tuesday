import json, sys, difflib
B = sys.argv[1]
for skill, before in (("job-underwriter", "ju-evals.json"), ("mock-interview", "mi-evals.json")):
    new = json.load(open(f"{B}/tree/skills/{skill}/evals/evals.json"))
    old = json.load(open(f"{B}/verify/vg/before/{before}"))
    for k in sorted(set(new["clauses"]) | set(old["clauses"])):
        a, b = old["clauses"].get(k), new["clauses"].get(k)
        if a != b:
            print(f"## {skill} clause {k} CHANGED")
    for co, cn in zip(old["evals"], new["evals"]):
        for key in set(co) | set(cn):
            if key == "expectations":
                for i, (x, y) in enumerate(zip(co[key], cn[key]), 1):
                    if x != y:
                        print(f"## {skill} eval {cn['id']} #{i} CHANGED")
                        print("  OLD:", x)
                        print("  NEW:", y)
                if len(co[key]) != len(cn[key]): print("LEN DIFF", skill, cn['id'])
            elif co.get(key) != cn.get(key):
                print(f"## {skill} eval {cn['id']} field {key} CHANGED")
    print("cases", len(old["evals"]), len(new["evals"]))
