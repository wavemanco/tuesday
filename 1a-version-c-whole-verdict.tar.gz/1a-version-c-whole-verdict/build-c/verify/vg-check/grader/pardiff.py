import json, sys, difflib, re
B = sys.argv[1]
ju = json.load(open(f"{B}/tree/skills/job-underwriter/evals/evals.json"))["clauses"]
mi = json.load(open(f"{B}/tree/skills/mock-interview/evals/evals.json"))["clauses"]
def wd(a, b, title):
    a = re.findall(r"\S+|\s+", a); b = re.findall(r"\S+|\s+", b)
    print("=====", title)
    for op, i1, i2, j1, j2 in difflib.SequenceMatcher(None, a, b, autojunk=False).get_opcodes():
        if op != "equal":
            print(f"  {op}: JU[{''.join(a[i1:i2])}] MI[{''.join(b[j1:j2])}]")
wd(ju["request_verdicts"], mi["request_verdicts"], "request_verdicts JU vs MI")
wd(ju["no_party_accusation"], mi["no_fraud_claim"], "no_party_accusation vs no_fraud_claim")
