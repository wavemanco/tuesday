import sys, json
B = sys.argv[1]
sys.path.insert(0, B + "/tree/evals")
import fixture_clauses as fc
from pathlib import Path
out = sys.argv[2]
for skill in ("job-underwriter", "mock-interview"):
    cases = fc.load_cases(Path(B) / "tree/skills" / skill / "evals/evals.json")
    with open(f"{out}/{skill}.expanded.txt", "w") as f:
        for c in cases:
            f.write(f"===== EVAL {c.get('id')} =====\n")
            for k, v in c.items():
                if k in ("expectations",):
                    continue
                f.write(f"--- {k}:\n{json.dumps(v, indent=1, ensure_ascii=False) if not isinstance(v, str) else v}\n")
            for i, e in enumerate(c.get("expectations", []), 1):
                f.write(f"[#{i}] {json.dumps(e, ensure_ascii=False) if not isinstance(e,str) else e}\n\n")
    spec = json.loads((Path(B) / "tree/skills" / skill / "evals/evals.json").read_text())
    with open(f"{out}/{skill}.clauses.txt", "w") as f:
        for k, v in spec.get("clauses", {}).items():
            f.write(f"### {k}\n{v}\n\n")
