export PATH=$(echo "$PATH" | tr ':' '\n' | grep -v '^/opt/node22/bin$' | paste -sd:)
export PYTHONDONTWRITEBYTECODE=1
export B=/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/l1a/build-c
export K=/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/l1a/runkit
export V=$B/verify/vi-check/records
export R=/home/user/tuesday
