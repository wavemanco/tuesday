import json, sys, re
B = sys.argv[1]; qf = sys.argv[2]
ju = json.load(open(f"{B}/tree/skills/job-underwriter/evals/evals.json", encoding="utf-8"))
mi = json.load(open(f"{B}/tree/skills/mock-interview/evals/evals.json", encoding="utf-8"))
jub = json.load(open(f"{B}/verify/vi/before/ju-evals.json", encoding="utf-8"))
mib = json.load(open(f"{B}/verify/vi/before/mi-evals.json", encoding="utf-8"))
def ev(d, i): return next(e for e in d["evals"] if e["id"] == i)
src = {
 "JU no_party_accusation": (ju["clauses"]["no_party_accusation"], jub["clauses"]["no_party_accusation"]),
 "JU request_verdicts": (ju["clauses"]["request_verdicts"], jub["clauses"]["request_verdicts"]),
 "MI request_verdicts": (mi["clauses"]["request_verdicts"], mib["clauses"]["request_verdicts"]),
 "MI invite_pointer": (mi["clauses"]["invite_pointer"], mib["clauses"]["invite_pointer"]),
 "MI no_fraud_claim": (mi["clauses"]["no_fraud_claim"], mib["clauses"]["no_fraud_claim"]),
 "JU 8 #5": (ev(ju,8)["expectations"][4], ev(jub,8)["expectations"][4]),
 "MI 10 #3": (ev(mi,10)["expectations"][2], ev(mib,10)["expectations"][2]),
 "MI 10 #9": (ev(mi,10)["expectations"][8], ev(mib,10)["expectations"][8]),
 "MI 11 #3": (ev(mi,11)["expectations"][2], ev(mib,11)["expectations"][2]),
 "MI 11 #6": (ev(mi,11)["expectations"][5], ev(mib,11)["expectations"][5]),
}
q = {}
for blk in open(qf, encoding="utf-8").read().split("@@ ")[1:]:
    name, _, body = blk.partition("\n"); q[name.strip()] = body.rstrip("\n")
wc = lambda s: len(s.split())
for k, (now, before) in src.items():
    eq = q.get(k) == now
    print(f"{k}: quote==shipped {eq} chars {len(now)} words before {wc(before)} -> now {wc(now)} (+{wc(now)-wc(before)})")
    if not eq:
        a = q.get(k, ""); i = next((j for j in range(min(len(a), len(now))) if a[j] != now[j]), min(len(a), len(now)))
        print("   first diff at", i, repr(a[i-40:i+60]), "|", repr(now[i-40:i+60]))
# no_accusation
print("JU no_accusation equal:", ju["clauses"]["no_accusation"] == jub["clauses"]["no_accusation"])
