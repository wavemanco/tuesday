import json, sys, difflib, re
def wd(a, b):
    ta = re.findall(r"\S+|\s+", a); tb = re.findall(r"\S+|\s+", b)
    s = difflib.SequenceMatcher(None, ta, tb, autojunk=False); out = []
    for o, p1, p2, q1, q2 in s.get_opcodes():
        if o == "equal":
            seg = "".join(ta[p1:p2]); out.append(seg if len(seg) < 60 else seg[:25] + " … " + seg[-25:])
        else:
            if p2 > p1: out.append("[-" + "".join(ta[p1:p2]) + "-]")
            if q2 > q1: out.append("{+" + "".join(tb[q1:q2]) + "+}")
    return "".join(out)
if sys.argv[1] == "pair":
    B = sys.argv[2]
    ju = json.load(open(f"{B}/tree/skills/job-underwriter/evals/evals.json")); mi = json.load(open(f"{B}/tree/skills/mock-interview/evals/evals.json"))
    print("JU rv -> MI rv:"); print(wd(ju["clauses"]["request_verdicts"], mi["clauses"]["request_verdicts"]))
    old = json.load(open(f"{B}/verify/vi/before/ju-evals.json")); oldm = json.load(open(f"{B}/verify/vi/before/mi-evals.json"))
    print("BEFORE JU rv -> MI rv:"); print(wd(old["clauses"]["request_verdicts"], oldm["clauses"]["request_verdicts"]))
    print("JU npa -> MI nfc:"); print(wd(ju["clauses"]["no_party_accusation"], mi["clauses"]["no_fraud_claim"]))
    sys.exit()
for old, new in [(sys.argv[1], sys.argv[2]), (sys.argv[3], sys.argv[4])]:
    A = json.load(open(old)); N = json.load(open(new))
    for k in N["clauses"]:
        if A["clauses"][k] != N["clauses"][k]: print(f"== clause {k}"); print(wd(A["clauses"][k], N["clauses"][k])); print()
    ae = {e["id"]: e for e in A["evals"]}
    for e in N["evals"]:
        for i, (x, y) in enumerate(zip(ae[e["id"]]["expectations"], e["expectations"])):
            if x != y: print(f"== eval {e['id']} #{i+1}"); print(wd(x, y)); print()
