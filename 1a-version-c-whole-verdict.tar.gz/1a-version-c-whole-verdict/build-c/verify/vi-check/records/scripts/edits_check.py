import json, sys
B = sys.argv[1]
new = json.load(open(f"{B}/edits.json")); old = json.load(open(f"{B}/verify/vi/before/edits.json"))
print("top keys same:", list(new) == list(old), "base same:", new["base"] == old["base"], "format same:", new["format"] == old["format"], "dropped same:", new["dropped_slice_edits"] == old["dropped_slice_edits"])
for pn, po in zip(new["phases"], old["phases"]):
    print("phase", pn["phase"], "meta same:", {k: v for k, v in pn.items() if k != "edits"} == {k: v for k, v in po.items() if k != "edits"}, "n", len(pn["edits"]), len(po["edits"]))
    eo = {e["id"]: e for e in po["edits"]}
    for e in pn["edits"]:
        o = eo.get(e["id"])
        if o is None: print("  NEW", e["id"]); continue
        if o != e:
            ks = [k for k in sorted(set(e) | set(o)) if e.get(k) != o.get(k)]
            print("  CHANGED", e["id"], e.get("file"), ks, "fixes:", e.get("fixes"))
    print("  ids same order:", [e["id"] for e in pn["edits"]] == [e["id"] for e in po["edits"]])
# VH tag holders
vh = [e["id"] for p in new["phases"] for e in p["edits"] if any("VI" in str(f) for f in (e.get("fixes") or []))]
print("edits tagged VI:", vh)
# shipped text check: each C edit's new must appear in the tree file (or evals case equal)
