import json, os, re, sys
B = os.environ['B']; V = os.environ['V']
spec = open(f"{B}/spec.md", encoding="utf-8").read().split("\n")
def texts(ju, mi):
    out = []
    for p in (ju, mi):
        d = json.load(open(p, encoding="utf-8"))
        out += list(d["clauses"].values()) + [x for e in d["evals"] for x in e["expectations"]]
    return out
sets = {
 "VG": texts(f"{B}/verify/vh/before/tree/skills/job-underwriter/evals/evals.json", f"{B}/verify/vh/before/tree/skills/mock-interview/evals/evals.json"),
 "VH": texts(f"{B}/verify/vi/before/ju-evals.json", f"{B}/verify/vi/before/mi-evals.json"),
 "VI": texts(f"{B}/tree/skills/job-underwriter/evals/evals.json", f"{B}/tree/skills/mock-interview/evals/evals.json"),
}
def section(title):
    i = next(n for n, l in enumerate(spec) if l.startswith("### ") and title in l)
    j = next(n for n in range(i+1, len(spec)) if spec[n].startswith("### ") or spec[n].startswith("## "))
    return "\n".join(spec[i:j])
secs = {"VG": section("(VG)"), "VH": section("The second review (VH)"), "VI": section("The third review (VI)")}
for tag, s in secs.items():
    # only bullets G1..G7 / VH1..VH7 / VI1..VI11
    found = nf = 0; miss = []
    for q in re.findall(r'"([^"]{25,})"', s):
        core = q.strip()
        core = re.sub(r'^(…[,;]?\s*)', '', core); core = re.sub(r'(\s*…)$', '', core)
        core = core.rstrip(".") if not any(core in t for t in sets[tag]) else core
        parts = [p.strip(" ,;") for p in core.split("…") if len(p.strip(" ,;")) > 10]
        if parts and all(any(p in t for t in sets[tag]) for p in parts): found += 1
        else: miss.append(q)
    print(f"== {tag}: quotes found in that review's own output {found}; not found {len(miss)}")
    for q in miss:
        other = [k for k in sets if k != tag and any(q.strip('… .,;') in t for t in sets[k])]
        print("   NOT FOUND:", q[:150], "| found in:", other)
