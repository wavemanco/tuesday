import sys, json, hashlib, subprocess
from pathlib import Path
sys.dont_write_bytecode = True
B = Path(sys.argv[1]); K = Path(sys.argv[2]); V = Path(sys.argv[3])
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
def exps(tree):
    out = subprocess.run([sys.executable, "-I", "-B", "-c", f"""
import sys, json, hashlib; sys.dont_write_bytecode=True; sys.path.insert(0, {str(Path(tree)/'evals')!r}); import fixture_clauses as fc
from pathlib import Path
r = {{}}
for s in ('job-underwriter','mock-interview'):
    p = Path({str(tree)!r})/'skills'/s/'evals'/'evals.json'
    d = json.loads(p.read_text(encoding='utf-8'))
    for k, v in d['clauses'].items(): r[f'clause {{s}} {{k}}'] = hashlib.sha256(v.encode()).hexdigest()
    for c in fc.load_cases(p):
        for i, e in enumerate(c['expectations'], 1): r[f'exp {{s}} {{c["id"]}} #{{i}}'] = hashlib.sha256(e.encode()).hexdigest()
print(json.dumps(r))
"""], capture_output=True, text=True, check=True).stdout
    return json.loads(out)
cur = {}
cur.update({f"case {s}": sha(B/"tree/skills"/s/"evals/evals.json") for s in ("job-underwriter", "mock-interview")})
cur.update({f"e23 {p.name}": sha(p) for p in sorted((B/"e23").iterdir())})
cur.update({"patch": sha(B/"patches/C-c.patch"), "expect": sha(K/"expect-c.json"), "doc spec.md": sha(B/"spec.md"), "doc manifest.md": sha(B/"manifest.md"),
            "doc owner-summary.md": sha(B/"owner-summary.md"), "doc edits.json": sha(B/"edits.json"), "kit README": sha(K/"README.md"), "commit-msg": sha(B/"commit-msg.txt"), "revert-msg": sha(B/"revert-msg.txt")})
cur.update(exps(B/"tree"))
curset = set(cur.values())
old = {}
for tag, d in (("vh", B/"verify/vh/before"), ("vg", B/"verify/vg/before")):
    o = {f"case {s}": sha(d/"tree/skills"/s/"evals/evals.json") for s in ("job-underwriter", "mock-interview")}
    o.update({f"e23 {p.name}": sha(p) for p in sorted((d/"e23").iterdir())})
    o.update({"patch": sha(d/"patches/C-c.patch"), "expect": sha(d/"kit/expect-c.json"), "doc spec.md": sha(d/"spec.md"), "doc manifest.md": sha(d/"manifest.md"),
              "doc owner-summary.md": sha(d/"owner-summary.md"), "doc edits.json": sha(d/"edits.json"), "kit README": sha(d/"kit/README.md"), "commit-msg": sha(d/"commit-msg.txt")})
    if (d/"revert-msg.txt").exists(): o["revert-msg"] = sha(d/"revert-msg.txt")
    if (d/"expect-c.after.json").exists(): o["expect.after"] = sha(d/"expect-c.after.json")
    o.update(exps(d/"tree"))
    for k, v in o.items():
        if v not in curset: old[f"{tag} {k}"] = v
json.dump({"current": cur, "old": old}, open(V/"old-values.json", "w"), indent=1)
targets = [B/"spec.md", B/"manifest.md", B/"owner-summary.md", B/"edits.json", K/"README.md", K/"expect-c.json", B/"commit-msg.txt", B/"revert-msg.txt"]
texts = {t: t.read_text(encoding="utf-8") for t in targets}
print("old values (superseded, not equal to any current value):", len(old))
hits = 0
for k, v in old.items():
    for t, s in texts.items():
        for L in (8,):
            if v[:L] in s: hits += 1; print("HIT", k, v[:12], "in", t.name)
print("hits in targets:", hits)
# positive control: before copies hold them
ctl = 0
for k, v in old.items():
    tag = k.split()[0]; d = B/"verify"/tag/"before"
    if any(v[:8] in (d/f).read_text(encoding="utf-8") for f in ("spec.md", "manifest.md", "kit/expect-c.json") if (d/f).exists()): ctl += 1
print("positive control: old values found in their own before copies (spec, manifest, expect):", ctl, "of", len(old))
