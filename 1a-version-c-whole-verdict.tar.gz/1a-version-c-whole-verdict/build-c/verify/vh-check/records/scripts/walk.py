import json, sys
def walk(a, b, path=""):
    out = []
    if type(a) != type(b):
        return [(path, "type")]
    if isinstance(a, dict):
        for k in sorted(set(a) | set(b)):
            if k not in a or k not in b: out.append((f"{path}/{k}", "missing-one-side")); continue
            out += walk(a[k], b[k], f"{path}/{k}")
    elif isinstance(a, list):
        if len(a) != len(b): out.append((path, f"len {len(a)} vs {len(b)}"))
        for i, (x, y) in enumerate(zip(a, b)):
            out += walk(x, y, f"{path}[{i}]")
    else:
        if a != b: out.append((path, "value"))
    return out
for name, old, new in [("JU", sys.argv[1], sys.argv[2]), ("MI", sys.argv[3], sys.argv[4])]:
    A = json.load(open(old, encoding="utf-8")); Bn = json.load(open(new, encoding="utf-8"))
    # map evals list index to id
    d = walk(A, Bn)
    print(name, len(d), "differences")
    for p, kind in d:
        lab = p
        if p.startswith("/evals["):
            i = int(p[7:p.index("]")]); lab = f"{p}  (eval id {A['evals'][i]['id']})"
        print("  ", lab, kind)
    print("  clause keys same:", list(A["clauses"]) == list(Bn["clauses"]), "eval ids same:", [e["id"] for e in A["evals"]] == [e["id"] for e in Bn["evals"]])
    print("  no_accusation identical:", A["clauses"].get("no_accusation") == Bn["clauses"].get("no_accusation"), "present:", "no_accusation" in Bn["clauses"])
