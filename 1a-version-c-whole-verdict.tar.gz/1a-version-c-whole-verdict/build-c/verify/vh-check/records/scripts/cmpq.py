import json, sys
B, Q = sys.argv[1], sys.argv[2]
ju = json.load(open(f"{B}/tree/skills/job-underwriter/evals/evals.json")); mi = json.load(open(f"{B}/tree/skills/mock-interview/evals/evals.json"))
je = {e["id"]: e for e in ju["evals"]}; me = {e["id"]: e for e in mi["evals"]}
q = lambda n: open(f"{Q}/{n}", encoding="utf-8").read().rstrip("\n")
for name, shipped in [("ju_npa.txt", ju["clauses"]["no_party_accusation"]), ("ju_rv.txt", ju["clauses"]["request_verdicts"]),
                      ("mi_rv.txt", mi["clauses"]["request_verdicts"]), ("mi_ip.txt", mi["clauses"]["invite_pointer"]),
                      ("mi_nfc.txt", mi["clauses"]["no_fraud_claim"]), ("ju8_5.txt", je[8]["expectations"][4]),
                      ("mi10_3.txt", me[10]["expectations"][2]), ("mi10_9.txt", me[10]["expectations"][8])]:
    t = q(name); print(name, "equal" if t == shipped else "DIFFERS", len(shipped))
    if t != shipped:
        import difflib
        for i,(a,b) in enumerate(zip(t, shipped)):
            if a!=b: print("   first diff at", i, repr(t[i-30:i+30]), repr(shipped[i-30:i+30])); break
p3 = open(f"{Q}/mi11_3.prefix").read(); p6 = open(f"{Q}/mi11_6.prefix").read()
s3 = me[11]["expectations"][2]; s6 = me[11]["expectations"][5]
t10_3 = me[10]["expectations"][2]; t10_9 = me[10]["expectations"][8]
tail3 = t10_3[t10_3.index("the statements above"):]; tail9 = t10_9[t10_9.index("the statements above"):]
print("mi11_3 = prefix + MI10#3 tail:", s3 == p3 + tail3, "ends 'which declines a verdict':", s3.endswith("which declines a verdict"))
print("mi11_6 = prefix + MI10#9 tail:", s6 == p6 + tail9, "ends 'nor is saying that the sign alone does not show a scam':", s6.endswith("nor is saying that the sign alone does not show a scam"))
