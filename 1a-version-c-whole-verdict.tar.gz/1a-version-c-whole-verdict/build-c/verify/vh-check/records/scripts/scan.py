import os, sys, re, zipfile, io, zlib
from pathlib import Path
sys.dont_write_bytecode = True
email = os.environ.get("SCAN_EMAIL", "")
assert "@" in email and not any(c.isspace() for c in email), "no email"
local = email.split("@")[0]
E = email.lower().encode(); L = local.lower().encode()
EF = [E, E.replace(b"@", b"%40"), E.replace(b"@", b" at ")]
LW = re.compile(rb"(?<![A-Za-z0-9._%+-])" + re.escape(L) + rb"(?![A-Za-z0-9_%+-])", re.I)
KEYS = {"sk-ant-": re.compile(rb"sk-ant-"), "ghp_": re.compile(rb"ghp_"), "github_pat_": re.compile(rb"github_pat_"),
        "AKIA+16": re.compile(rb"AKIA[0-9A-Z]{16}"), "-----BEGIN": re.compile(rb"-----BEGIN")}
HOME = re.compile(rb"/home/(?!user(?![A-Za-z0-9._-]))[A-Za-z0-9._-]+")
OTHER = re.compile(rb"/Users/[A-Za-z0-9._-]+|[A-Za-z]:\\\\?Users\\\\?", re.I)
ROOT = re.compile(rb"/root(?:/|\b)")
def git85(lines):
    alphabet = b"0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz!#$%&()*+-;<=>?@^_`{|}~"
    dec = {c: i for i, c in enumerate(alphabet)}; out = bytearray()
    for ln in lines:
        c = ln[0]; n = c - 64 if c <= 90 else c - 96 + 26; data = ln[1:]; buf = bytearray()
        for i in range(0, len(data), 5):
            acc = 0
            for ch in data[i:i+5]: acc = acc * 85 + dec[ch]
            buf += acc.to_bytes(4, "big")
        out += buf[:n]
    return bytes(out)
def texts_of(path):
    data = path.read_bytes(); yield str(path), data
    if data[:4] == b"PK\x03\x04":
        try:
            z = zipfile.ZipFile(io.BytesIO(data))
            for i in z.infolist():
                if not i.is_dir(): yield f"{path}!{i.filename}", z.read(i)
        except zipfile.BadZipFile: pass
    if path.suffix == ".patch":
        lines = data.split(b"\n"); i = 0
        while i < len(lines):
            if lines[i].startswith((b"literal ", b"delta ")):
                j = i + 1; chunk = []
                while j < len(lines) and lines[j]: chunk.append(lines[j]); j += 1
                try: yield f"{path}#hunk{i}", zlib.decompress(git85(chunk))
                except Exception: yield f"{path}#hunk{i}-UNDECODED", b""
                i = j
            i += 1
def scan(label, roots):
    tot = dict(files=0, texts=0, members=0, hunks=0, email=0, email_files=0, local_sub=0, local_word=0, home_other=0, users_win=0, root_paths=0, undecoded=0)
    for k in KEYS: tot[k] = 0
    for root in roots:
        root = Path(root); files = [root] if root.is_file() else sorted(p for p in root.rglob("*") if p.is_file())
        for f in files:
            tot["files"] += 1
            for name, data in texts_of(f):
                tot["texts"] += 1
                if "!" in name: tot["members"] += 1
                if "#hunk" in name: tot["hunks"] += 1
                if "UNDECODED" in name: tot["undecoded"] += 1
                low = data.lower(); c = sum(low.count(x) for x in EF)
                tot["email"] += c; tot["email_files"] += bool(c)
                tot["local_sub"] += low.count(L); tot["local_word"] += len(LW.findall(data))
                for k, rx in KEYS.items(): tot[k] += len(rx.findall(data))
                tot["home_other"] += len(HOME.findall(data)); tot["users_win"] += len(OTHER.findall(data)); tot["root_paths"] += len(ROOT.findall(data))
    print(f"{label}: " + ", ".join(f"{k} {v}" for k, v in tot.items()))
ctl = b"x " + email.encode() + b" y " + local.encode() + b" sk-ant-abc ghp_abc github_pat_x AKIAABCDEFGHIJKLMNOP /home/other/x /Users/bob C:\\Users\\bob -----BEGIN /root/x"
assert sum(ctl.lower().count(x) for x in EF) == 1 and LW.findall(ctl) and HOME.findall(ctl) and OTHER.findall(ctl) and all(rx.findall(ctl) for rx in KEYS.values())
assert not HOME.findall(b"/home/user/tuesday /home/user") and not ROOT.findall(b"/rootless")
print("positive and negative controls ok (in memory)")
for a in sys.argv[1:]:
    label, paths = a.split("=", 1); scan(label, paths.split(","))
