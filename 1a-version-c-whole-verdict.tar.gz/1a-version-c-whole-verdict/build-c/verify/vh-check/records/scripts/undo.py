import json, sys
def strs(o, path=""):
    if isinstance(o, dict):
        for k, v in o.items(): yield from strs(v, f"{path}/{k}")
    elif isinstance(o, list):
        for i, v in enumerate(o): yield from strs(v, f"{path}[{i}]")
    elif isinstance(o, str): yield path, o
for old, new in [(sys.argv[1], sys.argv[2]), (sys.argv[3], sys.argv[4])]:
    ob = open(old, "rb").read(); nb = open(new, "rb").read()
    A = dict(strs(json.loads(ob))); N = dict(strs(json.loads(nb)))
    raw = nb.decode("utf-8"); n = 0
    for p in N:
        if A.get(p) != N[p]:
            for ea in (False, True):
                enc_new = json.dumps(N[p], ensure_ascii=ea); enc_old = json.dumps(A[p], ensure_ascii=ea)
                if raw.count(enc_new) == 1: break
            else:
                print("not uniquely found", p); continue
            raw = raw.replace(enc_new, enc_old); n += 1
    print(new.split("/skills/")[1], "undone", n, "byte-equal to before:", raw.encode("utf-8") == ob)
