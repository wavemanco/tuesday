import sys, json
B = sys.argv[1]
sys.path.insert(0, B + "/tree/evals")
sys.dont_write_bytecode = True
import fixture_clauses as fc
from pathlib import Path
out = Path(sys.argv[2])
for skill in ("job-underwriter", "mock-interview"):
    p = Path(B) / "tree/skills" / skill / "evals/evals.json"
    cases = fc.load_cases(p)
    spec = json.loads(p.read_text())
    with open(out / f"{skill}.expanded.txt", "w") as f:
        for c in cases:
            f.write(f"===== case {c.get('id')} =====\n")
            f.write("PROMPT: " + str(c.get("prompt"))[:6000] + "\n")
            for k in c:
                if k not in ("prompt", "expectations"):
                    f.write(f"{k}: {json.dumps(c[k], ensure_ascii=False)[:3000]}\n")
            for n, e in enumerate(c.get("expectations") or [], 1):
                f.write(f"  #{n}: {e}\n\n")
    with open(out / f"{skill}.clauses.txt", "w") as f:
        for k, v in (spec.get("clauses") or {}).items():
            f.write(f"--- {k} ---\n{v}\n\n")
