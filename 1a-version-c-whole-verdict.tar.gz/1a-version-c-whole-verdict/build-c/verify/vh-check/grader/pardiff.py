import sys, json, difflib, re
sys.dont_write_bytecode = True
B = sys.argv[1]
ju = json.load(open(f"{B}/tree/skills/job-underwriter/evals/evals.json"))["clauses"]
mi = json.load(open(f"{B}/tree/skills/mock-interview/evals/evals.json"))["clauses"]
def wd(a, b):
    aw, bw = re.findall(r"\S+|\s+", a), re.findall(r"\S+|\s+", b)
    out = []
    for op, i1, i2, j1, j2 in difflib.SequenceMatcher(None, aw, bw, autojunk=False).get_opcodes():
        if op == "equal":
            seg = "".join(aw[i1:i2]); out.append(seg if len(seg) < 60 else seg[:25] + " ... " + seg[-25:])
        else:
            if i2 > i1: out.append("[-" + "".join(aw[i1:i2]) + "-]")
            if j2 > j1: out.append("{+" + "".join(bw[j1:j2]) + "+}")
    return "".join(out)
print("== request_verdicts JU -> MI\n" + wd(ju["request_verdicts"], mi["request_verdicts"]))
print("\n== no_party_accusation (JU) -> no_fraud_claim (MI)\n" + wd(ju["no_party_accusation"], mi["no_fraud_claim"]))
print("\nJU clause names:", sorted(ju)); print("MI clause names:", sorted(mi))
