#!/bin/bash
# rechain.sh: rerun version C's documented regeneration order after a generator edit, offline, claude off PATH.
# Every Python step runs as python3 -I -B (records observation O2, second review): -I alone ignores
# PYTHONDONTWRITEBYTECODE, so -B keeps bytecode off whatever a script sets itself.
set -uo pipefail
B=$(cd "$(dirname "$0")/.." && pwd); K=$(cd "$B/../runkit" && pwd); R=$(cd "$B/../.." && pwd)
export PYTHONDONTWRITEBYTECODE=1
NEWPATH=""; IFS=: read -ra parts <<< "$PATH"
for p in "${parts[@]}"; do [ -e "$p/claude" ] || NEWPATH="${NEWPATH:+$NEWPATH:}$p"; done; export PATH="$NEWPATH"
command -v claude >/dev/null && { echo "claude on PATH"; exit 9; }
step() { echo "== $(date -u +%H:%M:%S) $*"; "$@"; rc=$?; echo "   exit $rc"; return $rc; }
must() { step "$@" || { echo "STOP: $* failed"; exit 1; }; }
cd "$B/build"
must bash rebuild.sh
must python3 -I -B measure_bodies.py
must python3 -I -B lint_fixtures.py
e23() { python3 -I -B make_e23.py | tee "$B/out/e23.txt"; return "${PIPESTATUS[0]}"; }   # make_spec.py reads out/e23.txt
must e23
step python3 -I -B run_gates.py candidate
step python3 -I -B run_gates.py rehearsal
must python3 -I -B pin_diffs.py
must python3 -I -B ../verify/tools/b_vs_c_paths.py "$R/l1a/build-b" "$B" "$B/out/b-vs-c-paths.txt"
must bash ../verify/tools/mkpatch.sh 7b56c17 "$B/tree" "$B/patches/C-c"
must bash ../verify/tools/patch_check.sh 7b56c17 "$B/patches/C-c.patch" "$B/tree" "$B/out/patch-check.txt"
ACCOUNT_EMAIL=$(git -C /home/user/tuesday config user.email); export ACCOUNT_EMAIL
{
  python3 -I -B ../verify/tools/scan_all.py "patch and path list" "$B/patches/C-c.patch" "$B/patches/C-c.name-status"
  python3 -I -B ../verify/tools/scan_all.py "candidate tree" "$B/tree"
  python3 -I -B ../verify/tools/scan_all.py "rehearsal tree" "$B/tree-rehearsal"
  python3 -I -B ../verify/tools/scan_all.py "base tree" "$B/head"
} > "$B/out/scan.parts"
unset ACCOUNT_EMAIL
python3 -I -B - "$B/out/scan.parts" "$B/out/scan.txt" <<'PY'
import re, sys
lines = open(sys.argv[1]).read().splitlines()
tot = [0, 0, 0, 0]
for l in lines:
    for i, v in enumerate(re.findall(r": (\d+)(?= \|)", l)[:4]): tot[i] += int(v)
head = (f"account email: {tot[0]} occurrences; key-shaped strings: {tot[1]}; home paths other than /home/user: {tot[2]}; "
        f"root-folder paths: {tot[3]} (counts only; the value is read from git config at run time and never written)")
open(sys.argv[2], "w").write("\n".join([head] + lines) + "\n")
print(head)
PY
rm -f "$B/out/scan.parts"
must python3 -I -B make_spec.py
must bash ../verify/fresh/tools/fresh.sh
G=$B/verify/fresh/gates; rm -f "$G"/*.txt
step bash "$G/run.sh" "$B/verify/fresh/cand" candidate check_skills sync-check test_harness
step bash "$G/run.sh" "$B/verify/fresh/reh" rehearsal check_skills sync-check test_harness test_checks
cat "$G"/candidate-summary.txt "$G"/rehearsal-summary.txt
must bash ../verify/fresh/tools/scan_final.sh pre
must python3 -I -B "$K/make_expected.py" --build "$B" --variant C --out "$K/expect-c.json" --manifest "$B/manifest.md"
must python3 -I -B make_manifest.py
must python3 -I -B finish_manifest.py
must bash ../verify/fresh/tools/scan_final.sh post
must python3 -I -B "$K/make_expected.py" --build "$B" --variant C --out "$B/verify/expect-c.after.json" --manifest "$B/manifest.md"
cmp "$K/expect-c.json" "$B/verify/expect-c.after.json" && echo "expect-c.json byte-identical after the finish"
find "$B" "$K" -name __pycache__ -type d -prune -exec rm -rf {} + 2>/dev/null
echo "== $(date -u +%H:%M:%S) chain done"
