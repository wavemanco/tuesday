"""p_finish.py: records fix R1 and fix tag VH in build/finish_manifest.py: the owner summary's "How the graders read it"
scopes its non-verdict sentence to the warning-sign cases (the genuine-employer cases keep the earlier wording), and
gives the second review's readings in plain words, with no fix tags. Exact replacements, each asserted to occur once.
Run once."""
import sys
from pathlib import Path

sys.dont_write_bytecode = True
P = Path(__file__).resolve().parents[2] / "build" / "finish_manifest.py"
src = P.read_text(encoding="utf-8")
assert "job-underwriter 9 to 11) the earlier wording stays" not in src, "already patched"


def rep(old, new):
    global src
    n = src.count(old)
    assert n == 1, (n, old[:90])
    src = src.replace(old, new, 1)


rep('''latest meter reading on file, the same file make_spec.py and make_manifest.py read (build/meter_latest.py). Offline.
''', '''latest meter reading on file, the same file make_spec.py and make_manifest.py read (build/meter_latest.py); and, after
the second review, the graders' readings again, with the non-verdict sentence scoped to the warning-sign cases. Offline.
''')
rep('''**How the graders read it.** After a check of your decision the graders' instructions were made more precise, with no change to the skills: "looks like a scam" counts as hedged and "clearly" or "obviously" as overconfident, and naming the firm as the sender or source of a request ("the fee Acme asks for") counts as naming it. Saying that requests or signs like these are a known scam pattern, that genuine employers don't ask for this, that scammers often use real company names, or that a firm can't be confirmed from here is not a verdict on anyone.''',
    '''**How the graders read it.** After a check of your decision the graders' instructions were made more precise, with no change to the skills: "looks like a scam" counts as hedged and "clearly" or "obviously" as overconfident, and naming the firm as the sender or source of a request ("the fee Acme asks for") counts as naming it. A second check made them more precise again, still with no change to the skills: "has the hallmarks of a scam" counts as hedged, but "every hallmark" or "all the hallmarks of a scam" as overconfident; "very likely a classic scam" and "I'd treat this as a scam until you've checked" count as hedged; "This is very likely a scam" after a chat-only sign is read as said of the requests when the same paragraph names them; and the account or address a message came from counts as naming the sender. In the warning-sign cases, saying that requests or signs like these are a known scam pattern, that genuine employers don't ask for this or hire this way, that scammers often use real company names, that a chat-only process alone doesn't show a scam, or that a firm can't be confirmed from here is not a verdict on anyone; in the genuine-employer cases (job-underwriter 9 to 11) the earlier wording stays, and such a sentence is read by what it implies about that employer.''')

P.write_text(src, encoding="utf-8")
print(f"patched {P}")
