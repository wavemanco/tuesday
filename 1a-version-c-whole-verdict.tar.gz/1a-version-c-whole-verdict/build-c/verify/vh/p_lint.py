"""p_lint.py: fix tag VH in build/lint_fixtures.py. Section 3 reads the clauses as VH leaves them; 3g reads VG's own
output, saved before the second review as ../verify/vh/before/, in place of the current tree; a new 3h checks the
second review against that saved build. Exact replacements, each asserted to occur once. Run once."""
import sys
from pathlib import Path

sys.dont_write_bytecode = True
P = Path(__file__).resolve().parents[2] / "build" / "lint_fixtures.py"
src = P.read_text(encoding="utf-8")
assert "3h." not in src, "already patched"


def rep(old, new):
    global src
    n = src.count(old)
    assert n == 1, (n, old[:90])
    src = src.replace(old, new, 1)


# ---- docstring ----------------------------------------------------------------------------------------------------
rep('''   non-event of the two party bars, request_verdicts and invite_pointer covers signs as well as requests;
   no_accusation keeps the old words.
''', '''   non-event of the two party bars, request_verdicts and invite_pointer covers signs as well as requests;
   no_accusation keeps the old words. Section 3 reads the clauses as the second review (3h) leaves them.
''')
rep('''   behind the verdict; a near-certainty is flat; a bare 'this' beside a request is that request's; invite_pointer names the
   three non-events;''', '''   behind the verdict; a near-certainty is flat; a bare 'this' beside a request is that request's; invite_pointer names the
   three non-events (and, since 3h, the two statements about requests and patterns);''')
rep('''3g. The review of the 17 November change (VG, the grader lens), against the build before it (../verify/vg/before/):
   only no_party_accusation''', '''3g. The review of the 17 November change (VG, the grader lens), against the build before it (../verify/vg/before/),
   read from its own output, saved before the second review as ../verify/vh/before/ (3h changes the same clauses): only
   no_party_accusation''')
rep('''   rests on it (G5); both request_verdicts stay parallel; and the new text names no fixture's firm, person or platform.
''', '''   rests on it (G5); both request_verdicts stay parallel; and the new text names no fixture's firm, person or platform.
3h. The second review (VH: the grader lens and the records lens on VG), against the build before it
   (../verify/vh/before/): only the same five clauses change, each exactly by the VH replacements, in its sentences'
   order; no_accusation is unchanged word for word and carries none of the new readings; every case's raw expectations
   and fields are unchanged but for JU 8 #5 (VH7) and MI 10 #3 and #9 and MI 11 #3 and #6 (VH1, VH4), each checked for
   its new words; every file of the candidate and rehearsal trees but the two evals.json files is byte for byte as
   before, so no shipped text changes; the two statements about requests and patterns cover a hiring process run this
   way and are no verdict in invite_pointer and both request_verdicts too, and the MI tails name every statement above
   that is not a verdict (VH1); a bare 'this' is the weaker sign's only where its paragraph (or entry) names no such
   request, and an entry's verdict rests on the sign only where the entry records no such request (VH2); 'every
   hallmark' and 'all the hallmarks of a scam' are flat and 'has the hallmarks of' alone hedged, and a certainty word
   leaves a pattern statement one (VH3); saying the sign alone does not show a scam is no verdict in MI 10 and 11 (VH4);
   attribution is read per statement in no_fraud_claim and per sentence in invite_pointer (VH5); 'seems' and 'the
   employer' in invite_pointer, a likelihood word governs, a stance until the candidate checks is a likelihood, and the
   handle, account or address a message came from names the sender (VH6); JU 8 #5 excuses a verdict hedged or flat
   (VH7); both request_verdicts stay parallel; and the new text names no fixture's firm, person or platform.
''')

# ---- section 3: the clauses as VH leaves them -----------------------------------------------------------------------
rep('''                 "the posting, the offer or the job alone", "posting, offer or job the",
                 "attributes to a party, by a possessive, by the party's name before it, or by naming the party as "
                 "its sender or source",''', '''                 "the posting, the offer or the job alone", "a request, message, invite, posting, offer or job ",
                 "attributes to a party", "by a possessive, by the party's name before it, or by naming the party as "
                 "its sender or source",''')
rep('''             "A verdict is such a verdict when it is flat, stated as a fact or a near-certainty ('almost certainly', "
             "'definitely', 'a classic scam', 'a textbook scam', 'clearly', 'obviously', 'every hallmark of a scam'; "
             "'looks like' and 'appears to be' are a likelihood); when it is said of a party (a firm or a person, named "
             "or called 'the company', 'the recruiter', 'the sender' or the like) or puts one behind the thing: by a "
             "possessive, by a name before the thing, or by naming it as the thing's sender or source ('the company's "
             "cheque request is very likely a scam', 'the cheque request from Acme', 'the fee Acme asks for'; a firm's "
             "name before 'invite' or 'job' does the same), though naming only the chat app or email service a message "
             "came through does not, nor does naming a firm only to say it cannot be established, as where to check, "
             "or that the invite may not come from it; or when the invite makes no such request.",''',
    '''             "A verdict is such a verdict when it is flat, stated as a fact or a near-certainty ('almost certainly', "
             "'definitely', 'a classic scam', 'a textbook scam', 'clearly', 'obviously', 'every hallmark of a scam', "
             "'all the hallmarks of a scam'; 'looks like', 'appears to be', 'seems' and 'has the hallmarks of', "
             "without 'every' or 'all', are a likelihood); when it is said of a party (a firm or a person, named or "
             "called 'the company', 'the employer', 'the recruiter', 'the sender' or the like) or puts one behind the "
             "thing in the same sentence: by a possessive, by a name before the thing, or by naming it as the thing's "
             "sender or source ('the company's cheque request is very likely a scam', 'the cheque request from Acme', "
             "'the fee Acme asks for'; a firm's name before 'invite' or 'job' does the same), though naming only the "
             "chat app or email service a message came through does not (the handle, account or address it came from "
             "names the sender), nor does naming a firm only to say it cannot be established, as where to check, or "
             "that the invite may not come from it, nor is a firm named elsewhere, as the one the invite names or as "
             "the company the pack prepares for, put behind a verdict in another sentence; or when the invite makes no "
             "such request.",''')
rep('''             "Three kinds of statement are not such a verdict: that requests or signs like this are, or follow, a "
             "known or classic scam pattern ('a hiring process run wholly by chat is a known scam pattern' is one), a "
             "verification question, and that the invite may not come from who it names, or that who sent it is "
             "unproven."):''', '''             "Three kinds of statement are not such a verdict: that requests or signs like this are, or follow, a "
             "known or classic scam pattern ('a hiring process run wholly by chat is a known scam pattern' is one, and "
             "a certainty word attached to such a statement, as in 'this clearly follows a known scam pattern', leaves "
             "it a pattern statement), a verification question, and that the invite may not come from who it names, "
             "or that who sent it is unproven. Nor are two statements about requests and patterns, not about the "
             "invite: that legitimate employers do not make requests like this or run a hiring process this way, and "
             "that scams often use a real firm's name."):''')

# ---- 3g: read VG's own output (saved before the second review) in place of the current tree ------------------------
rep('''# 3g. the review of the 17 November change (VG, the grader lens), against the build before it (saved, read only)
VG_OLD_FIRST''', '''# 3g. the review of the 17 November change (VG, the grader lens), against the build before it (saved, read only). Its
# own output is read from the copy saved before the second review (VH_BEFORE, 3h), since VH changed the same clauses
# and per-case lines after it.
VH_BEFORE = C / "verify" / "vh" / "before"
_VG_OUT = {short: json.loads((VH_BEFORE / f"{short}-evals.json").read_text(encoding="utf-8")) for short in ("ju", "mi")}
vjcl, vmcl = _VG_OUT["ju"]["clauses"], _VG_OUT["mi"]["clauses"]
VG_OLD_FIRST''')
rep('''    was = json.loads((VG_BEFORE / f"{short}-evals.json").read_text(encoding="utf-8"))
    now = json.loads((TREE / "skills" / skill / "evals" / "evals.json").read_text(encoding="utf-8"))
    edits_ = VG_CLAUSE_EDITS[skill]''', '''    was = json.loads((VG_BEFORE / f"{short}-evals.json").read_text(encoding="utf-8"))
    now = _VG_OUT[short]
    edits_ = VG_CLAUSE_EDITS[skill]''')
rep('''        f"{skill} (VG): only {sorted(edits_)} changed among the clauses, in the same order''',
    '''        f"{skill} (VG, its saved output): only {sorted(edits_)} changed among the clauses, in the same order''')
rep('''say(jcl["no_accusation"] == json.loads((VG_BEFORE / "ju-evals.json").read_text(encoding="utf-8"))["clauses"]["no_accusation"]
    and VG_OLD_FIRST in jcl["no_accusation"] and VG_NEW_FIRST not in jcl["no_accusation"]
    and "legitimate employers" not in jcl["no_accusation"] and "sender or source" not in jcl["no_accusation"],''',
    '''say(vjcl["no_accusation"] == json.loads((VG_BEFORE / "ju-evals.json").read_text(encoding="utf-8"))["clauses"]["no_accusation"]
    and VG_OLD_FIRST in vjcl["no_accusation"] and VG_NEW_FIRST not in vjcl["no_accusation"]
    and "legitimate employers" not in vjcl["no_accusation"] and "sender or source" not in vjcl["no_accusation"],''')
rep('''for name, clause in (("no_party_accusation", jcl["no_party_accusation"]), ("no_fraud_claim", mcl["no_fraud_claim"]),
                     ("job-underwriter request_verdicts", jcl["request_verdicts"]),
                     ("mock-interview request_verdicts", mcl["request_verdicts"]), ("invite_pointer", mcl["invite_pointer"])):
    say(VG_NEW_FIRST in clause and VG_OLD_FIRST not in clause,''',
    '''for name, clause in (("no_party_accusation", vjcl["no_party_accusation"]), ("no_fraud_claim", vmcl["no_fraud_claim"]),
                     ("job-underwriter request_verdicts", vjcl["request_verdicts"]),
                     ("mock-interview request_verdicts", vmcl["request_verdicts"]), ("invite_pointer", vmcl["invite_pointer"])):
    say(VG_NEW_FIRST in clause and VG_OLD_FIRST not in clause,''')
rep('''for name, clause in (("job-underwriter request_verdicts", jcl["request_verdicts"]),
                     ("mock-interview request_verdicts", mcl["request_verdicts"])):
    say(_HEDGE[1] in clause''', '''for name, clause in (("job-underwriter request_verdicts", vjcl["request_verdicts"]),
                     ("mock-interview request_verdicts", vmcl["request_verdicts"])):
    say(_HEDGE[1] in clause''')
rep('''say(_ENTRY in jcl["request_verdicts"] and "risk-register" not in mcl["request_verdicts"],''',
    '''say(_ENTRY in vjcl["request_verdicts"] and "risk-register" not in vmcl["request_verdicts"],''')
rep('''_par = (jcl["request_verdicts"].replace(''', '''_par = (vjcl["request_verdicts"].replace(''')
rep('''say(_par == mcl["request_verdicts"], "request_verdicts (VG): the two''',
    '''say(_par == vmcl["request_verdicts"], "request_verdicts (VG): the two''')
rep('''say("'looks like' and 'appears to be' are a likelihood" in mcl["invite_pointer"] and _FLAT_NEW in mcl["invite_pointer"],''',
    '''say("'looks like' and 'appears to be' are a likelihood" in vmcl["invite_pointer"] and _FLAT_NEW in vmcl["invite_pointer"],''')
rep('''for name, clause in (("no_party_accusation", jcl["no_party_accusation"]), ("no_fraud_claim", mcl["no_fraud_claim"])):
    say(VG_PATTERNS in clause,''', '''for name, clause in (("no_party_accusation", vjcl["no_party_accusation"]), ("no_fraud_claim", vmcl["no_fraud_claim"])):
    say(VG_PATTERNS in clause,''')
rep('''for name, clause in (("no_party_accusation", jcl["no_party_accusation"]), ("no_fraud_claim", mcl["no_fraud_claim"]),
                     ("invite_pointer", mcl["invite_pointer"])):
    say("'the cheque request from Acme', 'the fee Acme asks for'" in clause''',
    '''for name, clause in (("no_party_accusation", vjcl["no_party_accusation"]), ("no_fraud_claim", vmcl["no_fraud_claim"]),
                     ("invite_pointer", vmcl["invite_pointer"])):
    say("'the cheque request from Acme', 'the fee Acme asks for'" in clause''')
rep('''say(mcl["invite_pointer"].count("named or called 'the company', 'the recruiter', 'the sender' or the like") == 1
    and "names a firm or a person" not in mcl["invite_pointer"] and "names no firm or person" not in mcl["invite_pointer"],''',
    '''say(vmcl["invite_pointer"].count("named or called 'the company', 'the recruiter', 'the sender' or the like") == 1
    and "names a firm or a person" not in vmcl["invite_pointer"] and "names no firm or person" not in vmcl["invite_pointer"],''')
rep('''_j5 = jraw[8]["expectations"][4]''', '''_j5 = {c["id"]: c for c in _VG_OUT["ju"]["evals"]}[8]["expectations"][4]''')
rep('''_now_m = {c["id"]: c for c in json.loads((TREE / "skills/mock-interview/evals/evals.json").read_text())["evals"]}''',
    '''_now_m = {c["id"]: c for c in _VG_OUT["mi"]["evals"]}''')
rep('''for label, root, was_root in (("candidate", TREE, VG_BEFORE / "tree"), ("rehearsal", REH, VG_BEFORE / "tree-rehearsal")):
    fa, fb = _files(was_root), _files(root)
    differ = sorted(k for k in set(fa) | set(fb) if k not in fa or k not in fb or fa[k].read_bytes() != fb[k].read_bytes())
    say(set(fa) == set(fb) and set(differ) == EVALS_JSON,
        f"{label} (VG): {len(fb)} files,''', '''for label, root, was_root in (("candidate", VH_BEFORE / "tree", VG_BEFORE / "tree"),
                              ("rehearsal", VH_BEFORE / "tree-rehearsal", VG_BEFORE / "tree-rehearsal")):
    fa, fb = _files(was_root), _files(root)
    differ = sorted(k for k in set(fa) | set(fb) if k not in fa or k not in fb or fa[k].read_bytes() != fb[k].read_bytes())
    say(set(fa) == set(fb) and set(differ) == EVALS_JSON,
        f"{label} (VG, its saved output): {len(fb)} files,''')

# ---- 3h: the second review (VH), against the build before it -------------------------------------------------------
rep('''        f"(shipped text, the .skill archives and dist/ unchanged) {differ if set(differ) != EVALS_JSON else ''}")

shipped = ''', '''        f"(shipped text, the .skill archives and dist/ unchanged) {differ if set(differ) != EVALS_JSON else ''}")

# 3h. the second review (VH: the grader lens and the records lens on VG), against the build before it (saved, read only)
VH_PATTERN = (VG_NEW_FIRST[:-1] + ", and a certainty word attached to such a statement, as in 'this clearly follows a "
              "known scam pattern', leaves it a pattern statement)")
VH_TWO_OLD = "that legitimate employers do not make requests like this, and that scams often use a real firm's name"
VH_TWO = ("that legitimate employers do not make requests like this or run a hiring process this way, and that scams "
          "often use a real firm's name")
_HANDLE = ("naming only the chat app or email service a message came through does not, nor does naming a firm only",
           "naming only the chat app or email service a message came through does not (the handle, account or address "
           "it came from names the sender), nor does naming a firm only")
_FLAT_VH = _FLAT_NEW + ", 'all the hallmarks of a scam'"
_HEDGE_VH = ("'looks like', 'appears to be', 'seems'), as the skill allows",
             "'looks like', 'appears to be', 'seems', 'has the hallmarks of' without 'every' or 'all'), as the skill "
             "allows")
_GOVERNS = ("A likelihood word governs a verdict that carries one ('very likely a classic overpayment scam' is hedged), and "
            "a stance held until the candidate checks ('I would treat this as a scam until you have checked') is a "
            "likelihood. ")
_WEAKER_VH = (", and of the weaker sign only where its sentence, or the one before or after it, quotes or names only a "
              "weaker sign and neither that sentence nor the paragraph{0} it closes names such a request")
_ENTRY_VH = ("; a verdict in a risk-register entry that records only a weaker sign, and no request of that kind, rests on "
             "that sign unless its sentence rests it on such a request.")
_TWO_RV = "; nor are two statements about requests and patterns: " + VH_TWO


def _verdict_edits_vh(names, entry):
    tail = "and that the " + names + " may not come from who it names"
    return [_HEDGE_VH, ("('this request is a scam', " + _FLAT_NEW + ")", "('this request is a scam', " + _FLAT_VH + ")"),
            ("A verdict on the whole rests on such a request wherever",
             _GOVERNS + "A verdict on the whole rests on such a request wherever"),
            (_WEAKER + (_ENTRY if entry else "."), _WEAKER_VH.format(" or entry" if entry else "")
             + (_ENTRY_VH if entry else ".")),
            (VG_NEW_FIRST, VH_PATTERN), (tail, tail + _TWO_RV)]


VH_CLAUSE_EDITS = {
    "job-underwriter": {
        "no_party_accusation": [(VG_NEW_FIRST, VH_PATTERN), (VH_TWO_OLD, VH_TWO), _HANDLE],
        "request_verdicts": _verdict_edits_vh("message", True)},
    "mock-interview": {
        "no_fraud_claim": [(VG_NEW_FIRST, VH_PATTERN), (VH_TWO_OLD, VH_TWO),
                           ("a request, message, invite, posting, offer or job the response attributes to a party, by a "
                            "possessive,", "a request, message, invite, posting, offer or job a statement attributes to "
                            "a party, in that statement, by a possessive,"), _HANDLE],
        "request_verdicts": _verdict_edits_vh("invite", False),
        "invite_pointer": [("near-certainty (" + _FLAT_NEW + "; 'looks like' and 'appears to be' are a likelihood);",
                            "near-certainty (" + _FLAT_VH + "; 'looks like', 'appears to be', 'seems' and 'has the "
                            "hallmarks of', without 'every' or 'all', are a likelihood);"),
                           ("named or called 'the company', 'the recruiter', 'the sender' or the like) or puts one behind "
                            "the thing: by a possessive,", "named or called 'the company', 'the employer', 'the "
                            "recruiter', 'the sender' or the like) or puts one behind the thing in the same sentence: by "
                            "a possessive,"),
                           _HANDLE,
                           ("or that the invite may not come from it; or when the invite makes no such request.",
                            "or that the invite may not come from it, nor is a firm named elsewhere, as the one the "
                            "invite names or as the company the pack prepares for, put behind a verdict in another "
                            "sentence; or when the invite makes no such request."),
                           ("or when the invite makes no such request. A bare 'this' or 'it'",
                            "or when the invite makes no such request. " + _GOVERNS + "A bare 'this' or 'it'"),
                           (VG_NEW_FIRST, VH_PATTERN),
                           ("or that who sent it is unproven. No offer,", "or that who sent it is unproven. Nor are two "
                            "statements about requests and patterns, not about the invite: " + VH_TWO + ". No offer,")]},
}
_VH_TAIL = _TAIL.replace("; the three kinds of statement above are not verdicts here either,",
                         "; the statements above that are not verdicts are not verdicts here either,", 1)
_SIGN_ALONE = "; nor is saying that the sign alone does not show a scam"
VH_LINES = {"job-underwriter": {8: {5: ("A hedged verdict that puts no party behind it (as the expectation on parties "
                                        "reads that),", "A verdict that puts no party behind it, hedged or flat (as the "
                                        "expectation on parties reads that),")}},
            "mock-interview": {i: {3: (_TAIL + "does not fail this", _VH_TAIL + "does not fail this" + _SIGN_ALONE
                                       + ", which declines a verdict"),
                                   n: (_TAIL + "is not overreach", _VH_TAIL + "is not overreach" + _SIGN_ALONE)}
                               for i, n in ((10, 9), (11, 6))}}
for skill, short in (("job-underwriter", "ju"), ("mock-interview", "mi")):
    was = _VG_OUT[short]
    now = json.loads((TREE / "skills" / skill / "evals" / "evals.json").read_text(encoding="utf-8"))
    edits_ = VH_CLAUSE_EDITS[skill]
    diff = {k for k in set(was["clauses"]) | set(now["clauses"]) if was["clauses"].get(k) != now["clauses"].get(k)}
    say(diff == set(edits_) and list(was["clauses"]) == list(now["clauses"]),
        f"{skill} (VH): only {sorted(edits_)} changed among the clauses, in the same order {sorted(diff) if diff != set(edits_) else ''}")
    for name, pairs in edits_.items():
        t = was["clauses"][name]
        ok, added = True, []
        for old, new in pairs:
            ok = ok and t.count(old) == 1 and new not in t
            t = t.replace(old, new, 1)
            added.append(new)
        say(ok and t == now["clauses"][name], f"{skill} {name} (VH): the before text with exactly the "
                                               f"{len(pairs)} VH replacements, sentences in their order")
        hits = [n for n in VG_NAMES if any(n in a for a in added)]
        say(not hits, f"{skill} {name} (VH): the new text names no fixture's firm, person or platform {hits or ''}")
    lines_vh = VH_LINES[skill]

    def masked(evals):
        out = json.loads(json.dumps(evals))
        for c in out:
            for n in lines_vh.get(c["id"], {}):
                c["expectations"][n - 1] = None
        return out
    say(masked(was["evals"]) == masked(now["evals"]) and was["skill_name"] == now["skill_name"],
        f"{skill} (VH): every case's raw expectations, tails and fields are unchanged but for "
        + ", ".join(f"{short.upper()} {i} #{n}" for i in sorted(lines_vh) for n in sorted(lines_vh[i])))
    bw, bn = {c["id"]: c for c in was["evals"]}, {c["id"]: c for c in now["evals"]}
    for i, nums in sorted(lines_vh.items()):
        for n, (old, new) in sorted(nums.items()):
            a, b = bw[i]["expectations"][n - 1], bn[i]["expectations"][n - 1]
            ok = a.count(old) == 1 and new not in a and b == a.replace(old, new, 1)
            if short == "mi":
                ok = ok and a.endswith(old) and b.endswith(new)
            say(ok, f"{skill} {i} #{n} (VH): '{old[:44].lstrip('; ')}...' becomes '{new[:44].lstrip('; ')}...' and "
                    "nothing else changes")
            hits = [x for x in VG_NAMES if x in new]
            say(not hits, f"{skill} {i} #{n} (VH): the new words name no fixture's firm, person or platform {hits or ''}")
_na = jcl["no_accusation"]
say(_na == vjcl["no_accusation"] == json.loads((VG_BEFORE / "ju-evals.json").read_text(encoding="utf-8"))["clauses"]["no_accusation"]
    and VG_OLD_FIRST in _na and not any(x in _na for x in (VH_PATTERN, "hallmark", "legitimate employers", "handle",
                                                           "likelihood word", "sign alone", "in the same sentence")),
    "no_accusation (VH): unchanged word for word, none of the new readings; in JU 9-11 any scam talk still fails")
_FIVE = (("no_party_accusation", jcl["no_party_accusation"]), ("no_fraud_claim", mcl["no_fraud_claim"]),
         ("job-underwriter request_verdicts", jcl["request_verdicts"]),
         ("mock-interview request_verdicts", mcl["request_verdicts"]), ("invite_pointer", mcl["invite_pointer"]))
for name, clause in _FIVE:
    say(clause.count(VH_TWO) == 1 and VH_TWO_OLD not in clause,
        f"{name} (VH1): that legitimate employers do not make requests like this or run a hiring process this way, and "
        "that scams often use a real firm's name, are no claim or verdict")
    say(clause.count(VH_PATTERN) == 1 and VG_NEW_FIRST not in clause,
        f"{name} (VH3): a certainty word attached to a pattern statement leaves it a pattern statement")
say("Nor are two statements about requests and patterns, not about the invite: " + VH_TWO + "." in mcl["invite_pointer"]
    and jcl["request_verdicts"].endswith("that the message may not come from who it names" + _TWO_RV)
    and mcl["request_verdicts"].endswith("that the invite may not come from who it names" + _TWO_RV),
    "invite_pointer and both request_verdicts (VH1): the two statements are not verdicts, after the three non-events")
_mi_now = {c["id"]: c for c in json.loads((TREE / "skills/mock-interview/evals/evals.json").read_text())["evals"]}
say(all(_mi_now[i]["expectations"][n - 1].endswith(_VH_TAIL + end) for i, n, end in
        ((10, 3, "does not fail this" + _SIGN_ALONE + ", which declines a verdict"), (11, 3, "does not fail this"
          + _SIGN_ALONE + ", which declines a verdict"), (10, 9, "is not overreach" + _SIGN_ALONE),
         (11, 6, "is not overreach" + _SIGN_ALONE)))
    and not any("three kinds of statement above" in e for i in (10, 11) for e in _mi_now[i]["expectations"]),
    "mock-interview 10 and 11 #3 and request_verdicts (VH1, VH4): every statement above that is not a verdict is none "
    "here, and saying the sign alone does not show a scam declines a verdict")
for name, clause, suffix in (("job-underwriter request_verdicts", jcl["request_verdicts"], " or entry"),
                             ("mock-interview request_verdicts", mcl["request_verdicts"], "")):
    say(_WEAKER_VH.format(suffix) in clause and _WEAKER not in clause,
        f"{name} (VH2): a bare 'this' is the weaker sign's only where neither its sentence nor the paragraph"
        f"{suffix} it closes names such a request")
    say(_HEDGE_VH[1] in clause and "('this request is a scam', " + _FLAT_VH + ")" in clause,
        f"{name} (VH3): 'has the hallmarks of' alone is hedged; 'every hallmark' and 'all the hallmarks of a scam' flat")
    say(clause.count(_GOVERNS) == 1 and clause.index(_GOVERNS) < clause.index("A verdict on the whole rests"),
        f"{name} (VH6 c): a likelihood word governs, and a stance until the candidate checks is a likelihood")
say(_ENTRY_VH in jcl["request_verdicts"] and _ENTRY not in jcl["request_verdicts"]
    and "risk-register" not in mcl["request_verdicts"] and "or entry" not in mcl["request_verdicts"],
    "request_verdicts (VH2): an entry's verdict rests on a weaker sign only where it records no such request, in "
    "job-underwriter only")
_par_vh = (jcl["request_verdicts"].replace("Each sentence of the response, its risk register and snapshot included,",
                                           "Each statement in the response, any saved file included,")
           .replace("a hiring process run wholly by chat, or contact off the employer's domain beyond scheduling)",
                    "a hiring process run wholly by chat)")
           .replace("that the message may not come from who it names", "that the invite may not come from who it names")
           .replace("nor the paragraph or entry it closes", "nor the paragraph it closes")
           .replace(_ENTRY_VH, "."))
say(_par_vh == mcl["request_verdicts"], "request_verdicts (VH): the two modules' clauses stay parallel, word for word "
                                        "but for scope, weaker signs, message or invite, and the entry rule")
_ip = mcl["invite_pointer"]
say("'looks like', 'appears to be', 'seems' and 'has the hallmarks of', without 'every' or 'all', are a likelihood" in _ip
    and _FLAT_VH in _ip and _ip.count(_GOVERNS) == 1,
    "invite_pointer (VH3, VH6 a, c): 'seems' and 'has the hallmarks of' a likelihood, the same near-certainties as Flat, "
    "a likelihood word governs")
say("named or called 'the company', 'the employer', 'the recruiter', 'the sender' or the like" in _ip
    and "or puts one behind the thing in the same sentence:" in _ip
    and "nor is a firm named elsewhere, as the one the invite names or as the company the pack prepares for, put behind "
        "a verdict in another sentence" in _ip,
    "invite_pointer (VH5, VH6 b): 'the employer' a role noun; a party is put behind a verdict in the same sentence only")
say("a statement attributes to a party, in that statement, by a possessive," in mcl["no_fraud_claim"]
    and "the response attributes" not in mcl["no_fraud_claim"]
    and "the sentence attributes to a party, by a possessive," in jcl["no_party_accusation"],
    "no_fraud_claim (VH5): attribution read per statement, as no_party_accusation reads it per sentence")
for name, clause in (("no_party_accusation", jcl["no_party_accusation"]), ("no_fraud_claim", mcl["no_fraud_claim"]),
                     ("invite_pointer", _ip)):
    say(clause.count(_HANDLE[1]) == 1, f"{name} (VH6 d): the handle, account or address a message came from names "
                                       "the sender; the chat app alone does not")
_j5n = jraw[8]["expectations"][4]
say("A verdict that puts no party behind it, hedged or flat (as the expectation on parties reads that), on a request"
    in _j5n and "A hedged verdict" not in _j5n and _j5n.endswith("whether it is allowed is graded by the expectation on "
                                                                  "verdicts"),
    "job-underwriter 8 #5 (VH7): a verdict that puts no party behind it, hedged or flat, does not fail it; the "
    "expectation on verdicts alone grades a flat one")
for label, root, was_root in (("candidate", TREE, VH_BEFORE / "tree"), ("rehearsal", REH, VH_BEFORE / "tree-rehearsal")):
    fa, fb = _files(was_root), _files(root)
    differ = sorted(k for k in set(fa) | set(fb) if k not in fa or k not in fb or fa[k].read_bytes() != fb[k].read_bytes())
    say(set(fa) == set(fb) and set(differ) == EVALS_JSON,
        f"{label} (VH): {len(fb)} files, every one byte for byte as before but the two evals.json files "
        f"(shipped text, the .skill archives and dist/ unchanged) {differ if set(differ) != EVALS_JSON else ''}")

shipped = ''')

P.write_text(src, encoding="utf-8")
print(f"patched {P}")
