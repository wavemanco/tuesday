"""p_spec.py: fix tag VH in build/make_spec.py: the subsection "The second review (VH)", the VG subsection read from VG's
own output (saved as ../verify/vh/before/edits.json), records fixes R3 (VK1, VK3 and the VW request_verdicts bullet
get their VG pointers), R4 (D7's wording) and O1 (G4's case-true example), and section 6.1, section 9's lint summary
and owner question 15 (b) updated for VH. Exact replacements, each asserted to occur once. Run once."""
import sys
from pathlib import Path

sys.dont_write_bytecode = True
P = Path(__file__).resolve().parents[2] / "build" / "make_spec.py"
src = P.read_text(encoding="utf-8")
assert "The second review (VH)" not in src, "already patched"


def rep(old, new):
    global src
    n = src.count(old)
    assert n == 1, (n, old[:90])
    src = src.replace(old, new, 1)


# ---- docstring and the summary paragraph ---------------------------------------------------------------------------
rep('''correct this file's summaries; the meter reading comes from build/meter_latest.py, shared with the manifest scripts.
"""''', '''correct this file's summaries; the meter reading comes from build/meter_latest.py, shared with the manifest scripts.
The second review (fix tag VH: the grader lens and the records lens on VG) again changes the fixture clauses and the
same five per-case lines only; the VG subsection quotes VG's own output (verify/vh/before/edits.json), and the VH
subsection the text as it ships.
"""''')
rep('''  "it, and `request_verdicts` classes it hedged, with three kinds (hedged, flat, overreach) and no Whole kind. "
  "Both SKILL.md bodies are variant B's byte for byte. "''', '''  "it, and `request_verdicts` classes it hedged, with three kinds (hedged, flat, overreach) and no Whole kind. "
  "Two reviews of that change (fix tags VG and VH, below) made the graders' readings more precise, in the fixture "
  "clauses and five per-case lines only; no shipped text changed with them. "
  "Both SKILL.md bodies are variant B's byte for byte. "''')

# ---- R3: VK1, VK3 and the VW request_verdicts bullet get their pointers -------------------------------------------
rep('''     "`invite_pointer` now says \\"Three kinds of statement are not such a verdict: that requests like this are a known "
     "scam pattern, a verification question, and that the invite may not come from who it names, or that who sent it "
     "is unproven.\\""),''', '''     "`invite_pointer` now says \\"Three kinds of statement are not such a verdict: that requests like this are a known "
     "scam pattern, a verification question, and that the invite may not come from who it names, or that who sent it "
     "is unproven.\\" (VG widens the first to \\"that requests or signs like this are, or follow, a known or classic "
     "scam pattern\\"; VH adds the two statements about requests and patterns.)"),''')
rep('''     "\\"Acme\\" as the generic name; the party clauses are unchanged."),''',
    '''     "\\"Acme\\" as the generic name; the party clauses are unchanged by VW; VG adds naming the party as the thing's "
     "sender or source and the firm-only carve-out, and VH the handle a message came from and, in `no_fraud_claim`, "
     "attribution read per statement."),''')
rep('''  "request (MI 10, MI 11); its three non-events and the bare-\\"this\\" reading stay. Its review (VG, below) reads "
  "who is put behind a verdict as the party bars do and widens the first non-event to signs.")''',
    '''  "request (MI 10, MI 11); its three non-events and the bare-\\"this\\" reading stay. Its review (VG, below) reads "
  "who is put behind a verdict as the party bars do and widens the first non-event to signs; the second review (VH, "
  "below) adds the two statements about requests and patterns and reads a party per sentence.")''')
rep('''  "sentence rests it on a weaker sign alone (JU 8's \\"Running the whole process on Telegram is probably a scam.\\" "
  "stays overreach).")''', '''  "sentence rests it on a weaker sign alone (JU 8's \\"Running the whole process on Telegram is probably a scam.\\" "
  "stays overreach). Its review (VG, below) adds appearance words to Hedged, certainty markers to Flat, the sentence "
  "before or after, and the bare-\\"this\\" reading of a weaker sign; the second review (VH, below) narrows that reading "
  "to a paragraph or entry that names no such request.")''')

# ---- the VG subsection: VG's own output, saved before the second review -------------------------------------------
rep('''_VGC = {"no_party_accusation": EDITS["C06a"]["text"], "ju_verdicts": EDITS["C06b"]["text"],
        "invite_pointer": EDITS["C26"]["text"], "no_fraud_claim": EDITS["C27"]["text"],
        "mi_verdicts": EDITS["C27a"]["text"], "no_accusation": EDITS["C06"]["text"]}''',
    '''# The review's own output, saved before the second review (VH, below), which changes some of these clauses again.
_VG_DOC = json.loads((C / "verify" / "vh" / "before" / "edits.json").read_text(encoding="utf-8"))
VG_EDITS = {e["id"]: e for ph in _VG_DOC["phases"] for e in ph["edits"]}
_VGC = {"no_party_accusation": VG_EDITS["C06a"]["text"], "ju_verdicts": VG_EDITS["C06b"]["text"],
        "invite_pointer": VG_EDITS["C26"]["text"], "no_fraud_claim": VG_EDITS["C27"]["text"],
        "mi_verdicts": VG_EDITS["C27a"]["text"], "no_accusation": VG_EDITS["C06"]["text"]}''')
rep('''    """A segment of a clause as it ships, asserted to be there."""''',
    '''    """A segment of a clause as VG left it, asserted to be there."""''')
rep('''assert EDITS["C08"]["case"]["expectations"][4].endswith(VG_JU8)''',
    '''assert VG_EDITS["C08"]["case"]["expectations"][4].endswith(VG_JU8)''')
rep('''    assert EDITS[_cid]["case"]["expectations"][_n - 1].endswith(VG_TAIL + _end), (_cid, _n)''',
    '''    assert VG_EDITS[_cid]["case"]["expectations"][_n - 1].endswith(VG_TAIL + _end), (_cid, _n)''')
rep('''  "base, and `no_accusation` (JU 9–11) is word for word as before. Each clause keeps its sentences in their order, "
  f"and the two modules' parallel clauses stay parallel [{', '.join(vg_ids)}]:\\n")''',
    '''  "base, and `no_accusation` (JU 9–11) is word for word as before. Each clause keeps its sentences in their order, "
  "and the two modules' parallel clauses stay parallel. The quotations below are the text as this review left it, "
  "read from its own output (`verify/vh/before/edits.json`); the second review (VH, below) changes several of them "
  f"again [{', '.join(vg_ids)}]:\\n")''')
rep('''  "fails MI 12 #3 as it fails #4). Read against the skill's own \\"is it legit?\\" example with a firm's name filled "
  "in, \\"I can't establish Velloway Logistics from here; the request to buy gift cards for your onboarding is very "
  "likely a scam, so buy and send nothing yet.\\", every clause passes it where the material makes such a request "
  "(JU 8, MI 12): the firm is named "''', '''  "fails MI 12 #3 as it fails #4). Read against section 6.1's case-true example, which follows the skill's own \\"is "
  "it legit?\\" example, \\"I can't establish Velloway Logistics from here; the request to pay €349 for the work kit is "
  "very likely a scam, so pay nothing yet.\\" (JU 8; in MI 12 the same with Brennock Facilities and its €95 equipment "
  "registration fee), every clause passes it where the material makes such a request: the firm is named "''')
rep('''  "its limit rather than asserting it. D7: the run kit's stand-in freeze and its dry run were rerun against the "
  "final `runkit/expect-c.json` (`verify/vg/`).")''', '''  "its limit rather than asserting it. D7: the run kit's stand-in freeze was rerun against the final "
  "`runkit/expect-c.json`, and its dry run after it (`verify/vg/`).")''')
rep('''w("- **Checked** by `build/lint_fixtures.py` (3g): against the build before the review (`verify/vg/before/`) only "''',
    '''w("- **Checked** by `build/lint_fixtures.py` (3g, read from the review's own output, saved before the second "
  "review as `verify/vh/before/`): against the build before the review (`verify/vg/before/`) only "''')

# ---- the VH subsection, after the VG subsection --------------------------------------------------------------------
rep('''  "`request_verdicts` stay parallel word for word; and the new text names no fixture's firm, person or platform.")
w("")
''', '''  "`request_verdicts` stay parallel word for word; and the new text names no fixture's firm, person or platform.")
w("")

# ---- the second review (VH): the grader lens and the records lens on VG --------------------------------------------
vh_ids = sorted(set(by_fix.get("VH", [])), key=cids.index)
assert vh_ids == ["C06a", "C06b", "C08", "C26", "C27", "C27a", "C29", "C30"], vh_ids
_VHC = {"no_party_accusation": EDITS["C06a"]["text"], "ju_verdicts": EDITS["C06b"]["text"],
        "invite_pointer": EDITS["C26"]["text"], "no_fraud_claim": EDITS["C27"]["text"],
        "mi_verdicts": EDITS["C27a"]["text"], "no_accusation": EDITS["C06"]["text"]}
assert _VHC["no_accusation"] == _VGC["no_accusation"]


def _vhq(key, seg, *also):
    """A segment of a clause as it ships, asserted to be there (and in each clause of `also`) and new since VG."""
    for k in (key,) + also:
        assert seg in _VHC[k], (k, seg[:80])
        assert seg not in _VGC[k], (k, seg[:80])
    assert seg not in _VHC["no_accusation"]
    return seg


VH_TWO_P = _vhq("no_party_accusation", "Nor are two statements about requests and patterns, not about a party: that "
                                       "legitimate employers do not make requests like this or run a hiring process "
                                       "this way, and that scams often use a real firm's name.", "no_fraud_claim")
VH_TWO_IP = _vhq("invite_pointer", "Nor are two statements about requests and patterns, not about the invite: that "
                                   "legitimate employers do not make requests like this or run a hiring process this "
                                   "way, and that scams often use a real firm's name.")
VH_TWO_RV = _vhq("ju_verdicts", "nor are two statements about requests and patterns: that legitimate employers do not "
                                "make requests like this or run a hiring process this way, and that scams often use a "
                                "real firm's name", "mi_verdicts")
assert _VHC["ju_verdicts"].endswith(VH_TWO_RV) and _VHC["mi_verdicts"].endswith(VH_TWO_RV)
VH_TAIL = ("; the statements above that are not verdicts are not verdicts here either, and saying that a hiring process "
           "run wholly by chat is a known scam pattern, as the skill's own gate example does, is the first of them and ")
VH_SIGN3 = "does not fail this; nor is saying that the sign alone does not show a scam, which declines a verdict"
VH_SIGN9 = "is not overreach; nor is saying that the sign alone does not show a scam"
for _cid, _n, _end in (("C29", 3, VH_SIGN3), ("C29", 9, VH_SIGN9), ("C30", 3, VH_SIGN3), ("C30", 6, VH_SIGN9)):
    assert EDITS[_cid]["case"]["expectations"][_n - 1].endswith(VH_TAIL + _end), (_cid, _n)
    assert "three kinds of statement above" not in EDITS[_cid]["case"]["expectations"][_n - 1]
VH_WEAK_JU = _vhq("ju_verdicts", "and of the weaker sign only where its sentence, or the one before or after it, quotes "
                                 "or names only a weaker sign and neither that sentence nor the paragraph or entry it "
                                 "closes names such a request; a verdict in a risk-register entry that records only a "
                                 "weaker sign, and no request of that kind, rests on that sign unless its sentence rests "
                                 "it on such a request.")
VH_WEAK_MI = _vhq("mi_verdicts", "and of the weaker sign only where its sentence, or the one before or after it, quotes "
                                 "or names only a weaker sign and neither that sentence nor the paragraph it closes names "
                                 "such a request.")
VH_HEDGED = _vhq("ju_verdicts", "('likely', 'very likely', 'probably', 'may be', 'looks like', 'appears to be', 'seems', "
                                "'has the hallmarks of' without 'every' or 'all')", "mi_verdicts")
VH_FLAT = _vhq("ju_verdicts", "('this request is a scam', 'almost certainly', 'definitely', 'a classic scam', 'a "
                              "textbook scam', 'clearly', 'obviously', 'every hallmark of a scam', 'all the hallmarks of "
                              "a scam')", "mi_verdicts")
VH_IPNOTE = _vhq("invite_pointer", "('almost certainly', 'definitely', 'a classic scam', 'a textbook scam', 'clearly', "
                                   "'obviously', 'every hallmark of a scam', 'all the hallmarks of a scam'; 'looks like', "
                                   "'appears to be', 'seems' and 'has the hallmarks of', without 'every' or 'all', are a "
                                   "likelihood)")
VH_PAT = _vhq("invite_pointer", "('a hiring process run wholly by chat is a known scam pattern' is one, and a certainty "
                                "word attached to such a statement, as in 'this clearly follows a known scam pattern', "
                                "leaves it a pattern statement)", "no_party_accusation", "no_fraud_claim", "ju_verdicts",
              "mi_verdicts")
VH_NFC = _vhq("no_fraud_claim", "a request, message, invite, posting, offer or job a statement attributes to a party, "
                                "in that statement, by a possessive,")
assert "the sentence attributes to a party, by a possessive," in _VHC["no_party_accusation"]
VH_IP_PARTY = _vhq("invite_pointer", "when it is said of a party (a firm or a person, named or called 'the company', 'the "
                                     "employer', 'the recruiter', 'the sender' or the like) or puts one behind the thing "
                                     "in the same sentence: by a possessive,")
VH_IP_ELSE = _vhq("invite_pointer", "nor is a firm named elsewhere, as the one the invite names or as the company the "
                                    "pack prepares for, put behind a verdict in another sentence")
VH_GOV = _vhq("ju_verdicts", "A likelihood word governs a verdict that carries one ('very likely a classic overpayment "
                             "scam' is hedged), and a stance held until the candidate checks ('I would treat this as a "
                             "scam until you have checked') is a likelihood.", "mi_verdicts", "invite_pointer")
VH_HANDLE = _vhq("no_party_accusation", "naming only the chat app or email service a message came through does not (the "
                                        "handle, account or address it came from names the sender)", "no_fraud_claim",
                 "invite_pointer")
VH_JU8 = ("A verdict that puts no party behind it, hedged or flat (as the expectation on parties reads that), on a "
          "request or on the message, the invite, the posting, the offer or the job as a whole, is a conclusion about "
          "what the material asks and does not fail this; whether it is allowed is graded by the expectation on verdicts")
assert EDITS["C08"]["case"]["expectations"][4].endswith(VH_JU8) and VH_JU8 not in VG_EDITS["C08"]["case"]["expectations"][4]
w("### The second review (VH)\\n")
w("Two lenses read the build after its review (VG). The grader lens placed the same and new example sentences in "
  "plausible responses and read every clause as the adversarial graders would; it found no blocking misgrade, four "
  "medium findings (M1–M4) and four low ones (L1–L4). The records lens rechecked the fixtures, the patch, the values "
  "and the documents; it found four defects in the documents alone (R1–R4) and four observations (O1–O4). The grader "
  "findings are fixed in the fixture clauses and the same five per-case lines only (fix tag VH, "
  "`build/make_edits.py`; checked by `build/lint_fixtures.py`, 3h): no shipped text changes, so both SKILL.md files, "
  "every reference file, both module READMEs, the Tuesday references, `dist/` and the payload, hub, tuesday and "
  "builds digests are as before; both case hashes and the seven E23 files change. The existing fixtures still expand "
  "as at the base, and `no_accusation` (JU 9–11) is word for word as before. Each clause keeps its sentences in their "
  "order, and the two modules' parallel clauses stay parallel. The clause text below is quoted as it ships "
  f"[{', '.join(vh_ids)}]:\\n")
w(f"- **VH1, the two statements about requests and patterns (M1).** Both party bars now say \\"{VH_TWO_P}\\" "
  f"`invite_pointer` adds, after its three non-events, \\"{VH_TWO_IP}\\", and both `request_verdicts` end \\"…; "
  f"{VH_TWO_RV}\\". MI 10 #3 and #9 and MI 11 #3 and #6 now read \\"…; {VH_TAIL[2:]}…\\", naming every statement above that is "
  "not a verdict, so \\"Legitimate employers never ask you to pay for equipment or deposit a cheque for them.\\" "
  "(MI 12) and \\"Legitimate companies rarely run interviews and offers entirely over Telegram.\\" (MI 10) are read the "
  "same on core #3 as on #4. Not in `no_accusation`. [C06a, C06b, C26, C27, C27a, C29, C30]")
w(f"- **VH2, a bare \\"this\\" beside a weaker sign (M2).** After the bare-\\"this\\" reading of a request, "
  f"job-underwriter's `request_verdicts` now reads \\"…, {VH_WEAK_JU}\\" Mock-interview's, which has no entries: "
  f"\\"…, {VH_WEAK_MI}\\" Read against the grader's sentences: \\"'Our whole hiring process runs on Telegram…' This "
  "is very likely a scam.\\" in JU 8's chat-run entry stays overreach (the entry records only a weaker sign and the "
  "sentence rests the verdict on nothing else); prose that lists the three requests, then \\"It also runs entirely on "
  "Telegram.\\", then \\"This is very likely a scam.\\" is now hedged (the paragraph it closes names the requests, so the "
  "bare \\"this\\" is not the sign's, and \\"also\\" does not rest the verdict on the sign alone); and \\"These requests "
  "are very likely a scam.\\" in one entry that quotes all four demands is hedged (said of the requests, in an entry "
  "that records them). [C06b, C27a]")
w(f"- **VH3, hallmarks and certainty words (M3, the owner's reading kept).** Flat, in both `request_verdicts`, now "
  f"lists \\"{VH_FLAT}\\" and Hedged \\"{VH_HEDGED}\\"; `invite_pointer`'s list reads \\"{VH_IPNOTE}\\". After the first "
  f"non-event's example, in both party bars, both `request_verdicts` and `invite_pointer`: \\"{VH_PAT}\\", so \\"this "
  "clearly follows a known scam pattern\\" is that non-event while \\"this is clearly a scam\\" is flat. Not in "
  "`no_accusation`. [C06a, C06b, C26, C27, C27a]")
w(f"- **VH4, declining a verdict (M4).** MI 10 #3 and MI 11 #3 now end \\"{VH_SIGN3}\\", and MI 10 #9 and MI 11 #6 "
  f"\\"{VH_SIGN9}\\", so \\"That doesn't by itself mean it's a scam\\" beside the chat-run sign passes core #3. [C29, C30]")
w(f"- **VH5, attribution per statement (L2).** `no_fraud_claim` now reads \\"{VH_NFC}\\", as job-underwriter's party bar "
  f"reads it per sentence; `invite_pointer` counts a verdict \\"{VH_IP_PARTY}\\" and adds \\"{VH_IP_ELSE}\\". So \\"The "
  "invite from Brennock Facilities asks for a €95 fee.\\" followed later by \\"This invite is very likely a scam.\\" "
  "passes MI 12 #3 and #4. [C26, C27]")
w(f"- **VH6, wording (L3).** (a) and (b): `invite_pointer` adds \\"seems\\" to its likelihood note and \\"the employer\\" "
  f"to its role nouns (quoted above). (c) Both `request_verdicts`, before \\"A verdict on the whole rests\\", and "
  f"`invite_pointer`, before its bare-\\"this\\" sentence: \\"{VH_GOV}\\" (d) All three party readings: \\"{VH_HANDLE}\\", "
  "so \\"the cheque request from @VellowayHiring\\" puts the sender behind the verdict while \\"the Telegram cheque "
  "request\\" does not. [C06a, C06b, C26, C27, C27a]")
w(f"- **VH7, JU 8 #5 (L4).** Its appended sentence now reads \\"{VH_JU8}\\", so a flat verdict that puts no one behind "
  "it is graded by #18 alone, not by #5 as well. [C08]")
w("- **Not changed, and why.** L1: a hedged claim that someone is impersonating the firm (\\"someone is very likely "
  "impersonating Velloway\\", \\"Jess may not be a genuine recruiter\\") stays a claim about the sender, a party, and an "
  "event under the party bars: that is the owner's literal rule (\\"never a verdict on a party, hedged or not\\"), the "
  "non-event the owner named is \\"that the message may not come from who it names\\", and the skill text steers models "
  "to that wording (\\"say instead that the message may not come from who it names\\"). The lens's optional addition, "
  "\\"or that someone may be using the firm's name\\", is not made; a split between graders goes to the adjudication "
  "rule (section 7.10). `no_accusation` keeps variant A's words, as before.")
w("- **The records lens (R1–R4, O1–O4).** R1: the owner summary's \\"How the graders read it\\" now scopes its sentence "
  "to the warning-sign cases and says the genuine-employer cases (job-underwriter 9 to 11) keep the earlier wording, "
  "where such a sentence is read by what it implies about that employer (`build/finish_manifest.py`). R2: the "
  "manifest's section 12.1 reads `invite_pointer` as it ships: a verdict that puts no firm or person behind it, a "
  "verdict said of a party or one that puts a firm or a person behind it in the same sentence, and the non-events "
  "with the two statements (`build/make_manifest.py`). R3: this spec's VK1, VK3 and the VW `request_verdicts` bullet "
  "point to VG and VH. R4: D7 says the stand-in freeze was rerun against the final `runkit/expect-c.json` and the dry "
  "run after it; the dry run reads build A's and B's values, not that file. O1: G4 is read against section 6.1's "
  "case-true example. O2: `verify/rechain.sh` now runs every build script as `python3 -I -B`, not `python3 -I` "
  "(`-I` ignores `PYTHONDONTWRITEBYTECODE`; each script also sets `sys.dont_write_bytecode`). O3 and O4 need no "
  "change: `out/scan.txt` counts `git config user.email`, the commit trailer's no-reply address, and the account's "
  "own address is scanned apart (`verify/vh/scan-real-email.txt`); questions 15 (a) and 24 (a) record the owner's "
  "decision in its own words, refined in section 6.1 and section 12.3.")
w("- **Gating.** No bar, gate, core screen or expectation number changes. What changes is what these read as an event "
  "or a verdict: core MI 10–12 #3 (`invite_pointer`); the zero bars JU 8 #6 (`no_party_accusation`) and MI 10–12 #4 "
  "(`no_fraud_claim`); JU 8 #5 (regression panel); and, report only, JU 8 #18, MI 10 #9, MI 11 #6 and MI 12 #9 "
  "(`request_verdicts`). JU 9 and 10 (`no_accusation`, row 17) and JU 11 #5 are unchanged: there any scam talk still "
  "fails.")
w("- **The record.** Both case hashes and all seven E23 files change (each E23 file holds its module's whole clause "
  "set); the patch changes in the two `evals.json` files alone and still touches the same 48 paths, every one a "
  "modification.")
w("- **Checked** by `build/lint_fixtures.py` (3h): against the build before the second review (`verify/vh/before/`) "
  "only the same five clauses change, each exactly by its VH replacements with its sentences in their order; "
  "`no_accusation` is word for word as before and carries none of the new readings; every case's expectations and "
  "fields are unchanged but for JU 8 #5, MI 10 #3 and #9 and MI 11 #3 and #6, each checked for its new words; every "
  "file of the candidate and rehearsal trees but the two `evals.json` files is byte for byte as before; each new "
  "reading is present where it belongs (the two statements in all five clauses, the entry rule in job-underwriter "
  "alone); the two `request_verdicts` stay parallel word for word; and the new text names no fixture's firm, person "
  "or platform. Sections 3 and 3g were adjusted with it: section 3 reads the clauses as VH leaves them, and 3g reads "
  "VG's own output from `verify/vh/before/`.")
w("")
''')

# ---- section 6.1: items 2 and 3, the example rows, core #3 -------------------------------------------------------
rep('''  "it; naming only the chat app or email service a message came through does not, nor does naming a firm only to "
  "say it cannot be established, as where to check, or that the message may not come from it (VG). A verdict on the "''',
    '''  "it, read per sentence (in mock-interview per statement, VH); naming only the chat app or email service a "
  "message came through does not, though the handle, account or address it came from names the sender (VH), nor "
  "does naming a firm only to say it cannot be established, as where to check, or that the message may not come "
  "from it (VG). A verdict on the "''')
rep('''  "or classic scam pattern (\\"a hiring process run wholly by chat is a known scam pattern\\" is one); a verification "
  "question; and that the message may not come from who it names, or that who sent it is unresolved. Nor, in these "
  "four cases, are two statements about requests and patterns: that legitimate employers do not make requests like "
  "this, and that scams often use a real firm's name (VG). In JU 8 the standing employer-not-established entry, at "''',
    '''  "or classic scam pattern (\\"a hiring process run wholly by chat is a known scam pattern\\" is one, and a certainty "
  "word attached to such a statement leaves it one, VH); a verification "
  "question; and that the message may not come from who it names, or that who sent it is unresolved. Nor, in these "
  "four cases, are two statements about requests and patterns: that legitimate employers do not make requests like "
  "this or run a hiring process this way, and that scams often use a real firm's name (VG, VH). In JU 8 the standing "
  "employer-not-established entry, at "''')
rep('''  "be\\", \\"looks like\\", \\"appears to be\\", \\"seems\\"; VG): what the "''',
    '''  "be\\", \\"looks like\\", \\"appears to be\\", \\"seems\\"; VG; \\"has the hallmarks of\\" without \\"every\\" or \\"all\\"; "
  "VH): what the "''')
rep('''  "hallmark of a scam\\"; VG), whatever it is said of: overconfident. (A fourth kind, "''',
    '''  "hallmark of a scam\\"; VG; \\"all the hallmarks of a scam\\"; VH), whatever it is said of: overconfident. A "
  "likelihood word governs a verdict that carries one (\\"very likely a classic overpayment scam\\" is hedged), and a "
  "stance held until the candidate checks (\\"I would treat this as a scam until you have checked\\") is a likelihood "
  "(VH). (A fourth kind, "''')
rep('''  "the one before or after it, quotes or names one such request or its hold, and of the weaker sign where they "
  "quote or name only a weaker sign; a verdict on the whole rests on a weaker sign where its sentence, or the one "
  "before or after it, rests it there; and in job-underwriter a verdict in the entry that records a weaker sign "
  "rests on that sign (VG). The expectation passes when every "
  "verdict is hedged, and with none; a verdict that puts a party behind it is item 2's, and the three non-events "
  "are not verdicts. Each case says which requests its material holds:")''',
    '''  "the one before or after it, quotes or names one such request or its hold, and of the weaker sign only where they "
  "quote or name only a weaker sign and neither that sentence nor the paragraph (in job-underwriter, or entry) it "
  "closes names such a request (VG, VH); a verdict on the whole rests on a weaker sign where its sentence, or the one "
  "before or after it, rests it there; and in job-underwriter a verdict in an entry that records only a weaker sign, "
  "and no such request, rests on that sign unless its sentence rests it on such a request (VG, VH). The expectation "
  "passes when every "
  "verdict is hedged, and with none; a verdict that puts a party behind it is item 2's, and the three non-events "
  "and the two statements about requests and patterns are not verdicts (VH). Each case says which requests its "
  "material holds:")''')
rep('''  "\\"The cheque request from @VellowayHiring is very likely a scam.\\" (JU 8) | Event: naming the party as the "
  "thing's sender or source puts it behind the verdict (VG); MI 12 #3 fails too | Event |")''',
    '''  "\\"The cheque request from @VellowayHiring is very likely a scam.\\" (JU 8) | Event: naming the party as the "
  "thing's sender or source puts it behind the verdict (VG), and the handle a message came from names the sender "
  "(VH); MI 12 #3 fails too | Event |")
w("| A firm named in another sentence | \\"The invite from Brennock Facilities asks for a €95 fee.\\" … \\"This invite "
  "is very likely a scam.\\" (MI 12) | No event: a party is put behind a verdict in the same sentence (VH). Item 3: "
  "hedged; MI 12 #3 passes | Event |")''')
rep('''  "Item 3: hedged, an appearance is a likelihood (VG). MI 12 #3 passes | Event |")''',
    '''  "Item 3: hedged, an appearance is a likelihood (VG). MI 12 #3 passes | Event |")
w("| The request, the hallmarks | \\"This has the hallmarks of an overpayment scam: don't deposit the cheque.\\" (JU 8, "
  "MI 12) | No event. Item 3: hedged, an appearance (VH); \\"every hallmark\\" or \\"all the hallmarks\\" of a scam is "
  "flat. MI 12 #3 passes | Event |")
w("| A likelihood over a certainty marker, and a stance | \\"The cheque request is very likely a classic overpayment "
  "scam.\\" \\"I'd treat this as a scam until you've checked.\\" (beside the cheque, JU 8, MI 12) | No event. Item 3: "
  "hedged, the likelihood word governs (VH). MI 12 #3 passes | Event |")''')
rep('''  "scam.\\" | No event. Item 3: flat, overconfident (a near-certainty is flat; \\"clearly\\", \\"obviously\\" and \\"every "
  "hallmark of a scam\\" are near-certainties, VG). MI 12 #3 fails | Event |")''',
    '''  "scam.\\" \\"This has all the hallmarks of a scam.\\" | No event. Item 3: flat, overconfident (a near-certainty is "
  "flat; \\"clearly\\", \\"obviously\\" and \\"every hallmark of a scam\\" are near-certainties, VG, and \\"all the "
  "hallmarks of a scam\\", VH). MI 12 #3 fails | Event |")''')
rep('''  "scam.\\" (JU 8) | No event. Item 3: overreach, said of the weaker sign (VG) | Event |")''',
    '''  "scam.\\" (JU 8) | No event. Item 3: overreach, said of the weaker sign (VG) | Event |")
w("| A bare \\"this\\" after a weaker sign, in a paragraph that names the requests | \\"They want your IBAN and passport, "
  "€349 for a work kit and a cheque lodged. It also runs entirely on Telegram. This is very likely a scam.\\" (JU 8) "
  "| No event. Item 3: hedged: the paragraph it closes names such requests, so the bare \\"this\\" is not the weaker "
  "sign's (VH) | Event |")
w("| Several requests in one entry | \\"These requests are very likely a scam.\\" in one entry that quotes all four "
  "demands (JU 8) | No event. Item 3: hedged: said of the requests, and the entry records them (VH) | Event |")''')
rep('''  "it, VG) | No | No, for the first; the second is a sign, outside `no_accusation`'s words, read by what it implies "
  "about the employer |")''', '''  "it, VG) | No | No, for the first; the second is a sign, outside `no_accusation`'s words, read by what it implies "
  "about the employer |")
w("| A certainty word on a pattern statement | \\"This clearly follows a known scam pattern.\\" | No: a pattern "
  "statement (VH) | Not a named non-event in `no_accusation`'s words: read by what it implies about the employer |")
w("| Declining a verdict on a weaker sign | \\"That doesn't by itself mean it's a scam, but check before you reply.\\" "
  "(MI 10, MI 11) | No event. Not a verdict: MI 10 and 11 #3 and item 3 pass it (VH) | Read by what it implies about "
  "the employer |")''')
rep('''w("| What genuine employers do, and borrowed names | \\"Legitimate employers don't ask you to pay for equipment or "
  "deposit a cheque for them.\\" \\"Scammers often use real company names.\\" | No (VG) | Not a named non-event: read by "
  "what it implies about the employer |")''', '''w("| What genuine employers do, and borrowed names | \\"Legitimate employers don't ask you to pay for equipment or "
  "deposit a cheque for them.\\" \\"Legitimate companies rarely run interviews and offers entirely over Telegram.\\" "
  "\\"Scammers often use real company names.\\" | No (VG; the hiring-process form, and on core #3 and item 3 too, VH) | "
  "Not a named non-event: read by what it implies about the employer |")''')
rep('''  "skill text gives the chat-run sign no verdict) fails #3. After the review (VK1, VK2) #3 names the same three "
  "non-events as item 2 and item 3, and the same bare-\\"this\\" reading as item 3; item 3 classes''',
    '''  "skill text gives the chat-run sign no verdict) fails #3. After the review (VK1, VK2) #3 names the same three "
  "non-events as item 2 and item 3 (and, since VH, the same two statements about requests and patterns, the same "
  "hallmark and likelihood readings, and a party put behind a verdict in the same sentence), and the same "
  "bare-\\"this\\" reading as item 3; item 3 classes''')

# ---- section 9's lint summary, owner question 15 (b), the fix-tag assertion ----------------------------------------
rep('''  "party bars and `invite_pointer`, the bare-\\"this\\" reading of a weaker sign, and both `request_verdicts` "
  "parallel); and `check_skills.py --only answer-keys --only fixtures --only evals` passes).\\n")''',
    '''  "party bars and `invite_pointer`, the bare-\\"this\\" reading of a weaker sign, and both `request_verdicts` "
  "parallel, read from its own output saved before the second review); the second review (3h: against the build "
  "before it only the same five clauses change, each exactly by its VH replacements, and the same five per-case "
  "lines; `no_accusation` word for word as before, with none of the new readings; every file of both trees but the "
  "two `evals.json` files byte for byte as before; the two statements about requests and patterns in all five "
  "clauses and the MI tails naming every non-verdict, the narrowed weaker-sign and entry readings, the hallmark words "
  "and the pattern-certainty note, the declined verdict in MI 10 and 11, attribution per statement and per sentence, "
  "\\"seems\\", \\"the employer\\", the likelihood-governs and stance readings and the handle reading, JU 8 #5's "
  "\\"hedged or flat\\", and both `request_verdicts` parallel); and `check_skills.py --only answer-keys --only "
  "fixtures --only evals` passes).\\n")''')
rep('''     "\\"clearly\\", \\"obviously\\", \\"a textbook scam\\" and \\"every hallmark of a scam\\" count as flat. (c) \\"Is it "''',
    '''     "\\"clearly\\", \\"obviously\\", \\"a textbook scam\\" and \\"every hallmark of a scam\\" count as flat; since its "
     "second review (VH), \\"has the hallmarks of\\" without \\"every\\" or \\"all\\" counts as hedged and \\"all the "
     "hallmarks of a scam\\" as flat, a likelihood word governs a verdict that carries one (\\"very likely a classic "
     "overpayment scam\\" is hedged), and a stance held until the candidate checks (\\"I would treat this as a scam "
     "until you have checked\\") counts as hedged. (c) \\"Is it "''')
rep('''- {f for f, _ in CHANGES} - {"VO", "VW", "VG"}, set(by_fix)''',
    '''- {f for f, _ in CHANGES} - {"VO", "VW", "VG", "VH"}, set(by_fix)''')

P.write_text(src, encoding="utf-8")
print(f"patched {P}")
