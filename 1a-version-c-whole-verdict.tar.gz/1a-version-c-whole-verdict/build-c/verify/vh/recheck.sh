#!/bin/bash
# (second review, VH; as verify/vg/recheck.sh) Re-check the 1,220 saved fix-round runs on the rebuilt candidate (B/tree) with the harness's own check_run, the way
# review-resolve/recheck/ was made: review-spill/recheck2.py over every fixround/round/<m>/<arm>/part-* entry, into
# review-resolve/recheck/<m>/<arm>/<part>; then compare every checks file with the base's (review-spill/recheck/head).
set -uo pipefail
S=/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad
B=$S/l1a/build-c
export PYTHONDONTWRITEBYTECODE=1
NEWPATH=""; IFS=: read -ra parts <<< "$PATH"
for p in "${parts[@]}"; do [ -e "$p/claude" ] || NEWPATH="${NEWPATH:+$NEWPATH:}$p"; done; export PATH="$NEWPATH"
command -v claude >/dev/null && { echo "claude on PATH"; exit 9; }
OUT=$B/review-resolve/recheck
[ -d "$OUT" ] && { rm -rf "$B/verify/vh/before/recheck-prev"; mv "$OUT" "$B/verify/vh/before/recheck-prev"; }
[ -f "$B/review-resolve/recheck.log" ] && mv "$B/review-resolve/recheck.log" "$B/verify/vh/before/recheck-prev.log"
mkdir -p "$OUT"
for src in "$S"/fixround/round/{haiku,opus,sonnet}/{alone,tuesday}/part-*; do
  rel=${src#$S/fixround/round/}
  python3 -I -B "$B/review-spill/recheck2.py" "$B/tree" "$src" "$OUT/$rel"
done > "$B/review-resolve/recheck.log" 2>&1
echo "recheck2 exit status of the loop: $?"
grep -c "runs re-checked" "$B/review-resolve/recheck.log"
python3 -I -B - "$OUT" "$B/review-spill/recheck/head" <<'PY'
import re, sys
from pathlib import Path
a, b = Path(sys.argv[1]), Path(sys.argv[2])
fa = {p.relative_to(a).as_posix(): p for p in a.rglob("*.checks.json")}
fb = {p.relative_to(b).as_posix(): p for p in b.rglob("*.checks.json")}
diff = [k for k in sorted(set(fa) & set(fb)) if fa[k].read_bytes() != fb[k].read_bytes()]
print(f"checks files: {len(fa)} rebuilt candidate, {len(fb)} base; only in candidate {len(set(fa)-set(fb))}, "
      f"only in base {len(set(fb)-set(fa))}; differing {len(diff)}")
log = (a.parent / "recheck.log").read_text()
runs = sum(int(m) for m in re.findall(r": (\d+) runs re-checked", log))
inv = sum(int(m) for m in re.findall(r"\((\d+) harness-invalid\)", log))
print(f"runs re-checked {runs}, harness-invalid {inv}")
for k in diff[:10]: print("  differs:", k)
PY
find "$B" -name __pycache__ -type d -prune -exec rm -rf {} + 2>/dev/null
find "$S/fixround/round" -name __pycache__ -newer "$B/review-resolve/recheck.log" -type d 2>/dev/null | head
