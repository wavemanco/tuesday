"""p_manifest.py: fix tag VH and records fix R2 in build/make_manifest.py: section 12.1 reads invite_pointer as it
ships (R2, with the second review), and section 12.3 and question 24 (b) give the second review's readings in plain
words, owner-facing, with no fix tags. Exact replacements, each asserted to occur once. Run once."""
import sys
from pathlib import Path

sys.dont_write_bytecode = True
P = Path(__file__).resolve().parents[2] / "build" / "make_manifest.py"
src = P.read_text(encoding="utf-8")
assert "has the hallmarks of" not in src, "already patched"


def rep(old, new):
    global src
    n = src.count(old)
    assert n == 1, (n, old[:90])
    src = src.replace(old, new, 1)


rep('''as a thing's sender or source puts it behind the verdict. Section 18's meter lines quote the latest reading on file, the
same file make_spec.py and finish_manifest.py read (build/meter_latest.py, records fix D6).
"""''', '''as a thing's sender or source puts it behind the verdict. Section 18's meter lines quote the latest reading on file, the
same file make_spec.py and finish_manifest.py read (build/meter_latest.py, records fix D6).
The second review (fix tag VH) is written into section 12.1's reading of invite_pointer (records fix R2), section 12.3
and question 24 (b), in plain words: "has the hallmarks of" is hedged and "all the hallmarks of a scam" flat; a
likelihood word governs; a bare "this" is a weaker sign's only where its paragraph or entry names no qualifying
request; what legitimate employers do (a hiring process run this way too) and declining a verdict on a weaker sign are
not verdicts; a party is put behind a verdict in the same sentence, and the handle a message came from names the sender.
"""''')

# R2 (with VH): section 12.1's reading of invite_pointer, as it ships
rep('''    "offer, invite or message as a whole, that names no firm or person is part of the warning (owner, 17 November); a flat verdict or a "
    "near-certainty, a verdict that names a firm or a person, and in 10 and 11 any verdict, fail it; the three "
    "non-events never do.")''', '''    "offer, invite or message as a whole, that puts no firm or person behind it is part of the warning (owner, 17 "
    "November); a flat verdict or a near-certainty, a verdict said of a party or one that puts a firm or a person "
    "behind it in the same sentence (a name, a possessive, role nouns such as \\"the company's\\" included, or the party "
    "named as the thing's sender or source; not a firm named only to say it cannot be established), and in 10 and 11 "
    "any verdict, fail it; the three non-events and the two statements about requests and patterns never do.")''')

# 12.3, item 2: attribution in the same sentence, the handle, the pattern note, the hiring-process form
rep('''    "a scam\\"), puts that party behind it; naming only the chat app or email service it came through does not, nor "
    "does naming a firm only to say it cannot be established, as where to check, or that the message may not come "
    "from it. A verdict on the request,''', '''    "a scam\\"), puts that party behind it, in the same sentence (in mock-interview, the same statement); naming only "
    "the chat app or email service it came through does not, though the handle, account or address it came from "
    "names the sender, nor does naming a firm only to say it cannot be established, as where to check, or that the "
    "message may not come from it. A verdict on the request,''')
rep('''    "known or classic scam pattern (\\"a hiring process run wholly by chat is a known scam pattern\\" is one); that "
    "legitimate employers do not make requests like this, or that scams often use a real firm's name; "''',
    '''    "known or classic scam pattern (\\"a hiring process run wholly by chat is a known scam pattern\\" is one, and "
    "\\"this clearly follows a known scam pattern\\" is still one); that legitimate employers do not make requests like "
    "this or run a hiring process this way, or that scams often use a real firm's name; "''')

# 12.3, item 3: hallmarks, a likelihood word governing, the stance, the narrowed weaker-sign reading
rep('''    "appearance (\\"looks like\\", \\"appears to be\\" and \\"seems\\" read as likelihoods), said of that request or of the "''',
    '''    "appearance (\\"looks like\\", \\"appears to be\\", \\"seems\\" and \\"has the hallmarks of\\" read as likelihoods), "
    "said of that request or of the "''')
rep('''    "\\"every hallmark of a scam\\") or "''', '''    "\\"every hallmark of a scam\\", \\"all the hallmarks of a scam\\") or "''')
rep('''    "process and its postmail address). A bare \\"this\\" or \\"it\\" next to one such request, its quote or its hold is "
    "that request's, and one next to a weaker sign alone is that sign's; in job-underwriter a verdict in the entry "
    "that records a weaker sign rests on it. A verdict on the whole rests on such a request wherever the case makes "
    "one, unless its sentence, or the one before or after it, rests it on a weaker sign alone. A pattern statement "
    "about requests or signs (\\"requests like this are a classic overpayment-scam pattern\\") is not a verdict. The "''',
    '''    "process and its postmail address). A likelihood word governs a verdict that carries one (\\"very likely a "
    "classic overpayment scam\\" is hedged), and \\"I would treat this as a scam until you have checked\\" is a "
    "likelihood. A bare \\"this\\" or \\"it\\" next to one such request, its quote or its hold is that request's, and "
    "one next to a weaker sign alone is that sign's only where neither its sentence nor the paragraph (in "
    "job-underwriter, or entry) it closes names such a request; in job-underwriter a verdict in an entry that records "
    "only a weaker sign rests on it unless its sentence rests it on such a request. A verdict on the whole rests on "
    "such a request wherever the case makes one, unless its sentence, or the one before or after it, rests it on a "
    "weaker sign alone. A pattern statement about requests or signs (\\"requests like this are a classic "
    "overpayment-scam pattern\\"), and the two statements about what legitimate employers do and borrowed names, are "
    "not verdicts. The "''')

# 12.3, the paragraph on #3 and the examples
rep('''    "template's own gate sentence, \\"A hiring process run wholly by chat is a known scam pattern.\\", passes.\\n\\n"''',
    '''    "template's own gate sentence, \\"A hiring process run wholly by chat is a known scam pattern.\\", passes, and so "
    "does saying that the chat-run sign alone does not show a scam.\\n\\n"''')
rep('''    "not an event, and hedged in item 3. \\"This looks like a scam: don't deposit the cheque.\\" is hedged in item 3; "
    "\\"This is clearly a scam\\" is flat.''', '''    "not an event, and hedged in item 3. \\"This looks like a scam: don't deposit the cheque.\\" and \\"This has the "
    "hallmarks of a scam\\" are hedged in item 3; \\"This is clearly a scam\\" and \\"This has all the hallmarks of a "
    "scam\\" are flat. Prose that names the three requests, then \\"It also runs entirely on Telegram. This is very "
    "likely a scam.\\", is hedged: the paragraph names the requests.''')

# question 24 (b)
rep('''    "\\"appears to be\\", \\"seems\\") also counts as hedged, and \\"clearly\\", \\"obviously\\", \\"a textbook scam\\" and "
    "\\"every hallmark of a scam\\" count as flat. (c) The answer''', '''    "\\"appears to be\\", \\"seems\\") also counts as hedged, and \\"clearly\\", \\"obviously\\", \\"a textbook scam\\" and "
    "\\"every hallmark of a scam\\" count as flat. After a second check, \\"has the hallmarks of\\" also counts as "
    "hedged and \\"all the hallmarks of a scam\\" as flat; a likelihood word governs a verdict that carries one (\\"very "
    "likely a classic overpayment scam\\" is hedged); and \\"I would treat this as a scam until you have checked\\" "
    "counts as hedged. (c) The answer''')

P.write_text(src, encoding="utf-8")
print(f"patched {P}")
