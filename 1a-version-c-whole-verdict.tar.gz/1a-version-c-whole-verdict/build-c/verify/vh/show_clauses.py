"""Print the VH-touched clauses and per-case lines from an edits.json (argv[1])."""
import json, sys
d = json.load(open(sys.argv[1], encoding="utf-8"))
E = {e["id"]: e for ph in d["phases"] for e in ph["edits"]}
for k in ("C06a", "C06b", "C26", "C27", "C27a"):
    print(f"== {k} {E[k]['name']} fixes={E[k]['fixes']}\n{E[k]['text']}\n")
print("== JU 8 #5\n" + E["C08"]["case"]["expectations"][4] + "\n")
for c, n in (("C29", 3), ("C29", 9), ("C30", 3), ("C30", 6)):
    print(f"== {c} #{n}\n{E[c]['case']['expectations'][n - 1]}\n")
print("fixes C08", E["C08"]["fixes"], "C29", E["C29"]["fixes"], "C30", E["C30"]["fixes"], "C31", E["C31"]["fixes"])
