"""Name the files under argv[1] that hold the git-config commit address (from SCAN_EMAIL, never printed), counts only.
Zip and .skill members are read as scan.py reads them."""
import io, os, sys, zipfile
from pathlib import Path
sys.dont_write_bytecode = True
e = os.environ["SCAN_EMAIL"].strip().lower(); forms = {e, e.replace("@", "%40"), e.replace("@", " at ")}
def walk(name, b):
    if b[:4] == b"PK\x03\x04":
        try:
            with zipfile.ZipFile(io.BytesIO(b)) as z:
                for m in z.namelist(): walk(f"{name}!{m}", z.read(m))
            return
        except zipfile.BadZipFile: pass
    t = b.decode("utf-8", "replace").lower(); c = sum(t.count(f) for f in forms)
    if c: print(f"  {c} in {name}")
for p in sorted(Path(sys.argv[1]).rglob("*")):
    if p.is_file(): walk(str(p), p.read_bytes())
