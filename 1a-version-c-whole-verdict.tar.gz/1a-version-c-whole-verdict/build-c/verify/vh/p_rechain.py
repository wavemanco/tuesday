"""p_rechain.py: records observation O2 in verify/rechain.sh: every build script runs as `python3 -I -B` (it ran as
`python3 -I`, and -I ignores PYTHONDONTWRITEBYTECODE; each script also sets sys.dont_write_bytecode). One comment line
records the change. Run once."""
import re
import sys
from pathlib import Path

sys.dont_write_bytecode = True
P = Path(__file__).resolve().parents[1] / "rechain.sh"
src = P.read_text(encoding="utf-8")
assert "O2" not in src, "already patched"
n_before = len(re.findall(r"python3 -I (?!-B)", src))
src = re.sub(r"python3 -I (?!-B)", "python3 -I -B ", src)
old = "# rechain.sh: rerun version C's documented regeneration order after a generator edit, offline, claude off PATH.\n"
assert src.count(old) == 1
src = src.replace(old, old + "# Every Python step runs as python3 -I -B (records observation O2, second review): -I alone ignores\n"
                             "# PYTHONDONTWRITEBYTECODE, so -B keeps bytecode off whatever a script sets itself.\n", 1)
assert not re.findall(r"python3 -I (?!-B)", src)
P.write_text(src, encoding="utf-8")
print(f"patched {P}: {n_before} python3 -I calls now python3 -I -B")
