"""p_make_edits.py: apply fix tag VH (the second review: the grader lens and the records lens on VG) to
build/make_edits.py, by exact replacements, each asserted to occur once. Run once; refuses a second run."""
import sys
from pathlib import Path

sys.dont_write_bytecode = True
P = Path(__file__).resolve().parents[2] / "build" / "make_edits.py"
src = P.read_text(encoding="utf-8")
assert "VH_PATTERN" not in src, "already patched"


def rep(old, new):
    global src
    n = src.count(old)
    assert n == 1, (n, old[:90])
    src = src.replace(old, new, 1)


# 1. docstring: one paragraph for VH
rep('''established; and a bare 'this' beside a weaker sign alone is that sign's. Every edit it touches carries the fix tag "VG".
''', '''established; and a bare 'this' beside a weaker sign alone is that sign's. Every edit it touches carries the fix tag "VG".
The second review (VH, the grader lens and the records lens on VG) again changes the clauses and the same per-case lines
only: the two statements about requests and patterns are no verdict either, and cover a hiring process run this way; a
bare 'this' is a weaker sign's only where its paragraph or entry names no qualifying request; 'all the hallmarks of a
scam' is a near-certainty and 'has the hallmarks of' an appearance; a certainty word leaves a pattern statement one; a
likelihood word governs a verdict that carries one; attribution is read per statement; and the handle a message came
from names the sender. Every edit it touches carries the fix tag "VH".
''')

# 2. the VH block, after the VG block
rep('''assert VG_PATTERN_OLD in NO_ACCUSATION and VG_PATTERN not in NO_ACCUSATION
''', '''assert VG_PATTERN_OLD in NO_ACCUSATION and VG_PATTERN not in NO_ACCUSATION

# ---- the second review (VH: the grader lens and the records lens on VG), in the clauses and per-case lines only -----
# VH1 (M1): the two statements about requests and patterns are no verdict in invite_pointer and both request_verdicts
# either, and cover a hiring process run this way as well as requests (in the party bars too); not no_accusation.
# VH2 (M2): a bare 'this' or 'it' is the weaker sign's only where neither its sentence nor the paragraph (in
# job-underwriter, or entry) it closes names a qualifying request; a verdict in an entry rests on a weaker sign only
# where the entry records no such request and its sentence does not rest it on one. VH3 (M3, the owner's reading kept):
# 'every hallmark of a scam' and 'all the hallmarks of a scam' are near-certainties, 'has the hallmarks of' alone an
# appearance; a certainty word attached to a pattern statement leaves it a pattern statement. VH5 (L2): attribution is
# read per statement in no_fraud_claim and per sentence in invite_pointer, as job-underwriter's party bar reads it.
# VH6 (L3): 'seems' and 'the employer' in invite_pointer; a likelihood word governs a verdict that carries one, and a
# stance held until the candidate checks is a likelihood; the handle, account or address a message came from names the
# sender. VH4 (M4) and VH7 (L4) are per-case lines, below. Not changed: L1 (a hedged claim that someone is
# impersonating the firm stays a claim about the sender, an event; the skill steers to "may not come from who it names").
VH_PATTERN = VG_PATTERN[:-1] + (", and a certainty word attached to such a statement, as in 'this clearly follows a "
                                "known scam pattern', leaves it a pattern statement)")
VH_TWO_OLD = "that legitimate employers do not make requests like this, and that scams often use a real firm's name"
VH_TWO = ("that legitimate employers do not make requests like this or run a hiring process this way, and that scams "
          "often use a real firm's name")
VH_HANDLE_OLD = "naming only the chat app or email service a message came through does not, nor does naming a firm only"
VH_HANDLE_NEW = ("naming only the chat app or email service a message came through does not (the handle, account or "
                 "address it came from names the sender), nor does naming a firm only")
VH_HEDGE_OLD = "'looks like', 'appears to be', 'seems'), as the skill allows"
VH_HEDGE_NEW = "'looks like', 'appears to be', 'seems', 'has the hallmarks of' without 'every' or 'all'), as the skill allows"
VH_FLAT = VG_FLAT + ", 'all the hallmarks of a scam'"
VH_GOVERNS = ("A likelihood word governs a verdict that carries one ('very likely a classic overpayment scam' is hedged), "
              "and a stance held until the candidate checks ('I would treat this as a scam until you have checked') is a "
              "likelihood. ")
VH_WEAKER = (", and of the weaker sign only where its sentence, or the one before or after it, quotes or names only a "
             "weaker sign and neither that sentence nor the paragraph{0} it closes names such a request")
VH_ENTRY = ("; a verdict in a risk-register entry that records only a weaker sign, and no request of that kind, rests on "
            "that sign unless its sentence rests it on such a request.")
for _c in (NO_PARTY_ACCUSATION_C, NO_FRAUD_CLAIM_C):
    assert _c.count("Nor are two statements about requests and patterns, not about a party: " + VH_TWO_OLD + ".") == 1
NO_PARTY_ACCUSATION_C = patch(NO_PARTY_ACCUSATION_C, VG_PATTERN, VH_PATTERN, "VH3")
NO_PARTY_ACCUSATION_C = patch(NO_PARTY_ACCUSATION_C, VH_TWO_OLD, VH_TWO, "VH1")
NO_PARTY_ACCUSATION_C = patch(NO_PARTY_ACCUSATION_C, VH_HANDLE_OLD, VH_HANDLE_NEW, "VH6 (d)")
NO_FRAUD_CLAIM_C = patch(NO_FRAUD_CLAIM_C, VG_PATTERN, VH_PATTERN, "VH3")
NO_FRAUD_CLAIM_C = patch(NO_FRAUD_CLAIM_C, VH_TWO_OLD, VH_TWO, "VH1")
NO_FRAUD_CLAIM_C = patch(NO_FRAUD_CLAIM_C, "a request, message, invite, posting, offer or job the response attributes to "
                         "a party, by a possessive,", "a request, message, invite, posting, offer or job a statement "
                         "attributes to a party, in that statement, by a possessive,", "VH5")
NO_FRAUD_CLAIM_C = patch(NO_FRAUD_CLAIM_C, VH_HANDLE_OLD, VH_HANDLE_NEW, "VH6 (d)")
assert NO_PARTY_ACCUSATION_C.endswith(NO_ACCUSATION[NO_ACCUSATION.index(" Nor is a finding"):])
assert NO_FRAUD_CLAIM_C.endswith(NO_FRAUD_CLAIM_A[NO_FRAUD_CLAIM_A.index(" Nor are a hold"):])


def vh_verdicts(clause, names, entry):
    """request_verdicts after the second review (VH): 'has the hallmarks of' hedged and 'all the hallmarks of a scam'
    flat, a likelihood word governing, the weaker-sign binding narrowed, and the two statements no verdict."""
    clause = patch(clause, VH_HEDGE_OLD, VH_HEDGE_NEW, "VH3")
    clause = patch(clause, "('this request is a scam', " + VG_FLAT + ")", "('this request is a scam', " + VH_FLAT + ")",
                   "VH3")
    clause = patch(clause, "A verdict on the whole rests on such a request wherever",
                   VH_GOVERNS + "A verdict on the whole rests on such a request wherever", "VH6 (c)")
    clause = patch(clause, VG_BARE_WEAKER + (VG_ENTRY if entry else "."),
                   VH_WEAKER.format(" or entry" if entry else "") + (VH_ENTRY if entry else "."), "VH2")
    clause = patch(clause, VG_PATTERN, VH_PATTERN, "VH3")
    tail = "and that the " + names + " may not come from who it names"
    assert clause.endswith(tail), clause[-80:]
    return clause + "; nor are two statements about requests and patterns: " + VH_TWO


VC_VERDICTS_JU = vh_verdicts(VC_VERDICTS_JU, "message", True)
VC_VERDICTS_MI = vh_verdicts(VC_VERDICTS_MI, "invite", False)
INVITE_POINTER_C = patch(INVITE_POINTER_C, "near-certainty (" + VG_FLAT + "; 'looks like' and 'appears to be' are a "
                         "likelihood);", "near-certainty (" + VH_FLAT + "; 'looks like', 'appears to be', 'seems' and "
                         "'has the hallmarks of', without 'every' or 'all', are a likelihood);", "VH3, VH6 (a)")
INVITE_POINTER_C = patch(INVITE_POINTER_C, "named or called 'the company', 'the recruiter', 'the sender' or the like) or "
                         "puts one behind the thing: by a possessive,", "named or called 'the company', 'the employer', "
                         "'the recruiter', 'the sender' or the like) or puts one behind the thing in the same sentence: "
                         "by a possessive,", "VH6 (b), VH5")
INVITE_POINTER_C = patch(INVITE_POINTER_C, VH_HANDLE_OLD, VH_HANDLE_NEW, "VH6 (d)")
INVITE_POINTER_C = patch(INVITE_POINTER_C, "or that the invite may not come from it; or when the invite makes no such "
                         "request.", "or that the invite may not come from it, nor is a firm named elsewhere, as the one "
                         "the invite names or as the company the pack prepares for, put behind a verdict in another "
                         "sentence; or when the invite makes no such request.", "VH5")
INVITE_POINTER_C = patch(INVITE_POINTER_C, "or when the invite makes no such request. A bare 'this' or 'it'",
                         "or when the invite makes no such request. " + VH_GOVERNS + "A bare 'this' or 'it'", "VH6 (c)")
INVITE_POINTER_C = patch(INVITE_POINTER_C, VG_PATTERN, VH_PATTERN, "VH3")
INVITE_POINTER_C = patch(INVITE_POINTER_C, "or that who sent it is unproven. No offer,", "or that who sent it is "
                         "unproven. Nor are two statements about requests and patterns, not about the invite: " + VH_TWO
                         + ". No offer,", "VH1")
for _c in (NO_PARTY_ACCUSATION_C, NO_FRAUD_CLAIM_C, VC_VERDICTS_JU, VC_VERDICTS_MI, INVITE_POINTER_C):
    assert VH_PATTERN in _c and VH_TWO in _c and VH_TWO_OLD + "." not in _c
for _c in (NO_PARTY_ACCUSATION_C, NO_FRAUD_CLAIM_C, INVITE_POINTER_C):
    assert VH_HANDLE_NEW in _c
for _c in (VC_VERDICTS_JU, VC_VERDICTS_MI, INVITE_POINTER_C):
    assert VH_GOVERNS in _c and VH_FLAT in _c and "'has the hallmarks of'" in _c
assert VG_PATTERN_OLD in NO_ACCUSATION and "hallmark" not in NO_ACCUSATION and "legitimate employers" not in NO_ACCUSATION
''')

# 3. JU 8 #5 (VH7), after the VG patch of it
rep('''    "and does not fail this; whether it is allowed is graded by the expectation on verdicts", "VG")
''', '''    "and does not fail this; whether it is allowed is graded by the expectation on verdicts", "VG")
# The second review (VH7, L4): the sentence excuses any verdict that puts no party behind it, hedged or flat, so a flat
# one is graded by the expectation on verdicts alone (#18), not here as well.
ju8["expectations"][4] = patch(
    ju8["expectations"][4], "A hedged verdict that puts no party behind it (as the expectation on parties reads that),",
    "A verdict that puts no party behind it, hedged or flat (as the expectation on parties reads that),", "VH")
''')

# 4. MI 10 and 11 #3 and their request_verdicts lines (VH1, VH4), after the VG tails
rep('''    x[2] = x[2] + VG_TAIL + "does not fail this"
    x[n_rv - 1] = x[n_rv - 1] + VG_TAIL + "is not overreach"
''', '''    x[2] = x[2] + VG_TAIL + "does not fail this"
    x[n_rv - 1] = x[n_rv - 1] + VG_TAIL + "is not overreach"
# The second review (VH1, VH4): the tails name every statement above that is not a verdict (the two statements about
# requests and patterns among them), and add that saying the sign alone does not show a scam declines a verdict.
VH_TAIL = VG_TAIL.replace("; the three kinds of statement above are not verdicts here either,",
                          "; the statements above that are not verdicts are not verdicts here either,", 1)
assert VH_TAIL != VG_TAIL and "three kinds" not in VH_TAIL
for i, n_rv in ((10, 9), (11, 6)):
    x = mi[i]["expectations"]
    x[2] = patch(x[2], VG_TAIL + "does not fail this", VH_TAIL + "does not fail this; nor is saying that the sign alone "
                 "does not show a scam, which declines a verdict", "VH")
    x[n_rv - 1] = patch(x[n_rv - 1], VG_TAIL + "is not overreach", VH_TAIL + "is not overreach; nor is saying that the "
                        "sign alone does not show a scam", "VH")
''')

# 5. fixes and whys (VH)
rep('''    fx = {8: ["K3", "VB", "VC", "VW", "VG"], 9:''', '''    fx = {8: ["K3", "VB", "VC", "VW", "VG", "VH"], 9:''')
rep('''                  + (["VW", "VG"] if i in (10, 11) else [])})''',
    '''                  + (["VW", "VG", "VH"] if i in (10, 11) else [])})''')
rep('''                     "that the message may not come from it, does not.",
              "fixes": ["VB", "VC", "VK3", "VK4", "VG"]})''',
    '''                     "that the message may not come from it, does not. After its second review (VH): the two "
                     "statements cover a hiring process run this way too; a certainty word leaves a pattern statement "
                     "one; the handle, account or address a message came from names the sender.",
              "fixes": ["VB", "VC", "VK3", "VK4", "VG", "VH"]})''')
rep('''                     "one, rests on that sign; the first non-event covers signs. Never a gate, never core.",
              "fixes": ["VB", "VC", "VK2", "VS7", "VW", "VG"]})''',
    '''                     "one, rests on that sign; the first non-event covers signs. After its second review (VH): "
                     "'has the hallmarks of' is hedged and 'all the hallmarks of a scam' flat; a likelihood word governs "
                     "a verdict that carries one; a bare 'this' is the weaker sign's only where its paragraph or entry "
                     "names no such request, and an entry's verdict rests on the sign only where the entry records no "
                     "such request; the two statements about requests and patterns are no verdict. Never a gate, never "
                     "core.",
              "fixes": ["VB", "VC", "VK2", "VS7", "VW", "VG", "VH"]})''')
rep('''                             "only to say it cannot be established; the first non-event covers signs.",
                      "fixes": ["VC", "VK1", "VK2", "VS7", "VW", "VG"]})''',
    '''                             "only to say it cannot be established; the first non-event covers signs. After its "
                             "second review (VH): 'seems' and 'has the hallmarks of' are a likelihood and 'all the "
                             "hallmarks of a scam' a near-certainty; a likelihood word governs; 'the employer' is a "
                             "role noun; a party is put behind a verdict in the same sentence only; the two statements "
                             "about requests and patterns are no verdict.",
                      "fixes": ["VC", "VK1", "VK2", "VS7", "VW", "VG", "VH"]})''')
rep('''                         "established, as where to check, or that the invite may not come from it, does not." if fixed
                  else "Invite-warning clause.", **({"fixes": ["C2", "K5", "VB", "VC", "VK3", "VG"]} if fixed else {})})''',
    '''                         "established, as where to check, or that the invite may not come from it, does not. After "
                         "its second review (VH): attribution is read per statement; the two statements cover a "
                         "hiring process run this way too; the handle, account or address a message came from names "
                         "the sender." if fixed
                  else "Invite-warning clause.", **({"fixes": ["C2", "K5", "VB", "VC", "VK3", "VG", "VH"]} if fixed else {})})''')
rep('''                     "beside a weaker sign alone rests on that sign; the first non-event covers signs. Never a gate, "
                     "never core.",
              "fixes": ["VB", "VC", "VK2", "VK8", "VS7", "VW", "VG"]})''',
    '''                     "beside a weaker sign alone rests on that sign; the first non-event covers signs. After its "
                     "second review (VH), as job-underwriter's C06b, without the entry rule. Never a gate, never core.",
              "fixes": ["VB", "VC", "VK2", "VK8", "VS7", "VW", "VG", "VH"]})''')

P.write_text(src, encoding="utf-8")
print(f"patched {P}")
