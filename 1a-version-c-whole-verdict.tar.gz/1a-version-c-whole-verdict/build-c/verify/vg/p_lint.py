"""p_lint.py: update build/lint_fixtures.py for fix tag VG: the section 3 readings the VG wording changes, 3f read
from the saved VW state (../verify/vg/before/), and a new section 3g against that state. Exact replacements, each
asserted to occur once. Run once; refuses a second run."""
from pathlib import Path

P = Path(__file__).resolve().parents[2] / "build" / "lint_fixtures.py"
src = P.read_text(encoding="utf-8")
assert "3g." not in src, "already patched"


def rep(old, new):
    global src
    n = src.count(old)
    assert n == 1, (n, old[:90])
    src = src.replace(old, new, 1)


# ---- docstring ----
rep('''   no_responsibility_line is JU 9's and JU 10's #17; invite_pointer accepts a hedged verdict on such a request and
   MI 10-12 #3 say which requests the invite makes.
''', '''   no_responsibility_line is JU 9's and JU 10's #17; invite_pointer accepts a hedged verdict on such a request and
   MI 10-12 #3 say which requests the invite makes. After the review of the 17 November change (3g) the first
   non-event of the two party bars, request_verdicts and invite_pointer covers signs as well as requests;
   no_accusation keeps the old words.
''')
rep('''3d. The review of version C (VK1-VK10, VS1-VS8), as the owner's decision of 17 November (3f) leaves it: a possessive
   or a firm's name puts a party behind the verdict; a near-certainty is flat; a bare 'this' beside a request is that
   request's; invite_pointer names the
''', '''3d. The review of version C (VK1-VK10, VS1-VS8), as the owner's decision of 17 November (3f) and its review (3g)
   leave it: a possessive, a firm's name before the thing or the party named as its sender or source puts a party
   behind the verdict; a near-certainty is flat; a bare 'this' beside a request is that request's; invite_pointer names the
''')
rep('''   against the build before the decision (../verify/whole-verdict/before/), only invite_pointer and request_verdicts
   change among the clauses, every case's raw expectations and fields are unchanged but for MI 10 #3 and MI 11 #3
   (every subject listed) and JU 8 #5 (a hedged verdict naming no one is a conclusion about what the material asks),
   each checked for its new words, and both SKILL.md files are byte for byte the same; and no new rule sentence shares a run of three content words with any fixture prompt or canned page.
''', '''   against the build before the decision (../verify/whole-verdict/before/), the decision's own output (saved before
   its review as ../verify/vg/before/{ju,mi}-evals.json) changes only invite_pointer and request_verdicts among the
   clauses, and every case's raw expectations and fields are unchanged but for MI 10 #3 and MI 11 #3 (every subject
   listed) and JU 8 #5 (a hedged verdict naming no one is a conclusion about what the material asks), each checked for
   its new words; both SKILL.md files are byte for byte the same; and no new rule sentence shares a run of three
   content words with any fixture prompt or canned page.
3g. The review of the 17 November change (VG, the grader lens), against the build before it (../verify/vg/before/):
   only no_party_accusation and request_verdicts (job-underwriter) and invite_pointer, no_fraud_claim and
   request_verdicts (mock-interview) change among the clauses, each exactly by the VG replacements, in its sentences'
   order; no_accusation is unchanged word for word; every case's raw expectations and fields are unchanged but for
   JU 8 #5 (G6) and MI 10 #3 and #9 and MI 11 #3 and #6 (G7), each checked for its new words; every file of the
   candidate and rehearsal trees but the two evals.json files is byte for byte as before, so no shipped text changes;
   the first non-event covers signs (G1); an appearance is hedged and 'clearly', 'obviously' and the like flat (G2);
   two statements about requests and patterns are no claim in the party bars alone (G3); naming a party as a thing's
   sender or source puts it behind a verdict, and naming a firm only to say it cannot be established, as where to
   check, or that the message may not come from it does not, in the party bars and invite_pointer alike (G4); a bare
   'this' beside a weaker sign alone is that sign's, and in job-underwriter a verdict in the entry that records one
   rests on it (G5); both request_verdicts stay parallel; and the new text names no fixture's firm, person or platform.
''')

# ---- section 3: the five-part check reads the first non-event per clause ----
rep('''for name, clause in (("no_accusation", jcl["no_accusation"]), ("no_party_accusation", jcl["no_party_accusation"]),
                     ("no_fraud_claim", mcl["no_fraud_claim"])):
    for part in ("is, or may be, a scam, a fraud, fake or criminal", "Three kinds of statement are not such a claim",
                 "requests like this are a known scam pattern", "a verification question",
                 "may not come from who it names"):
        say(part in clause, f"{name} says {part!r}")
''', '''VG_FIRST = "requests or signs like this are, or follow, a known or classic scam pattern"
for name, clause in (("no_accusation", jcl["no_accusation"]), ("no_party_accusation", jcl["no_party_accusation"]),
                     ("no_fraud_claim", mcl["no_fraud_claim"])):
    first = "requests like this are a known scam pattern" if name == "no_accusation" else VG_FIRST
    for part in ("is, or may be, a scam, a fraud, fake or criminal", "Three kinds of statement are not such a claim",
                 first, "a verification question", "may not come from who it names"):
        say(part in clause, f"{name} says {part!r}")
''')
rep('''                 "attributes to a party, by a possessive or by the party's name before it",''',
    '''                 "attributes to a party, by a possessive, by the party's name before it, or by naming the party as "
                 "its sender or source",''')
rep('''                 "A verdict on the whole rests on such a request wherever the case makes one, unless its sentence rests "
                 "it on a weaker sign alone.",''',
    '''                 "A verdict on the whole rests on such a request wherever the case makes one, unless its sentence, or "
                 "the one before or after it, rests it on a weaker sign alone.",''')
rep('''                 "graded by the expectation on parties", "requests like this are a known scam pattern",
                 "a verification question", "may not come from who it names"):
        say(part in clause, f"{skill} request_verdicts says {part!r}")''',
    '''                 "graded by the expectation on parties", VG_FIRST,
                 "a verification question", "may not come from who it names"):
        say(part in clause, f"{skill} request_verdicts says {part!r}")''')
rep('''for part in ("verdict on whether the invite is genuine. Where the invite asks for " + VC_REQ + ", a hedged verdict on "
             "such a request, or on the message, the invite, the posting, the offer or the job as a whole, that names "
             "no firm or person ('this request is very likely a scam', 'this job is very likely a scam') is part of "
             "the warning and not such a verdict",
             "A verdict is such a verdict when it is flat, stated as a fact or a near-certainty ('almost certainly', "
             "'definitely', 'a classic scam'); when it names a firm or a person, even by a possessive or by a name "
             "before the thing ('the company's cheque request is very likely a scam'; a firm's name before 'invite' "
             "or 'job' does the same); or when the invite makes no such request.",''',
    '''for part in ("verdict on whether the invite is genuine. Where the invite asks for " + VC_REQ + ", a hedged verdict on "
             "such a request, or on the message, the invite, the posting, the offer or the job as a whole, that puts "
             "no firm or person behind it ('this request is very likely a scam', 'this job is very likely a scam') is "
             "part of the warning and not such a verdict",
             "A verdict is such a verdict when it is flat, stated as a fact or a near-certainty ('almost certainly', "
             "'definitely', 'a classic scam', 'a textbook scam', 'clearly', 'obviously', 'every hallmark of a scam'; "
             "'looks like' and 'appears to be' are a likelihood); when it is said of a party (a firm or a person, named "
             "or called 'the company', 'the recruiter', 'the sender' or the like) or puts one behind the thing: by a "
             "possessive, by a name before the thing, or by naming it as the thing's sender or source ('the company's "
             "cheque request is very likely a scam', 'the cheque request from Acme', 'the fee Acme asks for'; a firm's "
             "name before 'invite' or 'job' does the same), though naming only the chat app or email service a message "
             "came through does not, nor does naming a firm only to say it cannot be established, as where to check, "
             "or that the invite may not come from it; or when the invite makes no such request.",''')
rep('''             "Three kinds of statement are not such a verdict: that requests like this are a known scam pattern, a "
             "verification question, and that the invite may not come from who it names, or that who sent it is "
             "unproven."):''',
    '''             "Three kinds of statement are not such a verdict: that requests or signs like this are, or follow, a "
             "known or classic scam pattern ('a hiring process run wholly by chat is a known scam pattern' is one), a "
             "verification question, and that the invite may not come from who it names, or that who sent it is "
             "unproven."):''')

# ---- 3f: the VW step read from the saved VW state ----
rep('''# 3f. the owner's decision of 17 November (VW), against the build before it (saved, read only)
BEFORE = C / "verify" / "whole-verdict" / "before"
''', '''# 3f. the owner's decision of 17 November (VW), against the build before it (saved, read only). The decision's own
# output is read from the copy saved before its review (VG_BEFORE, 3g), since VG changed the same clauses after it.
BEFORE = C / "verify" / "whole-verdict" / "before"
VG_BEFORE = C / "verify" / "vg" / "before"
''')
rep('''    was = json.loads((BEFORE / f"{short}-evals.json").read_text(encoding="utf-8"))
    now = json.loads((TREE / "skills" / skill / "evals" / "evals.json").read_text(encoding="utf-8"))
    diff = {k for k in set(was["clauses"]) | set(now["clauses"]) if was["clauses"].get(k) != now["clauses"].get(k)}
    say(diff == changed, f"{skill} (VW): only {sorted(changed)} changed among the clauses {sorted(diff) if diff != changed else ''}")''',
    '''    was = json.loads((BEFORE / f"{short}-evals.json").read_text(encoding="utf-8"))
    now = json.loads((VG_BEFORE / f"{short}-evals.json").read_text(encoding="utf-8"))
    diff = {k for k in set(was["clauses"]) | set(now["clauses"]) if was["clauses"].get(k) != now["clauses"].get(k)}
    say(diff == changed, f"{skill} (VW, its saved output): only {sorted(changed)} changed among the clauses "
                         f"{sorted(diff) if diff != changed else ''}")''')
rep('''for name, what in (("no_party_accusation", "it still counts a name or possessive before the thing and leaves a "
                                            "verdict on the thing alone to request_verdicts"),
                   ("no_accusation", "in JU 9-11 any scam talk, hedged or not, still fails")):
    say(jcl[name] == json.loads((BEFORE / "ju-evals.json").read_text(encoding="utf-8"))["clauses"][name],
        f"{name} (VW): unchanged; {what}")
say(mcl["no_fraud_claim"] == json.loads((BEFORE / "mi-evals.json").read_text(encoding="utf-8"))["clauses"]["no_fraud_claim"],
    "no_fraud_claim (VW): unchanged; it still counts a name or possessive before the thing and leaves a verdict on the "
    "thing alone to request_verdicts")''',
    '''_vw_ju = json.loads((VG_BEFORE / "ju-evals.json").read_text(encoding="utf-8"))["clauses"]
_vw_mi = json.loads((VG_BEFORE / "mi-evals.json").read_text(encoding="utf-8"))["clauses"]
for name, what in (("no_party_accusation", "it still counts a name or possessive before the thing and leaves a "
                                            "verdict on the thing alone to request_verdicts"),
                   ("no_accusation", "in JU 9-11 any scam talk, hedged or not, still fails")):
    say(_vw_ju[name] == json.loads((BEFORE / "ju-evals.json").read_text(encoding="utf-8"))["clauses"][name],
        f"{name} (VW, its saved output): unchanged; {what}")
say(_vw_mi["no_fraud_claim"] == json.loads((BEFORE / "mi-evals.json").read_text(encoding="utf-8"))["clauses"]["no_fraud_claim"],
    "no_fraud_claim (VW, its saved output): unchanged; it still counts a name or possessive before the thing and "
    "leaves a verdict on the thing alone to request_verdicts")''')

# ---- 3g: the review of the 17 November change (VG) ----
rep('''shipped = [p for p in (TREE / "skills").rglob("*.md")] + [p for p in (TREE / "skills").rglob("SKILL.md")]
''', '''# 3g. the review of the 17 November change (VG, the grader lens), against the build before it (saved, read only)
VG_OLD_FIRST = "that requests like this are a known scam pattern"
VG_NEW_FIRST = ("that requests or signs like this are, or follow, a known or classic scam pattern ('a hiring process run "
                "wholly by chat is a known scam pattern' is one)")
VG_PATTERNS = ("Nor are two statements about requests and patterns, not about a party: that legitimate employers do not "
               "make requests like this, and that scams often use a real firm's name.")
_FLAT = "'almost certainly', 'definitely', 'a classic scam'"
_FLAT_NEW = _FLAT + ", 'a textbook scam', 'clearly', 'obviously', 'every hallmark of a scam'"
_ATTR_OLD = ("by a possessive or by the party's name before it ('the company's cheque request is a fraud'; the firm's "
             "name before 'invite' or 'offer' does the same), puts that party behind it; naming only the chat app or "
             "email service a message came through does not.")
_ATTR_NEW = ("by a possessive, by the party's name before it, or by naming the party as its sender or source ('the "
             "company's cheque request is a fraud', 'the cheque request from Acme', 'the fee Acme asks for'; the firm's "
             "name before 'invite' or 'offer' does the same), puts that party behind it; naming only the chat app or "
             "email service a message came through does not, nor does naming a firm only to say it cannot be "
             "established, as where to check, or that the {0} may not come from it.")
_HEDGE = ("gives the verdict as a likelihood ('likely', 'very likely', 'probably', 'may be'), as the skill allows",
          "gives the verdict as a likelihood or an appearance ('likely', 'very likely', 'probably', 'may be', 'looks "
          "like', 'appears to be', 'seems'), as the skill allows")
_RESTS = ("unless its sentence rests it on a weaker sign alone.",
          "unless its sentence, or the one before or after it, rests it on a weaker sign alone.")
_BARE = "('This is very likely a scam. Don't deposit the cheque.')."
_WEAKER = (", and of the weaker sign where its sentence, or the one before or after it, quotes or names only a weaker "
           "sign")
_ENTRY = "; a verdict in the risk-register entry that records a weaker sign rests on that sign."
_IP_PARTY = (
    "when it names a firm or a person, even by a possessive or by a name before the thing ('the company's cheque "
    "request is very likely a scam'; a firm's name before 'invite' or 'job' does the same);",
    "when it is said of a party (a firm or a person, named or called 'the company', 'the recruiter', 'the sender' or "
    "the like) or puts one behind the thing: by a possessive, by a name before the thing, or by naming it as the "
    "thing's sender or source ('the company's cheque request is very likely a scam', 'the cheque request from Acme', "
    "'the fee Acme asks for'; a firm's name before 'invite' or 'job' does the same), though naming only the chat app "
    "or email service a message came through does not, nor does naming a firm only to say it cannot be established, "
    "as where to check, or that the invite may not come from it;")


def _verdict_edits(entry):
    return [_HEDGE, ("('this request is a scam', " + _FLAT + ")", "('this request is a scam', " + _FLAT_NEW + ")"),
            _RESTS, (_BARE, _BARE[:-1] + _WEAKER + (_ENTRY if entry else ".")), (VG_OLD_FIRST, VG_NEW_FIRST)]


VG_CLAUSE_EDITS = {
    "job-underwriter": {
        "no_party_accusation": [(VG_OLD_FIRST, VG_NEW_FIRST),
                                ("is unresolved. Nor is the standing", "is unresolved. " + VG_PATTERNS + " Nor is the standing"),
                                (_ATTR_OLD, _ATTR_NEW.format("message"))],
        "request_verdicts": _verdict_edits(True)},
    "mock-interview": {
        "no_fraud_claim": [(VG_OLD_FIRST, VG_NEW_FIRST),
                           ("is unproven. Nor are a hold", "is unproven. " + VG_PATTERNS + " Nor are a hold"),
                           (_ATTR_OLD, _ATTR_NEW.format("invite"))],
        "request_verdicts": _verdict_edits(False),
        "invite_pointer": [("or the job as a whole, that names no firm or person ('this request",
                            "or the job as a whole, that puts no firm or person behind it ('this request"),
                           ("near-certainty (" + _FLAT + ");",
                            "near-certainty (" + _FLAT_NEW + "; 'looks like' and 'appears to be' are a likelihood);"),
                           _IP_PARTY, (VG_OLD_FIRST, VG_NEW_FIRST)]},
}
_TAIL = ("; the three kinds of statement above are not verdicts here either, and saying that a hiring process run "
         "wholly by chat is a known scam pattern, as the skill's own gate example does, is the first of them and ")
_JU8_5 = ("A hedged verdict that names no firm or person, on a request or on the message, the posting, the offer or the "
          "job as a whole, is a conclusion about what the material asks and does not fail this",
          "A hedged verdict that puts no party behind it (as the expectation on parties reads that), on a request or on "
          "the message, the invite, the posting, the offer or the job as a whole, is a conclusion about what the "
          "material asks and does not fail this; whether it is allowed is graded by the expectation on verdicts")
VG_LINES = {"job-underwriter": {8: {5: ("replace",) + _JU8_5}},
            "mock-interview": {10: {3: ("append", "hedged or not, fails this", _TAIL + "does not fail this"),
                                    9: ("append", "hedged or not, is overreach", _TAIL + "is not overreach")},
                               11: {3: ("append", "hedged or not, fails this", _TAIL + "does not fail this"),
                                    6: ("append", "hedged or not, is overreach", _TAIL + "is not overreach")}}}
VG_NAMES = NAMES + ("Lumenvale", "Velloway", "postmail")
for skill, short in (("job-underwriter", "ju"), ("mock-interview", "mi")):
    was = json.loads((VG_BEFORE / f"{short}-evals.json").read_text(encoding="utf-8"))
    now = json.loads((TREE / "skills" / skill / "evals" / "evals.json").read_text(encoding="utf-8"))
    edits_ = VG_CLAUSE_EDITS[skill]
    diff = {k for k in set(was["clauses"]) | set(now["clauses"]) if was["clauses"].get(k) != now["clauses"].get(k)}
    say(diff == set(edits_) and list(was["clauses"]) == list(now["clauses"]),
        f"{skill} (VG): only {sorted(edits_)} changed among the clauses, in the same order {sorted(diff) if diff != set(edits_) else ''}")
    for name, pairs in edits_.items():
        t = was["clauses"][name]
        ok, added = True, []
        for old, new in pairs:
            ok = ok and t.count(old) == 1 and new not in t
            t = t.replace(old, new, 1)
            added.append(new)
        say(ok and t == now["clauses"][name], f"{skill} {name} (VG): the before text with exactly the "
                                               f"{len(pairs)} VG replacements, sentences in their order")
        hits = [n for n in VG_NAMES if any(n in a for a in added)]
        say(not hits, f"{skill} {name} (VG): the new text names no fixture's firm, person or platform {hits or ''}")
    lines_vg = VG_LINES[skill]

    def masked(evals):
        out = json.loads(json.dumps(evals))
        for c in out:
            for n in lines_vg.get(c["id"], {}):
                c["expectations"][n - 1] = None
        return out
    say(masked(was["evals"]) == masked(now["evals"]) and was["skill_name"] == now["skill_name"],
        f"{skill} (VG): every case's raw expectations, tails and fields are unchanged but for "
        + ", ".join(f"{short.upper()} {i} #{n}" for i in sorted(lines_vg) for n in sorted(lines_vg[i])))
    bw, bn = {c["id"]: c for c in was["evals"]}, {c["id"]: c for c in now["evals"]}
    for i, nums in sorted(lines_vg.items()):
        for n, (how, old, new) in sorted(nums.items()):
            a, b = bw[i]["expectations"][n - 1], bn[i]["expectations"][n - 1]
            if how == "replace":
                ok = a.count(old) == 1 and new not in a and b == a.replace(old, new, 1)
            else:
                ok = a.endswith(old) and b == a + new
            say(ok, f"{skill} {i} #{n} (VG): {how}s '{new[:60].lstrip('; ')}...' and nothing else changes")
say(jcl["no_accusation"] == json.loads((VG_BEFORE / "ju-evals.json").read_text(encoding="utf-8"))["clauses"]["no_accusation"]
    and VG_OLD_FIRST in jcl["no_accusation"] and VG_NEW_FIRST not in jcl["no_accusation"]
    and "legitimate employers" not in jcl["no_accusation"] and "sender or source" not in jcl["no_accusation"],
    "no_accusation (VG): unchanged word for word; in JU 9-11 any scam talk, hedged or not, still fails")
for name, clause in (("no_party_accusation", jcl["no_party_accusation"]), ("no_fraud_claim", mcl["no_fraud_claim"]),
                     ("job-underwriter request_verdicts", jcl["request_verdicts"]),
                     ("mock-interview request_verdicts", mcl["request_verdicts"]), ("invite_pointer", mcl["invite_pointer"])):
    say(VG_NEW_FIRST in clause and VG_OLD_FIRST not in clause,
        f"{name} (VG, G1): the first non-event covers signs, the template's gate sentence its example")
for name, clause in (("job-underwriter request_verdicts", jcl["request_verdicts"]),
                     ("mock-interview request_verdicts", mcl["request_verdicts"])):
    say(_HEDGE[1] in clause and "('this request is a scam', " + _FLAT_NEW + ")" in clause,
        f"{name} (VG, G2): an appearance ('looks like', 'appears to be', 'seems') is hedged; 'clearly', 'obviously', "
        "'a textbook scam' and 'every hallmark of a scam' are flat")
    say(_RESTS[1] in clause and _WEAKER in clause, f"{name} (VG, G5): a bare 'this' beside a weaker sign alone is that "
                                                   "sign's, and the sentence before or after can rest the whole on it")
say(_ENTRY in jcl["request_verdicts"] and "risk-register" not in mcl["request_verdicts"],
    "request_verdicts (VG, G5): a verdict in the entry that records a weaker sign rests on it, in job-underwriter only")
_par = (jcl["request_verdicts"].replace("Each sentence of the response, its risk register and snapshot included,",
                                         "Each statement in the response, any saved file included,")
        .replace("a hiring process run wholly by chat, or contact off the employer's domain beyond scheduling)",
                 "a hiring process run wholly by chat)")
        .replace("that the message may not come from who it names", "that the invite may not come from who it names")
        .replace(_ENTRY, "."))
say(_par == mcl["request_verdicts"], "request_verdicts (VG): the two modules' clauses stay parallel, word for word but "
                                     "for scope, weaker signs, message or invite, and the entry rule")
say("'looks like' and 'appears to be' are a likelihood" in mcl["invite_pointer"] and _FLAT_NEW in mcl["invite_pointer"],
    "invite_pointer (VG, G2): 'looks like' and 'appears to be' are a likelihood; the same near-certainties as Flat")
for name, clause in (("no_party_accusation", jcl["no_party_accusation"]), ("no_fraud_claim", mcl["no_fraud_claim"])):
    say(VG_PATTERNS in clause, f"{name} (VG, G3): that legitimate employers do not make requests like this, and that "
                               "scams often use a real firm's name, are no claim about a party")
_FIRM_ONLY = "nor does naming a firm only to say it cannot be established, as where to check, or that the"
for name, clause in (("no_party_accusation", jcl["no_party_accusation"]), ("no_fraud_claim", mcl["no_fraud_claim"]),
                     ("invite_pointer", mcl["invite_pointer"])):
    say("'the cheque request from Acme', 'the fee Acme asks for'" in clause and "sender or source" in clause
        and _FIRM_ONLY in clause and "naming only the chat app or email service a message came through does not"
        in clause, f"{name} (VG, G4): naming a party as the thing's sender or source puts it behind the verdict; a firm "
                   "named only to say it cannot be established, as where to check, or that the message may not come "
                   "from it, and the chat app alone, do not")
say(mcl["invite_pointer"].count("named or called 'the company', 'the recruiter', 'the sender' or the like") == 1
    and "names a firm or a person" not in mcl["invite_pointer"] and "names no firm or person" not in mcl["invite_pointer"],
    "invite_pointer (VG, G4): reads parties as no_fraud_claim does, role nouns included, not by a name alone")
say("I can't establish the firm from here; the request to buy gift cards for your onboarding is very likely a scam"
    in RD, "risk-and-decision.md: the 'is it legit?' example the G4 carve-out covers, with a firm's name filled in")
_j5 = jraw[8]["expectations"][4]
say(_JU8_5[1] in _j5 and "names no firm or person" not in _j5,
    "job-underwriter 8 #5 (VG, G6): a hedged verdict that puts no party behind it, the invite included, does not fail "
    "it; whether it is allowed is the expectation on verdicts'")
_now_m = {c["id"]: c for c in json.loads((TREE / "skills/mock-interview/evals/evals.json").read_text())["evals"]}
say(all(_now_m[i]["expectations"][n - 1].endswith(_TAIL + end) for i, n, end in
        ((10, 3, "does not fail this"), (11, 3, "does not fail this"), (10, 9, "is not overreach"),
         (11, 6, "is not overreach"))),
    "mock-interview 10 and 11 #3 and request_verdicts (VG, G7): the three non-events are not verdicts here either, "
    "the skill's own gate sentence the first")


def _files(root):
    return {p.relative_to(root).as_posix(): p for p in sorted(root.rglob("*")) if p.is_file() and "__pycache__" not in p.parts}


EVALS_JSON = {"skills/job-underwriter/evals/evals.json", "skills/mock-interview/evals/evals.json"}
for label, root, was_root in (("candidate", TREE, VG_BEFORE / "tree"), ("rehearsal", REH, VG_BEFORE / "tree-rehearsal")):
    fa, fb = _files(was_root), _files(root)
    differ = sorted(k for k in set(fa) | set(fb) if k not in fa or k not in fb or fa[k].read_bytes() != fb[k].read_bytes())
    say(set(fa) == set(fb) and set(differ) == EVALS_JSON,
        f"{label} (VG): {len(fb)} files, every one byte for byte as before but the two evals.json files "
        f"(shipped text, the .skill archives and dist/ unchanged) {differ if set(differ) != EVALS_JSON else ''}")

shipped = [p for p in (TREE / "skills").rglob("*.md")] + [p for p in (TREE / "skills").rglob("SKILL.md")]
''')

P.write_text(src, encoding="utf-8")
print(f"patched {P}")
