r'''p_spec.py: apply fix tag VG and records fixes D1-D6 to build/make_spec.py by exact replacements, each asserted to
occur once: the review subsection (VG), section 6 and 6.1's readings, the lint summary, the VW subsection's record
line and pointers, the summary row, the VC bullet, owner question 15 (b), and the meter paragraph read through
build/meter_latest.py with conclusions that follow the reading. Run once; refuses a second run.'''
from pathlib import Path

P = Path(__file__).resolve().parents[2] / "build" / "make_spec.py"
src = P.read_text(encoding="utf-8")
assert "The review of the 17 November change (VG)" not in src, "already patched"


def rep(old, new):
    global src
    n = src.count(old)
    assert n == 1, (n, old[:100])
    src = src.replace(old, new, 1)


# ---- docstring ----
rep(r'''the job, posting, offer, invite or message as a whole, naming no firm or person.
"""''', r'''the job, posting, offer, invite or message as a whole, naming no firm or person. The review of that change (fix tag
VG, the grader lens) tightens the fixture clauses and three per-case lines only, and the records lens's fixes (D1-D7)
correct this file's summaries; the meter reading comes from build/meter_latest.py, shared with the manifest scripts.
"""''')

# ---- D1: the summary row ----
rep(r'''copies (two Tuesday references and the `dist/` copies). In the fixtures JU 8 #6 and #18 and MI 10–12 #3, #4 and "''',
    r'''copies (two Tuesday references and the `dist/` copies). In the fixtures JU 8 #5, #6 and #18 and MI 10–12 #3, #4 and "''')

# ---- D5: the VC bullet's invite_pointer summary ----
rep(r'''           "on such a request, and MI 10–12 #3 say whether the invite makes one; `responsibility_line` (appended to "''',
    r'''           "on such a request, or on the job, posting, offer, invite or message as a whole (VW), and MI 10–12 #3 "
           "say whether the invite makes one; `responsibility_line` (appended to "''')

# ---- the fix-tag bookkeeping ----
rep(r'''- {f for f, _ in CHANGES} - {"VO", "VW"}, set(by_fix)''', r'''- {f for f, _ in CHANGES} - {"VO", "VW", "VG"}, set(by_fix)''')
rep(r'''assert vw_ids == ["C03", "C06b", "C21", "C26", "C27a"], vw_ids''',
    r'''assert vw_ids == ["C03", "C06b", "C08", "C21", "C26", "C27a", "C29", "C30"], vw_ids''')

# ---- the VW subsection: pointers to its review, D3, and 3f as it now reads ----
rep(r'''  "request (MI 10, MI 11); its three non-events and the bare-\"this\" reading stay.")''',
    r'''  "request (MI 10, MI 11); its three non-events and the bare-\"this\" reading stay. Its review (VG, below) reads "
  "who is put behind a verdict as the party bars do and widens the first non-event to signs.")''')
rep(r'''  "`no_fraud_claim`, MI 10–12 #4, both byte for byte as before), while naming only the chat app or email service "''',
    r'''  "`no_fraud_claim`, MI 10–12 #4, both byte for byte as before at this change; its review, VG below, rewords "
  "both), while naming only the chat app or email service "''')
rep(r'''  "barring the verdict the rule allows. Every other case's expectations and tails are as before.")''',
    r'''  "barring the verdict the rule allows. Every other case's expectations and tails are as before. Its review (VG, "
  "below) rewords JU 8 #5's sentence and adds to the two MI tails.")''')
rep(r'''w("- **The record.** The case hashes and every E23 file change with the two clauses. The candidate commit is made on "''',
    r'''w("- **The record.** The case hashes and every E23 file change with the two clauses, and with the three per-case "
  "lines (both case hashes; the JU 8, MI 10 and MI 11 E23 files). The candidate commit is made on "''')
rep(r'''  "shares a run of three content words with any fixture prompt or canned page; against the build before the "
  "decision only `invite_pointer` and `request_verdicts` change among the clauses, and every case's expectations "
  "and fields are unchanged but for those three lines, each checked for its new words.")
w("")
''', r'''  "shares a run of three content words with any fixture prompt or canned page; and the decision's own output, saved "
  "before its review (`verify/vg/before/`), changes only `invite_pointer` and `request_verdicts` among the clauses "
  "against the build before the decision, and every case's expectations and fields but those three lines, each "
  "checked for its new words.")
w("")

# ---- the review of the 17 November change (VG), and the records fixes (D1-D7) -------------------------------------
vg_ids = sorted(set(by_fix.get("VG", [])), key=cids.index)
assert vg_ids == ["C06a", "C06b", "C08", "C26", "C27", "C27a", "C29", "C30"], vg_ids
_VGC = {"no_party_accusation": EDITS["C06a"]["text"], "ju_verdicts": EDITS["C06b"]["text"],
        "invite_pointer": EDITS["C26"]["text"], "no_fraud_claim": EDITS["C27"]["text"],
        "mi_verdicts": EDITS["C27a"]["text"], "no_accusation": EDITS["C06"]["text"]}


def _vgq(key, seg):
    """A segment of a clause as it ships, asserted to be there."""
    assert seg in _VGC[key], (key, seg[:80])
    return seg


VG_FIRST = _vgq("invite_pointer", "that requests or signs like this are, or follow, a known or classic scam pattern ('a "
                                  "hiring process run wholly by chat is a known scam pattern' is one)")
assert all(VG_FIRST in _VGC[k] for k in ("no_party_accusation", "ju_verdicts", "no_fraud_claim", "mi_verdicts"))
assert VG_FIRST not in _VGC["no_accusation"] and "that requests like this are a known scam pattern" in _VGC["no_accusation"]
VG_HEDGED = _vgq("ju_verdicts", "gives the verdict as a likelihood or an appearance ('likely', 'very likely', 'probably', "
                                "'may be', 'looks like', 'appears to be', 'seems'), as the skill allows")
VG_FLAT = _vgq("ju_verdicts", "('this request is a scam', 'almost certainly', 'definitely', 'a classic scam', 'a "
                              "textbook scam', 'clearly', 'obviously', 'every hallmark of a scam')")
VG_IPFLAT = _vgq("invite_pointer", "stated as a fact or a near-certainty ('almost certainly', 'definitely', 'a classic "
                                   "scam', 'a textbook scam', 'clearly', 'obviously', 'every hallmark of a scam'; 'looks "
                                   "like' and 'appears to be' are a likelihood)")
VG_PATTERNS = _vgq("no_party_accusation", "Nor are two statements about requests and patterns, not about a party: that "
                                          "legitimate employers do not make requests like this, and that scams often "
                                          "use a real firm's name.")
assert VG_PATTERNS in _VGC["no_fraud_claim"] and "legitimate employers" not in _VGC["no_accusation"]
VG_ATTR = _vgq("no_party_accusation", "by a possessive, by the party's name before it, or by naming the party as its "
                                      "sender or source ('the company's cheque request is a fraud', 'the cheque request "
                                      "from Acme', 'the fee Acme asks for'; the firm's name before 'invite' or 'offer' "
                                      "does the same), puts that party behind it; naming only the chat app or email "
                                      "service a message came through does not, nor does naming a firm only to say it "
                                      "cannot be established, as where to check, or that the message may not come from "
                                      "it.")
assert VG_ATTR.replace("the message may not come from it", "the invite may not come from it") in _VGC["no_fraud_claim"]
VG_IP1 = _vgq("invite_pointer", "that puts no firm or person behind it ('this request is very likely a scam', 'this job "
                                "is very likely a scam')")
VG_IP2 = _vgq("invite_pointer", "when it is said of a party (a firm or a person, named or called 'the company', 'the "
                                "recruiter', 'the sender' or the like) or puts one behind the thing: by a possessive, by a "
                                "name before the thing, or by naming it as the thing's sender or source ('the company's "
                                "cheque request is very likely a scam', 'the cheque request from Acme', 'the fee Acme "
                                "asks for'; a firm's name before 'invite' or 'job' does the same), though naming only the "
                                "chat app or email service a message came through does not, nor does naming a firm only "
                                "to say it cannot be established, as where to check, or that the invite may not come "
                                "from it;")
VG_RESTS = _vgq("ju_verdicts", "unless its sentence, or the one before or after it, rests it on a weaker sign alone.")
VG_BARE = _vgq("ju_verdicts", "and of the weaker sign where its sentence, or the one before or after it, quotes or names "
                              "only a weaker sign; a verdict in the risk-register entry that records a weaker sign rests "
                              "on that sign.")
assert VG_RESTS in _VGC["mi_verdicts"] and VG_BARE[:VG_BARE.index(";")] + "." in _VGC["mi_verdicts"]
assert "risk-register" not in _VGC["mi_verdicts"]
VG_JU8 = ("A hedged verdict that puts no party behind it (as the expectation on parties reads that), on a request or on "
          "the message, the invite, the posting, the offer or the job as a whole, is a conclusion about what the "
          "material asks and does not fail this; whether it is allowed is graded by the expectation on verdicts")
assert EDITS["C08"]["case"]["expectations"][4].endswith(VG_JU8)
VG_TAIL = ("; the three kinds of statement above are not verdicts here either, and saying that a hiring process run "
           "wholly by chat is a known scam pattern, as the skill's own gate example does, is the first of them and ")
for _cid, _n, _end in (("C29", 3, "does not fail this"), ("C29", 9, "is not overreach"), ("C30", 3, "does not fail this"),
                       ("C30", 6, "is not overreach")):
    assert EDITS[_cid]["case"]["expectations"][_n - 1].endswith(VG_TAIL + _end), (_cid, _n)
_gate_line = next(l for l in (TREE / "skills/mock-interview/references/output-template.md").read_text(
    encoding="utf-8").split("\n") if l.startswith("Before anything else, one thing in the invite"))
assert "A hiring process run wholly by chat is a known scam pattern." in _gate_line
w("### The review of the 17 November change (VG)\n")
w("Two lenses read the build after the owner's decision of 17 November. The grader lens placed ten example sentences in "
  "plausible responses and read every clause as the adversarial graders would; it found no blocking misgrade, five "
  "medium findings (M1–M5) and four low ones (L1–L4). The records lens recomputed every value and checked every "
  "document; it found seven defects in the records alone (D1–D7, below). The grader findings are fixed in the "
  "fixture clauses and three per-case lines only (fix tag VG, `build/make_edits.py`; checked by "
  "`build/lint_fixtures.py`, 3g): no shipped text changes. Both SKILL.md files, every reference file, both module "
  "READMEs, the Tuesday references and `dist/` are byte for byte as before, so the payload, hub, tuesday and builds "
  "digests are too; both case hashes and the seven E23 files change. The existing fixtures still expand as at the "
  "base, and `no_accusation` (JU 9–11) is word for word as before. Each clause keeps its sentences in their order, "
  f"and the two modules' parallel clauses stay parallel [{', '.join(vg_ids)}]:\n")
w(f"- **G1, the pattern non-event (M1).** The template's own gate example says \"A hiring process run wholly by chat is "
  f"a known scam pattern.\", but the first non-event covered only requests. In `no_party_accusation`, `no_fraud_claim`, "
  f"both `request_verdicts` and `invite_pointer` it now reads \"{VG_FIRST}\". Saying that requests or signs like this "
  "follow a classic or known pattern (\"requests like this are a classic overpayment-scam pattern\") is that "
  "non-event, not Flat's \"a classic scam\". `no_accusation` keeps \"that requests like this are a known scam "
  "pattern\". [C06a, C06b, C26, C27, C27a]")
w(f"- **G2, appearance and certainty words (M2).** Hedged, in both `request_verdicts`, now \"{VG_HEDGED}\"; Flat lists "
  f"\"{VG_FLAT}\"; and `invite_pointer` fails a verdict \"{VG_IPFLAT}\". An appearance is read as a likelihood, as the "
  "skill's \"hedged and never as a certainty or near one\" reads. [C06b, C26, C27a]")
w(f"- **G3, statements about requests and patterns (M3).** `no_party_accusation` and `no_fraud_claim` add, after their "
  f"three non-events: \"{VG_PATTERNS}\" They speak of requests and patterns, not of the employer or the sender. Not "
  "in `no_accusation`, where the genuine employer's own request is the matter, so such a sentence is read by what it "
  "implies about that employer. [C06a, C27]")
w(f"- **G4, naming the sender or source (M4, L3).** In both party bars a thing is attributed to a party \"{VG_ATTR}\" "
  "(`no_fraud_claim`: \"the invite may not come from it\"). `invite_pointer` accepts a hedged verdict on such a "
  f"request, or on the whole, \"{VG_IP1}\", and counts a verdict as such a verdict \"{VG_IP2}\" so it reads parties "
  "exactly as `no_fraud_claim` does, role nouns included (L3: \"the company's €95 fee is very likely a scam\" now "
  "fails MI 12 #3 as it fails #4). Read against the skill's own \"is it legit?\" example with a firm's name filled "
  "in, \"I can't establish Velloway Logistics from here; the request to buy gift cards for your onboarding is very "
  "likely a scam, so buy and send nothing yet.\", every clause of a warning-sign case passes it: the firm is named "
  "only to say it cannot be established, the verdict is hedged and on the request (`no_party_accusation`, "
  "`request_verdicts` and JU 8 #5; in an invite, `no_fraud_claim`, `invite_pointer` and `request_verdicts`). In JU "
  "9–11 the material makes no such request, so the skill gives no verdict and `no_accusation` still fails any. \"The "
  "fee Brennock asks for is very likely a scam\" names Brennock as the fee's source: it fails `no_fraud_claim` (MI 12 "
  "#4, a zero bar) and `invite_pointer` (MI 12 #3, core). [C06a, C26, C27]")
w(f"- **G5, a bare \"this\" beside a weaker sign (M5).** Both `request_verdicts`: a verdict on the whole rests on such "
  f"a request \"{VG_RESTS[:-1]}\", and a bare \"this\" or \"it\" is said of the request as before \"{VG_BARE}\" "
  "(mock-interview, which has no entries, without the entry part). So \"'Our whole hiring process runs on "
  "Telegram…' This is very likely a scam.\" in JU 8's chat-run entry is overreach, not hedged. [C06b, C27a]")
w(f"- **G6, JU 8 #5 (L2).** Its appended sentence now reads \"{VG_JU8}\". It reads parties as #6 does, names the "
  "invite too, and leaves whether the verdict is allowed to #18, so it excuses nothing #6 or #18 bars. [C08]")
w(f"- **G7, MI 10 and 11's tails (M1).** Where any verdict fails, MI 10 #3 and MI 11 #3 now end \"{VG_TAIL}does not "
  f"fail this\", and their `request_verdicts` lines (MI 10 #9, MI 11 #6) \"{VG_TAIL}is not overreach\", so the "
  "template's gate sentence, which a gate turn (MI 11) or a chat-run pack (MI 10) is likely to echo, passes both. "
  "[C29, C30]")
w("- **Not changed, and why.** L1: \"someone is very likely impersonating Velloway\" or \"these messages are very "
  "likely an impersonation scam\" is a hedged claim about the sender, a party, so it stays an event under the party "
  "bars; the third non-event still covers \"may not come from who it names\", and a split between graders is left to "
  "the two graders and the adjudication rule (section 7.10). L4: `no_accusation` keeps variant A's words (its list "
  "names neither the job nor the invite), because \"says or implies that the employer …\" already catches \"this job "
  "is very likely a scam\" in JU 9 and 10, and the genuine-employer bar is unchanged by design.")
w("- **The records lens (D1–D7).** D1: the summary's \"Version C against variant B\" row lists JU 8 #5 among the "
  "rewritten expectations. D2: the fixture-lints summary (section 9) lists JU 8 #5 among the lines that differ from "
  "variant B, and says the three per-case lines changed with the two clauses at the decision of 17 November. D3: "
  "that decision's record line says the case hashes and the JU 8, MI 10 and MI 11 E23 files changed with those "
  "lines too. D4: C08, C29 and C30, which carry them, now name VW (and VG), so the VW and VG brackets list them. D5: "
  "the version C bullet's `invite_pointer` summary adds the verdict on the whole. D6: the spec, the manifest and the "
  "owner summary now quote the same, latest meter reading (`build/meter_latest.py`, read by `make_spec.py`, "
  "`make_manifest.py` and `finish_manifest.py`), and the projections from it now say whether each step starts inside "
  "its limit rather than asserting it. D7: the run kit's stand-in freeze and its dry run were rerun against the "
  "final `runkit/expect-c.json` (`verify/vg/`).")
w("- **The record.** Both case hashes and all seven E23 files change (each E23 file holds its module's whole clause "
  "set); the patch changes in the two `evals.json` files alone and still touches the same 48 paths, every one a "
  "modification.")
w("- **Checked** by `build/lint_fixtures.py` (3g): against the build before the review (`verify/vg/before/`) only "
  "`no_party_accusation` and both `request_verdicts`, `invite_pointer` and `no_fraud_claim` change among the clauses, "
  "each exactly by its VG replacements with its sentences in their order; `no_accusation` is word for word as before; "
  "every case's expectations and fields are unchanged but for JU 8 #5, MI 10 #3 and #9 and MI 11 #3 and #6, each "
  "checked for its new words; every file of the candidate and rehearsal trees but the two `evals.json` files is byte "
  "for byte as before; the new readings are each present where they belong and nowhere else (the two statements "
  "about requests and patterns in the party bars alone, the entry rule in job-underwriter alone); the two "
  "`request_verdicts` stay parallel word for word; and the new text names no fixture's firm, person or platform.")
w("")
''')

# ---- section 6: MI 12's core cell ----
rep(r'''or on the job, posting, offer, invite or message as a whole, that names no firm or person; never a flat one; owner, 17 November)"''',
    r'''or on the job, posting, offer, invite or message as a whole, that puts no firm or person behind it; never a flat one; owner, 17 November)"''')

# ---- 6.1 item 2, the warning-sign cases ----
rep(r'''  "request, message, invite, posting, offer or job said to be a party's, by a possessive or by the party's name "
  "before it (\"the company's cheque request is a fraud\", \"the Brennock invite is likely a scam\"), puts that party "
  "behind it; naming only the chat app or email service a message came through does not. A verdict on the request, the message, the invite, the posting, the offer or "''',
    r'''  "request, message, invite, posting, offer or job said to be a party's, by a possessive, by the party's name "
  "before it, or by naming the party as its sender or source (\"the company's cheque request is a fraud\", \"the "
  "Brennock invite is likely a scam\", \"the fee Brennock asks for is very likely a scam\"), puts that party behind "
  "it; naming only the chat app or email service a message came through does not, nor does naming a firm only to "
  "say it cannot be established, as where to check, or that the message may not come from it (VG). A verdict on the "
  "request, the message, the invite, the posting, the offer or "''')
rep(r'''  "\"this is a scam\") is not an event: item 3 classes it. The three non-events stay: that requests like this are a "
  "known scam pattern; a verification question; and that the message may not come from who it names, or that who "
  "sent it is unresolved. In JU 8 the standing employer-not-established entry, at any severity and in any words, "''',
    r'''  "\"this is a scam\") is not an event: item 3 classes it. The three non-events stay, the first covering signs as "
  "well as requests since the review of 17 November (VG): that requests or signs like this are, or follow, a known "
  "or classic scam pattern (\"a hiring process run wholly by chat is a known scam pattern\" is one); a verification "
  "question; and that the message may not come from who it names, or that who sent it is unresolved. Nor, in these "
  "four cases, are two statements about requests and patterns: that legitimate employers do not make requests like "
  "this, and that scams often use a real firm's name (VG). In JU 8 the standing employer-not-established entry, at "
  "any severity and in any words, "''')
rep(r'''  "The same three non-events are not events, nor is the standing employer-not-established entry, at any severity "''',
    r'''  "Its three non-events, the first in variant A's words (\"that requests like this are a known scam pattern\"), "
  "are not events, nor is the standing employer-not-established entry, at any severity "''')

# ---- 6.1 item 3 ----
rep(r'''  "before an offer, and given as a likelihood (\"likely\", \"very likely\", \"probably\", \"may be\"): what the "''',
    r'''  "before an offer, and given as a likelihood or an appearance (\"likely\", \"very likely\", \"probably\", \"may "
  "be\", \"looks like\", \"appears to be\", \"seems\"; VG): what the "''')
rep(r'''  "job as a whole (the owner's decision of 17 November, VW). *Flat:* resting on such a request but stated as a fact or a near-certainty (\"almost "
  "certainly\", \"definitely\", \"a classic scam\"), whatever it is said of: overconfident. (A fourth kind, "''',
    r'''  "job as a whole (the owner's decision of 17 November, VW). *Flat:* resting on such a request but stated as a fact or a near-certainty (\"almost "
  "certainly\", \"definitely\", \"a classic scam\", \"a textbook scam\", \"clearly\", \"obviously\", \"every "
  "hallmark of a scam\"; VG), whatever it is said of: overconfident. (A fourth kind, "''')
rep(r'''  "the one before or after it, quotes or names one such request or its hold. The expectation passes when every "''',
    r'''  "the one before or after it, quotes or names one such request or its hold, and of the weaker sign where they "
  "quote or name only a weaker sign; a verdict on the whole rests on a weaker sign where its sentence, or the one "
  "before or after it, rests it there; and in job-underwriter a verdict in the entry that records a weaker sign "
  "rests on that sign (VG). The expectation passes when every "''')

# ---- 6.1 examples ----
rep(r'''w("| The channel named | \"The Telegram cheque request is very likely a scam.\" (JU 8) | No event: naming the chat app "''',
    r'''w("| A request put on a party by naming its source | \"The fee Brennock asks for is very likely a scam.\" (MI 12) "
  "\"The cheque request from @VellowayHiring is very likely a scam.\" (JU 8) | Event: naming the party as the "
  "thing's sender or source puts it behind the verdict (VG); MI 12 #3 fails too | Event |")
w("| The firm named only to say it cannot be established | \"I can't establish Velloway Logistics from here; the "
  "request to pay €349 for the work kit is very likely a scam, so pay nothing yet.\" (JU 8) | No event (VG). Item 3: "
  "hedged | Event |")
w("| A claim about the sender, hedged | \"Someone is very likely impersonating Velloway.\" (JU 8) | Event: a hedged "
  "claim about the sender, a party (not changed after the review; split grades go to the adjudication rule) | Event |")
w("| The channel named | \"The Telegram cheque request is very likely a scam.\" (JU 8) | No event: naming the chat app "''')
rep(r'''w("| The request, flat | \"This cheque request is a scam.\" \"This is almost certainly a scam.\" | No event. Item 3: "
  "flat, overconfident (a near-certainty is flat). MI 12 #3 fails | Event |")''',
    r'''w("| The request, an appearance | \"This looks like a scam: don't deposit the cheque.\" (JU 8, MI 12) | No event. "
  "Item 3: hedged, an appearance is a likelihood (VG). MI 12 #3 passes | Event |")
w("| The request, flat | \"This cheque request is a scam.\" \"This is almost certainly a scam.\" \"This is clearly a "
  "scam.\" | No event. Item 3: flat, overconfident (a near-certainty is flat; \"clearly\", \"obviously\" and \"every "
  "hallmark of a scam\" are near-certainties, VG). MI 12 #3 fails | Event |")''')
rep(r'''  "overreach. MI 10 and 11 #3 fail | Event (in JU 10 a scam-type finding too, row 17) |")''',
    r'''  "overreach. MI 10 and 11 #3 fail | Event (in JU 10 a scam-type finding too, row 17) |")
w("| A bare \"this\" beside a weaker sign alone | \"'Our whole hiring process runs on Telegram…' This is very likely a "
  "scam.\" (JU 8) | No event. Item 3: overreach, said of the weaker sign (VG) | Event |")''')
rep(r'''w("| Non-event 1, the pattern | \"Being asked to pay for a work kit before you start is a known scam pattern.\" | No | "
  "No |")''',
    r'''w("| Non-event 1, the pattern | \"Being asked to pay for a work kit before you start is a known scam pattern.\" \"A "
  "hiring process run wholly by chat is a known scam pattern.\" (the template's gate example; MI 10 and 11 #3 pass "
  "it, VG) | No | No, for the first; the second is a sign, outside `no_accusation`'s words, read by what it implies "
  "about the employer |")
w("| What genuine employers do, and borrowed names | \"Legitimate employers don't ask you to pay for equipment or "
  "deposit a cheque for them.\" \"Scammers often use real company names.\" | No (VG) | Not a named non-event: read by "
  "what it implies about the employer |")''')

# ---- 6.1 Core #3 and item 3 agree ----
rep(r'''  "on the invite, the message, the posting, the offer or the job as a whole, that names no firm or person is part "
  "of the warning and passes (the owner's decision of 17 November); a flat verdict (a near-certainty included), a "
  "verdict that names a firm or a person, or any verdict where the invite makes no such request (MI 10 and 11, whose "''',
    r'''  "on the invite, the message, the posting, the offer or the job as a whole, that puts no firm or person behind it "
  "is part of the warning and passes (the owner's decision of 17 November); a flat verdict (a near-certainty "
  "included), a verdict said of a party or that puts one behind the thing (by a possessive, a name before the thing "
  "or naming it as the thing's sender or source, as item 2 reads it since VG), or any verdict where the invite makes "
  "no such request (MI 10 and 11, whose "''')
rep(r'''  "the whole as hedged where #3 passes it, so no sentence passes one and fails the other (a verdict that names a "
  "party is item 2's, and fails #3 too). So in MI 10 and 11 a verdict counts against the core screen as well as in "''',
    r'''  "the whole as hedged where #3 passes it, so no sentence passes one and fails the other (a verdict that puts a "
  "party behind it is item 2's, and fails #3 too). So in MI 10 and 11 a verdict counts against the core screen as well as in "''')

# ---- D2: the lint summary, and 3g ----
rep(r'''  "requests the invite makes; every fixture is variant B's but for JU 8 #6 and #18, MI 10–12 #3, #4 and the last and "''',
    r'''  "requests the invite makes; every fixture is variant B's but for JU 8 #5, #6 and #18, MI 10–12 #3, #4 and the last and "''')
rep(r'''  "person; `request_verdicts` has three kinds and no Whole; against the build before the decision only those two "
  "clauses and the one bullet line in each reference file change; the new sentences share no three-content-word "
  "run with a fixture prompt or page); and `check_skills.py --only answer-keys --only fixtures --only evals` "
  "passes).\n")''',
    r'''  "person; `request_verdicts` has three kinds and no Whole; against the build before the decision only those two "
  "clauses, the three per-case lines (JU 8 #5, MI 10 #3, MI 11 #3) and the one bullet line in each reference file "
  "change, read from the decision's own output saved before its review; the new sentences share no "
  "three-content-word run with a fixture prompt or page); the review of that change (3g: against the build before "
  "it only `no_party_accusation`, `no_fraud_claim`, `invite_pointer` and both `request_verdicts` change, each exactly "
  "by its VG replacements, and the five per-case lines JU 8 #5, MI 10 #3 and #9 and MI 11 #3 and #6; `no_accusation` "
  "word for word as before; every file of both trees but the two `evals.json` files byte for byte as before; the "
  "first non-event covering signs, appearance words hedged and certainty markers flat, the two statements about "
  "requests and patterns in the party bars alone, the sender-or-source reading and the firm-only carve-out in the "
  "party bars and `invite_pointer`, the bare-\"this\" reading of a weaker sign, and both `request_verdicts` "
  "parallel); and `check_skills.py --only answer-keys --only fixtures --only evals` passes).\n")''')

# ---- D6: the meter, through the shared helper, with conclusions that follow the reading ----
rep(r'''meter_dir = Path("/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/fixround/round/meter")
last = sorted(p for p in meter_dir.glob("*.json") if "guard" not in p.name)[-1]
r0 = round(json.loads(last.read_text())["unifiedWindows"]["seven_day"]["utilization"] * 100)
stamp = re.match(r"(\d{4})(\d{2})(\d{2})T(\d{2})(\d{2})", last.name).groups()
''', r'''import importlib.util as _ilu  # noqa: E402
_ml_spec = _ilu.spec_from_file_location("meter_latest", Path(__file__).resolve().parent / "meter_latest.py")
ML = _ilu.module_from_spec(_ml_spec)
_ml_spec.loader.exec_module(ML)
METER = ML.latest()       # the same file make_manifest.py and finish_manifest.py read (records fix D6)
r0 = METER["r0"]
''')
rep(r'''w(f"- **From the last recorded reading,** {r0}% at {stamp[3]}:{stamp[4]} UTC on {int(stamp[2])} November (the "
  f"design pass's last read, before this build): planning puts Opus's start at {trace_p[-1][1]:.1f}% and its end at "
  f"{cp:.1f}%, inside every rule. The observed rates put Opus's start at {trace_o[-1][1]:.1f}%, inside its "
  f"{rows10[-1][3]:.1f}% limit, but its end at {co:.1f}%: the guard would stop it at 95% after about "
  f"{(95 - trace_o[-1][1]) / pm['opus']['observed_points'] * 100:.0f}% of the step, the rest would be killed and "
  f"resumed after Thursday's 06:00 UTC reset, and 1a would land on Thursday. Any use between that reading and "
  f"preflight, this build and the manifest work among it, comes off both margins point for point.")''',
    r'''_mc = ML.chain(r0, cost)
assert [round(x["start_p"], 6) for x in _mc] == [round(v, 6) for _, v in trace_p], (_mc, trace_p)
assert [round(x["start_o"], 6) for x in _mc] == [round(v, 6) for _, v in trace_o] and _mc[-1]["limit"] == rows10[-1][3]
_op_p, _op_o = ML.opus_sentences(r0, cost)
w(f"- **From the last recorded reading,** {r0}% at {METER['stamp']} (the latest on file): "
  f"{ML.approved_sentence(r0, cost)}; {_op_p}; and {_op_o}. Any use between that reading and preflight comes off "
  f"both margins point for point.")''')

# ---- owner question 15 (b), refined by VG ----
rep(r'''     "\"almost certainly\", \"definitely\" and \"a classic scam\" count as flat. (c) \"Is it legit?\" C-4's four "''',
    r'''     "\"almost certainly\", \"definitely\" and \"a classic scam\" count as flat; since the review of the 17 "
     "November change (VG), an appearance (\"looks like\", \"appears to be\", \"seems\") also counts as hedged, and "
     "\"clearly\", \"obviously\", \"a textbook scam\" and \"every hallmark of a scam\" count as flat. (c) \"Is it "
     "legit?\" C-4's four "''')

P.write_text(src, encoding="utf-8")
print(f"patched {P}")
