r'''p_finish.py: records fixes D6 and D7 and the VG readings in build/finish_manifest.py, by exact replacements each
asserted to occur once: the meter reading read from the latest file (make_manifest.py now writes section 18's lines;
this script checks the manifest and the spec quote the same reading and writes it into the owner summary), the
stand-in freeze claim as rerun, and two plain sentences on the graders' readings in the owner summary. Run once.'''
from pathlib import Path

P = Path(__file__).resolve().parents[2] / "build" / "finish_manifest.py"
src = P.read_text(encoding="utf-8")
assert "meter_latest" not in src, "already patched"


def rep(old, new):
    global src
    n = src.count(old)
    assert n == 1, (n, old[:100])
    src = src.replace(old, new, 1)


rep(r'''first candidate commit 0d68817. Offline.
''', r'''first candidate commit 0d68817; and, after the review of that change, the graders' readings in plain words and the
latest meter reading on file, the same file make_spec.py and make_manifest.py read (build/meter_latest.py). Offline.
''')
rep(r'''# ---- values read from the final verification ------------------------------------------------------------------------
''', r'''# ---- the latest meter reading on file, shared with make_spec.py and make_manifest.py (records fix D6) ----------------
import importlib.util as _ilu  # noqa: E402
_ml_spec = _ilu.spec_from_file_location("meter_latest", Path(__file__).resolve().parent / "meter_latest.py")
ML = _ilu.module_from_spec(_ml_spec)
_ml_spec.loader.exec_module(ML)
METER = ML.latest()
COST = json.loads((C / "out" / "cost.json").read_text())
OPUS = ML.chain(METER["r0"], COST)[-1]
assert f"**{METER['r0']}% at {METER['stamp']}**" in text, "manifest.md does not quote the latest meter reading"
assert f"{METER['r0']}% at {METER['stamp']}" in (C / "spec.md").read_text(encoding="utf-8"), \
    "spec.md does not quote the latest meter reading"
assert "44% at 19:45" not in text and "From 40%" not in text

# ---- values read from the final verification ------------------------------------------------------------------------
''')
rep(r'''    "against `runkit/expect-c.json`) passes every check, and the kit's dry run passes, its rehearsal candidate "
    "committed on the merge-back commit and refused on a parent with another tree.\n")''',
    r'''    "against the final `runkit/expect-c.json`, rerun after the last change of 17 November) passes every check, and "
    "the kit's dry run passes, its rehearsal candidate committed on the merge-back commit and refused on a parent "
    "with another tree.\n")''')
rep(r'''rep("- Last recorded reading: **40% at 16:45 UTC on Monday 16 November**, before the build, its reviews, the "
    "verification and this manifest. Monday's agent work moved the meter a little under a point an hour. "
    "R0 **[preflight]**.",
    "- Last recorded readings: **40% at 16:45 UTC** and **44% at 19:45 UTC on Monday 16 November**, the second after "
    "the build, its reviews and the second accusation version, before this verification. R0 **[preflight]**.")
''', r'''# (section 18's last recorded reading is make_manifest.py's, from the latest meter file; checked above)
''')
rep(r'''offer, invite or message. It replaces the earlier reading that only a verdict on a request passed (question 24). That reading was in force for a first Haiku attempt, which was stopped after 22 minutes and discarded: no result from it is used, and its folder is kept aside as `/var/tmp/tuesday-measure/1a-aborted-20261117T0307Z`.
''', r'''offer, invite or message. It replaces the earlier reading that only a verdict on a request passed (question 24). That reading was in force for a first Haiku attempt, which was stopped after 22 minutes and discarded: no result from it is used, and its folder is kept aside as `/var/tmp/tuesday-measure/1a-aborted-20261117T0307Z`.

**How the graders read it.** After a check of your decision the graders' instructions were made more precise, with no change to the skills: "looks like a scam" counts as hedged and "clearly" or "obviously" as overconfident, and naming the firm as the sender or source of a request ("the fee Acme asks for") counts as naming it. Saying that requests or signs like these are a known scam pattern, that genuine employers don't ask for this, that scammers often use real company names, or that a firm can't be confirmed from here is not a verdict on anyone.
''')
rep(r'''Both steps can start if the reading before preflight is 65.6% or less (61.0% at observed rates). The last reading was 44% at 19:45 UTC on Monday. A guard stops any step at 95%.''',
    r'''Both steps can start if the reading before preflight is 65.6% or less (61.0% at observed rates). The last reading was {METER['r0']}% at {METER['stamp']}. A guard stops any step at 95%.''')
rep(r'''starts at 72.5% or less). You get the meter reading then. If Opus waits for Thursday's reset, 1a lands on Thursday.''',
    r'''starts at 72.5% or less). You get the meter reading then. {OPUS_LINE}If Opus waits for Thursday's reset, 1a lands on Thursday.''')
rep(r'''# ---- owner summary ---------------------------------------------------------------------------------------------------
''', r'''# ---- owner summary ---------------------------------------------------------------------------------------------------
OPUS_LINE = ("" if OPUS["start_p"] <= OPUS["limit"] else
             f"From the last reading, the meter would stand at about {OPUS['start_p']:.0f}% when Opus's turn came, even "
             f"at the planning rates, above its {OPUS['limit']:.1f}% limit. ")
''')

P.write_text(src, encoding="utf-8")
print(f"patched {P}")
