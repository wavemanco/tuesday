r'''p_spec2.py: two wording fixes in the VG subsection of build/make_spec.py (the "is it legit?" reading holds where
the material makes such a request; G5's quotation). Exact replacements, each asserted to occur once.'''
from pathlib import Path
P = Path(__file__).resolve().parents[2] / "build" / "make_spec.py"
src = P.read_text(encoding="utf-8")
def rep(old, new):
    global src
    assert src.count(old) == 1, (src.count(old), old[:80])
    src = src.replace(old, new, 1)
rep(r'''  "likely a scam, so buy and send nothing yet.\", every clause of a warning-sign case passes it: the firm is named "''',
    r'''  "likely a scam, so buy and send nothing yet.\", every clause passes it where the material makes such a request "
  "(JU 8, MI 12): the firm is named "''')
rep(r'''a request \"{VG_RESTS[:-1]}\", and a bare \"this\" or \"it\" is said of the request as before \"{VG_BARE}\" "''',
    r'''a request \"{VG_RESTS[:-1]}\", and a bare \"this\" or \"it\" is said of the request as before, \"{VG_BARE}\" "''')
P.write_text(src, encoding="utf-8")
print(f"patched {P}")
