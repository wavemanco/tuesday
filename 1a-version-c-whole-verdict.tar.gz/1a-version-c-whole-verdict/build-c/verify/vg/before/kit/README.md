# Round 1a run kit: freeze, preflight, Haiku, Sonnet (explicit panel and Opus ready)

This kit runs round 1a's first measured steps exactly as the priced manifest sets them out
(`l1a/build-c/manifest.md`, sections 3–9, 14 and 18). It writes nothing in the repository. The only
thing it creates through the repository's git is the two detached worktrees, and freeze.sh does
that. All evidence goes to the protected run directory `$M`.

| Name | Default | Set in |
|---|---|---|
| `$M` | `/var/tmp/tuesday-measure/1a` | `kit.env` |
| `$WT_BASE`, `$WT_CAND` | `/var/tmp/tuesday-measure/1a-pins/{baseline,candidate}` | `kit.env` |
| `$REPO` | `/home/user/tuesday` | `kit.env` |
| Run log | `$M/logs/run-log.txt` | `kit.env` |

Every value in `kit.env` can be overridden from the environment. The dry runs use this to point
everything at scratch folders.

## Files

| File | What it does |
|---|---|
| `kit.env` | Paths, pins, models, flags, parts, folder names, run counts, stop-rule constants. |
| `make_expected.py` | Writes the expected-values file from an offline build. Prints which values are missing from the manifest. |
| `freeze.sh` | Checks the pins, creates the worktrees, holds every value to the expected file, then writes `$M/frozen` (read-only), `$M/baseline` and `$M/checkrun`. |
| `preflight.sh` | Offline checks, then the meter (R0), the save probe in both plugin installs and the layout checks. Writes the passing record for this CLI version. |
| `run_step.sh` | Runs one measured step under the stop rule and the 95% guard. Also has `--plan` (offline argument check) and `--recovery` (killed-run commands). |
| `tools/meter.py`, `tools/save_probe.py`, `tools/layout_check.py`, `tools/guard.sh`, `tools/logged.sh` | Copies of the fix round's tools, with paths changed to `$M` and the worktrees. Changes beyond paths: the save probe keeps each session's init skill list; the layout check reads 1a's two plugin installs; the meter also logs the reset time; the guard compares in exact decimals and sends KILL 60 s after TERM. |
| `lib/stop_rule.py` | The start rule, the guard comparison and the chained projection from R0, in exact decimals. Has a self-test. |
| `lib/pin_values.py`, `lib/freeze.py` | Compute every digest, hash and E23 file from one tree with that tree's own harness. Compare them and write the frozen folder. |
| `lib/dry_runner.py` | Runs a step's exact argument list through the pinned runner's own `main()`. It stops at the first session, so `--expect`, parsing and the run plan are all checked with no call. |
| `lib/preflight_checks.py` | Sentinel declarations, account-email scan setup, and synthetic layout files for the offline run. |
| `dry/dry_run.sh` | Every offline check, from scratch. Results are in `dry/results.txt`. |
| `expected/expected-A.json`, `expected-B.json` | Expected values from builds A and B, used as worked examples and by the dry run. |

freeze.sh copies the kit into `$M/frozen/kit/` and records each file's hash in
`$M/frozen/freeze.json`. Everything after the freeze runs from that copy.

## Before the freeze (the session agent)

1. **Candidate commit.** Commit version C as one commit on a parent whose tree equals `7b56c17`'s: a revert
   of the first candidate commit `0d68817` (built before the owner's decision of 17 November), which itself
   sits on the branch's merge-back commit `5696742`, on `claude/skill-job-underwriter-95xjz8`, the only
   pushable branch (never force-pushed). The source edits, then `ci/sync.py` and `ci/package.py`. Push it.
   Note the SHA.
2. **Manifest with C's values.** `l1a/build-c/manifest.md`, written by `make_manifest.py` and
   `finish_manifest.py`, prints version C's digests, case hashes and E23 hashes; check them, don't hand-edit.
3. **Expected values.** Once `l1a/build-c` is done (it needs `tree/`, `tree-harness/`, `e23/` and exactly
   one candidate `patches/*.name-status` besides `H.name-status`), run:

   ```
   python3 -I -B make_expected.py --build <scratchpad>/l1a/build-c --variant C \
       --out expect-c.json --manifest <the manifest the owner approves>
   ```

   This takes a few seconds. It must end with `N of N values printed there`. Every
   `NOT IN THE MANIFEST` line is a disagreement between the build and the manifest, and it is settled
   before the freeze.
4. **Nursing register.** Search the public nursing register once for the invented PIN (manifest section 21).
   This step is manual.
5. **Variant C's shape.** If C creates or removes a file, freeze stops on its own (the manifest requires
   every candidate path to be `M`). If C changes the rooms or the fixtures that plant values, update
   `PART_RUNS` in `kit.env` and `KINDS` in `lib/preflight_checks.py` to match the manifest. The plan check
   compares the runner's plan against them.

## The order of commands

Run long steps in the background (for example `nohup … &`) and follow
`$M/logs/status/<model>-<step>.status`. Its last line is `done` or `stopped`. Durations come from the fix
round's run log (`fixround/round/run-log.txt`), scaled to 1a's run counts.

| # | Command | What it checks or does | Expected time |
|---|---|---|---|
| 1 | `./freeze.sh <candidate SHA> expect-c.json` | See "freeze.sh checks" below. Writes `$M/frozen` (about 77 files: case files, 7 E23 files, the explicit suite, the probe case file, the scorer, 46 expect files, the kit, the manifest, `freeze.json`), `$M/baseline` (3,241 files) and `$M/checkrun` (1,220). All are read-only, and their listing hashes go to the run log. | 15–30 s (rehearsal: 15 s) |
| 2 | `$M/frozen/kit/preflight.sh` | See "preflight.sh checks" below. | 3–5 min. Offline part under 1 min; save probe 33 s and layout check 26–61 s in the fix round. |
| 3 | `$M/frozen/kit/run_step.sh haiku quality` | Haiku step, starts at a reading of 80% or less. | About 3 h 10 min (2.6–3.8 h): arms about 2 h 25 min, then E23 about 45 min |
| 4 | `$M/frozen/kit/run_step.sh sonnet quality` | Sonnet step, starts at 74.54% or less. | About 5 h 05 min (4.3–6.0 h): arms about 3 h 53 min, then E23 about 1 h 13 min |
| 5 | `$M/frozen/kit/run_step.sh all explicit --owner-go "<the owner's words>"` | Explicit panel, three models in parallel. Starts at 80% or less, not on a Friday. **Not started without the owner.** | About 20–25 min (fix round: 8.5 / 17.3 / 20.4 min) |
| 6 | `$M/frozen/kit/run_step.sh opus quality --owner-go "<the owner's words>"` | Opus step, starts at 72.5% or less. **Not started without the owner.** | About 4 h 45 min (4.0–5.7 h): arms about 3 h 35 min, then E23 about 1 h 10 min |

How the times are worked out:

- Each run costs, in minutes per arm with 3 workers and two graders: Haiku 0.50–0.75 (job-underwriter)
  and 1.23 (mock-interview); Sonnet 0.92–1.08 and 1.98–2.10; Opus 0.96–0.99 and 1.95–1.97.
- Each arm runs 70 job-underwriter runs and 75 mock-interview runs.
- E23 runs 35 runs in seven 5-run calls, which costs about 20% more per run.
- The guard reads the meter about 9, 15 and 14 times in the three model steps.

**Before each step, `run_step.sh` checks:**

- `$M/frozen` is unchanged (its listing hash).
- Both worktrees are at their frozen pins and clean.
- A passing preflight exists for the current CLI version.
- The owner's go is given (explicit and Opus).
- Today is not a weekday the frozen explicit suite names (explicit).
- No output folder exists yet.
- The CLI's signed-in account email (`oauthAccount.emailAddress` in `~/.claude.json`, read by `lib/account_email.py`) is present. It is exported as `TUESDAY_SCAN_ACCOUNT_EMAIL` and never printed. It is the address the measured sessions can see; `git config user.email` here holds the commit trailer's no-reply address and is not used.

**Stop rule.** run_step.sh reads the meter, then refuses to start unless both hold:

- the reading is at or below the step's threshold;
- the reading plus the step's high estimate is 90% or less.

The high estimates are: Haiku 3.44, Sonnet 15.46, explicit 1.25, Opus 17.50, preflight 5.50. Time, CLI
and meter are logged before and after the step.

**Running the step.** The driver starts in its own process group. The guard reads the meter every
20 minutes and stops the group at 95% or more: TERM, then KILL 60 s later if needed.

A quality step runs both arms together. Each arm runs its four parts in order from `$WT_CAND`, then the
seven E23 replays run from `$WT_BASE`, with the module alone:

| Part (expect file) | `--out` folder | Selection | Runs per arm |
|---|---|---|---:|
| `ju-existing` | `part-1` | `--skill job-underwriter --eval 1…6` | 40 |
| `ju-new` | `part-4` | `--eval 7…11` | 30 |
| `mi-existing` | `part-2` | `--skill mock-interview --eval 1…8` | 50 |
| `mi-new` | `part-5` | `--eval 9…13` | 25 |
| E23 replays | `e23/part-1` … `e23/part-7`, in section 5's order | one `--cases $M/frozen/e23/e23-<module>-<id>.json` per call | 5 each |

Every call carries `--runs 5 --retry-runs 0 --graders 2 --grader-model claude-sonnet-5-5 --workers 3
--timeout 900` and its own `--expect $M/frozen/expect/<model>/<arm>/<part>.json`.

**After the step:**

- Each command's exit is logged. 0, 1 and 3 are normal ends; a runner refusal stops the step.
- For explicit, each results file's hub and Tuesday hashes, case hash, arm, layout and run count are checked
  against `$M/frozen/expect/explicit.json`.
- The outputs are copied to `$M/sealed/<step>-<time>` (read-only), and the copy's listing hash goes to the
  run log.

**Output folders** (manifest section 8, owner question 26): `$M/runs/<haiku|sonnet|opus>/<alone|tuesday>/<part-1|part-4|part-2|part-5>`
(existing job-underwriter, new job-underwriter, existing mock-interview, new mock-interview),
`$M/runs/<model>/e23/part-<1…7>` (job-underwriter 7 and 8, mock-interview 9 to 13), `$M/runs/<model>/explicit.json`.
Each command's output is beside its folder as `<folder>.log`. The expect files keep the part keys
(`$M/frozen/expect/<model>/<arm>/ju-new.json`, `…/e23/job-underwriter-7.json`): they are read by the runner and never
reach a room's path.

## freeze.sh checks

The freeze stops on any mismatch, before anything is copied. It checks:

- **The candidate commit.** It is one commit, on one parent, and that parent's tree equals `7b56c17`'s tree
  (`git rev-parse "$CAND^^{tree}"` against `"$BASE^{tree}"`): a revert of the first candidate commit `0d68817`,
  which sits on the branch's merge-back commit `5696742`, since the candidate cannot sit directly on `7b56c17` and
  the branch is never force-pushed. The check needs no change for it: it compares trees, and the revert's tree is
  `7b56c17`'s. `freeze.json` logs the parent's
  SHA and tree beside the baseline's SHA and tree. Both pins are on a remote branch.
- **Path lists.**
  - `git diff --name-status` from the baseline equals the build's candidate list, all `M`.
  - From `8e72375` to the baseline it equals the H list.
  - Nothing changes under `evals/*.py`, `ci/sync.py`, `ci/package.py`, `conventions/` or `skills/resume-tailor/`.
- **The trees.** Both worktrees equal the build's `tree` and `tree-harness` byte for byte.
- **Digests and hashes, at both pins:**
  - `check_skills.tuesday_digests()`
  - `run_fixtures.payload_digests()`
  - `MEASURED_TUESDAY`
  - the 14 dependency hashes
  - the runner's 15-file inventory
  - the grader prompt hash
  - the case-file hashes
- **The candidate's fixtures.** The room modes and planted sentinel kinds match the build.
- **The E23 files.** All seven are regenerated from the candidate. Their hashes match, they expand to the
  treatment's expectations, and they equal the build's byte for byte.
- **The copies.** The scorer, the subsets and the re-check report match their hashes. The baseline and
  checkrun copies match their listing hashes.

## preflight.sh checks

1. The freeze is unchanged, the pins are clean, and the kit files are the ones the freeze hashed.
2. The CLI version, the host, UID 0 and the scratchpad root `/tmp/claude-0`. UID 0 is required because
   `run_fixtures.sidecar_dirs` reads scratchpads only under `/tmp/claude-0`.
3. User settings hold no Tuesday plugin or personal Tuesday skill. The account's synced catalog holds its
   own `mock-interview`. That is noted, because `child_env` drops `CLAUDE_CODE_SYNC_SKILLS` and step 7's
   init lists show what each session loads.
4. Sentinel declarations. Every frozen case file and E23 file is checked with the pinned reader. The kinds
   must match manifest section 9, and `ci/check_skills.py --only fixtures` must pass on the candidate.
5. The account-email scan:
   - the address is read from the CLI's signed-in account (`lib/account_email.py`) and never printed;
   - it is read as one runtime sentinel;
   - the matcher finds it;
   - masking removes it;
   - it appears 0 times in `$M/frozen` and both worktrees.
6. Every step's command lines, run through the stubbed runner with `claude` off PATH. Haiku, Sonnet and Opus
   are 15 lines each, explicit is 3, plus the layout probe line. Each must be accepted with its expect file
   and plan exactly the priced runs.
7. The meter R0 under the preflight rule (80% or less). This prints the chained projection for every
   step and the reset time.
8. The save probe in both plugin installs and the layout probe. These are Haiku sessions, run in parallel
   as in the fix round. `layout_check.py` reads the routing file and the probe's init lists. The meter is
   read again after.

Preflight writes `$M/logs/preflight/ok-<CLI>.json`. A new CLI version needs a new preflight; run_step.sh
refuses until one passes. `preflight.sh --offline` (the dry run) starts no session. It writes an
`.offline.json` record, which a measured step never accepts.

## What to do when something fails

| Failure | What it means | What to do |
|---|---|---|
| `FREEZE STOPPED` (any line `STOP`) | A pin, path list, digest, hash or copy differs from the expected values | Stop for the owner. Nothing was copied. Do not edit the expected file to match the pins. Find which side is wrong (the commit or the build). |
| freeze: `$M/frozen exists` | A freeze is never redone | Move it aside only on the owner's word. |
| freeze: on no remote branch | A pin is not pushed | Push it, then freeze. |
| preflight `FAIL` in steps 1–6 | Offline problem: freeze changed, dirty worktree, user settings, sentinel lists, email scan, or a command line the runner refuses | Stop for the owner. No session was started. The report is `$M/logs/preflight/preflight-<time>.txt`. |
| preflight: stop rule bars it | R0 is above 80% | Wait for the reset (Thursday 06:00 UTC), or get an owner-approved reset. There is no exception. |
| save probe `FAIL` or `INCONCLUSIVE` | A save into the room was refused, or the plugin's own SKILL.md was writable or not attempted | Stop for the owner. Rerun only after the cause is found. Each rerun goes to a new folder. |
| layout check `FAIL` | A session listed a Tuesday-family skill it did not install, or the hashes are not the candidate's | Stop for the owner. Check the user's `~/.claude` and the CLI version. |
| run_step: `NOT STARTED` | A pre-check or the stop rule refused (the reason is in the line) | Fix the cause. For the stop rule, wait for the reset. Nothing ran. |
| run_step: `REFUSED by the runner` | `--expect` found a difference in payload, harness or settings before any call | Stop for the owner. Remaining commands are not started. The step's partial folders hold only pass records. |
| Exit 1 or 3 from a part | 1: failures found. 3: runs set aside or unresolved. | Normal ends under `--retry-runs 0`. Score them. |
| `STOPPED BY THE GUARD` (exit 4) | The meter reached 95%. Unfinished runs are killed runs. | After the reset, follow `run_step.sh <model> <step> --recovery`: `--killed --move` per part, then `--stems` reruns under their own stems on the same pins and flags. Run them with logged.sh, under the stop rule and the guard. |
| Usage-limit kill or container restart | Runs ended without a result | Same as above. After a restart, rerun at once. After a usage kill, rerun after the reset. Finished runs are kept. |
| Missing grades | `--grade-gaps` lists them | `--grade-gaps --move` (add `--accept-partial` on the owner's word), then `--stems … --skip-execute` (the `--recovery` lines). |
| Explicit results differ from the freeze (exit 6) | Wrong digests or cases in a results file | Stop for the owner. |
| Explicit run killed | Runs in an arm ended without a result | Rerun the killed cases into a new results file, then use the runner's tested `--merge`. An arm with no completed results starts again as an arm. |
| CLI changed mid-week | The runner notes it and never refuses | run_step.sh refuses the next step until preflight passes on the new CLI. |

## Points for the session agent and the owner

- **The manifest's explicit command needs one change.** Section 8 prints `run_routing.py … --expect <hub>
  <tuesday>`, but `run_routing.py` accepts `--expect` only with `--merge` and exits at once otherwise. The
  dry run shows this. The kit drops `--expect` from the explicit command and checks the same hashes
  (and the case hash) on each results file after the run. The manifest's section 8 row is corrected.
- **The output folder names reach the model.** Each room's path, and the plugin folder beside it, sits under
  the `--out` folder, and the CLI shows the room path to the model. The draft's names (`ju-new`, `mi-new`,
  `e23/job-underwriter-7`) abbreviated or named the module, against evals/README.md ("Through Tuesday": a room
  never names its module). Question 26 is taken as recommended (16 November, by the session under the owner's
  approval of the manifest's recommendations; reversible before the freeze): neutral `part-1` and `part-2` for the
  existing rooms, as in the fix round's baseline, `part-4` and `part-5` for the new ones, and `e23/part-1` to
  `e23/part-7` for the replays. They are set in two maps in `kit.env`, `PART_FOLDER` and `E23_FOLDER`; the plan,
  the recovery commands and the seals read them from there, and nothing else depends on them.
- **Expect files are per invocation**, not one per step and revision. There are 45 fixture-runner files
  and one explicit file. Each freezes the payload digests, the 15-file inventory and every setting,
  including the case file's hash, so a wrong arm, model or case file is refused before any call.
- **The CLI is 2.1.326** (meter reading of 16 Nov 23:03). The saved baseline ran on 2.1.322. Each expect
  file lists the CLI read at the freeze under `preflight`, and preflight must pass on that version.
- **Measured sessions inherit `TUESDAY_SCAN_ACCOUNT_EMAIL`.** `child_env` does not drop it. Bash is
  refused in the rooms, so a session cannot read it, but it is in each session's environment. This is
  noted only: the harness is frozen.
- **The E23 replays follow the arms**, as the manifest orders. Running them as a third lane at the same
  time would save about 45–75 minutes per step, but it is not in the manifest.

## Dry run

`bash dry/dry_run.sh` runs everything offline. It takes about 2 minutes, with `claude` off PATH and no
network. It touches no model, no runner execution and nothing in the repository: `git archive` and a
shared clone in `dry/` only. It covers:

- Syntax, and the self-tests of the stop rule, save probe, meter parser and layout check.
- `make_expected.py` on builds A and B, including the manifest cross-check.
- The stand-in pair: both pins from `git archive 7b56c17`.
- The rehearsal: a scratch clone with variant A's candidate committed on the branch's merge-back commit
  `5696742` (a merge whose tree equals `7b56c17`'s), from freeze to every step's plan. The freeze accepts that
  parent and refuses the same candidate committed on a parent with a different tree (`7b56c17`'s own parent).
- Simulated steps with a fake meter and the stubbed runner: starts, refusals, a guard stop, and sealing.
- An account-email leak check over everything the kit wrote.

The results are in `dry/results.txt`.
