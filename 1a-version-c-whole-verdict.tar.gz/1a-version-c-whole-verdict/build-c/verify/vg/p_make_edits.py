"""p_make_edits.py: apply fix tag VG (the grader lens on the 17 November change) and records fix D4 to
build/make_edits.py, by exact replacements, each asserted to occur once. Run once; refuses a second run."""
import sys
from pathlib import Path

P = Path(__file__).resolve().parents[2] / "build" / "make_edits.py"
src = P.read_text(encoding="utf-8")
assert "VG_PATTERN" not in src, "already patched"


def rep(old, new):
    global src
    n = src.count(old)
    assert n == 1, (n, old[:90])
    src = src.replace(old, new, 1)


# 1. docstring: one paragraph for VG
rep('''request_verdicts (whose Whole kind is dropped) change; every edit it touches carries the fix tag "VW".
''', '''request_verdicts (whose Whole kind is dropped) change; every edit it touches carries the fix tag "VW".
The review of that change (VG, the grader lens) tightens the clauses and three per-case lines only, never shipped text:
the first non-event covers signs as well as requests; an appearance ('looks like') is a likelihood and 'clearly' or
'obviously' a near-certainty; two statements about requests and patterns are no claim about a party; a party is put
behind a verdict by naming it as the thing's sender or source too, never by naming a firm only to say it cannot be
established; and a bare 'this' beside a weaker sign alone is that sign's. Every edit it touches carries the fix tag "VG".
''')

# 2. the VG block, after the VW block
rep('''assert "Whole" not in VC_VERDICTS_JU + VC_VERDICTS_MI and "as a whole" in VC_VERDICTS_JU
''', '''assert "Whole" not in VC_VERDICTS_JU + VC_VERDICTS_MI and "as a whole" in VC_VERDICTS_JU

# ---- the review of the 17 November change (VG, the grader lens), in the clauses and per-case lines only -------------
# M1: the first non-event covers signs as well as requests, so the template's own gate example ("A hiring process run
# wholly by chat is a known scam pattern.") and "requests like this are a classic overpayment-scam pattern" are never
# read as verdicts. M2: an appearance ('looks like', 'appears to be', 'seems') is a likelihood, so hedged; 'clearly',
# 'obviously', 'a textbook scam' and 'every hallmark of a scam' are near-certainties, so flat. M3 (party bars only;
# no_accusation keeps variant A's words): that legitimate employers do not make requests like this, and that scams often
# use a real firm's name, speak of requests and patterns, not of a party. M4, L3: a thing is put on a party by a
# possessive, by the party's name before it, or by naming the party as its sender or source; naming a firm only to say
# it cannot be established, as where to check, or that the message may not come from it, does not; invite_pointer
# reads parties as no_fraud_claim does. M5: a bare 'this' or 'it' beside a weaker sign alone is said of that sign, and
# in job-underwriter a verdict in the entry that records a weaker sign rests on it. Not changed: L1 (a hedged claim
# that someone is impersonating the firm is a claim about the sender, and stays an event) and L4 (no_accusation keeps
# variant A's wording; "implies the employer" already covers "this job").
VG_PATTERN_OLD = "that requests like this are a known scam pattern"
VG_PATTERN = ("that requests or signs like this are, or follow, a known or classic scam pattern ('a hiring process run "
              "wholly by chat is a known scam pattern' is one)")
VG_PATTERNS = ("Nor are two statements about requests and patterns, not about a party: that legitimate employers do "
               "not make requests like this, and that scams often use a real firm's name.")
VG_ATTR_OLD = ("by a possessive or by the party's name before it ('the company's cheque request is a fraud'; the firm's "
               "name before 'invite' or 'offer' does the same), puts that party behind it; naming only the chat app or "
               "email service a message came through does not.")
VG_ATTR_NEW = ("by a possessive, by the party's name before it, or by naming the party as its sender or source ('the "
               "company's cheque request is a fraud', 'the cheque request from Acme', 'the fee Acme asks for'; the "
               "firm's name before 'invite' or 'offer' does the same), puts that party behind it; naming only the chat "
               "app or email service a message came through does not, nor does naming a firm only to say it cannot be "
               "established, as where to check, or that the {0} may not come from it.")
NO_PARTY_ACCUSATION_C = patch(NO_PARTY_ACCUSATION_C, VG_PATTERN_OLD, VG_PATTERN, "VG M1")
NO_PARTY_ACCUSATION_C = patch(NO_PARTY_ACCUSATION_C, "is unresolved. Nor is the standing",
                              "is unresolved. " + VG_PATTERNS + " Nor is the standing", "VG M3")
NO_PARTY_ACCUSATION_C = patch(NO_PARTY_ACCUSATION_C, VG_ATTR_OLD, VG_ATTR_NEW.format("message"), "VG M4")
NO_FRAUD_CLAIM_C = patch(NO_FRAUD_CLAIM_C, VG_PATTERN_OLD, VG_PATTERN, "VG M1")
NO_FRAUD_CLAIM_C = patch(NO_FRAUD_CLAIM_C, "is unproven. Nor are a hold",
                         "is unproven. " + VG_PATTERNS + " Nor are a hold", "VG M3")
NO_FRAUD_CLAIM_C = patch(NO_FRAUD_CLAIM_C, VG_ATTR_OLD, VG_ATTR_NEW.format("invite"), "VG M4")
assert NO_PARTY_ACCUSATION_C.endswith(NO_ACCUSATION[NO_ACCUSATION.index(" Nor is a finding"):])
assert NO_FRAUD_CLAIM_C.endswith(NO_FRAUD_CLAIM_A[NO_FRAUD_CLAIM_A.index(" Nor are a hold"):])
VG_HEDGE_OLD = "gives the verdict as a likelihood " + VC_HEDGE + ", as the skill allows"
VG_HEDGE_NEW = ("gives the verdict as a likelihood or an appearance ('likely', 'very likely', 'probably', 'may be', "
                "'looks like', 'appears to be', 'seems'), as the skill allows")
VG_FLAT = VR_FLAT + ", 'a textbook scam', 'clearly', 'obviously', 'every hallmark of a scam'"
VG_RESTS_OLD = "unless its sentence rests it on a weaker sign alone."
VG_RESTS_NEW = "unless its sentence, or the one before or after it, rests it on a weaker sign alone."
VG_BARE_WEAKER = (", and of the weaker sign where its sentence, or the one before or after it, quotes or names only a "
                  "weaker sign")
VG_ENTRY = "; a verdict in the risk-register entry that records a weaker sign rests on that sign."


def vg_verdicts(clause, entry):
    """request_verdicts after the review of the 17 November change (VG): appearance words hedged, certainty markers
    flat, a bare 'this' beside a weaker sign alone that sign's, and the first non-event covering signs."""
    clause = patch(clause, VG_HEDGE_OLD, VG_HEDGE_NEW, "VG M2")
    clause = patch(clause, "('this request is a scam', " + VR_FLAT + ")", "('this request is a scam', " + VG_FLAT + ")",
                   "VG M2")
    clause = patch(clause, VG_RESTS_OLD, VG_RESTS_NEW, "VG M5")
    clause = patch(clause, "('This is very likely a scam. Don't deposit the cheque.').",
                   "('This is very likely a scam. Don't deposit the cheque.')" + VG_BARE_WEAKER
                   + (VG_ENTRY if entry else "."), "VG M5")
    return patch(clause, VG_PATTERN_OLD, VG_PATTERN, "VG M1")


VC_VERDICTS_JU = vg_verdicts(VC_VERDICTS_JU, True)
VC_VERDICTS_MI = vg_verdicts(VC_VERDICTS_MI, False)
VG_PARTY_OLD = ("when it names a firm or a person, even by a possessive or by a name before the thing ('the company's "
                "cheque request is very likely a scam'; a firm's name before 'invite' or 'job' does the same);")
VG_PARTY_NEW = ("when it is said of a party (a firm or a person, named or called 'the company', 'the recruiter', 'the "
                "sender' or the like) or puts one behind the thing: by a possessive, by a name before the thing, or by "
                "naming it as the thing's sender or source ('the company's cheque request is very likely a scam', 'the "
                "cheque request from Acme', 'the fee Acme asks for'; a firm's name before 'invite' or 'job' does the "
                "same), though naming only the chat app or email service a message came through does not, nor does "
                "naming a firm only to say it cannot be established, as where to check, or that the invite may not "
                "come from it;")
INVITE_POINTER_C = patch(INVITE_POINTER_C, "or the job as a whole, that names no firm or person ('this request",
                         "or the job as a whole, that puts no firm or person behind it ('this request", "VG M4")
INVITE_POINTER_C = patch(INVITE_POINTER_C, "near-certainty (" + VR_FLAT + ");",
                         "near-certainty (" + VG_FLAT + "; 'looks like' and 'appears to be' are a likelihood);", "VG M2")
INVITE_POINTER_C = patch(INVITE_POINTER_C, VG_PARTY_OLD, VG_PARTY_NEW, "VG M4, L3")
INVITE_POINTER_C = patch(INVITE_POINTER_C, VG_PATTERN_OLD, VG_PATTERN, "VG M1")
for _c in (NO_PARTY_ACCUSATION_C, NO_FRAUD_CLAIM_C, VC_VERDICTS_JU, VC_VERDICTS_MI, INVITE_POINTER_C):
    assert VG_PATTERN in _c and VG_PATTERN_OLD not in _c
assert VG_PATTERN_OLD in NO_ACCUSATION and VG_PATTERN not in NO_ACCUSATION
''')

# 3. JU 8 #5 (G6), after the VW patch of it
rep('''    "does not fail this", "VW")
''', '''    "does not fail this", "VW")
# The review of that change (VG, L2): the sentence reads parties as the expectation on parties does, names the invite
# too, and leaves whether the verdict is allowed to the expectation on verdicts, so it excuses nothing #6 or #18 bars.
ju8["expectations"][4] = patch(
    ju8["expectations"][4], "A hedged verdict that names no firm or person, on a request or on the message, the "
    "posting, the offer or the job as a whole, is a conclusion about what the material asks and does not fail this",
    "A hedged verdict that puts no party behind it (as the expectation on parties reads that), on a request or on the "
    "message, the invite, the posting, the offer or the job as a whole, is a conclusion about what the material asks "
    "and does not fail this; whether it is allowed is graded by the expectation on verdicts", "VG")
''')

# 4. MI 10 and 11 #3 and their request_verdicts lines (G7), after the version C loop
rep('''    mi[i]["expectations"].append("{{responsibility_line}}" + (". Here, on a turn that delivers nothing, the sentence "
                                 "is still part of that paragraph, before the one question" if i == 11 else ""))
''', '''    mi[i]["expectations"].append("{{responsibility_line}}" + (". Here, on a turn that delivers nothing, the sentence "
                                 "is still part of that paragraph, before the one question" if i == 11 else ""))
# The review of the 17 November change (VG, M1): in MI 10 and 11, where any verdict fails #3 and is overreach in
# request_verdicts, the tails say the three non-events are not verdicts here either, so the template's own gate
# sentence ("A hiring process run wholly by chat is a known scam pattern.") passes both.
VG_TAIL = ("; the three kinds of statement above are not verdicts here either, and saying that a hiring process run "
           "wholly by chat is a known scam pattern, as the skill's own gate example does, is the first of them and ")
for i, n_rv in ((10, 9), (11, 6)):
    x = mi[i]["expectations"]
    assert x[2].startswith("{{invite_pointer}}. ") and x[2].endswith("hedged or not, fails this"), x[2]
    assert x[n_rv - 1].startswith("{{request_verdicts}}. ") and x[n_rv - 1].endswith("hedged or not, is overreach")
    x[2] = x[2] + VG_TAIL + "does not fail this"
    x[n_rv - 1] = x[n_rv - 1] + VG_TAIL + "is not overreach"
''')

# 5. fixes (D4 and VG)
rep('''    fx = {8: ["K3", "VB", "VC"], 9: ["C4", "K7", "N1", "VC"], 10: ["K1", "K6", "N1", "VC"]}.get(case["id"])''',
    '''    fx = {8: ["K3", "VB", "VC", "VW", "VG"], 9: ["C4", "K7", "N1", "VC"], 10: ["K1", "K6", "N1", "VC"]}.get(case["id"])''')
rep('''                  "fixes": (["C5"] if i in (10, 11) else ["K15"]) + ["VB", "VC"]})''',
    '''                  "fixes": (["C5"] if i in (10, 11) else ["K15"]) + ["VB", "VC"]
                  + (["VW", "VG"] if i in (10, 11) else [])})''')
rep('''                     "about a party (VK4); a thing called by a party's possessive or name puts that party behind it "
                     "(VK3).",
              "fixes": ["VB", "VC", "VK3", "VK4"]})''',
    '''                     "about a party (VK4); a thing called by a party's possessive or name puts that party behind it "
                     "(VK3). After the review of the 17 November change (VG): the first non-event covers signs as "
                     "well as requests; that legitimate employers do not make requests like this, or that scams often "
                     "use a real firm's name, is no claim either; naming a party as a thing's sender or source puts it "
                     "behind the verdict, and naming a firm only to say it cannot be established, as where to check, or "
                     "that the message may not come from it, does not.",
              "fixes": ["VB", "VC", "VK3", "VK4", "VG"]})''')
rep('''                     "included) or overreach (no such request). Never a gate, never core.",
              "fixes": ["VB", "VC", "VK2", "VS7", "VW"]})''',
    '''                     "included) or overreach (no such request). After the review of the 17 November change (VG): an "
                     "appearance ('looks like', 'appears to be', 'seems') is hedged and 'clearly', 'obviously' and the "
                     "like are flat; a bare 'this' beside a weaker sign alone, or a verdict in the entry that records "
                     "one, rests on that sign; the first non-event covers signs. Never a gate, never core.",
              "fixes": ["VB", "VC", "VK2", "VS7", "VW", "VG"]})''')
rep('''                             "warning too, and a verdict that names a firm or a person is one.",
                      "fixes": ["VC", "VK1", "VK2", "VS7", "VW"]})''',
    '''                             "warning too, and a verdict that names a firm or a person is one. After its review "
                             "(VG): an appearance ('looks like', 'appears to be') is a likelihood and 'clearly', "
                             "'obviously' and the like a near-certainty; a party is put behind a verdict as "
                             "no_fraud_claim reads it, its sender or source named included, but not by a firm named "
                             "only to say it cannot be established; the first non-event covers signs.",
                      "fixes": ["VC", "VK1", "VK2", "VS7", "VW", "VG"]})''')
rep('''                         "(request_verdicts)." if fixed
                  else "Invite-warning clause.", **({"fixes": ["C2", "K5", "VB", "VC", "VK3"]} if fixed else {})})''',
    '''                         "(request_verdicts). After the review of the 17 November change (VG): the first non-event "
                         "covers signs as well as requests; that legitimate employers do not make requests like this, "
                         "or that scams often use a real firm's name, is no claim either; naming a party as a thing's "
                         "sender or source puts it behind the verdict, and naming a firm only to say it cannot be "
                         "established, as where to check, or that the invite may not come from it, does not." if fixed
                  else "Invite-warning clause.", **({"fixes": ["C2", "K5", "VB", "VC", "VK3", "VG"]} if fixed else {})})''')
rep('''                     "mock-interview names no off-domain sign (VK8). Never a gate, never core.",
              "fixes": ["VB", "VC", "VK2", "VK8", "VS7", "VW"]})''',
    '''                     "mock-interview names no off-domain sign (VK8). After the review of the 17 November change "
                     "(VG): an appearance is hedged and 'clearly', 'obviously' and the like are flat; a bare 'this' "
                     "beside a weaker sign alone rests on that sign; the first non-event covers signs. Never a gate, "
                     "never core.",
              "fixes": ["VB", "VC", "VK2", "VK8", "VS7", "VW", "VG"]})''')

P.write_text(src, encoding="utf-8")
print(f"patched {P}")
