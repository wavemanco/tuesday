**Short answer: probably yes, but hold off until you know whether this role is remote or based in Leeds.** Status: `hold_pending_answers`.

Your fit on the stated requirements is strong. The posting contradicts itself on location, though, and that could decide this for you.

## Decision snapshot

**Probably worth applying to. Status: `hold_pending_answers`.** The hold waits on the location answer (R1, RR1) and on your own constraints, which you haven't given me.

**Fit ledger.**

- `hard_gate`: unclear: R1 (Work location)
- `must_have`: direct: R2, R3, R4, R5
- `important`: direct: R7, R8 · adjacent: R6 (Pet-insurance product pricing)
- `preferred`: direct: R9

R6 is a credible bridge, its limit named. R1 is unresolved because the JD and the careers page disagree.

**Opportunity ledger.** The scope is clear and the hiring manager's public record fits the work (RR4). Against that, the location terms conflict across sources (RR1), no salary is shown (RR2), and the employer's footprint outside its own site is thin (RR3).

- **Hard gates:** unconfirmed: R1 (Work location: JD says fully remote UK, careers page says Leeds four days a week); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **What would change this:** If the role is Leeds four days a week and that doesn't work for you, this becomes `no_go`. If it's genuinely remote and the employer confirms it, the status moves to `conditional_go`, capped there by RR3 until the employer is confirmed as established.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, insurtech; its careers page is live and matches the posting | `[grounded]` careers page fetched |
| Mandate | Own pricing analytics for the pet-insurance product: build and monitor rating models, design and read price tests, turn results into recommendations for underwriting and product | `[grounded]` JD |
| Reporting line | Reports to the Director of Pricing (Odile Varga) | `[grounded]` careers page |
| Working pattern | **Contradiction.** JD: "Fully remote (UK)." Careers page: "Leeds office four days a week." | `[grounded]` both sources |
| Management | None stated. The JD asks for no people management, so your not having managed anyone is not a gap against this role. | `[grounded]` JD |
| Scope read | A normal scope for the title: one product, with modelling, testing and recommendations | `[inferred]` from the listed duties |
| Market calibration | Senior pricing analysts at UK insurers and insurtechs: median base £58,400, interquartile range £52,100–£64,900 (n=612). The survey is not pet-specific. | `[generic]` Pricewell 2026 UK Pricing and Actuarial Analytics Pay Survey (pricewell.example/2026-uk-pricing-analytics-pricing-survey) |
| Salary | Not shown on the careers page or in the JD. The band above is what to expect, not this employer's offer. | `[grounded]` absence on both pages |
| Unknowns | Location in practice; salary; who approves rate changes once the analysis is done; team size | — |
| Contradictions | Location (above) | `[grounded]` |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Work location: fully remote UK (JD) vs Leeds four days a week (careers page) | hard_gate | unclear | low | hard_gate | The sources disagree and your location and constraints are not on file. Nothing here can be resolved from the documents. | `[grounded]` both sources | Q1 below; RR1 to the employer |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | Five years in UK motor pricing analytics, the last two as senior analyst. Stated, not yet inspectable. | `[grounded]` your statement | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | Used daily in both. Stated, not yet inspectable. | `[grounded]` your statement | none |
| R4 | GLM experience | must_have | direct | medium | none | Built and maintained the GLM rating model for the young-driver book. | `[grounded]` your statement | none |
| R5 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | Present the quarterly pricing review to the head of underwriting. | `[grounded]` your statement | none |
| R6 | Pet-insurance product pricing (implied by "our pet-insurance product") | important | adjacent | medium | transferability | Motor rating and modelling carry over. You have not priced pet cover, and pet claims behave differently (breed, age, vet-cost inflation) — that is `[generic]`. | `[inferred]` from your motor work against the product named | see G1 |
| R7 | Designing and reading price tests | important | direct | medium | none | Ran 14 price tests last year with the underwriting team. | `[grounded]` your statement | none |
| R8 | Monitoring rating models in production | important | direct | medium | none | Maintained the young-driver GLM, which implies monitoring; not described in detail yet. | `[inferred]` from R4 | none |
| R9 | Insurance experience (a plus) | preferred | direct | medium | none | Five years at a UK motor insurer. | `[grounded]` your statement | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pet-insurance pricing (R6, important) | transferability | Motor only. Adjacent: GLM build, price testing, underwriting presentation. Limit: no pet or other non-motor product. | Likely the first objection in interview. A stronger bridge narrows it. | Any non-motor product you priced, tested or monitored (home, travel, or anything with a different claims pattern); any work on claims-cost trends | A sanitized model note, a test readout, or a pricing-review excerpt | `[inferred]` bridge from your motor work; `[generic]` that pet is the likely objection |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Location terms contradict across sources | risk_signal | medium | "Fully remote (UK)." / "Leeds office four days a week." | Either the JD or the careers page is out of date, or the role is hybrid with a Leeds requirement that the JD omits. Severity held at medium because the sources conflict; no hostile reading is needed. | `[inferred]` from the two sources | "Is this role fully remote across the UK, or based in the Leeds office four days a week?" | unresolved |
| RR2 | Salary not shown | unknown | — | (no salary on either source) | The figure may sit below the band in role reality, or it may just be unpublished. | `[inferred]` from the absence, against the `[generic]` band | "What is the budgeted base salary for this role?" | unresolved |
| RR3 | Employer not established from attributable sources (standing entry) | risk_signal | medium | "Senior Pricing Analyst — Brindlemoor" | The careers page is on the company's own domain, but the broader search for "Brindlemoor insurtech pet insurance" returned nothing. The company may be too new or small for a footprint, the posting may be stale, or the employer may be less established than its site suggests. Severity stays medium. | `[generic]` pattern for companies of this size, not a claim about this one | "Who would I be interviewing with, and what is the team size?" | unresolved |
| RR4 | Hiring manager's public record fits the work | positive_signal | — | (public profile, search snippet only, not fetched) | Odile Varga, Director of Pricing; previously head of pricing analytics at Calloway Re for six years; spoke at the 2025 Insurance Pricing Forum on monitoring rating models in small books. Lead with GLM monitoring. | `[grounded]` public profile snippet | — | noted |
| RR5 | Decision rights on rate changes unstated | unknown | — | "turn the results into recommendations for underwriting and product" | The role recommends. Who approves a rate change is not stated. | `[inferred]` from the verb "recommendations" against the silence on sign-off | "Who signs off a rate change once the analysis is done?" | unresolved |

**Severity note:** none of these is a severe red flag. The posting contains no request for payment, deposits or bank details, and nothing in it suggests one.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm the location with the employer before investing in the application | RR1, R1 | `[grounded]` the contradiction | pending your approval |
| A2 | Ask RR2, RR3 and RR5 verbatim at first contact | The register doubles as interview prep | `[grounded]` register | pending your approval |
| A3 | Lead with GLM monitoring and price-test readouts when writing to Odile Varga | RR4, R4, R7 | `[generic]` positioning for this reader | pending your approval |
| A4 | Frame pet as an adjacent bridge, never as direct experience | R6, G1 | `[grounded]` R6 row | pending your approval |

Every row is a proposal. Nothing here changes your CV or goes out until you approve it.

## Evidence status

Verified: none yet. Everything above rests on your statements, the two web sources, and the public profile snippet.

Research tier: L1 — searches 4 of 5, fetches 1 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Queries: "Brindlemoor insurtech pet insurance" (no results), "Brindlemoor careers Senior Pricing Analyst". Fetched brindlemoor.co.uk/careers/senior-pricing-analyst. Moved: confirmed the posting is live; surfaced the Leeds contradiction (RR1); no salary; the standing employer-footprint entry (RR3). |
| 2. Role-family sweep | yes | Query: "Senior Pricing Analyst pet insurance UK salary GLM", returning the Pricewell 2026 survey (pricewell.example/2026-uk-pricing-analytics-pay-survey). Moved: the market calibration line in role reality. |
| 3. Hiring manager's public footprint | yes | Query: "Odile Varga Director of Pricing Brindlemoor", returning a public profile (linkedin.example/in/odile-varga), seen as a search snippet and not fetched. Moved: RR4 and the positioning in A3. |

## Upgrade menu

- Your location answer → R1 closes, and the decision likely moves to `go` or `no_go`.
- The employer's confirmed location and salary → RR1 and RR2 close.
- Any non-motor or pet-related pricing work, even a sanitized note → R6 moves up from `adjacent`.
- A sanitized GLM model document or validation pack → R4 moves to `high` confidence.
- A deeper research pass on Brindlemoor (funding, leadership changes, past hiring, staff reports; up to 5 more searches and 2 more fetches). Say the word and it runs.

If you want a `tuesday-dossier.md` saved for this role, say so and I'll produce it.

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**R1:** Where are you based, and would Leeds four days a week work for you? If remote-only is a hard limit, say so, because the posting contradicts itself on this.

**RR2:** What is your salary floor for this role?

**G1:** Have you priced, tested or monitored any product outside motor (home, travel, or anything with a different claims pattern), and what did you own?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.