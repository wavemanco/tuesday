**Decision: `no_go` on this posting as written.** Two hard gates fail, and neither can be fixed by wording or negotiation. Your instinct is picking up real things in the posting.

Research tier: L0, no searches. Everything below comes from the posting and your stated background. Labels: `[grounded]` = from the posting or your input, `[inferred]` = my reasoning from them, `[generic]` = a role-family pattern, not a claim about Novaline.

**Hard gates (both fail)**

| Gate | Posting | Your constraint | Result |
|---|---|---|---|
| Location | "On-site in our Austin office 5 days a week — no exceptions" `[grounded]` | Remote-only, Portland, won't relocate | Fail. The posting rules out the exception you'd need. |
| Base pay | $70–85k base `[grounded]` | Minimum $150k base | Fail. The posted ceiling is about $65k below your floor. Head-of-growth base pay is usually far higher than this `[generic]`. |

**Opportunity ledger (role on its own merits)**

- **Scope vs. pay:** "Own all revenue growth end to end" covers paid, SEO/content, lifecycle, brand, PR, partnerships and sales ops, as a team of one `[grounded]`. That is several senior roles' worth of work at a fraction of their pay `[inferred]`.
- **Overwork signals:** "evenings and weekends when it matters is just who we are" and "players who don't need a bench" `[grounded]`. These normalize unpaid overtime and resist hiring support.
- **Vague success:** "metrics will evolve as we learn" and "meaningful equity" with no terms `[grounded]`. Nothing here is measurable, and the equity is unquantified.
- **Equity offsets nothing here:** Equity can't close a gap this size on base salary, and it's unquantified `[inferred]`.
- **Unverified company facts:** "Series A, profitable since day one" is unchecked. I couldn't confirm the company exists as described, because I didn't search. Treat it as unverified `[grounded]`.
- **Minor:** "Team of one" conflicts with "Head of" a function, and you manage 3–7 people. Not a gate, but a sign the role's shape is still undefined `[inferred]`.

**Fit (candidate side)**

Strong on the requirements `[grounded]`: 9 years vs. "8+ years required"; $8M→$40M ARR with budget ownership; paid, lifecycle, experimentation; SQL, GA4, Braze. Fit is not the problem. The gates and the posting's terms are.

**What would change this:** Only both of these together: written confirmation of remote work, and a base of at least $150k. The posting's "no exceptions" makes that unlikely. If you want to test it, one short message to the recruiter asking both questions is cheap. If either answer is no, the posting is closed.

**Questions**
1. Did this reach you through a recruiter, or did you apply directly? Are you already in conversation with anyone at Novaline?
2. Is $150k base a firm floor, or would you consider lower base with a larger guaranteed bonus?

Response mode: answer in prose, or reply "skip" to either question.

**Upgrade menu:** A link to the live posting or the company's careers page would let me check that Novaline exists as described (L1 research: up to 5 searches and 2 page fetches). A pasted CV would let me build a full evidence inventory rather than work from your summary.

**Dossier offer:** If you want, I can save this assessment as `tuesday-dossier.md` for later use.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.