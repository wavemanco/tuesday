**Decision: conditional_go.** On the evidence you gave, you meet the core of this role. Three things are unresolved: location and right to work (the role is fully remote UK), pay (the posting doesn't state it), and whether the role carries people leadership. Nothing you've told me fails a hard gate outright, but two gates are unconfirmed.

**Decision snapshot**
- **Must-have:** Met on 5 of 5. Four years of pricing analytics, SQL, Python, GLM work and underwriting presentations are all in your background. Your evidence is stated, not yet shown with work samples. `[inferred]`
- **Core:** Met on rating models and price tests. Partial on recommendations to product, since you have only presented to underwriting.
- **Preferred:** Met on insurance experience, but it's motor, not pet.
- **Context:** Gap on pet-insurance domain knowledge. You have none, and the role is for a pet product.
- **Hard gates:** Unknown. Location and right to work for UK remote are unconfirmed. Pay is unstated.

**Role reality**
- Senior individual-contributor ownership of pricing analytics for a pet-insurance product, reporting into a Director of Pricing. Scope covers rating models, price tests, and recommendations to underwriting and product. `[grounded]` from the JD.
- The posting withholds pay and says nothing about direct reports. Both are worth asking about.
- I did not check the company, the posting, or the market. Everything about Brindlemoor is unverified. `[generic]` for any pattern I describe.

**Evidence map**

| # | Priority | Requirement | Fit | Confidence | Gap | Evidence |
|---|---|---|---|---|---|---|
| 1 | Must | 4+ yrs pricing or actuarial analytics | Met | medium | none | 5 yrs, last 2 as senior analyst |
| 2 | Must | Strong SQL | Met | medium | none | Daily use, stated |
| 3 | Must | Strong Python | Met | medium | none | Daily use, stated |
| 4 | Must | GLM experience | Met | medium | none | Built and maintained the young-driver GLM |
| 5 | Must | Presenting to underwriting or actuarial leads | Met | medium | none | Quarterly pricing review to head of underwriting |
| 6 | Core | Design and read price tests | Met | medium | none | 14 tests last year with underwriting |
| 7 | Core | Build and monitor rating models | Met | medium | none | Built and maintained one |
| 8 | Core | Recommendations for underwriting and product | Partial | medium | discovery | Underwriting is evidenced; product is not |
| 9 | Preferred | Insurance experience | Met | medium | transferability | Motor, not pet |
| 10 | Context | Pet-insurance product knowledge | Gap | none | transferability | No pet work |
| 11 | Implied | Leading people | Unknown | none | discovery | JD silent; you have never managed |
| 12 | Hard gate | Fully remote UK: location and right to work | Unknown | none | hard-gate | Not stated in your inputs |
| 13 | Hard gate | Pay against your floor | Unknown | none | hard-gate | Not in posting or inputs |

**Gap recovery queue**
- **Row 8, product recommendations:** Would close with one example of a recommendation that went to product, or a product-adjacent test. Motor pricing reviews usually involve product, so this may already exist.
- **Row 10, pet domain:** Closes partly through transfer. GLM and test methods carry over; pet-specific drivers such as breed, species, vet-cost inflation and lower claim volume are new to you. Frame it as a ramp, not as experience you have.
- **Row 11, people leadership:** Closes if the role has no direct reports, which the JD suggests. If it does, this becomes a real gap.
- **Rows 12 and 13:** Hard gates. Both close with answers, below.

**Risk register**
- **Unverified employer and posting, medium, standing:** I did not confirm the company exists as described, is live, or is hiring. This caps a `go` at `conditional_go` until verified. Verify it by finding the posting on Brindlemoor's own careers page.
- **Pay withheld, medium:** Unknown whether it meets your floor. Can't be calibrated without research.
- **Pet-domain ramp, low to medium:** Real but learnable.
- **Management expectation, medium if the role includes it:** You have never managed people.

**Application plan (proposed, pending your approval)**
- Lead with the GLM you built and maintained, then the 14 price tests and your underwriting presentations. These are your strongest and most directly matched evidence.
- Describe motor insurance pricing as transferable insurance pricing. Do not describe it as pet-adjacent.
- Do not describe yourself as having managed, led a team, or owned pet pricing.
- No CV language has been drafted. Any wording for your CV or outreach needs your approval before I write it.

**Evidence status**

Research tier: L0 — no searches

| # | Target | Status | Reason |
|---|---|---|---|
| 1 | Company site and careers page | skipped | Not run in this pass; employer and posting unverified |
| 2 | Role-family sweep (senior pricing analyst, UK) | skipped | Not run; pay and market unverified |
| 3 | Hiring manager's public footprint (Odile Varga, Director of Pricing) | skipped | Not run |

**Dossier:** If you'd like, I can save this assessment as a `tuesday-dossier.md` for later use.

**Upgrade menu**
- A light research pass (5 searches, 2 page fetches) to verify Brindlemoor and its posting, calibrate pay against the role family, and check Odile Varga's public professional background. It would close the company and market gaps above.
- A link to the live posting, if one exists.
- One anonymised example of a recommendation that went to product, which would close row 8.
- One anonymised work sample of a GLM or price test, which would raise the confidence of rows 4 to 7 from medium to high.

**Questions**
1. **Row 12:** Are you based in the UK, and do you have the right to work here?
2. **Row 13:** Do you know the pay band for this role, or what your floor is? The posting doesn't say.
3. **Row 11:** Did the recruiter or hiring manager say whether this role has direct reports?

Reply with answers, skip any, or say "research" to run the light pass.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.