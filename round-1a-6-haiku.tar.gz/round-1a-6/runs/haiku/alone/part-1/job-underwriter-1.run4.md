**Worth applying to, with conditions. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1
- `must_have`: direct: R2, R3, R4, R5, R7 · adjacent: R6
- `important`: adjacent: R8 · unclear: R9
- `preferred`: adjacent: R10

Your core analytics profile matches the role's center: SQL, experimentation, Looker, and executive communication. The gaps are healthcare, clinician partnership, mentoring, and the metrics-layer ownership question.

- **Hard gates:** none failed; unconfirmed: R1 (work authorization and location against the role's location). Your own constraints weren't given, so checks against them are unknown.
- **Severe red flags:** none found in the material provided.
- **Conditions for go:** (1) the posting and employer are confirmed live and real (RR1); (2) location and work authorization are confirmed (R1); (3) healthcare is framed as adjacent consent and PII governance, never as healthcare experience (R10).

**Research tier: L1, but no research ran.** The host denied web search permission, so no company or market check happened. Everything about Harborlight below is from your JD, labeled as such.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, digital-health scale-up, ~400 people, Series C | `[grounded]` your JD |
| Mandate | Own product analytics for the care-navigation app: metrics layer, A/B tests, self-serve Looker dashboards, PM and clinician partnership, mentoring two junior analysts | `[grounded]` your JD |
| Scope read | Senior IC with a two-person mentoring remit, which is a normal senior analytics scope | `[inferred]` from the responsibility list |
| Market calibration | Not run; research was unavailable | — |
| Unknowns | Location, work authorization, salary, contract basis, reporting line, whether the employer is as described | — |
| Contradictions | None within the material you provided; employer existence unverified | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Work authorization and location against the role's location | hard_gate | unclear | low | hard_gate | JD silent on location; your location and authorization weren't given | `[grounded]` absence in JD | Q1 |
| R2 | Expert SQL | must_have | direct | medium | none | Daily SQL on Snowflake; CV-stated only | `[grounded]` your statement | none |
| R3 | Experiment design at scale | must_have | direct | medium | none | 30+ A/B tests a year; pricing test behind an 11% retention lift. Be ready to explain measurement, significance, and guardrails | `[grounded]` your statement | none |
| R4 | 5+ years product analytics | must_have | direct | medium | none | Six years, consumer subscription | `[grounded]` your statement | none |
| R5 | Looker or similar BI; self-serve dashboards | must_have | direct | medium | none | Built the Looker instance from scratch; 40+ governed dashboards. Self-serve adoption not stated | `[grounded]` your statement | confirm adoption if asked |
| R6 | Define and maintain the metrics layer | must_have | adjacent | medium | transferability | Governed dashboards and a warehouse consent-state model imply metric definitions; whether you owned definitions is not stated | `[inferred]` from governed dashboards | G2 |
| R7 | Strong written communication to non-technical stakeholders | must_have | direct | medium | none | Writes the monthly exec metrics memo; presents monthly to VP Product | `[grounded]` your statement | none |
| R8 | Partner with PMs and clinicians to turn analysis into roadmap decisions | important | adjacent | medium | transferability | Exec and VP-level partnership is evidenced; PM partnership is implied; clinician partnership is not evidenced | `[inferred]` from the memo and presentation | G1, Q3 |
| R9 | Mentor two junior analysts | important | unclear | low | discovery | CV silent | `[grounded]` absence | Q2 |
| R10 | Healthcare data experience (HIPAA), a plus | preferred | adjacent | medium | capability | No healthcare work. Adjacent: GDPR and CCPA consumer PII handling and a consent-state model | `[grounded]` your statement | G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I see | What would close it | Provenance |
|---|---|---|---|---|---|
| G1 | Clinician partnership (R8) | transferability | No clinician-facing work listed | An example of analysis shaped by clinical or care-team input, even informal | `[grounded]` absence in CV |
| G2 | Metric-definition ownership (R6) | transferability | Governed dashboards and the consent model, but no statement that you owned definitions | Examples of metric definitions you wrote, changed, or governed | `[inferred]` |
| G3 | Healthcare and HIPAA (R10) | capability | Consent and PII work, no PHI or HIPAA exposure | A description of consent or access controls you built, mapped to HIPAA-style concerns. Do not present this as HIPAA compliance | `[generic]` role-family pattern |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer and live posting not verified | unknown | medium | — | Standing entry: research couldn't run, so this is unconfirmed, not a finding against the employer. It caps `go` at `conditional_go` until checked | `[grounded]` search denied | Can you send the live posting link, the careers page, and the recruiter's email domain? | unresolved |
| RR2 | Location and authorization not stated | unknown | — | — | Could block at the screen stage if the role is location-bound | `[inferred]` JD silence | Q1 | unresolved |
| RR3 | Salary not in the material provided | unknown | — | — | Compensation can't be calibrated without a band or your floor | `[inferred]` | What is your floor, and does the posting state a range? | unresolved |
| RR4 | Clinical-domain fluency | risk_signal | low | "partner with … clinicians" | Clinical stakeholders may judge metrics by outcomes, not revenue; expect a ramp | `[inferred]` from the JD and your consumer background | Q3 | unresolved |
| RR5 | PHI handling | risk_signal | low | "HIPAA a plus" | Early weeks may include access and PHI-handling rules you haven't worked under | `[generic]` role-family pattern | — | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Lead with the experiment program and Looker governance; put the monthly exec memo second | Those are the strongest matches to the JD's first and third requirements | `[inferred]` from R3, R5, R7 | pending your approval |
| P2 | Describe the pricing test as one you ran and measured. Do not write that you drove the 11% retention lift | Ownership and attribution must match what you did | `[grounded]` your statement and the reframing audit | pending your approval |
| P3 | Frame healthcare as adjacent: consent-state model and GDPR/CCPA PII handling, never as healthcare experience | R10 is adjacent, not direct | `[grounded]` your statement | pending your approval |
| P4 | Proposed phrasing: "Built the consent-state model for our warehouse and handled GDPR/CCPA consumer PII." Every clause traces to your sentences | Usable healthcare-adjacent line | `[grounded]` your sentences | pending your approval |

## Evidence status

Verified: none yet. Every claim rests on your statement here. No artifact or external source has been checked, so nothing is verified.

Research tier: L1 — searches 2 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Would check that the employer exists as described and that the posting is live. Search permission was denied; not retried |
| 2. Role-family sweep | unavailable | Would set the market calibration and compensation band. Not sent after the denial |
| 3. Hiring manager's public footprint | n/a | No name given |

## Upgrade menu

- Live posting link and careers page → RR1 closes; the `go` cap lifts if it checks out.
- Location and work authorization → R1 closes.
- Salary band or your floor → RR3 closes; the compensation calibration can run.
- A redacted metrics memo or experiment readout → R7 and R3 move toward `high`.
- Permission to retry web search → L1 runs: up to 5 searches and 2 fetches on Harborlight and the role-family pattern.
- Hiring manager's name → positioning for that reader.

If you want, I can save this as `tuesday-dossier.md` for later use.

**Questions (answer in text, or say skip):**

1. **(R1)** Where are you based, what is your work authorization, and where is the role located?
2. **(R9)** Have you mentored or managed junior analysts? If yes, give one example.
3. **(R8, RR4)** Have you worked with clinicians, care teams, or any non-consumer stakeholders? If yes, describe one case.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.