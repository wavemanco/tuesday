## Decision snapshot

**Decision: `conditional_go`.** Apply, but only after two conditions are settled.

- **Fit (candidate ledger):** Strong on the platform, years and SQL requirements. Two must-haves are gaps, and both sit at the centre of the role: owning the forecast, and working with finance on billing data.
- **Opportunity ledger:** No red flags in the posting. The company checks out as a real Bristol invoicing and payments business. The posted pay sits inside the market band.
- **Hard gates:** Bristol hybrid (two days a week in office) and the £61,500–£67,000 range are both unknown against your constraints. I have no record of where you're based or your pay floor.
- **Conditions to clear:** (1) Bristol hybrid and the pay range work for you. (2) You have some forecast-adjacent or finance-facing revenue work to point to. If you don't, this is a stretch application, and you should go in knowing that.

## Role reality

- **Title and organisation:** Revenue Operations Lead, Quillfield, Bristol. Invoicing and payments software for UK builders' merchants; founded 2018; 96 employees; £11M Series A in April 2025 [grounded, quillfield.co.uk/about].
- **Scope:** Owns CRM and billing data; builds pipeline and renewal reporting for sales and finance; runs the quarterly revenue forecast with the CFO [grounded, posting].
- **Hiring manager:** Tamsin Achebe is listed as Head of Revenue Operations. Her public profile says she previously ran sales operations at Corvane Payments for four years [grounded, linkedin.example profile]. The role likely sits in her team, and her background suggests she knows the payments-to-software move well. I can't tell from public sources whether you overlapped at Corvane.
- **Stated pay:** £61,500–£67,000 plus share options [grounded, posting].
- **Market calibration:** For UK B2B software revenue operations leads, the 2026 median base is £64,200, with an interquartile range of £57,800–£70,400 (n=438) [generic, Ledgerline 2026 pay guide]. The posted range sits inside that band, straddling the median. Share options are unquantified.
- **Contradictions:** None found between the posting and the company's own description.

## Evidence map

| # | Priority | Requirement | Fit | Confidence | Gap | Evidence |
|---|---|---|---|---|---|---|
| R1 | must | 4+ years in RevOps, sales ops or analytics at a B2B software company | partial | high on years, medium on fit | transferability | 5 years in sales ops at a B2B payments company; last 2 running UK RevOps |
| R2 | must | HubSpot or Salesforce administration | met | high | none | Salesforce admin certified |
| R3 | must | Strong SQL and spreadsheet modelling | likely met | medium | capability to verify | SQL weekly, Excel daily; "modelling" depth not stated |
| R4 | must | Experience owning a forecast | gap | high that it's absent | capability | Never owned the company forecast; finance did it. The monthly pipeline review is forecast input, not ownership |
| R5 | must | Experience working with finance on billing or revenue data | gap (billing); unknown (revenue) | high on billing, unknown on revenue | discovery | Never worked on billing data. Whether any renewal or pipeline work touched finance revenue figures is not stated |
| R6 | implied | Owns CRM and billing data | gap | high | follows R5 | As R5 |
| R7 | implied | Runs the quarterly forecast with the CFO | gap | high | follows R4 | As R4 |
| H1 | hard gate | Bristol hybrid, two days a week in office | unknown | — | not stated | No location in the background you gave |
| H2 | hard gate | £61,500–£67,000 salary | unknown | — | your floor not stated | Posted range inside market band |

## Opportunity risk register

- **Low, unknown:** Scope of the forecast role. The posting says "run the quarterly revenue forecast with the CFO", which is a senior, finance-facing responsibility, not a light reporting job. Test: ask Tamsin whether the forecast is owned end to end or shared with finance.
- **Low, positive:** The company is verified (Bristol, 96 staff, Series A). No failed-attribution entry is needed.
- **None:** No red flags, no requests for payment or bank details, no pay mismatch against the market band.

## Application plan (as far as the evidence allows)

- **Lead with:** five years in sales operations, Salesforce admin certification, the pipeline and renewal dashboards you rebuilt, SQL weekly, and the payments background, which is close to Quillfield's payments-and-invoicing product.
- **Don't claim:** forecast ownership, billing-data work, or modelling depth beyond what you've described. The pipeline review is forecast input, and it should be presented as that.
- **Not yet drafted:** No CV or positioning language is written. Any proposed wording will come to you as pending approval before it's used.

## Gap recovery queue

- **R4 (forecast ownership):** Closed only by evidence of a forecast or projection you built or maintained, even at team level, that someone relied on.
- **R5 / R6 (billing and revenue data):** Closed by any renewal, pipeline or revenue reporting that reconciled to invoices, billing or finance figures.
- **R3 (modelling):** Closed by one SQL query or spreadsheet model you've written, which would raise confidence to high.
- **H1 / H2:** Closed by your answers on location and pay floor.

## Evidence status

Research tier: L1 — searches 3 of 5, fetches 0 of 2; user links read 1

| # | Target | Status | Reason |
|---|---|---|---|
| 1 | Company site and careers page | yes | Queries: "Quillfield invoicing software company Bristol". Rests on quillfield.co.uk/about (search snippet; page not fetched). Careers page not fetched. |
| 2 | Role-family sweep (pay and scope) | yes | Query: "Revenue Operations Lead salary UK £60,000 B2B software". Rests on the Ledgerline 2026 UK Revenue Operations Pay Guide (search snippet). |
| 3 | Hiring manager's public footprint | yes | Query: "Tamsin Achebe Quillfield CFO OR finance OR revenue". Rests on her public professional profile (search snippet). |

Note: the posting itself was read from the link you gave, not through research.

Dossier offer: If you want, I can save this underwriting as `tuesday-dossier.md` so a later interview-prep session can pick it up.

Upgrade menu:
- **Forecast or finance-facing revenue work (R4, R5):** any spreadsheet, dashboard or write-up showing a revenue projection or billing reconciliation. This is the single biggest lever on the decision.
- **One SQL or modelling sample (R3):** a query or model you've written. Raises R3 to high confidence.
- **Location and pay floor (H1, H2):** closes both hard-gate unknowns.
- **Careers page fetch:** one more page fetch would confirm the posting matches the company's own site. It uses one of the two L1 fetches.
- **L2 research (offered once):** deeper company diligence (funding, leadership churn, hiring patterns) and a recent-news sweep. Capped at up to 5 more searches and 2 more fetches. Say if you want it.

Questions (answer in prose, skip any, or say "skip" — silence is an answer):
1. **(R4)** Have you ever built or maintained any forward-looking revenue number, even a team-level or pipeline-to-bookings projection that someone relied on, even if finance signed off the final figure?
2. **(R5, R6)** Did any of your renewal or pipeline work reconcile to invoices, billing or finance revenue figures? If so, who checked it?
3. **(H1, H2)** Can you work from Bristol two days a week, and is £61,500–£67,000 at, above or below your floor?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.