**Decision: conditional_go.** Apply, but state the two gaps plainly. Settle the location and pay questions and check the employer before you invest in interviews.

**Research tier: L0, no searches; user links read 1.** I read the posting you linked and nothing else. Employer, pay band and hiring-manager claims below are not checked against outside sources.

## Decision snapshot

- **Fit, by requirement**
  - *Strong:* Salesforce admin (certified), 4+ years in sales/revenue ops (5 years), pipeline and renewal reporting, SQL weekly. All `[grounded]` in your background.
  - *Partial:* "Strong spreadsheet modelling" (you use Excel daily, but modelling depth is not shown). "B2B software" (your employer was B2B payments, which is adjacent).
  - *Gap:* **Owning a forecast.** The posting says you will run the quarterly forecast with the CFO. You say finance owned it.
  - *Gap:* **Billing or revenue data with finance.** You have never worked on billing data.
- **Hard gates:** Bristol, hybrid two days a week. Your location and commute are unknown to me. Your pay floor is unknown, and the posted band is £61,500–£67,000 plus share options `[grounded]`.
- **Opportunity ledger:** Scope is wide. The posting combines CRM ownership, billing data, pipeline and renewal reporting, and the forecast. That is heavier than the title suggests `[inferred]`. Salary is stated, which is a positive signal. The employer is unverified (see below).
- **Failed attribution:** Not tested, since no searches ran. Tallyboard is a job board, so I cannot confirm Quillfield directly from this page. This is a `medium` standing item, not a finding against them. Your recruiter's email domain or Quillfield's own careers page would settle it.

## Evidence map

| # | Priority | Fit | Requirement | Your evidence | Confidence | Gap |
|---|---|---|---|---|---|---|
| 1 | Must | Strong | 4+ yrs RevOps/sales ops at B2B software | 5 yrs sales ops, B2B payments, last 2 running UK RevOps | High (your statement) | Sector is adjacent, not software |
| 2 | Must | Strong | HubSpot or Salesforce admin | Salesforce admin certified; rebuilt dashboards | High | None |
| 3 | Must | Strong | Strong SQL and spreadsheet modelling | SQL weekly, Excel daily | Medium | Modelling depth not evidenced |
| 4 | Must | Gap | Experience owning a forecast | Ran monthly pipeline review; finance owned forecast | — | Possible discovery gap (see Q1) |
| 5 | Must | Gap | Working with finance on billing/revenue data | None stated | — | Capability gap, possibly transferable (see Q2) |
| 6 | Core | Strong | Pipeline and renewal reporting | Rebuilt both | High | None |

## Role reality

- **Scope:** Owning CRM and billing data, building reporting that sales and finance both depend on, and running the quarterly forecast with the CFO `[grounded]`. The forecast and billing items are the two that sit outside your current remit.
- **Compensation:** £61,500–£67,000 plus shares `[grounded]`. I have no market band, so I cannot say whether that is high or low for Bristol RevOps leads `[generic — not researched]`.

## Gap recovery queue

- **Row 4 (forecast):** Closing this needs evidence that your pipeline and stage work fed the forecast, even if finance held the final number.
- **Row 5 (billing):** Closing this needs any reconciliation or revenue-recognition exposure, even at the edge of finance's data.
- **Row 3 (modelling):** Closing this needs an example of a model you built.

## Application plan

- **Lead with:** Salesforce certification, pipeline and renewal rebuilds, and the monthly pipeline review with the sales director. These are verified and map directly to rows 2 and 6.
- **Do not claim:** forecast ownership or billing-data experience. Any resume line for those must wait for your answers below.
- **Approval:** No CV or outreach text is drafted yet. Anything externally visible needs your approval first.

## Evidence status

Research tier: L0 — no searches; user links read 1

| Target | Status | Reason |
|---|---|---|
| L1-1: Quillfield official site and careers page | skipped | Not run; L0 tier chosen |
| L1-2: Role-family sweep (pay and scope norms) | skipped | Not run; L0 tier chosen |
| L1-3: Hiring manager public footprint | skipped | Not run; no research consent given |

## Upgrade menu

- **Quillfield's own site and careers page (L1):** Confirms the employer and whether this posting is live. Unlocks the employer check.
- **Role-family pay sweep (L1):** Shows whether £61.5k–£67k is normal for this seniority. Unlocks the market calibration line.
- **Your CV or a sample of a pipeline or forecast model:** Verifies the row 3 and row 4 claims.
- **Hiring-manager footprint for Tamsin Achebe (L1):** Shows what to lead with for her. Only public professional background is checked.

If you want the dossier saved, I can produce `tuesday-dossier.md` with this assessment at the end of the engagement, or whenever you ask.

## Questions

1. **Row 4:** Did your pipeline review or stage-weighting feed into the sales forecast, for example commit or best-case calls, even though finance owned the final number?
2. **Row 5:** Did you ever reconcile pipeline, renewals or bookings against invoices or recognised revenue, even informally?
3. **Hard gates:** Can you work in Bristol two days a week, and what is your pay floor?

Reply with an answer, "skip", or "not sure" for each.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.