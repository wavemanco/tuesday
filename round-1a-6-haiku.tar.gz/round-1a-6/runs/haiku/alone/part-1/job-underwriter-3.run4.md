**Decision: `no_go`. Not worth pursuing as posted.** Your two hard constraints both fail on the posting's own terms, and the fit on paper doesn't offset either one.

- **Hard gates:** failed: R1 (on-site in Austin 5 days a week), R2 (base $70–85k against your $150k floor). Candidate constraints given, and both checks ran against them.
- **Fit ledger:** Strong on paper. Your paid, lifecycle, experimentation, team-building, scale, and tooling evidence all map directly. Gaps sit in the mandate's breadth (brand, PR, SEO, partnerships, sales ops) and in building alone from zero.
- **Opportunity ledger:** Two severe red flags (both are your hard constraints restated as terms), plus two medium risk signals: an always-on expectation and accountability without the resources to deliver it. The profitability claim is a positive signal, but unverified.
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`).
- **What would change this:** both gates would have to move: base at or above $150k and remote eligibility. The posting says "no exceptions" on location, so the realistic answer is no.

You said something feels off. The posting has concrete reasons behind that: the pay is roughly half your floor, the location is non-negotiable, and the role asks for a senior mandate with a team of one, evenings and weekends, and metrics that will change. That combination reads as a senior title with a junior budget and no team.

**Role reality**

- Head of Growth, reporting to the CEO with a dotted line to the board. Series A, described as profitable since day one (unverified).
- Scope: paid acquisition, SEO/content, lifecycle/CRM, brand, PR, partnerships, sales ops, all end to end. Team of one to start.
- Compensation: $70–85k base plus equity. Stated, so it is `[grounded]` from the JD.
- Market calibration: not established. The role-family search was refused, so I have no market band for this title. The comparison rests on the posting's own figure against your floor, not on a market norm.

**Evidence map**

| # | Priority | Fit | Confidence | Requirement | Evidence |
|---|---|---|---|---|---|
| R1 | hard_gate | hard_gate_fail | high | On-site Austin, 5 days/week | Posting: "no exceptions"; you are remote-only, Portland |
| R2 | hard_gate | hard_gate_fail | high | Base at or above $150k | Posting $70–85k; your floor $150k |
| R3 | must_have | direct | medium | 8+ years growth leadership | 9 years, Growth lead then Head of Growth (CV-stated) |
| R4 | must_have | direct | medium | Own paid acquisition | Owned paid at two B2C subscription companies |
| R5 | must_have | direct | medium | Own lifecycle/CRM | Owned lifecycle; deep in Braze |
| R6 | must_have | direct | medium | Experimentation and measurement | Owned experimentation; SQL and GA4 |
| R7 | important | unclear | low | Build the function as a team of one | Managed teams of 3–7; no evidence of building solo |
| R8 | important | absent | — | SEO/content | Not in your profile |
| R9 | important | absent | — | Brand and PR | Not in your profile |
| R10 | important | absent | — | Partnerships | Not in your profile |
| R11 | important | absent | — | Sales ops | Not in your profile |
| R12 | preferred | adjacent | medium | E-commerce enablement | B2C subscription, not e-commerce enablement |
| R13 | must_have | adjacent | medium | Thrive on ambiguity; metrics evolve | Scaled $8M→$40M ARR with a budget you controlled; no 0-to-1 evidence cited |

**Opportunity risk register**

- **RR1** `red_flag`, `severity: high`, `confirmed`. Source: "Compensation: $70–85k base plus meaningful equity upside." Hypothesis: the stated base is about half your floor and is `[grounded]` against your constraint, not a market claim. Verification question: "What is the base range for this role, and is there any flexibility toward $150k?" Decision rule: no pursuit unless the base moves.
- **RR2** `red_flag`, `severity: high`, `confirmed`. Source: "On-site in our Austin office 5 days a week — no exceptions." Hypothesis: a remote-only candidate cannot meet this term. Verification question: "Is there any remote or hybrid arrangement for this role?" Decision rule: no pursuit unless the posting changes.
- **RR3** `risk_signal`, `severity: medium`, `unresolved`. Source: "evenings and weekends when it matters is just who we are." Hypothesis `[inferred]` from the wording: an always-on expectation. Verification question: "What does a typical week look like for this role, including evenings and weekends?"
- **RR4** `risk_signal`, `severity: medium`, `unresolved`. Source: "a team of one to start … success metrics will evolve." Hypothesis `[inferred]`: accountability for all revenue lines with no team or budget stated. Verification question: "Which budget and decision rights does this role control on day one?"
- **RR5** standing, `risk_signal`, `severity: medium`, `unresolved`. Employer not established: the company search was refused, so I could not confirm Novaline exists as described. Possible reasons, none ranked as likely: too new or small, a stale or aggregated posting, or not a real hiring employer. Verification question: "Can you point me at the role on your own careers site, and who would I be interviewing with?"

**Gap recovery queue**

- R7 (team-of-one) and R13 (ambiguity) are the only fit questions that could move, and neither changes the gate result.
- R8–R11 are absent from your profile. If you have any of them in real work, they would move a row; they would not change `no_go`.

**Application plan**

Do not apply as posted. If you want to keep the thread open, one verification message to the recruiter covering RR1 and RR2 is worth sending. Put your effort into openings that meet both constraints.

**Evidence status**

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| # | Target | Status | Reason |
|---|---|---|---|
| 1 | Company site and careers page (Novaline) | unavailable | Search refused; employer existence not established (RR5) |
| 2 | Role-family sweep (title, scope, pay for this seniority) | unavailable | Search refused; no market band |
| 3 | Hiring manager's public footprint | n/a | No name given |

**Upgrade menu**

- A link to the live posting or the company's careers page would resolve RR5, and would show whether the posting is current.
- Your own offer history or recruiter-stated bands would give a grounded comparison for the $150k floor if market search stays unavailable.
- Search access would unlock targets 1 and 2 above.

The dossier can be saved as a file for later. Say the word and I'll produce `tuesday-dossier.md`.

1. Is anything in the process already in motion, such as a recruiter call or a stage you've reached? That would change how to word the verification message.
2. What specifically feels off to you? If it's something the posting doesn't show, it belongs in the register.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.