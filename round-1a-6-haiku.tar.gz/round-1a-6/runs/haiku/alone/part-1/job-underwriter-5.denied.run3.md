## Decision snapshot

**Yes on skills, but not decidable yet. Status: `hold_pending_answers`.** Your must-haves match your background. Two hard gates (location and pay floor) are unchecked because you haven't given me your constraints, and the BigQuery gap is the one interviewers will probe.

**Fit ledger.**

- `hard_gate`: unclear: R1 (Remote US or Denver office), R2 (base pay $148,000–$166,000)
- `must_have`: direct: R3 (5+ years data engineering), R4 (strong SQL and Python), R5 (dbt and a cloud warehouse), R6 (orchestration with Airflow or similar), R7 (data quality testing)
- `important`: adjacent: R8 (dbt-modelled warehouse in BigQuery); unclear: R9 (ingestion from our app and CRM), R10 (data contracts our analysts depend on)

R8 is a credible bridge with its limit named. R9 and R10 are silent on your CV, so they are open questions, not gaps.

**Opportunity ledger.** The stated pay sits inside the market band (RR4, positive). Open items are decision rights and scope (RR2), unquantified equity (RR3), and an employer I could not verify in this run (RR1, medium).

- **Hard gates:** none failed; unconfirmed: R1 (Remote US or Denver office), R2 (base pay $148,000–$166,000); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found. The material asks for no payment, deposit, or pre-offer bank or ID details.
- **What would change this:** answers to R1 and R2 (both gates) and to the R9/R10 question. If both gates are met, the status moves to `conditional_go`, not `go`, until RR1 is verified.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states; founded 2016, Denver; 264 employees; Series C ($52M, February 2026) | `[grounded]` About text you pasted; not checked, since web search was denied |
| Mandate | Build and run pipelines behind tutoring-platform reporting: ingestion from app and CRM, a dbt-modelled warehouse in BigQuery, data contracts for analysts | `[grounded]` JD |
| Pay and location | $148,000–$166,000 plus equity; remote (US) or Denver office | `[grounded]` JD |
| Hiring manager | Not named | `[grounded]` JD |
| Market calibration | Senior Data Engineer, Series B–D: base median $151,000, IQR $139,000–$163,500; senior typically 5–8 years; scope usually one domain's pipelines, no direct reports. The posting's range sits inside that IQR, and its midpoint ($157,000) is close to the median | `[generic]` band from the Datawright 2026 report you sent, which I have not verified; `[inferred]` the comparison |
| Scope read | The JD says "the pipelines" and "our reporting", which may mean the whole reporting stack rather than one domain. Unconfirmed | `[inferred]` from breadth of the JD against its silence on ownership |
| Unknowns | Decision rights, equity terms, location policy, the salary you would accept | — |
| Contradictions | None checkable; the careers page was not read | — |

## Evidence map

Your background is CV-equivalent prose, so every claim stays at `medium` until you give an inspectable artifact.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | Your location is not given, so the gate is not established. No candidate statement exists to grade | `[grounded]` JD; candidate silent | Q1 |
| R2 | Base pay $148,000–$166,000 | hard_gate | unclear | none | hard_gate | The posted range is known; your floor is not. No candidate statement exists to grade | `[grounded]` JD; candidate silent | Q2 |
| R3 | 5+ years data engineering | must_have | direct | medium | none | Six years at a B2B payroll company, stated. Self-report, no artifact | `[grounded]` your background | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | Used daily, stated. Self-report, no artifact | `[grounded]` your background | none |
| R5 | dbt and a cloud warehouse | must_have | direct | medium | none | Built a dbt project of about 180 models on Snowflake, which is a cloud warehouse | `[grounded]` your background | none |
| R6 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow, stated | `[grounded]` your background | none |
| R7 | Data quality testing | must_have | direct | medium | none | You set up the Great Expectations suite, stated | `[grounded]` your background | none |
| R8 | dbt-modelled warehouse in BigQuery | important | adjacent | medium | transferability | Same category of work (dbt on a cloud warehouse). BigQuery itself was never used, and BigQuery-specific cost and table design are not exercised | `[grounded]` the Snowflake work and "never used BigQuery"; `[inferred]` that the adjacency carries over | G1 |
| R9 | Ingestion from our app and CRM | important | unclear | low | discovery | CV does not say what sources you ingested | `[inferred]` responsibility from the JD; `[grounded]` CV silence | Q3 |
| R10 | Data contracts our analysts depend on | important | unclear | low | discovery | CV does not say whether you defined contracts with consumers | `[inferred]` responsibility from the JD; `[grounded]` CV silence | Q3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R8, important) | transferability | Dbt on Snowflake at about 180 models; no BigQuery work | The posting names BigQuery; interviewers will ask what changes between the two | Any dbt project you ran on Snowflake whose modelling choices would transfer; any BigQuery exposure outside work | A small dbt-bigquery project, a repo, or a README showing a model build | `[inferred]` bridge from the Snowflake work; `[generic]` that BigQuery-specific cost and partitioning are the likeliest objection |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not verified in this run | risk_signal | medium | "Pellucid Learning runs live online tutoring for K-12 schools in 31 US states." | The employer may be too new or small for a footprint, the posting may be stale or aggregated, or it may not be a live hiring employer | `[generic]` pattern for companies of this size, not a claim about this one; the check itself was refused, so this is not a finding | Can you point me at this role on your own careers site, and who would I interview with? | unresolved |
| RR2 | Scope and decision rights unstated | unknown | — | "Build and run the pipelines behind our tutoring platform's reporting" | The role may own the whole reporting stack or one domain; scope drives whether the role is typical | `[inferred]` from the JD's breadth against its silence on ownership | Which pipelines does this role own end to end, and which are shared with other teams? | unresolved |
| RR3 | Equity unquantified | unknown | — | "$148,000–$166,000 plus equity" | Total pay may be well below the headline if the equity is thin | `[generic]` that equity value varies widely at Series C | What is the equity grant, its vesting schedule, and the latest valuation? | unresolved |
| RR4 | Stated pay inside the market band | positive_signal | — | "$148,000–$166,000" | The range sits within the role-family IQR, so pay is not a warning sign | `[grounded]` posting figure against `[generic]` band | Is this base range set for this level, and where in it do hires typically land? | noted |

Severe red flags: none found.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Find the live posting on the company's own careers page before investing effort | RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Proposed resume line for the Snowflake and BigQuery gap: "Built a dbt project of about 180 models on Snowflake. Have not used BigQuery." | R8 | `[grounded]` your background. Audit: "built" ← "Built our dbt project"; "about 180 models" ← your figure; "on Snowflake" ← your statement; "have not used BigQuery" ← "Never used BigQuery" | resume_edits_pending_approval |
| A3 | Ask RR2 and RR3 verbatim in the first interview | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Everything above is your own prose, which is `medium` at most until you give an artifact or answer a probe.

Research tier: L1 — searches 2 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Both searches were refused because web search permission was not granted. Would have checked that the employer exists as described, that the posting is live, and that it matches the About text. RR1 stands unresolved |
| 2. Role-family sweep | skipped | The Datawright report you pasted fixes the band and scope norm; no search was sent. Its genuineness is unchecked |
| 3. Hiring manager's public footprint | n/a | No name was given, so there is no query to form |

## Upgrade menu

- A BigQuery sample project or dbt-bigquery repo → R8 moves from `medium` toward `high`, and G1 closes.
- An artifact for ingestion or a data contract you wrote (a schema YAML, a contract doc, a DAG) → R9 and R10 move from `low`.
- Web search permission → target 1 runs and checks RR1 directly.
- The live posting link, or the recruiter's email domain → RR1 clears or stays open.
- The equity terms → RR3 closes.

Once the L1 checks have run, a deeper diligence pass on the company is available on request.

Want a `tuesday-dossier.md` file with this assessment, so the next session can pick it up without rerunning the analysis? Say the word.

Questions, each tagged to its row:

- **R1:** Are you based in the US, and can you work remote from there, or from Denver? Is that a hard requirement for you?
- **R2:** Do you have a base-salary floor you won't go below? If so, what is it?
- **R9 / R10:** Have you owned ingestion from an application database or a CRM, and defined data contracts that downstream analysts relied on? Name one and what you owned.

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.