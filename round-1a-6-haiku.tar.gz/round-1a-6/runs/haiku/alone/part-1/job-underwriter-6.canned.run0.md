**Yes, go for it, with conditions. Status: `conditional_go`.**

**Fit ledger.**
- `must_have`: direct: R1, R2, R3, R7 · adjacent: R4, R5
- `important`: unclear: R6 (owning billing data)
- `hard_gate`: unclear: R8 (Bristol, two office days a week), R9 (the £61,500–£67,000 range)

R4 and R5 are the forecast and finance-data gaps, with their limits named. R6 is the billing-data gap, and nothing you've told me yet settles it.

**Opportunity ledger.** The scope is clear and the salary sits inside the market band, but the posting did not appear on Quillfield's own careers site in my search (RR1), and the forecast is shared with the CFO (RR2).

- **Hard gates:** none failed; unconfirmed: R8 (Bristol, two office days a week), R9 (£61,500–£67,000 plus share options); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **Conditions for go:** (1) the role is confirmed on Quillfield's own careers page or by the recruiter (RR1); (2) you learn what the forecast role owns versus the CFO (RR2); (3) you check R8 and R9 against your own constraints, which I don't have yet; (4) you don't claim forecast ownership — R4 stays `adjacent`.

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quillfield: invoicing and payments software for UK builders' merchants; founded 2018 in Bristol; 96 employees; £11M Series A closed April 2025 | `[grounded]` quillfield.co.uk/about (search snippet, not fetched) |
| Mandate | Own CRM and billing data; build pipeline and renewal reporting for sales and finance; run the quarterly revenue forecast with the CFO | `[grounded]` JD |
| Working pattern | Bristol hybrid, two days a week in the office | `[grounded]` JD |
| Pay | £61,500–£67,000 plus share options | `[grounded]` JD |
| Market calibration | UK revenue operations lead, B2B software, 2026: median £64,200, interquartile range £57,800–£70,400 (n=438). The posted band sits inside that range, near the median | `[generic]` Ledgerline 2026 UK Revenue Operations Pay Guide |
| Hiring manager | Tamsin Achebe, Head of Revenue Operations at Quillfield; previously sales operations manager at Corvane Payments for four years | `[grounded]` LinkedIn profile (search snippet, not fetched) |
| Unknowns | Whether this role reports to Tamsin; forecast decision rights; contract basis; billing-data access | — |
| Contradictions | The posting is hosted on tallyboard.example, and I found no matching role on Quillfield's own careers site | `[grounded]` search results |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 4+ years in RevOps, sales ops or analytics at a B2B software company | must_have | direct | medium | none | Five years in sales ops, the last two running UK revenue operations. The employer is B2B payments, a near match to software | `[grounded]` your statement; JD | none |
| R2 | HubSpot or Salesforce administration | must_have | direct | high | none | Salesforce admin certified: a credential you can show | `[grounded]` your statement | none |
| R3 | Strong SQL and spreadsheet modelling | must_have | direct | medium | none | SQL weekly, Excel daily; no artifact yet | `[grounded]` your statement | none |
| R4 | Experience owning a company forecast | must_have | adjacent | medium | transferability | You run the monthly pipeline review and built pipeline and renewal dashboards, which feed forecasts. You never owned the forecast; finance did | `[inferred]` adjacency from pipeline review to forecasting | see RR2 and Q2 |
| R5 | Experience working with finance on billing or revenue data | must_have | adjacent | medium | transferability | Revenue data via pipeline and renewals; no billing data; finance partnership not described | `[grounded]` your statement; `[inferred]` adjacency | Q2 |
| R6 | Owning CRM and billing data (implied by the role's mandate) | important | unclear | low | discovery | CRM is strong; billing data is not evidenced. Your payments company may have touched billing-adjacent data | `[grounded]` JD; your statement | Q3 |
| R7 | Pipeline and renewal reporting for sales and finance (implied by the mandate) | must_have | direct | medium | none | Rebuilt pipeline and renewal dashboards; the finance audience is not confirmed | `[grounded]` your statement | none |
| R8 | Bristol hybrid, two office days a week | hard_gate | unclear | none | hard_gate | Your constraint is not in this conversation | `[grounded]` JD; constraint not given | Q1 |
| R9 | Salary £61,500–£67,000 plus shares | hard_gate | unclear | none | hard_gate | Your pay floor is not in this conversation | `[grounded]` JD; constraint not given | Q1 |

**Gap recovery queue**

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Forecast ownership (R4, must_have) | transferability | Pipeline reviews and renewal dashboards, with no forecast ownership | The most visible requirement; a clear limit makes the bridge credible | Pipeline-stage weighting, renewal-rate assumptions, forecast-call input to the CFO | A sanitized pipeline review deck or forecast input sheet | `[inferred]` bridge; `[generic]` that a forecast requirement gets probed in interview |
| G2 | Billing data (R6, important) | discovery | No billing data in your CV | Owning billing data is in the mandate | Reconciliation, failed-payment or subscription reports at the payments company | A sanitized report or data dictionary | `[grounded]` JD; your statement |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posting not found on the employer's own careers site | risk_signal | medium | "Revenue Operations Lead, Quillfield" (hosted on tallyboard.example) | The role may be stale, aggregated or not yet live | `[generic]` pattern for job-board postings; the employer itself is established | Is this role open on Quillfield's careers page, and who would I report to? | unresolved |
| RR2 | Forecast decision rights split with the CFO | unknown | — | "run the quarterly revenue forecast with the CFO" | You may produce inputs while the CFO owns the call | `[inferred]` from the JD's wording | Who makes the final forecast call, and what does this role own versus the CFO? | unresolved |
| RR3 | Scope and pay stated | positive_signal | — | "Salary £61,500–£67,000 plus share options" | The posting is transparent on pay and mandate | `[grounded]` JD | How is success measured in year one? | noted |

**Severe red flags:** none found. The posting asks you for nothing unusual.

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Check the role on Quillfield's careers page before investing in an application | RR1 | `[generic]` job-board pattern | pending your approval |
| A2 | Lead with the pipeline and renewal dashboards and the Salesforce certification, and describe the forecast as input, not ownership | R2, R4, R7 | `[inferred]` from Tamsin's public title | pending your approval |
| A3 | Ask the forecast question (RR2) early, in the first conversation | RR2 | `[grounded]` RR2 | pending your approval |

**Evidence status**

Verified: none yet. Everything above rests on what you have told me in this conversation, not on artifacts I have inspected.

Research tier: L1 — searches 4 of 5, fetches 0 of 2; user links read 1

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Quillfield invoicing software company Bristol", which returned quillfield.co.uk/about (snippet only, not fetched): founded 2018, Bristol, 96 employees, Series A. Searched "Quillfield careers Revenue Operations Lead": no results, so the role is not confirmed on the employer's site. Moved the Organization row and RR1 |
| 2. Role-family sweep | yes | Searched "revenue operations lead UK salary B2B software 2026", which returned Ledgerline 2026 UK Revenue Operations Pay Guide (ledgerline.example/2026-uk-revenue-operations-pay-guide, snippet only): median £64,200, interquartile range £57,800–£70,400. Moved the Market calibration row |
| 3. Hiring manager's public footprint | yes | Searched "Tamsin Achebe Quillfield", which returned her LinkedIn profile (linkedin.example/in/tamsin-achebe, snippet only): Head of Revenue Operations at Quillfield; previously sales operations manager at Corvane Payments. Moved the Hiring manager row and A2 |

**Upgrade menu**

- Quillfield's careers page or a recruiter confirmation of the role → RR1 closes.
- A written note on forecast ownership from the recruiter or Tamsin → RR2 closes and R4 is re-read.
- Your constraints on Bristol office days and your pay floor → R8 and R9 are checked.
- Any billing or invoice-data work from the payments company → R6 moves from unclear.
- A sanitized pipeline or renewal dashboard → R7 rises to high confidence.
- A deeper research pass on Quillfield (funding, leadership changes, recent news; up to 5 more searches and 2 more fetches) — say the word and it runs.

If you want, I can write this up as a `tuesday-dossier.md` so the next step can pick it up.

Three questions, tagged to their rows:

- R8/R9 — Do Bristol with two office days a week, and £61,500–£67,000 plus shares, both fit your constraints?
- R4 — Which forecast inputs did you produce in your current role, and did you present any of them to the CFO or finance?
- R6 — Did any of your payments-company work touch billing or invoice data, even reconciliation or failed-payment reports?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.