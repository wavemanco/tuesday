**Short answer: yes, apply, once the posting checks out.** Status: `conditional_go`.

Your fit on the core of this role is strong. Web research didn't run, so the employer and posting are unverified and the market pay band is missing.

## Decision snapshot

**Fit ledger.**

- `must_have`: direct: R1, R2, R3, R4, R8 · adjacent: R5 (metrics layer and its maintenance), R7 (partnering with clinicians)
- `important`: direct: R6 · unclear: R9 (mentoring two junior analysts)
- `preferred`: absent: R10 (healthcare data, HIPAA)

R1, R2, R3, R4 and R8 are your strongest case. R5 and R7 are the interview questions. R9 needs one answer from you. R10 is a stated plus, not a gate.

**Opportunity ledger.** Sound on its scope, thin on specifics: pay, contract type, decision rights over metric definitions and the clinical data scope are missing (RR2, RR3, RR4). The posting's concrete responsibilities and mentoring remit are a positive (RR5). The employer itself is unverified (RR1).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the posting is live on Harborlight's own careers page (RR1); (2) the pay and contract type are acceptable (RR2); (3) metric-definition ownership and the clinician interface hold up in conversation (RR3, RR4).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, digital-health scale-up, ~400 people, Series C | `[grounded]` JD header |
| Mandate | Own product analytics for the care-navigation app: metrics layer, A/B design and analysis, self-serve Looker dashboards, partnering with PMs and clinicians, mentoring two junior analysts | `[grounded]` JD |
| Scope read | Senior individual-contributor role with a mentoring remit, covering analytics for one app | `[inferred]` from the responsibility list |
| Compensation | Not stated | `[grounded]` posting silence |
| Market calibration | Not run; the role-family search was unavailable, so no pay band is given | — |
| Working pattern, first-year outcomes | Not stated | — |
| Unknowns | Pay, contract type, location, whether the role owns metric definitions, clinical data scope | — |
| Contradictions | None found in the JD as provided; the careers page was not checked | `[grounded]` JD |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | Six years at a subscription company | `[grounded]` CV, self-report | none |
| R2 | Expert SQL | must_have | direct | medium | none | Daily SQL on Snowflake | `[grounded]` CV, self-report | a sanitized query sample would raise to high |
| R3 | Experiment design at scale | must_have | direct | medium | none | Ran 30+ A/B tests a year, including the pricing test behind an 11% retention lift | `[grounded]` CV, self-report | a sanitized test readout would raise to high |
| R4 | Looker or similar BI | must_have | direct | medium | none | Built the company's Looker instance from scratch, 40+ governed dashboards | `[grounded]` CV, self-report | a scrubbed dashboard screenshot would raise to high |
| R5 | Define and maintain the metrics layer | must_have | adjacent | medium | transferability | Governed Looker models and a consent-state model are close, but the CV shows no metric-definition layer owned as such | `[inferred]` from the CV | G1 |
| R6 | Self-serve dashboards | important | direct | medium | none | Governed dashboards for a wide audience | `[grounded]` CV, self-report | none |
| R7 | Partner with PMs and clinicians on roadmap decisions | must_have | adjacent | medium | transferability | Direct partnership with product and the exec team through the monthly memo; no clinician-facing work on record | `[inferred]` from the CV | G2 |
| R8 | Strong written communication for non-technical readers | must_have | direct | medium | none | Writes the monthly metrics memo the exec team reads | `[grounded]` CV, self-report | none |
| R9 | Mentor two junior analysts | important | unclear | low | discovery | CV is silent on mentoring | `[grounded]` CV silence | G3 |
| R10 | Healthcare data, HIPAA | preferred | absent | high | capability | No healthcare work. Consumer PII under GDPR/CCPA is related, but it is not HIPAA | `[grounded]` CV statement | G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Metrics layer (R5, must_have) | transferability | Governed models and a consent-state model, but no record of owning definitions as a layer | A must-have; ownership is the main thing to clear | Owning metric definitions or governed model logic in Looker or the warehouse | A sanitized metric dictionary or model excerpt | `[inferred]` from the CV |
| G2 | Clinician partnership (R7, must_have) | transferability | Strong product and exec partnership; no clinician or care-team work | Clinicians are named in the mandate | Any work with care-ops, clinical or support teams, even as a stakeholder | An example of a clinician-facing analysis or decision | `[inferred]` from the CV |
| G3 | Mentoring (R9, important) | discovery | Not on the CV | Named in the mandate | Informal or formal coaching of analysts | Any example of analysts you helped grow | `[grounded]` CV silence |
| G4 | Healthcare data (R10, preferred) | capability | None | Stated as a plus, not a gate | Consumer privacy and consent work is the nearest bridge | None will close this quickly | `[grounded]` CV statement |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer and posting not verified | risk_signal | medium | "Harborlight Health (digital-health scale-up, ~400 people, Series C)" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer. Web research was not permitted, so this is unverified, not a finding against the employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Pay not stated | unknown | — | (no compensation in the posting) | Pay may sit below the market band, or the employer may not publish pay | `[inferred]` from the posting's silence | What is the budgeted base salary and bonus range for this role? | unresolved |
| RR3 | Decision rights over metric definitions | unknown | — | "define and maintain the metrics layer" | The role may own metric definitions, or the definitions may sit with product, finance or the clinical teams | `[inferred]` from the responsibility list against its silence on authority | When product, finance and clinical teams disagree on a metric, who decides, and does this role set that definition? | unresolved |
| RR4 | Clinical data scope and governance | unknown | — | "partner with product managers and clinicians" | The role may touch PHI, which would make HIPAA a working requirement rather than a plus | `[inferred]` from the clinician partnership against the "a plus" wording | What data does the analytics team see, is any of it PHI, and how is access to clinician-facing data governed? | unresolved |
| RR5 | Concrete scope and mentoring remit | positive_signal | — | "mentor two junior analysts" | Scope is defined and measurable enough to plan around | `[grounded]` JD | How will success in this role be measured in the first year? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Confirm the posting is live on Harborlight's own careers page before you invest in an application | see RR1 | `[generic]` pattern | advice |
| P2 | Lead with the 40+ governed Looker dashboards and the 30+ tests a year. Describe the consent and privacy work as GDPR/CCPA consumer PII, not as healthcare experience | see R4, R3, R10; keeps the claim to what you did | `[grounded]` CV | resume_edits_pending_approval |
| P3 | Prepare the pricing test as your worked example: design, sample, guardrails, and what you would defend | see R3 | `[grounded]` CV | pending your approval before any written use |
| P4 | Ask RR2, RR3 and RR4 verbatim in the first conversation | the register doubles as interview preparation | `[grounded]` register | advice |
| P5 | Don't claim clinician or healthcare experience in the application. Address R7 and R10 directly in conversation | see G2, G4 | `[inferred]` | advice |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches ("Harborlight Health care navigation app company Series C" and "Harborlight Health Senior Product Analyst careers") were refused, because web search permission has not been granted. Would have moved the organization row, the live-posting check and RR1 |
| 2. Role-family sweep | unavailable | No search was sent; web search was declined. Would have moved the market calibration and RR2 |
| 3. Hiring manager's public footprint | n/a | No name was given, so no query could be formed |

## Upgrade menu

- **Grant web search permission** and I'll run the three L1 checks: the live posting (RR1), the pay band for this title (RR2) and the role's usual scope (RR3). That's up to 5 searches and 2 fetches.
- **A sanitized metric dictionary or governed-model excerpt** moves R5 to high confidence and tests G1.
- **A sanitized readout of the 11% pricing test** moves R3 to high confidence.
- **A scrubbed dashboard screenshot** moves R4 to high confidence.
- **The posted salary, contract type and location** close RR2 and the hard-gate check.
- **Deeper diligence on Harborlight** (funding, leadership changes, recent news) is available once the first checks run, up to 5 more searches and 2 more fetches.

If you want this kept for later, I can write it to a `tuesday-dossier.md` file.

1. About R9: have you mentored or managed junior analysts, and what did that involve?
2. About R7 and RR4: have you worked directly with clinicians or care teams, or mainly with product and executive stakeholders?
3. About RR2 and your constraints: are there hard limits I should check, such as location or remote terms, work authorization, minimum pay or contract type?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.