**Worth applying to, on conditions. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (remote US or Denver office), R2 (base pay $148,000–$166,000)
- `must_have`: direct: R3, R4, R5, R6, R7
- `important`: adjacent: R9 (dbt-modelled warehouse in BigQuery); unclear: R8 (ingestion from app and CRM), R10 (data contracts analysts depend on)

R9, a credible bridge from Snowflake with the BigQuery limit named; R8 and R10, the intake is silent, and one question covers both.

**Opportunity ledger.** Sound on the posting: concrete responsibilities, a stack that matches your dbt and Airflow work, and a base range inside the market band (RR4, RR5). Open: no hiring manager named (RR1), equity terms unstated (RR2), and the Series C appears only on the company's own About page (RR3).

- **Hard gates:** none failed; unconfirmed: R1 (remote US or Denver office), R2 (base pay $148,000–$166,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) R1 and R2 check out against your location and pay floor; (2) R8 and R10 hold up in the first screen; (3) the BigQuery gap is framed as the adjacent bridge in R9, never as experience.
- **What would change this:** if R1 or R2 fails, the status becomes `no_go` with that gate as the reason. A clear answer on R8 and R10 moves it toward `go`.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states; founded 2016, Denver; 264 employees | `[grounded]` About page, fetched |
| Stated role | Build and run ingestion from the app and CRM, a dbt-modelled warehouse in BigQuery, and data contracts for analysts | `[grounded]` careers page, fetched; matches the pasted JD |
| Posting status | Live: "Accepting applications" | `[grounded]` careers page, fetched |
| Working pattern | Remote (US) or Denver office | `[grounded]` JD |
| Scope read | Ownership of the reporting pipelines with no direct reports stated, the usual scope for the title | `[inferred]` from "build and run"; `[generic]` the role-family norm |
| Market calibration | Senior Data Engineer at Series B–D companies, US: base median $151,000, IQR $139,000–$163,500 (n=2,310) | `[generic]` Datawright 2026 report, search snippet only, not fetched |
| Compensation | $148,000–$166,000 base plus equity; midpoint $157,000 sits above the median and inside the IQR | `[grounded]` JD; `[inferred]` from the band |
| Unknowns | Hiring manager, team size, equity terms, funding and runway beyond the self-reported Series C, your location and pay floor | — |
| Contradictions | None between the JD, the careers page and the About page | `[grounded]` both pages fetched |

The employer is established from its own domain, and its pages agree with the JD, so the failed-attribution entry does not apply. No third-party source corroborates the funding claim (RR3).

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | Your location is not in the intake, so the check is open. No statement of your constraint exists yet. | `[grounded]` JD; candidate constraint not given | Q1 |
| R2 | Base pay $148,000–$166,000 | hard_gate | unclear | none | hard_gate | Your pay floor is not stated, so the check is open. The range sits inside the market band; that is calibration, not your fit. | `[grounded]` JD; `[generic]` band | Q1 |
| R3 | 5+ years data engineering | must_have | direct | medium | none | Six years at a B2B payroll company. Self-reported, with no inspectable artifact yet, so expect a probe. | `[grounded]` intake statement | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | Both used daily, as stated. No artifact yet. | `[grounded]` intake statement | none |
| R5 | dbt and a cloud warehouse | must_have | direct | medium | none | dbt project on Snowflake, about 180 models. Self-reported. | `[grounded]` intake statement | none |
| R6 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow used for orchestration, as stated. | `[grounded]` intake statement | none |
| R7 | Data quality testing | must_have | direct | medium | none | Set up a Great Expectations suite, as stated. Its scope is not described. | `[grounded]` intake statement | none |
| R8 | Ingestion from the app and CRM | important | unclear | low | discovery | The intake does not mention ingesting from an application database or a CRM. Not established either way. | `[grounded]` intake silence | G1, Q2 |
| R9 | dbt-modelled warehouse in BigQuery | important | adjacent | medium | transferability | Snowflake dbt work carries over. BigQuery itself is unused, as stated. The limit is BigQuery-specific operations, which are unexercised. | `[grounded]` "never used BigQuery"; `[inferred]` bridge from Snowflake work; `[generic]` what BigQuery-specific limits involve | G2 |
| R10 | Data contracts analysts depend on | important | unclear | low | discovery | Tests and dbt models are adjacent, but the intake shows no agreed schemas with analysts. | `[inferred]` from test and model work; no contract claim made | G3, Q2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Ingestion from app and CRM (R8, important) | discovery | Warehouse modelling and orchestration are shown; source ingestion is not | It is the posting's first listed responsibility | Pulling from a production application database; syncing a CRM into a warehouse; a connector or change-data-capture job you ran | A DAG or connector README; a sanitized ingestion design | `[grounded]` intake silence |
| G2 | BigQuery warehouse (R9, important) | transferability | dbt on Snowflake, about 180 models; BigQuery never used | Named in the responsibilities, so the bridge needs its limit stated | dbt work on another cloud warehouse; any GCP project work; cost or partition tuning elsewhere | A free BigQuery sandbox running one of your dbt models | `[inferred]` bridge; `[generic]` BigQuery-specific limits |
| G3 | Data contracts (R10, important) | discovery | Tests and models exist; no agreed schemas with analysts are stated | Contracts are where analysts feel data quality | Schema agreements or a breaking-change process with downstream users; test failures handled with stakeholders | A sanitized contract or changelog | `[grounded]` intake silence; `[generic]` what contracts usually require |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | No hiring manager named | unknown | — | Posting names no hiring manager | Reporting line and team size are unknown | `[grounded]` posting silence | Who would I report to, and how many engineers and analysts would I work with day to day? | unresolved |
| RR2 | Equity terms unstated | unknown | — | "Salary $148,000–$166,000 plus equity" | The equity's value, vesting and basis are unknown | `[grounded]` JD | What equity grant is offered, with what vesting schedule and valuation basis? | unresolved |
| RR3 | Series C stated only on the company's own page | unknown | — | "Series C ($52M, February 2026)" | Funding and runway are self-reported; one search found no third-party corroboration | `[grounded]` About page; `[generic]` on how such claims are usually checked | Who led the February 2026 Series C, and is the data roadmap funded beyond the next year? | unresolved |
| RR4 | Scope matches the usual senior pattern | positive_signal | — | "Build and run the pipelines behind our tutoring platform's reporting" | One domain owned without direct reports is the usual scope for the title | `[grounded]` JD; `[generic]` Datawright scope norm | Which reporting pipelines does this role own end to end? | noted |
| RR5 | Stated pay sits inside the market band | positive_signal | — | "$148,000–$166,000" | Pay is at or near market; the midpoint is above the median | `[grounded]` JD; `[generic]` Datawright IQR | Is the base range flexible for the right candidate? | noted |

No `red_flag` entries. The posting asks nothing of you before an offer, and no payment, deposit or chat-only process appears in the material.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | CV line: "Built our dbt project on Snowflake, about 180 models; used Airflow for orchestration; set up our Great Expectations test suite." | States the verified stack with no added scope | `[grounded]` your intake sentences, clause by clause | pending your approval |
| E2 | BigQuery answer: say you have not used BigQuery, and that your dbt models and tests carry over, with the BigQuery-specific parts still to learn | Names the limit instead of claiming it | `[inferred]` from R9; `[generic]` on the BigQuery-specific parts | pending your approval |
| W1 | Run one dbt model in a free BigQuery sandbox before interviews | Narrows R9's limit with an artifact | `[generic]` closure path | pending your approval |
| Q1 | Ask RR1, RR2 and RR3 verbatim in the first screen | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A1 | Check R1 and R2 against your location and pay floor before investing in the application | Both gates are open | `[grounded]` R1, R2 | for you to check |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Pellucid Learning live online tutoring K-12 Denver" (no results, so the attribution is not established from that query) and "Pellucid Learning senior data engineer careers" (returned the careers page). Fetched pellucidlearning.com/careers/senior-data-engineer and pellucidlearning.com/about. Moved role reality: the posting is live and matches the JD, the About page matches the company text, and the contradictions row is empty. Series C is on the company's own page only. |
| 2. Role-family sweep | yes | Searched "Senior Data Engineer base salary median 2026 United States", which returned the Datawright 2026 Data Engineering Pay Report snippet (datawright.example/2026-data-engineering-pay-report). The snippet was not fetched. Moved the market calibration line and RR5. |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form. The upgrade menu names what a name would unlock. |

## Upgrade menu

- Your location and pay floor, one line each → R1 and R2 leave `unclear`, and the hard-gates line clears.
- A sanitized ingestion example (a connector or pipeline you ran) → R8 moves up from `unclear`.
- A sanitized data-contract or schema agreement with analysts → R10 moves up.
- A BigQuery sandbox running one of your dbt models → R9's limit narrows.
- Your dbt project repo or its README → R3–R7 move from `medium` toward `high`.
- The hiring manager's name → RR1 closes, and the scope read sharpens.
- A deeper company pass on Pellucid Learning (funding and leadership changes, hiring patterns, public employee and candidate reports, recent news): up to 5 more searches and 2 more fetches. Say the word and it runs.

If you want this kept for later recovery turns, I can write it out as `tuesday-dossier.md`.

Q1, tagged R1 and R2: Can you work from the US, remote or from Denver, and is a $148,000 base above your floor?

Q2, tagged R8 and R10: Have you built ingestion from an application database or a CRM, or agreed schemas with analysts that downstream users depended on?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.