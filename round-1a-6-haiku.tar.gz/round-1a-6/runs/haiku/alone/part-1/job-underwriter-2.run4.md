**Decision snapshot:** `conditional_go`. You're not wasting your time, but this is a stretch role, and applying to it cold is the weakest version of the pivot. Apply if you can show ownership-shaped evidence. Otherwise, target roles where the title gap matters less.

**Hard gates:** none stated in the JD. Your location, pay floor and schedule are unknown to me, so those checks are open.

**Fit ledger**

| Requirement (JD) | Priority | Fit | Gap type |
|---|---|---|---|
| Discovery with integration partners | must-have | strong | none |
| Launch coordination with sales and support | must-have | strong | none |
| API technical fluency: docs, schemas | must-have | strong | none |
| Stakeholder management across engineering, sales, customers | must-have | strong | presentation |
| Shipped API or platform products | must-have | partial | transferability |
| Writing specs and driving delivery with engineering squads | must-have | partial | transferability |
| 3+ years product management | must-have | gap | capability or presentation |
| Owning the roadmap | must-have | gap | capability |
| Defining and tracking adoption metrics | must-have | unknown | — |
| Agile delivery | must-have | unknown | — |

**Role reality.** The role is platform PM for a partner-facing API: it owns priorities and outcomes, not just specs. The posting says nothing about the team beyond two squads and about 150 people. I did not run research, so nothing here is checked against Quartzline itself. Role-family pattern: a platform PM role at this stage usually expects a few years of PM ownership. `[generic]`

**Evidence read.**

- **Strongest match.** Your seven years of integration work are close to this job's core loop: discovery with partners, requirements, architecture, UAT, go-live, and feedback into product. You know the API surface, and you've been the person holding engineers, clients and PMs together. That covers about half the JD well.
- **Real gap.** The must-have is "3+ years PM" and you have no PM title. Roadmap ownership, prioritization decisions, and metrics you were accountable for are the other gaps. Quarterly roadmap-input sessions are evidence you gathered input for product. They are not evidence you owned the roadmap. Don't let the resume blur that line.
- **Unconfirmed.** The request-triage tool from earlier is a lead, not evidence. If you built it, owned what it did, and can show adoption numbers, it becomes your best PM-shaped proof. I have not counted it.

**Risk register**

- **Must-have title gap.** Expect a screen to reject you on it unless your story addresses it directly. `[generic]`
- **Reframing risk.** "Ran roadmap-input sessions" must not become "owned the roadmap" on your resume or in interviews. That is the claim an interviewer will probe, and it would be inflated.

**Application plan (as far as evidence allows).** Lead with the integration-to-product loop: you saw what partners needed, you turned it into requirements, and you shipped it with them live. Be explicit about the transition: "I haven't held the title, and here's what I've owned." Do not claim PM ownership you can't document. No outreach or CV text should go out until you approve it.

**Dossier offer.** I can write a `tuesday-dossier.md` capturing this analysis so you can reuse it for other roles. Say the word.

**Upgrade menu.** Research on Quartzline (company stage, whether the posting is live, the hiring manager's background) would sharpen the opportunity side. It is one search pass and currently not run. Confirming the triage tool would most change the fit side. Your stated non-negotiables would close the hard-gate check.

**Research tier: L0 — no searches; user links read 0**

**Questions**

1. Did you build the request-triage tool, what did it do, and did you own the decisions about it? Did you track any adoption numbers?
2. Have you ever owned a prioritization or backlog decision for a product or feature, even informally? Did you write product specs that engineers built against?
3. What are your hard constraints: location, pay floor, and whether you'd take a PM title below the 3-year bar?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.