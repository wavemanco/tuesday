I'll read the reference files the skill needs before building the assessment.
**Yes, on conditions: `conditional_go`.** Your experience lines up with the four `must_have` rows (R2, R3, R4, R5 all read `direct`). What holds the decision back is three open items: R1, the fully-remote UK gate, which is unconfirmed; RR2, the employer, which I could not verify; and RR3, the salary, which the posting doesn't state.

**Fit ledger.**

- `hard_gate`: unclear: R1 (Fully remote, UK-based)
- `must_have`: direct: R2, R3, R4, R5
- `important`: direct: R6 · adjacent: R7 (Pet-insurance product)
- `preferred`: direct: R8 (Insurance experience)

R1 is the gate your inputs don't settle. R7 carries over from motor pricing, but the pet-specific parts don't. R2 to R5 and R8 are read from your intake, so they stay at `medium` until there's an artifact.

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote, UK-based); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Opportunity ledger:** RR2 (employer unverified, `medium`), RR1 (people management unstated) and RR3 (salary withheld) are open. RR4 is positive: the listed work matches what you already do daily.
- **Conditions for go:** (1) R1 confirmed; (2) RR2 checked on Brindlemoor's own careers page; (3) RR3 checked against your pay floor once a salary is known.

**Research was not run.** The web search tool was refused permission in this session, so I sent four searches and fetched nothing. The employer, the live posting, the pet-pricing salary band and Odile Varga's public footprint are all unchecked.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech with a pet-insurance product | `[grounded]` your JD text; existence not checked |
| Mandate | Own pricing analytics for the pet product: build and monitor rating models, design and read price tests, recommend to underwriting and product | `[grounded]` JD |
| Working pattern | Fully remote, UK | `[grounded]` JD |
| Hiring manager | Odile Varga, Director of Pricing | `[grounded]` your message; footprint not checked |
| Scope read | A senior analyst owning one product's pricing analytics, with no team size stated | `[inferred]` from the listed responsibilities |
| Market calibration | Not run; no salary band | — |
| Unknowns | Salary, people management, team size, whether pet rating models already exist, employer verification | — |
| Contradictions | None visible within the JD | `[grounded]` JD |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote, UK-based ("Fully remote (UK)") | hard_gate | unclear | none | hard_gate | Your location and right to work aren't in the material, so the gate is not established | `[grounded]` JD; your location not given | Q1 below |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | Five years stated, two as senior analyst; no artifact to inspect | `[grounded]` your intake | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | Daily use stated; no code artifact | `[grounded]` your intake | An anonymised query or script would raise this to `high` |
| R4 | GLM experience; building and monitoring rating models | must_have | direct | medium | none | You built and maintained a GLM for a motor young-driver book; the technique transfers, the domain is motor | `[grounded]` your intake; `[inferred]` transfer of technique | A model documentation extract would raise this to `high` |
| R5 | Experience presenting to underwriting or actuarial leads | must_have | direct | medium | none | Quarterly pricing review to the head of underwriting | `[grounded]` your intake | none |
| R6 | Designing and reading price tests | important | direct | medium | none | Fourteen price tests last year with the underwriting team | `[grounded]` your intake | none |
| R7 | Pet-insurance product knowledge ("our pet-insurance product") | important | adjacent | medium | transferability | Motor pricing carries over: GLMs, rating-factor choice, price testing. Limits: no pet claims frequency or severity work, no breed or species rating, no vet-cost dynamics | `[inferred]` adjacency from motor work; `[generic]` that pet claims behave differently from motor | G1 |
| R8 | Insurance experience (a plus) | preferred | direct | medium | none | Motor insurance pricing for five years | `[grounded]` your intake | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pet-insurance product knowledge (R7, important) | transferability | Motor pricing work only; no pet data | R7 is the likeliest objection; a bridge narrows it | Any rating work that used non-motor data; any work on frequency or severity models; a claims-cost analysis | A one-page note mapping your motor GLM steps onto a pet rating structure | `[inferred]` bridge from motor work; `[generic]` that this is the likeliest objection |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | People management not stated | unknown | — | "Senior Pricing Analyst" (no management mentioned) | The role may carry line management, which you have not done | `[inferred]` from title and silence | Will this role line-manage anyone now or within a year, and if so, how many? | unresolved |
| RR2 | Employer not established | risk_signal | medium | "Brindlemoor (insurtech)" | Brindlemoor may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not be a real hiring employer. Research did not run, so this is unverified, not disproved | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR3 | Salary withheld | unknown | — | Not stated in the material | Pay may sit below a senior pricing band, or the company may simply not publish salaries. No band was checked | `[inferred]` from the posting's silence | What is the base salary for this role, and is there a bonus? | unresolved |
| RR4 | Scope is concrete | positive_signal | — | "Design and read price tests … recommendations for underwriting and product" | The listed work matches your current practice, so the scope is defined | `[grounded]` JD | Which rating models does the team already run, and who owns the pet price tests today? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Move the GLM line ("Built and maintained the GLM rating model for our young-driver book") and the price-test line ("Ran 14 price tests last year with the underwriting team") above the tools list. No new wording | R3–R6 are must-haves and read more clearly up top | `[grounded]` your own sentences; reframing audit clean | resume_edits_pending_approval |
| A1 | Check Brindlemoor's careers page before investing in an application | RR2 | `[grounded]` RR2 | pending your approval |
| A2 | Put RR1 and RR3 to the employer in the first conversation | Verification questions | `[grounded]` register | pending your approval |
| A3 | Write the one-page motor-to-pet bridge note | G1 and R7 | `[inferred]` from G1 | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches for Brindlemoor were refused. Would have moved RR2 and the contradictions row |
| 2. Role-family sweep | unavailable | One search for pet-insurance pricing salary was refused. Would have moved the market calibration and RR3 |
| 3. Hiring manager's public footprint | unavailable | One search for Odile Varga was refused. Would have moved the scope read and the positioning |

I can write this up as `tuesday-dossier.md` whenever you want to keep it.

**Upgrade menu:**

- Permission for web search, so the three L1 targets can run (4 searches, 2 fetches): verifies Brindlemoor and the posting, pulls a pet-pricing salary band, and checks Odile Varga's public footprint. This would move RR2, RR3 and the scope read.
- The posting's URL, if you have it: a direct read could settle RR2 and the contradictions row.
- A salary range, if you know one: closes RR3.
- An anonymised script or model document: raises R3 and R4 to `high`.

**Questions** (response modes below):

1. R1: Are you based in the UK and able to work here without sponsorship?
2. RR3: Do you have a pay floor for this role, and would a withheld salary stop you applying?
3. RR1: Would you take a role that line-manages people, or does that rule it out?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.