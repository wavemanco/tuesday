**Decision: `no_go`.** Your two hard constraints both fail on the posting's own terms: R1 (remote work) and R2 (base of at least $150k). The rest of the posting's pattern also looks like the kind of role that would be hard to succeed in, though that doesn't change the decision.

- **Hard gates:** failed: R1 (remote work; posting says on-site Austin 5 days, "no exceptions"), R2 (base at least $150k; posting says $70–85k). Candidate constraints were given, so these checks ran.
- **Fit ledger:** R1 and R2 are both hard-gate failures. Your evidence is strong on the must-haves R3, R4a and R6. R4b (SEO, brand, PR, partnerships, sales ops) isn't in your CV, and R5 (team of one) is adjacent to your 3–7-person teams.
- **Opportunity ledger:** the posting has one stated positive, Series A and profitable since day one, which is unverified. Its risk entries are RR1 to RR4 below, plus the standing entry RR5.
- **Severe red flags:** none found.
- **What would change this:** both gates would have to differ in writing, base at or above $150k and remote work. The posting states both as fixed, so I'd expect that to be unlikely.

**Evidence map**

| # | Priority | Fit | Requirement | Confidence | Evidence |
|---|---|---|---|---|---|
| R1 | hard_gate | hard_gate_fail | Remote work (posting: on-site 5 days) | high | Posting |
| R2 | hard_gate | hard_gate_fail | Base at least $150k (posting: $70–85k) | high | Posting |
| R3 | must_have | direct | 8+ years growth leadership | medium | Your CV, unverified |
| R4a | must_have | direct | Paid acquisition, lifecycle/CRM, experimentation | medium | Your CV |
| R4b | must_have | unclear | SEO/content, brand, PR, partnerships, sales ops | low | Not in your CV |
| R5 | important | adjacent | Lead a team, starting as a team of one | medium | Built and managed teams of 3–7 |
| R6 | important | direct | SQL, GA4, Braze | medium | Your CV |
| R7 | important | unclear | Reporting to the CEO with a board dotted line | low | Not evidenced |

**Opportunity risk register**

| ID | Class | Severity | Signal and quote | Basis | Verification question for the employer |
|---|---|---|---|---|---|
| RR1 | risk_signal | medium | Responsibility without authority: "all revenue growth end to end," "team of one to start" | `[inferred]` from scope against headcount | What budget and headcount are committed to this role in year one, and which decisions can I make without sign-off? |
| RR2 | risk_signal | medium | Always-on expectation: "evenings and weekends when it matters is just who we are" | `[inferred]` from the posting's wording | How often does the team work evenings and weekends outside launches, and how is that compensated? |
| RR3 | risk_signal | medium | Absent success metrics: "success metrics will evolve as we learn" | `[inferred]` | What three numbers will define success at my six-month review, and who sets them? |
| RR4 | risk_signal | medium | Seniority–pay mismatch: Head-level scope at $70–85k base | Posting's range is `[grounded]`; I have no verified market band (see the research note), so this is not yet calibrated | How was the base set against this scope, and is it open to change? |
| RR5 | risk_signal (standing) | medium | Employer not established: the company could not be checked, so the posting is unverified | `[generic]` pattern for companies of this size | Can you point me to this role on your own careers site, and who would I interview with? |

RR5 would cap a `go` at `conditional_go` until verified. Because R1 and R2 already force `no_go`, it changes nothing here.

**Research tier: L1 — searches 1 of 5, fetches 0 of 2; user links read 0**

| # | Target | Status | Reason |
|---|---|---|---|
| 1 | Company official site and careers page | unavailable | My one web search was refused for lack of permission, so nothing about Novaline was checked |
| 2 | Role-family sweep (scope, title, pay) | unavailable | Same refusal; no market band is cited above |
| 3 | Hiring manager's public footprint | n/a | No hiring manager was named |

On your question: your sense that something is off is well-founded. The posting pairs Head-level scope and an eight-year requirement with a team of one, a pay range about $65k below your floor at its top, and both always-on and no-defined-success language. Those patterns don't prove a bad job, but they are the kind of signal worth checking before you invest time.

If you want, I can save this assessment as a `tuesday-dossier.md` for your records. To sharpen it, the live posting link and Novaline's own careers page would let RR5 be checked, and a permitted search would let RR4 be calibrated against a real market band. Neither would change the `no_go`.

Is there anything beyond pay and location that would make you want to pursue this if the recruiter signaled a change?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.