**Worth applying to, on conditions. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: H1 (your location and US work authorization for the remote option; the Denver option needs a commute)
- `must_have`: direct: R1, R2, R3, R4, R5
- `important`: adjacent: R6 (BigQuery); unclear: R7 (ingestion from app and CRM), R8 (data contracts)
- `preferred`: none stated in the posting

**Opportunity ledger.** No red flags and no severe signals. The posting is specific about its outcomes and its pay range sits in the market band `[generic]`. The open items are the employer check (RR1), the scope (RR2), the withheld equity terms (RR3), and the contract basis, which the posting does not state.

- **Hard gates:** none failed; unconfirmed: H1 (location and US work authorization). Your non-negotiables were not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) confirm the posting is live and the employer is as described (RR1); (2) confirm location and work authorization for the remote option (H1); (3) present BigQuery as not yet used, never as experience (R6).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 states; founded 2016, Denver; 264 employees; Series C, $52M, February 2026 | `[grounded]` from the about page as you supplied it; not checked live |
| Mandate | Build and run the reporting pipelines: ingestion from the app and CRM, a dbt-modelled warehouse in BigQuery, data contracts for analysts | `[grounded]` JD |
| Stack | dbt, BigQuery, Airflow or similar, data-quality testing | `[grounded]` JD |
| Compensation | $148,000–$166,000 base, plus equity (amount not stated) | `[grounded]` JD |
| Market calibration | Series B–D senior base median $151,000; IQR $139,000–$163,500. The posted range overlaps most of that IQR, and its midpoint ($157,000) sits above the median | `[generic]` from the recruiter-supplied 2026 report; not re-checked live |
| Scope read | The posting asks for ingestion from two sources, the warehouse, and the contracts. That is wider than the one-domain scope typical for this title | `[inferred]` from the duties against the market report's scope norm |
| Location | Remote (US) or Denver office | `[grounded]` JD |
| Unknowns | Hiring manager, team size, equity terms, contract basis, whether BigQuery is current or a planned move | — |
| Contradictions | None found between the JD and the about page as supplied. Not checked against the live site | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years data engineering | must_have | direct | medium | none | Six years at a B2B payroll company, stated; not yet inspected | `[grounded]` your background | none |
| R2 | Strong SQL and Python | must_have | direct | medium | none | Daily use, stated | `[grounded]` your background | none |
| R3 | dbt and a cloud warehouse | must_have | direct | medium | none | dbt project of about 180 models on Snowflake, a cloud warehouse. The requirement names the category, not a vendor | `[grounded]` your background | offer: a sanitized model sample |
| R4 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow, stated | `[grounded]` your background | none |
| R5 | Data quality testing | must_have | direct | medium | none | Set up the Great Expectations suite, stated | `[grounded]` your background | offer: a sanitized expectations file |
| R6 | BigQuery specifically (named in the duties) | important | adjacent | medium | transferability | Snowflake and BigQuery are both cloud warehouses on dbt, but you have not used BigQuery | `[grounded]` background; `[generic]` that dbt works across warehouses through adapters | see gap queue G1 |
| R7 | Ingestion from the app and CRM | important | unclear | low | discovery | Not in your background. Payroll-company ingestion is plausible but unstated | — | see gap queue G2 |
| R8 | Data contracts for analysts | important | unclear | low | discovery | Not in your background | — | see gap queue G2 |
| H1 | Location and US work authorization | hard_gate | unclear | none | hard_gate | Remote requires US work eligibility; Denver requires a commute. Neither is stated | — | confirm before applying |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R6) | transferability | Snowflake-on-dbt experience; no BigQuery | The duties name it, and an interviewer may probe it | Any GCP work, a side project or course, or a warehouse migration you led | A short BigQuery query or dbt profile, if one exists | `[inferred]` from the duties against your background |
| G2 | Ingestion and data contracts (R7, R8) | discovery | Your background describes warehouse and testing work but not source ingestion or contracts | Two of the duties rest on these | Payroll data feeds you built, schema agreements with consumers, data-contract or SLA work | Pipeline diagram or a contract you wrote | `[inferred]` from the duties against your background |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer and posting not confirmed as described (standing entry) | risk_signal | medium | "Pellucid Learning runs live online tutoring… 264 employees" | Reasons, none ranked as likely: the company is newer or smaller than its page reads; the posting is stale; the listing is not from a current hiring employer. The web search this check needed was refused, so none of the three can be ruled out | `[grounded]` the check could not run | Can you send the live posting link, the company's careers page, or the recruiter's email domain? | unresolved; caps `go` at `conditional_go` |
| RR2 | Scope wider than a single domain | risk_signal | low | "Build and run the pipelines behind our tutoring platform's reporting" | Ingestion, warehouse and contracts together, possibly for one hire with no team stated | `[inferred]` from the duties against the `[generic]` scope norm | Who else owns these pipelines, and what does this role own alone? | unresolved |
| RR3 | Equity amount and terms not stated | unknown | — | "plus equity" | Could be modest or standard; the posting does not say | `[grounded]` JD silence | What is the equity grant, vesting and valuation basis? | unresolved |
| RR4 | Contract basis not stated | unknown | — | (silent) | Permanent or fixed-term is not in the posting | `[grounded]` JD silence | Is this a permanent role? | unresolved |
| RR5 | Pay range sits inside the market band | positive_signal | — | "$148,000–$166,000" | Pay is unlikely to be the constraint | `[grounded]` JD; `[generic]` band | — | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Lead the CV with the dbt project (about 180 models on Snowflake) and Airflow, and name Great Expectations in the testing line | Direct evidence for R3–R5 | `[grounded]` your background | pending your approval |
| A2 | State BigQuery as not used yet. Say what transfers (dbt, SQL, the warehouse design work) without claiming BigQuery experience | R6, G1 | `[grounded]` R6; `[generic]` dbt adapter model | pending your approval |
| A3 | Before investing in an interview loop, ask the recruiter for the live posting, the scope of ingestion and contracts, the contract basis and the equity terms | RR1–RR4 | `[inferred]` from the register | pending your approval |

## Evidence status

Verified: none yet. Your background claims are stated, not inspected. They are leads until an artifact supports them.

Research tier: L1 — searches 3 of 5, fetches 0 of 2; user links read 1

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searches refused in this session (permission not granted). The posting's liveness, the employer's existence, and consistency with the about page are unchecked. This is RR1 |
| 2. Role-family sweep | unavailable | Search refused. The market band rests on the recruiter-supplied report only |
| 3. Hiring manager's public footprint | n/a | No name was given |

## Dossier offer

I can write this assessment out as a `tuesday-dossier.md` file if you want a kept copy.

## Upgrade menu

- The live posting link or the careers page URL → closes RR1 (employer and posting status)
- The recruiter's email domain → also closes RR1
- Equity terms (grant size, vesting, valuation basis) → closes RR3
- A sanitized dbt model, an Airflow DAG, or a Great Expectations file → raises R3–R5 from `medium` to `high`
- A hiring manager's name → adds a footprint check and sets the positioning for that reader
- A deeper research pass on Pellucid (funding, leadership, staff reports; up to 5 more searches and 2 more fetches), offered once; it can run only once search permission is granted

**Questions**

H1: Where are you based, and are you authorized to work in the US without sponsorship?
G2 (R7, R8): Have you built ingestion from application or CRM sources, or owned data contracts with analysts? Which?
G1 (R6): Have you touched BigQuery or any other GCP service, even in a side project or course?

Answer in text, paste a voice transcript, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.