**Yes, it's worth applying to, with conditions: `conditional_go`.** Your core stack matches the posting, and the main gap is BigQuery, which is recoverable. Two hard gates (location and pay floor) are unconfirmed, and I need your answers on them before you invest in the loop.

**Fit ledger.**

- `hard_gate`: unclear: R1 (Remote US or Denver location), R2 (salary $148,000–$166,000)
- `must_have`: direct: R3, R4, R5, R6, R7
- `important`: adjacent: R8 (dbt-modelled warehouse in BigQuery); unclear: R9 (ingestion from app and CRM), R10 (data contracts analysts depend on)

R8 is a credible bridge, its limit named (no BigQuery use). R9 and R10 aren't in your background, so they stay unestablished until you answer Q3.

**Opportunity ledger.** The posting is transparent: the salary is published (RR4), and it's live on the company's own careers page. Open questions are the warehouse's platform status (RR1), the scope of ownership (RR2), and equity and reporting line (RR3). Severe red flags: none found.

- **Hard gates:** none failed; unconfirmed: R1 (Remote US or Denver location), R2 (salary $148,000–$166,000); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **Conditions for go:** (1) location and work eligibility confirmed (R1, Q1); (2) your pay floor sits at or below the posted range (R2, Q2); (3) the BigQuery gap is framed as adjacent, with a concrete plan to close it (R8, G1)

---

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 states; founded 2016, Denver; 264 employees; Series C ($52M, February 2026) | `[grounded]` company About page, found by search |
| Mandate | Build and run ingestion, a dbt-modelled BigQuery warehouse, and analyst-facing data contracts for tutoring reporting | `[grounded]` JD and careers page (fetched) |
| First-year outcomes | Not stated | `[grounded]` absence in JD |
| Working pattern | Remote (US) or Denver office | `[grounded]` JD |
| Scope read | Spans ingestion, modelling and contracts; wider than one domain's pipelines, though no direct reports are stated | `[inferred]` from the posting's three responsibilities |
| Market calibration | Posted base $148,000–$166,000 sits around the median of $151,000, with the top above the $163,500 upper quartile. Band basis: Datawright 2026 report, US, n=2,310, Series B–D | `[generic]` band; `[grounded]` posted figure |
| Unknowns | Equity terms, reporting line, team size, whether the warehouse is moving off Snowflake or already on BigQuery | — |
| Contradictions | None: the JD matches the careers page | `[grounded]` careers page |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver location | hard_gate | unclear | none | hard_gate | Your location and work authorization are not in the material | `[grounded]` JD | Q1 |
| R2 | Salary $148,000–$166,000 against your floor | hard_gate | unclear | none | hard_gate | No pay floor given | `[grounded]` JD; `[generic]` band | Q2 |
| R3 | 5+ years data engineering | must_have | direct | medium | none | Six years at a B2B payroll company; your own statement, no artifact | `[grounded]` your brief | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | Daily use, self-reported | `[grounded]` your brief | none |
| R5 | dbt and a cloud warehouse | must_have | direct | medium | none | ~180-model dbt project on Snowflake; expect a probe on warehouse depth | `[grounded]` your brief | none |
| R6 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow for orchestration, self-reported | `[grounded]` your brief | none |
| R7 | Data quality testing | must_have | direct | medium | none | Set up the Great Expectations suite | `[grounded]` your brief | none |
| R8 | Dbt-modelled warehouse in BigQuery | important | adjacent | medium | transferability | dbt and warehouse work carry over; you have never used BigQuery, which is the limit | `[inferred]` bridge from Snowflake work; `[generic]` that the dbt modelling layer is largely portable | G1 |
| R9 | Ingestion from app and CRM | important | unclear | low | discovery | Not in your background | `[grounded]` absence | Q3 |
| R10 | Data contracts analysts depend on | important | unclear | low | discovery | Not in your background | `[grounded]` absence | Q3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R8, important) | transferability | Snowflake dbt work; no BigQuery | The JD names BigQuery as the target warehouse; a credible plan narrows the most visible objection | Any warehouse migration or cost-tuning you did; any GCP work, including a sandbox | A BigQuery sandbox project, a short note on dbt-on-BigQuery differences, a cost or partitioning example | `[inferred]` bridge; `[generic]` that the SQL dialect and cost model differ, while the dbt layer largely carries over |
| G2 | Ingestion and data contracts (R9, R10, important) | discovery | Not in your background | Two of five responsibilities; ownership here decides how much of the role is new | Pipelines from a product database or a CRM API; schema or SLA agreements with analysts | A pipeline diagram, a contract doc, an ingestion DAG | `[grounded]` absence; the question is in the closing block |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Warehouse platform unstated | unknown | — | "a dbt-modelled warehouse in BigQuery" | The warehouse may be moving off Snowflake, which makes the bridge wider work than an adjacent skill | `[inferred]` from the JD's silence on migration | Is the warehouse already in BigQuery, or is a migration planned? | unresolved |
| RR2 | Ownership scope unclear | unknown | — | "Build and run the pipelines" | The role may own ingestion, modelling and contracts alone, which is broader than one domain | `[inferred]` from the three responsibilities | Which of ingestion, modelling and contracts does this role own alone, and who shares them? | unresolved |
| RR3 | Equity and reporting line unstated | unknown | — | "plus equity" | Equity value and the manager relationship are both unknown | `[grounded]` JD silence | What is the equity grant, and who would this role report to? | unresolved |
| RR4 | Salary published | positive_signal | — | "Salary $148,000–$166,000" | Transparent pay; the range sits around the market median | `[grounded]` JD; `[generic]` band | Is there room above the top of the range for a senior hire? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm location and work eligibility with the recruiter before the loop | R1 gate | `[grounded]` JD | pending your approval |
| A2 | Build a short BigQuery bridge: a sandbox project and a dbt-on-BigQuery note | G1, R8 | `[inferred]` from R8 | pending your approval |
| A3 | Lead with the Snowflake dbt and Great Expectations work for R5 and R7; do not claim BigQuery | Honest positioning | `[grounded]` your brief | pending your approval |
| A4 | Ask RR1 and RR2 in the first recruiter screen | Scope and platform | `[grounded]` register | pending your approval |

Nothing here is externally visible until you approve it.

## Evidence status

Verified: R3, R4, R5, R6, R7 claims (your brief, specific; no artifact yet). Unverified leads: none. Rejected inferences: none.

Research tier: L1 — searches 2 of 5, fetches 1 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Pellucid Learning online tutoring K-12 Denver Series C" (returned the company's About page); fetched pellucidlearning.com/careers/senior-data-engineer. Confirmed the posting is live and matches the JD. Organization and contradictions rows |
| 2. Role-family sweep | yes | Searched "Datawright 2026 Data Engineering Pay Report senior data engineer salary", which returned datawright.example/2026-data-engineering-pay-report. The figures come from the search snippet, not a full read. Market calibration `[generic]` |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

The company is attributable: its About page and careers page match the posting, so the standing employer-not-established entry does not apply.

Dossier offer: I can write this assessment to `tuesday-dossier.md` for you to keep.

**Upgrade menu**

- A BigQuery sandbox project or a migration note → R8 to `high`, and the RR1 answer
- Your answer to Q3 → R9 and R10 resolve, and the scope read (RR2) firms up
- Your pay floor and eligibility → R1 and R2 close, and the decision moves to `go` or `no_go`
- The budgeted salary or equity terms → RR3 and RR4 close
- A deeper research pass on Pellucid Learning (funding history, leadership changes, public employee reports; up to 5 more searches and 2 more fetches): say the word and it runs

**Questions**

Q1 (R1): Are you based in the US, and can you work there without sponsorship?

Q2 (R2): What is the lowest base salary you would accept for this role?

Q3 (R9, R10): Have you built ingestion from an app or CRM, or defined data contracts with analysts? If so, what did you own?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.