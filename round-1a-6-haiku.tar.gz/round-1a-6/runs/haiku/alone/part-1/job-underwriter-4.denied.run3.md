**Worth applying, on conditions. Status: `conditional_go`.**

**Fit ledger** (per requirement, from the evidence map below)

- `hard_gate`: unclear: R11 (your constraints were not given, so nothing was checked against them)
- `must_have`: direct: R1, R2, R3, R4 · adjacent: none
- `important`: direct: R6 · adjacent: R5 · unclear: R7 · absent: R8
- `preferred`: direct: R9

**Opportunity ledger.** Nothing in the posting is a red flag. Its scope is concrete (rating models, price tests, recommendations), and the hiring manager is named. The unknowns are whether this role owns pet rating decisions or recommends them, whether it has direct reports, and whether the employer checks out. Company research did not run (see the research tier below), so the employer is unverified.

- **Hard gates:** none failed; unconfirmed: R11 (your non-negotiables were not given).
- **Severe red flags:** none found.
- **Conditions for go:**
  1. Confirm the posting is live and the employer is real, via the company's careers page or the recruiter's email domain (RR4). Until then this caps at `conditional_go`.
  2. Confirm whether the role has direct reports (RR2). You have never managed anyone, and the JD does not say.
  3. Frame the pet gap honestly as a bridge from motor, never as existing pet expertise (R5, R8).

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, described as an insurtech with a pet-insurance product | `[grounded]` JD header; not verified (see RR4) |
| Mandate | Own pricing analytics for the pet product: build and monitor rating models, design and read price tests, turn results into recommendations for underwriting and product | `[grounded]` JD |
| Seniority signal | Senior title with ownership of the product's pricing analytics | `[grounded]` JD title and responsibilities |
| Hiring manager | Odile Varga, Director of Pricing | `[grounded]` your input |
| Market calibration | Not established. Web search was refused, so no title or salary band was checked. The JD states no compensation. | — |
| Unknowns | Decision rights against the pricing committee; direct reports; pet data history; compensation; contract basis | — |
| Contradictions | None within the material you provided | — |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | Five years in UK motor pricing analytics, two as senior analyst. Length of experience is not a gate, and you meet it either way. | `[grounded]` your CV, unverified | none |
| R2 | Strong SQL and Python | must_have | direct | medium | none | Daily use stated; no artifact yet | `[grounded]` your CV | offer: a sanitized query or notebook would raise to high |
| R3 | GLM experience | must_have | direct | medium | none | Built and maintained the GLM rating model for the young-driver book. The method transfers, but the risk factors are motor's. | `[grounded]` your CV | none |
| R4 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | Presents the quarterly pricing review to the head of underwriting | `[grounded]` your CV | none |
| R5 | Build and monitor rating models for the pet product (implied by the mandate) | important | adjacent | medium | transferability | You have built and monitored rating models in motor. No pet model is in your history. | `[inferred]` the mandate against your motor work | see gap queue G1 |
| R6 | Design and read price tests | important | direct | medium | none | Ran 14 price tests last year with the underwriting team | `[grounded]` your CV | none |
| R7 | Turn results into recommendations for underwriting and product | important | unclear | low | discovery | Underwriting recommendations are evidenced. Product recommendations are not. | `[grounded]` CV silence on product | ask Q3 |
| R8 | Pet-insurance domain knowledge (species, breed, vet-cost inflation, lifetime versus annual cover; implied by "our pet-insurance product") | important | absent | none | capability | No pet-insurance work in your history. Learnable, but not yet evidenced. | `[grounded]` CV silence | closure path named in G1 |
| R9 | Insurance experience | preferred | direct | medium | none | Five years at a UK motor insurer. The "plus" is met, though not in pet. | `[grounded]` your CV | none |
| R10 | Direct reports (not in the JD; you have never managed anyone) | — | unclear | low | discovery | The JD does not state line management. It is a risk only if the role has direct reports. | `[inferred]` from the JD's silence | ask Q2; see RR2 |
| R11 | Non-negotiables (location, contract, pay, start date) | hard_gate | unclear | low | hard_gate | Remote UK is in the JD, but your own constraints were not given. Nothing can be checked. | — | ask Q1 |

**Gap recovery queue**

| # | Gap (req) | Type | What I see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pet-insurance rating (R5, R8) | transferability / capability | Motor GLM and price-test experience; no pet work | This is the objection most likely to come up. The method transfers, but the risk drivers do not. | Any pet, livestock or health-related rating work; any product-analytics work outside motor | A sanitized note on how you would re-specify a GLM for pet risk drivers | `[inferred]` bridge from your motor work; `[generic]` that pet risk drivers differ |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Decision rights unstated | unknown | — | "own pricing analytics" | The role may recommend to the Director of Pricing rather than own rating decisions | `[inferred]` from the JD's verbs against its silence on sign-off | Would this role own rating decisions for the pet product, or recommend them to the Director? | unresolved |
| RR2 | Direct reports not stated | unknown | — | none | The role may line-manage, which you have not done | `[inferred]` from the JD's silence | Does this role have direct reports, now or planned? | unresolved |
| RR3 | Pet data history unknown | risk_signal | medium | "build and monitor rating models" | A young insurtech product may have thin claims history, which would limit GLM fitting | `[inferred]` from the product's age and insurtech stage, neither confirmed | How much claims history does the pet product have, and where are the gaps? | unresolved |
| RR4 | Employer unverified | risk_signal | medium | "Brindlemoor (insurtech)" | Too new or small, a stale posting, or not a live hiring entity. Equally likely; none ranked. | `[inferred]`; web search refused, so not established | Is there a live posting or a careers page for Brindlemoor, or a recruiter email domain? | unresolved |
| RR5 | Positive: concrete scope | positive_signal | — | the three responsibilities listed | The role is defined enough to prepare for | `[grounded]` JD | Who sets the rating-model roadmap? | noted |
| RR6 | Positive: named hiring manager | positive_signal | — | "Odile Varga, Director of Pricing" | A senior reporting line, close to the work | `[grounded]` your input | — | noted |

**Application plan** (all rows proposed; nothing externally visible until you approve)

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm the posting and employer via the careers page or the recruiter's email domain | RR4 | `[grounded]` RR4 | you to do |
| A2 | Ask in the first screen whether the role has direct reports | R10, RR2 | `[inferred]` | you to do |
| A3 | CV line, honest form: "Built and maintained a GLM rating model for a motor young-driver book; applying the same workflow to a new product line." | R3, R5 | `[grounded]` your CV | pending your approval |
| A4 | Lead the interview with the 14 price tests, each with its underwriting decision and outcome | R6, R4 | `[grounded]` your CV | pending your approval |

Reframing check: avoid "pet pricing experience", "led pricing", or "managed" in any CV line, cover note or interview answer. Each of these is unsupported by your record.

**Evidence status**

Verified: none yet. Every claim above comes from your input or from the JD and is unconfirmed by a source.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches were refused by the host's permission setting, so no page was read. Would have settled whether the posting is live and the employer exists (RR4). |
| 2. Role-family sweep | unavailable | Search refused. Would have set the market calibration for this title and salary. Nothing is given. |
| 3. Hiring manager's public footprint | unavailable | The name was given, but search was refused, so no footprint was checked. Would have set the scope read and the story to lead with. |

**Dossier offer:** If you want this carried into interview prep, I can emit it as a `tuesday-dossier.md`.

**Upgrade menu**

- The posting link or the recruiter's email domain → RR4 closes or stays open.
- Your non-negotiables (minimum pay, contract type, start date) → R11 gets checked.
- Enable web search for this session (you would need to grant the permission) → targets 1 to 3 run, and the employer and salary band get checked. A deeper pass on Brindlemoor (up to 5 more searches and 2 more fetches) can run on your say-so.
- A sanitized query, notebook or model note → R2 and R3 confidence rises to high.
- A sanitized note on how you would adapt a GLM to pet risk factors → G1 closes or strengthens.

**Questions**

1. (R11) What are your non-negotiables for this search: minimum pay, permanent versus fixed-term, and start date? None were in what you gave me, so those checks are open.
2. (R10, RR2) Has the posting or the recruiter said whether this role has direct reports?
3. (RR1, R7) Would this role own rating decisions for the pet product, or recommend them to the Director of Pricing?

Answer in text, paste a link, attach a document, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.