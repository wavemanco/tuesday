## Decision snapshot

**Yes, apply, on conditions. Status: `conditional_go`.** On your account you meet the core of the JD: R1, R2, R3, R4 and R6 read as `direct`, and R5 reads as `adjacent`. The open items are whether the role is really live on Harborlight's own site and what it pays.

**Fit ledger.**

- `must_have` — direct: R1, R2, R3, R4, R6 · adjacent: R5 (define and maintain the metrics layer)
- `important` — adjacent: R7a (partnering on roadmap decisions) · unclear: R7b (partnering with clinicians), R8 (mentoring two junior analysts)
- `preferred` — adjacent: R9 (healthcare data, HIPAA)

R3 — 30+ tests a year, but the basis of the 11% lift is unstated; R5 — credible adjacent work, ownership of metric definitions unstated; R7b and R8 — no clinical or mentoring work stated; R9 — consent and PII work is adjacent, with no HIPAA-covered data held.

**Opportunity ledger.** The posting is concrete about duties and tooling (RR5, positive). Pay is withheld (RR2), the employer and live posting are not yet checked (RR1), and the mentoring scope is unclear (RR3).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the role is live on Harborlight's own careers page (RR1); (2) the pay is in a range you accept (RR2); (3) the mentoring scope and clinician partnership are confirmed in conversation (RR3, R7b, R8).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, a digital-health scale-up, about 400 people, Series C | `[grounded]` your JD text; not checked, see the research line |
| Mandate | Own product analytics for the care-navigation app: metrics layer, A/B tests, self-serve Looker dashboards, partnering with PMs and clinicians | `[grounded]` JD |
| Team shape | Mentor two junior analysts | `[grounded]` JD |
| Scope read | One product area with a dedicated analytics seat and a people element | `[inferred]` from the single-app scope and the mentoring duty |
| Market calibration | Not run. The role-family sweep did not complete, so there is no pay or scope band here | — |
| Unknowns | Pay, location and remote terms, reporting line for the analysts, whether this is the only analytics seat | — |
| Contradictions | None visible from the JD alone | `[grounded]` JD |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | Six years at a consumer-subscription company, your own statement; no artifact yet | `[grounded]` your background | Share a CV or dated role summary |
| R2 | Expert SQL | must_have | direct | medium | none | Daily SQL on Snowflake, stated; "expert" is your own word | `[grounded]` your background | A redacted query sample would raise this to `high` |
| R3 | Experiment design at scale | must_have | direct | medium | none | Ran the program: 30+ tests a year, including the pricing test behind an 11% retention lift. Relative or absolute lift, sample size and your design role are not stated | `[grounded]` your background | Ask for a readout of the pricing test to inspect |
| R4 | Looker or similar BI; self-serve dashboards | must_have | direct | medium | none | Built the company's Looker instance and 40+ governed dashboards, stated | `[grounded]` your background | A dashboard inventory or redacted screenshot would raise this to `high` |
| R5 | Define and maintain the metrics layer | must_have | adjacent | medium | transferability | Governed dashboards and the monthly metrics memo are credible adjacent work. You have not said you owned metric definitions | `[inferred]` from the governed dashboards and the memo | Gap G1 |
| R6 | Strong written communication with non-technical stakeholders | must_have | direct | medium | none | Writes the monthly metrics memo the exec team reads; presents monthly to VP Product, stated | `[grounded]` your background | A redacted memo sample would raise this to `high` |
| R7a | Turning analysis into roadmap decisions with PMs | important | adjacent | medium | transferability | Monthly presentations to the VP Product are the nearest link. PM-level work is not described | `[inferred]` from the VP Product presentations | Gap G1 |
| R7b | Partnering with clinicians | important | unclear | none | discovery | No clinical or care-team work stated | `[grounded]` silence in your background | Question 2 below |
| R8 | Mentoring two junior analysts | important | unclear | none | discovery | No mentoring or management stated | `[grounded]` silence in your background | Question 1 below |
| R9 | Healthcare data experience (HIPAA) | preferred | adjacent | medium | transferability | No healthcare work. The consent-state model and GDPR/CCPA consumer PII handling are credible adjacent work. Limit: no PHI or HIPAA-covered data | `[grounded]` your consent-model work; `[generic]` that HIPAA is a separate regime from GDPR/CCPA | Gap G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Metrics layer ownership and PM partnership (R5, R7a) | transferability | Governed dashboards and the metrics memo; no statement that you owned definitions or worked with PMs directly | R5 is a must-have at `adjacent`; a clear ownership story narrows the main objection | Defining a metric's logic and sign-off; a dashboard your PMs used to decide a launch | A metric definitions doc, a PM-facing dashboard, a roadmap decision you influenced | `[inferred]` from the governed dashboards; `[generic]` that a semantic-layer question is the likeliest probe |
| G2 | Healthcare data (R9) | transferability | Consent-state model and GDPR/CCPA PII handling; no HIPAA or PHI work | R9 is a plus, so it is a differentiator and not a barrier | Consent or purpose limits on sensitive data; access controls on identifiable records | A short description of how the consent model handles sensitive categories | `[grounded]` your consent-model work |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer and live posting not checked | unknown | — | "Harborlight Health (digital-health scale-up, ~400 people, Series C)" | Company size and stage rest on the JD's word; the posting may not be live | `[inferred]` from research not run this session | Can you point me at this role on Harborlight's own careers page, and who would I be interviewing with? | unresolved |
| RR2 | Pay withheld | unknown | — | (no compensation stated in the JD) | The figure may sit below the level's usual range, or the company may not publish pay | `[inferred]` from JD silence; no band available, since the sweep did not run | What is the budgeted base range for this role? | unresolved |
| RR3 | Mentoring scope unclear | unknown | — | "mentor two junior analysts" | The remit may be line management or informal mentoring | `[inferred]` from the JD wording | Do the two analysts report to this role, and how is mentoring measured? | unresolved |
| RR4 | Healthcare learning curve | risk_signal | low | "healthcare data experience (HIPAA) a plus" | You would learn a regulated data regime on the job, with a ramp on clinical data | `[generic]` pattern for healthcare analytics roles, not a claim about this employer | What healthcare data does the analytics team use, and how are access and approvals handled? | unresolved |
| RR5 | Concrete mandate | positive_signal | — | "define and maintain the metrics layer … build self-serve dashboards in Looker" | Scope is defined and measurable | `[grounded]` JD | Who owns metric definitions today, and who signs off a change? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Attach a redacted metrics memo and the pricing-test readout to your application | Would raise R6 and R3 to `high` | `[grounded]` R3, R6 rows | pending your approval |
| E2 | Describe the consent-state model as consumer-PII governance under GDPR/CCPA. Do not describe it as healthcare or HIPAA experience | Keeps R9 at `adjacent` | `[grounded]` R9 row; `[generic]` on the HIPAA distinction | pending your approval |
| E3 | Lead with the experiment program and the Looker build, since those are your strongest direct rows | Matches the direct must-haves | `[grounded]` R3, R4 rows | pending your approval |
| E4 | Put RR1 to the employer before spending effort on the application | The cheapest loss to avoid is effort on an unchecked posting | `[grounded]` RR1 | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches for Harborlight Health's company and careers page were refused; web search was not permitted in this session. Would have confirmed the company exists as described and the posting is live (RR1) |
| 2. Role-family sweep | unavailable | One search for senior product analyst pay and scope was refused. Would have set the market calibration line and the RR2 band |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

## Upgrade menu

- Permission for web search would let the two unavailable targets run: confirming the company and posting (RR1), and setting a pay band (RR2).
- The posted salary or budgeted range closes RR2 and sets it against the band.
- A redacted memo sample or the pricing-test readout raises R6 and R3 to `high`.
- A dashboard inventory raises R4 to `high`.
- The hiring manager's name would sharpen the scope read and the positioning for that reader.

Want this saved as a `tuesday-dossier.md` you can keep and reuse?

**Questions**

1. R8 — Have you mentored or managed junior analysts, and did they report to you?
2. R7b — Have you worked directly with clinicians or care-team staff, even informally?
3. RR1 — Do you have the live posting link, or the recruiter's email domain?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.