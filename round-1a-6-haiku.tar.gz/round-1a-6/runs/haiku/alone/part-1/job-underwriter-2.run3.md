**Not a waste of time, but a stretch on the literal title: R1 (3+ years product management) is `adjacent`, not met. `conditional_go`.**

**Fit ledger.**

- `must_have`: direct R3, R4; adjacent R1 (3+ years product management), R2 (shipped API or platform products); unclear R7 (roadmap ownership)
- `important`: direct R6; adjacent R5 (discovery with partners), R9 (launch coordination with sales and support); unclear R8 (adoption metrics), R10 (agile delivery)

R1 — no PM title, and the integration work is the adjacent case; R2 — shipped integrations, not a product she owned; R5 — client discovery, not platform discovery; R9 — go-live work, no sales or support on record; R7 — input given, ownership unproven; R8 — no metric on record; R10 — process not stated.

**Opportunity ledger.** The role is specific: RR3 (roadmap ownership and adoption metrics stated) is the strongest positive. RR1 (salary absent) and RR2 (the 3+ years line read as a screen) are open. RR4 caps the decision because the employer is unverified.

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:** (1) RR4: the employer verifies from its own careers page; (2) RR2: the 3+ years line proves negotiable, or you apply knowing a literal screen may stop you before a person reads the rest; (3) G1: you can name one product-scope decision you owned, which moves R7 out of `unclear`.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline, B2B logistics-tech, about 150 people, Series B | `[grounded]` JD; not verified (search refused) |
| Mandate | Own the roadmap for the partner-facing API platform, with two engineering squads | `[grounded]` JD |
| Scope read | A full PM remit on one platform, consistent with a PM title | `[inferred]` from the listed duties |
| Market calibration | Platform PM postings of this shape often ask for prior PM years and screen on titles | `[generic]` pattern; no role-family search ran |
| Compensation | Not stated, so not calibrated | — |
| Unknowns | Salary; roadmap decision rights; whether 3+ years is a screen; agile process; sales and support role at launch | — |
| Contradictions | None between the JD items as provided | `[grounded]` JD text |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 3+ years product management | must_have | adjacent | medium | transferability | Seven years of product-facing integration work; no PM title, and no product decisions owned on record | `[grounded]` CV; `[inferred]` that the work carries over | G1 |
| R2 | Shipped API or platform products | must_have | adjacent | medium | transferability | Led 30+ client integrations of REST APIs end to end; she integrated the vendor's product and did not ship one she owned | `[grounded]` CV | W1 |
| R3 | Technical fluency: API docs, schemas | must_have | direct | medium | none | Postman, SQL, OpenAPI on CV; schema discussion unprobed, so expect a live test | `[grounded]` CV | none |
| R4 | Stakeholder management: engineering, sales, customers | must_have | direct | medium | none | Coordinated vendor engineers, client engineers and PMs on custom builds; sales not named | `[grounded]` CV | none |
| R5 | Discovery with integration partners | important | adjacent | medium | transferability | Scoping workshops and requirements with clients, for custom builds rather than a platform roadmap | `[grounded]` CV; `[inferred]` transfer | none |
| R6 | Specs and delivery with two engineering squads | important | direct | medium | presentation | Requirements documents and engineer coordination are on CV, framed as implementation | `[grounded]` CV | E1 |
| R7 | Own the partner API platform roadmap | must_have | unclear | low | discovery | Ran quarterly roadmap-input sessions; ownership and decision rights not on record | `[grounded]` CV; ownership unstated | G1 |
| R8 | Define and track adoption metrics | important | unclear | low | discovery | No metric on CV; an unconfirmed memory lead exists and counts only as a question | `[grounded]` CV silence; memory lead is not evidence | G3 |
| R9 | Launch coordination with sales and support | important | adjacent | medium | transferability | Go-live and UAT with clients; no sales or support coordination on record | `[grounded]` CV | E1 |
| R10 | Agile delivery | important | unclear | none | discovery | CV silent on process, sprints and methodology | `[grounded]` CV silence | G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Roadmap ownership and scope decisions (R7, R1) | discovery | Input sessions on record; no decision she made and owned | R7 is a must-have, and it decides whether the adjacent reading holds | A custom-build scope call a client or engineer could have overruled; a trade-off between a client's need and the vendor's roadmap; a feature request she took to product and what followed | A requirements doc showing the decision and its owner | `[grounded]` CV; `[inferred]` that this moves R7 |
| G2 | Shipped product (R2) | transferability | Integrations shipped for clients; no product she released | The must-have reads literally | Integrations she shaped that changed the vendor's API or docs | A sanitized requirements doc or go-live plan | `[grounded]` CV |
| G3 | Adoption metrics (R8) | discovery | No metric on record; one unconfirmed memory lead | Must be defined for this role | An internal tool or integration with a usage number she tracked | Dashboard, usage report, or a sanitized note | `[grounded]` CV silence |
| G4 | Agile practice (R10) | discovery | Process not stated | Two squads imply a working cadence she is expected to run | Sprint planning or backlog ownership with engineers | Team process doc, or a plain description | `[grounded]` CV silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Salary not stated | unknown | — | (absent from the JD as provided) | The band may sit below her expectations, or the figure may be withheld for policy | `[inferred]` from the withheld figure | What base salary is budgeted for this role? | unresolved |
| RR2 | 3+ years of PM as a listed requirement | risk_signal | medium | "3+ years product management experience (must-have)" | A literal screen on PM years may filter out candidates without a PM title before the rest of the profile is read | `[generic]` pattern for must-have experience thresholds | Is the 3+ years of product management a hard screen, or would platform-product and integration-lead experience be considered? | unresolved |
| RR3 | Roadmap ownership and metrics stated | positive_signal | — | "Own the roadmap for our partner-facing API platform"; "define and track adoption metrics" | The role has defined scope and measurable outcomes | `[grounded]` JD | Which roadmap decisions does this role make alone, and which need engineering leadership sign-off? | noted |
| RR4 | Employer unverified | unknown | — | Quartzline (B2B logistics-tech, ~150 people, Series B) | Existence, stage and posting liveness are unchecked; nothing here says the employer is not real | `[generic]` most small companies are simply small; not a claim about this one | Where is this posted on your careers site, and who would I interview with? | unresolved; caps the decision at `conditional_go` |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Reframe two bullets: "requirements documents" as specs for two engineering squads; "roadmap-input sessions" as discovery outputs. No title or ownership change. Pitch her as an integration lead who has done the product's discovery and spec work from the customer side, not as a product manager | R6, R7, R9 presentation | `[grounded]` CV | pending your approval |
| E2 | Add adoption figures to integration bullets, only where real numbers exist | R8 | `[grounded]` CV silence | pending your approval |
| W1 | A sanitized integration requirements doc or go-live plan as a work sample | R2 limit; R6 | `[grounded]` R2 row | pending your approval |
| A1 | Ask the recruiter whether 3+ years of PM is a hard screen, and what the salary is, before writing a cover letter | RR1, RR2 | `[grounded]` register | pending your approval |
| A2 | Apply only once the posting is verified on the company's own careers site | RR4 | `[grounded]` RR4 | pending your approval |
| S1 | Rehearse the "no PM title" question; that is mock-interview's job, not this skill's | R1 | `[generic]` | your call |

## Evidence status

Verified: none yet.

Unverified lead: a memory note that she built an internal request-triage tool that support agents adopted. It is unconfirmed and is not evidence for R8; it prompts question G3 only.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches ("Quartzline logistics software company Series B"; "Quartzline careers Product Manager Platform APIs") were refused by the host before any result. Would have moved the employer check and RR4 |
| 2. Role-family sweep | unavailable | One search ("product manager API platform salary partner integrations role scope") was refused. Would have moved the market calibration and the compensation band |
| 3. Hiring manager's public footprint | n/a | No name given, so there was no query to form |

## Upgrade menu

- The posting link or the careers-page text → the employer check; RR4 closes and the cap lifts if it verifies.
- Permission to use web search this session → the L1 targets run (up to 5 searches and 2 fetches): the market band and the employer check. The three searches were refused, and I have not retried.
- The budgeted salary → RR1 closes, and the figure is set against the band.
- A deeper pass on Quartzline (funding, leadership changes, hiring patterns; up to 5 more searches and 2 more fetches) → runs only if you say so.
- A sanitized integration requirements doc or go-live plan → R2 and R6 evidence, and the R6 presentation fix can be checked against it.
- The hiring manager's name → positioning for that reader.

If you want it, I can write this assessment to `tuesday-dossier.md`, with the map and register intact.

1. G1 (R7, R1): Have you ever made a product-scope call someone could have overruled? What did you decide, what did you say no to, and who had the final word?
2. G3 (R8): I have an unconfirmed note that you built an internal request-triage tool that support agents adopted. Did you? If so, how did you know it was used, and what number did you track?
3. G4 (R10): How did your engineering squads plan work day to day: sprints, backlog ownership, and who set priority?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.