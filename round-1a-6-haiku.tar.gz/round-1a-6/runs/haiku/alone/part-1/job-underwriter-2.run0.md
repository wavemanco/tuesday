**Decision snapshot: conditional_go.** Apply, but expect the 3+ years of PM experience to be the screen you have to get past. You are not wasting your time. You are a credible candidate for the technical and stakeholder half of this job, and you have no product-management track record for the other half.

- **Hard gates:** none found. The JD names no authorization, location, schedule or pay constraints. [grounded]
- **Fit, by requirement:** 3 strong, 2 partial, 1 unmet, 2 unconfirmed. Details below.
- **Opportunity side:** A Series B logistics-tech company hiring a PM to own a partner-facing API platform is a sound role for someone with your background. The posting has no red flags I can see from the text alone. [inferred]

**Research tier: L0, no searches.** I did not check that Quartzline exists as described, so the company is unverified. That alone caps this at conditional_go.

| Target | Status | Reason |
|---|---|---|
| 1. Company site and careers page | skipped | L0: no search run |
| 2. Role-family sweep (scope, title, pay) | skipped | L0: no search run |
| 3. Hiring manager footprint | n/a | No name given |

## Requirement mapping

| Requirement (JD) | Fit | Evidence (your CV) | Gap type |
|---|---|---|---|
| 3+ years PM experience (must-have) | Unmet | No PM title. Closest is requirements work and roadmap-input sessions, which you did not describe as owning a roadmap. | Capability/transferability |
| Shipped API or platform products | Partial | 30+ end-to-end integrations of the company's REST APIs. You shipped client implementations, not a platform product you owned. | Transferability |
| Technical fluency: API docs, schemas | Strong | Postman, SQL, OpenAPI. Stated, not yet demonstrated. | Presentation |
| Stakeholder management: eng, sales, customers | Strong | Coordinated vendor engineers, client engineers and PMs on custom builds. Sales coordination is not explicit. | Presentation |
| Partner discovery | Strong | Scoping workshops; quarterly client feedback sessions for product. | Transferability |
| Specs and delivery with eng squads | Strong | Requirements documents, integration architecture, UAT. | Presentation |
| Adoption metrics | Unconfirmed | Not mentioned. | Discovery gap |
| Launch coordination with sales and support | Partial | Go-live coordination is clear. Support handoff is not. | Presentation |
| Agile delivery | Unconfirmed | Not mentioned. | Discovery gap |

Derived from the table [inferred]: the 3+ years PM line is the only must-have you do not meet. Because the skill treats experience length as a requirement, not a hard gate, a strong case elsewhere can offset it in some hiring decisions, but not reliably.

## Gap recovery queue
- **G1, PM experience (3+ years):** Closed only by evidence that you owned decisions you can name: backlog, prioritization, a launch you decided on. Without it, the gap stays open.
- **G2, adoption metrics:** Closed by one example of a metric you tracked for integrations, such as time to first successful call or partner activation.
- **G3, agile:** Closed by naming the delivery cadence you worked in.

## Risk register
- **Must-have mismatch (medium):** The JD lists 3+ years PM as must-have. Expect a resume screen against it. [grounded]
- **Unverified employer (medium, standing):** Existence and posting status are not checked. Resolve with the live posting link or the company's careers page.
- **Unconfirmed triage tool (low, not evidence):** Your prior-memory note says you built a request-triage tool that support adopted. I have not confirmed it, so it stays out of your materials until you confirm it.

## Application plan
1. **Apply, and lead with the integration story.** Frame it as product work done from the customer side: discovery, requirements, and feedback you turned into roadmap input. Do not use the word "product manager" in a title or summary. [inferred]
2. **Prepare one work sample.** A sanitized requirements document or integration playbook section you wrote is the strongest proof of the spec and discovery requirements.
3. **Proposed resume edit, pending your approval:** rewrite the roadmap-input bullet to say what you collected, how you prioritized it, and what changed as a result. Only if that is accurate. Nothing changes until you approve it.
4. **Target the bridge roles too.** Titles like technical PM, platform PM or solutions-to-product transitions match your profile better than a generic PM search. Whether the market accepts this seniority gap is not verified here. [generic]

**Dossier offer:** If you want, I can save this assessment as a dossier so the next session starts from it.

**Upgrade menu:**
- The live job posting or Quartzline's careers page, so I can confirm the employer is real and the role is open (unlocks the unverified-employer check).
- One work sample: a sanitized spec or playbook section (raises the discovery and spec rows).
- Permission to run L1 research: company check plus a role-family sweep for PM title and pay norms.

**Questions:**
1. Have you ever owned a backlog, a prioritization call or a launch decision, even informally? (Closes G1.) Response: answer, or skip.
2. Did you ever track an adoption metric for an integration or API? (Closes G2.) Response: answer, or skip.
3. Can you confirm the request-triage tool: what you built, whether support adopted it, and whether you can show it? Response: answer, or skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.