## Decision snapshot

**Verdict: `no_go` on the posting's own terms.** Your fit is strong. The opportunity fails both of your hard constraints.

| Ledger | Result |
|---|---|
| Candidate fit | Strong on paid, lifecycle, experimentation, team leadership, and seniority. Gaps on SEO/content, PR, partnerships, and sales ops. Transferability is partial on e-commerce enablement (you come from B2C subscription). |
| Opportunity quality | Fails two hard gates. Compensation and on-site location are both stated in the posting. |
| Hard gates | **Fail:** on-site Austin 5 days/week, "no exceptions" vs. remote-only. **Fail:** $70–85k base vs. your $150k floor, a gap of at least $65k even at the top of the range `[grounded]`. |

What would change it: a remote arrangement and a base of $150k or more. The posting says neither is possible, so a conversation would have to start from the employer changing those terms.

## Role reality

- **Scope:** Head of Growth owning all revenue channels, starting as a team of one. The posting asks for 8+ years of leadership, then describes an individual-contributor-sized start. `[grounded]`
- **Contradictions:** "Don't need a bench" alongside "8+ years growth leadership required." Also "evenings and weekends when it matters is just who we are." These describe an overloaded role. I'm not calling it a scam or a bad company; I can't tell from the posting alone.
- **Compensation calibration:** $70–85k base for a Head of Growth role with this scope and seniority looks low. `[generic]`, from general pattern, not verified here.
- **Market calibration:** Research didn't run, so I have no sourced role-family comparison.

## Evidence map (summary)

| # | Requirement | Priority | Fit | Confidence | Gap |
|---|---|---|---|---|---|
| 1 | 8+ years growth leadership | must-have | strong | high (9 yrs, 2 Head-level roles) | none |
| 2 | Own paid acquisition | must-have | strong | high | none |
| 3 | Own lifecycle/CRM | must-have | strong | high (Braze) | none |
| 4 | Experimentation and analytics | preferred | strong | high (SQL, GA4) | none |
| 5 | SEO/content | must-have | partial | low | not evidenced in the CV |
| 6 | Brand and PR | must-have | unknown | low | not evidenced |
| 7 | Partnerships | must-have | unknown | low | not evidenced |
| 8 | Sales ops | must-have | unknown | low | not evidenced |
| 9 | E-commerce enablement context | preferred | partial | medium | transferability from B2C subscription |
| 10 | Team of one to start | implied | fits | high | you have managed teams of 3–7, so this is a step down in team size |
| **H1** | **On-site Austin, 5 days/week** | hard gate | **fail** | high | remote-only is a non-negotiable |
| **H2** | **Base $70–85k** | hard gate | **fail** | high | your floor is $150k |

## Opportunity risk register

1. **Hard gate: location** — `severity: high`, `confirmed`. Austin 5 days/week, "no exceptions." Remote-only is non-negotiable.
2. **Hard gate: compensation** — `severity: high`, `confirmed`. Stated base is well below your $150k floor. Equity is unquantified.
3. **Scope vs. seniority** — `severity: medium`. 8+ years required for a team-of-one start.
4. **Work pattern** — `severity: medium`. Evenings and weekends are framed as culture, not exception.
5. **Failed attribution (standing entry)** — `severity: medium`. I haven't confirmed Novaline exists as described (stage, Series A, profitability). Reasons: too new or small, a stale posting, or not a real hiring employer. Not ranked as likely. This caps any `go` at `conditional_go` until verified.

## Evidence status

Research tier: L0 — no searches

| Target | Status | Reason |
|---|---|---|
| 1. Company official site and careers page | skipped | Both hard gates are stated in the posting, so the verdict doesn't depend on the company's website. It would only verify existence (item 5 above). |
| 2. Role-family sweep | skipped | Would refine the market calibration only. Doesn't change the verdict. |
| 3. Hiring manager footprint | n/a | No name was given. |

Available on request. The `[generic]` labels above are pattern-based, not sourced.

## Application plan

Not applicable. The verdict is `no_go`, so there's no application plan. If the employer changed both terms, I'd revisit the plan. The strongest lead would be paid, lifecycle, and experimentation, with the $8M→$40M ARR scale-up as the proof point.

## Dossier offer

If you want, I can save this assessment as `tuesday-dossier.md` for future reference.

## Upgrade menu

- **Live posting link or Novaline's careers page**: verifies that the employer exists as described (closes the standing attribution entry).
- **Recruiter's email domain, if this came through a recruiter**: verifies the sender.
- **Research at L1 (up to 5 searches, 2 fetches)**: checks the company's site and a role-family comp band. Doesn't change the verdict; it would sharpen the `[generic]` labels.

## Questions

1. Did this posting come directly from Novaline, or through a recruiter? If through a recruiter, which firm and what email domain?
2. Have you seen any remote option for this role anywhere else (a careers page, recruiter note, or a second posting)?

Reply with answers, or "skip" to pass on either.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.