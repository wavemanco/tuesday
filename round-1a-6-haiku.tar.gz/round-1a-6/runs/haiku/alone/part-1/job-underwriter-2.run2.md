**Not a waste of time, but this is a stretch rather than a straight apply: `conditional_go`.** The must-have you don't meet is the titled 3+ years (R1a). Your integration work is a real bridge to the rest of the JD (R1b, R2, R5, R8), so it's worth one application if the years screen and the employer both check out.

## Decision snapshot

**Not a waste of time, but not a straight apply: `conditional_go`.**

**Fit ledger.**

- `must_have`: absent: R1a (3+ years titled PM); adjacent: R1b (roadmap input, specs)
- `important`: direct: R3 (API docs and schemas), R4 (stakeholders); adjacent: R2 (shipped API products), R5 (launch coordination), R6 (specs and delivery), R8 (partner discovery); unclear: R7 (agile delivery), R9 (adoption metrics)

R1a — titled years, absent; R1b — roadmap and spec work, adjacent `medium`; R3 — technical fluency, `direct` `medium`; R7 and R9 — agile and adoption metrics, unclear, the open questions below.

**Opportunity ledger.** The posting is clear on scope and resourcing (RR1 positive: two named squads and a defined partner-facing remit). Pay and location are not in it (RR2), the employer is not verified because the search that would check it was refused (RR3), and the years requirement may be screened literally (RR4).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) Quartzline verifies as a real hiring employer (RR3); (2) the recruiter or interviewer accepts adjacent product work against the 3+ years (R1b, RR4); (3) you can name a product decision you owned, if one exists (R1a, Q1).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline, B2B logistics-tech, ~150 people, Series B | `[grounded]` JD; existence not checked (search refused) |
| Mandate | Own the roadmap for the partner-facing API platform; discovery with partners; specs and delivery with two squads; adoption metrics; launch coordination | `[grounded]` JD |
| Scope read | Broad for one seat, but resourced: two squads and a metrics remit | `[inferred]` from the JD's listed scope against its two-squad line |
| Market calibration | Not run: the role-family sweep was refused. Pattern only: owner-of-roadmap seats often screen on titled years | `[generic]` role-family pattern, no search |
| Unknowns | Pay, location, reporting line, whether this is the first PM hire, whether adoption metrics exist today | — |
| Contradictions | None found within the posting | `[grounded]` JD |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1a | 3+ years product management (titled) | must_have | absent | none | transferability | No PM title on any role. Adjacent work is scored in R1b | `[grounded]` CV: no PM title | Q1 |
| R1b | Product-management work: roadmap input, specs, deciding what gets built | must_have | adjacent | medium | transferability | Quarterly roadmap-input sessions and requirements documents are real. The CV shows feeding a roadmap, not choosing what a product builds | `[grounded]` CV bullets | Q1 |
| R2 | Shipped API or platform products | important | adjacent | medium | transferability | 30+ REST integrations delivered end to end, built on a vendor's API. No evidence of releasing or versioning a product | `[grounded]` CV | see G1 |
| R3 | Technical fluency: API docs and schemas | important | direct | medium | none | Postman, SQL, OpenAPI named; integration architecture written. Tool list only, no artifact | `[grounded]` CV | none |
| R4 | Stakeholders across engineering, sales, customers | important | direct | medium | none | Coordinated vendor engineers, client engineers and PMs. Sales not named | `[grounded]` CV | none |
| R5 | Coordinate launches with sales and support | important | adjacent | medium | transferability | Owned go-live and UAT for 30+ integrations. No sales or support coordination shown | `[grounded]` CV | see G4 |
| R6 | Specs and delivery with two engineering squads | important | adjacent | medium | transferability | Requirements documents across client builds. Not product specs for a squad | `[grounded]` CV | see G1 |
| R7 | Agile delivery experience | important | unclear | low | discovery | CV silent on sprints, backlogs, delivery method | `[grounded]` CV silence | Q3 |
| R8 | Discovery with integration partners | important | adjacent | medium | transferability | Scoping workshops and client feedback sessions. Discovery for implementations, not a platform roadmap | `[grounded]` CV | none |
| R9 | Define and track adoption metrics | important | unclear | low | discovery | CV silent. An unconfirmed memory lead may bear on it | `[grounded]` CV silence; `memory_lead` unconfirmed | Q2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Titled years and owned product decisions (R1a, R1b, R2, R6) | transferability | Strong feeding-the-roadmap and spec work; no record of choosing what got built or released | The must-have most likely to screen you out, and the JD's central ask | A feature or integration pattern you chose to build or drop, and why; a backlog you ordered | A roadmap doc, a spec you wrote, a decision memo | `[grounded]` CV; `[inferred]` that this is the decisive gap |
| G2 | Adoption metrics (R9) | discovery | No metrics on the CV | The JD makes this part of the job | Any usage or go-live metric you tracked after a launch | A dashboard, a rollout report | `[grounded]` CV silence |
| G3 | Agile delivery (R7) | discovery | CV silent on method | Named as a requirement | Sprint planning, backlog grooming, roadmap tools | A sprint review or backlog export | `[grounded]` CV silence |
| G4 | Sales and support in launches (R5) | transferability | Go-live coordination shown; the sales and support side is not | Named in the JD's launch line | Launch briefings for account teams; support handover | A launch checklist | `[grounded]` CV |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Ownership resourced | positive_signal | — | "Own the roadmap ... write specs and drive delivery with two engineering squads" | The role has delivery capacity behind it | `[inferred]` from the JD's scope against its two-squad line | Who sets sequencing across the two squads, and what can this role decide without sign-off? | noted |
| RR2 | Pay and location not stated | unknown | — | Posting names no pay or location | Pay may be withheld; location may be remote or hybrid | `[grounded]` the posting's silence | What is the base range, and where is the role based? | unresolved |
| RR3 | Employer not verified | risk_signal | medium | "Quartzline (B2B logistics-tech, ~150 people, Series B)" | The employer is too new or small for a footprint, the posting is stale, or it is not a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on Quartzline's own careers page, and who would I interview with? | unresolved |
| RR4 | Years screen may be literal | risk_signal | low | "3+ years product management experience (must-have)" | Adjacent work may not count against a titled-years requirement | `[generic]` role-family pattern: literal screens check titles first | Would adjacent product work count against the 3+ years, and what evidence would you accept? | unresolved |

**Severe red flags:** none found.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Find the posting on Quartzline's own careers page before tailoring anything | RR3 | `[grounded]` RR3 | proposed |
| P2 | Move the roadmap-input bullet up and name the product it fed, if you can name it. No new claim | R1b, presentation gap | `[grounded]` CV | pending your approval |
| P3 | If Q1 turns up a real product decision, write it as a story with your part named | R1a | `[grounded]` once you answer | pending your approval |
| P4 | Ask the recruiter whether adjacent product work counts against the 3+ years | RR4 | `[generic]` pattern | proposed |
| P5 | Also target integration, partner-platform or technical PM roles, where an implementation background is a common entry | R1a is less likely to gate there | `[generic]` role-family pattern, not searched | proposed |
| P6 | Internally, ask to own one discovery-to-spec cycle and keep a record of the decisions you made | Builds the owned-decision evidence R1a lacks | `[generic]` career pattern | proposed |

Nothing here is final until you approve it. Every line above is a proposal.

## Evidence status

Verified: none yet. Unverified lead: the request-triage tool from an earlier conversation (`memory_lead`, unconfirmed). It prompts Q2 and nothing more. Rejected inferences: none.

Research tier: L1 — searches 2 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Quartzline logistics technology Series B"; refused. Would have settled RR3 and the live posting |
| 2. Role-family sweep | unavailable | Searched API product-manager hiring and salary; refused. Would have set the market calibration and the pay band for RR2 |
| 3. Hiring manager's public footprint | n/a | No name given |

## Upgrade menu

- A confirmed account of the request-triage tool (what it did, your part, any adoption figure) → R9 moves from `low`, and R1b gains a concrete product example.
- One redacted spec or requirements document you wrote → R6 moves toward `direct`.
- A launch checklist with sales or support steps → R5 moves to `direct`.
- The live posting link and Quartzline's careers page → RR3 closes or stays open.
- The pay band and location from the recruiter → RR2 closes.
- A search pass once search is allowed (employer check, role-family sweep) → RR2, RR3 and the market calibration.

If you want it, I can save this as `tuesday-dossier.md`, with the verification questions included, so you can carry it into the application.

**Questions**

- **R1a:** Have you ever owned a product decision, meaning you chose what got built or dropped, not how an integration was configured? If so, what did you decide, who pushed back, and what happened?
- **R9:** Earlier notes, unconfirmed, mention an internal request-triage tool that support agents adopted. Did you build one? If so, what did it do, which part was yours, and how did you know agents used it?
- **R7:** How was delivery run on your teams: sprints, a backlog, a roadmap tool? Did you run sprint planning or backlog grooming, or did engineering run it?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.