**Probably worth applying.** Status: `hold_pending_answers`. Two facts only you can supply (your location and your pay floor) could still change that, and the one real skills gap is BigQuery.

**Fit ledger**

- `hard_gate`: unclear: R1 (remote-US or Denver location), R2 (salary against your floor)
- `must_have`: direct: R3 (5+ years data engineering), R4 (SQL and Python), R5 (dbt and a cloud warehouse), R6 (Airflow orchestration), R7 (data-quality testing)
- `important`: adjacent: R8 (BigQuery); unclear: R9 (data contracts analysts depend on), R10 (ingestion from app and CRM)

R3–R7 read `direct` on your CV. R8 is adjacent: Snowflake carries over, BigQuery specifics don't. R9 and R10 have no claim in your background yet.

**Opportunity ledger.** Sound on the posting's own terms. The posted pay sits near the market median (RR5), and the scope is concrete. Open items are equity terms (RR1), no named hiring manager (RR2) and the Series C figure, which is self-reported (RR3). Scope may be wider than typical for the title (RR4, low).

- **Hard gates:** none failed; unconfirmed: R1 (remote-US or Denver location), R2 (salary floor against $148,000–$166,000); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **What would change this:**
  - R1: if you're not US-based and wouldn't take Denver, it fails and the status is `no_go`.
  - R2: if your floor is above $166,000, it fails and the status is `no_go`. Inside the range, pay is no longer a question.
  - R9/R10: if you've owned ingestion or data contracts, the status moves toward `go`. If not, it's `conditional_go` with BigQuery and contracts named as conditions.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning, live online tutoring for K-12 schools in 31 states; Denver; 264 employees | `[grounded]` about page; careers page fetched |
| Mandate | Build and run ingestion (app, CRM), a dbt warehouse in BigQuery, and data contracts | `[grounded]` JD, identical on careers page |
| Working pattern | Remote (US) or Denver office | `[grounded]` JD |
| Scope read | Pipeline build-and-run plus contracts across three sources; wider than one domain | `[inferred]` from the listed responsibilities; compare RR4 |
| Market calibration | Title fits: "Senior" usually means 5–8 years, and you have 6. Posted $148,000–$166,000 has a $157,000 midpoint, above the $151,000 median and inside the $139,000–$163,500 IQR | `[generic]` Datawright 2026, US, n=2,310, Series B–D; `[grounded]` posted figure |
| Unknowns | Equity terms, hiring manager and team, whether contracts are owned here, your location and floor | — |
| Contradictions | None between JD and careers page | `[grounded]` careers page fetched |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver location | hard_gate | unclear | none | hard_gate | Your location isn't in what you've given me, so the gate is not established | `[grounded]` JD; your location not stated | Q1 |
| R2 | Salary $148,000–$166,000 against your floor | hard_gate | unclear | none | hard_gate | No floor given | `[grounded]` JD | Q2 |
| R3 | 5+ years data engineering | must_have | direct | medium | none | Six years at one payroll company; CV-stated, unprobed | `[grounded]` your background | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | Daily use, CV-stated | `[grounded]` your background | none |
| R5 | dbt and a cloud warehouse | must_have | direct | medium | none | dbt on Snowflake, about 180 models | `[grounded]` your background | none |
| R6 | Airflow or similar orchestration | must_have | direct | medium | none | Airflow stated | `[grounded]` your background | none |
| R7 | Data-quality testing | must_have | direct | medium | none | Great Expectations suite set up | `[grounded]` your background | none |
| R8 | BigQuery (the JD's warehouse) | important | adjacent | medium | transferability | Snowflake dbt work transfers; BigQuery not used. Limit: BigQuery-specific cost and partitioning untested | `[grounded]` "never used BigQuery"; `[inferred]` adjacency | G1 |
| R9 | Data contracts analysts depend on | important | unclear | none | discovery | No claim in your background yet | `[grounded]` JD silent on your history | Q3 |
| R10 | Ingestion from app and CRM | important | unclear | none | discovery | No claim in your background yet | `[grounded]` JD silent on your history | Q3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R8, important) | transferability | Snowflake dbt at scale; no BigQuery | A stated limit, not a blocker. A sharp interviewer will probe cost and partitioning | Any BigQuery query, load or dbt run, even on a sandbox project | A BigQuery dbt snippet or cost note | `[grounded]` CV; `[inferred]` that interviews probe this |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Equity terms unstated | unknown | — | "plus equity" | Equity may be worth little or unclear | `[inferred]` from silence on grant terms | What is the grant size, vesting schedule and strike price? | unresolved |
| RR2 | No hiring manager or team named | unknown | — | (posting names none) | The owner of these pipelines is unclear | `[grounded]` posting silence | Who would I report to, and which team owns the ingestion pipelines? | unresolved |
| RR3 | Series C figure self-reported | unknown | — | "Series C ($52M, February 2026)" | Funding may be accurate but is so far only on the company's own site | `[grounded]` search found no independent source | Who led the round, and where was it announced? | unresolved |
| RR4 | Scope may exceed one domain | risk_signal | low | "Build and run the pipelines … the data contracts our analysts depend on" | Ownership may span ingestion, warehouse and contracts, wider than typical | `[generic]` Datawright typical scope; `[inferred]` from the JD's list | Which pipelines and contracts does this role own end to end, and who else touches them? | unresolved |
| RR5 | Pay is posted and sits near the median | positive_signal | — | "Salary $148,000–$166,000" | Pay transparency and a realistic band | `[grounded]` JD; `[generic]` band | — | noted |

There are no severe red flags, and no request in the material asks you to pay, deposit or give bank or ID details. The standing failed-attribution entry does not apply: the careers page and the about page are on the company's own domain and agree.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Lead with the Airflow and Great Expectations work, then name BigQuery as the one tool you haven't used | Puts the gap in your words | `[grounded]` R5–R8 | pending your approval |
| P2 | Ask the recruiter for the hiring manager, team and equity terms before investing in the loop | RR1, RR2 | `[grounded]` register | pending your approval |
| P3 | Prepare one ingestion or data-contract story, if you have one | R9, R10 | `[grounded]` gap queue | pending your approval |

Nothing above is externally visible until you approve it.

## Evidence status

Verified: none yet. Everything from your background is CV-equivalent and unprobed.

Research tier: L1 — searches 3 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Pellucid Learning live online tutoring K-12 Denver" (no results) and "Pellucid Learning Series C funding 2026" (only the about page); fetched pellucidlearning.com/careers/senior-data-engineer, which matches the JD. Role reality: contradictions row, and the standing attribution entry (not triggered). The Series C figure rests only on pellucidlearning.com/about |
| 2. Role-family sweep | yes | Searched "Senior Data Engineer salary Series B-D US 2026 base pay median", which returned the Datawright 2026 Data Engineering Pay Report (datawright.example). Snippet only, not fetched. Market calibration `[generic]` |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

## Upgrade menu

- Your location and pay floor → R1 and R2 close, and the status can move to `go` or `no_go`.
- A sanitized BigQuery snippet, or a data-contracts doc → R8 and R9 rise.
- The recruiter's answer on the hiring manager and equity → RR1 and RR2 close.
- A deeper research pass on Pellucid (funding leads, hiring patterns, recent news; up to 5 more searches and 2 more fetches) — say the word and it runs.

If you want, I can write this up as `tuesday-dossier.md` for later interview prep.

1. R1: Are you based in the US, and would you take remote-US only, or do you need Denver?
2. R2: Is $148,000 the bottom of what you'd take?
3. R9/R10: Have you owned ingestion from a product app or CRM, or defined data contracts that analysts relied on? If so, what did the contract cover and who consumed it?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.