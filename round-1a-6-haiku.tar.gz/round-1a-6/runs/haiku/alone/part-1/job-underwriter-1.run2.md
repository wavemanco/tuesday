**Worth applying to, on conditions. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: none stated in the posting; your constraints were not given, so checks against location, work authorization and pay are unknown.
- `must_have`: direct on R1, R2, R3, R4, R5.
- `important`: adjacent on R6, R7; unclear on R8.
- `preferred`: adjacent on R9.

The core analytics requirements are direct. The gaps are the clinician-facing work, mentoring, and the healthcare-specific requirement.

**Opportunity ledger.** The posting is specific about scope, but the employer could not be verified and the posting omits location, pay and working pattern.

- **Hard gates:** none stated in the posting; constraints not given, so checks against them are unknown.
- **Severe red flags:** none found in the posting text.
- **Conditions for go:** (1) verify the employer and the live posting (RR1); (2) confirm location and pay against what you need (RR2, RR3); (3) confirm the clinician-partnership and data-handling expectations (RR4).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, digital-health scale-up, ~400 people, Series C | `[grounded]` JD as provided; not verified (research unavailable) |
| Mandate | Own product analytics for the care-navigation app: metrics layer, A/B tests, self-serve Looker dashboards, PM and clinician partnership, mentoring two junior analysts | `[grounded]` JD |
| Scope read | Senior individual-contributor analytics owner with a mentoring duty; the remit reads as ordinary for the title | `[inferred]` from the responsibility list |
| Stage | Assumed evaluating; not stated | Assumption |
| Market calibration | Not established. The salary and role-family search was refused, so there is no band | — |
| Unknowns | Base pay, location, work pattern, contract type, reporting line, whether the metrics layer already exists, clinician involvement | — |
| Contradictions | None found within the JD text | `[grounded]` JD |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | Six years at one consumer-subscription company, stated in the CV; employment dates would verify it | `[grounded]` CV | none |
| R2 | Expert SQL | must_have | direct | medium | none | Daily SQL on Snowflake for six years. "Expert" is a judgment the CV doesn't demonstrate | `[grounded]` CV | SQL work sample would raise to high |
| R3 | Experiment design and analysis at scale | must_have | direct | medium | none | 30+ A/B tests a year, including a pricing test behind an 11% retention lift. No methodology or guardrail detail stated, so expect probes | `[grounded]` CV | sanitized test-design doc would raise |
| R4 | Looker or similar BI; self-serve dashboards | must_have | direct | medium | none | Built the company's Looker instance from scratch; 40+ governed dashboards. Self-serve adoption is not stated | `[grounded]` CV | adoption figures would raise |
| R5 | Strong written communication to non-technical stakeholders | must_have | direct | medium | none | Writes the monthly exec metrics memo and presents it to the VP Product monthly | `[grounded]` CV | redacted memo would raise |
| R6 | Define and maintain the metrics layer | important | adjacent | medium | discovery | Governed dashboards and the exec memo imply metric definitions, but the CV never says you owned canonical definitions | `[inferred]` from dashboards and memo | question on R6 |
| R7 | Partner with PMs and clinicians to turn analysis into roadmap decisions | important | adjacent | medium | transferability | PM and VP Product partnership is stated. No clinician work appears | `[grounded]` CV for PM; clinicians absent | gap G1 |
| R8 | Mentor two junior analysts | important | unclear | low | discovery | The CV is silent on mentoring | `[grounded]` CV silence | question on R8 |
| R9 | Healthcare data experience (HIPAA) | preferred | adjacent | medium | capability | No healthcare work. Adjacent: GDPR/CCPA consumer PII handling and a consent-state model for the warehouse. These are not HIPAA, and no HIPAA knowledge is claimed | `[grounded]` CV; `[generic]` that HIPAA is a distinct regime | gap G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Clinician partnership (R7) | transferability | PM partnership is on the CV; no clinician-facing work | Clinicians are named in the core duties | Any work with clinical, care-team or support-ops stakeholders on product decisions | A sanitized example of a recommendation that changed a non-PM team's decision | `[grounded]` CV; `[inferred]` that this is the likeliest objection |
| G2 | Healthcare data and HIPAA (R9) | capability | No healthcare data work; consumer PII and consent modeling only | Preferred, so a minor risk, but the regulated context changes how tests and queries are handled | Consent-state design and PII handling, which transfer in part | Any written data-access or consent policy you worked under | `[grounded]` CV; `[generic]` that HIPAA is a separate regime |
| G3 | Metrics-layer ownership (R6) | discovery | Governed dashboards and memo imply definitions | Core responsibility of the role | Canonical metric definitions, metric review, a semantic layer | A redacted metric dictionary entry | `[inferred]` from dashboards and memo |
| G4 | Mentoring (R8) | discovery | Nothing on the CV | Stated duty for a senior hire | Onboarding or reviewing others' analysis, even informally | Any example of coaching analysts | `[grounded]` CV silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer and posting not verified | unknown | medium | "Harborlight Health (digital-health scale-up, ~400 people, Series C)" | Could not confirm the entity as described. Reasons, none ranked: too new or small to be well documented; a stale posting; the listing not tied to a hiring entity. Standing entry; caps a go at conditional_go until verified | `[grounded]` research refused; `[generic]` that these are the usual shapes of unconfirmed listings | Can you share the live posting link, the company's careers page, or the recruiter's email domain? | unresolved |
| RR2 | Location, work pattern and contract type not stated | unknown | — | (JD silent) | Remote, hybrid or on-site is unknown, so hard-gate checks against your constraints cannot run | `[grounded]` JD silence | Question on RR2 | unresolved |
| RR3 | Base pay not stated | unknown | — | (JD silent) | Pay cannot be compared with your floor, and the market band could not be established | `[grounded]` JD silence | Question on RR2 | unresolved |
| RR4 | Clinical context may slow experimentation | risk_signal | low | "partner with product managers and clinicians" | A patient-facing product may need clinical review and stricter data handling before tests ship, which changes the experiment playbook | `[inferred]` from the clinician partnership and the HIPAA mention | How are product changes reviewed for clinical risk, and what data can analysts query? | unresolved |
| RR5 | Scope is specific | positive_signal | — | "Own product analytics for our care-navigation app" | Responsibilities are explicit, so expectations are legible | `[grounded]` JD | — | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Verify the live posting and the recruiter's email domain before applying | RR1 | `[grounded]` register | pending your approval |
| E2 | Use the CV sentence as is: "Ran 30+ A/B tests a year, including the pricing test behind an 11% retention lift" | R3 | `[grounded]` CV sentence; no added scope | resume_edits_pending_approval |
| E3 | Use the CV sentence as is: "Built the company's Looker instance from scratch; 40+ governed dashboards" | R4 | `[grounded]` CV sentence | resume_edits_pending_approval |
| E4 | Frame the healthcare gap as consumer PII under GDPR/CCPA plus the consent-state model, not as health-data experience | R9 | `[grounded]` CV; reframing audit: no HIPAA claim | pending your approval |
| E5 | Lead with experimentation and the exec memo, the two strongest must-have matches | R3, R5 | `[inferred]` | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Search was refused by the host, so employer existence, posting liveness and stage remain not established. Would have moved the organization row and RR1 |
| 2. Role-family sweep | unavailable | Search was refused. No market band; would have set market calibration and the RR3 check |
| 3. Hiring manager's public footprint | n/a | No hiring manager was named |

## Upgrade menu

- Web search permission granted: I can run the employer check and the role-family sweep, which would move RR1, RR3 and market calibration.
- Live posting link or company careers page: resolves RR1 and lifts the conditional_go cap.
- Location, work pattern and base-pay floor: lets the hard-gate checks run and closes RR2 and RR3.
- A SQL work sample or sanitized query: raises R2 to high.
- A sanitized design doc for one A/B test: raises R3 to high.
- A redacted exec memo: raises R5 to high.
- Adoption figures for the Looker dashboards: raises R4 to high.
- Any past work with clinical or care-team stakeholders: changes R7 from adjacent.
- Deeper research on Harborlight (funding, leadership changes, public reviews, up to 5 more searches and 2 more fetches): say the word and it runs.

If you want, I can save this assessment as `tuesday-dossier.md` so it carries into later sessions.

**Questions**

1. (RR2, RR3) What location and base-pay floor must this role clear, and can you work on-site, hybrid or remote?
2. (R8) Have you mentored or coached junior analysts, and how?
3. (R6) Did you own the canonical metric definitions in the warehouse or Looker, or did another team?

Answer in text, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.