**Recommendation: apply, on conditions. Status: `conditional_go`.** Your method fit is strong. The gaps are pet-insurance domain knowledge, product-facing recommendations, and whether the role carries people management. Research was refused, so the company is unverified.

## Decision snapshot

**Worth applying to, on conditions. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — unclear: H1 (remote UK; your location and right to work were not given)
- `must_have` — direct: R1, R2, R3, R4
- `important` — direct: R5 · adjacent: R6 (pet-insurance pricing) · unclear: R8 (recommendations for product)
- `preferred` — direct: R7

**Opportunity ledger.** The JD contains no red flags. Its unknowns are people management (RR2), the salary (RR4), and whether Brindlemoor exists as described (RR3, unverified because search was refused). Its explicit first-year scope is a positive signal (RR5).

- **Hard gates:** none failed; unconfirmed: H1 (remote UK). Candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) Brindlemoor and the live posting verified (RR3); (2) people management clarified (RR2); (3) your location, right to work and salary floor checked against the role (H1, RR4).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech. Existence not confirmed; research unavailable | `[grounded]` JD header; existence unverified |
| Mandate | Own pricing analytics for the pet-insurance product; build and monitor rating models; design and read price tests; turn results into recommendations for underwriting and product | `[grounded]` JD |
| First-year outcomes | Not stated in the JD you pasted | — |
| Working pattern | Fully remote, UK | `[grounded]` JD |
| Hiring manager | Odile Varga, Director of Pricing. Public footprint unresolved | `[grounded]` your message |
| Scope read | A senior analytics role owning one product's pricing. Line management is not stated | `[inferred]` from the responsibilities list |
| Market calibration | Unavailable. The role-family search was refused, so there is no band | — |
| Unknowns | People management; who sets rate changes (pricing or underwriting); salary; contract type; start date | — |
| Contradictions | None checkable. No live posting was read | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Pricing or actuarial analytics, 4+ years | must_have | direct | medium | none | Five years in pricing analytics, two as senior analyst. Self-reported, so a lead to verify | `[grounded]` your statement | none |
| R2 | Strong SQL and Python | must_have | direct | medium | none | Daily use. Self-reported | `[grounded]` your statement | none |
| R3 | GLM experience | must_have | direct | medium | none | You built and maintained a GLM rating model for the young-driver book. The method is the same across lines; the book is motor | `[grounded]` your statement | none |
| R4 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | Quarterly pricing review to the head of underwriting | `[grounded]` your statement | none |
| R5 | Design and read price tests | important | direct | medium | none | Fourteen tests last year with the underwriting team | `[grounded]` your statement | none |
| R6 | Pet-insurance pricing, the product's domain | important | adjacent | medium | transferability | Pricing discipline transfers from motor. You have never worked on pet insurance, and nothing in your background shows pet-specific knowledge | `[inferred]` from the domain gap | see G1 |
| R7 | Insurance experience | preferred | direct | medium | none | Motor insurer | `[grounded]` your statement | none |
| R8 | Turn results into recommendations for product, not only underwriting | important | unclear | low | discovery | Your recommendations have gone to underwriting. Nothing shows product | `[grounded]` CV silence on product | see G2 |
| H1 | Fully remote, UK (a hard constraint) | hard_gate | unclear | none | hard_gate | The JD says remote UK. Your location and right to work were not given | `[grounded]` JD; your constraints not given | answer Q2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pet-insurance domain (R6) | transferability | Motor pricing only | The role owns a pet product. Hiring managers usually ask about domain ramp-up | Any work on a non-motor line, or on claims or lapse drivers that transfers to pet | A pet-relevant model or analysis you can describe | `[inferred]` from the JD and CV |
| G2 | Product-facing recommendations (R8) | discovery | Recommendations have gone to underwriting | The JD names product as an audience | Any product or proposition decision you influenced, even indirectly | A product-facing review or test readout | `[grounded]` CV silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Domain gap: pet insurance | risk_signal | medium | "Own pricing analytics for our pet-insurance product" | You would need a ramp-up period on pet-specific risk drivers | `[inferred]` from R6 | How long is the expected ramp-up on pet-specific drivers? | unresolved |
| RR2 | People management not stated | unknown | — | "Own pricing analytics" (no reporting line given) | The role may carry direct reports, which you have never had | `[inferred]` from the silence on management, against your history | Does this role line-manage anyone? | unresolved |
| RR3 | Employer not verified | risk_signal | medium | Brindlemoor, insurtech, no link to the posting | Cannot confirm the company exists as described. This is unverified, not evidence of a problem. Causes could be a recent company, a stale posting, or a search gap | `[generic]` standing entry; research refused | Can you share the live posting link or the recruiter's email domain? | unresolved |
| RR4 | Salary not in the JD you pasted | unknown | — | (none in the pasted JD) | The figure may be on the full posting or withheld | `[inferred]` from the paste | What is the budgeted salary for this post? | unresolved |
| RR5 | Explicit scope and presenting to underwriting | positive_signal | — | "turn results into recommendations for underwriting and product" | Role scope is defined and your presenting experience matches its audience | `[grounded]` JD and CV | Which underwriting decisions would this role own? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Lead with GLM, price tests and the underwriting presentation | Strongest direct matches (R1 to R5) | `[grounded]` CV | pending your approval |
| A2 | Frame pet as an adjacent extension of motor pricing discipline. Do not claim pet expertise | R6; avoids inflation | `[inferred]` R6 | pending your approval |
| A3 | Check the live posting and recruiter before applying | RR3 | `[grounded]` RR3 | pending your approval |
| A4 | Ask about people management early in the process | RR2 | `[grounded]` RR2 | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Search permission was not granted. Would have checked that Brindlemoor exists and that the posting is live (RR3) |
| 2. Role-family sweep | unavailable | Search permission was not granted. Would have set a market band for senior pet-insurance pricing (role reality) |
| 3. Hiring manager's public footprint | unavailable | Search permission was not granted. Would have shown Odile Varga's public role and scope (role reality) |

## Upgrade menu

- The live posting link or the recruiter's email domain → verifies Brindlemoor (RR3), which lifts the `conditional_go` cap.
- Your location and right-to-work status → closes H1.
- The budgeted salary → closes RR4 and sets it against the band.
- Search permission → the three refused targets above run, and the company and market band get checked.
- Optionally, a deeper pass on Brindlemoor (funding, leadership changes, recent news), up to 5 more searches and 2 more fetches. Say the word and it runs once you grant search permission.

Dossier offer: I can write this assessment out as `tuesday-dossier.md` if you want it on file.

1. Does this role line-manage anyone, or is it individual analytics ownership? (RR2)
2. What are your non-negotiables: location and right to work, salary floor, contract type, and start date? (H1)
3. Can you share the live posting link or the recruiter's email domain, so Brindlemoor can be checked? (RR3)

Answer any of these, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.