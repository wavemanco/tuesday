**Yes, apply, on conditions. You are a strong fit for the analytical core of this role. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: none stated in the JD; candidate constraints not given
- `must_have`: direct: R1, R2, R3, R4, R6; adjacent: R5
- `important`: direct: R7; unclear: R8, R9
- `preferred`: adjacent: R10

R5 (metrics layer) reads adjacent: you ran governed dashboards, not a metrics layer you can show you defined. R8 and R9 (clinicians, mentoring) have no evidence either way.

**Opportunity ledger.** The scope is concrete and the mandate is measurable (RR-P1), but the employer is not yet established from attributable sources (RR1, standing), and pay, reporting line and PHI access are unknown (RR2–RR4). Severe red flags: none found.

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **Conditions for go:** (1) the posting is confirmed live on Harborlight's own careers page (RR1); (2) pay, location and work authorization are checked against your constraints; (3) clinician partnership and mentoring hold up in interview (R8, R9).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, digital-health scale-up, ~400 people, Series C | `[grounded]` JD header; not verified (search refused, see Evidence status) |
| Mandate | Own product analytics for the care-navigation app: metrics layer, A/B tests, self-serve Looker, PM and clinician partnership, two junior analysts | `[grounded]` JD |
| Working pattern | Not stated | — |
| Scope read | Senior analytics owner with mentoring duties; a normal scope for the title | `[inferred]` from the responsibility count against the title |
| Market calibration | Not run: the role-family search was refused, so no pay or scope band is available here | — |
| Unknowns | Base pay, location, reporting line, clinician decision rights, PHI access scope | — |
| Contradictions | None found in the JD as pasted | `[grounded]` |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | Six years at a consumer subscription company; CV claim, no artifact yet | `[grounded]` CV as stated | none |
| R2 | Expert SQL | must_have | direct | medium | none | Daily SQL on Snowflake is what the CV supports. "Expert" is not claimed: the evidence shows daily use, not depth | `[grounded]` CV | none |
| R3 | Experiment design at scale | must_have | direct | medium | none | 30+ A/B tests a year and the pricing test behind an 11% retention lift. Scale is established; methodology depth is not shown | `[grounded]` CV | W1 below |
| R4 | Looker or similar BI; self-serve dashboards | must_have | direct | medium | none | Built the company's Looker instance from scratch; 40+ governed dashboards | `[grounded]` CV | none |
| R5 | Define and maintain a metrics layer | must_have | adjacent | medium | transferability | Governed dashboards carry the same discipline, but the CV does not say you defined a canonical metric layer | `[inferred]` from the governed-dashboard work | G1 closes if you describe the definitions you owned |
| R6 | Written communication to non-technical stakeholders | must_have | direct | medium | none | Writes the monthly metrics memo the exec team reads; presents monthly to VP Product | `[grounded]` CV | none |
| R7 | Partner with PMs to turn analysis into roadmap decisions | important | direct | medium | none | Monthly presentation to VP Product | `[grounded]` CV | none |
| R8 | Partner with clinicians | important | unclear | low | discovery | The CV names no clinical stakeholders. Carried as a question, not inferred | `[grounded]` CV silence | G2 |
| R9 | Mentor two junior analysts | important | unclear | low | discovery | No mentoring in the CV | `[grounded]` CV silence | G2 |
| R10 | Healthcare data experience, HIPAA (a plus) | preferred | adjacent | medium | transferability | You built a consent-state model and handled GDPR/CCPA consumer PII. No PHI and no HIPAA work | `[grounded]` CV; `[generic]` that HIPAA's scope and rules differ from GDPR/CCPA | G1 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Healthcare data and HIPAA (R10, R5) | transferability | Consent-state model and consumer PII under GDPR/CCPA. No PHI, no HIPAA-governed data, no BAA work | Care-navigation data is likely PHI, so the analyst works under HIPAA constraints from day one | Consent or access rules you applied to sensitive data; minimum-necessary access; retention or deletion rules you owned; any definitions you wrote for a metrics layer | A sanitized description of the consent-state model and its access rules | `[grounded]` CV; `[generic]` that HIPAA differs from GDPR/CCPA |
| G2 | Clinician partnership and mentoring (R8, R9) | discovery | Strong PM partnership and exec communication; no clinical stakeholders or mentoring in the CV | Two of the role's named duties, both `important` | Analysis you ran for a non-product team with its own domain experts; a junior analyst you trained, reviewed or unblocked | A sanitized example of working with a non-PM team; a note on a junior's development | `[grounded]` CV silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources (standing) | risk_signal | medium | "digital-health scale-up, ~400 people, Series C" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer. Research was refused here, so this reflects the check not running, not a finding against the employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me to this role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Base pay not stated | unknown | — | Not in the JD as pasted | The salary may be published elsewhere or withheld | `[grounded]` absence in the pasted JD | What is the base salary range for this role? | unresolved |
| RR3 | Reporting line and clinical decision rights | unknown | — | "partner with … clinicians" | Clinical requests may compete with product priorities, with unclear ownership | `[inferred]` from the clinician partnership duty | Who does this role report to, and how are clinical and product requests prioritized against each other? | unresolved |
| RR4 | PHI access scope | unknown | — | "healthcare data experience (HIPAA) a plus" | The analyst may work directly with PHI, under access controls you would need to learn | `[inferred]` from the HIPAA mention | What data does this team query, is it PHI, and what does access require? | unresolved |
| RR-P1 | Concrete scope and measurable mandate | positive_signal | — | "Own product analytics … define and maintain the metrics layer" | Scope is defined and success is measurable | `[grounded]` JD | Which experiment decisions from last year changed the roadmap? | noted |

**Severe red flags:** none found.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead the resume's Looker bullet with the governed-dashboard outcome, and put the pricing test's 11% retention lift first in the experimentation bullet | Surfaces R3 and R4 at the top | `[grounded]` CV | resume_edits_pending_approval |
| E2 | Describe the consent-state model as consumer-PII work under GDPR/CCPA, not as HIPAA experience | Keeps R10 at adjacent and avoids an interview probe | `[grounded]` CV; reframing audit applied | resume_edits_pending_approval |
| A1 | Confirm the posting on Harborlight's careers page before investing in the application | RR1 | `[generic]` | pending your approval |
| W1 | Prepare a one-page sanitized experiment readout as a work sample | Would raise R3 from medium to high | `[inferred]` from R3 | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches were refused by the host, so the employer and posting were not checked. Would have moved RR1 |
| 2. Role-family sweep | unavailable | Search refused; no pay or scope band, so market calibration is absent |
| 3. Hiring manager's public footprint | n/a | No name was given |

The host did not grant web search, so the two calls above are counted as sent. Nothing in this assessment about Harborlight's existence, size or funding is verified.

The dossier offer: I can write this analysis to `tuesday-dossier.md` so it carries into later sessions.

**Upgrade menu**

- **A live posting link from Harborlight's careers page** → RR1 closes, and the posting is verified against the JD.
- **A base salary range** → RR2 closes, and the figure is set against your floor.
- **A description of the data this team queries, and whether it is PHI** → RR4 closes and R10 moves.
- **A sanitized experiment readout or a metrics-memo excerpt** → R3 and R6 move to high.
- **Web search access, granted for this session** → targets 1 and 2 run, and the market band for pay and scope is added.
- **A deeper pass on Harborlight** (funding, leadership churn, public reviews; up to 5 more searches and 2 more fetches). Say the word and it runs.

**Questions**

G2 — Have you mentored junior analysts, and how have you worked with clinicians or other non-product teams on analysis? What did you own, and what happened?

Where do you need to be located, do you have work authorization for that location, and what is your minimum base salary?

Can you paste the posting link from Harborlight's careers site, and tell me the email domain of any recruiter who contacted you?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.