**Decision snapshot — hold_pending_answers.** One question decides this: the JD says fully remote (UK), but the company's careers page says Leeds, four days a week. Renata's location isn't known to me, so the location hard gate can't be checked yet.

- **Hard gates:** location unresolved (JD and careers page conflict; candidate location unknown). Compensation not stated in the JD; candidate floor unknown.
- **Fit:** strong on every stated requirement. The one clear gap is pet-insurance domain, which is not a stated requirement.
- **Confidence:** the fit read is high for the requirements she has evidenced. The location read is unknown.

**Research tier: L1 — searches 4 of 5, fetches 1 of 2; user links read 0**

**Role reality**
- **Role:** Senior Pricing Analyst, Brindlemoor. Owns pricing analytics for the pet-insurance product; builds and monitors rating models; designs and reads price tests; turns results into recommendations for underwriting and product. Reports to the Director of Pricing (Odile Varga). [grounded: JD, careers page]
- **Contradiction:** JD says "Fully remote (UK)". Careers page says "Leeds office four days a week." [grounded] Unresolved.
- **Company existence:** the careers page is the company's own site and shows the posting is live and matches the JD's scope. A general search for "Brindlemoor" returned nothing else, so I have only one attributable source for the company. [grounded]
- **Scope read (hiring manager):** one search result describes Odile Varga as Director of Pricing at Brindlemoor, who spoke at the 2025 Insurance Pricing Forum on monitoring rating models in small books, and previously ran pricing analytics at Calloway Re for six years. This comes from a single result whose link I couldn't verify, so treat it as a lead to check, not a confirmed profile. [grounded, single source]
- **Market calibration:** Pricewell 2026 UK pricing survey: senior pricing analyst at UK insurers and insurtechs, median base £58,400, interquartile range £52,100–£64,900 (n=612). [generic]
- **Compensation:** the JD doesn't state a salary, and the careers page doesn't either. The band above is the only comparison available.
- **Management:** the JD doesn't mention direct reports, so "has never managed anyone" is not a stated gap. It becomes one only if the role has reports.

**Evidence map**

| # | Priority | Requirement | Fit | Confidence | Gap | Evidence |
|---|---|---|---|---|---|---|
| 1 | Must | 4+ years pricing/actuarial analytics | Strong | High | None | 5 years UK motor pricing analytics; last 2 as senior analyst [grounded: CV] |
| 2 | Must | Strong SQL and Python | Strong | High | None | Used daily [grounded: CV] |
| 3 | Must | GLM experience | Strong | High | None | Built and maintained the young-driver GLM rating model [grounded: CV] |
| 4 | Must | Presenting to underwriting or actuarial leads | Strong | High | None | Quarterly pricing review to head of underwriting [grounded: CV] |
| 5 | Must (JD: "design and read price tests") | Price testing | Strong | High | None | 14 price tests last year with underwriting [grounded: CV] |
| 6 | Must (JD: "build and monitor rating models") | Rating model monitoring | Strong | Medium | Monitoring is evidenced through the young-driver model; pet-specific monitoring is not | Built and maintained [grounded: CV] |
| 7 | Preferred | Insurance experience | Met | High | None (motor only) | UK motor insurer [grounded: CV] |
| 8 | Implied | Pet-insurance domain | Gap | Low | Capability/transferability | Never worked on pet insurance. The methods transfer; pet-specific mechanics (lifetime vs annual cover, breed/age rating, claims-cost drivers) are unverified for her. [inferred] |
| 9 | Hard gate | Location (remote UK vs Leeds 4 days/week) | Unknown | Unknown | Contradiction in sources; candidate location unknown | [grounded: JD vs careers page] |
| 10 | Unknown | Compensation | Unknown | Unknown | Not stated; floor unknown | [generic] band above |
| 11 | Unknown | Direct reports | Unknown | Unknown | Not in JD; if present, "never managed" becomes a real gap | Renata's CV [grounded] |

**Gap recovery queue**
- **Row 8 (pet domain):** closes with a short pet-insurance self-study or a worked example she can point to, or with a brief test-design example from a non-motor line. Neither is a requirement, so this is low priority.
- **Row 11 (management):** closes if the role has no reports, which the recruiter can confirm.

**Opportunity risk register**
- **Location conflict (hard gate), severity: high, class: mismatch.** The job is advertised two ways. Her location decides which one applies.
- **Compensation unstated, severity: medium, class: mismatch.** No band to compare against her floor, and the posting withholds it.
- **Single-source company attribution, severity: medium, class: failed attribution.** Only the company's own careers page confirms the entity. Keeps the decision capped at conditional_go until the location is clarified and the posting is confirmed on a second source.

**Application plan (as far as evidence allows)**
- Lead with the young-driver GLM build and maintenance, and with the 14 price tests run with underwriting. These match the JD's core work.
- Position the pet gap as a method transfer, not as domain experience. Don't claim pet knowledge she doesn't have.
- For the hiring manager's lens, the 2025 forum talk on monitoring small books is a useful reference point if the lead holds up. Verify before using.
- No CV language is proposed yet; any wording goes to Renata for approval first.

**Evidence status**

| Target | Status | Reason |
|---|---|---|
| 1. Company site and careers page | yes | Careers page fetched; general name search returned nothing else. Queries: "Brindlemoor careers pricing"; "Brindlemoor insurtech pet insurance". Page: brindlemoor.co.uk/careers/senior-pricing-analyst |
| 2. Role-family sweep | yes | Query: "Senior Pricing Analyst UK insurance salary GLM pricing analyst 4+ years". Source: Pricewell 2026 survey |
| 3. Hiring manager footprint | yes | Query: "Odile Varga Director of Pricing Brindlemoor". Single result, unverified link |
| 4–5 (L2) | n/a | L2 not run; offered below |

**Dossier offer:** I can write this up as a `tuesday-dossier.md` if you want a shareable record.

**Upgrade menu**
- Brindlemoor's location policy confirmed by the recruiter → hard gate resolved; decision likely moves to `go` or `no_go`.
- The budgeted salary → compensation row closes against the band.
- Whether the role has direct reports → management row closes or becomes a real gap.
- A second, independent source for the company (Companies House record, press) → failed-attribution entry closes.
- Deeper research on Brindlemoor (funding, leadership changes, reviews) → up to 5 more searches and 2 more fetches, on your go-ahead.

**Questions**
1. Where are you based, and could you work from Leeds four days a week if the role turns out to be hybrid? (Location hard gate)
2. Does this role have direct reports? If yes, how do you see that fitting with your experience? (Management row)
3. Do you have a salary floor for this role? (Compensation row)

Response modes: answer each question, or say "skip" for any of them; skipping is a fine answer.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.