## Decision snapshot

**Yes, apply, on conditions. Status: `conditional_go`.** Your technical record matches the core of this role closely. The open items are the pet-insurance domain, an employer I could not verify, and three terms the posting leaves out.

**Fit ledger.**

- `hard_gate` — unclear: R1 (Fully remote, UK)
- `must_have` — direct: R2, R3, R4, R5, R7, R8
- `important` — adjacent: R6 (Pet-insurance product knowledge)
- `preferred` — direct: R9 (Insurance experience)

R6 — a motor-to-pet bridge, its limit named; R1 — location and right to work not yet stated, the one open gate.

**Opportunity ledger.** The scope is concrete: one product, named deliverables (RR5, positive). The posting is under-specified on pay, decision rights and direct reports (RR2, RR3). The employer is not established from sources in this session (RR1), which caps the status at `conditional_go`.

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote, UK); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **Conditions for go:** (1) RR1: the posting and employer confirmed on Brindlemoor's own careers page; (2) RR3: decision rights and direct reports confirmed; (3) R1: UK location and right to work confirmed; (4) R6: the pet gap stated as a limit, not as expertise.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, described as an insurtech | `[grounded]` JD header; not verified (see RR1) |
| Mandate | Own pricing analytics for the pet-insurance product: build and monitor rating models, design and read price tests, turn results into recommendations for underwriting and product | `[grounded]` JD |
| Scope read | One product, several linked duties (modelling, testing, recommendations); normal for a senior analyst title | `[inferred]` from the duty count against the stated title |
| Working pattern | Fully remote, UK | `[grounded]` JD |
| Compensation | Not stated in the posting | `[grounded]` JD omits pay |
| Market calibration | Not run; the role-family search was refused | — |
| Unknowns | Pay; decision rights; direct reports; pet claims and pricing data; location eligibility | — |
| Contradictions | None inside the JD; no careers page checked | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote, UK (location and right to work) | hard_gate | unclear | low | hard_gate | Not stated by you; UK motor background is indirect context only | `[grounded]` JD term | Q1 below |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | 5 years, last 2 as senior analyst; user-stated, no artifact; expect a probe | `[grounded]` your statement | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | Used daily; user-stated | `[grounded]` your statement | none |
| R4 | GLM experience | must_have | direct | medium | none | Built and maintained the GLM rating model for the young-driver book (motor) | `[grounded]` your statement | name the motor context |
| R5 | Build and monitor rating models | must_have | direct | medium | none | Build is direct; monitoring is only implied by "maintained" and should be confirmed in interview | `[grounded]` your statement | none |
| R6 | Pet-insurance product knowledge (implied by "our pet-insurance product") | important | adjacent | low | transferability | Motor rating and test design carry over; no pet claims, pet rating factors or pet price response; limit named | `[inferred]` from motor work against the pet product | G1 |
| R7 | Design and read price tests | must_have | direct | medium | none | Ran 14 price tests last year with the underwriting team | `[grounded]` your statement | none |
| R8 | Present to underwriting or actuarial leads | must_have | direct | medium | none | Presents the quarterly pricing review to the head of underwriting | `[grounded]` your statement | none |
| R9 | Insurance experience (a plus) | preferred | direct | medium | none | 5 years at a UK motor insurer | `[grounded]` your statement | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pet-insurance product knowledge (R6, important) | transferability | Motor pricing work, with nothing touching pet claims, pet rating factors or pet price response | The objection most likely to come up; a clear bridge narrows it | Any motor segment beyond the young-driver book; claims frequency or severity work; price-test design on a customer segment other than young drivers | A sanitized test-design note; a model-documentation excerpt | `[inferred]` bridge from your motor work; `[generic]` that this is the likeliest objection |
| G2 | UK location and right to work (R1, hard_gate) | hard_gate | Nothing stated | The role is fully remote and UK-based; the gate is unsettled, not failed | Not an experience question; a statement of your status | Not applicable | `[grounded]` JD term |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources in this session (searches refused, so not checked) | risk_signal | medium | "Brindlemoor (insurtech)" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer. This is unverified here because the search was refused, not because nothing was found. | `[generic]` pattern for companies of this size, not a claim about this one | "Can you point me at this role on your own careers site, and who would I be interviewing with?" | unresolved |
| RR2 | Pay not stated | unknown | — | Posting has no salary line | Pay may sit below the senior band or may be unpublished; no band was checked this session | `[grounded]` posting omits pay; `[generic]` on pay practice | "What is the base salary range for this role?" | unresolved |
| RR3 | Decision rights and direct reports unstated | unknown | — | "Own pricing analytics … turn the results into recommendations" | The role may own analysis and recommendations while pricing approval sits with underwriting or product; reports are not mentioned | `[inferred]` from the verbs against silence on decision rights | "Which pricing decisions does this role approve itself, and does it line-manage anyone?" | unresolved |
| RR4 | Pet-domain expectations in the first months | risk_signal | low | "our pet-insurance product" | The early work may centre on pet-specific rating and claims behaviour you have not worked on | `[generic]` pattern for moves between product lines | "What would success look like in the first six months on the pet book, and which pet data would I start from?" | unresolved |
| RR5 | Concrete scope | positive_signal | — | "Own pricing analytics for our pet-insurance product" | One product and named deliverables suggest a defined remit | `[inferred]` from the JD's wording | "How many people work on pricing for this product, and who owns the rating model today?" | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Check Brindlemoor's careers page for this posting before investing in an application | see RR1 | `[generic]` standard check | proposed |
| A2 | Lead with the motor record: GLM work, 14 price tests, the quarterly review to the head of underwriting, each stated as motor work in your own verbs ("built and maintained", "ran"), not "owned" or "designed" unless you did | see R4, R7, R8 | `[grounded]` your statements | pending your approval |
| A3 | Name the pet gap before they do: what carries over (rating method, test design, presenting to underwriting) and what you have not done (pet claims, pet rating factors) | see R6, RR4 | `[inferred]` | pending your approval |
| A4 | Ask the RR2 and RR3 questions in the first screen | pay and decision rights decide whether the role is worth the loop | `[grounded]` register | proposed |

## Evidence status

Verified: none yet. Every candidate claim above is user-stated; none has an inspected artifact.

Research tier: L1 — searches 4 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Brindlemoor insurtech pet insurance" and "Brindlemoor Senior Pricing Analyst careers"; both refused (search permission not granted). Would have moved the organization row and RR1 |
| 2. Role-family sweep | unavailable | Searched "senior pricing analyst pet insurance UK salary GLM"; refused. Would have set the market calibration and the RR2 pay band |
| 3. Hiring manager's public footprint | unavailable | Name given (Odile Varga, Director of Pricing); searched "Odile Varga Director of Pricing pet insurance"; refused. Would have moved the scope read and which story to lead with for this reader |

I did not retry the refused searches.

## Upgrade menu

- Brindlemoor's careers-page link or the posting URL → RR1 closes, or stays open with a reason.
- The pay range, from the posting or the recruiter → RR2 closes, and the band can be set against it.
- A sanitized test-design note or model-documentation excerpt → R5 and R7 move to `high` confidence; R6 may narrow.
- A non-young-driver motor example, or any claims-frequency or severity work → G1 narrows.
- Search permission granted → the three declared targets run again (up to 5 searches and 2 fetches at L1).
- Deeper company diligence and a recent-news sweep (up to 5 more searches and 2 more fetches) — offered once; say the word and it runs.

If you want, I can write this up as a `tuesday-dossier.md` file that the mock-interview skill can use to rehearse for the interview.

## Questions

1. **G2 (R1):** Are you based in the UK and eligible to work there? This is the one hard gate, and I can only ask whether it is met.
2. **RR3:** Did the recruiter say whether this role has direct reports, or who approves pricing changes?
3. **RR1:** Where did you find this posting, and have you spoken to anyone at Brindlemoor yet?

Answer in text, or say skip for any of them.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.