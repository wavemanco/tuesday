## Decision: conditional go

Apply, but treat this as a stretch on two must-haves: you'd be applying for a forecast and billing-data role you haven't done. Your CRM, SQL and sales-ops background is a strong match, so the application is worth your time if you can truthfully speak to some forecasting or revenue-data exposure. Otherwise I'd hold off.

**Fit ledger (per requirement, not averaged):**
- **Met:** 4+ years in RevOps/sales ops (5 years); Salesforce admin (certified); pipeline and renewal reporting (you've built both).
- **Partly met:** B2B background (your employer is B2B payments, not B2B software); SQL and spreadsheet modelling (SQL weekly and Excel daily are evidenced, "modelling" is not stated).
- **Gap:** owning a forecast (finance did it for you); working with finance on billing or revenue data (you've never worked on billing data).

**Hard gates:**
- **Location, unknown:** the role is Bristol, two days a week in the office. Your location isn't in what you gave me, so this is unchecked.
- **Pay, unknown:** the posting gives £61,500–£67,000 plus share options. Your floor isn't stated, so this is unchecked.

**Role reality** (from the posting you linked):
- The role owns CRM and billing data, builds pipeline and renewal reporting for sales and finance, and runs the quarterly revenue forecast with the CFO.
- This is a finance-adjacent role. Its two distinctive duties, the forecast and billing data, are the two you lack. Your sales-ops work covers the other half.
- Market calibration: not run. I did no company or market research in this pass, so there is no `[generic]` band for the title or the salary.

**Evidence map:**

| # | Priority | Requirement | Fit | Confidence | Gap | Evidence |
|---|---|---|---|---|---|---|
| 1 | must-have | 4+ yrs RevOps/sales ops/analytics at B2B software | partial | medium | transferability | 5 yrs sales ops at B2B payments; "software" not stated |
| 2 | must-have | HubSpot or Salesforce admin | met | high | — | Salesforce certified admin, rebuilt pipeline and renewal dashboards |
| 3 | must-have | Strong SQL and spreadsheet modelling | partial | medium | capability | SQL weekly, Excel daily; modelling not described |
| 4 | must-have | Experience owning a forecast | gap | — | capability | Finance owned the company forecast; you run the monthly pipeline review with the sales director |
| 5 | must-have | Experience working with finance on billing or revenue data | gap | — | capability | Never worked on billing data; renewal dashboards may be adjacent (unconfirmed) |
| 6 | hard gate | Location (Bristol, hybrid) | unknown | — | hard-gate | Not stated |
| 7 | hard gate | Pay (£61.5k–£67k) | unknown | — | hard-gate | Your floor is not stated |

**Application plan (what to say, and what not to say):**
- Lead with the Salesforce admin certification, the pipeline and renewal dashboards you rebuilt, and the UK team you ran.
- Describe the monthly pipeline review as exactly that. Don't call it forecasting, and don't use "forecast ownership" language. If you contributed to a number finance used, say what you contributed.
- Don't claim billing-data experience. If your renewal dashboards touched contract values or invoices, describe that precisely.

**Risk register:**
- Standing `medium` entry: company not verified. I did not check that Quillfield exists as described. This caps the decision at conditional go until it is checked.
- Hiring manager: Tamsin Achebe's public footprint was not researched.

**Evidence status:**

Research tier: L0 — no searches; user links read 1

| Target | Status | Reason |
|---|---|---|
| 1. Company site and careers page | skipped | Not run in this pass; offered in the upgrade menu |
| 2. Role-family sweep (scope, title, pay) | skipped | Not run in this pass; no market figure is claimed |
| 3. Hiring manager's public footprint | skipped | Not run; the name is from the recruiter and no search was done |

The posting itself was read from the link you gave me.

**Conditions for the conditional go:**
1. Your location and ability to be in Bristol two days a week are confirmed.
2. You can point to at least one real forecast or revenue-number contribution, or you accept that forecasting is a gap you'd have to argue past.
3. The company is verified as a real hiring employer.

**Dossier:** I can write your analysis to `tuesday-dossier.md` so it carries into interview prep, if you want it.

**Upgrade menu (what each missing input unlocks):**
- **Company and market research (up to 5 searches, 2 fetches):** verifies Quillfield and the recruiter's employer, and gives a market salary band for the £61.5k–£67k range. Also a public-footprint check on Tamsin Achebe, limited to professional information.
- **Your CV as a document:** would make the fit rows verifiable rather than based on what you've told me.
- **Your floor and location:** closes the two hard-gate rows.

**Questions:**
1. Where are you based, and could you work in Bristol two days a week? (hard-gate row 6)
2. Have you ever contributed to a forecast or commit number, even without owning it, such as pipeline inputs or sales-to-finance reconciliation? (row 4)
3. Have you touched any revenue or billing figures alongside finance, such as renewal values, invoice reconciliation or ARR reporting? (row 5)

Response modes: answer any of these, or say "skip" and I'll mark the row as unknown.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.