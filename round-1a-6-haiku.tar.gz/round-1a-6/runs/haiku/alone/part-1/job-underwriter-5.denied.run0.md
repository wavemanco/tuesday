## Decision snapshot

Probably worth applying, but not decidable yet: `hold_pending_answers`. Two hard gates are unconfirmed, and your answers to them could change the status: your location against R1, and your pay floor against R2.

**Fit ledger.**

- `hard_gate`: unclear: R1 (Remote (US) or Denver office), R2 (Salary $148,000–$166,000 plus equity)
- `must_have`: direct: R3 (5+ years data engineering), R4 (strong SQL and Python), R5 (dbt and a cloud warehouse), R7 (orchestration with Airflow or similar), R8 (data quality testing)
- `important`: adjacent: R6 (BigQuery as the named warehouse); unclear: R9 (ingestion from app and CRM), R10 (data contracts analysts depend on)

R3, R4, R5, R7 and R8 read as direct on your own account. R6 is BigQuery, which you have not used. R9 and R10 are responsibilities your background does not address.

**Opportunity ledger.** RR1 is a standing entry: the employer is not established from attributable sources (`medium`). RR2 and RR3 are unknowns: who owns "build and run", and the equity terms. RR4 is a positive signal: the posting states its stack, pay range and location.

- **Hard gates:** none failed; unconfirmed: R1 (Remote (US) or Denver office), R2 (Salary $148,000–$166,000 plus equity); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **What would change this:** if R1 and R2 both clear, the status moves to `conditional_go`, with conditions: RR1 verifies on the employer's own careers page, and RR2 is answered in conversation. If R1 comes back not met, the status is `no_go`.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states; founded 2016, Denver; 264 employees; Series C ($52M, February 2026) | `[grounded]` the about page as you pasted it; not checked (web search refused) |
| Mandate | Build and run the pipelines behind the tutoring platform's reporting: ingestion from app and CRM, a dbt-modelled BigQuery warehouse, data contracts for analysts | `[grounded]` JD |
| Scope read | A senior individual-contributor shape over one reporting domain; no direct reports named | `[inferred]` from the JD's responsibilities against the senior-scope norm in the pay report |
| Pay | $148,000–$166,000 plus equity | `[grounded]` JD |
| Market calibration | The posting's range straddles the report's median ($151,000); its top end is $2,500 above the upper quartile ($163,500). No compensation mismatch | `[grounded]` the pay report you sent, unchecked; `[generic]` that this band describes the role family, not this employer's offer |
| Location | Remote (US) or Denver office | `[grounded]` JD |
| Unknowns | Who else owns the pipelines; what "run" includes (on-call, incidents); equity size and vesting; hiring manager (none named); whether BigQuery is needed on day one | — |
| Contradictions | None between the JD and the about page you pasted | `[grounded]` |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | No location given for you, so unestablished, not failed | `[grounded]` JD; no candidate claim | Q1 |
| R2 | Salary $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | No pay floor given; the band is in role reality | `[grounded]` JD; no candidate claim | Q2 |
| R3 | 5+ years data engineering | must_have | direct | medium | none | Six years at one B2B payroll company, self-reported; medium is the intake ceiling | `[grounded]` your background | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | Daily use, self-reported | `[grounded]` your background | none |
| R5 | dbt and a cloud warehouse | must_have | direct | medium | none | About 180 dbt models on Snowflake; BigQuery is handled in R6 | `[grounded]` your background | none |
| R6 | BigQuery as the named warehouse | important | adjacent | medium | transferability | dbt work carries over; BigQuery itself is unused, the limit named | `[grounded]` background; `[generic]` that warehouse dialects and cost models differ | G2 |
| R7 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow for orchestration, self-reported | `[grounded]` your background | none |
| R8 | Data quality testing | must_have | direct | medium | none | You set up the Great Expectations suite, self-reported | `[grounded]` your background | none |
| R9 | Ingestion from app and CRM | important | unclear | none | discovery | Not in your background; the CV is silent | `[grounded]` background silence | G1 |
| R10 | Data contracts analysts depend on | important | unclear | none | discovery | Not in your background; the CV is silent | `[grounded]` background silence | G1 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Ingestion and data contracts (R9, R10) | discovery | dbt, Airflow and Great Expectations are in your background; ingestion and contracts are not | Both are named responsibilities; experience with either moves the role closer | Building an extractor from an application database or event stream; pulling from a CRM API; agreeing schema or breaking-change rules with analysts | A sanitized pipeline diagram, a contract spec, or a repo excerpt | `[grounded]` CV silence; `[generic]` that ingestion and contracts are often split across teams |
| G2 | BigQuery (R6) | transferability | dbt on Snowflake at about 180 models; no BigQuery | The bridge is real; the limit must be stated, not hidden | dbt model work on Snowflake; any cloud warehouse run through dbt; cost or performance tuning | A BigQuery sandbox project with a dbt repo, or a short course project | `[grounded]` CV; `[generic]` that warehouse dialects and cost models differ |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Build and run the pipelines behind our tutoring platform's reporting" | The employer may be too new or small for a footprint, the posting may be stale, or it may not be a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Ownership and on-call unstated | unknown | — | "Build and run the pipelines" | You could own build and run alone, with on-call duty and no team named | `[inferred]` from the JD's "run" language against its silence on team and on-call | Who else owns these pipelines day to day, and what does "run" include, such as on-call or incident response? | unresolved |
| RR3 | Equity stated without terms | unknown | — | "$148,000–$166,000 plus equity" | Equity value and vesting could change the total compensation picture | `[inferred]` from the JD's silence on terms | What is the equity grant's size, its vesting schedule, and the basis for its value? | unresolved |
| RR4 | Stack, pay range and location stated | positive_signal | — | "Salary $148,000–$166,000 plus equity. Remote (US) or our Denver office." | The posting is specific on pay and location | `[grounded]` JD | — | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Answer the two gate questions (Q1, Q2) before anything else | R1 and R2 decide between `no_go` and the rest | `[grounded]` R1, R2 | pending your answers |
| P2 | Open the posting on the employer's own careers page yourself, and check the recruiter's email domain against it | Resolves RR1 before you invest effort | `[grounded]` RR1; `[generic]` that small employers are often simply small | pending your approval |
| P3 | Describe BigQuery as a limit: "I've built a dbt project of about 180 models on Snowflake. I haven't used BigQuery yet." | Honest bridge that states the limit | `[grounded]` CV; no BigQuery claim made | pending your approval |
| P4 | If any ingestion or contract work exists, bring one sanitized artifact | Raises R9 and R10 from `unclear` | `[grounded]` G1 | pending your answer to G1 |
| P5 | Check the source and date of the pay report before citing it in any negotiation | It is unverified, and the research that would check it was refused | `[grounded]` the report as you sent it | pending your action |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searches for the company and the posting were refused by the permission prompt. Would have checked that the employer exists, its stage, and that the posting is live (RR1, role reality) |
| 2. Role-family sweep | unavailable | A search for the pay report was refused. Would have checked the report's source and date; the band rests on the pasted report |
| 3. Hiring manager's public footprint | n/a | No name was given |

I did not retry the refused searches.

Your dossier can be written to `tuesday-dossier.md` whenever you want it for a later interview-prep run.

## Upgrade menu

- Granting web search lets the L1 checks run: employer existence, posting status, and the pay report's source and date.
- Your answers to Q1 and Q2 close R1 and R2 and settle the decision status.
- A sanitized ingestion or data-contract artifact would raise R9 and R10 from `unclear`.
- A BigQuery sandbox project or course artifact would narrow the limit on R6.
- The hiring manager's name would unlock a footprint check for scope and positioning.

## Questions

R1 — Are you based in the US, and could you work fully remote from there, or would you need to be in Denver?

R2 — What is your base-pay floor?

G1 — Have you built ingestion from an application database or a CRM, or set up data contracts that analysts rely on? If so, what did you own, and what was it?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.