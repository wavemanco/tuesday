**Yes, worth applying, on conditions: `conditional_go`.** Your core requirements map directly onto the posting. BigQuery is the real gap, and the employer's own footprint is not yet verified.

**Decision snapshot**

**Status: `conditional_go`.** Apply once the employer checks out (RR2) and your location fits (R1). Your Snowflake/dbt/Airflow/Great Expectations work answers the core requirements, so the open items are about the employer and the scope, not your fit.

**Fit ledger.**

- `hard_gate` — unclear: R1 (Remote (US) or Denver office)
- `must_have` — direct: R2, R3, R4, R5, R6, R7
- `important` — adjacent: R8 (BigQuery warehouse); unclear: R9 (Data contracts), R10 (Ingestion from app and CRM)

R2–R7 — direct, with the claims your own statements carry and no artifact yet inspected; R8 — adjacent, your Snowflake dbt work is the bridge and BigQuery is the limit; R9 and R10 — unclear, not mentioned in your inputs.

**Opportunity ledger.** Sound, with three things unstated: the employer is not yet established from attributable sources (RR2), data-contract and ingestion ownership is unstated (RR3), and equity is unquantified (RR4). The salary is stated and sits inside the market band (RR1).

- **Hard gates:** none failed; unconfirmed: R1 (Remote (US) or Denver office); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **Conditions for go:** (1) RR2 clears: the posting is live on Pellucid's own careers page; (2) R1 confirmed: your location fits remote-US or Denver; (3) RR3 answered: data contracts and app/CRM ingestion are in scope for you; (4) BigQuery is presented as adjacent, never as experience.

**Research tier: L1 — searches 1 of 5, fetches 0 of 2; user links read 0**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | The one search was refused (WebSearch permission not granted), so no page was read. It would have moved the organization row, whether the posting is live, and RR2. |
| 2. Role-family sweep | skipped | The Datawright report you pasted already fixes the market band for this title and seniority, which feeds the market calibration line. A second sweep would restate it. |
| 3. Hiring manager's public footprint | n/a | No name is given in the posting, so there is no query to form. |

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online K-12 tutoring in 31 US states, founded 2016, Denver, 264 employees, Series C $52M (Feb 2026) | `[grounded]` your pasted about page; self-reported, not independently checked |
| Mandate | Build and run the pipelines behind tutoring-platform reporting: app and CRM ingestion, a dbt-modelled BigQuery warehouse, and the data contracts analysts depend on | `[grounded]` JD |
| Working pattern | Remote (US) or Denver office | `[grounded]` JD |
| Scope read | Ownership of a domain's pipelines plus contracts, consistent with the title | `[inferred]` from the JD's listed responsibilities against the role-family norm |
| Market calibration | Posted $148k–$166k against the Series B–D senior band: median $151k, IQR $139k–$163.5k. The posted range sits inside the IQR, upper-middle. Typical senior scope is one domain with no direct reports, which matches | `[grounded]` the pasted pay report's figures; `[generic]` for the band's application to this stage |
| Unknowns | Equity size and vesting; who owns data contracts; whether ingestion covers the whole app and CRM | — |
| Contradictions | None between the JD and the about page as provided. Not checked against the live site (see tier line) | — |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | Your location and authorization aren't in your inputs, so the gate can't be checked | `[grounded]` JD | Q1 |
| R2 | 5+ years data engineering | must_have | direct | medium | none | Six years at a B2B payroll company, specific; no artifact inspected | `[grounded]` your statement | none |
| R3 | Strong SQL | must_have | direct | medium | none | Daily SQL, across a 180-model dbt project | `[grounded]` your statement | W1 |
| R4 | Strong Python | must_have | direct | medium | none | Daily Python | `[grounded]` your statement | none |
| R5 | dbt and a cloud warehouse | must_have | direct | medium | none | dbt on Snowflake is a cloud warehouse; the JD doesn't name BigQuery in this line | `[grounded]` your statement, JD | W1 |
| R6 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow orchestration in production | `[grounded]` your statement | none |
| R7 | Data quality testing | must_have | direct | medium | none | Set up a Great Expectations suite | `[grounded]` your statement | W1 |
| R8 | Dbt-modelled warehouse in BigQuery (responsibility) | important | adjacent | medium | transferability | The dbt-on-warehouse skill transfers; BigQuery itself is unused. Limit named wherever this is used | `[inferred]` from the Snowflake dbt work | G1 |
| R9 | Data contracts analysts depend on | important | unclear | none | discovery | Not in your inputs | `[grounded]` JD | Q3 |
| R10 | Ingestion from app and CRM | important | unclear | low | discovery | Pipeline work is plausible context; not stated | `[inferred]` | Q3 |

**Gap recovery queue**

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R8) | transferability | dbt and Snowflake at scale; no BigQuery | The JD names BigQuery; a direct match moves R8 | Any dbt-on-BigQuery work, even a personal project | A sanitized model or project repo | `[inferred]` from your Snowflake work |
| G2 | Data contracts (R9) | discovery | Not in your inputs | The JD makes contracts a responsibility | Schema agreements with analysts, dbt model contracts or versioning | A sample contract or the agreement's shape | `[grounded]` JD |
| G3 | App and CRM ingestion (R10) | discovery | Not in your inputs | Scope depends on which sources you'd own | Ingestion from a product database or a CRM | A pipeline diagram or description | `[inferred]` |

The questions for G2 and G3 are in the closing block, tagged with their row ids.

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Salary stated and in band | positive_signal | — | "$148,000–$166,000 plus equity" | Pay is transparent and sits inside the senior band | `[grounded]` JD and pasted pay report | Is the range the budgeted band for this hire? | noted |
| RR2 | Employer not established from attributable sources | risk_signal | medium | "Pellucid Learning" posting and about page | The entity may be too new or small to have a footprint, the posting may be stale, or it may not be a real hiring employer. Research didn't run, so this reflects the missing check, not evidence against the employer | `[generic]` pattern for companies this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR3 | Data-contract and ingestion ownership unstated | unknown | — | "the data contracts our analysts depend on" | You may own contracts alone or with analysts; ingestion scope is unclear | `[inferred]` from the JD's listing | Who owns the data contracts with analysts, and which upstream systems does ingestion cover? | unresolved |
| RR4 | Equity unquantified | unknown | — | "plus equity" | Equity value may be little or unvested for a while | `[inferred]` from the JD's wording | What is the equity grant, and what's its vesting schedule? | unresolved |

No request in the material asks anything of you. It's a posting, not a message, so no request entry applies.

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead the summary with the Snowflake dbt project (about 180 models), Airflow ownership, and the Great Expectations suite, and state Snowflake as your warehouse. Don't write BigQuery as experience | see R5, R6, R7, R8 | `[grounded]` your sentences; audited for scope and kind | pending your approval (`resume_edits_pending_approval`) |
| A1 | Confirm the posting on Pellucid's careers page before you invest effort | see RR2 | `[generic]` pattern | pending your approval |
| A2 | Interview framing for BigQuery: "I haven't run BigQuery in production. My dbt and Snowflake work transfers, and here's how I'd close the BigQuery-specific gap." Don't claim BigQuery use | see R8, G1 | `[inferred]` from R8 | pending your approval |
| W1 | Share a sanitized dbt model or Great Expectations excerpt to raise R3, R5, R7 | see the upgrade menu | `[grounded]` rows | pending your approval |

**Evidence status**

Verified: R2–R7 claims, as your own statements in this engagement. No artifact has been inspected, so these stay at `medium`. Unverified leads: none. Rejected inferences: none.

**Dossier offer:** Want me to write this assessment to `tuesday-dossier.md`, so you can carry it into interview prep?

**Upgrade menu**

- A sanitized dbt model or GX suite excerpt → R3, R5, R7 move toward `high`.
- Any BigQuery use, even personal → R8 moves from `adjacent` toward `direct`.
- Your location and authorization → R1 closes.
- The live posting link, or the recruiter's email domain → RR2 closes.
- If you grant WebSearch, I can run the careers-page check, which is the one that didn't run: up to 4 more searches and 2 fetches inside the L1 caps.

**Questions**

1. **R1:** Are you located in the US, and can you work fully remote or from Denver?
2. **G2 / RR3:** Have you agreed schemas or contracts with analysts, such as dbt model contracts or versioned interfaces?
3. **G3 / RR2:** Did you find this posting on Pellucid's own careers page, or through a recruiter? If a recruiter, what's their email domain?

Answer in text, or say skip for any of them.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.