**Yes, worth applying, on conditions. Status: `conditional_go`.** On what you've shared, you meet almost every stated requirement. The gaps are pet-insurance product knowledge and product-side recommendations. I couldn't verify the employer, because the web searches were refused in this session.

**Fit ledger.**

- `hard_gate`: unclear: R1 (Fully remote, UK)
- `must_have`: direct: R2, R3, R4, R5, R6, R7, R8a; unclear: R8b (product recommendations)
- `important`: adjacent: R9 (pet-insurance product)
- `preferred`: direct: R10

Your evidence covers the core of the role. R8b and R9 are the rows that matter most for the application.

**Opportunity ledger.** The JD's scope is specific and measurable, but the employer is unverified (RR1, medium), line-management scope is unstated (RR2), and no salary is given (RR3). No severe red flags.

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote, UK); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **Conditions for go:** (1) RR1 clears: the posting appears on Brindlemoor's own careers page; (2) R1 is confirmed against your location and any constraints you name; (3) you frame the pet gap honestly as adjacent (R9), not as pet expertise.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech with a pet-insurance product | `[grounded]` JD header and your message; not verified externally |
| Mandate | Own pricing analytics for the pet product: rating models, price tests, recommendations to underwriting and product | `[grounded]` JD |
| Working pattern | Fully remote, UK | `[grounded]` JD |
| Scope read | A normal senior IC analytics remit. The JD lists no direct reports | `[inferred]` from the JD's responsibilities against its silence on people management |
| Market calibration | Not run. Searches were refused, so no band is available | — |
| Unknowns | Line-management scope, salary, whether product decisions are yours or the product team's, the pet loss-history data you would work with | — |
| Contradictions | None visible in what you provided | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote, UK | hard_gate | unclear | low | hard_gate | Your UK motor work suggests you're UK-based, but you haven't stated your location or constraints | `[inferred]` from your UK employment history | Q1 below |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | Five years in pricing analytics, the last two as senior analyst | `[grounded]` your message, self-reported | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | Daily use of both | `[grounded]` your message, self-reported | Artifact would raise to high |
| R4 | GLM experience | must_have | direct | medium | none | Built and maintained the young-driver GLM | `[grounded]` your message, self-reported | Sanitised model documentation would raise to high |
| R5 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | Presents the quarterly pricing review to the head of underwriting. No actuarial-lead audience stated | `[grounded]` your message | none |
| R6 | Build and monitor rating models | must_have | direct | medium | none | Built and maintained the GLM; monitoring not described | `[grounded]` your message | Ask about monitoring in interview prep |
| R7 | Design and read price tests | must_have | direct | medium | none | Ran 14 price tests last year with underwriting | `[grounded]` your message | A test readout would raise to high |
| R8a | Recommendations to underwriting | must_have | direct | medium | none | The quarterly review is a recommendation channel to underwriting | `[grounded]` your message | none |
| R8b | Recommendations to product | must_have | unclear | low | discovery | Nothing in what you've shared shows product-side recommendations | `[inferred]` from the JD against your stated experience | Q3 below |
| R9 | Pet-insurance product pricing | important | adjacent | medium | transferability | Motor rating and testing carry over directly. Pet loss patterns, product features and no exposure to pet data are not covered | `[inferred]` from your motor work against the JD's product | Bridge case, see G1 |
| R10 | Insurance experience | preferred | direct | medium | none | UK motor insurer | `[grounded]` your message | none |

R9 is inferred from the JD's "pet-insurance product" wording, not stated as a requirement. Confidence grades your claims, which are self-reported at intake and so capped at medium.

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pet-insurance product (R9, important) | transferability | Motor pricing, GLMs and price tests. No pet work | This is the most likely objection. A credible bridge narrows it | Pricing a new book or product with thin loss history; a launch you priced; any work on rating factors that aren't motor-specific | A launch pricing note, or a sanitised product review | `[inferred]` bridge from your motor work; `[generic]` that pet is the likeliest objection |
| G2 | Product recommendations (R8b, must_have) | discovery | Underwriting recommendations are clear. Product-side ones are not shown | The JD names product explicitly | Changes to cover terms, excesses, or product rules that you proposed and were adopted | A product change paper or a before/after summary | `[grounded]` the JD's "and product" against your stated experience |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not yet verified from attributable sources | risk_signal | medium | "Brindlemoor (insurtech)" | The posting may be stale, the company may be small, or the posting may sit on an aggregator rather than the employer's site. Search was refused, so this is unverified, not disproven | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Line-management scope unstated | unknown | — | "Senior Pricing Analyst" | The role may include managing analysts. You haven't managed people, so this matters | `[inferred]` from the title against the JD's silence on people management | Does this role line-manage anyone, and if so, how many people? | unresolved |
| RR3 | Salary not stated | unknown | — | JD gives no pay | Pay may sit below your expectations, or simply isn't published | `[inferred]` from the JD's silence | What is the budgeted salary band for this role? | unresolved |

No severe red flags. Nothing in this material asks you to pay, deposit, or give bank or ID details.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Confirm the live posting on Brindlemoor's careers site before applying | RR1 | `[grounded]` the register entry | pending your approval |
| P2 | Frame pet as adjacent: motor pricing transfers, pet loss patterns and product features are new to you, and you name that limit | R9, G1 | `[grounded]` R9 row | pending your approval |
| P3 | Lead with the GLM and price-test record, stated as your work | R4, R7 | `[grounded]` rows | pending your approval |
| P4 | Prepare one product-side example, if you have one, for R8b | R8b, G2 | `[grounded]` R8b row | pending your approval |

## Evidence status

Verified: none yet. Your claims are self-reported intake and stay at medium until you give an artifact or a specific probe answer.

Research tier: L1 — searches 4 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Every search call was refused ("permission not granted"). Would have verified RR1 and the posting's consistency |
| 2. Role-family sweep | unavailable | Same refusal. Would have set the market calibration line and the salary check for RR3 |
| 3. Hiring manager's public footprint | unavailable | Same refusal. A name was given, so a query could be formed. Would have shaped positioning for Odile Varga |

## Upgrade menu

- Granting search permission lets the three L1 targets run (the refused calls count against the budget, so about one search remains). A link to the live posting would settle RR1 in one step.
- A sanitised GLM validation summary or a test readout → R4 and R7 move to high.
- A product change paper → R8b moves from unclear toward direct.
- The budgeted salary → RR3 closes.
- Odile Varga's public role history → positioning for the interview.

If you want this kept, I can write it up as a `tuesday-dossier.md` you can reuse.

**Questions, tagged to their rows:**

- R1: Are you based in the UK, and are there other constraints (pay floor, contract type, start date) you want checked against this role?
- G1 / R9: Have you priced a product with little loss history, or launched a new book? That is the bridge to pet.
- G2 / R8b: Have you made product recommendations (cover terms, excesses, product rules) that were adopted, not just rate changes?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.