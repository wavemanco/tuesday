**Worth applying to, on conditions. Status: `conditional_go`.** Your background matches the core requirements well. The open items are whether you meet the location term, and how much BigQuery ramp the role needs.

**Fit ledger.**
- `hard_gate`: unclear: R1 (Remote US or Denver office)
- `must_have`: direct: R2, R3, R4, R5, R6, R7
- `important`: adjacent: R8 (BigQuery), R10 (data contracts); unclear: R9 (ingestion from app and CRM)

R2–R7 are direct on your own account, graded medium because no artifact is attached. R8 is the one clear gap: you have Snowflake, not BigQuery.

**Opportunity ledger.** Sound and specific. The scope is defined, the salary is published, and the company's own pages match the posting. Three things are unknown: contract basis, on-call expectations, and the current state of the BigQuery warehouse (RR1–RR3). No red flags found, and the posting has no requests made of you.

- **Hard gates:** none failed; unconfirmed: R1 (Remote US or Denver office); candidate constraints not given. Checks against them are unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) you meet the location term (R1); (2) the BigQuery ramp is framed as adjacent, not claimed (R8, RR1); (3) on-call and ownership are clarified (RR3).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states; founded 2016, Denver; 264 employees; Series C, $52M, February 2026 | `[grounded]` company's own about page, fetched |
| Mandate | Build and run reporting pipelines: app and CRM ingestion, a dbt-modelled BigQuery warehouse, data contracts for analysts | `[grounded]` posting, fetched and matching your paste |
| Scope read | One domain (reporting) with no direct reports stated. That matches the typical pattern for this title | `[generic]` Datawright pattern for Senior DE at Series B–D |
| Market calibration | Posted $148k–$166k sits inside the Datawright IQR ($139k–$163.5k); the $157k midpoint is above the $151k median | `[grounded]` posting; `[generic]` band from the Datawright 2026 report you supplied |
| Unknowns | Contract basis (permanent or fixed-term); equity terms; on-call; current warehouse state; team size; hiring manager (not named) | — |
| Contradictions | None between the posting and the careers page | `[grounded]` fetched page |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | Your location isn't in the inputs, so the gate can't be checked | `[grounded]` posting | Q1 below |
| R2 | 5+ years data engineering | must_have | direct | medium | none | 6 years at a B2B payroll company | `[grounded]` your background | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | Daily use of both | `[grounded]` your background | none |
| R4 | dbt | must_have | direct | medium | none | ~180-model dbt project | `[grounded]` your background | none |
| R5 | Cloud warehouse | must_have | direct | medium | none | Snowflake, a cloud warehouse | `[grounded]` your background | none |
| R6 | Orchestration (Airflow or similar) | must_have | direct | medium | none | Airflow in production | `[grounded]` your background | none |
| R7 | Data quality testing | must_have | direct | medium | none | Set up a Great Expectations suite | `[grounded]` your background | none |
| R8 | BigQuery warehouse (named in responsibilities) | important | adjacent | medium | transferability | Snowflake and dbt carry over. No BigQuery use, so the limit is BigQuery-specific tooling and cost controls | `[inferred]` from the Snowflake work | G1 |
| R9 | Ingestion from app and CRM | important | unclear | low | discovery | Your background doesn't say which sources you ingested | `[grounded]` posting; silence in your background | G2 |
| R10 | Data contracts analysts depend on | important | adjacent | medium | transferability | The Great Expectations suite is related but isn't a consumer-facing contract. Limit: no formal contracts named | `[inferred]` from the GE suite | G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R8, important) | transferability | Snowflake warehouse and dbt on it; no BigQuery | Named in the posting's architecture. A clear transfer case with a stated limit is the honest version | Any BigQuery exposure, including a sandbox or a migration | A query-cost note, a partitioning decision, a migration plan | `[grounded]` posting and CV; `[generic]` that BigQuery ramp is the usual objection |
| G2 | Source ingestion and data contracts (R9, R10, important) | discovery, transferability | Ingestion work is unnamed; contracts are unnamed | Both are named responsibilities; you may have real examples under other names | Pipelines from a product database, an API or a CRM export; schema agreements with downstream users | A pipeline diagram, a schema-change note, a contract doc | `[grounded]` posting; `[inferred]` that the GE suite is the nearest bridge |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Warehouse platform unclear | unknown | — | "a dbt-modelled warehouse in BigQuery" | The warehouse may be fully on BigQuery, or partly migrating from elsewhere | `[inferred]` from the posting's wording | Is the warehouse on BigQuery today, or is anything migrating in? | unresolved |
| RR2 | Contract basis unstated | unknown | — | "Salary $148,000–$166,000 plus equity" | Could be permanent or fixed-term; the posting doesn't say | `[grounded]` posting silence | Is this a permanent role, and what is the equity vesting schedule? | unresolved |
| RR3 | Operational ownership unstated | unknown | — | "Build and run the pipelines" | "Run" could mean on-call; the posting doesn't say | `[inferred]` from "run" against silence on on-call | Who is on call for pipeline failures, and how often? | unresolved |
| RR4 | Salary stated and within band | positive_signal | — | "$148,000–$166,000" | The range is competitive for the title | `[generic]` band against `[grounded]` posting | — | noted |
| RR5 | Company scale and funding stated | positive_signal | — | "Series C ($52M, February 2026)" | Stable funding and a clear scale; figures are self-reported | `[grounded]` own about page | — | noted |

**Standing entry: employer not established.** Not triggered. The careers page is live and the about page matches the posting, both on the company's own domain.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm the location term with the recruiter before investing in the loop | R1 is unclear and can't be checked from the inputs | `[grounded]` posting | pending your answer |
| A2 | Frame BigQuery as a transfer with a stated limit, never as experience | R8 is adjacent | `[grounded]` R8 | pending your approval |
| A3 | Lead with the 180-model dbt project and the Great Expectations suite | These are your direct matches | `[grounded]` CV | pending your approval |
| A4 | Ask RR1–RR3 in the first screen | They decide the conditions | `[grounded]` register | pending your approval |

Under the reframing audit, nothing here adds a claim. Don't describe the Snowflake work as BigQuery work, and don't describe the GE suite as data contracts.

## Evidence status

Verified: none yet. Your background is your own written statement, graded `medium` with no artifact attached.

Research tier: L1 — searches 0 of 5, fetches 2 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Fetched `https://pellucidlearning.com/careers/senior-data-engineer`, which is live and matches your paste; fetched `https://pellucidlearning.com/about`, which matches the company facts you gave. Moved the Role reality organization row and cleared the standing employer-not-established entry |
| 2. Role-family sweep | skipped | The Datawright report you pasted already fixes the calibration band, so no search was needed |
| 3. Hiring manager's public footprint | n/a | No name was given |

## Upgrade menu

- A BigQuery example (a query, a cost note, or a migration) → R8 moves from `adjacent` to a stronger bridge.
- A CRM or app ingestion example, or a contract doc → R9 and R10 resolve.
- Your location, if you share it → R1 closes and the decision firms up.
- A deeper research pass on Pellucid (funding, leadership churn, staff reports; up to 5 more searches and 2 more fetches): say the word and it runs.

If you want this kept as a reusable file, I can emit it as `tuesday-dossier.md`.

Questions, one for each tagged row:

- Q1 (R1, gate): Are you based in the US, and can you work remotely or from the Denver office?
- G1 (R8): Have you used BigQuery in any form, such as a sandbox, a query, or a migration?
- G2 (R9, R10): Have you built ingestion from a product database or CRM, or set up a schema agreement with downstream users?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.