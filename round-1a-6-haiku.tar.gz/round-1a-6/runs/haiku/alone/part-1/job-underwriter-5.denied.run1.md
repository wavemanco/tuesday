**Yes, it's worth applying, as `conditional_go`: your background matches the must-haves, but verify the posting before you invest in it.**

## Decision snapshot

- **Fit ledger**
  - `hard_gate`: unclear: R1 (Remote US or Denver office)
  - `must_have`: direct: R2, R3, R4, R5, R6
  - `important`: adjacent: R7 (BigQuery warehouse); unclear: R8 (ingestion from app and CRM), R9 (data contracts analysts depend on)

  R2, R3, R4, R5, R6: stated background, not yet inspected. R7: Snowflake and dbt transfer, BigQuery limit named. R8, R9: nothing in your background yet, asked below.

- **Opportunity ledger:** Sound on scope and pay, unverified on the employer. RR3 (pay in band) and RR4 (bounded scope) read positive. RR1 (employer and posting unconfirmed) is open because web checks were refused. RR2 names no team or reporting line.
- **Hard gates:** none failed; unconfirmed: R1 (Remote US or Denver office); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) RR1: the posting is live on Pellucid's own careers page and the company checks out. (2) R1: you are US-based and remote or Denver works. (3) R8 and R9: your work has touched source ingestion and data contracts, or the transfer holds up in interview.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states; founded 2016, Denver; 264 employees; Series C ($52M, Feb 2026) | `[grounded]` your pasted About text; not checked live (RR1) |
| Mandate | Build and run reporting pipelines: app and CRM ingestion, a dbt-modelled BigQuery warehouse, the data contracts analysts depend on | `[grounded]` JD |
| Working pattern | Remote (US) or Denver office | `[grounded]` JD |
| Scope read | One domain (platform reporting), three named deliverables, senior title | `[inferred]` from JD responsibilities; `[generic]` that one domain's pipelines with no direct reports is the usual scope for this title |
| Market calibration | Stated $148,000–$166,000 runs from the band's median ($151,000) to above its upper quartile ($163,500). Your 6 years fits the "Senior" norm of 5–8 | `[generic]` Datawright 2026 report you provided (US, n=2,310, Series B–D); `[grounded]` JD figure. The band is a pattern, not this employer's offer |
| Unknowns | Team size and reporting line (RR2); whether the role owns CRM ingestion and contracts; BigQuery depth expected | — |
| Contradictions | None between the JD and the About text as pasted. Neither was checked against a live source | `[grounded]` |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | No candidate location or work-arrangement statement given, so the gate is not established | `[grounded]` JD; your location not given | Ask (Q1) |
| R2 | 5+ years data engineering | must_have | direct | medium | none | Six years at a B2B payroll company, stated in intake prose (CV-equivalent, not inspected) | `[grounded]` your background | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | Both used daily, stated; no artifact inspected | `[grounded]` your background | none |
| R4 | dbt and a cloud warehouse | must_have | direct | medium | none | dbt project of ~180 models on Snowflake; Snowflake is a cloud warehouse | `[grounded]` your background | none |
| R5 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow used for orchestration | `[grounded]` your background | none |
| R6 | Experience with data quality testing | must_have | direct | medium | none | Set up a Great Expectations test suite | `[grounded]` your background | none |
| R7 | Dbt-modelled warehouse in BigQuery (responsibilities) | important | adjacent | medium | transferability | Snowflake and dbt carry over. BigQuery never used, so its platform specifics are absent from your record. Limit named | `[inferred]` adjacency from R4 | Proposed wording in P2; strengthener in G1 |
| R8 | Ingestion from application and CRM | important | unclear | none | discovery | Your background names no source systems or CRM ingestion | `[grounded]` absence in your background | Ask (Q3) |
| R9 | Data contracts analysts depend on | important | unclear | none | discovery | Your background names no contracts or schema agreements | `[grounded]` absence in your background | Ask (Q2) |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery warehouse (R7, important) | transferability | Snowflake and dbt at ~180 models; no BigQuery | The posting names BigQuery; a narrower limit reduces the main platform objection | A dbt project on BigQuery public data; a course or certification with a dbt build; any GCP work, however small | A small repository or a sanitized model graph | `[inferred]` bridge from R4; `[generic]` that a platform gap is the likeliest objection |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer and posting unverified | risk_signal | medium | "Pellucid Learning runs live online tutoring for K-12 schools in 31 US states" | Web checks could not run, so the company, live posting and Series C figure rest on your pasted text. The employer may be too new or small for a public footprint, the posting may be stale, or it may not be a hiring employer | `[generic]` pattern for companies of this size, not a claim about this one; the check was unavailable, not failed | Can you point me at this posting on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Team size and authority not stated | unknown | — | "Build and run the pipelines behind our tutoring platform's reporting" | The role may carry the whole pipeline estate alone, or a team exists but is unpublished | `[inferred]` from the JD's scope against its silence on team and reporting line | How large is the data team this role sits in, and who would I report to? | unresolved |
| RR3 | Stated pay sits in the role-family band | positive_signal | — | "Salary $148,000–$166,000 plus equity" | Pay is disclosed and runs from the band's median to above its upper quartile | `[grounded]` JD figure; `[generic]` band from the Datawright report | Is $148,000–$166,000 the approved budget, and where do offers usually land? | noted |
| RR4 | Scope named and bounded | positive_signal | — | "ingestion from our app and CRM, a dbt-modelled warehouse in BigQuery, and the data contracts our analysts depend on" | Three named deliverables in one reporting domain. Success measures are not stated | `[grounded]` JD; `[generic]` that this scope is normal for the title | Which of these three is the first deliverable, and what does done look like at six months? | noted |

Severe red flags: none found. The posting makes no requests of the candidate.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Before investing effort, verify the posting is live on Pellucid's careers page and confirm the employer | RR1 | `[grounded]` RR1 | pending your approval |
| P2 | Proposed resume line: "Built the dbt project on Snowflake (~180 models) at a B2B payroll company; Airflow for orchestration; set up the Great Expectations test suite." Do not add BigQuery or GCP wording | R4, R5, R6, R7 | `[grounded]` your sentences; each clause traces to your words | resume_edits_pending_approval |
| P3 | Positioning: lead with dbt on Snowflake and data-quality testing, the must-haves you hold directly. State BigQuery as the limit, not as experience | R4, R6, R7 | `[grounded]` rows; `[generic]` that leading with direct matches is usual practice | pending your approval |
| P4 | Ask the recruiter RR2's question: team size and reporting line | RR2 | `[grounded]` RR2 | pending your approval |

## Evidence status

Verified: none yet. Your background (R2–R6) is intake prose, CV-equivalent. It becomes verified once you confirm it in answer to the questions below.

Research tier: L1 — searches 2 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Pellucid Learning live online tutoring K-12 Denver" and "Pellucid Learning Series C funding 2026"; fetch of pellucidlearning.com/careers/senior-data-engineer. All were refused, because web search and fetch permission was not granted in this session. Would have moved RR1 and the Series C and headcount figures |
| 2. Role-family sweep | skipped | The Datawright 2026 pay report you provided already fixes the market band and the scope norm; no search sent |
| 3. Hiring manager's public footprint | n/a | No name given, so no query could be formed |

Dossier: I can write this out as `tuesday-dossier.md` if you want to keep it.

## Upgrade menu

- Permission for web search and page fetch: runs target 1 (live posting, careers page, Series C claim) within the remaining L1 caps of 3 searches and 1 fetch.
- Your location and the pay you need: closes R1, and turns RR3 from a band comparison into a check against your floor.
- A small dbt project on BigQuery, or a sanitized one: narrows R7's limit.
- A sanitized dbt model graph or Great Expectations suite screenshot: R4 and R6 rise to `high`.
- The hiring manager's name, if you have it: unlocks the team and reporting-line context for RR2.

## Questions

R1: Are you based in the US, and is remote-US or the Denver office workable for you?

R9: Have you defined or owned data contracts, or agreed schemas, with downstream consumers such as analysts? What did they cover?

R8: Which sources have you ingested from, such as an application database, a CRM, or event streams?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.