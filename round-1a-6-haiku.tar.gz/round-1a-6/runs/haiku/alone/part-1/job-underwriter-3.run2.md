**Short answer: no, not on these terms.** Two of your hard constraints fail outright, and the posting says both are non-negotiable. `no_go`.

**Research tier: L1, but web search was refused.** Every search was denied by the host, and I did not retry. Nothing below about the company or the market is verified.

## Decision snapshot

**No, not as written: `no_go`.** R1 (on-site, five days a week) and R2 (base pay) both fail your constraints, and the posting says the on-site requirement has "no exceptions."

**Fit ledger.**

- `hard_gate`: failed: R1 (on-site work five days a week), R2 (base salary $70–85k)
- `must_have`: direct: R3, R4a · adjacent: R5 (team of one, no bench) · unclear: R4b (SEO/content, brand, PR, partnerships, sales ops)
- `important`: direct: R7 · unclear: R6 (ambiguity, evolving metrics)

The fit is real where you have evidence (R3, R4a, R7). The gaps are in functions outside your CV and in a solo-operator model you haven't done.

**Opportunity ledger.** The posting is thin on terms and heavy on expectations. RR2 (one person owning seven functions) and RR4 (metrics that will "evolve") are risk signals, and RR1 (evenings and weekends) is an always-on pattern. RR3 is the compensation mismatch against your floor. The equity is unquantified (RR5).

- **Hard gates:** failed: R1 (on-site work five days a week), R2 (base salary $70–85k) · met: none
- **Severe red flags:** none found
- **What would change this:** Both gates would have to move: on-site would have to become remote, and base would have to reach at least $150k. Fit can't offset either one. The posting's own "no exceptions" makes that unlikely.

Your sense that something was off is right. The pay sits $65–80k below your floor, the location is fixed, and the job is seven roles under one title with an always-on expectation.

## Role reality

- **Title and scope:** Head of Growth, reporting to the CEO with a dotted line to the board. Scope covers paid, SEO/content, lifecycle/CRM, brand, PR, partnerships, and sales ops `[grounded]`.
- **Team:** "A team of one to start" `[grounded]`.
- **Compensation:** $70–85k base plus unquantified equity `[grounded]`. No market band was checked, so the mismatch is against your floor only, not against the market `[generic]`.
- **Contradictions and unknowns:** "Profitable since day one" and "Series A" are unverified `[grounded]` claims from the posting. Equity size is unknown.

## Evidence map

| # | Priority | Fit | Requirement | Confidence | Gap | Provenance | Source and reasoning |
|---|---|---|---|---|---|---|---|
| R1 | hard_gate | hard_gate_fail | On-site, Austin, five days a week | high | hard-gate | [grounded] | Posting: "no exceptions." You: remote-only, Portland, won't relocate. |
| R2 | hard_gate | hard_gate_fail | Base at least $150k | high | hard-gate | [grounded] | Posting: $70–85k. Your floor: $150k. |
| R3 | must_have | direct | 8+ years growth leadership | medium | none | [grounded] | Your CV: 9 years, Growth lead then Head of Growth. Self-reported, no artifacts. |
| R4a | must_have | direct | Revenue growth via paid acquisition and lifecycle/CRM | medium | none | [grounded] | Your CV: owned paid, lifecycle, experimentation. |
| R4b | must_have | unclear | SEO/content, brand, PR, partnerships, sales ops | low | capability | [grounded] | Not in your CV. |
| R5 | must_have | adjacent | Team of one to start, no bench | medium | transferability | [inferred] | Your CV shows teams of 3–7 built and managed. No solo-operator example. |
| R6 | important | unclear | Thrives on ambiguity; metrics evolve | low | transferability | [inferred] | Your $8M→$40M ARR scale-up with budget control is evidence of scale, not of ambiguity. |
| R7 | important | direct | Scaled revenue growth | medium | none | [grounded] | Your CV: $8M→$40M ARR over three years with a budget you controlled. |

## Gap recovery queue

- **R4b:** Five of the seven functions have no evidence in your CV. Closing this would need your own examples in SEO/content, brand, PR, partnerships, or sales ops.
- **R5:** Solo-builder evidence. Closing it would need an example of building a function from zero alone.
- **R6:** Evidence of operating under unclear success metrics.

These gaps do not change the decision. The gates decide it.

## Opportunity risk register

- **RR1 — Always-on expectation** (`risk_signal`, `severity: medium`). Quoted: "evenings and weekends when it matters is just who we are." Hypothesis: the hours are open-ended `[inferred]`. Verification question: "What does a typical week look like for this role, and how often are evenings and weekends required?"
- **RR2 — Responsibility without authority or resources** (`risk_signal`, `severity: medium`). Quoted: "Own all revenue growth end to end," with "a team of one." Hypothesis: you could be accountable for outcomes without budget or decision rights `[inferred]`. Verification question: "What budget and decision rights does this role hold on day one?"
- **RR3 — Compensation mismatch against your floor** (`red_flag` for this candidate, `severity: medium`). Quoted: "$70–85k base." Hypothesis: the stated range is below your $150k floor. It is already a hard gate (R2), so this entry adds no new condition. Market band: not checked `[generic]`. Verification question: "Is the base range negotiable, and is there any version of this role at $150k or above?"
- **RR4 — Success metrics not defined** (`risk_signal`, `severity: medium`). Quoted: "success metrics will evolve as we learn." Hypothesis: accountability without a fixed definition of success `[inferred]`. Verification question: "What are the three metrics you'll judge this role on at 90 days?"
- **RR5 — Equity unquantified** (`unknown`). Quoted: "meaningful equity upside." Verification question: "What percentage of the company does the equity represent, on what vesting schedule, and at what strike price?"
- **RR6 — Employer not verified** (`unknown`, `status: unresolved`). Web search was refused, so I could not confirm that Novaline exists as described or that the posting is live. This records that the check did not run. It is not a finding that the employer is absent. Verification question: "Can you point me to the live posting on your careers page?"

## Application plan

Under `no_go`, no application plan is recommended on these terms. If you want to test whether the terms can move, send one question to the recruiter (see the question below). Don't spend application effort before you have an answer.

## Evidence status

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | Reason |
|---|---|---|
| 1. Company official site and careers page | unavailable | Web search permission denied by the host. No search ran. |
| 2. Role-family sweep (title, scope, compensation) | unavailable | Same. Market band not calibrated. |
| 3. Hiring manager's public footprint | n/a | No hiring manager named in the posting. |

No user links were read.

## Upgrade menu

- **Web search access:** would verify whether Novaline exists as described, whether the posting is live, and what the market band is for a Head of Growth at this stage. It would not change the `no_go` on the gates, since those rest on the posting's own terms.
- **The live posting link or Novaline's careers page:** would settle RR6.
- **Equity terms:** would replace RR5 with figures.
- **Your evidence in R4b and R5:** would move those rows from `unclear` to something you can defend in an interview. It would not change the decision.

If you want the full write-up saved for later, I can produce `tuesday-dossier.md` from this assessment.

Do you want me to draft a message to Novaline asking whether remote work and a base at or above $150k are open to negotiation? I'd send nothing until you approve the wording.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.