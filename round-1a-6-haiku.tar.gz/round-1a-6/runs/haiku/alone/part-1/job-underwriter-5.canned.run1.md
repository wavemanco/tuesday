**Yes, worth applying to, on conditions: `conditional_go`.** Your dbt, Airflow and data-testing experience maps directly onto the requirements. The open items are the location and pay checks, which I can't settle without your constraints, and the scope of the role.

**Fit ledger.**

- `hard_gate` — unclear: R1 (Remote (US) or Denver office), R2 (Salary $148,000–$166,000 plus equity)
- `must_have` — direct: R3 (5+ years data engineering), R4 (strong SQL and Python), R5 (dbt and a cloud warehouse), R6 (orchestration with Airflow), R7 (data quality testing)
- `important` — adjacent: R8 (BigQuery warehouse); unclear: R9 (data contracts for analysts), R10 (ingestion from app and CRM)

R8 is Snowflake against BigQuery, limit named. R9 and R10 are not yet in your account.

**Opportunity ledger.** The posting is live on the company's own careers page and matches the text you pasted (RR4, RR5). Open on scope and team: three areas in one role, and no team or hiring manager named (RR1, RR2). No severe red flags.

- **Hard gates:** none failed; unconfirmed: R1 (Remote (US) or Denver office), R2 (Salary $148,000–$166,000 plus equity); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **Conditions for go:** (1) your location and pay floor fit R1 and R2; (2) RR1 and RR2 check out as a single-owner role with a clear team; (3) R8 is framed as transferable Snowflake experience, not BigQuery experience.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning, live online tutoring for K-12 schools in 31 US states; founded 2016, Denver; 264 employees; Series C ($52M, February 2026) | `[grounded]` company About page (search snippet) |
| Mandate | Build and run ingestion from app and CRM, a dbt-modelled BigQuery warehouse, and analyst data contracts | `[grounded]` JD and careers page (fetched) |
| Scope read | Three domains in one post. The usual Senior scope is ownership of one domain's pipelines, so this reads broader | `[generic]` Datawright report scope norm; `[inferred]` from the JD's three areas |
| Market calibration | Posted $148k–$166k sits around the $151k median; the top end is above the $163.5k IQR top. Equity is extra | `[generic]` band from the Datawright report you supplied (not checked by me); `[grounded]` posted range |
| Unknowns | Team size, reporting line, whether the warehouse is migrating to BigQuery, contract type, equity size | — |
| Contradictions | None between the JD and the careers page | `[grounded]` fetched page |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | Your location isn't in the intake, so the gate is not settled | `[grounded]` JD; no candidate location given | Your location (RR… see questions) |
| R2 | Salary $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | Your pay floor isn't in the intake | `[grounded]` JD; no floor given | Your pay floor |
| R3 | 5+ years data engineering | must_have | direct | medium | none | Six years at a B2B payroll company, self-reported. No artifact yet | `[grounded]` your intake | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | Daily use, self-reported | `[grounded]` your intake | none |
| R5 | dbt and a cloud warehouse | must_have | direct | medium | none | ~180-model dbt project on Snowflake, self-reported | `[grounded]` your intake | none |
| R6 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow in production, self-reported | `[grounded]` your intake | none |
| R7 | Experience with data quality testing | must_have | direct | medium | none | Set up a Great Expectations suite, self-reported | `[grounded]` your intake | none |
| R8 | BigQuery warehouse (named in the role description) | important | adjacent | medium | transferability | Snowflake carries over to BigQuery. Limit: you've never used BigQuery | `[grounded]` intake; `[inferred]` transfer from Snowflake | See G1 |
| R9 | Data contracts analysts depend on | important | unclear | low | discovery | Not in your account. Could exist under another name | `[grounded]` JD silence on your side | See G2 |
| R10 | Ingestion from app and CRM | important | unclear | low | discovery | Not in your account | `[grounded]` JD silence on your side | See G3 |

Rows R3–R7 are your own statements, capped at `medium` because they are unprobed intake. The fit is `direct` on your word alone.

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R8, important) | transferability | Snowflake dbt work; no BigQuery | Likely the first technical probe | Any cloud-warehouse cost, partitioning or access-control work; any BigQuery training project | A sample model or config from any warehouse | `[inferred]` Snowflake-to-BigQuery transfer; `[generic]` that this is the likeliest probe |
| G2 | Data contracts (R9, important) | discovery | Nothing in your intake | An analyst-facing responsibility named in the JD | Schema agreements with analysts; a published table definition; a breaking-change process | A contract file, schema doc or review note | `[grounded]` JD silence |
| G3 | CRM and app ingestion (R10, important) | discovery | Nothing in your intake | A named responsibility, and the one that would decide the scope read | Connectors or syncs from Salesforce, HubSpot or a product database | A pipeline diagram or DAG list | `[grounded]` JD silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Three domains in one Senior role | risk_signal | low | "ingestion from our app and CRM, a dbt-modelled warehouse in BigQuery, and the data contracts" | The role may carry all three areas alone, beyond the usual one-domain scope | `[generic]` Senior scope norm; `[inferred]` from the JD's three areas | Which of these three areas does this role own end to end, and who else works on them? | unresolved |
| RR2 | No team or hiring manager named | unknown | — | (no hiring manager named) | Team size and reporting line are unknown | `[grounded]` posting silence | Who would I report to, and who is on the data team? | unresolved |
| RR3 | BigQuery named, migration status unstated | unknown | — | "a dbt-modelled warehouse in BigQuery" | The warehouse may be on BigQuery already or may be migrating to it | `[inferred]` from the JD wording | Is the warehouse already on BigQuery, or is a migration planned? | unresolved |
| RR4 | Pay range stated | positive_signal | — | "Salary $148,000–$166,000 plus equity" | Transparent pay with a range set near the market median | `[grounded]` posted range; `[generic]` band | Is the range set for this level, and how is equity sized? | noted |
| RR5 | Company footprint consistent | positive_signal | — | "Series C ($52M, February 2026)" | Funded, sized and described the same on the posting and the About page | `[grounded]` careers page and About page | none | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Lead the CV with dbt on Snowflake, Airflow and the Great Expectations suite | Direct evidence for R3–R7 | `[grounded]` intake | pending your approval |
| A2 | Frame BigQuery as adjacent, with the limit named | Honest version of R8 | `[grounded]` R8 row | pending your approval |
| A3 | Confirm location and pay floor before investing in the application | R1, R2 are unconfirmed | `[grounded]` decision snapshot | pending your approval |
| A4 | Ask RR1–RR3 in the first screen | Settles scope and team | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Your claims are intake self-report, capped at `medium`.

Research tier: L1 — searches 1 of 5, fetches 1 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Pellucid Learning online tutoring K-12 Series C Denver", which returned the About page (snippet only, not fetched). Fetched "Senior Data Engineer — Pellucid Learning careers" (pellucidlearning.com/careers/senior-data-engineer): live, text matches your pasted JD. Contradictions row: none |
| 2. Role-family sweep | skipped | The Datawright 2026 report you supplied already fixes the band this output reads from |
| 3. Hiring manager's public footprint | n/a | No name given |

## Upgrade menu

- A sample dbt model, data-quality config or pipeline diagram → R3–R7 to `high`
- Any BigQuery exposure (a project, a course, a sample query) → R8 closes or narrows
- Anything on CRM ingestion or data contracts → R9 and R10 move off `unclear`
- Your location and pay floor → R1 and R2 resolve
- The hiring manager's name → the scope read in role reality
- A deeper research pass on Pellucid (funding, leadership changes, hiring patterns; up to 5 more searches and 2 more fetches) — say the word and I'll run it.

Dossier offer: I can write `tuesday-dossier.md` from this assessment, so the mock-interview skill can rehearse RR1–RR3 later.

**Questions**

- R1, R2 — Where are you based, and what is your base-pay floor?
- R9, R10 — Have you built ingestion from a CRM or product app, or defined data contracts analysts relied on? What did you own?
- RR1 — Does this role own all three areas, and who else is on the data team?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.