**Decision: conditional_go.** Fit and opportunity are scored separately below.

**Decision snapshot**

- **Candidate fit:** Strong on years, tooling and query skills. Partial on forecast ownership. Missing on billing and finance data, which the posting lists as a requirement.
- **Opportunity:** Bristol hybrid (two days a week in office), £61,500–£67,000 plus share options [grounded]. The role adds ownership of billing data and a quarterly forecast run with the CFO [grounded]. The employer is unverified.
- **Hard gates:** Location, right to work and pay floor are unknown. None has failed. You haven't stated any other non-negotiables.
- **Why conditional, not go:** Two of five must-have requirements are gaps, and the employer hasn't been checked.

**Role reality**

- Title: Revenue Operations Lead, Quillfield, Bristol, hybrid [grounded].
- Stated scope: own CRM and billing data; build pipeline and renewal reporting for sales and finance; run the quarterly revenue forecast with the CFO [grounded].
- Scope read [inferred]: this is a step up from sales operations toward finance-facing ownership. The forecast and billing duties are the new part.
- Market calibration: not run. The salary band can't be checked against role-family norms without research (see upgrade menu).

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Evidence |
|---|---|---|---|---|---|---|
| 1 | 4+ yrs RevOps / sales ops / analytics at a B2B software company | Must-have | Meets on years; sector adjacent | Medium (CV-stated) | Transferability | 5 yrs sales ops, last 2 running UK RevOps, at a B2B payments company |
| 2 | HubSpot or Salesforce administration | Must-have | Meets | Medium (high once the cert is checked) | — | Salesforce admin certified; rebuilt pipeline and renewal dashboards |
| 3 | Strong SQL and spreadsheet modelling | Must-have | Meets on SQL; modelling not stated | Medium | Presentation | SQL weekly, Excel daily |
| 4 | Experience owning a forecast | Must-have | Gap | Low | Capability, with adjacent evidence | Runs the monthly pipeline review with the sales director. Finance owned the company forecast. |
| 5 | Experience working with finance on billing or revenue data | Must-have | Gap | Low | Capability | No billing data work stated |

**Gap recovery queue**

- **Row 4:** Adjacent evidence exists in the pipeline review. Closing it needs evidence that you built or fed forecast inputs (stage weighting, commit calls, renewal forecasts), not just attended the review.
- **Row 5:** Nothing in the background touches this yet. Only real experience with finance on revenue or billing data closes it. Reconciling renewals or bookings against invoices with finance would count if it happened.

**Opportunity risk register**

- **Employer unverified** (standing entry, severity medium). I haven't confirmed that Quillfield exists as described, that this posting is live on its own site, or that Tamsin Achebe is the hiring manager. Possible reasons, none ranked as likely: the company is too new or small, the posting is stale, or the employer isn't actually hiring. This caps a go at conditional_go until verified. To resolve it: the company's own careers page, the recruiter's email domain, or the direct link to the live posting.
- **Pay unverified** (medium). £61,500–£67,000 is stated, but it hasn't been calibrated against the market or your floor.
- **Scope step-up** (low). The role owns billing data and a CFO-facing forecast on top of pipeline work. Ask whether these are expected from day one or grown into.
- **Location and right to work** (unknown). Bristol, two days a week in office. Not checked against your situation.
- No red flags in the posting itself. It asks for no payments, deposits or bank details.

**Application plan (evidence-limited)**

- **Lead with:** five years of sales operations, two running UK revenue operations, Salesforce certification, the pipeline and renewal dashboards you rebuilt, and weekly SQL. All of these are in your own account and are checkable.
- **On the forecast:** describe what you did, such as "run the monthly pipeline review with the sales director." Don't say you owned forecasting; finance did.
- **On billing data:** don't claim it. Name the gap and say how you'd get up to speed. If you have worked with finance on renewals or bookings, say that specifically.
- **External wording:** nothing is proposed for sending yet. Any CV or outreach text will come back for your approval first.

**Evidence status**

Research tier: L0 — no searches; user links read 1

| # | Target | Status | Reason |
|---|---|---|---|
| 1 | Company site and careers page | skipped | Not run; offered in the upgrade menu |
| 2 | Role-family sweep (scope, title, pay) | skipped | Not run; offered in the upgrade menu |
| 3 | Hiring manager's public footprint | skipped | Not run; the name came from the recruiter only |

Everything above is from the posting or your background, and CV-stated claims are unverified.

**Dossier offer:** I can save this assessment as `tuesday-dossier.md` so you can pick it up later.

**Upgrade menu**

- **Research at L1** (up to 5 searches and 2 page fetches): checks that Quillfield exists as described and that the posting is live on its own site, calibrates the salary band against role-family norms, and looks at the hiring manager's public professional footprint. This resolves the employer risk and the pay check.
- **Your CV as a document:** turns the CV-stated claims into checkable ones and firms up rows 1–3.
- **Salesforce certification record:** would move row 2 to high confidence.
- **Any forecast inputs or billing-adjacent work:** the only thing that closes rows 4 and 5.
- **Location, right-to-work status and pay floor:** closes the hard-gate checks.

**Questions**

1. **Hard gates (location, pay):** Can you work in Bristol two days a week, and is £61,500–£67,000 plus share options at or above your floor?
2. **Row 4 (forecast):** Have you ever supplied inputs to a forecast someone else signed off, such as stage-weighted pipeline, rep commit calls or renewal forecasts? If so, what did you build and who used it?
3. **Row 5 (billing/finance):** Have you worked with finance on any revenue data, even partly, such as reconciling renewals or bookings against invoices?

Reply to the questions, say "skip" for any you'd rather not answer, or ask for the L1 research to run.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.