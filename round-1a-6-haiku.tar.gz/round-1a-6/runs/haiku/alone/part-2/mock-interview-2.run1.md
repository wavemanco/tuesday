Your prep pack is saved as /tmp/claude-0/-var-tmp-tuesday-measure-1a6-runs-haiku-alone-part-2-rooms-case-2-denied-65871f85/7cd0d26f-a748-4d6a-876a-f58dc1769233/scratchpad/atlas-freight_operations-manager_interview_pack.md, and I've sent it to you. I built it for a hiring-manager round, since your note didn't say who you're meeting.

The pack's main points:
- **Biggest gap:** the JD asks you to lead 12 supervisors and run four sites, and your material shows 3 supervisors at one site. Expect that to be the first thing probed. Rehearse it until you can state the gap plainly and say what you'd do in the first 90 days.
- **Power BI:** say "I haven't used Power BI" plainly, then describe how you'd learn it as a plan, not as experience.
- **The 40% mis-pick figure:** be ready to explain how it was counted, the baseline, and the assumption you'd defend least.
- **Things to avoid:** don't stretch "solid Excel" into "built reporting," or "3 supervisors" into a team of 12. The pack's prohibited-claims section lists these.

Web search was refused in this session, so the pack has nothing on Atlas Freight's values, interview process or recent news. If you can grant search permission, I can add those.

Say the word and I'll play the Skeptic on the 12-supervisor question, the pack's highest-ROI prep. I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

Is the person you're meeting your future manager, or a peer on the team? The answer reweights every bank.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: atlas-freight_operations-manager_interview_pack.md -----
# Atlas Freight: Operations Manager interview pack

Role: Operations Manager, Atlas Freight (regional logistics, 800 employees). Interviewer: not named. Round: built as a hiring-manager round, since your note didn't say who you're meeting. Changed: first session, nothing to regenerate yet.

## How to use

- **Personas** describe how a question is asked. **Types** describe what is being scored.
- Type key: **EXP** work-experience deep-dive (what you actually did). **JD** the job's own responsibilities and requirements. **CASE** a live problem from the role. **VAL** behavioural, a decision under pressure. **CO** company knowledge (none in this pack; see Sources).
- Guidance is scaffolding, not a script. Aim for 90 to 120 seconds spoken.
- An **answer slot** is an instruction for the interview: it asks you to say what actually happened, and it has an honest branch for when it did not happen. It is not a question to me.

## Research status

Web search was not permitted in this session, so this pack is built only from your JD and your background note. It contains no claim about Atlas Freight's values, interview loop, strategy or recent news. Those are listed in the upgrade menu.

## The fit snapshot

Every requirement is quoted from your JD. Every evidence quote is a sentence or fragment from your message, verbatim.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" (JD) | "currently a senior shift manager over 3 supervisors" (your message); "7 years in warehouse and distribution ops" (your message) | medium | [grounded] | transferability | Your material shows a shift and a site's operations, not four sites or a terminal, and the pack should not stretch it. Bridge at its own scope: "I'm currently a senior shift manager over 3 supervisors, and I have 7 years in warehouse and distribution ops." Answer slot: if you have been accountable for daily operations across more than one site, say how many and how you ran the daily rhythm; if you have not, say so, and say how you would bring that rhythm across four sites. |
| F2 | "drive on-time performance and cost-per-shipment down" (JD) | "cut mis-pick rate 40% by redesigning the pick path" (your message) | medium | [grounded] | transferability | Your material shows a picking-accuracy measure, not on-time performance or cost per shipment. Bridge: "I cut the mis-pick rate 40% by redesigning the pick path." The 40% raises the defend-the-number questions in C1. |
| F3 | "lead a team of 12 supervisors" (JD) | "currently a senior shift manager over 3 supervisors" (your message) | medium | [grounded] | transferability | Three supervisors is the scale your material shows, not twelve. Bridge: "I lead three supervisors now." Answer slot: if you have led more supervisors or a larger group before, say how many and when; if not, say so, and say how you would build a team of twelve. |
| F4 | "5+ years operations leadership required" (JD) | "7 years in warehouse and distribution ops" (your message); "currently a senior shift manager over 3 supervisors" (your message) | medium | [grounded] | discovery | Your material shows seven years in operations and a current leadership role, but not how long you have led people. This is an experience length, not a credential, so it is not a gate. Answer slot: say since when you have been leading people, in your own words, and whether that was in operations. |
| F5 | "build reporting in Excel/Power BI" (JD) | "solid Excel" (your message) | low | [grounded] | discovery | "Solid Excel" is a skill claim, not a reporting record. Answer slot: if you built a recurring report, say what it tracked, who used it and how often; if you have not, say so, and say which Excel report you would build first. |
| F6 | "build reporting in Excel/Power BI" (JD), Power BI part | "never used Power BI" (your message) | none | [grounded] | capability | You stated the absence. Words: "I haven't used Power BI." Then how you would learn it, said as a plan and never as a past. |
| F7 | "Lean/Six Sigma a plus" (JD) | "green belt certified" (your message) | medium | [grounded] | none | No gap. Lead with the certification in its own terms: "I'm Green Belt certified." Expect a probe on what you applied it to, since no certificate has been inspected. |

Notes on the table:

- No JD requirement here is a gate in this suite's sense. "5+ years" is an experience length, and it is graded like any other row.
- Gap type follows the evidence cell. F1 to F3 are transferability because adjacent work is shown and the direct scope is not. F4 and F5 are discovery because the material is silent on the part that matters. F6 is capability because you said so.

## Prohibited list

These are claims the pack will not coach. Each is listed with its basis, and each has the honest form that replaces it.

| Not coached | Basis | Honest form |
|---|---|---|
| Ran daily terminal operations across four sites | Inflated form of F1 | F1's quote at its own scope. The material shows a shift and a site's operations, not four sites. |
| Led a team of 12 supervisors | Inflated form of F3 | "over 3 supervisors", at its own scope. |
| Improved on-time performance and cost-per-shipment | Inflated form of F2 | "cut mis-pick rate 40% by redesigning the pick path", at its own scope. |
| Built reporting that management uses in Excel | Inflated form of F5 | "solid Excel", at its own scope. |
| Built Power BI reporting | Negative you stated (F6) | The plain acknowledgment: "I haven't used Power BI." No answer slot is attached to it. |

## Persona weights

No interviewer profile exists, so no interviewer signals apply. Relationship prior for a hiring-manager round is Case/Strategist and Skeptic, with the loop unknown, so this pack is a single session.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy | Depth |
|---|---|---|---|---|
| Skeptic | Probes the gaps: scope, team size, Power BI, "why should we believe this scales" | High. The JD's span and team size sit far from your current scope (F1, F3), and that is the first thing a hiring manager checks | Rehearse the most predictable objection until it is plain; concede the scale gap specifically; say what you would do in the first 90 days | 5 |
| Case/Strategist | A live problem on terminal performance across four sites | High. The JD is a live operating job, and a hiring manager buys the ability to run it | Clarify, then objective, segmentation, approach, metrics, risks. Think aloud | 4 |
| Data-Driven Prober | Counts the 40% and asks how it was measured | High. The 40% is your headline figure, and the JD names reporting | Say how it was counted, the period, and the weakest assumption behind it, before they ask | 3 |
| Pressure | Time-boxed challenge on how much of a result was yours | Medium. The team-of-12 gap invites it, but the relationship prior is low | Pause, restate, hold the quoted position through two follow-ups, then concede the specific limit | 2 |
| Conversational | A friendly walk through your background | Medium. Casual openers are still scored | A 90-second arc built only from your quoted sentences | 2 |
| Values/Behavioral | A "tell me about a time" prompt | Lower. No published values were available, so these prompts stay generic | Selection scaffold ending in the honest branch | 2 |

## Question banks

Provenance comes first in each row. Guidance and rationale refer to your history only by fit-snapshot row. Questions are the interviewer's lines. Answer slots are instructions for the interview.

### A. Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Your background is warehouse and distribution, and this role runs daily terminal operations across four sites. Which part would you be weakest at on day one?" | JD | [grounded] "7 years in warehouse and distribution ops" (your message); "currently a senior shift manager over 3 supervisors" (your message) | Name the scope step plainly, in your own words, and then the part you would learn first and how. Answer slot: if you have run more than one site, say so; if not, name the gap. Speak it as a plan, not a past. | F1 is the largest distance between your evidence and the JD, so this is the likeliest opening. JD because it scores the stated scope. |
| A2 | "You lead three supervisors. This role leads twelve. What's your answer to that?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" (your message) | **Highest-ROI prep in this pack.** Hold the quoted position: "I lead three supervisors now." Concede the scale specifically, not generally. Hold through two follow-ups by returning to what you do with three, never by adding to it. Answer slot: if you have led a larger group before, say how many and when; if not, say what carries over from three and what you would build for the rest of the team. | This is the objection the material is thinnest on, so it is the one most likely to be asked in some form. F3 is the row it draws on. |
| A3 | "The JD asks for Power BI. Have you used it?" | JD | [grounded] "never used Power BI" (your message) | Plain acknowledgment: "I haven't used Power BI." Then say how you would learn it, as a plan. Do not describe any Power BI work, however small. | F6 is a negative you stated, so this is the one place the plain acknowledgment carries no slot. |
| A4 | "Tell me about a time your supervisors challenged a call you made. How did it end?" | EXP | [generic] | Selection scaffold: pick a time a call you made was challenged by people who report to you. It needs a named stake, a moment you held or changed course, and what happened to the people involved. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it. | An open prompt, so it names no event. It tests how you lead the team you have, which is the closest thing the material shows to F4. |
| A5 | "You ran the peak-season plan two years running. Why would it scale to four sites?" | JD | [grounded] "ran the site's peak-season surge plan two years running" (your message) | Story-map only the quoted beats: the plan, and the two years. Answer slot: if the plan you ran covered more than one site, say so; if it covered one, say which parts would translate to four and which would not. | F1 is the scope question again, but from a strength you did show. |

### B. Case/Strategist (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "One of the four sites has seen on-time performance fall for several weeks. What do you do in your first two weeks?" | CASE | [generic] | Clarify first: which site, which lanes, which shifts. Then objective, segmentation, approach, metrics, risks. Think aloud and say one assumption you are testing. | A live problem from the JD's on-time line (F2's requirement). It names no fact about you, so it carries no provenance quote. |
| B2 | "Cost per shipment has risen this quarter. Where do you look first, and what do you measure?" | CASE | [generic] | Define the metric before you segment it. Name the buckets you would split it into and which one you would check first. | The JD's cost-per-shipment line, asked as a diagnosis. Generic, because it is a pattern for the problem and not a fact about this employer. |
| B3 | "What's the first report you would build for a site manager, and what decision would it change?" | JD | [grounded] "solid Excel" (your message); [grounded] "never used Power BI" (your message) | Name the report and the decision it would change, in general terms. If you would build it in Excel, say so; if you would need to learn Power BI for it, say that plainly. Answer slot: if you have built a recurring report before, name it and what it tracked. | The JD's reporting line. This row is where your Excel strength and your Power BI gap meet, and the interviewer will see both. |
| B4 | "Two sites share a mis-pick problem but have different pick paths. Where do you start?" | CASE | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Use your own redesign as the example of how you start, in your own words: what you measured before any change. Answer slot: if you measured a baseline before the redesign, say what it was; if you did not, say so, and say what you would measure first. | F2 is the strongest story you have that touches the JD's performance line, and the baseline is the first thing a case interviewer will ask for. |

### C. Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how you counted the 40% mis-pick reduction." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Say how it was counted, the period it covered, and whose count it was. Then name the assumption behind it you would defend least, before they do. Answer slot: if you counted it, say what the baseline was; if someone else counted it, say so. | A figure you gave raises defend-the-number questions and nothing else. F2 is the figure. |
| C2 | "Which of your numbers would you defend least, and why?" | JD | [grounded] | Name one figure, its weakest assumption, and what you would change to make it stronger. Do not offer a second figure you did not put to the test. | A Prober's standard opener. The JD's on-time and cost lines are the raising source, so the question is fair. |
| C3 | "How did you know the peak-season plan was working while it was running?" | EXP | [grounded] "ran the site's peak-season surge plan two years running" (your message) | Answer slot: if you tracked a measure during the peak, name it, its source and how often you looked. If you did not track one during the plan, say so, and say what you would track now. | A Prober checks whether the plan was measured or only remembered. A1 and A5 raise the same scope. |

### D. Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "That 40%. How much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Hold-then-concede. Hold: "I redesigned the pick path, and the mis-pick rate fell 40%." Through two follow-ups, return to the redesign. Concede the specific part that was shared, if any: answer slot. If others carried out the change, say who. | A Pressure interviewer tests whether you fold on a claim that is yours. The hold is the redesign, and the concession is the part you did not do alone, if that is true. |
| D2 | "Sixty seconds. Why should we hire a shift manager for a twelve-supervisor role?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" (your message) | Pause, restate, and answer in sixty seconds: what you do now, what carries over, and the one gap you would close first. Hold your ground on what carries over, and concede the scale gap plainly. | Time-boxed challenge on F3. It rewards composure and an honest scale concession. |

### E. Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "7 years in warehouse and distribution ops" (your message); "currently a senior shift manager over 3 supervisors" (your message) | Ninety-second arc, using only the quoted beats: the seven years, the current role, then the peak plan and the pick-path redesign. Add nothing between them. | Casual openers are scored. The arc is built only from sentences you gave. |
| E2 | "What are you actually playing with in Excel these days?" | JD | [grounded] "solid Excel" (your message) | Name what you do in Excel, in your own words. Answer slot: name the most complex thing you have built in it. If you have not built reporting, say so. | The JD's Excel half, asked casually. Still scored. |

### F. Values/Behavioral (weight 2)

No published values were available, so these prompts are generic. They have no provenance quotes because they make no claim about you.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Tell me about a time you had to give leadership a number they did not want to hear." | VAL | [generic] | Selection scaffold: pick a time you raised a bad number to someone above you. It needs a named stake, a moment you held your position, and a relationship intact at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material carries. | An open prompt. Generic because it is a pattern, not a fact about Atlas. |
| F2 | "When did you have to make a call on service or safety that cost you on the numbers?" | VAL | [generic] | Selection scaffold: pick a call where the metric and the right action pointed different ways. Name the stake, what you did, and what you would do again. If no such time comes to mind, say so plainly. | Operations hiring managers ask this to see how you trade off. Generic, same reason as F1. |

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| Own daily terminal operations across 4 sites | A1, A5, B1 |
| Drive on-time performance and cost-per-shipment down | B1, B2, B4, C2 |
| Lead a team of 12 supervisors | A2, A4, D2 |
| Build reporting in Excel/Power BI | A3, B3, E2 |
| 5+ years operations leadership required | A4, F1 |
| Lean/Six Sigma a plus | C1, since a Green Belt is the method a measured reduction like the 40% would be judged by |

Question count: 18 across six banks, within the 18 to 26 range.

## Reverse questions

Each one carries a line on why it lands. No interviewer profile exists, so none ties to a career path, and this is not a peer round.

1. "What would a stable first 90 days look like for the supervisors in this role?" Why it lands: it shows you are already thinking about the team at its full size.
2. "How do the four sites differ from each other day to day?" Why it lands: it shows you understand that terminal work varies, and it gets you the operating picture.
3. "Of on-time performance and cost per shipment, which is the harder target right now, and why?" Why it lands: it asks them to name the actual gap, which is the conversation you want to be in.
4. "What reporting do site managers use today, and what do they wish it did?" Why it lands: it shows interest in the Power BI side without claiming any experience with it.
5. "What would success look like at twelve months for this role?" Why it lands: it sets a standard you can be measured against, and the answer shows you what they are weighting.

## Sources

- Provided documents: the JD text as you pasted it in your message; your background note in the same message.
- No web search or fetch ran. Three searches were sent, and each was refused because web search permission was not granted.

Research tier: L1, searches 0 of 6 completed (3 sent, all refused), fetches 0 of 2.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Atlas Freight values | unavailable | Would have filled section 10 (values cheat sheet) if a values-style round is detected. Refused. Query: "Atlas Freight regional logistics company values" (refused) |
| 2. Atlas Freight interview process, operations | unavailable | Would have set the loop structure and the persona weights. Refused. Query: "Atlas Freight operations manager interview process" (refused) |
| 3. Atlas Freight strategy and recent news | unavailable | Would have added CO questions and a grounding brief. Refused. Query: "Atlas Freight logistics news 2026" (refused) |
| 4. Interviewer name plus company | n/a | No name was given, so there was no query to form. The interviewer read is absent. |
| 5. Representative operations manager JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions. |

No dossier was consumed.

## Upgrade menu

- The interviewer's name → a tailored reverse question, and persona weights read from their public footprint.
- Permission for web search → Atlas Freight's values, interview loop and recent news, which would add a values section, CO questions and a grounding brief.
- A short account of how many sites you have run, or how many supervisors you have led before → F1, F3 and F4 move from answer slots to grounded bridges.
- Whether you have built any recurring report, and in what tool → F5 and B3 move from answer slots to grounded bridges.
- Your CV as a file → every `[grounded]` quote can be checked against the document itself.
- The recruiter's prep email → coverage of any pre-declared deliverable, such as a presentation or take-home.
