Your prep pack is saved as /tmp/claude-0/-var-tmp-tuesday-measure-1a6-runs-haiku-alone-part-2-rooms-case-1-denied-6143c709/6bd1b317-922d-41fa-90cc-63357590ee87/scratchpad/northwind-data_senior-gtm-strategy-lead_interview_pack.md. I built it for a peer round, since you said Dan is Priya's peer on the same VP.

The pack has 22 questions across seven personas, weighted toward the Peer Evaluator and the Data-Driven Prober. It also covers the fit snapshot, a prohibited-claims list, reverse questions, and a JD coverage table.

Three things to know before you use it:

- **The biggest gap is sales ops and quota-setting.** Priya has no classic experience there, and Dan sits in sales strategy. Question D1 gets the deepest rehearsal, with the honest bridge from her volume-target work.
- **Every quote is from your message, not a CV.** Your message is a summary, so the wording is the summary's. Uploading her CV would tighten the answers.
- **Research ran at L0.** The one web search for Dan's public footprint was refused at the permission prompt, so the interviewer read uses only what you told me.

Offers, one line each:
- I can play the Skeptic on D1 as a live drill.
- I can save a tuesday-dossier.md recording the gaps this prep exposed.
- I can convert the pack to Word (.docx).

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: northwind-data_senior-gtm-strategy-lead_interview_pack.md -----
# Priya: Senior GTM Strategy Lead, Emerging Products, Northwind Data

Interviewer: Dan Kovac, Director of Sales Strategy. Relationship: peer (same VP). Format: single 60-minute conversation.
Changelog: first build.
Evidence note: every quote below is from your message, not a CV. Your message is a summary, so the quoted wording is the summary's. Swap in your CV's own sentences when you can (upgrade menu).

## 1. How to use, and the type key

Personas describe how a question arrives. Types describe what it scores. Guidance is scaffolding, not a script. Rehearse the honest branch of every answer slot as readily as the strong one.

| Tag | Name | What it scores |
|---|---|---|
| VAL | Behavioral / values | Whether past behavior shows a published company value. No published values were provided, so none are tagged VAL |
| EXP | Work-experience deep-dive | Whether what is on the CV survives scrutiny, and what you actually did |
| JD | Role / JD-driven | Whether you can do the listed job, gaps included |
| CO | Company and strategy | Homework depth on the company's own strategy. No research ran, so none are tagged CO |
| CASE | Live problem | Structure and reasoning on a problem from the role, delivered live |

## 2. Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" (JD highlights) | "built a partner-level revenue model used in carrier negotiations" (your message) | medium | [grounded] | transferability | Your material shows a revenue model and where it was used, not GTM ownership of a product line. Say the model in your words, at its own scope: "I built a partner-level revenue model used in carrier negotiations." Answer slot: the JD's own line makes a probe on GTM ownership likely. If you owned go-to-market decisions for a launch, say which and how you decided; if you did not, say so and describe how you would build the plan. |
| F2 | "identify whitespace across land/adopt/expand/renew" (JD highlights) | "set annual volume targets with cross-org consensus" (your message) | medium | [grounded] | transferability | Target-setting is adjacent to whitespace work, not the same thing, and the quote does not show lifecycle whitespace. Words: "I set annual volume targets with cross-org consensus." Answer slot: if you found where volume was unclaimed across the customer lifecycle, say how; if target-setting was the nearest step you took, say so. |
| F3 | "run independent analysis in SQL and Tableau" (JD highlights) | "skilled in SQL/Tableau" (your message) | medium | [grounded] | none | The quote reaches the requirement in the tools' own terms. Medium because it is self-described with no artifact, so expect a probe. Say it in your words, then be ready to walk one piece of work. |
| F4 | "partner-motion design experience required" (JD highlights) | "built a partner-level revenue model used in carrier negotiations" (your message) | medium | [grounded] | transferability | Carrier negotiations are partner-facing commercial work. The quote does not show partner-motion design, meaning how a partner program is structured and run. Keep to the model and the negotiations. Answer slot: if you shaped partner terms, incentives or program structure, say which and how; if the model was an input to a negotiation and not the design of a motion, say so. |
| F5 | "strong cross-functional influence" (JD highlights) | "set annual volume targets with cross-org consensus" (your message) | medium | [grounded] | presentation | The quote already reaches influence in other terms: consensus across orgs. Reword only that quote and add nothing: "the targets were set with cross-org consensus." Answer slot: if the orgs disagreed, say how it was resolved; if they did not, say so. |
| F6 | "AI experience a plus" (JD highlights) | "uses AI tools daily" (your message) | medium | [grounded] | transferability | Daily use is adjacent to AI work. The quote does not show building or launching AI features. Say the use: "I use AI tools daily." Answer slot: if you have built or shipped anything with AI, say what and your part in it; if not, say so and stay with how you use the tools. |
| F7 | Headline metric on the CV; no JD requirement (your message) | "proposed a store-surface change credited with a ~$400M ARR uplift" (your message) | medium | [grounded] | discovery | The material does not show how the figure was counted. Words: "I proposed a store-surface change; it is credited with a ~$400M ARR uplift." Answer slot (defend-the-number): how the uplift was counted, the assumption you would defend least, and which part was yours. Say only what you know. |
| F8 | Sales-side planning: sales ops and quota-setting, unquoted prose drawn from the interviewer's title and the JD's land/adopt/expand/renew line (inferred) | "No classic sales-ops or quota-setting experience" (your message) | none | [grounded] | capability | A gap wording cannot close, and you stated it. Words: "I haven't done classic sales ops or quota-setting." Then how you would learn it, as a plan and never as past work. Never claim quota or sales-ops work. |

Rules the table enforces: the evidence cell holds your sentences only. The gap type follows the evidence, not the writer's sense of the row. F8 is the largest gap in the pack, and it is also where the interviewer's own job sits.

## 3. Prohibited claims

Not coached in any cell, with its basis and its honest form:

| Not coached | Basis | Honest form |
|---|---|---|
| "I owned go-to-market for a product line" | Inflated form of F1 | F1's quote at its own scope. The limit is my observation: your material says a model used in negotiations, not a GTM you owned. B4 and D2 stay inside the model. |
| "I designed the carrier partner program" or any partner-motion ownership | Inflated form of F4 | F4's quote at its own scope. The material says a model used in negotiations. |
| "I drove the ~$400M" or "the uplift is mine" | Inflated form of F7 | The quote's own words: "proposed", "credited with". E2 asks what part was yours. |
| "I set quotas" or "I ran sales ops" | Negative you stated, F8 | Plain acknowledgment: "I haven't done classic sales ops or quota-setting." No slot. |
| "I'm an expert in SQL and Tableau" | Inflated form of F3 | "skilled in SQL/Tableau" at its own scope. |
| "I built AI features" or "I led AI work" | Inflated form of F6 | "uses AI tools daily" at its own scope. |

## 4. Grounding brief (from your research note; not checked against any current source)

- Stated priorities: enterprise expansion; "AI copilot launch ('Compass')"; reaching profitability. [grounded] Your research note.
- Main competitive threat: "main competitive threat is bundling by a much larger platform vendor." [grounded] Your research note.
- Use: do not recite this list. Everyone prepared will have the same list. Bring one shared item, enterprise expansion, to show you read the company, then one divergence of your own. Keep it to your own view of which motion the bundle hits first, with reasons.
- Stale-framing check: I could not verify any of these against a current source (see Sources). Treat them as your notes.

## 5. Reading the interviewer

Public footprint only, as you described it. I did not search for him.

- Career pattern: a pricing and monetization spine, with one early-stage-startup chapter.
- Self-described: "relentlessly data-driven."

Implications:
1. The Prober's weight is up. Every number you give will be taken back to its assumptions, so the pack has two Prober banks.
2. His native language is pricing, packaging and unit economics. Case questions and the revenue-model questions lean that way.
3. The startup chapter means builder stories land with him, and expect scrappiness probes on big-company pace. Your material has no startup chapter; do not claim one.

Mirror opportunity: a shared professional domain, revenue modelling. F4's quote is the sentence to use: "built a partner-level revenue model used in carrier negotiations." It is a shared domain, not a shared path. There is no shared career jump to offer.

## 6. Persona table

| Persona | How it shows up here | Weight and reasoning | Counter-strategy | Questions |
|---|---|---|---|---|
| Peer Evaluator | Seams between your team and his, credit-sharing, what you would need from him | 5. Peer is the prior for this persona, and the same VP makes the seam question likely | Reciprocity first; propose seam principles, not a seam you have not seen; disagreement with spine and tact | A1 to A5 |
| Data-Driven Prober | Denominators, assumptions, depth of any analysis you name | 5. Prior for a peer probing pricing, raised by his self-description | Name your weakest assumption before he does; walk any analysis end to end; say plainly when you do not know how a figure was counted | B1 to B5 |
| Case / Strategist | Pricing or GTM problems from the role | 3. Lower under a peer prior; raised by his pricing spine | Clarify, objective, segmentation, approach, metrics, risks; challenge one premise out loud | C1 to C3 |
| Skeptic | The sales-ops and quota gap; the GTM ownership gap; the partner-design gap | 3. Medium. The peer prior is low, but F8 is large enough that a peer will ask | Calibrated candor; bridge only from what you stated; no bluffing a skill you lack | D1 to D3 |
| Pressure / Stress | Time-boxed interruption on the $400M figure or the "why you" | 2. Low for a peer. Kept so composure is rehearsed | Pause, restate, hold through two follow-ups, then concede exactly one thing | E1, E2 |
| Values / Behavioral | Cross-functional stories, since no published values were detected | 2. Low. No values-style round was detected | Selection scaffold ending in its honest branch; "I" for your contribution | F1, F2 |
| Conversational | A casual opener and a casual question on AI | 2. Low, but casual questions are still scored | 90-second arc; treat the AI question as scored | G1, G2 |

Total: 22 questions. Top-weight personas get 5, mid-weight 3, low-weight 2.

## 7. Question banks

Provenance comes first: the sentences the guidance rests on, quoted. Question type is in the Type column.

### A. Peer Evaluator (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Our teams sit side by side. Where's the seam between your work and mine, and what happens when we disagree?" | JD | [grounded] "set annual volume targets with cross-org consensus" (your message) | Reciprocity first: name what you bring to his team, not only what you need. Propose seam principles, such as who owns the target and who owns the data, rather than a seam you have not seen. For disagreement, use the cross-org consensus only as far as the quote goes. Answer slot: if the orgs disagreed, say how it resolved; if they did not, say so. 90 seconds. | F5 is the only cross-functional evidence you have. Peer prior puts seam questions first. |
| A2 | "How do you handle credit when work spans teams?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (your message) | Say what you proposed, and that the credit is shared. Answer slot: if you know how the credit was split, say how; if you do not, say so plainly. Do not claim a share. | F7 is the figure most likely to draw a credit probe from a peer. |
| A3 | "What would you need from my team in the first month to make this work?" | JD | [generic] | Ask for something specific: a named data owner, a decision forum, the inputs his team already keeps. Make no claim about his team's practice. | Reciprocity question; the peer-evaluator stem. No candidate claim, so the label stands alone. |
| A4 | "When two teams want the same decision, how do you decide who owns it?" | JD | [generic] | State a principle: decisions follow the data owner and the revenue at stake. Then name the escalation you would use. | Seam-splitting between peers. Tests the influence requirement without asserting past events. |
| A5 | "Which parts of GTM for the new lines should sit with sales strategy, and which with product?" | JD | [inferred] from the JD line "own GTM strategy for two new product lines" | Propose a decision-rights principle and one concrete handoff. Say what you would want from his team to make it work. No claim about your past. | F1 and the JD line put GTM ownership between two functions. Peer prior makes the seam question likely. |

### B. Data-Driven Prober (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Walk me through how that ~$400M number was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (your message) | Answer slot: if you know how the uplift was counted, say it in your own words. If you do not, say so plainly. Do not offer a counting method you were not given. | F7 is the headline figure the Prober will probe first. |
| B2 | "Which assumption behind that number would you defend least?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (your message) | Name the weakest assumption you know of before he does. If you know none, say so, and say what you would check first. Do not name an assumption the material does not show. | Weakest-assumption move for F7. Converts a gotcha into a credibility gain. |
| B3 | "You're skilled in SQL and Tableau. Walk me through one analysis you ran yourself, end to end." | JD | [grounded] "skilled in SQL/Tableau" (your message) | Answer slot: if you ran an analysis yourself in SQL or Tableau, walk through the question, the data, and what it changed. If the work was shared or built by others, say whose part was yours. If you have not done independent analysis in these tools, say how far you have gone. | F3 is medium: self-described, no artifact. The JD requirement is raised, so the premise is fair; the second branch allows that the analysis was not yours. |
| B4 | "Walk me through the inputs to that partner revenue model." | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" (your message) | Name the inputs you know. Answer slot: which inputs were yours to set; if none were, say so. Keep to the model and the negotiations. | F4. Upgrades F4 if you have a model walkthrough. His pricing spine makes revenue-model assumptions his first probe. |
| B5 | "What's the largest number you've got wrong, and how did you find out?" | EXP | [generic] | Pick a real error if you have one: what the number was, how it surfaced, what you changed. If you cannot recall one, say so, then describe the nearest check you run on numbers now. | Open prompt, theme from the Prober's stem. No candidate claim in the cell, so the label stands alone. |

### C. Case / Strategist (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A much larger platform vendor bundles its data tools into a suite most of our enterprise accounts already pay for. Where do you start?" | CASE | [grounded] "main competitive threat is bundling by a much larger platform vendor" (your research note) | Clarify first: what the bundle includes, which segment is exposed, what the price gap is. Then objective, segmentation, approach, metrics, risks. Challenge one premise out loud: for example, that the suite's bundle is priced to win. Pricing angle: bundled price against standalone unit economics. | Research threat. Pricing spine makes this his native case. |
| C2 | "Sketch a GTM plan for one of the two new lines for its first 90 days. What do you need to know first?" | CASE | [grounded] "own GTM strategy for two new product lines" (JD highlights) | Clarify before structuring: which line, which segment, what the target is. Then approach, metrics, risks. Name the data you would need and who holds it. | JD line, asked live. Tests structure over a "right" answer. |
| C3 | "Land volume is up and renewal is flat in one segment. Where's the whitespace across land, adopt, expand and renew, and what would you check first?" | CASE | [grounded] "identify whitespace across land/adopt/expand/renew" (JD highlights) | Clarify the segment and the definition of flat. Name the lifecycle stage you would check first and why. Say what you would not change before checking mix and price. Make no claim about your past. | JD line, live. Covers R2 for the coverage table; the case asks nothing about you. |

### D. Skeptic (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You don't have classic sales-ops or quota-setting experience. How would you set targets for this role's whitespace anyway?" | JD | [grounded] "No classic sales-ops or quota-setting experience" (your message) | Deepest rehearsal in the pack. Open with the plain acknowledgment: "I haven't done classic sales ops or quota-setting." Then the bridge from what you stated: "I set annual volume targets with cross-org consensus." Follow-up 1, "What would the targets be measured against?": "I haven't set quotas; the nearest thing I did is the volume targets, set with cross-org consensus." Follow-up 2, "How would you ramp?": name the first three things you would check, in order, and who you would check them with. Concede exactly one thing: you have not set quota. Do not state a number. | Highest-ROI prep. This is the largest gap, and it sits in his own function. Expect it in some form. |
| D2 | "Show me where you've owned go-to-market for a product line." | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" (your message) | Answer slot: if you owned GTM decisions for a launch, say which and how you decided. If you did not, say so, and return to the revenue model and what it was used for. Hold through two follow-ups by returning to the model, not by adding to it. | F1 transferability. The JD requirement raises the premise, and the second branch allows it to be false. |
| D3 | "We need partner-motion design, not partner-level modelling. How would you tell the difference?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" (your message) | Answer slot: if you shaped partner terms or program structure, say which and how. If your work was a model used in negotiations, say that plainly, and say how you would learn the design side. | F4 transferability. Tests the required skill without claiming it. |

### E. Pressure / Stress (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you, over an internal candidate?" | JD | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" (your message) | Pause, restate the question, anchor in one quoted fact: the revenue model used in negotiations. Hold through two follow-ups. Do not say anything about the internal candidate, whom you have not seen. Concede one thing: the sales-side planning gap. | Composure check under a time box. |
| E2 | "That result: how much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (your message) | Answer slot: say what you proposed. If you can split the credit, say how. If you cannot, say plainly that you cannot size your share. Hold the proposal; concede only the split. | F7. Pressure version of B1. |

### F. Values / Behavioral (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Tell me about a time you pushed back on a cross-functional plan you thought was wrong." | JD | [grounded] "set annual volume targets with cross-org consensus" (your message) | Selection scaffold: pick a time you disagreed with a cross-org plan. It needs a stake, a moment you held a view, and an intact relationship at the end. If none comes to mind, say so plainly, then give the nearest thing your material carries: the cross-org consensus behind the volume targets. Answer slot: how the consensus was reached, in your words. | JD influence line. No published values, so this is behavioral, not a values probe. |
| F2 | "When did a metric point one way and the customer the other?" | JD | [generic] | Selection scaffold: pick a time the two conflicted and say what you did. If none comes to mind, say so, then describe how you would decide. Make no claim about your past in the cell. | Behavioral stem for the influence requirement. Label stands alone. |

### G. Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey." | JD | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" (your message) | Keep to a 90-second arc: two years in consulting, nine in consumer-tech product strategy and ops, the revenue model used in negotiations, why this role. Add nothing the quotes do not carry. | Casual opener, scored as a communication check. |
| G2 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" (your message) | Name the tools you use and what you use them for, in your words. Do not describe building anything. Treat this as the AI-plus requirement, asked casually. | F6. Casual, but scored. |

### Coverage: JD requirements to questions

| Requirement | Covered by |
|---|---|
| own GTM strategy for two new product lines | A5, C2, D2 |
| identify whitespace across land/adopt/expand/renew | C3 |
| run independent analysis in SQL and Tableau | B3 |
| partner-motion design experience required | B4, D3 |
| strong cross-functional influence | A1, F1 |
| AI experience a plus | G2 |

Question type coverage: JD 13, EXP 6, CASE 3, CO 0, VAL 0. Total 22. CO is zero because research did not run, and VAL is zero because no published values were provided. The strategy material is in the grounding brief and the reverse questions instead.

## 8. Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Your path runs from pricing and monetization into sales strategy. What from pricing carried into planning targets, and what did not?" | Ties to his own path. Turns a probe into a peer conversation and shows you read him, not only the company. |
| R2 | "What could a new person do in the first month that would genuinely help your team?" | Reciprocity, the peer's question. Signals you are thinking about his load, not only your own. |
| R3 | "Where does the bundling threat land first in your segment: pricing, renewal, or expansion?" | Uses your research note and asks for his view. Differentiates you from the consensus answer. |
| R4 | "How will the AI copilot launch change what the sales team is asked to sell in the first year?" | Ties to the Compass launch and the AI-plus requirement, asked as a peer. |
| R5 | "Of the three priorities, which one carries the profitability target: enterprise expansion or the new-line land?" | Makes the company's stated priorities a decision, not a recital. |

## 9. Sources

Provided documents: your message (the JD highlights, your summary of your background, the interviewer's profile, and your research note). No CV, no dossier, no recruiter guidance.

Research tier: L0. The one L1 search was refused at the permission prompt, so the pack runs on the provided documents only.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Company values | skipped | No values-style round was detected, so the values cheat sheet is dropped. |
| 2. Interview process for the role family | skipped | Your brief states a single 60-minute conversation, which fixes the structure. |
| 3. Company strategy and recent news | skipped | Your research note supplies the priorities and the threat already. |
| 4. Interviewer's public footprint | unavailable | Would have confirmed or corrected the interviewer read, sharpened R1, and shown any recent talks and writing. Query sent and refused: "Dan Kovac Director of Sales Strategy Northwind Data". |
| 5. Representative JD | skipped | The JD highlights you supplied fix the fit snapshot and the JD questions. |

## 10. Upgrade menu

- Your CV (the document itself) → the quotes become your own sentences, not the summary's, and B1, B2 and E2 can rest on the CV's figure wording.
- Full JD text → the mid-list requirements get questions, and the coverage table shows any that still have none.
- The interviewer's public footprint (permission to search him with Northwind) → his talks and writing sharpen R1 and the interviewer read.
- A deep research pass (offered once): company strategy, his talks and writing, loop reports for the role family, recent org context. It would cost at most six further searches and two fetches, and a few minutes.
- One SQL or Tableau piece you built → B3 becomes a story to rehearse, not an answer slot.
- How the ~$400M figure was counted, if you know it → B1 and B2 become grounded answers.
- Any AI work you built or shipped → F6 and G2 gain a story.
- A tuesday-dossier.md from a prior verification run, if you have one → verified evidence in place of the summary quotes, and the strategy constraints for the weak areas.
