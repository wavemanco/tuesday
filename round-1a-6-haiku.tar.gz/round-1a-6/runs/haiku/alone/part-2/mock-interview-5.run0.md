Your prep pack is saved as `/var/tmp/tuesday-measure/1a6/runs/haiku/alone/part-2/rooms/case-5-denied-2da354b6/kelverton-rail_senior-partnerships-manager_interview_pack.md`. I built it for a panel round with Deepa as your future manager and Ross on commercials, since that's what the recruiter's email said. I had no job description and no market report, so the requirements come from the recruiter's own lines, quoted.

Research didn't run. Every web search was refused, so the pack says nothing about Kelverton's values, strategy, or either interviewer's background. Those parts are generic and marked as such.

The pack's priorities for your four hours:
- **Build the 10-minute POV first.** Pick one of the three theses, with its concession. Speak it aloud twice.
- **Rehearse B1 ("you've never sold into rail") until it's dull.** It's the objection you'll meet in some form. The honest answer is "I haven't sold into rail, and I've never carried a direct quota," then what you did carry.
- **Know how the £4M was counted before Ross asks.** Say "influenced" every time. Give a share only if you can defend it.
- **Don't claim operator-side experience.** Your sentence is "so I know the operator world from the other side," which places you on the consulting side. The pack keeps you there.

If you're offering to drill, I can play Ross's Pressure persona on D1 and push back on your answers. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions.

Three questions would sharpen it:

1. Could you paste the operator-partnerships section of the internal market report, or its headline findings? Without it, I can't check the POV's thesis against what the other candidates will likely say.
2. Do you have the job description or the recruiter's role spec? If so, the requirement rows become grounded in its own words.
3. Do you want to grant search permission so I can retry the research? If not, paste Kelverton's values page and each interviewer's public profile, and I'll use those instead.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: kelverton-rail_senior-partnerships-manager_interview_pack.md -----
# Interview prep pack: Senior Partnerships Manager, Kelverton Rail, second round

**Panel (60 min):** Deepa, VP Partnerships (your future manager), and Ross, Commercial Director.
**Format:** first 15 minutes, a short spoken POV on where you'd take operator partnerships over the next 18 months, landing on what it means for the operators themselves (no slides). Remaining 45 minutes Q&A. Ross will push on commercials.
**Research tier:** L1 ran, but every search was refused, so nothing about Kelverton, its values, strategy or the two interviewers is in this pack. Those parts are generic, and the sections that need them are marked.

---

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored.
- Type key: **VAL** behavioural / values; **EXP** your past work, tested for attribution; **JD** the role's requirements; **CO** company and strategy knowledge; **CASE** a live problem.
- Guidance is scaffolding, not a script. Say it in your own words. Where a guidance cell says "answer slot", the honest answer is either branch: what you did, or that it was not yours or did not happen.

---

## Prep triage (about 4 hours)

1. **About 90 min: build and speak the POV.** Pick one thesis from the graded-deliverable section, with its concession. Speak it aloud twice, timed. Aim for about 10 minutes, leaving room for Deepa to interrupt. Ends on what it means for operators.
2. **About 60 min: Deepa's bank (A1 to A5) and the Skeptic (B1 to B3).** B1 is the highest-return item in the pack. Rehearse it until it is dull.
3. **About 60 min: Ross's bank (C1 to C5) and the Pressure items (D1 to D3).** Start with C1 and D2: the £4M figure. Know how it was counted, which part was yours, and where the number is weakest.
4. **About 20 min: the reverse questions** and the opener E1 (90-second arc).
5. **About 10 min: your own check.** Say aloud the three sentences you will not say: that you have sold into rail, that you carried a quota, and that you ran an operator's operations.

Everything else is insurance.

---

## Fit snapshot

Requirements come from the recruiter's email, quoted, because no job description was supplied. Evidence quotes are your own sentences, from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "where you'd take our operator partnerships over the next 18 months" (recruiter's email) | "9 years in partnerships" (your message), "last 4 at a payments company running the ISV channel" (your message) | medium | [grounded] | transferability | Your material shows partnership work in payments. It does not show a partnership with an operator, and the bridge should not pretend it does. Answer slot: if you have worked with an operator directly, say how; if your partnerships have all been with other kinds of partner, say which. |
| F2 | "what it means for the operators themselves" (recruiter's email) | "so I know the operator world from the other side" (your message) | low | [grounded] | transferability | Your sentence places the operator knowledge on the consulting side, so say it from there. Answer slot: name one operator decision you saw up close, and say whose side you were on when you saw it. |
| F3 | "Ross will push on commercials." (recruiter's email) | "took it from 6 partners to 40" (your message), "roughly £4M of influenced revenue" (your message) | medium | [grounded] | transferability | The figure is influenced revenue, and the word stays. Answer slot: how the £4M was counted and which part was yours, in your own words. If you cannot say how it was counted, say so. |
| F4 | carry a direct sales quota into rail (role-family pattern, no quote, [generic]) | "Never sold into rail specifically and never carried a direct quota, only influenced revenue." (your message) | none | [grounded] | capability | A gap you stated, so the words can be yours: "I haven't sold into rail, and I've never carried a direct quota." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap smaller. |

Gate rows: none. The material shows no eligibility, location or credential gate, and no JD was supplied to check one. If the JD has one, it will need its own row.

**Reading the snapshot:** Your evidence is strong on partnership management and on the operator side from the consulting seat. It is thin on operator-side partnering and on direct revenue ownership. The pack builds on the first and does not thicken the second.

---

## Prohibited list

Claims this pack will not coach. Each has its basis and the honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Carried a sales quota or revenue target | Negative you stated (F4) | Plain acknowledgment: "I've never carried a direct quota." No slot. |
| Sold or delivered the £4M | Inflated form of F3's quote | "roughly £4M of influenced revenue", at its own scope. The pack's observation: your material says influenced, not sold. |
| Worked inside a train operator, or ran an operator's operations | Inflated form of F2's quote | "so I know the operator world from the other side", at its own scope. The pack's observation: your material places this on the consulting side. |

---

## Graded deliverable: the 15-minute POV

Recruiter pre-declared this deliverable, so it gets its own build section.

**Facts to build on:** F1 (partnership work in payments) and F2 (the operator view from the consulting side). Quoted in F1 and F2 above.

**Thesis options.** Each has a mandatory concession. Pick one you can defend under questions. The theses are generic pattern, not claims about Kelverton. They have not been checked against the company, because search was refused.

| Thesis | What it says | Concession you must say |
|---|---|---|
| T1 [generic] | Tie operator partnerships to measures the operator already reports on, such as timetable reliability, so the partnership is judged on the operator's terms. | "I don't yet know which measures your operators report, and I haven't sold into rail." |
| T2 [generic] | Build partnerships through the operator's own planning and procurement calendar, not the vendor's sales calendar. | "The people who decide may sit in a different team from the ones I'd reach first." |
| T3 [generic] | Make the commercial model share outcomes with operators, not only licence sales. | "My revenue record is influenced revenue. I would have to learn direct quota mechanics." |

**Differentiation.** The internal market report was not in this session, so no consensus answer can be checked against it. Do this before the interview if you can (see upgrade menu). Until then, the differentiation is your choice of thesis, not a fact about the market.

**Anti-pick [generic]:** Say no to a bespoke build for one operator if the product cannot be reused across operators. Say it as a judgment, with the reason.

**Requested close:** Recruiter asked for the operator's benefit. Close on the operator's next concrete decision, named in your own words. Do not invent an operator's outcome.

**Shape:** About 10 minutes spoken. Thesis first, then two supports, then the concession, then the operator close. Stop at the close.

---

## Persona table

Weights are a shown judgment. Relationship priors come first, then the panel blend. No interviewer profile was researched, so the weights rest on the round and the email alone.

| Persona | Who | Weight | How it shows up | Why this weight | Counter-strategy |
|---|---|---|---|---|---|
| Case / Strategist | Deepa | high | Live problem on operator partnerships; scores structure and clarifying first. | Hiring-manager prior, and your future manager. | Clarify, then objective, then segments, approach, metrics, risks. Name one premise you challenge. |
| Skeptic | Deepa | medium | Quiet cross-examination of the no-rail, no-quota gap. | Hiring-manager prior: they are buying capability and checking derisking. | Rehearse B1 until it is boring. Say the stated gap plainly, then the part you do have. |
| Data-Driven Prober | Ross | high | Walks through the £4M figure: counting, assumptions, your share. | Named commercials; commercial heads probe the number. | Know how each figure was counted, say when you do not know, name the weakest assumption first. |
| Pressure | Ross | medium | Interrupts on the rail gap and "how much was actually you". | Commercial head pushing; likely to test composure. | Pause, restate, hold through two follow-ups, concede a specific uncertainty. |
| Conversational | Both | low | Opening "walk us through the journey". | Opener at any panel. | 90-second arc, stop at the payments-to-operator link. |

Depth: Deepa's bank has 8 questions, Ross's has 8, and the opener has 2. Total 18.

---

## Question banks

Provenance is the first cell. Quotes are your sentences, or the recruiter's.

### Persona A: Case / Strategist (Deepa)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Take us through where you'd take our operator partnerships over the next 18 months." | CASE | [grounded] "where you'd take our operator partnerships over the next 18 months" (recruiter's email) | The POV itself. Speak the thesis, the two supports, the concession and the operator close, in about 10 minutes. Make no claim about operator relationships you have not stated. | The pre-declared deliverable. CASE, delivered live. |
| A2 | "What would you need to know about our operators in the first month before committing to a plan?" | CASE | [generic] | Clarify first: which operators, what they report on, who decides. Say the list aloud. Do not assert any fact about Kelverton's operators. | Case persona scores clarifying before structuring. |
| A3 | "Which operator would you start with, and why?" | CASE | [generic] | State a criterion you could test, such as where scheduling is causing the most pain, and say what you would check first. You do not know their book, so say so. | Forces a choice with a stated reason, not a list. |
| A4 | "What does this mean for the operators themselves?" | JD | [grounded] "what it means for the operators themselves" (recruiter's email) | Land on one operator outcome in the operator's terms, then one measure you would ask them to commit to. Answer slot: name one operator decision you saw up close and whose side you were on. | F2 is the evidence and the likeliest place for a relationship probe. Recruiter named this line. |
| A5 | "Where does this plan break?" | CASE | [generic] | Name the biggest risk in the plan and give one concession from the POV. Do not wait for the question to end before answering. | Case personas test whether you can name your own weak point. |

### Persona B: Skeptic (Deepa)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've never sold into rail. Why would an operator take a call from a partnerships person without that?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." (your message) | **Highest-return item in this pack.** Hold, then concede. Opening: "I haven't sold into rail, and I've never carried a direct quota." Then the part your material carries: "bus and light rail network planning" (your message). Answer slot: say whose planning work it was, in your own words; if it was for another kind of client, say that. Hold through two follow-ups by returning to what you did. Concede one specific: name what you would learn first, and from whom. | F4 is the stated gap, and this objection will be raised in some form. Rehearse the non-defensive version until it is ordinary. |
| B2 | "Your background is partnerships in payments. What does a payments partner programme have in common with a rail operator?" | JD | [grounded] "9 years in partnerships" (your message), "last 4 at a payments company running the ISV channel" (your message) | Name one mechanic that carries over, such as partner onboarding or joint pipeline reviews. Give the limit: rail procurement and regulation work differently [generic], and you have not worked inside them. Answer slot: if the ISV channel had a joint pipeline review, say how it ran; if it did not, name the nearest equivalent. | F1: the evidence is partnership work, and the bridge is a mechanic, not a claim. |
| B3 | "Consulting on the network side is not the same as partnering with operators. What did you actually do with operators?" | EXP | [grounded] "so I know the operator world from the other side" (your message) | Say what the consulting work was, in your words, and whose side you were on. Do not claim operator-side work. Answer slot: name the client the planning work was done for. | F2's relationship risk: a consultant is not an operator, and this interviewer will know the difference in one sentence. |

### Persona C: Data-Driven Prober (Ross)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the £4M of influenced revenue was counted." | EXP | [grounded] "roughly £4M of influenced revenue" (your message) | Defend the number: how it was counted, in your own words; the assumption you would defend least, named before they ask; which part was yours. Answer slot: if you cannot say how it was counted, say so. Do not supply a method. | F3. The defend-the-number slots for this figure. Ross will push commercials here. |
| C2 | "What share of that £4M would you put on your own work, and how do you know?" | EXP | [grounded] "roughly £4M of influenced revenue" (your message) | Give a share only if you can defend it, and say how you arrived at it. If you cannot, say that you would rather not put a number on it. | Premise is the figure only, not a split. The answer is your own. |
| C3 | "You took the partner count from six to forty. What does that number tell you, and what doesn't it?" | EXP | [grounded] "took it from 6 partners to 40" (your message) | Say that a partner count is an input, not an outcome. Name the weakest assumption in the count, such as what "partner" meant. Answer slot: if you tracked which partners were active, say so. | A headline count is the second place a prober presses. |
| C4 | "On a rail contract, what does a partner-influenced deal look like?" | JD | [generic] | Say what you know about influence versus a sale, and say plainly that you have not worked a rail contract. No claim about rail deal structures. | Ross's commercial question, and F3's limit. |
| C5 | "How would you know, in year one, that an operator partnership was working?" | CO | [generic] | Name two measures in the operator's terms, not yours, and name the one you would doubt first. | Commercial heads test whether a plan has a measure that can fail. |

### Persona D: Pressure (Ross)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why should we take a chance on someone who has never sold into rail?" | JD | [grounded] "Never sold into rail specifically" (your message) | Pause. Restate the question. "I haven't sold into rail." Hold through two follow-ups by returning to the part your material carries. Concede one specific: what you would do in the first 90 days, said as a plan. | Pressure tests composure. Same gap as B1, faster and colder. |
| D2 | "That £4M. How much of it was actually you?" | EXP | [grounded] "roughly £4M of influenced revenue" (your message), "took it from 6 partners to 40" (your message) | Say "influenced". Give the share you can defend, or say you would rather not give a figure you cannot defend. Answer slot: which part was yours and how you know. | F3 under pressure. The honest answer is the quoted one. |
| D3 | "Name one commercial call you'd make on an operator in your first quarter that you'd regret if it went wrong." | CASE | [generic] | Name one decision and the stake it carries. Do not build a history for it. | Tests judgment under pressure without asking for a past. |

### Persona E: Conversational opener (both)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk us through the journey." | JD | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel" (your message), "5 years in transport consulting" (your message) | 90-second arc: nine years in partnerships; the payments ISV channel; the consulting years on the operator side, in your words. Stop there. | Casual register, scored. Keep it to the two bridges the panel will use. |
| E2 | "What are you most curious about in our operator world?" | CO | [generic] | Ask one specific question about operators, such as which ones are hardest to partner with. Do not claim knowledge of the market. | Casual question, still scored. Your question is part of the answer. |

### Coverage

| Requirement (source) | Question IDs |
|---|---|
| "where you'd take our operator partnerships over the next 18 months" (recruiter) | A1, A2, A3, A5, B2, B3 |
| "what it means for the operators themselves" (recruiter) | A4, B3, E1, POV close |
| "Ross will push on commercials." (recruiter) | C1 to C5, D2, D3 |
| Direct sales quota into rail (role-family pattern) | B1, D1; F4 |

---

## Reverse questions

Each has a reason it lands. No interviewer profile was researched, so none is tied to a path.

1. **To Deepa:** "Which operators would you want a partnership with in the first three months, and where do those relationships stand today?" Lands because it shows you are thinking about operators specifically, not the channel.
2. **To Deepa:** "Where has the partner route helped most with operators, and where has it got in the way?" Lands because it asks for an honest answer and shows you expect friction.
3. **To Ross:** "How are partner-influenced deals counted against the commercial plan today, and who signs off on them?" Lands because it shows you already know influenced is not sold, and asks how they handle that gap.
4. **To Deepa:** "What did the last person in this role get wrong in their first 90 days?" Lands because it asks for a lesson, not a reassurance.
5. **To Ross:** "What would make you say, six months in, that this was the wrong hire?" Lands because it lets Ross name the test, which is the one you need to meet.
6. **To both:** "Which part of the 18-month plan is still unsettled?" Lands because it signals you would build on the work, not restart it.

---

## Sources

- **Provided documents:** your background message, and the recruiter's email as quoted in your message. The internal market report was not in this session, so none of it is quoted or used here.
- **Research tier:** L1. Searches: 4 of 6. Fetches: 0 of 2. User links read: 0.

**Target accounting**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Kelverton Rail values | unavailable | Values cheat sheet absent. No values-style round detected in the email. Query sent: "Kelverton Rail company values": refused. |
| 2. Interview process, role family | skipped | The recruiter's email fixes the format: panel, 60 minutes, 15-minute POV. |
| 3. Strategy and recent news | unavailable | Grounding brief absent, and POV differentiation is generic. Query sent: "Kelverton Rail scheduling software train operators partnerships": refused. |
| 4. Interviewer public footprint | unavailable | Reverse questions and interviewer read absent. Queries sent: "Kelverton Rail Deepa VP Partnerships", "Kelverton Rail Ross Commercial Director": both refused. |
| 5. Representative JD | unavailable | Requirements come from the recruiter's words, not a JD, so F1 to F4 are not grounded in one. No call sent. |

Searches sent, all refused: four, as listed above. No search was sent outside the declared targets.

---

## Upgrade menu

- **The market report's operator-partnership section (or its headline findings)** → the POV's thesis can be checked against the internal consensus, so the differentiation becomes a real choice rather than a guess.
- **The job description, or the recruiter's role spec** → F1 to F4 become grounded in its own words, and the JD-tagged questions are checked against its full requirement list.
- **Search permission, or the Kelverton values page and each interviewer's public profile pasted** → a values cheat sheet, a strategy grounding brief, an interviewer read, and reverse questions tied to their career paths.
- **Deep research (L2), offered once:** a strategy brief, interviewer talks and writing, and rail-loop reports. Cost: up to 6 more searches and 2 more fetches. Run only if you say so.
- **A working-style assessment, if you have one** → a delivery-coaching section for the panel.
