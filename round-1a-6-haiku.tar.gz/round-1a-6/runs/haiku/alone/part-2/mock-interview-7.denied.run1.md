This matches the mock-interview prep skill, so I'll load it and build the pack from your background and the JD.
Loading the reference files the skill requires before I write anything.
The skill needs live research before I write the pack, so I'll load the search tool and run the L1 targets for this company and interviewer.
The four searches were refused because search permission hasn't been granted, so the pack is built from your message and the JD alone. I'll save it now and show the gaps this leaves.
Your prep pack is saved at `/tmp/claude-0/-var-tmp-tuesday-measure-1a6-runs-haiku-alone-part-2-rooms-case-7-denied-927dadab/c136aac9-f3ad-4538-9943-6a4c86fce2b1/scratchpad/Saltmarsh_Games_live-operations-producer_interview_pack.md`. I built it on the assumption that Friday is a hiring-manager round with Tobias.

The web searches were refused for lack of permission, so the pack contains nothing about Saltmarsh's values, strategy, or interview process, and nothing about Tobias. If you grant search permission, I can rebuild those sections.

**The main gaps and how the pack handles them:**
- **In-app purchases (the largest one).** The JD doesn't mention monetization, but a Skeptic will likely raise it. Question B1 is the one to rehearse hardest: acknowledge it in one plain sentence, then give a learning plan. Don't claim any monetization experience.
- **Two titles vs one.** Your calendar covered one title. B2 covers the step to two, framed as a plan, not a past.
- **No team leadership.** The JD asks you to coordinate design, art, engineering and community, not to lead them. B3 keeps your answer to coordination, and says you haven't led a team.
- **Post-event review and KPI ownership.** You presented retention numbers but not a review. C1 covers how those numbers were counted; C3 covers both branches of whether you've run a review.

Things to avoid saying, listed in the pack: "two titles," "led a team," "own the KPIs," "manage the checklist with QA," "monetization experience," and "live-service production" as a claim.

Two things would sharpen this:

1. What stage is Friday's round, and is Tobias the hiring manager? That reweights the personas.
2. Are there any location, work-pattern or start-date requirements? The pack can't account for those yet.

Also available, one line each, neither pushed: a live drill on B1, and a `tuesday-dossier.md` recording the gaps this prep exposed, plus a Word version of the pack.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Saltmarsh_Games_live-operations-producer_interview_pack.md -----
# Interview pack: Live Operations Producer at Saltmarsh Games

Interviewer: Tobias Wrenfield, Head of Live Operations (they/them). Format: 60 minutes, Friday. Candidate: Femi (they/them).

Assumption: the round is with the hiring manager. The interviewer's title suggests it, but your note didn't say what stage this is. Persona weights below would change if it is a peer or a panel round.

## How to use this pack and type key

Personas describe how a question arrives. Types describe what is being scored. Guidance is scaffolding, not a script. Say it in your own words.

| Tag | Name | What is scored |
|---|---|---|
| JD | Role / JD-driven | Can you do the listed job, gaps included |
| EXP | Work-experience deep-dive | Whether your past claims survive scrutiny |
| CASE | Hypothetical / live problem | Structure and reasoning on a problem from the role |
| CO | Company and strategy | Not scored this run: research did not run |
| VAL | Values alignment | Not scored this run: no values round detected |

## Fit snapshot

Requirements are quoted from the JD you supplied. Evidence is quoted from your message. Gap types follow the routing rule in the skill: none, presentation, transferability, discovery, capability.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "experience running a content calendar" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | none | Limit stated: one title, weekly drops. Expect a probe on what you can show; you have no artifact in this material yet. Words: "I ran the weekly content-drop calendar for our main title for the last two years." |
| F2 | "manage the release checklist with QA" (JD) | "Wrote the release checklist our QA team still uses." (your message) | medium | [grounded] | none | Your sentence says you wrote it and QA still uses it. It does not say you managed the checklist with QA day to day. Words: "I wrote the release checklist our QA team still uses." |
| F3 | "comfortable with player-retention metrics" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | medium | [grounded] | transferability | Presenting numbers is adjacent to being comfortable with them. It does not show who defined them. Words: "I presented the monthly retention numbers to the studio head." Then the answer slot in C1. |
| F4 | "own the post-event review and the KPIs it reports" (JD) | none given | none | [grounded] | discovery | Your material does not show a post-event review or KPI ownership. Answer slot: if you ran a review and chose what it measured, say so in your own words; if you did not, say so plainly and describe how you would structure one. |
| F5 | "Plan and run the live-events calendar for two of our mobile titles" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | low | [inferred] | transferability | Your calendar covered one title. The JD asks for two. Bridge at its own scope: one title's calendar, run weekly. Answer slot: which two-title decisions you would make first (see B2). |
| F6 | "coordinate design, art, engineering and community teams on each update" (JD) | none given | none | [grounded] | discovery | Your material does not show coordinating those teams on an update. Answer slot: if you coordinated any of them on a release, say which and how; if you did not, say so and describe how you would run one. |
| F7 | "3+ years producing live-service games or apps" (JD) | "4 years as an associate producer at a puzzle-game studio." (your message) | medium | [grounded] | transferability | The years meet the 3+ stated. Your material does not say live-service production in those words. Your weekly content drops are live content. Say so in those terms, no more. |
| F8 | in-app purchases (role-family, not in the JD) | "never worked on a game with in-app purchases" (your message) | none | [grounded] | capability | This is a stated absence, so you can say it plainly. Words: "I haven't worked on a game with in-app purchases." Then how you would learn it, as a plan, never as a past. |
| F9 | "coordinate design, art, engineering and community teams on each update" (JD) | "Never led a team" (your message) | none | [grounded] | discovery | Your stated absence is leading a team, not coordinating one. The JD does not say lead. A leadership probe is still likely. Words: "I haven't led a team." Then how you coordinate without line authority, as a plan. |

Where the requirements come from: the JD you pasted, quoted. The in-app purchase row (F8) uses a role-family expectation, labeled [grounded] only because you stated the absence yourself.

## Prohibited claims

Built locally from the fit snapshot. These are the claims a candidate reaches for under pressure. Nothing in the pack asserts or implies them.

| Not coached | Basis | Honest form |
|---|---|---|
| "I ran the calendar for two titles" | Inflated form of F5 (your material says one title) | F1's sentence at its own scope |
| "I've led a team" / "I've led cross-functional teams" | Sourced: your stated negative (F9) | "I haven't led a team." |
| "I own the KPIs and the post-event review" | Inflated form of F3 and F4 (presenting numbers is not owning KPIs) | F3's sentence |
| "I manage the release checklist with QA" | Inflated form of F2 (you wrote it) | F2's sentence |
| "I have in-app purchase or monetization experience" | Sourced: your stated negative (F8) | "I haven't worked on a game with in-app purchases." |
| "I've produced live-service games" | Inflated form of F7 | F7's sentence, at its own scope |

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | A live plan for two titles, a retention drop to diagnose | High. A hiring manager for a plan-and-run role buys capability and tests it live. | Clarify before structuring. Name the weakest assumption. Think aloud. |
| Skeptic | "You haven't run a game with in-app purchases" | High. Two gaps are stated in your own words, plus the one-title scope. | Acknowledge the gap in one plain sentence. Then a plan. Hold through two follow-ups. |
| Data-Driven Prober | "How was that retention number counted?" | Medium-high. The JD names retention and KPIs; you presented retention numbers. | Say what you know and what you don't. Name the weakest assumption before they do. |
| Pressure | Time-boxed challenge on leadership or monetization | Medium. Leadership and monetization are the obvious pressure points. | Pause. Hold the position you can back. Concede only the specific gap. |
| Conversational | Opening "walk me through" | Low-medium. Casual openers are still scored. | Prepared 90-second arc, no claims beyond your message. |

Depth follows weight. Case and Skeptic are weighted highest (5 each), Prober 4, Pressure and Conversational 2 each. The weighting rests on the hiring-manager prior, since no loop source and no interviewer profile were available.

## Question banks

Rule: each guidance cell rests only on the quoted sentences in its Provenance column, or it is an answer slot.

### A. Case / Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Two of our titles each need a live event next month, and you have one designer, one artist and a two-person community team. How would you plan the calendar?" | CASE | [generic] | Clarify first: each title's goal (retention or revenue this month), what engineering can ship, and the QA gate date. Then sequence the events, name the dependencies, and say what you would cut first. Make no claim about your past. | The JD's first line (R1) and second line (R2) in one problem. Generic because it is a pattern for the problem, not a fact about this employer. |
| A2 | "Retention on one title dropped 12 percent week over week after an update. Diagnose it." | CASE | [generic] | Segment before blaming the update: new against returning players, platform, app version, event exposure. Check that the drop is real and the instrumentation did not change. Name the assumption you would test first. | Scores the retention-metrics requirement (R7) as reasoning, not recall. |
| A3 | "An update slips a week and the partner team is not ready. What do you do?" | CASE | [generic] | Decide what moves and who needs to know today. Name the QA sign-off you would protect and the one you would negotiate. Say what you would tell the community team before players notice. | Covers R2 and R4 as a live coordination problem. |
| A4 | "How would you judge an event a success in the first 48 hours?" | CASE | [generic] | Name the metric you would read first and a control to compare it against. Name the metric that would mislead you, and why. | Feeds the post-event review requirement (R3). Generic because the answer is a method, not a claim. |
| A5 | "How would you plan an event on a title where in-app purchases carry much of the revenue?" | CASE | [generic] | Name the questions you would ask first: which purchases the event touches, what the revenue calendar looks like, who owns it. Say plainly that you have not done this and how you would learn it. | Asked as a problem, so it presumes nothing about your past. This is where F8 comes up if asked as a case. |

### B. Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You haven't worked on a game with in-app purchases. How would you own the monetization side of an event?" | JD | [grounded] "never worked on a game with in-app purchases" (your message) | **Highest-ROI rehearsal in this pack.** Hold: "I haven't worked on a game with in-app purchases." Then a plan: first learn the revenue calendar, pair with the monetization owner, review what the purchase data shows before you propose anything. Hold through two follow-ups by returning to the plan. Concede specifically: "I can't yet tell you how a purchase bundle will move retention." Answer slot: if you have any monetization-adjacent work, say it in your own words; if not, say so. | F8 is the largest gap and the likeliest probe. The JD does not name monetization, so this objection may come as a monetization question. The hold and concession are the structure to rehearse. |
| B2 | "The role plans two titles and you've run one. What is harder about that, and what would you do in week one?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | Say one title, weekly drops, two years. The step to two titles is a planning problem: two calendars competing for the same teams. Name what you would check first. Do not say you have already run two. | F5: the JD's two-title line against your one. The honest answer is the limit plus a plan. |
| B3 | "You've never led a team. How do you coordinate designers, artists, engineers and community on each update without authority over them?" | JD | [grounded] "Never led a team" (your message) | Hold: "I haven't led a team." Then coordination mechanics as a plan: one update document, a named owner per workstream, a standing check-in before each release. Hold through two follow-ups. Answer slot: if you coordinated any of those teams on a release, say which and how; if not, say so. | F9: the stated absence is leading, so answer only what it covers. Coordination is described as a plan, not a past. |
| B4 | "On the release checklist you wrote: which part would you change first?" | JD | [grounded] "Wrote the release checklist our QA team still uses." (your message) | Name one item you would change and why. Answer slot: if you have changed it since you wrote it, say how and why; if you have not, say what you would review with QA first. | F2: a checklist that QA still uses is a strong fact; the probe is whether you can critique your own work. |
| B5 | "Give me one reason we shouldn't hire you over someone with live-service monetization experience." | Pressure stem, JD | [grounded] "never worked on a game with in-app purchases" (your message) | Hold the calendar and checklist experience as what you bring. Concede the monetization gap plainly. Do not fold on the calendar. | Rehearses the hold-then-concede structure against the largest stated gap. |

### C. Data-Driven Prober (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "The monthly retention numbers you presented: how were they counted, and which assumption would you defend least?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." (your message) | Say what you know about how the numbers were built. If you do not know the counting method, say so plainly. Name the assumption you would defend least before they do. Answer slot: if you chose what the numbers measured, say so; if the method was not yours, say so and say what you presented. | F3: presenting is not defining. The honest answer is what you know, not a method you can't repeat under a second question. |
| C2 | "The post-event review reports KPIs. Which three would you report for a live event, and why?" | JD | [generic] | Name the metrics for the event type, a control to compare against, and the one that would mislead you. Keep the choices as your reasoning, not as past practice. | Covers R3. Generic because it asks for a method. |
| C3 | "Have you run a post-event review? If so, walk me through it. If not, how would you structure one?" | JD | [generic] | Honest branch in both directions. If you have run one, describe it and what it measured in your own words. If not, say so and describe the structure you would use. | F4: no quote in your material carries a review, so the question offers both branches. |
| C4 | "What would you check before you trust a number from the dashboard?" | EXP | [generic] | Name the instrumentation check, the date range, and the one segment that would change your read. Say plainly what you have and have not checked yourself. | A general probe on a number you presented in your own work. No claim about your past. |

### D. Conversational / Rapport (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey." | JD | [grounded] "4 years as an associate producer at a puzzle-game studio." (your message) | 90-second arc: four years as an associate producer at a puzzle-game studio, the calendar, the checklist, the retention numbers. Make no claim beyond those sentences. | Opener. The arc is the four quoted facts in order. |
| D2 | "What are you playing these days?" | JD | [generic] | Name one game and why it works, in terms of its live updates if you can. Say plainly what you have not played. | Casual, but the live-service angle is a plus the JD names. |

### E. Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you, for a two-title live role?" | JD | [grounded] "Ran the weekly content-drop calendar for our main title for the last two years." (your message) | Pause. Lead with the calendar and the checklist. Concede the gaps plainly: one title, no leadership, no monetization. Do not fold on the calendar. | Time-boxed. Rehearses holding a position you can back. |
| E2 | "I don't see monetization or team leadership in your background. What's left?" | JD | [grounded] "Never led a team" and "never worked on a game with in-app purchases" (your message) | Hold: "I haven't led a team, and I haven't worked on a game with in-app purchases." Then what you did bring, in your own words. Hold through two follow-ups; concede the gap, not the calendar. | The two stated absences in one probe. Practice holding without becoming defensive. |

## Requirement coverage

| JD requirement | Question IDs | Notes |
|---|---|---|
| Plan and run the live-events calendar for two titles | A1, B2 | F5 is the gap |
| Coordinate design, art, engineering and community teams | A3, B3 | F6 and F9 are the gaps |
| Own the post-event review and the KPIs it reports | A4, C2, C3 | F4 is the gap |
| Manage the release checklist with QA | B4, A3 | F2 |
| 3+ years producing live-service games or apps | — none, and why | A length-of-experience line, not a gate. Graded in F7 and covered by D1. |
| Experience running a content calendar | B2, D1 | F1 |
| Comfortable with player-retention metrics | A2, C1 | F3 |
| Clear written communication | — none, and why | No written sample in the material. See the upgrade menu. |

## Reverse questions

Each one has a "why it lands."

1. "Which two titles are in scope, and how different are their revenue models?" Why it lands: it names the scope gap and the monetization gap in one question, and shows you want the specifics before you commit.
2. "How is a post-event review run today: who writes it, and which KPIs does it report?" Why it lands: it lands directly on the ownership requirement (R3) and shows you think in KPIs.
3. "How does the release checklist with QA work now, and what did the last miss teach the team?" Why it lands: it shows you know the checklist already exists and that you want to learn from it, not reinvent it.
4. "Who would I coordinate with on an update, and where do decisions get made when design and engineering disagree?" Why it lands: it turns the coordination requirement into a seam the interviewer can describe.
5. "What would a good first 90 days look like in this role?" Why it lands: it signals you plan to earn the role, and gives them a concrete answer to score you on.

No reverse question ties to the interviewer's own career path. No profile was available, because the name search was refused.

## Upgrade menu

- Permission to search, granted, then the pack is rebuilt → Saltmarsh's values, loop structure, recent strategy, and the interviewer's public footprint. Until then, those sections are absent.
- The stage of this round and your interviewer's role in the loop → persona weights confirmed or reweighted.
- A redacted calendar or checklist sample, if you can share one → F1 and F2 move from medium to high, and B2 and B4 get an artifact to point to.
- The retention numbers you presented, with how they were counted, if you can say → C1 becomes a stated answer instead of an answer slot.
- Work pattern, location and start date → the skeleton's gate rows, which the material does not show.

## Sources

Provided documents: your message (background), the JD you pasted.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | unavailable | Every call refused. The values cheat sheet is absent, since no values page was read. |
| 2. Saltmarsh Games interview process, live operations | unavailable | Every call refused. No loop source; generic archetype applies, so weights are flat and no values round is detected. |
| 3. Saltmarsh Games strategy / recent news | unavailable | Refused. Would have fed the CO bank, which is absent. |
| 4. Tobias Wrenfield, Saltmarsh Games | unavailable | Refused. Would have informed the interviewer read and a personal reverse question. |
| 5. Representative live operations producer JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions. |

Searches sent, all refused for lack of permission:
- "Saltmarsh Games values": refused
- "Saltmarsh Games interview process live operations producer": refused
- "Tobias Wrenfield Saltmarsh Games": refused
- "Saltmarsh Games mobile game news": refused

Nothing about Saltmarsh Games is in this pack beyond what the JD says. Nothing about the interviewer is in it at all.

Section omissions, by condition: interviewer read (no profile), values cheat sheet (no values round detected), grounding brief (research did not run), graded deliverables (none declared), delivery coaching (no assessment), prep triage (prep time not given).
