# Stripe, Product Operations Manager: final-round prep pack

**Round:** final round, format and interviewer unknown. **Relationship:** unknown, so persona weights are flat.
**Inputs:** none supplied (no CV, no JD, no interviewer, no round format). Built at L0: web search was refused in this session.

## How to use this pack

- **Personas** describe how a question arrives (its register). **Types** describe what it scores.
- Type key: **VAL** behavioral and values; **EXP** work-experience deep-dive; **JD** role-driven; **CO** company and strategy; **CASE** live problem.
- Guidance is scaffolding, not a script. Each cell should be speakable in 90 to 120 seconds.
- Provenance: the pack holds no sentence of yours to draw on, so every label is `[generic]`. Nothing here says what you did. Where a cell asks about your past, it gives you a way to choose an example and an honest branch if none fits.

## Fit snapshot (worksheet variant)

No JD was supplied, so the requirements below are role-family prose, not quotes. Your evidence is not yet in the pack, so every evidence cell reads `none given`. Silence is recorded as `discovery`, not as a capability gap.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Runs cross-functional operating processes end to end, such as planning, launch or review cadences (role family, no JD) | none given | none | [generic] | discovery | Pick a process you ran that several teams depended on. Name it, the teams involved, and what changed. If no such time comes to mind, say so plainly, then give the nearest thing you have done, or how you would approach it. |
| F2 | Uses data to decide what to measure and whether a change worked (role family, no JD) | none given | none | [generic] | discovery | Pick a metric you used to make an operational call. Say how it was counted, what it misses, and the assumption you would defend least. If you have not used one for a decision, say so, then say what you would measure first. |
| F3 | Makes prioritization trade-offs and says no to work (role family, no JD) | none given | none | [generic] | discovery | Pick a request you declined or re-sequenced. Say what the trade-off was and who decided. If none comes to mind, say so, then describe how you would decide. |
| F4 | Writes decisions clearly for executives and engineers (role family, no JD) | none given | none | [generic] | discovery | Pick a decision memo or brief you wrote. Say who read it and what it changed. If you have not written one of this kind, say so and describe the format you would use. |
| F5 | Partners with product and engineering owners without owning their roadmaps (role family, no JD) | none given | none | [generic] | discovery | Pick a case where a partner team disagreed with your recommendation. Say how it was settled. |

No row is a hard gate, because no JD was supplied to declare one.

## Persona table

Relationship is unknown and the round format is not stated, so the weights are flat. Each persona gets three questions except Pressure and Conversational, which get two. Those two weights are lower because nothing signals a stress or casual round.

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist | Live problems from the role | 3. Finals often include a problem from the team's real work. | Clarify, objective, segment, approach, metrics, risks. Say the framework aloud once. |
| Skeptic | Probes on gaps and on why you, why now | 3. Finals press on what earlier rounds raised. | Rehearse the gap question until it is boring. Name a real gap plainly, with a ramp plan. |
| Data-Driven Prober | Counts, denominators, assumptions | 3. Operations roles are judged on measurement. | Know how each metric was counted. Say plainly when you do not know. |
| Peer Evaluator | Seams with product and engineering | 3. Ops sits beside product, and a peer may be on the panel. | Propose seam principles. Do not pretend to know their seam. |
| Values/Behavioral | Stories matched to principles | 3. No values round is established (see Sources), so this weight rests on the pattern, not on Stripe's documented loop. | STAR-shaped. "We" for context, "I" for your part. |
| Pressure | Time-boxed challenges | 2. Lower weight with no stress signal. | Pause, restate, hold through two follow-ups. |
| Conversational | Casual openers that are still scored | 2. Lower weight, but never treat it as unscored. | A 90-second arc. Treat casual questions on JD topics as scored. |

## Question banks

Question IDs are letter-by-persona. Counts: Case/Strategist 3, Skeptic 3, Prober 3, Peer 3, Values 3, Pressure 2, Conversational 2. Total 19.

### A. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A launch slips two weeks, and two partner teams disagree on whether to ship anyway. What do you do this week?" | CASE | [generic] | Clarify who owns the decision and weigh the cost of delay against the risk. Get each team's facts. Make a named recommendation, then say who decides and how you would tell the affected teams. | A live problem on a launch seam. CASE because it tests structure. It presupposes nothing about your past. |
| A2 | "Review-queue volume has doubled in a quarter. Diagnose it and tell me what you would change first." | CASE | [generic] | Ask whether volume, throughput or staffing moved. Segment the queue by type, source and age. Name the likely bottleneck, propose one change, and the measure that would show it worked. | Tests structure under a measurement frame. The usual follow-up asks for the denominator. |
| A3 | "What is the most important operational problem in this business today, and what would you need to know to act on it?" | CO | [generic] | Say you are working from public information and name its limit. Give one problem, one reason, and the data you would need. Do not recite strategy you have not checked. | CO with no research behind it, so the guidance stays generic and labelled. The defensible answer is the one you can back. |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | **Highest-ROI prep in this pack.** Name one gap that is real for you, say how you would close it in the first thirty days, and do not pick a gap you cannot defend. Hold through two follow-ups by returning to the ramp plan. Rehearse this one most. | A Skeptic staple, and the one most likely to be asked in some form. With no CV or JD, the specific objection is unknown, so this generic form stands in. |
| B2 | "Why are you leaving where you are, and why this role?" | EXP | [generic] | Lead with what you want to do more of and how this role offers it. Keep it about your direction, not the old employer. Say it in your own words. | Motivation consistency. EXP because it asks about your history. |
| B3 | "What in your background would make a skeptic doubt you here, and how would you answer them?" | EXP | [generic] | Pick the doubt you would most expect. Answer it with the nearest thing you have done, stated plainly. If nothing you have done answers it, say so and say how you would close the gap. | An open prompt, so it presupposes nothing about your past. The honest branch is built in. |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a number you used to make an operational decision. How was it counted?" | EXP | [generic] | Pick one you can defend. Define it in one sentence. Name the assumption you would defend least before they do. Say plainly what you do not know about how it was counted. | Probers go to denominators. EXP because it tests attribution. |
| C2 | "How would you know a new internal review process is working? Give three measures and what each would miss." | CASE | [generic] | One outcome measure, one leading indicator, one guardrail. Say what each would miss. | Measurement design is central to an ops role. CASE because it is a live design problem. |
| C3 | "Tell me about a decision you made on incomplete data. What happened when it turned out wrong?" | EXP | [generic] | Pick a decision you can describe. Say what you knew, what you did, and what you changed afterward. Do not claim the decision was right if it was not. | Tests honesty about error under data pressure. An open prompt. |

### D. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Product and engineering both own launches. Where would you expect the seam with your work, and what happens when you disagree?" | JD | [generic] | Propose principles for the seam: who decides what, and how disagreements get escalated. Do not claim to know their team. | The product seam is the core of the role. A peer probes it collegially. |
| D2 | "How do you handle credit when work spans teams?" | EXP | [generic] | Name the people, not just the outcome. "We" for the shared work, "I" for your part. | Peers probe credit-sharing. An open prompt. |
| D3 | "If I'm a PM on a team you'd support, what would you need from me in the first month?" | JD | [generic] | Name two or three concrete asks: a clear owner for each decision, a shared metric baseline, a decision calendar. Then say what you would bring to their team. | Reciprocity. The peer prices what the hire costs them, and this answer turns the probe into a conversation. |

### E. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Pick a time the hard truth actually landed. Say what you said, to whom, and what changed. If none comes to mind, say so plainly, then give the nearest one you have. | Persona stem. VAL because it scores behavior, not virtue. No Stripe values were checked, so none are named. |
| E2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Pick a case with a real cost to the metric. Name the metric, the customer, and what you chose. | Persona stem for customer-first framing. An open prompt that needs a real instance. |
| E3 | "Tell me about a process you changed that people resisted. What did you do?" | VAL | [generic] | Name the resistance and who held it. Say what you did first, and what you would do differently now. | Change management is central to ops. An open prompt. |

### F. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why should we hire you over someone we already know?" | JD | [generic] | Pause, restate the question, then answer with the one thing you can defend in sixty seconds. Do not argue against the other candidate. | Pressure stem. Composure is what is scored. |
| F2 | "Describe an outcome you are proud of. How much of it was actually you?" | EXP | [generic] | Name your part in one sentence. Hold it through two follow-ups. Concede the specific part that was shared, never the core of your contribution. | Hold-then-concede. The second follow-up is where candidates fold. |

### G. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey." | EXP | [generic] | A 90-second arc: where you started, the work that taught you the most, why this role. Use your own words and do not script it word for word. | Casual but scored. The arc is the rehearsal. |
| G2 | "What are you playing with in operations tooling these days?" | JD | [generic] | Name the tools you have used in your own work. Say plainly which you have not used. | Casual register on a JD topic. The honest answer is the one you can show. |

### Requirement coverage

| Requirement (F row) | Questions |
|---|---|
| F1 operating processes | A1, A2, E3 |
| F2 measurement | C1, C2, C3 |
| F3 prioritization and saying no | A1, E1 |
| F4 written decisions | none, and why: no question asks about writing yet; add the JD and this gets a question |
| F5 partnership | D1, D2, D3 |

## Reverse questions

Five are required, and none ties to an interviewer's path because no interviewer profile exists. Each has a "why it lands."

1. "What would a strong first ninety days look like for this role, and who would judge it?" Why it lands: it turns the day-one gap question into a shared target.
2. "Where do product and operations most often disagree right now?" Why it lands: it shows you already think about the seam.
3. "When teams disagree on a launch, who has the final say, and how often does it get escalated?" Why it lands: it tests decision rights, which is what the first month will depend on.
4. "Which operational metric does the team trust least right now, and why?" Why it lands: it opens the measurement conversation on their terms.
5. "What is the next step after this round, and is there anything I should address that I haven't?" Why it lands: it shows you are closing the loop, and it invites the last objection while there is time to answer it.

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| No entries | Nothing in the inputs is a sentence of yours, so there is nothing to stretch. | No claim about your past is coached anywhere in this pack. Every answer slot asks you for your own example, or lets you say none fits. |

## Sources

No documents were supplied. Web search was refused in this session, and no fetch was attempted.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Stripe company values` | unavailable | The values cheat sheet. Search refused (query: "Stripe company values operating principles"). Stripe's values are not stated in this pack, because they must come from a source. |
| 2. `Stripe interview process product operations` | unavailable | Loop structure, and persona weights would follow the named rounds. Search refused (query: "Stripe interview process final round onsite loop"). |
| 3. `Stripe strategy` / recent news | unavailable | The CO bank would become current. Not sent. |
| 4. `{interviewer name} Stripe` | n/a | No interviewer name was given, so there was no query to form. |
| 5. representative `Product Operations Manager` JD | unavailable | The fit snapshot would quote a representative posting. Search refused (query: "Stripe Product Operations Manager job description"). |

Research tier: L0 in effect. Three searches were sent and all were refused; no fetch was attempted.

## Upgrade menu

- **Round type and who you are meeting** → restructures the persona weights and the reverse questions. A recruiter screen, a hiring-manager round and a panel each read differently.
- **The JD text** → the fit snapshot rows become quotes, the B1 gap question is grounded in the posting's own words, and the coverage table gets real requirements. Gate rows would surface here if the JD declares any.
- **Your CV or background notes** → the evidence column fills with your own sentences, and the scaffolds become story maps.
- **Search permission for this session** → targets 1, 2 and 5 at L1: Stripe's published values, its interview process, and a representative JD. A values cheat sheet appears only if a values round is detected from a loop source.
- **An interviewer's name** → an interviewer read from public footprint, and persona weights adjusted to it.
- **The recruiter's prep email** → any focus areas or pre-declared exercise, such as a case or presentation. If the final is several sessions, the schedule would allow per-session mini-packs.
- **A deeper research pass (L2)** → a strategy brief and loop reports, once search is allowed. It costs up to six more searches and two more fetches, several minutes.
