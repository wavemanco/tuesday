# Interview prep pack: Dara, Member Experience Lead, Ashgrove Credit Union

**Rounds (5 December 2026):** (1) recruiter, 30 min. (2) Head of Member Services, your future manager, 45 min, mostly behavioural. (3) Panel of two branch managers, 60 min, including a 20-minute complaint-escalation case, scored against the four values.
**Interviewers:** only the recruiter is named. Round 2 is the Head of Member Services; round 3's two branch managers are not yet named.
**Build:** first version, built on the JD, recruiter email, values page and strategy brief you supplied, plus your message. No changes yet.

## How to use this pack

- **Personas** describe how a question is asked. **Types** describe what is being scored.
- Type key: **VAL** values and behaviour · **EXP** your experience, tested closely · **JD** the listed role requirements · **CO** company and strategy knowledge · **CASE** a live problem.
- Guidance is scaffolding, not a script. Say the quoted sentence first, in your own words, then the beats.
- An **answer slot** is an instruction for the interview. It is not a question to me.

## Fit snapshot

Requirements are quoted from the JD you supplied. Evidence is quoted exactly from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" (JD) | "6 years in retail banking, the last 3 as a branch supervisor" (your message) | high | [grounded] | none | No gap on years. Say it as written: "Six years in retail banking, the last three as a branch supervisor." Expect a check on whether branch work counts as customer operations. Say what the customer work was, in your own words. |
| F2 | "experience handling regulated complaints" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | transferability | Your material shows a formal log at one branch, not regulated complaints as such. Bridge stays at the log: "I handled the branch's formal complaints log." Answer slot: the JD says "regulated". If the log ran to set rules or timescales, say which. If it did not, say so and say how you would learn them. |
| F3 | "own the complaints process end to end across branches and the contact centre" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | transferability | The quote carries one branch's log, not the process end to end. Bridge: "I handled the branch's formal complaints log." Answer slot: if any step of the process was yours to decide, say which. If others owned those steps, say so. |
| F4 | "across branches and the contact centre" (JD) | "Never worked in a contact centre" (your message) | none | [grounded] | capability | A gap you stated. Words: "I've never worked in a contact centre." Then how you would learn it, said as a plan. Never describe a contact-centre past. |
| F5 | "coach branch supervisors on escalations" (JD) | "trained new tellers on our escalation script" (your message) | low | [grounded] | transferability | Your material shows tellers, not supervisors. Bridge: "I trained new tellers on our escalation script." Answer slot: if you coached anyone other than tellers on escalations, say whom and what. If not, say so and say how you would coach supervisors. |
| F6 | "report monthly on complaint volumes and resolution times" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | medium | [grounded] | presentation | The quote reaches monthly reporting. Bridge: "I built the monthly complaints spreadsheet our regional manager uses." Your material does not show whether resolution times were counted, so the pack does not assume they were. |
| F7 | "confident presenting to senior leaders" (JD) | "I've never presented to anyone above regional level" (your message) | none | [grounded] | capability | A gap you stated. Words: "I've never presented to anyone above regional level." Then your plan for building the skill, as a plan. |
| F8 | "comfortable with Excel reporting" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | medium | [grounded] | presentation | Your material says spreadsheet, not Excel. Bridge: "I built the monthly complaints spreadsheet our regional manager uses." Name the tool only if it was Excel. |
| F9 | "work with digital teams on self-service journeys" (JD) | none given | none | [grounded] | discovery | Answer slot: if you worked with a digital or IT team on a customer-facing change, say what it was and your part in it. If you did not, say so and say how you would approach a self-service journey. |

**Pattern the material shows:** branch complaints work, a formal log and monthly reporting. It does not show contact-centre work, presenting above regional level or work with digital teams.

## Prohibited claims

These claims are not coached anywhere in this pack, including in answers and drills.

| Not coached | Basis | Honest form |
|---|---|---|
| Owns the complaints process end to end across branches and the contact centre | Inflated form of F3 | "I handled the branch's formal complaints log," at that scope. The contact-centre gap is F4. |
| Has coached branch supervisors on escalations | Inflated form of F5 | "I trained new tellers on our escalation script." |
| Designed the escalation script | Inflated form of F5 | "I trained new tellers on our escalation script." |
| Reports resolution times to leaders, or presents monthly results to senior leaders | Inflated form of F6, and F7's stated negative | "I built the monthly complaints spreadsheet our regional manager uses." Plain: "I've never presented to anyone above regional level." |
| Works to regulated complaints timescales | Inflated form of F2 | "I handled the branch's formal complaints log." |
| Excel expert | Inflated form of F8 | "I built the monthly complaints spreadsheet our regional manager uses." |

## Persona weights

No interviewer profiles were supplied, so weights come from the round descriptions and the relationship priors.

| Persona | Where it shows | Questions | Why | Counter-strategy |
|---|---|---|---|---|
| Values/Behavioral | Rounds 2 and 3 | 5 | Round 2 is "mostly behavioural"; round 3 scores the four values | Map a story to each value where your quotes carry one. Where none does, say so |
| Case/Strategist | Round 3 case and a strategy question | 5 | Round 3 holds a 20-minute case, so it ties with Values at the top | Clarify, then structure, then answer. Think aloud |
| Conversational | Round 1 recruiter screen | 5 | The screen's logistics are scored, so this is the whole round | Give your logistics in your own words; keep the biography to 90 seconds |
| Skeptic | Round 2 manager, checking the two stated gaps | 2 | The manager is buying capability and checking your two stated gaps | Hold the true part, concede the gap plainly, then your plan |
| Pressure | Round 3 panel | 2 | Panel members may test how much of a result was yours | Hold a position through two follow-ups, then concede what is uncertain |
| Data-Driven Prober | Monthly reporting and Excel | 2 | The reporting requirement rests on one CV line | Name the tool and the assumption you would defend least, in your own words |

## Question banks

Ordered by round. Provenance is the candidate sentence each guidance cell rests on. Where the cell makes no claim about you, it carries its label alone.

### Round 1: recruiter screen (Conversational, light Skeptic)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R1 | "Walk me through your background." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "I handled the branch's formal complaints log and trained new tellers on our escalation script"; "I built the monthly complaints spreadsheet our regional manager uses" | Ninety seconds, in your own words, through three beats: the years and the supervisor role, the complaints log and the tellers, the spreadsheet. End on the spreadsheet, the nearest thing to the reporting requirement. | F1 and F6 are what a recruiter checks against the JD first. Casual openers are still scored. |
| R2 | "What is your notice period, and when could you start?" | JD | [generic] | Instruction: give your actual notice period and earliest start date. This pack supplies neither. | Logistics slot. The answer is yours alone. |
| R3 | "What are your pay expectations for this role?" | JD | [generic] | Instruction: give your own figure or range if you have one, or ask first for the band for this role. If asked what you earn now: "I'd rather focus on the range for this role." | Logistics slot. The pack supplies no figure. |
| R4 | "Where are you based, and which locations could you work from?" | JD | [generic] | Instruction: name your base and the locations you could reach, in your own words. | The strategy brief's move from eight branches to five hubs makes location a live question. Logistics slot. |
| R5 | "Why are you looking to leave your current role?" | EXP | [generic] | Instruction: give the reason in your own words. If you have not settled on it, settle it before 5 December. | Logistics slot. An unclear reason is the first thing a screen follows up on. |

### Round 2: Head of Member Services (Values/Behavioral, Skeptic, Prober)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V1 | "Tell me about a time you had to give a member a decision they didn't want." | VAL | [grounded] "I handled the branch's formal complaints log" | Open prompt. If a case from the log comes to mind, use it. Beats: the member's position, the decision, what you told them in plain words, and what you did when they pushed back. Answer slot: if no case from the log comes to mind, say so plainly and describe how you would handle a case like this. | Members First. The log is where such decisions sit, so the story must come from your own cases. |
| V2 | "Tell me about a time you spotted a problem and stayed with it until it was fixed." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Own the Fix. If you built the spreadsheet because you noticed a problem, say what you noticed and what changed. If it was requested, say so and say what you followed through. Answer slot: if you passed a problem on before it was solved, say so. | Own the Fix. A spreadsheet is a tool, not a fix, so the answer must show follow-through you did. |
| V3 | "When did you explain something to a colleague or customer who needed it said twice?" | VAL | [grounded] "trained new tellers on our escalation script" | Plain Words. The teaching is stated: you trained tellers on the script. Beats: what the tellers got wrong, how you explained it again, what you changed. Answer slot: if the script did not land first time and you changed how you taught it, say what. If you did not, say so and say how you would check it. | Plain Words. The story is with tellers, not members, so say so rather than stretch it. |
| V4 | "When did you weigh a branch's local situation against a central target?" | VAL | [generic] | Neighbours, Not Numbers. Pick a time you had to choose between a town's need and a number. If none comes to mind, say so plainly, then give the nearest case your material shows, or how you would handle it. | Neighbours has no quoted sentence in your material, so the scaffold and its honest branch are the answer. |
| V5 | "Tell me about a time you had to tell your own manager something they did not want to hear." | VAL | [generic] | Pick a time you disagreed with a manager on something with a real stake. If none comes to mind, say so and describe how you would raise it. | Values/Behavioral stem. The "unpopular truth" probe is common in behavioural rounds. |
| S1 | "You have never worked in a contact centre, and you have never presented above regional level. Which of this role's requirements would you be weakest on day one, and what would you do?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | **Highest-ROI prep.** Hold the true part first: "I haven't worked in a contact centre, and I haven't presented above regional level." Then say what your branch work carries over, only where the quotes carry it. Then concede specifically: contact-centre process and senior presenting are untested for you. Then name your first two steps, as plans, in your own words. Hold through two follow-ups by returning to what you did, never to a past you did not have. | The JD makes this objection unavoidable: two of its headline asks are gaps you stated. It will be asked in some form, and a calm, specific answer changes the round. |
| S2 | "Your log covered one branch. How many branches' complaints would this role own, and which rules or timescales did you work to?" | JD | [grounded] "I handled the branch's formal complaints log" | Hold the scope: "I handled one branch's formal complaints log." Answer slot: if you set the rules for what counted as a complaint, say so. If branch or regional policy set them, say so. | Covers the scope gap in F3 and the "regulated" wording in F2, both from the JD. |
| D1 | "Walk me through how you built the monthly complaints spreadsheet." | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Describe the build in your own words. Weakest-assumption move: name, before they do, the assumption you would defend least. Answer slot: if the spreadsheet held figures you would be asked about, say how they were counted. If it held none, or you did not decide how counts were made, say so. | F6 and F8 rest on this line. The reporting requirement is the likeliest probe. |

### Round 3: panel of two branch managers (Case/Strategist, Pressure, Prober)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A member has been passed between three staff over a fee dispute and is angry at the counter. You have ten minutes. What do you do?" | CASE | [generic] | Structure, aloud, in 90–120 seconds: clarify the facts; stop the bounce by owning the case; decide the fix and its owner; say what the member will hear, in plain words; record it so it cannot bounce again. | A live problem from the escalation role. No claim about your past. |
| C2 | "The same kind of escalation keeps coming from one branch. What is your first move?" | CASE | [generic] | Look at the pattern before the cases: which branch, what kind, what the log shows. Then find the cause and its owner. Involve the branch manager before changing anything. | Own the Fix, and the Neighbours value, in a live branch problem. |
| C3 | "The contact centre and two branches gave the member three different answers. Your call." | CASE | [generic] | Name one answer and one owner. Decide which answer is right and why. Fix the source of the conflict, not just this case. Tell the member once, in plain words. | Combines Own the Fix and Plain Words in one case. |
| C4 | "A member cannot finish a change in the app and calls the branch. Who do you bring in, and what do you tell the member meanwhile?" | CASE | [generic] | Route the case to the digital team with its facts. Keep the member's contact. Tell the member what happens next, in plain words. | Covers F9 with no claim about your past. |
| CO1 | "We plan to move 40% of member service to digital by 2028. What changes for complaints?" | CO | [generic]. Raising source: the strategy brief you supplied | Name the routes complaints will arrive by, the risk for members who stay on branch or phone, and the measure you would watch. Use the brief's figure as given. | Strategy brief, July 2026. App-only banks are the competitive pressure. |
| P1 | "Sixty seconds: why should we take you over someone who has run a contact centre?" | Pressure | [grounded] "Never worked in a contact centre" | Pause, then restate the question. Hold: "I haven't worked in a contact centre. What I've handled is one branch's formal complaints log." Hold through two follow-ups, then concede the gap specifically. | A stress-style stem. The answer must hold the true part without becoming defensive. |
| P2 | "That spreadsheet: how much of its value was actually you?" | Pressure | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Hold: "I built it, and my regional manager uses it." Concede specifically what the spreadsheet does not do. Answer slot: if others added to or changed it, say what they changed. | Built is yours. Uses is theirs. Keep the two apart. |
| D2 | "Which tools do you use day to day for reporting, and how far do they go?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Name the tool, in your own words. If it was Excel, say so. If you did not build formulas or pivot tables, say so. | F8. The question is the tool, not your skill level. |

### Requirement coverage

| JD requirement | Questions |
|---|---|
| 4+ years in financial-services customer operations | R1 |
| Experience handling regulated complaints | S2 (answer slot on rules and timescales) |
| Own the complaints process end to end across branches and the contact centre | S1, S2, C3, P1 |
| Coach branch supervisors on escalations | Partial: V3 covers tellers only. No question yet on coaching supervisors. See upgrade menu |
| Report monthly on complaint volumes and resolution times | D1, D2. Resolution times are not in your material |
| Confident presenting to senior leaders | S1, P2 |
| Comfortable with Excel reporting | D2 |
| Work with digital teams on self-service journeys | C4, CO1 |

## Values cheat sheet

Round 3 is scored against the four values, so this section applies. Each value is mapped to a quoted sentence where one carries a story, or to a scaffold ending in its honest branch.

| Value (official) | Working meaning | Mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | Scaffold, from F2: "I handled the branch's formal complaints log." Pick a case where the member's side changed your decision (see V1). If none comes to mind, say so, then give the nearest case your material shows. |
| Plain Words | If a member needs it explained twice, the wording was wrong | F5: "trained new tellers on our escalation script." The teaching is stated; "plain" is not. Scaffold: a case where you changed how you explained something (see V3). If none, say so. |
| Neighbours, Not Numbers | Every branch is part of its town | No quoted sentence carries it. Scaffold: a time a branch's local need changed a number-driven choice (see V4). If none, say so and give the nearest case you have. |
| Own the Fix | Whoever finds the problem keeps it until it is solved | F6: "I built the monthly complaints spreadsheet our regional manager uses." The build is stated; the follow-through is not. Scaffold: name the problem you found and what you did after. If the fix was not yours, say so. |

## Grounding brief

From the strategy brief you supplied (July 2026):

- **40%** of member service to move to digital channels by 2028.
- Eight branches consolidate into **five hubs** over 2027.
- A **small-business lending** product launches in Q1 2027.
- The main competitive pressure is **app-only banks**.

The brief is four months old. Before round 2, check it for newer moves. I flagged no stale framings in the documents you supplied.

## Reverse questions

| Question | Why it lands |
|---|---|
| "When a complaint has been escalated twice, what does it look like on the monthly report today?" | Shows you read the reporting line closely and want to know the current practice. |
| "Which complaint types do the contact centre and the branches disagree on most?" | Points to the seam you would own across branches and the contact centre. |
| "How will the branch-to-hub consolidation change where complaints are logged?" | Ties your questions to the brief's 2027 move. |
| "What would you need to see from me in the first 90 days to know the complaints process is in good shape?" | Makes the success measure theirs, and invites a plan. |
| "How do you define a complaint as resolved: when the member signs off, or when the file closes?" | Asks the question the resolution-times requirement depends on. |

## Sources

- Provided: the JD, the recruiter's email (round structure), the values page as copied on 26 November 2026, the 2026 strategy brief as sent by the recruiter, and your message.
- Research tier: L1. Searches 0 of 6 · fetches 0 of 2. Every target's inputs were already in hand, so no call was sent.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Company values | skipped | The values page you pasted fixes the values cheat sheet |
| 2. Interview process | skipped | The recruiter's email fixes the three rounds and their format |
| 3. Strategy / recent news | skipped | The July 2026 brief fixes current priorities. Checking for newer moves is in the upgrade menu |
| 4. Interviewer footprint | n/a | No interviewer was named, so there is no query to form |
| 5. Representative JD | skipped | The JD you supplied fixes the fit snapshot and the JD questions |

## Upgrade menu

- Names of the Head of Member Services and the two branch managers → tailored reverse questions and persona weights from their public footprint
- Whether you used Excel, and which features → F8 and D2 move from the spreadsheet wording to a named tool
- Whether the spreadsheet held resolution times → F6 and D1 close the resolution-times limit
- Any coaching of supervisors, even informal → a question for the supervisor-coaching requirement, which has none yet
- Your notice period, pay position, location and reason for leaving, in your own words → the recruiter screen's logistics slots, filled
- Hours before 5 December → a prioritised prep schedule sized to that time
- Deep research (L2): a current check of the strategy brief, the interview panel's public material and recent Ashgrove news. Capped at 6 further searches and 2 further fetches. Offered once; not run
- Round 3's case format (whether a written pre-read comes ahead) → coverage of any pre-declared deliverable
