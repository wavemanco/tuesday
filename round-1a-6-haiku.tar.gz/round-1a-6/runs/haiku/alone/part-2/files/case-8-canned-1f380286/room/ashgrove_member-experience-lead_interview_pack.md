# Ashgrove Credit Union: Member Experience Lead. Interview pack (loop mode)

**Role:** Member Experience Lead, Ashgrove Credit Union (member-owned, about 900 staff)
**Candidate:** Dara
**Loop (three rounds, 5 December 2026):**
- Round A, 30 min: recruiter
- Round B, 45 min: Head of Member Services, who would be your manager; mostly behavioural
- Round C, 60 min: panel of two branch managers, including a 20-minute complaint-escalation case; scored against the four values

Interviewer names are not yet known. Persona weights below come from the round descriptions, not from anyone's profile.

## How to use + type key

- **Personas** describe how a question is asked. **Types** describe what is being scored.
- **VAL**: behavioural / values alignment. Whether past behaviour shows the published values.
- **EXP**: work-experience deep-dive. Whether your claims hold up, and what you actually did.
- **JD**: role-driven. Whether you can do the listed job, including its gaps.
- **CO**: company and strategy knowledge.
- **CASE**: live problem.

Guidance is scaffolding, not a script. Rehearse the shape, then say it in your own words. Any sentence in quotation marks is one you wrote; use it as written.

## Fit snapshot

Requirements are quoted from the job description you pasted. Evidence is quoted from your message. Where your material is silent, the row says so and gives an answer slot, not a line to say.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" (JD) | "6 years in retail banking, the last 3 as a branch supervisor" (your message) | medium | [grounded] | presentation | Your material shows six years in retail banking, three as a branch supervisor. Keep the numbers and the words: "Six years in retail banking, the last three as a branch supervisor." The JD counts customer operations; your material shows the years, not that they were in those words. Do not extend it. |
| F2 | "experience handling regulated complaints" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | hard_gate | Surfaced, not bridged. Your material shows a formal complaints log. It does not establish that the complaints were regulated, so the pack does not supply that word. |
| F3 | "Own the member complaints process end to end across branches and the contact centre" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | transferability | At the quote's scope: "For the branch, I handled the formal complaints log." The JD's end-to-end scope is wider. Answer slot: the JD's end-to-end line makes a probe on which stages you ran likely. If you set any stage of the process, say which and how you decided. If none was yours, say so plainly and stay with the log. |
| F4 | "coach branch supervisors on escalations" (JD) | "trained new tellers on our escalation script" (your message) | medium | [grounded] | transferability | At that scope: "I trained new tellers on our escalation script." Training tellers is not coaching supervisors. Answer slot: if you have coached anyone above teller level on an escalation, say what you did. If not, say so and say how you would approach it. |
| F5 | "comfortable with Excel reporting" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | medium | [grounded] | presentation | Your material shows a spreadsheet you built and that is used monthly. Use those words: "I built the monthly complaints spreadsheet our regional manager uses." The word Excel is not in your material; if you built it in Excel, say so in your own words. |
| F6 | "report monthly on complaint volumes and resolution times" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | medium | [grounded] | presentation | Your material reaches monthly complaint reporting. It does not show resolution times. Bridge at the quote's scope: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: the JD names resolution times, so a probe on them is likely. If the spreadsheet tracked how long complaints took, say what, and how it was counted, in your own words. If it did not, say so plainly and say what you would measure first. |
| F7 | "confident presenting to senior leaders" (JD) | "I've never presented to anyone above regional level." (your message) | none | [grounded] | capability | Your own words: "I've never presented to anyone above regional level." Then describe how you would prepare for a senior audience, as a plan and never as a past. |
| F8 | "Own the member complaints process end to end across branches and the contact centre" (JD) | "Never worked in a contact centre" (your message) | none | [grounded] | capability | Your own words: "Never worked in a contact centre." Then how you would learn a contact centre, as a plan and never as a past. |
| F9 | "work with digital teams on self-service journeys" (JD) | none given | none | [grounded] | discovery | Your material is silent on this. Answer slot: if you have worked with a team on a customer-facing journey, say what your part was. If not, say so and say how you would learn it. |

**Requirement coverage.** Each stated requirement maps to the question IDs that rehearse it.

| JD requirement | Question IDs |
|---|---|
| 4+ years in financial-services customer operations | A1, A6 |
| Experience handling regulated complaints | A7, B1, C5 |
| Confident presenting to senior leaders | B4, C9 |
| Comfortable with Excel reporting | B5, C7 |
| Own the complaints process end to end, branches and contact centre | B3, C5, C10 |
| Report monthly on volumes and resolution times | B5, C7 |
| Coach branch supervisors on escalations | B6, C5 |
| Work with digital teams on self-service journeys | B8 (answer slot only; no evidence in your material) |

Nothing is uncovered. Two requirements rest only on answer slots, F9 and the contact-centre side of F3/F8, so they will need the most rehearsal.

## Prohibited claims

Claims this pack will not coach. Each entry gives its basis and the honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end across branches and the contact centre | Inflated form of F3 | "For the branch, I handled the formal complaints log." The pack's observation: the material shows one branch's log. |
| Handled regulated complaints | Inflated form of F2 | "I handled the branch's formal complaints log." The pack's observation: the material does not establish that the complaints were regulated. |
| Trained supervisors on escalations | Inflated form of F4 | "I trained new tellers on our escalation script." |
| Owned resolution-time reporting | Inflated form of F6 | "I built the monthly complaints spreadsheet our regional manager uses." |
| Presented to senior leaders | Stated negative, F7 | "I've never presented to anyone above regional level." No answer slot. |
| Worked in a contact centre | Stated negative, F8 | "Never worked in a contact centre." No answer slot. |

## Strategy grounding (from your summary of the July 2026 brief)

Built from your summary, not the brief itself. If the brief is sent, this section is rewritten.

- **Digital shift.** 40% of member service to digital channels by 2028. Complaints must stay visible in digital routes.
- **Branch consolidation.** Eight branches into five hubs over 2027.
- **Small-business lending.** Launch in Q1 2027.
- **Competitive pressure.** App-only banks.

**Sensitivity flag.** Branch consolidation is personal for branch managers. Do not speculate about which branches close or merge, and do not present the consolidation as your opinion. Questions B9 and C3 touch it. Treat any hub question as a values question about the member, not a question about the plan.

---

## Persona weights by round

Relationship priors come first. Round descriptions adjust them. No interviewer profiles exist, so no interviewer signals apply.

| Round | Persona weights | Reasoning |
|---|---|---|
| A: recruiter, 30 min | Conversational 50%, light Skeptic 30%, logistics 20% | Recruiter screens are friendly but scored. Pay, notice, location and reason for leaving are logistics slots. |
| B: Head of Member Services, 45 min | Values/Behavioural 35%, Skeptic 25%, Pressure 20%, Case 10%, Prober 10% | Your future manager. "Mostly behavioural" puts Values first. A manager buying capability adds Skeptic and Pressure. |
| C: panel of two branch managers, 60 min | Values/Behavioural 35%, Case 30%, Peer Evaluator 20%, Prober 15% | Values are scored; the 20-minute escalation case is a live problem. Branch managers are peers to the role, so the seam and credit questions apply. |

**Highest-ROI prep.** B3, the question on which part of the complaints process you have owned yourself. It is the probe most likely to test F3 and the inflated claim above, and the one most likely to be asked in some form in every round.

---

## Round A: recruiter (8 questions, 30 min)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Tell me about your background in a minute or two." | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | Walk the arc in those words: six years, three as a branch supervisor, then the complaints log, the tellers and the spreadsheet, each in your own words. Aim for 60 to 90 seconds. | F1 and F2 are the first things screened. |
| A2 | "What is your current notice period?" | JD | [generic] logistics slot, no candidate sentence | Give your actual notice period, as you know it. The pack supplies no figure. | Logistics slot; notice is a JD term. |
| A3 | "What are your salary expectations?" | JD | [generic] logistics slot, no candidate sentence | Give your own figure in your own words, or ask for the band first. The pack supplies no figure, range or flexibility. | Logistics slot; pay. |
| A4 | "Where could you work, and how often would you need to be on site?" | JD | [generic] logistics slot, no candidate sentence | Answer with the pattern you can actually work, in your own words. Do not speculate about hub locations. | Logistics slot; location. |
| A5 | "Why are you looking to leave your current role?" | EXP | [generic] logistics slot, no candidate sentence | Give your own reason in one or two sentences. The pack supplies none. | Logistics slot; reason for leaving. |
| A6 | "How does retail banking map onto the customer operations this role describes?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | Say the years in those words, then which parts of the branch work were customer-facing, in your own words. | Tests whether F1 holds up at its scope. |
| A7 | "Have you handled regulated complaints?" | JD | [grounded] "I handled the branch's formal complaints log" | Answer from what you did: say what the log was, and what rules, if any, governed it. If you did not know of rules that governed it, say so plainly. | F2 is a gate the material does not establish; answer from the log, not from the word regulated. |
| A8 | "Do you have any questions for me?" | CO | [generic] | Use the reverse questions below. Never answer with "no". | Rapport interviewers weight this slot heavily. |

**Reverse questions, Round A**

1. "How does this role work with the digital team on the 40% self-service goal?" Why it lands: it ties the role to the strategy without quoting numbers you were not given in the room.
2. "Will the panel score against a shared scorecard?" Why it lands: it shows you care how you are assessed.

---

## Round B: Head of Member Services (10 questions, 45 min)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time you handled a complaint a member would not accept." | VAL | [grounded] "I handled the branch's formal complaints log" | Story from that sentence: the log, and the member who would not accept the outcome. Answer slot: if you held the decision, say what it was and how you reached it. If you did not, say so and tell the part you did handle. | Open prompt on Members First; F2 is the evidence. |
| B2 | "Walk me through how you trained new tellers on the escalation script." | EXP | [grounded] "trained new tellers on our escalation script" | Beats: the new tellers, the script, the training, in those words. Answer slot: if you checked whether tellers used the script correctly, say what you did and how you knew. If you did not, say so. | F4 is the nearest thing to coaching; EXP tests whether you can describe it. |
| B3 | "What part of the complaints process across branches and the contact centre have you owned yourself?" | JD | [grounded] "I handled the branch's formal complaints log"; "Never worked in a contact centre" | "For the branch, I handled the formal complaints log." Then: "I have never worked in a contact centre." Answer slot: if you set any stage beyond the log, say which and how you decided. If none was yours, say so plainly and stay with the log. Hold through two follow-ups by returning to the log. Concede specifically: the contact centre is not in your experience. | F3 is the likeliest inflation probe. This is the highest-ROI prep in the pack. |
| B4 | "Six years in and you have never presented above regional level. Why should senior leaders trust you in a room like that?" | VAL | [grounded] "I've never presented to anyone above regional level." | Pressure: pause, then restate the question. Hold: say what you have done in front of your regional manager and what the spreadsheet is used for. Concede: "I've never presented above regional level, and I would prepare for it properly." Do not claim senior presentations. | F7; holding a position you can back, then conceding the gap. |
| B5 | "Your monthly spreadsheet: did it ever report how long complaints took to resolve?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: if it reported resolution times, say which and how they were counted, and the assumption you would defend least. If it did not, say so plainly and say what you would measure first. | F5 and F6; resolution times are the JD's line, not yet in your material. |
| B6 | "We coach branch supervisors on escalations. You've trained tellers. How would you start with supervisors?" | JD | [grounded] "trained new tellers on our escalation script" | "I trained new tellers on our escalation script." Then a plan for supervisors, as a plan. Answer slot: if you have coached anyone above teller level, say what you did. If not, say so. | F4; the coaching gap is real and should be named plainly. |
| B7 | "Two branches send you complaints at twice the normal rate. What do you do first?" | CASE | [generic] | Clarify first: volumes by branch and by reason, and whether the rate is real. Then check whether the cause is process, staffing or product. Then decide who owns the fix. Say the order aloud. | Generic live problem from the JD's coaching and reporting lines. |
| B8 | "We are moving 40% of member service to digital by 2028. How would you keep complaints visible when they move online?" | CO | [generic] | Name the complaint routes a digital channel has to carry: the in-app report, the call-back, and the handoff to a person. Answer slot: if you have designed any part of a self-service journey, say your part. If you have not, say so and say how you would learn it. | F9 is silent, so this is the only answer slot for the digital requirement. |
| B9 | "Two branches in your region are being merged into a hub. A member writes that their town is losing its branch. What do you say?" | VAL | [generic] | Neighbours, Not Numbers: acknowledge the member's loss in their words. Do not promise what has not been decided. Say what you can do: keep the complaint moving and tell them what changes and when, once it is known. | Sensitive. The values test is how you speak to the member, not your view of the plan. |
| B10 | "Tell me about a time you explained a decision to a member and had to put it more plainly." | VAL | [generic] | Pick a time you explained a decision in writing or in person. If none comes to mind, say so plainly, then give the nearest thing your material carries (the formal complaints log) and how you would put the decision in plain words. | Plain Words; no candidate sentence carries this story. |

**Reverse questions, Round B**

1. "What would a good first ninety days look like for coaching supervisors on escalations?" Why it lands: it turns F4's gap into a plan you can talk through.
2. "How do branch and contact-centre complaints data come together today?" Why it lands: it shows you are thinking about the end-to-end process the JD describes.

---

## Round C: panel of two branch managers (10 questions, 60 min, 20-minute case)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you put a member ahead of a process or a target." | VAL | [generic] | Selection scaffold: pick a time a member's need changed what you did. If none comes to mind, say so plainly, then give the nearest thing your material carries (the formal complaints log) and how you would handle it. | Members First; no candidate sentence carries this story. |
| C2 | "Tell me about a time you explained something to a member and had to say it again." | VAL | [generic] | Selection scaffold: pick a time a member needed a second explanation. If none comes to mind, say so plainly, then describe how you would avoid the second explanation. | Plain Words; the training story is not a member story, so do not stretch it. |
| C3 | "How would you make sure a complaint in a small town gets the same care as one in a city branch?" | VAL | [generic] | Neighbours, Not Numbers: say what you would do for a member whose branch is the town's only one. Do not speculate about the hub plan. | Values round; the consolidation question sits underneath it. |
| C4 | "Tell me about a complaint you kept hold of until it was solved." | VAL | [generic] | Selection scaffold: pick a time you stayed with a complaint to closure. Answer slot: if the log showed closure, say how. If it did not, say so plainly. | Own the Fix; no candidate sentence says a complaint was solved. |
| C5 | "A member's complaint has been escalated three times across two branches and the contact centre. The member now says they will go to the ombudsman. It's your case: walk us through it." | CASE | [generic] | Clarify: what was promised, the timeline, and which rules apply. Keep the fix with you until it is solved. Reply in plain words. Name who owns each step. Set a date. Record the learning for supervisors. | 20-minute case; scored against all four values. Ties F2 and F3 without claiming either. |
| C6 | "The branch manager says the supervisor already told the member no. What do you do now?" | CASE | [generic] | Pressure within the case: do not blame the supervisor. Ask what the member was told and what was promised. Decide whether the no stands, and say why. | Tests composure and ownership under a challenge. |
| C7 | "What number would tell you this escalation has worked?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Name a measure, such as time to resolution or repeat escalations. Answer slot: if your spreadsheet did not track it, say so and say what you would measure first. Name the weakest assumption before they do. | F5 and F6; a figure raises the defend-the-number slots. |
| C8 | "Branch managers hold their own complaint numbers. If you report across the contact centre, what happens to ours?" | CO | [generic] | Propose principles, not a plan you do not know: branch numbers stay branch-owned, the report is shared, and you would check the definitions with each manager first. | Peer seam; objections from Round B return in collegial form. |
| C9 | "Tell me about a time you had to give your senior manager an unwelcome truth." | VAL | [grounded] "I've never presented to anyone above regional level." | Say what you did with your regional manager. If you have not given an unwelcome truth to someone senior, say so plainly and describe how you would. Do not claim a senior presentation. | F7; a values question the material answers only partly. |
| C10 | "How would you run a complaints queue for a contact centre you have never worked in?" | JD | [grounded] "Never worked in a contact centre" | "Never worked in a contact centre." Then a plan: learn from the centre's team leads, sit in on calls, and take the queue's data first. | F8; a plan, never a past. |

**Reverse questions, Round C**

1. "What does a strong escalation look like to you on this panel?" Why it lands: it asks them to name the values in practice.
2. "What could a new person do in the first month that would genuinely help your branches with complaints?" Why it lands: a peer question. It shows what you would bring to their work, not just what you need.

---

## Values cheat sheet

| Value (official name) | Working meaning | Mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter. | No candidate sentence carries a member-first story. Use C1's selection scaffold and its honest branch. |
| Plain Words | If a member needs it explained twice, we wrote it wrong. | "trained new tellers on our escalation script" carries training, not plain words. Use C2's scaffold. |
| Neighbours, Not Numbers | Every branch is part of its town. | No candidate sentence carries this. Use C3's scaffold, and keep the hub plan out of it. |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved. | No candidate sentence says a complaint was solved. Use C4's scaffold and its honest branch. |

## Sources

Research tier: L0. No searches or page fetches were run. Every target below is covered by inputs you pasted.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | Your pasted copy of the values page fixes the cheat sheet. |
| 2. Ashgrove interview process | skipped | Your recruiter email fixes the three rounds and their weights. |
| 3. Ashgrove strategy / recent news | skipped | Your summary of the July 2026 brief fixes the strategy grounding. The brief itself would sharpen it. |
| 4. Interviewer names | n/a | No names given, so there was no query to form. |
| 5. Representative JD | skipped | The JD you pasted fixes the fit snapshot and the JD-tagged questions. |

Provided documents: the JD text, the values copy (26 November 2026), the recruiter's email, your summary of the strategy brief, and your background.

## Upgrade menu

- The names of the Head of Member Services and the two branch managers → personas weighted from their public footprint, and tailored reverse questions
- The full July 2026 strategy brief → a fuller grounding section and sharper strategy questions (B8, C8)
- Whether the complaints you handled fell under a regulator's or ombudsman's rules → F2 becomes a row the pack can bridge
- Whether the spreadsheet tracked resolution times, and how → F6 and questions B5 and C7 become rehearsable with figures you can defend
- Whether you have built or used any digital self-service journey → F9 gets a grounded bridge in place of an answer slot
- Deep research on Ashgrove's recent moves and loop reports → a more current strategy section
- A tuesday-dossier.md → verified evidence and any risks it carries
