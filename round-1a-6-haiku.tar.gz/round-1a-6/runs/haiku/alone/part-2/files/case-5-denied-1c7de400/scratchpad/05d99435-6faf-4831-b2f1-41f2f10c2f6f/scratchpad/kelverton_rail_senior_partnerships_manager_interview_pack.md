# Kelverton Rail, Senior Partnerships Manager: second-round panel prep

Role: Senior Partnerships Manager. Company: Kelverton Rail (UK rail-tech, ~600 staff, sells scheduling software to train operating companies). Round: second round, 60 minutes, panel. Interviewers: Deepa (VP Partnerships, future manager) and Ross (Commercial Director). Structure: first 15 minutes, a spoken point of view on operator partnerships over the next 18 months, no slides; remaining time Q&A, with Ross pushing on commercials. First build for this round, so there is no changelog.

## How to use + type key

Personas describe how a question arrives. Types describe what it is scoring. The guidance is scaffolding, not a script. Say it in your own words, and only the parts you can stand behind.

- **VAL**: behavioural / values alignment (none detected for this company, so none in this pack)
- **EXP**: work-experience deep-dive; whether your claims survive scrutiny
- **JD**: role-driven; can you do the job as the panel describes it
- **CO**: company and strategy knowledge (none researched; see Sources)
- **CASE**: live problem set in the role; structure and reasoning

## Prep triage

Prep time is about 4 hours over the weekend. In priority order:

1. **About 75 minutes: the POV, spoken aloud and timed.** Build it from the POV build section below and say it out loud twice, aiming at 15 minutes. Practise the close: what it means for the operators themselves.
2. **About 45 minutes: the influenced-revenue answer (A1, A2).** Write your answer to the £4M figure in your own words: how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. Then say it aloud. Ross will push here.
3. **About 30 minutes: the rail gap (B3).** Practise the plain acknowledgement ("I haven't sold into rail") and then a concrete first-90-days plan. This is the most likely objection, so it gets the most repetitions.
4. **About 30 minutes: drill.** Run A1 and B3 live (see the drill offer below).
5. **About 30 minutes: reverse questions and the report.** Choose three reverse questions (see Reverse questions). If you can paste the market report, read it once and note where your POV agrees and where it differs.

Everything else is insurance.

## Fit snapshot

No job description was supplied. The requirements below come from the recruiter's own words, quoted, which the skill treats as the raising source for this round. Quotes come only from your message or the recruiter's words as you pasted them.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "where I'd take our operator partnerships over the next 18 months" (recruiter) | "9 years in partnerships" (your message); "Last 4 at a payments company running the ISV channel" (your message) | medium | [grounded] | transferability | Your material is partnerships and the ISV channel, not operator partnerships. Say the channel you ran and the operator frame you are bringing, in your own words. Answer slot: the panel will probe how an ISV channel transfers to a buyer who is not a reseller. If you can name where that transfer holds and where it breaks, say so. If you have not worked it through, say so and give your reasoning. |
| F2 | "Please land on what it means for the operators themselves." (recruiter) | "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" (your message) | medium | [grounded] | transferability | Your operator knowledge is from the consultant side. Say that plainly, and do not describe it as knowing how operators buy. Answer slot: if you have seen a decision an operator made about planning or scheduling, say what you saw; if you have not, say that and describe what you would need to learn. |
| F3 | "Ross will push on commercials." (recruiter) | "Never carried a direct quota; influenced revenue only." (your message) | high | [grounded] | capability | Gap wording you stated: "I've never carried a direct quota. My number is influenced revenue." Then how you would learn to own a commercial number, as a plan, never as a past. |
| F4 | Rail-specific sales (recruiter's description of the company, as supplied by you) | "Never sold into rail specifically" (your message) | high | [grounded] | capability | A negative you stated, so it can be said back: "I haven't sold into rail." Then the ramp plan, never a claim to rail sales. |
| F5 | "where I'd take our operator partnerships" growth record (recruiter) | "took it from 6 partners to 40" (your message); "roughly £4M of influenced revenue" (your message) | medium | [grounded] | discovery | The growth is in your material, but the mechanism is not. Answer slot: the panel will ask what you did to grow the channel and how the £4M was counted. If you did a specific thing, say it in your own words. If it was not yours, or there was no such step, say so plainly and stay with the numbers. |

Requirement coverage: the recruiter's words supply four requirement lines (operator partnerships, operator outcomes, commercials, the 18-month plan). Each maps to at least one question below: operator partnerships to B1 and B2; operator outcomes to C1 and C2; commercials to A1 to A5; the 18-month plan to B1 and the POV. No requirement is left uncovered.

## Graded deliverables

### POV build (15 minutes, no slides)

**Facts to build on** (from the fit snapshot):
- F2, quoted: "so I know the operator world from the other side" (your message).
- F5, quoted: "took it from 6 partners to 40" (your message).

**Theses.** Pick one, or at most two. Each comes with a concession you say out loud.

- **T1: start from the operator's planning cycle, not the vendor's roadmap.** Partnerships start where an operator's timetable change actually happens, then extend to the partners who serve that moment. Concession: "I haven't sold into rail, so my view of operator buying comes from the consultant side, not the procurement side."
- **T2: make partner payment follow operator outcomes, not just resale.** The commercial model rewards partners for operator results. Concession: "I haven't measured this in rail. Treat the numbers as assumptions to test, not as results."
- **T3: the ISV channel does not transfer directly.** ISVs resell; operators buy directly or through their own IT. Concession: "I may be wrong about how operators procure. That is the first thing I'd check."

**Differentiation.** The market report is not in this conversation, so I cannot say what its consensus answer is. Do not commit to a differentiation until you have read it. Once you have, bring one consensus point to show you have read it, then one thesis of your own that departs from it, with reasons.

**The close** (requested by the recruiter): "what it means for the operators themselves." End on one concrete thing an operator gets in the first 90 days, in your own words. Do not end on a claim you cannot back.

## Reading the interviewer

No interviewer profiles were researched. Names only: Deepa (VP Partnerships) and Ross (Commercial Director). No public footprint has been read. The personas below are relationship priors for a hiring manager and a commercial director, not personality reads. Add surnames or profiles and the weights can be tuned.

## Persona table

| Persona | Who it fits | How it shows up | Likelihood | Reasoning | Counter-strategy |
|---|---|---|---|---|---|
| Pressure / commercial | Ross | Pushes on the £4M figure, the lack of a quota, pricing and margin | high | The recruiter said so in writing: "Ross will push on commercials." | Hold the figure in its own scope; concede the no-quota fact plainly; do not defend a number you cannot account for |
| Data-Driven Prober | Ross | Asks how the £4M was counted and what sits behind it | high | Commercial directors check how influenced revenue is attributed | Know your attribution method in your own words; name the weakest assumption before he does |
| Case / Strategist | Deepa | Live operator problem; plan the first 18 months | high | Hiring manager; the POV and "over the next 18 months" are her framing | Clarify, then structure, then answer; say your hypothesis early |
| Skeptic | Deepa | Asks about rail and the operator buyer | high | No rail sales experience, and a recruiter-flagged gap | The plain acknowledgment, then a ramp plan with specific learning steps |
| Values / Behavioural | Neither | Not signalled | low | No values round detected | Not in this pack |

Depth: the top personas (Pressure and Prober for Ross, Case and Skeptic for Deepa) get the most questions. The minor personas get two each.

## Question banks

### Bank A: Ross (Pressure, Data-Driven Prober), weight high

| ID | Type | Question | Provenance | Guidance | Rationale |
|---|---|---|---|---|---|
| A1 | EXP | "Roughly £4M of influenced revenue. What share of that would have happened without the partners?" | [grounded] "roughly £4M of influenced revenue" (your message) | Defend-the-number slot. Answer slot: if you did the attribution, say how you counted it, in your own words, what it is sensitive to, and the assumption you would defend least. Name which part was yours. If you did not count it, or the attribution was not yours, say so plainly and return to the figure as it is. Do not invent a method or a baseline. | Figures attract probers. The panel will test whether you know your own number |
| A2 | EXP | "You have never carried a direct quota. Why should we believe you can own a commercial number here?" | [grounded] "Never carried a direct quota; influenced revenue only." (your message) | Plain acknowledgement, then a plan: "I haven't carried a direct quota. My number has been influenced revenue. Here is how I would learn to own one." Do not claim quota-like work you did not do. | Ross will test the no-quota gap directly. A plan beats a bluff |
| A3 | CASE | "An operator tells you they will not pay for scheduling software on top of their planning tools. What do you say?" | [generic] (no candidate sentence; the question is a live problem) | Clarify what the operator's objection is about (budget, risk, integration). Then name the value to them and the cost to switch, and say what you would test. Do not invent operator figures. | Ross will push on whether the operator sees value. A live problem tests commercial reasoning |
| A4 | CO | "How would you price a partnership with an operator: reseller margin, revenue share, or a direct licence?" | [generic] (no candidate sentence) | Name the trade-off between margin, control, and speed to revenue. Choose one, and say what would make you change it. | Commercial pricing question. It tests whether the answer survives Ross's follow-up |
| A5 | JD | "Walk me through how you'd measure partner revenue for an operator-facing channel." | [grounded] "roughly £4M of influenced revenue" (your message) | Start from what you measured before, in your own words, then say how an operator channel would differ. Answer slot: if you have a method for operator-facing revenue, say it; if not, say so and say what you would measure first. | Measurement is commercial, and the recruiter flagged commercials |

### Bank B: Deepa (Case / Strategist, Skeptic), weight high

| ID | Type | Question | Provenance | Guidance | Rationale |
|---|---|---|---|---|---|
| B1 | CASE | "Tell me where you'd take our operator partnerships over the next 18 months." | [grounded] "where I'd take our operator partnerships over the next 18 months" (recruiter) | This is the POV. Use the build section. Open with the operator, then the thesis, then the concession. Stay inside the 15 minutes | The recruiter named this as the first 15 minutes |
| B2 | EXP | "You took the channel from 6 partners to 40. What did you do to make that happen?" | [grounded] "took it from 6 partners to 40" (your message) | Answer slot: if you did a specific thing that caused the growth, say what it was and what part was yours. If there was no such step, or it was not yours, say so plainly and stay with the numbers. | The question asks for a practice. The panel may probe a choice you did not make |
| B3 | JD / Skeptic | "You've never sold into rail. Where would you be weakest on day one?" | [grounded] "Never sold into rail specifically" (your message) | Plain acknowledgement: "I haven't sold into rail." Then name the weakest area on day one, which is the operator's buying process. Then a ramp plan: three things you would learn in the first 30 days and who you would learn them from. | The most likely objection. Give it the most repetitions |
| B4 | Skeptic | "Why would someone from payments and transport consulting be the right person for rail?" | [grounded] "5 years in transport consulting" and "9 years in partnerships" (your message) | Name the transfer that holds (partnerships, operator-side planning knowledge) and the one that does not (rail sales). Concede the gap in your own words. | Motivation consistency and a credibility check |

### Bank C: operator follow-ups (Case, Deepa and Ross), weight mid

| ID | Type | Question | Provenance | Guidance | Rationale |
|---|---|---|---|---|---|
| C1 | CASE | "What does this mean for a train operator's own planning team?" | [grounded] "Please land on what it means for the operators themselves." (recruiter) | Name one operator role (planner, scheduler, commercial lead) and the one thing it changes for them in the first 90 days. Say how you would know it changed. | The recruiter's close, asked as a follow-up |
| C2 | CASE | "Which operator would you start with, and what would you need to learn from them?" | [generic] (no candidate sentence) | Name a type of operator (size, network, franchise model) and the two things you'd need to learn from it. Do not name a real operator as a fact you know. | Tests whether you think at operator level, not the vendor's |

## Requirement coverage

| Requirement (source) | Question IDs |
|---|---|
| "where I'd take our operator partnerships over the next 18 months" (recruiter) | B1, B2, F1 |
| "Please land on what it means for the operators themselves." (recruiter) | C1, C2, F2 |
| "Ross will push on commercials." (recruiter) | A1 to A5, F3 |
| Rail experience (your message) | B3, B4, F4 |

## Reverse questions

Each has a "why it lands." Deepa is the future manager; Ross is the commercial director. No profile tie-in yet.

1. **To Deepa:** "What would you need to see in the first 90 days to think this hire has worked?" *Why it lands:* it turns the Skeptic probe into a shared success measure.
2. **To Ross:** "When an operator partnership hit the commercial model, where did it usually break?" *Why it lands:* it shows you are thinking about margin and risk, and it invites him to answer the commercial question himself.
3. **To Ross:** "How is partner-influenced revenue credited today, against direct revenue?" *Why it lands:* it signals you know the attribution problem and asks for the rule, not a figure.
4. **To Deepa:** "Which operator relationship would you most want protected in the next 18 months?" *Why it lands:* it asks for the priority, and frames your POV as operator-first.
5. **To Deepa:** "What did the last person in this role get wrong that you'd want fixed?" *Why it lands:* it is candid, and it opens the question of what the panel actually expects.

## Prohibited claims

Built locally from the fit snapshot. None of these may be asserted, softened, or implied in answers.

| Claim | Kind | Basis | Honest form |
|---|---|---|---|
| "I owned the revenue number" / "I carried a quota" | inflated form | F3: "Never carried a direct quota; influenced revenue only." | "My number was influenced revenue. I have not carried a direct quota." |
| "I've sold into rail" / "I know the rail buyer" | sourced entry | F4: "Never sold into rail specifically" | "I haven't sold into rail." Then the ramp plan |
| "I built" / "I designed" the ISV channel | inflated form | F1: "running the ISV channel" | "I ran the ISV channel." |
| "I know how operators buy" | inflated form | F2: "so I know the operator world from the other side" | "I know the operator world from the consultant's side." |
| "The £4M was mine" / "I sourced the £4M" | inflated form | F5: "roughly £4M of influenced revenue" | "roughly £4M of influenced revenue", with the attribution in your own words |

## Sources

- **Provided documents:** your message (the candidate background and the panel details). Quoted in the fit snapshot as "your message." The recruiter's email wording came via your message, quoted as "recruiter."
- **Market report (internal strategy report, last quarter):** attached by the recruiter; you read it; **not pasted here**, so it was not used. The POV's differentiation section is therefore unfinished.
- **Research tier: L1 (default), requested. All web searches were refused by the host's permission setting. No results came back.**
- **Target accounting:**
  - Company values: not run (refused)
  - Loop structure: not run (refused)
  - Current strategy: not run (refused)
  - Interviewer public footprint: skipped (names only, no surnames)
  - Representative JD: not run (refused)
- No dossier was consumed.

Nothing in this pack about Kelverton Rail's values, strategy, products, customers, or competitors is verified. Treat every company fact as yours to check before the interview.

## Upgrade menu

- The job description text → turns the recruiter-sourced requirement rows into grounded rows, and adds JD-tagged questions for each listed requirement
- The market report text (paste it) → lets the POV's differentiation be written against the consensus answer instead of left open
- The panel's surnames, or their public profiles → personalised persona weights and a tailored reverse question
- Permission to run web search → company values, loop structure and current strategy, which are not in this pack
