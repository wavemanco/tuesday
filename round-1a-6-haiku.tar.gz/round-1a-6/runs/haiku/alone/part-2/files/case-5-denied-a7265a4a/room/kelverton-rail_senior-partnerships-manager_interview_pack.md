# Interview prep pack: Senior Partnerships Manager, Kelverton Rail

Round: second round, Tuesday 1 December. Panel: Deepa (VP Partnerships, your future manager) and Ross (Commercial Director). 60 minutes: first 15 minutes a spoken POV, no slides, then Q&A with Ross pushing on commercials.

Built without a job description and without research (see Sources). Company facts are not in this pack. Anything about Kelverton is marked `[generic]` or is a quote from the recruiter's email.

## How to use this pack and the type key

Personas describe how a question arrives. Types describe what is being scored.

- **VAL**: behavioural and values alignment (none detected here; no published values were retrieved)
- **EXP**: experience deep-dive: whether your claims survive scrutiny
- **JD**: role-driven: what the job asks of you, including gaps
- **CO**: company and strategy knowledge (none in this pack; research did not run)
- **CASE**: a live problem from the role, reasoned aloud

Guidance is scaffolding, not a script. Each guidance cell is speakable in about 90 to 120 seconds. Where a guidance cell says "answer slot", it is an instruction for the interview, not a question for you to answer here.

## Prep triage (four hours)

1. **75 minutes: build and time the POV.** One thesis, the concession that goes with it, and an operator-outcome close. Deliver it aloud twice and keep it under 12 minutes. Rows A1, A2, A5 and the graded-deliverable section.
2. **60 minutes: rehearse the Skeptic objection, B1, with its follow-ups.** This is the highest-return prep in the pack. The panel will very likely ask some version of "you've never sold into rail", and a non-defensive, specific answer changes the room. Then B3 and C1 for the commercials.
3. **45 minutes: commercials, C1 to C4.** Hold-then-concede on influenced revenue versus quota.
4. **30 minutes: pick three reverse questions** from the list and say them aloud.
5. **30 minutes: insurance.** A3, A4, B2, B4, D1 to D3.

Everything else is insurance.

## Fit snapshot

Requirements come from the recruiter's email, quoted. No job description was supplied, so the requirement column is lighter than a normal pack's, and rows marked `[generic]` describe role-family expectations, not anything Kelverton has stated.

| ID | Requirement and source | Evidence (quoted from your inputs) | Confidence | Provenance | Gap type | Gap and bridge |
|---|---|---|---|---|---|---|
| F1 | "where you'd take our operator partnerships over the next 18 months" (recruiter email) | "9 years in partnerships, last 4 at a payments company running the ISV channel" | medium | [grounded] | transferability | Partnership management carries over. Operators are a new counterparty type. Bridge by saying what you would test first with operators, not by claiming operator relationships you have not had. |
| F2 | "Please land on what it means for the operators themselves." (recruiter email) | "bus and light rail network planning, so I know the operator world from the other side" | medium | [grounded] | presentation | Verified planning-side experience exists; the job needs it framed as the operator's outcome. Frame it as the planning view, not as operator-side commercial experience. |
| F3 | "Ross will push on commercials." (recruiter email) | "took it from 6 partners to 40, roughly £4M of influenced revenue" | medium | [grounded] | transferability | Influenced revenue is a different number from owned revenue. Say what "influenced" meant in your counting and which part was yours. |
| F4 | Rail and operator selling, `[generic]` expectation for a rail-tech vendor | "never sold into rail specifically" | high | [grounded] | transferability | Payments ISV channel work is adjacent: selling through partners into a regulated buyer is the nearest match. Bridge with that, and name the rail-specific parts as new. |
| F5 | Direct quota ownership, `[generic]` expectation for a senior commercial role | "never carried a direct quota, only influenced revenue" | high | [grounded] | capability | No direct quota experience. Name a closure path you can describe: what you would want your first-year target to be measured on, and how you would learn the buying cycle. |
| F6 | Location, right to work or clearance, `[generic]` gate | None given in your inputs | none | [generic] | hard_gate | Not established. Surface prominently. Confirm before Tuesday (see upgrade menu). |

Your own two negatives in F4 and F5 are the most important lines in the table. They are specific and you stated them, so they can be said plainly. Do not soften them.

## Prohibited claims

These are the claims this pack will not coach. Each has its basis. No answer slot, hold, bridge or rationale in this pack asserts, softens or implies them.

| ID | Claim the pack will not coach | Basis | Honest form |
|---|---|---|---|
| PL1 | Carrying a quota | Sourced: you stated "never carried a direct quota" | "I haven't carried a direct quota. My revenue was influenced." |
| PL2 | Selling into rail | Sourced: you stated "never sold into rail specifically" | "I haven't sold into rail." |
| PL3 | "Built the channel" | Inflated form: your sentence says "took it from 6 partners to 40". Pack observation: the material says you grew it, not when it started or who set it up. | "I took it from 6 partners to 40." |
| PL4 | "My £4M" or "I generated £4M" | Inflated form of "roughly £4M of influenced revenue" | "Roughly £4M of influenced revenue." |
| PL5 | "I know how operators make commercial decisions" | Inflated form of "so I know the operator world from the other side". Pack observation: your material shows the planning side, not operator procurement or commercial decisions. | "I know the planning side of the operator world." |

## Question banks

Coverage note: 16 questions in total, under the 18 that a full pack targets. The shortfall is because no job description or research was available. A JD would raise the count.

Persona weights: Case/Strategist highest (Deepa is hiring manager and this is a POV round). Skeptic second (the rail and quota gaps are obvious to any panel). Pressure and commercial probing for Ross. Data-driven prober third. No values, conversational or peer persona in this round.

### Persona A: Case / Strategist (weight: top, 5 questions)

| ID | Type | Question | Provenance | Guidance | Rationale |
|---|---|---|---|---|---|
| A1 | CASE | Walk us through your 18-month view of operator partnerships. | [grounded] "where you'd take our operator partnerships over the next 18 months" | Lead with the operator outcome. State one thesis in a sentence, then the concession that goes with it, then three steps across the 18 months. Do not name any Kelverton fact. Stay under 12 minutes. | This is the graded POV. Type CASE because it is a live problem about the role. |
| A2 | CASE | What does this mean for the operator in practice? | [grounded] "Please land on what it means for the operators themselves." [grounded] "bus and light rail network planning, so I know the operator world from the other side" | Name one operator decision you would want to make easier and say how you would know it worked. If the planning work shows a decision like this, name it in your own words. If it does not, say you would test it with operators first. | This is the close the recruiter asked for. Answer slot: your planning-side view may support the decision, but only in your own words. |
| A3 | CASE | Which operator would you start with, and why? | [grounded] "where you'd take our operator partnerships" | Give two selection criteria, such as the size of the relationship and whether a relationship already exists. Say which one you would not pick first and why. | Tests whether you think like someone who has to pick and commit. |
| A4 | JD | What would you stop doing from the current approach? | [grounded] "our operator partnerships" | Name one thing you would stop, and say what evidence would make you stop it. If you have not seen the current approach, say so and name the question you would ask first. | Tests whether you can challenge a current approach you have not yet been inside. |
| A5 | JD | How would you know in 18 months that it worked? | [grounded] "over the next 18 months" | Name one operator-side measure and one commercial measure. Say which one you would be least sure of. | Ties the POV to a measure, and shows you know where your evidence is weakest. |

### Persona B: Skeptic (weight: second, 4 questions)

| ID | Type | Question | Provenance | Guidance | Rationale |
|---|---|---|---|---|---|
| B1 | JD | You have never sold into rail. Why would an operator take a call from you? | [grounded] "never sold into rail specifically" | **Highest-return prep in this pack.** Hold: partnership and channel work transfers, and you have done it into a regulated buyer. Hold that through two follow-ups. Concede specifically: operator buying cycles and rail procurement are new to you. Name the first thing you would do: how many operator conversations you would want before pitching anything. Answer slot: if you have sold into any regulated or public buyer, name it in your own words. If not, say so. | This is the single most predictable objection. Deepest rehearsal in the pack. |
| B2 | EXP | Tell me about a partner you lost or never signed. Why? | None; open prompt from the Skeptic persona stem | Selection scaffold: pick a partner that did not work out. If you did not lose one, say so and give the nearest thing your material carries. If you do not know why, say you would find out. | Tests whether you can talk about failure without spin. Open prompt, so no premise. |
| B3 | EXP | How much of the roughly £4M was yours? | [grounded] "roughly £4M of influenced revenue" | Defend-the-number slots, in your own words: how you counted it, what it is most sensitive to, the assumption you would defend least, and which part was yours. Answer slot: if a step was not yours, say so plainly. Do not give a method you cannot repeat. | Your figure is the easiest thing for a prober to test. Influenced revenue invites the question. |
| B4 | JD | Rail is a regulated, procurement-heavy market. What in your background says you would manage that? | [grounded] "bus and light rail network planning" | Name the closest thing you have. If the closest thing is planning-side work, say that. If you have no procurement experience, say so and name how you would learn the buyer. Do not assert anything about rail procurement you have not seen. | Skeptic framing of the same gap as B1, from the other direction. |

### Persona C: Pressure / commercial probe for Ross (weight: third, 4 questions)

| ID | Type | Question | Provenance | Guidance | Rationale |
|---|---|---|---|---|---|
| C1 | JD | What would you accept as a commercial target for operator partnerships in year one? | [grounded] "never carried a direct quota, only influenced revenue" | Hold: influenced revenue is accountable revenue, and you can be measured on it. Hold through two follow-ups. Concede: you have not carried a direct quota. State the thing you would want to see in the target: how it is split between direct and influenced revenue. Do not name a number. Answer slot: if you have a view on a year-one number, state it. | Ross will push on commercials. This is the question most likely to make you name a figure you cannot defend. |
| C2 | EXP | Of the growth from six partners to forty, what would have happened without you? | [grounded] "took it from 6 partners to 40" | Answer slot: if you were the cause, say how, in your words. If the product or market was the cause, say that. Do not name a programme or method you did not run. | Tests attribution. Premised question? No: it asks for a counterfactual, not a practice. |
| C3 | CASE | Operators work on multi-year budgets and fixed cycles. How do you make a commercial case when the budget is not there? | None; a hypothetical from the interviewer's own framing | Name one trade-off between price and a shared outcome. Name the concession: you do not know this buyer's budget cycle yet. | A live problem for the role. It presupposes nothing about you. |
| C4 | JD | What would you give up to get an operator to co-invest? | None; hypothetical from the commercial frame | Name one thing you would give up and one thing you would not. State which you would concede first. | Ross wants to see you trade. Hold-then-concede again. |

### Persona D: Data-driven prober (weight: third, 3 questions)

| ID | Type | Question | Provenance | Guidance | Rationale |
|---|---|---|---|---|---|
| D1 | JD | What operator-side metric would you put in front of Ross first? | [grounded] "where you'd take our operator partnerships" | Name one metric, say what it measures, and say the assumption behind it that you would defend least. | Puts the operator outcome into a number, which is what Ross will look for. |
| D2 | EXP | Your channel grew from six partners to forty. What share came from the partner programme and what share from the product? | [grounded] "took it from 6 partners to 40" | Answer slot: if the programme drove it, say how in your words. If the product did, say that. Do not name a programme you did not run. | Premised question about a practice; the answer slot is the honest form. |
| D3 | EXP | What did you get wrong in the channel? | None; open prompt from the prober persona stem | Selection scaffold: pick one decision that did not work. If none comes to mind, say so plainly, then give the nearest thing your material carries and how you would handle it. | Tests candour. A specific, owned miss is stronger than a list of wins. |

## Requirement coverage

| Requirement (source) | Questions |
|---|---|
| 18-month operator partnerships POV (recruiter email) | A1, A5, D1 |
| Operators themselves, the close (recruiter email) | A2, A3 |
| Commercials, Ross to push (recruiter email) | C1, C2, C3, C4, B3 |
| Rail sales and quota (`[generic]`) | B1, B4, C1 |
| Influenced revenue (your background) | B3, C2, D2 |
| Location, right to work, clearance (`[generic]` gate) | none, and why: a gate is a yes or no about your status, not a question for rehearsal. Confirm before Tuesday. |

No job description was supplied, so no requirement from a JD is covered. A JD would add rows.

## Graded deliverable: the 15-minute POV

Your POV was announced by the recruiter, so it is graded. Build it from these options, each with a concession.

- **Thesis 1: operator-as-planner.** Partnerships built around what an operator's planning team needs to decide faster. Grounded in F2, the planning-side view. Concession: you do not yet know this operator base or where Kelverton is already strong. Differentiation: most candidates will pitch ecosystem breadth; you lead with the planning decision.
- **Thesis 2: shared outcomes, not only licences.** Partnerships priced or structured around an outcome the operator can see. Concession: you have not structured operator-facing commercial terms. Differentiation: this answers Ross's commercial question before he asks it.
- **Thesis 3: channel-led growth, with a limit.** Use the ISV channel model from F1 as a starting point, and say where operators would not buy the way partners do. Concession: rail may not have a comparable partner ecosystem, and you would test that first. This is the anti-pick: do not recommend a broad partner-count target for operators.

The close the recruiter asked for is the operator's outcome. Say what changes for them, in a sentence, and say how you would know. Anything about the operator's outcome is `[generic]` unless the operator's own words are quoted.

## Reverse questions

Each one has a reason it lands.

1. **Deepa:** What would you need to see from me in the first 90 days to say the operator approach is working? Lands because it shows you are measuring your own work from the start.
2. **Ross:** How are commercial targets for partnerships split between direct and influenced revenue today? Lands because it shows you understand the gap and want the rule before you are measured on it.
3. **Deepa:** Which operator relationship is most at risk or most important over the next year? Lands because it signals you think about operator outcomes, not only pipeline.
4. **Ross:** What has the operator partnership approach tried in the last 18 months that did not land? Lands because it invites candour, and you can then build on the answer.
5. **Deepa:** What would make this role fail in the first year? Lands because it shows you are looking for the real risk, not a flattering answer.

No interviewer profile was provided, so no reverse question is tied to either interviewer's own career path.

## Not included in this pack

- **Interviewer read (section 7):** no profiles, only names and titles. Dropped.
- **Values cheat sheet (section 10):** no values were retrieved and no values round was detected. Dropped.
- **Grounding brief (section 6):** research did not run. Dropped.
- **Delivery coaching (section 12):** no assessment provided. Dropped.

## Sources

- **Provided documents:** the recruiter's email, quoted in your message (panel, format, POV instructions). Your background, quoted in your message. The strategy team's market report: you read it, and it is not in this session, so no claim here draws on it.
- **Searches and fetches:** three standard web searches were sent, for Kelverton's values, its interview process, and its recent strategy. All three were refused: web search permission was not granted in this session. No page fetches were attempted.
- **Research tier:** L0 (provided documents only).
- **Target accounting:**
  - Target 1, `{company} values`: unavailable (search refused).
  - Target 2, `{company} interview process`: unavailable (search refused).
  - Target 3, `{company} strategy`: unavailable (search refused).
  - Remaining L1 targets: skipped.
  - L2 targets: n/a.

## Upgrade menu

- **Job description text** → turns the `[generic]` requirement rows into `[grounded]`, and adds a JD-coverage section and JD-typed questions.
- **Your location and right-to-work status, and the role's stated location** → closes the F6 hard-gate row. Until then it is open.
- **Kelverton's published values or operating principles, pasted** → adds a values cheat sheet mapped to your stories, and a VAL bank.
- **The relevant sections of the strategy team's market report, pasted** → makes the CO questions and the thesis concessions grounded in the company's own stated direction, and lets you check Thesis 2 against it.
- **Public profiles for Deepa and Ross, pasted as text** → a reading of each interviewer and persona weights tuned to them, plus interviewer-path reverse questions.
- **Re-running web research once permission is granted** → company values, interview structure and recent strategy, at the default research tier.
- **The recruiter's note on whether the POV is scored separately or pre-read** → changes how much of the 15 minutes goes to the thesis versus the operator close.
