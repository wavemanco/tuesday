# Interview prep pack: Member Experience Lead, Ashgrove Credit Union

**Candidate:** Dara
**Role:** Member Experience Lead (member-owned credit union, about 900 staff)
**Rounds (5 December 2026):** (1) 30 min with the recruiter; (2) 45 min with the Head of Member Services, your future manager, mostly behavioural; (3) 60 min with a panel of two branch managers, including a 20-minute complaint-escalation case, scored against the four values.
**Interviewers:** names not yet assigned for rounds 2 and 3, so persona weights are round priors, not personal reads.
**Built on:** the JD and values text you pasted, the recruiter's process email, the July 2026 strategy brief, and your background as you described it. I assumed the 20-minute case is given live. If it comes with written material in advance, section 5 changes (see the upgrade menu).

---

## 1. How to use this pack

- **Personas** describe how a question arrives (friendly, sceptical, scoring against values, and so on). **Types** describe what is being scored.
- Type key: **VAL** behavioural/values alignment; **EXP** your own past work; **JD** the job's stated requirements; **CO** company and strategy knowledge; **CASE** a live problem.
- The guidance is scaffolding, not a script. Aim to say each answer in 90 to 120 seconds, in your own words.
- Where you see an **answer slot**, it is an instruction for the interview: answer either branch honestly. It is not a question to me.

---

## 2. Fit snapshot

Requirements are quoted from the JD you supplied. Evidence is quoted from your own words. Where your material is silent, the pack says so and does not fill the gap.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" (JD) | "6 years in retail banking, the last 3 as a branch supervisor" (your message) | medium | [grounded] | none | No gap on years. Bridge: "Six years in retail banking, three of them as a branch supervisor." Limit: self-reported, so expect the dates to be checked. |
| F2 | "experience handling regulated complaints" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | discovery | Your material shows a formal log. It does not show whether those complaints were regulated. Bridge stays with the quote: "I handled the branch's formal complaints log." Answer slot: if the log recorded complaints against an outside rule or timescale, say which and how you tracked it; if it did not, say so plainly and say what it did record. |
| F3 | "report monthly on complaint volumes and resolution times" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | medium | [grounded] | discovery | Monthly reporting is reached. Volumes and resolution times are not shown. Answer slot: if the spreadsheet counted volumes or time to resolve, say which and how each was counted; if it did not, say what it tracked. |
| F4 | "comfortable with Excel reporting" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | medium | [grounded] | none | The spreadsheet reaches the requirement in role terms. Limit: your material says spreadsheet, not Excel. Name the software in your own words if asked. |
| F5 | "coach branch supervisors on escalations" (JD) | "trained new tellers on our escalation script" (your message) | medium | [grounded] | transferability | Coaching tellers is adjacent to coaching supervisors. Bridge: "I trained new tellers on our escalation script." Limit: tellers, not supervisors. |
| F6 | "Own the member complaints process end to end across branches and the contact centre" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | transferability | One branch's log is adjacent to an end-to-end process across branches and a contact centre. Bridge: "I handled the branch's formal complaints log." Limit: one branch, and no contact centre. |
| F7 | "work with digital teams on self-service journeys" (JD) | none given | none | [grounded] | discovery | Silence is not absence. Answer slot: if you have worked with a digital or product team on a member route, say what it was and what your part was; if you have not, say so plainly and say how you would start. |
| F8 | "across branches and the contact centre" (JD) | "Never worked in a contact centre" (your message) | none | [grounded] | capability | A gap you stated. Words: "I haven't worked in a contact centre." Then how you would learn it, as a plan, never as a past. |
| F9 | "confident presenting to senior leaders" (JD) | "I've never presented to anyone above regional level" (your message) | none | [grounded] | capability | A gap you stated. Words: "I haven't presented to anyone above regional level." Then how you would prepare, as a plan, never as a past. |

**Gate check.** None of the JD's requirements is a gate under the evidence conventions. The JD states no licence, credential or location bar, so no gate row appears.

**Reading the snapshot.** Your years are strong. Your complaints and reporting work is real but sits at branch scope. The contact centre and senior presentation are stated gaps, so the pack gives you plain words for them and plans, not stories.

---

## 3. Prohibited claims

The claims this pack will not coach, and why. Built locally from the snapshot, because no dossier was supplied.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end | Inflated form of F6 | "I handled the branch's formal complaints log." Your material says one branch's log, not the process. |
| Set or tracked resolution-time targets | Inflated form of F3 | "I built the monthly complaints spreadsheet our regional manager uses." Your material does not say what it counted. |
| Coached supervisors on escalations | Inflated form of F5 | "I trained new tellers on our escalation script." |
| Handled complaints to a regulator's standard | Inflated form of F2 | "I handled the branch's formal complaints log." Whether those were regulated is not shown. |
| Presented to senior leaders | Negative you stated, F9 | "I haven't presented to anyone above regional level." No slot. |
| Worked in a contact centre | Negative you stated, F8 | "I haven't worked in a contact centre." No slot. |

---

## 4. Persona weights (by round)

| Round | Dominant personas | Weights and reasoning |
|---|---|---|
| 1. Recruiter (30 min) | Conversational, light Skeptic | Conversational 5 questions: the biography and the four logistics terms. Skeptic 1: the contact-centre gap. Logistics are the recruiter's real job here, so they are scored. |
| 2. Head of Member Services (45 min) | Skeptic, then Values/Behavioral, then Data-Driven Prober | Skeptic 3 (B2, B3, B8). Your manager is buying capability and de-risking gaps, so the regulated-complaints and contact-centre questions come first. Values/Behavioral 1 (B1). Prober 2 (B4, B5). Experience 1 (B7). Case 1 (B6). Round 2 is "mostly behavioural", so the Case persona is lower than a hiring-manager prior would give. |
| 3. Panel of two branch managers (60 min) | Values/Behavioral, then Case/Strategist, then Peer Evaluator | Values 4 (C1 to C4): the panel scores against the four values. Case 3 (C5 to C7): the 20-minute escalation case and the two strategy questions. Peer 1 (C8): two branch managers are peers to a branch-network lead. Pressure is absent because no interviewer signal supports it. |

Interviewer names are unknown, so none of these weights reflects a personal read. Expect the panel's two members to score differently. Tune each answer to the whole panel, not to one member.

---

## 5. Question banks

**Requirement coverage**

| JD requirement | Question IDs |
|---|---|
| Own the complaints process end to end across branches and the contact centre | C5, B6, C8, A6 |
| Report monthly on volumes and resolution times | B4, B5 |
| Coach branch supervisors on escalations | B6, B7 |
| Work with digital teams on self-service journeys | C6, C7 |
| 4+ years in financial-services customer operations | A1 |
| Experience handling regulated complaints | B2 |
| Confident presenting to senior leaders | B8 |
| Comfortable with Excel reporting | B4 |
| Contact centre (your stated gap) | A6, B3 |

### Round 1: Recruiter screen (Conversational, light Skeptic)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, walk me through the journey." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" (your message) | A 90-second arc: six years in retail banking, the last three as a branch supervisor, in your own words. Stop there; do not add roles or dates you did not give. | F1 is the strongest line you have; the recruiter will open with it. Typed EXP because it tests what you actually did. |
| A2 | "What salary are you looking for?" | JD | [grounded] recruiter's round 1 (no candidate sentence yet) | Instruction: give your own figure, or ask first what the band is. Never estimate or give your current pay. | Pay is a logistics slot. Your answer is yours alone; no figure is supplied here. |
| A3 | "What notice would you need to give?" | JD | [grounded] recruiter's round 1 (no candidate sentence yet) | Instruction: give your actual notice period in your own words. | Notice is a logistics slot. Nothing about it is in your material, so the slot is yours to fill. |
| A4 | "Which Ashgrove locations could you work from?" | JD | [grounded] strategy brief: "consolidate eight branches into five hubs over 2027" | Instruction: say the locations and days you can work, in your own words. If unsure, ask which of the planned hubs this role sits in. | Location is a logistics slot, and the hub plan makes it live. |
| A5 | "What's prompting the move?" | EXP | [grounded] "I handled the branch's formal complaints log" (your message) | Instruction: give your reason in one or two sentences, in your own words. Do not criticise your current employer. | The reason for leaving is a logistics slot. Your material does not give one, so the slot is yours. |
| A6 | "You haven't worked in a contact centre. What draws you to this role?" | JD | [grounded] "Never worked in a contact centre" (your message); "I handled the branch's formal complaints log" (your message) | Plain words first: "I haven't worked in a contact centre." Then what draws you, in terms of the branch complaints work you did, not a claimed contact-centre background. | F8 is a stated gap. The plain acknowledgment has its source in your message. |

### Round 2: Head of Member Services (Skeptic first, then Behavioral and Prober)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "When did you put a member ahead of an internal target?" | VAL | [grounded] published value "Members First, Always" (values text supplied); no candidate sentence carries a story | Selection scaffold: pick a complaint where the member's side changed what you did, and say what the target was and what you did instead. If no such time comes to mind, say so plainly, then give the nearest case you handled and how you decided. | Round 2 is behavioural and the values run through it. Stem from the Values/Behavioral persona. |
| B2 | "The role handles regulated complaints. What in your experience counts as one, and how would you tell?" **Highest-ROI prep in this pack.** | JD | [grounded] "I handled the branch's formal complaints log" (your message); JD line "experience handling regulated complaints" | Hold: "I handled the branch's formal complaints log," and say what the log recorded. Answer slot: if the log recorded complaints against an outside rule or timescale, say which and how you tracked it; if it did not, say so plainly and say what you would learn first. Follow-up one: return to the log in the same words. Follow-up two: concede only the limit your material shows, which is that the regulated part is not established by the log, and say how you would find out. Never fold on the log itself, and never claim a regulated record you cannot name. | This is the requirement most likely to be probed, and F2 is where your material is thinnest. A rehearsed, non-defensive answer changes the interview. |
| B3 | "You haven't worked in a contact centre. Why would this team trust you to run complaints across one?" | JD | [grounded] "Never worked in a contact centre" (your message) | Plain words: "I haven't worked in a contact centre." Then a plan, not a past: how you would learn the work (listening to calls, shadowing the team, reading the complaint routes). Do not claim contact-centre experience. | F8 is a stated gap; the plan is the honest answer, the bridge is not. |
| B4 | "Walk me through the monthly complaints spreadsheet you built. Who uses it, and how?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" (your message) | Story-mapped on F4: you built it, and your regional manager uses it. Answer slot: name the software in your own words. If it counted volumes or time to resolve, say which and how each was counted; if it did not, say what it tracked. | F3 and F4 are the Excel and reporting requirements. Typed EXP because it tests attribution. |
| B5 | "The role reports volumes and resolution times monthly. Have you reported either, and what did you count?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" (your message); JD line "report monthly on complaint volumes and resolution times" | Answer slot, both branches: if you counted volumes or resolution time, say which, from where, and what it was sensitive to; if you did not, say so and say what the report did show. Do not name a measure the material does not carry. | F3 gap: the requirement is reached but not shown. A figure you give would raise the defend-the-number slots. |
| B6 | "A branch supervisor escalates three complaints a week to you. How would you coach them?" | CASE | [generic] role-family pattern; no candidate sentence | Structure: ask what the supervisor has tried first; coach the one decision that most often goes wrong; check the next three escalations together; record what changed. Ninety seconds. No past claim. | Coaching supervisors is a JD requirement, and F5 is adjacent only. A live problem tests the method, not your history. |
| B7 | "Tell me about a time you taught someone a process they had to get right." | EXP | [grounded] "trained new tellers on our escalation script" (your message) | Story-mapped on F5: you trained new tellers on the escalation script. Answer slot: if you checked whether the script was followed after training, say how; if you did not, say so plainly and say what you would check. Limit: tellers, not supervisors. | F5 is the closest evidence for coaching; the probe for the next step is likely. |
| B8 | "You have five minutes with the executive team. What do they need to hear about complaints?" | JD | [grounded] "I've never presented to anyone above regional level" (your message); JD line "confident presenting to senior leaders" | Plain words: "I haven't presented to anyone above regional level." Then a plan: one page, one number they will act on, and one question you want answered. Practise it aloud before round 3. | F9 is a stated gap. Senior presentation is in the JD and the panel will judge it. |

### Round 3: Panel of two branch managers (Values, Case, Peer)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "When did you put a member ahead of an internal target?" | VAL | [grounded] "Members First, Always" (values text supplied); no candidate sentence carries a story | Selection scaffold, as B1: pick a case; if none comes to mind, say so, then give the nearest and how you decided. | Scored against the first value. |
| C2 | "Tell me about a time you had to explain something a member didn't follow the first time." | VAL | [grounded] "Plain Words, if a member needs it explained twice, we wrote it wrong" (values text); "trained new tellers on our escalation script" (your message) | Story-mapped on F5 if it fits: the script training, and how you checked it landed. If not, selection scaffold: a time you rewrote an explanation, and what you changed. Honest branch: if you did not check, say so. | Scored against Plain Words. |
| C3 | "Tell me about a time a local detail changed how you handled a complaint." | VAL | [grounded] "Neighbours, Not Numbers" (values text); no candidate sentence carries a story | Selection scaffold: pick a branch-specific fact that changed the handling. If none comes to mind, say so plainly, then say how you would find out what a town needs. | Scored against Neighbours, Not Numbers. Your material has no story for it, so the honest branch matters. |
| C4 | "Tell me about a complaint you didn't close the first time, and what you did next." | VAL | [grounded] "Own the Fix" (values text); "I built the monthly complaints spreadsheet our regional manager uses" (your message) | Selection scaffold: pick a complaint you kept hold of until it was solved. If you can't name one, say so, then give the nearest one from the log you handled and what you did with it. Answer slot: if the spreadsheet helped you spot a repeat problem, say how; if not, leave it out. | Scored against Own the Fix. |
| C5 | "A member escalates a complaint that the branch has already rejected twice. Walk us through what you'd do." | CASE | [generic] role-family pattern; no candidate sentence | The 20-minute case. Clarify the complaint and what "rejected" meant. Set the objective: a fair outcome for the member and a decision the branch can stand behind. Work through steps, a check on the decision, and what you would record. Name one risk and one metric. Think aloud and challenge one premise. | The case is the panel's centrepiece. Structure before answers, and use the company's own words (member, escalation, decision). |
| C6 | "We're moving 40% of member service to digital by 2028. A complaint starts in the app and lands in a branch. Who owns it, and where does it go?" | CO | [grounded] strategy brief: "move 40% of member service to digital channels by 2028" | Structure the answer by channel: who owns the complaint at each handover, how the member sees one story, and what the digital team and the branch each need. Answer slot: if you have worked on a cross-channel handover, say how; if not, say so and propose how you would map one. | Tests whether you can think at the company's altitude. Digital is the JD's self-service requirement (F7). |
| C7 | "We're consolidating eight branches into five hubs over 2027. What happens to open complaints when a branch closes?" | CO | [grounded] strategy brief: "consolidate eight branches into five hubs over 2027" | Name the risks: open cases with no owner, members who lose their branch, a backlog on handover. Propose a principle: no complaint changes owner without a named handover. Answer slot: if you have handled a branch change, say what happened to open cases; if not, say so. | Shows you read the strategy, and turns the closure into a member-experience problem. |
| C8 | "Our teams sit side by side. Where's the seam between branch and contact-centre complaints, and what happens when we disagree?" | JD | [generic] peer-panel pattern; no candidate sentence | Reciprocity first: what you would bring to the branch managers' teams, not only what you need. Propose seam principles rather than claiming you know the seam. Disagreement: if you have disagreed with a peer on a complaint, say what you did and how it ended; if not, say how you would disagree well. | Peer Evaluator prior. The panel is the branch network; it is the best place to show spine and tact together. |

---

## 6. Values cheat sheet

Scored by the panel. Your material carries no story for three of the four values, so the honest branch is written in.

| Value (official name) | Working meaning (paraphrased) | Mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter. | Selection scaffold, using F2: "I handled the branch's formal complaints log." Pick a log entry where the member's side changed what you did. If none comes to mind, say so plainly, then give the nearest one and how you decided. |
| Plain Words | If a member needs it explained twice, the writing or explanation was wrong. | Scaffold, using F5: "trained new tellers on our escalation script." Say how you checked the explanation landed. If you did not check, say so. |
| Neighbours, Not Numbers | Every branch is part of its town. | No candidate sentence carries a story. Selection scaffold: a local fact that changed a complaint's handling. If none comes to mind, say so and say how you would find out what a town needs. |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved. | Scaffold, using F3: "I built the monthly complaints spreadsheet our regional manager uses." Pick a complaint you kept hold of until it was solved. If you can't name one, say so, then give the nearest and what you did. |

---

## 7. Reverse questions

Each has a "why it lands". Interviewer names are unknown, so none is tied to a personal career path yet.

1. "What would a good first 90 days look like, and what would you need me to have in place by then?" Why it lands: it shows you plan for the role, and it gives the manager a concrete answer to score.
2. "How does complaint data reach branch supervisors today, and what would you change?" Why it lands: it links to your Excel and reporting work (F4) and to the monthly report the role owns.
3. "How will the digital shift and the hub consolidation change where complaints come from?" Why it lands: it shows you read the July 2026 brief, and it opens the strategy discussion on your terms.
4. "Which complaints take longest to resolve today, and why?" Why it lands: it signals you think in outcomes for members, not only in volumes.
5. "When a branch supervisor escalates, what do you expect them to have tried first?" Why it lands: it ties to the escalation case and shows you care about the handover, not only the outcome.
6. Panel only: "What is one thing a new lead could do in the first month that would genuinely help your branches?" Why it lands: the panel members are peers, and this asks for their view, which is a reciprocity question.

---

## 8. Grounding brief: Ashgrove's stated strategy

From the July 2026 strategy brief the recruiter sent. Treat these as the vocabulary to use, and do not add numbers the brief does not state.

- **Digital shift:** move 40% of member service to digital channels by 2028.
- **Hub consolidation:** consolidate eight branches into five hubs over 2027.
- **Small-business lending:** a launch in Q1 2027.
- **Main competitive pressure:** app-only banks.

Flags: I have not checked whether the brief has been updated since July 2026, and I have not checked the values page against Ashgrove's live site. Both are as you copied them. Use the brief's wording, and confirm the current position with the recruiter before round 2.

---

## 9. Prohibited claims (rendered)

See section 3. Nothing in the banks or the cheat sheet claims contact-centre experience, senior presentation, regulated-complaints handling beyond the quoted log, or coaching supervisors.

---

## 10. Sources

- Provided documents: the JD text, the four values (copied from ashgrovecu.org/about/values on 26 November 2026, not checked against the live site), the recruiter's process email, the July 2026 strategy brief as summarised by you, and your background as you described it.
- Research tier: L1. No searches or fetches were run.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | The values you pasted fix the values section. |
| 2. Ashgrove interview process | skipped | The recruiter's email fixes the three rounds and the panel's scoring against values. |
| 3. Ashgrove strategy / recent news | skipped | The July 2026 brief supplies current priorities. A news sweep could show later changes; the upgrade menu offers it. |
| 4. Interviewer name and Ashgrove | n/a | No interviewer names have been given for rounds 2 and 3. |
| 5. Representative JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions. |

---

## 11. Upgrade menu

- Interviewer names for round 2 and round 3 → personal persona weights, an interviewer read, and a reverse question tied to their career path.
- The 20-minute case sent in advance, as written material → a build section for the case, with theses and a mandatory concession.
- Which complaint rules your branch's log worked under → B2's answer slot can quote what the log recorded, and the regulated-complaints row F2 can move up a band.
- Numbers from your spreadsheet, if you have them → the defend-the-number slots (B4, B5) become quoted figures, and F3 can move from discovery to grounded.
- Ashgrove's values page, fetched from the live site → the values section is verified rather than copied.
- A news sweep on Ashgrove since July 2026 (L2 deep research, offered once, capped at six further searches and two further fetches) → the grounding brief gains current headlines.
