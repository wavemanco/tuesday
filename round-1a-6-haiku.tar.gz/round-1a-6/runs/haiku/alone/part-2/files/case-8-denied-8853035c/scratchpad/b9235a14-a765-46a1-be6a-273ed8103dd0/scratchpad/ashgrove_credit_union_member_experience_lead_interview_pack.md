# Ashgrove Credit Union: Member Experience Lead

**Interviews:** 5 December 2026, three rounds.
- Round 1, 30 min: recruiter.
- Round 2, 45 min: Head of Member Services, your future manager, mostly behavioural.
- Round 3, 60 min: panel of two branch managers, including a 20-minute complaint-escalation case. The panel also scores the four values.

Interviewers in rounds 2 and 3 are not yet named. Built 26 November 2026, first version.

## How to use this pack

- **Personas** are how a question arrives. **Types** are what is being scored.
- Type key: **VAL** behavioural and values; **EXP** your own experience, probed; **JD** the listed job; **CO** company and strategy; **CASE** a live problem.
- Guidance is scaffolding, not a script. Say only what you did, in your own words.
- An **answer slot** is an instruction for the interview: answer from your own experience either way, including "that was not mine."

## Grounding brief: strategy and vocabulary

Source for every row: the July 2026 strategy brief the recruiter sent, as you pasted it.

| Fact | Provenance |
|---|---|
| "move 40% of member service to digital channels by 2028" | [grounded] |
| "consolidate eight branches into five hubs over 2027" | [grounded] |
| "launch a small-business lending product in Q1 2027" | [grounded] |
| "the main competitive pressure is app-only banks" | [grounded] |

Vocabulary to use: member service, digital channels, hubs, app-only banks. No outside research ran, so no stale framing has been checked against anything beyond this brief.

## Fit snapshot

Requirements are quoted from the JD you pasted. Evidence is quoted from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | none | Your years are not in question. Say them in your own words: "6 years in retail banking, the last 3 as a branch supervisor." Expect a probe on whether branch work counts as customer operations. Answer slot: say what the branch's customer work involved day to day. |
| F2 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | discovery | Your material shows complaints handled, not regulation. Say it as it is: "I handled the branch's formal complaints log." Answer slot: if any rules or outside bodies set how the log was run, say which and how you worked to them; if none did, say so plainly. |
| F3 | "Own the member complaints process end to end across branches and the contact centre" — JD | "I handled the branch's formal complaints log" — your message | medium | [inferred] | transferability | The quote is one branch's log. Stay at that scope: "I handled the branch's formal complaints log." Answer slot: if you ran complaints beyond that one log, say where and how; if not, say so and say how you would extend the log across branches. |
| F4 | "Own the member complaints process end to end across branches and the contact centre" — JD, contact-centre part | "Never worked in a contact centre" — your message | none | [grounded] | capability | Plain acknowledgment: "I've never worked in a contact centre." Then a plan, said as a plan and never as a past: how you would learn a contact centre's complaint flow, and from whom. |
| F5 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | The quote says a monthly spreadsheet, not what it measured. Answer slot: say what it tracked. If resolution times were among its measures, say how they were counted; if not, say so and what you would track first. |
| F6 | "coach branch supervisors on escalations" — JD | "trained new tellers on our escalation script" — your message | medium | [grounded] | transferability | Stay at the quote's scope: you trained tellers. Answer slot: if you coached supervisors on escalations, say how; if not, say so and say how you would start. |
| F7 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material does not mention digital work. Answer slot: if you have worked with anyone on a digital or self-service journey, say what your part was; if not, say so and how you would begin with the digital team. |
| F8 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level." — your message | none | [grounded] | capability | Plain acknowledgment: "I've never presented to anyone above regional level." Then a plan for how you would prepare to present monthly, said as a plan. |
| F9 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | Your message does not name the tool. Answer slot: say which tool you built it in; if it was not Excel, say what it was. |

No row is a hard gate: the JD's requirements are experience and skill terms, not licences or conditions.

## Prohibited claims

Claims this pack will not coach, and the honest form of each.

| Not coached | Basis | Honest form |
|---|---|---|
| Ran complaints end to end across branches and the contact centre | Inflated form of F3 and F4 | "I handled the branch's formal complaints log." The material says one branch's log. No contact-centre claim is made. |
| Worked in a contact centre | Stated negative, F4 | "I've never worked in a contact centre." No answer slot on the fact. |
| Presented to senior leaders | Stated negative, F8 | "I've never presented to anyone above regional level." No answer slot on the fact. |
| Reported resolution times monthly | Inflated form of F5 | "I built the monthly complaints spreadsheet our regional manager uses." The material does not say what it measured. |
| Coached branch supervisors on escalations | Inflated form of F6 | "trained new tellers on our escalation script." |
| Handled regulated complaints | Inflated form of F2 | "I handled the branch's formal complaints log." "Formal" is not the same as "regulated." |
| Used Excel | Inflated form of F9 | "I built the monthly complaints spreadsheet our regional manager uses." The tool is not named. |

## Personas and weights

| Round | Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|---|
| 1 recruiter | Conversational | Friendly opener, then logistics checks | High. A recruiter screen is friendly and still scored, and pay, notice, location and reason for leaving are asked here | Rehearse one 90-second arc from your own sentences |
| 1 recruiter | Skeptic, light | Quiet check on why now and why this role | Medium. Your message gives no reason for leaving | Give your reason in your own words, and no more |
| 2 Head of Member Services | Skeptic | Goes straight to the gaps in the JD | High. Contact centre, senior presentation and regulated complaints are the visible gaps | Rehearse the contact-centre answer until it is plain; hold, then concede exactly |
| 2 Head of Member Services | Values/Behavioral | Scenario and STAR-shaped questions | High. The round is mostly behavioural | Stories built from your quotes, with "I" for what you did |
| 2 Head of Member Services | Data-Driven Prober | Asks how the spreadsheet was counted | Medium. The spreadsheet is the one artifact your message names | Say what it tracked and which part was yours |
| 3 panel | Values/Behavioral | Scores each of the four values | High. The recruiter says the panel scores the values | Map one story or an honest selection to each value |
| 3 panel | Case/Strategist | The 20-minute escalation case | High. A case is set for this round | Clarify, then structure out loud, then decide |
| 3 panel | Pressure | Composure test on the contact-centre gap | Medium. Two branch managers may test a gap they run every day | Pause, restate, hold the position your quotes carry, concede the gap specifically |

Depth follows weight: the recruiter bank has five questions (four logistics, mandatory), the Head bank six, the panel seven. Total: eighteen.

## Question banks

### A. Recruiter (round 1)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, walk me through your journey so far." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "I handled the branch's formal complaints log"; "trained new tellers on our escalation script"; "I built the monthly complaints spreadsheet our regional manager uses." | A 90-second arc in the order of those four quotes: the six years and the last three as a branch supervisor, then the formal complaints log you handled, then training tellers on the escalation script, then the monthly spreadsheet your regional manager uses. Say each in your own words. Add no beat beyond these. | Covers F1 (the four years), F2 and F5, and the nearest coaching evidence in F6. |
| A2 | "What are your salary expectations?" | JD | [generic] | Logistics slot. Give your own figure, or ask for the advertised band first. Your message gives no figure, so nothing here is set for you. | Pay is a logistics slot under the rubric. |
| A3 | "What's your notice period?" | JD | [generic] | Logistics slot. Give your actual notice period. Your message gives none. | Same rule as A2. |
| A4 | "Where would you be based, and how often could you work from an office?" | JD | [generic] | Logistics slot. State the locations and office days you can work, in your own words. None is in your message. | Location is a logistics slot. The JD gives no office pattern. |
| A5 | "Why are you looking to move from your current role, and why this one?" | EXP | [generic] | Logistics slot for the reason. Give your reason in your own words. Your message does not state one, so the slot is yours to fill. Do not add a reason because it sounds better. | The recruiter's motivation check. None of your quotes carries a reason. |

### B. Head of Member Services (round 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "This role owns complaints across the contact centre. Which part of that would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre" | **Highest-ROI prep in this pack.** Start with the plain acknowledgment: "I've never worked in a contact centre." Then a plan, said as a plan: what you would ask first to learn how complaints move through a contact centre, and who you would ask. Hold through two follow-ups by returning to the plan, not to a claim. If pushed to concede, name the gap exactly: the contact centre, not complaints work in general. | F4 is the most likely objection and this manager will test it on day one. The negative is yours to say; the plan is what you hold. |
| B2 | "Tell me about a time you presented to senior leaders." | JD | [grounded] "I've never presented to anyone above regional level." | Open prompt. Plain acknowledgment: "I've never presented to anyone above regional level." Then how you would prepare to present monthly to senior leaders, as a plan. Do not describe a presentation you did not give. | F8. The presentation line in the JD is a likely probe. |
| B3 | "Walk me through how you handled entries on the formal complaints log." | EXP | [grounded] "I handled the branch's formal complaints log" | Story-mapped on F2: the log and your handling of its entries, in your own words. Answer slot: if any rules or outside bodies set how the log was run, say which and how you worked to them; if none did, say so plainly and describe how you handled the entries. | F2's regulated gap, tested at the log. The question names no stages the quote does not carry. |
| B4 | "How would you coach a branch supervisor whose escalations come in late?" | JD | [grounded] "trained new tellers on our escalation script" | Live scenario, so no past claim is needed. Start from what you would look at first, then the coaching conversation. Your nearest basis is the teller training, said at its own scope. Answer slot: if you coached supervisors on escalations, say how; if not, say so and say what you would do first. | F6. The JD's coaching line, tested on a case the role would face. |
| B5 | "Tell me about a time you worked with anyone on a self-service journey." | JD | [grounded] JD line: "work with digital teams on self-service journeys" | Open prompt. Answer slot: say what your part was, in your own words. If you have none, say so plainly and say how you would start with the digital team. | F7. The JD's self-service line is the raising source; your material is silent. |
| B6 | "We're moving 40% of member service to digital channels by 2028, and app-only banks are the main competition. What happens to complaints when a member can't reach a person?" | CO | [grounded] "move 40% of member service to digital channels by 2028"; "the main competitive pressure is app-only banks" | A reasoning question with no claim about your past. Name the route a complaint takes from the app to a person, who owns it at each step, and how the member hears back. Hold on one thing you would check first. | Strategy-linked, from the brief. The question carries the plan as the brief states it. |

### C. Panel of two branch managers (round 3, includes the case and the values)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You have 20 minutes. A member's fee complaint was refused at the branch. The member has now phoned the contact centre and says they will go to the regulator. The branch says the case is closed; the contact centre says it is open. What do you do, and in what order?" | CASE | [generic]; optional example only: "trained new tellers on our escalation script" | Clarify first, in one sentence: what the record shows, whether the case is open anywhere, and which deadlines apply. Then one owner, who takes the case and stops the conflicting messages. Then the member's side of the counter: the refund decision on the facts, explained in plain words once. Then the supervisor: coach on the refusal, not over them. Then the pattern: log it and report it. Say which step comes first and why. Do not describe a similar case as one you handled. If you want an example, the nearest basis is your teller training, said as training. | The live case for round 3. It tests structure and ordering, and it has no past claim to defend. |
| C2 | "Tell me about a time you found a problem and stayed with it until it was solved." | VAL | [generic]; nearest thing only: "I built the monthly complaints spreadsheet our regional manager uses." | Own the Fix. Selection scaffold: a named problem you found and kept hold of, with an end state. If no such time comes to mind, say so plainly, then give the nearest thing your material carries. Say what the spreadsheet is used for, not that it fixed anything. | Values round. The spreadsheet is the nearest evidence, and it does not show a fix. |
| C3 | "A branch in a small town is being merged into a hub. How do you handle complaints from members who feel the town is losing its bank?" | CO | [grounded] "consolidate eight branches into five hubs over 2027" | Neighbours, Not Numbers. Lead with the member and the town, not the figure. Say what you would do before the merger and how the complaint route stays visible in the town. Your material holds no branch merger, so say so if asked for one. No claim about your past. | VAL on the consolidation the brief names. The question is live from the brief. |
| C4 | "Tell me about a time someone needed something explained to them twice. What did you do?" | VAL | [generic]; nearest basis only: "trained new tellers on our escalation script" | Plain Words. Selection scaffold: a time an explanation did not land the first time. Answer slot: say what you changed in the explanation; if you changed nothing, say so and what you would change next. | Values round. Your material has no clear story here, so the honest branch matters. |
| C5 | "What did the monthly complaints spreadsheet track, and who used it?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Say what it tracked, in your own words, and who used it: your regional manager. Answer slot: if resolution times were among its measures, say how they were counted and which part was yours; if not, say so and what you would track first. Answer slot on the tool: say which one you built it in; if it was not Excel, say what it was. | Data-Driven Prober. F5 and F9 are both here. No figure is given, so no defend-the-number slot is raised yet. |
| C6 | "Sixty seconds: why should we choose you over a candidate who has run a contact centre?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "Never worked in a contact centre" | Pressure. Pause and restate. Hold the position your quotes carry: six years in retail banking, the last three as a branch supervisor, and the formal complaints log you handled. If pushed, concede the gap specifically: you have never worked in a contact centre. Do not fold on the banking record, and do not add a contact-centre claim. | Pressure stem. The hold is what your quotes carry; the concession is your stated negative. |
| C8 | "Tell me about a complaint you decided where the member's side of the counter was the hard call." | VAL | [generic]; nearest thing only: "I handled the branch's formal complaints log" | Members First. Selection scaffold: a decision where the member's side was the hard part, with the outcome. If none comes to mind, say so plainly, then give the nearest thing your material carries: the log you handled. | Values round. Your material does not show a decision of this kind yet. |

**Requirement coverage**

| JD requirement | Covered by |
|---|---|
| 4+ years in financial-services customer operations | A1 (F1) |
| Own the complaints process end to end, branches and contact centre | B1, B3, C6 (F3, F4) |
| Report monthly on volumes and resolution times | C5 (F5); resolution times in an answer slot |
| Coach branch supervisors on escalations | B4 (F6) |
| Work with digital teams on self-service journeys | B5, B6 (F7) |
| Experience handling regulated complaints | B3 (F2) |
| Confident presenting to senior leaders | B2 (F8) |
| Comfortable with Excel reporting | C5 (F9) |

**Values coverage:** Members First, C8; Plain Words, C4; Neighbours, Not Numbers, C3; Own the Fix, C2.

### Escalation case: rehearsal schedule

You asked for a drill plan for the case. This is the self-rehearsal schedule for C1. The live drill is in the offers at the end of this message.

| Date | What to do |
|---|---|
| 27 Nov | Read C1 aloud. Spend two minutes writing down the clarifying questions you would ask first. |
| 29 Nov | Talk through the structure in three minutes: clarify, owner, member, supervisor, pattern. Say which step comes first and why. |
| 1 Dec | Run the full 20 minutes with a timer, speaking aloud. Note whether you asked about deadlines before deciding anything. |
| 3 Dec | Repeat, and add a pressure: the branch insists the case is closed. Hold your order, then concede what is actually uncertain. |
| 4 Dec | Light pass only: C2, C4, C8 and the four-phrase arc from A1. Do not add new stories. |

## Values and principles cheat sheet

Round 3 scores the four values. Each row maps a value to a story from your quotes where one exists, or gives a selection scaffold with the honest branch where none does.

| Value | Working meaning | Mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | No quote carries a member-side decision. Use C8: name a complaint where the member's side was the hard call. If none, say so, and give the formal complaints log you handled ("I handled the branch's formal complaints log"). |
| Plain Words | If a member needs it explained twice, the writing or the explanation was wrong | No quote carries a rewrite. Use C4: name an explanation that did not land first time. Say what changed; if nothing changed, say so. Your teller training on the escalation script is the nearest basis ("trained new tellers on our escalation script"), said as training. |
| Neighbours, Not Numbers | Every branch is part of its town | No quote carries a town. Use C3 as a live case, and say so plainly if asked for a branch you have known in its town. Do not use the spreadsheet to stand for this value. |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | No quote carries a fix. Use C2: a named problem you found and kept hold of. If none, say so. The spreadsheet is the nearest evidence ("I built the monthly complaints spreadsheet our regional manager uses"), and it shows what the spreadsheet is for, not that anything was fixed. |

## Reverse questions

None of these checks an invite. Each has a reason it lands.

| # | Question for the interviewer | Why it lands |
|---|---|---|
| R1 | "What would a good first six months look like in this role, especially on the contact-centre side?" | It names the gap you are most likely to be asked about, and shows you have already planned for it. |
| R2 | "How are complaints reported to senior leaders now, and what do they need the report to answer?" | It shows you are thinking about the presentation requirement, and you want their questions, not just your own slides. |
| R3 | "When branches move into hubs, how will complaints from towns that lose a branch be handled?" | It ties Neighbours, Not Numbers to the consolidation the brief names. |
| R4 | "Which complaints do you expect to rise as more service moves to digital, and what is being done before that happens?" | It shows you have read the 40 percent target and think about where complaints come from. |
| R5 | "Which rules set the timelines for the complaints this team handles, and who checks them?" | It shows you want to know the regulated part of the role rather than guess it. |
| R6 | "What made the team decide to fill this role now?" | It gets the reason behind the job, which you can match to your own reason. |

## Sources

- **Provided documents:** your message, which holds your background, the JD you copied, the four values as you copied them on 26 November 2026, the strategy brief the recruiter sent, and the round details from the recruiter's email.
- **Searches:** none. **Fetches:** none.
- **Research tier:** L1, searches 0 of 6, fetches 0 of 2. Every L1 target was already fixed by inputs in hand, so nothing was sent.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove Credit Union values | skipped | The values cheat sheet came from the copy you pasted. |
| 2. Ashgrove Credit Union interview process, member experience lead | skipped | The recruiter's email gives the three rounds, their length and the values scoring. |
| 3. Ashgrove Credit Union strategy and recent news | skipped | The July 2026 brief you pasted supplies current priorities. Recent news would be an L2 target. |
| 4. Interviewer name and Ashgrove Credit Union | n/a | No names were given, so there was no query to form. |
| 5. Representative Member Experience Lead JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions. |

## Upgrade menu

- Your monthly complaints spreadsheet, shared with member data removed → lifts F5 and F9 from medium toward high, and lets C5 be walked through.
- The names of the Head of Member Services and the two branch managers → persona weights per interviewer and a tailored reverse question.
- Deep research (L2) on Ashgrove's recent news and leadership talks → a fuller grounding brief and a sharper strategy question for round 3.
- The rules and outside bodies your formal complaints log followed → turns F2 from a discovery gap into a grounded answer.
- Your own pay, notice, office pattern and reason for leaving → fills the logistics slots A2 to A5 in your words.
- Any contact-centre or supervisor-coaching work, however small → upgrades F4 and F6.
