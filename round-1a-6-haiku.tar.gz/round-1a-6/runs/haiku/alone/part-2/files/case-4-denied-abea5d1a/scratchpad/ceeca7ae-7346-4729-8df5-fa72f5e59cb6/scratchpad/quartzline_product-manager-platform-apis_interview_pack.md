# Interview pack: Product Manager, Platform APIs at Quartzline

Hiring-manager round, 45 minutes, Thursday. Interviewer not named. Built from your underwriting dossier (`tuesday-dossier.md`, dossier_version 1.1, generated 2026-08-14) and your message.

**Check before Thursday:** the dossier is about 3.5 months old (14 August to 26 November). Its decision (conditional_go) and its two open unknowns (decision authority versus the squad leads; the current adoption baseline) may have moved. See the upgrade menu at the end.

## How to use this pack

- **Personas** describe how a question arrives (its style). **Types** describe what it scores.
- Type key: **JD** = the role's stated requirements and responsibilities; **EXP** = your past work, and whether you can say exactly what you did; **CASE** = a live problem from the role. VAL and CO are not used: no values-style round was detected, and no company research ran.
- Guidance is scaffolding, not a script. Say it in your own words. A sentence that isn't yours is the one you drop under follow-up.
- Evidence labels: V1 to V3 are the dossier's verified-evidence entries in their order. Quotes are exact.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" (JD, dossier role_profile R1) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier row V1 | low | [grounded] | transferability | Your material shows integration leadership at its own scope, and the quote stays at that scope. The limit, which the dossier records: you have not held a product manager title. Say the limit before it is asked. |
| F2 | "Shipped API or platform products" (JD, dossier role_profile R2) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier row V1 | low | [inferred] | discovery | This is this pack's own reading, not the underwriter's: the dossier neither grades R2 nor lists evidence for it. V1 touches it through go-live without showing whether any of those integrations were products you owned. Answer slot: if you owned a shipped API product, say which and what your part was; if the work was integrations on the vendor's API, say so and stay with go-live at that scope. |
| F3 | "Technical fluency: API docs, schemas" (JD, dossier role_profile R3) | "Wrote the internal integration playbook her team uses" — dossier row V2 | high | [grounded] | presentation | Say the playbook as you wrote it, and do not stretch it to API docs or schemas. Whether it covers schemas, your material does not show. |
| F4 | "Stakeholder management across engineering, sales, customers" (JD, dossier role_profile R4) | "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier row V3; "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier row V1 | medium | [grounded] | discovery | The evidence reaches clients and product. Engineering and sales are not shown. Answer slot: name one time you worked with engineering or with sales on an integration, and what it was; if neither came through your work, say so and stay with the client and product work the quotes carry. |
| F5 | "Agile delivery experience" (JD, dossier role_profile R5) | none given | none | [grounded] | discovery | No sentence you gave carries agile delivery. The dossier grades R5 low for delivery inside a product org; this pack grades it none, because no quote supports even that. Answer slot, in the clarify form: say what you ran, or say you never worked that way. |
| F6 | Owning a roadmap and prioritization authority (dossier role_profile R1 sub-claim; dossier allowed_interview_strategy acknowledge_gap) | none given | none | [grounded] | capability | The dossier records this absence. Words: "I haven't owned a product roadmap." Then a ramp plan, said as a plan and never as past work. No bridge. |

Gate rows: none. The dossier's hard_gates list is empty, and none of R1 to R5 is a term rather than experience.

## Prohibited claims

Each entry gives its basis and its honest form. These are not coached in any answer below.

| Not coached | Basis | Honest form |
|---|---|---|
| Held a product manager title or role | Dossier prohibited_claims ("Having held a product manager title or role"); inflated form of F1 | Plain acknowledgment from the dossier: "I haven't held a product manager title." No answer slot. |
| Owned a product roadmap | Dossier prohibited_claims ("Having owned a product roadmap"); acknowledge_gap on F6 | "I haven't owned a product roadmap." Then the ramp plan. |
| Set prioritization for an engineering squad | Dossier prohibited_claims ("Having set prioritization for an engineering squad") | "I haven't set prioritization for an engineering squad." No answer slot. |
| Ran the roadmap sessions, so you shaped the roadmap | Inflated form of V3 (kind and relationship: input to a decision read as the decision) | V3 at its own scope: "Ran quarterly roadmap-input sessions feeding client evidence to product." The pack's observation, not a claim about you: the material shows the sessions fed evidence to product, and does not show who decided. |
| Led the product decisions on the API | Inflated form of V1 (verb and kind: leading integrations read as owning product direction) | V1 at its own scope. The limit is the pack's observation: the material shows integrations led for clients, not product decisions made. |
| Wrote the API docs and schemas | Inflated form of V2 (scope and kind) | V2 at its own scope: "Wrote the internal integration playbook her team uses." |

## Persona weights

Hiring-manager prior: Case/Strategist and Skeptic lead. Two interviewer signals adjust it: the dossier names one objection, which is a Skeptic line; and the open squad-authority question means a peer-style seam probe is plausible. No values round was detected.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy | Questions |
|---|---|---|---|---|
| Skeptic | Probes the gaps: the PM title, the roadmap, why you | High. Hiring-manager prior, and the dossier's named objection (A1) is a Skeptic line | Rehearse A1 until it is boring. Hold, then concede the roadmap and prioritization limits exactly | 5 (A1 to A5) |
| Case/Strategist | Live problems on the partner platform | High. Hiring-manager prior; the JD asks for roadmap and adoption ownership | Clarify, then structure, then name the metric. Ask for the baseline aloud | 3 (B1 to B3) |
| Data-Driven Prober | Counts the 30+ and asks what adoption was | Medium. The 30+ is a headline figure (V1); the adoption baseline is an open dossier unknown | Defend the figure in your own words. Name the weakest assumption behind it, or say you do not know how it was counted | 3 (C1 to C3) |
| Peer Evaluator | Seams between you and the squad leads | Low to medium. The hiring manager is not a peer, but squad authority is open and the squad leads may come up | Propose seam principles, not a verdict | 2 (D1 to D2) |
| Conversational | Opens with "walk me through" | High for the opener, which is scored anyway | A 90-second arc built from V1 to V3 | 2 (E1 to E2) |
| Pressure | Sixty-second challenges to your fit | Medium. The PM gap is the obvious pressure point | Hold through two follow-ups; concede specifically, never fold on the core | 2 (F1 to F2) |

## Question banks

### Bank A: Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier row V1); dossier prohibited_claims: "Having held a product manager title or role"; "Having owned a product roadmap" | The deepest rehearsal in this pack. Open with the limit in your own words: "I haven't held a product manager title, and I haven't owned a product roadmap." Then what the integration work gives you, quoting V1 at its own scope. Then the ramp: what you would do in the first 90 days, said as a plan. Hold: when pushed, return to V1, not to a larger claim. Concede specifically: "Prioritization across squads is the part I would be learning." On the second follow-up, state the same limit again, shorter. | The dossier's underwriter named this objection, derived from your confirmed evidence. F1 and F6 are where the answer comes from; the hold is only what V1 carries, and the concession is the dossier's own limit. |
| A2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Own the roadmap for the partner-facing API platform" (dossier role_profile responsibilities); dossier acknowledge_gap on roadmap ownership (F6) | Name roadmap ownership plainly: "I haven't owned a product roadmap." Then the one thing you would do first: learn how decisions are made between the roadmap and the two squads. No bridge and no claim about roadmap work. | Asks for the F6 gap directly. A plain answer scores better here than a bridge, which the dossier's acknowledge_gap rules out. |
| A3 | "Tell me how you have run agile delivery, inside a product org or otherwise." | JD | [grounded] "Agile delivery experience" (dossier role_profile R5); no sentence you gave carries it (F5) | Answer slot. If you ran agile delivery on any integration, say what it was and what you did. If you never worked that way, say so plainly, and say what you would want to confirm about how this team defines agile. | F5 is the discovery gap the dossier flagged. The clarify strategy gives the question-shaped answer; nothing about your past is added beyond what you say in the slot. |
| A4 | "Tell me about a request that came from sales and had to reach engineering. What did you do?" | JD | [grounded] "Stakeholder management across engineering, sales, customers" (dossier role_profile R4); "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier row V1) | Open prompt. If one of your integrations had a sales request reach engineering, tell it in your own words: what was asked, who you dealt with, what you did. If none did, say so plainly, and tell the nearest client-facing case V1 carries: scoping and requirements with the client. | F4 has no quote showing sales or engineering. This question tests the part of the row the material does not show, and the honest answer is available either way. |
| A5 | "Have you set priorities for an engineering squad?" | JD | [grounded] dossier prohibited_claims: "Having set prioritization for an engineering squad" | Closed question, closed answer: "I haven't set prioritization for an engineering squad." Then the nearest thing your material does carry, at its own scope: V3, "Ran quarterly roadmap-input sessions feeding client evidence to product." No answer slot, because this claim is on the prohibited list. | A closed question needs a closed answer. The dossier lists this claim as prohibited, so the pack does not coach any version of it. |

### Bank B: Case/Strategist (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A partner asks for an endpoint that three other partners don't use. How would you decide whether it goes on the roadmap?" | CASE | [generic] | Clarify first: what the partner needs and what it costs to say yes. Then structure: who else is affected, what it displaces, and the adoption measure you would judge it by. Name what you would need to know, including who holds the call between the roadmap and the squad leads. Propose a decision rule as a principle; do not pick a verdict. | A live problem from the JD's "Run discovery with integration partners" and "Own the roadmap" lines. Generic: it makes no claim about your past, and it touches the open squad-authority unknown. |
| B2 | "Adoption of one partner API dropped 20% this quarter. Diagnose it." | CASE | [generic] | Ask for the baseline before anything else. If there isn't one, say so, and say you would set one first. Then segment (which partners, which endpoints, which clients), and name the two or three causes you would test first. Do not claim a measure you have used. | Tests the adoption-baseline unknown from the dossier. A reply that asks for the baseline shows the open question is the answer. |
| B3 | "Write the first paragraph of a spec for a partner webhook feature." | CASE | [generic] | Start with the partner problem and what success looks like, then state what is out of scope. Keep it to one paragraph, and say what you would leave to engineering. | The JD's "Write specs and drive delivery with two engineering squads," tested as a writing task. Generic. |

### Bank C: Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "How did you count the 30+ integrations, and which of them were yours to scope?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier row V1) | Defend the number in your own words. Say how you counted, then name the assumption you would defend least before they do. Which part was yours: V1 says "Led," and that stays at the integrations' scope. Answer slot: if you do not know how the 30+ was counted, say so, and say what you would check first. | The 30+ is a headline figure in V1, so probers go two levels down. The pack does not supply a counting method; the answer must be one you can repeat under a second question. |
| C2 | "Tell me how you knew a go-live had worked." | EXP | [grounded] "scoping, requirements, architecture, UAT, go-live" (dossier row V1) | Open prompt. Walk the beats V1 names, in order: scoping, requirements, architecture, UAT, go-live. Answer slot: if you tracked anything after go-live, say what it was and who looked at it; if nothing was tracked after go-live, say so plainly. Do not name an adoption number you do not have. | Probes R2 (F2) and the open adoption question from the other side. The honest answer about what you measured after go-live is available whether or not anything was. |
| C3 | "How would you measure adoption of a partner API from the first week?" | JD | [generic] | Name the measure you would start with (for example, partners with a live integration), say you would agree the definition with engineering, and say you would need today's baseline first. Do not quote a figure from your past. | The JD asks you to "Define and track adoption metrics," and the dossier lists the baseline as unknown. Generic, because it is a method, not a claim. |

### Bank D: Peer Evaluator (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Our two squad leads work alongside this role. Where would you expect them to disagree with a PM here, and what happens then?" | JD | [grounded] "Write specs and drive delivery with two engineering squads" (dossier role_profile responsibilities) | Name the seam as a principle: who owns scope, who owns sequencing, and what you would want written down. Do not claim you have resolved one. | Peer-style seam question. The squad-authority unknown is what makes it real. The guidance makes no claim about your history. |
| D2 | "Which decisions would you make alone in this role, and which would you take to the squad leads?" | JD | [grounded] "Own the roadmap for the partner-facing API platform" (dossier role_profile responsibilities); dossier unresolved decision authority | Answer by category, not by verdict. Name the call you would keep (partner scope, say) and the call you would share (sequencing, say) as proposals. Then ask it in reverse before you commit (reverse question 1). | The dossier's open decision-authority question, asked by the interviewer. The guidance names the question to ask back, which the reverse questions carry. |

### Bank E: Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So — walk me through the journey." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier row V1); "Wrote the internal integration playbook her team uses" (dossier row V2); "Ran quarterly roadmap-input sessions feeding client evidence to product" (dossier row V3) | A 90-second arc: the integrations at V1's scope, the playbook at V2's scope, the roadmap-input sessions at V3's scope, then the limit in one line. Use each quote's own verb. Do not add a fourth beat you cannot back. | A casual opener that is scored. The arc is the three verified entries in order, with the limit last. |
| E2 | "What have you been reading or building against in API docs lately?" | JD | [grounded] "Technical fluency: API docs, schemas" (dossier role_profile R3); "Wrote the internal integration playbook her team uses" (dossier row V2) | Answer slot. If you worked from the vendor's API docs, name them and what you did with them. If you did not, say what you did read. Point to the playbook as what you wrote, and say plainly whether it covers schemas; if it does not, say so. | The casual wording of the JD's technical-fluency line. F3's presentation bridge keeps V2 at its own scope. |

### Bank F: Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why would you be a better hire than a PM with three years of the job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier row V1); dossier prohibited_claims: "Having held a product manager title or role" | Pause, and restate the question to yourself. Do not claim to beat a PM with three years of product work. Hold: the case you can make is the integration work at V1's scope. Concede specifically: you cannot match three years of owning a roadmap, and you would be learning prioritization. Two follow-ups: return to V1, then concede again. | The pressure form of A1. The hold is V1 at its own scope, and the concession is the dossier's own limit. |
| F2 | "Convince me you can say no to a squad lead." | JD | [grounded] "Write specs and drive delivery with two engineering squads" (dossier role_profile responsibilities) | Answer slot. If you have declined a request from someone senior, say what it was and how you handled it. If you have not, say so plainly, and say how you would decide when a squad lead pushed back. Hold through two follow-ups by naming the principle you would use. | No quote carries a refusal, so the second branch is the honest one. The hold is a principle you can state, not a past refusal you cannot name. |

## Requirement coverage

| Requirement | Covered by |
|---|---|
| R1: 3+ years product management | A1, A2, F1 |
| R2: shipped API or platform products | C2 only, as an answer slot. No quote carries a shipped product. |
| R3: API docs, schemas | E2. No schema-review question. |
| R4: stakeholder management | A4, D1 |
| R5: agile delivery | A3 |
| Roadmap ownership (R1 sub-claim) | A2, A5, D2 |
| Own the roadmap for the partner-facing API platform | A2, B1 |
| Run discovery with integration partners | B1 |
| Define and track adoption metrics | B2, C3 |
| Write specs and drive delivery with two engineering squads | B3, D1, F2 |

## Reverse questions

Each is a question to ask the interviewer. The first two answer the dossier's two open unknowns.

1. "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" Why it lands: it is the dossier's unresolved decision-authority question, and you need the answer before you accept.
2. "How is partner API adoption measured today, and what is the current baseline?" Why it lands: the baseline is open, and the answer tells you whether the metric is yours to set.
3. "How do partner integration requests reach the roadmap today?" Why it lands: it asks the discovery question the JD raises, and shows how decisions get made.
4. "What would a strong first 90 days look like in this role?" Why it lands: it sets the bar your ramp plan will be judged against.
5. "Is the partner platform roadmap a new mandate, or inherited from earlier planning?" Why it lands: it tells you what "owning" means here and how much of the roadmap is already committed.

## Sources

- **Provided:** your message; `tuesday-dossier.md` (dossier_version 1.1, generated 2026-08-14). The dossier supplied handoff_to_mock_interview (verified evidence, allowed strategies, prohibited claims, likely objection, risks, employer questions), role_profile (requirements, responsibilities, unknowns) and decision. It did not include evidence_map, evidence_state or risk_register, so the fit snapshot's grades come from the handoff's uncertain areas and this pack's own reading (F2, F5).
- **Where this pack differs from the dossier:** R5 is graded low in the dossier; this pack grades it none (F5). R2 is not graded in the dossier; the pack's reading is discovery, marked [inferred] (F2).
- **Research tier:** L1. Searches 0 of 6 returned results (2 refused). Fetches 0 of 2.
- **Queries sent:** "Quartzline platform APIs partner integrations product" (refused); "Quartzline company news 2026" (refused).

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quartzline values | unavailable | Values cheat sheet (section 10). No values-style round was detected, so it would not be built even with search. |
| 2. Quartzline interview process, product management | unavailable | Loop structure. Persona weights rest on the hiring-manager prior, not on a confirmed loop. |
| 3. Quartzline strategy and recent news | unavailable | The CO bank and the "sound current" guidance. Both queries above were refused. |
| 4. Interviewer name | n/a | No name was given, so there was no query to form. |
| 5. Representative JD | skipped | The dossier's role_profile fixes the requirement list and the JD-tagged questions. |

## Upgrade menu

- The current posting, or any change to the role since 14 August → fit rows F1 to F5 are regraded, and the dossier's R1 and R5 grades may move.
- Your answers to the decision-authority question and the adoption baseline, if you have learned either since August → rows D2, B2 and C3 and reverse questions 1 and 2 become firmer.
- The interviewer's name → an interviewer read, persona weights from their public footprint, and a tailored reverse question.
- Current company strategy (a strategy page or recent news you paste) → CO questions on the partner platform's current priorities.
- The playbook itself, or your CV → V2's presentation bridge can be checked against what the playbook covers (schemas), and V1 and V3 move from medium to higher confidence if an artifact can be inspected.
- Prep time before Thursday → a prioritized schedule keyed to the question IDs.
- Deep research (L2), offered once: up to 6 further searches and 2 fetches covering the interviewer, company strategy and role-family loop reports. It takes time, and web search was not granted in this session.
