# Ashgrove Credit Union: Member Experience Lead interview prep

**Role:** Member Experience Lead, Ashgrove Credit Union (member-owned, about 900 staff)
**Candidate:** Dara (they/them)
**Mode:** Loop. Three rounds on 5 December 2026, which is a Saturday. Confirm the times and format.

| Round | Who | Length | What it is |
|---|---|---|---|
| 1 | Recruiter | 30 min | Screen: background, logistics, motivation |
| 2 | Head of Member Services (your future manager) | 45 min | Mostly behavioural |
| 3 | Panel of two branch managers (not yet named) | 60 min | Includes a 20-minute complaint-escalation case. The panel also scores the four values. |

No interviewer profiles exist yet, so there is no interviewer read. The personas below rest on round-type priors and the recruiter's description of each round.

---

## 1. How to use, and the type key

Personas describe how a question is asked. Types describe what is being scored.

- **VAL**: values alignment. Does past behaviour show the published values?
- **EXP**: experience deep-dive. Do the CV's claims survive scrutiny?
- **JD**: role-driven. Can you do the listed job, gaps included?
- **CO**: company and strategy knowledge.
- **CASE**: a live problem from the role.

Guidance is scaffolding, not a script.

- **Answer slot:** an instruction for the interview, not a question for this conversation. It has two branches. "If you did this, say how. If not, say so plainly." The pack never supplies the missing practice.
- **Provenance:** the label, then the sentences the guidance rests on, quoted from your message or from the documents you pasted.
- **Labels:** `[grounded]` traces to a document you provided or to your own sentence. `[inferred]` is a derivation, named. `[generic]` is a pattern for this kind of interview, with no claim about you or about Ashgrove.
- **Question IDs:** A = round 1, B = round 2, C = round 3.

---

## 2. Prep triage (9 days)

Nine days remain. In order:

1. **Days 1 to 2:** settle your logistics answers, A3 to A6 (pay position, notice period, location, reason for leaving). Only you can supply these facts.
2. **Days 2 to 4:** drill B1, B2 and B3. These cover the two gaps your own message states (contact centre, presenting above regional level). They are the highest-return prep in the pack.
3. **Days 4 to 6:** run the C5 case twice, timed at 20 minutes, using the walkthrough in section 8.
4. **Days 6 to 7:** write one honest story per value from your own material for C1 to C4, or the honest branch where none exists.
5. **Day 8:** say the three strategy figures in section 4 aloud, and be ready for C8 and C9.
6. **Day 9:** confirm the round times, the format (in person or video), and whether the case material is sent in advance.

Everything else is insurance.

---

## 3. Fit snapshot

Requirements are quoted from the job description. Evidence is quoted from your message. Nothing here adds to what you said.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" (JD) | "6 years in retail banking, the last 3 as a branch supervisor." (your message) | medium | [grounded] | none | Your sentence covers the length and the branch role. Expect a probe on whether the branch work counts as customer operations. Say it in your sentence's terms: "I have six years in retail banking, three of them as a branch supervisor." |
| F2 | "experience handling regulated complaints" (JD) | "I handled the branch's formal complaints log and trained new tellers on our escalation script." (your message) | medium | [grounded] | transferability | Your sentence carries formal complaints work. It does not say the work followed a regulatory framework, such as set response deadlines or a referral to an outside body. That is adjacent work, and the bridge stops there: "I handled the branch's formal complaints log." Answer slot: if the log had set timescales or an outside referral route, say which and what you did in your own words. If it did not, say so, and say how you would learn the timescales that apply to regulated complaints. |
| F3a | "Own the member complaints process end to end across branches and the contact centre" (JD), branch part | "I handled the branch's formal complaints log and trained new tellers on our escalation script." (your message) | medium | [grounded] | transferability | Your material shows one branch's log, not the process end to end. Keep the bridge at that scope. Do not widen it to "the process." |
| F3b | "Own the member complaints process end to end across branches and the contact centre" (JD), contact-centre part | "Never worked in a contact centre" (your message) | none | [grounded] | capability | A stated absence. Words: "I have never worked in a contact centre." Then how you would learn that side of the work, as a plan and never as a past. |
| F4 | "coach branch supervisors on escalations" (JD) | "trained new tellers on our escalation script" (your message) | medium | [grounded] | presentation | Training tellers on the escalation script reaches coaching on escalations in other terms. Your sentence does not say you coached supervisors. Bridge: "I trained new tellers on our escalation script." Answer slot: if you ever coached a supervisor on an escalation, say what and when. If you did not, say so. Your own time as a branch supervisor is the nearest thing your material carries. |
| F5 | "work with digital teams on self-service journeys" (JD) | none given | none | [grounded] | discovery | Your material is silent on this. Answer slot: if you worked with anyone on a digital or self-service journey, say what and what your part was. If you did not, say so, and say how you would start. |
| F6 | "report monthly on complaint volumes and resolution times" (JD) | "I built the monthly complaints spreadsheet our regional manager uses." (your message) | medium | [grounded] | discovery | The sentence reaches monthly complaint reporting. It does not show whether the report tracked resolution times. Answer slot: if it tracked how long complaints took to close, say which measure and how it was counted, in your own words. If it did not, say so, and say what you would add. |
| F7 | "comfortable with Excel reporting" (JD) | "I built the monthly complaints spreadsheet our regional manager uses." (your message) | medium | [grounded] | none | Your sentence says spreadsheet, not Excel. Use the word spreadsheet unless you can confirm the tool. Expect a probe on which features you used. |
| F8 | "confident presenting to senior leaders" (JD) | "I've never presented to anyone above regional level." (your message) | none | [grounded] | capability | A stated absence. Words: "I have never presented to anyone above regional level." Then how you would close the gap, as a plan. |

**Observations (analysis, not words for you):** your material shows one branch's complaints log, not an end-to-end process. It shows a spreadsheet, not a confirmed Excel skill. It shows tellers trained on a script, not supervisors coached. It shows no digital work and no contact-centre work. Two rows are stated absences from you: F3b and F8. Both are answered plainly, then with a plan.

**Hard gates:** none surfaced in the material.

---

## 4. Grounding brief: Ashgrove's vocabulary

**Sources:** the 2026 strategy brief you pasted (July 2026) and the values page you pasted. Neither was checked against Ashgrove's live site, because no searches were run. The brief is under six months old.

**Use the brief's terms:** "member service", "digital channels", "hubs", "small-business lending", "app-only banks".

**Probes to expect:**

- **40% of member service to digital channels by 2028.** Complaints move into the app, and so do the escalation routes that go with them. See C8.
- **Eight branches consolidated into five hubs over 2027.** Open complaints at a closing branch, and the supervisor's role during the move. See C9.
- **Small-business lending launch, Q1 2027.** New complaint types arrive with a new product. Your material has no lending experience. Answer as a plan.
- **App-only banks as the main competitive pressure.** Expect a question on response speed and member retention.

---

## 5. Prohibited claims

Built locally from the fit snapshot. Each entry is a claim this pack will not coach, with its basis and its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| "Owned the complaints process end to end across branches and the contact centre" | Inflated form of F3a. The contact-centre part is a stated absence (F3b). | F3a at its scope: "I handled the branch's formal complaints log." Plus "I have never worked in a contact centre." |
| "Coached branch supervisors on escalations" | Inflated form of F4 | "I trained new tellers on our escalation script." |
| "Presented to senior leaders" | Negative you stated (F8) | "I have never presented to anyone above regional level." Plain acknowledgment, no slot. |
| "Reported resolution times" | Inflated form of F6 | "I built the monthly complaints spreadsheet our regional manager uses." at its scope. The resolution-time question is the slot in C6. |
| "Excel expert" or "built the reporting in Excel" | Inflated form of F7 | The spreadsheet sentence at its scope. |

**Observation:** the material says one branch's log, not the process. It says a spreadsheet, not Excel. It says tellers, not supervisors. Where a question widens these, the answer stays inside the quoted scope.

---

## 6. Round 1: recruiter screen (30 min)

**Persona weights**

| Persona | Weight | Why |
|---|---|---|
| Conversational / rapport | 4 (A1) | Screen priors. The opener is scored for economy. |
| Skeptic, light | 3 (A2) | Your stated contact-centre gap, asked in a friendly register. |
| Logistics slots | A3 to A6 | Pay, notice, location and reason for leaving. Recruiter screens check these. |

**Question bank**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, walk me through your background." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." (your message) | A 90-second arc: six years in retail banking, the last three as a branch supervisor, then the complaints log and the tellers' script, in your words, then why this role. Name only what your sentence says. | Rapport opener, scored for economy. F1 is the evidence. |
| A2 | "Do you have contact-centre experience?" | JD | [grounded] "Never worked in a contact centre" (your message) | "I have never worked in a contact centre." Then one sentence of plan: how you would learn that side of the work in your first months. Do not claim contact-centre work. | F3b is the stated gap, and the JD names the contact centre. B1 is the deeper form. |
| A3 | "What are your pay expectations?" | JD | [generic] logistics slot | Choose your position before the call: give your own figure, or ask for the role's band first. The pack supplies no figure. | Pay is a logistics slot. Only you can fill it. |
| A4 | "What is your notice period?" | JD | [generic] logistics slot | Give your actual notice period. The pack has no figure for it. | Notice is a logistics slot. Only you can fill it. |
| A5 | "Where are you based, and could you work across hubs?" | JD | [generic] logistics slot | Give your actual location, and any limit on travel between sites, in your own words. | Location is a logistics slot. The hub question returns in round 2 (see B2). |
| A6 | "Why are you leaving retail banking, and why now?" | EXP | [generic] logistics slot | Give your own reason, in your words, and keep it about the move rather than about the bank. The pack supplies none. | Reason for leaving is a logistics slot. The honest answer is yours to give. |

---

## 7. Round 2: Head of Member Services (45 min, mostly behavioural)

**Persona weights**

| Persona | Weight | Why |
|---|---|---|
| Skeptic | Highest: B1 (deepest), B2, B3 | Your two stated gaps, and the JD's "confident presenting to senior leaders." This is your manager, so the gaps matter most here. |
| Values / behavioural | 3 (B4) | The recruiter calls this round mostly behavioural. |
| EXP | 2 (B5, B8) | Tests what you did with the log and the script. |
| JD | 1 (B6) | Regulated-complaints experience. |
| Pressure | 1 (B7) | Tests whether you hold a position without folding. |

Depth follows weight: B1 receives the most follow-up rehearsal.

**Question bank**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The role owns complaints across the contact centre. What's your experience there?" | JD | [grounded] "Never worked in a contact centre" (your message) | Two sentences, then the slot: "I have never worked in a contact centre." If you handled complaints that came in by phone or through queues, say which and what your part was. If not, say so plainly. Then your 90-day plan for that side. Hold through two follow-ups by returning to the stated fact, not by adding to it. | **Highest-return prep in the pack.** The contact centre is named in the JD and is your stated gap, so a follow-up is likely. Rehearse it through three levels of follow-up. |
| B2 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre" and "I've never presented to anyone above regional level." (your message) | Name the contact centre first, and senior presentation second, in your own sentences. Then a ramp plan for each: what you would do in the first month. Concede without apology, and do not claim either area as covered. | Skeptic stem. Calibrated candour beats bluffing. The two stated gaps are the honest answer. |
| B3 | "You've never presented above regional level. How would you present to our leadership team?" | JD | [grounded] "I've never presented to anyone above regional level." (your message) | "I have never presented to anyone above regional level." Then one concrete plan: how you would prepare, and what you would want to see first before presenting to senior leaders. Do not say you have presented to anyone above regional level, and do not say the spreadsheet was presented. | JD: "confident presenting to senior leaders." Your stated negative is the answer, and the plan is the rest. |
| B4 | "Tell me about a time you had to tell a member something they did not want to hear about a complaint." | VAL | [grounded] "Members First, Always: we decide from the member's side of the counter." (values you pasted) | Selection scaffold: a complaint where the outcome went against the member and you had to say so. The story needs a named member outcome, what you said, and what happened after. If none comes to mind, say so plainly, then give the nearest thing your material carries: the formal complaints log you handled. | VAL for Members First. No sentence of yours carries a story for it, so the honest branch is written in. |
| B5 | "Walk me through how you handled the branch's formal complaints log." | EXP | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." (your message) | Story-mapped on F2: the log and your handling of it, in your sentence's terms. Answer slot: if you tracked how long complaints took to close, say what you tracked. If you did not, say so. Do not add a volume or a timeline. | The question names the log, which your sentence carries. EXP because it tests what you did. |
| B6 | "Which of those complaints had a set response time, or a route to an outside body?" | JD | [grounded] "I handled the branch's formal complaints log" (your message) | Answer slot: if they did, say which, and what you did to meet the deadline, in your own words. If they did not, say so plainly, then say how you would learn the timescales for regulated complaints. Do not name a regulator or a deadline you did not work to. | Premised on a practice that the JD raises ("regulated complaints") and your quote does not carry. The second branch allows that the premise is false. |
| B7 | "Your sentence says you trained tellers. Why should a branch supervisor take escalation coaching from you?" | Pressure | [grounded] "trained new tellers on our escalation script" and "6 years in retail banking, the last 3 as a branch supervisor." (your message) | Hold: "I trained new tellers on our escalation script, and I was a branch supervisor for the last three years." Then through the second follow-up, concede the specific gap: "I have not coached supervisors. My first step would be to sit in on their escalations before I coached anyone." | Pressure: hold, then concede a specific gap. Never claim supervisor coaching. |
| B8 | "Walk me through the escalation script you trained tellers on." | EXP | [grounded] "trained new tellers on our escalation script" (your message) | Story-mapped on your training of tellers: the script, and the training, at your sentence's scope. Answer slot: if you changed the wording, say what and why. If you did not, say so, and say what you would change to make it plainer. Do not say you wrote the script. | Tests plain-words thinking. Your material does not say you wrote it. |

---

## 8. Round 3: panel of two branch managers (60 min)

The recruiter's email names this round as the values round. Values-style detection is therefore met, and the values sheet and the case walkthrough live here.

**Persona weights**

| Persona | Weight | Why |
|---|---|---|
| Values / behavioural | Highest: C1 to C4 | The panel scores against the four values. |
| Case / strategist | 4 (C5) | A 20-minute complaint-escalation case. |
| Data-driven prober | 2 (C6) | Monthly reporting and Excel. |
| Peer evaluator | 3 (C7) | Two branch managers are peers. Expect seam probes between branch and contact centre. |
| CO | 2 (C8, C9) | Strategy probes from the brief. |

**Question bank**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you decided something from the member's side of the counter." | VAL | [grounded] "Members First, Always: we decide from the member's side of the counter." (values you pasted) | Selection scaffold: a counter moment where the member's need and the process disagreed. Beats: what the member asked, what you decided, what changed for them. If none comes to mind, say so plainly, then give the nearest thing: the complaint you handled through the log. Do not supply the ending. | Members First is one of four scored values. No sentence of yours carries a story for it. |
| C2 | "Tell me about something you wrote that someone had to have explained twice." | VAL | [grounded] "if a member needs it explained twice, we wrote it wrong" (values you pasted) | Selection scaffold: a letter, script or form that needed a second explanation. Beats: what was unclear and what changed. Nearest thing from your material: the escalation script you trained tellers on. If you changed its wording, say so. If you did not, say what you would change, in plain words. | Plain Words. Do not claim you rewrote the script. |
| C3 | "What did you know about the town your branch served?" | VAL | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." (your message) and "every branch is part of its town" (values you pasted) | Describe what you knew about the town, from your own time there. If you did not learn much about it, say so, and say how you would learn it before a hub move. Do not invent local facts. | Neighbours, Not Numbers. The hub consolidation makes this live. Premised on your supervision, which your sentence states. |
| C4 | "Tell me about a problem you found and kept hold of until it was solved." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." (your message) and "whoever finds the problem keeps hold of it until it is solved" (values you pasted) | Selection scaffold: a problem the figures showed you, which you kept until it was solved. Beats: what you saw, who you told, what you did, how you knew it was solved. The spreadsheet is the tool, not the fix. If the spreadsheet showed a problem you took on, say so. If it was reporting only, say so, and describe the problem you would hold next. | Own the Fix. A tool used by someone else is not a fix. |
| C5 | "Here's the case. A member has complained three times about a fee, after a branch declined a fee waiver. The complaint has sat with the branch for 21 days. The member now asks for it to go higher, and says they will take it to a regulator. Walk us through what you would do in the next 20 minutes." | CASE | [generic] | Use the walkthrough in the section below. | This is a role-family pattern. The recruiter has confirmed the case is about escalation, not its details. |
| C6 | "The spreadsheet you built: how did it measure how long a complaint took to resolve?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." (your message) | Answer slot: if the spreadsheet measured resolution time, say how it counted it and which assumption you would defend least. If it did not, say so, and say what you would add. Never describe a measure it did not carry. | Premised on a measure your quote does not carry. JD: resolution times. Second branch allows it absent. Excel reporting is tested here too. |
| C7 | "A branch manager disagrees with how an escalated complaint was closed. What do you do?" | Peer | [grounded] "coach branch supervisors on escalations" (JD) | Selection scaffold: a disagreement with a peer about a case. Beats: what each side wanted, what you did, what it changed. If none comes to mind, say so, then state the principle you would use: who decides on the case, and what is shared between branch and contact centre. Do not claim authority you did not hold. | Peer evaluator: seam principles, not an invented history. |
| C8 | "Forty percent of member service moving to digital by 2028. What does that do to complaints?" | CO | [grounded] "move 40% of member service to digital channels by 2028" (strategy brief you pasted) | Answer as a plan. Complaints arrive through the app or web forms. The risk is members who get stuck, and the escalation route that goes with them. Name what you would measure in the first quarter. Answer slot: the JD line, "work with digital teams on self-service journeys." If you have worked on a digital journey, say how. If not, say so, and say how you would work with the digital team on complaint routes. | Strategy probe, answered as a plan. Also tests F5. |
| C9 | "Eight branches become five hubs over 2027. What happens to open complaints at a branch that closes?" | CO | [grounded] "consolidate eight branches into five hubs over 2027" (strategy brief you pasted) | Answer as a plan: an inventory of open cases, a named owner for each, a plain-words notice to members about what changes and when, a handover date, and a check that no case goes unowned. Do not describe a closure you have run. | Tests whether you think about members, not only the timetable. |

### Values cheat sheet (round 3)

| Value (official name) | Working meaning | Mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | No sentence of yours carries a story here. Selection scaffold C1. Honest branch: say so, then the complaint you handled through the log (B5). |
| Plain Words | If a member needs it explained twice, we wrote it wrong | "trained new tellers on our escalation script" (your message). Whether you changed the script's wording is an answer slot in C2. |
| Neighbours, Not Numbers | Every branch is part of its town | No sentence of yours carries a story here. Scaffold C3. Honest branch: say what you knew, or what you would learn first. |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | "I built the monthly complaints spreadsheet our regional manager uses." (your message) is the artifact. Whether you kept a problem until solved is an answer slot in C4. |

### Case walkthrough: C5 (20 minutes)

The scenario is `[generic]`. The structure is the model. Ashgrove's escalation policy is not known, so ask about it rather than assume it.

| Minutes | Step | What to say |
|---|---|---|
| 0 to 3 | Clarify | What is the member asking for? What has been done so far? Is there a response deadline or an outside referral route? Who owns the case now? What does the branch hold, and what does the contact centre hold? |
| 3 to 6 | Objective and triage | Objective: resolve it fairly and keep the member informed, with regulatory exposure in view. Today: acknowledge the member, name one owner, and decide whether the disputed fee stands while the case is reviewed. |
| 6 to 12 | Options and decision | (a) The branch supervisor reviews the fee now. (b) The complaints team reviews it, with a set date. (c) The external route, if the member wants it. Criteria: harm to the member, the deadline, whether the branch's decision was consistent, and the fairness of the outcome. Pick one and say why. |
| 12 to 16 | Own it and communicate | One named owner. A plain-words call or letter. What happens next, and by when. What the member can do if unhappy. Set a follow-up date and check it: that is "keep hold until solved." |
| 16 to 20 | Learn and report | Record the root cause (were the waiver criteria unclear?). Check other branches for the same pattern. Say what goes into the monthly report: volumes, time to resolve, repeats. |

**Rules for the walkthrough:** think aloud. Name the assumption you are making about the policy. A handover to a supervisor is not a failure. If you have never handled a case with a regulator mentioned, say so, and describe the structure rather than a history.

---

## 9. Reverse questions

Every round has at least two. No profile exists, so none ties to an interviewer's own path. Round 3 includes a reciprocity question because the panel are peers.

**Round 1 (recruiter)**

- *"Is the case in round three based on a complaint file I would see beforehand, or would I get it on the day?"* Why it lands: it changes how you prepare, and the recruiter knows.
- *"Do you know how the values scores are combined across the three rounds?"* Why it lands: it shows you read the process, and it tells you whether the values round carries extra weight.

**Round 2 (Head of Member Services)**

- *"How do complaints from the contact centre and from the branches reach you today, and who owns each step?"* Why it lands: it tests the actual seam you would be managing, and it invites the manager to describe it.
- *"What would make the first six months in this role a success, especially through the hub changes?"* Why it lands: it shows you are already thinking about the consolidation, and it tells you what the manager will judge.

**Round 3 (panel, peer reciprocity)**

- *"What could a new person do in their first month that would genuinely help your branch?"* Why it lands: reciprocity framing. It asks what you bring the peer's team, not only what you need.
- *"When a complaint moves from the branch to the contact centre, what does it look like from where you sit?"* Why it lands: it probes the seam directly, and it lets the panel show you its own view.

---

## 10. Coverage: JD requirement to question IDs

| JD requirement | Covered by |
|---|---|
| Own complaints across branches and the contact centre | A2, B1, B2, C7 |
| Report monthly on volumes and resolution times | C6, B5 |
| Coach branch supervisors on escalations | B7, B8, C7 |
| Work with digital teams on self-service journeys | C8 (answer slot). Silence in the material, so no bank question of its own. |
| 4+ years in financial-services customer operations | A1 |
| Experience handling regulated complaints | B5, B6, C5 |
| Confident presenting to senior leaders | B2, B3 |
| Comfortable with Excel reporting | C6 |

---

## 11. Sources and target accounting

**Provided documents**

- The job description, quoted from your message.
- Your background, from your message.
- The four values, from the page you pasted this morning.
- The strategy brief, pasted from the July 2026 document the recruiter sent.
- The recruiter's email about the rounds.

**Searches and fetches:** none run. Each research target below is answered by a provided document, or does not apply.

**Research tier:** L1. Searches 0 of 6, fetches 0 of 2. No call was needed, because provided material fixes each output.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | Values sheet (section 8) and C1 to C4 use the pasted page. Not checked against the live site. |
| 2. Ashgrove interview process | skipped | The recruiter's email fixes the three rounds and their content. Persona weights follow them. |
| 3. Ashgrove strategy or recent news | skipped | The pasted July 2026 brief supplies the priorities and figures in section 4. It is under six months old. |
| 4. Interviewer name and company | n/a | No interviewer names were given. |
| 5. Representative JD | skipped | Your job description was supplied. |

---

## 12. Upgrade menu

- **Each interviewer's name** → per-round persona weights from public professional footprint, and a tailored reverse question for each. The panel's names matter most.
- **The recruiter's answer on the case format** (whether the scenario is sent in advance, and whether there is a scoring sheet) → C5 becomes a specific case, not `[generic]`.
- **Facts on F2, F5 and F6:** whether the log had set timescales or an outside referral route; any digital or self-service work; whether the spreadsheet tracked resolution times → each becomes a grounded claim, and its answer slot becomes a stated fact.
- **Your CV** → the Provenance cells can cite "your CV" with more quotes. F1 can rise to high if it has dated roles.
- **Your pay position, notice period and reason for leaving** → A3, A4 and A6 stop being instructions, and you rehearse the answers you have chosen.
- **A deeper research pass (L2)** → the strategy brief is already supplied, so it would add interviewer talks, loop reports and recent organisational context. Caps: up to 6 more searches and 2 more fetches, several minutes. Want it?
