# Interview prep pack: Senior GTM Strategy Lead, Emerging Products, Northwind Data

**Interviewer:** Dan Kovac, Director of Sales Strategy. Peer, same VP. Single 60-minute conversation.
**Built on:** your brief. No full JD text, no CV document, no pre-declared deliverable. Public research was refused in this session (see Sources), so nothing below about Northwind or Dan comes from a live check.

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored: VAL (values and behavior), EXP (your own experience), JD (the posting's requirements), CO (company and strategy), CASE (a live problem).
- Guidance is scaffolding, not a script. Rehearse the beats in your own words, and say only what you actually did.
- Answer slots (instructions, not questions) are where the honest answer is. Prepare both branches.

## 4. Fit snapshot

Requirements are the highlights from your note, which paraphrase the JD. Quotes in the evidence column come from your brief ("coach's notes").

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" (JD highlights) | "proposed a store-surface change credited with ~$400M ARR uplift" (coach's notes) | medium | [grounded] | transferability | Your material shows a change you proposed, not a go-to-market you owned. Say it at that scope: "I proposed a store-surface change, credited with a ~$400M ARR uplift." Answer slot: if you set any go-to-market decision for that change, say which and how you decided; if you set none, say so plainly and stay with the change. |
| F2 | "whitespace across land/adopt/expand/renew" (JD highlights) | "set annual volume targets with cross-org consensus" (coach's notes) | low | [inferred] | discovery | Volume targets are a planning input, not a whitespace map, and should not be stretched into one. Answer slot: if you ever sized unclaimed volume across land, adopt, expand or renew, say what you found and how; if you did not, say so and say how you would find it first. |
| F3 | "independent analysis in SQL and Tableau" (JD highlights) | "skilled in SQL/Tableau" (coach's notes) | medium | [grounded] | none | The quote reaches the requirement in role terms. Medium band: confirmed, with limited inspectable proof, so expect a probe. Say it as "I'm skilled in SQL and Tableau," and be ready to show one analysis. |
| F4 | "partner-motion design experience required" (JD highlights) | "built a partner-level revenue model used in carrier negotiations" (coach's notes) | medium | [grounded] | transferability | The model is partner-level and was used in negotiations. Your material does not show a partner motion designed: channel, terms or enablement. Say it at that scope: "I built a partner-level revenue model used in carrier negotiations." Answer slot: if you designed any part of how partners were signed, enabled or paid, say which and how you decided; if none of that was yours, say so and stay with the model. |
| F5 | "strong cross-functional influence" (JD highlights) | "set annual volume targets with cross-org consensus" (coach's notes) | medium | [grounded] | presentation | The quote reaches influence in other terms: targets set across orgs by consensus. Say it in those words: "I set annual volume targets with cross-org consensus." |
| F6 | "AI experience a plus" (JD highlights) | "uses AI tools daily" (coach's notes) | medium | [grounded] | transferability | Daily use of AI tools is adjacent to AI product work and does not reach it. Say "I use AI tools daily." Answer slot: if you have shaped an AI feature or product, say what it did and what your part was; if not, say so and say how you use the tools. |
| F7 | Not a JD highlight: the gap you stated (coach's notes) | "No classic sales-ops or quota-setting experience" (coach's notes) | none | [grounded] | capability | Plain acknowledgment from your own sentence: "I don't have classic sales-ops or quota-setting experience." Then how you would learn it, said as a plan, never as a past. |

Gate rows: none. The highlights name no eligibility term such as location, work authorization or travel. If the full JD has one, it becomes a gate row.

## 7. Reading the interviewer

Public footprint: not established. Searches were refused, so everything here comes from your description: "relentlessly data-driven," a career spine in pricing and monetization, and one early-stage-startup chapter.

- **Prober up.** Expect every number taken to its denominator and assumptions. Persona A carries the most weight.
- **Pricing spine.** Case questions tilt toward pricing and unit economics (C4, B5). Your partner-level model is the closest thing to his native language.
- **Startup chapter.** Expect probes on big-company pace and scrappiness. Your brief shows no startup chapter, so there is no shared career jump to offer as a mirror.
- **Shared vocabulary** is professional only: pricing and partner terms. Use his terms only where one of your quoted sentences carries them.

## 8. Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy | Questions |
|---|---|---|---|---|
| Data-Driven Prober | Figures taken to their denominators and assumptions | Highest. His profile says "relentlessly data-driven," and a peer round tests the analytics you would bring | Name the weakest assumption first; say plainly when you do not know how a figure was counted | 5 (A) |
| Peer Evaluator | Seams between your work and his pricing; disagreement; credit | High. Peer relationship prior, same VP | Propose seam principles, not claims about his team; credit by naming the consensus | 5 (B) |
| Case / Strategist | Live GTM and pricing problems | Medium-high. His pricing spine tilts cases toward pricing and unit economics | Clarify, then structure by land, adopt, expand and renew | 4 (C) |
| Skeptic | The GTM ownership and quota gaps | Medium. F1 and F7 are the gaps a peer will test | Plain acknowledgment, then a plan, not a past | 3 (D) |
| Pressure / Stress | A time-boxed challenge to the $400M credit | Low-medium. A short peer session can still press the headline number | Pause, restate, hold through two follow-ups, concede specifically | 2 (E) |
| Conversational / Rapport | A casual arc, and a casual AI question | Low. Peer openers are still scored | A 90-second arc; treat casual AI questions as scored | 2 (F) |

Total: 21 questions, inside the 18 to 26 range.

## 9. Question banks

### A. Data-Driven Prober (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how the $400M figure was counted." | EXP | [grounded] "proposed a store-surface change credited with ~$400M ARR uplift" | Say the change you proposed and the credit it received, in those words. Answer slot: if you know how the figure was counted, say how and name the assumption you would defend least; if you did not see the counting method, say so plainly. Hold to "credited with," not "drove." | The headline number on F1; probers go to headline figures first. EXP tests attribution. |
| A2 | "Which assumption behind that number would you defend least?" | EXP | [grounded] "proposed a store-surface change credited with ~$400M ARR uplift" | Name the weakest assumption before he does, in your own words. Answer slot: if you know which assumption is weakest, say it; if you do not know how the credit was attributed, say that plainly. | The weakest-assumption move on F1. The answer must be one you can repeat under a second question. |
| A3 | "Walk me through what your partner-level model estimates, and which input you trust least." | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" | Describe the model's output and its use in negotiations, in those words. Answer slot: name the least certain input; if you did not set that input yourself, say whose it was. | F4's model is the one artifact a probe can ask about. EXP tests who set which input. |
| A4 | "What is the most recent analysis you ran in SQL or Tableau, and what did you check before you trusted it?" | JD | [grounded] "skilled in SQL/Tableau" | Pick one analysis you ran yourself, and name the question, the data source and one check. Answer slot: if you did not run the last analysis yourself, say so and describe the check you did on it; if you have not run one end to end, say so and describe how you would validate it. | The JD's independent-analysis line. F3 is medium, so the probe is likely. |
| A5 | "Which AI tool output have you verified, and what did it get wrong?" | JD | [grounded] "uses AI tools daily" | Name one tool and one output you checked, and say what the check was. Answer slot: if you have not caught an error, say how you check outputs before they reach a decision. | The JD's AI plus, asked as a check on use, not as a claim of AI product work (F6). |

### B. Peer Evaluator (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our teams sit side by side. Where's the seam, and what happens when we disagree?" | VAL | [generic] | Propose seam principles, such as who decides pricing and who decides partner terms, rather than claims about his team. Say how you would settle a disagreement with an equal: the data first, then the owner of the decision. | A peer stem. The seam is the Peer Evaluator's scored item. |
| B2 | "How do you handle credit when work spans teams?" | VAL | [grounded] "set annual volume targets with cross-org consensus" | Tell the consensus story in those words: who was in the room and what you changed. Answer slot: if the consensus had dissent, say who and how it settled; if it had none, say so. | F5 is the cross-org evidence. The credit question is a peer's. |
| B3 | "What would you need from my team in the first month?" | VAL | [generic] | Name inputs as questions: deal data, pricing data, and how each is read. Do not say what his team has or has not done. | Tests how you would use his team without claiming knowledge of it. |
| B4 | "Where would partner terms touch my pricing decisions?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | Name the overlap plainly: your carrier model touches partner pricing. Say what you would hand off and what you would keep. Answer slot: if you have designed partner terms beyond the model, say how; if the model is as far as it went, say so. | The partner-motion requirement meets his pricing. A peer tests the seam here. |
| B5 | "You've run pricing and monetization for years. Where would you disagree with me on a discount?" | CO | [grounded] "built a partner-level revenue model used in carrier negotiations" | Name one discount principle you would hold, and where you would defer to his pricing data. | Tilts to his native language. The answer should show judgment, not agreement. |

### C. Case / Strategist (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A customer adopts the data product and stops expanding after year one. What do you check first?" | CASE | [generic] | Clarify first: which segment, and which stage: land, adopt, expand or renew. Then segmentation, one or two metrics, one approach, one risk. Think aloud. | The whitespace requirement as a live problem. Asks about no past. |
| C2 | "Of enterprise expansion, the AI copilot launch and reaching profitability, which would you protect if you could fund only two?" | CO | [grounded] "enterprise expansion, an AI copilot launch ('Compass'), and reaching profitability" (research note) | Say which you would protect, and the one metric that would show the trade. Do not describe internal plans you have not seen. | Shows you read the company's stated priorities. The research note is your source, not a live check. |
| C3 | "A much larger platform vendor starts bundling a competing tool into its suite. What is your first move?" | CASE | [grounded] "main competitive threat is bundling by a much larger platform vendor" (research note) | Clarify which accounts see the bundle and where price matters. Then say what you would not do, such as matching a bundled discount, and why. Name one concession. | The anti-pick. The consensus move is to match; saying no, with reasons, scores as judgment. |
| C4 | "How would you price a copilot tier so it doesn't cannibalize the current tier?" | CASE | [generic] | Name the cannibalization test first, then the unit economics, then the willingness-to-pay assumption you cannot verify. Say which data would settle it. | Pricing spine tilt, and the Compass priority. Makes no claim about this company's pricing. |

### D. Skeptic (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "The JD asks you to own GTM strategy for two new product lines. Which part of that have you done?" | JD | [grounded] "proposed a store-surface change credited with ~$400M ARR uplift" | **Highest-ROI rehearsal in this pack.** Open with the proposal, in those words. Answer slot: if you set any go-to-market decision for that change, say which and how; if you set none, say so, and name the part of GTM you would take first. Hold through two follow-ups by returning to the proposal, and never add to it. | This is the requirement the material leaves thinnest (F1). The objection will arrive in some form, and the rehearsed answer is the one that holds. |
| D2 | "You have no quota-setting experience. How would you set one?" | EXP | [grounded] "No classic sales-ops or quota-setting experience" | Plain acknowledgment from your own sentence: "I don't have classic sales-ops or quota-setting experience." Then the method you would use, said as a plan, never as a past. Adjacent: "I set annual volume targets with cross-org consensus," at that scope only. | The stated gap a peer will test. F7 gives the plain acknowledgment; no slot asks about quota work you did not do. |
| D3 | "The JD asks for partner-motion design. What is the closest thing you have designed, and where does it stop?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | Describe the model in its scope, then its limit. Answer slot: if you designed any part of partner recruitment, enablement or terms beyond the model, say which and how you decided; if not, say the model is as far as you went. | An open prompt on a JD line the material only partly meets (F4, transferability). |

### E. Pressure / Stress (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why should I take you over someone who has run GTM for two product lines?" | JD | [grounded] "proposed a store-surface change credited with ~$400M ARR uplift"; "built a partner-level revenue model used in carrier negotiations" | Pause, then restate the question. Lead with the proposal and the model, in those words. Concede the GTM gap by name, in one sentence. Hold through two follow-ups; never fold on the product and revenue work. | Pressure form of F1 and F4. Hold, then concede, specifically. |
| E2 | "That $400M. How much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with ~$400M ARR uplift" | Give the credit as the sentence states it, then the share you can name. If it was shared, concede shared credit explicitly. Never fold on the proposal itself. | The attribution probe is the stress stem most likely to target the headline. |

### F. Conversational / Rapport (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm, then 9 years at a large consumer-tech company in product strategy & ops" | A 90-second arc in those beats, then the proposal, then the model. Claim no startup experience. | A casual opener is still scored. The arc uses your own dates and sequence. |
| F2 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" | Name one tool and one use you checked. Keep it to use, not building. | A casual form of the AI plus, scored as usual (F6). |

### Requirement coverage

| JD requirement | Question IDs |
|---|---|
| Own GTM strategy for two new product lines | D1, E1, C1 |
| Whitespace across land / adopt / expand / renew | C1 |
| Independent analysis in SQL and Tableau | A4 |
| Partner-motion design experience | D3, B4 |
| Strong cross-functional influence | B2, B1 |
| AI experience a plus | A5, F2 |
| Quota-setting (your stated gap; not a JD highlight) | D2 |

## 11. Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What would a new person do in their first month that would genuinely help your team?" | Reciprocity, for a peer round. It moves the conversation from what you need to what you bring. |
| R2 | "Your career has run through pricing and monetization. Which pricing call do you think about most, and why?" | Tied to his own path. It turns the interview into a peer conversation about his judgment, and shows you read his profile, not only the company's. |
| R3 | "Where does the partner motion sit between sales strategy and pricing today?" | Names the seam directly. The answer tells you who owns partner terms. |
| R4 | "How does Compass position against bundling by the larger platform vendors?" | Uses the stated priority and the stated threat, and shows the research note was read. |
| R5 | "What does a good first 90 days look like for whoever leads emerging-product GTM?" | Calibrates scope and what the decision owner expects early on. |
| R6 | "How do the emerging-product numbers get read, and who reads them?" | Speaks to a data-driven peer. Signals that you care how the work is judged. |

## 13. Prohibited claims

Built locally from the fit snapshot. These are the claims a candidate reaches for under pressure. No answer, hold, bridge or rationale in this pack asserts them.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned GTM strategy for a product line | Inflated form of F1 | "proposed a store-surface change credited with ~$400M ARR uplift," at its own scope. Pack observation: the material shows a proposal, not a go-to-market. |
| Drove the $400M uplift | Inflated form of F1's figure | "credited with ~$400M ARR uplift." E2 asks for the share. |
| Designed a partner motion | Inflated form of F4 | "built a partner-level revenue model used in carrier negotiations." Pack observation: the material shows the model, not channel, terms or enablement. |
| Set whitespace or land, adopt, expand and renew plans | Inflated form of F2 | "set annual volume targets with cross-org consensus." Pack observation: the material shows targets, not whitespace. |
| Has shipped AI products | Inflated form of F6 | "uses AI tools daily." Pack observation: the material shows use, not product work. |
| Has set quotas or run sales ops | Stated negative (F7) | "I don't have classic sales-ops or quota-setting experience," in your own words. No slot. |

## 14. Sources

- **Provided documents:** your brief (coach's notes), covering the candidate's history, the JD highlights, the interviewer's profile description, and the research note on Northwind's three stated priorities and the bundling threat.
- **Calls sent:**
  - "Northwind Data company values": refused.
  - "Northwind Data Compass AI copilot launch": refused.
  - "Dan Kovac Director of Sales Strategy Northwind Data": refused.

Research tier: L1 — searches 3 of 6, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Northwind values | unavailable | Search refused. Would have moved the values cheat sheet, which is omitted because no values-style round is detected. |
| 2. Interview process for the role family | unavailable | No call sent after the refusals. Would have set persona weights for the round; the relationship (peer) and your description set them instead. |
| 3. Strategy and recent news | unavailable | Compass query refused. Would have moved the grounding brief and the CO bank; your research note supplies the three priorities. |
| 4. Dan Kovac public footprint | unavailable | Search refused. Would have moved the interviewer read beyond your description, and the reverse questions. |
| 5. Representative Senior GTM JD | unavailable | No call sent. Would have moved the JD rows where your highlights run out. |

## 15. Upgrade menu

- Full JD text → requirement quotes become the posting's own words, and any eligibility term becomes a gate row.
- Your CV document → the evidence quotes come from the CV rather than from your brief, and each sentence is checked against it.
- A pre-declared deliverable (a deck, POV or written exercise) → a build section for it.
- Search access → targets 1 to 5 move from unavailable to yes or skipped, and the interviewer read gains public footprint.
- Dan's public talks or writing → persona weights and a tailored reverse question.
- Prep time before the round → a prioritized triage of the pack.
- `tuesday-dossier.md` with verified evidence → user-confirmed quotes with confidence set by inspection, which sharpens every F row.
