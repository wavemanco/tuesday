# Interview prep pack: Product Operations Manager, Stripe (final round)

Changelog: first version. Built with no CV, no job description, no interviewer name, and no round details. Research was not run (search permission was not granted), so nothing below about Stripe's values, process or strategy is verified.

## How to use this pack

- **Personas** describe *how* a question is asked (friendly, skeptical, time-pressured, and so on). **Types** describe *what* is being scored.
- Type key: **VAL** behavioral/values alignment · **EXP** your own past work, probed in depth · **JD** the role's stated responsibilities · **CO** company and strategy knowledge · **CASE** a live problem.
- Guidance is scaffolding, not a script. Speak it in your own words.
- Provenance: **[generic]** means a question or pattern drawn from the role family, not from you or from Stripe. No line in this pack is a fact about your past.

## Prep triage

Prep time was not stated, so no schedule is given. In order of value:
1. Rehearse the Pressure and Skeptic questions (section 8 onward) out loud. These are the moments where a prepared answer matters most.
2. Rehearse the CASE questions with a timer.
3. Write your own two or three stories from past work, using the selection scaffolds in the banks.

Everything else is insurance.

## Fit snapshot (worksheet variant)

No CV or job description was supplied, so each row is a worksheet. Every evidence cell is `none given`, and every confidence is `none`.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Run the operating cadence that keeps a product org on track (role family) | none given | none | [generic] | discovery | Answer slot: describe a recurring planning or review process you have run or taken part in. If you have not run one, say so and describe how you would set one up. |
| F2 | Turn ambiguous cross-team problems into a clear owner, plan and metric (role family) | none given | none | [generic] | discovery | Answer slot: describe one cross-team problem you helped structure. If none was yours to structure, say so plainly and describe how you would approach one. |
| F3 | Measure whether a product or process change worked (role family) | none given | none | [generic] | discovery | Answer slot: name a metric you tracked and what you did with it. If you have not tracked one, say so and name the one you would track first. |
| F4 | Partner with engineering, finance and go-to-market teams (role family) | none given | none | [generic] | discovery | Answer slot: describe one working relationship across functions, in your own words. |
| F5 | Communicate clearly to senior leaders (role family) | none given | none | [generic] | discovery | Answer slot: describe one update or recommendation you gave a senior audience and how it landed. |

Gate requirements: none are known, because no JD was supplied. If the posting lists a hard gate (location, work authorization, a required certification), add it to the JD and it will get its own row.

## Prohibited claims

Built from the fit snapshot. No quote exists yet, so there are no inflated-form or sourced entries. Nothing below may be claimed, and no answer should be rehearsed as if it were true:
- No specific project, metric, team size or outcome is attributed to you. The pack has no source for any of them.

This section will fill in once your background is supplied.

## Reading the interviewer

Not available: no interviewer name or profile was given.

## Persona weights

Relationship and round are unknown, so weights are flat. This is noticeably weaker than a weighted pack. Each persona gets depth 2–3.

| Persona | Weight | Why | Counter-strategy |
|---|---|---|---|
| Case / Strategist | 3 | Product ops is judged on structure, and the case is the likeliest live format | Clarify, then structure, then answer. Say the framework aloud. |
| Values / Behavioral | 3 | Stripe-style final rounds often include a scored values conversation | Pick a specific story per value. "We" for context, "I" for your part. |
| Data-Driven Prober | 3 | Any metric you cite will be probed | Name the weakest assumption before they do. Say plainly when you don't know how a figure was counted. |
| Skeptic | 3 | "Why this role, why now, what's the gap" is near-universal | Rehearse your single most likely objection until it is calm and short. |
| Pressure / Stress | 2 | Tests composure, not content | Pause, restate the question, hold a position through two follow-ups, then concede uncertainty specifically. |
| Conversational / Rapport | 2 | Casual questions are still scored | Have a 90-second career arc ready. Treat casual questions about the role as scored. |
| Peer Evaluator | 2 | If a peer is on the panel, expect seam and credit questions | Lead with what you bring to their team, not only what you need. |

## Question banks

Guidance cells contain no claim about your past. Where you need a story, use the selection scaffold.

### A. Case / Strategist (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A product team's launch slipped by six weeks and nobody knows why. How would you find out?" | CASE | [generic] | Clarify the scope and timeline first. Then list the likely causes (scope, dependencies, staffing, decisions). Then propose how to get data on each, and who to ask. | A live problem set in the role. Generic because it is a pattern, not a fact about this company. |
| A2 | "Design a quarterly business review for a product area with five teams. What goes in it?" | CASE | [generic] | Start with the decision the review should support. Then agenda, inputs, owners, and what would change as a result. | Tests whether you design a process around decisions, not around slides. |
| A3 | "A key metric went down 15% last month. Walk me through how you'd diagnose it." | CASE | [generic] | Clarify the metric definition and the change window. Segment before you hypothesize. Name two or three hypotheses, then the data that would confirm or kill each. | The most common analytical probe in ops roles. Structure matters more than the answer. |

### B. Values / Behavioral (weight 3)

Stripe's published values were not verified this session. Read the company's own values page before this bank, then map one story to each value. The selection scaffold below applies until then.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time you raised a hard truth to someone more senior than you." | VAL | [generic] | Open prompt. Pick a specific time with a real stake, a moment you did not back down, and an outcome. If no such time comes to mind, say so plainly, then give the nearest one you have and what you would do differently. | A standard behavioral probe. Requires a real story. |
| B2 | "Describe a time you improved a process that others had accepted as fine." | VAL | [generic] | Open prompt. Pick a process, the evidence that it was broken, what you changed, and how you knew it worked. If none, say so and describe how you would find such a process. | Tests ownership and initiative. |
| B3 | "Tell me about a decision you made with incomplete information." | VAL | [generic] | Open prompt. Say what you knew, what you didn't, what you chose, and what you'd check first next time. | Tests judgment under uncertainty, which ops roles require constantly. |

### C. Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Pick a number from your last role. How was it counted?" | EXP | [generic] | Answer slot: if you have a figure, say how it was counted, what it is sensitive to, and which assumption you would defend least. If you have no figure, say so and describe how you would measure it. | Prober questions always go to the denominator. Only use numbers you can defend in your own words. |
| C2 | "What would make your best result from last year look like noise?" | EXP | [generic] | Answer slot: name the confounder you know of. If you did not check for one, say that plainly. | Tests whether you can see the weakness in your own claim. |
| C3 | "How would you know if a process change you made actually worked?" | JD | [generic] | Name the outcome metric, the comparison, the time window, and what you would call a failure. | Tests measurement thinking that the role requires. |

### D. Pressure / Stress (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why should we hire you over someone who has done this exact job?" | EXP | [generic] | Pause. Restate the question. Answer with the strongest true thing you can say about your fit, and do not invent a credential you lack. Hold your position through two follow-ups. Concede specifically if a follow-up is right. | Tests composure, not your résumé. |
| D2 | "That result sounds good. How much of it was actually you?" | EXP | [generic] | Answer slot: say which part was yours, in your own words. If the result was mainly someone else's, say so and describe what you contributed. | Tests attribution honesty under pressure. |

### E. Skeptic (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | Name one real gap, then a concrete ramp plan. Keep it short. Do not bluff a skill you lack. | Calibrated candor is the scoring point. |
| E2 | "Why this role, and why leave where you are now?" | EXP | [generic] | Answer in your own words: one reason about the role, one reason about your move. Keep both forward-looking. Say nothing you would not repeat to your current manager. | The motivation probe is near-universal in final rounds. |
| E3 | "Product ops at a fast-moving company can be reactive. How would you keep it from becoming that?" | CASE | [generic] | Name one mechanism: a planning cadence, a decision log, or a rule for what gets escalated. Then say how you would know it worked. | A generic challenge to the role, not a fact about Stripe. |

### F. Conversational / Rapport (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through your journey." | EXP | [generic] | Have a 90-second arc ready: what you did, in what order, and why you moved. Stick to facts you can repeat. | An easy opener that is still scored on communication economy. |
| F2 | "What's the most interesting problem you've been thinking about lately?" | CO | [generic] | Name one problem in product operations you have actually thought about. Say why it interests you. | Tests genuine interest. Do not use a line you have not thought through. |

### G. Peer Evaluator (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Our teams sit side by side. Where's the seam, and what happens when we disagree?" | JD | [generic] | Propose principles for the seam (who decides what, how disputes escalate). Do not pretend to know their seam yet. | Peer probe on turf and disagreement. |
| G2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Name the practice you use to make credit visible, and one time it was hard. | Tests collegiality. |

Coverage notes:
- **Requirement-coverage line:** no JD, so no requirement can be mapped. Supply the JD and this line will be built.
- **CO coverage is thin.** Research did not run. Stripe's strategy and recent moves are not in this pack. Read Stripe's current product announcements before the final round.

## Reverse questions

Each has a "why it lands." At least one would tie to the interviewer's path once a profile exists.

1. "What does a strong first six months look like in this role?" *Why it lands:* signals you plan to be useful, not just to get the job.
2. "Which operating process here do people complain about most, and what's being done?" *Why it lands:* shows you look for friction, which is the core of the job.
3. "How do product and operations decisions get made when they disagree?" *Why it lands:* the seam question, asked as curiosity.
4. "What would you need from the person in this role that you aren't getting now?" *Why it lands:* turns the interview into a working conversation.
5. "What did the last person in this role do that you'd want more of?" *Why it lands:* an informed question about the team's real needs.
6. Reciprocity (if a peer is on the panel): "What could a new person in your team do in their first month that would genuinely help you?" *Why it lands:* shows you think about their load, not only yours.

## Delivery coaching

No working-style assessment was provided, so this section is omitted.

## Prohibited claims (revisited)

No claims are prohibited yet, because nothing has been quoted from you. Once you share your background, claims will be listed here with the sentence each rests on.

## Sources

- Provided documents: none beyond the request itself.
- Research tier: L1 requested, but search permission was not granted; no searches or fetches ran.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Stripe values | unavailable | Values cheat sheet (section B). Would have named the published values. |
| 2. Stripe interview process, product operations | unavailable | Loop structure and persona weights. Would have named the rounds. |
| 3. Stripe strategy / recent news | unavailable | CO bank and grounding brief. Would have supplied current priorities. |
| 4. Interviewer name + Stripe | n/a | No interviewer name was given, so there was no query to form. |
| 5. Representative Product Operations Manager JD | unavailable | Would have supplied requirement rows labeled [inferred]. |

## Upgrade menu

- Your CV or background → the fit snapshot's worksheet rows become real rows, and the banks become story-mapped where your sentences carry a story.
- The job description (paste it) → the requirement rows become [grounded], and the requirement-coverage line gets built.
- The interviewer's name → a tailored reverse question, and persona weights read from their public footprint.
- The round type and whether it is a panel → persona weights restructured to match.
- Search access granted → Stripe's values, interview process and current strategy get verified, and the values cheat sheet and CO bank get written.
