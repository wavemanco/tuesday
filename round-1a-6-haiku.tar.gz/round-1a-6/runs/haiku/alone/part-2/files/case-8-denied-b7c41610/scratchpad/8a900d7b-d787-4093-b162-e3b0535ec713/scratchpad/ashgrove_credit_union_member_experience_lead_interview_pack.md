# Interview prep pack: Member Experience Lead, Ashgrove Credit Union

**Role:** Member Experience Lead
**Company:** Ashgrove Credit Union (member-owned, about 900 staff)
**Candidate:** Dara
**Rounds (5 December 2026):** Round 1, 30 min, recruiter. Round 2, 45 min, Head of Member Services (would be your manager), mostly behavioural. Round 3, 60 min, panel of two branch managers, with a 20-minute complaint-escalation case; the panel also scores against the four values.
**Interviewer names:** not yet known for any round. The interviewer read is therefore absent and the personas use round-type priors.
**Changelog:** first version.

---

## 1. How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored.
- Type key: **VAL** behavioural / values; **EXP** your own work, checked for attribution; **JD** the role's listed requirements; **CO** company and strategy; **CASE** a live problem.
- Guidance is scaffolding, not a script. Each guidance cell is written to be spoken in 90 to 120 seconds, using your own sentences.
- Where a cell says "answer slot", the answer is yours to give from your own experience. If the honest answer is "that was not mine" or "I haven't done that", say so. That answer is acceptable.
- Quoted sentences in the **Provenance** column are the only things this pack says about your past. Everything else is either a question, a plan, or labelled `[generic]`.

---

## 2. Fit snapshot (shared across all three rounds)

Requirements are the JD's own words. Evidence is your own words, quoted from your message. Confidence is set by what can be inspected; none of your material has been inspected yet.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches and the contact centre" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | transferability | Your material says the branch's complaints log, not the process end to end. Keep the words there: "I handled the branch's formal complaints log." Answer slot: if any part of the process was yours to set, say which and how you decided; if not, say so and stay with the log. |
| F2 | "across branches and the contact centre" (JD) | "Never worked in a contact centre" (your message) | none | [grounded] | capability | A gap you stated, so the words can be given back: "I haven't worked in a contact centre." Then how you would learn it, said as a plan, never as a past. |
| F3 | "report monthly on complaint volumes and resolution times" (JD) | "I built the monthly complaints spreadsheet our regional manager uses." (your message) | medium | [grounded] | presentation | The spreadsheet reaches monthly complaint reporting in other terms. It does not say resolution times were in it. Bridge rewords only the quote: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: if it counted resolution times, say how; if not, say so plainly. |
| F4 | "comfortable with Excel reporting" (JD) | "I built the monthly complaints spreadsheet our regional manager uses." (your message) | low | [grounded] | discovery | Your material does not name the tool. Answer slot: say which tool you built it in, and what you did in it yourself. |
| F5 | "coach branch supervisors on escalations" (JD) | "trained new tellers on our escalation script" (your message); "the last 3 as a branch supervisor" (your message) | medium | [grounded] | transferability | Training tellers is adjacent to coaching supervisors, not the same work. Bridge: "I trained new tellers on our escalation script." Answer slot: if you coached supervisors on escalations, say how it differed; if you did not, say so and say what you would do first. |
| F6 | "experience handling regulated complaints" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | presentation | Your material says "formal", not "regulated". Bridge rewords only the quote. Answer slot: if the log followed specific rules or timescales, name them in your own words; if not, say so. |
| F7 | "4+ years in financial-services customer operations" (JD) | "6 years in retail banking, the last 3 as a branch supervisor." (your message) | medium | [grounded] | none | The quote reaches the requirement. Bridge: "6 years in retail banking." The claim is retail banking in branches, and the words stay there. |
| F8 | "confident presenting to senior leaders" (JD) | "I've never presented to anyone above regional level." (your message) | none | [grounded] | capability | A gap you stated: "I haven't presented to anyone above regional level." Then how you would build to it, as a plan. |
| F9 | "work with digital teams on self-service journeys" (JD) | none given | none | [grounded] (JD line) | discovery | Your material says nothing about digital teams. Answer slot: if you have worked with a digital team on a self-service journey, say what your part was; if not, say so and say how you would approach it. |

**Gate rows:** none. Nothing in the JD or your material is a term you either meet or do not, such as authorisation or a credential.

**Prohibited list (section 4 below) binds every cell.**

---

## 3. Grounding brief (from the July 2026 strategy brief your recruiter sent)

Vocabulary the interviewers are likely to use:

- **Digital channels:** the brief's target is to "move 40% of member service to digital channels by 2028." Use "digital channels" and "member service" as the brief does.
- **Hubs:** "consolidate eight branches into five hubs over 2027." Expect questions about what this means for complaints in the towns involved.
- **Small-business lending:** launching in Q1 2027. Not core to this role; say so if asked, and do not pretend a view on it.
- **Competitive pressure:** the brief names app-only banks as the main pressure.

Flag: the brief is from July 2026. It is the best current source you have, but treat it as a snapshot. Do not coach yourself to correct an interviewer who uses older framing.

---

## 4. Prohibited list

These claims are not coached, in any cell. Each entry says why.

| Not coached | Basis | Honest form |
|---|---|---|
| "Owned the complaints process end to end across branches and the contact centre" | Inflated form of F1 | "I handled the branch's formal complaints log." Limit, in analysis: your material says the log, not the process. B7's answer slot stays inside the log. |
| "Coached branch supervisors on escalations" | Inflated form of F5 | "I trained new tellers on our escalation script." |
| "Experience handling regulated complaints" | Inflated form of F6 | "I handled the branch's formal complaints log." |
| "Reported resolution times monthly" or "built it in Excel" | Inflated form of F3 and F4 | The quote at its own scope, with the answer slot for the rest. |
| "Contact-centre experience" | Sourced negative, F2 | "I haven't worked in a contact centre." |
| "Presented to senior leaders" | Sourced negative, F8 | "I haven't presented to anyone above regional level." |

---

## 5. Persona weights (by round)

Weights are shown so you can recalibrate. Round 1 is a recruiter screen. Round 2 is a manager round that the recruiter described as mostly behavioural. Round 3 is a values-scored panel with a case.

| Round | Persona | Weight | Reasoning | Counter-strategy |
|---|---|---|---|---|
| 1 Recruiter | Conversational / rapport | top | Round-type prior; the recruiter screens logistics and motivation | Rehearse the 90-second arc; treat every "casual" question as scored |
| 1 Recruiter | Skeptic | light | Motivation and gaps are checked early | Say the two stated gaps plainly, once, with a plan |
| 2 Head of Member Services | Values / behavioural | top (4 of 11) | Recruiter said "mostly behavioural" | Selection scaffolds with honest branches |
| 2 Head of Member Services | Skeptic | high (3 of 11) | The JD's contact-centre and senior-presenting requirements are both stated gaps | Hold, then concede specifically |
| 2 Head of Member Services | Case / strategist | mid (2 of 11) | Manager will want to see the role's coaching and strategy | Structure before answer |
| 2 Head of Member Services | Data prober | low (1 of 11) | Your spreadsheet is the one number-bearing claim | Name the weakest assumption first |
| 2 Head of Member Services | Pressure | low (1 of 11) | Touched, not weighted, given the round's stated focus | Restate, then hold through two follow-ups |
| 3 Panel (two branch managers) | Values / behavioural | top (4 of 11) | Panel scores against the four values | One story per value, or the honest branch |
| 3 Panel | Case / strategist | top (3 of 11) | The 20-minute escalation case | Clarify, triage, act, then change the system |
| 3 Panel | Peer evaluator | mid (2 of 11) | Assumption: the branch managers would work beside this role. Not confirmed | Propose seam principles, not facts about their seam |
| 3 Panel | Data prober | low (1 of 11) | Monthly reporting will come up | Weakest-assumption move |
| 3 Panel | Pressure | low (1 of 11) | Touched via the senior-presenting gap | Hold, then concede |

Round totals are 8, 11 and 11 questions. Each round stands alone, per loop mode.

---

## 6. Round 1: Recruiter screen (30 min)

**Persona weights:** Conversational top; Skeptic light; logistics rows are the recruiter's own checks and sit under Conversational.

**Reverse questions (5)**

| # | Question | Why it lands |
|---|---|---|
| R1-Q1 | "How many candidates are at this stage, and when is the decision expected?" | Tells you the pace of the 5 December loop. |
| R1-Q2 | "How does the 5 December panel work, and is the case sent in advance or given on the day?" | Sets how you prepare the 20-minute case. |
| R1-Q3 | "Which of the brief's three moves, the digital shift, the hub consolidation or the small-business lending launch, is this role most tied to?" | Strategy-linked; shows you read the brief. |
| R1-Q4 | "What would a good first six months look like in this role?" | Turns the screen toward the job. |
| R1-Q5 | "What has the last person in this role found hardest?" | Shows you want the real picture, not the brochure. |

**Round 1 bank (8 questions)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, walk me through your journey to where you are now." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." (your message); "I handled the branch's formal complaints log and trained new tellers on our escalation script." (your message) | Ninety-second arc: six years in retail banking, the last three as a branch supervisor, then the two things you did in the branch, in those words. Stop there and let them follow up. | F7 and F5 supply the arc. The recruiter's first question sets the tone, so the arc should be rehearsed until it fits 90 seconds. |
| A2 | "What's drawing you to Ashgrove?" | JD | [generic] | Name one thing you have read in the material, such as the member-owned model or the values page, and say why it matters to you in your own words. Do not give a view on the brief you have not formed. | Motivation consistency. The question makes no claim about you. |
| A3 | "The role runs across branches and the contact centre, and it presents to senior leaders. Where's your experience on either?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." (your message) | Plain acknowledgment: "I haven't worked in a contact centre, and I haven't presented to anyone above regional level." Then one sentence of plan: how you would learn the contact-centre side first. Say no more on either. | F2 and F8 are gaps you stated. The recruiter is likely to ask early, so the plain words should be settled before round 2. |
| A4 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." (your message) | Name the two stated gaps in the words above, then the first thing you would do about each. Do not add a third. | Skeptic stem. Scores honest self-assessment. |
| A5 | "What are your salary expectations?" | JD | [generic] | Logistics slot: give the figure you are working to, or ask for the band first. Your material gives no figure, so this pack gives none. | Pay is yours alone to answer. |
| A6 | "What's your notice period?" | JD | [generic] | Logistics slot: give your actual notice period. | As A5. |
| A7 | "Where are you based, and what travel could you do across branches?" | JD | [grounded] "consolidate eight branches into five hubs over 2027" (strategy brief) | Logistics slot: say where you are based and what travel you can do, in your own words. If asked how you would make the journey, answer in your own words. | The brief's hub move makes travel a likely question. |
| A8 | "Why are you leaving your current role?" | EXP | [generic] | Logistics slot: give your own reason in your own words. Use the same reason every time you tell it. | Reason for leaving is a logistics slot; nothing here supplies one. |

---

## 7. Round 2: Head of Member Services (45 min, mostly behavioural)

**Reverse questions (5)**

| # | Question | Why it lands |
|---|---|---|
| R2-Q1 | "What does a good first 90 days look like in this role?" | Shows you are planning for the job, not the interview. |
| R2-Q2 | "How are complaint volumes and resolution times reviewed today, and who sees them?" | Gives you the reporting baseline. |
| R2-Q3 | "When a branch escalation goes wrong, what usually caused it?" | Gets to the real problem. |
| R2-Q4 | "Which hub moves first in the 2027 consolidation, and what happens to complaints in those towns?" | Strategy-linked; ties to Neighbours, Not Numbers. |
| R2-Q5 | "Where does the first digital self-service journey sit against this role?" | Ties to the 40 percent digital target. |

**Round 2 bank (11 questions)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time you kept hold of a problem until it was actually solved." | VAL (Own the Fix) | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." (your message) | Selection scaffold: pick a complaint pattern you found and stayed with until it stopped recurring. If the spreadsheet is that story, say what the problem was and how you kept hold of it. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it. | Own the Fix is the value your material is thinnest on. The spreadsheet is the nearest sentence, and it counts only if the fix was yours. |
| B2 | "Tell me about a time a member's side of a complaint changed what you did." | VAL (Members First) | [grounded] "I handled the branch's formal complaints log" (your message) | Open prompt: choose a complaint where the member's account changed the outcome. Map it to the log only if the log is where it happened. If not, say so, then describe how you would decide from the member's side. | Members First. Complaint logs are where member accounts come in. |
| B3 | "You've never worked in a contact centre. Why would we hire you to run complaints across one?" | JD | [grounded] "Never worked in a contact centre" (your message) | Hold: "I haven't worked in a contact centre." Then what you would do first: learn how contact-centre complaints are logged and routed before changing anything. The part you can speak to is the branch complaints log you handled. Hold through two follow-ups. Concede specifically that a contact centre is a different operation. | **Highest-ROI prep in this pack.** The JD names the contact centre, you stated the gap, and this is the objection the Head of Member Services is most likely to aim at. |
| B4 | "The role reports complaint trends to senior leaders. How would you start presenting to them?" | JD | [grounded] "I've never presented to anyone above regional level." (your message) | Plain acknowledgment: "I haven't presented to anyone above regional level." Then one plan: for example, rehearsing the first senior session with your regional manager. Say it as a plan, never as a past. | F8's gap, and the JD's senior-presenting line. |
| B5 | "Six years, the last three as a supervisor. How much of your branch's complaint outcomes was actually you?" | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." (your message); "I handled the branch's formal complaints log" (your message) | Hold: "I handled the branch's formal complaints log." Hold through two follow-ups by returning to the log. Concede that outcomes depended on others, if that is true for you. Never claim outcomes your records do not show. | Pressure stem; the attribution probe the coverage rules say to rehearse. |
| B6 | "Walk me through what the monthly spreadsheet counted, and which figure you'd defend least." | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." (your message) | Say what it counted, in your own words, then the figure whose assumption you would defend least. Answer slot: if it counted resolution times, say how they were counted; if not, say so plainly. | Data prober. This is the JD's monthly reporting and Excel requirement meeting your one number-bearing quote. |
| B7 | "The role owns the complaints process end to end, across branches and the contact centre. Which part of that have you owned?" | JD | [grounded] "I handled the branch's formal complaints log" (your message) | Keep to the quote. Answer slot: if any part of the process was yours to set, say which and how you decided; if not, say so and return to the log. | Inflated-form trap: end-to-end ownership is the JD's wording, not your material's. |
| B8 | "A branch supervisor keeps closing complaints as resolved before the member agrees. How would you coach them?" | CASE | [generic] | Structure: check the member's outcome first, then the escalation script, then coach by example and agree a check on closures. This makes no claim about your past. | The JD asks you to coach branch supervisors on escalations. The question is a pattern for that. |
| B9 | "Tell me about a self-service change you've shaped with a digital team." | JD | [grounded] JD line: "work with digital teams on self-service journeys" | Open prompt: if you have such a time, pick it. If not, say so plainly and describe how you would work with a digital team on a self-service journey. | F9: JD requirement with no quote. The honest branch covers it. |
| B10 | "The brief says 40% of member service moves to digital by 2028. What does that mean for complaints?" | CO | [grounded] "move 40% of member service to digital channels by 2028" (strategy brief) | Say what the complaints work would have to track: volumes by channel, where members get stuck, and what a self-service journey must do before a member can escalate. Frame it as your view, not Ashgrove's plan. | Strategy-linked. No claim about the candidate. |
| B11 | "The complaints log was formal. What made it formal in how it was run?" | EXP | [grounded] "I handled the branch's formal complaints log" (your message) | Answer slot: if the log followed specific rules or timescales, name them in your own words; if not, say so and say what you did to keep to the process. | The JD's regulated-complaints requirement. The quote says "formal", so the question asks what made it formal rather than presuming rules. |

---

## 8. Round 3: Panel of two branch managers (60 min, values-scored, with a 20-minute case)

**Persona weights:** Values / behavioural top (4); Case / strategist top (3); Peer evaluator mid (2); Data prober and Pressure low (1 each). The peer weight is an assumption: the branch managers would work beside this role. It is not confirmed.

### 8a. Values cheat sheet

The panel scores against the four values. None of your quoted sentences tells a finished values story, so each row gives a selection scaffold with its honest branch.

| Value (official name) | Working meaning (paraphrased) | Mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter. | Selection scaffold: a complaint where the member's account changed the decision. Nearest quoted sentence: "I handled the branch's formal complaints log" (your message). If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it. |
| Plain Words | If a member needs it explained twice, the explanation was wrong. | Selection scaffold: a time you explained a decision to a member and checked it landed. Nearest quoted sentence: "trained new tellers on our escalation script" (your message), which is staff, not members. Say which, and what you checked. If none, say so, then the nearest thing you carry. |
| Neighbours, Not Numbers | Every branch is part of its town. | No quoted sentence carries a story. Selection scaffold: a branch change you handled with its town in mind. If none, say so, then how you would handle a hub move for a town. |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved. | Selection scaffold: a fix you saw through that took longer than expected. Nearest quoted sentence: "I built the monthly complaints spreadsheet our regional manager uses" (your message). Claim it only if the fix was yours. If none, say so, then the nearest thing you carry. |

### 8b. Round 3 bank (11 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a complaint where the member's side pointed away from the policy." | VAL (Members First) | [grounded] "I handled the branch's formal complaints log" (your message) | Selection scaffold, per the cheat sheet. Say what the policy said, what the member said, and what you decided. If none comes to mind, say so, then give the nearest thing your material carries. | Members First. |
| C2 | "Tell me about a time you had to explain a decision to a member, and how you knew they understood it." | VAL (Plain Words) | [grounded] "trained new tellers on our escalation script" (your message) | Selection scaffold. The nearest thing is training tellers on the script, which is explaining to staff. Say which, and what you checked. If none, say so. | Plain Words. |
| C3 | "A branch in a town you know is moving into a hub. What do you do about the complaints from that town?" | VAL / CASE | [generic] | Structure: what the town's members lose, what you would tell them, which complaints stay open through the move, who checks. No claim about your past. | Neighbours, Not Numbers, tied to the eight-to-five hub consolidation. |
| C4 | "What's a fix you saw through that took longer than you expected?" | VAL (Own the Fix) | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." (your message) | Selection scaffold. Claim the fix only if it was yours. If none, say so, then the nearest thing you carry. | Own the Fix. Different wording from B1 so you rehearse it twice. |
| C5 | Case A (see 8c): "A member's fee complaint was closed as resolved. Two weeks later it is open again." | CASE | [generic] | 20-minute structure: 2 minutes to clarify (what the member needs, what the records show), 5 minutes to triage (what went wrong and where), 8 minutes to act (who owns the fix and by when), 5 minutes on what to change so it does not recur. | The 20-minute case is the panel's main test. |
| C6 | Case B (see 8c): "The digital team wants the app to take complaints. Supervisors in two towns say members will not use it." | CASE / CO | [grounded] "move 40% of member service to digital channels by 2028" and "the main competitive pressure is app-only banks" (strategy brief) | Structure: what the app must do for complaints, where members fall out, keep an assisted route for those who cannot use it, measure drop-off. Say what you would need to know first. | Strategy-linked case under the brief's own framing. |
| C7 | "What would you measure in the first month of escalations, and which number would you trust least?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." (your message) | Name the measure you would start with and the assumption you would trust least. If you cannot yet say how resolution time would be counted here, say so. | Data prober; the weakest-assumption move. |
| C8 | "Our teams sit side by side. Where's the seam between branches and the contact centre, and what happens when you disagree?" | JD | [grounded] "across branches and the contact centre" (JD) | Propose seam principles, not facts about their seam: who owns the complaint record at each handoff, and how you would settle a disagreement with a branch manager. Your material has no sentence on disagreeing with a peer. If asked for a time, say so plainly and describe how you would handle it. | Peer evaluator. Honest branch. |
| C9 | "Describe how you'd coach a branch supervisor after an escalation went badly." | JD | [grounded] "trained new tellers on our escalation script" (your message) | Selection scaffold. The nearest thing is training tellers on the script. Say what changes when the learner is a supervisor, and how you would check the coaching worked. Do not call training tellers coaching supervisors. | JD requirement: coach branch supervisors. Honest. |
| C10 | "How do you handle credit when a complaint fix spans branches and the contact centre?" | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." (your message) | Credit: say that the regional manager uses the sheet and that what they do with it is theirs. Do not claim anything you did not do. | Peer credit-sharing probe. |
| C11 | "Sixty seconds: why should we hire someone with no contact-centre experience?" | JD | [grounded] "Never worked in a contact centre" (your message); "6 years in retail banking, the last 3 as a branch supervisor." (your message) | Hold: restate the question, then answer with the six years and the complaints log in quoted terms. Concede the contact-centre gap in plain words. Hold through two follow-ups. Never claim contact-centre experience. | Pressure; hold-then-concede. |

### 8c. Case scenarios (drill-ready)

These are practice cases, not facts about Ashgrove. Labelled `[generic]`.

- **Case A (C5): escalation.** A member's complaint about a wrongly charged fee was closed as resolved after a phone call. Two weeks later they write again: the contact centre says the complaint is still open, and the fee has not been refunded. You have 20 minutes. What do you do?
- **Case B (C6): digital.** The digital team wants the app to take complaints from next year. Supervisors in two towns say members there rely on the counter and will not use the app. The brief names app-only banks as the main pressure. What do you recommend, and what do you need to know first?
- **Case C (C7): data.** Monthly complaint volumes are flat, but resolution times have risen at one branch for two months. The regional manager wants one reason. What do you do?

### 8d. Reverse questions for round 3 (5, including one reciprocity question)

| # | Question | Why it lands |
|---|---|---|
| R3-Q1 | "What could a new person do in their first month that would genuinely help your team?" | **Reciprocity** (peer panel): frames your help as theirs. |
| R3-Q2 | "When the branches and the contact centre disagree about a complaint's outcome, who decides?" | Tests the ownership seam before you have to. |
| R3-Q3 | "How do the two branches' complaint volumes differ, and what is the reason?" | Shows you can read a monthly report. |
| R3-Q4 | "Which hub comes first in the 2027 consolidation, and what do you expect complaints to do during the move?" | Strategy-linked; the panel will know the answer. |
| R3-Q5 | "How do you judge whether the four values have been met in a complaint?" | Shows you have listened to the values round. |

---

## 9. Sources and target accounting

**Provided documents (the research module ran no searches):**
1. The job description, pasted by you.
2. Ashgrove's values, copied from ashgrovecu.org/about/values on 26 November 2026 and pasted by you.
3. The recruiter's process email (three rounds, 5 December 2026).
4. The 2026 strategy brief (July 2026), sent to you by the recruiter.
5. Your message: your background, including the four sentences quoted in the fit snapshot.

Dossier consumed: none.

**Research tier:** L1, searches 0 of 6, fetches 0 of 2. The pasted inputs already supply every output the targets would have fed, so no search was sent.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. ashgrove values | skipped | The pasted values page fixes the cheat sheet's inputs. |
| 2. Ashgrove interview process | skipped | The recruiter's email fixes the three rounds and their focus. |
| 3. Ashgrove strategy / recent news | skipped | The brief you were sent supplies the current priorities. Recent news was not searched. |
| 4. Interviewer name | n/a | No names given, so there was no query to form. |
| 5. Representative JD | skipped | The JD you supplied fixes the fit snapshot. |

---

## 10. Upgrade menu

- **Names of the Head of Member Services and the two branch managers** → an interviewer read, persona weights per named member, and reverse questions tailored to their career paths.
- **An anonymised copy of the monthly complaints spreadsheet (no member data)** → F3 and F4 move from medium and low toward a higher band, because an inspectable artifact is the proof that raises them. It also gives B6 and C7 something real to test.
- **Your complaints log's rules or timescales, if any, in your own words** → F6 and B11 can be answered from your material rather than from a slot.
- **Whether the 5 December case is sent in advance or given on the day** (your recruiter can say) → the case rounds are reweighted: pre-read changes the prep for C5 to C7.
- **Prep time before 5 December** → a prioritised prep schedule.
- **Your CV** → F1 to F9 are built from your message; a CV would let each row quote more of your history.
- **`tuesday-dossier.md`** → carries verified evidence and gaps into later sessions.
