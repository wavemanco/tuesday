# Operations Manager, Atlas Freight: interview prep pack

Session mode. Built for a hiring-manager round (assumed; the round and your relationship to the interviewer are not yet known). Research: web search was refused in this session, so no company material is in the pack.

## How to use

- **Personas** describe how a question is asked (the delivery). **Types** describe what is being scored.
- **Type key:** JD = a stated responsibility or qualification, tested directly. EXP = your own past work, checked for attribution. CASE = a live problem from the role, scored on structure and reasoning.
- Guidance is scaffolding, not a script. Say it in your own words, and only about work you did.

## Fit snapshot

Requirements are quoted from the JD. Your evidence is quoted from your message, verbatim.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" (JD) | "7 years in warehouse and distribution ops" (your message); "currently a senior shift manager over 3 supervisors" (your message) | medium | [grounded] | transferability | Your material shows one site's shift work, not four sites. Bridge: "I'm a senior shift manager over 3 supervisors." Answer slot: if you have had a say in how work ran across more than one site or shift, say how; if not, say so, and say how you would set the daily rhythm across four sites. |
| F2 | "drive on-time performance and cost-per-shipment down" (JD) | "cut mis-pick rate 40% by redesigning the pick path" (your message) | medium | [grounded] | transferability | Accuracy, not on-time or cost. Say the mis-pick result at its own scope. Answer slot: if you tracked on-time or cost on that site, say what and what it showed; if not, say so. |
| F3 | "lead a team of 12 supervisors" (JD) | "currently a senior shift manager over 3 supervisors" (your message) | medium | [grounded] | transferability | Three, not twelve. Bridge: "over 3 supervisors," at that scale. Answer slot: if you have led supervisors across more than one shift or site, say how many and how you ran them; if not, say so. |
| F4 | "5+ years operations leadership required" (JD) | "7 years in warehouse and distribution ops" (your message) | medium | [grounded] | discovery | Seven years of operations is in your material; how many of them were leadership is not. Bridge: "I have 7 years in warehouse and distribution ops." Answer slot: which of those years you led people, and for how long. |
| F5 | "build reporting in Excel/Power BI" (JD) | "solid Excel" (your message) | medium | [grounded] | discovery | Excel is covered; reporting built in it is not shown. Bridge: "I'm solid in Excel." Answer slot: if you have built reporting in Excel, say what it tracked and who used it; if not, say so. |
| F6 | "build reporting in Excel/Power BI" (JD) | "never used Power BI" (your message) | none | [grounded] | capability | A gap you stated. Plain acknowledgment: "I haven't used Power BI." Then how you would learn it, as a plan, never as a past. |
| F7 | "Lean/Six Sigma a plus" (JD) | "green belt certified" (your message) | medium | [grounded] | none | Reaches the plus directly. Bridge: "I'm Green Belt certified." The certificate is not inspected here, so expect a probe. |

No gate rows: the JD states no licence, location or schedule term.

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Ran terminal operations across four sites | Inflated form of F1 | "I'm a senior shift manager over 3 supervisors." The limit is this pack's observation: your material shows one site's shift, not four sites. A1 and B1 slots stay inside that. |
| Led 12 supervisors | Inflated form of F3 | "over 3 supervisors" |
| Drove on-time performance or cost-per-shipment down | Inflated form of F2 | The mis-pick result, at its own scope, with the C2 slot |
| Seven years of operations leadership | Inflated form of F4 | "7 years in warehouse and distribution ops," with the F4 slot |
| Designed or led the pick-path redesign on your own | Inflated form of "redesigning the pick path" | Your words: "cut mis-pick rate 40% by redesigning the pick path." Whose decision it was goes in the C1 slot. |
| Built Power BI reporting, or know Power BI | Negative you stated, F6 | "I haven't used Power BI." No slot. |
| Lean Six Sigma practitioner beyond the Green Belt | Inflated form of F7 | "Green Belt certified" |

## Question banks

Persona weights (see the table below) set the depth: Case 5, Skeptic 4, Prober 3, Pressure 2, Conversational 2, Peer 2.

### A. Case / Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "How would you run daily operations across four sites in your first 30 days?" | CASE | [grounded] "Own daily terminal operations across 4 sites" | Clarify first: site sizes, volumes, current on-time figures, staffing. Then structure: one daily huddle, one KPI set per site, a cost-per-shipment baseline, an escalation path. No claim about your past. Answer slot from F1: if you have run work across more than one site, say how; if not, say so. | The JD's headline requirement, asked as a live problem. |
| A2 | "On-time performance dropped at one of your sites last month. Walk me through the diagnosis." | CASE | [generic] | Structure: define on-time, split by lane, shift and carrier, check whether the drop is in one step or across all. Name what you would check first. | Tests the on-time responsibility in the JD without assuming a past event. |
| A3 | "Cost per shipment is up 8% year on year. Where do you look first?" | CASE | [generic] | Split cost per shipment into labour, space, transport and rework; check volume mix before efficiency. Ask for the baseline. | Tests the cost-per-shipment half of the JD. The 8% is a hypothetical, not a fact about the company. |
| A4 | "You lead a team of 12 supervisors and three peak weeks are coming. How do you decide where labour goes?" | JD | [grounded] "lead a team of 12 supervisors" (JD); "ran the site's peak-season surge plan two years running" (your message) | Story-mapped on your surge plan: the plan you ran, twice. Beats: the plan, the two seasons. Answer slot: which decisions in that plan were yours to make, and how you made them; if the labour allocation was not yours, say so and describe how you would decide it. | F3's gap, and your strongest material for it. |
| A5 | "Lean is a plus for this role. How would you use it to bring cost per shipment down?" | CASE | [grounded] "green belt certified" (your message) | Name one Lean tool you have used and what it changed, in your words. Answer slot: if you have run a Green Belt project, say what it was; if you have not, say what you would map first. | F7's bridge, rehearsed as a method question. |

### B. Skeptic (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Your experience is one site and three supervisors. What makes you ready for four sites and twelve?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" (your message); "lead a team of 12 supervisors" (JD) | **Highest-ROI prep in this pack.** This objection is likely in some form. Hold: name the scale you actually ran, and the two peak plans and the pick-path result, all as they happened. Concede the scale plainly ("three supervisors, one site, I haven't run twelve or four"). Hold through two follow-ups by returning to what you ran, not by adding to it. Answer slot: if you have led across more than one shift or site, say how; if not, say so, and say what you would do in the first 90 days. | F1 and F3 together: the biggest gap, and the place where a rehearsed answer changes the interview. |
| B2 | "You've never used Power BI. Why should we believe you can build our reporting?" | JD | [grounded] "never used Power BI" (your message); "solid Excel" (your message) | Plain acknowledgment: "I haven't used Power BI." Then Excel, in your own words, and the way you would learn Power BI as a plan. Answer slot: if you have built Excel reporting, say what it tracked and who used it; if not, say so. | F6, and F5's slot. |
| B3 | "The JD asks for five years of operations leadership. How do you count yours?" | JD | [grounded] "5+ years operations leadership required" (JD); "7 years in warehouse and distribution ops" (your message); "currently a senior shift manager over 3 supervisors" (your message) | Count what the quotes carry: seven years in operations, and the leadership years you can name. Answer slot: how many of the seven years you led people, and for how long. | F4. Asked in the open, so you answer for yourself. |
| B4 | "What is pulling you out of shift management and into this role?" | EXP | [generic] | Give your own reason, in your own words, and tie it to the role's scope, not to a complaint. Not in the material; the answer is yours to give. | Motivation is a standard Skeptic probe; the material does not supply the reason. |

### C. Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You cut mis-pick rate 40%. How was that counted, and which assumption behind it would you defend least?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Name how mis-picks were counted, in your words; name the assumption you would defend least; say which part of the redesign was yours. Answer slot: if you cannot say how it was counted, say so plainly. | Defend-the-number slot on your headline metric. No baseline or method is supplied here. |
| C2 | "Mis-pick rate is not on-time or cost per shipment. What did you track on those, and what did it show?" | JD | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message); "drive on-time performance and cost-per-shipment down" (JD) | Say the mis-pick result at its own scope, then what you tracked on the two JD metrics. Answer slot: if you tracked either, say what it showed; if not, say so. | F2. The probe is designed to catch a stretched metric. |
| C3 | "What do you measure in Excel today, and how often?" | JD | [grounded] "solid Excel" (your message) | Name the sheets or measures you actually use, and their cadence. Answer slot: if you have built a report another person used, say what it was; if not, say so. | F5, asked as a probe on Excel depth. |

### D. Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why should we hire you over someone who has run four sites?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" (your message) | Pause, restate the question, then hold: the scale you ran, the surge plan, the mis-pick result. Concede one thing specifically: the number of sites. Do not fold on the seven years. | The pressure version of B1. |
| D2 | "That mis-pick result: how much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Hold the redesign as yours to the extent your words say it. Concede team effort specifically if there was some. Answer slot: if the redesign was your decision, say what you decided; if it was a team's or someone else's, say so. | Hold-then-concede on the claim the interviewer will try to dilute. |

### E. Conversational / Rapport Builder (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through your path to here." | JD | [grounded] "7 years in warehouse and distribution ops" (your message); "currently a senior shift manager over 3 supervisors" (your message) | A 90-second arc: where you started, what you ran, where you are now, in the order your quotes give. | Casual openers are scored. |
| E2 | "What did your Green Belt work teach you?" | JD | [grounded] "green belt certified" (your message) | Name what the Green Belt covered and one thing you changed in your own work. Answer slot: if you have a Green Belt project, say what it was; if not, say so. | F7's plus, in a casual register. |

### Peer (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Our site leads sit beside you. Where is the seam between your team and theirs, and what happens when you disagree?" | JD | [generic] | Propose seam principles, not a seam you have not seen. Give one disagreement you handled, if you have one; otherwise say how you would raise it. | Peer probes return in collegial form. |
| P2 | "How do you handle credit when work spans two teams?" | EXP | [generic] | Name who did what, in your own words, and say how you would share credit without claiming others' work. | Standard peer probe; no claim about your past. |

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Weight | Counter-strategy |
|---|---|---|---|---|
| Case / Strategist | Live problems on the four-site operation | High: a hiring manager for an ops leader buys capability and tests it on the real problem | 5 | Clarify, structure, then answer. Say the framework aloud. |
| Skeptic | The one-site, three-supervisor gap; the Power BI gap | High: the gap is in the material, so it is the likeliest probe | 4 | Rehearse B1 until it is plain. Acknowledge the gap; bridge only from what you stated. |
| Data-Driven Prober | Mis-pick number, on-time and cost metrics | Medium: a metric-heavy JD invites it | 3 | Name the weakest assumption before it is named for you. Say plainly what you do not know. |
| Pressure | Sixty-second challenges; "how much was you" | Medium: common for senior roles | 2 | Pause. Hold through two follow-ups, then concede one specific thing. |
| Conversational | Casual "walk me through" openers | Medium: most interviews open this way | 2 | A 90-second arc. Treat casual questions as scored. |
| Peer | Seam and credit probes | Low-to-medium: depends on the round | 2 | Reciprocity framing. Propose seam principles. |

Weights are the hiring-manager prior, since the round is not confirmed. If the round is with a peer or a recruiter, the weights change.

## Requirement coverage

| JD requirement | Questions | Notes |
|---|---|---|
| Own daily terminal operations across 4 sites | A1, B1, D1 | |
| Drive on-time performance down | A2, C2 | |
| Drive cost-per-shipment down | A3, C2 | |
| Lead a team of 12 supervisors | A4, B1 | |
| Build reporting in Excel/Power BI | B2, C3 | |
| 5+ years operations leadership | B3 | |
| Lean/Six Sigma a plus | A5, E2 | |

## Reverse questions

1. "What does on-time performance look like at each of the four sites right now, and which one is furthest from target?" Why it lands: shows you think in the metric the JD leads with.
2. "What reporting do the site leads use day to day, and what would they change about it?" Why it lands: surfaces whether the reporting need is new or an upgrade.
3. "What would a strong first 90 days look like for this role?" Why it lands: sets the bar in their words, so you can aim at it.
4. "What did the last person in this role do well, and what would you have them do differently?" Why it lands: shows how they manage and what they value.
5. "What is the biggest operational risk across the four sites this peak season?" Why it lands: asks for the real problem, and shows you plan around peak.

## Sources

- Provided documents: the JD text and your background, as given in your message.
- Research tier: L1 — searches 0 of 6 (3 attempted, all refused), fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Atlas Freight values | unavailable | Values cheat sheet, section 10. Not included: the search was refused, and no values are in hand. |
| 2. Atlas Freight operations manager interview process | unavailable | Loop structure and persona weights. Not included: refused. |
| 3. Atlas Freight strategy / recent news | unavailable | CO bank. Not included: refused. |
| 4. Interviewer name | n/a | No name given. |
| 5. Representative JD | skipped | The JD you supplied fixes the fit snapshot and the JD questions. |

Searches sent: "Atlas Freight regional logistics company values" (refused); "Atlas Freight operations manager interview process" (refused); "Atlas Freight logistics strategy recent news" (refused).

## Upgrade menu

- The round type and your relationship to the interviewer → persona weights and the reverse questions reweighted (peer and recruiter weights differ from the hiring-manager prior used here)
- Company values, once you can paste them → a values cheat sheet mapping each value to your story (F1, F2 and F3 carry the stories you have)
- Atlas Freight's current strategy or recent news, pasted → a grounded section on the four-site plan and a CO question
- The interviewer's name → a tailored reverse question, and persona weights read from their public footprint
- Your Power BI learning plan, if you have one → B2 and F6 can state a concrete plan instead of a bare acknowledgment
- Any reporting you have built in Excel, with what it tracked → F5 and C3 can be rehearsed against real material
- The Green Belt certificate or project summary → F7 and E2 can name the project in your own words
