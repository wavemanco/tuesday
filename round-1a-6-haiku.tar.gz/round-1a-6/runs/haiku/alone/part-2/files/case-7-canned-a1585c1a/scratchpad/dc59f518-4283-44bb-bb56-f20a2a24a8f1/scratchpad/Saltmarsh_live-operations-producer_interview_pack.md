# Live Operations Producer, Saltmarsh Games: interview prep for Femi

Interviewer: Tobias Wrenfield, Head of Live Operations. Relationship not stated; this pack assumes a hiring-manager-level round. Format: 60 minutes, Friday.
Research tier: L0 (your message only). No public-footprint research on the interviewer or company was run.

## How to use this pack

- **Personas** describe how the question is asked. **Types** describe what is being scored.
- Type key: **Experience** (what you did), **Behavioral** (a past example you pick), **Situational** (what you would do), **Analytical** (how you read numbers), **Pressure** (a probe on a gap).
- Guidance is scaffolding, not a script. Every line about your past comes from a sentence you wrote, or is marked as a slot for you to fill in.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years producing live-service games or apps" (JD) | "4 years as an associate producer at a puzzle-game studio" (your message) | medium | [grounded] | hard_gate | Your material shows four years, but does not establish that the puzzle title was live-service. Step 1 question (d) asks this. Do not bridge it until answered. |
| F2 | "experience running a content calendar" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | high | [grounded] | none | No gap. Lead with the quote's own terms: weekly, two years, one title. |
| F3 | "comfortable with player-retention metrics" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | medium | [grounded] | presentation | Your material says you presented the numbers. It does not show that you chose the metrics. Words: "I presented the monthly retention numbers to the studio head." Add no figures. Answer slot: if you chose what to measure or what the numbers meant, say which; if not, say you presented them. |
| F4 | "clear written communication" (JD) | "Wrote the release checklist our QA team still uses." (your message) | medium | [grounded] | presentation | The quote is a written artifact in use, which reaches the requirement by proxy. Words: "I wrote the release checklist our QA team still uses." Do not claim a writing style you have not described. |
| F5 | "manage the release checklist with QA" (JD) | "Wrote the release checklist our QA team still uses." (your message) | medium | [grounded] | transferability | The quote covers writing the checklist, not managing it with QA. Words: "I wrote the release checklist our QA team still uses." Answer slot: how you kept it current with QA. |
| F6 | "Plan and run the live-events calendar for two of our mobile titles" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | transferability | One title, not two. Content drops, not live events as the JD uses the term. Answer slot: how you would plan a second title. |
| F7 | "coordinate design, art, engineering and community teams on each update" (JD) | none given | none | [grounded] | discovery | Your material does not show this. Answer slot: describe a time you coordinated two or more of these teams on one update. If none, say so and say how you would set it up. |
| F8 | "own the post-event review and the KPIs it reports" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | low | [inferred] | discovery | The quote touches KPIs but does not show whether you owned the review or the KPI choice. Answer slot: if you chose which KPIs were reported, say so; if not, say what you presented. |

Gap types: `hard_gate` = a gate the material does not show met; `presentation` = the quote reaches the requirement in other terms; `transferability` = adjacent work that does not reach the requirement; `discovery` = the evidence may exist and the material does not show it; `none` = a quote already reaches the requirement.

## Prohibited claims

These are claims this pack will not coach. Each one would overstate your material.

| Claim not to make | Basis | Honest form |
|---|---|---|
| Experience with in-app purchases or monetisation | "never worked on a game with in-app purchases" (your message) | "I haven't worked on a game with in-app purchases." Then how you would learn it. |
| Leading or managing a team | "Never led a team" (your message) | "I haven't led a team." |
| Owning a live calendar for two titles | One title in your material: "I ran the weekly content-drop calendar for our main title" | "I ran one title's calendar." |
| Owning post-event reviews or KPI targets | Not in your material | Answer slot (F8). |
| The puzzle title was live-service | Not established (F1) | Say what the title was, in your words. |
| Retention figures or improvements | No figures given | "I presented the monthly numbers." No figures unless you bring them. |

## Persona table

Weights assume a hiring-manager round, because the interviewer is a Head of function. Change them if the round is a peer or skip-level.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy (a rehearsal method) |
|---|---|---|---|
| The Skeptic (weight 5) | Probes the gaps: one title, the word "ran", in-app purchases, team leadership | High. The JD asks for two titles and live-service; your material shows one title, no in-app purchases and no team. | Hold-then-concede: say the gap in one sentence, then the nearest thing you did. Practise A1 and A2 aloud. |
| The Operator (weight 4) | Walks through the calendar, the checklist and a failed drop | High. The calendar and the checklist are concrete and the JD is process-heavy. | Structure each answer as decision, reason, result, and what you'd change. Practise B1 and B3. |
| The Analyst (weight 3) | Asks for the metrics and what you did with them | Medium-high. Retention and post-event KPIs are explicit in the JD; your material shows presenting, not owning. | Name the metric, the cadence and the conclusion. Do not add figures. Practise C1 and C4. |
| The Partner (weight 3) | Asks about coordinating four teams and holding a deadline | Medium. The JD lists four teams; your material shows none of them. | Use the selection scaffold: pick a real time two teams disagreed. Practise D1 and D2. |

## Question banks

Type tags: Experience, Behavioral, Situational, Analytical, Pressure. Provenance comes first in each row.

### The Skeptic (weight 5)

| ID | Type | Question | Provenance | Guidance | Rationale |
|---|---|---|---|---|---|
| A1 | Situational | "You ran one title's calendar. This role covers two. What would you change for the second?" | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Open with the one-title fact in your own words. Name what you would carry over from that calendar and what you would rebuild, picking the two you can describe. Then say what you would need to learn about the second title: its players, its update rhythm, its team. Plan, don't claim. | The JD's "two of our mobile titles" is the widest gap on the page. A Skeptic goes straight to scale. |
| A2 | Pressure | "You say you ran the calendar. Did you decide what went in it, or run a schedule someone else set?" | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Answer with the split, item by item: which you chose, which you were given, which you negotiated. If you did not set the content, say so plainly, then describe the part that was yours. Do not upgrade "ran" to "owned" in the room. | Highest-ROI prep in this pack. "Ran" is the word the JD will be read against, and this is the most likely objection. A precise answer beats a bigger one. |
| A3 | Pressure | "Have you worked on a game with in-app purchases?" | [grounded] "never worked on a game with in-app purchases" (your message) | "No, I haven't." Then name how you would learn the monetisation side: what you would read, and which numbers you would ask for first. | Not in the JD, but a live-events role at a mobile studio will likely test it. Answer before it is asked. |
| A4 | Pressure | "You've never led a team. Why would we trust you to coordinate four disciplines?" | [grounded] "Never led a team" (your message) | Say you haven't led a team. Then describe the coordination you have done, using only quoted work: the release checklist you wrote that QA still uses. Name what you would do first in a coordinating role. | The JD asks for coordination, not management. The gap is real and you stated it. |
| A5 | Pressure | "Why should we believe a four-year associate producer can own two live titles?" | [grounded] "4 years as an associate producer at a puzzle-game studio." (your message) | Answer with the four years and what they contained, in order, then your plan for the first 90 days. Let the sequence carry the case; do not argue for yourself. | Tests composure on seniority. The title level is a fact; the answer is what you did with it. |

### The Operator (weight 4)

| ID | Type | Question | Provenance | Guidance | Rationale |
|---|---|---|---|---|---|
| B1 | Behavioral | "Walk me through the content-drop calendar you ran. How did you decide what went in each week?" | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Structure: what the calendar had to satisfy, the inputs you weighed, one week's decision in detail, and what you would change. Keep to decisions you made. | The most concrete thing on your CV. Operators ask for the mechanism. |
| B2 | Behavioral | "Tell me about a content drop that slipped. What happened, and what did you do?" | [generic] Selection scaffold: no quoted sentence carries a slip. "Pick a drop that moved, missed or shipped late, and say what your part was." | Describe the cause, your decision, and the fix. If no drop slipped on your watch, say so, then say how you would handle one. | The material has no slip. Choose a real one; do not invent it. |
| B3 | Experience | "Walk me through the release checklist you wrote. What's on it, and how did you know it worked?" | [grounded] "Wrote the release checklist our QA team still uses." (your message) | Describe the checklist's structure. Then the proof: QA still uses it is evidence of adoption. If you added an item after a miss, say so; if not, say how you would tell whether it works. | Strong, specific evidence. "Still uses" is the proof point, so use it. |
| B4 | Situational | "A live event goes out with a bug on day one. Walk me through the next 24 hours." | [generic] Selection scaffold: no quoted sentence carries an incident. | Order the steps: contain, communicate, fix, review. Name who you would call and in what order. | The role owns the release checklist with QA, so incident response is the test. |
| B5 | Situational | "How do you run a post-event review so it changes the next event?" | [generic] | Give a method: the question the review answers, the data it needs, who reads it, and how a finding becomes a change with an owner. | The JD says "own the post-event review". Your material shows no review you ran, so answer as a method. |

### The Analyst (weight 3)

| ID | Type | Question | Provenance | Guidance | Rationale |
|---|---|---|---|---|---|
| C1 | Analytical | "What retention numbers did you present, and what did you conclude from them?" | [grounded] "Presented the monthly retention numbers to the studio head." (your message) | Name the metric definition, the cadence and the one conclusion or recommendation you took from it. Give a figure only if you have it to hand; if not, say it is not in your head. | Retention is in the JD. The question asks for the step after presenting. |
| C2 | Analytical | "Retention drops three points in the week after an event. What do you check first?" | [generic] | Order your checks: the cohort and metric definition first, then what the event changed, then outside factors. Say what would make you roll back. | A method test. Generic, so answer with a sequence. |
| C3 | Analytical | "Which KPIs would you report for a live event, and how would you tell a good event from a lucky one?" | [generic] | Name three KPIs with a reason for each, then one comparison you would use, such as a holdout or a prior-cohort baseline. | Maps to "own the KPIs it reports". Answer as a method. |
| C4 | Behavioral | "Show us how you'd write a one-page post-event summary for a head of studio." | [grounded] "Wrote the release checklist our QA team still uses." (your message) | Lead with the decision the summary asks for, then two or three numbers, then what happens next. Keep it to one page. | "Clear written communication" is a requirement; this is the live test. |

### The Partner (weight 3)

| ID | Type | Question | Provenance | Guidance | Rationale |
|---|---|---|---|---|---|
| D1 | Situational | "Design wants a new mechanic, art has no capacity, and community is already promising it. How do you run that update?" | [generic] Selection scaffold: "Pick a time two teams disagreed on a timeline." | Name the decision owner, the constraint, and the sequencing trade-off. Say how you would tell each team what changed and why. | The JD lists four teams; your material shows none of them. |
| D2 | Behavioral | "Tell me about a time you pushed back on a deadline from another team." | [generic] Selection scaffold: no quoted sentence carries it. | Describe the deadline, your pushback, the outcome, and what you would do the same way. If none happened, say so, then say how you would push back. | Tests judgment under pressure with a real example. |
| D3 | Situational | "A hotfix lands the morning of a live event. How do you handle the release checklist with QA?" | [grounded] "Wrote the release checklist our QA team still uses." (your message) | Say what the checklist gives you on a day like this and what it doesn't. Then how you would make the call with QA, and who signs off. | Connects your strongest artifact to a requirement the JD names. |
| D4 | Behavioral | "What did you do when a partner team ignored the schedule?" | [generic] Selection scaffold: no quoted sentence carries it. | Describe the signal you noticed, who you told first, and the change you made. | Tests follow-through with teams you do not manage. |

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| 3+ years producing live-service games or apps | F1 (Step 1 question d); A5 |
| Experience running a content calendar | A1, A2, B1 |
| Comfortable with player-retention metrics | C1, C2, C3 |
| Clear written communication | C4, B3 |
| Plan and run the live-events calendar for two titles | A1, A2, B2 |
| Coordinate design, art, engineering and community | D1, D2, D4 |
| Own the post-event review and the KPIs it reports | B5, C3 |
| Manage the release checklist with QA | B3, D3 |

## Reverse questions

Interviewer profile not researched, so these are role-generic.

1. "What does a good first 90 days look like for this role?" Why it lands: shows you are planning the job, not just interviewing for it.
2. "Which two titles are in scope, and how far apart are their update cadences?" Why it lands: tests whether the JD is as concrete as it reads, and shows you think in calendars.
3. "How are post-event reviews shared today, and who reads them?" Why it lands: reveals whether the review changes decisions, the thing the JD asks you to own.
4. "Which KPI do you trust most for a live event, and which do you distrust?" Why it lands: an honest answer tells you how the team argues about numbers.
5. "When design and community disagree on an update, where is the decision made?" Why it lands: shows how you would work inside the four-team coordination the role requires.
6. "How does the release checklist change when QA finds something new?" Why it lands: connects to the checklist, which is your strongest concrete evidence.

## Sources

- Provided documents: your message (the JD text and your background).
- Research: none run. Tier L0. Interviewer public footprint: skipped (not consented). Company strategy: skipped. Representative JD: n/a (JD supplied).
- Persona weights and type tags are this pack's own; they are not drawn from a source.

## Upgrade menu

- The interviewer's relationship to you (future manager, peer, skip-level) → persona weights and reverse questions set for that round.
- Tobias Wrenfield's public footprint (with your consent) → a tailored reverse question and interviewer read.
- The puzzle title's live-service status → F1 becomes a grounded row, and A5 can be answered directly.
- Any figures you presented → C1 gets a number you can say.
- A tuesday-dossier.md would record the gaps this prep exposed for later sessions.
