# Larkfield Systems: Engineering Manager, three-round prep pack

**Role:** Engineering Manager, Larkfield Systems (industrial IoT, about 600 people). Lead two squads building device-management services; own delivery, hiring and growth for 11 engineers; partner with hardware and product on the roadmap.

**Rounds:** Tuesday, hiring manager (Director of Engineering, 45 min). Thursday, panel (two staff engineers and a product manager, 60 min). Following Monday, VP Engineering (30 min, which the recruiter described as "values and leadership philosophy").

**Shape:** Loop pack. One shared fit snapshot, then a mini-pack per round with its own persona weights, question bank and reverse questions. No interviewer names were given, so there is no interviewer read; personas fall back to round-type priors.

## How to use this pack

- **Personas** describe how a question is asked: the register, the pace, the follow-ups.
- **Types** describe what is being scored: VAL (behavioral and values alignment), EXP (work-experience deep-dive), JD (role-driven), CO (company and strategy), CASE (live problem).
- **Guidance is scaffolding, not a script.** Aim for 90 to 120 seconds spoken.
- **Answer slots** are instructions for the interview, not questions. Where your material does not show a practice, the guidance gives both honest branches: say how it was yours, or say plainly it was not.
- **Provenance:** `[grounded]` traces to your message or a supplied requirement; `[inferred]` is a derivation from your material; `[generic]` is a role-family pattern with no claim about you or Larkfield.

## Fit snapshot

Shared across all three rounds. Requirements are quoted from the role summary in your message. Your evidence is quoted from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" (role summary) | "9 years engineering, 3 as a team lead of 6" (your message) | medium | [grounded] | transferability | Your material reaches one team of six for three years, not two squads or device management. Words: "For three years I was team lead of six." Answer slot: if you have led across more than one team, say how; if not, say so and say how you would run two. |
| F2 | "Lead two squads building device-management services" (role summary) | none given | none | [grounded] | discovery | Your material is silent on device, embedded or connected-systems work, so no bridge should be stretched. Answer slot: if you have built or run anything involving connected devices, say what and your part in it; if not, say so and say how you would learn the device-management domain. |
| F3 | "own delivery, hiring and growth for 11 engineers" (role summary) | "I run our hiring loop for backend roles" (your message), "about 40 interviews last year" (your message) | medium | [grounded] | none | Hiring is reached in your own scope: backend roles, about 40 interviews last year. The word "our" stays: which parts of the loop were yours to set is asked in the banks. |
| F4 | "own delivery, hiring and growth for 11 engineers" (role summary) | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" (your message) | medium | [grounded] | presentation | Delivery is reached in other terms: a reliability quarter you pushed through, with on-call burden down 60%. Reword only the quote: "After I pushed a reliability quarter through against roadmap pressure, my team's on-call burden dropped 60%." The 60% is a headline figure; see A8 and B1. |
| F5 | "own delivery, hiring and growth for 11 engineers" (role summary) | none given | none | [grounded] | discovery | Growth of engineers is not in your material. Answer slot: name one engineer whose growth you shaped, what you did, and what changed, in your own words; if you cannot name one, say so and say how you would start. |
| F6 | Managing managers (not in the role summary; a role-family requirement, `[generic]`) | "I've never managed managers" (your message) | none | [grounded] | capability | The plain acknowledgment you stated: "I haven't managed managers." Then how you would learn it, said as a plan and never as a past: what you would do first if you were leading leaders. |
| F7 | "partner with hardware and product on roadmap" (role summary) | "pushed a reliability quarter through against roadmap pressure" (your message) | low | [inferred] | transferability | Your material shows you held a roadmap line against pressure, not a partnership with product or hardware on the roadmap. Bridge at that scope: "I pushed a reliability quarter through against roadmap pressure." Answer slot: describe one roadmap decision you made jointly with product; if none, say so. |
| F8 | "partner with hardware and product on roadmap" (role summary) | "never owned a hardware-adjacent roadmap" (your message) | none | [grounded] | capability | The plain acknowledgment you stated: "I've never owned a hardware-adjacent roadmap." Then how you would learn hardware constraints, as a plan: who you would ask first and what you would ask them to show you. |

**Read this before the banks.** Your message does not mention device or IoT experience, so F2 is recorded as silence (discovery), not as a gap you stated. If it is a gap, say so and the row becomes a capability row; if you have related work, add it and the row is re-graded.

**Requirement coverage.** Each stated requirement, and the gaps you flagged, mapped to the questions that cover it.

| Requirement or gap | Questions | Note |
|---|---|---|
| Lead two squads building device-management services | A3, B3 | Device domain also in A2 and B3 |
| Delivery (own delivery) | A5, C5 | |
| Hiring | A6 | |
| Growth for 11 engineers | C2 | Growth is the least evidenced requirement; see F5 |
| Partner with hardware and product on roadmap | A1, A4, B4, B7, C6 | A1 is the highest-ROI prep |
| Managing managers (not in the role summary) | A2, C7 | Your stated gap |

## Persona weights by round

Relationship priors set the starting weights, the loop adjusts them, and depth follows weight: top persona 4 to 5 questions, mid 3, low 2. No interviewer profiles exist, so the weights are round-type priors.

| Round | Persona | Weight (questions) | How it shows up | Likelihood, and why | Counter-strategy |
|---|---|---|---|---|---|
| Tuesday, hiring manager | Skeptic | 3 (A1 to A3) | Probes the gaps: hardware roadmap, managing managers, one team to two squads | High. A hiring manager is buying capability and derisking gaps, and two of your gaps are in the role's own lines | Rehearse the most predictable objection until it is boring; plain acknowledgment first, then a ramp plan |
| Tuesday, hiring manager | Case/Strategist | 3 (A4 to A6) | Live problems on the roadmap: a hardware slip, a reliability trade, hiring for eleven | High. Hiring-manager prior, and the role's partner line invites a live problem | Clarify, then structure, then decide; think aloud; challenge one premise per case |
| Tuesday, hiring manager | Pressure | 2 (A7, A8) | Time-boxed challenge; the 60% figure invites a probe | Medium. Low prior for this round, but your headline figure is a magnet | Pause, restate, hold the defensible claim through two follow-ups, concede precisely |
| Thursday, panel | Data-Driven Prober | 3 (B1 to B3) | Staff engineers test figures and device technicals | High. Technical-specialist prior from two staff engineers | Name the weakest assumption before they do; say plainly what you do not know |
| Thursday, panel | Peer Evaluator | 3 (B4 to B6) | Seam-splitting between teams; "what do you need from us"; credit | High. The panel is the teams you would sit beside; the PM and staff engineers price your load | Reciprocity framing; propose seam principles rather than pretending to know the seam |
| Thursday, panel | Case/Strategist | 2 (B7, B8) | A roadmap trade-off with the PM; a measure for the first month | Medium. Product brings the roadmap trade | Structure before answer; name the metric you would distrust |
| Following Monday, VP | Values/Behavioral | 3 (C1 to C3) | Open prompts on pressure, growth, and what a manager owes a team | High. The recruiter's own words name values and leadership philosophy | STAR shape: "I" for the decision, "we" for the team; say where it cost something, or say it did not |
| Following Monday, VP | Case/Strategist (executive) | 3 (C4 to C6) | Altitude: what engineering needs in eighteen months; a platform slip | Medium. Executive prior, strategy-heavy | Say plainly what you would need to learn first; do not assert the company's strategy |
| Following Monday, VP | Pressure | 2 (C7, C8) | Composure on the managers gap and motive | Medium. Executive composure, and F6 is the obvious probe | Plain acknowledgment, then plan; hold through two follow-ups, concede where the material does not reach |

## Round 1: Tuesday, hiring manager (45 min)

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "This role partners with hardware on the roadmap, and you have never owned a hardware-adjacent roadmap. What do you do in the first ninety days?" | JD, CASE delivery | [grounded] "never owned a hardware-adjacent roadmap" (your message); [grounded] "partner with hardware and product on roadmap" (role summary) | Hold, then concede. Beat 1, first sentence: "I haven't owned a hardware-adjacent roadmap." Beat 2, the ramp as a plan: the first conversations with the hardware leads, and what you would ask them to show you about constraints. Beat 3, one transfer at its own scope: "I pushed a reliability quarter through against roadmap pressure", which is roadmap pressure, not hardware planning. Follow-up 1, "How would you handle a hardware date you cannot move?": hold the ramp; concede specifically: "I would learn the hardware constraints from the leads before I promised any date." Follow-up 2, "Why trust a plan from someone who hasn't done this?": concede: "You shouldn't yet. You can check it at the first roadmap review." | F8 is a capability gap, and the role's partner line raises it. This is the single most predictable objection and the highest-ROI prep in the pack: deepest rehearsal here. |
| A2 | "Which part of this job would you be weakest at on day one?" | JD, EXP | [generic] persona stem (Skeptic); [grounded] "I've never managed managers" (your message) | Name the weakest part honestly in the first sentence. If it is managing managers, use the plain acknowledgment and the plan from F6. If it is the device domain, use F2's honest branch. Do not pick a weakness that is a strength in disguise. | Skeptic stem. The answer is a stated gap, so the pack adds no new claim. |
| A3 | "You have led one team of six. This role leads two squads and eleven engineers. What is the difference, and what would you change first?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6" (your message); [grounded] "Lead two squads building device-management services" (role summary); [grounded] "own delivery, hiring and growth for 11 engineers" (role summary) | Story-mapped on F1: three years, one team of six. The beats are the ones the quote states: the team, the three years. Answer slot: if you have led across more than one team, say how; if not, say so and name the first change you would make, one you could start in the first month. Hold through two follow-ups by returning to one team of six, not by adding scope. | F1 is transferability; this is the natural JD probe on scope, and the Skeptic's standard move. |
| A4 | "Hardware says a dependency for your device-management service will slip six weeks. Walk me through what you do." | CASE | [generic] live problem built on "partner with hardware and product on roadmap" (role summary) | Clarify, then objective, options, decision, what you tell product and hardware, and what you measure. Think aloud. Name one premise you would challenge, such as whether the slip is real or a buffer. No claim about your past. | A live problem from the role's partner line. A CASE question asks about no past and presupposes nothing about you. |
| A5 | "Your team's on-call burden dropped after a reliability quarter. The roadmap wants new features this quarter. How do you choose which reliability work to take on?" | CASE, EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" (your message) | Method first, as a method and not a past: the criteria you would use (on-call load, incident cost, what hardware depends on, who must agree). Then one clause from the quote, at its scope: "I pushed a reliability quarter through against roadmap pressure." Answer slot: if you chose which reliability work went in, say how you decided; if you did not choose it, say so and say what you did choose. | Ties the delivery requirement to a method. The method is generic; the experience is the quote's. |
| A6 | "Walk me through how you would run hiring for eleven engineers, and what you would keep from the loop you run now." | JD, EXP | [grounded] "I run our hiring loop for backend roles" (your message); [grounded] "about 40 interviews last year" (your message) | Story-mapped on F3: the loop you run, backend roles, about forty interviews last year. The design for eleven engineers is a method, not a past. Answer slot: which parts of "our" loop you set, and which were set for you; if the loop was not yours to change, say so plainly. Do not add a figure you do not have. | F3 is the strongest hiring evidence; "own hiring" is the role's own line, and "our" is the attribution to protect. |
| A7 | "Sixty seconds: why you over an internal candidate who knows the hardware?" | JD, VAL | [generic] persona stem (Pressure); [grounded] "never owned a hardware-adjacent roadmap" (your message) | Pause. Restate the question. Hold the claims you can defend: one team of six for three years, and the reliability quarter. Concede the hardware gap in your first sentence, then hold through two follow-ups; concede on hardware specifically, never on the team's results. | Pressure stem. The concession is the stated negative; the held claims are both quoted. |
| A8 | "That 60%. How much of it was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" (your message) | Defend-the-number. Say how the 60% was counted, in your words; if you do not know how it was counted, say so plainly. Name the weakest assumption before they do. Your part is the quote's: you pushed the quarter through. The team's part is theirs to name; do not extend your claim to it. Answer slot: if you can say how it was counted, say it; if not, say that. | A headline figure. The pack never supplies a baseline, method or attribution model; "I don't know how it was counted" is an honest branch. |

## Round 2: Thursday, panel (60 min)

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The on-call burden fell after the reliability quarter. How do you know the quarter caused it?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" (your message) | Answer slot: if you know of anything else that changed in the same period, say what; if you do not know, say the quarter is what you can defend, and not that it caused the whole drop. Do not claim causation the quote does not state. | Your quote says "after", not "because". Panels probe the causal leap; the inflated form is on the prohibited list. |
| B2 | "Which assumption behind the 60% would you defend least?" | EXP | [grounded] same quote as B1 | Weakest-assumption move: name it in your own words before they do. The pack does not name the assumption. Answer slot: if you can name it, name it; if you cannot, say you have not tested it. Hold the drop itself; concede the assumption you name. | Persona stem (Prober). Converts a gotcha into a credibility gain. |
| B3 | "A device fleet fails in a pattern nobody predicted. How would you find out which devices, and what would you ask the hardware team first?" | JD, CASE | [grounded] "Lead two squads building device-management services" (role summary) | Structure the diagnosis: scope, the data you need, and what hardware knows that software does not: failure logs, firmware versions, the device's own telemetry. No claim about your past. Answer slot: if you have worked on fleet failure data, say what and your part; if not, say so. | Probes the device domain (F2) as a live problem rather than a record. |
| B4 | "Our teams sit side by side. Where's the seam, and what happens when we disagree?" | EXP, VAL | [generic] persona stem (Peer Evaluator); [grounded] "partner with hardware and product on roadmap" (role summary) | Propose seam principles, not a map: who decides on a shared interface, and how disagreements escalate. Do not pretend to know their seam; ask where it is. Answer slot: if you have disagreed with a peer team and seen the result, say what you did and how it ended; if not, say how you would want disagreement handled. | Peer stem; the seam is the role's partner line. |
| B5 | "How do you handle credit when work spans teams?" | VAL | [grounded] "I run our hiring loop for backend roles" (your message) | Story-mapped on F3's "our": say what you ran and what was shared, and keep "I" for what you set. Answer slot: if you can name a case where credit was shared, say it in your own words; if not, say how you would split it. | Peer stem. "Our" is the attribution to protect; the answer should keep it. |
| B6 | "What would you need from product to make the roadmap work?" | JD | [generic] peer reciprocity pattern | Name the inputs: the constraints you would need from product, the decisions that must be written down, and what you would bring to their team. No claim about your past. | Reciprocity framing: the PM's team is the one that carries the load. |
| B7 | "Hardware can ship a firmware fix or a feature next quarter, not both. You are the one who has to pick. What do you do?" | CASE | [generic] live problem; raising source "partner with hardware and product on roadmap" (role summary) | Clarify what each option costs and who has to agree. Structure the decision, pick one, and say what you would give up. Think aloud. No claim about your past. | Live roadmap trade with the PM in the room. |
| B8 | "What would you measure in the first month to tell whether your squads are shipping the right device-management work?" | CASE | [generic] live problem | Name the outcome before the output. Separate delivery measures from customer outcomes. Name one leading measure and one you would distrust. No claim about your past. | Tests altitude and measurement sense. |

## Round 3: Following Monday, VP Engineering (30 min)

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you held a position under pressure from someone senior." | VAL | [grounded] "pushed a reliability quarter through against roadmap pressure" (your message); recruiter's theme "values and leadership philosophy" (your message) | Open prompt with the recruiter's theme. Story-mapped on the quote: the quarter, the roadmap pressure, the position held, the on-call drop after. "I" for the push, "we" for the team's part. Say where it cost something, in your own words. Answer slot: if the pressure cost you something, say what; if nothing came of it, say so. Do not add an ending. | Values round. The only held-position story in your material is the reliability quarter. |
| C2 | "Tell me about someone who reported to you and got better because of something you did." | VAL | [grounded] "own delivery, hiring and growth for 11 engineers" (role summary) | Open prompt; the theme is the role's growth line. The material holds no growth example. Answer slot: name one engineer, what you did, and what changed, in your own words; if you cannot name one, say so and say how you would start. Do not supply an outcome. | Growth is the least evidenced requirement (F5). This is the probe. |
| C3 | "What do you believe a manager owes a team that most managers skip?" | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" (your message) | Give one belief in one sentence, then tie it to a decision you made, using only the quote. Do not make the belief bigger than the quarter. Answer slot: if the belief came from a decision you made, say which; if it is a belief without a decision behind it, say so. | Leadership philosophy, anchored to the only decision your material shows. |
| C4 | "What does the device-management business need from engineering in the next eighteen months?" | CO | [generic] company strategy not researched (Research tier L0); the role summary is the only company input | Say plainly what you would need to learn first: customers, the fleet growth plan, the hardware roadmap. Do not assert the company's strategy; it is not in your material. | Executive altitude. The CO bank would need research to be current; this is the honest answer at L0. |
| C5 | "How do you decide between shipping the device roadmap and paying down reliability debt?" | CASE | [grounded] "pushed a reliability quarter through against roadmap pressure" (your message) | Method first: what the debt costs in incidents, what the roadmap costs in missed commitments, who decides. Then the quote, at its scope: "I pushed a reliability quarter through against roadmap pressure." Answer slot: if you made a call like this, say what you traded and who agreed; if the call was not yours, say so. | Executive trade-off grounded in the one held decision you have. |
| C6 | "Hardware tells you a platform release will slip. You report to me. What do you do in the first forty-eight hours?" | CASE | [generic] live problem; raising source "partner with hardware and product on roadmap" (role summary) | Clarify. Decide who you tell and in what order. Say what you would not promise yet. Check with the leads before you commit. No claim about your past. | Executive composure on a live partner problem. |
| C7 | "You've never managed managers. Why should I trust you with two squads' leaders?" | EXP, JD | [grounded] "I've never managed managers" (your message) | Hold, then concede. First sentence: "I haven't managed managers." Then the plan: what you would do first with leaders, which is to learn what they need before deciding how to coach them. Hold the plan through two follow-ups. Concede: "You shouldn't trust that yet. You can check it at the first review." Add no experience. | F6 is the VP's most likely probe. A plain acknowledgment, then a plan, with no past claimed. |
| C8 | "Sixty seconds: why this role, and why now?" | EXP | [generic] persona stem (Pressure) | Answer slot: say what you want from this role, in your own words. The material holds no motive for the move, so the answer has to come from you. Keep the reason for leaving to one sentence, and do not criticise your current employer. | Motivation is not in your material. The question is a stock probe for the executive round, and the answer has to come from you. |

## Reverse questions

Each round has five. Each has a reason it lands. Interviewers are unnamed, so no career-path question appears; a name would add one.

### Round 1: Director of Engineering

1. "What would have to be true six months in for you to say this was the right hire?" Why it lands: it surfaces the success criteria the Skeptic will test, and signals that you think in outcomes.
2. "Where do hardware's planning cycle and the squads' release cycle collide today?" Why it lands: it shows you read the partner-with-hardware line and want the real friction, not the slogan.
3. "Which of the eleven engineers' growth paths is hardest to make work right now?" Why it lands: it opens the growth conversation the role asks for, and shows you think about individuals.
4. "What will the new manager be expected to decide without you in the first quarter?" Why it lands: it finds the real scope and delegation line.
5. "If someone held this seat before, what did they do well, and what did they leave undone?" Why it lands: a fair, specific question about history; the answer tells you the real problem.

### Round 2: panel (two staff engineers and a product manager)

1. (PM) "What is the roadmap decision from the last quarter you would want made differently?" Why it lands: it invites an honest post-mortem and signals you want to be useful on decisions, not only to inherit them.
2. (Staff) "Where does the squads' work pay the most for technical debt today?" Why it lands: a concrete seam, and it tells you about the stack.
3. (Staff) "How does hardware come into design reviews today, and when does that go badly?" Why it lands: it shows you will partner in design, not only in planning.
4. (PM, reciprocity) "What could a new engineering manager do in the first month that would genuinely help your team?" Why it lands: peer reciprocity. The panel is their team, and this asks about their load.
5. (Staff) "What would you want a new manager to understand about the device-management services before the first design review?" Why it lands: it points at the device domain, your gap, so you can ask rather than pretend.

### Round 3: VP Engineering

1. "Which of the company's values do you see most often tested by roadmap decisions?" Why it lands: it shows you read values as behaviour, not slogans.
2. "What would you want a manager to fix in their first six months, and what would you not want them to touch?" Why it lands: it gets the leadership philosophy in one question, both halves.
3. "How do you decide whether to hire a skill or grow it inside a team?" Why it lands: it links hiring and growth, the two halves of the role's own line.
4. "What have you seen work when a manager and the hardware leads disagree?" Why it lands: it names your gap and gets the VP's experience without a confession.
5. "What do you and the hiring manager need to agree on before you sign off this role?" Why it lands: it shows you want alignment before an offer, and the answer defines the approval path.

## Prohibited claims

What this pack will not coach, built from the fit snapshot before the banks were written. Each entry has its basis and its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned a hardware-adjacent roadmap | Stated negative, F8 | "I've never owned a hardware-adjacent roadmap." No answer slot. |
| Managed managers | Stated negative, F6 | "I've never managed managers." No answer slot. |
| Owned the hiring process end to end, or set hiring policy | Inflated form of F3 | "I run our hiring loop for backend roles", at its own scope. A6 asks which parts were yours. |
| The reliability quarter caused the whole 60% drop | Inflated form of F4: your sentence says "after", not "because" | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." Limit, in the pack's analysis: your material says after, not because of. |
| Set the roadmap jointly with product and hardware | Inflated form of F7 | F7's quote at its own scope: "I pushed a reliability quarter through against roadmap pressure." B4 names the seam without claiming it. |

## Sources

- **Provided documents:** your message (your background, the role summary, the three rounds, the recruiter's theme). No dossier was provided, so no `prohibited_claims` came from one; the list above was built locally.
- **Searches and fetches:** none sent.
- **Research tier: L0.** No searches and no fetches. Research was not yet consented, and the upgrade menu offers it.

Target accounting:

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Larkfield Systems values` | unavailable | Would have moved the values cheat sheet, which is absent; the Round 3 VAL bank runs on the recruiter's theme instead |
| 2. `Larkfield Systems interview process engineering manager` | unavailable | Would have confirmed the loop structure; the three rounds you named set the loop |
| 3. `Larkfield Systems strategy` / recent news | unavailable | Would have moved the strategy-grounded CO and CASE questions; C4 is generic for this reason |
| 4. `{interviewer name} Larkfield Systems` | n/a | No interviewer names were given, so there was no query to form |
| 5. Representative `Engineering Manager` JD | unavailable | Would have added requirement rows beyond the role summary |

## Upgrade menu

- **Full job posting text** → adds requirement rows you have not seen and makes the requirement coverage table complete; the role summary is the only requirement source now.
- **Your CV** → turns the "your message" evidence into checkable claims. Named artifacts would be needed to raise the medium-confidence rows (F1, F3, F4) to high.
- **Any device, connected-systems or embedded work** → F2 moves from discovery to a story you can rehearse at its own scope.
- **Recruiter's notes on each round's focus or exercise** → sharpens the round weights and the Monday values bank.
- **Interviewer names** (Director, the two staff engineers, the PM, the VP) → per-member personas, an interviewer read, and tailored reverse questions.
- **Research at L1** (up to 6 searches and 2 page fetches, on Larkfield's values, interview process and strategy) → a values cheat sheet, the loop confirmed, and a strategy-grounded CO question.
- **Research at L2** (deep research, offered once, on your go-ahead: up to 6 further searches and 2 further fetches on interviewer talks and loop reports) → role-family loop reports and interviewer public footprint.
- **`tuesday-dossier.md`** → verified evidence and absolute prohibited-claim guardrails in place of the list built here.
