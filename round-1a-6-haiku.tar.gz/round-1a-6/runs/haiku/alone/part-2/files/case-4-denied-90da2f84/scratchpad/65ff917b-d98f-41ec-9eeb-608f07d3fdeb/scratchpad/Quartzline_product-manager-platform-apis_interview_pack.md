# Interview prep pack: Product Manager, Platform APIs at Quartzline

Hiring-manager round, 45 minutes. Built from your underwriting dossier (`tuesday-dossier.md`: `handoff_to_mock_interview` and `role_profile`). The dossier is dated 2026-08-14 and today is 2026-11-26, so confirm the role's scope and the squad-authority answer still hold before Thursday. No company research ran this session (see Sources). Highest-ROI rehearsal: **S1**.

## 2. How to use and type key

Personas describe how a question arrives; types describe what it scores. Guidance is scaffolding for a spoken answer, not a script.

- **JD**: a listed requirement or responsibility from the role
- **EXP**: what you did, attributed precisely
- **CASE**: a live problem from the role, answered aloud

VAL and CO do not appear: no values round was detected and no company research ran.

Reference IDs: V1 to V3 are the dossier's `verified_candidate_evidence` entries, in order. R1 to R5 are the `role_profile` requirements, in order.

## 4. Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" — dossier R1 | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier V1; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier V3 | low | [grounded] | transferability | Your confirmed work is client integration leadership and roadmap input, not product management, and the bridge says so first. Use V1 and V3 at their own scope. Any wider claim is an answer slot inside those quotes (S4). Dossier limit: no PM title held, no roadmap owned. |
| F2 | "Own the roadmap for the partner-facing API platform" — dossier role_profile responsibility; dossier uncertain_or_weak_areas, "Owning a roadmap and prioritization authority" | none given | none | [grounded] | capability | Acknowledgment only, sourced to the dossier's acknowledge_gap entry and its prohibited_claims. Say plainly: I haven't owned a product roadmap, and I haven't set prioritization for an engineering squad. No bridge and no answer slot on this area. |
| F3 | "Stakeholder management across engineering, sales, customers" — dossier R4 | "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier V3 | medium | [grounded] | transferability | V3 reaches product and clients, not engineering or sales. Use V3 at its scope and name the medium-confidence caveat yourself: confirmed, limited inspectable proof. Engineering and sales management are an answer slot: if you managed those stakeholders, say which and how; if not, say so. |
| F4 | "Shipped API or platform products" — dossier R2 | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier V1 | high | [grounded] | transferability | Integration delivery on the vendor's APIs, for clients, is adjacent to shipping an API product, and the bridge keeps that limit. Answer slot: if you were part of building the API itself, say which part and how; if you integrated with it, say so plainly. Routing note: the dossier does not grade R2, so this gap type is this pack's call. |
| F5 | "Technical fluency: API docs, schemas" — dossier R3 | "Wrote the internal integration playbook her team uses" — dossier V2 | low | [grounded] | discovery | The playbook is documentation you can show, and the dossier rates it inspectable. No quote shows schema work. Answer slot: if you have written or reviewed schemas, say which; if not, say so and name how you would learn them. |
| F6 | "Agile delivery experience" — dossier R5 | none given | low | [grounded] | discovery | Clarify strategy: no verified entry speaks to agile delivery, so no bridge is coached. Answer slot on the requirement's own wording: what agile delivery means to you and where you have done it. If you have not worked that way, say so, and say what you would want to confirm about how this team defines it. |
| F7 | "Define and track adoption metrics" — dossier role_profile responsibility; dossier unknowns, "How adoption is measured today" | none given | none | [grounded] | discovery | No verified entry speaks to metrics. Answer slot: if you measured adoption of anything, say what and how; if you did not, say so and say what you would measure first. |

Gate rows: none. The dossier records `hard_gates: []`, and the JD text supplied states no location, pay, or notice term.

## 8. Persona table

Relationship prior for a hiring manager: Case/Strategist plus Skeptic. The dossier's risk sits on the title and roadmap gap, which is the Skeptic's ground, so Skeptic takes top weight. No interviewer profile exists, so no interviewer signal applies. This is a single 45-minute session with no loop source, so no loop tilt applies. Total questions: 19.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy | Weight |
|---|---|---|---|---|
| Skeptic | Quiet probing of the title and roadmap gap; "why you, why now" | High. Hiring managers buy capability and derisk gaps. The dossier names this objection as the likeliest one | Rehearse S1 until it is plain; hold the integration evidence; concede the roadmap gap specifically, with a ramp plan | 5 questions |
| Case/Strategist | Live problems on partner discovery and adoption | High. Two JD responsibilities are case-shaped: discovery and adoption metrics | Clarify, then objective, segmentation, approach, metrics, risks; think aloud | 4 questions |
| Data-Driven Prober | Denominators on the 30+ count and the playbook's use | Medium. The 30+ figure in V1 is the headline number a prober will test | Defend-the-number answer slots; name the weakest assumption yourself | 3 questions |
| Pressure | Time-boxed challenge to the title gap | Medium. A hiring manager may test composure on the gap | Pause, restate, hold two follow-ups, concede specifically | 3 questions |
| Conversational | Open journey question; casual check on the API docs skill | Low to medium. Casual questions are still scored | A 90-second arc from quoted lines only | 2 questions |
| Peer Evaluator | Seam between you and the two engineering squads | Low to medium. The role sits between two squads, so seam questions are plausible | Propose seam principles; do not claim to know the seam | 2 questions |

## 9. Question banks

### Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| S1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier V1. The acknowledgment is sourced to the dossier's prohibited_claims and uncertain_or_weak_areas (acknowledge_gap), named by field. | Restate the question in your own words. Then the plain acknowledgment, from F2: you have not held a product manager title, and you have not owned a product roadmap. Then the nearest true thing at the quote's own scope: you led 30+ end-to-end client integrations, from scoping through go-live. Then the limit, said by you: that is integration delivery, not roadmap ownership. Close with a ramp plan in your own words: how you would learn the squads' decision boundaries and the partner roadmap in the first 90 days. Hold the integration evidence through two follow-ups. Concede the roadmap gap plainly and specifically. There is no answer slot here, because the roadmap area is acknowledge_gap. | The dossier named this as the likeliest objection, so it gets the deepest rehearsal. Its negatives have sources, so the question is kept as written. Follow-up to drill: "Which decisions did you make?" Answer with the acknowledgment, then V1. |
| S2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Own the roadmap for the partner-facing API platform" — dossier role_profile responsibility; the roadmap acknowledgment is sourced as in S1. | Name the roadmap ownership first and plainly, as in F2. Then name the second weakest area honestly: adoption metrics, from F7. Answer slot: if you have measured adoption of anything, say what and how; if you have not, say so and say what you would measure first. Do not list any bridge as if it were ownership. | This is a Skeptic stem aimed at the two gap rows, F2 and F7. Naming the gaps first converts the question from an audit into your own diagnosis. |
| S3 | "Have you shipped an API or platform product?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier V1 | Answer with V1 at its scope: the integrations you led were on the vendor's REST APIs, for clients. Answer slot: if you were part of building the API itself, say which part and how you decided; if you integrated with it, say so plainly. Do not use the word "shipped" for work the quote does not state. | F4 is a transferability gap. The question's premise is the JD's own line, so the slot stays inside the quote's scope. |
| S4 | "What is the closest you have come to a product call that a lead would have argued with?" | JD | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier V3 | Describe the sessions in V3's words: they fed client evidence to product. Limit, said by you: that is evidence going to product, not a call you made. Answer slot: if a call of yours came out of those sessions, say which and what you did; if the decision went to product, say so plainly and stay with the evidence you gathered. | R1 is transferability, and V3 carries medium confidence, so expect a probe. Name the limit before it is extracted. |
| S5 | "What does agile delivery mean to you, and where have you done it?" | JD | [grounded] "Agile delivery experience" — dossier role_profile R5 | The requirement's own wording is the probe. Answer slot: describe the delivery cadence you worked in, in your own words. Second branch: if you have not worked that way, say so, and say what you would want to confirm about how this team defines agile delivery. | F6 is a discovery gap with a clarify strategy. No verified entry speaks to it, so the answer slot is the only form allowed. |

### Case/Strategist (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Suppose partner API adoption had been flat for two quarters. How would you diagnose it?" | CASE | [grounded] "Define and track adoption metrics" — dossier role_profile responsibility. The scenario is a hypothetical: [generic] | Clarify first: ask for the current adoption baseline and how it is measured, which the dossier lists as unknown. Then objective, segmentation by partner type or integration size, approach, metrics, and risks. Think aloud. Make no claim about adoption data you have not seen. | F7 has no evidence, so the case is where you show structure without claiming a past. The scenario itself carries no claim about you. |
| C2 | "How would you decide which partner request makes the roadmap?" | CASE | [grounded] "Run discovery with integration partners" — dossier role_profile responsibility; [grounded] "scoping, requirements" — dossier V1, as method evidence | Give a framework: partner value, how many partners ask, engineering effort, strategic fit, and how you say no. Use V1 only for the steps it names: you ran scoping and requirements on those integrations. Do not say you prioritized anything. | The responsibility is a raising source for the question. The V1 quote lets you point to method evidence without stretching it into prioritization. |
| C3 | "A partner's top request needs work that one squad is already planning, and the other squad owns the change. What do you do?" | CASE | [grounded] "Write specs and drive delivery with two engineering squads" — dossier role_profile responsibility. The scenario is a hypothetical: [generic] | Start by asking who decides between the squads. Then state a recommendation and name what you need from each squad lead. Say that you would bring the call to the decision owner, and do not claim decision authority. | The dossier lists decision authority as unknown. This tests how you act without authority, which is the real question behind the squad line. |
| C4 | "Adoption went up 15 percent after the change, but support tickets went up too. What do you do?" | CASE | [generic] | Name the weakest assumption behind the 15 percent first: what counts as adoption. Check whether the new tickets come from new adopters. Then define the next metric to track. | The adoption responsibility raises the metric question. The scenario is generic, so the guidance makes no claim about your history. |

### Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Walk me through how the 30+ integrations were counted." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier V1 | Defend-the-number slot. If you kept the count yourself, say how you counted and what counted as one integration. If the count came from somewhere else, say so. Then the assumption behind the figure you would defend least, and which of the five steps were yours. If no count was kept, say so plainly. | V1 is the headline figure, so a prober will test it. The slot asks for your method, not a method supplied here. |
| P2 | "How do you know your team actually uses the playbook?" | EXP | [grounded] "Wrote the internal integration playbook her team uses" — dossier V2 | Say what the playbook is, in V2's words. Answer slot: if you measured its use, say how; if you did not, say so plainly and name what you would show: the playbook itself, which the dossier rates as inspectable. | The question tests whether "uses" is yours to claim. The dossier rates V2 high, so the honest answer is a document you can show. |
| P3 | "What happened to the evidence from those roadmap-input sessions? How would you know it changed anything?" | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier V3 | Say the sessions and where the evidence went, in V3's words. Name the medium-confidence caveat yourself: limited inspectable proof. Answer slot: if you tracked what product did with the evidence, say what you tracked; if you did not, say so and say what you would track. | V3 touches R4 and F7 at once. Volunteering its limit before it is extracted is the coaching point. |

### Pressure (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| Pr1 | "Sixty seconds: why you over a PM with three years on the job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier V1; the acknowledgment is sourced as in S1 | Pause, then restate. Answer in about 60 seconds using S1's order: the plain acknowledgment, V1, the limit, the ramp plan. Hold the integration evidence through two follow-ups. Concede the roadmap gap plainly. | The time-boxed version of S1. Same content, same sources, shorter delivery. |
| Pr2 | "That result — how much of it was actually you?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier V1 | Hold the scope the sentence gives: you led them end to end. Answer slot: which of the five steps were yours to do, and which your team did. Do not add to "led". If credit was shared, say so plainly. | The attribution probe on V1. Holding the quote's wording under pressure is the skill being rehearsed. |
| Pr3 | "When have you disagreed with an engineering lead about what to build?" | JD | [generic] open prompt. The theme comes from R4's "engineering" and the squads line. Nearest quoted line: "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier V3 | Selection scaffold ending in the honest branch: pick a time you disagreed with an engineering lead about scope. If none comes to mind, say so plainly, then give the nearest thing the material carries: the V3 sessions, and how you would handle a disagreement with an engineering lead now. | The question is an open prompt, so it supplies no event. No quote carries an engineering disagreement, so the honest branch is the answer. |

### Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| Cv1 | "So — walk me through the journey." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier V1; [grounded] "Wrote the internal integration playbook her team uses" — dossier V2; [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier V3 | A 90-second arc from the three quoted lines, in order: V1, then V2, then V3. Close with the link to this role in your own words, and say the gap once. | Casual questions are still scored. The arc is built only from quoted lines, so it cannot grow past them. |
| Cv2 | "What are you working with in API docs and schemas these days?" | JD | [grounded] "Technical fluency: API docs, schemas" — dossier R3; [grounded] "Wrote the internal integration playbook her team uses" — dossier V2 | Name the documentation you can show: the playbook, in V2's words. Answer slot for schemas: if you have written or reviewed schemas, name which; if you have not, say so and name how you would learn them. | F5 is a discovery gap on the schema half of R3. This is the casual form of the same check. |

### Peer Evaluator (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| Pe1 | "Your two squad leads sit side by side. Where is the seam, and what happens when you disagree with one?" | JD | [grounded] "Write specs and drive delivery with two engineering squads" — dossier role_profile responsibility; [generic] seam principles | Propose seam principles, not a claimed map of the seam: who decides scope, how a disagreement escalates, and what you need written down. For the disagreement, use the Pr3 selection scaffold and its honest branch. | The squads are the raising source. The peer persona tests partnership, and the seam is unknown to you, so say that. |
| Pe2 | "When work spans teams, who gets the credit for an integration?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier V1 | Answer in V1's terms: you led the integrations end to end. Answer slot: if credit was shared, name who did which of the five steps; if the steps were not shared, say so plainly. | The credit probe on V1. It mirrors Pr2 from a collegial angle. |

### Coverage

| Requirement or responsibility | Covered by |
|---|---|
| R1, 3+ years PM experience | S1, S4, Pr1 |
| R2, shipped API or platform products | S3 |
| R3, API docs and schemas | Cv2, P2 |
| R4, stakeholder management | Pe1, P3, Pe2 |
| R5, agile delivery | S5 |
| Own the roadmap | S1, S2 |
| Run discovery with integration partners | C2 |
| Write specs and drive delivery with two squads | C3, Pe1 |
| Define and track adoption metrics | C1, C4, S2 |

Total questions: 19, within the 18 to 26 range.

## 11. Reverse questions

Five or more, each with why it lands. No interviewer profile exists, so none ties to the interviewer's path. This is a hiring-manager round, not a peer round, so no reciprocity question is required.

1. "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" Why it lands: it resolves the dossier's open squad-authority question, which the JD asserts and nothing evidences. You need the answer before you accept.
2. "How is partner API adoption measured today, and what is the current baseline?" Why it lands: the adoption responsibility has no stated baseline. The answer tells you what you would be measured against.
3. "Which partner relationships would this role own in its first six months?" Why it lands: it tests the scope of partner discovery against the role as written, and it shows you read the responsibilities closely. [generic]
4. "What does the current PM hand over, and what did they find hardest?" Why it lands: it shows you what the real job is, not the posting's version. [generic]
5. "What would make you say in six months that this was the right hire?" Why it lands: it names the success criteria, which ties straight back to the adoption metrics question. [generic]

## 13. Prohibited list

Built from the dossier's `prohibited_claims` and `uncertain_or_weak_areas` (acknowledge_gap), and from the inflated forms of the quoted lines. No answer slot, hold, bridge, or rationale in this pack asserts any entry below.

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | Sourced: dossier prohibited_claims | Plain acknowledgment: you have not held a product manager title. No slot. |
| Having owned a product roadmap | Sourced: dossier prohibited_claims and acknowledge_gap | Plain acknowledgment: you have not owned a product roadmap. No slot. |
| Having set prioritization for an engineering squad | Sourced: dossier prohibited_claims and acknowledge_gap | Plain acknowledgment: you have not set prioritization for an engineering squad. No slot. |
| Ran discovery with integration partners | Inflated form of V3 | V3 at its own scope. The material shows evidence fed to product, not discovery you ran. Limit stated as this pack's observation, not as words for you. S4 slot stays inside the quote. |
| Wrote the API schemas and docs | Inflated form of V2 | V2 at its own scope: a playbook. The material shows no schema work. F5 slot asks what you have written or reviewed. |
| Owned the partner-facing API platform | Inflated form of V1 | V1 at its own scope: you led client integrations end to end. The material shows no platform ownership. S3 slot stays inside the quote. |

## 14. Sources

Provided documents:
- `tuesday-dossier.md` (underwriting dossier, conditional_go). Consumed: `handoff_to_mock_interview` (V1 to V3 verified evidence, uncertain_or_weak_areas, likely_interviewer_objections, opportunity_risks_to_validate, questions_for_employer, prohibited_claims) and `role_profile` (R1 to R5, responsibilities, unknowns). Context only: `decision`. Not consumed: `evidence_map` (not present in the file given).
- Staleness: the dossier was generated 2026-08-14. Today is 2026-11-26, about fifteen weeks later. The role's scope and the squad-authority answer may have changed.
- Gap-type routing for R2, R3, R4 and F7 is this pack's proposal. The dossier does not grade those rows.

Searches sent this session, both refused (web search permission not granted; no retry attempted):
- "Quartzline Product Manager Platform APIs" — refused
- "Quartzline company values strategy 2026" — refused

Fetches: none.

Research tier: L1, searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quartzline values | unavailable | Values cheat sheet, section 10: not built, since no values round was detected and the search was refused |
| 2. Quartzline interview process, hiring manager | unavailable | Loop structure: unknown. Persona weights are hiring-manager priors, not loop-derived |
| 3. Quartzline strategy and recent news | unavailable | CO bank: not built. The search was not sent after the first two refusals |
| 4. Interviewer name and Quartzline | n/a | No interviewer name was given, so there was no query to form |
| 5. Representative Product Manager, Platform APIs JD | skipped | The dossier's role_profile fixes the JD requirements |

## 15. Upgrade menu

- Permission for web search → company research at L1: Quartzline values, a values cheat sheet, the interview loop structure, and a current strategy section with a CO bank
- The interviewer's name → an interviewer read, tailored persona weights, and a reverse question about their own path
- A check that the role has not changed since August → a refreshed dossier. If the squad-authority answer changed, S1, S2 and C3 are rebuilt
- The current posting text → the R1 to R5 quotes are confirmed against what the employer now says
- Your CV, one line per role → F1, F3 and F4 can carry story maps beyond V1 to V3, not only the three confirmed lines
- Deep research (L2) → strategy brief, interviewer writing, and loop reports, at up to six more searches and two more fetches. It needs the same search permission
