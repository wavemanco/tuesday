# Interview pack: Senior Partnerships Manager, Kelverton Rail, second round

Panel: Deepa (VP Partnerships, future manager) and Ross (Commercial Director). 60 minutes: a 15-minute spoken POV on operator partnerships over the next 18 months, then Q&A, with Ross pushing on commercials. Session pack, first version, no changelog.

Built on: your stated background, the recruiter's email as you quoted it, and the round's format. No JD, no text of the market report, and no company research (the searches were refused this session; see Sources).

## How to use

- **Personas** describe how a question is asked. **Types** describe what is being scored.
- Type key: **VAL** behavioural/values, **EXP** your own experience, **JD** the role's requirements, **CO** company and strategy, **CASE** a live problem.
- No VAL questions: no values-style round is detected, and no company values were read.
- Guidance is scaffolding, not a script. Quoted words are yours; anything in square brackets is a label on where the content came from.

## Prep triage (about 4 hours)

1. **About 90 min: build the POV and say it aloud twice, timed to 15 minutes.** Section "Graded deliverable" below. Start with the market report's recommendations (see the upgrade menu) so you know what to depart from.
2. **About 30 min: B1, the rail objection.** It is the most likely opening from Deepa and the highest-return rehearsal in this pack. Say the hold and the concession out loud three times.
3. **About 40 min: the commercial numbers.** C1, C2, D1, D2. Get the answer to "how was the £4M counted" from your own records, not from memory.
4. **About 30 min: the management and partnership-model answers.** A3, B3. Say the honest branch aloud as well as the one you would use.
5. **About 20 min: reverse questions,** R1 to R6, chosen to fit the conversation you want.

Everything else is insurance. Leave the last 30 minutes unplanned.

## Fit snapshot

Requirements come from the recruiter's own words where quoted, and otherwise from role-family prose labelled as generic. No JD was supplied, so no gate can be checked here; the upgrade menu asks for it.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "where you'd take our operator partnerships over the next 18 months" (recruiter email, as quoted in your message) | "last 4 at a payments company running the ISV channel" (your message), "took it from 6 partners to 40, roughly £4M of influenced revenue" (your message) | medium | [grounded] | transferability | Your record is partner growth in a payments channel, not operators. Bridge, in your words: "Over the last 4 years running the ISV channel, I took it from 6 partners to 40." Answer slot: the 18-month question will probe what carries over from ISV partners to operators. Say what you would keep and what you would not, as a plan, not as a past. |
| F2 | "Please land on what it means for the operators themselves." (recruiter email, as quoted in your message) | "5 years in transport consulting" (your message), "bus and light rail network planning" (your message), "so I know the operator world from the other side" (your message) | medium | [grounded] | transferability | Bus and light rail network planning is operator-adjacent. It is not rail operations, and not scheduling software. Bridge: "Before that, 5 years in transport consulting, on bus and light rail network planning." Answer slot: name a decision you saw an operator make from the planning side. If you did not see one made, say so. |
| F3 | "Ross will push on commercials." (recruiter email, as quoted in your message) | "roughly £4M of influenced revenue" (your message) | medium | [grounded] | transferability | The figure is influenced revenue, not sourced or closed revenue. Bridge: say the figure as your message does, roughly £4M of influenced revenue, and say what it covers. Answer slots: how the figure was counted and against what base, in C2 and D1. |
| F4 | closes a revenue number against operators (generic: role family, no JD line) | "Never sold into rail specifically" (your message), "never carried a direct quota, only influenced revenue" (your message) | none | [grounded] | capability | A gap you stated, so the pack may give the words back. Words: "I haven't sold into rail." "I haven't carried a direct quota." Then how you would learn it, said as a plan. Never claim sales experience in a market you have not sold into. |
| F5 | leads a partnership team (generic: role family; Deepa is your future manager) | none given | none | [generic] | discovery | Your material does not show people management. Answer slot: if you have led people, say how many and one thing you changed in how they worked. If not, say so plainly, then describe the cadence you would set in your first month. |

Gap type follows the evidence: F4 is a capability gap because you stated the absence. F5 is discovery because the material is silent.

## Graded deliverable: the 15-minute POV

Facts to build on, each quoted from F1 and F2 so the POV rests on your words: "took it from 6 partners to 40, roughly £4M of influenced revenue" (F1), and "so I know the operator world from the other side" (F2).

Three theses. Each comes with its concession. Every claim about the rail market here is [generic]: no research or report text was available.

- **Thesis 1: judge operator partnerships on what the operator's planners can do after the next timetable change, not on partner count.** Draws on F2. Concession: this makes revenue slower to show, and Ross will say so. Name the trade-off yourself before they do.
- **Thesis 2: move some partners from reselling to owning an operator outcome, such as a planning or delivery service, with the software as the engine.** Draws on F1, which carries channel building, not operator delivery. Concession: this brings channel conflict, thinner margin, and partners you have not yet met.
- **Thesis 3: treat the operator relationship as a planning-data relationship.** The operator's planners tell you what the tool gets wrong. Concession: operators are slow to share data, and some will refuse.

**Differentiation.** The consensus answer is most likely the shortlist in last quarter's market report, and you have read it. Its text was not provided, so this step is open until you paste its recommendations. Then choose the one thesis you would depart from, and say why. Anti-pick, where the role calls for it: "I would not build a partner tier for operators who won't share planning data."

**Close.** The recruiter asked for what it means for the operators themselves. Close on the planner: what they can do on the Monday after go-live that they could not do before, and what they would have to trust you with to get there.

## Persona table

Panel rule: blend the two top personas for each member's relationship. Deepa is the hiring manager, so Case/Strategist and Skeptic. Ross is commercial and senior, so Pressure and Data-Driven Prober. You gave no interviewer profile, so no interviewer-signal adjustments are applied.

| Persona | Who | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|---|
| Case/Strategist, weight 5 | Deepa | A live problem on the operator roadmap, likely the POV itself, then a follow-up | High: the hiring manager is buying direction, and the POV is the case | Clarify, then objective, segment, approach, metrics, risks. A1 to A5 |
| Skeptic, weight 3 | Deepa | "Why you, why now", and the rail gap | High: no rail sales and no quota are the two obvious gaps (F4) | Rehearse B1 until it is boring. Plain acknowledgment, then the plan |
| Pressure, weight 5 | Ross | Interruptions, a time box, "how much was actually you" | High: a commercial director is paid to test a quota-less candidate | Pause and restate. Hold through two follow-ups, then concede precisely. C1 to C5 |
| Data-Driven Prober, weight 3 | Ross | Denominators, the assumption behind the figure | Medium to high: influenced revenue invites exactly this probe (F3) | Name the weakest assumption if you know it. If not, say so. D1 to D3 |
| Conversational, weight 2 | either | The opener, "walk me through the journey" | Low: the POV takes the first slot, but a casual question is still scored | A 90-second arc in quoted words. E1, E2 |

## Question banks

Coverage: the JD is absent, so the requirement line below maps the recruiter's stated requirements and your own priorities.

| Stated requirement or priority | Source | Covered by |
|---|---|---|
| Operator partnerships over 18 months | recruiter email | POV, A5, D3 |
| What it means for operators themselves | recruiter email | POV close, A5, E1 |
| Commercials, which Ross will push | recruiter email | C1 to C5, D1, D2 |
| Partnership model | your priority | A3, A4 |
| Managing a partnership team | your priority | B3 |
| Rail sales and quota | your message, F4 | B1, C3, E2. No further question, because no JD line is quoted |

### Case/Strategist, weight 5 (Deepa)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Sketch the plan for your first 90 days on operator partnerships. What do you need to know first?" | CASE | [generic] | Clarify first: which operators, which decisions they own, and what a timetable change costs them when it goes wrong. Then one objective, one segment to start, the approach, two metrics, one risk. Name the questions you would put to the operator before you propose anything. | Deepa is buying direction, and this is the POV's own problem. Generic, because it is a pattern, not a fact about Kelverton. |
| A2 | "An operator says the scheduling tool works but the partner route is confusing. What do you change first?" | CASE | [generic] | Ask which operator, and at which stage it breaks: evaluation, procurement, or rollout. Then one change, one metric that shows it worked, and the risk that the change makes the route worse for the operator. | A live problem with no past claim. Generic because the scenario is invented, not sourced. |
| A3 | "How would you structure the partner model? Who sells, who configures, and who the operator calls when a timetable breaks?" | JD | [generic] | Name three roles, then the one you would pilot, and the assumption you would test first. Make no claim about the company's model: you do not know it yet. | Deepa's partnership-model question, your priority 3. The answer rests on no fact about the company. |
| A4 | "Which operators should we partner with first, and why those?" | CO | [generic] | No strategy was pulled, so you cannot cite the company's book. Segment operators on one stated criterion, such as where a timetable change costs the operator most, and say it is your working view. Name the first two and why. | Company strategy went generic without research, and this is labelled as such. |
| A5 | "What does a good outcome look like for an operator, not for us?" | JD | [grounded] "Please land on what it means for the operators themselves." (recruiter email) | Name two outcomes an operator's own planners would measure, in their terms. Name one you would not claim credit for even if it moved. Keep the operator's measure first. | The recruiter's own line raises this, so the premise is theirs. It is the POV close, rehearsed as a question. |

### Skeptic, weight 3 (Deepa)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've never sold into rail. Why should an operator take your call?" | EXP | [grounded] "Never sold into rail specifically" (your message), "so I know the operator world from the other side" (your message) | Highest-return prep in this pack. In order: "I haven't sold into rail." Then the scope you can stand on: "5 years in transport consulting" on "bus and light rail network planning", which is why the operator world is one you know from the other side. Then the plan, said as a plan: what you would do first with an operator, and what the first call would teach you. Hold through two follow-ups by returning to the planning side. Concede exactly: "I'd be learning the rail sales cycle. I haven't run one." Do not say you have sold into any other operator market, because your material does not carry it. | The Skeptic's most predictable objection, and the gap F4 names. The deepest rehearsal, because a rehearsed plain acknowledgment changes the room. |
| B2 | "Why leave a payments company, and why now?" | EXP | [grounded] "last 4 at a payments company running the ISV channel" (your message), "so I know the operator world from the other side" (your message) | Answer slot: give the real reason, in your own words. Then what this role gives you that the channel does not, stated as operator-side work. If the reason is the operator side, say so in those terms. Do not supply a reason you did not give. | Motivation consistency is the Skeptic's test. The answer has to be yours. |
| B3 | "How would you lead a team of partnership managers? Have you done it?" | EXP | [grounded] "Deepa (VP Partnerships, your future manager)" (recruiter email, as quoted in your message) | Answer slot: if you have led people, say how many and one thing you changed in how they worked. If not, say so plainly, then describe the cadence you would set in the first month. | F5 is discovery, and this is your priority 3. The honest branch is the answer. |

### Pressure, weight 5 (Ross)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You've never carried a quota. Why would I trust a commercial number from you?" | EXP | [grounded] "never carried a direct quota, only influenced revenue" (your message) | Hold: the figure you have is roughly £4M of influenced revenue, and you describe it. Hold through two follow-ups without adding a quota. Concede precisely: "I haven't carried a quota, so there's no attainment history to show you. What I can show is what I influenced and how I'd build the number here." Do not fold into "I'm confident I'd hit it." | The Pressure persona's central test. The hold is the only claim you may make, and the concession is the one you can defend. |
| C2 | "£4M influenced. How much of that was actually you?" | EXP | [grounded] "roughly £4M of influenced revenue" (your message), "took it from 6 partners to 40" (your message) | Answer slot: say which part of the partner-sourced revenue you took part in, in your own words, and what the partners did on their own. If you know how the figure was counted, say it. If you do not, say so: "I don't know the attribution model on that figure, and I'd check it." | Influenced revenue is the most probed figure. Defend-the-number applies, and the honest branch is the answer. |
| C3 | "Sixty seconds: why you over someone who has sold into rail?" | JD | [grounded] "Never sold into rail specifically" (your message), "took it from 6 partners to 40" (your message) | Pause, then restate the question. Say the rail gap in your first sentence, not your last. Then what you did: took the channel from 6 partners to 40. Then the planning side. Hold through two follow-ups, and concede the sales cycle exactly as in B1. | Ross's version of the Skeptic objection, timed. A pause and a restatement are the composure test. |
| C4 | "What would you commit to as an operator revenue number in year one?" | JD | [generic] | Do not name a figure you cannot build. Give the method, not a number: how many operators you would have live, what each would buy, and the assumption you would defend least. If the company sets the number, say so, and say what you would need to see before accepting it. | A figure invented in the room is the failure mode. Generic, because it asks for a plan, not a fact about you. |
| C5 | "Where does the margin come from when a partner sells our software to an operator?" | CO | [generic] | Name the split you would need to see: partner margin against the price the operator pays, and who carries the support load. Say you have not seen the partner terms. Give your trade-off as a view. | Ross's commercial pushback. No market or margin claim is made, because none is sourced. |

### Data-Driven Prober, weight 3 (Ross)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Against what base is the £4M influenced figure measured?" | EXP | [grounded] "roughly £4M of influenced revenue" (your message) | Answer slot: if you know the base, say it. If you do not, say so, and name the assumption about the base you would check first. Do not supply a denominator. | The prober asks for the denominator. A figure you cannot defend the base of is the first thing this probe finds. |
| D2 | "What's the assumption behind the £4M you'd defend least?" | EXP | [grounded] "roughly £4M of influenced revenue" (your message) | Name the weakest assumption before they do, in your own words. If you cannot name one, say you have not looked for it. Then say what would change the number if that assumption were wrong. | The weakest-assumption move. It turns a gotcha into a credibility point. |
| D3 | "What would you measure at month six to know operator partnerships are working?" | JD | [grounded] "where you'd take our operator partnerships over the next 18 months" (recruiter email, as quoted in your message) | Name two measures an operator would recognise, one partner-side measure, and the measure that would look good while the operator gets no better off. Keep it to a plan. | A metrics problem drawn from the recruiter's own line. The decoy measure is the probe's real target. |

### Conversational, weight 2

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Talk us through the journey, from the planning side to partnerships." | EXP | [grounded] "bus and light rail network planning" (your message), "took it from 6 partners to 40, roughly £4M of influenced revenue" (your message) | A 90-second arc in this order: the planning side, the channel, why operators. Use your quoted words, and do not add a stage the quotes do not carry. | A rapport opener that is still scored. Keep it short. |
| E2 | "Which part of this role do you expect to be hardest for someone who has never sold into rail?" | JD | [grounded] "Never sold into rail specifically" (your message) | Plain first: "I haven't sold into rail." Then the part you think is hardest, as your view, and the first thing you would learn about it. Do not claim to know how the company's sales cycle runs. | A casual question about a flagged topic, still scored. |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What have the operator partnerships delivered so far, and which operators are buying through them?" | It is the question the POV is about. It shows you came to learn the current state, not to pitch. |
| R2 | "Which conclusion in last quarter's market report do you most want challenged?" | It names the report you read and invites the departure the POV needs. It shows you read it as a thinker, not a copier. |
| R3 | "How is revenue from operator partnerships split between partner-sourced and direct today?" | It shows commercial literacy before Ross presses on it. |
| R4 | "What would make this hire look like a mistake a year in?" | It shows Deepa what success looks like to them, and it tests the Skeptic's objection from the other side. |
| R5 | "What would the first six months need to have proved, in numbers you would hold me to?" | It pins the target, which is what Ross's pressure is really after. |
| R6 | "How much of the role's time is spent with operators themselves, compared with the partners who sell to them?" | It shows you think operator-first, which is the POV's close. |

No reverse question ties to an interviewer's path, because no interviewer profile was given. Reciprocity is not needed: neither panel member is a peer.

## Prohibited claims

Each entry has its basis and its honest form. No answer slot, hold, bridge or reverse question asserts, softens or implies a listed claim.

| Not coached | Basis | Honest form |
|---|---|---|
| "I've sold into rail," or any rail sales record | Stated negative: "Never sold into rail specifically" (your message). Sourced entry | "I haven't sold into rail." Plain acknowledgment, from your own message |
| "I carried a quota," "I hit quota" | Stated negative: "never carried a direct quota, only influenced revenue" (your message). Sourced entry | "I haven't carried a direct quota." Plain acknowledgment, from your own message |
| "I generated £4M," or "I drove the £4M" | Inflated form of "roughly £4M of influenced revenue" (your message). Inflated-form entry | The quoted figure at its own scope. Limit, in the pack's analysis: your material says influenced, not generated or sourced revenue. Never a first-person negative |
| "I ran operator timetables," or "I know how operators run scheduling" | Inflated form of "bus and light rail network planning" and "so I know the operator world from the other side" (your message). Inflated-form entry | "Bus and light rail network planning", at its own scope. Limit, in the pack's analysis: your material says network planning, not operating timetables |

Not listed: "I have managed a team of partnership managers." Your material is silent on it, so it is an answer slot (B3), not a prohibited claim.

## Sources

Provided documents: the recruiter's email as quoted in your message, and your background as stated. The market report was not provided, so it was not read.

Research tier: L1, searches 3 of 6, fetches 0 of 2. User links read 0.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Kelverton Rail values | unavailable | Search refused. Would have moved the values cheat sheet, which is not triggered here: no values-style round is detected |
| 2. Kelverton Rail interview process | skipped | The recruiter's email fixes this round's panel, length and format, which is every output this target feeds in session mode |
| 3. Kelverton Rail strategy and news | unavailable | Search refused. Would have moved the company-strategy questions (A4, C5) and a grounding brief |
| 4. Deepa and Ross, with Kelverton Rail | unavailable | No call sent: the host refused search. Would have moved persona weights and a reverse question tied to their path |
| 5. Representative JD for the title | unavailable | No call sent: the host refused search, and no JD was supplied. Would have moved the fit snapshot requirements |

Un-numbered: a further search outside the declared targets, "Kelverton Rail scheduling software train operating companies". Refused. Moved nothing.

Queries sent and their outcomes: "Kelverton Rail values" (target 1), refused. "Kelverton Rail strategy news" (target 3), refused. The un-numbered query above, refused.

## Upgrade menu

- The market report's headline recommendations or shortlist (paste them) → the POV can depart from the consensus answer. Without them, the differentiation step is open.
- The JD text → fit rows F1 to F5 take their requirements from the JD's own lines, and the JD-tagged questions anchor to them.
- Public footprint for Deepa and Ross (talks, career paths) → persona weights per member, and a reverse question tied to their path.
- A search that works in this session → a company values, process and strategy pass. That grounds A4 and C5 and adds a grounding brief. A deeper strategy pass is available on request, with its caps and time stated.
- Any real experience of leading people → F5 becomes a grounded row, and B3 becomes a story rather than a slot.
- A `tuesday-dossier.md` carrying this pack's gaps into later rounds, if you want it.
