# Kelverton Rail: Senior Partnerships Manager, second-round prep pack

**Panel (60 min):** Deepa, VP Partnerships (future manager), and Ross, Commercial Director. First 15 minutes: a spoken POV (no slides) on operator partnerships over the next 18 months, landing on what it means for the operators. Remaining time: Q&A, with Ross pressing on commercials.

**Research tier: L0.** The three searches sent were refused, so no public research ran. Company values, loop structure and strategy are not in this pack. Anything not traceable to your message or the recruiter's quoted words is labelled `[generic]`.

## 1. How to use + type key

- **Personas** describe how a question arrives. **Types** describe what is being scored.
- **VAL** values alignment · **EXP** your experience, attribution · **JD** the role's requirements · **CO** company knowledge · **CASE** a live problem.
- The guidance is scaffolding, not a script. Say it in your own words, and rehearse what you actually did.

## 2. Prep triage (about 4 hours)

1. **60 min:** Give the POV aloud twice, timed at 15 minutes. Choose one thesis from section 5 and write the operator-close sentence.
2. **45 min:** Ross bank A1–A5. Drill A2 and A3 (how the £4M was counted, and what "influenced" means).
3. **45 min:** D1, the highest-return prep in this pack. Say the rail and quota answer aloud three times, to the end of its follow-up levels.
4. **30 min:** Case bank C1–C2 (live problems), using the clarify-first structure.
5. **20 min:** B bank and E1 (your journey, in 90 seconds).
6. **20 min:** Reverse questions. Pick three.

Everything else is insurance.

## 3. Fit snapshot

Requirements come from the recruiter's words (quoted in your message) and your role title. No JD was supplied. Evidence is quoted from your message only.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "where you'd take our operator partnerships over the next 18 months" (recruiter, via your message) | "Before that, 5 years in transport consulting (bus and light rail network planning), so I know the operator world from the other side." (your message) | medium | [grounded] | transferability | Your sentence says you know the operator world from the planning side, not that you have run partnerships with operators. Say it in those words. Answer slot: name one operator decision your POV depends on. If you have not seen that decision made, say so and say how you would test it. |
| F2 | "Senior Partnerships Manager" (your message) | "9 years in partnerships" (your message) | medium | [grounded] | none | No gap. Lead with the nine years in those terms. |
| F3 | "Ross will push on commercials." (recruiter, via your message) | "took it from 6 partners to 40, roughly £4M of influenced revenue" (your message) | medium | [grounded] | presentation | Reword only this sentence: "I took it from 6 partners to 40, roughly £4M of influenced revenue." The limit, in the pack's analysis: the figure is influenced, not direct. Expect the defend-the-number slots in section 6. |
| F4 | "Ross will push on commercials." (recruiter, via your message) | "Never sold into rail specifically and never carried a direct quota, only influenced revenue." (your message) | medium | [grounded] | capability | Your stated absence. Words: "I haven't carried a direct quota. What I've carried is influenced revenue." Then how you would take on a direct number, as a plan and never as a past. |
| F5 | "sell scheduling software to train operating companies" (your message) | "Never sold into rail specifically" (your message) | medium | [grounded] | capability | Your stated absence. Words: "I haven't sold into rail." Operator-side knowledge (F1) is adjacent. It is never a claim of rail sales. |

**Gate rows:** none. The material is silent on location, office pattern and right to work. If the JD sets any of these, they become `hard_gate` rows.

## 4. Persona weights

Panel: Deepa's hiring-manager prior is Case/Strategist plus Skeptic. Ross is the commercial director, and the recruiter said he will push on commercials, so his weights are Pressure plus Prober. There is no interviewer profile, so these rest on relationship priors only. No values round is detected: no loop source is in hand.

| Persona | Likelihood and reasoning | Depth | Counter-strategy |
|---|---|---|---|
| Pressure (Ross) | **High.** The recruiter named him as the commercial pusher. | 5 | Pause, restate, anchor in your quoted sentence. Hold a position through two follow-ups, then concede the exact limit. |
| Data-Driven Prober (Ross) | **High.** The £4M figure invites a count-the-denominator probe. | 4 | Name the weakest assumption before he does. Say plainly what you do not know. |
| Case/Strategist (Deepa) | **High.** The POV is a live problem about her roadmap. | 4 | Clarify, then structure, then answer. Say the framework aloud. |
| Skeptic (Deepa) | **High, on the rail and quota gaps.** The gaps are stated in your own words. | 3 | Rehearse the one objection until it is boring. Acknowledge plainly, bridge only from adjacent evidence. |
| Conversational | **Low.** Second-round openers are sometimes casual. | 2 | Treat any casual question as scored. |

## 5. Graded deliverable: the 15-minute POV

Facts to build on: F1 ("I know the operator world from the other side") and F3 ("took it from 6 partners to 40, roughly £4M of influenced revenue"). Nothing else about your past goes in the POV.

Suggested timing: 2 min why you can speak to operators (E1's first and second sentences); 5 min your thesis and its reasons; 5 min the first six months; 3 min the operator close.

**Choose one thesis, and give its concession aloud.**

- **T1. Build operator partnerships around the operator's own planning, not our release calendar.** `[generic]` sector pattern, not a claim about Kelverton. Concession: "I haven't sold into rail, so I would first test which operator decision our product changes before I build around it."
- **T2. Measure operator partnerships on an operator outcome, not only our revenue.** Basis: F3 at its own scope, plus `[generic]` sector pattern. Concession: "I've been measured on influenced revenue. I'd need the operators' own measures before I trust this one."
- **T3. Go deep with a few operators before adding partners.** Basis: F3 ("took it from 6 partners to 40") at its own scope, plus `[generic]` sector pattern. Concession: "Breadth worked in payments ISVs. Whether operators buy the same way, I don't yet know."

**Differentiation.** I have not seen the market report's consensus answer. Paste its operator section and I will write the anti-pick. Until then, the conditional anti-pick is: "a partner whose operator would not change its timetable process at all." Label it as your view, not as a finding.

**The requested close: what it means for the operators.** Land on one change for an operator's planners or customers within 18 months, stated as a measure the operator would recognise. Answer slot: name that measure. If you do not know how operators measure it, say so and say how you would find out.

## 6. Question banks

Question types: CASE and CO are `[generic]` here, because no company research ran.

### A. Pressure (Ross), 5 questions

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Sixty seconds: why should we trust a partnerships person with no quota to own our commercial numbers?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | Pause, then restate: "I haven't carried a direct quota. What I've carried is influenced revenue." Add the figure in your own words, then how you would take on a direct number as a plan. Do not soften the first sentence. | F4 is the stated gap Ross will open with. |
| A2 | "How much of that £4M was actually you?" | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" and [grounded] "Last 4 at a payments company running the ISV channel" | Say what you ran: the channel. Say what is shared: the influenced figure across it. Answer slot: which part you can point to as your decisions, in your own words. If you cannot separate it, say so plainly. Hold through two follow-ups; concede the split once. | F3 is the commercial figure most likely to draw a probe. |
| A3 | "What does 'influenced' mean to you, and what would you say to a finance director who doesn't accept it?" | EXP | [grounded] "roughly £4M of influenced revenue" | Give the definition you used, in your own words. Answer slot: if someone else set the rule, say so; if you do not know the rule, say that and name who would. | F3 and F4 together: a definition you cannot repeat is worse than none. |
| A4 | "That's a partner channel in payments. Why would a train operating company buy the same way?" | JD | [grounded] "Last 4 at a payments company running the ISV channel" and [grounded] "Never sold into rail specifically" | Name the one thing that transfers, which is partners as a channel. Name the one thing you have not seen: how operators buy from a vendor. Concede that you do not know their buying process yet. | F5 is what this question tests; the payments sentence is the one thing that transfers. |
| A5 | "Give me the number you'd commit to in year one." | JD | [generic] | Do not invent a number. Answer slot: a number only if you can say what it is built on. Otherwise: "I'd set it after the first conversations with operators, and here is what I'd measure first." | Time-boxed pressure. A plan figure is not a claim. |

### B. Data-Driven Prober (Ross), 4 questions

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Walk me through how the £4M was counted." | EXP | [grounded] "roughly £4M of influenced revenue" | Say the counting rule in your own words. Name the assumption you would defend least before he asks. Answer slot: if you cannot describe the rule, say so and name who would know it. | F3's defend-the-number slot. |
| B2 | "Of the 40 partners, which ones do you count in the £4M, and which don't you?" | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" | Answer slot: say which partners you counted and why, in your own words. If there was no such rule, say so plainly. | Presupposes a counting rule the quote does not state, so the second branch allows that there was none. |
| B3 | "What would you check first if the £4M were half of what it looks like?" | JD | [generic] | Name the first assumption you would test, and how. Make no claim about your past. | A hypothetical about the figure, not a fact about it. |
| B4 | "How would you judge whether a partner added to the channel was worth it?" | JD | [generic] | Name one measure you would use, and say what would make you drop a partner. | Tests judgment without a claim about your history. |

### C. Case/Strategist (Deepa), 4 questions

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A train operating company says their planners cannot draft timetable changes fast enough with our scheduling tool. They want a partner route, not an escalation. What do you do in the first 30 days?" | CASE | [generic] | Clarify first: which planners, which change, how often. Then segment the operators. Then your approach, your metrics and your risks, in that order. Say the framework aloud. | Deepa's live problem. Hypothetical, so no past to claim. |
| C2 | "Which operator would you start with, and why that one?" | CASE | [generic] | Name the criteria first: exposure to the problem, willingness to pilot, a named planning lead. Do not name an operator as a fact. | Tests prioritisation. |
| C3 | "Name one thing you would stop doing in a partnerships team in your first quarter." | JD | [generic] | Name one practice and say what you would replace it with. No claim about your current team. | A manager's question about judgment. |
| C4 | "What does a partner look like that you would turn down?" | JD | [generic] | Name the anti-pick criterion: a partner whose operator would not change anything in its planning. | The differentiation answer from section 5. |

### D. Skeptic (Deepa), 3 questions

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You've never sold into rail, and you've never carried a direct quota. Why should we believe this hire works?" | JD / EXP | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." and [grounded] "so I know the operator world from the other side" | **The highest-return rehearsal in this pack. Three levels.** Level 1: "I haven't sold into rail, and I haven't carried a direct quota." Level 2, "so what's the case?": "From 6 partners to 40, roughly £4M of influenced revenue, and five years on the operator side planning bus and light rail networks." Level 3, "which part transfers?": the operator-side knowledge, "I know the operator world from the other side". Concede once: "I'd be learning the sales motion on the job, and I'd say so early." Hold through two follow-ups. Never add a sale or a quota. | This is the most predictable objection to you, and it is stated in your own words. |
| D2 | "Why now, and why this company rather than an operator-side role?" | JD | [generic] | Answer slot: give your reason in your own words. The material has none stated, so do not supply one. | A motivation probe. |
| D3 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | Say it plainly: rail selling and a direct number, which you have said you have not done. Then the ramp. | Asks for the honest gap; the answer is the stated absence. |

### E. Conversational, 2 questions

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | JD | [grounded] "9 years in partnerships" · [grounded] "5 years in transport consulting (bus and light rail network planning), so I know the operator world from the other side" · [grounded] "Last 4 at a payments company running the ISV channel" | A 90-second arc in that order: partnerships, the operator side, the payments channel. Add no reasons for moves that your material does not state. | An open prompt, scored casually. |
| E2 | "What are you reading about operator partnerships at the moment?" | JD | [generic] | Name one point from the market report, in your own words. If you have not read it closely, say so. | Scored casually. The report is not in this pack yet (see upgrade menu). |

### Requirement coverage

| Stated requirement (source) | Covered by |
|---|---|
| "where you'd take our operator partnerships over the next 18 months" (your message) | POV build; C1; C2 |
| "Please land on what it means for the operators themselves." (your message) | POV close; C2 |
| "Ross will push on commercials." (your message) | A1–A5; B1–B4 |
| "sell scheduling software to train operating companies" (your message) | D1; D3; A4 |
| "Senior Partnerships Manager" (your message) | D2; E1 |
| Any requirement with no question | None |

## 7. Reverse questions

Each has a "why it lands". No interviewer profile exists, so none is tied to a career path.

1. "What would a strong first year look like for this role, and which operator relationships would you want moved by then?" *Why it lands:* it puts the outcome first, before the commercial questions.
2. "How do you measure partnership success today: influenced revenue, direct revenue, or operator outcomes?" *Why it lands:* it surfaces the commercial frame before Ross does.
3. "Who owns the number when an operator and one of our partners both touch the same deal?" *Why it lands:* it tests the no-quota gap in a constructive way.
4. "What did the last person in this role wish they had known on day one?" *Why it lands:* it signals you are planning to join the team, not only the job.
5. For Ross: "From the commercial side, what would make an operator conversation a good use of your time?" *Why it lands:* it gives him a question he can answer well.

## 8. Prohibited claims

Built locally from the fit snapshot. No dossier was supplied.

| Not coached | Basis | Honest form |
|---|---|---|
| "I've sold into rail" or "I've sold to train operating companies" | Stated negative, F5 | "I haven't sold into rail." |
| "I carried a quota" or "I hit a direct number" | Stated negative, F4 | "I haven't carried a direct quota. What I've carried is influenced revenue." |
| "I owned operator relationships" or "I know operators from the inside" | Inflated form of F1 | F1 at its scope: "I know the operator world from the other side." The pack's observation: the material says planning work on the operator side, not partnerships with operators. |
| "I generated £4M" or "my £4M" | Inflated form of F3 | "roughly £4M of influenced revenue", at its scope, across the channel. The limit: influenced, not direct. |
| "I built the ISV channel" | Inflated form of "running the ISV channel" | "running the ISV channel" |

## 9. Sources

- **Provided:** your message (background, the company description, the role title, and the recruiter's quoted lines).
- **Not in hand:** the recruiter's market report. You said you have read it, but its text is not in this conversation, so nothing in this pack draws on it.
- **Searches sent, all refused** (permission not granted):
  - "Kelverton Rail values"
  - "Kelverton Rail interview process partnerships"
  - "Kelverton Rail strategy news"

**Target accounting**

Research tier: L0. The L1 searches were sent and refused.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Kelverton Rail values` | unavailable | Would have supplied the values cheat sheet. No values round is detected, so none is included. |
| 2. `Kelverton Rail interview process partnerships` | unavailable | Would have confirmed the loop structure. Persona weights rest on relationship priors. |
| 3. `Kelverton Rail strategy news` | unavailable | Would have fed the CO bank and grounded the POV theses. Without it, the theses are `[generic]`. |
| 4. Deepa and Ross public footprint | unavailable | Would have shaped persona weights and a career-path reverse question. No call was sent. |
| 5. Representative JD | unavailable | Would have supplied requirement lines. Your recruiter's words stand in. No call was sent. |

## 10. Upgrade menu

- **The job description text** → the recruiter's words become a full requirement list, and the coverage table checks every mid-list item.
- **The market report's operator section, pasted** → the POV anti-pick is written for you; CO questions become `[grounded]`.
- **Permission to search** → rows 1–5 above run, and the Deepa and Ross footprints can shape the reverse questions.
- **The interviewer's public profiles, if you can paste them** → persona weights tuned per panel member, and a career-path reverse question.
- **A `tuesday-dossier.md` from job-underwriter** → verified evidence, and an absolute list of claims to avoid.
