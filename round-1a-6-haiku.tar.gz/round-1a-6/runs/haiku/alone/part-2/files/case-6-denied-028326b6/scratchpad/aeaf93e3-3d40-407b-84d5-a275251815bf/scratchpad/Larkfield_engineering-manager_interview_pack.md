# Interview prep pack: Engineering Manager, Larkfield Systems

Prepared for Yusuf. Loop mode: three rounds, one shared fit snapshot, then a mini-pack per round.

- Round 1: hiring manager, Director of Engineering, 45 min
- Round 2: panel, two staff engineers and a product manager, 60 min
- Round 3: VP Engineering, 30 min, "values and leadership philosophy"

Built without a posting or a CV. Web search was refused in this session, so nothing about Larkfield itself is researched (see Sources).

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what it scores.
- **Question IDs** read round, then persona letter, then number: `1-D1` is round 1, Prober, question 1.
- **Priority order:** `1-D1` first, because the same 60% figure comes back in all three rounds. Then `1-B2`, the hardware line. Everything else is depth.
- **Guidance is scaffolding, not a script.** Say it in your own words. If a sentence in the guidance is not something you would say about your own work, cut it.
- **Answer slot:** an instruction for the interview, not a question for you. Your material does not show the thing it names, so either honest branch is a valid answer.

| Tag | Name | What is being scored |
|---|---|---|
| VAL | Behavioral / values | Whether past behavior shows the approach the round names |
| EXP | Experience deep-dive | Whether your stated experience survives a probe, and exactly what was yours |
| JD | Role-driven | Whether you can do what the role text lists, including its gaps |
| CO | Company and strategy | Homework depth. None was possible this session, so CO items here are labeled generic |
| CASE | Live problem | Structure and reasoning on a problem from this role |

## Fit snapshot (shared across rounds)

Requirements come from the role text in your message. It is a summary, not the posting, so each quote in the requirement column is the wording you gave, not the posting's.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" (role text in your message) | "3 as a team lead of 6" — your message | medium | [grounded] | transferability | Your words are one team: "3 as a team lead of 6." Two squads and device-management services are not in them. Limited proof, nothing inspectable, so expect a probe. Say in your own words what the team of 6 did. What carries over to two squads is yours to argue; the sentence does not argue it for you. |
| F2 | "own delivery" (role text in your message) | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" — your message | medium | [grounded] | presentation | The bridge only reorders what you said: "I pushed a reliability quarter through against roadmap pressure." Keep the 60% attached to "after", not "because". Limited proof, so expect a probe. The sentence shows delivery under pressure; it does not show what the squads' delivery looked like day to day. |
| F3 | "hiring", from "own delivery, hiring and growth for 11 engineers" (role text in your message) | "I run our hiring loop for backend roles" and "about 40 interviews last year" — your message | medium | [grounded] | presentation | Say it in your words: "I run our hiring loop for backend roles," and about 40 interviews last year. Limited proof, so expect a probe. The role asks about hiring for eleven engineers across two squads. Your sentence is a loop for backend roles. The 40 is interviews, not hires. |
| F4 | "growth", from "own delivery, hiring and growth for 11 engineers" (role text in your message) | none given | none | [grounded] | discovery | Answer slot: say what you have done to help one engineer grow, in your own words. If nothing comes to mind, say so plainly, then say how you would start with eleven. |
| F5 | "partner with hardware and product on roadmap" (role text in your message) | none given | none | [grounded] | discovery | Answer slot: if you have worked with a hardware team on a roadmap's dates or constraints, say how, in your own words. If you have not, say so, and say how you would learn what hardware needs before a date is set. |
| F6 | "partner with hardware and product on roadmap" (role text in your message) | "never owned a hardware-adjacent roadmap" — your message | none | [grounded] | capability | Plain acknowledgment, in your words: "I've never owned a hardware-adjacent roadmap." Then how you would learn the hardware constraints, said as a plan, never as a past. This row closes nothing about partnering; F5 carries that. |
| F7 | Managing managers. Not in the role text; included because you named it as a gap | "I've never managed managers" — your message | none | [grounded] | capability | Plain acknowledgment, in your words: "I've never managed managers." The closest sentence is "3 as a team lead of 6" (F1). Whether this row is live depends on whether the two squads have team leads under them. See the upgrade menu. Then a plan, not a past. |

**Gap type reading:** F6 and F7 are stated absences, so they are `capability`, and their words come from your own sentences. F1, F2 and F3 are where your material is real but thin. F4 and F5 are silence, so they are `discovery`: the honest answer is an answer slot, not a claim.

### Requirement coverage

| Requirement | Covered by |
|---|---|
| Lead two squads building device-management services | 2-E3, 2-G1 |
| Device-management services (the product) | 1-A2, 2-E3 |
| Own delivery | 1-D1, 2-E4 |
| Own hiring | 1-A4, 1-D2, 2-F3 |
| Growth | 3-I4 (no round 1 or 2 item: the material has nothing on growth, and 3-I4 carries the honest answer) |
| Eleven engineers | 2-G1, 3-I4 |
| Partner with hardware and product on roadmap | 1-A3, 1-B2, 2-G2, 3-J3 |
| Managing managers (not in the role text; you named it) | 1-B1, 1-B3, 3-J2 |
| Values and leadership philosophy (recruiter's words) | 3-I1, 3-I2, 3-I3, 3-I4 |

## Prohibited claims

Built locally from the fit snapshot. These are the claims a candidate reaches for under pressure. No answer, hold, bridge or rationale in this pack asserts, softens or implies them.

| Not coached | Basis | Honest form |
|---|---|---|
| "Caused the 60% drop" | Inflated form of F2. Your sentence says "after" | "After", at its scope. The pack's observation, not words for you: your material says after, not because |
| Any ownership of a hardware roadmap | Stated negative, F6 | "I've never owned a hardware-adjacent roadmap." Plain acknowledgment, no slot |
| "I've managed managers" | Stated negative, F7 | "I've never managed managers." Plain acknowledgment, no slot |
| "I led eleven engineers" or "I ran two squads" | Inflated form of F1. Your sentence is a team of 6 | "3 as a team lead of 6", at its scope |
| "I owned hiring for the company" or "I set the hiring plan" | Inflated form of F3 | "I run our hiring loop for backend roles." The 40 is interviews, not hires |

## Round 1: Hiring manager (Director of Engineering), 45 min

### Persona weights

| Persona | Questions | How it shows up | Why this weight | Counter-strategy |
|---|---|---|---|---|
| Case/Strategist | 4 | Live problems on the roadmap they own | Hiring-manager prior: they are buying capability and checking the role's roadmap items | Clarify, then structure. Say the decision rule aloud |
| Skeptic | 3 | Cross-examines your two stated negatives | Hiring-manager prior, and F6 and F7 are the obvious lines | Plain acknowledgment first, then a plan, not a past |
| Conversational | 2 | A biography opener, and "anything for me?" | Low weight, but scored | Ninety-second arc in time order |
| Data-Driven Prober | 2 | Counts the 60% and the 40 interviews | Low here, but the figure is your own sentence, so expect it | Say what you counted, and say when you didn't |

No interviewer profile exists, so there are no interviewer-signal adjustments. Your round schedule came in your message, which establishes the loop, so no archetype fallback is used.

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 1-A1 | "The role partners with hardware and product on the roadmap. What do you need to know in your first 30 days before you change anything?" | CASE | [grounded] "partner with hardware and product on roadmap" (role text) | Clarify before structuring: what each team owns, what is fixed, which decisions are open. Name two or three facts you need and who holds them. Do not describe a roadmap you ran | A live problem from the role text. The question presupposes nothing about your past |
| 1-A2 | "A device fleet's failed updates rose this month. Walk me through how you'd diagnose it." | CASE | [generic] | Clarify scope: which devices, which versions, since when. Split the cause across device, firmware and service. Name the metric you'd check first and the risk you'd check last. If you have worked a failure of this kind, say which step you would lean on, in your own words. If not, say so plainly | A live reliability problem in a device-management service. Generic because it is a pattern for this kind of service, not a fact about Larkfield's fleet |
| 1-A3 | "Two squads, one roadmap that hardware and product also shape. When hardware and product disagree on sequence, how do you decide what goes first?" | JD | [grounded] "partner with hardware and product on roadmap" (role text) | State the decision rule and who holds the final call. Name what you would need from hardware before agreeing a date. Hold your rule through one push, and concede what you don't yet know about hardware's constraints. Say what you would do this week | F5 and F6 are why this is the probe: your material has no hardware roadmap in it |
| 1-A4 | "Walk me through how you'd set the hiring plan for these eleven engineers." | JD | [grounded] "I run our hiring loop for backend roles" and "about 40 interviews last year" (your message) | Say what you run today, in those words: "I run our hiring loop for backend roles." Scale: "about 40 interviews last year." Answer slot: if you set a hiring plan or headcount, say how and what you counted. If you did not, say so plainly, then say how you would build one | F3. The role asks for hiring ownership, and the loop is your nearest sentence. Keep interviews and hires apart |
| 1-B1 | "You've never managed managers. What makes this different from what you've done?" | JD | [grounded] "I've never managed managers" and "3 as a team lead of 6" (your message) | Plain acknowledgment first: "I've never managed managers." Then the nearest sentence your material carries: "3 as a team lead of 6," one team. Then what you would do to learn a layer of leads, as a plan. Hold through one follow-up, then concede plainly if the gap is real | F7. The premise is your own negative, so the sentence is yours to say. Live only if the squads have leads under you; see the upgrade menu |
| 1-B2 | "Hardware and product set the constraints on this roadmap. You've never owned a hardware-adjacent roadmap. Why would we trust you with one?" | JD | [grounded] "never owned a hardware-adjacent roadmap" (your message); "I pushed a reliability quarter through against roadmap pressure" (your message) | Second-highest-ROI prep in the pack. Open with the plain acknowledgment: "I've never owned a hardware-adjacent roadmap." Then the bridge at the quote's own scope: a reliability quarter you pushed through against roadmap pressure. That is roadmap pressure, not hardware. Answer slot: if you have worked with a hardware team on dates or constraints, say how. If not, say so, and say how you would learn what hardware needs before you set a date. Hold through two follow-ups by returning to what you would do, never by adding a hardware story | F5 and F6. The stated absence is the line most likely to be pressed, and the bridge must not stretch the reliability quarter into hardware experience |
| 1-B3 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "never owned a hardware-adjacent roadmap" and "I've never managed managers" (your message) | Name the two gaps yourself before they do, in the words you already have: the hardware roadmap, and leads if the squads have them. Give one concrete first step for each. Do not name a third gap you have not checked | A Skeptic opener that lets you choose the frame. F5, F6 and F7 are your own gap statements |
| 1-C1 | "So — walk me through the journey." | EXP | [grounded] "9 years engineering," "3 as a team lead of 6," "currently at a payments company," "I run our hiring loop for backend roles" (your message) | Ninety-second arc in time order: nine years in engineering, three as a team lead of six, now at a payments company, and the hiring loop you run for backend roles. Keep each beat at its sentence's scope. Leave the reliability quarter for 1-D1 unless asked | A biography is scored as much as any probe. The pack's job here is to keep it short and in your own sentences |
| 1-C2 | "What made you want to look at this role?" | EXP | [generic] | Name one thing in the role text you want to work on, in your own words, and why, if you can say it. Your material gives no reason for this role, so none is repeated here. Answer slot: if you have a reason, say it. If you don't have one yet, say so and name what you would want to find out | Motivation consistency is scored by a hiring manager. The role text is the only source for this answer |
| 1-D1 | "Your team's on-call burden dropped 60%. Walk me through how that was counted." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" (your message) | **Highest-ROI prep in the pack.** Deepest rehearsal here. Follow three levels. (1) What the 60% measures and over what window. Answer slot: if you can say the baseline and the window, say them. If not, say you would check. (2) What else changed in that period. Answer slot: name what you know, and say which part was yours. (3) The assumption you would defend least; name it before they do. Keep the sentence's word, "after," not "because." Claim the quarter caused the drop only as far as you can show it, and concede plainly what you can't | Every round's prober returns to this figure. It is your own sentence and the most-checked line in the pack. 2-F1 and 3-J1 reuse it |
| 1-D2 | "About forty interviews last year. How many of them were yours to run, and what did you count?" | EXP | [grounded] "about 40 interviews last year" and "I run our hiring loop for backend roles" (your message) | Say the number you ran, if you can count it, and whose the other interviews were. Answer slot: if you tracked anything about those interviews, say what. If you didn't, say so plainly | The interview count is the only hiring figure in your material. A prober will ask what it measures |

### Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "What would make this role a success in its first year, in your team's own terms?" | You hear their criterion before you describe your fit against it |
| 2 | "How do the two squads and the hardware team split ownership of the device interface today?" | Turns the roadmap partnership into a concrete seam. Shows you are listening for the part of the role you are least sure of |
| 3 | "What would you want a new manager to have sorted in the first 90 days?" | Their answer becomes your ramp plan, in their terms |
| 4 | "What does the hiring plan for these eleven engineers look like over the next two quarters?" | Ties to F3. Their answer shows how much of the hiring is yours |
| 5 | "Where would you expect me to need the most support?" | Hands them the gap on your terms. No interviewer profile exists, so none of these ties to their own career path; a name would add one |

## Round 2: Panel, two staff engineers and a product manager, 60 min

Assignments per panelist are not known, because their names are not. The personas below blend the top two of each member's likely relationship: staff engineers as peer and technical prober, the product manager as roadmap partner.

### Persona weights

| Persona | Questions | How it shows up | Why this weight | Counter-strategy |
|---|---|---|---|---|
| Peer Evaluator | 4 | Seam probes, "what would you need from us," disagreement | Top weight: two of three panelists are your future peers, and the product manager is a roadmap partner | Propose seam principles rather than a map you don't have |
| Data-Driven Prober | 3 | Counts, denominators, assumptions | Staff engineers read the CV closely | Name the weakest assumption before they do |
| Case/Strategist | 3 | A roadmap trade-off from the product manager | The product manager is the roadmap partner | Clarify, structure, then state a decision rule |
| Skeptic | 2 | Hardware and managing-leads gaps raised by a staff engineer | Low weight, same gaps as round 1 | Plain acknowledgment, then a plan |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 2-E1 | "Our teams sit side by side. Where's the seam between your squads and ours, and what happens when we disagree?" | JD | [generic] "I pushed a reliability quarter through against roadmap pressure" (your message) | Propose principles for the seam, not a map you don't have: who decides on interfaces, how disagreements get written down, what escalates. Then the nearest disagreement your material carries, in your words: who pressed, and how it resolved. If the other side isn't in your material, say so and say what you would want to hear from them | A peer probe on seam and disagreement. Your nearest sentence is about pressure, not a peer disagreement, so the second branch is needed |
| 2-E2 | "How do you handle credit when work spans teams?" | JD | [generic] | Pick a piece of work that spanned teams and say whose name went on it. If no such work comes to mind, say so plainly, then say how you would share credit on a cross-team project | Peer evaluators score credit-sharing. Your material holds no cross-team example, so the scaffold is the honest form |
| 2-E3 | "What would you need from the two staff engineers on device-management architecture in your first month?" | JD | [grounded] "Lead two squads building device-management services" (role text) | Name the decisions you would ask them to own and the ones you would keep. Say how you would find out what the existing architecture already commits you to. Answer slot: if you have made architecture calls on a service like this, say which and how. If not, say so plainly | The question names the service in your role text. Architecture experience is not in your material, so either branch is honest |
| 2-E4 | "Tell me about a dependency that slipped and what you did about it." | JD | [grounded] "own delivery" (role text); "I pushed a reliability quarter through against roadmap pressure" (your message) | Open prompt: pick a commitment that slipped under pressure. If the nearest one your material carries comes to mind, its beats are the sentence's: the on-call burden, the roadmap pressure, and that you pushed it through. If no slipped commitment comes to mind, say so plainly, then give the nearest | Delivery is the role's first duty. The story uses only the beats the sentence states; "dependency" is the interviewer's word, not yours |
| 2-F1 | "Walk me through how that 60% was counted." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" (your message) | The same probe as 1-D1, from a staff engineer who will read the counting. Use 1-D1's three levels. Answer slot on baseline and window: say them if you have them, and say so if you don't. Hold the "after"; do not upgrade it to "because" | A staff engineer is the likeliest person to ask for the denominator, so the figure gets a second, more technical probe |
| 2-F2 | "Which assumption behind that number would you defend least?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" (your message) | Name the weakest assumption in your own words before they do: which part of the drop you cannot attribute to the quarter. If you have not tested the number, say that, which is also an honest answer | The assumption you name is the one you will be asked to defend. Name only one you can defend |
| 2-F3 | "How do you tell whether the hiring loop is working?" | EXP | [grounded] "I run our hiring loop for backend roles" and "about 40 interviews last year" (your message) | Answer slot: if you measure the loop, say what you measure. If you don't, say so plainly and say what you would look at first. Keep to the loop, not the whole hiring plan | An open question about a practice your material doesn't show. Either branch is honest |
| 2-G1 | "Two squads, eleven engineers, one device-management service, and a roadmap that hardware and product both shape. How would you split the work between the squads?" | CASE | [grounded] "Lead two squads building device-management services" and "own delivery, hiring and growth for 11 engineers" (role text) | Clarify each squad's service boundary. Split on dependency and ownership, not on headcount. Name the one thing you would check before committing. Think aloud, and challenge one premise respectfully | Case scores structure on the role's own numbers. It makes no claim about your past, so there is no answer slot |
| 2-G2 | "A firmware rollout has stalled for a week. Hardware says the fault is on the device. Product wants the next release. What do you do?" | CASE | [generic] | Clarify which devices and which versions, what the evidence is, and who holds it. Separate the release decision from the diagnosis. Don't pretend to know hardware failure modes; ask what hardware needs to call it. Name the risk to the release and to the fleet, then hold a position you can defend | A live problem on the hardware and product partnership. Generic because it is a pattern, not Larkfield's fleet |
| 2-G3 | "You have one quarter: a device-onboarding flow from product, and reliability fixes from your squads. Which do you take first?" | CASE | [generic] "I pushed a reliability quarter through against roadmap pressure" (your message) | State the decision rule and the evidence you would need. Name what you would give up. Hold the choice through one push. If you cite reliability experience, use only the sentence's words | A trade-off with product. Your reliability sentence is the only candidate sentence near this, so it is the only one that may be cited |
| 2-H1 | "Why leave a payments company for an industrial IoT business?" | EXP | [grounded] "currently at a payments company" (your message); "industrial IoT" (role text) | Give your reason in your own words. Your material does not state one, so none is supplied here. Answer slot: name what draws you to device management and to industrial hardware, if those are true for you. If they are not yet, say so | Motivation consistency is the Skeptic's test. The premise comes from your current employer and the role's own description |
| 2-H2 | "What part of this would you rather not do?" | EXP | [generic] | Name one task you would hand off or find hard, and say what you would do about it. Don't say you enjoy everything | A Skeptic's honesty test. Calibrated candor beats a bluffed competency |

### Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "What could a new engineering manager do in the first month that would genuinely help your team?" | Reciprocity. Panel members are your future peers, and this shows you are offering as well as taking |
| 2 | "Which decisions on the device-management services do you want the manager to own, and which do you want to keep with the staff engineers?" | Decision rights are the seam. Their answer is the real shape of the job |
| 3 | "When hardware and product disagree on the roadmap, where does that get settled today?" | Shows you have heard the partnership line and want to know how it works in practice |
| 4 | "What is the hardest thing the squads have to get right in the next two quarters?" | Pulls the real risk into the open, where you can respond to it |
| 5 | "What would you want a new manager to keep doing from the current setup?" | Shows intent to build on what exists rather than reset it |

## Round 3: VP Engineering, 30 min, "values and leadership philosophy"

**Values round detected.** Your recruiter's words name one, "values and leadership philosophy," and that is a loop source.

**Values cheat sheet: not built.** Larkfield's published values are not in hand, and the search that would have fetched them was refused (see Sources). Without them, this round's questions use the recruiter's theme as their raising source, with open prompts and selection scaffolds. No company value name appears anywhere in this round. A pasted values page would change that (upgrade menu).

### Values-alignment read

A read of the theme against your sentences, not a mapping to any company value.

| Theme (from the recruiter's words) | Your sentence, verbatim (source) | Honest branch |
|---|---|---|
| Leadership philosophy under pressure | "I pushed a reliability quarter through against roadmap pressure" (your message) | If you can name the criterion you used, say it. If you decided on judgment, say that |
| Leading a team | "3 as a team lead of 6" (your message) | Say what the team did in your words. The sentence does not say what your leadership looked like |
| Growing people | "own delivery, hiring and growth for 11 engineers" (role text). Your material has no growth sentence | Answer slot: say what you have done to help one engineer grow. If nothing comes to mind, say so plainly |
| Telling leadership the hard thing | None given | Selection scaffold: pick a time you told someone senior something unwelcome. If none comes to mind, say so plainly, then give the nearest |

### Persona weights

| Persona | Questions | How it shows up | Why this weight | Counter-strategy |
|---|---|---|---|---|
| Values / Behavioral | 4 | Open prompts on the recruiter's theme | Guaranteed: the recruiter's words document a values round | Story selection with its honest branch, "I" for your part and "we" for context |
| Pressure | 3 | "How much of that was you," "sixty seconds" | Skip-level prior: composure and altitude | Pause, restate, hold two follow-ups, then concede precisely |
| Case/Strategist | 2 | A prioritization problem | Skip-level prior, strategy-heavy. Generic here because research didn't run | Clarify, then a decision rule |
| Conversational | 2 | "What's been the best part?" | Low weight, but scored | Answer in your own words |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| 3-I1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] "I pushed a reliability quarter through against roadmap pressure" (your message, nearest) | Selection scaffold: pick a time you told someone senior something unwelcome. It needs a stake, a moment you didn't fold, and the relationship intact at the end. If none comes to mind, say so plainly, then give the nearest: the reliability quarter, with the beats its sentence states, the on-call burden and the roadmap pressure, and that you pushed it through. Keep "I" for what you did and "we" for context | An open prompt on the recruiter's theme. The only sentence near "unpopular" is the reliability quarter, and only its stated beats may be used |
| 3-I2 | "What is your leadership philosophy? Give me a sentence or two." | VAL | [generic] | Write the sentence in your own words, then test it: can each of your stories carry it? If not, change the sentence, not the stories. Don't adopt a phrase you have not used before | A philosophy stated as a slogan that your stories don't bear out is the failure this round is built to catch |
| 3-I3 | "How do you decide when reliability work takes priority over roadmap work?" | VAL | [grounded] "I pushed a reliability quarter through against roadmap pressure" (your message) | Name the criterion you used then, if you had one. The stake your sentence states is the on-call burden. Answer slot: if you wrote down a criterion, say it. If the call was judgment, say so and say what you would weigh next time. Hold the position through one push. Don't claim a framework you did not use | The question presupposes a priority call, and your sentence states one made under pressure. The criterion is the honest gap |
| 3-I4 | "How have you helped someone on your team grow?" | VAL | [grounded] "own delivery, hiring and growth for 11 engineers" (role text) | Answer slot: say what you have done for one engineer's growth, in your own words, and what changed for them. If nothing comes to mind, say so plainly, then say how you would start with eleven | F4. The role asks for growth, your material shows none, and this row carries the honest answer |
| 3-J1 | "That result. How much of it was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" (your message) | Hold, then concede where it's true. Hold the part that was yours: you pushed it through. Concede the part you cannot show, in one sentence. Don't add a second figure to hold | The same attribution probe as 1-D1, at a pressure persona's altitude. A VP asking how much was you wants the concession made precisely |
| 3-J2 | "Sixty seconds: why should I give eleven engineers to you rather than someone who has managed managers?" | JD | [grounded] "I've never managed managers" and "3 as a team lead of 6" (your message) | Pause, then the plain acknowledgment: "I've never managed managers." Then the nearest sentence your material carries: "3 as a team lead of 6." Then the ramp plan, as a plan. Hold through two follow-ups. Don't argue the comparison | Pressure on F7 at the VP's altitude. The premise is your own negative |
| 3-J3 | "Hardware says the date can't move, and product says it has to. You have sixty seconds. What do you say?" | CASE | [grounded] "partner with hardware and product on roadmap" (role text) | State a decision rule in the first ten seconds. Name what you would need to be sure. Concede the uncertainty, not the rule. Don't describe a past instance | Pressure on F5 at the VP's altitude. No past is presupposed, so there is no answer slot |
| 3-K1 | "What should a device-management service optimize for in an industrial setting?" | CO | [generic] | Name two things the answer depends on: what downtime costs the customer, and what change you can safely make to a fleet you don't fully control. Then a view, and one thing you would measure | No Larkfield strategy was researched, so this is generic and labeled so. Don't cite the company's priorities unless you have read them |
| 3-K2 | "Two hardware variants, one fleet, a reliability goal and a release date. How would you prioritize the next two quarters?" | CASE | [generic] | Clarify the fleet's mix and how the goal is measured. Sequence by exposure, not by who asks loudest. Name the decision you would take to the VP, and what you would want the VP to decide | A live problem on the role's partnership. Generic scenario |
| 3-L1 | "What's been the best part of leading a team so far?" | EXP | [grounded] "3 as a team lead of 6" (your message) | Answer in one or two sentences, in your own words. Name what you actually found most satisfying or hardest. The material does not say, so don't supply it | A friendly opener that is scored as a values probe. The answer should be yours |
| 3-L2 | "What did the reliability quarter teach you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" (your message) | Give the lesson in your words, tied to the stakes the sentence states: the on-call burden and the roadmap pressure. Don't name a lesson your material doesn't show, and keep the 60% at its "after" scope | An open invitation to narrate. A lesson you cannot tie to something you did reads as spin |

### Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "How do you want a manager in this role to make the call between reliability and roadmap, and where does that decision sit?" | It is their philosophy, asked back, and it shows where decision rights sit |
| 2 | "What would you want a manager in this role to stop doing in the first quarter?" | Surfaces what they have seen fail, without you guessing it |
| 3 | "What has the strongest manager on your team done that the others have picked up?" | They describe their own standard for leadership |
| 4 | "What does success look like at the end of a year, from your chair?" | Their success criterion, from the altitude they hold |
| 5 | "What would you want a new leader to unlearn from their last role?" | Shows you expect to be coached, and tests how they think about it |

No interviewer profile exists, so none of these ties to the VP's career path. A name would add one.

## What to research yourself

Web search was refused in this session, so these are the questions a research pass would answer. Check each one against official pages only.

- **Larkfield's published values page.** Copy the exact value names. Round 3 is values-shaped, and names you can quote beat names you paraphrase. If there is no page, ask the recruiter for the written leadership principles.
- **Larkfield's careers page.** Does it describe the engineering interview loop? If it does, use it to confirm or correct the round structure in this pack.
- **The device-management product.** Which product or services the squads build, which devices they serve, and whether hardware is built in-house or by partners.
- **How hardware and software plan together.** Public talks, engineering blog posts, or job posts for the two squads. Their stated requirements are a useful second source for the role.
- **Recent organizational news.** Reorgs, leadership changes, layoffs or a hiring wave. A hiring wave changes what "growth for 11 engineers" is for.
- **Public profiles of the Director and the VP,** if you have their names. Career path only; no personal detail.

## Sources

**Provided documents:** your message, containing the role text, the three-round schedule, the recruiter's description "values and leadership philosophy," and your background. No posting text, CV, interviewer names, working-style assessment or dossier was provided.

**Research tier: L1, searches 0 of 6, fetches 0 of 2.** All three searches were refused by the session's permissions.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Larkfield Systems values` | unavailable | Values cheat sheet (section 10). Not built. Query refused |
| 2. `Larkfield Systems interview process engineering manager` | unavailable | Loop structure. Round order comes from your message, not from the company's documented process. Query refused |
| 3. `Larkfield Systems strategy` / recent news | unavailable | CO questions. Labeled generic instead. Query refused |
| 4. `{interviewer name} Larkfield Systems` | n/a | No names were given, so no query could be formed. The interviewer read is absent |
| 5. Representative `{role title}` JD | skipped | Your role text fixes the requirement rows. The upgrade menu asks for the full posting |

Queries sent, with outcome: "Larkfield Systems values" (refused); "Larkfield Systems interview process engineering manager" (refused); "Larkfield Systems strategy news industrial IoT device management" (refused).

## Upgrade menu

- The full posting → the requirement quotes become the posting's own words instead of your summary, and any requirement it adds gets its own fit row and question.
- Whether the two squads have team leads under you → decides whether F7 and 1-B1, 1-B3 and 3-J2 are live, or whether they become a ramp-plan exercise.
- Larkfield's published values page, pasted → the values cheat sheet, and per-value VAL questions in round 3. Right now the recruiter's words drive scaffolds only.
- The interview-process page or a candidate guide, pasted → confirms or corrects the loop. The loop is currently from your message alone.
- A strategy or recent-news page under six months old, pasted → the CO questions (3-K1 and the strategy branch of 3-K2) move from generic to grounded.
- The interviewers' names → persona weights from their public footprint, and one tailored reverse question per round.
- Stories you would tell for the unpopular-truth question (3-I1) and the slipped-dependency question (2-E4), in your own words → each becomes a quoted fit row, and the honest-branch slots shrink.
- Any hardware-team work, even if not a roadmap → F5 becomes a quoted row, and 1-B2's answer slot becomes a story.
- Your round dates → prep time sizing for the triage, and the order of the mini-packs against the calendar.
- Any location, office-days or work-authorization requirement → a gate row, if one applies.
- The recruiter's email, if it names a take-home or presentation → a build section for each deliverable.
