Your prep pack is saved as /tmp/claude-0/-var-tmp-tuesday-measure-1a6-runs-haiku-alone-part-2-rooms-case-8-canned-8ff93a2e/144e165c-4be0-4cf8-98ad-bba0d6fa2718/scratchpad/ashgrove_credit_union_member_experience_lead_interview_pack.md. I built it as a three-round loop from the recruiter's email, and I took the Head of Member Services as your future manager, as that email says. I ran no web searches, because your JD, the pasted values, the recruiter's email and your strategy summary already cover what research would have checked.

Say the word and I'll play the Head of Member Services on H1. That is the contact-centre and senior-presenting objection, and the pack names it as your highest-ROI prep.

I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.

If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove_credit_union_member_experience_lead_interview_pack.md -----
# Ashgrove Credit Union: Member Experience Lead, interview pack

Loop mode: three rounds on 5 December 2026. Built 26 November 2026.
Rounds: (1) recruiter, 30 min. (2) Head of Member Services, your future manager, 45 min, mostly behavioural. (3) Panel of two branch managers, 60 min, including a 20-minute complaint-escalation case and scored against the four values. No interviewer names yet.

## How to use + type key

Personas describe how each question is asked. Types describe what is being scored. Each question carries one type tag.

- **VAL**: behavioural and values alignment. Does past behaviour show one of the four published values?
- **EXP**: work-experience deep-dive. Does your record hold up when probed?
- **JD**: role-driven. Can you do the listed job, gaps included?
- **CO**: company and strategy knowledge.
- **CASE**: hypothetical or live problem.

Guidance is scaffolding, not a script. Say it in your own words.

Provenance labels: **[grounded]** traceable to your message, the JD, the recruiter's email or the values you pasted. **[inferred]** a derivation this pack made. **[generic]** a pattern for this kind of question, with no claim about Ashgrove or about you.

An **answer slot** is an instruction for the interview. It has two honest branches: say what you actually did, or say plainly that the practice was not yours or did not happen. It is never a question to answer here.

## Fit snapshot (shared across all three rounds)

Requirements are quoted from your JD. Evidence is quoted from your message. No row is a hard gate: none of the JD's requirements is a licence, location, schedule, pay or credential term, and years of experience are graded on fit.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" (JD) | "6 years in retail banking, the last 3 as a branch supervisor" (your message) | medium | [grounded] | transferability | The years are not the gap; the scope is. Your material says retail banking, and it does not say customer operations. Say it at that scope: "Six years in retail banking, the last three as a branch supervisor." Do not call it customer operations unless that is what the work was called. |
| F2 | "experience handling regulated complaints" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [inferred] | transferability | Formal complaints work is adjacent. Your material does not say those complaints were regulated, so do not say they were. Words: "At the branch I handled the formal complaints log." Answer slot: if a complaint in that log carried a regulated timescale or rule, say which and what you did; if none did, say so plainly. |
| F3 | "Own the member complaints process end to end across branches and the contact centre" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | transferability | One branch's log, not the process end to end across branches or the contact centre. Words: "I handled the branch's formal complaints log." Answer slot: if you decided how a complaint moved between the branch and anyone else, say what and how; if you did not, say so plainly. |
| F4 | "report monthly on complaint volumes and resolution times" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | medium | [grounded] | discovery | The spreadsheet touches the requirement but does not show whether it counted volumes, resolution times, both or neither. Answer slot: if it counted volumes or resolution times, say which and how you read them; if it counted neither, say so plainly and say what it did count. |
| F5 | "comfortable with Excel reporting" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | medium | [grounded] | presentation | The quote already reaches reporting in other terms. It does not name the software. Words: "I built the monthly complaints spreadsheet our regional manager uses." Name Excel only if the spreadsheet was in Excel. |
| F6 | "coach branch supervisors on escalations" (JD) | "trained new tellers on our escalation script" (your message) | medium | [grounded] | transferability | Tellers, not supervisors. Words: "I trained new tellers on our escalation script." Answer slot: if you coached anyone above teller level on escalations, say what you did; if not, say so and say what you would do with a supervisor whose escalation has gone wrong. |
| F7 | "work with digital teams on self-service journeys" (JD) | none given | none | [grounded] | discovery | Silence, not an absence. You have not said you lack this. Answer slot: if you worked on a customer journey alongside a digital team, say which and what was yours; if you did not, say so plainly, then say how you would start with that team. |
| F8 | "confident presenting to senior leaders" (JD) | "I've never presented to anyone above regional level" (your message) | none | [grounded] | capability | A stated absence. Words: "I haven't presented to anyone above regional level." Then how you would learn it, as a plan, never as a past. Add nothing to make it smaller. |
| F9 | "Own the member complaints process end to end across branches and the contact centre" (JD, contact-centre part) | "Never worked in a contact centre" (your message) | none | [grounded] | capability | A stated absence. Words: "I haven't worked in a contact centre." Then how you would learn the contact-centre side, as a plan, never as a past. |

**Routing note:** F8 and F9 are `capability` because you stated the absence. F7 is `discovery` because the material is silent. F4 is `discovery` because the quote touches the requirement without showing whether it reaches it.

## Grounding brief

From your summary of Ashgrove's July 2026 strategy brief. I have not seen the brief itself. The summary is under six months old, so it is treated as current.

- [grounded] "move 40% of member service to digital channels by 2028." Use this vocabulary when the digital shift comes up; it is the brief's target, not a number you need to defend.
- [grounded] "consolidate eight branches into five hubs over 2027." Relevant to where complaints get logged and who answers them. Ask about it; do not assume your branch is affected.
- [grounded] "launch a small-business lending product in Q1 2027." Context only. Expect it to shape the complaints volume and the team's priorities.
- [grounded] "the main competitive pressure is app-only banks." The competitive frame for any CO question about member experience.

## Round 1: recruiter screen (30 min)

**Loop source:** the recruiter's email, which sets this round's length and its place in three sessions. The loop is established, so no archetype fallback applies.

**Persona weights:** Conversational (top, 4 questions), light Skeptic (1 question). The three logistics questions are knockout checks in a friendly register. Reasoning: the recruiter-screen prior is conversational with a light skeptic, and the logistics questions are scored here even though the register is casual.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R1 | "Walk me through your career so far, in about two minutes." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | A 90-second arc: the six years, then the three as a branch supervisor, then the two things your message names. Say "I handled the branch's formal complaints log" and "trained new tellers on our escalation script" in those words. Do not mention the contact-centre or senior-presenting gaps here unless asked. | Conversational opener, scored for economy. F1 gives the beats. EXP because the arc is your own record. |
| R2 | "Tell me about a complaint you handled that you're proud of." | EXP | [grounded] "I handled the branch's formal complaints log" | Open prompt. Pick one case from the log and tell it in the order it happened. Answer slot: if no case comes to mind, say so plainly, then give the nearest thing the log carries, which is the handling itself. | F3 is the only complaints sentence you gave. The question chooses an instance; it does not supply one. |
| R3 | "Why are you looking to move now?" | EXP | [generic] | Instruction: give the reason in your own words, in one sentence, framed on what you want next. This pack supplies no reason. | Logistics question, the relationship prior's reason-for-leaving slot. |
| R4 | "What are your salary expectations for this role?" | JD | [generic] | Give your own figure or range, or ask for the band for this role first. This pack supplies no figure and no floor. If asked what you earn now: "I'd rather focus on the range for this role." | Logistics slot for pay. Your message gave no figure, so none is coached. |
| R5 | "What's your notice period, and when could you start?" | JD | [generic] | Give your actual notice period in your own words, and the earliest start you would commit to. | Logistics slot for notice. Your message gave none. |
| R6 | "Where would you be based, and how often would you need to be on site?" | JD | [generic] | Say which branch or hub you could work from and which office days you can keep, in your own words. If you do not yet know the site, ask the recruiter for it. | Logistics slot for location. Hub consolidation makes this a live question. |
| R7 | "You've never worked in a contact centre. What's your read on that?" | JD | [grounded] "Never worked in a contact centre" | Hold it plainly: "I haven't worked in a contact centre." Then how you would learn it, as a plan. Answer slot: if any of your complaint handling ran by phone or through a contact channel, say which; if none did, say so. | A knockout check in a friendly register. The panel and Head of Member Services will return to this, so the plain answer should be short and settled. |
| R8 | "What do you know about Ashgrove as a member-owned credit union?" | CO | [grounded] "we decide from the member's side of the counter" (published values) | Name one value in your own words and why it matters to your work. Keep it to what the pasted values say. | Homework depth at the recruiter's altitude. The values page is the only Ashgrove source this pack uses. |

**Reverse questions:**
- "Will the complaint case in the panel round be given in advance, or on the day?" Why it lands: it tells you whether the 20-minute case is rehearsal or live, and it is a process question the recruiter can answer.
- "What does the move from eight branches to five hubs mean for the team this role would lead?" Why it lands: it shows you read the strategy brief. The recruiter may not know; that is fine.

## Round 2: Head of Member Services (45 min, mostly behavioural)

**Persona weights:** Skeptic (top, 4 questions), Values/Behavioral (2), Case/Strategist (2), Data-Driven Prober (2). Reasoning: the hiring-manager prior is Case and Skeptic. The recruiter's "mostly behavioural" adds Values/Behavioral. The JD's monthly reporting line adds the Prober. The Skeptic is weighted highest because two gaps are stated in your own words.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "You've never worked in a contact centre, and you've never presented to anyone above regional level. Why should we hire you to own complaints across the contact centre?" | JD | [grounded] "Never worked in a contact centre"; "I've never presented to anyone above regional level" | **Highest-ROI prep in this pack.** Hold on the transfer only as far as your sentences go: "I handled the branch's formal complaints log" and "trained new tellers on our escalation script". Hold through two follow-ups by returning to those sentences, never by adding a contact-centre example. Then concede plainly: "I haven't worked in a contact centre. I haven't presented to anyone above regional level." Then the plan: how you would learn the contact-centre side and where you would first present, as a plan. | The two stated absences are the most predictable objection to you, and this question joins them. Rehearse the non-defensive concession until it is boring. |
| H2 | "Tell me about a complaint that had a regulated timescale or rule attached. What did you do?" | JD | [grounded] "I handled the branch's formal complaints log" | Story map from the log: you handled it, and nothing more is stated. Answer slot: if a complaint you handled carried a regulated timescale or rule, say which and what you did; if none did, say so plainly and describe how the log ran. | Covers the JD's "experience handling regulated complaints" line. Your message does not say the complaints were regulated, so the answer is yours to supply. |
| H3 | "Sketch how you'd own complaints across branches and the contact centre in your first six months. What do you need to know first?" | CASE | [generic] | Clarify first: volume by channel, who holds each stage today, and any regulated timescales. Then objective, segmentation by branch and channel, approach, the two monthly measures, and risks at the handoffs. If you mention the digital shift, use the brief's target: "move 40% of member service to digital channels by 2028." | A live problem from the JD's end-to-end line. It needs no claim about your past, so none is made. |
| H4 | "Tell me about a time you coached someone on handling an escalation." | JD | [grounded] "trained new tellers on our escalation script" | Story map: you trained tellers on the escalation script. Answer slot: if you coached anyone above teller level on escalations, say what you did and how it went; if the nearest case is the tellers, say so and use it. | Tests the JD's "coach branch supervisors on escalations" line. F6 is the only coaching sentence, and it is about tellers. |
| H5 | "Tell me about the monthly complaints spreadsheet you built." | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Describe in your own words what the spreadsheet was for and who reads it. Answer slot: if it showed volumes or resolution times, say which and how you read them; if it showed neither, say so plainly and say what it did show. | Covers F4 and F5. No figure is stated, so no defend-the-number slot is raised. |
| H6 | "The role reports monthly on complaint volumes and resolution times. What would you track first, and how would you count resolution time?" | JD | [grounded] "report monthly on complaint volumes and resolution times" | Name the two measures you would track. For resolution time, say the start and stop points you would use, and what you would do when they disagree. This question is about the future, so no claim about your past is made. | Forward-looking JD question. Tests method without asking you to defend a number you have not given. |
| H7 | "Have you worked with a digital or self-service channel, and if so, how?" | JD | [grounded] "work with digital teams on self-service journeys" | Answer slot: if you worked on a customer journey alongside a digital team, say which and what was yours; if you did not, say so plainly, then say how you would start with that team. | F7 is discovery: the material is silent. The honest answer is ready before the probe arrives. |
| H8 | "Tell me about a time you presented a complaints picture to a senior audience." | JD | [grounded] "I've never presented to anyone above regional level" | Plain acknowledgment: "I haven't presented to anyone above regional level." Answer slot: if you presented anything to your regional manager or to a group of branch staff, say what it was and how it went; if you presented nothing, say so plainly, then say how you would prepare for a senior room. | Covers the JD's "confident presenting to senior leaders". The stated absence is the only presenting sentence you gave, so the honest form comes first. |
| H9 | "Tell me about a time you decided something for a member, against the easy answer." | VAL | [grounded] "I handled the branch's formal complaints log" | Story map from the log: you handled it. Answer slot: a decision you made from the member's side; if the log gave you no such decision, say so and give the nearest case. | Members First, Always. The values line is in the published values, so the theme is grounded. |
| H10 | "A member writes that your complaint letter is unreadable. What do you do?" | CASE | [generic] | Clarify what the member needs. Read the letter as they would. Rewrite a plain version with them, check whether other letters have the same problem, and log the pattern. | Tests Plain Words in a live problem. Scored on how the answer is delivered as well as what it decides. |

**Reverse questions:**
- "What would a good first six months look like for complaints ownership, and who judges it?" Why it lands: it asks how success will be measured, which is a manager's question and shows you intend to be measured.
- "Where do you expect the digital shift to first change what members complain about?" Why it lands: it links the 40% target to the complaints work you would own, and it shows you read the brief.
- "Which of the monthly figures do branch supervisors use day to day?" Why it lands: it shows you have thought about the reporting as a working tool, not only as a deliverable.

## Round 3: panel of two branch managers (60 min, values round, 20-min case)

**Loop source:** the recruiter's email, which names the panel, its length and the 20-minute complaint-escalation case, and says the panel scores against the four values. That documents a values-style round, so the values cheat sheet below is included.

**Persona weights:** Values/Behavioral (top, 5 questions), Case/Strategist (2), Peer Evaluator (2), Pressure (1). Reasoning: the recruiter names the values scoring explicitly, which makes Values top. The escalation case gives the Case weight. Two branch managers sitting together make the Peer weight a real one. One Pressure question tests composure on the contact-centre gap.

### Values cheat sheet (the panel scores against these)

Published values are quoted from your pasted text.

| Value (official name) | Working meaning (paraphrased) | Mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side. Published: "we decide from the member's side of the counter." | F3 carries "I handled the branch's formal complaints log": you handled it. The member-side decision is not stated, so the answer is a selection scaffold: pick a time you decided something for a member, say what you decided and why. If none comes to mind, say so plainly, then give the nearest case. See P1. |
| Plain Words | If a member needs it explained twice, it was written wrong. Published: "if a member needs it explained twice, we wrote it wrong." | F6 carries "trained new tellers on our escalation script": you taught it. Whether the script was written in plain words is not stated. Scaffold: say what you taught and whether members understood it first time. See P2. |
| Neighbours, Not Numbers | Each branch is part of its town. Published: "every branch is part of its town." | None of your sentences carries a town-level story. Your most concrete artifact is a numbers spreadsheet, which is the awkward match for this value. Honest branch: say so plainly, then give the nearest thing your material does carry, the spreadsheet itself. Do not invent a town. See P3. |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved. Published: "whoever finds the problem keeps hold of it until it is solved." | F3 carries "I handled the branch's formal complaints log". Scaffold: pick a complaint you kept hold of from first contact to closure. If your part ended earlier, say where it passed and how you followed it up. See P4. |

### Panel bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Tell me about a time you decided something from the member's side of the counter." | VAL | [grounded] "I handled the branch's formal complaints log" | Story map: the log is where the complaint sat, and the sentence states you handled it. Answer slot: if you made a call on a complaint for the member's benefit, say what you decided and why; if the log gave you no such call, say so plainly and give the nearest case. | Members First, Always. The theme is the published value, which is a raising source. |
| P2 | "When have you rewritten an explanation so a member understood it first time?" | VAL | [grounded] "trained new tellers on our escalation script" | Scaffold: you taught the script to new tellers. Answer slot: if you changed how something was explained so that members understood it, say what you changed; if you only taught the script as written, say so and say what the teaching covered. | Plain Words. The question chooses an instance; the teaching is the only thing the quote states. |
| P3 | "When has a number on a report told you less about a town than a conversation would?" | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Honest branch first: your material has no sentence that carries a local story, so say so plainly if none comes to mind. Then give the nearest thing the spreadsheet does carry, which is the spreadsheet itself. Never supply a town-level incident. | Neighbours, Not Numbers. Your most concrete artifact is a numbers artifact, so this is the question most likely to tempt an invented story. |
| P4 | "Tell me about a complaint you kept hold of until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log" | Story map: you handled the log. Answer slot: if you kept a complaint from first contact to closure, say what held you to it; if your part ended earlier, say where it passed and how you followed it up. | Own the Fix. Coach the honest version: the value is about keeping hold, and your material shows handling, not closure. |
| P5 | "A member's complaint about a fee has been escalated to you. The branch says it is resolved and the contact centre says it is open. What do you do in the first hour?" | CASE | [generic] | Structure: what the record says now, who holds it, and what the member actually asked for in their words. Decide the one thing to fix today, give the member one plain update, name the branch and contact-centre seam for later, and record what you did. Speakable in 90 seconds. | The 20-minute escalation case. Scored on structure and on Own the Fix: the finder keeps hold of the case. |
| P6 | "The branch manager says the member already agreed the fix. Why should you reopen it?" | CASE | [generic] | Hold the position only if the member's own words in the file support it: reopen when the file does not show what the member agreed to. Concede plainly where the file is silent, and say what you would check first. | Pressure inside the case. Hold-then-concede, with the case's own evidence as the test. |
| P7 | "Our branch managers and the contact centre sit side by side. Where's the seam in escalations, and what happens when you disagree?" | JD | [grounded] "coach branch supervisors on escalations" | Propose seam principles, such as one owner per case and one shared record, rather than pretending to know their seam. Answer slot: if you disagreed with a colleague over a complaint, say what happened and what you did; if no such time comes to mind, say so and say how you would handle it. | Peer Evaluator probe, asked collegially. Reciprocity: what you bring their branches, not only what you need from them. |
| P8 | "Sixty seconds: why should two branch managers take escalation advice from someone who has never worked in a contact centre?" | JD | [grounded] "Never worked in a contact centre"; "trained new tellers on our escalation script" | Plain acknowledgment first: "I haven't worked in a contact centre." Hold on the escalation work: "I trained new tellers on our escalation script" and "I handled the branch's formal complaints log". Then concede: where the contact-centre knowledge will come from, as a plan. Hold through two follow-ups. | The Pressure question on the same gap as H1, delivered in a 60-second challenge. Rehearse the hold so it is calm rather than defensive. |
| P9 | "How would you coach a branch supervisor on an escalation they handled too late, without taking the case over?" | JD | [grounded] "coach branch supervisors on escalations" | Open hypothetical. Structure: find out what happened, give the supervisor the decision back, and agree a check-in. Answer slot: if you have coached a supervisor, say what you did; if your nearest coaching was with tellers, say so and use it. | Peer Evaluator probe on the JD's coaching line. F6 is the only coaching sentence you gave, and it is about tellers. |
| P10 | "Which of the four values is hardest to keep in complaint handling, and why?" | VAL | [grounded] | Name one honest tension and say why it is hard. This question makes no claim about your past. | The values round checks candour as much as content. A specific, honest tension scores better than a balanced list. |

**Reverse questions:**
- "Is there a scoring sheet for the four values that I can see before the day?" Why it lands: it shows you want the bar stated, and it asks for something the panel can give.
- "Which of the four values do you see least often in complaint handling today?" Why it lands: it invites candour from the panel and tests whether they are comfortable with a direct question.
- "How do complaints that start in a branch and then reach the contact centre get handed over today?" Why it lands: it names the seam the JD cares about, and the answer tells you where P7 and P9 will land.

## Requirement coverage

| JD requirement | Covered by |
|---|---|
| Own the member complaints process end to end across branches and the contact centre | H1, H3, P5, P7 |
| report monthly on complaint volumes and resolution times | H5, H6 |
| coach branch supervisors on escalations | H4, P9 |
| work with digital teams on self-service journeys | H7 |
| 4+ years in financial-services customer operations | R1 |
| experience handling regulated complaints | H2 |
| confident presenting to senior leaders | H8 |
| comfortable with Excel reporting | H5 |

Values coverage: Members First, Always (P1); Plain Words (P2); Neighbours, Not Numbers (P3); Own the Fix (P4, P10).

## Prohibited claims

Built locally from the fit snapshot. Each entry names its basis and its honest form. No answer slot, hold, bridge or rationale in this pack asserts a listed claim.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end across branches and the contact centre | Inflated form of F3. The quote carries one branch's log. | "I handled the branch's formal complaints log." The limit is the pack's observation: your material shows one branch's log, not the process end to end. |
| Set the monthly volume and resolution-time measures | Inflated form of F4 and F5. The quote says you built the spreadsheet, not that you chose its measures. | The quote at its own scope. H5's slot asks only what the spreadsheet counted. |
| Coached branch supervisors on escalations | Inflated form of F6. The quote is about tellers. | "I trained new tellers on our escalation script." |
| Regulated complaints | Inflated form of F2. Your sentence says formal, not regulated. | "I handled the branch's formal complaints log." H2's slot asks whether any were regulated. |
| Six years in customer operations | Inflated form of F1. Your sentence says retail banking. | "6 years in retail banking, the last 3 as a branch supervisor." |
| Worked in a contact centre | Negative you stated, F9. | "I haven't worked in a contact centre." No slot. |
| Presented to senior leaders | Negative you stated, F8. | "I haven't presented to anyone above regional level." No slot. |

## Sources

- **Provided documents:** your JD text and requirements (your message); the Ashgrove values, pasted from ashgrovecu.org/about/values and copied 26 November 2026; the recruiter's email on the three rounds; your summary of the July 2026 strategy brief (the brief itself is not in this session); your background (your message).
- **Searches and fetches sent:** none.

**Research tier:** L1, searches 0 of 6, fetches 0 of 2.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove Credit Union values | skipped | The values you pasted fix the official names and wording in the cheat sheet; a fetch would only re-check them. |
| 2. Ashgrove interview process, Member Experience Lead | skipped | The recruiter's email fixes the loop: three sessions, their lengths, and who runs each. |
| 3. Ashgrove strategy and recent news | skipped | Your summary of the July 2026 brief fixes the current priorities and dates, and it is under six months old. |
| 4. Interviewer name and Ashgrove | n/a | No interviewer names given, so there was no query to form. The interviewer read is absent. |
| 5. Representative Member Experience Lead JD | skipped | Your JD fixes the fit snapshot and the JD-tagged questions. |

## Upgrade menu

- The full strategy brief → confirms the 40%, hub and Q1 2027 figures, and lets the reverse questions and H3 cite the brief directly. Today they rest on your summary.
- Interviewer names, once assigned → personas per panellist and a reverse question tied to their career path.
- Whether the 20-minute case is given in advance → turns P5 and P6 from live cases into rehearsed ones.
- What the monthly complaints spreadsheet counted, whether volumes, resolution times, both or neither → H5's slot and F4 from discovery to a grounded answer.
- Any complaint in your log that carried a regulated timescale or rule → F2 and H2 from a slot to a grounded answer.
- Whether you have coached anyone above teller level → F6, H4 and P9.
- Any work alongside a digital team on a customer journey → F7 and H7 from discovery to a grounded answer.
- How many hours you have before 5 December → a prep triage in priority order, each step tied to a question ID.
- A tuesday-dossier.md, if you have one → verified evidence in place of the quoted lines above, and a strategy constraint for each weak area.
- Deeper research (L2): up to 6 more searches and 2 more fetches, several more minutes. Want it? Offered once.
