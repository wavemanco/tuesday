Your prep pack is saved as /var/tmp/tuesday-measure/1a6/runs/haiku/alone/part-2/rooms/case-7-canned-c7c763de/saltmarsh_live-operations-producer_interview_pack.md. I built it for the hiring-manager round the careers page describes, the Outage Hour: a single 60-minute interview with a live-incident tabletop, then a values conversation.

**What matters most for Friday**

- **Highest-ROI prep is C1.** Tobias will likely press on the JD's "coordinate design, art, engineering and community" line against your "Never led a team." The honest answer is "I haven't led a team," then the checklist you wrote with QA, then a plan for the first update. Rehearse it until the concession sounds plain, not defensive.
- **The Outage Hour is a live problem (A1).** Your material says nothing about incidents, so the pack gives you a triage structure, not a past. If you have handled a live incident or rollback, say what happened. If not, say so and walk through your triage.
- **Your strongest material is the checklist and the calendar.** "Wrote the release checklist our QA team still uses" maps to two of Saltmarsh's three values (Ship the Patch Not the Promise, Leave the Build Greener). "Players Before Plans" needs a real story: if you don't have one, say so and give the nearest thing you do have.
- **Don't stretch the two-title gap.** Your sentence covers one title. If asked how you would run two, answer from your own plan, not from experience you didn't have.

**What the research found**

- Saltmarsh's values, from the official page: Players Before Plans, Ship the Patch Not the Promise, Leave the Build Greener.
- Tobias came from QA as a lead at a console studio. A GDC 2026 talk of his is titled "Patch Notes Are a Promise." I read only the search snippet, not the talk, so expect probes on whether what you say about a release matches what shipped.
- Saltmarsh's news says it is moving to one shared events calendar and one live-ops group from February 2027, and retiring per-title event teams. That is a snippet too. A3 and C4 use it.

I used the default research depth: 4 of 6 searches and both page fetches.

Offers, not pushed:
- A drill: I can play the Skeptic on C1 and give feedback against that question's guidance.
- A `tuesday-dossier.md` recording this prep's gaps for later sessions.
- A Word version of the pack, if you want one.

One question: was your puzzle title a live-service game with ongoing events or content drops, and did it have any monetisation at all? The answer would move your "3+ years of live-service" line from a transferability gap to a grounded one.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh_live-operations-producer_interview_pack.md -----
# Interview pack: Live Operations Producer, Saltmarsh Games

Candidate: Femi (they/them). Interviewer: Tobias Wrenfield, Head of Live Operations. Round: the Outage Hour, a single 60-minute interview with the hiring manager (per the careers page): a live-incident tabletop, then a values conversation.

## How to use

- **Personas** describe how a question arrives. **Types** describe what is being scored: VAL (values), EXP (your experience, attribution), JD (the listed job), CO (company and strategy), CASE (a live problem).
- Guidance is scaffolding, not a script. Rehearse the beats in your own words.
- Answer slots (instructions, not questions) tell you what to say when the material does not show something. Answer whichever branch is true.

## Fit snapshot

Requirements come from the JD you pasted, the careers page, or the values page. Quotes in your evidence column come only from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | transferability | Your material shows one title, not two, and planning is not in the sentence. Bridge at its own scope: "For two years I ran the weekly content-drop calendar for our main title." Answer slot: if you planned any part of a calendar yourself, say which and how; if not, say how you would split one calendar across two titles. |
| F2 | "coordinate design, art, engineering and community teams on each update" (JD) | none given | none | [grounded] | discovery | Nothing in your material shows coordinating several functions on an update. Answer slot: if you coordinated more than one function on a release or drop, say which and how; if you did not, say so and say how you would set up that coordination for the first update. |
| F3 | "own the post-event review and the KPIs it reports" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | low | [inferred] | transferability | Presenting numbers is not owning a review or the KPIs. Bridge: "I presented the monthly retention numbers to the studio head." Answer slot: if you ran a review after an event or decided what a KPI measured, say so; if not, say so and say what you would review first. |
| F4 | "manage the release checklist with QA" (JD) | "Wrote the release checklist our QA team still uses." (your message) | medium | [grounded] | none | Your sentence reaches the requirement in its own terms: you wrote it and QA uses it. Expect a probe on what the checklist has caught, which your material does not say. |
| F5 | "3+ years producing live-service games or apps" (JD) | "4 years as an associate producer at a puzzle-game studio." (your message) | medium | [grounded] | transferability | Length meets the requirement. Whether the puzzle title was live-service is not in the sentence. Bridge at its own scope: "I've spent four years as an associate producer at a puzzle-game studio." Answer slot: if the title ran ongoing events or drops as a live service, say what made it so; if not, say which live work you did. |
| F6 | "experience running a content calendar" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | none | Your sentence reaches the requirement directly. Limited inspectable proof, so expect a probe on how it ran. |
| F7 | "comfortable with player-retention metrics" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | low | [inferred] | transferability | Exposure to the numbers, not ownership of how they were counted. Bridge: "I presented the monthly retention numbers to the studio head." Answer slot: if you know how those figures were counted, say so in your own words; if you do not, say that. |
| F8 | "clear written communication" (JD) | "Wrote the release checklist our QA team still uses." (your message) | medium | [grounded] | none | A written artifact in daily use by another team. One artifact, so the strongest proof is the checklist itself, if you can talk through it. |
| F9 | "a live-incident tabletop on a simulated outage during a live event" (careers page, fetched) | none given | none | [grounded] | discovery | The Outage Hour's central exercise, and your material says nothing about live incidents. Answer slot: if you have run through or responded to a live incident or a rollback, say what happened and what you did; if not, say so and walk through how you would triage. |
| F10 | People leadership, not stated in the JD (role-family pattern, [generic]) | "Never led a team" (your message) | none | [grounded] | capability | You have stated the absence. Words: "I haven't led a team." Then how you would coordinate across functions without line authority, said as a plan, not a past. |
| F11 | In-app purchase and monetisation work (role-family pattern, [generic]; the Larkspur news makes it likelier to be asked) | "never worked on a game with in-app purchases" (your message) | none | [grounded] | capability | You have stated the absence. Words: "I haven't worked on a game with in-app purchases." Then how you would learn an economy, as a plan. |

Gate rows: none. The JD states no location, pay or credential bar. The 3+ years line is length of experience, not a gate.

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the calendar for two titles | Inflated form of F1: the JD says two, your sentence says one | F1 at its own scope. Your material says one title's calendar. |
| Owned the post-event review or the KPIs | Inflated form of F3: your sentence says presented | F3's quote, with the limit as the pack's observation: your material says you presented the numbers. |
| Built or ran a live-service product | Inflated form of F5: your sentence says puzzle-game studio | F5's quote at its own scope. |
| Led a team or coordinated functions as a leader | Stated negative, F10 | "I haven't led a team." |
| Worked with in-app purchases or monetisation | Stated negative, F11 | "I haven't worked on a game with in-app purchases." |

## Reading the interviewer

Public footprint only. The search result gives this:

- **Career pattern:** a GDC 2026 talk listed as by "Tobias Wrenfield, Head of Live Operations at Saltmarsh Games, previously a QA lead at a console studio." The path runs from QA into live operations.
- **Published argument:** the talk is titled "Patch Notes Are a Promise", and its summary says "a live team is judged by how often its patch notes describe what actually shipped." I read the search snippet, not the talk itself.

Implications:

1. Expect probes on whether what you say about a release matches what shipped. Be exact about what you did and did not verify.
2. The Outage Hour is his format. A QA-minded interviewer will test triage, rollback judgement and what gets communicated, not just the plan.
3. The QA path is his, and your checklist sits with QA. The shared professional path is real but thin: your material does not show a move from QA to live operations, so no shared jump is offered.

## Persona weights

| Persona | How it shows up | Weight | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|---|
| Case / Strategist | The Outage Hour tabletop on a live event | 5 | High. The careers page names the tabletop, so this is a confirmed part of the round. | Clarify, then impact, then players, then decision points, then what gets recorded for the post-event review. |
| Values / Behavioral | The values conversation in the same hour | 4 | High. The loop source documents it, so values are in this round. | Map to a value only where a quoted sentence carries it; otherwise a selection scaffold with the honest branch. |
| Skeptic | Probes on the team coordination and leadership gaps | 4 | High. A hiring manager's prior, and F2, F10 and F11 are the gaps they will test. | Rehearse C1 until it is plain. Acknowledge, then bridge, then a plan. |
| Data-Driven Prober | Probes on the retention figures and the release claims | 3 | Medium. His talk is about the accuracy of release claims, and you presented retention numbers. | Say what you know about how figures were counted; say plainly when you do not know. |
| Conversational | The opener, and a casual question about live craft | 2 | Low to medium. A short opener in a 60-minute hour; treat it as scored. | A 90-second arc from your three quoted sentences, then a stop. |

## Question banks

### A. Case / Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "It is 40 minutes into a live event and reward claims start failing for a share of players. Walk me through your first hour." | CASE | [generic] pattern for a live incident, from the Outage Hour's format (careers page); no claim about you | Clarify what is failing and for whom. Pull in engineering and QA for diagnosis, community for player messaging. Decide on rollback or patch by player impact. Say what you tell players and when, and what you log for the post-event review. Speakable in 90 seconds. | F9 is the row this raises. The question presupposes no event in your past. |
| A2 | "You have two titles and one calendar that has to serve both. Sketch how you would plan the next quarter." | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Story-map from F1: the calendar you ran, at its scope. Then the design: what is shared (engineering capacity, QA windows) and what is per title. Answer slot: if you planned any part of a calendar yourself, say which and how; if not, say how you would split one calendar across two titles. | F1 is where the two-title requirement presses hardest. JD because it scores the stated requirement. |
| A3 | "Saltmarsh is retiring per-title event teams for a single live-ops group. What is the first risk you would watch for?" | CO | [grounded] "retires per-title event teams in favour of a single live-ops group" (Saltmarsh news, search snippet, not fetched) | Name one risk you can reason about: a title losing its voice, or QA windows shared between titles. Do not claim you know the company's plan. | The one differentiator question. Its premise is the company's published news, not your past. |
| A4 | "What retention number would tell you a content drop worked, and what would you check before you believed it?" | JD | [grounded] "Presented the monthly retention numbers to the studio head." | Name the metric, then the assumption you would check first. Answer slot: if you know how the figures you presented were counted, say so in your own words; if you do not, say that and say how you would find out. | F7 is the evidence for the retention requirement. This is a metric question, so it carries the weakest-assumption move. |
| A5 | "Your QA lead says the build is not ready. The community lead says the event starts tomorrow. Decide." | CASE | [generic] pattern for a cross-team conflict; raising source: "when the calendar and the players disagree, the players win" (values page, fetched) | Decide by player impact. Say who you consult, what you would tell each lead, and what you would record. No claim about your past. | This is the coordination gap (F2) asked as a decision. |

### B. Values / Behavioral (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time the calendar and the players pulled in different directions." | VAL | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Selection scaffold: pick a drop where player feedback or a bug changed the date or contents, and say what you chose. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, the two-year calendar, and how you would decide. | Maps to "Players Before Plans". The scaffold ends in the honest branch. |
| B2 | "Tell me about a time a release went out with notes that got ahead of the build." | VAL | [grounded] "Wrote the release checklist our QA team still uses." | Selection scaffold: if you can name a release where the notes and the build diverged, say what happened and what the checklist did. If no such release comes to mind, say so plainly, then describe what the checklist covers, only as far as you know it. | Maps to "Ship the Patch Not the Promise", and echoes the talk's theme. |
| B3 | "What did you leave better than you found it?" | VAL | [grounded] "Wrote the release checklist our QA team still uses." | If the checklist changed after you wrote it, say what changed and why. If it did not, say you wrote it and what it covers. Do not claim it improved builds. | Maps to "Leave the Build Greener". Only the checklist is in your material. |
| B4 | "Tell me about a time you had to tell leadership something they did not want to hear." | VAL | [grounded] "Presented the monthly retention numbers to the studio head." | Story-map on the presenting: what the numbers showed and what you said. If they were not unwelcome, say so, then give the closest time you had to say something hard, and say plainly if there is none. | A persona stem, scored for candour. |

### C. Skeptic (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You have never led a team. What makes you the person who coordinates design, art, engineering and community on every update?" | JD | [grounded] "Never led a team" (your message); [grounded] "Wrote the release checklist our QA team still uses." (your message) | **Highest-ROI prep in this pack.** Plain acknowledgment first: "I haven't led a team." Then the closest thing you have: the checklist, which you wrote and QA uses. Answer slot: if you coordinated more than one function on a release or drop, say which and how; if not, say how you would set up that coordination for the first update. Hold through two follow-ups by returning to the checklist and the plan. Concede specifically: "I haven't coordinated four functions on an update, and I would start by..." | This is the most predictable objection: F2 and F10 meet the JD's own coordination line. Rehearsing a plain, non-defensive answer changes the round. |
| C2 | "You have run one title's calendar. Two titles on one calendar means one of them slips sometimes. Which one, and how do you decide?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Story-map on the one calendar: its scope and length. Then the decision rule you would use. Answer slot: if you ever chose between two things competing for one calendar, say what and how you decided; if you did not, say so and state your rule. | F1's gap in its sharpest form. |
| C3 | "Tell me about a post-event review you owned. What did it measure?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Answer slot: if you owned a post-event review, say what it measured. If you did not, say so and say what you would measure first. Do not describe a review you did not run. | F3 is the gap. The question presupposes a review; the second branch lets that be false. |
| C4 | "Our shift to a season-pass model changes the economy you would be tuning. What is your experience there?" | JD | [grounded] "never worked on a game with in-app purchases" (your message); raising source: the Larkspur news (search snippet) | Plain acknowledgment: "I haven't worked on a game with in-app purchases." Then a plan: how you would learn the economy in your first month, using retention numbers and what you would ask the economy team. | F11 is stated and cannot be closed by wording. Names the plan, never a past. |

### D. Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how the monthly retention numbers you presented were counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | If you know how they were counted, say it in your own words. If you do not, say so plainly and say who you would ask. | F7. The prober's first move is the method; an honest "I don't know" beats an invented one. |
| D2 | "Tell me about the last release where the patch notes said one thing and the build did another." | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Open prompt. If you can name such a release, say what happened and what the checklist did. If none comes to mind, say so plainly, then describe the checklist's scope as far as you know it. | Ties the checklist to the talk's theme. Not a claim that the checklist prevents this. |
| D3 | "Which step in the release checklist would you change first?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Name one step you would challenge, from what you remember of it. If you do not remember its steps well, say so. | A probe on whether you can talk through what you wrote. |

### E. Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | JD | [grounded] "4 years as an associate producer at a puzzle-game studio." "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." | A 90-second arc using those three sentences, in that order. Then stop and say why you are here. | Casual, but scored. This covers the 3+ years line (F5). |
| E2 | "What is the best live update you have seen in a mobile game, and why?" | CO | [generic] pattern for a live-craft question; no claim about you | Pick a real one, name what it did for players, and say what you would copy. No claim about your past. | A casual question about the job's craft. Treat it as scored. |

## Requirement coverage

| JD requirement | Questions | Notes |
|---|---|---|
| Plan and run the calendar for two titles | A2, C2 | |
| Coordinate design, art, engineering and community | C1, A5 | |
| Own the post-event review and the KPIs | C3, A4 | |
| Manage the release checklist with QA | B2, D2, D3 | |
| 3+ years of live-service production | E1 | Covered by the F5 slot. |
| Experience running a content calendar | A2, B1 | |
| Comfortable with player-retention metrics | A4, D1 | |
| Clear written communication | none | The checklist shows it in your written work, not in a question. |
| Outage Hour (live incident) | A1 | From the careers page. |

## Sources

- **Provided:** the JD text and your background, from your message.
- **Searches (4 of 6):**
  1. "Saltmarsh Games values": `saltmarshgames.com/values` (fetched).
  2. "Saltmarsh Games interview process live operations producer": `saltmarshgames.com/careers/interviewing` (fetched).
  3. "Tobias Wrenfield Saltmarsh Games": `talks.gdconf.example/2026/patch-notes-are-a-promise` (search snippet, not fetched).
  4. "Saltmarsh Games strategy news 2026": `saltmarshgames.com/news/project-larkspur` (search snippet, not fetched).
- **Fetches:** 2 of 2 used.

**Research tier: L1, searches 4 of 6, fetches 2 of 2; user links read 0**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh values | yes | Values cheat sheet: three values by name, from the official page |
| 2. Interview process | yes | Loop: recruiter call, then the Outage Hour. Loop established: one 60-minute hiring-manager session, tabletop plus values conversation. Moved personas A1 and B1 to B4 and F9 |
| 3. Strategy / recent news | yes | Larkspur: season passes, one calendar, one live-ops group. Moved A3, C4 and the reverse questions. Snippet only |
| 4. Interviewer name | yes | Career pattern and talk title. Moved the interviewer read and the Prober weight. Snippet only |
| 5. Representative JD | skipped | The JD you supplied fixes the fit snapshot |

## Values cheat sheet

The values conversation is documented by the careers page, so this section applies.

| Value (official name) | Working meaning | Your mapped story |
|---|---|---|
| Players Before Plans | When the calendar and the players disagree, the players win. | Fit row F1. Quote: "I ran the weekly content-drop calendar for our main title for the last two years." Selection scaffold for B1: a drop where players changed the plan. If none, say so, then the calendar's own decisions. |
| Ship the Patch Not the Promise | Announce what is built, not what is hoped. | Fit row F4. Quote: "Wrote the release checklist our QA team still uses." Selection scaffold for B2: a release where notes and build diverged. If none, say so. |
| Leave the Build Greener | Every release leaves the codebase and the checklist better than it found them. | Fit row F4 again. Quote: "Wrote the release checklist our QA team still uses." Selection scaffold for B3: what changed, if anything. If nothing did, say you wrote it and what it covers. |

## Reverse questions

1. "You came up through QA before running live operations. What did that change about how you set release gates?" Why it lands: it shows you read his path, and it invites his own story.
2. "Saltmarsh is moving to one calendar and one live-ops group from February 2027. What does the first 90 days look like for this role?" Why it lands: it shows you read the news and asks for the scope.
3. "How does the live-ops group divide work between the title teams and the central team?" Why it lands: it finds the seam, and tells you where you would sit.
4. "What does a post-event review look like the week after an event?" Why it lands: it tests the review you would own (F3).
5. "What trips up candidates in the Outage Hour?" Why it lands: it shows you prepared for this format, and it gets a direct answer.
6. "What would you want the first update I own to prove?" Why it lands: it turns the gap into a criterion you can meet.

## Prohibited list

See the table under **Prohibited claims** above. It binds every guidance cell.

## Upgrade menu

- The full text of the GDC talk → a sharper D2, and a check on whether the snippet's thesis holds.
- Whether your puzzle title ran ongoing events or drops as a live service, and whether it had any monetisation → F5 upgrades from transferability to grounded; sharper A2 and C4.
- A CV, or a document from the calendar or checklist → F1, F4 and F6 move to high confidence, with inspectable proof.
- The recruiter's note on the Outage Hour's format → confirms A1 and the tabletop's expected depth.
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → the strategy brief, the talk's full text, and recent org context for the live-ops group. Want it?
- `tuesday-dossier.md` → one line on what one would add: carried-over gaps for later sessions.
