Your prep pack is saved at `/tmp/claude-0/-var-tmp-tuesday-measure-1a6-runs-haiku-alone-part-2-rooms-case-7-denied-6fa60cd5/b1510698-9b5f-4260-adb2-fb4241e1b84e/scratchpad/saltmarsh_games_live_operations_producer_interview_pack.md`. I built it for a hiring-manager round, since your note didn't say who you're meeting.

Web search was refused, so the pack has no company values, interview-loop structure, or information about Tobias. Those sections are dropped, and the pack's Sources section lists each one. Everything in it rests on the JD and your message.

The highest-ROI prep is A1, "Which part of this JD would you be weakest at on day one?" Your in-app purchase gap is the most likely objection, and the pack gives you a plain, honest answer for it.

Two questions, so I can reweight the pack:

1. Is Tobias the person you'd report to, or is he a peer or cross-functional partner?
2. Did the recruiter share any focus areas, a take-home, or a presentation? If so, I'll add a section for it.

Say the word and I'll play the Skeptic on A1 so you can rehearse it. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh_games_live_operations_producer_interview_pack.md -----
# Interview prep pack: Live Operations Producer, Saltmarsh Games

Interviewer: Tobias Wrenfield, Head of Live Operations. Relationship: assumed hiring manager (not yet confirmed). Round: 60 minutes, Friday.

## How to use this pack

Personas describe how a question arrives. Types describe what it scores.

- **EXP**: work-experience deep-dive. Tests whether what you did survives scrutiny.
- **JD**: role-driven. Tests whether you can do the listed job, gaps included.
- **CASE**: live problem from the role. Tests structure and reasoning.
- **CO**: company knowledge. Not covered here, because research did not run (see Sources).

Guidance is scaffolding, not a script. Say it in your own words, and only what you did.

## Fit snapshot

Requirements are quoted from the JD you supplied. Your evidence is quoted from your message. Bridges use only those words.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "Ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | transferability | Your material shows one title and content drops, not two titles or live events. Words: "For two years I ran the weekly content-drop calendar for our main title." Answer slot: if you planned for a second title, or ran events beyond content drops, say what and how. If not, say so, and say how you would take on a second title. |
| F2 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio" — your message | medium | [grounded] | transferability | Your material gives four years and an associate role, not live-service production as a credited role. Words: "Four years as an associate producer at a puzzle-game studio." Answer slot: if you were producing a live title, not supporting one, say which parts were yours. If it was not live-service, say so and describe the closest live work you did. |
| F3 | "experience running a content calendar" — JD | "Ran the weekly content-drop calendar for our main title for the last two years" — your message | high | [grounded] | none | No gap. The quote reaches the requirement directly. Lead with the calendar and the two years. |
| F4 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | presentation | The quote reaches the metric, but shows you presented it, not that you chose or defined it. Words: "I presented the monthly retention numbers to the studio head." Answer slot: if you chose the definition or acted on a number, say so. If you presented figures someone else defined, say that. |
| F5 | "own the post-event review and the KPIs it reports" — JD | none given | none | [grounded] | discovery | Your material does not show a post-event review or KPI ownership. Answer slot: if you ran a review after a content drop, say what it measured and what changed. If you did not, say so, and describe the review you would set up first. |
| F6 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses" — your message | high | [grounded] | none | No gap. The quote reaches the requirement directly. Lead with the checklist, and that QA still uses it. |
| F7 | "coordinate design, art, engineering and community teams on each update" — JD | none given | none | [grounded] | discovery | Your material does not show coordination with other teams beyond QA. Answer slot: if you coordinated other teams on a drop, say which and how. If QA was the main cross-team work, say so, and describe how you ran it. |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses" — your message | low | [grounded] | presentation | The checklist shows written work others rely on. It does not show writing quality on its own. Words: "I wrote the release checklist our QA team still uses." Upgrade: a writing sample would strengthen this row (see upgrade menu). |
| F9 | Monetization and in-app purchase work — [generic], not in the JD; a likely probe for a live-ops role | "Never worked on a game with in-app purchases" — your message | none | [grounded] | capability | You stated this absence, so the words are yours. Words: "I haven't worked on a game with in-app purchases." Then how you would learn it, said as a plan, never as a past. |
| F10 | Leading a team — [generic], not in the JD; the interviewer may raise it | "Never led a team" — your message | none | [grounded] | capability | You stated this absence. Words: "I haven't led a team." Then how you would work with a team, said as a plan. |

Your material does not establish the JD's "3+ years" line as met. F2 carries it at its own scope.

## Prohibited list

The claims this pack will not coach, and why. Each is built from the fit snapshot.

| Not coached | Basis | Honest form |
|---|---|---|
| Ran a live-events calendar across two titles | Inflated form of F1 | F1's quote at its own scope. Your material says one title and content drops. |
| Owned the post-event review and its KPIs | Inflated form of F5 | No quote supports it. Answer slot only. |
| Coordinated design, art, engineering and community on each update | Inflated form of F7 | No quote supports it. Answer slot only. |
| Chose or defined the retention metric | Inflated form of F4 | "I presented the monthly retention numbers to the studio head." |
| Has worked on a game with in-app purchases | Negative you stated, F9 | "I haven't worked on a game with in-app purchases." |
| Has led a team | Negative you stated, F10 | "I haven't led a team." |

## Personas

Assumed hiring-manager round. Weights below.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy | Depth |
|---|---|---|---|---|
| Skeptic | Probes the JD gaps: monetization, leadership, two titles | Top. Hiring managers buy capability and derisk gaps. Your three named gaps are the obvious targets. | Rehearse the in-app purchase answer until it is plain. Use only the bridges above. | 5 |
| Case / Strategist | Live problems on a live-ops roadmap | High. The JD is about planning and running a calendar. | Clarify, then objective, segmentation, approach, metrics, risks. Think aloud. | 4 |
| Data-Driven Prober | Asks how the retention figure was counted | High. The JD names retention, and you presented the numbers. | Name the weakest assumption before they do. Say plainly what you do not know. | 4 |
| Pressure | Challenges "never led" and "never worked on IAP" | Medium. Time-boxed challenges on your two stated absences. | Pause, restate, hold through two follow-ups, then concede the specific gap. | 3 |
| Conversational | Opens with "walk me through the journey" | Low. Still scored. | A 90-second arc that starts with the calendar. | 2 |

## Question banks

Provenance quotes are your sentences from the fit snapshot. Labels show what the guidance rests on.

### Skeptic (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never worked on a game with in-app purchases" | Highest-ROI prep. Plain acknowledgment: "I haven't worked on a game with in-app purchases." Then a plan for learning it: how you would study the monetization side of the calendar before your first drop. Keep it a plan, not a past. | F9 is your largest gap, and this objection is likely in some form. |
| A2 | "What would change about running live events on a game with in-app purchases?" | CASE | [generic] | Structure it: what changes (offer timing, the spend economy, store and review cycles, what you would measure). Name what you have not done. Your material supports no claim about this. | Monetization is a probe for this role, not a JD line. |
| A3 | "The role runs the live-events calendar for two titles. Where have you run a calendar across more than one?" | JD | [grounded] "Ran the weekly content-drop calendar for our main title for the last two years" and the JD's "Plan and run the live-events calendar for two of our mobile titles" | Answer slot: if you ran a calendar for more than one title, say how, in your own words. If you ran one, say so plainly, then describe how you would take on a second. | F1 is the evidence for the two-title requirement, and the premise is the JD's own line. |
| A4 | "What is the post-event review you would run after an update, and what would you do with its KPIs?" | JD | [generic] | Answer slot: if you ran a review after a content drop, say what it measured and what changed. If you did not, say so, and describe the review you would set up first. | F5 is silent in your material, so the answer is yours to give. |
| A5 | "How do you coordinate design, art, engineering and community on a single update?" | JD | [generic] | Answer slot: if you coordinated other teams on a drop, say which and how. If QA was the main cross-team work, say so, and describe how you ran it. | F7 is the coordination requirement, with no quote behind it. |

### Case / Strategist (4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Sketch a live-events plan for one of our titles for next quarter. What do you need to know first?" | CASE | [generic] | Clarify first: the objective (retention, spend or both), the current baseline, the team's capacity. Then segmentation, cadence, metrics, risks. | The JD's calendar requirement, live. |
| B2 | "Retention dropped 15% after last month's event. Diagnose it." | CASE | [generic] | Clarify whether the drop is the event or the baseline. Check the instrumentation first. Segment by cohort. Name the assumption you would test first. | F4 is the retention requirement. |
| B3 | "Two teams want the same release slot. How do you decide?" | CASE | [generic] | Criteria first: player impact, QA readiness against the checklist, risk to the other team. Name the trade-off you would escalate. | F6 covers the release checklist. |
| B4 | "Which metric would you put on the post-event review first, and why?" | CASE | [generic] | Name one metric and the assumption behind it. Say what you would check before trusting it. | F5 is the post-event review requirement. |

### Data-Driven Prober (4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how you counted the retention numbers you presented to the studio head." | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Answer slot: say how the figure was counted, in your own words. If the definition or cohort came from someone else, say so. If you do not know how it was counted, say that plainly. | F4 is the evidence, and a figure raises the defend-the-number slots. |
| C2 | "Which assumption behind that retention figure would you defend least?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Name the weakest assumption you know of, before they do. If you do not know one, say so plainly. | Metric questions include the weakest-assumption move. |
| C3 | "You wrote the release checklist. Which parts were yours, and which came from QA?" | EXP | [grounded] "Wrote the release checklist our QA team still uses" | Say which items you wrote and which QA added or changed. Answer slot: if QA contributed items, name them. | F6 is the evidence for the checklist requirement. |
| C4 | "How do you know the content drops moved retention, and not something else that shipped that month?" | EXP | [grounded] "Ran the weekly content-drop calendar for our main title for the last two years" and "Presented the monthly retention numbers to the studio head" | Say what the figures can show and what they cannot. Answer slot: if you tested or compared drops, say how. If not, say that the figures show timing, not cause. | F1 and F4 together. This is the attribution probe. |

### Pressure (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why should we hire someone who has never led a team?" | JD | [grounded] "Never led a team" | Pause. Plain acknowledgment: "I haven't led a team." Hold through two follow-ups. Concede the specific gap, then give a plan for working with a team. | F10 is your stated absence. |
| D2 | "That retention result: how much of it was actually you?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Say what you presented and what you did with it. Hold through two follow-ups. Concede what was not yours, specifically. | F4 is the evidence. |
| D3 | "You've never worked on a game with in-app purchases. Why would we bet on you for live ops?" | JD | [grounded] "Never worked on a game with in-app purchases" | Plain acknowledgment: "I haven't worked on a game with in-app purchases." Then the closest thing your material carries: "Ran the weekly content-drop calendar for our main title for the last two years." Hold, then concede the gap specifically. | F9 under pressure. |

### Conversational (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio"; "Ran the weekly content-drop calendar for our main title for the last two years" | A 90-second arc: the puzzle studio, then the calendar you ran for two years, then what you want next. | F2 and F3 carry the story. |
| E2 | "What is a live title you admire, and why?" | CO | [generic] | Pick one title you have played. Say what you would take from its update cadence. Make no claims about its internal data. | Research did not run, so this is generic. |

## Requirement coverage

| JD requirement | Questions |
|---|---|
| Plan and run the live-events calendar for two titles | A3, B1 |
| Coordinate design, art, engineering and community on each update | A5 |
| Own the post-event review and the KPIs it reports | A4, B4 |
| Manage the release checklist with QA | B3, C3 |
| 3+ years producing live-service games or apps | E1 |
| Experience running a content calendar | C4 |
| Comfortable with player-retention metrics | C1, C2, D2 |
| Clear written communication | none, and why: no writing sample was in the material. The upgrade menu asks for one. |

Not in the JD, covered anyway: monetization (A1, A2, D3), leading a team (D1).

## Reverse questions

Why each lands is given below. No profile for the interviewer exists, so these are role-generic.

1. "How is the calendar planned across the two titles today, and who sets its priorities?" Why it lands: it shows you read the ownership line in the JD.
2. "Which retention number is this role judged on this year?" Why it lands: it tells you the scoring, and it shows you read the retention requirement.
3. "Where do design, art, engineering and community most often disagree on an update?" Why it lands: it asks about the coordination work the JD names.
4. "What does a good first 90 days look like in this role?" Why it lands: it turns the gap question into a plan you can state.
5. "Which of the two titles needs the most attention right now, and why?" Why it lands: it shows you are already thinking about both titles.

## Sources

Provided documents: the JD text and your message.

Research tier: L1, with 0 of 6 searches run. Three searches were sent, and all three were refused because permission to use web search was not granted.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | unavailable | Would have set the values cheat sheet. Refused. |
| 2. Saltmarsh Games interview process, live operations | unavailable | Would have set the loop structure and persona weights. No call sent, since web search was declined. |
| 3. Saltmarsh Games strategy and recent news | unavailable | Would have set the company context section. No call sent. |
| 4. Tobias Wrenfield, Saltmarsh Games | unavailable | Would have produced the interviewer read and a tailored reverse question. Refused. |
| 5. Representative Live Operations Producer JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions. |

Queries sent, all refused:
- "Saltmarsh Games mobile studio values"
- "Saltmarsh Games live operations mobile game"
- "Tobias Wrenfield Head of Live Operations Saltmarsh Games"

Sections dropped for lack of research: values cheat sheet, grounding brief, interviewer read, CO-based questions.

## Upgrade menu

- Whether Tobias is your future manager, or a peer → persona weights recomputed; the pack currently assumes a hiring manager.
- Web search permission for a rerun → company values, loop structure, company context, and Tobias's public background; the values section and interviewer read come back.
- A writing sample, such as a checklist excerpt or a post-drop note, pasted as text → F8 gets a grounded quote, and the written-communication row stops relying on the checklist alone.
- Any recruiter notes on focus areas or a take-home → a graded-deliverable section, and coverage for what they name.
- A tuesday-dossier.md from job-underwriter → verified evidence and the highest-ROI objection, derived from evidence instead of inferred.
