Your prep pack is saved as `/var/tmp/tuesday-measure/1a6/runs/haiku/alone/part-2/rooms/case-8-canned-f0b8ae8e/ashgrove_member-experience-lead_interview_pack.md`. I built it as a loop pack because you have three rounds on 5 December: a recruiter screen, a behavioural round with the Head of Member Services, and a panel with a 20-minute escalation case. Each round has its own question bank.

The three things to focus on, in order:

1. **B3** is the objection most likely to come up: "I don't see contact-centre work in your background." Your material says you have never worked in a contact centre, so the answer has to start with that plainly, then come back to the complaints log you handled. This is the highest-return rehearsal.
2. **The escalation case (C1, C2)** is the most heavily scored part of the loop, so practise the structure out loud and timed.
3. **The values questions.** Only "Own the Fix" has a story in your material (the complaints log). For the other three values the pack gives a selection scaffold, with an honest "say so plainly" branch, because I did not want to invent stories for you.

The pack is built only on what you gave me. It has no figures, because your material has none, so I did not supply any complaint volumes or resolution times. I did not search anything: the values, strategy and round structure came from the text you pasted, and the strategy is the July 2026 summary.

Options from here:
- Want me to play the Skeptic on B3 as a live drill? It's a one-off rehearsal, and the feedback is measured against that question's guidance.
- I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, to carry into later sessions.
- If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove_member-experience-lead_interview_pack.md -----
# Ashgrove Credit Union: Member Experience Lead interview pack

## 1. Title block

- **Role:** Member Experience Lead, Ashgrove Credit Union (member-owned, about 900 staff)
- **Format:** Loop mode, three rounds on 5 December 2026
  - **Round 1, 30 min:** recruiter (relationship: screen)
  - **Round 2, 45 min:** Head of Member Services, who would be your manager (mostly behavioural)
  - **Round 3, 60 min:** panel of two branch managers, with a 20-minute complaint-escalation case; the panel scores against the four values
- **Interviewer names:** not yet given. The interviewer read is dropped, so Round 2 and Round 3 are personas set by round type.
- **Prep window:** 26 November to 5 December, nine days.
- This is a first version, so there is no changelog.

## 2. How to use + type key

- **Personas** describe how a question arrives. **Types** describe what it scores.
- **Type key**
  - **VAL:** behavioural and values alignment, tested against the four published values
  - **EXP:** your own past work, tested for what was actually yours
  - **JD:** the role's stated responsibilities and requirements
  - **CO:** company and strategy knowledge
  - **CASE:** a live problem from the role, reasoned aloud
- **Guidance is scaffolding, not a script.** Rehearse the shape, then say it in your own words. Each guidance cell is meant to be spoken in 90 to 120 seconds.
- **Quotes:** text in quotation marks is taken from your message or from a document, and the source is named beside it.

## 3. Prep triage (nine days)

1. **Days 1 to 2: B3 and B4**, the two objections the material makes most likely. Rehearse until a plain, non-defensive answer is routine. This is the highest-return work in the pack.
2. **Days 2 to 4: C1, C2 and C9**, the 20-minute escalation case and its follow-ups. Practise the structure out loud, timed.
3. **Days 4 to 6: the values questions** (B1, B2, B7, C3 to C6) and the cheat sheet in section 10.
4. **Days 6 to 7: the rest of Round 2 and Round 3** (B5, B6, B8, B9, C7, C8), out loud.
5. **Day 8: Round 1 logistics** (A1 to A4). Decide your own answers in your own words before the call.
6. **Day 9:** a timed run of the escalation case and one values answer, with no notes.

Everything else is insurance.

## 4. Fit snapshot

Requirements are quoted from the JD you supplied. Evidence is quoted from your message, which is the only background the pack has. No requirement here is a gate in the sense of a legal or credential term, so no gate row appears.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor" — your message | medium | [grounded] | none | No gap on years. Expect a probe on whether branch work counts as customer operations at the scale this role names. Answer with what the branch's customer work was, in your words. |
| F2 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | presentation | The quote already reaches this in other terms: "I handled the branch's formal complaints log." Answer slot: the JD's "regulated complaints" line makes a probe on which rules set the complaint timescales likely. If your log followed a set timescale or a regulator's rules, say which and how you tracked against it. If it did not, say so plainly and say what the log did track. |
| F3 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level" — your message | none | [grounded] | capability | Stated absence, so the words come from it: "I've never presented to anyone above regional level." Then the first step you would take, said as a plan, never as a past. |
| F4 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | presentation | The quote already reaches this in other terms: "I built the monthly complaints spreadsheet our regional manager uses." Your message does not name Excel, and the bridge does not add it. Answer slot: the JD names Excel, so expect a probe on the tool and the functions you used. If you used formulas, lookups or pivot tables, name them. If not, say what you used. |
| F5 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | transferability | The quote carries adjacent work: a monthly complaints report. It does not show resolution times. Answer slot: the JD raises resolution times. If the spreadsheet tracked how long complaints took to close, say which and how. If it did not, say so plainly. |
| F6 | "own the member complaints process end to end across branches" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | transferability | The quote is one branch's log, and the JD asks for the process across branches. Bridge at the quote's own scope: "I handled the branch's formal complaints log." Answer slot: if you handled complaints beyond your own branch, say where and how. If the log was one branch's, say so plainly. |
| F7 | "across branches and the contact centre" — JD | "Never worked in a contact centre" — your message | none | [grounded] | capability | Stated absence: "Never worked in a contact centre." No slot. Then how you would learn contact-centre queues and handoffs, said as a plan. |
| F8 | "coach branch supervisors on escalations" — JD | "trained new tellers on our escalation script" — your message | medium | [grounded] | transferability | Adjacent work: you trained tellers on an escalation script, and the JD asks you to coach supervisors on escalations. Bridge at the quote's scope: "I trained new tellers on our escalation script." Answer slot: if you coached a supervisor on an escalation, say what you did and what happened. If you have not, say so and say how you would start. |
| F9 | "work with digital teams on self-service journeys" — JD | "no digital/self-service journey experience" — your message | none | [grounded] | capability | Stated absence: "I have no digital or self-service journey experience." No slot. Then how you would work with a digital team, said as a plan. |

**Analysis (the pack's own observation):** your material gives no figures: no complaint volumes, no resolution times, no team sizes. The pack supplies none, and no answer should be built on one that is not yours.

**Requirement coverage**

| JD requirement | Questions covering it |
|---|---|
| 4+ years in financial-services customer operations | F1, A5 |
| Experience handling regulated complaints | F2, B5, C1 |
| Confident presenting to senior leaders | F3, B4 |
| Comfortable with Excel reporting | F4, B6 |
| End to end across branches and the contact centre | F6, F7, B3, C7 |
| Monthly reporting on volumes and resolution times | F5, B5, C9 |
| Coach branch supervisors on escalations | F8, C1, C2 |
| Work with digital teams on self-service journeys | F9, B8 |

## 5. Grounding brief

The strategy facts below come only from the July 2026 brief summary you supplied. The pack did not check anything newer.

- **Vocabulary:** "digital channels", "member service", "hubs"
- **Headline aims:** move 40% of member service to digital channels by 2028; consolidate eight branches into five hubs over 2027; launch a small-business lending product in Q1 2027
- **Competitive pressure:** the brief names app-only banks as the main one
- **Stale-framing check:** none flagged. Use the brief's wording, not older phrasing.

## 6. Persona table

| Persona | Likelihood by round, with reasoning | Counter-strategy |
|---|---|---|
| Values / Behavioral | **Round 2, high:** the recruiter says Round 2 is mostly behavioural, so this persona leads it. **Round 3, high:** the panel scores against the values. | Map each story to a value using the cheat sheet. Where no story exists, give the selection scaffold and its honest branch. Use "we" for context and "I" for what you did. |
| Case / Strategist | **Round 2, medium:** the strategy questions (B8, B9). **Round 3, high:** the 20-minute escalation case. | Clarify, then structure, then decide. Think aloud. Use the brief's own vocabulary. |
| Skeptic | **Round 2, high:** the gaps in F3, F7 and F9 are the likeliest probes, and the recruiter's stated focus is behavioural, so this persona is not the lead. **Round 3, low.** | Rehearse the single most predictable objection until it is routine. Concede the gap in your own words, then say the plan as a plan. |
| Data-Driven Prober | **Round 2, medium:** your spreadsheet (F4, F5) is the only artifact in the material, so it will be probed. **Round 3, medium** (C9). | Say what the spreadsheet tracked, and say plainly what you do not know about how it was counted. |
| Pressure / Stress | **Round 3, medium:** the panel's probes on contact-centre experience (C7). | Pause, restate the question, hold the position through two follow-ups, then concede the specific gap. |
| Peer Evaluator | **Round 3, medium:** the panel are branch managers, so seam questions are likely (C8). | Describe what you bring to their branches, then propose a seam principle rather than claiming to know the seam. |
| Conversational / Rapport | **Round 1, high:** the screen is conversational, but logistics are scored. | Keep a 90-second arc for "walk me through the journey" (A5). |

**Depth note:** the top persona carries three questions per round, below the four or five a session pack would give. That is the loop structure's cost, and the cap is set by the per-round bank size.

## 7. Question banks

### Round 1: Recruiter screen (30 min)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "What are your salary expectations for this role?" | JD | [generic] | Logistics slot. If you have a firm range, give it in your own words. If you want the band first, say so. Give no figure you have not chosen. | Pay is a logistics topic. Nothing in your material states a figure, so none is given here. |
| A2 | "What's your notice period?" | JD | [generic] | Logistics slot. Give your actual notice period in one sentence. | Notice is a logistics topic. Your material says nothing about it. |
| A3 | "Where are you based, and how do you get to the branches?" | JD | [generic] | Logistics slot. Give your location in your own words. If asked about the commute, give your own words only, with nothing added. | Location is a logistics topic. |
| A4 | "Why are you leaving your current role?" | EXP | [generic] | Logistics slot. Give your reason in one true sentence, in your own words, then move to what you want next. Your material gives no reason, so none is supplied here. | The reason for leaving is a logistics topic that the recruiter will score for consistency. |
| A5 | "So, walk me through the journey." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "I handled the branch's formal complaints log"; "I built the monthly complaints spreadsheet our regional manager uses" | A 90-second arc in your own words. Beats, each taken from a quoted sentence: retail banking for six years, the last three as a branch supervisor, the formal complaints log, the spreadsheet, and what you want next. | F1, F2 and F4 are the spine of the journey. Casual openers are still scored. |
| A6 | "Where do you think you're weakest for this role?" | JD | [grounded] "I've never presented to anyone above regional level" | Name the presentation gap plainly, in those words: "I've never presented to anyone above regional level." Then the first step you would take, as a plan. | F3 is the gap most likely to surface early, and a clean answer here sets up Round 2. |
| A7 | "Eight branches into five hubs over 2027. What's your reaction?" | CO | [grounded] "consolidate eight branches into five hubs over 2027" from the recruiter's strategy brief | Say what you think the change means for complaints: where they get raised and how they reach a decision. No claim about your own experience. | A strategy question from the brief, so it tests whether you read it. |
| A8 | "What's drawing you to Ashgrove?" | VAL | [grounded] "Members First, Always — we decide from the member's side of the counter" from the values page you copied | Say why in your own words, keyed to one value you can explain. Do not claim member-owned experience you do not have. | Values are scored early in a conversational screen. |

**Reverse questions, Round 1**

1. "What's the next step after this call, and who sits on the panel?" Why it lands: it shows you are planning around the process and gives you the panel's makeup.
2. "Why is the team opening this role now?" Why it lands: it asks for the context behind the hire, which a prepared candidate would want.

### Round 2: Head of Member Services (45 min, mostly behavioural)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time you had to explain a complaint outcome to a member who didn't want to hear it." | VAL | [grounded] "Plain Words — if a member needs it explained twice, we wrote it wrong" from the values page; no candidate sentence carries a story | Selection scaffold: pick a time a member needed an outcome explained and you explained it. Say what you said first and what made it land. If no such time comes to mind, say so plainly, then give the nearest thing your material carries: the escalation script you trained tellers on, in your own words. | Plain Words is the value this question tests. Your material has no outcome-explaining story, so the scaffold ends in its honest branch. |
| B2 | "When did you put a member's side of the counter ahead of a branch target or an internal process?" | VAL | [grounded] "Members First, Always — we decide from the member's side of the counter" from the values page | Selection scaffold: pick a decision where the member's view changed the outcome. If none comes to mind, say so plainly, then give the nearest thing your material carries, which is the complaints log you handled, in your own words. | Members First is the first value and the one most often scored. |
| B3 | "I don't see contact-centre work in your background. How would you run complaints across a contact centre you've never worked in?" | JD | [grounded] "Never worked in a contact centre" — your message | **The highest-ROI rehearsal in this pack.** The hold is what your material carries. Say the negative first, in your words: "I've never worked in a contact centre." Then return to the complaints log you handled: "I handled the branch's formal complaints log." Then the first thing you would learn, as a plan. Hold through two follow-ups by returning to the log, never by adding to it. | F7 is the gap this objection targets, and it will arrive in some form. The non-defensive answer is what changes the interview. |
| B4 | "You've never presented above regional level. How will you present to the leadership team in six months?" | JD | [grounded] "I've never presented to anyone above regional level" — your message | Say the negative in those words. Then the plan you would start with, as a plan, not a past. Do not describe presenting experience you do not have. | F3 is the capability gap a Skeptic will test. |
| B5 | "The role reports monthly on complaint volumes and resolution times. What did your spreadsheet report?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" — your message | Say what the spreadsheet tracked, in your own words. If it did not track resolution times, say so. Answer slot from F5, with the same two branches. | F5 is the requirement with the thinnest match, so the honest answer must be ready. |
| B6 | "Which Excel functions did you use to build it?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" — your message | Answer slot from F4. If you used formulas, lookups or pivot tables, name them. If you used something else, say what. | F4 is the requirement the JD names by tool, so expect the tool to be probed. |
| B7 | "A supervisor disagrees with your escalation decision. What happens next?" | VAL | [grounded] "trained new tellers on our escalation script" — your message | Selection scaffold: pick a time your decision was challenged. Hold the position you actually took through one follow-up, then concede any part that was wrong. If none comes to mind, say so and give the nearest thing your material carries, which is the escalation script you trained tellers on. | Own the Fix and Plain Words are both tested here. |
| B8 | "The brief moves 40% of member service to digital by 2028. How would you work with digital teams on a self-service complaints journey?" | CO | [grounded] "move 40% of member service to digital channels by 2028" from the strategy brief; [grounded] "no digital/self-service journey experience" — your message | Name the aim in the brief's words. Then say plainly that you have no digital or self-service journey experience. Then the plan: how you would work with a digital team, as a plan. | F9 is the gap, and the strategy question tests whether you read the brief. |
| B9 | "What do you do in your first ninety days?" | CASE | [generic] | Structure it: what you would read, who you would meet, what you would measure, and what you would decide first. Make no claim about your past. | A standard live-problem question for a manager who is buying a plan. |

**Reverse questions, Round 2**

1. "Where do complaints first reach you, and how long before they reach a decision?" Why it lands: it shows you want the remit in operational terms.
2. "How will the hub move change which supervisors own escalations in 2027?" Why it lands: it uses the brief and asks about the coaching remit the role names.
3. "What would success look like for this role at twelve months?" Why it lands: it asks for the manager's own measure of success.

### Round 3: Panel of two branch managers (60 min, values scored, 20-minute case)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | The 20-minute case: a member's complaint about an escalation, as the recruiter describes it. | CASE | [grounded] "a 20-minute case on a complaint escalation" from the recruiter's email | Clarify first: the facts, the member's ask, and the timescale your policy sets. Then the options and what you would decide. Then what you would record. Name the timescale as your policy's, not as a rule you know. No claim about your past. | The case is the most heavily scored part of the loop. |
| C2 | "What would you say to the branch supervisor in the first two minutes?" | JD | [generic] | Structure: what you would ask, what you would tell the supervisor, and what you would not decide for them. | The coaching remit is the JD's escalation line. |
| C3 | "When did a member's side of the counter change a decision you had already made?" | VAL | [grounded] "Members First, Always — we decide from the member's side of the counter" from the values page; no candidate sentence carries a story | Selection scaffold: pick a decision you changed because of the member's view. If none comes to mind, say so plainly, then give the nearest thing your material carries: the complaints log you handled. | Members First is scored, and the scaffold is the honest route. |
| C4 | "When did a branch's local context change how you handled a complaint?" | VAL | [grounded] "Neighbours, Not Numbers — every branch is part of its town" from the values page | Selection scaffold: pick a complaint where local context mattered. If none comes to mind, say so plainly. Your material carries no such story, so say that, then say how you would find out what the town needs. | Neighbours, Not Numbers has no candidate sentence behind it. |
| C5 | "Tell us about a letter or explanation you rewrote because a member did not understand it." | VAL | [grounded] "Plain Words — if a member needs it explained twice, we wrote it wrong" from the values page | Selection scaffold: pick a time you rewrote an explanation. If none comes to mind, say so plainly, then give the nearest thing your material carries: the escalation script you trained tellers on. | Plain Words is scored, and the honest branch is the one to rehearse. |
| C6 | "Tell us about a complaint you kept hold of until it was solved. What did you do?" | VAL | [grounded] "I handled the branch's formal complaints log" — your message | Map the quote at its own scope: the log you handled. Answer slot: if you kept a complaint from first contact to a resolution you chased yourself, say what you did. If the log only recorded complaints, say so plainly. | Own the Fix is the value this question tests, and F6 is the quote it rests on. |
| C7 | "You've never worked in a contact centre. Why should we trust your judgement on contact-centre complaints?" | JD | [grounded] "Never worked in a contact centre" — your message | Hold the position through two follow-ups: say the negative, then the complaints work you did, in your own words. Concede the specific gap, not the whole role. Do not fold on the core claim to restore harmony. | A Pressure probe on F7. Its second follow-up is where a held position that cannot be backed breaks. |
| C8 | "Our branches run escalations their own way. Where does your work sit with ours, and what happens when we disagree?" | CO | [generic] | Name a seam principle, such as who owns the member's case at each step, rather than pretending to know the seam. Describe what you would bring to their branches. | A Peer probe that uses the same objections in collegial packaging. |
| C9 | "How would you report resolution times each month?" | JD | [grounded] "report monthly on complaint volumes and resolution times" — JD; [grounded] "I built the monthly complaints spreadsheet our regional manager uses" — your message | Answer slot from F5. If the spreadsheet tracked resolution times, say how. If it did not, say so, and say what you would measure first. | F5 is the requirement with the thinnest match. |

**Reverse questions, Round 3**

1. "What could a new person do in their first month that would genuinely help your branches?" Why it lands: a reciprocity question to a peer panel, asking what the hire contributes to their work.
2. "Where do complaints pile up in your branches, and what would you fix first?" Why it lands: it shows you are thinking about their branches, not only the role.
3. "How does a complaint move from a branch to the contact centre today?" Why it lands: it asks about the seam between the two channels, which the role owns.

## 8. Values / principles cheat sheet

Values are the four published values, as copied from ashgrovecu.org/about/values on 26 November 2026. The pack did not visit the site.

| Value (official name) | Working meaning (paraphrased) | Mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter. | **Selection scaffold, no candidate sentence carries a story (F6 is the nearest).** Pick a decision where the member's view changed the outcome. If none comes to mind, say so plainly, then give the complaints log you handled, in your words. |
| Plain Words | If a member needs it explained twice, the writing was wrong. | **Selection scaffold, no candidate sentence carries a story.** Pick a time you rewrote an explanation. If none comes to mind, say so, then give the escalation script you trained tellers on, in your words. |
| Neighbours, Not Numbers | Every branch is part of its town. | **Selection scaffold, no candidate sentence carries a story.** Pick a complaint where local context mattered. If none comes to mind, say so plainly, and say how you would find out what the town needs. |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved. | Mapped to F6 at its own scope: "I handled the branch's formal complaints log." Answer slot: if you chased a complaint to resolution yourself, say what you did. If the log only recorded complaints, say so. |

## 9. Delivery coaching

Dropped. No working-style assessment was provided.

## 10. Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| "I've worked in a contact centre" | Sourced: your message states "Never worked in a contact centre" | Plain acknowledgment: "Never worked in a contact centre." No slot. |
| "I've presented to senior leaders" | Sourced: your message states "I've never presented to anyone above regional level" | Plain acknowledgment: "I've never presented to anyone above regional level." No slot. |
| "I have worked on self-service journeys" | Sourced: your message states "no digital/self-service journey experience" | Plain acknowledgment: "I have no digital or self-service journey experience." No slot. |
| "I owned the complaints process end to end across branches" | Inflated form of F6 | F6's quote at its own scope: "I handled the branch's formal complaints log." The limit is the pack's observation: your material describes one branch's log. |
| "I designed the reporting that senior leaders use" | Inflated form of F4 and F5 | The quote at its own scope: "I built the monthly complaints spreadsheet our regional manager uses." The limit is the pack's observation: your material says the regional manager uses it, not who else does. |
| "I coached branch supervisors on escalations" | Inflated form of F8 | The quote at its own scope: "I trained new tellers on our escalation script." |

## 11. Sources

**Provided documents**

- The job description, as you pasted it
- The recruiter's email, describing the three rounds and the panel's values scoring
- The four values, as you copied them from ashgrovecu.org/about/values on 26 November 2026
- The 2026 strategy brief summary, from July 2026, as you supplied it
- Your message describing your background

**Research tier: L0.** No searches or fetches were run. Every target below was already fixed by the documents in hand.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | Pasted values text fixes section 8. |
| 2. Ashgrove interview process, member experience lead | skipped | The recruiter's email fixes the round structure and the loop. |
| 3. Ashgrove strategy / recent news | skipped | The brief summary fixes section 5 and the CO questions. Anything newer would need a search (see upgrade menu). |
| 4. Interviewer names | n/a | No names given. Round 2 and Round 3 are personas by round type. |
| 5. Representative JD for the title | skipped | The JD you supplied fixes the fit snapshot. |

## Upgrade menu

- **Your complaints spreadsheet, anonymised (or a screenshot of its headers):** F4 and F5 move from medium to high, and the B5, B6 and C9 slots have an artifact to point at.
- **The recruiter's case brief for the escalation case:** C1 and C2 tailored to the exact scenario.
- **The Head of Member Services' and the panel's names:** persona weights and reverse questions tailored to their public footprint.
- **Your notice period, pay range and location, in your own words:** A1 to A3 get their answers, and each is quoted into its logistics slot.
- **Your reason for leaving, in your own words:** A4 gets its quote.
- **A search of Ashgrove's current news (up to six searches, two page fetches):** B8 and A7 grounded in a newer source than July 2026.
- **A tuesday-dossier.md from an earlier session:** verified evidence and the objections already rehearsed, so B3 and B4 can be sharpened.
