Your prep pack is saved as `/tmp/claude-0/-var-tmp-tuesday-measure-1a6-runs-haiku-alone-part-2-rooms-case-6-denied-f00a80cf/511a757c-6c1d-4047-8ba1-4dd44f2ba2df/scratchpad/Larkfield_engineering-manager_interview_pack.md`. It's built on your role summary and background. Web search was refused in this session, so there's no company research, and with no interviewer names I used round-type priors.

# Larkfield Systems: Engineering Manager, prep for three rounds

**Rounds:** (1) Tuesday, 45 min, hiring manager (Director of Engineering). (2) Thursday after, 60 min panel: two staff engineers and a product manager. (3) Following Monday, 30 min, VP Engineering, "values and leadership philosophy."

## How to use + type key

Personas are how a question is asked. Types are what it scores.

- **VAL**: values and leadership, tested through past behaviour.
- **EXP**: your own experience, and whether it survives scrutiny.
- **JD**: the stated role requirements, gaps included.
- **CO**: company and strategy knowledge. None here, because research did not run.
- **CASE**: a live problem from the role.

Guidance is scaffolding for a spoken answer, not a script. Answer slots are instructions for the interview, not questions to answer here.

## The fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" (role summary) | "3 as a team lead of 6" (your message) | medium | [grounded] | transferability | Your material shows one team of six for three years, not two squads or device services. Words: "I've spent three years as a team lead of six." Answer slot: if you set priorities across more than one group, say how; if not, say so and describe the team of six. |
| F2 | "own delivery, hiring and growth for 11 engineers" (role summary): hiring | "I run our hiring loop for backend roles — about 40 interviews last year" (your message) | medium | [grounded] | none | The quote reaches hiring. Words: "I run our hiring loop for backend roles." Keep the scope at backend roles; don't widen it to the organisation. |
| F3 | same requirement: growth | none given | none | [grounded] | discovery | Your material doesn't show growth of engineers. Answer slot: describe a time you grew an engineer; if there is none, say so and say what you'd do first. |
| F4 | same requirement: delivery | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" (your message) | medium | [grounded] | transferability | Reliability work under roadmap pressure, not delivery across two squads. Words: that sentence, at its own scope. Answer slot: describe how you'd show delivery across two squads. |
| F5 | "partner with hardware and product on roadmap" (role summary): hardware | "never owned a hardware-adjacent roadmap" (your message) | none | [grounded] | capability | Your stated absence. Words: "I haven't owned a hardware-adjacent roadmap." Then how you'd learn it, as a plan, never as a past. |
| F6 | same requirement: product | none given | none | [grounded] | discovery | Your material doesn't show a roadmap decision made with product. Answer slot: describe one; if there is none, say so and say how you'd start. |
| F7 | Two squads for 11 engineers implies squad leads, so a manager-of-managers role (my inference; not in the role summary) | "I've never managed managers" (your message) | none | [inferred] | capability | Your stated absence. Words: "I haven't managed managers." Then the plan for learning it. The upgrade menu asks whether squads have leads, which decides how much this row weighs. |

**Requirement coverage:** "Lead two squads" → H1, H3, V3. "Own delivery" → H3, H5, P2. "Hiring" → H3, H6. "Growth for 11 engineers" → V4. "Partner with hardware" → H2, H3, P3, P4. "Partner with product" → P3. "Manager-of-managers" (F7) → H1, V3. "Values and leadership philosophy" → V1, V2, V6. Nothing is uncovered.

## Persona weights

| Round | Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|---|
| 1. Hiring manager | Skeptic | Probes the two-squad line and the managers gap | High. The boss owns the derisking decision, and F7 is the obvious gap | Rehearse the gap sentence until it's plain; hold through two follow-ups |
| 1. Hiring manager | Case/Strategist | Live roadmap and hardware problems | High. The hiring manager is buying capability | Clarify first, then structure |
| 1. Hiring manager | Data-Driven Prober | Asks how the 60% was counted | Medium. One headline figure | Name the weakest assumption first |
| 1. Hiring manager | Pressure | Tests composure on the gap | Medium | Pause, restate, hold |
| 1. Hiring manager | Conversational | Opens with "the journey" | Low, but scored | 90-second arc |
| 2. Panel | Peer Evaluator | Seams, disagreement, credit | High. Staff engineers price partnership | Propose seam principles, not an invented seam |
| 2. Panel | Data-Driven Prober | Denominators from the staff engineers | Medium-high | Name the weakest assumption |
| 2. Panel | Case/Strategist | Hardware-product trade-off from the PM | Medium-high | Clarify, then state the decision and what's reversible |
| 2. Panel | Skeptic | Hardware and managers gaps | Low-medium | Plain acknowledgment, then plan |
| 3. VP | Values/Behavioral | "Values and leadership philosophy" | High. The recruiter's own words | One sentence you can point to; one story |
| 3. VP | Pressure | Skip-level composure | Medium | Concede the gap first; hold the plan |
| 3. VP | Case/Strategist | Altitude on the roadmap | Low-medium. Generic, since research didn't run | One view, assumption named |

## Question banks

**Round 1 (hiring manager)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "You've spent three years as a team lead of six. What makes you ready to lead two squads when you've never managed managers?" | JD | [grounded] "3 as a team lead of 6" (your message); [grounded] "I've never managed managers" (your message) | **Highest-ROI prep in this pack.** Say the facts in your own words: three years, a team of six. Concede the gap in the same sentence: you haven't managed managers. Then your first 90 days, as a plan. Hold through two follow-ups by returning to the team and the plan. Concede only the gap you've stated. | The most predictable objection, asked in some form in this round. F1 and F7 supply the sentences. |
| H2 | "Two squads share one device-management roadmap, and hardware reports a slip on a shared dependency. What do you do first?" | CASE | [generic] | Clarify before structuring: who owns the dependency, what the hardware team's constraint is, what's fixed and what can move. Then decide this week versus next, and name who you'd bring in. No claim about past work. | A live problem from the hardware line (F5). Generic: a pattern, not a fact about this employer. |
| H3 | "In your first quarter, how would you split your time across delivery, hiring and the hardware and product partnership?" | JD | [grounded] "partner with hardware and product on roadmap" (role summary); [grounded] "I run our hiring loop for backend roles" (your message) | Map what you already do: the hiring loop, in those words. Then a plan for the squads and the partnership, labelled as a plan. Answer slot: the hardware partnership is new to you; say so and say what you'd learn first. | F2 supports hiring; F5 is the stated gap. The time split is the probe. |
| H4 | "Your team's on-call burden dropped 60%. How was that counted, and which part was yours?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" (your message) | Say how you measured it, in your own words. Name the assumption behind the figure you'd defend least, before they do. Say which part was yours: you pushed the quarter through; say what the team did. Answer slot: if you can't say how it was counted, say so plainly. The drop was your team's; don't claim it alone. | F4. The figure raises defend-the-number slots only. A prober drill. |
| H5 | "Tell me about a time you held a delivery commitment against senior pressure." | EXP | [grounded] "pushed a reliability quarter through against roadmap pressure" (your message) | Open prompt. Your instance is the reliability quarter, as the sentence states it. Answer slot: if someone senior pushed back, say who and what you held; if it went differently, say how. Hold through two follow-ups; concede only real uncertainty. | F4. The quote supplies the held position, so the hold has a source. |
| H6 | "Hiring for backend roles is different from hiring for device services. How would you change the loop?" | JD | [grounded] "I run our hiring loop for backend roles" (your message) | Say what you'd keep from your loop, what you'd change, and what you'd learn first. Answer slot: if you've assessed for hardware-adjacent skills, say how; if not, say you'd learn it, then how. | F2 is the hiring evidence. |
| H7 | "So — walk me through the journey." | Conversational | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" (your message) | A 90-second arc: nine years in engineering; three as a team lead of six; the payments company; the hiring loop; the reliability quarter. Say each beat in your words; add no roles. | The opener is scored. The hiring manager hears this first. |

**Round 2 (panel)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Our teams sit side by side. Where's the seam between your squads and ours, and what happens when we disagree?" | JD | [generic] persona stem | Propose seam principles rather than pretending to know the seam. Say what you'd need from them and what you'd bring to their team. | Peer stem. Staff engineers price partnership. |
| P2 | "You say on-call burden dropped 60%. Which assumption behind that figure would you defend least?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" (your message) | Name the weakest assumption in your own words before they do. Answer slot: if you don't know how the figure was counted, say so plainly. Don't offer a method you can't repeat under a second question. | F4. Staff engineers will push the denominator. |
| P3 | "Hardware has a slip and product wants the feature. Walk us through the trade-off." | CASE | [generic] | Clarify what's fixed. Name the questions you'd put to hardware. Then state the decision, who makes it, and what's reversible. No claim about past work. | The PM's trade-off, from the hardware-and-product line. |
| P4 | "You've never owned a hardware-adjacent roadmap. Where would you learn it, and from whom?" | JD | [grounded] "never owned a hardware-adjacent roadmap" (your message) | Acknowledge first: "I haven't owned a hardware-adjacent roadmap." Then a plan: which kinds of people and documents you'd learn from. Describe roles, not names. Never claim a hardware roadmap. | F5. The plain acknowledgment has its source: your sentence. |
| P5 | "How do you handle credit when work spans teams?" | EXP | [generic] persona stem | Pick a time work spanned teams; say whose work it was and who got credit. Answer slot: if the reliability quarter crossed teams, say how; if none of your work did, say what you'd do. | Peer stem. Your material doesn't show a cross-team instance. |

**Round 3 (VP Engineering).** No published values are in hand, so there's no values cheat sheet. The recruiter's words are the raising source.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V1 | "What's your leadership philosophy, in a sentence, and where did it come from?" | VAL | [grounded] "values and leadership philosophy" (recruiter); [grounded] "pushed a reliability quarter through against roadmap pressure" (your message) | One sentence you can point to in your work. Beats your material supports: the reliability quarter, the team of six, the hiring loop. Answer slot: if the sentence you'd give isn't one you can point to, say that and give the nearest thing your material carries. | The recruiter named this round's theme. The question asks for your statement. |
| V2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "pushed a reliability quarter through against roadmap pressure" (your message) | Open prompt. Your instance is the reliability quarter. Answer slot: if leadership pushed back and you held, say who and what; if it went another way, say how. Put the hard truth in the first 30 seconds. | Your material doesn't show how leadership received it. |
| V3 | "Sixty seconds: why should we bet on you for two squads when you haven't managed managers?" | Pressure | [grounded] "I've never managed managers" (your message); [grounded] "3 as a team lead of 6" (your message) | Concede the gap in the first sentence, then your evidence: three years, a team of six. Hold through two follow-ups with your 90-day plan. Concede only what you don't know. Don't fold to "I'm ready." | Skip-level composure. Your stated negative sources the premise. |
| V4 | "How do you grow an engineer into a lead?" | VAL | [generic] | Answer slot: if you've grown someone into a lead, say how; if not, say so, then name the criteria and first stretch you'd use. | Growth has no quote (F3), so the slot is the honest form. |
| V5 | "Where should device management sit on our roadmap over the next two years?" | CASE | [generic] | State one view, name its assumption, and say what would change it. Clarify first what the company has said. No claim about past work. | Altitude. Check the published strategy before the round. |
| V6 | "Who has shaped your leadership, and what did you change because of them?" | VAL | [grounded] "3 as a team lead of 6" (your message) | Name one person, what they did, and what you changed. Answer slot: if no one comes to mind, say so and give the nearest thing your material carries. | Leadership philosophy as an open prompt. |

## Reverse questions

No interviewer profile exists, so none ties to an interviewer's path.

**Round 1:** "What would the first 90 days need to deliver for these two squads?" (shows you're planning). "Where do the squads' roadmaps and the hardware schedule most often collide?" (meets the hardware gap head-on). "What have hardware and product asked this group for that engineering hasn't yet delivered?" (finds the real backlog). "What would make you say at 90 days that this hire was right?" (tests what success means). "If you could change one thing about the squads' hiring plan for next year, what would it be?" (invites their view).

**Round 2:** "What could a new person do in their first month that would genuinely help your teams?" (reciprocity, which peers weight heavily). "Where does on-call sit between your teams and the squads today?" (puts the reliability story where it belongs). "What's the biggest roadmap risk product sees for device management?" (tests the PM's view on P3's trade-off). "What do the staff engineers wish the squads did differently?" (surfaces the seam). "What would you need from a new manager before trusting them with the hardware roadmap?" (turns the gap into a shared question).

**Round 3:** "What does leadership philosophy look like in practice for the engineering leaders here?" (tests the recruiter's framing against the VP's). "What's the hardest leadership decision you've made in the past year?" (invites candour at the VP's altitude). "How do you weigh reliability work against roadmap commitments when they compete?" (ties to the reliability quarter). "What would you want this manager to do in their first six months that the teams haven't had?" (shows you're thinking about the role). "What would make you regret hiring the wrong manager for these squads?" (tests what they fear).

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| "I led two squads" or "I've managed managers" | Inflated form of F1; contradicted by F7 | F1's quote at its own scope: "I've spent three years as a team lead of six." Pack observation: your material shows one team of six, not two squads or managers. |
| "I have hardware roadmap experience" | Contradicted by F5 | Plain acknowledgment from F5: "I haven't owned a hardware-adjacent roadmap." |
| "I ran hiring for the whole organisation" | Inflated form of F2 | F2's quote at its own scope: "I run our hiring loop for backend roles." Pack observation: the material says backend roles. |
| "The 60% drop was my result alone" | Inflated form of F4 | The sentence at its own scope: "after I pushed a reliability quarter through." Pack observation: the drop is your team's; your material doesn't show how much was yours. |

## Sources

- **Provided:** your message (role summary, background, and the recruiter's phrase "values and leadership philosophy").
- **Research tier:** L1. Searches 0 of 6 (both refused by the host); fetches 0 of 2.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Larkfield Systems values | unavailable | Values cheat sheet, dropped: no published values in hand. Query refused: "Larkfield Systems industrial IoT company values" |
| 2. Larkfield Systems interview process, engineering manager | unavailable | Loop structure; persona weights follow the named rounds. Query refused: "Larkfield Systems engineering manager interview process" |
| 3. Larkfield Systems strategy / recent news | unavailable | Would have moved V5. No call sent; host search not permitted. |
| 4. {interviewer name} Larkfield Systems | n/a | No interviewer names given. |
| 5. Representative Engineering Manager JD | unavailable | Would have firmed up the role-family requirements. No call sent; host search not permitted. |

## Upgrade menu

- **The Thursday panel's format** (a presentation, take-home, or named focus areas) → coverage of any pre-declared deliverable. Usually one email to the recruiter.
- **Whether the two squads have leads under them** → confirms or drops F7, and shifts the weight of H1 and V3. Usually one email to the recruiter.
- **Your current CV** → the fit-snapshot quotes come from your CV, not only your message.
- **The full job description** → the role-summary rows become quotes from the posting, and any inferred requirement becomes sourced.
- **Interviewer names** → an interviewer read, persona weights per panel member, and personalised reverse questions.
- **The company's values page, pasted** → the values cheat sheet, with V4 and V6 given mapped stories where your material carries them.
- **Web search allowed for this session** → retry L1, or the deep tier (L2: strategy brief, interviewer talks, loop reports, recent news), which firms up V5 and the round structure.
- **A `tuesday-dossier.md`, if you have one** → verified evidence from earlier sessions, and its prohibited claims, binding every guidance cell.

---

**Offers:**
- Want a live drill? I can play the Skeptic on H1, the highest-ROI question in the pack.
- I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions.
- If you'd like the pack as a Word document, say so and I'll convert it.

**Questions:**
1. Does Thursday's panel include a presentation or take-home, or did the recruiter name focus areas?
2. Does the role require on-site days, and does that fit you?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Larkfield_engineering-manager_interview_pack.md -----
# Larkfield Systems: Engineering Manager, prep for three rounds

**Role:** Engineering Manager, Larkfield Systems (industrial IoT, ~600 people). Two squads on device-management services; delivery, hiring and growth for 11 engineers; hardware and product partnership on the roadmap.
**Rounds:** (1) Tuesday, 45 min, hiring manager, Director of Engineering. (2) Thursday after, 60 min panel: two staff engineers and a product manager. (3) Following Monday, 30 min, VP Engineering, "values and leadership philosophy".
**Interviewer names:** none given. Interviewer read and personalised reverse questions are absent; personas use round-type priors.
**Research:** web search was refused in this session. The pack has no company values, strategy or loop-structure research. See Sources.

## How to use + type key

Personas are how a question is asked. Types are what it scores.

- **VAL**: values and leadership, tested through past behaviour.
- **EXP**: your own experience, and whether it survives scrutiny.
- **JD**: the stated role requirements, gaps included.
- **CO**: company and strategy knowledge. None in this pack, because research did not run.
- **CASE**: a live problem from the role.

Guidance is scaffolding for a spoken answer, not a script. Answer slots are instructions for the interview, not questions to answer here.

## The fit snapshot

Requirements are quoted from the role summary you gave, or from your message. Your evidence is quoted verbatim.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" (role summary) | "3 as a team lead of 6" (your message) | medium | [grounded] | transferability | Your material shows one team of six for three years, not two squads or device services. Words: "I've spent three years as a team lead of six." Answer slot: if you set priorities across more than one group, say how; if not, say so and describe the team of six. |
| F2 | "own delivery, hiring and growth for 11 engineers" (role summary): hiring | "I run our hiring loop for backend roles — about 40 interviews last year" (your message) | medium | [grounded] | none | The quote reaches hiring. Words: "I run our hiring loop for backend roles." Keep the scope at backend roles; do not widen it to the organisation. |
| F3 | "own delivery, hiring and growth for 11 engineers" (role summary): growth | none given | none | [grounded] | discovery | Your material does not show growth of engineers. Answer slot: describe a time you grew an engineer; if there is none, say so and say what you would do first. |
| F4 | "own delivery, hiring and growth for 11 engineers" (role summary): delivery | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" (your message) | medium | [grounded] | transferability | This is reliability work under roadmap pressure, not delivery across two squads. Words: that sentence, at its own scope. Answer slot: describe how you would show delivery across two squads. |
| F5 | "partner with hardware and product on roadmap" (role summary): hardware | "never owned a hardware-adjacent roadmap" (your message) | none | [grounded] | capability | Your stated absence. Words: "I haven't owned a hardware-adjacent roadmap." Then how you would learn it, said as a plan, never as a past. |
| F6 | "partner with hardware and product on roadmap" (role summary): product | none given | none | [grounded] | discovery | Your material does not show a roadmap decision made with product. Answer slot: describe one; if there is none, say so and say how you would start. |
| F7 | Two squads for 11 engineers implies squad leads, so a manager-of-managers role (this pack's inference; not in the role summary) | "I've never managed managers" (your message) | none | [inferred] | capability | Your stated absence. Words: "I haven't managed managers." Then the plan for learning it. The upgrade menu asks whether squads have leads, which decides how much this row weighs. |

Requirement coverage: "Lead two squads" → H1, H3, V3. "Own delivery" → H3, H5, P2. "Hiring" → H3, H6. "Growth for 11 engineers" → V4. "Partner with hardware" → H2, H3, P3, P4. "Partner with product" → P3. "Manager-of-managers" (F7) → H1, V3. "Values and leadership philosophy" (recruiter) → V1, V2, V6. No requirement is uncovered.

## Persona weights

Round-type priors, with no interviewer signals.

| Round | Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|---|
| 1. Hiring manager | Skeptic | Probes the two-squad line and the managers gap | High. The boss owns the derisking decision, and F7 is the obvious gap | Rehearse the gap sentence until it is plain; hold through two follow-ups |
| 1. Hiring manager | Case/Strategist | Live roadmap and hardware problems | High. The hiring manager buys capability | Clarify first, then structure |
| 1. Hiring manager | Data-Driven Prober | Asks how the 60% was counted | Medium. One headline figure | Name the weakest assumption first |
| 1. Hiring manager | Pressure | Tests composure on the gap | Medium | Pause; restate; hold |
| 1. Hiring manager | Conversational | Opens with the journey | Low. An opener, but scored | 90-second arc |
| 2. Panel | Peer Evaluator | Seams, disagreement, credit | High. Staff engineers price partnership | Propose seam principles, not a made-up seam |
| 2. Panel | Data-Driven Prober | Denominators from the staff engineers | Medium-high | Name the weakest assumption |
| 2. Panel | Case/Strategist | Hardware-product trade-off from the PM | Medium-high | Clarify, then state the decision and what is reversible |
| 2. Panel | Skeptic | Hardware and managers gaps | Low-medium | Plain acknowledgment, then plan |
| 3. VP Engineering | Values/Behavioral | "Values and leadership philosophy" | High. The recruiter's own words | One sentence you can point to; one story |
| 3. VP Engineering | Pressure | Skip-level composure | Medium | Concede the gap first; hold the plan |
| 3. VP Engineering | Case/Strategist | Altitude on the roadmap | Low-medium. Generic, as research did not run | One view, assumption named |

## Question banks

Round 1 (hiring manager): Skeptic 5, Case 4, Prober 2, Pressure 2, Conversational 1.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "You've spent three years as a team lead of six. What makes you ready to lead two squads when you've never managed managers?" | JD | [grounded] "3 as a team lead of 6" (your message); [grounded] "I've never managed managers" (your message) | **Highest-ROI prep in this pack.** Say the facts in your own words: three years, a team of six. Concede the gap in the same sentence: you haven't managed managers. Then your first 90 days, said as a plan. Hold through two follow-ups by returning to the team of six and the plan. Concede only the gap you have stated. | The most predictable objection, asked in some form in this round. F1 and F7 supply the sentences. |
| H2 | "Two squads share one device-management roadmap, and hardware reports a slip on a shared dependency. What do you do first?" | CASE | [generic] | Clarify before structuring: which squad owns the dependency, what the hardware team's constraint is, what is fixed and what can move. Then decide this week versus next, and name who you would bring in. Make no claim about past work. | A live problem from the role's hardware line (F5). Generic: a pattern for the problem, not a fact about this employer. |
| H3 | "In your first quarter, how would you split your time across delivery, hiring and the hardware and product partnership?" | JD | [grounded] "partner with hardware and product on roadmap" (role summary); [grounded] "I run our hiring loop for backend roles" (your message) | Map what you already do: the hiring loop, in those words. Then a plan for the two squads and the partnership, labelled as a plan. Answer slot: the hardware partnership is new to you; say so, and say what you would learn first. | F2 supports the hiring part; F5 is the stated gap. The time split is the probe. |
| H4 | "Your team's on-call burden dropped 60%. How was that counted, and which part was yours?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" (your message) | Say how you measured it, in your own words. Name the assumption behind the figure you would defend least, before they do. Say which part was yours: you pushed the quarter through; say what the team did. Answer slot: if you cannot say how it was counted, say so plainly. The drop was your team's; do not claim it alone. | F4. The figure raises defend-the-number slots only. A prober drill. |
| H5 | "Tell me about a time you held a delivery commitment against senior pressure." | EXP | [grounded] "pushed a reliability quarter through against roadmap pressure" (your message) | Open prompt. Your instance is the reliability quarter: the quarter, the roadmap pressure, the push through, as the sentence states them. Answer slot: if someone senior pushed back, say who and what you held; if it went differently, say how. Hold the position through two follow-ups; concede only the uncertainty you have. | F4. The quote supplies the held position, so the hold has a source. |
| H6 | "Hiring for backend roles is different from hiring for device services. How would you change the loop?" | JD | [grounded] "I run our hiring loop for backend roles" (your message) | Say what you would keep from your loop, what you would change, and what you would learn first. Answer slot: if you have assessed for hardware-adjacent skills, say how; if not, say you would learn it, then how. | F2 is the hiring evidence. |
| H7 | "So — walk me through the journey." | Conversational | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" (your message) | A 90-second arc: nine years in engineering; three as a team lead of six; the payments company; the hiring loop; the reliability quarter. Say each beat in your words; add no roles. | The opener is scored. This is what the hiring manager hears first. |

Round 2 (panel): Peer Evaluator 4, Prober 3, Case 3, Skeptic 2, Pressure 2.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Our teams sit side by side. Where's the seam between your squads and ours, and what happens when we disagree?" | JD | [generic] persona stem | Propose seam principles rather than pretending to know the seam. Say what you would need from them and what you would bring to their team. | Peer stem. Staff engineers price partnership. Generic: no interviewer names are known. |
| P2 | "You say on-call burden dropped 60%. Which assumption behind that figure would you defend least?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" (your message) | Name the weakest assumption in your own words before they do. Answer slot: if you do not know how the figure was counted, say so plainly. Do not offer a method you cannot repeat under a second question. | F4. Staff engineers will push the denominator. Same figure as H4, asked from the other side. |
| P3 | "Hardware has a slip and product wants the feature. Walk us through the trade-off." | CASE | [generic] | Clarify what is fixed. Name the questions you would put to hardware. Then state the decision, who makes it, and what is reversible. Make no claim about past work. | PM's trade-off. Generic, from the role's hardware-and-product line. |
| P4 | "You've never owned a hardware-adjacent roadmap. Where would you learn it, and from whom?" | JD | [grounded] "never owned a hardware-adjacent roadmap" (your message) | Acknowledge first: "I haven't owned a hardware-adjacent roadmap." Then a plan: which kinds of people and which documents you would learn from. Describe roles, not names. Never claim a hardware roadmap. | F5. The plain acknowledgment has its source: your sentence. |
| P5 | "How do you handle credit when work spans teams?" | EXP | [generic] persona stem | Pick a time work spanned teams. Say whose work it was and who got credit. Answer slot: if the reliability quarter crossed teams, say how; if none of your work did, say what you would do. | Peer stem. Credit is a seam probe, and your material does not show a cross-team instance. |

Round 3 (VP Engineering): Values/Behavioral 5, Pressure 3, Case 2, Conversational 1. No published values are in hand, so no values cheat sheet; the recruiter's words are the raising source.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V1 | "What's your leadership philosophy, in a sentence, and where did it come from?" | VAL | [grounded] "values and leadership philosophy" (recruiter); [grounded] "pushed a reliability quarter through against roadmap pressure" (your message) | Give one sentence you can point to in your work. Beats your material supports: the reliability quarter, the team of six, the hiring loop. Answer slot: if the sentence you would give is not one you can point to, say that and give the nearest thing your material carries. | The recruiter named this round's theme. The question asks for your statement, not ours. |
| V2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "pushed a reliability quarter through against roadmap pressure" (your message) | Open prompt. Your instance is the reliability quarter, as the sentence states it. Answer slot: if leadership pushed back and you held, say who and what; if it went another way, say how, in your own words. Put the hard truth in the first 30 seconds. | A values stem. Your material does not show how leadership received the truth. |
| V3 | "Sixty seconds: why should we bet on you for two squads when you haven't managed managers?" | Pressure | [grounded] "I've never managed managers" (your message); [grounded] "3 as a team lead of 6" (your message) | Concede the gap in the first sentence, then your evidence: three years, a team of six. Hold through two follow-ups with your 90-day plan. Concede only what you do not know. Do not fold to "I'm ready." | Skip-level composure. The stated negative sources the premise. |
| V4 | "How do you grow an engineer into a lead?" | VAL | [generic] | Answer slot: if you have grown someone into a lead, say how, in your own words; if not, say so, then name the criteria and first stretch you would use. | Growth has no quote (F3), so the slot is the honest form. |
| V5 | "Where should device management sit on our roadmap over the next two years?" | CASE | [generic] | State one view, name its assumption, and say what would change it. Clarify first what the company has said. Make no claim about past work. | Altitude. Research did not run, so this is generic; check the published strategy before the round. |
| V6 | "Who has shaped your leadership, and what did you change because of them?" | VAL | [grounded] "3 as a team lead of 6" (your message) | Name one person, what they did, and what you changed. Answer slot: if no one comes to mind, say so and give the nearest thing your material carries. | Leadership philosophy as an open prompt. |

## Reverse questions

No interviewer profile exists, so none ties to an interviewer's own path.

**Round 1 (hiring manager)**
- "What would the first 90 days need to deliver for these two squads?" Why it lands: shows you are planning, not waiting for an offer.
- "Where do the squads' roadmaps and the hardware schedule most often collide?" Why it lands: meets the hardware gap head-on.
- "What have hardware and product asked this group for that engineering has not yet delivered?" Why it lands: shows you are looking for the real backlog.
- "What would make you say at the 90-day mark that this hire was right?" Why it lands: tests what success means to them.
- "If you could change one thing about the squads' hiring plan for next year, what would it be?" Why it lands: invites their own view on the hiring you would run.

**Round 2 (panel)**
- "What could a new person do in their first month that would genuinely help your teams?" Why it lands: reciprocity, which peers weight heavily.
- "Where does on-call sit between your teams and the squads today?" Why it lands: puts the reliability story where it belongs.
- "What is the biggest roadmap risk product sees for device management?" Why it lands: tests the PM's view on the same trade-off as P3.
- "What do the staff engineers wish the squads did differently?" Why it lands: surfaces the seam directly.
- "What would you need from a new manager before you trusted them with the hardware roadmap?" Why it lands: turns the hardware gap into a shared question.

**Round 3 (VP Engineering)**
- "What does leadership philosophy look like in practice for the engineering leaders here?" Why it lands: tests the recruiter's framing against the VP's own.
- "What is the hardest leadership decision you have made in the past year?" Why it lands: invites candour at the VP's altitude.
- "How do you weigh reliability work against roadmap commitments when they compete?" Why it lands: ties to the reliability quarter.
- "What would you want this manager to do in their first six months that the teams have not had?" Why it lands: shows you are thinking about the role, not the offer.
- "What would make you regret hiring the wrong manager for these squads?" Why it lands: tests what they fear.

## Prohibited claims

What this pack will not coach, and why. Built from the fit snapshot.

| Not coached | Basis | Honest form |
|---|---|---|
| "I led two squads" or "I've managed managers" | Inflated form of F1; contradicted by F7's quote | F1's quote at its own scope: "I've spent three years as a team lead of six." Pack observation: your material shows one team of six, not two squads or managers. |
| "I have hardware roadmap experience" | Contradicted by F5's quote | Plain acknowledgment from F5: "I haven't owned a hardware-adjacent roadmap." |
| "I ran hiring for the whole organisation" | Inflated form of F2 | F2's quote at its own scope: "I run our hiring loop for backend roles." Pack observation: the material says backend roles. |
| "The 60% drop was my result alone" | Inflated form of F4 | The sentence at its own scope: "after I pushed a reliability quarter through." Pack observation: the drop is your team's, and your material does not show how much was yours. |

## Sources

- **Provided:** your message (role summary, background, and the recruiter's phrase "values and leadership philosophy").
- **Research tier:** L1, searches 0 of 6 (both refused by the host), fetches 0 of 2.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Larkfield Systems values` | unavailable | Values cheat sheet (section dropped: no published values in hand). Query refused: "Larkfield Systems industrial IoT company values". |
| 2. `Larkfield Systems interview process engineering manager` | unavailable | Loop structure; persona weights follow the named rounds. Query refused: "Larkfield Systems engineering manager interview process". |
| 3. `Larkfield Systems strategy` / recent news | unavailable | Would have moved V5 (altitude). No call sent; host search not permitted. |
| 4. `{interviewer name} Larkfield Systems` | n/a | No interviewer names were given. |
| 5. representative `Engineering Manager` JD | unavailable | Would have firmed up the role-family requirements. No call sent; host search not permitted. |

## Upgrade menu

- **The Thursday panel's format** (a presentation, take-home, or named focus areas) → coverage of any pre-declared deliverable. Usually one email to the recruiter.
- **Whether the two squads have leads under them** → confirms or drops F7 and shifts the weight of H1 and V3. Usually one email to the recruiter.
- **Your current CV** → the fit-snapshot quotes come from your CV, not only from your message.
- **The full job description** → the role-summary rows become quotes from the posting, and any inferred requirement becomes sourced.
- **Interviewer names** → the interviewer read, persona weights per panel member, and personalised reverse questions.
- **The company's published values page, pasted** → the values cheat sheet, with V4 and V6 given mapped stories where your material carries them.
- **Web search allowed for this session** → retry the L1 research, or the deep tier (L2: strategy brief, interviewer talks, role-family loop reports, recent news), which firms up V5 and the round structure.
- **A `tuesday-dossier.md`, if you have one** → verified evidence from earlier sessions, and its prohibited claims, bind every guidance cell.
