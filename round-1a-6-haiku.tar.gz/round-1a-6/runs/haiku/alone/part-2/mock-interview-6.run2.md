Your prep pack is saved at `/var/tmp/tuesday-measure/1a6/runs/haiku/alone/part-2/rooms/case-6-denied-e02fd0ac/Larkfield_engineering-manager_interview_pack.md`. It has a shared fit snapshot, prohibited claims, a persona table, question bank and reverse questions for each round, and a coverage table against the role.

I built it from your role summary and your message. Both web searches were refused, so there are no Larkfield values, interview structure or strategy in it. The Round 3 values cheat sheet is therefore not built. Your two stated gaps, no hardware-adjacent roadmap and never managed managers, are flagged as gaps, not covered with bridges.

Where to focus: B1 ("Which part of this role would you be weakest at on day one?") is the highest-return prep. It is the Round 1 question most likely to come up in some form, and the honest answer is to name the hardware-roadmap gap first and bring a learning plan. C1 and D2 are the 60% on-call figure. Know how it was counted and which assumption you would defend least, and say plainly if you don't know.

Say the word and I'll play the Skeptic on B1 as a live drill. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions, and convert the pack to Word if you'd like.

Two questions would sharpen it:
1. Can you paste the full job description? That would turn the role-summary rows into exact quotes and catch any requirement I've missed.
2. Does the recruiter's note say what the panel will focus on, or whether any round includes a presentation or take-home?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Larkfield_engineering-manager_interview_pack.md -----
# Interview prep pack: Engineering Manager, Larkfield Systems

Three rounds, one fit snapshot, one set of prohibited claims.

| Round | When | Who | Length | Persona weights |
|---|---|---|---|---|
| 1. Hiring manager | Tuesday | Director of Engineering (your would-be boss) | 45 min | Case and Skeptic, then Prober |
| 2. Panel | Thursday after | Two staff engineers, one product manager | 60 min | Peer and Prober (staff engineers), Case (product manager) |
| 3. VP Engineering | Following Monday | VP Engineering, recruiter's note: "values and leadership philosophy" | 30 min | Values, then Pressure and Conversational |

Interviewer names are not in your material, so no interviewer profile is read and the persona weights are round-type priors.

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what it scores.
- Type key: **VAL** behavioral and values; **EXP** your own experience, probed; **JD** the role's stated requirements; **CASE** a live problem; **CO** company and strategy (not built: no research ran).
- Guidance is scaffolding, not a script. Lines that begin "Answer slot" are instructions for the interview. They are not questions for you to answer here.
- Every claim about your past is one of your own sentences, quoted. Where the material does not show something, the pack says so and leaves the words to you.

## Fit snapshot

Requirements come from your role summary, which stands in for the job description. Evidence is quoted from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own delivery, hiring and growth for 11 engineers" (your role summary) | "9 years engineering, 3 as a team lead of 6, currently at a payments company." (your message); "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." (your message) | medium | [grounded] | transferability | Your material shows a team of six and one reliability quarter, not two squads or 11 people. Say the team of six at its own size. Answer slot: how you would split delivery across two squads is a plan, so say it as a plan. |
| F2 | "own delivery, hiring and growth for 11 engineers" (your role summary) | "I run our hiring loop for backend roles — about 40 interviews last year." (your message) | medium | [grounded] | none | No gap at the level of running a loop. Lead with the loop in your own terms. The quote is backend hiring, so do not stretch it to hardware roles (see F5). |
| F3 | "growth for 11 engineers" (your role summary) | none given | none | [grounded] | discovery | Your material says nothing about growing engineers into new roles. Answer slot: if you have promoted or grown someone, say how; if you have not, say so, then say what criteria you would use. |
| F4 | "partner with hardware and product on roadmap" (your role summary) | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." (your message) | medium | [grounded] | transferability | Your material shows you pushing a reliability quarter through roadmap pressure in software work. It does not show partnering on a roadmap with hardware or with product. Keep the bridge at that scope: what you held, and how. |
| F5 | "partner with hardware and product on roadmap" (your role summary) | "I've never managed managers and never owned a hardware-adjacent roadmap." (your message) | none | [grounded] | capability | A gap you have stated. Words: "never owned a hardware-adjacent roadmap." Then how you would learn it, said as a plan, never as a past. |

**Not a row, but a gap:** managing managers. Your role summary lists no manager layer, so it is not a requirement here. If the two squads have leads under you, managing them becomes one, and your stated absence in F5 becomes a capability gap at that level. Check the full job description for it (see the upgrade menu).

## Prohibited claims

Claims this pack will not coach, and why. They bind every answer cell below.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned a hardware-adjacent roadmap | Your stated negative (F5) | Plain acknowledgment only: "I've never owned a hardware-adjacent roadmap." No slot. |
| Managed managers | Your stated negative, same sentence as F5 | Plain acknowledgment only: "I've never managed managers." No slot. |
| Caused the 60% on-call drop | Inflated form of the 60% sentence (F4): "after" stretched to "because of" | The quote at its own scope: "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." Limit, as this pack's observation: your material says "after," not "because of." |
| Designed the hiring process | Inflated form of F2: "run our hiring loop" stretched to "designed" | The quote at its own scope: "I run our hiring loop for backend roles." Limit, as this pack's observation: your material shows running the loop, not designing it. |

## Round 1: Hiring manager (Tuesday, 45 min)

### Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | A live problem on the squads' roadmap, with the hardware team in it | High. Hiring managers buy capability and test it on their real roadmap; the role names the hardware partnership. | Clarify before you structure. Say the objective, the dependencies and the risks. Think aloud and challenge one premise. |
| Skeptic | "Which part would you be weakest at?", and the gaps F5 and the managers absence | High. Your two stated gaps sit where a hiring manager derisks. | Name the gap first, then the ramp plan. Do not bluff a competency the interviewer owns. |
| Data-Driven Prober | Follow-ups on the 60% figure | Medium. Headline numbers get probed, and a Director may check the one on your CV. | Say how it was counted if you know. Name the weakest assumption. Say plainly when you do not know. |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Two squads, one device fleet: a firmware rollout fails on 3% of devices, and the hardware team wants to ship a new feature this sprint. What do you need to know first?" | CASE | [generic] | Clarify before structuring: which devices, what the failure covers, what the feature's risk is, who can say no. Then approach, risks and what you would tell product. Think aloud. The question makes no claim about your past. | A live problem from the role's hardware partnership. [generic] because it is a pattern for the role, not this team's practice. |
| A2 | "What would your first 90 days look like leading two squads you have not run before?" | CASE | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Plan in order: learn the two squads and their delivery and on-call data, meet the hardware and product leads, then decide what changes. You may name the reliability quarter as the thing you would look for first. Do not promise its result. | Tests delivery ownership at the scale of the role (F1, transferability). The quote is a reference point for the method, not evidence of two squads. |
| A3 | "How would you run hiring for hardware-adjacent skills the team does not have yet?" | CASE | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Say what you would keep from the backend loop, what you would change for hardware skills, and who you would bring in to set the bar. Do not claim hardware hiring experience. | Tests whether your hiring transfers when the domain does not (F2 and F5). |
| B1 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "I've never owned a hardware-adjacent roadmap." | Name it first, in your words: you have never owned a hardware-adjacent roadmap. Then say how you would learn it in the first month: whom you would sit with and what you would ask to see. Hold a plan, not a past. | **Highest-ROI prep in this pack.** F5 is your biggest gap, and some form of this question will come. Naming it before they do is the move. |
| B2 | "You've never managed managers. Why would a Director give you this scope?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | Hold through two follow-ups on what the material carries: "3 as a team lead of 6" and "I run our hiring loop for backend roles." Concede specifically: "I haven't managed managers. Here is what I would do first." Do not fold on the scope. | A pressure-style premise taken from your own sentence. The honest hold is the team-of-six evidence, not a claim about managers. |
| B3 | "Why this role, and why now?" | JD | [grounded] "currently at a payments company." | Answer slot: say what you want from this work, in your own words. If the hardware roadmap is part of the pull, say that plainly, since it is also your stated gap. | Motivation probe. Stated as an open prompt, so it presupposes no reason for leaving. |
| C1 | "Walk me through how that 60% on-call number was counted." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Answer slot: say how it was counted, in your words. Name the assumption behind it you would defend least. Say which part was yours. If you do not know how it was counted, say so plainly. | Headline metric from F4. Every CV figure gets a defend-the-number question. The pack supplies no method. |
| C2 | "Who else was on the reliability quarter, and what part of it was yours to decide?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Answer slot: if you decided the scope, say which part and how; if the scope was set above you, say so plainly and say what you did within it. | Separates team result from personal credit. Probers test exactly this. |

### Reverse questions

1. "What would make the first six months a clear success for this role?" Why it lands: it surfaces the scoring, and it shows you plan against the job, not the title.
2. "Which part of the device roadmap is most contested between hardware and software right now?" Why it lands: it shows you know the partnership is the job.
3. "What did the last manager hired into these squads struggle with?" Why it lands: it shows onboarding thinking, and it opens the gap discussion on your terms.
4. "How are the two squads' on-call and incident loads trending this year?" Why it lands: it links to your reliability record without claiming it.
5. "How does the hiring bar for device-management engineers differ from backend?" Why it lands: it tests B1 and A3 directly.

No interviewer profile exists, so no reverse question ties to the Director's career path.

## Round 2: Panel (Thursday, 60 min)

### Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Peer Evaluator | Seams with the firmware team, credit-sharing, "what would you need from me" | High. Staff engineers are peers, and the role's partnership line makes the seam a live topic. | Propose seam principles, not a map you have not seen. Give credit by name. |
| Data-Driven Prober | Follow-ups on the reliability quarter's scope and the 60% | High. Staff engineers verify technical claims, and the 60% is your one hard number. | Name the weakest assumption before they do. Say plainly what you do not know. |
| Case / Strategist (product manager) | Roadmap trade-offs between reliability work and features | High for the product manager. The role's roadmap partnership is their job too. | Clarify the trade-off, state the cost of delay on each side, then propose and defend one trade. |

Panel members have no names here, so personas are blended by seat, not assigned per member.

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through what the reliability quarter covered, and who decided its scope." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Answer slot: if you chose the scope, say how; if it was set elsewhere, say so plainly and say what you did within it. | A staff engineer will test attribution. The question presupposes only that a reliability quarter existed. |
| D2 | "Which assumption behind that 60% would you defend least?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Name the assumption in your own words before they do. If you do not know the assumptions, say that. Do not offer one you cannot repeat under a second question. | The weakest-assumption move, applied to your one hard figure. |
| E1 | "Where's the seam between your squads and the firmware team, and what happens when you disagree?" | JD | [grounded] "partner with hardware and product on roadmap" (your role summary) | Give seam principles: who owns the device contract, who can say no to a feature, how a disagreement escalates. Claim no past hardware seam. | A peer's seam probe, drawn from the role's partnership line. Principles are the honest answer while F5 stands. |
| E2 | "How do you handle credit when work spans your team and another?" | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Credit the other team by name where the work crossed. Say "my team's" for the team's number, not "I". | Credit-sharing is a peer probe. The quote is your one team-level result. |
| E3 | "What would you need from a staff engineer to own a squad's technical direction?" | JD | [generic] | Name what you would need in terms of decision rights and context, and ask them what they have seen fail. Claim no experience. | A peer question about working together, answered as a principle. |
| E4 | "Describe a disagreement with an equal that changed the outcome." | VAL | [grounded] "pushed a reliability quarter through against roadmap pressure" (your message) | Selection scaffold: pick a disagreement with an equal where the outcome moved, and say what changed and whose change it was. If none comes to mind, say so plainly, then give the nearest thing your material carries: the reliability quarter, and what you said to whom. | A peer's disagreement probe. The scaffold keeps the honest branch. |
| F1 | "The reliability work is a fifth of capacity, and product wants two device features this quarter. What do you trade?" | CASE | [generic] | Clarify the capacity assumption and the cost of delay on each feature. Name the risk of the reliability work slipping. Propose one trade and what you would show the PM. | A live roadmap trade-off. The figure is hypothetical, which is why the label is [generic]. |
| F2 | "Which feature would you cut to protect device uptime, and what would make you wrong?" | CASE | [generic] | Structure it: what uptime protects, what the cut costs, and what signal would show the call was wrong. Think aloud. | Tests judgment at the seam with product. The question makes no claim about your past. |

### Reverse questions

1. "What is one thing a new engineering manager could do in the first month that would genuinely help your team?" Why it lands: it is the reciprocity question for a peer panel, and it turns a probe into a working conversation.
2. "Where do your services meet the firmware, and who owns that boundary today?" Why it lands: it maps the seam E1 asks about.
3. "How do you raise a disagreement with product in the middle of a quarter?" Why it lands: it shows you think about the PM relationship, not only the engineers.
4. "What does a good design review look like for device-management changes here?" Why it lands: it signals staff-engineer depth.
5. "What was the most painful on-call incident this year, and what changed after it?" Why it lands: it links to the reliability question without claiming a result.

## Round 3: VP Engineering (following Monday, 30 min)

Values section: not built. The recruiter described this round as values-style, but no published Larkfield values are in hand (the research searches were refused). A values cheat sheet would have to invent the values, so G1 to G4 use selection scaffolds, each with its honest branch.

### Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | "Tell me about a time…", scored on leadership principles | High. The recruiter framed the round around values and leadership philosophy. | Choose the story where the hard truth landed. Say "we" for context and "I" for what you did. Where the material shows none, say so. |
| Pressure / Stress | "You haven't managed managers", "why you over someone who has run a hardware roadmap" | Medium-high. A VP tests composure on the gaps they can see on the CV. | Pause, restate the question, hold through two follow-ups on what is quoted, then concede the gap specifically. |
| Conversational / Rapport | "So, walk me through the journey" | Medium. Casual register, still scored. | Keep a 90-second arc ready from quoted facts only. Treat the hiring question as scored, not chatty. |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Selection scaffold: pick a time you told someone senior what they did not want to hear: a named stake, the moment you did not fold, and the outcome, including any cost. The nearest thing your material carries is the reliability quarter against roadmap pressure: say what you said, to whom, and what happened next. If no such time comes to mind, say so plainly, then give the nearest one you have. | A values prompt. The quote is the nearest evidence, and the scaffold keeps the honest branch. |
| G2 | "What do you do when delivery and on-call load pull in opposite directions?" | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Say the principle you apply and what you did with it, in your words. If the principle you would use differs from what you did, say so. Do not claim an outcome the quote does not carry. | Values answers land the trade-off principle. Your one example is the quote. |
| G3 | "What is your leadership philosophy in one sentence, and where has it failed?" | VAL | [generic] | Give one sentence you would defend. Name a place it failed, from the three years leading six. If nothing in your material shows a failure, say so and name where you would expect it to fail. | An open prompt. [generic] because your material holds no philosophy statement. |
| G4 | "How do you decide which engineer on your team is ready for the next step?" | JD | [grounded] "own delivery, hiring and growth for 11 engineers" (your role summary) | Answer slot: if you have grown someone into a new role, say how and what you saw; if you have not, say so plainly, then give the criteria you would use. Do not describe a promotion you did not make. | Growth is a stated requirement and your material is silent on it (F3). The slot keeps the honest branch. |
| H1 | "You haven't managed managers. What would you do in your first 90 days to avoid becoming a bottleneck?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | Hold a plan: how you would delegate, and what you would do with the leads the role may have. Concede specifically: "I haven't managed managers. Here is how I would learn it." Claim no manager experience. | F5's stated gap, asked at the VP's level. |
| H2 | "Sixty seconds: why you over a candidate who has run a hardware roadmap?" | JD | [grounded] "I've never owned a hardware-adjacent roadmap." | Hold on what the material carries: "9 years engineering, 3 as a team lead of 6." Concede specifically: "They have owned a hardware roadmap and I have not. Here is what I would bring, and how I would close that gap first." | Pressure: the hold is quoted, and the concession names the gap. |
| I1 | "So, walk me through the journey." | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." | Build a 90-second arc from those facts and the reliability quarter, in your own words. Add nothing. | A casual opener that is scored. The arc uses only quoted material. |
| I2 | "What does your hiring loop look like, and what would you change?" | JD | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Describe the loop you run, in your words. Name one change you would make and why. Do not say you designed it. | Hiring is a headline requirement, and the casual register does not lower the score. |

### Reverse questions

1. "What would you need to see in the first 90 days to know this hire is working?" Why it lands: it surfaces the VP's bar.
2. "How much does engineering shape hardware roadmap decisions today?" Why it lands: it tests how the partnership actually runs.
3. "What does the leadership layer under engineering managers look like today?" Why it lands: it opens the managers question on your terms.
4. "What has the VP changed in how engineering leadership works over the last year?" Why it lands: it shows you follow the leadership's direction, not only the team's.
5. "When a values trade-off costs a quarter, what does a good leader here do?" Why it lands: it tests the values directly and invites a real answer.

## Requirement coverage

| JD requirement | Question IDs |
|---|---|
| Own delivery | A2, C1, C2, D1, F1, G2 |
| Own hiring | A3, I2 |
| Growth for 11 engineers | G4 |
| Partner with hardware and product on roadmap | A1, B1, E1, F1 |
| Hardware-adjacent roadmap (stated gap) | B1, H2 |
| Managing managers | None in the role summary. H1 covers it if the role has squad leads. |

## Sources

- Provided documents: your message, containing the role summary and your background.
- Web search: "Larkfield Systems industrial IoT company values", refused (permission not granted). "Larkfield Systems engineering manager interview process", refused (permission not granted). Neither returned a result.

**Research tier:** L1, searches 0 of 6 (two attempted and refused), fetches 0 of 2.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Larkfield values | unavailable | Values cheat sheet (not built); the two searches above were refused |
| 2. Larkfield interview process | unavailable | Loop structure; persona weights are round-type priors only |
| 3. Larkfield strategy / recent news | unavailable | No strategy brief in hand; no CO questions written |
| 4. Interviewer name and company | n/a | No names were given |
| 5. Representative engineering-manager JD | unavailable | Your role summary stands in for the JD, so requirement rows are [grounded] to it, not to full job-description text |

## Upgrade menu

- Full job description text → requirement rows quote the posting's exact wording, and the managing-managers question is answered from the posting.
- Recruiter's prep email → any named panel focus areas, and any pre-declared deliverable such as a presentation or take-home.
- Panel member names and roles → personas assigned per member and tailored reverse questions.
- Larkfield's published values page, pasted here → a values cheat sheet for Round 3, with each value mapped to a quoted story where one exists.
- Permission to retry web search → company values, interview structure and current strategy in place of the unavailable rows above.
- Whether the two squads have leads under you → if yes, the managing-managers gap becomes a stated requirement with its own bank questions.
- Your CV → more quoted evidence rows, which would firm up F1, F3 and F4.
- Prep time available → a prioritized schedule sized to it.
- A `tuesday-dossier.md`, if you have one → sharper evidence rows and firmer prohibited claims.
