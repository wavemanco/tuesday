The dossier already has a handoff section built for interview prep, so I'll run the mock-interview skill on it.
I have what the pack needs: a hiring-manager round, a dossier with the JD and evidence, and no gate the material leaves open. I'll read the dossier-handoff and output-template references and run one standard search on Quartzline's public context, in parallel.
Web search isn't permitted in this session, so research stays at L0 (provided documents only). I'll read the full reference text for the skeleton and rules.
The reference text is longer than I need, but I have the rules that matter: dossier evidence quoted verbatim, prohibited claims binding every cell, and answer slots only where the gap is not an acknowledged absence. Web search was refused, so the pack is built from the dossier alone. I'll write the pack file now.
Your prep pack is saved at `/var/tmp/tuesday-measure/1a6/runs/haiku/alone/part-2/rooms/case-4-denied-66228515/quartzline_product_manager_platform_apis_interview_pack.md`. It's built only from your dossier: web search was refused in this session, so there's no company or interviewer research. Today is Thursday 26 November, so if the interview is today, start with A1.

Start with **A1**, the objection your underwriter named: "You have never held the PM title or owned a roadmap — why should we hire you into one…?" Concede the gap in one sentence, then give the integrations and the roadmap-input sessions at their exact scope, name the limit, and say what you'd do first. Rehearse it through two follow-ups. The pack's other priorities are A2 (who decides when you and a squad lead disagree) and B3 (what product did with the roadmap-input evidence), which is the medium-confidence seam your dossier flagged.

Two things in the pack you should know about:
- Several rows are my grading, not the underwriter's. The paste had no `evidence_map`, so the fit rows for R2–R4, adoption metrics, partner discovery and specs/squads are marked `[inferred]`.
- Every answer slot is an instruction to answer from your own experience, with an honest branch if that experience isn't there. Nothing in the pack asserts the PM title, roadmap ownership or squad prioritization.

I can drill any question as the Skeptic, and I can save a `tuesday-dossier.md` with `pack_feedback` recording what the rehearsal exposes, if you want it. A Word version is available too.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quartzline_product_manager_platform_apis_interview_pack.md -----
# Interview prep: Product Manager, Platform APIs at Quartzline

Interviewer: hiring manager (name not given). Round: 45-minute hiring-manager conversation. Built on: the pasted tuesday-dossier.md (decision: conditional_go, dossier_version 1.1). Assumption: the hiring manager is the person you would report to. No prep time was stated, so there is no triage section.

## How to use this pack

- **Personas** describe how a question is asked. **Types** describe what is being scored: **EXP** (what you actually did), **JD** (can you do the listed job, gaps included), **CASE** (a live problem from the role).
- Guidance is scaffolding, not a script. Each cell should be speakable in 90 to 120 seconds, in your own words.
- Quoted sentences are the only things the guidance says about your past. Where the material is silent, the cell is an answer slot: an instruction to answer from your own experience, with an honest branch if the experience is not there.

## Fit snapshot

Requirements are quoted from the dossier's role_profile. Evidence is quoted from the dossier's verified_candidate_evidence and nowhere else. The dossier did not grade R2, R3, R4, adoption metrics, partner discovery, or specs and squads, so those rows carry this pack's own grading and are marked [inferred].

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" (dossier role_profile R1, must_have) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier verified_candidate_evidence) | low | [grounded] | transferability | The quote is integration work, not product management, and the bridge stays at that scope. Words: "I led 30+ end-to-end client integrations of the vendor's REST APIs, from scoping through go-live." Say the limit first: you have not held the PM title. |
| F2 | "Shipped API or platform products" (dossier role_profile R2, must_have) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier verified_candidate_evidence) | medium | [inferred] | transferability | The quote reaches API delivery on someone else's platform, not a product you shipped. Use the quote at its own scope. Answer slot: if you shipped an API or platform product on your side, say which and what you did; if not, say the integrations went live on an API someone else built. |
| F3 | "Technical fluency: API docs, schemas" (dossier role_profile R3, important) | "Wrote the internal integration playbook her team uses" (dossier verified_candidate_evidence) | medium | [inferred] | presentation | The quote already reaches API documentation in other terms, so reword only it: "I wrote the internal integration playbook my team uses." Answer slot on schemas: if you worked with schemas or specs directly, say which; if not, say so. |
| F4 | "Stakeholder management across engineering, sales, customers" (dossier role_profile R4, important) | "Ran quarterly roadmap-input sessions feeding client evidence to product" (dossier verified_candidate_evidence) | medium | [inferred] | transferability | The quote reaches customers and product, not engineering or sales. Words: "I ran quarterly roadmap-input sessions feeding client evidence to product." Answer slot: if you worked with engineering or sales on an integration, say which and what you did; if not, say so. |
| F5 | "Agile delivery experience" (dossier role_profile R5, preferred) | none given | low | [grounded] | discovery | No verified entry speaks to agile delivery. The probe is the requirement's own wording: "How have you worked in agile delivery?" Answer slot: if you worked in sprints or a delivery cadence, say how; if you did not, say so, and say what you would want to confirm about how this team defines it. |
| F6 | "Own the roadmap for the partner-facing API platform" (dossier role_profile responsibilities) | none given. The dossier records the absence: "Owning a roadmap and prioritization authority" (dossier uncertain_or_weak_areas, capability, confidence none) | none | [grounded] | capability | Words: "I haven't owned a product roadmap." Then a ramp plan, said as a plan: "I'd want to learn how roadmap and priority decisions get made here before I claim any." No answer slot: the underwriter found no evidence here, and a slot would reopen the bridge it closed. |
| F7 | "Define and track adoption metrics" (dossier role_profile responsibilities) | none given | none | [inferred] | discovery | No quote reaches adoption metrics. Answer slot: if you tracked any usage or adoption figure for the integrations, say what was counted and by whom; if you did not, say so and say what you would measure first. |
| F8 | "Run discovery with integration partners" (dossier role_profile responsibilities) | "Ran quarterly roadmap-input sessions feeding client evidence to product" (dossier verified_candidate_evidence) | medium | [inferred] | presentation | The quote already reaches client discovery in other terms, so reword only it. Answer slot: how you gathered the client evidence, in your own words; if you did not gather it directly, say so. |
| F9 | "Write specs and drive delivery with two engineering squads" (dossier role_profile responsibilities) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier verified_candidate_evidence) | medium | [inferred] | transferability | The quote reaches requirements and scoping on client integrations, not engineering squads. Use the quote at its own scope. Answer slot: if an engineering squad built from specs you wrote, say which and how; if not, say your requirements went into client integrations. |

Confidence and gap types here are the underwriter's vocabulary (low, medium, high, none; discovery, transferability, presentation, capability). Where the dossier's verified-evidence note says "medium" (roadmap-input sessions), the limit is said in the answer, not discovered by the interviewer.

## Prohibited claims

These claims will not be coached, in any answer, reverse question or drill, and they override every other label.

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | dossier prohibited_claims | "I haven't held the PM title." Then F1's quote at its own scope. |
| Having owned a product roadmap | dossier prohibited_claims; F6 | "I haven't owned a product roadmap." Then "Ran quarterly roadmap-input sessions feeding client evidence to product," as input, not decision. |
| Having set prioritization for an engineering squad | dossier prohibited_claims; F4 and F9 | "I haven't set priorities for an engineering squad." F4's quote at its own scope. |
| An adoption figure, baseline or metric definition | no quote supports one; F7 | The F7 answer slot only. Never a figure you did not track. |

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (hiring manager, weight 5) | Premise questions on the PM title, roadmap and decision authority (A1, A2, A5) | High. The dossier names the PM-title objection as the likely one, and R1 is the must-have gap. | Concede the gap first, name the limit before it is asked, hold, then concede the trade. |
| Prober (EXP, weight 4) | Denominator and mechanism questions on the 30+ integrations, the playbook and the roadmap sessions (B1 to B3, C1, C5) | High for the 30+ figure and the roadmap sessions. The dossier expects a probe on the sessions. | Quote the scope exactly; say the denominator honestly; volunteer the medium-confidence limit. |
| Pressure (weight folded into Skeptic) | Sustained challenge on authority and on a wrong call (A4, A6) | Medium. Used when a first answer sounds strong. | Return to the quote, do not add to it. |
| JD scorer and CASE (weight 3) | Requirement-by-requirement and live-problem questions (B4 to B6, C2 to C6) | Medium to high. A hiring manager reads the JD line by line. | Answer the requirement's own wording; use the plan form for the ramp. |

## Question banks

### Skeptic bank (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product"; [grounded] "I haven't owned a product roadmap." | Concede first: you have not held the PM title or owned a roadmap. Then the bridge at its limit: "I led 30+ end-to-end client integrations, and I ran quarterly roadmap-input sessions feeding client evidence to product." Name the limit: that was input to the roadmap, not the call on it. Concede the trade: a PM with three years would own the roadmap sooner than you would. Then the plan: learn how roadmap and priority decisions get made here, and ask each squad lead what they decide. Hold through two follow-ups by returning to the integrations and the limit, not by adding to them. | Named by the underwriter as the likely objection, and the highest-ROI rehearsal: R1 is the must-have gap and this is where it is pressed. The premise stays because the dossier records it as fact. |
| A2 | "Who decides on the roadmap when you and a squad lead disagree?" | JD | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Decision authority is the open question, so do not answer it from the role's title. Answer slot: if you settled a disagreement between a product owner and an engineering lead, say how; if no such call was yours, say so and say what you fed in: "Ran quarterly roadmap-input sessions feeding client evidence to product." | Tests the top opportunity risk: the JD asserts authority the dossier found no evidence for. The honest branch is the only safe answer. |
| A3 | "The squad leads already set priorities. How would you bring a partner's request into their planning?" | CASE | [generic] | Structure: what you would ask each squad lead first, how partner evidence reaches their planning, what you do when a partner request conflicts with committed work, and what you would record. Make no claim about your past. | A live problem from the JD's two-squad line, asked as a decision rather than a record. |
| A4 | "What is the hardest decision you have made with less authority than you wanted?" | EXP | [generic] | Answer slot: pick a real case where you lacked the final call; say what you recommended, what you did and what happened. If there is no such case, say so and use the nearest one you have. | Pressure on authority. Hold-then-concede: name the recommendation before the outcome. |
| A5 | "Why move from integration work into a product role now?" | JD | [generic] | Give your own reason in your own words. The material contains none, so the pack writes none. Keep it to what you want to do, with no claim about past PM work. | Motivation is tested directly; a rehearsed reason beats an improvised one. |
| A6 | "Tell me about a time you were wrong about what a partner needed." | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Answer slot: if you misread a client need through those sessions, say what you assumed, what the evidence showed and what changed. If you have no such case, say so and use the nearest one. | Pressure on discovery, which is the partner-facing half of the role. |

### Prober bank (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Of the 30+ integrations, how many did you lead end to end, and how many did you support?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Defend the count in the quote's words: "Led 30+ end-to-end client integrations." Answer slot: if the number is firm, give it and say what end-to-end covered; if you are not sure of the split, say you would check it against the project list rather than estimate in the room. | The headline figure is the prober's first move. The denominator is the question, and the honest answer is the one you can repeat under a second follow-up. |
| B2 | "Walk me through the integration playbook. Who uses it, and what changed because of it?" | EXP | [grounded] "Wrote the internal integration playbook her team uses" | Say what you wrote and who uses it, in those words. Answer slot: name a change after the playbook was in use, if you can; if you cannot measure it, say it is not measured. | The playbook is your strongest inspectable proof, so the prober will ask for its outcome. |
| B3 | "What did product do with the roadmap-input evidence?" | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Volunteer the limit before it is pulled: the proof here is limited. Words: "I ran quarterly roadmap-input sessions feeding client evidence to product." Answer slot: if you saw a roadmap decision change because of that evidence, name it; if you did not see what product did with it, say so. | This is the medium-confidence seam the dossier flagged. Name it before it is extracted. |
| B4 | "What adoption number did those integrations produce, and how do you know?" | JD | [grounded] "Define and track adoption metrics" (dossier role_profile responsibility) | Answer slot: if you tracked a usage or adoption figure, say what was counted and how; if you did not, say so and say what you would measure first. Never describe a metric you did not track. | The JD names adoption tracking and the material shows none. The honest branch is the answer. |
| B5 | "A partner wants a breaking change to an endpoint. A squad says it is a month of work. What do you do?" | CASE | [generic] | Structure: what the partner needs and by when, what the squad's month covers, options that cut scope or stage the change, who decides, and how you tell the partner. Make no claim about your past. | The JD's delivery line, in a live form. |
| B6 | "What would your first 30 days look like in this role?" | JD | [generic] | Plan, not past: learn the roadmap and how decisions get made; meet each squad lead; review adoption data with the team; list the partner discovery you would start first. Frame every step as a plan. | The ramp plan for R1, and the place to show how you would close the authority gap. |

### JD scorer bank (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Describe a spec you wrote that an engineering team built from." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Answer slot: if an engineering squad built from a spec you wrote, say which and how it went; if not, say your requirements went into client integrations, and describe one of those. | F9: spec-to-delivery is a JD responsibility, and the honest branch is the safe default. |
| C2 | "What have you done with API schemas or specs directly?" | JD | [grounded] "Wrote the internal integration playbook her team uses" | Answer slot: if you worked with schemas or specs directly, say which and what you did; if you worked from the playbook and the vendor's APIs without touching schemas, say that. | R3 is only partly reached; the schema half is the gap. |
| C3 | "How has your work fit a sprint or delivery cadence?" | JD | [grounded] "Agile delivery experience" (dossier role_profile R5); no candidate sentence | Answer slot: if you worked in sprints or a delivery cadence, say how and with which team; if not, say so and ask what cadence this product org runs. | R5 is a clarify area. The question also asks the employer how they work, which you need to know. |
| C4 | "Tell me about pushback from engineering on a client deadline." | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Answer slot: if engineering pushed back on a client deadline, say what happened and how you handled it; if engineering was not part of the work you ran, say so. | R4 covers customers and product; engineering is not shown. |
| C5 | "What did you do after go-live, if anything?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Answer slot: if you followed a live integration after go-live, say what you checked and what you found; if your work ended at go-live, say so and describe what you would check now. | Links R2 and adoption: the answer shows whether you watched anything after launch. |
| C6 | "How do you find out what integration partners actually need?" | JD | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Answer slot: describe how the quarterly sessions gathered client evidence, in your own words; if you gathered it another way, or did not gather it directly, say that. | The responsibility is partner discovery; the quote reaches it in other terms, so reword only it. |

### Coverage

| Requirement | Questions covering it |
|---|---|
| R1, 3+ years PM | A1, A4, A5, B6 |
| R1 sub-claim, roadmap and authority | A1, A2, A3 |
| R2, shipped API or platform products | B1, C5 |
| R3, API docs and schemas | B2, C2 |
| R4, stakeholders across engineering, sales, customers | B3, C4, A6 |
| R5, agile delivery | C3 |
| Run discovery with partners | C6, A6 |
| Write specs and drive delivery with two squads | C1, A3, B5 |
| Define and track adoption metrics | B4 |

Eighteen questions in total. The named objection, A1, has the deepest rehearsal: three follow-up levels, the exact concession, and the limit named before it is asked for.

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| RQ1 | "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" | Decision authority is asserted in the JD and evidenced nowhere. The answer tells you whether the title describes the job you would be hired into. |
| RQ2 | "How is partner API adoption measured today, and what is the current baseline?" | The JD names adoption tracking with no baseline. If there is none, building one is the first job, and you need to know that before accepting. |
| RQ3 | "How do the two squads plan and deliver, and where does a PM fit in that cadence?" | R5 is a clarify area. The answer shows the delivery model you would be judged on. |
| RQ4 | "What would a strong first 90 days look like for someone coming from integration leadership?" | The objection is about ramp. This shows what they expect a ramp to produce. |
| RQ5 | "What did the last person in this role get right, and where did they run into trouble?" | Gets the real shape of the job. The answer is both diligence and information. |
| RQ6 | "What would make you say no to a partner request, and who makes that call?" | Tests the decision-authority risk from the partner side. |

## Prohibited claims check

The pack has been checked against the prohibited list above. No answer, reverse question or cell asserts the PM title, roadmap ownership or squad prioritization, and every bridge keeps its limit.

## Sources

- **Provided document:** tuesday-dossier.md, pasted into the message (dossier_version 1.1, generated 2026-08-14). Consumed: `role_profile` (as the JD tier), `handoff_to_mock_interview` (verified evidence, allowed strategies, the named objection, risks, employer questions, prohibited claims) and `decision` (context only). `evidence_map`, `evidence_state` and `risk_register` are absent from the paste, so the grades in rows F2 to F4 and F7 to F9 are this pack's own and marked [inferred].
- **Research tier:** L1 requested; web search was not permitted in this session. Searches 0 of 6 completed (1 attempted, refused). Fetches 0 of 2.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quartzline values | unavailable | No values-style round was detected, so the values section is dropped either way. |
| 2. Quartzline interview process, product role | unavailable | One search attempted, refused: "Quartzline Product Manager Platform APIs partner API platform". Loop structure would have set persona weights; the stated hiring-manager round sets them instead. |
| 3. Quartzline strategy and recent news | unavailable | Would have fed a company and strategy bank. None was built, so no CO question appears. |
| 4. Interviewer name and company | n/a | No name was given, so there is no query to form. |
| 5. Representative JD | skipped | The dossier's role_profile supplies the requirements. |

## Upgrade menu

- The interviewer's name → a tailored reverse question, and persona weights from their public footprint.
- The full posting text → JD questions anchored to its exact lines, in place of the dossier's requirement wording.
- A refreshed dossier, if the posting has changed since 14 August → regraded fit rows.
- The project list behind the 30+ integrations, or the playbook's version history → a confirmed count for B1 and C1, and a stronger F1 row.
- The dossier's `evidence_map`, if it exists → the underwriter's grades in place of this pack's [inferred] rows.
- Search permission in this session → the L2 deep tier (6 more searches, 2 fetches): strategy brief, loop reports, recent org context.
