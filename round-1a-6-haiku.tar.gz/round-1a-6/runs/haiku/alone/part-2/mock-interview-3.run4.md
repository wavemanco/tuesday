Your prep pack is saved as /tmp/claude-0/-var-tmp-tuesday-measure-1a6-runs-haiku-alone-part-2-rooms-case-3-denied-4097ff06/dcd4a089-24bc-4dc9-9a95-073508ff7a9a/scratchpad/stripe_product-operations-manager_interview_pack.md. I built it from your message alone, so the persona weights are flat and the fit snapshot is a worksheet. It has 18 questions, and the highest-ROI one is C1, "Why this role, and why now for you?" Web search was refused in this session, so the values, interview-loop and strategy material is missing. The pack doesn't guess at Stripe's values.

Say the word and I'll play the Skeptic on C1 and give you feedback against its guidance.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Who are you meeting, and what kind of round is it: hiring manager, peer, a cross-functional interviewer, or a recruiter? The answer reweights every bank.

Could you paste the job description and a CV, or a few lines on your background? Without them, the fit snapshot stays a worksheet and the answers stay as selection scaffolds rather than stories from your own work.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: stripe_product-operations-manager_interview_pack.md -----
# Stripe, Product Operations Manager: final-round prep pack

Built with no job description, CV, interviewer name or round format yet, so persona weights are flat and the fit snapshot is a worksheet. Research was not available in this session (see Sources).

## How to use

- **Personas** describe how a question is asked. **Types** describe what is being scored.
- Type key: **VAL** behavioural or values fit · **EXP** your own past work, probed · **JD** the role's stated duties · **CO** company knowledge · **CASE** a live problem.
- Guidance is scaffolding, not a script. Say it in your own words, and say what you actually did.

## Fit snapshot (worksheet)

Nothing about your background is in this conversation yet, so every evidence cell reads `none given`. No job description was supplied, so the requirements below are role-family prose, not quotes.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Coordinating work across product, engineering, design and go-to-market teams (role family) | none given | none | [generic] | discovery | No material yet. Selection scaffold: pick a time you moved work forward with people who did not report to you. Name the shared goal and what you did. If no such time comes to mind, say so plainly, then give the nearest thing you have. |
| F2 | Defining and tracking measures for a launch or an operating process (role family) | none given | none | [generic] | discovery | No material yet. Selection scaffold: pick a process or launch you measured. Say which measure you watched and what you did when it moved. If you did not measure one, say so and say what you would measure first. |
| F3 | Designing or improving an intake, review or decision process (role family) | none given | none | [generic] | discovery | No material yet. Selection scaffold: pick a process you changed or set up. Say what the old version did wrong and what you changed. If you did not change one, say so and describe how you would start. |
| F4 | Managing risk, policy or compliance review on launches (role family) | none given | none | [generic] | discovery | No material yet. Selection scaffold: pick a time a launch or change needed a risk or policy check. Say who made the call and what you were responsible for. If none comes to mind, say so plainly. |
| F5 | Prioritising competing requests and making the tradeoff explicit (role family) | none given | none | [generic] | discovery | No material yet. Selection scaffold: pick a time you had more requests than capacity. Say what you ranked first, why, and who you told. If none comes to mind, say so plainly. |

## Prohibited list

No entries. Nothing in the material is stated for the pack to stretch, so there is no inflated form to list. Once your CV is shared, claims to avoid are built from its sentences and this list updates. The rule that holds throughout: no answer here asserts an ownership, metric or outcome you have not given.

## Persona table

Relationship is unknown and the round is not established as a loop, so weights are flat and the archetype fallback is the generic one: flat weights, said plainly. Depth is 4 for the top persona, 3 for mid-weight, 2 for low.

| Persona | How it shows up | Weight and depth | Reasoning | Counter-strategy |
|---|---|---|---|---|
| Case / Strategist | A live operations problem: a launch slipping, a queue overflowing | Top, 4 questions (A) | Product ops is judged on how you structure messy operational problems | Clarify, then structure, then name metrics and risks; think aloud |
| Data-Driven Prober | Asks how a number was counted and which assumption you would defend least | Mid, 3 questions (B) | Common for ops roles that report on metrics | Say how you counted, and say plainly when you don't know |
| Skeptic | Probes the motivation and the gap: why this role, what is missing | Mid, 3 questions (C) | Hiring managers test whether the move is deliberate | Rehearse the motivation answer until it is plain; name the thinnest area and a ramp plan |
| Values / Behavioural | Asks for past behaviour against values | Low, 2 questions (D) | No values round is established, so this is a generic fallback | Selection scaffold; say so if no such time comes to mind |
| Pressure / Stress | Time-boxed challenge to a position | Low, 2 questions (E) | Tests composure, not content | Pause, restate, hold through two follow-ups, concede a specific point only |
| Conversational | A casual opener that is still scored | Low, 2 questions (F) | Casual questions are scored too | Have a 90-second arc ready and treat openers as scored |
| Peer Evaluator | Seam-splitting between teams and disagreement | Low, 2 questions (G) | Peers price what the hire does to their load | Propose seam principles; give a disagreement story with spine and tact |

## Question banks

### A: Case / Strategist (top weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A launch you own is 20% behind plan two weeks out, and engineering says the blocker sits outside your team. What do you do first?" | CASE | [generic] | Clarify what "behind" measures and which launch gate is at risk. Name the decision owner. Separate what you control from what you escalate. Propose a dated plan with a check-in. Speakable in 90 seconds. | CASE: a live problem from the role's launch work. It asks about no past and presupposes nothing about you. |
| A2 | "Requests are coming in faster than the team can review them. Design the review process and walk me through it." | CASE | [generic] | Clarify volume, risk tiers and who decides. Segment by risk. Set a service level per tier. Name the metric you would watch, and the one that would tell you the process is wrong. | CASE: the intake and decision work named in F3. |
| A3 | "How would you know this operations work is succeeding six months from now?" | JD | [generic] | Name two or three leading measures and one lagging measure. Say what result would make you change a measure. | JD: F2 is the role-family requirement this scores. |
| A4 | "What would you want to learn about a team before you proposed changes to how it works?" | CASE | [generic] | Ask about the current queue, who holds decision rights, how work enters, and past failures. Do not propose a fix before these are answered. | CASE: tests whether you clarify before structuring. |

### B: Data-Driven Prober (mid weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a metric you tracked. How was it counted?" | EXP | [generic] | Open prompt. Pick one you tracked. State how it was counted and what it is sensitive to. Name the assumption you would defend least. Answer slot: if you did the counting, say how, in your own words; if the number was someone else's, say so plainly. | EXP: the defend-the-number slot every figure you give will raise. |
| B2 | "Which assumption behind that number would you defend least?" | EXP | [generic] | Name the weakest assumption before the interviewer does. Keep it to what you know. If you do not know the assumption, say so. | EXP: the weakest-assumption move. |
| B3 | "Tell me about a time a number you relied on was wrong. What changed?" | EXP | [generic] | Open prompt. Pick a real case, say what was wrong and how you found out, and what you changed. If no such time comes to mind, say so plainly, then give the nearest thing you have. | EXP: tests whether you own errors in measurement. |

### C: Skeptic (mid weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Operations can look like support work. Why this role, and why now for you?" | JD | [generic] | **Highest-ROI prep in this pack.** This is the motivation question a skeptic will ask in some form. Build a 60-second answer around one piece of operating work you find interesting and can describe concretely. Then say what in this role draws you to it. Do not claim experience you have not given. | JD: a skeptic's first probe, and the one most worth rehearsing aloud. |
| C2 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | Name one area honestly, then give a 90-day plan to close it. Do not bluff a competency the interviewer owns. | JD: scores honest self-assessment. |
| C3 | "Where is your background thinnest for this role?" | EXP | [generic] | Open prompt. Name the thinnest area. Say how you would close it. If nothing is thin, say so only if it is true. | EXP: tests whether the story holds under cross-examination. |

### D: Values / Behavioural (low weight)

No values round is established for this company, so these are generic behavioural questions. The company's published values are not in hand, so none are named here.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell me about a time you had to deliver an unpopular truth to someone senior." | VAL | [generic] | Open prompt. Pick a time the hard truth landed. Use "we" for context and "I" for what you did. If no such time comes to mind, say so plainly, then give the nearest thing you have. | VAL: generic fallback; the open-prompt scaffold ends in its honest branch. |
| D2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Open prompt. Pick a real trade-off. Say what you gave up and why. Same honest branch as D1. | VAL: generic fallback. |

### E: Pressure / Stress (low weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why should we hire you over someone who has done this exact job?" | JD | [generic] | Pause. Restate the question. Answer with what you would bring and the honest gap. Hold the position through two follow-ups. Concede one specific point; do not fold on the core claim. | JD: tests composure under time pressure. |
| E2 | "That result: how much of it was actually you?" | EXP | [generic] | Name what was yours, in your own words. Concede what was not, specifically. Do not add credit you did not have. | EXP: a truthful-attribution probe. |

### F: Conversational (low weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through your journey." | EXP | [generic] | Have a 90-second arc: where you started, the through-line, one piece of work you can describe concretely, and why this role. Keep it to what happened. | EXP: casual, but scored. |
| F2 | "What have you been reading or thinking about on operations lately?" | CO | [generic] | Give one current, specific interest. Do not invent research or reading. | CO: a rapport opener that tests whether you are current. |

### G: Peer Evaluator (low weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Our teams sit side by side. Where's the seam, and what happens when we disagree?" | JD | [generic] | Propose principles for the seam rather than pretending to know it. Give a disagreement story with spine and tact, if you have one. If not, say how you would handle one. | JD: a peer's seam probe. |
| G2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Say how you name others' contributions and your own. Give one real example, or say how you would handle it. | VAL: a generic peer probe. |

Coverage: 18 questions in total. No JD was supplied, so coverage is checked against role-family requirements F1 to F5 rather than a list of stated requirements.

## Reverse questions

Each one is for the end of the interview. Ask the ones that fit the round you are in.

1. **"What does a strong first six months look like in this role?"** Why it lands: it turns the interview into a planning conversation.
2. **"Which operating process here creates the most friction for the teams it serves?"** Why it lands: it shows you think in terms of outcomes, not tasks.
3. **"How are launch and exception decisions made today, and who has the final say?"** Why it lands: it shows you know decision rights matter in this work.
4. **"What has the team tried to change in operations in the last year, and what happened?"** Why it lands: it invites an honest account and signals you learn from history.
5. **"What would make you say a year from now that this hire was a success?"** Why it lands: it gives you the success criteria directly.
6. **"What is the biggest open question the team is working through right now?"** Why it lands: it shows interest in the work itself.

No interviewer profile exists, so none of these is tied to a career path. No peer relationship is known, so no reciprocity question is included.

## Sources

Provided documents: your message (company, role title, and that this is a final round).

Research tier: L1 attempted. Searches 0 of 6 (both refused: web search permission was not granted), fetches 0 of 2.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Stripe values | unavailable | Values cheat sheet, section 10. Refused: "Stripe company values operating principles" |
| 2. Stripe interview process, product operations | unavailable | Loop structure, and persona weights that follow the named rounds. Refused: "Stripe interview process product operations manager final round" |
| 3. Stripe strategy and recent news | unavailable | CO questions would have been grounded in current strategy. No call sent: web search permission was not granted |
| 4. Interviewer name and Stripe | n/a | No interviewer name was given, so there was no query to form |
| 5. Representative Product Operations Manager JD | unavailable | JD-tagged questions and the fit snapshot would have rested on a current posting. No call sent: web search permission was not granted |

## Upgrade menu

- **Your CV or background** → the worksheet rows become quoted evidence, story-mapped answers replace the selection scaffolds, and the prohibited list gets built from your sentences.
- **The job description** → F1 to F5 become quoted requirements, and the JD-tagged questions get their raising sources.
- **Round type and who you are meeting** → persona weights and reverse questions get reweighted; the current flat weights are a guess.
- **Web search permission** → a research pass at L1 (up to 6 searches and 2 fetches, a few minutes): Stripe's values by name, its interview loop, and current strategy. That would ground the values and CO questions, which are generic now.
- **Interviewer name** → a tailored reverse question and persona weights from their public footprint.
- **Recruiter's note on focus areas, or any take-home or presentation** → a build section for each graded deliverable.
- **A deeper research pass** (up to 6 more searches and 2 more fetches, several more minutes): the strategy brief and interviewer talks. Want it? Offered once.
- **A tuesday-dossier.md from a prior review** → verified evidence in place of the worksheet, and a list of claims to avoid.
