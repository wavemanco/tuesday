Your prep pack is saved as /var/tmp/tuesday-measure/1a6/runs/haiku/alone/part-2/rooms/case-1-denied-8662f06c/Northwind_Data_Senior_GTM_Strategy_Lead_Emerging_Products_interview_pack.md. I built it for a single 60-minute peer conversation with Dan, on the JD highlights and background you gave. Web search was refused in this session, so it rests on your inputs alone.

The pack has 20 questions across six personas. Peer Evaluator and Data-Driven Prober carry the most weight. The banks, fit snapshot, prohibited-claims list, reverse questions and requirement-coverage table are all in the file.

Say the word and I'll play the Skeptic on C1, the question the pack names as its highest-ROI prep.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Northwind_Data_Senior_GTM_Strategy_Lead_Emerging_Products_interview_pack.md -----
# Interview prep pack: Senior GTM Strategy Lead, Emerging Products

**Company:** Northwind Data (B2B data-infrastructure SaaS, about 3,000 employees)
**Candidate:** Priya
**Interviewer:** Dan Kovac, Director of Sales Strategy. Relationship: **peer**, same VP.
**Round:** one 60-minute conversation.
**Built on:** the JD highlights, your background notes, the interviewer profile and the research note you gave. No CV was supplied, so no CV wording appears in this pack.

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored.
- **Type key:** EXP = your past work and what you actually did. JD = a stated requirement of the role. CO = company and strategy knowledge. CASE = a live problem. VAL is not used: no values-style round was detected.
- **Guidance is scaffolding, not a script.** Say it in your own words.
- **Answer slot:** an instruction for the interview, not a question to answer here. It gives two honest branches: a practice you did, described plainly, or a plain statement that it was not yours or did not happen. Neither branch is ever scored against the practice it names.

## Fit snapshot

Confidence is one of high, medium, low, none. Provenance is one of [grounded], [inferred], [generic]. Quotes come only from your inputs. "Coach's notes" means the background you wrote for this pack.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" (JD highlights) | "9 at a large consumer-tech company in product strategy & ops" — coach's notes | medium | [grounded] | transferability | Your notes show product strategy and operations, not go-to-market ownership of a new line. Product strategy is the adjacent work, and its limit is stated. Answer slot: if you set a go-to-market decision for a launch, name it and how you decided; if none was yours, say so plainly and say how you would build the plan for the first new line. |
| F2 | "identify whitespace across land/adopt/expand/renew" (JD highlights) | none given | none | [grounded] | discovery | No quote touches this requirement. The material is silent, which is not the same as a negative. Answer slot: name a whitespace you found and where in land, adopt, expand or renew it sat; if you have not found one, say so and say how you would look. |
| F3 | "run independent analysis in SQL and Tableau" (JD highlights) | "skilled in SQL/Tableau" — coach's notes | low | [inferred] | discovery | A skill is claimed, but no analysis is named, so this stays a lead and not a story. Answer slot: name one analysis you ran in SQL and Tableau, the question it answered and what you left out; if you have not run one end to end, say so. |
| F4 | "partner-motion design experience required" (JD highlights) | "built a partner-level revenue model used in carrier negotiations" — coach's notes | medium | [grounded] | transferability | Carrier negotiations are the partner side of a deal. Your notes show a model used in them, not a partner motion designed. Answer slot: if you set terms, incentives or a joint structure in those negotiations, say which and how you decided; if the model informed terms others set, say so and walk through the model. |
| F5 | "strong cross-functional influence" (JD highlights) | "set annual volume targets with cross-org consensus" — coach's notes | medium | [grounded] | none | The quote reaches the requirement in role-relevant terms: targets set across the organization by consensus. Expect a probe on how much of the consensus was yours. |
| F6 | "AI experience a plus" (JD highlights) | "uses AI tools daily" — coach's notes | low | [inferred] | transferability | Daily use is adjacent to building or launching an AI product, and it does not reach that. Say the use in your own words and do not call it AI product experience. Answer slot: if you have made a product decision about an AI feature, name it; if not, say which tools you use and for what. |
| F7 | None in the JD highlights; a headline figure in your notes | "proposed a store-surface change credited with ~$400M ARR uplift" — coach's notes | medium | [grounded] | none | No gap in the evidence. The figure carries its attribution as written: "credited with", which is not the same as measured or owned. Expect probes on counting and on your share. The slots are in bank B. |
| F8 | None in the JD highlights; your career arc | "2 years strategy consulting at a top firm" — coach's notes, "9 at a large consumer-tech company in product strategy & ops" — coach's notes | medium | [grounded] | none | No gap. The arc is in your notes as written, and the biography question uses only these words. |
| F9 | None in the JD highlights; your notes state an absence | "No classic sales-ops or quota-setting experience." — coach's notes | medium | [grounded] | capability | Your notes record the absence, so the pack may give back the plain acknowledgment: "I haven't done classic sales-ops or quota-setting." Confirm this wording in your own voice before you rehearse it. Then say how you would learn it, as a plan and not as past work. |

**How to read the table:** Confidence grades your evidence. Provenance grades what this pack wrote about it. F3 and F6 are low, so the pack treats them as leads and never as your story. F9's gap is one you stated, so its words come from that statement.

## Prohibited claims

The pack will not coach these, and no answer, slot, reverse question or rehearsal line may assert, soften or imply them. Each entry names its basis and its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned go-to-market for a product line | Inflated form of F1 | F1's quote at its own scope. The pack's observation, in analysis only: your notes say product strategy and operations, not go-to-market ownership. Question C1's slot stays inside the quote. |
| Designed a partner motion | Inflated form of F4 | F4's quote at its own scope. Question C2's slot asks only what terms you set. |
| Ran independent analysis end to end in SQL and Tableau | Inflated form of F3 | "skilled in SQL/Tableau" at its own scope. Question B5's slot asks only what you ran. |
| Built or shipped AI products | Inflated form of F6 | "uses AI tools daily" at its own scope. |
| Set quotas or sales targets for a sales team | Inflated form of F5, and a negative your notes state (F9) | F5's quote at its own scope: "set annual volume targets with cross-org consensus". The plain acknowledgment only after you confirm it: "I haven't done classic sales-ops or quota-setting." |
| Drove or measured the ~$400M uplift | Inflated form of F7 | F7's quote at its own scope: "credited with ~$400M ARR uplift". Question B1 asks how it was counted, if you know. |

## Persona table

Relationship priors for a peer round set the starting weights: Peer Evaluator and Data-Driven Prober first. The interviewer's profile adjusts them, as shown below. Depth follows weight: top 5 questions, mid 3, low 2.

| Persona | How it shows up | Likelihood, with the reasoning | Weight, depth | Counter-strategy |
|---|---|---|---|---|
| Peer Evaluator | Seam questions, "what would you need from me", credit and disagreement | High. The peer relationship puts this first, and it is the prior for a same-VP round. | Top, 5 | Reciprocity first; seam principles; one disagreement story |
| Data-Driven Prober | Denominators, how figures were counted, assumptions | High. Dan's profile says "relentlessly data-driven", and a numbers-first pricing career tilts the same way. | Top, 5 | Know how each figure was counted and say what you don't know; name the weakest assumption before they do |
| Skeptic | The GTM-ownership gap and the partner-design gap | Mid. The gaps are visible from the JD against your notes. A peer probes them collegially rather than as a hiring test. | Mid, 3 | Rehearse C1 until it is plain; hold, then concede |
| Case/Strategist | Whitespace, copilot sizing, the bundling threat | Mid. Dan's pricing and monetization spine means cases will lean toward pricing, packaging and unit economics. | Mid, 3 | Clarify, then structure; one consensus move and one divergence |
| Pressure | Time-boxed motive and credit probes | Low. A peer round rarely presses, but a sharp one may test the $400M line. | Low, 2 | Pause, restate, hold then concede |
| Conversational | The journey opener and a casual AI question | Low. Casual questions are still scored. | Low, 2 | A pre-scripted 90-second arc; treat the AI question as scored |

Values and behavioral questions are not weighted, because no values-style round was detected.

## Reading the interviewer

**Source:** the profile you gave. Its public footprint was not verified, because search was refused in this session.

- **Career pattern:** a pricing and monetization spine, with one early-stage startup chapter.
- **Self-described style:** "relentlessly data-driven".

**Implications for this conversation:**

1. Dan's Prober weight is up. Every figure you give will be taken back to its assumptions. Bank B is the rehearsal.
2. Cases will lean toward pricing, packaging and unit economics. Those are Dan's native terms. Bank D uses them.
3. The startup chapter means builder stories land well. Expect a probe on big-company pace, and do not claim scrappiness your notes do not show.
4. As a peer, Dan will test whether you reduce or add to their load. Reciprocity answers this.

**Mirror opportunities:** there is no shared career jump, so no reverse question is built on one. The one shared vocabulary is the revenue model: "revenue model" is Dan's native term, and F4 carries the sentence. Use the word only as your own sentence describes the work.

## Question banks

Each question's provenance leads with its label, followed by the quoted sentences its guidance rests on, exactly as they appear in the fit snapshot. A question with no claim about you carries its label alone. Each question's type is one of JD, EXP, CO or CASE.

### A. Peer Evaluator (top weight, 5 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Where does your work meet mine, and what happens when we read the same number differently?" | JD | [grounded] "set annual volume targets with cross-org consensus" | Propose seam principles rather than a map you do not know: who decides the number, who signs off the forecast, and how a disagreement is escalated. Then one disagreement story, if you have one. Answer slot: if none comes to mind, say so plainly, then describe the nearest thing your notes carry: the targets were set with consensus across the organization, and say your part in that. | The peer's seam probe. Cross-functional influence is a stated requirement (F5), and the quote grounds the nearest story. |
| A2 | "What would you need from my team in the first ninety days?" | JD | [generic] | Reciprocity first: name what your work would give their team, such as a shared forecast or a seam both teams sign, before anything you need. Do not name a need you have not seen. | The peer tests partnership fit, and a rehearsed reciprocal answer shows the hire would lighten their load. The guidance claims nothing about your history. |
| A3 | "How do you handle credit when work spans teams? Give me one example." | EXP | [grounded] "set annual volume targets with cross-org consensus" | An open prompt. The quote says the targets were set with consensus across the organization. Say your part in that setting and whose input was whose. Answer slot: if you did not lead it, say so and name the part that was yours. | Tests attribution in the words of F5. Credit-sharing is the peer's favorite probe. |
| A4 | "Our teams both touch the same partners. If we disagree on a partner's terms, what do you do?" | JD | [generic] | Propose a principle: the terms go to the one forum both teams agree on, with the numbers both accept. Do not claim a partner motion you have not run. Name what you would bring to that forum first. | Partner-motion design is a required qualification and this disagreement is the peer's seam. [generic] because the scenario comes from the JD, not from your history. |
| A5 | "What did you learn from the carrier negotiations that would change how you'd run a partner motion here?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | Say what the model did in those negotiations, at the quote's own scope. Answer slot: if you set any partner terms yourself, say which; if the model informed terms others set, say so. Then the transferable lesson, marked as a plan and not as past work. | F4 is the partner evidence, and a peer is most likely to test partner work here. JD because partner design is scored. |

### B. Data-Driven Prober (top weight, 5 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Walk me through how the ~$400M ARR uplift was counted." | EXP | [grounded] "proposed a store-surface change credited with ~$400M ARR uplift" | Defend the number, in your words: how it was counted, what it is most sensitive to, the assumption you would defend least, and which part was yours. Name the weakest assumption before they do. Answer slot: if you know how it was counted, say how; if you do not, say so plainly and say who credited it. | The headline figure (F7) is the Prober's first target. "Credited with" is the phrase they will test, so the guidance keeps that attribution. |
| B2 | "Of that number, what part was you, and what would have happened without the change?" | EXP | [grounded] "proposed a store-surface change credited with ~$400M ARR uplift" | Separate the two things your notes state: you proposed the change, and the figure is credited with it. Say the proposing in the quote's own terms. Answer slot: if you know what the uplift was measured against, say it; if you do not, say so plainly. | The counterfactual is what a prober asks for next, and it is where a credited figure most often gets stretched. |
| B3 | "What was the annual volume target, and how was it arrived at?" | EXP | [grounded] "set annual volume targets with cross-org consensus" | Say the target and the inputs behind it, in the quote's terms: set with consensus across the organization. Answer slot: if you built the method, say it; if the figure came from others' inputs, say whose and what you did with them. | The prober checks the figure's basis. The question's second half asks for a method the quote does not carry, so the honest branch is an answer slot. |
| B4 | "Which assumption in that revenue model would you defend least?" | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" | The weakest-assumption move: name, in your words, the assumption behind the model you would defend least, before they name it. Your notes give no assumption, so the name has to be yours. If you do not recall the inputs, say so. Answer slot: which parts of the model you built and which came from others. | Revenue modeling is Dan's native vocabulary. F4 carries the sentence. |
| B5 | "Tell me about one analysis you ran end to end in SQL and Tableau. What question did it answer, and what did you leave out?" | JD | [inferred] "skilled in SQL/Tableau" | An open prompt from the JD's independent-analysis line. Your notes show a skill, not an analysis, so the guidance does not assume one. If you have one, name the question, the data and what you left out. If you do not, say so plainly and describe how you would scope the first analysis for a new line. | F3 is low confidence, so this stays a lead. A prober asks for the denominator and the exclusions, so the answer needs them ready. |

### C. Skeptic (mid weight, 3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Your background is product strategy and operations. This role owns go-to-market for two new product lines. What have you owned go-to-market for?" | JD | [grounded] "9 at a large consumer-tech company in product strategy & ops" | **Highest-ROI prep in this pack.** Hold: "Product strategy and operations is what my background shows. Here is the part of it closest to go-to-market." Answer slot: if you set a go-to-market decision for a launch, name it, who it reached and how you decided; if none was yours, say so plainly. Hold through two follow-ups by returning to the product strategy and operations you did. On the third, concede specifically: name the part of a go-to-market plan you have not run, and the first thing you would learn. Never add a launch, channel or price you did not set. | This is the most predictable objection, and F1 is the gap a Skeptic reaches first. It gets the deepest rehearsal: two holds, then a named concession. The question asks what you have owned, not that you owned go-to-market. |
| C2 | "Partner-motion design is required here. Have you designed one?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | Answer the first word honestly. Your notes do not show a partner motion you designed. If you did design one, name it. If you did not, say no, then give the carrier model at the quote's scope, and say that program design is what you would build. | A yes or no question leaves the Skeptic no room to probe a partial claim, and it is the honest version of F4's transferability gap. |
| C3 | "How would you set a quota for a new product line?" | CASE | [grounded] "set annual volume targets with cross-org consensus" "No classic sales-ops or quota-setting experience." | Answer from first principles: the number, the inputs, the owners and the check on it. Say the difference between a volume target and a quota, because your notes show the first and not the second. Answer slot: if you have set a target before, name it. Do not claim quota history. Say the plain acknowledgment only once you have confirmed it in your own voice. | JD-adjacent, since the requirement is not in the highlights but the Skeptic will likely probe quota-setting on a sales-strategy team. It tests the gap that F9 records. |

### D. Case/Strategist (mid weight, 3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Here is a new product line with no customers yet. Where do you look first for whitespace across land, adopt, expand and renew?" | CASE | [generic] | Clarify, then structure: which customers, which lifecycle stage, and which evidence you would trust first. Name one hypothesis and what would disprove it. No claim about your past is needed. | A live problem from the JD's whitespace line. [generic] because it is a pattern for the problem. |
| D2 | "Take an AI copilot launch in a data-infrastructure product. How would you size the go-to-market?" | CO | [grounded] "AI copilot launch ('Compass')" | Clarify which customers the copilot is for. Size from the existing base before new logos. Name the assumption you would test first. Bring one consensus move and one divergence, with a reason for the divergence. | Compass is Northwind's stated priority in the research note, so the question uses its name as vocabulary. |
| D3 | "A much larger platform vendor bundles a competing product into its suite. What do you do in the next two quarters?" | CO | [grounded] "bundling by a much larger platform vendor" | Bring one consensus move, such as protecting the renewal base. Then one divergence with a thesis, and the anti-pick: do not match the bundle on price. Say what you would say no to, and why. | The research note names bundling as the main threat, and the anti-pick is the judgment Dan will look for. Pricing and packaging angles suit a pricing-trained interviewer. |

### E. Pressure (low weight, 2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why this role over staying in product strategy?" | EXP | [grounded] "9 at a large consumer-tech company in product strategy & ops" | Pause, restate the question, then answer in your own words. Your notes give no reason, so the reason is yours to name. Answer slot: one sentence with your reason, then one fact from your notes that makes it credible. Hold the reason through two follow-ups, and do not disparage your current company. | A time-boxed motive probe. The material does not answer it for you. |
| E2 | "That $400M. How much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with ~$400M ARR uplift" | Hold-then-concede. Hold what the quote says: you proposed the change. Concede specifically where the figure is credited, not owned: name the attribution and the counting you cannot defend. Do not fold to "all of it" or retreat to "none of it." | The Pressure version of B1 and B2. The structure is hold, then concede. |

### F. Conversational (low weight, 2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm" "9 at a large consumer-tech company in product strategy & ops" | Pre-scripted 90-second arc: the consulting first, then the consumer-tech years, in your own words and at the quotes' scope. Stop before the "why" and let them ask. Do not add a job, title or scope. | Casual openers are scored. F8 is the only place the arc appears in your notes as written. |
| F2 | "What are you actually playing with in AI these days?" | JD | [inferred] "uses AI tools daily" | Treat it as scored. Name the tools you use and what for, in your own words. Do not stretch daily use into building AI products. Answer slot: if you have made a decision about an AI feature, name it; if not, say which tools you use and where they save you time. | A JD plus-skill asked casually. F6 is low confidence, so the guidance stays at use. |

### Requirement coverage

| JD requirement | Questions covering it |
|---|---|
| own GTM strategy for two new product lines | C1, D2 |
| identify whitespace across land/adopt/expand/renew | D1 |
| run independent analysis in SQL and Tableau | B5 |
| partner-motion design experience required | C2, A4, A5 |
| strong cross-functional influence | A1, A2, A3 |
| AI experience a plus | F2 |

Headline figures: the ~$400M uplift is covered by B1, B2 and E2. The volume target is covered by B3. The revenue model is covered by B4. Every JD line has at least one question, so none is "— none, and why."

## Reverse questions

Each question has a reason for asking it. R1 ties to Dan's own path. R2 is the reciprocity question for a peer.

| # | Question | Why it lands |
|---|---|---|
| R1 | "You came up through pricing and monetization, then a startup. Which of those taught you to distrust a number first?" | It ties to Dan's own career and invites Dan to describe a method. That turns the interview into a peer conversation and shows you researched Dan. |
| R2 | "What could a new person do in their first month that would genuinely help your team?" | Peer reciprocity. It signals that you are thinking about the load on Dan's team. |
| R3 | "Where does sales strategy hand off to pricing for a new line today, and who decides the number?" | It shows you see the seam, and the answer tells you the decision rights. |
| R4 | "How do the enterprise expansion goal and the Compass launch show up in your team's plan this year?" | It uses Northwind's stated priorities from the research note, and the answer shows how the priorities are actually run. |
| R5 | "When the bundling threat comes up in your planning, what has your team actually tried?" | It shows you have looked at the main threat. The answer shows which moves have been tested. |
| R6 | "What does a good number look like on your team? What do you ask for first when a figure lands on your desk?" | It speaks directly to the Prober. Asking this signals that you will bring the assumption up front. |

## Sources

**Provided documents:** your message. It supplied the JD highlights, the candidate background (the coach's notes), the interviewer profile, and the research note (the three priorities and the bundling threat). No CV, dossier or recruiter guidance was supplied.

**Searches and fetches:**

- "Dan Kovac Director of Sales Strategy Northwind Data": **refused** (search permission not granted in this session). No other search or fetch was sent.

**Target accounting**

Research tier: L1 — searches 0 of 6 (1 sent, refused), fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Northwind Data values | skipped | Values cheat sheet, not triggered: the round is a peer conversation, so no values-style round was detected |
| 2. Northwind interview process, peer round | unavailable | Would have moved the loop structure. No search was sent, because search permission was not granted. Your stated single peer conversation fixes the weights instead |
| 3. Northwind strategy and recent news | skipped | The research note you gave already supplies the three priorities and the bundling threat |
| 4. Dan Kovac, Northwind | unavailable | Would have moved the interviewer's public footprint and a tailored reverse question. The one query sent was refused |
| 5. Representative JD for the title | skipped | The JD highlights you supplied fix the fit snapshot |

## Upgrade menu

- **Full JD text** → the six JD lines become full requirements, and any further `[inferred]` or `[generic]` rows can be grounded.
- **Search permission for this session, or Dan's public profile pasted in** → the interviewer read gets a verified public footprint and a tailored reverse question.
- **Your CV** → F1 to F9 move from coach's notes to CV wording, and each CV line still needs checking against its quote.
- **Your own wording for the quota negative (F9) and the $400M attribution (F7)** → B1, B2, C3 and E2 rehearse your words, not the coach's notes.
- **Recruiter guidance (focus areas, or any deliverable declared in advance)** → a check that the coverage matches what the round will score.
- **Prep time available** → a prioritized schedule, with each item tied to a question ID.
- **Deep research (L2), offered once:** a strategy brief, Dan's talks and writing, and role-family loop reports. It is up to six further searches and two further fetches, and it needs search permission.
- **A `tuesday-dossier.md`** → verified evidence and prohibited-claims guardrails in place of the coach's notes.

---

Your prep pack is saved as /var/tmp/tuesday-measure/1a6/runs/haiku/alone/part-2/rooms/case-1-denied-8662f06c/Northwind_Data_Senior_GTM_Strategy_Lead_Emerging_Products_interview_pack.md. I built it for a single 60-minute peer conversation with Dan, on the JD highlights and background you gave. Web search was refused in this session, so it rests on your inputs alone.

Say the word and I'll play the Skeptic on C1, the question the pack names as its highest-ROI prep.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.
