I'm stopping research here: the three web searches were refused by the permission system, so I've built the pack from your inputs only and will say so in the pack.
Your prep pack for Priya is saved at `/tmp/claude-0/-var-tmp-tuesday-measure-1a6-runs-haiku-alone-part-2-rooms-case-1-denied-ddd1ad0b/0b717c04-d7b7-4953-b223-634e01b820e4/scratchpad/northwind_senior-gtm-strategy-lead-emerging-products_interview_pack.md`. I built it for a peer round, since Dan reports to the same VP.

**What's in it**
- **Fit-gap map:** six JD highlights and the no-quota gap, each with Priya's own words quoted from your notes and bridge language.
- **Question bank:** 21 questions across seven personas, weighted 5/4/3/3/2/2/2 for the Prober, Peer, Case, Skeptic, Pressure, Values and Conversational personas. Every row has type, provenance, answer guidance and rationale.
- **Requirement coverage:** each JD requirement mapped to question IDs.
- **Reverse questions:** six for Dan, including one tied to his pricing and startup path and one reciprocity question.
- **Prohibited claims:** inflated wordings of her record that the pack won't coach, such as "set quotas" and "drove the $400M."

**The no-quota gap**
D1 is the highest-ROI prep. It's a hold-then-concede drill: state the gap first, hold the adjacent fact (she set annual volume targets with cross-org consensus), then concede the gap plainly. The pack never calls volume targets quotas.

**Things you should know**
- **Research didn't run.** The three web searches were refused by the permission system, so the pack has no values, no loop structure and no Dan footprint beyond your profile. The values cheat sheet is dropped and the Values questions are generic.
- **Built from your summary, not her CV.** Every provenance tag reads "coach's notes." Her own sentences would raise confidence on most rows.
- **Full JD not supplied.** Requirements are quoted from your highlights. Any gate the posting names (location, work authorization) isn't in the pack yet.

Offers:
- I can play the Skeptic on D1 as a live drill.
- I can save a `tuesday-dossier.md` recording the gaps this prep exposed.
- I can convert the pack to Word if you want it.

Can you paste the full JD text? It would turn the highlight-based requirement rows into verbatim quotes.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: northwind_senior-gtm-strategy-lead-emerging-products_interview_pack.md -----
# Interview prep pack: Priya, Senior GTM Strategy Lead, Emerging Products

**Company:** Northwind Data (B2B data-infrastructure SaaS, about 3,000 employees)
**Role:** Senior GTM Strategy Lead, Emerging Products
**Interviewer:** Dan Kovac, Director of Sales Strategy. Peer, same VP.
**Format:** One 60-minute conversation
**Built on:** Your highlights of the JD (not the full posting), the coach's summary of Priya's background, the coach's profile of Dan, and the coach's research note. No CV, no full JD, no dossier.
**Research tier:** L1 attempted. Searches 0 of 6 (3 refused), fetches 0 of 2. See Sources.

---

## 1. How to use this pack and the type key

- **Personas** describe how a question arrives. **Types** describe what is being scored.
- Personas: **A** Data-Driven Prober, **B** Peer Evaluator, **C** Case/Strategist, **D** Skeptic, **E** Pressure, **V** Values/Behavioral, **G** Conversational.
- Types: **VAL** behavioral/values, **EXP** work-experience deep-dive, **JD** role-driven, **CO** company and strategy, **CASE** live problem.
- Guidance is scaffolding for a spoken answer, not a script. Keep answers in your own words.
- **Answer slots** are instructions for the interview. They are not questions to answer in this conversation. Where a slot says "if X, say so," the honest branch is always available.
- **Provenance** on each question row names the sentence the guidance rests on. "Coach's notes" means the summary you gave, not Priya's own wording. Her own wording would raise confidence (see the upgrade menu).

---

## 2. Fit-gap map

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" (JD highlights) | "9 at a large consumer-tech company in product strategy & ops" (coach's notes); "proposed a store-surface change credited with a ~$400M ARR uplift" (coach's notes) | medium | [grounded] | transferability | Your notes say product strategy and ops, and a store-surface change. They do not say go-to-market for a new line. Answer slot: if you owned any go-to-market decision for a launch, say which and how you decided; if you did not, say so and bridge through the product-strategy work you did. |
| F2 | "identify whitespace across land/adopt/expand/renew" (JD highlights) | "built a partner-level revenue model used in carrier negotiations" (coach's notes) | medium | [grounded] | transferability | A revenue model used in negotiations is adjacent to sizing whitespace. It does not show whitespace work across land, adopt, expand and renew. Answer slot: if you sized where revenue was missing at a specific stage, say which stage and how; if not, name the model as the closest work. |
| F3 | "run independent analysis in SQL and Tableau" (JD highlights) | "skilled in SQL/Tableau" (coach's notes) | low | [inferred] | discovery | "Skilled" is a self-description with nothing inspected behind it. Answer slot: name the last analysis you ran yourself in SQL or Tableau, the question it answered, and whether it changed a decision. If it was support on someone else's analysis, say so. |
| F4 | "partner-motion design experience required" (JD highlights) | "built a partner-level revenue model used in carrier negotiations" (coach's notes) | medium | [grounded] | transferability | Partner-facing work, but not partner-motion design as the posting names it. Answer slot: if you designed terms, roles, or the sequence of a partner motion beyond the model, say which and how you decided. If the model was the extent of it, say that plainly. |
| F5 | "strong cross-functional influence" (JD highlights) | "set annual volume targets with cross-org consensus" (coach's notes) | medium | [grounded] | presentation | The quote already reaches influence in other terms: agreement across organizations. Caveat: limited inspectable proof, so expect a probe on who agreed and what each side gave up. Name those orgs in your own words. |
| F6 | "AI experience a plus" (JD highlights) | "uses AI tools daily" (coach's notes) | medium | [grounded] | transferability | Daily use is adjacent to AI experience and does not reach building it. Say the use, not a build. |
| F7 | Not in the JD highlights. A sales-strategy peer is likely to ask about it. (role-family expectation, [generic]) | "No classic sales-ops or quota-setting experience" (coach's notes) | medium | [grounded] | capability | Words, from the stated absence: "I don't have classic sales-ops or quota-setting experience." Then how you would learn it, as a plan and never as a past. Pack observation, not words for Priya: the material shows target-setting with cross-org consensus, which is not quota-setting. Do not present it as quota-setting. |

Notes on the map:
- **No gate row.** The highlights name no location, work-authorization or other term, so the pack invents none. If the full JD names one, add it (see the upgrade menu).
- **Priority gap.** F7 and F4 are the two that a peer from Sales Strategy is most likely to test. D1 and E1 rehearse them.

---

## 3. Prohibited claims

These claims are not coached anywhere in the pack. Every answer slot, hold, bridge and rationale is written against this list.

| Not coached | Basis | Honest form |
|---|---|---|
| Set sales quotas | Inflated form of F5 | The quote at its own scope: "set annual volume targets with cross-org consensus." Pack observation: the material shows targets with consensus, not quotas. |
| Owned go-to-market for a product line | Inflated form of F1 | The quote at its own scope. Pack observation: the material says product strategy and ops. |
| Designed or owned the partner motion | Inflated form of F4 | The quote at its own scope: "a partner-level revenue model used in carrier negotiations." |
| Drove the ~$400M | Inflated form of the F1 figure | "credited with a ~$400M ARR uplift," followed by the four defend-the-number slots in A1 and A2. |
| Built AI products | Inflated form of F6 | "uses AI tools daily," said as use. |
| Ran independent SQL and Tableau analysis for leadership | Inflated form of F3 | The slot in A4. No claim until she names the analysis. |
| Has quota-setting experience | Sourced entry: negative stated in the coach's notes (F7) | Plain acknowledgment: "I don't have classic sales-ops or quota-setting experience." |

---

## 4. Reading the interviewer

**Dan Kovac**, Director of Sales Strategy. Peer, same VP.

- **Career pattern (coach-supplied):** pricing and monetization roles, plus one early-stage-startup chapter.
- **Self-description (coach-supplied):** "relentlessly data-driven."
- **Public footprint:** not searched. The search was refused. This read uses only the coach's profile.

**Practical implications**
1. Expect every figure traced to its inputs. Dan is at the top of the persona weights (A).
2. Case questions tilt toward pricing and packaging, which is Dan's home ground (C3).
3. The startup chapter means builder stories land, and a scrappiness probe is likely.
4. As a peer, Dan will test credit-sharing and the seam between the two teams (B).

**Mirror opportunities**
- **Shared professional path:** none found. Dan's startup chapter has no counterpart in the fit rows, so it is not offered as a shared jump.
- **Shared vocabulary:** monetization. Priya's revenue model is adjacent to it. Use it as shared vocabulary only, paired with F4's quote: "built a partner-level revenue model used in carrier negotiations."

---

## 5. Persona weights

Peer round, single session, no loop schedule. Relationship priors (Peer Evaluator and Data-Driven Prober) set the starting weights. The coach's profile of Dan ("relentlessly data-driven," pricing spine) raises the Prober and tilts the case toward pricing. No loop, so no loop adjustments. No values round detected, so V is a fallback weight.

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| A Data-Driven Prober | Every figure and SQL claim traced to inputs | 5 questions. Top weight. Peer prior, raised by Dan's self-description. | Know how each figure was counted, or say plainly you don't. Name the weakest assumption before it is asked. |
| B Peer Evaluator | Seams, disagreement, credit | 4 questions. Peer prior; Dan's team sits beside Priya's. | Propose seam principles, not a pretended map. Show reciprocity. |
| C Case/Strategist | Live problem on whitespace and bundling | 3 questions. Pricing background tilts the case. | Clarify, then structure. Challenge one premise. |
| D Skeptic | The no-quota gap and the product-to-GTM bridge | 3 questions. The stated gap is the likely objection. | Hold the adjacent fact at its own scope, then concede the gap plainly. |
| E Pressure | The ~$400M credit, and "why you" | 2 questions. A peer round rarely pressure-tests, but the headline figure invites it. | Pause, restate, anchor in the quote. Hold through two follow-ups. |
| V Values/Behavioral | Cross-functional stories | 2 questions. Fallback. No published values in hand. | Selection scaffold, with the honest branch. |
| G Conversational | Opener and an AI question | 2 questions. The opener is a scored bio. | Use the 90-second arc. Treat the AI question as scored. |

Session total: 21 questions, within the 18 to 26 range.

---

## 6. Question banks

**Highest-ROI prep: D1.** Dan's function owns quota-setting. The gap is visible on the CV summary. Rehearse D1 until it is boring.

### A. Data-Driven Prober (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how the ~$400M ARR uplift was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (coach's notes) | Defend-the-number slots, in your words: how it was counted; what it is most sensitive to; the assumption you would defend least; which part was yours. If a team did the count, say so and name your part. If you do not know how it was counted, say that plainly and offer to find out. Name no method. | F1 holds this figure. It is the most-probed number on the summary, so the four slots are the rehearsal. EXP because it tests what was actually hers. |
| A2 | "Which assumption behind that figure would you defend least?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (coach's notes) | Weakest-assumption move: name, in your words, the assumption you would defend least before Dan asks. If you cannot name one, say so and say what you would check first. | Metric questions include the weakest-assumption move. It converts a gotcha into a credibility gain. |
| A3 | "Walk me through the inputs of the partner revenue model, and where it is most sensitive." | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" (coach's notes) | Answer slot: name the inputs you set. If an input came from another team, say whose. Say where the model is most sensitive, in your own words. | F4's evidence. Dual-reaching the JD's partner-motion line (the question is EXP primary, with JD content). Premised only on the quote. |
| A4 | "Pick one analysis you ran yourself in SQL and Tableau. What was the question, and what changed because of it?" | JD | [inferred] "skilled in SQL/Tableau" (coach's notes), low confidence, so this is a question, not an assertion | Answer slot: name the question, the data you worked from, and the output. If the work was support on someone else's analysis, say so and say what your part was. Do not claim tools beyond those in the quote. | The JD asks for independent analysis. F3's confidence is low, so the question is the only honest way to raise it. |
| A5 | "What do you not trust an AI tool to count for you?" | JD | [grounded] "uses AI tools daily" (coach's notes) | Name the tasks you use AI for, and say whether you checked the outputs and how. If you did not check them, say that. Say use, not build. | F6, and the JD's AI plus. A prober tests whether AI use is shallow. |

### B. Peer Evaluator (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Where is the seam between your GTM work and Sales Strategy, and what happens when we disagree?" | JD | [grounded] "set annual volume targets with cross-org consensus" (coach's notes) | Propose two seam principles, such as who owns the number and how data is shared, rather than pretending to a full map. Answer slot: name a time you disagreed with a peer team, what you did, and whether it was settled. If no such time comes to mind, say so plainly, then give how you would handle it. | F5 is the evidence for cross-functional influence. A peer probe on disagreement is the peer persona's core. |
| B2 | "When work crosses teams, how do you handle credit?" | VAL | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (coach's notes) | "We" for context, "I" for your contribution. Name who else is credited, in your words. Answer slot: if the credit was shared, say so, and say what you proposed. | Credit-sharing probe. The figure is F1's, so B2 is the same quote at a peer's angle. |
| B3 | "What would you need from my team to get your first 90 days done?" | JD | [generic] | Reciprocity: name what you need from Dan's team, then name what you would bring to it. This guidance makes no claim about your past. | Peer reciprocity. A reciprocity answer is what a peer's weighting rewards. |
| B4 | "Which of land, adopt, expand or renew would you expect the new lines to lean on hardest?" | JD | [grounded] "identify whitespace across land/adopt/expand/renew" (JD highlights) | Name one stage and why, in one sentence, with a stated assumption. No claim about your past. | A JD line raises the question. It is also a seam question, since Sales Strategy works the same stages. |

### C. Case/Strategist (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Sketch how you would find whitespace for a new product line across land, adopt, expand and renew. What do you need to know first?" | CASE | [generic] | Clarify, then objective, segmentation, approach, metrics, risks. Name what you need first: stage definitions and the account base. Think aloud. Challenge one premise. | A live problem from the JD. Dan's pricing lens means packaging and unit economics should appear in the approach. Presupposes nothing about the candidate. |
| C2 | "How would you sequence go-to-market across enterprise expansion and an AI copilot launch?" | CO | [grounded] "enterprise expansion" and "an AI copilot launch ('Compass')" (coach's research note) | Say the sequencing question you would ask first, then one option with its trade-off. Use Northwind's own terms. | Company priorities from the coach's research note. Sounds current, not archival. The research is shallow, so the answer should stay at the level of the stated priorities. |
| C3 | "Your main threat is bundling by a much larger platform vendor. How would you think about pricing against it?" | CO | [grounded] "main competitive threat is bundling by a much larger platform vendor" (coach's research note) | State the first question you would ask: who gets bundled, and at what price point. Then one pricing option with its trade-off. No claim about your past. | Dan's pricing background makes this his native ground. The question is aimed at the company's threat, not at Priya's history. |

### D. Skeptic (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You haven't set quotas before. How would you decide what a new line should be expected to sell?" | JD | [grounded] "No classic sales-ops or quota-setting experience" (coach's notes); [grounded] "set annual volume targets with cross-org consensus" (coach's notes) | **Hold-then-concede, three levels deep.** Limit first, in her words: "I don't have classic sales-ops or quota-setting experience." Follow-up 1: hold the adjacent fact at its own scope: "I did set annual volume targets with cross-org consensus." Follow-up 2: answer slot. Name how the targets were agreed and what went into them, if she did that. If she did not, say so. Follow-up 3: concede the specific gap: "I'd learn quota design with the sales-ops team." This is a plan, not a past. Never call the volume targets quotas. | **The highest-ROI objection.** The gap sits on the CV summary and Dan's function owns the answer. F7 is the gap; F5 is the adjacent fact. Deepest rehearsal, with the limit named before it is asked for. |
| D2 | "Why should a product-strategy background lead go-to-market for these lines?" | JD | [grounded] "9 at a large consumer-tech company in product strategy & ops" (coach's notes) | Name what carried over, at the quote's scope: product strategy and ops. State the limit: that is not go-to-market for a new line. Answer slot: if you owned a go-to-market decision for a launch, say which; if not, say so plainly. | F1's transferability gap. The Skeptic will test whether the bridge is real. |
| D3 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "partner-motion design experience required" (JD highlights); [grounded] "No classic sales-ops or quota-setting experience" (coach's notes) | Name the one area with the most honest gap, partner-motion design or quota-setting, in the quotes' own scope. Then say a ramp plan you would start, as a plan and never as a past. | Persona stem. It lets Priya name the gap before the interviewer does, which is what calibrated candor means. |

### E. Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why should the emerging lines be yours rather than someone who has run go-to-market at a B2B data company?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" and "proposed a store-surface change credited with a ~$400M ARR uplift" (coach's notes) | Pause. Restate the question. Anchor in the two quotes. Hold through two follow-ups. Concede specifically: name the go-to-market gap plainly. Do not fold on the partner model. | The pressure form of the "why you" probe. It rehearses the hold-then-concede structure on F4 and F1. |
| E2 | "That ~$400M figure. How much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (coach's notes) | Hold on the quote's words: "proposed" and "credited." Concede the specific share that was not hers, in her words. Answer slot: if she cannot say what share was hers, say so, and say what she did propose. | Pressure form of A1. The hold is only the quote's scope, never more. |

### V. Values/Behavioral (weight 2, fallback)

No published values are in hand, so these questions are generic and labelled as such.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time you told someone senior something they did not want to hear, with a stake and an outcome you can name. "I" for your part, "we" for context. If no such time comes to mind, say so plainly, then give the nearest thing you did and how it landed. | The persona stem. No values were detected, so the question carries no company claim. |
| V2 | "When did the numbers and the people disagree, and what did you do?" | VAL | [generic] | Selection scaffold: pick a time when the data and a team's view conflicted. Name what you did and whether the decision held. If no such time comes to mind, say so, then give the nearest case and how it resolved. | Generic behavioral probe. It sets up the cross-functional influence stories in B1. |

### G. Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm" and "9 at a large consumer-tech company in product strategy & ops" (coach's notes) | 90-second arc: consulting, then consumer tech, then why this role. Use only the two quoted clauses. Add no roles or dates. | The first ask is scored even though it is casual. The arc should be pre-scripted, not improvised. |
| G2 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" (coach's notes) | Name the tools you use daily, the tasks, and one thing they did not do well. Say use, not build. | F6, the JD's AI plus, asked casually. Treat the casual register as scored. |

### Requirement coverage

| JD requirement | Questions |
|---|---|
| Own GTM strategy for two new product lines | D2 (JD), C1 |
| Identify whitespace across land/adopt/expand/renew | B4 (JD), C1 |
| Run independent analysis in SQL and Tableau | A4 (JD) |
| Partner-motion design experience required | A3, E1 (JD) |
| Strong cross-functional influence | B1 (JD), B2 |
| AI experience a plus | A5, G2 (JD) |
| Not in the highlights: quota-setting (role expectation) | D1 (JD), D3 |

---

## 7. Reverse questions for Dan

At least five. One ties to Dan's own path. One is a reciprocity question, since Dan is a peer.

| # | Question | Why it lands |
|---|---|---|
| RQ1 | "Your career has run through pricing and monetization. When a new product line is priced, which decision is hardest to reverse later?" | Ties to Dan's path. It turns an interview into a peer conversation about pricing, and signals that Priya researched Dan. |
| RQ2 | "What did your early-stage chapter teach you about go-to-market that a larger company does not?" | Ties to the startup chapter. Invites a story and shows interest in Dan's path. |
| RQ3 | "What could a new person do in the first month that would genuinely help your team?" | Peer reciprocity. A prep signal, since rapport-style interviewers weight this slot heavily. |
| RQ4 | "Where do Sales Strategy and the emerging-products work currently disagree about whitespace, and how is it settled?" | Tests the seam directly, in Dan's own domain. It shows Priya knows the teams sit side by side. |
| RQ5 | "How is the bundling threat showing up in your pricing conversations today?" | Uses the coach's research note. Invites Dan's view on pricing against the threat. |
| RQ6 | "How are annual targets set across Sales Strategy and the product lines today, and who signs off?" | Shows Priya knows targets and quotas are different things. Lets her learn the process, which is the D1 gap. |

---

## 8. Sources

**Provided documents (coach's message):**
- JD highlights (six lines). Not the full posting.
- Candidate summary (the coach's notes). Not Priya's CV or her own words.
- Interviewer profile: name, title, "relentlessly data-driven," pricing career, one early-stage chapter.
- Research note: three priorities (enterprise expansion, the "Compass" AI copilot, reaching profitability) and one threat (bundling by a much larger platform vendor).

**Searches and fetches sent:** three, all refused by the permission system. No retries were made.
- "Northwind Data company values": refused
- "Northwind Data interview process sales strategy": refused
- "Dan Kovac Northwind Director of Sales Strategy": refused

**Research tier:** L1 attempted. Searches 0 of 6 (3 refused), fetches 0 of 2.

**Target accounting**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Northwind values | unavailable | Would have fed the values cheat sheet. Section dropped: no values round detected and no published values in hand. V1 and V2 stay generic. |
| 2. Northwind interview process, sales strategy | unavailable | Would have set the loop structure. Persona weights assume a single session. |
| 3. Northwind strategy and recent news | skipped | The coach's research note already gives three priorities and one threat, which fix the company-knowledge questions. Recent moves are not established. |
| 4. Dan Kovac, Northwind | unavailable | Would have filled the interviewer's public footprint. The read uses only the coach's profile. |
| 5. Representative sales-strategy JD | unavailable | Would have filled requirements missing from the highlights. Not sent after the first three were refused. |

---

## 9. Upgrade menu

- **Full JD text** → Requirement cells quote the posting verbatim, not the highlights. Any gate the posting names (location, work authorization) gets a row.
- **Priya's own CV or resume lines** → F1 to F6 move from the coach's summary to her own sentences. Confidence can rise to high where an artifact exists, such as the revenue model or the ~$400M analysis.
- **Priya's own account of how the ~$400M was counted** → A1, A2 and E2 get her own quoted answer in place of answer slots.
- **Dan's public footprint** (talks, posts, or a pasted profile link) → persona weights from his public record, and a tailored reverse question.
- **Web research, once search is permitted** → V1 and V2 become company-specific, the loop structure is checked, and Northwind's current strategy goes beyond the coach's note.
- **Prep time** → a prioritized triage section for the time available.
- **A `tuesday-dossier.md` from an underwriting run** → would ground the D1 and F7 rows in evidence rather than the coach's summary. None is present.
