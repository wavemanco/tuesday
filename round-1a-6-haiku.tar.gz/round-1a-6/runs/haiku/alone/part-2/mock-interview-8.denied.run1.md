Your prep pack is saved at `/tmp/claude-0/-var-tmp-tuesday-measure-1a6-runs-haiku-alone-part-2-rooms-case-8-denied-0dfdbbc2/04d38f2c-2f01-4966-8481-e808afacdab5/scratchpad/ashgrove_member_experience_lead_interview_pack.md`. I built it for the three rounds in the recruiter's email, using the JD, your background, the pasted values and the strategy summary as given. I didn't run any web searches, because those inputs already covered everything a search would have added.

The three things that matter most:

- **B3 is the highest-return rehearsal.** Expect "I don't see contact-centre experience in your background." You've never worked in a contact centre, so hold on the branch complaints log you handled, then concede that plainly, and give a plan.
- **Round 1 will ask about pay, notice, location and why you're leaving.** The pack gives no figures for any of them. For pay, if asked what you earn now, the line is "I'd rather focus on the range for this role."
- **Don't claim the things the JD asks for that your material doesn't show.** The pack lists five inflated claims to avoid, including "owned the complaints process end to end" and "presented to senior leaders."

Two more things to know:

- The values cheat sheet has no ready-made story for any of the four values. Each one is a scaffold with an honest "if none comes to mind" branch, so you'll need to pick real cases from your log.
- The strategy points are from the summary you gave me, not the full July brief. If you can paste the full brief, the strategy section can cite it directly.

I can run a live drill on B3 with the Skeptic persona. I can also save a `tuesday-dossier.md` that records the gaps this prep exposed, for carrying into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove_member_experience_lead_interview_pack.md -----
# Ashgrove Credit Union: Member Experience Lead, interview pack

**Role:** Member Experience Lead. **Company:** Ashgrove Credit Union (member-owned, about 900 staff).
**Interviewers:** recruiter (round 1, 30 min); Head of Member Services, your future manager (round 2, 45 min, mostly behavioural); two branch managers as a panel (round 3, 60 min, including a 20-minute complaint-escalation case). Names for rounds 2 and 3 are not yet assigned.
**Loop:** three rounds on 5 December 2026. Built in loop mode: one shared fit snapshot, then a mini-pack per round.

## How to use + type key

Personas describe how a question arrives. Types describe what it scores.

- **VAL**: behavioural / values alignment. Whether past behaviour shows the published values.
- **EXP**: work-experience deep-dive. Whether your record survives scrutiny, and what you actually did.
- **JD**: role-driven. Whether you can do the listed job, including its gaps.
- **CO**: company and strategy knowledge. Whether you think at the company's altitude.
- **CASE**: live problem. Structure and reasoning on a problem from the role.

**Guidance is scaffolding, not a script.** Every claim about your past is quoted from your own words. Where your material has no such sentence, the guidance is a selection scaffold or an answer slot, and you answer from your experience.

---

## Shared: fit snapshot

Requirements come from the JD you supplied. Evidence is quoted from your message. Where a requirement has no quote, it is marked "none given".

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" (JD) | "6 years in retail banking, the last 3 as a branch supervisor." (your message) | high | [grounded] | none | Say it in your words: "For six years in retail banking, the last three as a branch supervisor." Expect the probe to be contact-centre operations, which is F3. |
| F2 | "experience handling regulated complaints" (JD) | "I handled the branch's formal complaints log and trained new tellers on our escalation script." (your message) | medium | [grounded] | presentation | "I handled the branch's formal complaints log." The quote reaches complaints; the regulatory element is not in your material. Answer slot: the JD raises regulated handling. If you worked to a timescale or outcome rule, name it and how you applied it. If you did not, or it was not yours to apply, say so plainly. |
| F3 | "Own the member complaints process end to end across branches and the contact centre" (JD) | "I handled the branch's formal complaints log" (your message); "Never worked in a contact centre" (your message) | low | [grounded] | capability | Your material shows the branch log. The contact-centre half is a stated absence: "I've never worked in a contact centre." Do not bridge the end-to-end scope. |
| F4 | "coach branch supervisors on escalations" (JD) | "trained new tellers on our escalation script" (your message) | low | [inferred] | transferability | Tellers, not supervisors: "I trained new tellers on our escalation script." Answer slot: if you coached a supervisor on an escalation, say what you did; if you have not, say so plainly and describe your approach. |
| F5 | "report monthly on complaint volumes and resolution times" (JD) | "I built the monthly complaints spreadsheet our regional manager uses." (your message) | medium | [grounded] | presentation | "I built the monthly complaints spreadsheet our regional manager uses." The quote reaches monthly reporting; resolution times are not in it. Answer slot: if the spreadsheet tracked resolution times, say how they were counted; if it did not, say so. |
| F6 | "confident presenting to senior leaders" (JD) | "I've never presented to anyone above regional level." (your message) | none | [grounded] | capability | A stated absence: "I haven't presented to anyone above regional level." Then your plan for learning it, said as a plan and never as a past. |
| F7 | "comfortable with Excel reporting" (JD) | "I built the monthly complaints spreadsheet our regional manager uses." (your message) | medium | [grounded] | presentation | The quote is a spreadsheet, not Excel by name. Say what you built, in those words. Answer slot: if you used particular Excel features, name them; if the tool was not Excel, say so. |
| F8 | "work with digital teams on self-service journeys" (JD) | none given | none | [grounded] (JD) | discovery | The material is silent. Answer slot: if you worked with a digital or app team on a journey, say which and what you did; if you did not, say so and say how you would start. |

**Gap-type routing.** F1 is none because the quote reaches the requirement in role terms. F2, F5 and F7 are presentation because a quote reaches the requirement in other terms. F3 and F6 are capability because you stated the absence. F4 is transferability because tellers are adjacent to supervisors. F8 is discovery because the material is silent, not absent.

## Shared: prohibited claims

These are not coached, in any answer, hold, bridge or rationale.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end across branches and the contact centre | Inflated form of F3 | "I handled the branch's formal complaints log." The limit is this pack's observation: your material says the branch log, not end-to-end ownership. |
| Worked in or ran a contact centre | Negative you stated (F3) | "I've never worked in a contact centre." |
| Presented to senior leaders | Negative you stated (F6) | "I haven't presented to anyone above regional level." |
| Coached branch supervisors on escalations | Inflated form of F4 | "I trained new tellers on our escalation script." |
| Reported resolution times monthly | Inflated form of F5 | The spreadsheet quote at its own scope. The material does not say resolution times were in it. |

## Shared: values cheat sheet

Published values from ashgrovecu.org/about/values, as you copied them on 26 November 2026. Each value maps to a quoted sentence where one carries a story, or to a selection scaffold ending in an honest branch where none does. None of your sentences carries a complete story for a value, so each row is a scaffold.

| Value | Working meaning | Mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | F2 quote. Scaffold: pick a complaint where the member's side changed what you did. If none comes to mind, say so plainly, then give the nearest thing your log carries. |
| Plain Words | If a member needs it explained twice, it was written wrong | F4 quote. Scaffold: pick a time an explanation failed and what you changed. If the training you ran changed what tellers told members, say how. If not, say so and give the nearest example. |
| Neighbours, Not Numbers | Every branch is part of its town | No quote carries this. Scaffold: pick a decision with a local dimension and how you explained it to the place. Note the F5 spreadsheet is a numbers artefact, so prepare a non-numbers example. If none, say so plainly. |
| Own the Fix | Whoever finds the problem keeps hold of it until solved | F2 quote. Scaffold: pick a complaint you kept hold of until it closed, and say the close yourself. If the log shows such a case, use it. If none comes to mind, say so plainly. |

## Shared: grounding brief

Source: the July 2026 strategy brief, as summarised in your message. I have not read the full document, so these are the summary's words, not the brief's.

- 40% of member service to digital channels by 2028.
- Eight branches consolidated into five hubs over 2027.
- Small-business lending product launched in Q1 2027.
- Main competitive pressure: app-only banks.

Implication for this role [inferred]: hub consolidation changes where complaints get escalated, and digital migration changes which complaints stay with people. Use the vocabulary "digital channels" and "hubs". Do not add figures the brief does not give you.

---

## Round 1: recruiter screen (30 min)

### Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / rapport | Friendly opener, then logistics | High. A recruiter screen is logistics and motivation, and the risk is treating it as unscored. | Rehearse a 90-second arc. Treat logistics as scored. |
| Skeptic (light) | "Why now" and the contact-centre gap | Medium. The recruiter screens against the JD first. | Plain acknowledgment, then the nearest thing you carry. |

Depth: eight questions. The conversational persona carries the opener and logistics.

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Take me through your background in about two minutes." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." and "I handled the branch's formal complaints log" | Give the arc in your own words, using the quoted beats: six years, the last three as a branch supervisor. Then one clause on the complaints log. Stop there and leave the contact-centre gap to round 2. | F1 is the opening fact. EXP because the arc is your record. |
| A2 | "What notice do you need to give in your current role?" | JD | [generic] | Logistics slot. Give your actual notice period in your own words. Your material gives none, so this pack supplies no figure. If you prefer, ask for the role's notice expectation first. | Recruiter-screen logistics. The answer must be yours. |
| A3 | "What salary range are you expecting for this role?" | JD | [generic] | Logistics slot. Give your own number, or ask for the role's band first. If asked what you earn now: "I'd rather focus on the range for this role." Do not mention current pay. | Pay is a logistics slot. No figure is supplied. |
| A4 | "Where are you based, and what working pattern can you do?" | JD | [generic] | Logistics slot. Give your location and the pattern you can work, in your own words. Your material gives neither. | Location is a logistics slot. |
| A5 | "What's drawing you to leave your current role?" | EXP | [generic] | Logistics slot. Give your reason in your own words. Your material does not state one, so this pack does not fill it. | Reason for leaving is a logistics question. |
| A6 | "What does your monthly complaints spreadsheet show, and who uses it?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Story map on F5: you built it, and your regional manager uses it. Answer slot: the JD asks about resolution times. If the spreadsheet tracked them, say how they were counted. If it did not, say so and say what you would add first. | F5 is the reporting requirement. JD because it scores the monthly-reporting line. |
| A7 | "Are you comfortable presenting to senior leaders?" | JD | [grounded] "I've never presented to anyone above regional level." | Plain acknowledgment: "I haven't presented to anyone above regional level." Then your plan for learning it, as a plan. | F6 is a stated absence, so the plain line is yours to give. |
| A8 | "Does your experience include contact centres?" | JD | [grounded] "Never worked in a contact centre" and "I handled the branch's formal complaints log" | Plain acknowledgment: "I've never worked in a contact centre." Then the nearest thing you carry: "I handled the branch's formal complaints log." Do not extend that to contact-centre work. | F3's contact-centre half is a stated absence. The bridge covers only what the sentence covers. |

## Round 2: Head of Member Services (45 min, mostly behavioural)

### Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values / behavioural | Scenario probes, STAR-shaped | High. The recruiter said mostly behavioural. | STAR, with "we" for context and "I" for your contribution. |
| Skeptic | Cross-examines the contact-centre gap | High. Your future manager is buying the capability, and F3 is the biggest gap. | Hold through two follow-ups, then concede specifically. |
| Case / strategist | A live escalation or digital question | Lower than the hiring-manager default, because the recruiter said behavioural. | Structure before answering. |

Depth: eight questions. The Skeptic holds the deepest rehearsal here.

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time you had to explain a decision to a member who disagreed with it." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Selection scaffold: pick a complaint where you explained the outcome to the member. Say what they asked and what you said, in your own words. If none comes to mind, say so plainly, then give the nearest thing your log carries. | Open prompt. Theme from Plain Words. F2 and F4. |
| B2 | "Tell me about a complaint you handled under a regulatory timescale." | JD | [grounded] "I handled the branch's formal complaints log" | Answer slot: the JD raises regulated handling. If you worked to a timescale or outcome rule, name it and how you applied it. If you did not, or it was not yours to apply, say so plainly, then describe how you would check the timescales in a new role. | F2 is a presentation gap: the log is in the quote, the regulatory element is not. |
| B3 | "I don't see contact-centre experience in your background. How would you run complaints across a branch and a contact centre?" | JD | [grounded] "Never worked in a contact centre" and "I handled the branch's formal complaints log" | Hold through two follow-ups by returning to the branch log you handled. Then concede specifically: "I've never worked in a contact centre." Then a plan, as a plan. Do not describe end-to-end ownership. | **Highest-ROI prep.** F3 is the biggest gap, and this objection is almost certain. The negative is yours. The end-to-end scope is the JD's, not a fact about you. |
| B4 | "What did your monthly spreadsheet count, and how?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Answer slot: say what it counts, in your own words. If it counted resolution times, say how they were counted. If it did not, say so and what you would add first. | F5. The probe is what the figures meant. |
| B5 | "Our branch supervisors struggle with escalations. How would you coach them?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Start from what you did: you trained tellers on the escalation script. Then say how you would move from scripts to supervisors' decisions. Answer slot: if you have coached a supervisor on an escalation, say what you did. If you have not, say so plainly and describe your approach. | F4. Tellers are adjacent to supervisors; the JD names supervisors. |
| B6 | "Tell me about a time you presented a complaints pattern to a senior manager." | JD | [grounded] "I've never presented to anyone above regional level." | Plain acknowledgment: "I haven't presented to anyone above regional level." Then your plan for a senior audience, as a plan. If you have presented to your regional manager, say what you showed, in your own words. | F6 is a stated absence. Open prompt. |
| B7 | "What should stay with a person in complaints as more members go digital?" | CO | [generic] | Take a view: vulnerable members and disputed decisions stay with people, and routine status queries can move to self-service. Say what you would check first. Answer slot: if you have worked with a digital team on a journey, say which and what you did. If not, say so and how you would start. | Strategy: 40% of member service to digital by 2028. No claim about your past is made. |
| B8 | "Walk me through what should happen to a complaint in its first 48 hours." | CASE | [generic] | Structure: acknowledge, log, triage by severity and any deadline, assign an owner, contact the member. Say which steps you have run yourself, in your own words, and which you would set up. | Process judgment. No claim about your branch's process is supplied. |

## Round 3: panel of two branch managers (60 min, including a 20-minute case)

### Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values / behavioural | Scored against the four values | Guaranteed. The recruiter said the panel scores the values. | Map each value to a story, or use the honest branch. |
| Case | The 20-minute complaint escalation | Guaranteed. Named in the recruiter's email. | Clarify, then objective, owner, interim contact, record, review. |
| Peer evaluator | Seam between branch and contact centre | Medium to high. Branch managers are peers to this role. | Reciprocity. Propose seam principles, not a known seam. |

Depth: nine questions. Values and case carry most of the weight.

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you kept hold of a complaint until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log" | Selection scaffold: pick a complaint you kept until it closed, and say the close yourself. If your log shows such a case, use it. If none comes to mind, say so plainly and give the nearest thing the log carries. | Own the Fix. F2. |
| C2 | "When did you put a member's side ahead of a branch figure?" | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Members First, Always. The spreadsheet is the figure side you know. Select a moment a member's position and a count disagreed. If none comes to mind, say so plainly. Do not invent the member's side. | F5 is the figure side. The value asks for the member's side. |
| C3 | "When has a member needed to hear something twice, and what changed?" | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Plain Words. Select a time an explanation failed and what you changed. If the training you ran changed what tellers told members, say how. If not, say so and give the nearest example. | F4. The honest branch matters here. |
| C4 | "Tell me about a local decision that a town cared about beyond the member involved." | VAL | [generic] | Neighbours, Not Numbers. Select a decision with a local dimension and how you explained it to the place. If none, say so plainly. | No quote carries this value. A selection scaffold is the honest form. |
| C5 | "Walk us through the monthly report you would build on volumes and resolution times." | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Story map on F5: you built the monthly spreadsheet. Resolution times are not in your material. Say what you would put in the report and what you would check first. | F5 is a presentation gap. Covers the reporting line. |
| C6 | Case (20 min): "A member has complained three times about a fee, once to a branch and twice to the contact centre. They now ask for an external review. Walk us through how you would handle it." | CASE | [generic] | Clarify what was said, logged and promised, and any deadlines. Set the objective, the owner, the interim contact, when a supervisor takes it, the record, and the review at close. Say which steps you have run yourself. Do not claim contact-centre experience; the material shows none. | Generic scenario with no facts about you. Covers end-to-end ownership and escalation coaching. |
| C7 | "The member's complaint is now on the external body's list. What changes on day one?" | CASE | [generic] | Confirm the deadlines and the file, name who owns the reply, say what the member is told, and say what goes to the regional manager. Hold the owner decision yourself and say what goes up. | Follow-up to C6. Pressure on a live step. |
| C8 | "The contact-centre lead thinks your fix creates more work for her team. What do you do?" | VAL | [generic] | Name the shared outcome. Propose seam principles rather than pretending to know the seam. Do not claim contact-centre history. | Peer seam. No past claim is made. |
| C9 | "How do you handle credit when a complaint fix needs two teams?" | VAL | [generic] | Name the shared fix and the decision that was yours. Do not claim a credit history the material does not show. | Peer stem. Reciprocity. |

---

## Requirement coverage

| JD requirement | Covered by |
|---|---|
| 4+ years in financial-services customer operations | A1 |
| Experience handling regulated complaints | B2, B3 |
| Own the complaints process end to end across branches and the contact centre | B3, C6 |
| Report monthly on complaint volumes and resolution times | A6, B4, C5 |
| Coach branch supervisors on escalations | B5, C6 |
| Confident presenting to senior leaders | A7, B6 |
| Comfortable with Excel reporting | A6, B4 |
| Work with digital teams on self-service journeys | B7 |

## Reverse questions

Each has a "why it lands" line. No interviewer profile exists, so none is tied to an interviewer's career path.

**Round 1, recruiter**
- "What would a successful first 90 days in this role look like?" Why it lands: it shows you are planning the job, not just the offer.

**Round 2, Head of Member Services**
- "How do complaints move today between branches and the contact centre?" Why it lands: it names the seam the role must own before you are asked to describe it.
- "What would you want this role to have changed by the first review?" Why it lands: it asks for the success measure, and shows you expect to be judged on it.

**Round 3, panel**
- "What is the hardest escalation your branch managers pass to each other?" Why it lands: it shows you want the real case, and leads into the seam.
- "What could a new Member Experience Lead do in their first month that would genuinely help your branches?" Why it lands: reciprocity for a peer panel.
- "How will the hub consolidation in 2027 change where complaints are handled?" Why it lands: it uses the July 2026 brief and shows you read it.

## Sources

**Provided documents**
- Job description, from your message.
- Your background, from your message.
- Published values, pasted from ashgrovecu.org/about/values, copied 26 November 2026.
- Recruiter's process email, with the three rounds on 5 December.
- Strategy brief, July 2026. You supplied its summary; I have not read the full document.

**Searches and fetches:** none sent.

**Research tier:** L1. Searches 0 of 6, fetches 0 of 2. Every target was fixed by a provided input, so none needed a search.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Company values | yes | Provided. Values cheat sheet. Pasted values fix the content, so no search. |
| 2. Interview process | skipped | Provided. The recruiter's email fixes the loop structure. |
| 3. Company strategy / recent news | skipped | Provided. The strategy brief summary fixes the grounding brief. |
| 4. Interviewer name | n/a | No names assigned. |
| 5. Representative JD | skipped | Provided. Your JD fixes the fit snapshot. |

## Upgrade menu

- Names of the Head of Member Services and the two branch managers → per-person persona weights, an interviewer read from public professional footprint only, and tailored reverse questions.
- The panel's case sheet, if they share one → C6 and C7 rebuilt on the real facts, not the generic scenario.
- Any regulatory timescale or external review you worked to → upgrades F2 and B2 from presentation to grounded detail.
- Any work with a digital or app team → upgrades F8 and B7 from discovery to grounded.
- The complete strategy brief → the grounding brief cites the document, not your summary.
- Figures from your own complaints records, if you can share them → figures become quoted material, and the defend-the-number slots become rehearsable.
