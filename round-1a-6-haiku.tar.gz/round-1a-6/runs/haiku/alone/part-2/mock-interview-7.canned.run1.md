Your prep pack is saved at `/tmp/claude-0/-var-tmp-tuesday-measure-1a6-runs-haiku-alone-part-2-rooms-case-7-canned-05bbc213/260358ad-4afc-4067-b718-50ef1375ce16/scratchpad/saltmarsh_live-operations-producer_interview_pack.md`.

The most useful things in it:

- **The interview format is public.** Saltmarsh's interviewing page says the loop is a recruiter call, then the "Outage Hour": a 60-minute interview with the hiring manager. It's a live-incident tabletop during a live event, then a values conversation. So expect a tabletop problem, not only questions about your CV.
- **Three published values** (Players Before Plans, Ship the Patch Not the Promise, Leave the Build Greener). The pack maps each to your material, and where your material doesn't carry a story it gives a selection prompt with an honest "if none, say so" branch.
- **Your highest-ROI prep is B1**: "You've never led a team. Why would we trust you to coordinate four teams on an update?" Concede the gap plainly, then hold on the coordination you actually did.
- **Tobias** wrote a GDC 2026 talk, "Patch Notes Are a Promise," and was previously a QA lead. The pack uses that for a shared jump to your release checklist. That talk is from a search result, so check it before you cite it.
- **A news item matters for the two-title requirement.** Project Larkspur (from a search snippet; I did not open the page) moves both titles to a season-pass model with one shared calendar from February 2027. That is monetisation, which you have not worked on, so B2 and A4 are built around it. Read the announcement yourself before Friday.

Gaps the pack treats honestly: you've never led a team, never worked on in-app purchases, and have no evidence yet of coordinating design/art/engineering/community, post-event reviews, or running two titles at once. Each gets an answer slot rather than a suggested story. Don't rehearse anything you didn't do.

I need one answer to finish the gate row:

Did your four years as an associate producer include producing a live-service title, or only running the content calendar?

If you'd like, I can run a drill on the Skeptic question B1 before Friday. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions. And I can convert the pack to Word if you want it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh_live-operations-producer_interview_pack.md -----
# Interview prep pack: Live Operations Producer, Saltmarsh Games

**Interviewer:** Tobias Wrenfield, Head of Live Operations
**Round:** the Outage Hour, a single 60-minute interview with the hiring manager (per Saltmarsh's interviewing page): a live-incident tabletop during a live event, then a values conversation. No take-home.
**Relationship:** hiring manager. The Outage Hour page establishes the round, so no round-type question was needed.

---

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored.
- Type key: **CASE** = live problem from the role, solved aloud. **VAL** = whether your past behaviour shows a published Saltmarsh value. **JD** = a requirement from the job description, including its gaps. **EXP** = a deep-dive into something on your CV or message. **CO** = company knowledge.
- Guidance is scaffolding, not a script. Each cell is written to be said in 90 to 120 seconds. Use your own words.

---

## Fit snapshot

Requirements are quoted from the JD you pasted, or from the company pages I fetched. Evidence is quoted from your message, with its source named.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| R1 | "3+ years producing live-service games or apps" (JD, gate) | "4 years as an associate producer at a puzzle-game studio" (your message) | medium | [grounded] | hard_gate | Surfaced, not bridged. Your material does not establish this gate as worded: it shows four years as an associate producer, and does not say whether that was producing, or whether the title was live-service. Answered by the closing question. |
| R2 | "experience running a content calendar" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | high | [grounded] | none | No gap. Lead with the calendar in your own terms: a weekly content-drop calendar, one title, two years. |
| R3 | "Plan and run the live-events calendar for two of our mobile titles" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | transferability | Your material says one title and a weekly content-drop calendar, not two titles or live events. Bridge: "For two years I ran the weekly content-drop calendar for our main title." Answer slot: the JD asks for two titles at once, so expect a probe on how you would split one calendar across two. If you have planned more than one calendar, say so; if not, say so and say how you would plan it. |
| R4 | "comfortable with player-retention metrics" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | medium | [grounded] | presentation | The quote reaches retention in other terms: you presented the numbers, not that you defined or analysed them. Bridge rewords only the quote: "I presented the monthly retention numbers to the studio head." Add no figures. |
| R5 | "clear written communication" (JD) | "Wrote the release checklist our QA team still uses." (your message) | medium | [grounded] | none | A written artifact another team still uses. Its scope is a checklist, not general writing, so use the checklist as the example and no broader claim. |
| R6 | "manage the release checklist with QA" (JD) | "Wrote the release checklist our QA team still uses." (your message) | medium | [grounded] | transferability | Your material says you wrote it and QA uses it, not that you managed it release by release. Bridge: "I wrote the release checklist our QA team still uses." Answer slot: if you ran the checklist with QA for a specific release, say what you did; if you did not, say so and say how you would run it. |
| R7 | "coordinate design, art, engineering and community teams on each update" (JD) | none given | none | [grounded] | discovery | Your material does not show coordinating these teams on an update. Answer slot: if you coordinated any of them for a content drop, say which and what you did; if you did not, say so and describe how you would set it up. |
| R8 | "own the post-event review and the KPIs it reports" (JD) | none given | none | [grounded] | discovery | Your material does not show running a post-event review or owning KPIs. Answer slot: if you ran or owned a review, say what it covered; if not, say so and say what you would put in it first. |
| R9 | leading people (not in the JD text; role-family expectation for a producer-level role) | "Never led a team" (your message) | none | [grounded] | capability | A gap you stated. Words: "I've never led a team." Then how you would work with the teams without line authority, said as a plan, never as a past. |
| R10 | season-pass monetisation on the company's titles (Saltmarsh news, see Sources; [inferred] that it bears on this role) | "never worked on a game with in-app purchases" (your message) | none | [grounded] | capability | A gap you stated. Words: "I haven't worked on a game with in-app purchases." Then how you would learn it, as a plan. |

**Gate note.** R1 is a gate. Whether it is met is asked once, in the closing question.

---

## Prohibited claims

What this pack will not coach, and why. Each entry names its basis.

| Not coached | Basis | Honest form |
|---|---|---|
| Ran live-events calendars for two titles | Inflated form of R2 and R3 | Your quote at its own scope: one title, a weekly content-drop calendar, two years. My observation, not words for you: the material says one title. E1 and B3 stay inside that. |
| Owned the KPIs the post-event review reports | Inflated form of R8 and R4 | Your quote about presenting monthly retention numbers, at its own scope. My observation: the material does not show owning KPIs. E3's slot asks what you would put in a review. |
| Managed the release checklist with QA | Inflated form of R6 | "I wrote the release checklist our QA team still uses." No broader verb. |
| Led a team | Sourced negative: "Never led a team" (your message) | "I've never led a team." No slot about leading people. |
| Worked on a game with in-app purchases | Sourced negative: "never worked on a game with in-app purchases" (your message) | "I haven't worked on a game with in-app purchases." |

---

## Persona weights

| Persona | How it shows up in this round | Weight | Reasoning |
|---|---|---|---|
| Case/Strategist | The live tabletop: a simulated outage in the middle of a live event | Highest (5 questions) | The page describes the round as a live-incident tabletop first. |
| Skeptic | Probes your two gaps: two titles at once, and no in-app purchase work | High (4 questions) | A hiring manager is buying capability and reducing risk on exactly these gaps. |
| Values | The values conversation that follows the tabletop | Mid (3 questions) | The page names a values conversation in the same hour. |
| Data-Driven Prober | Retention and post-event KPIs | Mid (3 questions) | The JD names retention metrics and KPI ownership. |

Every persona gets questions, so no style is met for the first time live.

---

## Interviewer read

Public footprint only.

- **Career pattern.** A GDC 2026 talk, "Patch Notes Are a Promise," lists Tobias as Head of Live Operations at Saltmarsh and previously a QA lead at a console studio. The argument, as the listing gives it: a live team is judged by how often its patch notes describe what actually shipped. (Source: search result only, not fetched; check the talk on Saltmarsh's or the conference's own page.)
- **Implications.** Expect claims to be tested against what shipped. Your strongest answers say what you checked, not what you believe.
- **Shared jump.** His QA-lead path, paired with the quote: "Wrote the release checklist our QA team still uses." Use it once, in the context of the release checklist.
- **Mirror opportunities.** His vocabulary: "patch notes," "shipped." Your R6 and C2 answers can use the same words, if you did the work they describe.

---

## Values cheat sheet

Saltmarsh's published values (official page, fetched). The values conversation is part of this round.

| Value (official name) | Working meaning | Your mapped story |
|---|---|---|
| Players Before Plans | "when the calendar and the players disagree, the players win." | Scaffold, see C1: "I ran the weekly content-drop calendar for our main title for the last two years." Pick a time a date moved for players. If none comes to mind, say so, then give the nearest thing you did. |
| Ship the Patch Not the Promise | "we announce what is built, not what is hoped." | Scaffold, see C2: "Wrote the release checklist our QA team still uses." Did the checklist ever stop something being announced? If yes, say what. If not, say so. |
| Leave the Build Greener | "every release leaves the codebase and the checklist better than it found them." | Scaffold, see C3: the checklist again. Did a release change it, and why? If it did not, say so. |

---

## Question banks

Ordered by persona weight. Provenance lists every candidate sentence the guidance rests on.

### A. Case/Strategist (outage tabletop)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "It is 6pm on day two of a limited-time event. The reward claim is failing for about one player in five, and the community team has the first complaints. Walk me through your first hour." | CASE | [generic] | Name the incident owner first. Then: hold the event or not, which engineers and QA you pull in, what you tell players and when, and what you log for the post-event review. Keep the order short. | The tabletop is the round's first half, per the company's page. The question needs no claim about your past. |
| A2 | "Engineering says the fix is 48 hours away. What do you tell the community team, and what do you tell players tonight?" | CASE | [grounded] Saltmarsh values page: "we announce what is built, not what is hoped." | Tell players only what is built. Give the community team the same line. Name what is unknown and when you will update. | Tests the "Ship the Patch Not the Promise" value under pressure, in a live problem. |
| A3 | "An event goes live Thursday. QA says the release checklist was not fully run on the last patch. Do you ship?" | CASE | [generic] | Decide what is unverified, and what it would take to verify it. Make the call with QA, in the room, not alone. Write down the decision and the risk. | The release checklist is a JD line (R6). This tests the decision, not a past. |
| A4 | "If two titles share one live-ops calendar, and two events want the same slot the following week, how do you decide?" | CASE | [inferred] Saltmarsh news search result (Project Larkspur), not fetched | Name the criteria first: player impact, commitments already made to players, QA capacity. Then the decision. Say what you would tell the losing team. | Tests the two-title requirement (R3) as a live problem. Phrased conditionally, so it presupposes nothing about your past. |
| A5 | "Last month's event hit its target but retention dipped the week after. What changes in the next patch?" | CASE | [generic] | Separate what changed for players who attended from what changed for players who did not. Name the one change you would make first, and what would tell you it worked. | Connects the event calendar to retention, which the JD asks for. |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've never led a team. Why would we trust you to coordinate four teams on an update?" | JD | [grounded] "Never led a team" (your message) | Hold-then-concede. Concede plainly: "I've never led a team." Then hold on the coordination you did, and on how you would run the four teams without line authority. Answer slot for R7: if you coordinated any of design, art, engineering or community for a drop, say which and what you did; if you did not, say so and say how you would set it up. Do not fold on the plan. | This is the highest-ROI prep. The objection lands where your material is thinnest, and it will be asked in some form. |
| B2 | "You've never worked on a game with in-app purchases. What would you need to know before planning a paid event?" | JD | [grounded] "never worked on a game with in-app purchases" (your message) | Acknowledge the gap in your own words: "I haven't worked on a game with in-app purchases." Then name what you would ask first: the purchase data, the players who would see it, and what retention looked like before. These are questions, not claimed experience. | A plain acknowledgment with a plan. Guidance names no practice you did. |
| B3 | "A weekly content drop is not two titles. How is planning two titles different from what you did?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | Story from one calendar: the cadence, the one title, the two years, in your words. Answer slot: if you planned any cadence across more than one product, say which. If not, say so and say what carries over from the calendar you ran. | Tests the transferability in R3 under the most likely probe. |
| B4 | "Who owns the post-event review here, and what did you own in yours?" | JD | [grounded] "Presented the monthly retention numbers to the studio head." (your message) | You presented the monthly numbers. Say that, and no more. Answer slot for R8: if you ran or owned a post-event review, say what it covered; if not, say so and say what you would own first. | The JD says "own the post-event review." This tests whether you claim more than you did. |

### C. Values

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time the calendar and the players disagreed. Which one won?" | VAL | [grounded] Saltmarsh values page: "when the calendar and the players disagree, the players win." Also "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | Selection: pick a time a content date had to move for players. Name the trade-off and what you did. If no such time comes to mind, say so, then give the nearest thing your calendar work carries and how you handled it. | Players Before Plans, mapped to the calendar you ran. |
| C2 | "Tell me about a time you had to pull back something you'd already announced." | VAL | [grounded] Saltmarsh values page: "we announce what is built, not what is hoped." Also "Wrote the release checklist our QA team still uses." (your message) | Selection: a time a checklist, or a QA check, stopped an announcement. If yours did, say what it checked and what it stopped. If none did, say so, then say what the checklist does check. | Ship the Patch Not the Promise. Tobias's talk is about this exact claim. |
| C3 | "What did a release leave behind that the next one used?" | VAL | [grounded] Saltmarsh values page: "every release leaves the codebase and the checklist better than it found them." Also "Wrote the release checklist our QA team still uses." (your message) | Story: the checklist you wrote, and what QA still uses. If a release changed it after you wrote it, say what changed and why. If none did, say so. Do not extend it to the codebase. | Leave the Build Greener, mapped to the one artifact you have. |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You presented the monthly retention numbers. What counted as retained?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." (your message) | Say what you presented. If you can name the retention definition the studio used, say it in your words. If you cannot, say so. Answer slot: name the assumption you would defend least, if you know it. | A premised question about a presentation. You gave no figure, so no defend-the-number slot is raised. |
| D2 | "Which cohort would you watch first after a limited-time event?" | JD | [generic] | Name the cohort the event targets, and the one it might have pulled players away from. Say why, and what you would expect to see. | Tests retention reasoning from the role, with no claim about your past. |
| D3 | "Your post-event review says the event hit target, but retention dipped. What is your next question?" | CASE | [generic] | Name the question that could change the conclusion: what the event did to players who did not attend. Name the assumption behind the target. | Tests the KPI reasoning the JD asks for. |

### E. JD coverage

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Plan and run the live-events calendar for two of our mobile titles. What would your first 30 days look like?" | JD | [grounded] JD: "Plan and run the live-events calendar for two of our mobile titles" with "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | Start from the calendar you ran: the weekly cadence, the one title. Then the steps for the second title. Answer slot: the two-title part is new to you; say so and describe the plan. | The headline requirement. |
| E2 | "Coordinate design, art, engineering and community on each update. How do you run that?" | JD | [grounded] JD: "coordinate design, art, engineering and community teams on each update" | Answer slot only (R7): your material does not show this. Say which team you worked with on a drop, if any, and what you did. If none, say so and describe the plan. | A mid-list requirement that is easy to miss. It is in the JD, so it is in the pack. |
| E3 | "Own the post-event review and the KPIs it reports. What would be in yours?" | JD | [grounded] JD: "own the post-event review and the KPIs it reports" with "Presented the monthly retention numbers to the studio head." (your message) | Start from the retention numbers you presented. Name what the review would add: the event targets, the cohort, the one number you would check first. Answer slot for R8: say what you owned, if anything. | Ties the JD's KPI ownership to the one thing your material does show. |

### Requirement coverage

| JD requirement | Question IDs |
|---|---|
| 3+ years producing live-service games or apps | none in the banks: a gate, asked in the closing question and surfaced in R1 |
| Plan and run the live-events calendar for two titles | E1, B3, A4 |
| Coordinate design, art, engineering and community | E2, B1, A2 |
| Own the post-event review and the KPIs it reports | E3, B4, D3 |
| Manage the release checklist with QA | A3, C3 |
| Experience running a content calendar | B3, E1 |
| Comfortable with player-retention metrics | D1, D2 |
| Clear written communication | none, and why: the Outage Hour as the company describes it is a tabletop then a values conversation, with no written component. R5 covers the checklist. |

---

## Reverse questions

Ask these in the second half. Each has a reason it lands.

1. "What does the first hour of a live incident look like on your team today, and who makes the call?" Why it lands: it shows you read the round, and it tests how the role holds decisions.
2. "Your talk argues that patch notes are a promise. Which checks does your team run before a note goes out?" Why it lands: it shows you read the talk and ties to his path. (Confirm the talk first; see Sources.)
3. "Coming from QA, what did you have to learn about producing that you'd want the next producer to know?" Why it lands: ties to his QA-lead path, and asks for experience he can answer.
4. "If the two titles share one live-ops team from next year, what does the calendar look like in the first quarter?" Why it lands: it shows you read the company's news, and asks how the role will be planned. (From the search result, not fetched.)
5. "Where does the post-event review sit, who reads it, and what happens after it is read?" Why it lands: it tells you whether the KPIs the role owns are acted on.
6. "What would a good first 90 days look like for the person in this role?" Why it lands: it asks for the bar in his words.

---

## Delivery coaching

Dropped: no working-style assessment was provided.

---

## Sources

Research tier: L1 — searches 4 of 6, fetches 2 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | yes | Values cheat sheet: three values by official name, from the fetched page at saltmarshgames.com/values |
| 2. `Saltmarsh Games interview process Live Operations Producer` | yes | Loop structure: recruiter call, then the Outage Hour, a 60-minute interview with the hiring manager. The round is a live-incident tabletop during a live event, then a values conversation. No take-home. Establishes the loop; sets the persona weights. Fetched at saltmarshgames.com/careers/interviewing |
| 3. `Saltmarsh Games strategy news 2026` (strategy / recent news) | yes | One search result: Project Larkspur, moving Tidepool Tactics and Lantern Row to a season-pass model with one shared events calendar from February 2027, and retiring per-title event teams for a single live-ops group. Moved A4, R10 and reverse question 4. Search snippet only; not fetched |
| 4. `Tobias Wrenfield Saltmarsh Games Head of Live Operations` (interviewer public footprint) | yes | One result: a GDC 2026 talk listing, "Patch Notes Are a Promise." Moved the interviewer read, the shared jump and reverse questions 2 and 3. Source is a search result on an unverified domain |
| 5. representative `Live Operations Producer` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

Further search outside the declared targets: none.

Documents you provided: your message (the JD and background as pasted).

---

## Upgrade menu

- Confirm the Larkspur announcement at saltmarshgames.com/news/project-larkspur → turns A4 and reverse question 4 from [inferred] into [grounded]
- Confirm the GDC talk on its own page → turns the interviewer read from a search result into a checked source
- Any example of coordinating design, art, engineering or community on a drop → upgrades R7, E2, B1 from answer slots to stories
- Any example of running or owning a post-event review → upgrades R8, E3, B4
- Any cross-title or cross-team planning, even informal → upgrades R3, E1, B3
- A deeper research pass (strategy brief, the company's other talks, loop reports for this role family): up to 6 more searches and 2 more fetches, several minutes, if you want it
