Your prep pack is saved as /var/tmp/tuesday-measure/1a6/runs/haiku/alone/part-2/rooms/case-4-denied-b78874f2/quartzline_product_manager_platform_apis_interview_pack.md. It is built on your dossier, with three things to know first:

- **The dossier is 104 days old.** It is dated 14 August. Check the posting before Thursday. If the requirements have changed, send me the current JD and I'll regenerate the affected rows.
- **No Quartzline research ran.** Search permission was not granted in this session, so the pack says nothing about their values, interview loop or current strategy.
- **I've assumed Thursday means 3 December.** Today, 26 November, is itself a Thursday.

Top priority is A1, the objection the underwriter named: "You have never held the PM title or owned a roadmap…". Rehearse it aloud. Concede the title and roadmap in one sentence, give the 30+ integrations at their own scope, then name the limit. Hold through at least three follow-ups.

One grading call differs from a simple read of the dossier. It does not weak-flag "Shipped API or platform products", but I grade that row as transferability, because the integration work was client-side. If the underwriter should stand on that, tell me and I'll change the row.

Say the word and I'll play the Skeptic on A1, the question the pack names as its highest-ROI prep.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quartzline_product_manager_platform_apis_interview_pack.md -----
# Interview prep pack: Product Manager, Platform APIs at Quartzline

**Interviewer:** hiring manager (name not given). Round: 45 minutes, one conversation.
**Built from:** the underwriting dossier dated 2026-08-14 (conditional_go). That dossier is 104 days old. Check the posting before Thursday; if its requirements have changed, the fit snapshot and the JD-tagged questions need regenerating.
**Assumed:** Thursday means 3 December 2026. Today, 26 November, is itself a Thursday.

## How to use + type key

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script. Say it in your own words, and where a line is an answer slot, answer from what you actually did.

| Type | Scores |
|---|---|
| JD | Whether you can do the listed job, gaps included |
| EXP | Whether your claims survive scrutiny and who did what |
| CASE | Structure and reasoning on a live problem from the role |
| VAL | Published values (none in hand; not built) |
| CO | Company and strategy knowledge (no research ran; not built) |

Provenance: `[grounded]` traces to your dossier or the posting. `[inferred]` is a derivation from it. `[generic]` is a pattern for this kind of question, with no claim about you or Quartzline.

## Fit snapshot

Requirements are the dossier's `role_profile` (quoted as its text). Evidence is quoted from the dossier's `verified_candidate_evidence` entries, which I label E1 to E3 in order. R1 to R5 are the dossier's requirement IDs.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" (JD, R1) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier E1 | high | [grounded] | transferability | Adjacent, not PM experience. Words: "I led 30+ end-to-end client integrations of the vendor's REST APIs." Limit, as the pack's own observation: this is client-side integration work, with no product title or roadmap in it. Answer slot: of scoping, requirements, architecture, UAT and go-live, which did you decide, and which did the vendor decide? |
| F2 | "Shipped API or platform products" (JD, R2) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier E1 | high | [grounded] | transferability | The dossier does not list R2 as weak. I grade it transferability because the quote is client-side work, not a shipped product. If the underwriter's view should stand, change this row to none. Words: "I led 30+ end-to-end client integrations of the vendor's REST APIs." Answer slot: if you shipped an API or platform product yourself, name it and your part; if not, say so and stay with the integrations. |
| F3 | "Technical fluency: API docs, schemas" (JD, R3) | "Wrote the internal integration playbook her team uses" — dossier E2 | high | [grounded] | transferability | Adjacent. Words: "I wrote the internal integration playbook my team uses." Limit: a playbook covers how integrations run, not API documentation or schema design. Answer slot: if you have written or reviewed API docs or schemas, name them; if not, say so and say what you would check first. |
| F4 | "Stakeholder management across engineering, sales, customers" (JD, R4) | "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier E3 | medium | [grounded] | presentation | The quote reaches the requirement in other terms: product and clients. Words: "I ran quarterly roadmap-input sessions that fed client evidence to product." Caveat: limited inspectable proof, so expect a probe and volunteer the limit. Answer slot: name any engineering or sales stakeholders you worked with on that, if any; if none, say so. |
| F5 | "Agile delivery experience" (JD, R5) | none given | low | [grounded] | discovery | Clarify, no bridge. Nothing in the material speaks to this requirement. Answer slot: if you have delivered through sprints with a product squad, name the cadence and your place in it; if not, say so plainly and ask what agile means for their teams. |
| F6 | "Own the roadmap for the partner-facing API platform" (JD responsibility); "Owning a roadmap and prioritization authority" (dossier, weak area) | none given | none | [grounded] | capability | The dossier records this as an acknowledge_gap area, so the words come from its prohibited_claims field. Words: "I haven't owned a product roadmap." and "I haven't set prioritization for an engineering squad." Then a ramp plan in your own words, labelled as a plan, not a past. No bridge. |
| F7 | "Define and track adoption metrics" (JD responsibility) | none given | none | [grounded] | discovery | Evidence may exist; the material does not show it. Answer slot: name any adoption measure you have tracked, in your own words; if none, say so and say what you would count first. The dossier states no current baseline. |

Hard gates: none. The dossier lists none.

Note on F2: I graded it differently from a simple read of the dossier, which does not weak-flag R2. The reason is the client-side framing of E1. Flag it if the underwriter should be consulted.

## Persona table

| Persona | How it shows up | Weight and why | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet probes on the missing PM title, roadmap authority and agile delivery | 5. A hiring manager buys capability and derisks gaps, so Case and Skeptic are the priors. The dossier's three weak areas and its named objection both sit here. | Rehearse A1 until it is plain: concede, give the evidence at its own scope, name the limit, then the plan. |
| Case/Strategist | Live problems from the JD's responsibilities: partner breakage, flat adoption, deprecation, a trade-off between stakeholders | 5. Hiring-manager prior, and the JD's responsibilities are the scoring sheet. | Clarify, then segment, then metrics. Name who decides before you decide. |
| Data-Driven Prober | Counts behind the 30+ figure; which metric you would trust least | 3. Mid. The JD's adoption line and the headline figure give it material. No interviewer signal raises it. | Defend the number in your own words; name the weakest assumption before they do. |
| Pressure | Time-boxed "why you"; "how much was actually you" | 3. Mid. The dossier's objection invites follow-up holds. | Pause, restate, hold through two follow-ups, then concede specifically. |
| Conversational | A friendly opener and a casual question on partner APIs | 2. Low weight, but both are scored. | Prepare one 90-second arc from quoted sentences only. |
| Values/Behavioral, Peer | Not weighted | 0. No values round is detected (no research ran), and the loop is unknown, so no peer round is assumed. | Not applicable to this pack. |

No interviewer profile was given, so the interviewer read is dropped.

## Question banks

Eighteen questions in total: A (Skeptic, weight 5), B (Case/Strategist, weight 5), C (Prober, weight 3), D (Pressure, weight 3), E (Conversational, weight 2).

**A1 is the highest-ROI prep in this pack.** The underwriter named this objection, and I have used its wording. It is the one most likely to be asked in some form.

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs" (dossier E1); prohibited_claims "Having held a product manager title or role" and "Having owned a product roadmap" | Hold, then concede, in this order. (1) Concede in one sentence: "I haven't held a product manager title, and I haven't owned a product roadmap." (2) Give the evidence at its own scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs." (3) Name the limit in your own words: the work was on the client side of the APIs. (4) Answer slot: name the first thing you would want to learn from the squad leads before you set priorities. Hold through two follow-ups by returning to the integrations. Never argue that integration work equals PM experience. About 100 seconds. | The underwriter named this as the likeliest objection, and the question is its wording. Both negatives carry the dossier's prohibited_claims as their source. Rehearse it with at least three follow-ups. F1 and F6 are the rows it reads. |
| A2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] prohibited_claims "Having owned a product roadmap"; JD R5 "Agile delivery experience" | Name the roadmap first: "I haven't owned a product roadmap, so day one is the roadmap." Then agile, as a clarify: "Here's what I'd want to confirm about how your teams define agile before I say how I'd work in it." | A stem from the Skeptic bank. Two areas in the dossier are weak, and this question makes you rank them yourself. F6 and F5. |
| A3 | "I don't see a product management role in your background — how would you handle the roadmap in this role?" | JD | [grounded] prohibited_claims "Having held a product manager title or role" | Confirm the gap in one line, then give the plan: how you would learn the roadmap with the two squad leads, as a plan and not a past. Answer slot: name the first roadmap decision you would want to see made with them. Claim no past roadmap work. | The premise is the interviewer's own negative, sourced to the dossier field. It tests the same gap as A1 from the other side. The plan is the only thing the answer adds. |
| A4 | "Walk me through how delivery has run for you in an agile cadence, and where you sat in it." | JD | [grounded] JD R5 "Agile delivery experience" | Answer slot: if you have delivered through sprints with a product squad, name the cadence and your place in it. If you have not, say so plainly, then ask what agile means for their two squads. No bridge: nothing in your material speaks to this requirement, and the nearest entry, UAT and go-live, is not sprint work. | Clarify strategy for R5. The dossier allows no bridge here, so the honest answer is a limit. |
| A5 | "Why this role, and why now?" | JD | [generic] | Your reason is not in the material, so the answer is yours: one sentence on why this role, one on why this partner-API problem in particular. Answer slot: the reason you are moving, in your own words. | A standing Skeptic probe on motivation. The material gives no reason, so the pack supplies none. |

### B. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A partner says its integration broke after our last API change, and it's escalating. What do you do in the first 48 hours?" | CASE | [generic] | Clarify first: which partners, which endpoints, which version, and whether the break is from a change or from load. Then the objective: keep the partner live and trusting the platform. Segment before you fix. Name who makes the rollback call, and say you would confirm it with the squad leads rather than assume it. Two minutes. | A live problem from the JD's partner-discovery and partner-facing responsibilities. It presupposes nothing about your past. The "who decides" step tests the decision-authority unknown. |
| B2 | "Partner API adoption is flat. Diagnose it, and tell me what you would measure first." | CASE | [grounded] JD responsibility "Define and track adoption metrics" | Clarify the definition of adoption first, then the baseline, which the dossier says is not stated. Segment by partner type and integration stage. Propose the first measure and say what it would not tell you. Ask for the baseline as a question if you do not have it. | The JD's adoption responsibility is the raising source, and the dossier flags the baseline as unknown. The answer needs no claim about your past. |
| B3 | "We're considering deprecating v1 of the partner API in six months. What's your plan?" | CASE | [generic] | Frame the decision: what it costs partners, what it saves the squads, and who decides. Then the migration path: notice, support, and a measure of cutover. Say what you would need from the squad leads before you commit to a date. | Tests partner-facing platform ownership without asking for any past work. |
| B4 | "Engineering wants a rate-limit feature three partners asked for. Sales says a larger partner wants something else. How do you decide, and who decides?" | CASE | [grounded] JD R4 "Stakeholder management across engineering, sales, customers" | Structure: criteria first (adoption, partner value, cost to the squads), then the decision owner. Say you would want to know which decisions the squad leads own before you answer. | Tests R4 and the decision-authority unknown in one scenario. The provenance is the JD requirement; the guidance states nothing about you. |
| B5 | "Tell me about a time you shipped an API or platform product." | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs" (dossier E1) | Answer slot: if you shipped an API or platform product yourself, name it and your part in it. If you did not, say so plainly, then give the nearest thing your material carries: the integrations you led, end to end. Do not stretch "shipped" over the integrations. | R2 is the requirement this open prompt scores. The honest branch is the one the quote carries, so the answer is a limit, not a claim. |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the 30+ integrations were counted." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs" (dossier E1) | Answer slot: how you counted them, in your own words. If you cannot say how, say that plainly. Then name the assumption behind the count you would defend least, and say which integrations you ran end to end. The pack supplies no counting method. | A headline figure raises the defend-the-number slots. Rehearse the "I don't know how it was counted" branch as much as the others. |
| C2 | "Which partner-integration metric would you trust least, and why?" | JD | [grounded] JD responsibility "Define and track adoption metrics" | Selection scaffold ending in the honest branch: name a metric you have used on integrations and why you would doubt it. If you have not defined adoption metrics, say so, then name what you would count first. The pack proposes no metric of its own. | The Prober probes the metric responsibility. The honest branch matters more than any metric you could name. |
| C3 | "Which of those 30+ integrations would you defend least as your own work?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs" (dossier E1) | Answer slot: say which of the 30+ you ran end to end, which the vendor's teams drove, and which you would defend least. Hold to the split you can name, and do not add a count. | Assumption-level attribution. C1 asks how the count works; C3 asks what share is yours. |

### D. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you, and not an internal candidate?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs" (dossier E1); "Ran quarterly roadmap-input sessions feeding client evidence to product" (dossier E3) | A 60-second answer from the two quotes: the integrations, then the roadmap-input sessions, then one plain concession that you have not held the PM title. Say you do not know who else they are seeing, and do not compare yourself with an internal name. Hold the client-side argument through two follow-ups. | Persona stem for Pressure. The clock is the test; the concession is the point. |
| D2 | "That integration result: how much of it was actually you?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs" (dossier E1) | Hold the quote: you led them. Answer slot: name which parts were yours and which the vendor's teams did. If you cannot split them, say so and stay with "led." Add no outcome. | Attribution pressure. The hold is the quote, and the concession is the split, not an outcome. |
| D3 | "A ramp plan is cheap to say. What would you show me in 90 days?" | JD | [generic] | Name three concrete outputs, in your own words: for example, an adoption baseline, a decision map agreed with the squad leads, and the first roadmap call you would take to them. Concede that a plan is not a track record, then show what you would check first. Do not cite past roadmap work. | Pressure on the ramp plan that A1 and A3 depend on. The concession is what makes the plan believable. |

### E. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs" (dossier E1); "Wrote the internal integration playbook her team uses" (dossier E2); "Ran quarterly roadmap-input sessions feeding client evidence to product" (dossier E3) | A 90-second arc in this order: the integrations, the playbook, the roadmap-input sessions, then why this role. Each beat is one of the quotes at its own scope. Stop at the sessions; the PM title belongs to A1, not the arc. | The opener is scored too. The arc uses only the three verified entries, so nothing in it outruns the evidence. |
| E2 | "What are you actually playing with in partner APIs these days?" | JD | [grounded] "Wrote the internal integration playbook her team uses" (dossier E2) | Name the API work you have done most recently, in your own words, then say what the playbook covers: how integrations run. Answer slot: if you have hands-on API work now, say what it is; if not, say which API you know best from the integration side. | A casual probe on R3. The playbook is adjacent, so say what it does not cover. |

## Requirement coverage

| Requirement | Questions |
|---|---|
| JD R1, 3+ years product management | A1, A3, D1 |
| JD R2, shipped API or platform products | B5, A1 |
| JD R3, technical fluency: API docs, schemas | E2 |
| JD R4, stakeholder management | B4, E1 |
| JD R5, agile delivery experience | A2, A4 |
| Responsibility: own the partner API roadmap | A2, A3, B3 |
| Responsibility: run discovery with integration partners | B1 |
| Responsibility: write specs and drive delivery with two squads | B4, A4 |
| Responsibility: define and track adoption metrics | B2, C2 |
| Unknown: decision authority versus the squad leads | A3, B1, B4, reverse question 1 |
| Unknown: adoption baseline | B2, C2, reverse question 2 |

Every requirement has at least one question. No row is marked "none, and why."

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" | The JD asserts decision authority and the material does not evidence it. The answer tells you whether the role is what it says. |
| 2 | "How is partner API adoption measured today, and what is the current baseline?" | The JD names adoption as a responsibility and the dossier found no baseline. Reads as diligence, and answers a question you genuinely need settled. |
| 3 | "Which two squads does this role sit across, and where do they disagree most?" | Two squad leads share the authority question. Whether the work is coordinating or deciding depends on the answer. |
| 4 | "What would a strong first 90 days look like here, and which decision would you want me to make first?" | Tests whether your ramp plan matches their expectation. The answer tells you what A1 and A3 should promise. |
| 5 | "Is there a next round after this conversation, and who is in it?" | Process question. Tells you whether this is the final conversation before you plan the rest. |

No interviewer profile was given, so no reverse question ties to the interviewer's path.

## Prohibited claims

These claims are not coached, in any cell of this pack.

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | Dossier prohibited_claims | "I haven't held a product manager title." Plain acknowledgment, sourced to the dossier field. |
| Having owned a product roadmap | Dossier prohibited_claims | "I haven't owned a product roadmap." Plain acknowledgment, sourced to the dossier field. |
| Having set prioritization for an engineering squad | Dossier prohibited_claims | "I haven't set prioritization for an engineering squad." Plain acknowledgment, sourced to the dossier field. |
| Owned the partner-API platform | Inflated form of F1 (built here) | The F1 quote at its own scope. Pack observation, not words for you: your material describes client-side integrations, not the platform. |
| Shipped API or platform products | Inflated form of F2 (built here) | The F1 quote at its own scope. If you shipped something yourself, the B5 answer slot is where you say so. |

## Sources

- **Provided:** `tuesday-dossier.md`, pasted as a JSON envelope. Version 1.1, generated 2026-08-14 by job-underwriter, role Product Manager, Platform APIs at Quartzline.
- **Consumed:** `role_profile` (requirements, responsibilities, unknowns); `handoff_to_mock_interview` (verified_candidate_evidence, uncertain_or_weak_areas, likely_interviewer_objections, opportunity_risks_to_validate, questions_for_employer, prohibited_claims); `decision` (context only).
- **Absent from the dossier:** `evidence_map`, `evidence_state`, `risk_register`.
- **Dossier age:** 104 days at 2026-11-26. The role and its requirements may have changed.
- **Research:** two searches were sent and both were refused, because permission to use WebSearch was not granted in this session: "Quartzline company values" and "Quartzline Product Manager Platform APIs partner API". Nothing about Quartzline's values, interview loop or current strategy is in the pack.
- **Research tier:** L1, searches 0 of 6, fetches 0 of 2.

Target accounting:

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quartzline values | unavailable | Would have checked for a values round and built a values cheat sheet. No values round is detected, so no cheat sheet is built. |
| 2. Quartzline interview process, product management | unavailable | Would have set the loop structure and persona weights. Weights here come from the hiring-manager prior and the dossier, not from a loop. |
| 3. Quartzline strategy and recent news | unavailable | Would have moved the CO bank. No CO questions are written. |
| 4. interviewer name | n/a | No name was given, so there was no query to form. |
| 5. representative product management JD | skipped | The dossier's role_profile fixes the requirements and the JD-tagged questions. |

## Upgrade menu

- Grant WebSearch permission, then ask for the L1 sweep → Quartzline values, interview loop and recent strategy. This would add a values cheat sheet if values are detected, and would turn the CO questions from generic into grounded.
- The current posting text, if it has changed since 14 August → refreshes the fit snapshot and the JD-tagged questions. Until then the requirements are the dossier's.
- The interviewer's name → a tailored reverse question, and persona weights from their public footprint.
- The CV behind the three confirmed claims → B5 and C1 could quote more of your own sentences instead of falling to answer slots.
- Deep research at L2 → strategy brief, interviewer talks and loop reports. Capped at 6 more searches and 2 more fetches, offered once, and it needs WebSearch permission.
- If Thursday is one of several sessions → send the schedule and I'll build per-session mini-packs.
