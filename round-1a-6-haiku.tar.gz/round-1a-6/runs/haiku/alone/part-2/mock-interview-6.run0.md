This is interview prep for three rounds, which matches the mock-interview skill, so I'll load it and build the pack from there.
The skill spec is loaded. Before writing the pack I need published values and loop structure for Larkfield, so I'll load the search tool and run the two L1 targets.
Search permission was refused, so the company's values and interview-process research can't run this session. The pack will say so. I'll write it now in loop mode, one shared fit snapshot and three per-round mini-packs.
Your prep pack is saved at /var/tmp/tuesday-measure/1a6/runs/haiku/alone/part-2/rooms/case-6-denied-788b0a9e/Larkfield_engineering-manager_interview_pack.md. It covers all three rounds with shared fit-gap rows, prohibited claims, coverage, and reverse questions for each round.

Two things it could not do. Web search permission was refused, so I have no Larkfield values or interview-process research. The values cheat sheet is omitted, and Round 3's values questions rest on the recruiter's own words. The highest-ROI rehearsal is B1, the hardware-roadmap objection, which you'll likely meet in both Round 1 and Round 2.

Say the word and I'll play the hiring manager on B1 for a drill. I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.

Two questions that would change the pack:
1. Can you paste the job description? With it, the generic rows become quoted, and I can add JD-tagged questions for each stated requirement.
2. Is the role on-site, hybrid or remote, and is there any work-authorization condition?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Larkfield_engineering-manager_interview_pack.md -----
# Interview prep pack: Engineering Manager, Larkfield Systems

Three scheduled rounds, prepped together (loop mode):

- **Round 1, Tuesday, 45 min:** hiring manager, Director of Engineering (your would-be boss)
- **Round 2, the Thursday after, 60 min:** panel with two staff engineers and a product manager
- **Round 3, the following Monday, 30 min:** VP Engineering, which the recruiter describes as "values and leadership philosophy"

Interviewer names are not in your inputs, so there is no interviewer read. This is the first build, so there is no changelog.

## How to use this pack

Personas describe how each question will be asked. Types describe what it scores.

| Type | Meaning |
|---|---|
| VAL | Behavioral / values: whether past behavior shows the values the interviewer names |
| EXP | Experience deep-dive: whether what you did survives scrutiny, and how much of it was yours |
| JD | Role-driven: whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge (not covered here; see the research note in Sources) |
| CASE | Live problem from the role, reasoned aloud |

Guidance is scaffolding, not a script. Each answer should run 90 to 120 seconds. Where a row says "answer slot," it is an instruction for the interview: answer it in your own words, from what you actually did.

Section 10 (values cheat sheet) is omitted. It needs Larkfield's published values in hand, and none are. Round 3's values questions rest on the recruiter's own words instead.

---

## Shared: fit snapshot

Requirements are quoted only from your message (the role description and gap list you gave). No job description was supplied, so there are no JD-quoted requirements.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" (your message) | "9 years engineering, 3 as a team lead of 6" (your message) | medium | [grounded] | transferability | Your material shows one team of six, for three years. Words: "Three years as a team lead of six." Two squads and eleven people is a step past that quote, so the bridge stops at the quote. Answer slot: if you have coordinated work across two groups, say how; if you have not, say so and say how you would set up two squads. |
| F2 | "own delivery, hiring and growth for 11 engineers" (your message, delivery part) | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." (your message) | medium | [grounded] | transferability | Reliability delivery at team-of-six scale, with a figure. Words: "I pushed a reliability quarter through against roadmap pressure." Scale to eleven across two squads is not in the quote. Expect a probe on the 60% (C1, F3). |
| F3 | "own delivery, hiring and growth for 11 engineers" (your message, hiring part) | "I run our hiring loop for backend roles, about 40 interviews last year." (your message) | medium | [grounded] | none | The quote reaches hiring in role-relevant terms. Words: "I run our hiring loop for backend roles." Two limits to keep: the scope is backend, and the figure counts interviews, not hires. Expect probes on both (A3, C2). |
| F4 | "own delivery, hiring and growth for 11 engineers" (your message, growth part) | none given | none | [grounded] | discovery | Your material does not show growth work. The words are an answer slot: if you grew someone into a larger scope, name the person and the step in your own words; if you have not, say so and say how you would start. |
| F5 | "partner with hardware and product on roadmap" (your message, hardware part) | "I've never managed managers and never owned a hardware-adjacent roadmap." (your message) | none | [grounded] | capability | A stated gap. Words: "I've never owned a hardware-adjacent roadmap." Then how you would learn it, said as a plan and never as a past. |
| F6 | "partner with hardware and product on roadmap" (your message, product part) | "I pushed a reliability quarter through against roadmap pressure." (your message) | low | [inferred] | transferability | The quote is roadmap pressure at team scale. It does not show partnering with product on a roadmap. The derivation is this pack's reading of the quote as adjacent, not as the partnership. Answer slot: what you did with product to get that quarter agreed, if anything; if you did not work with product on it, say so. |
| F7 | "building device-management services" (your message) | none given | none | [grounded] | discovery | Your material does not show device-management or IoT service work. Your listed experience is at a payments company. Answer slot: if any of your work touched services that manage devices, name it in your words; if none did, say so. |
| F8 | "Lead two squads building device-management services" (your message, manager-of-managers gap from your gap list) | "I've never managed managers" (your message) | none | [grounded] | capability | A stated gap. Words: "I've never managed managers." The pack's own observation: the role description does not say whether the two squads have their own leads. That decides how large this gap is. |
| F9 | Location or office pattern for the role ([generic], role-family pattern, not from your inputs) | none given | none | [generic] | hard_gate | Your material does not establish whether this role is on-site, hybrid or remote. This is the one question in the message that presents this pack. |

**Sources of requirement text:** all quotes above come from your message. F9 is a role-family pattern and carries no quote.

## Shared: prohibited claims

Built locally from the fit snapshot. These are the claims a candidate reaches for under pressure. None may be coached in any answer, hold or reverse question below.

| Not coached | Basis | Honest form |
|---|---|---|
| Led two squads | Inflated form of F1 | "Three years as a team lead of six." The limit is this pack's observation: your material shows one team of six. |
| Managed managers | Stated negative, F8 | "I've never managed managers." A plain acknowledgment, with no slot. |
| Owned a hardware roadmap | Stated negative, F5 | "I've never owned a hardware-adjacent roadmap." A plain acknowledgment, with no slot. |
| Hired 40 engineers | Inflated form of F3 | "I run our hiring loop for backend roles, about 40 interviews last year." The figure counts interviews, not hires. |
| Drove the 60% on-call cut across the org | Inflated form of F2 | "My team's on-call burden dropped 60%," at team scale. |

## Shared: highest-ROI prep

The single most predictable objection to you is the hardware roadmap gap (F5). It will be asked in some form in Round 1 and again in Round 2. Rehearse **B1** until the second follow-up is automatic. It is the deepest-rehearsed question in the pack.

## Shared: coverage

| Requirement (your message) | Covered by |
|---|---|
| Lead two squads building device-management services | A2, B2, G1 |
| Own delivery | A1, C1, F1, F3, V1, K2 |
| Hiring | A3, C2, F2 |
| Growth | D1 |
| Partner with hardware and product on roadmap | A1, B1, G1, H1, K1 |
| Device-management services | A2, B3, H1 |
| Manager-of-managers (your gap list) | B2, V3 |

Every requirement has at least one question.

---

## Round 1: Hiring manager, Director of Engineering (Tuesday, 45 min)

**Persona weights.** Relationship prior for a hiring manager: Case/Strategist and Skeptic. There are no interviewer signals, so no adjustment. The loop source is your own description of this round, so no archetype fallback applies. Weights: Skeptic 3 questions (top, because the highest-ROI objection lives here), Case 3, Prober 2, JD 1. Nine questions total.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Probes the stated gaps: hardware roadmap, scale from six to eleven | High. A would-be boss has to derisk F5 and F1 before an offer | Plain acknowledgment first, then a plan. See B1 |
| Case/Strategist | A live problem from the device roadmap | High. A hiring manager buys capability on their own roadmap | Clarify, then structure, then one trade-off. See A1 to A3 |
| Data-Driven Prober | Asks how the 60% and the 40 interviews were counted | Medium. Both are headline figures on your material | Defend-the-number, in your own words. See C1 and C2 |

**A1 (CASE).** "A device-management release is late and the hardware team has a dependency slipping. Walk me through the next two weeks."
- **Type:** CASE
- **Provenance:** [generic]
- **Guidance:** Clarify what is committed and to whom before proposing anything. Name the decision owner for the dependency, what you would ask hardware and product in your first conversation, and what you would hold or cut. Say what you would tell the product lead on day one. Make no claim about your past.
- **Rationale:** A live roadmap problem from the role's stated partnership line (F5, F6). [generic] because it is a pattern for the problem, not a fact about this employer.

**A2 (CASE).** "Two squads, one new to device-management services. How do you structure your first ninety days?"
- **Type:** CASE
- **Provenance:** [generic]
- **Guidance:** Map ownership first: what each squad owns, where the handoffs are, where hardware sits. Then a learning and hiring plan for the new domain. Keep it a plan, not a claim about having done it.
- **Rationale:** F7 says the device domain is not in your material. This question tests the honest route in without any claim about your past.

**A3 (CASE).** "You run a backend hiring loop. How would you change it for roles that need hardware-facing skills?"
- **Type:** CASE, with EXP
- **Provenance:** [grounded] "I run our hiring loop for backend roles, about 40 interviews last year."
- **Guidance:** Start from the loop you ran. Say what would stay and what would change: the bar for hardware-facing skill, who from hardware sits on the panel, what a useful signal looks like. Answer slot: if you have changed a loop for a different kind of role before, say which and what you changed, in your own words; if you have not, say so and give the first change you would make.
- **Rationale:** F3 is the evidence. The premise is the quoted loop, which is backend only. This tests whether the loop transfers to the 11-engineer hiring line.

**B1 (SKEPTIC, highest-ROI).** "I don't see hardware-adjacent roadmap work in your background. How would you handle the roadmap with the hardware team?"
- **Type:** JD
- **Provenance:** [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap."
- **Guidance:** Open with your own sentence: "I've never owned a hardware-adjacent roadmap." Then your first month: who you would meet on the hardware side, what you would ask, and which decisions you would not make alone. Hold this position through two follow-ups by returning to the plan, never by adding experience. If pressed a third time, concede specifically: name one part of the hardware roadmap you do not understand yet, and how you would find out. Do not say you have partnered on a hardware roadmap.
- **Rationale:** F5 is the stated gap and the single most predictable objection for you. This is the deepest rehearsal in the pack: the follow-up levels and the concession wording are written out so you meet the second follow-up already prepared. The hold is only what the quote carries.

**B2 (SKEPTIC).** "Eleven engineers across two squads is nearly twice the team you've led. What's your honest read on the step?"
- **Type:** EXP, with JD
- **Provenance:** [grounded] "9 years engineering, 3 as a team lead of 6"
- **Guidance:** Hold the quote: "Three years as a team lead of six." State the step plainly: from six to eleven, across two squads. Say what you have done at team scale and where you expect to learn. Answer slot: if you have coordinated work across any groups, say what; if you have not, say so.
- **Rationale:** F1 is the evidence and the gap. A skeptic is testing whether you know the size of the jump. A plain read beats a bluff.

**B3 (SKEPTIC).** "Why this role, given your background has been at a payments company?"
- **Type:** JD
- **Provenance:** [grounded] "currently at a payments company."
- **Guidance:** Say what draws you to device-management services in terms of what you have done: the reliability work and the team-scale delivery. Do not imply hardware experience.
- **Rationale:** A motivation-consistency probe. F7 shows the domain is not in the material, so the answer must come from the reliability work, not from a claim about devices.

**C1 (PROBER).** "Walk me through how the 60% on-call number was counted."
- **Type:** EXP
- **Provenance:** [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure."
- **Guidance:** Defend the number, in your words. Cover how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. Answer slot: if you counted it one way, say that way; if you did not measure it the same way throughout, say so. If the quarter's decision was not yours alone, say whose it was.
- **Rationale:** A headline figure on your material, so the defend-the-number slots apply. The method is not supplied here because the material does not state one.

**C2 (PROBER).** "Of the forty interviews last year, how many did you run yourself, and how many became hires?"
- **Type:** EXP
- **Provenance:** [grounded] "I run our hiring loop for backend roles, about 40 interviews last year."
- **Guidance:** Give the figure you gave: about 40 interviews. Say what it counts. If you do not know how many became hires, say so plainly. Name the assumption about the count you would defend least.
- **Rationale:** F3 says interviews, not hires. The answer must not claim a hire count.

**D1 (JD).** "How do you grow engineers into bigger scope?"
- **Type:** JD
- **Provenance:** [generic]
- **Guidance:** Name the mechanism you would use: a scope step, a named stretch piece, a feedback rhythm, and why it fits the squads. If you have done this, name the person and the step in your own words. If you have not, say so and give your first step.
- **Rationale:** "Growth" is a stated part of the role (F4), and your material does not show it. The honest answer is the one F4 calls for.

**Reverse questions, Round 1.**
- **R1:** "What did the last person in this seat get right in the first ninety days, and what did they miss?" Why it lands: it shows you are planning to inherit a structure, not start from a blank page.
- **R2:** "Where does hardware's roadmap input enter planning today, and who decides when it conflicts with product?" Why it lands: it tests the partnership line directly and shows you have read it.
- **R3:** "How much of the eleven-engineer plan is already committed, and which roles are open now?" Why it lands: it turns the hiring line into a concrete conversation.
- **R4:** "What would make you say in six months that this was the right hire?" Why it lands: it shows you are working toward their derisking test, not around it.

---

## Round 2: Panel, two staff engineers and a product manager (Thursday, 60 min)

**Persona weights.** Relationship priors: a staff engineer is a peer (Peer Evaluator, Data-Driven Prober); the product manager is a peer with a roadmap focus (Peer Evaluator, Case). No names are given, so personas are blended across the panel. Weights: Peer 2, Prober 3, Case 2, JD 1. Eight questions total.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Peer Evaluator | Seams between teams, credit, disagreement with equals | High. Two staff engineers plus a PM price what you add to their work | Seam principles, not a claimed seam. Reciprocity in the answer. See E1, E2 |
| Data-Driven Prober | Asks for the period, the denominator, the personal share | High. Two of your three figures are on the interview list | Defend-the-number, matching your Round 1 answers. See F1 to F3 |
| Case/Strategist | Sequencing a roadmap with a hardware dependency | Medium. The PM is the roadmap owner on the panel | Clarify, then sequence with a trade-off. See G1, G2 |

**E1 (PEER).** "Where's the seam between your squads and the staff engineers' work, and what happens when you disagree?"
- **Type:** JD
- **Provenance:** [generic]
- **Guidance:** Propose seam principles rather than claiming to know this seam: who decides a boundary, how a disagreement gets settled, when you would escalate. Say what you would bring to their teams, not only what you would need. Make no claim about your past.
- **Rationale:** Peer evaluators price collegial fit. Seam principles avoid pretending to know an architecture you have not seen.

**E2 (PEER).** "How do you handle credit when delivery spans two teams?"
- **Type:** VAL
- **Provenance:** [grounded] "I pushed a reliability quarter through against roadmap pressure."
- **Guidance:** Use the quote as your example: what you pushed and against what, in your own words. Name the other people who carried work only if you know who they were. If the work was largely yours, say so.
- **Rationale:** The peer's credit probe, answered on the one delivery story your material carries (F2).

**F1 (PROBER).** "What did the 60% measure, and over what period?"
- **Type:** EXP
- **Provenance:** [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure."
- **Guidance:** Defend the number as in C1: what was counted, what it is sensitive to, the weakest assumption, and which part was yours. Answer slot: if the period or the measure differed from what the staff engineer assumes, say so and say what you did measure. Keep the answer consistent with C1.
- **Rationale:** The same figure as C1 from a different interviewer. The prober checks the period, so the answer must match Round 1.

**F2 (PROBER).** "Of those forty interviews, how many did you run yourself?"
- **Type:** EXP
- **Provenance:** [grounded] "I run our hiring loop for backend roles, about 40 interviews last year."
- **Guidance:** Give your own share: how many you ran, for which roles, and what you can and cannot say about the count. If you do not know, say so.
- **Rationale:** A different question from C2. C2 asks about hires; this asks about your personal share of the interviews.

**F3 (PROBER).** "Which assumption behind that reliability quarter's case would you defend least?"
- **Type:** EXP
- **Provenance:** [grounded] "I pushed a reliability quarter through against roadmap pressure."
- **Guidance:** Name the weakest assumption in your own words before the panel does. Answer slot: if the case had an assumption you can name, say it; if you did not write the case down in terms that could be tested, say so.
- **Rationale:** The weakest-assumption move. A named weakness reads as credibility.

**G1 (CASE, PM).** "Your squads have a hardware dependency and a reliability backlog. How would you sequence the next two quarters?"
- **Type:** CASE
- **Provenance:** [generic]
- **Guidance:** Clarify first: which dates are committed, which reliability items carry a customer or on-call cost, which hardware dependency is firm. Then sequence, with a stated trade-off and the product call you would make.
- **Rationale:** The product manager's roadmap case. [generic] because the framing is the role's pattern and the dependencies are the role's stated partnership line.

**G2 (CASE, PM).** "Product wants a device-management feature in six weeks. The squad says eight. What do you do?"
- **Type:** CASE
- **Provenance:** [generic]
- **Guidance:** Clarify scope and what six weeks buys. Separate the commitment from the estimate. Bring product a choice rather than a verdict. Make no claim about your past.
- **Rationale:** A roadmap trade-off as a live problem.

**H1 (JD, Skeptic-leaning).** "Device-management services are new ground for you. What do you know about the domain, and what would your first month look like?"
- **Type:** JD
- **Provenance:** [grounded] "I've never owned a hardware-adjacent roadmap."
- **Guidance:** Say the plain sentence first: "I've never owned a hardware-adjacent roadmap." Then your first month: what you would read, who you would meet on the hardware side, what you would ask product. Answer slot: if any part of your work touched services that manage devices, name it in your words; if none did, say so.
- **Rationale:** The panel includes a product manager, and roadmap ownership is the gap (F5, F7). Acknowledgment first, plan second.

**Reverse questions, Round 2.**
- **R5 (reciprocity, peer):** "What could a new person do in their first month that would genuinely help your team?" Why it lands: a peer's question about what you add, not what you need. It is the reciprocity question a panel of peers rewards.
- **R6 (product manager):** "How are reliability and feature trade-offs decided today when they conflict?" Why it lands: it shows you are thinking about the same trade-off the panel's roadmap depends on.

---

## Round 3: VP Engineering, values and leadership philosophy (following Monday, 30 min)

**Persona weights.** Relationship prior for a skip-level: Case/Strategist and Pressure. The recruiter's own words, "values and leadership philosophy," are a loop source that documents a values round, so Values/Behavioral is guaranteed here. Weights: Values 4, Case 2, Pressure 2. Eight questions total.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral | Open prompts on published principles; expects STAR-shaped stories | High. The recruiter named the round as values-led | Selection scaffold ending in its honest branch, since no published values are in hand. See V1 to V4 |
| Pressure | Challenges fit for scale, interrupts, asks for a concession | Medium. A VP tests composure on the step from six to eleven | Hold, then concede specifically. See S1, S2 |
| Case/Strategist | Escalation and trade-off in a live problem | Medium. Skip-level altitude | Clarify, then escalate with a recommendation. See K1, K2 |

**V1 (VAL).** "Tell me about a time you delivered an unpopular truth to leadership."
- **Type:** VAL
- **Provenance:** [grounded] "I pushed a reliability quarter through against roadmap pressure."
- **Guidance:** Open prompt. Pick the time you pushed a reliability quarter through against roadmap pressure, if it fits: the stake, the point where it was contested, what you did, and how the relationship ended, each only where you can state it. Tell it with "I" for what you did and "we" for the team. If no such time comes to mind, say so plainly, then give the nearest thing your material carries.
- **Rationale:** The question is the stem. The quote is the nearest story your material carries (F2), so it is the answer's raw material.

**V2 (VAL).** "When did you put a customer ahead of an internal metric?"
- **Type:** VAL
- **Provenance:** [generic]
- **Guidance:** Selection scaffold: pick a time when a user-facing outcome and a team metric pointed in different directions and you chose the user. If none comes to mind, say so plainly, then give the nearest thing your material carries. The reliability quarter was about on-call load, not customers, so do not stretch it to fit.
- **Rationale:** A persona stem. No published values are in hand, so the scaffold carries the honest branch.

**V3 (VAL, leadership).** "What is your philosophy for leading when you haven't managed managers?"
- **Type:** VAL
- **Provenance:** [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap."
- **Guidance:** Plain acknowledgment first: "I've never managed managers." Then your philosophy in your own terms: how you set expectations, how you give feedback, what you would do first. Do not describe managing managers.
- **Rationale:** The recruiter's "leadership philosophy" is the raising source. The premise is your own stated negative, so the acknowledgment is sourced.

**V4 (VAL).** "Tell me about a time you were wrong about a team."
- **Type:** VAL
- **Provenance:** [generic]
- **Guidance:** Selection scaffold: pick a time you misjudged a team's capacity or direction. Name what you assumed and what changed your mind. If none comes to mind, say so plainly, then give the nearest thing your material carries.
- **Rationale:** A values probe on candour. The honest branch is built in.

**K1 (CASE).** "A hardware partner and product disagree on a device-management release date. You're two layers from the decision. What do you do?"
- **Type:** CASE
- **Provenance:** [generic]
- **Guidance:** Clarify what each side is committing to and what a slip costs. Name the decision owner, and bring them the trade-off with a recommendation. Say what you would not decide alone.
- **Rationale:** A live problem on the role's partnership line, testing escalation judgment at skip-level.

**K2 (CASE).** "Two quarters in, reliability is slipping again and the roadmap is behind. What do you tell product and the hardware lead?"
- **Type:** CASE
- **Provenance:** [generic]
- **Guidance:** Structure: what is slipping and why, what each stakeholder needs, what you propose, and what you would say to each. Do not promise dates you cannot defend.
- **Rationale:** A strategy-heavy skip-level case.

**S1 (PRESSURE).** "You've led six people for three years. Why should we give you eleven?"
- **Type:** JD
- **Provenance:** [grounded] "9 years engineering, 3 as a team lead of 6"
- **Guidance:** Hold the position: "Three years as a team lead of six" is the ground you stand on. Follow-up one: restate what you have done at that scale. Follow-up two: say where the step is and what you would do first. Concede specifically if needed: "I've never managed managers," said once, plainly, and how you would build a structure for managers if the role needs one. Do not concede that you cannot lead eleven unless you believe it.
- **Rationale:** A hold-then-concede item. The hold is the quote's own scope. The concession uses your stated negative, so it has a source.

**S2 (PRESSURE).** "Sixty seconds: why should we hire you for this, now?"
- **Type:** JD
- **Provenance:** [grounded] "9 years engineering, 3 as a team lead of 6"
- **Guidance:** Sixty seconds, anchored on your quoted sentences: nine years, three as a team lead, the hiring loop you run, the reliability quarter. Add nothing that is not in those sentences.
- **Rationale:** A pressure question held to the material. The time limit is the pressure.

**Reverse questions, Round 3.**
- **R7:** "What does 'values and leadership philosophy' look like in practice here? Where has it worked, and where has it not?" Why it lands: it turns the round's name into a question about their real practice, which a VP can answer in detail.
- **R8:** "What would you want a new engineering manager to have fixed by the end of the first quarter?" Why it lands: it shows you are planning for their priorities, not for an abstract role.

---

## Sources

- **Provided documents:** your message (role description, the three rounds, your background and gap list). No job description, company values page, strategy brief or interviewer profile was supplied.
- **Searches and fetches sent:**
  - "Larkfield Systems values": refused (search permission not granted)
  - "Larkfield Systems interview process engineering manager": refused (search permission not granted)
- **Research tier:** L1, searches 2 of 6, fetches 0 of 2, user links read 0.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Larkfield Systems values | unavailable | Both calls refused. Section 10 (values cheat sheet) is omitted for this reason. Would have moved section 10 and the mapped stories in Round 3's VAL questions |
| 2. Larkfield Systems interview process, engineering manager | unavailable | Refused. Loop structure is taken from your message, which names all three rounds. Would have checked the rounds and whether any deliverable is due |
| 3. Larkfield Systems strategy / recent news | unavailable | No call sent. Would have moved the CO and differentiator questions, which are currently generic |
| 4. Interviewer name and Larkfield | n/a | No interviewer name was given, so there was no query to form |
| 5. Representative engineering manager JD | unavailable | No call sent. Would have moved the fit snapshot's requirement quotes; the role description you gave is used instead |

---

## Upgrade menu

- **The Director's name** → an interviewer read from their public footprint, persona weights for Round 1 adjusted, and a tailored reverse question
- **The full job description** → the [generic] rows become [grounded] quotes, and JD-tagged questions are added for each stated requirement
- **Larkfield's published values page, pasted** → section 10 (values cheat sheet) for Round 3, with each value mapped to a story your material carries
- **The recruiter's note on each round** → confirms whether any round has a deliverable (a take-home or presentation), and which interviewers run which round
- **A Larkfield strategy brief or a recent-news summary, pasted** → CO questions for Rounds 2 and 3 grounded in current priorities instead of generic
- **Whether the role is on-site, hybrid or remote** → resolves gate row F9
- **Web search permission, once granted** → the values, process and strategy targets can run and fill the rows above
