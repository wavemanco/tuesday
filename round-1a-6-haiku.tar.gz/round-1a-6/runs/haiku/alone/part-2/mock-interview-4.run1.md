Your prep pack is saved as `/var/tmp/tuesday-measure/1a6/runs/haiku/alone/part-2/rooms/case-4-denied-3d52644d/Quartzline_product-manager-platform-apis_interview_pack.md`. I built it for a hiring-manager round, since your note said the interview is with the hiring manager.

Web search was refused in this session, so the pack has nothing about Quartzline's values, interview loop or current strategy. It is built on your dossier and the requirement lines it carries. The dossier is 104 days old, so if the posting has changed, paste the current one and I'll regenerate the fit snapshot.

Say the word and I'll play the Skeptic on A1, the question the pack names as its highest-ROI prep: "You have never held the PM title or owned a roadmap. Why should we hire you into one?"
I can also add a `pack_feedback` section to your `tuesday-dossier.md`, recording the gaps this prep exposed. I'd leave the underwriter's sections untouched.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Quartzline_product-manager-platform-apis_interview_pack.md -----
# Interview prep pack: Product Manager, Platform APIs at Quartzline

**Round:** hiring-manager conversation, 45 minutes, Thursday. **Interviewer:** not named.
**Dossier:** `tuesday-dossier.md` (job-underwriter, decision `conditional_go`, generated 2026-08-14). That is 104 days before today (2026-11-26). If the posting or the role has changed since then, paste the current posting and the fit snapshot regenerates.

Not built in this pack: values cheat sheet (no values round detected, and web search was refused), grounding brief (deep research not run), interviewer read (no name given), graded deliverables (none declared), prep triage (prep time not stated), delivery coaching (no assessment provided).

## How to use this pack

Personas describe how a question arrives. Types describe what is being scored.

- **VAL**: behavioral and values alignment. Not used here: no values round was detected.
- **EXP**: your own experience, and whether it holds up under scrutiny.
- **JD**: a requirement or responsibility the posting states.
- **CO**: company and strategy knowledge. Not used here: no current research was available.
- **CASE**: a live problem from the role, reasoned aloud.

Guidance is scaffolding, not a script. An **answer slot** is an instruction for the interview: you answer it from your own experience, and either branch it offers is a true answer. Nothing in this pack gives you words about your past beyond the quotes in the Provenance columns.

## The fit snapshot

Requirements are the dossier's `role_profile` lines, which stand in for the posting. Evidence is quoted from the dossier's `verified_candidate_evidence`. Confidence follows the dossier where it grades a requirement; this pack grades the rest and says so.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" (dossier role_profile R1, must_have) | "Led 30+ end-to-end client integrations of the vendor's REST APIs" (dossier verified_candidate_evidence) | low | [grounded] | transferability | Your verified work is integration work, at that scope: "Led 30+ end-to-end client integrations of the vendor's REST APIs." Say the limit first: that is not a product-management role. The plain acknowledgment has its source in the dossier's `prohibited_claims` item "Having held a product manager title or role": "I haven't held a product manager title." Limit as the pack's observation: your material does not show a PM title or role. |
| F2 | "Shipped API or platform products" (dossier role_profile R2, must_have) | "Led 30+ end-to-end client integrations of the vendor's REST APIs" (dossier verified_candidate_evidence) | medium | [grounded] | transferability | The dossier does not grade R2, so this pack grades it medium. The integrations went live with clients; the quote does not reach a product of your own shipping. Limit as the pack's observation: your material shows integrations, not a shipped product. Answer slot: if you shipped a product or platform release yourself, say what it was and your part in it; if the work was integrations only, say so. |
| F3 | "Technical fluency: API docs, schemas" (dossier role_profile R3, important) | "Wrote the internal integration playbook her team uses" (dossier verified_candidate_evidence) | high | [grounded] | presentation | The playbook reaches documentation in other terms: "Wrote the internal integration playbook her team uses." Reword only that quote. Schemas are not in it. Answer slot: the posting names schemas, so expect a probe. If you worked with API schemas on an integration, say which and how; if the playbook covered process only, say so. |
| F4 | "Stakeholder management across engineering, sales, customers" (dossier role_profile R4, important) | "Ran quarterly roadmap-input sessions feeding client evidence to product" (dossier verified_candidate_evidence); "Led 30+ end-to-end client integrations of the vendor's REST APIs" (dossier verified_candidate_evidence) | medium | [grounded] | transferability | Customer and product work is in the quotes; engineering and sales are not. Bridge at scope: the integrations were with clients, and the sessions carried client evidence to product. Answer slot: if you worked with engineering or sales on those integrations, say how; if that work sat with someone else, say so. |
| F5 | "Agile delivery experience" (dossier role_profile R5, preferred) | none given | low | [grounded] | discovery | Your material does not show an agile delivery role. Clarify, not bridge: the requirement's own wording is the interviewer's probe, and the honest branch is "I'd want to confirm how this team defines agile." |
| F6 | Owning a roadmap and prioritization authority (dossier uncertain_or_weak_areas, R1 sub-claim, acknowledge_gap) | none given | none | [grounded] | capability | The dossier records the absence, so the words are its plain acknowledgment, sourced by its `prohibited_claims` items "Having owned a product roadmap" and "Having set prioritization for an engineering squad": "I haven't owned a product roadmap, and I haven't set priorities for an engineering squad." Then a ramp, as a plan, never as a past. No answer slot. |

## Persona weights

Relationship prior: hiring manager, so Case/Strategist and Skeptic lead. The posting's responsibilities (roadmap, partner discovery, two engineering squads, adoption metrics) make the live problems likely. Peer Evaluator is omitted: this is a manager round, not a peer one.

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy | Weight |
|---|---|---|---|---|
| Case/Strategist | A live partner-roadmap problem, or an adoption-metric problem | High: hiring-manager prior, and the posting's own responsibilities | Clarify, objective, segmentation, approach, metrics, risks; think aloud | 5 |
| Skeptic | The title and roadmap objection, and the squad-authority question | High: the dossier named this objection; it targets F1 and F6 | Rehearse A1 until it is boring; concede the specific gap, hold the bridge | 5 |
| Data-Driven Prober | "How was the 30-plus counted?" and "what happened to the sessions?" | Medium: the integration count is a headline figure, and the roadmap-input sessions are medium confidence | Say how it was counted; name the weakest assumption first | 3 |
| Pressure | "Sixty seconds" and "how much of it was actually you?" | Medium: the objection is one a pressure interviewer would press | Pause, restate, anchor in the quote, hold two follow-ups | 3 |
| Conversational | A casual opener, or "what are you curious about?" | Low to medium: scored in a friendly register | A 90-second arc; treat the casual question as scored | 2 |

Total: 18 questions, within the 18 to 26 range.

## Question banks

### Bank A: Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have never held the PM title or owned a roadmap. Why should we hire you into one instead of a PM with three years of the actual job?" | JD, Skeptic delivery | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs" (dossier verified_candidate_evidence); [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" (dossier verified_candidate_evidence); the plain acknowledgment is sourced by the dossier's `prohibited_claims` items "Having held a product manager title or role" and "Having owned a product roadmap" | **The highest-ROI prep in this pack.** Concede the specific gap in one sentence first: "I haven't held a product manager title, and I haven't owned a product roadmap." Then the bridge at its scope: "What I have done is lead 30+ end-to-end client integrations of the vendor's REST APIs, and run quarterly roadmap-input sessions that carried client evidence to product." Hold through two follow-ups by returning to those two quotes, adding no stage, count or decision to them. On the third, concede the authority gap: "Prioritization authority is the part I haven't done." Then the ramp, as a plan. | The dossier named this objection. It presses R1 (F1) and the roadmap capability (F6). JD because it scores the stated requirement; Skeptic because it attacks the hire's premise. |
| A2 | "The role is about shipped API products. Which of those have you shipped yourself?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs" (dossier verified_candidate_evidence) | Answer slot: if you shipped a product or platform release yourself, name it and your part in it, in your own words. If the work was client integrations, say so and describe them at the quote's scope. Hold through two follow-ups on the integrations; do not reach for "product" or "release" as a label for them. | F2 is medium and the dossier does not grade R2. This probe tests the inflated form listed in the prohibited list. |
| A3 | "Walk me through how you deliver agile work. What do you actually run?" | JD, clarify | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs" (dossier verified_candidate_evidence) | Answer slot: if you ran a sprint or delivery cadence on the integration work, say what it was and your part in it. If the work ran another way, say how, and say what you would want to confirm about how this team defines agile. Do not bridge agile from the integration quote. | F5 is low and the requirement is preferred. The posting names it, so the probe is likely. |
| A4 | "On a scope change, what do you do when engineering says no?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs" (dossier verified_candidate_evidence) | Answer slot: if you handled a scope change with engineering on an integration, say what changed, who said no and what you did. If engineering's part of that work sat with someone else, say so. | F4: engineering is not in the quotes. The posting names two engineering squads, so the probe is likely. |
| A5 | "Why this move, and why now?" | EXP | [generic] | Give your actual reason for the move in one sentence, then the link to this role's partner work. The reason must be yours and true; nothing in this pack supplies one. | A skeptic checks motivation consistency. Nothing about your past is asserted here. |

### Bank B: Case/Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A partner tells you a change to one of your endpoints is blocking their go-live. What do you do in the first week?" | CASE | [generic] | Clarify first: which partners, how many integrations are affected, what go-live means to each. Then the objective, segmentation, approach, metrics and risks. Think aloud, and challenge one premise respectfully. | The posting names partner discovery and delivery, so a live partner problem is likely. This is a case, so it asserts nothing about your past. |
| B2 | "How would you decide what counts as adoption for this platform?" | CASE | [generic] | Name the candidate definitions (for example, partners registered, live calls, integrations in production) and choose one with reasons. Name the weakest assumption in your choice before they do. If asked for the current baseline, say you would need to check how it is counted today. | The posting makes adoption metrics a responsibility. The baseline is not stated anywhere in the material, so none is supplied here. |
| B3 | "Two squad leads want opposite sequencing for next quarter's partner work. You're the PM. What happens?" | CASE | [generic] | Clarify who owns the call before you answer. Then put the trade-off on one page, get the partner evidence, name the decision owner and the escalation route. Concede in one line: "I haven't made a sequencing call between squads; here is how I would run it." | The dossier lists decision authority as unknown. This probes F6 directly, so the concession is the answer. |
| B4 | "Walk me through how you'd run discovery with a partner who wants a feature you think is wrong." | JD | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" (dossier verified_candidate_evidence) | Answer slot: if you have run a conversation like this with a client, say what they asked, what you did and what happened. If you have not, say so and describe how you would run it. The nearest thing in your material is the roadmap-input sessions, in their own words. | The posting names "run discovery with integration partners". The sessions are medium confidence, so the slot protects the answer. |
| B5 | "Which API docs and schemas would you read first on this platform, and what would you check in them?" | JD | [grounded] "Wrote the internal integration playbook her team uses" (dossier verified_candidate_evidence) | Answer as a plan: name the docs and schemas you would read first and what you would check. Answer slot: if you have worked with schemas on an integration, say which. The playbook is the nearest thing in your material; say what it covers. | F3: the posting names schemas, and the quote does not. |

### Bank C: Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "How did you count the 30-plus integrations, and which of them did you lead end to end?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs" (dossier verified_candidate_evidence) | Defend the number in your own words: say how the count was made. Name the assumption behind the figure you would defend least, before they ask. If you cannot say how it was counted, say that. Answer slot: if any of them were not led end to end by you, say which and what your part was. No counting method is supplied here. | A headline figure raises defend-the-number slots (F1, F2). |
| C2 | "What happened to the evidence you fed to product in those sessions?" | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" (dossier verified_candidate_evidence) | Answer slot: if you can name a product decision the evidence reached, say which and what you fed in. If you do not know what product did with it, say so. The question does not presuppose an outcome, and neither should your answer. | Medium confidence, and the dossier says to expect this probe. |
| C3 | "What's the adoption baseline today, and how would you know it's moving?" | JD | [generic] | If you have the baseline, state it and where it came from. If you do not, say you do not have it, and name what you would define and count first, with its weakest assumption. | The posting makes adoption tracking a responsibility. The dossier flags the baseline as unknown. |

### Bank D: Pressure (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "That integration count. How much of it was actually you?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs" (dossier verified_candidate_evidence) | Pause, restate the question, then hold the quote: "I led them end to end, scoping through go-live." Answer slot: if other people carried any stage, name who and which stage; if you led all of them, say so plainly. Do not fold on the quote to restore calm. | F1 and F2. The pressure stem puts the attribution question on the headline figure. |
| D2 | "You'd be directing two squad leads who've done this longer than you have. Why would they take direction from you?" | JD | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" (dossier verified_candidate_evidence); the plain acknowledgment is sourced by the dossier's `prohibited_claims` item "Having set prioritization for an engineering squad" | Hold on the working relationship the sessions show, then concede authority explicitly: "I haven't set priorities for an engineering squad, and I won't claim direction authority I don't have yet." Then the ramp, as a plan. | F6, under pressure. The hold is the sessions, the concession is the authority. |
| D3 | "Tell me about a time you had to hold a position with a partner or client. What did it cost you?" | EXP | [generic] selection scaffold | Pick a time you held a position with a partner or client. It needs a named stake, a moment you did not fold, and an intact relationship at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material carries: the client integrations, at their scope. | The pressure persona's open prompt, with its honest branch. Nothing about your past is asserted by the guidance. |

### Bank E: Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey to here." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs"; [grounded] "Wrote the internal integration playbook her team uses"; [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" (all dossier verified_candidate_evidence) | A 90-second arc in this order: the integrations (quote, at scope), the playbook (quote), the sessions (quote). Then the boundary in one sentence: "The part I haven't done is owning a roadmap." | A casual opener, scored on economy and on whether the arc stays inside the quotes. |
| E2 | "What's the part of this role you're most curious about?" | JD | [generic] | Name one thing the posting states, such as the two engineering squads or adoption measurement, and ask a question back from the reverse bank. Do not answer "I think you've covered everything." | A casual question about a hot topic is still scored. |

### Coverage

| Requirement | Questions | Note |
|---|---|---|
| R1: 3+ years PM experience (must_have) | A1, D2 | F1 and F6 |
| R2: Shipped API or platform products (must_have) | A2, C1 | F2 |
| R3: Technical fluency, API docs, schemas (important) | B5 | F3 |
| R4: Stakeholder management, engineering, sales, customers (important) | A4, B4 | Sales is not covered: no question asks about sales work, and the material has none to bridge |
| R5: Agile delivery (preferred) | A3 | F5 |
| Responsibility: own the roadmap | A1, B3, D2 | |
| Responsibility: run discovery with partners | B4 | |
| Responsibility: drive delivery with two squads | A4, B3, D2 | |
| Responsibility: define and track adoption metrics | B2, C3 | |

## Reverse questions

Each one comes from the dossier's `questions_for_employer` or `opportunity_risks_to_validate`.

1. "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" Why it lands: the posting asserts decision authority, and the material does not evidence it. You need to know this before you accept.
2. "How is partner API adoption measured today, and what is the current baseline?" Why it lands: the posting makes adoption tracking a responsibility and states no baseline. Asking shows you would measure from day one.
3. "What would you most want a PM who came up through integration work to learn first?" Why it lands: it names the title gap and asks them to name what they would value, which tells you where the bar is.
4. "How does the team run discovery with integration partners today, and who is in the room?" Why it lands: discovery is a stated responsibility. The answer shows whether the PM runs it alone or with the squads.
5. "What would make you say this hire was a success at six months?" Why it lands: it turns the risk into their definition of success, and it ends on expectations.

No reverse question is tied to the interviewer's path: no interviewer profile was given.

## Prohibited claims

Built from the fit snapshot and the dossier's `prohibited_claims`. Every bank cell above is written against this list.

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | Dossier `prohibited_claims` (sourced) | "I haven't held a product manager title." The bridge is F1's quote at its own scope. |
| Having owned a product roadmap | Dossier `prohibited_claims` and `acknowledge_gap` (sourced) | "I haven't owned a product roadmap." F6. |
| Having set prioritization for an engineering squad | Dossier `prohibited_claims` (sourced) | "I haven't set priorities for an engineering squad." F6. |
| Shipped an API or platform product | Inflated form of F2, built locally | F2's quote at its own scope: "Led 30+ end-to-end client integrations of the vendor's REST APIs." The limit is the pack's observation: your material shows integrations, not a shipped product. No first-person negative is written for this one. |

## Sources

- **Dossier consumed:** `tuesday-dossier.md`, dossier_version 1.1, major version 1, supported. Sections used: `handoff_to_mock_interview` (verified evidence, weak areas and strategies, likely objection, prohibited claims, employer questions, risks), `role_profile` (the posting's requirement lines), `verified_candidate_evidence`, and `decision` as context only. Not present in the dossier: `evidence_map`, `risk_register`, `evidence_state`. The fit snapshot's grading of R2 and R4 is this pack's, as stated above.
- **Searches sent:** three. All three were refused: web search permission was not granted in this session.
  - "Quartzline company values": refused
  - "Quartzline Product Manager Platform APIs interview process": refused
  - "Quartzline partner API platform strategy news": refused
- **Research tier:** L1, with searches 0 of 6 returning results (3 attempted, all refused) and fetches 0 of 2.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quartzline company values` | unavailable | Values cheat sheet. No values round was detected, so the section is dropped, and the search was refused |
| 2. `Quartzline interview process product manager` | unavailable | Loop structure. Persona weights use the hiring-manager prior instead |
| 3. `Quartzline strategy` / recent news | unavailable | Current strategy and a CO question. None written; the search was refused |
| 4. `{interviewer name} {company}` | n/a | No name was given, so there was no query to form |
| 5. representative product manager JD | skipped | The dossier's `role_profile` fixes the requirement lines, so no representative JD is needed |

## Upgrade menu

- The interviewer's name → a tailored reverse question, and persona weights from their public footprint. Needs search access, which was refused here.
- The current posting text → if the role has changed since 2026-08-14, the fit snapshot's requirement quotes regenerate from the new text.
- Search access → the values cheat sheet if the round turns out to be values-style, a current-strategy question, and the loop structure. The deep research tier (L2) is also available once, on your consent: four further targets, at most 6 further searches and 2 further fetches. It needs search access, which was refused in this session.
- The recruiter's prep email → coverage of any deliverable they pre-declared.
- Pasted sections of the integration playbook → new quoted material for F3 and B5.
