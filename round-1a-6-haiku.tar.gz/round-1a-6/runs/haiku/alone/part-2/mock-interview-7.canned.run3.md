Your prep pack is saved at `/var/tmp/tuesday-measure/1a6/runs/haiku/alone/part-2/rooms/case-7-canned-a7365f67/Saltmarsh_live-operations-producer_interview_pack.md`. I built it for a hiring-manager round, since your note didn't say who you're meeting. No web research ran, so the pack has no Saltmarsh values, loop structure or strategy in it.

# Interview prep: Live Operations Producer, Saltmarsh Games

**Interviewer:** Tobias Wrenfield, Head of Live Operations. Relationship assumed to be hiring manager (not yet confirmed).
**Format:** 60 minutes, Friday.
**Research tier:** L0, provided documents only.

## How to use this pack

Personas are how a question is asked. Types are what is being scored. Guidance is scaffolding, not a script: rehearse each answer in your own words, out loud, in 90 to 120 seconds.

- **VAL**: behavioral and values alignment
- **EXP**: deep-dive on your past work and what you actually did
- **JD**: the role's listed responsibilities and requirements
- **CASE**: a live problem from the job
- **CO**: company and strategy knowledge (not used here, because no research was run)

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | transferability | Your material shows one title's weekly drops, not live events across two titles. Bridge: "For two years I ran the weekly content-drop calendar for our main title." Answer slot: the two-title scope is the probe. If you have planned events across two titles, say how. If not, say what you would carry over and what you would check first. |
| F2 | "coordinate design, art, engineering and community teams on each update" (JD) | "Wrote the release checklist our QA team still uses." (your message) | low | [grounded] | discovery | Your material touches QA only. Nothing shows coordination across design, art, engineering or community. Answer slot: name an update where you got those teams to a shared date, and what you did. If there was none, say so and say how you would set it up. |
| F3 | "own the post-event review and the KPIs it reports" (JD) | "Presented monthly retention numbers to the studio head." (your message) | medium | [grounded] | transferability | Reporting monthly retention is adjacent to owning a post-event review. Bridge: "I presented monthly retention numbers to the studio head." Answer slot: say whether you ran a post-event review and what it reported. If the only reporting you did was the monthly presentation, say so. |
| F4 | "manage the release checklist with QA" (JD) | "Wrote the release checklist our QA team still uses." (your message) | medium | [grounded] | none | The quote reaches the requirement. Confidence is medium because it is one artifact with nothing inspected behind it, so expect a probe on how much was yours (D2). |
| F5 | "3+ years producing live-service games or apps" (JD) | "4 years as an associate producer at a puzzle-game studio" (your message) | medium | [grounded] | none | The years and the studio type reach the requirement. Bridge: "I was an associate producer for four years at a puzzle-game studio." Do not change the title. Expect a probe on whether that title was live-service. |
| F6 | "experience running a content calendar" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | none | The quote reaches the requirement. Confidence is medium because it is your own account, not an inspected calendar. |
| F7 | "comfortable with player-retention metrics" (JD) | "Presented monthly retention numbers to the studio head." (your message) | medium | [grounded] | presentation | Verified evidence exists, but the quote does not say you analysed the metrics. Bridge, rewording only the quote: "I presented monthly retention numbers to the studio head." Comfort with the metrics is not established; see C1 to C3. |
| F8 | "clear written communication" (JD) | "Wrote the release checklist our QA team still uses." (your message) | medium | [grounded] | none | One written artifact, in use by another team. Written communication to a wider audience is not shown here, beyond the monthly presentation in F3. |
| F9 | Team leadership (not named in the JD; your own flag) | "Never led a team." (your message) | none | [grounded] | capability | A stated absence, so the words are yours. Words: "I haven't led a team." The JD asks you to coordinate four teams without naming a reporting line, so expect this to be tested as leadership (A2). |
| F10 | In-app purchases (not named in the JD; your own flag) | "Never worked on a game with in-app purchases." (your message) | none | [grounded] | capability | A stated absence. Words: "I haven't worked on a game with in-app purchases." Then how you would learn it, as a plan and never as a past (A3). |

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy | Questions |
|---|---|---|---|---|
| Skeptic | Probes the gaps: one title, no team leadership, no in-app purchases | High. A hiring-manager round prior, and the gaps in your own message are where a manager probes | Say the limit in one sentence, then return to what you did | A1 to A5 (5) |
| Case / Strategist | Live problems from the role: plan a calendar, diagnose a retention drop | High. A hiring-manager prior, and the JD is written as live problems | Clarify first, then structure. Name the weakest assumption | B1 to B4 (4) |
| Data-Driven Prober | Retention and KPI numbers, checked down to their assumptions | Medium-high. The JD names retention metrics and KPIs you would own | Know how each number was counted, and say so when you don't | C1 to C3 (3) |
| Pressure | Interrupts, time-boxes, challenges motive | Medium. Common in hiring-manager rounds at this level, but not certain | Pause, restate, hold a position through two follow-ups | D1 to D3 (3) |
| Conversational | Friendly opener that is still scored | Low to medium | Prepare a 90-second arc. Treat casual questions on JD topics as scored | E1 to E2 (2) |
| Peer Evaluator | Seams with engineering, art and design teams | Low to medium. Coordination is central to the JD, but no peer round is indicated | Offer seam principles, not invented seams | P1 to P2 (2) |
| Values / Behavioral | Scenario questions about past behavior | Low. No values source and no values round were detected, so these are generic | Give an honest answer if no story exists | V1 to V2 (2) |

Weighting: no loop source was available (no interview-process research), so the hiring-manager archetype sets the weights. Total: 21 questions.

## Prohibited claims

Not coached in this pack, and why. Each entry has the honest form to use instead.

| Not coached | Basis | Honest form |
|---|---|---|
| "I ran live events for two titles" or "I owned multi-title live-ops" | Inflated form of F1 | "For two years I ran the weekly content-drop calendar for our main title." |
| "I led" or "I managed" a team | Inflated form of F9 | "I haven't led a team." |
| Any monetization, in-app purchase or revenue experience | Stated absence, F10 | "I haven't worked on a game with in-app purchases." |
| "I owned the post-event review and its KPIs" | Inflated form of F3 | "I presented monthly retention numbers to the studio head." |
| Retention moved because of your content drops | Not in the material; a causal claim | "I presented the numbers. I can't separate a drop's effect without a comparison." |
| "Producer" as your title | Title inflation; your title was associate producer | "I was an associate producer for four years." |
| Owning QA sign-off | Inflated form of F4 | "I wrote the checklist. QA uses it." |

## Question banks

Provenance comes before the guidance. Quotes are your own sentences, exactly as you wrote them.

### A. Skeptic (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've run one title's calendar. What changes when it's two?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Story-mapped on F1: the one title and the two years, in your words: "For two years I ran the weekly content-drop calendar for our main title." Answer slot: if you have planned events across two titles, say how you split the work. If not, say so, then name what you would check first: each title's release dates, QA capacity and shared engineering time. Do not describe a two-title calendar you did not run. | F1 is the evidence for the calendar requirement, and two titles is where the JD presses. JD because it scores the first line of the JD. |
| A2 | "You've never led a team. How do you coordinate design, art, engineering and community on each update without managing any of them?" | JD | [grounded] "Never led a team." | Start with the stated limit: "I haven't led a team." Then the coordination. If you got design, art, engineering or community to deliver to one date, say which update and what you did. If not, say so, and say how you would set it up: one owner per deliverable and one dated checkpoint per team. Hold through two follow-ups by returning to the limit and the plan, never by adding to the record. | F9 is the absence this question presses on, and F2 is silent on coordination, so the answer slot carries it. This is the highest-ROI rehearsal in the pack: coordinating four teams is the core of the job, and there is no leadership record. JD because it scores the stated requirement. |
| A3 | "Our revenue comes from in-app purchases. What's your experience with that?" | JD | [grounded] "Never worked on a game with in-app purchases." ; [grounded] "Presented monthly retention numbers to the studio head." | Say the limit: "I haven't worked on a game with in-app purchases." Then the closest thing you have done: "I presented monthly retention numbers to the studio head." Say what you would want to learn about purchase data alongside retention. Do not claim any monetization knowledge. | F10 is the absence. The JD does not name in-app purchases, so the premise belongs to the interviewer and the guidance does not adopt it; purchase mechanics are a common feature of mobile live-ops [generic]. |
| A4 | "Which requirement in this JD would you be weakest at on day one?" | JD | [grounded] "Never led a team." ; [grounded] "Never worked on a game with in-app purchases." | Answer in your own sentences with the two stated limits, leadership and purchases. For each, say the limit, then one plan. Stop at two. Do not add a third to seem humble. | F9 and F10 are the two stated absences. The question asks for an honest self-assessment, which these quotes can carry. |
| A5 | "Walk me through the release checklist you wrote. Who uses it, and what happens when a step fails?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Say what you wrote and who uses it, in those words. Answer slot: if a step has failed in a release, say what happened and what you changed. If none has, say you haven't seen one fail, and describe what the checklist says happens. Never describe a sign-off you did not give. | F4 is the checklist requirement. "still uses" is the only sentence about its use, so the failure question is an answer slot, not a claim. |

### B. Case / Strategist (4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Two titles, one release calendar, one QA team. Sketch next quarter's events plan. What do you need to know first?" | CASE | [generic] | Clarify before you structure: each title's goals and lifecycle stage, the QA window for each release, team capacity, and which events are already committed. Then objective, cadence and risks, including the single QA team as a bottleneck. Think aloud and challenge one premise. | A live problem from the JD's first line. It presupposes nothing about your past, so the guidance makes no claim about it. |
| B2 | "Retention on an event came in 8% below plan a week after launch. Diagnose it." | CASE | [generic] | Segment before concluding: new and returning players, who was exposed to the event, cohorts, and what else shipped that week. Name the assumption you would test first. Ask what the 8% was measured against. | The JD's post-event review and retention metrics, as a hypothetical. The figure belongs to the interviewer's scenario. |
| B3 | "How would you structure a post-event review so the KPIs it reports are the ones the team acts on?" | JD | [grounded] "Presented monthly retention numbers to the studio head." | Set the KPIs before the event, one owner for each, and the decision each one would trigger. Answer slot: if you have run a post-event review, say what it measured and what changed after. If the only review you have been in is the monthly presentation, say so, and say what you would add to it. Never describe a review you did not run. | F3 is the post-event review requirement, and the monthly presentation is the only reporting the material shows. JD because it scores the post-event line. |
| B4 | "A release is due Thursday and QA hasn't signed off. What do you do on Monday?" | CASE | [grounded] "Wrote the release checklist our QA team still uses." | Triage: find which checklist item is blocking and why. Ask the QA lead for a date, not a yes. Decide what moves and who decides. Tell the affected teams the same day. Answer slot: if a release was held for QA in your past, say what you did. If not, describe the steps. | The checklist is the one thing the material shows you own, so it grounds the QA step only. |

### C. Data-Driven Prober (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through the retention numbers you presented. How was retention defined, and which assumption would you defend least?" | EXP | [grounded] "Presented monthly retention numbers to the studio head." | Say what you presented and how often, in those words. Answer slot: name the retention definition you used, and whose it was if it was not yours. Name the weakest assumption you know of, such as the cohort window or how returning players were counted. If you don't know how a number was counted, say so. | F7 is a presentation gap, and this is where comfort with metrics gets tested. The figures are not in the material, so the answer has to be yours. |
| C2 | "Which of the retention changes you showed came from a content drop, and how do you know?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Do not claim cause. Say what you saw and what you could not separate from the drop. Answer slot: if you had a comparison between drops, say what it compared. If not, say the drops ran on a schedule and were not a test. | An attribution probe. The material links the calendar and the retention numbers only by being part of the same job. |
| C3 | "Which retention number would you trust least, and why?" | JD | [generic] | Name the metric you would question first, such as day-1, day-7 or day-30 retention, or active versus returning players, and say what it can hide. Hold to one number. | The JD requires comfort with retention metrics. This is a pattern question with no claim about you. |

### D. Pressure (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why hire four years on one puzzle title over someone who has run two live titles?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Pause and restate the question. Anchor in what you did: "For two years I ran the weekly content-drop calendar for our main title." Concede the true part: you have not run two titles. Hold through two follow-ups. Do not claim two-title work. | F1 is the scope gap at its hardest. The concession is your own limit. |
| D2 | "The checklist your QA team uses. How much of it did you actually write?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Separate what you wrote from what QA added or changed. Answer slot: if QA changed parts of it, say which. If you can't split it, say so. | An attribution probe on F4. |
| D3 | "Did the studio head act on those retention numbers, or just listen?" | EXP | [grounded] "Presented monthly retention numbers to the studio head." | Answer slot: if you know a decision followed, say what it was. If you don't know, say so and don't guess. Hold on the presentation itself. | F7 is the quote. The outcome is not in the material, so the answer is yours to give or to admit not knowing. |

### E. Conversational (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the last four years." | JD | [grounded] "4 years as an associate producer at a puzzle-game studio" ; [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | A 90-second arc: the studio and your title, then the calendar, the checklist and the retention numbers. Keep "associate producer" exactly. Make no claim beyond these sentences. | A casual opener, and still scored. The arc is built from these quotes only. |
| E2 | "What are you playing at the moment, and what's its event cadence like?" | JD | [generic] | Name a title you have actually played, and one thing its event cadence does well or badly. If you don't play current mobile titles, say so and name the last one you did play. Do not invent a title. | A casual question on a JD topic, so it is scored. No claim about your past. |

### P. Peer Evaluator (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Our engineering and art sit beside yours on every update. Where's the seam, and what happens when we disagree?" | JD | [grounded] "Wrote the release checklist our QA team still uses." | Propose seam principles: who decides scope, who decides the date, and how a disagreement escalates. Answer slot: if you disagreed with a team you worked beside, tell that. If not, say how you would want to be told and how you would raise it. Offer what your calendar gives their teams. | The checklist is the one cross-team artifact the material shows. The rest of a peer seam is generic, so the answer slot carries it. |
| P2 | "When an event spans several teams and goes well, who gets the credit?" | JD | [generic] | Name the teams and roles, not yourself as the reason. Answer slot: a case where credit was shared, in your own words. If there is none, say how you would handle it. | A collegial credit probe. No claim about your past. |

### V. Values / Behavioral (2)

No Saltmarsh values were available, so these are generic behavioral questions. No values cheat sheet is included.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V1 | "Tell me about a time you delivered bad news to leadership." | VAL | [grounded] "Presented monthly retention numbers to the studio head." | Use a STAR shape. If the monthly presentation carried bad news, tell that. Answer slot: if no presentation carried bad news, say so and choose another time, in your own words. Do not supply the ending. | A behavioral probe. There are no published values to map to. |
| V2 | "When did you put a player's experience ahead of an internal metric?" | VAL | [generic] | Answer slot: if you have a clear case, tell it in STAR shape, with the trade you made. If you don't, say so and say how you would decide it. Do not build a case. | No values source. No claim about your past. |

## Reverse questions

Ask these at the end. Each one has a reason it lands.

1. **"What does a good post-event review look like here, and who writes it?"** It shows you know the review is a deliverable, and it tests whether the role owns it or shares it.
2. **"Which two titles is this for, and at what stage is each?"** It tests the scope directly, and it lets you hear what the two titles need before you answer A1.
3. **"Does this role manage anyone directly, or coordinate across teams?"** It settles the leadership question (F9) before the interview ends, rather than leaving it to the panel's guess.
4. **"How is the release checklist split between QA and production today?"** It shows you know QA owns a stake in the release, and it checks whether F4 is a shared or a solo job.
5. **"Which KPIs does the studio head expect this role to report, and how often?"** It connects to your monthly presentation and tells you what continuity looks like.
6. **"What would make you say the first 90 days went well?"** It gets the expectations in his own words, and it shows you plan for outcomes, not just for tasks.

No reverse question is tied to Tobias's own career path, because no public profile was researched.

## Sources

- **Provided documents:** the job description and your background, both in your message. Nothing else.
- **Searches and fetches:** none run. The research tier was L0.
- **Saltmarsh values:** not provided and not researched. Nothing has been invented, and the values sections are omitted.
- **Target accounting**

| Research tier | L0, provided documents only |
|---|---|
| 1. Saltmarsh values | skipped |
| 2. Interview process for this role family | skipped |
| 3. Saltmarsh strategy and recent news | skipped |
| 4. Tobias Wrenfield, public footprint | skipped |
| 5. Representative JD | n/a, JD supplied |

Research consent was not asked. The round-type question took its place, so the deep research offer sits in the upgrade menu.

## Upgrade menu

- **Round type and relationship** (answer the question below) → persona weights and reverse questions recomputed. Currently assumed: hiring manager.
- **Research at L1** (say yes and I'll run it: at most 6 searches and 2 page fetches) → Saltmarsh's published values by name, the interview loop structure, recent strategy, and a values cheat sheet.
- **Tobias Wrenfield's public profile** (name only so far) → an interviewer read, and a reverse question tied to his own path.
- **Recruiter's prep email** → any pre-declared test or deliverable, and a section for it.
- **A redacted copy of the content-drop calendar or the release checklist** → F4 and F6 could move from medium to high, because there is an inspectable artifact behind them.
- **Your retention presentation, or the definitions you used in it** → C1 to C3 get the metric definition you actually used, in place of a guess.
- **A two-title plan, if you ever made one** → F1 and A1 get a real answer in place of the answer slot.
- **A tuesday-dossier.md** → the evidence grading and the most likely objection rehearsed from evidence, not inference.

**Drill offer:** I can play the Skeptic on A2, the highest-ROI rehearsal in the pack, and give feedback against its guidance.

**Dossier offer:** I can also save a tuesday-dossier.md recording the gaps this prep exposed, for later sessions.

**Word offer:** If you want this as a Word document, say so and I'll convert it.

Is Tobias the person you'd report to, or someone on the panel who sits beside you? The answer reweights every bank.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Saltmarsh_live-operations-producer_interview_pack.md -----
# Interview prep: Live Operations Producer, Saltmarsh Games

**Interviewer:** Tobias Wrenfield, Head of Live Operations. Relationship assumed to be hiring manager (not yet confirmed).
**Format:** 60 minutes, Friday.
**Research tier:** L0, provided documents only. No web research was run, so this pack has no Saltmarsh values, loop structure or strategy in it. See Sources.

## How to use this pack

Personas are how a question is asked. Types are what is being scored. Guidance is scaffolding, not a script: rehearse each answer in your own words, out loud, in 90 to 120 seconds.

Type key:
- **VAL**: behavioral and values alignment
- **EXP**: deep-dive on your past work and what you actually did
- **JD**: the role's listed responsibilities and requirements
- **CASE**: a live problem from the job
- **CO**: company and strategy knowledge (not used here, because no research was run)

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | transferability | Your material shows one title's weekly drops, not live events across two titles. Bridge: "For two years I ran the weekly content-drop calendar for our main title." Answer slot: the two-title scope is the probe. If you have planned events across two titles, say how. If not, say what you would carry over and what you would check first. |
| F2 | "coordinate design, art, engineering and community teams on each update" (JD) | "Wrote the release checklist our QA team still uses." (your message) | low | [grounded] | discovery | Your material touches QA only. Nothing shows coordination across design, art, engineering or community. Answer slot: name an update where you got those teams to a shared date, and what you did. If there was none, say so and say how you would set it up. |
| F3 | "own the post-event review and the KPIs it reports" (JD) | "Presented monthly retention numbers to the studio head." (your message) | medium | [grounded] | transferability | Reporting monthly retention is adjacent to owning a post-event review. Bridge: "I presented monthly retention numbers to the studio head." Answer slot: say whether you ran a post-event review and what it reported. If the only reporting you did was the monthly presentation, say so. |
| F4 | "manage the release checklist with QA" (JD) | "Wrote the release checklist our QA team still uses." (your message) | medium | [grounded] | none | The quote reaches the requirement. Confidence is medium because it is one artifact with nothing inspected behind it, so expect a probe on how much was yours (D2). |
| F5 | "3+ years producing live-service games or apps" (JD) | "4 years as an associate producer at a puzzle-game studio" (your message) | medium | [grounded] | none | The years and the studio type reach the requirement. Bridge: "I was an associate producer for four years at a puzzle-game studio." Do not change the title. Expect a probe on whether that title was live-service. |
| F6 | "experience running a content calendar" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | none | The quote reaches the requirement. Confidence is medium because it is your own account, not an inspected calendar. |
| F7 | "comfortable with player-retention metrics" (JD) | "Presented monthly retention numbers to the studio head." (your message) | medium | [grounded] | presentation | Verified evidence exists, but the quote does not say you analysed the metrics. Bridge, rewording only the quote: "I presented monthly retention numbers to the studio head." Comfort with the metrics is not established; see C1 to C3. |
| F8 | "clear written communication" (JD) | "Wrote the release checklist our QA team still uses." (your message) | medium | [grounded] | none | One written artifact, in use by another team. Written communication to a wider audience is not shown here, beyond the monthly presentation in F3. |
| F9 | Team leadership (not named in the JD; your own flag) | "Never led a team." (your message) | none | [grounded] | capability | A stated absence, so the words are yours. Words: "I haven't led a team." The JD asks you to coordinate four teams without naming a reporting line, so expect this to be tested as leadership (A2). |
| F10 | In-app purchases (not named in the JD; your own flag) | "Never worked on a game with in-app purchases." (your message) | none | [grounded] | capability | A stated absence. Words: "I haven't worked on a game with in-app purchases." Then how you would learn it, as a plan and never as a past (A3). |

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy | Questions |
|---|---|---|---|---|
| Skeptic | Probes the gaps: one title, no team leadership, no in-app purchases | High. A hiring-manager round prior, and the gaps in your own message are where a manager probes | Say the limit in one sentence, then return to what you did | A1 to A5 (5) |
| Case / Strategist | Live problems from the role: plan a calendar, diagnose a retention drop | High. A hiring-manager prior, and the JD is written as live problems | Clarify first, then structure. Name the weakest assumption | B1 to B4 (4) |
| Data-Driven Prober | Retention and KPI numbers, checked down to their assumptions | Medium-high. The JD names retention metrics and KPIs you would own | Know how each number was counted, and say so when you don't | C1 to C3 (3) |
| Pressure | Interrupts, time-boxes, challenges motive | Medium. Common in hiring-manager rounds at this level, but not certain | Pause, restate, hold a position through two follow-ups | D1 to D3 (3) |
| Conversational | Friendly opener that is still scored | Low to medium | Prepare a 90-second arc. Treat casual questions on JD topics as scored | E1 to E2 (2) |
| Peer Evaluator | Seams with engineering, art and design teams | Low to medium. Coordination is central to the JD, but no peer round is indicated | Offer seam principles, not invented seams | P1 to P2 (2) |
| Values / Behavioral | Scenario questions about past behavior | Low. No values source and no values round were detected, so these are generic | Give an honest answer if no story exists | V1 to V2 (2) |

Weighting: no loop source was available (no interview-process research), so the hiring-manager archetype sets the weights. Total: 21 questions.

## Prohibited claims

Not coached in this pack, and why. Each entry has the honest form to use instead.

| Not coached | Basis | Honest form |
|---|---|---|
| "I ran live events for two titles" or "I owned multi-title live-ops" | Inflated form of F1 | "For two years I ran the weekly content-drop calendar for our main title." |
| "I led" or "I managed" a team | Inflated form of F9 | "I haven't led a team." |
| Any monetization, in-app purchase or revenue experience | Stated absence, F10 | "I haven't worked on a game with in-app purchases." |
| "I owned the post-event review and its KPIs" | Inflated form of F3 | "I presented monthly retention numbers to the studio head." |
| Retention moved because of your content drops | Not in the material; a causal claim | "I presented the numbers. I can't separate a drop's effect without a comparison." |
| "Producer" as your title | Title inflation; your title was associate producer | "I was an associate producer for four years." |
| Owning QA sign-off | Inflated form of F4 | "I wrote the checklist. QA uses it." |

## Question banks

Provenance comes before the guidance. Quotes are your own sentences, exactly as you wrote them.

### A. Skeptic (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've run one title's calendar. What changes when it's two?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Story-mapped on F1: the one title and the two years, in your words: "For two years I ran the weekly content-drop calendar for our main title." Answer slot: if you have planned events across two titles, say how you split the work. If not, say so, then name what you would check first: each title's release dates, QA capacity and shared engineering time. Do not describe a two-title calendar you did not run. | F1 is the evidence for the calendar requirement, and two titles is where the JD presses. JD because it scores the first line of the JD. |
| A2 | "You've never led a team. How do you coordinate design, art, engineering and community on each update without managing any of them?" | JD | [grounded] "Never led a team." | Start with the stated limit: "I haven't led a team." Then the coordination. If you got design, art, engineering or community to deliver to one date, say which update and what you did. If not, say so, and say how you would set it up: one owner per deliverable and one dated checkpoint per team. Hold through two follow-ups by returning to the limit and the plan, never by adding to the record. | F9 is the absence this question presses on, and F2 is silent on coordination, so the answer slot carries it. This is the highest-ROI rehearsal in the pack: coordinating four teams is the core of the job, and there is no leadership record. JD because it scores the stated requirement. |
| A3 | "Our revenue comes from in-app purchases. What's your experience with that?" | JD | [grounded] "Never worked on a game with in-app purchases." ; [grounded] "Presented monthly retention numbers to the studio head." | Say the limit: "I haven't worked on a game with in-app purchases." Then the closest thing you have done: "I presented monthly retention numbers to the studio head." Say what you would want to learn about purchase data alongside retention. Do not claim any monetization knowledge. | F10 is the absence. The JD does not name in-app purchases, so the premise belongs to the interviewer and the guidance does not adopt it; purchase mechanics are a common feature of mobile live-ops [generic]. |
| A4 | "Which requirement in this JD would you be weakest at on day one?" | JD | [grounded] "Never led a team." ; [grounded] "Never worked on a game with in-app purchases." | Answer in your own sentences with the two stated limits, leadership and purchases. For each, say the limit, then one plan. Stop at two. Do not add a third to seem humble. | F9 and F10 are the two stated absences. The question asks for an honest self-assessment, which these quotes can carry. |
| A5 | "Walk me through the release checklist you wrote. Who uses it, and what happens when a step fails?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Say what you wrote and who uses it, in those words. Answer slot: if a step has failed in a release, say what happened and what you changed. If none has, say you haven't seen one fail, and describe what the checklist says happens. Never describe a sign-off you did not give. | F4 is the checklist requirement. "still uses" is the only sentence about its use, so the failure question is an answer slot, not a claim. |

### B. Case / Strategist (4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Two titles, one release calendar, one QA team. Sketch next quarter's events plan. What do you need to know first?" | CASE | [generic] | Clarify before you structure: each title's goals and lifecycle stage, the QA window for each release, team capacity, and which events are already committed. Then objective, cadence and risks, including the single QA team as a bottleneck. Think aloud and challenge one premise. | A live problem from the JD's first line. It presupposes nothing about your past, so the guidance makes no claim about it. |
| B2 | "Retention on an event came in 8% below plan a week after launch. Diagnose it." | CASE | [generic] | Segment before concluding: new and returning players, who was exposed to the event, cohorts, and what else shipped that week. Name the assumption you would test first. Ask what the 8% was measured against. | The JD's post-event review and retention metrics, as a hypothetical. The figure belongs to the interviewer's scenario. |
| B3 | "How would you structure a post-event review so the KPIs it reports are the ones the team acts on?" | JD | [grounded] "Presented monthly retention numbers to the studio head." | Set the KPIs before the event, one owner for each, and the decision each one would trigger. Answer slot: if you have run a post-event review, say what it measured and what changed after. If the only review you have been in is the monthly presentation, say so, and say what you would add to it. Never describe a review you did not run. | F3 is the post-event review requirement, and the monthly presentation is the only reporting the material shows. JD because it scores the post-event line. |
| B4 | "A release is due Thursday and QA hasn't signed off. What do you do on Monday?" | CASE | [grounded] "Wrote the release checklist our QA team still uses." | Triage: find which checklist item is blocking and why. Ask the QA lead for a date, not a yes. Decide what moves and who decides. Tell the affected teams the same day. Answer slot: if a release was held for QA in your past, say what you did. If not, describe the steps. | The checklist is the one thing the material shows you own, so it grounds the QA step only. |

### C. Data-Driven Prober (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through the retention numbers you presented. How was retention defined, and which assumption would you defend least?" | EXP | [grounded] "Presented monthly retention numbers to the studio head." | Say what you presented and how often, in those words. Answer slot: name the retention definition you used, and whose it was if it was not yours. Name the weakest assumption you know of, such as the cohort window or how returning players were counted. If you don't know how a number was counted, say so. | F7 is a presentation gap, and this is where comfort with metrics gets tested. The figures are not in the material, so the answer has to be yours. |
| C2 | "Which of the retention changes you showed came from a content drop, and how do you know?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Do not claim cause. Say what you saw and what you could not separate from the drop. Answer slot: if you had a comparison between drops, say what it compared. If not, say the drops ran on a schedule and were not a test. | An attribution probe. The material links the calendar and the retention numbers only by being part of the same job. |
| C3 | "Which retention number would you trust least, and why?" | JD | [generic] | Name the metric you would question first, such as day-1, day-7 or day-30 retention, or active versus returning players, and say what it can hide. Hold to one number. | The JD requires comfort with retention metrics. This is a pattern question with no claim about you. |

### D. Pressure (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why hire four years on one puzzle title over someone who has run two live titles?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Pause and restate the question. Anchor in what you did: "For two years I ran the weekly content-drop calendar for our main title." Concede the true part: you have not run two titles. Hold through two follow-ups. Do not claim two-title work. | F1 is the scope gap at its hardest. The concession is your own limit. |
| D2 | "The checklist your QA team uses. How much of it did you actually write?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Separate what you wrote from what QA added or changed. Answer slot: if QA changed parts of it, say which. If you can't split it, say so. | An attribution probe on F4. |
| D3 | "Did the studio head act on those retention numbers, or just listen?" | EXP | [grounded] "Presented monthly retention numbers to the studio head." | Answer slot: if you know a decision followed, say what it was. If you don't know, say so and don't guess. Hold on the presentation itself. | F7 is the quote. The outcome is not in the material, so the answer is yours to give or to admit not knowing. |

### E. Conversational (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the last four years." | JD | [grounded] "4 years as an associate producer at a puzzle-game studio" ; [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | A 90-second arc: the studio and your title, then the calendar, the checklist and the retention numbers. Keep "associate producer" exactly. Make no claim beyond these sentences. | A casual opener, and still scored. The arc is built from these quotes only. |
| E2 | "What are you playing at the moment, and what's its event cadence like?" | JD | [generic] | Name a title you have actually played, and one thing its event cadence does well or badly. If you don't play current mobile titles, say so and name the last one you did play. Do not invent a title. | A casual question on a JD topic, so it is scored. No claim about your past. |

### P. Peer Evaluator (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Our engineering and art sit beside yours on every update. Where's the seam, and what happens when we disagree?" | JD | [grounded] "Wrote the release checklist our QA team still uses." | Propose seam principles: who decides scope, who decides the date, and how a disagreement escalates. Answer slot: if you disagreed with a team you worked beside, tell that. If not, say how you would want to be told and how you would raise it. Offer what your calendar gives their teams. | The checklist is the one cross-team artifact the material shows. The rest of a peer seam is generic, so the answer slot carries it. |
| P2 | "When an event spans several teams and goes well, who gets the credit?" | JD | [generic] | Name the teams and roles, not yourself as the reason. Answer slot: a case where credit was shared, in your own words. If there is none, say how you would handle it. | A collegial credit probe. No claim about your past. |

### V. Values / Behavioral (2)

No Saltmarsh values were available, so these are generic behavioral questions. No values cheat sheet is included.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V1 | "Tell me about a time you delivered bad news to leadership." | VAL | [grounded] "Presented monthly retention numbers to the studio head." | Use a STAR shape. If the monthly presentation carried bad news, tell that. Answer slot: if no presentation carried bad news, say so and choose another time, in your own words. Do not supply the ending. | A behavioral probe. There are no published values to map to. |
| V2 | "When did you put a player's experience ahead of an internal metric?" | VAL | [generic] | Answer slot: if you have a clear case, tell it in STAR shape, with the trade you made. If you don't, say so and say how you would decide it. Do not build a case. | No values source. No claim about your past. |

## Reverse questions

Ask these at the end. Each one has a reason it lands.

1. **"What does a good post-event review look like here, and who writes it?"** It shows you know the review is a deliverable, and it tests whether the role owns it or shares it.
2. **"Which two titles is this for, and at what stage is each?"** It tests the scope directly, and it lets you hear what the two titles need before you answer A1.
3. **"Does this role manage anyone directly, or coordinate across teams?"** It settles the leadership question (F9) before the interview ends, rather than leaving it to the panel's guess.
4. **"How is the release checklist split between QA and production today?"** It shows you know QA owns a stake in the release, and it checks whether F4 is a shared or a solo job.
5. **"Which KPIs does the studio head expect this role to report, and how often?"** It connects to your monthly presentation and tells you what continuity looks like.
6. **"What would make you say the first 90 days went well?"** It gets the expectations in his own words, and it shows you plan for outcomes, not just for tasks.

No reverse question is tied to Tobias's own career path, because no public profile was researched.

## Sources

- **Provided documents:** the job description and your background, both in your message. Nothing else.
- **Searches and fetches:** none run. The research tier was L0.
- **Saltmarsh values:** not provided and not researched. Nothing has been invented, and the values sections are omitted.
- **Target accounting**

| Research tier | L0, provided documents only |
|---|---|
| 1. Saltmarsh values | skipped |
| 2. Interview process for this role family | skipped |
| 3. Saltmarsh strategy and recent news | skipped |
| 4. Tobias Wrenfield, public footprint | skipped |
| 5. Representative JD | n/a, JD supplied |

Research consent was not asked. The round-type question took its place, so the deep research offer sits in the upgrade menu.

## Upgrade menu

- **Round type and relationship** (answer the question below) → persona weights and reverse questions recomputed. Currently assumed: hiring manager.
- **Research at L1** (say yes and I'll run it: at most 6 searches and 2 page fetches) → Saltmarsh's published values by name, the interview loop structure, recent strategy, and a values cheat sheet.
- **Tobias Wrenfield's public profile** (name only so far) → an interviewer read, and a reverse question tied to his own path.
- **Recruiter's prep email** → any pre-declared test or deliverable, and a section for it.
- **A redacted copy of the content-drop calendar or the release checklist** → F4 and F6 could move from medium to high, because there is an inspectable artifact behind them.
- **Your retention presentation, or the definitions you used in it** → C1 to C3 get the metric definition you actually used, in place of a guess.
- **A two-title plan, if you ever made one** → F1 and A1 get a real answer in place of the answer slot.
- **A tuesday-dossier.md** → the evidence grading and the most likely objection rehearsed from evidence, not inference.
