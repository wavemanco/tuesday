Your prep pack is saved as `/var/tmp/tuesday-measure/1a6/runs/haiku/alone/part-2/rooms/case-2-denied-ba6bfe6a/atlas-freight_operations-manager_interview_pack.md`. I built it for a hiring-manager round, since your note didn't say who you're meeting. Web search was refused in this session, so the pack has no Atlas Freight values, interview-loop or strategy content. It rests only on your JD and your background.

The pack's central finding is that the scale gap is the objection to rehearse most. Your material shows three supervisors, and the role asks for twelve across four sites. That's question B2, and it's the highest-return prep in the pack. The Power BI gap, which you stated yourself, is the second one to have a plain answer ready for.

I can also play the Skeptic on B2 in a live drill. I can save a `tuesday-dossier.md` that records the gaps this prep exposed, for you to carry into later sessions. If you want the pack as a Word document, say so and I'll convert it.

Is the person you're meeting your future manager, or a peer? And is it one session or several? The answer reweights every question bank.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: atlas-freight_operations-manager_interview_pack.md -----
# Operations Manager, Atlas Freight: interview prep pack

Role: Operations Manager. Company: Atlas Freight (regional logistics, 800 employees). Interviewer: not named. Round: assumed to be a hiring-manager round, since your note didn't say who you're meeting. First version, so there is no changelog.

Web search was refused in this session. Company values, interview-loop structure and current strategy are therefore absent from this pack; the pack is built only from your JD and your background. The research accounting is in Sources.

## How to use this pack

- **Personas** describe how a question is asked (its register). **Types** describe what is being scored.
- **Guidance is scaffolding, not a script.** Say it in your own words, and only what you actually did.
- **Type key:** VAL = behavioral/values alignment (none in this pack, since no values round was detected); EXP = work-experience deep-dive; JD = the role's stated requirements; CO = company and strategy knowledge (generic here, because research did not run); CASE = live problem.
- **Labels:** [grounded] traces to your message or CV; [inferred] is derived from a typical role or a reasonable extension of a grounded fact; [generic] is a role-family pattern with no fact about Atlas Freight.
- **"Your message"** means the background text you sent me.
- **Sections left out, with reasons:** prep triage (no prep time given), grounding brief (no research ran), values cheat sheet (no values-style round detected), reading the interviewer (no profile), graded deliverables (none declared), delivery coaching (no assessment provided).

## Fit snapshot

Each requirement from the JD, set against your own words. Gap types follow the evidence cell, not the writer's sense of the row.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" (JD) | "7 years in warehouse and distribution ops" (your message); "ran the site's peak-season surge plan two years running" (your message) | medium | [grounded] | transferability | Your material names one site, and the peak plan was run at that site. The JD asks for daily operations across four sites at a terminal, which is adjacent work, not the same. Words you can use: "I've run the site's peak-season surge plan two years running." Answer slot: say which parts of the site's daily operations you set yourself and how, in your own words; if you did not set the daily rhythm, say so plainly. |
| F2 | "drive on-time performance and cost-per-shipment down" (JD) | "cut mis-pick rate 40% by redesigning the pick path" (your message) | medium | [grounded] | transferability | The quote is a mis-pick reduction, not on-time performance or cost per shipment, and your material gives no figure for either. Words: "The mis-pick rate fell 40% by redesigning the pick path." Answer slot: if you have a figure for on-time or cost per shipment, say which and how it was counted; if not, say so plainly and name the one you would take first. |
| F3 | "lead a team of 12 supervisors" (JD) | "currently a senior shift manager over 3 supervisors" (your message) | medium | [grounded] | transferability | This is a scale gap: three supervisors now, twelve in the role. Words: "currently a senior shift manager over 3 supervisors." Answer slot: say how you would structure a span of twelve across four sites, and which of your current work carries over, in your own words. |
| F4 | "5+ years operations leadership required" (JD) | "7 years in warehouse and distribution ops" (your message); "currently a senior shift manager over 3 supervisors" (your message) | medium | [grounded] | presentation | Your quotes reach the requirement in other terms: seven years in operations, and leadership over three supervisors. Your material does not count leadership years, so the count is yours to give. Words: "I have 7 years in warehouse and distribution ops, and I'm currently a senior shift manager over 3 supervisors." Answer slot: state the leadership years you can stand behind from your own record, and say plainly if they are fewer than the role asks. |
| F5 | "build reporting in Excel/Power BI" (JD), Excel part | "solid Excel" (your message) | medium | [grounded] | presentation | Your quote reaches Excel as a tool, not reporting built in it. Words: "My Excel is solid." Answer slot: name one report you built in Excel and who used it; if you have not built one others used, say so plainly. |
| F6 | "build reporting in Excel/Power BI" (JD), Power BI part | "never used Power BI" (your message) | none | [grounded] | capability | A gap you stated, which the pack cannot close with wording. Words: "I haven't used Power BI." Then how you would learn it, as a plan for the first month, never as a past. |
| F7 | "Lean/Six Sigma a plus" (JD) | "green belt certified" (your message) | medium | [grounded] | none | No gap: the quote already reaches the requirement. The certification has no project behind it in your material, so expect a probe on what you applied it to. Lead with "Green Belt certified." A certificate or project summary would move this to high. |

Gate check: no requirement in the JD is a legal or credential gate (location, schedule, pay or travel are not stated), so no hard_gate row appears.

## Persona table and weights

Relationship prior for a hiring-manager round is Case/Strategist plus Skeptic (personas.md). No interviewer profile exists, and no loop source was found, so the weights follow the round-type prior only, and the loop is unknown.

| Persona | Questions | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|---|
| Case/Strategist | 5 (A1 to A5) | Live operating problems from the JD: on-time, cost per shipment, a new four-site remit, peak staffing | High. The prior says a hiring manager is buying capability and running live problems on the actual roadmap; the JD's four outcomes are case-shaped. | Clarify, then structure, then name the metric you would watch; think aloud. |
| Skeptic | 4 (B1 to B4) | The span gap (F3), the leadership-years gap (F4), the Power BI gap (F6) | High. The prior puts Skeptic beside Case, and these three gaps are where your material is thinnest. | Name the gap before they do, quote it in your own words, then give a plan. Do not bluff a skill you don't have. |
| Data-Driven Prober | 3 (C1 to C3) | Defend-the-number on the 40% figure; the Excel report; on-time and cost figures | Medium. No interviewer signal. The 40% is the one headline figure in your material, and a figure raises the defend-the-number slots. | Name the weakest assumption behind each figure first; say plainly what you don't know about how it was counted. |
| Pressure / Stress | 3 (D1 to D3) | Time-boxed "why you", challenges to the 40% credit, the peak plan | Medium. A step up to ops leadership invites a composure check even though the prior is low. | Pause, restate the question, hold through two follow-ups, then concede only the specific point that is uncertain. |
| Conversational | 2 (E1, E2) | Biography opener; motivation asked casually | Low. Recruiter-style warmth appears even in hiring-manager rounds, and casual questions are still scored. | A 90-second arc built only from your own sentences. |
| Peer Evaluator | 2 (F1, F2) | Seams with planning or customer service; credit for the pick-path result | Low. Peers will be in the org, but the prior puts them last for a hiring manager. | Reciprocity framing; propose seam principles rather than facts you don't know. |

Total: 19 questions. Depth follows weight (top 4 to 5, middle 3, low 2).

## Requirement coverage

| JD requirement | Questions that cover it |
|---|---|
| Own daily terminal operations across 4 sites | A2 (JD), B2 (JD) |
| Drive on-time performance and cost-per-shipment down | A1 and A3 (CASE), C1 (EXP), C3 (JD) |
| Lead a team of 12 supervisors | B2 (JD) |
| Build reporting in Excel/Power BI | C2 (JD), B1 (JD) |
| 5+ years operations leadership required | B3 (JD) |
| Lean/Six Sigma a plus | A4 (JD) |

No requirement is left uncovered.

## Question banks

Ordered by persona weight. Guidance is spoken in about 90 to 120 seconds.

### A. Case/Strategist (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "On-time performance at one of your sites has slipped for three weeks. Walk me through how you'd find out why." | CASE | [generic] | Clarify what on-time is measured against and over what window. Segment by shift, lane or dock before proposing anything. State one hypothesis early and the data that would rule it out. Name the first two actions and the metric you would watch to know they worked. | A live problem from the on-time requirement in F2. It is a decision, not a record, so it needs no claim about your past. |
| A2 | "You're taking over four sites. What would you need to see in the first 30 days before changing anything?" | JD | [generic] | Ask for the daily scorecard by site, staffing by shift, and the on-time and cost-per-shipment trend. Separate what is broken from what is merely different. Say what you would leave alone for now. | The JD's four-site daily-operations line, asked as judgment. Typed JD because it scores the stated scope. It presupposes no event in your past. |
| A3 | "Cost per shipment is up at one site while volume is flat. Sketch your first two weeks." | CASE | [generic] | Clarify what sits inside cost per shipment (labour, overtime, carrier charges) and whether volume is truly flat. Segment by cost line before blaming headcount. Name the one metric you would check first. | The second route into the cost requirement in F2. Live problem; asks no past. |
| A4 | "Lean and Six Sigma are a plus in this role. How would you use one of them on an on-time problem?" | JD | [grounded] "green belt certified" (your message) | Name the method and its first step: define the problem and measure it before any fix. Answer slot: if you have applied the Green Belt to a project, say what it was and what changed; if the certification is the only Lean or Six Sigma work you have done, say so plainly and say how you would apply it to on-time. | F7 is the evidence. The question asks about use, which the quote does not carry, so the honest branch is written in. |
| A5 | "Peak season starts in six weeks and two sites are short on people. What do you do this week?" | CASE | [grounded] "ran the site's peak-season surge plan two years running" (your message) | Clarify the staffing gap and the volume forecast. Separate what you can move this week (overtime, cross-training, pick-path changes) from what needs approval. Name the risk you would escalate. If you draw on the peak plan you ran, describe only the parts that were yours to set; if you did not set a part, say so. | Your peak-season quote is the nearest thing in your material to a surge decision. The question itself is live, so the quote is a reference, not a claim. |

### B. Skeptic (4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "never used Power BI" (your message); "currently a senior shift manager over 3 supervisors" (your message) | Name the Power BI gap before they do: "I haven't used Power BI." Then how you would close it in the first month, as a plan. Keep to one or two honest gaps; a list of weaknesses reads as a bluff. | F6 and F3 are the gaps this question is aimed at. Rehearsing the plain acknowledgment makes the honest answer quick. |
| B2 | "I don't see a team of 12 supervisors in your background. How would you lead one across four sites?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" (your message) | Hold the quote: name the three supervisors you lead now, in those words. Answer slot: how you would structure a span of twelve across four sites, and which of your current work carries over, in your own words. Hold through two follow-ups by returning to the structure, not to a larger team you have not led. | Highest-ROI prep in this pack. The scale gap in F3 is the most predictable objection, and it is where your material is thinnest, so it gets the deepest rehearsal. |
| B3 | "The role asks for five years of operations leadership. Walk me through the leadership roles you've held, and for how long." | JD | [grounded] "7 years in warehouse and distribution ops" (your message); "currently a senior shift manager over 3 supervisors" (your message) | Story-map on the two quotes: the senior shift manager role over three supervisors, then the seven years, each in those words. Answer slot: state the leadership years you can stand behind from your own record, and say plainly if they are fewer than the role asks. Do not round up. | F4. The count is not in the material, so it is yours to give. |
| B4 | "Your 40% mis-pick reduction: what would have to be true for it to hold across the whole operation?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Weakest-assumption move: name, before they do, the assumption behind the 40% you would defend least. Answer slot: if you tested what made the change work, say what you tested; if you did not, say so plainly and name what you would test first. | Tests the scope of the one headline figure. EXP because it asks what was actually yours to set. |

### C. Data-Driven Prober (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the 40% mis-pick reduction was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Weakest-assumption move: name the assumption behind the figure you would defend least, in your words, before they do. Answer slot: say how the figure was counted and which part of the redesign was yours; if you don't know how it was counted, say so plainly. The pack supplies no baseline, period or denominator. | The defend-the-number slot for the 40%. Relevant to F2, which is the on-time and cost requirement the figure stands in for. |
| C2 | "Which report have you built in Excel, and who used it?" | JD | [grounded] "solid Excel" (your message) | Name one report: what it tracked and who read it, in your words. Answer slot: if you have built a report others used, say which; if you haven't, say so plainly and say what Excel you have used. Do not claim a build you cannot walk through. | F5. "Solid" is your word and nothing has been inspected, so expect a probe. The Power BI half is B1. |
| C3 | "Have you owned an on-time or cost-per-shipment number? Which one, and how was it counted?" | JD | [generic] | Your material gives no figure for either. If you have one, say which and how it was counted. If you don't, say so plainly and name the one you would take first and why. | F2's requirement, asked as a question the material cannot answer. The honest answer is ready before the probe arrives. |

### D. Pressure / Stress (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over someone who has run a multi-site network?" | JD | [grounded] "7 years in warehouse and distribution ops" (your message); "cut mis-pick rate 40% by redesigning the pick path" (your message) | Pause and restate the question. Build the 60 seconds only from those two sentences. Hold through two follow-ups by returning to what you have done and the measured result. Concede only what is uncertain, in your own words, and only what your quotes leave open. | The pressure register on the fit question. The concession is limited to the quotes' own scope, so it cannot overstate. |
| D2 | "That 40%: how much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Hold-then-concede: hold the position by describing what you did, in your words. Concede explicitly any part that was the team's, by naming it. Never fold the core claim to restore the room. If the redesign was yours to make, say which part; if it was not, say so. | The pressure version of C1. The hold is the quote's own claim. |
| D3 | "What would you change about the peak plan you ran?" | EXP | [grounded] "ran the site's peak-season surge plan two years running" (your message) | Pause, restate, then answer from what you did. Name one change you would make and why. Answer slot: if you would run it the same way, say so and why. Do not invent a failure to confess. | Pressure on the peak-plan quote. The question presupposes no failure, so the guidance asks for none. |

### E. Conversational / Rapport (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "7 years in warehouse and distribution ops" (your message); "currently a senior shift manager over 3 supervisors" (your message); "ran the site's peak-season surge plan two years running" (your message); "green belt certified" (your message) | 90-second arc in this order: seven years in warehouse and distribution ops; the senior shift manager role over three supervisors; the peak plan run two years; the Green Belt. Each beat is one of your own sentences. Stop at the present and do not add a reason. | Casual register, but scored. This is the biography opener the pack should have ready. |
| E2 | "What's pulling you toward this role?" | EXP | [generic] | Answer in one or two sentences from your own reasons. Your material does not state one, so the reason is yours to supply. If you are unsure, say so rather than reaching for a bigger reason. | Motivation consistency under a casual register. No quote carries a reason. |

### F. Peer Evaluator (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Our teams sit side by side. Where's the seam, and what happens when we disagree?" | JD | [generic] | Name the seam as principles, not facts you don't know: where operations ends and planning or customer service begins. Propose how you would settle a disagreement, for example with a shared scorecard. Ask what their team needs from yours. | Partnership probe. Generic, because nothing about this company's teams is known to the pack. |
| F2 | "How do you handle credit when a result spans two teams?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Name who else was involved in the pick-path work and what each person did, in your words. If the result was yours alone, say so. Do not claim others' work as yours, or yours as theirs. Answer slot: if the change involved another team, say who and what they did. | Credit-sharing probe on the one result you have. The slot is conditional and presupposes no other team. |

## Prohibited claims

These are the claims this pack will not coach, each with its basis and its honest form. They are built locally from the fit snapshot.

| Not coached | Basis | Honest form |
|---|---|---|
| Ran daily operations across multiple sites | Inflated form of F1 | The quote at its own scope: "I've run the site's peak-season surge plan two years running." The pack's own observation, in analysis: your material names one site. No slot names multiple sites. |
| Led 12 supervisors, or a team of that size | Inflated form of F3 | The quote at its scope: "currently a senior shift manager over 3 supervisors." B2's slot asks how you would structure a span of twelve, not what you have led. |
| Designed the pick path and owns the 40% result | Inflated form of F2 | "The mis-pick rate fell 40% by redesigning the pick path." The agency is open in the quote; C1 and D2 ask which part was yours. |
| Five years of operations leadership | Inflated form of F4 | The quote at its scope: seven years in operations, and the senior shift manager role. Your material does not count leadership years. |
| Experience with Power BI | Negative you stated, F6 | Plain acknowledgment: "I haven't used Power BI." No slot. |
| Applied Lean or Six Sigma to live projects | Inflated form of F7 | "Green Belt certified," at its own scope. A4 asks what, if anything, you applied it to. |

## Reverse questions

Five questions to ask them. Answer "any questions for me?" with R1 or R3, not with "no, you've covered everything."

| # | Question | Why it lands |
|---|---|---|
| R1 | "On a bad week, which of the four sites is furthest from its on-time target, and what's blocking it?" | Shows you think in site-level data and gets you the real problem. |
| R2 | "How would the twelve supervisors be spread across the four sites today?" | Tests the span you would inherit before you are asked about it. |
| R3 | "What reporting does this role own now, and what's built in Excel versus Power BI?" | Tells you whether Power BI is a must-have or a nice-to-have, and turns your weakness into a question you can answer. |
| R4 | "What would you need to see from me in the first 90 days to call the role a success?" | Asks for the scorecard in their words. |
| R5 | "Which operational problem has taken the most leadership time in the last year?" | Shows you are thinking about where the time actually goes. |

## Sources

Research tier: L1, searches 2 of 6, fetches 0 of 2. Web search was refused in this session. Both calls were sent and refused, and nothing was returned.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Atlas Freight values | unavailable | The values cheat sheet, which is absent. Refused: "Atlas Freight regional logistics company values". No values-style round is detected, so the cheat sheet is dropped. |
| 2. Atlas Freight interview process, operations manager | unavailable | The loop structure. Refused: "Atlas Freight operations manager interview process". No loop source was established, so persona weights follow the round-type prior and the loop is flagged as unknown. |
| 3. Atlas Freight strategy / recent news | unavailable | The CO bank. No call was sent, because the host refused search. CO questions are therefore generic. |
| 4. {interviewer name} Atlas Freight | n/a | No interviewer name was given, so there was no query to form. The interviewer read is absent. |
| 5. Representative Operations Manager JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions. |

Provided documents: your JD text and your background message. No other documents were supplied.

## Upgrade menu

- A web-search permission grant, which lets me rerun the research pass for the company's values, interview loop and recent strategy. Those become a values cheat sheet, a grounding brief and CO questions in place of [generic] ones.
- The interviewer's name, which unlocks a tailored reverse question and persona weights from their public footprint.
- The recruiter's note on the round (who runs it, how many sessions, what they test), which confirms or reweights the persona table. If it is several sessions, I can build one mini-pack per session.
- A Green Belt certificate or project summary, which moves F7 from medium to high.
- Any on-time or cost-per-shipment figure you can stand behind, which upgrades F2 and C3 from answer slots to grounded answers.
- Confirmation of whether the role's sites need on-site shifts or travel. If they do, that becomes a gate row in the fit snapshot.
