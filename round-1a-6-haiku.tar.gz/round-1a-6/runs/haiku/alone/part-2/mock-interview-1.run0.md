Your prep pack is saved as /var/tmp/tuesday-measure/1a6/runs/haiku/alone/part-2/rooms/case-1-denied-a4356ad9/northwind_senior-gtm-strategy-lead_interview_pack.md. I built it for a peer round with Dan, since you described him as a peer, and on your research note alone: I ran no searches, because you said you have what's needed.

The pack has 22 questions across seven personas, weighted toward Peer Evaluator and Data-Driven Prober. The highest-ROI prep is D2: the partner-motion requirement against Priya's adjacent evidence, a partner-level revenue model. Her strongest facts are the ~$400M ARR sentence and the volume-targets sentence, and the pack holds each to its own wording. Rehearsing a claim wider than those sentences is the failure to avoid.

Priya's background came from your notes, not a CV, so every quote is your wording. Have her confirm each sentence before she rehearses it.

Say the word and I'll run a drill as Dan on D2, the partner-motion question.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: northwind_senior-gtm-strategy-lead_interview_pack.md -----
# Interview prep pack: Priya, Senior GTM Strategy Lead, Emerging Products

**Role:** Senior GTM Strategy Lead, Emerging Products
**Company:** Northwind Data (B2B data-infrastructure SaaS, about 3,000 employees)
**Round:** One 60-minute conversation with Dan Kovac, Director of Sales Strategy. A peer: both report to the same VP.
**Version:** First pack. No changes yet.

## How to use this pack

Personas describe how a question arrives. Types describe what it scores. Every question carries a type, a provenance label, answer guidance and a rationale. The guidance is scaffolding for a spoken answer, not a script. Answer slots are instructions for the interview; they ask nothing of you here.

| Type | Name | What it scores |
|---|---|---|
| VAL | Behavioral / values | Past behavior, told as a story with you in it |
| EXP | Experience deep-dive | Whether what is on the record holds up under pressing |
| JD | Role-driven | Whether you can do the listed job, gaps included |
| CO | Company and strategy | Whether you know Northwind's priorities and threats |
| CASE | Live problem | How you structure a problem from this role |

Provenance labels: **[grounded]** traceable to your inputs or research. **[inferred]** a reasonable extension, with its derivation named. **[generic]** a pattern for this kind of question, not a fact about Priya or Northwind.

**Where the quotes come from:** Priya's background reached me as your coach's notes. No CV was supplied, so every quoted sentence below is your wording, not hers. Confirm each one with her before she rehearses it.

## Fit snapshot

Requirements are the JD highlights in your message, quoted as you wrote them.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" (JD highlights, your message) | "9 at a large consumer-tech company in product strategy & ops" (coach's notes) | medium | [grounded] | transferability | The sentence places the strategy work in product strategy and ops, not in go-to-market strategy for a new line. Say that scope and no wider. Answer slot: if you set go-to-market choices for any product you worked on, say which and how you decided; if none were yours, say so and describe the strategy work you did. |
| F2 | "identify whitespace across land/adopt/expand/renew" (JD highlights, your message) | none given | none | [grounded] | discovery | Your material does not show whitespace work across the lifecycle. Answer slot: if you found an unserved segment or a missing motion at any stage, name it and what you did about it; if you did not, say so and say how you would find it first. |
| F3 | "run independent analysis in SQL and Tableau" (JD highlights, your message) | "skilled in SQL/Tableau" (coach's notes) | medium | [grounded] | discovery | The sentence names the tools, not analysis run on your own, so the bridge does not stretch it. Answer slot: name one analysis you ran yourself, the question it answered and the data behind it; if you did not run one on your own, say so and say what you used the tools for. |
| F4 | "partner-motion design experience required" (JD highlights, your message) | "built a partner-level revenue model used in carrier negotiations" (coach's notes) | medium | [grounded] | transferability | A revenue model used in negotiations is adjacent to partner-motion design, not the same thing, and the sentence stays at its own scope. Your material does not show a partner motion you designed. Answer slot: if you shaped how partners were engaged, incentivized or sequenced, say how and what you decided; if you did not, say so and say which part of the model you would start from. |
| F5 | "strong cross-functional influence" (JD highlights, your message) | "set annual volume targets with cross-org consensus" (coach's notes) | medium | [grounded] | presentation | Say it in these terms: "I set annual volume targets with cross-org consensus." This row adds no name, number or event. |
| F6 | "AI experience a plus" (JD highlights, your message) | "uses AI tools daily" (coach's notes) | low | [inferred] derivation: usage read as adjacent to the AI plus | transferability | Usage is adjacent to AI experience and is not evidence of it, so it appears only as a lead. Answer slot: describe one AI task you have done beyond using a tool, if there is one; if there is none, name the tools you use and what for. |
| F7 | Headline figure on the CV, with no JD line (plain prose, the coverage rule) [generic] | "proposed a store-surface change credited with a ~$400M ARR uplift" (coach's notes) | medium | [grounded] | none | The sentence carries no gap. It is a headline figure, so the defend-the-number questions apply (B1, B2, P2). Keep its wording: "proposed," "credited with," "about $400M." |

## Grounding brief

From your research note, not re-checked. Northwind's three stated priorities are enterprise expansion, an AI copilot launch called Compass, and reaching profitability. Its main competitive threat is bundling by a much larger platform vendor. No recent-news check ran, so treat these as the note's framings, not as current facts. Priya should use the vocabulary; she should not correct the interviewer on it.

## Reading the interviewer

Public footprint only, from your profile of Dan Kovac.

- **Career pattern:** a pricing and monetization spine, with one early-stage startup chapter.
- **Self-described:** "relentlessly data-driven."

Practical implications:

1. Expect every number to be taken apart. Rehearse B1 and B2 before anything else.
2. Pricing and packaging are his native language. Put the case answers in those terms (C1, A5).
3. The startup chapter means builder stories land, and scrappiness probes are likely.
4. As a peer, he will test the seam collegially (A1, A4).

**Mirror opportunity:** a shared domain, not a shared jump. His monetization path and F4's partner-level revenue model meet in pricing, which gives a natural opening on pricing. The profile shows no career jump like Priya's, so none is offered.

## Persona table

Relationship prior: peer. Dan's profile tilts the weights: data-driven self-description and a pricing spine push Prober and case questions up; the startup chapter adds builder and scrappiness probes. Depth follows weight: 5, 5, 3, 3, 2, 2, 2 questions, 22 in total.

| Persona | Questions | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|---|
| Peer Evaluator | 5 (A1 to A5) | Seam questions, credit, what he would need from her | High. The peer prior, and the same VP, make turf and credit live | Name seam principles, not a seam map. Credit in the sentence's own words |
| Data-Driven Prober | 5 (B1 to B5) | How it was counted, weakest assumption, the test design behind a result | High. Self-described data-driven, and the ARR figure is the obvious target | Know what can be said about each number, and say plainly what cannot |
| Case / Strategist | 3 (C1 to C3) | Pricing and packaging against the bundling threat; sequencing around Compass | Medium. The pricing spine tilts cases toward packaging; peer rounds use live cases less than hiring-manager rounds do | Clarify, then structure. State the framework once; do not perform it |
| Skeptic | 3 (D1 to D3) | The partner-motion gap, the day-one weakness, the move from consumer tech | Medium. The required partner-motion skill and the thin adjacent evidence make it likely; a peer raises it collegially | Hold the model; concede the gap as a plan for learning it |
| Conversational | 2 (E1, E2) | The journey opener; the AI plus asked casually | Low to medium. Peer rounds open casually, and casual questions are still scored | A 90-second arc; treat the AI question as scored |
| Pressure | 2 (P1, P2) | Why her over an internal candidate; how much was her | Low. A peer round, not an executive one, but the ARR figure invites it | Hold, then concede, through two follow-ups |
| Values / Behavioral | 2 (V1, V2) | An unpopular truth; a customer against an internal metric | Low. No values-style round is detected and no published values are in hand | Selection scaffold ending in the honest branch |

## Question banks

### A. Peer Evaluator (weight: top)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Our teams sit side by side — where's the seam, and what happens when we disagree?" | JD | [generic] | Name the seam as principles, not as a map you claim to know: who decides price on a new line, who owns partner pricing, and how you would settle a disagreement, by looking at the same data before either of you argues a conclusion. Ask him where his team draws the line. | Persona stem. The JD's "strong cross-functional influence" raises it. No claim about her past, so the label stands alone. |
| A2 | "How do you handle credit when work spans teams?" | JD | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (coach's notes); "set annual volume targets with cross-org consensus" (coach's notes) | Use the sentences. "I proposed the change, and it is credited with about $400M in ARR uplift." If others shaped it, name the part they carried; if it was hers alone, say so. Do not turn "credited with" into "delivered." Answer slot: if she cannot say whose part was whose, she says that plainly. | F5 and F7 are the sentences credit is tested against. A peer's credit probe is the seam question in its collegial form. |
| A3 | "Walk me through how the annual volume targets were set." | EXP | [grounded] "set annual volume targets with cross-org consensus" (coach's notes) | Say the sequence in her own words: who she brought in and what each group agreed to. Answer slot: if one group's input changed a target, say which and how; if others set the targets and she ran the consensus, say that; if there was no consensus step, say so and say how the targets were set. | F5's sentence is the nearest thing in the material to sales-target work. Dan's sales-strategy title makes a quota follow-up likely; the material shows volume targets, not quotas, so the answer stays at that scope (prohibited list, item 4). |
| A4 | "What would you need from me in the first 90 days, and where would I step on your work?" | JD | [generic] | Name two things she would need from his team's data and two boundaries she would propose, as proposals: "I'd want the pricing cut by segment"; "I'd propose you own price changes on existing lines." No claim about past work. | Persona stem, peer-collegial. A peer scores the needs answer as partnership fit. |
| A5 | "A partner's list price undercuts your direct motion on a new line. Who decides, and on what data?" | CASE | [generic] | Clarify first: the same product at a discount, or a bundle? State the decision right, name the data cut needed first (win and loss by channel), recommend, then name one risk. No claim about partner work she did. | F4 is the gap here, and this question tests reasoning, not history. It presupposes nothing about her past. |

### B. Data-Driven Prober (weight: top)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Walk me through how that number was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (coach's notes) | Say what the uplift measures, over what window, and how the change was separated from everything else that moved. The material does not show the method. Answer slot: if she knows how it was attributed, she says it; if not, she says she does not know how it was counted and who would. Never supply a baseline or method to fill the gap. | F7 is the headline figure. A data-driven interviewer's first move is to check the counting, and an explanation she cannot repeat under a second question is worse than none. |
| B2 | "Which assumption behind that number would you defend least?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (coach's notes) | Name the weakest assumption before he does, in her words. Answer slot: if she can name one, she names it; if not, she says the figure's basis is not something she can defend from memory. Do not add a second assumption to sound complete. | The second follow-up to B1. Naming the weak point turns a gotcha into a credibility gain. |
| B3 | "Walk me through the partner-level revenue model: what did it estimate, and what was it used for?" | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" (coach's notes) | Say what it estimated and how it was used in negotiations, in those words. Answer slot: if she can say which input moved the answer most, she says it; if she did not test that, she says so. | The strongest analytic sentence in the material, and the one a data-driven peer tests. It is also the adjacent evidence for F4, so it stays at the model's scope. |
| B4 | "Take me through one analysis you ran in SQL or Tableau yourself: the question, the data, and what changed." | JD | [grounded] "skilled in SQL/Tableau" (coach's notes) | Answer slot: name one analysis she ran herself, with its question, its data and what it changed. If she did not run one on her own, she says so and says what the tools were used for. Never describe an analysis she did not run. | F3. The JD requires "run independent analysis," and the quote names only the tools, so the guidance is a slot, not a story. |
| B5 | "How would you test whether an adopt-stage incentive moves expansion revenue? What's the control?" | CASE | [generic] | Name the unit, the control group, the metric, the timeframe, and the one thing that would make the test misleading. Do not name a result. | A JD requirement on land/adopt/expand/renew. A method question scores the test design, and asks no past claim. |

### C. Case / Strategist (weight: mid)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Your research note says the main threat is bundling by a much larger platform vendor. How would you position the first new line against it?" | CO | [grounded] "main competitive threat is bundling by a much larger platform vendor" (your research note) | Clarify first: is the line sold alone, or into the bundle's buyers? Choose one place to differentiate (pricing and packaging, a partner route, or data depth) and say what she would not do, such as matching the bundle's price. Keep the note's wording. Do not claim a Northwind response. | The CO bank rests on your research note, the only source at this tier. Dan's pricing spine makes packaging the angle he will test. |
| C2 | "Northwind's stated priorities include enterprise expansion and reaching profitability. Where do those two pull against each other for a new line?" | CO | [grounded] "enterprise expansion" and "reaching profitability" (your research note) | Name the trade-off: spend that buys expansion, against payback over the period profitability is measured. Propose one test or guardrail. Do not cite Northwind figures; none are in hand. | Tests whether she can think at the company's altitude. It stays on priorities, not numbers. |
| C3 | "Compass is the AI copilot launch. How would you sequence a new product line around it?" | CASE | [grounded] "an AI copilot launch ('Compass')" (your research note) | Clarify whether the line depends on Compass. Give two sequencing options with the dependency named, recommend one, and state its main risk. Make no claim about Compass's status. | Ties the JD's "own GTM strategy for two new product lines" to the stated launch. A live problem, so it asks nothing about her past. |

### D. Skeptic (weight: mid)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "identify whitespace across land/adopt/expand/renew" (JD highlights, your message) | Name the weakest part as a plan, not as a past: the lifecycle whitespace read is the slowest part until she has seen the company's data; then say the first thirty days. Make no claim to whitespace work; F2 does not show it. | Skeptic stem. F2 is the row with no evidence, so the honest answer is a ramp. |
| D2 | "Partner-motion design is central to this role. Which part of a partner motion have you designed yourself, if any?" | JD | [grounded] "partner-motion design experience required" (JD highlights, your message); "built a partner-level revenue model used in carrier negotiations" (coach's notes) | **The highest-ROI rehearsal in this pack.** Open with the model in her own words. Answer slot: if she shaped how partners were engaged, incentivized or sequenced, she says how and what she decided; if not, she says so plainly and says which part of the model she would start from. Hold through two follow-ups by returning to the model. Concede the gap in the form the material allows: name the piece she would learn first, and how. | F4. The requirement is stated as required, the evidence is adjacent, and a peer will test it collegially. The deepest rehearsal goes here because the objection is predictable and the material is thinnest where it lands. |
| D3 | "Why move from consumer tech to B2B data infrastructure?" | EXP | [grounded] "9 at a large consumer-tech company in product strategy & ops" (coach's notes) | Answer slot: she says the reason in her own words. The material gives none, so this pack offers none. Keep it to a motive she can name and defend. | The skeptic's "why leave, why here" probe. It bites hardest because F1 is adjacent, not direct. |

### E. Conversational (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So — walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" (coach's notes) | Ninety seconds: consulting, then consumer-tech product strategy and ops, then the revenue model and the volume targets. Use only those beats. The reason for the move belongs to D3's slot, not to the arc. | Openers are scored. The beats are the sentences' own, so the arc needs no detail she has not given. |
| E2 | "What are you actually playing with in AI these days?" | JD | [inferred] derivation: "uses AI tools daily" (coach's notes) read as adjacent to the AI plus | Name the tools and one task she uses them for, at the scope she uses them. If she has built something with AI, she names it. If her use stays at tools, she says that and says what she would want to learn. | F6 is low confidence, so this is a lead, not a claim. The JD marks AI as a plus, and casual questions about it are still scored. |

### P. Pressure (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Sixty seconds: why you over an internal candidate?" | JD | [grounded] "set annual volume targets with cross-org consensus" (coach's notes); "built a partner-level revenue model used in carrier negotiations" (coach's notes) | Hold the one quoted sentence that answers the cross-functional requirement, and say it in one breath. Two follow-ups will press on why an internal candidate would not do. Hold the position without adding a claim. Concede in the plan form: the partner-motion piece she would learn first. | F5 and F4. The hold has to be something the sentences carry; a held position she cannot back is what the second follow-up breaks. |
| P2 | "That result — how much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (coach's notes) | Hold: "I proposed the change, and it is credited with about $400M in ARR uplift." Under two follow-ups on the share, concede the part she cannot prove and name what she would check. Do not fold to "it was mostly mine" or "it was mostly the team's." | F7. Hold, then concede, on the figure's share. The concession is specific, and the core claim stays put. |

### V. Values / Behavioral (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time she disagreed with a senior decision on the numbers. Name the stake, the moment she said it, and what happened after. If no such time comes to mind, she says so plainly, then gives the nearest thing her material carries, or how she would handle it. | Persona stem. No published values are in hand and no values round is detected, so this is kept at low weight, with no shared-values claim. |
| V2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a time a customer's outcome cost her against an internal number. Name the customer, the metric and the trade-off. If none comes to mind, she says so plainly, then gives the nearest thing her material carries, or how she would handle it. | Persona stem. If Northwind's published values arrive later, these become mapped VAL rows. |

### Requirement coverage

| JD requirement | Questions |
|---|---|
| own GTM strategy for two new product lines | C1, C3 |
| identify whitespace across land/adopt/expand/renew | B5, D1 |
| run independent analysis in SQL and Tableau | B4 |
| partner-motion design experience required | A5, B3, D2, P1 |
| strong cross-functional influence | A1, A2, A3, A4 |
| AI experience a plus | E2 |

Research-note priorities outside the JD: enterprise expansion and profitability, C2; Compass, C3; the bundling threat, C1. The headline figure, which the coverage rule requires, gets B1, B2 and P2.

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What could a new person do in their first month that would genuinely help your team?" | Reciprocity, since he is a peer. It turns the seam into a shared plan and shows she is thinking about his work too. |
| R2 | "Your career has centered on pricing and monetization. Which pricing call on a new line would you want the GTM lead to own, and which would you keep for pricing?" | Tied to his own path. It turns the interview into a peer conversation and shows she read his background, not only the company's. |
| R3 | "Where does the Compass launch depend on the emerging-products lines, and where does it not?" | Shows she read the research note, and asks for the dependency that drives sequencing. |
| R4 | "How are enterprise expansion targets divided between your team and the new-product work?" | Surfaces the seam and the decision rights without assuming a split. |
| R5 | "When the bundling threat comes up, what response do you want from this role?" | Tests whether the role is set up to strategize or to execute, and gives her the decision rights. |
| R6 | "What would a strong first 90 days look like from where you sit?" | Gives him a concrete picture to react to, and a closing signal she can use. |

## Prohibited claims

Priya has stated no negatives yet, so the list holds no sourced entries. Each entry below is an inflated form of a sentence she did say. Every answer, hold and bridge in this pack stays off these claims.

| Not coached | Basis | Honest form |
|---|---|---|
| "Designed a partner motion" or "owned partner-motion design" | Inflated form of F4 | The quote at its own scope: "built a partner-level revenue model used in carrier negotiations." Your material does not show a partner motion she designed; D2's slot stays inside the model. |
| "Delivered" or "owned" the ~$400M ARR uplift | Inflated form of F7 | "proposed a store-surface change credited with a ~$400M ARR uplift." The share is a defend-the-number question (B1, B2, P2). |
| "Led the cross-org consensus" | Inflated form of F5 | "set annual volume targets with cross-org consensus." A3's slot covers which groups fed in, and nothing more. |
| "Set quotas" or "owned sales-ops" | Inflated form of F5: volume targets widened into quota work | The volume-target sentence at its own scope. Your material shows targets, not quotas. |
| "Ran independent SQL and Tableau analysis" | Inflated form of F3 | "skilled in SQL/Tableau." B4's slot asks for one analysis she can describe, and only that. |
| "Built AI products" or AI experience beyond usage | Inflated form of F6 | "uses AI tools daily," as an [inferred] lead only. |
| "Enterprise B2B product strategy" | Inflated form of F1 | "product strategy & ops at a large consumer-tech company." Your material shows consumer-tech work; the limit is the pack's observation, not a claim she must make. |

## Sources

**Provided documents, all from your message:**

- The JD highlights: six requirement lines.
- Priya's background, as your coach's notes. No CV was supplied.
- Dan Kovac's profile: Director of Sales Strategy, self-described "relentlessly data-driven," a pricing and monetization career with one early-stage startup chapter.
- Your research note: three stated priorities and one competitive threat.

No dossier was supplied. No searches or fetches were sent.

Research tier: L0 — no searches

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Northwind Data values | skipped | Values cheat sheet (section 10). It needs a values-style round; this is one peer conversation with no values signal, so no output depends on it |
| 2. Northwind Data interview process, senior GTM | skipped | Loop structure. Your message says one 60-minute conversation, so persona weights are set for a single session |
| 3. Northwind Data strategy and recent news | unavailable | Declined: you said you have what is needed. Would have moved the freshness of the research note's priorities and recent moves, and the case and CO banks (C1 to C3) |
| 4. Dan Kovac, Northwind Data | unavailable | Declined. Would have moved the public footprint behind the interviewer read (talks, writing) and reverse question R2 |
| 5. Representative senior GTM JD | skipped | The JD highlights in your message fix the fit-snapshot requirements and the JD-tagged questions |

## Upgrade menu

- Priya confirming the coach's-note sentences in her own words, or sending her CV → the quotes become hers, the confidence bands in the fit snapshot can rise, and F1, F3, F4, F5 and F7 rest on her own sentences.
- Priya's answers to the answer slots, in her own words, sent back → F1 to F4, D2 and D3 regenerate. If she states a negative (for example, that she has not set quotas), that gap becomes a plain acknowledgment, and A3's slot becomes a statement.
- The full JD text → the six highlights become full quotes, and any location, schedule or work-authorization terms it states get checked as gates. None appear in the highlights.
- A public-footprint check on Dan Kovac's talks and writing (L1) → the interviewer read gains his published themes, and R2 can cite them.
- A freshness check on the research note (L1) → the grounding brief and C1 to C3 are confirmed or updated against current news.
- A planned case or deliverable in Dan's session → a case bank and a deliverable section.
