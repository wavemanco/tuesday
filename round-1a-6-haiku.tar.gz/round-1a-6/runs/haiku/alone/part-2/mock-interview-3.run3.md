Your prep pack is saved at `/var/tmp/tuesday-measure/1a6/runs/haiku/alone/part-2/rooms/case-3-denied-b6e53523/stripe_product-operations-manager_interview_pack.md`. I built it without a job description, CV, interviewer name or round details, so the questions and reverse questions are role-family generic. The host also refused web search, so the pack has no Stripe-specific values, strategy or loop facts. Your answers to the three questions below would let me replace the generic parts with real material.

Want me to play the Skeptic on C1? It's the question I'd rehearse hardest: "Which part of this role would you be weakest at on day one?" Final rounds usually probe the gap a panel sees, and a calm, specific answer you've practiced will carry you through it.

I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.

Three things would reshape the pack:

1. What round is this, and who are you meeting: your future manager, a peer, a senior leader or a panel? Did the recruiter name any focus areas or a take-home?
2. Could you paste the job description and your CV, or a few bullets from it?
3. Does the posting list any must-haves I should treat as hard gates, such as work authorisation, location or a certification?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: stripe_product-operations-manager_interview_pack.md -----
# Stripe, Product Operations Manager: final-round prep pack

**Role:** Product Operations Manager. **Company:** Stripe. **Round:** final (type and interviewer not yet known). **Interviewer:** unknown. **Relationship:** unknown, so persona weights are blended.
**Changelog:** first build. No JD, CV, interviewer or round details were in the conversation, and web search was refused by the host, so this pack is built on role-family knowledge only.

## 1. How to use this pack

- **Personas** describe how a question is asked (the delivery). **Types** describe what is being scored.
- Type key: **JD** = stated responsibilities and whether you can do the listed job. **EXP** = what you actually did, and whether it survives a follow-up. **CASE** = a live problem from the role, scored on structure and reasoning. **CO** = company knowledge (none in this pack, see Sources). **VAL** = published values (none, since no values round is detected).
- Guidance is scaffolding, not a script. Rehearse the structure and the honest branches, then say it in your own words.

## 2. Fit snapshot (worksheet variant)

No CV and no JD were provided, so no requirement is quoted and no evidence exists yet. Each row is a role-family requirement written as plain prose and labeled `[generic]`. Every evidence cell is `none given`, so no claim about your past is written here.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Designing and running an operating cadence for a product organisation (role family, no source) | none given | none | [generic] | discovery | Strong evidence: you have set up or run a recurring review that produced a decision. Selection scaffold: pick a recurring meeting or review you ran or helped run, and say what decision it produced. If you have none, say so and describe how you would design one |
| F2 | Working across product, engineering, finance and go-to-market teams (role family, no source) | none given | none | [generic] | discovery | Strong evidence: a cross-team process you ran, with the teams named. Selection scaffold: pick a time two teams wanted different things from one process. If none comes to mind, say so and describe how you would find the seam |
| F3 | Defining metrics and reporting on them (role family, no source) | none given | none | [generic] | discovery | Strong evidence: a metric you defined, its definition, and who used it. Selection scaffold: name a number you reported regularly, how it was defined, and one assumption behind it. If none, say so, and say what you would define first |
| F4 | Managing launches and rollouts (role family, no source) | none given | none | [generic] | discovery | Strong evidence: a launch or rollout you tracked end to end. Selection scaffold: pick a launch where dates slipped, and say where the slip came from. If you have none, say so and describe how you would track one |
| F5 | Prioritising among competing requests and making trade-offs (role family, no source) | none given | none | [generic] | discovery | Strong evidence: a request you declined or deferred, and why. Selection scaffold: pick a time you said no to something useful, and say what you did with the requester. If none, say so and describe your method |
| F6 | Owning internal tools and systems that teams rely on (role family, no source) | none given | none | [generic] | discovery | Strong evidence: a tool or system you were accountable for, and what broke. Selection scaffold: pick a tool a team depended on, and say how you decided when to change it. If none, say so and describe how you would decide |
| F7 | Ramping into a new domain quickly (role family, no source) | none given | none | [generic] | discovery | Strong evidence: a time you learned an unfamiliar process fast, and what you did in week one. Selection scaffold: pick one such time. If none, say so and describe your first 30 days |

*Observation, not words for you:* the material does not show any of these, so the pack cannot say what you did. Gap types are `discovery` because the evidence may exist and nothing here shows it.

## 3. Persona table

Relationship and round are unknown, so weights are blended. The most common shape for a final-round loop is a hiring-manager-led round with a skeptic element (personas.md, relationship priors). That is an assumption, not a fact about this loop. Weights are flat-ish until the round is known.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy | Depth |
|---|---|---|---|---|
| Case / Strategist | Live operating problems from the role: launches, metrics, process choices | High. Hiring-manager prior, and ops roles are judged on structure | Clarify, then structure, then one metric, then a risk. Say the framework aloud once | 5 (bank A) |
| Data-Driven Prober | Asks how a number was counted and what it hides | Medium-high. Ops roles are measured on reporting, so metrics get probed | Name the weakest assumption before they do. Say plainly when you do not know how a figure was counted | 3 (bank B) |
| Skeptic | Quiet questions on the gaps: "why this role, why now", day-one weakness | High. Final rounds usually test the one risk the panel has | Rehearse the one predictable objection until it is calm. Candour over bluffing | 3 (bank C) |
| Peer Evaluator | Seam questions between ops and product, finance or GTM; credit questions | Medium. Likely if a peer sits on the panel | Propose seam principles, not invented facts. Say what you would need from them | 3 (bank D) |
| Pressure / Stress | Time-boxed challenges, interruptions | Low-medium. Possible from a senior leader | Pause, restate, hold through two follow-ups, concede specifically | 2 (bank E) |
| Conversational / Rapport | Friendly open: "walk me through your journey" | Medium. Casual questions are still scored | 90-second arc, and treat casual questions as scored | 2 (bank F) |

Values/Behavioral is not weighted: no values round is detected, so no loop source establishes one.

## 4. Question banks

Provenance is `[generic]` throughout because no candidate sentence exists to quote. Every guidance cell that asks for a past event is a selection scaffold with an honest branch, not a story map.

### Bank A: Case / Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Launches on this product team keep slipping because hand-offs between design and launch are untracked. What do you do?" | CASE | [generic] | Clarify which launches and what slipping means against which date. Objective: fewer surprises at launch. Segment: where hand-offs break (intake, dependencies, sign-off). Approach: map the current flow with the people in it, then fix one bottleneck. Metrics: on-time launch rate, days of slip. Risk: process teams route around. Challenge one premise the interviewer gave you | Launch management is a role-family requirement (F4), and this is its likeliest live form. CASE because it is scored on structure |
| A2 | "How would you decide which internal processes to retire?" | CASE | [generic] | Criteria first: usage, cost of delay, who depends on it. Talk to owners before deciding. Then a sunset plan with a date and a fallback | F1 and F5 meet here. CASE because the reasoning is the answer |
| A3 | "Sketch an operating review for a fifty-person product org. What goes on it?" | CASE | [generic] | Inputs, cadence, the decisions it must produce, and what you would drop. Say which decision it exists to make | F1 is the cadence requirement; a review that makes no decision is the common failure |
| A4 | "A key metric fell fifteen percent week on week. Walk me through the diagnosis." | CASE | [generic] | Definitions first: is it counted the same way? Then segments, then what changed in the period, then a short hypothesis list. Say which check you run first and why | F3 is reporting, and metric diagnosis is the standard ops case. Structure over the right answer |
| A5 | "How would you decide whether a team should build or buy a tool for its workflow?" | CASE | [generic] | Clarify the workflow's volume and owner. Compare the cost of each over a year, including the cost of switching later. Name the test you would run first | F6 and F5. Tests the trade-off reasoning |

### Bank B: Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time you measured whether a process change worked." | EXP | [generic] | Selection scaffold: pick a change you made or helped make. Name what you measured before and after, how you counted it, and the assumption you would defend least. If you have no such example, say so, then describe how you would set up the measurement | Open prompt, theme from the Prober's stem. Tests attribution, not whether you have the example |
| B2 | "What number would you ask a team to report every week, and what would it hide?" | JD | [generic] | Name one metric, its definition and denominator, then the thing it hides. Say what you would check before trusting it | F3 requirement. Looks like a simple question and is a test of whether you know a metric's blind spot |
| B3 | "How do you stop a dashboard becoming the thing people argue about?" | JD | [generic] | One owner of each definition, a change log, one source of truth. Say how you would settle a disputed number | F3 and F6. Tests process, not tooling |

### Bank C: Skeptic (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | **Highest-ROI prep in this pack.** Name one real gap in your own words, since you know your background better than this pack does. Then say how you would close it in thirty days: who you would ask, what you would read, what you would do first. Do not claim a skill to make the gap smaller | The most predictable objection in a final round is "your background does not show this." Naming the gap yourself is calmer than being cornered by it. Rehearsal here changes the room |
| C2 | "Why this role, and why now?" | EXP | [generic] | Ninety seconds: what draws you to making a product organisation run, one thing you would want to avoid, and why this is the next step. Keep it to what you want, not what they want to hear | Motivation consistency is the Skeptic's scored item. No claim about your past is needed |
| C3 | "If you had to run a process you had never used before, what would you do in the first month?" | JD | [generic] | Learn the process from its users first. Name who you would ask, what you would map, and what you would not change yet. Say what would make you change it | F7 and F6, asked as a plan, not a record |

### Bank D: Peer Evaluator (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Our product and finance teams sit side by side. Where is the seam with operations, and what happens when we disagree?" | JD | [generic] | Name principles for the seam: who decides what, what gets shared. Then the disagreement: pick a time you disagreed with a peer and both of you were partly right. If none comes to mind, say so and describe how you would settle it | Open prompt, theme from the Peer's stem. Tests turf awareness and disagreement style |
| D2 | "How do you handle credit when work spans teams?" | EXP | [generic] | Name the people who did the work, and say what you did in your own words. Do not claim what others did. If you have no example, describe your rule | Credit probes test honesty about shared work |
| D3 | "What would you need from my team to do this job well?" | JD | [generic] | Ask for specific decisions and data access, not vague support. Name one thing your team would need from theirs | Reciprocity framing, so the answer is about what you bring to their team too |

### Bank E: Pressure / Stress (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why should we hire you over an internal candidate?" | EXP | [generic] | Pause, restate the question. Anchor in one thing you can actually say about your own work. Hold that through two follow-ups. Concede a specific uncertainty if one is real, and do not fold on the core claim | Hold-then-concede structure: the Pressure persona scores composure, not the answer |
| E2 | "That is a lot of process for a team this size. Why would it help?" | JD | [generic] | Hold: say what the process is for and the decision it makes. Concede where it would be overhead, and name a size or trigger at which you would drop it | Tests whether you can defend a process without defending process for its own sake |

### Bank F: Conversational / Rapport (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through your path into this kind of work." | EXP | [generic] | Ninety-second arc: the problem you kept meeting, what you did about it in your own words, why this is the next step. If your path does not form an arc, say so and give the one thread through it | Casual opener, still scored. Selection scaffold, since there is no sentence to map |
| F2 | "What are you reading about how companies run their operations these days?" | CO | [generic] | Name one thing you have read and what you took from it. Do not recite a shared report. If you have not read anything recently, say so and name one source you would read first | Tests whether you keep current. No strategy claim is made here, since research did not run |

### Coverage: role-family requirements to question IDs

| Requirement | Covered by |
|---|---|
| Operating cadence design (F1) | A2, A3 |
| Cross-team work (F2) | D1, D3, E2 |
| Metrics and reporting (F3) | A4, B1, B2, B3 |
| Launch management (F4) | A1 |
| Prioritisation and trade-offs (F5) | A2, A5, E2 |
| Owning tools and systems (F6) | A5, B3, C3 |
| Ramping into new domains (F7) | C1, C3 |

Every requirement has at least one question. No CO or CASE question is grounded in current Stripe strategy: research did not run.

## 5. Reverse questions

Each has a "why it lands." No interviewer profile exists, so none is tied to the interviewer's own path.

1. "What does a strong first ninety days look like in this role, and which part of the ops work is most often under-resourced?" Why it lands: it shows you are thinking about the job's real shape, not the title.
2. "Who decides when an internal process gets retired here, and how has that worked recently?" Why it lands: it tests the seam with product and finance and shows you know decisions have owners.
3. "Which metric is this team judged on, and has that changed in the last year?" Why it lands: a question about the scoreboard shows you expect to be measured.
4. "What has the team tried that did not work, and what did it teach you?" Why it lands: it invites candour and tells you how the team handles failure.
5. "What could a new person do in their first month that would genuinely help your team?" Why it lands: reciprocity. It works whether the interviewer is a peer or not, and it changes the conversation from being assessed to planning together.
6. "What would make you confident this hire was right?" Why it lands: it shows you want the actual bar, and it gives you the last thing to address.

Answer to "any questions for me?" is never generic: use one of the questions above, chosen for the round once you know who is in it.

## 6. Prohibited list

Built locally, since no dossier exists. Nothing here is an inflated form yet, because no candidate sentence exists to stretch.

| Not coached | Basis | Honest form |
|---|---|---|
| Any specific past role, ownership, figure or outcome | No candidate sentence in the material. Any such claim would be invented | The selection scaffolds above, with their honest branch: say so plainly, then describe how you would do it |
| Any claim of Stripe-specific knowledge (values, strategy, team structure, the loop) | Not researched in this session, so not verified | Check Stripe's own careers and product pages before the interview, and cite only what you read there |

## 7. Sources

- Provided documents: none. No JD, CV, interviewer profile, recruiter note or strategy brief was supplied.
- Research tier: L1. Searches 0 of 6 succeeded; fetches 0 of 2.
- Searches sent, all refused by the host (WebSearch permission not granted):
  - "Stripe company values principles": refused
  - "Stripe interview process final round onsite loop": refused
  - "Stripe Product Operations Manager job description": refused

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Stripe values | unavailable | Values cheat sheet (section 10): not built, since no values round is detected |
| 2. Stripe interview process, product operations | unavailable | Loop structure. Persona weights stay blended, not tuned to a known loop |
| 3. Stripe strategy and recent news | unavailable | CO and CASE questions grounded in current strategy, and the grounding brief (section 6). None written |
| 4. Interviewer name and Stripe | n/a | No interviewer name was given, so there was no query to form |
| 5. Representative Product Operations Manager JD | unavailable | JD-derived rows would become `[inferred]`. Requirements here stay `[generic]` |

## 8. Upgrade menu

- Your CV, or a few bullets from it → story-mapped answers for banks B, C and E, replacing the selection scaffolds; fit-snapshot rows F1 to F7 get real evidence and confidence
- The job description → the seven `[generic]` rows become `[grounded]` quotes, and JD questions carry the posting's own wording
- The round format and who you are meeting → persona weights reordered to fit, and a tailored reverse question
- The interviewer's name → an interviewer read and a reverse question tied to their own path
- Permission for web search → the research targets above (values, loop structure, strategy), so the values sheet and CO questions can be built
- Any take-home or deliverable the recruiter named → a build section for it
- A `tuesday-dossier.md` → would carry verified evidence and prohibited-claim guardrails into later sessions
