Your prep pack is saved as `/tmp/claude-0/-var-tmp-tuesday-measure-1a6-runs-haiku-alone-part-2-rooms-case-7-denied-9643b2da/55656582-7321-4ec9-91a0-84a6a30a440e/scratchpad/saltmarsh_live_operations_producer_interview_pack.md`. It's built on a hiring-manager round with Tobias as Head of Live Ops, from the JD and background in your note. Web search was refused on this run, so nothing about Saltmarsh's values, interview loop or Tobias's background is in it. The pack is based on the JD alone.

# Interview prep pack: Live Operations Producer, Saltmarsh Games

Interviewer: Tobias Wrenfield, Head of Live Operations. Relationship assumed to be hiring manager (60 minutes).

## How to use this pack

Personas describe how a question arrives. Types describe what is being scored: **JD** (the listed responsibilities), **EXP** (your past work and how you attribute it), **CASE** (a live problem), **CO** (company knowledge), **VAL** (values). Guidance is scaffolding, not a script. Say it in your own words, and only what you did.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | transferability | Your material shows one title and weekly content drops, not live events across two titles. Bridge stays at the calendar you ran: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: if you have planned or run a calendar across more than one title, say which and what was yours; if not, say so plainly and say how you would sequence two. |
| F2 | "coordinate design, art, engineering and community teams on each update" (JD) | "Wrote the release checklist our QA team still uses." (your message) | low | [inferred] | discovery | Your material does not show coordination with design, art, engineering or community on updates. The checklist touches QA only. Answer slot: if you coordinated any of those four teams on an update, say which and how, in your own words; if you did not, say so and describe how you would set up those handoffs. |
| F3 | "own the post-event review and the KPIs it reports" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | medium | [grounded] | transferability | Presenting monthly numbers is reporting, not owning a post-event review. Bridge: "I presented the monthly retention numbers to the studio head." Answer slot: if you owned a post-event review or its KPIs, say which and how; if you did not, say so plainly. |
| F4 | "manage the release checklist with QA" (JD) | "Wrote the release checklist our QA team still uses." (your message) | medium | [grounded] | presentation | The quote reaches the requirement in other terms: you wrote the checklist and QA uses it. Bridge: "I wrote the release checklist our QA team still uses." Do not say "managed". |
| F5 | "3+ years producing live-service games or apps" (JD) | "4 years as an associate producer at a puzzle-game studio." (your message) | medium | [grounded] | presentation | Four years is the fit. Your material does not say the puzzle title ran on a live-service cadence, and the title is associate. Bridge: "4 years as an associate producer at a puzzle-game studio." Answer slot: if you carried responsibilities above that title, say which and how you decided, in your own words; if not, say so and stay with the four years. |
| F6 | "experience running a content calendar" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | none | The quote reaches the requirement directly. Expect a probe on what you decided. Answer slot: if any calendar decisions were set by others, say which. |
| F7 | "comfortable with player-retention metrics" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | medium | [grounded] | none | The quote reaches the requirement in role terms. Expect a probe on how the figures were counted. No figure is in your material, so none is offered here. Answer slot: if you know how they were counted, say so in your words; if not, say that plainly. |
| F8 | "clear written communication" (JD) | "Wrote the release checklist our QA team still uses." (your message) | medium | [grounded] | presentation | A written artifact a team still uses is the evidence. Bridge: "I wrote the release checklist our QA team still uses." Nothing added. |
| F9 | lead a team of people (role-family prose, not in the JD text) | "Never led a team, and never worked on a game with in-app purchases." (your message) | none | [grounded] | capability | A gap you stated. Words: "I haven't led a team." Then how you would learn to lead a team, said as a plan and never as a past. |
| F10 | in-app purchase and monetization experience (role-family prose, not in the JD text) | "Never led a team, and never worked on a game with in-app purchases." (your message) | none | [grounded] | capability | A gap you stated. Words: "I haven't worked on a game with in-app purchases." Then how you would learn the spending metrics, said as a plan. |

The pack's own observations, not words for you to say: the JD asks you to coordinate four teams, not manage them, so F9 is a probe risk rather than a listed requirement. Two titles, live events and KPI ownership are where the JD asks for more than your material shows.

## Persona table

Weights are relationship priors for a hiring-manager round, adjusted for the JD. No loop source was read, so the loop is the generic fallback: flat weights, said plainly.

| Persona | Weight | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|---|
| Case / Strategist | 5 (top) | A live problem on his own calendar: two titles, one update, a bad day-two event | Hiring-manager prior. The JD is a responsibilities list, so he is likely to hand you one. | Clarify, then structure, then name the metric. Think aloud. |
| Skeptic | 4 | Quiet, persistent probing of the gaps: one title, no IAP, no team | Hiring-manager prior. The gaps in F1, F2, F9 and F10 are where a skeptic presses. | Rehearse the most predictable objection until it is boring. Concede specifically. |
| Data-Driven Prober | 4 | Follow-ups on how the retention figure was counted and who owned the KPIs | Not a default for this relationship, raised to 4 by the JD's KPI and retention language and by F7. | Know what you can and cannot say about each number. Name the weakest assumption you know. |
| Pressure / Stress | 3 | Time-boxed answers, sharp challenges on the IAP and team gaps | Not in the relationship prior. A 60-minute slot raises the chance of time-boxing. | Pause, restate, hold through two follow-ups, concede only the specific gap. |
| Conversational / Rapport | 2 | A "walk me through the journey" opener and a casual question about a JD topic | Low weight, but scored. Casual questions on JD topics count. | A 90-second arc. Treat casual questions as scored. |

## Question banks

Provenance comes first in each row. A row whose guidance makes no claim about you carries its label alone.

### A. Case / Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Two titles, one live-events calendar. Plan next month's events for both, with one design team and one art team. What do you do first?" | CASE | [generic] | Clarify before structuring: each title's goal for the month, what is already committed, which constraints are real. Then structure: objective, dependencies across design, art, engineering, community and QA, sequencing, risks, and the metric each event is judged on. Say what you would ask before you commit a date. Rehearse it aloud in 90 seconds. | JD's first requirement and the likeliest live problem. CASE because the answer is reasoning, not record. No claim about your past. |
| A2 | "Day two of a live event: a reward is paying out wrong for some players, and engagement is down. What do you do in the next 24 hours?" | CASE | [grounded] "Wrote the release checklist our QA team still uses." | Confirm scope and who is affected. Decide between pausing, a hotfix and communicating. Say who decides and how fast. Answer slot: say whether the release checklist has a rollback or hotfix step. If it does, name it; if it does not, say so and propose adding one. | JD's release checklist with QA. F4 is the only release-process evidence. |
| A3 | "A designer wants a bigger event than the art team can finish in the window. How do you resolve it?" | CASE | [generic] | Name the trade-off: scope, date, or which assets get cut. Say who decides and how quickly, what you would tell design and art the same day, and what you would record. | JD's coordination line, as a live conflict rather than a record. No claim about your past. |
| A4 | "Retention on one of your titles dropped right after an update. Walk me through the diagnosis." | CASE | [grounded] "Presented the monthly retention numbers to the studio head." | Clarify the metric's definition and the comparison window. Split by segment: new versus returning, platform, version, cohort. Check whether anything else shipped in the window. Separate the update from outside effects. Then say who you would tell and when. Answer slot: if you have diagnosed a retention drop before, say what you looked at, in your own words; if you have not, say so. | F7 is the retention evidence. The question tests method, which the quote does not contradict. |
| A5 | "The post-event review reports KPIs to leadership. What would you put on that page, and what would you leave off?" | JD | [grounded] "Presented the monthly retention numbers to the studio head." | Lead with what the event was meant to move and the one metric that says whether it did. Leave off any figure you cannot define. Name the pick you would defend least. Then say the reporting in your material is the monthly retention numbers you presented, in those words. | F3 is the ownership gap, so this rehearses the honest version of the review. |

### B. Skeptic (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Have you planned a live-events calendar across two titles? If yes, walk me through it. If no, what would you do differently?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | **Highest-ROI prep in this pack.** Answer slot: if you have planned a calendar across more than one title, say which and what part was yours. If not, say so plainly, then describe how you would run two, starting from the calendar you ran. Hold through two follow-ups by returning to that sentence, never by adding to it. | F1 is the only calendar evidence and the JD asks for two titles. This is the objection most likely to come up in some form. |
| B2 | "You have never worked on a game with in-app purchases. How would you plan KPIs for one?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Plain acknowledgment: "I haven't worked on a game with in-app purchases." Then a plan, said as a plan: how you would learn the spending metrics, which owners you would ask (economy design, live analytics), and which events you would read first. Never claim monetization experience. | F10, a gap you stated. The JD does not name IAP, so this is a skeptic's probe, not a listed requirement. |
| B3 | "On day one, what do you need to know about our two titles before you change anything?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio." | Name what you would read first: the current calendar commitments for both titles, the last post-event reports, the release checklist as it stands, and who owns each team's queue. Do not promise changes before those are read. | F5 and F1 leave the two-title scope open. The skeptic tests whether you know what you do not know. |
| B4 | "Coordinating four teams on an update without managing them is harder than it sounds. Tell me about a time you got design, art or engineering to move on a date you set." | EXP | [grounded] "Wrote the release checklist our QA team still uses." and "Never led a team, and never worked on a game with in-app purchases." | Answer slot: if you have got a design, art, engineering or community team to move on a date, say which and how. If you have not, say so plainly: "I haven't led a team." Then describe how you would set up the handoffs for the next update, starting from the checklist you wrote. | F2 is discovery, so the honest branch should be ready before the probe. |

### C. Data-Driven Prober (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the monthly retention numbers you presented were counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Answer slot: if you know how the figures were counted, say it in your words. If you do not, say so plainly. Name the assumption behind them you would defend least, if you know one. Your material contains no figure, so none is offered here. | F7 and the JD's retention line. Probers test exactly this, and a method you cannot repeat under a second question is worse than none. |
| C2 | "Which part of that retention presentation was yours: the numbers, the slides, or the delivery?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Answer slot: say which parts were yours and which were someone else's, in your own words. If you did not prepare the numbers, say so. If you did, say how. | Attribution under probe. The quote supports presenting, nothing more. |
| C3 | "What retention metric would you check first after a new live event, and what would make you distrust it?" | JD | [generic] | Name the metric by definition, such as returning-player retention or a day-N cohort, and the comparison it needs. Name the distortion you would check first: the window, the cohort mix, an overlapping release. | JD's retention line as a method question. No claim about your past. |
| C4 | "The post-event review and its KPIs: which would you own, and why those?" | JD | [grounded] "Presented the monthly retention numbers to the studio head." | Name the KPIs you would own and the one you would only read. Then: the retention reporting in your material is the monthly retention numbers you presented, in those words. Do not describe owning a post-event review. Answer slot: if you have owned one, say which. | F3, the ownership gap, asked as a choice. |

### D. Pressure / Stress (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why should we hire someone who has never worked on a game with in-app purchases?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Pause and restate the question. Hold: "I haven't worked on a game with in-app purchases." Then your position, from your own quotes: the calendar you ran and the checklist you wrote. If pressed, concede one specific thing: "I'd need to learn the spending metrics." Hold through two follow-ups. Concede only that gap, never the core claim. | F10 under time pressure. The hold-then-concede structure is the rehearsal. |
| D2 | "That release checklist. How much of it was actually you?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Hold: "I wrote it, and QA still uses it." Answer slot: if others changed sections, say which. If you wrote it end to end, say so. Do not claim QA approved it unless you know that. | F4 attribution under pressure. |
| D3 | "You've never led a team, and this one needs four functions moving together. Why isn't this a scope problem you hand back in six months?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Hold: "I haven't led a team." Then how you would scope the first months: what you would take on, what you would name early as needing support, and what you would report back. Concede a specific thing if pressed: "I'd want to name the scope early." Hold through two follow-ups. | F9, with the honest answer ready before the challenge. |

### E. Conversational / Rapport (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." | A 90-second arc: the puzzle studio and your role there, the weekly content-drop calendar, the release checklist, the retention presentation. Stop there; do not pad. | Opener, scored for economy. F5 and F6 carry it. |
| E2 | "What games do you play that run live events well?" | JD | [generic] | Name one game you can describe by its event cadence and one thing you noticed about how it runs events. Do not claim familiarity beyond what you can explain. | A casual question on a JD topic is still scored. No claim about your past. |

### Requirement coverage

| JD requirement | Questions |
|---|---|
| Plan and run the live-events calendar for two of our mobile titles | A1, B1, B3 |
| coordinate design, art, engineering and community teams on each update | A3, B4, D3 |
| own the post-event review and the KPIs it reports | A5, C4 |
| manage the release checklist with QA | A2, D2 |
| 3+ years producing live-service games or apps | B3, E1 |
| experience running a content calendar | A1, E1 |
| comfortable with player-retention metrics | A4, C1, C3 |
| clear written communication | none, and why: no written exercise has been announced. Add one if the recruiter names it |

Not in the JD, but raised by your gaps: in-app purchases (B2, D1) and team leadership (D3). Session total: 18 questions, weighted 5, 4, 4, 3, 2.

## Reverse questions for Tobias

1. **"What did the last post-event review change in the calendar, and who acted on it?"** Why it lands: it shows you care about the review loop, which is the ownership line in the JD.
2. **"Which of the two titles needs the most from this role in the next two quarters?"** Why it lands: it tests scope priority and asks him to name a title.
3. **"How does the release checklist with QA run today, and where does it slow an update down?"** Why it lands: it shows you read the QA line and have thought about the checklist's real use.
4. **"Where are the retention and monetization KPIs for these titles decided, and who in live operations is in that room?"** Why it lands: it handles the IAP gap as a question about process, not as a claim.
5. **"What would success look like for this role at the six-month mark?"** Why it lands: it asks him to define the job, which is the most useful thing a hiring manager can answer.

No reverse question is tied to his career path, since no profile was read. The round is not a peer round, so no reciprocity question is included.

## Prohibited claims

These are not coached anywhere in this pack. Each entry names its basis and its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned or led the two-title calendar | Inflated form of F1 | F1's quote at its own scope: one title, weekly content drops. Limit, as the pack's observation: your material shows one title, not two. B1's slot stays inside what was yours. |
| Coordinated design, art, engineering and community on updates | Inflated form of F2 | No quote supports it. Your material shows the QA checklist only. Limit, as the pack's observation. |
| Owned the post-event review and its KPIs | Inflated form of F3 | F3's quote at its own scope: you presented monthly retention numbers. |
| Managed the release checklist with QA | Inflated form of F4, taking the JD's verb | F4's quote: you wrote the checklist and QA uses it. |
| Explained how the retention figures were counted | Practice not in the quotes (F7) | Nothing. C1 is an answer slot only. |
| Led or managed a team | Negative you stated (F9) | "I haven't led a team." |
| Monetization or in-app purchase experience | Negative you stated (F10) | "I haven't worked on a game with in-app purchases." |

## Sources

Provided documents: the JD and the background in your message. No dossier was present.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | unavailable | Search refused, so no published values were read. The values cheat sheet is absent. Pasting the values page would supply it. |
| 2. Saltmarsh Games interview process live operations producer | unavailable | Search refused. No loop source established the loop, so the fallback is the generic archetype: flat weights, no values round assumed. |
| 3. Saltmarsh Games strategy / recent news | unavailable | Not sent, since the budget went to targets 1, 2 and 4 first. Would have moved the CO bank and the grounding brief; this pack has no CO questions. |
| 4. Tobias Wrenfield Saltmarsh Games | unavailable | Search refused. The interviewer read is absent, and the reverse questions are role-generic. |
| 5. representative Live Operations Producer JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions. |

Queries sent, all refused: "Saltmarsh Games values"; "Saltmarsh Games interview process live operations producer"; "Tobias Wrenfield Saltmarsh Games Head of Live Operations".

## Upgrade menu

- Pasted text of Saltmarsh's published values page → a values cheat sheet, and a check on whether the round is values-style
- Your recruiter's email on the round format → whether there is a panel, a pre-declared exercise or a presentation, and loop-based persona weights
- Tobias's public profile, or a link to his talks or writing, pasted → a persona read and a reverse question tied to his career path
- Whether you have planned anything across more than one title, or coordinated design, art, engineering or community on an update → rows F1 and F2, and the B1 and B4 slots, upgrade to grounded material
- The retention figure you presented and how it was counted, in your words → C1 and F7 upgrade to a defended number
- A deeper research pass (strategy brief, interviewer talks, loop reports): up to 6 more searches and 2 more fetches, several minutes. If search access is granted, it can run once
- `tuesday-dossier.md`, if you have one from earlier work: its verified evidence and prohibited claims would bind every guidance cell. Without it, the prohibited list above is built locally

---

Want me to play the Skeptic on B1? That is the question the pack names as the highest-return prep.

I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions. If you want the pack as a Word document, say so and I'll convert it.

Is Tobias your future manager, or is there a panel or a pre-set exercise on Friday? The answer reweights the banks.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh_live_operations_producer_interview_pack.md -----
# Interview prep pack: Live Operations Producer, Saltmarsh Games

Interviewer: Tobias Wrenfield, Head of Live Operations. Relationship assumed to be hiring manager (60 minutes). Built from the JD and background in your note. Company research was refused on this run, so nothing below is about Saltmarsh beyond the JD itself.

## How to use this pack

Personas describe how a question arrives. Types describe what is being scored: **JD** (the listed responsibilities), **EXP** (your past work and how you attribute it), **CASE** (a live problem), **CO** (company knowledge), **VAL** (values). Guidance is scaffolding, not a script. Say it in your own words, and only what you did.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | transferability | Your material shows one title and weekly content drops, not live events across two titles. Bridge stays at the calendar you ran: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: if you have planned or run a calendar across more than one title, say which and what was yours; if not, say so plainly and say how you would sequence two. |
| F2 | "coordinate design, art, engineering and community teams on each update" (JD) | "Wrote the release checklist our QA team still uses." (your message) | low | [inferred] | discovery | Your material does not show coordination with design, art, engineering or community on updates. The checklist touches QA only. Answer slot: if you coordinated any of those four teams on an update, say which and how, in your own words; if you did not, say so and describe how you would set up those handoffs. |
| F3 | "own the post-event review and the KPIs it reports" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | medium | [grounded] | transferability | Presenting monthly numbers is reporting, not owning a post-event review. Bridge: "I presented the monthly retention numbers to the studio head." Answer slot: if you owned a post-event review or its KPIs, say which and how; if you did not, say so plainly. |
| F4 | "manage the release checklist with QA" (JD) | "Wrote the release checklist our QA team still uses." (your message) | medium | [grounded] | presentation | The quote reaches the requirement in other terms: you wrote the checklist and QA uses it. Bridge: "I wrote the release checklist our QA team still uses." Do not say "managed". |
| F5 | "3+ years producing live-service games or apps" (JD) | "4 years as an associate producer at a puzzle-game studio." (your message) | medium | [grounded] | presentation | Four years is the fit. Your material does not say the puzzle title ran on a live-service cadence, and the title is associate. Bridge: "4 years as an associate producer at a puzzle-game studio." Answer slot: if you carried responsibilities above that title, say which and how you decided, in your own words; if not, say so and stay with the four years. |
| F6 | "experience running a content calendar" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | none | The quote reaches the requirement directly. Expect a probe on what you decided. Answer slot: if any calendar decisions were set by others, say which. |
| F7 | "comfortable with player-retention metrics" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | medium | [grounded] | none | The quote reaches the requirement in role terms. Expect a probe on how the figures were counted. No figure is in your material, so none is offered here. Answer slot: if you know how they were counted, say so in your words; if not, say that plainly. |
| F8 | "clear written communication" (JD) | "Wrote the release checklist our QA team still uses." (your message) | medium | [grounded] | presentation | A written artifact a team still uses is the evidence. Bridge: "I wrote the release checklist our QA team still uses." Nothing added. |
| F9 | lead a team of people (role-family prose, not in the JD text) | "Never led a team, and never worked on a game with in-app purchases." (your message) | none | [grounded] | capability | A gap you stated. Words: "I haven't led a team." Then how you would learn to lead a team, said as a plan and never as a past. |
| F10 | in-app purchase and monetization experience (role-family prose, not in the JD text) | "Never led a team, and never worked on a game with in-app purchases." (your message) | none | [grounded] | capability | A gap you stated. Words: "I haven't worked on a game with in-app purchases." Then how you would learn the spending metrics, said as a plan. |

The pack's own observations, from your material and not words for you to say: the JD asks you to coordinate four teams, not to manage them, so F9 is a probe risk, not a listed requirement. Two titles, live events and KPI ownership are the three places where the JD asks for more than your material shows.

## Persona table

Weights are relationship priors for a hiring-manager round, adjusted for the JD. No loop source was read, so the loop is the generic fallback: flat weights, said plainly.

| Persona | Weight | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|---|
| Case / Strategist | 5 (top) | A live problem on his own calendar: two titles, one update, a bad day-two event | Hiring-manager prior. The JD is a responsibilities list, so he is likely to hand you one. | Clarify, then structure, then name the metric. Think aloud. |
| Skeptic | 4 | Quiet, persistent probing of the gaps: one title, no IAP, no team | Hiring-manager prior. The gaps in F1, F2, F9 and F10 are where a skeptic presses. | Rehearse the most predictable objection until it is boring. Concede specifically. |
| Data-Driven Prober | 4 | Follow-ups on how the retention figure was counted and who owned the KPIs | Not a default for this relationship, raised to 4 by the JD's KPI and retention language and by F7. | Know what you can and cannot say about each number. Name the weakest assumption you know. |
| Pressure / Stress | 3 | Time-boxed answers, sharp challenges on the IAP and team gaps | Not in the relationship prior. A 60-minute slot raises the chance of time-boxing. | Pause, restate, hold through two follow-ups, concede only the specific gap. |
| Conversational / Rapport | 2 | A "walk me through the journey" opener and a casual question about a JD topic | Low weight, but scored. Casual questions on JD topics count. | A 90-second arc. Treat casual questions as scored. |

## Question banks

Provenance comes first in each row. A row whose guidance makes no claim about you carries its label alone.

### A. Case / Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Two titles, one live-events calendar. Plan next month's events for both, with one design team and one art team. What do you do first?" | CASE | [generic] | Clarify before structuring: each title's goal for the month, what is already committed, which constraints are real. Then structure: objective, dependencies across design, art, engineering, community and QA, sequencing, risks, and the metric each event is judged on. Say what you would ask before you commit a date. Rehearse it aloud in 90 seconds. | JD's first requirement and the likeliest live problem. CASE because the answer is reasoning, not record. No claim about your past. |
| A2 | "Day two of a live event: a reward is paying out wrong for some players, and engagement is down. What do you do in the next 24 hours?" | CASE | [grounded] "Wrote the release checklist our QA team still uses." | Confirm scope and who is affected. Decide between pausing, a hotfix and communicating. Say who decides and how fast. Answer slot: say whether the release checklist has a rollback or hotfix step. If it does, name it; if it does not, say so and propose adding one. | JD's release checklist with QA, and F4's checklist is the only release-process evidence. |
| A3 | "A designer wants a bigger event than the art team can finish in the window. How do you resolve it?" | CASE | [generic] | Name the trade-off: scope, date, or which assets get cut. Say who decides and how quickly, what you would tell design and art the same day, and what you would record. | JD's coordination line, as a live conflict rather than a record. No claim about your past. |
| A4 | "Retention on one of your titles dropped right after an update. Walk me through the diagnosis." | CASE | [grounded] "Presented the monthly retention numbers to the studio head." | Clarify the metric's definition and the comparison window. Split by segment: new versus returning, platform, version, cohort. Check whether anything else shipped in the window. Separate the update from outside effects. Then say who you would tell and when. Answer slot: if you have diagnosed a retention drop before, say what you looked at, in your own words; if you have not, say so. | F7 is the retention evidence. The question tests method, which the quote does not contradict. |
| A5 | "The post-event review reports KPIs to leadership. What would you put on that page, and what would you leave off?" | JD | [grounded] "Presented the monthly retention numbers to the studio head." | Lead with what the event was meant to move and the one metric that says whether it did. Leave off any figure you cannot define. Name the pick you would defend least. Then say the reporting in your material is the monthly retention numbers you presented, in those words. | F3 is the ownership gap, so this rehearses the honest version of the review. |

### B. Skeptic (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Have you planned a live-events calendar across two titles? If yes, walk me through it. If no, what would you do differently?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | **Highest-ROI prep in this pack.** Answer slot: if you have planned a calendar across more than one title, say which and what part was yours. If not, say so plainly, then describe how you would run two, starting from the calendar you ran. Hold through two follow-ups by returning to that sentence, never by adding to it. | F1 is the only calendar evidence and the JD asks for two titles. This is the objection most likely to be asked in some form. |
| B2 | "You have never worked on a game with in-app purchases. How would you plan KPIs for one?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Plain acknowledgment: "I haven't worked on a game with in-app purchases." Then a plan, said as a plan: how you would learn the spending metrics, which owners you would ask (economy design, live analytics), and which events you would read first. Never claim monetization experience. | F10, a gap you stated. The JD does not name IAP, so this is a skeptic's probe, not a listed requirement. |
| B3 | "On day one, what do you need to know about our two titles before you change anything?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio." | Name what you would read first: the current calendar commitments for both titles, the last post-event reports, the release checklist as it stands, and who owns each team's queue. Do not promise changes before those are read. | F5 and F1 leave the two-title scope open. The skeptic tests whether you know what you do not know. |
| B4 | "Coordinating four teams on an update without managing them is harder than it sounds. Tell me about a time you got design, art or engineering to move on a date you set." | EXP | [grounded] "Wrote the release checklist our QA team still uses." and "Never led a team, and never worked on a game with in-app purchases." | Answer slot: if you have got a design, art, engineering or community team to move on a date, say which and how. If you have not, say so plainly: "I haven't led a team." Then describe how you would set up the handoffs for the next update, starting from the checklist you wrote. | F2 is discovery, so the honest branch is ready before the probe. |

### C. Data-Driven Prober (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the monthly retention numbers you presented were counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Answer slot: if you know how the figures were counted, say it in your words. If you do not, say so plainly. Name the assumption behind them you would defend least, if you know one. Your material contains no figure, so none is offered here. | F7 and the JD's retention line. Probers test exactly this, and a method you cannot repeat under a second question is worse than none. |
| C2 | "Which part of that retention presentation was yours: the numbers, the slides, or the delivery?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Answer slot: say which parts were yours and which were someone else's, in your own words. If you did not prepare the numbers, say so. If you did, say how. | Attribution under probe. The quote supports presenting, nothing more. |
| C3 | "What retention metric would you check first after a new live event, and what would make you distrust it?" | JD | [generic] | Name the metric by definition, such as returning-player retention or a day-N cohort, and the comparison it needs. Name the distortion you would check first: the window, the cohort mix, an overlapping release. | JD's retention line as a method question. No claim about your past. |
| C4 | "The post-event review and its KPIs: which would you own, and why those?" | JD | [grounded] "Presented the monthly retention numbers to the studio head." | Name the KPIs you would own and the one you would only read. Then: the retention reporting in your material is the monthly retention numbers you presented, in those words. Do not describe owning a post-event review. Answer slot: if you have owned one, say which. | F3, the ownership gap, asked as a choice. |

### D. Pressure / Stress (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why should we hire someone who has never worked on a game with in-app purchases?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Pause and restate the question. Hold: "I haven't worked on a game with in-app purchases." Then your position, from your own quotes: the calendar you ran and the checklist you wrote. If pressed, concede one specific thing: "I'd need to learn the spending metrics." Hold through two follow-ups. Concede only that gap, never the core claim. | F10 under time pressure. The hold-then-concede structure is the rehearsal. |
| D2 | "That release checklist. How much of it was actually you?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Hold: "I wrote it, and QA still uses it." Answer slot: if others changed sections, say which. If you wrote it end to end, say so. Do not claim QA approved it unless you know that. | F4 attribution under pressure. |
| D3 | "You've never led a team, and this one needs four functions moving together. Why isn't this a scope problem you hand back in six months?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Hold: "I haven't led a team." Then how you would scope the first months: what you would take on, what you would name early as needing support, and what you would report back. Concede a specific thing if pressed: "I'd want to name the scope early." Hold through two follow-ups. | F9, with the honest answer ready before the challenge. |

### E. Conversational / Rapport (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." | A 90-second arc: the puzzle studio and your role there, the weekly content-drop calendar, the release checklist, the retention presentation. Stop there; do not pad. | Opener, scored for economy. F5 and F6 carry it. |
| E2 | "What games do you play that run live events well?" | JD | [generic] | Name one game you can describe by its event cadence and one thing you noticed about how it runs events. Do not claim familiarity beyond what you can explain. | A casual question on a JD topic is still scored. No claim about your past. |

### Requirement coverage

| JD requirement | Questions |
|---|---|
| Plan and run the live-events calendar for two of our mobile titles | A1, B1, B3 |
| coordinate design, art, engineering and community teams on each update | A3, B4, D3 |
| own the post-event review and the KPIs it reports | A5, C4 |
| manage the release checklist with QA | A2, D2 |
| 3+ years producing live-service games or apps | B3, E1 |
| experience running a content calendar | A1, E1 |
| comfortable with player-retention metrics | A4, C1, C3 |
| clear written communication | none, and why: no written exercise has been announced. Add one if the recruiter names it |

Not in the JD, but raised by your gaps: in-app purchases (B2, D1) and team leadership (D3). Session total: 18 questions, weighted 5, 4, 4, 3, 2.

## Reverse questions for Tobias

1. **"What did the last post-event review change in the calendar, and who acted on it?"** Why it lands: it shows you care about the review loop, which is the ownership line in the JD.
2. **"Which of the two titles needs the most from this role in the next two quarters?"** Why it lands: it tests scope priority and asks him to name a title.
3. **"How does the release checklist with QA run today, and where does it slow an update down?"** Why it lands: it shows you read the QA line and have thought about the checklist's real use.
4. **"Where are the retention and monetization KPIs for these titles decided, and who in live operations is in that room?"** Why it lands: it handles the IAP gap as a question about process, not as a claim.
5. **"What would success look like for this role at the six-month mark?"** Why it lands: it asks him to define the job, which is the most useful thing a hiring manager can answer.

No reverse question is tied to his career path, since no profile was read, and the round is not a peer round, so no reciprocity question is included.

## Prohibited claims

These are not coached anywhere in this pack. Each entry names its basis and its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned or led the two-title calendar | Inflated form of F1 | F1's quote at its own scope: one title, weekly content drops. Limit, as the pack's observation: your material shows one title, not two. B1's slot stays inside what was yours. |
| Coordinated design, art, engineering and community on updates | Inflated form of F2 | No quote supports it. Your material shows the QA checklist only. Limit, as the pack's observation. |
| Owned the post-event review and its KPIs | Inflated form of F3 | F3's quote at its own scope: you presented monthly retention numbers. |
| Managed the release checklist with QA | Inflated form of F4, taking the JD's verb | F4's quote: you wrote the checklist and QA uses it. |
| Explained how the retention figures were counted | Practice not in the quotes (F7) | Nothing. C1 is an answer slot only. |
| Led or managed a team | Negative you stated (F9) | "I haven't led a team." |
| Monetization or in-app purchase experience | Negative you stated (F10) | "I haven't worked on a game with in-app purchases." |

## Sources

Provided documents: the JD and the background in your message. No dossier was present.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | unavailable | Search refused, so no published values were read. The values cheat sheet is absent. Pasting the values page would supply it. |
| 2. Saltmarsh Games interview process live operations producer | unavailable | Search refused. No loop source established the loop, so the fallback is the generic archetype: flat weights, no values round assumed. |
| 3. Saltmarsh Games strategy / recent news | unavailable | Not sent, since the budget went to targets 1, 2 and 4 first. Would have moved the CO bank and the grounding brief; this pack has no CO questions. |
| 4. Tobias Wrenfield Saltmarsh Games | unavailable | Search refused. The interviewer read is absent, and the reverse questions are role-generic. |
| 5. representative Live Operations Producer JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions. |

Queries sent, all refused: "Saltmarsh Games values"; "Saltmarsh Games interview process live operations producer"; "Tobias Wrenfield Saltmarsh Games Head of Live Operations".

## Upgrade menu

- Pasted text of Saltmarsh's published values page → a values cheat sheet, and a check on whether the round is values-style
- Your recruiter's email on the round format → whether there is a panel, a pre-declared exercise, or a presentation, and loop-based persona weights
- Tobias's public profile or a link to his talks or writing, pasted → a persona read and a reverse question tied to his career path
- Whether you have planned anything across more than one title, or coordinated design, art, engineering or community on an update → rows F1 and F2 and the B1 and B4 slots upgrade to grounded material
- The retention figure you presented and how it was counted, in your words → C1 and F7 upgrade to a defended number
- A deeper research pass (strategy brief, interviewer talks, loop reports): up to 6 more searches and 2 more fetches, several minutes. If search access is granted, it can run once
- `tuesday-dossier.md`, if you have one from earlier work: its verified evidence and prohibited claims would bind every guidance cell. Without it, the prohibited list above is built locally
