The search tool was denied permission, so I can't run company research this session. I'll build the pack from your JD and background, label every claim by source, and write the file now.
Your prep pack is saved at /tmp/claude-0/-var-tmp-tuesday-measure-1a6-runs-haiku-alone-part-2-rooms-case-2-denied-270af7a2/aa0db711-5fff-45fb-b840-5ea3d1dfc526/scratchpad/atlas-freight_operations-manager_interview_pack.md. It is built only from your JD and your background. I could not research Atlas Freight because the web search tool was denied permission, so the pack has no company values, interview-process or strategy content. Those sections are missing, not guessed.

The pack covers:
- **Fit snapshot:** each JD requirement against your own words, with gap-and-bridge language.
- **Biggest objection:** "You lead three supervisors today, and this role leads twelve across four sites." Rehearse that one first.
- **Gaps:** multi-site scope, the 12-supervisor span and Power BI are the thin spots. Excel and Lean/Six Sigma are your strongest matches.
- **Question banks:** 18 questions across five interviewer styles, each with answer guidance and a rationale.
- **Reverse questions:** six to ask them.

One correction on my side: I launched a background research agent by mistake and stopped it right away. It produced nothing that the pack uses.

Question for you: what round is this, and who are you meeting? A hiring manager, a peer, or a panel? The answer reweights the question banks. If you also share the interviewer names, I can tailor the reverse questions and personas to them.

Other options:
- **Drill:** I can play the Skeptic and put the scale question to you live, then give feedback.
- **Dossier:** I can save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions.
- **Word:** I can convert the pack to a Word document.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: atlas-freight_operations-manager_interview_pack.md -----
# Interview prep pack: Operations Manager, Atlas Freight

Round and interviewer: not yet known. Built as a flat, hiring-manager-leaning default (see Persona table). Reweight once you know who you are meeting.

## How to use this pack

- **Personas** describe how a question will be asked (the delivery style). **Types** describe what is being scored.
- Type key: **JD** = can you do the listed job, including its gaps. **EXP** = what you actually did in your past roles. **CASE** = a live problem from the role, reasoned aloud. **CO** = company knowledge (none included: company research was not available this session). **VAL** = values fit (none included: no values-style round is established).
- Guidance is scaffolding, not a script. Rehearse it in your own words, 90 to 120 seconds per answer.
- Answer slots are instructions for the interview, not questions to answer here. Each has an honest branch for when the practice was not yours or did not happen.

## The fit snapshot

Requirements are quoted from the JD you supplied. Evidence is quoted from your own message, the only candidate material available. Confidence grades your evidence. Provenance grades this pack's statement about it.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own daily terminal operations across 4 sites" (JD) | "7 years in warehouse and distribution ops" (your message) | medium | [grounded] | transferability | Your material gives warehouse and distribution operations. It does not show ownership across more than one site, so do not stretch the bridge. Answer slot: if you have run or overseen operations at more than one site, say which, your role at each, and the scale. If you have worked at one site, say so and say how you would run four. |
| F2 | "drive on-time performance and cost-per-shipment down" (JD) | "cut mis-pick rate 40% by redesigning the pick path" (your message) | medium | [grounded] | transferability | Your result is a mis-pick rate. It is not on-time performance or cost per shipment. Say the mis-pick result in those terms and no further. Answer slot: if you tracked on-time or cost per shipment during that work, say what and how; if you did not, say so and say which measure you would use first. |
| F3 | "lead a team of 12 supervisors" (JD) | "currently a senior shift manager over 3 supervisors" (your message) | medium | [grounded] | transferability | Your current scope is 3 supervisors. The JD asks for 12. Say the 3 plainly. Answer slot: if you have led a larger group of supervisors or staff, say the number and the setting. If not, say so and say how you would structure 12 supervisors across four sites. |
| F4 | "5+ years operations leadership required" (JD) | "7 years in warehouse and distribution ops" (your message) | low | [inferred] | discovery | Your message gives seven years of operations, not how many were in a leadership role. Length of experience is not a gate, but the leadership span is unknown here. Answer slot: how many of those seven years you were in a leadership role, and what you led in each. |
| F5 | "build reporting in Excel/Power BI" (JD), Excel part | "solid Excel" (your message) | medium | [grounded] | presentation | Your material says Excel is solid. It does not say what reports you built or what they drove. Say "solid Excel" in your own words. Answer slot: name one report you built in Excel and what it was used for. If the reporting was someone else's, say so. |
| F6 | "build reporting in Excel/Power BI" (JD), Power BI part | "never used Power BI" (your message) | none | [grounded] | capability | You stated this absence. Words: "I haven't used Power BI." Then how you would learn it, as a plan and never as a past. No claim to Power BI work of any kind. |
| F7 | "Lean/Six Sigma a plus" (JD) | "green belt certified" (your message) | medium | [grounded] | none | The quote already reaches the requirement. Certification is inspectable: having the certificate to hand raises this row. Expect a probe on what the green belt project was, if there was one. |
| F8 | Not a JD requirement. Story source for the peak-season and pick-path questions | "ran the site's peak-season surge plan two years running" (your message) | medium | [grounded] | none | This is a story source. It carries the scope "the site's" and "two years running", and nothing beyond what it states. |

Gate rows: none. The JD as supplied states no licence, credential, location or schedule term, and nothing about the candidate's location or availability was given. If the role requires being on site at a particular location, or travel between the four sites, that is a gate this pack cannot assess until you say.

## Prohibited list

What this pack will not coach, and why. Each entry shows its basis and its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Runs multi-site terminal operations | Inflated form of F1: the material says one site's operations | Your material says 7 years in warehouse and distribution ops. The limit is this pack's observation: the material does not show multi-site ownership. A1 and A2 stay within your own scope |
| Has delivered on-time or cost-per-shipment improvement | Inflated form of F2: the material says a mis-pick result | "I cut the mis-pick rate 40% by redesigning the pick path." Nothing further |
| Leads a team of 12 supervisors | Inflated form of F3: the material says 3 supervisors | "I'm a senior shift manager over 3 supervisors." Nothing further |
| Has built Power BI reporting, or is experienced in Power BI | Stated negative, F6 | "I haven't used Power BI." Plain acknowledgment, then a plan. No slot |
| Has led a green belt project | Inflated form of F7: the material says certified | "I'm green belt certified." Nothing further |

## Persona table

Round type is unknown, so weights are a flat default that leans toward a hiring manager. The reasoning is shown so you can correct it.

| Persona | How it shows up | Likelihood | Reasoning | Counter-strategy |
|---|---|---|---|---|
| Skeptic | Quiet probing of the scale and multi-site gaps, "why you, why now" | High, top weight | An operations manager role with a 12-supervisor and 4-site scope invites the cross-examination of your 3-supervisor scope. F1, F3 and F4 are the gap rows | Rehearse the single most predictable objection until it is plain. Say the 3 supervisors and the 7 years exactly as quoted, then the answer slot |
| Case / Strategist | Live problems: an on-time drop, a cost rise, a 90-day plan | High | The JD's OTP and cost-per-shipment lines are live problems in the role | Clarify definitions first, then segment, then pick the one lever |
| Data-Driven Prober | Walk me through the numbers; what was the baseline | High | The 40% mis-pick figure and the Excel reporting are the numbers a prober will test | Name the weakest assumption before they do. Say plainly what you cannot say about how a figure was counted |
| Pressure | Time-boxed challenge: why you over someone with a bigger team | Medium | Scope mismatch with the 12-supervisor ask | Hold on the result you can back. Concede team size plainly. Do not fold on the core claim |
| Conversational | Friendly walk-through of your journey; a casual Excel question | Medium | Casual questions are still scored | A 90-second arc in your own words. Do not improvise numbers |

## Question banks

Provenance comes first. Each candidate sentence the guidance rests on is quoted exactly.

### Skeptic (weight: top, 5 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" (your message) | Name the requirement you would be weakest on and say what you would do in the first 90 days. Answer slot: if you have led more people or sites than your current scope, say so with the numbers. If not, say your current scope is 3 supervisors and name the one gap you would close first | This is the Skeptic's opening move. F3 and F1 are the likeliest answers, and naming them first prevents the probe from landing as a surprise |
| A2 | "You lead three supervisors today, and this role leads twelve across four sites. What's the bridge?" (highest-ROI prep in this pack) | JD | [grounded] "currently a senior shift manager over 3 supervisors" (your message) | Highest-ROI prep. Say the 3 first, exactly as quoted. Answer slot: if you have led a larger group or more sites, say the numbers and the setting. If not, say so and say how you would structure 12 supervisors across four sites. Hold through two follow-ups by returning to the 3 and your plan, never by adding scope. Concede plainly where the gap is real | F3 and F1 together are the most predictable objection. The answer must be ready before the probe, because a bluffed scale claim is the one that breaks on the second follow-up |
| A3 | "What's your Power BI experience?" | JD | [grounded] "never used Power BI" (your message) | "I haven't used Power BI." Then how you would learn it: the tool, a timeframe, and which Excel reporting you would port first. Do not describe any Power BI work | F6 is a stated gap. The honest answer is the plain negative and a plan, which is what a Skeptic tests for |
| A4 | "Walk me through a report you built in Excel. What did it drive?" | JD | [grounded] "solid Excel" (your message) | Answer slot: name one report you built and what decision or action it drove. If the reporting was someone else's, say so and describe the part you used | F5 is the Excel half of the reporting requirement. A probe on the report's use is likely; the honest branch is ready |
| A5 | "What would you need from IT to deliver a dashboard in the first month?" | CASE | [generic] | Structure it: data sources, refresh cadence, who owns access, and what you would deliver first. This needs no claim about your past | A live problem from the reporting line of the JD. Asked as a plan, it does not depend on Power BI experience you do not have |

### Case / Strategist (weight: 4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "On-time performance is down at one terminal and cost per shipment has risen. Where do you start?" | CASE | [generic] | Clarify the definitions first: on-time measured how, and against which cutoff. Then segment by shift, lane and volume. Check labour against volume before changing process. Pick one lever and say what would tell you it worked | Direct from the JD's OTP and cost lines. Generic: a pattern for the problem, not a fact about Atlas Freight |
| B2 | "Plan your first 90 days across four sites." | CASE | [generic] | Clarify what success means in year one. Then listen, then measure each site the same way, then act on the one site with the largest gap. Name the risk of changing four sites at once | The JD's 4-site scope, asked as a plan. Needs no claim about your past |
| B3 | "Take us through how you ran peak season." | EXP | [grounded] "ran the site's peak-season surge plan two years running" (your message) | Story-mapped on F8: the surge plan, run two years running at the site. Tell it in your own words: what the plan covered, and how you knew it was working. Answer slot: what did the plan ask of your supervisors, and what was your part in it? If the plan was set above you, say so | F8 is your strongest story source for the scale question. The surge plan is the nearest thing in your material to running a site's daily operation |
| B4 | "At a site with flat volume, where would you cut cost per shipment first?" | CASE | [generic] | Look at labour hours per shipment, overtime and idle time before tools or contracts. Say what you would measure before you changed anything | A live problem from the cost line. Generic reasoning, with no claim about any past cost work |

### Data-Driven Prober (weight: 4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the 40% mis-pick reduction was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Name the weakest assumption before they do: the baseline and the period, in your own words. If you cannot say how it was counted, say so plainly. Do not supply a baseline you did not state | F2 is the headline figure, and a prober tests the denominator first. Naming the weakest assumption turns a gotcha into a credibility gain |
| C2 | "Did you track on-time performance or cost per shipment during that work?" | JD | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Answer slot: if you tracked either, say what and how. If not, say so, and say which measure you would use first. Do not claim the mis-pick figure moved either one | F2 is the bridge to the role's two headline metrics. The honest answer is what you did track, or that you did not track them |
| C3 | "What reporting did you build for the surge plan?" | EXP | [grounded] "ran the site's peak-season surge plan two years running" (your message); [grounded] "solid Excel" (your message) | Answer slot: name the reporting you built for the surge plan and how it was used. If the reporting was not yours, say so, and say what you did use | Connects F5 to F8: the reporting question is where Excel meets the role's reporting line |
| C4 | "How do the green belt and the pick-path work connect?" | JD | [grounded] "green belt certified" (your message); [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Say the certification as quoted. Answer slot: if the pick-path work used green belt methods, say which and how. If the certification is separate from that work, say so | F7 and F2 are two facts a prober will try to join. Do not join them unless you did |

### Pressure (weight: 3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why should we hire you over someone who has run a bigger team?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" (your message); [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Hold the position on the one result you can back: the 40% mis-pick reduction and the peak plan. Concede the team size plainly. Hold through two follow-ups; do not fold on the result itself | Pressure questions test composure. The concession is specific: team size, not your ability |
| D2 | "That 40%. How much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Hold: say what you did in the redesign, in your own words. Concede: which parts were the team's, if any. Answer slot: if the redesign was a team decision, say so and say what you proposed | Attribution under pressure. Naming your share honestly is the answer; a bigger share is the one that breaks on the second follow-up |
| D3 | "This role spans four sites. What have you run at more than one?" | JD | [grounded] "7 years in warehouse and distribution ops" (your message) | Answer slot: say the sites you have worked at and your role at each. If you have worked at one site, say so and say how you would run four | F1 under pressure. The question is premised on the JD's four sites, not on a claim about your past |

### Conversational (weight: 2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "7 years in warehouse and distribution ops" (your message); [grounded] "currently a senior shift manager over 3 supervisors" (your message) | A 90-second arc: seven years in warehouse and distribution, the current role over 3 supervisors, the pick-path result, the peak plan. Each beat is the quoted sentence in your own words | An opener that is scored. Keep it to what your material states, in order |
| E2 | "What are you actually playing with in Excel these days?" | JD | [grounded] "solid Excel" (your message) | Say what you use Excel for, in your own words. If asked about Power BI, use the plain line: "I haven't used Power BI," then the plan | A casual question about a JD requirement is still scored. The plain line for Power BI is the only honest answer |

## Requirement coverage

| JD requirement | Question IDs | Note |
|---|---|---|
| Own daily terminal operations across 4 sites | B2, D3, A1 | |
| Drive on-time performance and cost-per-shipment down | B1, B4, C2 | |
| Lead a team of 12 supervisors | A2, D1 | Largest gap in the material |
| Build reporting in Excel and Power BI | A3, A4, A5, C3, E2 | Power BI is a stated gap |
| 5+ years operations leadership | E1, A2 | Length of experience is not a gate |
| Lean / Six Sigma a plus | C4 | |

## Reverse questions

Ask any of these. Each has a reason it lands. No interviewer profile was given, so none is tied to a career path.

1. "What does the first 90 days look like for someone taking over one of the four sites?" Why it lands: it shows you are already thinking about the sites in operational terms.
2. "How is on-time performance measured across the four sites, and which site is furthest behind?" Why it lands: it asks for the baseline, which is the question you should be able to answer for your own numbers.
3. "What reporting do the supervisors use today, and what is missing from it?" Why it lands: it names the reporting gap without assuming you will fill it.
4. "How are the 12 supervisors divided across the four sites, and who do they report to?" Why it lands: it shows you understand the span of control before you are asked to take it on.
5. "What would success look like at the end of the first year?" Why it lands: it gives you the scorecard the interviewer is holding.
6. "Which parts of the reporting are already built, and who owns them?" Why it lands: it tells you whether the Power BI work is greenfield or inherited, without you having to claim any experience with it.

## Sources

- Provided: the JD text you pasted, and your background in your message.
- Research: none completed. The web search tool was refused for this session (permission not granted), so no company values, interview process or strategy research ran. Nothing below is drawn from research.

Research tier: L1 — searches 3 of 6, fetches 0 of 2 (every call refused by host permission)

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Atlas Freight values | unavailable | Would have set the values cheat sheet and the VAL bank. Query sent: "Atlas Freight values" — refused |
| 2. Atlas Freight interview process, operations manager | unavailable | Would have set loop structure and the persona weights. Query sent: "Atlas Freight interview process operations manager" — refused |
| 3. Atlas Freight strategy / recent news | unavailable | Would have fed the CO bank. Query sent: "Atlas Freight regional logistics strategy news" — refused |
| 4. Interviewer name and company | n/a | No interviewer name was given, so there is no query to form |
| 5. Representative operations manager JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Round type and who you are meeting → persona weights reordered to that interviewer, and a tailored reverse question
- Search access restored (or the company's own values and interview page pasted) → values cheat sheet, loop structure, and CO questions grounded in Atlas Freight's current strategy. Without it, the pack has no company-specific content
- Green belt certificate in hand → F7 becomes an inspectable credential
- A report or dashboard you built in Excel, described or shared → F5 and C3 get a specific artifact to rehearse
- Multi-site or larger-team experience, described → F1 and F3 can be bridged from a stated fact rather than an answer slot
- Location, travel or on-site terms of the role → a gate row can be assessed
